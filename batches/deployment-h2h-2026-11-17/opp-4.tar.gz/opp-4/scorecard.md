# Doctrine scorecard: dep-opp-13df7bd-p4

### Scorecard: dep-opp-13df7bd-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 3 | - | 0 | 2 | 2 | 0 | 0 | 184 |
| L0114 | 6 | 1 | Opponent | no | 6 | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | no | 2 | - | 0 | 1 | 1 | 0 | 0 | 387 |
| L0130 | 4 | 1 | Opponent | no | 5 | 2 | 4 | 2 | 0 | 0 | 0 | 98 |
| L0214 | 4 | 1 | Mine | no | 1 | 2 | 1 | 2 | 1 | 0 | 0 | 200 |
| L0214 | 4 | 1 | Opponent | no | 5 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 3 | 1 | 4 | 0 | 0 | 0 | 170 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 1 | 3 | 1 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | yes | 3 | 3 | 2 | 1 | 0 | 0 | 0 | 675 |
| L0315 | 3 | 1 | Opponent | yes | 15 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | 3 | 2 | 1 | 0 | 0 | 0 | 590 |
| L0332 | 2 | 1 | Opponent | - | - | 1 | 3 | 3 | 1 | 0 | 0 | 170 |
| L0417 | 3 | 1 | Mine | no | 3 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | no | 5 | 2 | 1 | 0 | 0 | 0 | 0 | 219 |
| L0434 | 2 | 1 | Mine | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 2 | 1 | 3 | 0 | 0 | 0 | 107 |
| L0520 | 4 | 1 | Mine | no | 1 | - | 0 | 0 | 0 | 0 | 0 | 475 |
| L0520 | 4 | 1 | Opponent | no | 0 | - | 1 | 4 | 2 | 0 | 0 | 420 |
| L0608 | 2 | 1 | Mine | - | - | - | 0 | 3 | 1 | 0 | 0 | 615 |
| L0608 | 2 | 1 | Opponent | - | - | 5 | 1 | 2 | 0 | 0 | 0 | 605 |
| L0624 | 6 | 1 | Mine | no | 0 | 4 | 5 | 0 | 0 | 0 | 0 | 615 |
| L0624 | 6 | 1 | Opponent | no | 0 | 3 | 4 | 3 | 0 | 0 | 0 | 60 |
| L0713 | 5 | 1 | Mine | yes | - | 2 | 2 | 1 | 0 | 0 | 0 | 420 |
| L0713 | 5 | 1 | Opponent | yes | - | 3 | 2 | 0 | 1 | 0 | 0 | 140 |
| L0729 | 3 | 1 | Mine | no | 6 | 3 | 2 | 0 | 0 | 0 | 0 | 375 |
| L0729 | 3 | 1 | Opponent | no | 2 | 2 | 1 | 3 | 1 | 0 | 0 | 0 |
| L0819 | 3 | 1 | Mine | no | 0 | 1 | 2 | 0 | 1 | 0 | 0 | 802 |
| L0819 | 3 | 1 | Opponent | no | 6 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 0 | 5 | 1 | 2 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 0 | - | 0 | 4 | 1 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | 6 | 1 | 1 | 0 | 0 | 0 | 537 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | no | 5 | 2 | 5 | 0 | 0 | 0 | 0 | 456 |
| L1017 | 3 | 1 | Opponent | no | 2 | 1 | 3 | 2 | 1 | 0 | 0 | 433 |
| L1034 | 2 | 1 | Mine | - | - | - | 0 | 0 | 0 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L1126 | 4 | 1 | Mine | no | 3 | - | 0 | 0 | 1 | 0 | 0 | 427 |
| L1126 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | 1 | 0 | 2 | 1 | 0 | 0 | 210 |
| L1314 | 6 | 1 | Mine | no | 6 | 3 | 3 | 0 | 0 | 0 | 0 | 140 |
| L1314 | 6 | 1 | Opponent | yes | 9 | 1 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1331 | 5 | 1 | Mine | yes | - | 3 | 0 | 1 | 1 | 0 | 0 | 140 |
| L1331 | 5 | 1 | Opponent | yes | - | 4 | 4 | 1 | 0 | 0 | 0 | 340 |
| L1427 | 5 | 1 | Mine | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | yes | - | 2 | 3 | 3 | 1 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | yes | - | 3 | 3 | 1 | 1 | 0 | 0 | 126 |
| L1523 | 5 | 1 | Opponent | yes | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1621 | 1 | 1 | Mine | no | 1 | 2 | 2 | 1 | 0 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 1 | 2 | 2 | 3 | 0 | 0 | 0 | 355 |
| L1719 | 3 | 1 | Mine | yes | 1 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Opponent | no | 2 | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Mine | no | 0 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | yes | 1 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | yes | - | 6 | 1 | 2 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | no | - | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2021 | 5 | 1 | Mine | no | - | 4 | 0 | 5 | 1 | 0 | 0 | 210 |
| L2021 | 5 | 1 | Opponent | no | - | 5 | 2 | 4 | 0 | 0 | 0 | 0 |
| L2123 | 5 | 1 | Mine | no | - | - | 0 | 6 | 0 | 0 | 0 | 577 |
| L2123 | 5 | 1 | Opponent | no | - | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | yes | 4 | 3 | 2 | 0 | 0 | 0 | 0 | 170 |
| L2227 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 1 | 0 | 0 | 380 |
| L2331 | 3 | 1 | Mine | no | 0 | 1 | 3 | 1 | 2 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Opponent | no | 2 | 4 | 2 | 0 | 2 | 0 | 0 | 340 |
| L2527 | 1 | 1 | Mine | no | 0 | 5 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 0 | 1 | 6 | 1 | 0 | 0 | 0 | 250 |
| L2634 | 6 | 1 | Mine | no | 8 | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 1 | 1 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Mine | - | - | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 3 | 3 | 2 | 1 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 2 | 3 | 2 | 1 | 1 | 0 | 0 | 170 |
| L3234 | 6 | 1 | Opponent | no | 3 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 29% | 2.3 | 2.9 | 1.9 | 1.3 | 0.4 | 0.0 | 0.0 | 273.2 |
| **Average** | | | Opponent | 25% | 3.1 | 2.2 | 2.5 | 1.8 | 0.4 | 0.0 | 0.0 | 114.6 |

### KPIs: dep-opp-13df7bd-p4

Rules off - Mine only: HOLDER AT DEPLOYMENT, LANE BY FIGURES, DEPLOY BY FIGURES.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 29% (49 of 170) | 2% (3 of 184) | 15% (52 of 354) |
| Winner chose to follow up after the loser gave ground |  | 99% (73 of 74); on the table 99% | 98% (49 of 50); on the table 98% | 98% (122 of 124); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 95% (18 of 19); on the table 100% | 100% (14 of 14); on the table 100% | 97% (32 of 33); on the table 100% |
| Winner chose to pursue after the loser fled |  | 55% (12 of 22); on the table 68% | 86% (38 of 44); on the table 89% | 76% (50 of 66); on the table 82% |
| Winner chose to follow up or pursue (all three) |  | 90% (103 of 115); on the table 93% | 94% (101 of 108); on the table 94% | 91% (204 of 223); on the table 94% |
| Magic missiles tried each own turn | 50%+ | 23% (62 of 269) | 32% (56 of 173) | 27% (118 of 442) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 36% (62 of 172) | 44% (56 of 128) | 39% (118 of 300) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 49% (17 of 35) | 54% (35 of 65) | 52% (52 of 100) |
| Points that never fought | lower | 37% (25421 of 67942) | 34% (24738 of 71984) | 36% (50159 of 139926) |
|   infantry points that never fought | lower | 52% (7978 of 15347) | 52% (7234 of 13804) | 52% (15212 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 68% (184 of 270) | 50% (141 of 280) | 59% (325 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 91% (20 of 22); 1.8 uses a game | 89% (8 of 9); 0.7 uses a game | 90% (28 of 31); 1.2 uses a game |
| Bound items with another spell used |  | 19% (3 of 16); 0.2 uses a game | 45% (9 of 20); 0.3 uses a game | 33% (12 of 36); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 63% (12 of 19); 0.3 uses a game | 67% (10 of 15); 0.3 uses a game | 65% (22 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 63% (36383 of 57750) | 45% (28294 of 63347) | 53% (64677 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.4 (25%) | 1.2 (37%) | 2.6 (29%) |
| MARCHED: its unit marched | 1.3 (22%) | 0.6 (17%) | 1.8 (20%) |
| CHARGED: its unit charged | 0.1 (1%) | 0.2 (8%) | 0.3 (4%) |
| IN COMBAT: engaged in combat | 1.0 (18%) | 0.6 (19%) | 1.6 (18%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 1.5 (26%) | 0.6 (20%) | 2.1 (23%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 1.3 | 1.8 | 3.3 | 0.4 | 2.3 |
| not cast | 2.9 | 2.7 | 3.0 | 9.0 | 1.6 | 20.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.2 (44%) | 0.2 (6%) | 2.6 (29%) | 0.1 (9%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.8 (20%) | 0.4 (27%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (4%) | 0.2 (6%) | 0.6 (20%) | 1.6 (18%) | 0.3 (21%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.4 (13%) | 0.2 (6%) | 0.3 (11%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.1 (2%) | 0.1 (5%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| GONE: slain | 0.8 (26%) | 0.5 (19%) | 0.5 (16%) | 2.1 (23%) | 0.5 (34%) | 3.6 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (8%) | 0.1 (5%) | 0.2 (7%) | 0.2 (2%) | 0.0 (0%) | 0.3 (2%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (12%) | 0.0 (1%) | 0.1 (1%) | 0.1 (9%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.2 (43%) | 0.1 (5%) | 1.0 (34%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.0 (73%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.1 a game | 0.8 a game | 0.9 a game |
| stood (cast and not dispelled) | 59% (22 of 37) | 33% (5 of 15) | 52% (27 of 52) |
| the unit moved after it | 73% (16 of 22) | 80% (4 of 5) | 74% (20 of 27) |
| it charged on its next turn | 14% (3 of 22) | 0% (0 of 5) | 11% (3 of 27) |
| the enemy charged it first | 18% (4 of 22) | 20% (1 of 5) | 19% (5 of 27) |
| it fought by the end of its next turn | 18% (4 of 22) | 0% (0 of 5) | 15% (4 of 27) |
| it moved out of a charge the enemy had planned (not charged first) | 32% (7 of 22) | 0% (0 of 5) | 26% (7 of 27) |
| none of these (no charge, no fight, no charge escaped) | 41% (9 of 22) | 80% (4 of 5) | 48% (13 of 27) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (564 of 887) | 53% (304 of 579) | 59% (868 of 1466) |
|   cavalry | 61% (40 of 66) | 80% (101 of 127) | 73% (141 of 193) |
|   character | 47% (47 of 99) | 20% (28 of 139) | 32% (75 of 238) |
|   chariot | 57% (59 of 104) | 81% (17 of 21) | 61% (76 of 125) |
|   infantry | 51% (141 of 278) | 56% (137 of 243) | 53% (278 of 521) |
|   monster | 44% (20 of 45) | 20% (4 of 20) | 37% (24 of 65) |
|   war machine | 87% (257 of 295) | 59% (17 of 29) | 85% (274 of 324) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.8 (31%) | 1.6 (20%) | 4.3 (26%) |
| CHARGED: it charged | 1.0 (11%) | 1.6 (21%) | 2.6 (16%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.9 (10%) | 0.4 (6%) | 1.3 (8%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 2.2 (25%) | 1.5 (20%) | 3.8 (23%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (6%) | 0.8 (10%) | 1.3 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.1 (12%) | 1.5 (20%) | 2.6 (16%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.1 (1%) | 0.4 (2%) |
| OTHER BAR | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.2 | 1.5 | 80% | 5.5 pts | 34 pts |
| character | 2.6 | 0.7 | 80% | 8.1 pts | 21 pts |
| chariot | 2.1 | 1.3 | 64% | 14.0 pts | 30 pts |
| infantry | 11.2 | 3.3 | 79% | 7.7 pts | 86 pts |
| monster | 0.8 | 0.1 | 93% | 1.1 pts | 1 pts |
| war machine | 7.6 | 6.9 | 62% | 33.4 pts | 254 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.2 | 6.6 | 4.9 |
| Charges that made contact a game | 2.5 | 4.8 | 3.6 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.47 declared, 0.47 contact (17 units) | 0.92 declared, 0.58 contact (12 units) | 0.66 declared, 0.52 contact (29 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.62 declared, 0.50 contact (8 units) | 1.00 declared, 0.67 contact (12 units) | 0.85 declared, 0.60 contact (20 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.41 declared, 0.31 contact (249 units) | 0.72 declared, 0.53 contact (296 units) | 0.58 declared, 0.43 contact (545 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 49% (40 of 81) | 75% (12 of 16) | 67% (4 of 6) | 54% (56 of 103) |
| Character in a unit | 82% (27 of 33) | 47% (8 of 17) | 0% (0 of 1) | 69% (35 of 51) |
| Character on its own | 75% (24 of 32) | 64% (16 of 25) | 31% (24 of 77) | 48% (64 of 134) |
| Chariot | 73% (11 of 15) | 92% (11 of 12) | - | 81% (22 of 27) |
| Infantry | 63% (52 of 83) | 48% (12 of 25) | 50% (3 of 6) | 59% (67 of 114) |
| Monster | 62% (21 of 34) | 50% (7 of 14) | - | 58% (28 of 48) |
| Monstrous | 71% (10 of 14) | 57% (8 of 14) | - | 64% (18 of 28) |
| War Machines | 79% (34 of 43) | 50% (1 of 2) | - | 78% (35 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 88% (7 of 8); on the table 88% | 20% (20 of 102) | 30% | 77% (17 of 22) | 83% (5 of 6); 4.2 uses a game | 50% (1 of 2); 0.5 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 80% (20 of 25); on the table 88% | 62% (15 of 24) | 37% | 59% (19 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (10 of 10); on the table 100% | - | 63% | 78% (21 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 89% (8 of 9); on the table 89% | 33% (6 of 18) | 58% | 76% (47 of 62) | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game | 60% (3 of 5); 0.5 uses a game |
| Grand Cathay | 4 | 100% (16 of 16); on the table 100% | 21% (18 of 84) | 22% | 46% (17 of 37) | 89% (8 of 9); 6.8 uses a game | 0% (0 of 2); 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| High Elf Realms | 9 | 91% (21 of 23); on the table 91% | 23% (8 of 35) | 30% | 59% (41 of 70) | 100% (7 of 7); 2.8 uses a game | 33% (10 of 30); 1.3 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 0% (0 of 1); on the table 0% | - | 57% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 96% (24 of 25); on the table 100% | 33% (2 of 6) | 33% | 71% (15 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 100% (6 of 6); on the table 100% | 0% (0 of 6) | 47% | 86% (12 of 14) | 100% (2 of 2); 3.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (8 of 8); on the table 100% | 36% (15 of 42) | 21% | 38% (9 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 6 | 91% (10 of 11); on the table 91% | 32% (13 of 41) | 39% | 62% (28 of 45) | 100% (3 of 3); 1.2 uses a game | 0.0 uses a game | 67% (4 of 6); 0.7 uses a game |
| Tomb Kings of Khemri | 4 | 81% (13 of 16); on the table 88% | 33% (2 of 6) | 29% | 40% (8 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 86% (12 of 14); on the table 93% | 27% (16 of 60) | 30% | 50% (21 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 96% (26 of 27); on the table 96% | 8% (1 of 12) | 29% | 49% (35 of 72) | 100% (2 of 2); 0.3 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 96% (23 of 24); on the table 96% | 33% (2 of 6) | 42% | 55% (31 of 56) | 50% (1 of 2); 0.5 uses a game | 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |

Flank and rear charges a unit could have turned to face (dep-opp-13df7bd-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 48% (50) | 40% (17) | 45% (67) |
| ...free all their last turn and able to turn (per game) | 0.64 | 0.47 | 1.11 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.42 | 0.00 | 0.42 |
| ...with the charger already in that arc before they moved (per game) | 0.56 | 0.36 | 0.92 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.08 | 1.67 | 3.75 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.67 | 1.03 | 1.69 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.19 | 5.64 | 11.83 |

### Quality by phase: dep-opp-13df7bd-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 2.5 |
| Strategy | Charge objectives carried out (made contact) | 50% (54 of 109) | 41% (83 of 201) |
| Strategy | Shoot objectives carried out (shot that target) | 38% (157 of 408) | 41% (68 of 167) |
| Strategy | Close-in objectives charged next turn | 13% (19 of 144) | 18% (38 of 216) |
| Strategy | Support requests answered (helper made contact too) | 46% (6 of 13) | 39% (14 of 36) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 30% (3 of 10) | 70% (7 of 10) |
| Strategy | Joined characters whose unit fought | 44% (16 of 36) | 57% (17 of 30) |
| Strategy | Lone characters that fought | 77% (67 of 87) | 77% (66 of 86) |
| Movement | Charges halted short of contact | 0.1 | 0.3 |
| Movement | Idle units | 1.3 | 1.8 |
| Movement | Points that never moved of their own | 273.2 | 114.6 |
| Movement | Fights charged into per game | 2.1 | 3.8 |
| Movement | Charges with odds: long shots (under 50%) | 6 of 66, net +292 | 16 of 113, net -5 |
| Movement | Charges with odds: sweet spot (55-75%) | 9 of 66, net -25 | 27 of 113, net +130 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 7 of 66, net +63 | 10 of 113, net +100 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 15 of 66, net +62 | 27 of 113, net +158 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.3 | 9.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 49% (163 of 336) | 36% (119 of 327) |
| Shooting | Points destroyed by shooting units | 59.7 | 29.6 |
| Shooting | War machine shots | 7.1 | 0.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 55% (142 of 257) | 35% (6 of 17) |
| Shooting | Points destroyed by war machines | 83.5 | 6.4 |
| Magic | Magic missiles cast | 1.1 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 41% (16 of 39) | 26% (9 of 35) |
| Magic | Wounds caused by magic missiles | 2.8 | 1.1 |
| Magic | Wounds caused by other spells | 1.4 | 1.5 |
| Magic | Points destroyed by magic (all spells) | 43.2 | 50.6 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.9 / 0.3 / 0.9 / 0.2 | 1.9 / 0.5 / 0.7 / 0.1 |
| Combat | Points destroyed in combat | 240.0 | 534.3 |
| Combat | Points run down | 60.7 | 72.8 |
| Combat | Net points per charged fight, damage counted | +58 | +100 |
| Combat | Net per 100 charger points, damage counted | +18.8 | +31.2 |
| Combat | First round won (charged fights) | 70% | 76% |
| Combat | Net points per charged fight | +35 | +101 |
| Combat | Net points per supported fight / lone fight | +176 / +12 | +165 / +82 |
| Combat | Charged fights on a top-3 enemy unit | 25 of 77 | 66 of 136 |
| Game | Points lost | 838.8 | 547.6 |
| Game | VP from objectives | 496.4 | 540.8 |
| Game | Lone holders (player turns) | 2.3 | 3.1 |

- Mine won / drew / lost: 8 / 9 / 19 of 36 ended games (of 36); mean margin (Mine - Opponent) -322 VP
- The side that went first won 10 of 27 games with a winner
- Points traded per game (both sides' losses): 1386
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: dep-opp-13df7bd-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.9 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 8.9 | 2.6 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 1.6 | +0.0 | 0.0 | 19.6 | 0.0 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.0 | +6.3 | 0.0 | 20.8 | 1.1 | +9.7 | 0.0 | 19.1 |
| BEST FACING | 0.9 | +30.5 | 0.0 | 11.9 | 0.9 | +24.4 | 0.0 | 71.3 |
| BEST FIRST | 4.8 | +179.4 | 100.1 | 93.3 | 4.9 | +155.4 | 207.6 | 48.4 |
| BEST OVERALL | 0.6 | +49.9 | 0.0 | 16.0 | 0.8 | +40.9 | 0.0 | 34.7 |
| BEST PREY | 0.6 | +41.7 | 8.7 | 14.4 | 1.2 | +44.4 | 51.9 | 9.6 |
| BEST PRIZE | 0.1 | -0.8 | 1.6 | 0.0 | 0.2 | -11.7 | 18.0 | 13.9 |
| BIG CHARACTER SAFETY | 0.2 | -0.4 | 0.0 | 10.2 | 0.3 | +0.6 | 0.0 | 13.7 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 5.2 | 15.2 | 0.2 | +0.0 | 8.6 | 0.0 |
| BLOCKED WHEEL | 0.4 | +11.5 | 0.0 | 0.0 | 0.4 | +3.3 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.2 | -46.4 | 27.4 | 15.0 | 0.4 | -72.6 | 46.6 | 17.1 |
| BOMBING RUN | 0.0 | +0.4 | 1.2 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 123.7 | 4.6 | 0.0 | +0.0 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 5.7 | +308.4 | 400.2 | 98.8 | 0.4 | +21.0 | 6.2 | 5.4 |
| CANNON SIGHT KEPT | 1.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | - | - | - | - | 0.1 | -1.0 | 6.5 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | -1.2 | 15.0 | 0.0 | 0.2 | +0.0 | 36.0 | 3.0 |
| CAST JOB | 1.2 | +41.6 | 85.4 | 41.0 | 0.3 | +5.0 | 14.7 | 21.4 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +20.1 | 24.9 | 10.3 | 0.0 | +0.6 | 3.9 | 0.0 |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 22.5 | 0.4 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.2 | 0.0 | 9.3 | 0.1 | -0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 2.2 | +0.0 | 207.8 | 102.8 | 2.9 | +0.0 | 371.8 | 65.9 |
| CHARGE NOW WEIGHED | 0.7 | -52.7 | 10.6 | 22.6 | 0.4 | -57.9 | 3.1 | 29.6 |
| CHARGER SLAIN LOST | 0.3 | -5.3 | 33.1 | 9.8 | 1.0 | -15.3 | 124.0 | 10.3 |
| CHARIOT WIZARD CAREFUL | 0.1 | -3.2 | 13.9 | 13.9 | 0.2 | -1.8 | 5.1 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 5.0 | 0.0 | 0.1 | +0.0 | 21.7 | 1.1 |
| COMBAT PIVOT | 0.4 | +0.0 | 1.4 | 47.0 | 0.5 | +0.0 | 26.5 | 26.5 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 2.6 | 0.0 |
| CONVEYANCE SEARCH | 0.8 | +114.7 | 51.2 | 25.1 | 0.3 | +32.3 | 0.0 | 0.0 |
| COUNTER-CHARGE COVER | 9.3 | +704.6 | 0.0 | 251.5 | 8.1 | +754.8 | 0.0 | 108.9 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 5.0 | 2.5 | 0.0 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | - | - | - | - | 0.0 | +3.3 | 13.9 | 0.0 |
| DEPLOY BY FIGURES | - | - | - | - | 7.8 | +68.1 | 0.0 | 36.1 |
| EDGE GIVE GROUND | 0.1 | +2.9 | 20.4 | 1.2 | 0.2 | +5.4 | 40.5 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +0.6 | 0.0 | 9.7 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.1 | +161.8 | 0.0 | 61.9 | 1.7 | +109.3 | 0.0 | 80.8 |
| FALLBACK BY WORTH | 4.9 | +80.2 | 0.0 | 74.8 | 6.3 | +35.7 | 0.0 | 27.8 |
| FIGHT LIFT | 0.1 | +2.8 | 23.6 | 0.0 | - | - | - | - |
| FLANK NOT WEIGHED | 6.3 | +0.0 | 0.0 | 212.8 | 5.7 | +0.0 | 0.0 | 99.5 |
| FOCUS FIRE | - | - | - | - | 0.1 | +0.2 | 1.5 | 1.7 |
| FOLLOW UP WEIGHED | 1.1 | +166.1 | 0.0 | 52.8 | 1.1 | +149.5 | 0.0 | 13.3 |
| FRIENDS SHOTS CHECKED | 0.2 | +16.9 | 0.0 | 10.5 | 0.3 | +14.1 | 0.0 | 0.8 |
| GIVES UP | 0.1 | -1.3 | 24.8 | 0.0 | 0.1 | -1.6 | 16.2 | 1.1 |
| GROUND FLIERS | 0.1 | +4.5 | 0.0 | 0.0 | 0.0 | +2.6 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 10.9 | 0.0 | 0.2 | +0.0 | 22.4 | 0.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 33.9 | 6.0 | 0.7 | +0.0 | 60.6 | 10.1 |
| HILL BY ITS CHANCE | 0.4 | -41.2 | 0.0 | 5.6 | 0.4 | -36.9 | 0.0 | 11.6 |
| HOLDER AT DEPLOYMENT | - | - | - | - | 0.9 | +143.5 | 0.0 | 7.2 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.1 | -114.4 | 292.1 | 184.9 | 8.3 | -205.7 | 575.8 | 125.4 |
| HUNT ADVANCE | - | - | - | - | 0.2 | +3.6 | 11.0 | 5.1 |
| HUNT DROPPED | - | - | - | - | 0.2 | +0.0 | 3.5 | 3.2 |
| HUNT IN PAIRS | 0.4 | +15.4 | 0.0 | 32.2 | 0.4 | +21.0 | 0.0 | 0.0 |
| HUNT KEPT | - | - | - | - | 0.1 | +2.1 | 4.6 | 0.0 |
| HUNT RESULT | - | - | - | - | 0.3 | +23.3 | 3.5 | 3.2 |
| HUNT THE GUNS | - | - | - | - | 0.3 | +86.8 | 22.5 | 5.1 |
| INVITES THE FIGHT | 1.7 | +36.7 | 44.2 | 37.1 | 1.2 | +21.0 | 30.9 | 28.7 |
| JOINT CHARGE PLAN | 0.1 | +6.2 | 0.0 | 4.0 | 0.2 | +9.4 | 10.2 | 0.0 |
| JOINT KNOWS CHALLENGE | 0.1 | -0.8 | 21.8 | 0.0 | 0.1 | -3.4 | 17.8 | 0.8 |
| KEEP FALLS | 0.1 | +1.7 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | - | - | - | - | 0.1 | +1.5 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.5 | +44.2 | 117.7 | 51.5 | 2.0 | +60.0 | 238.0 | 56.5 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.1 | +53.9 | 58.7 | 50.8 | 2.1 | +121.3 | 196.7 | 32.7 |
| KILLS COUNT NEXT TURN | 5.0 | +128.7 | 107.3 | 137.5 | 6.4 | +224.2 | 322.3 | 93.8 |
| LANE BY FIGURES | - | - | - | - | 1.1 | +65.1 | 0.0 | 0.0 |
| LONE CHARACTER SAFE SPOT | 0.3 | +9.7 | 0.0 | 10.1 | 0.3 | +9.4 | 7.0 | 35.5 |
| LONE WIZARD HOLDS BACK | 0.2 | +0.0 | 0.0 | 2.4 | 0.3 | +0.0 | 1.5 | 5.3 |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | -0.3 | 26.0 | 0.0 | 0.4 | +1.9 | 38.1 | 4.9 |
| LOST CHARGE | 2.8 | -51.1 | 38.9 | 109.7 | 2.0 | -36.6 | 95.3 | 27.9 |
| LURE BY WHAT IT DRAWS | 0.1 | -8.3 | 0.0 | 1.0 | 0.0 | -10.3 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.7 | +101.2 | 15.0 | 2.8 | 1.2 | +118.5 | 85.1 | 0.8 |
| MANOEUVRE | 0.1 | +0.1 | 0.0 | 0.0 | 0.1 | +4.8 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.0 | 0.0 | 11.0 | 0.1 | +1.5 | 0.0 | 0.0 |
| MARCH CHECK | 0.6 | +11.0 | 0.0 | 52.2 | 0.3 | +9.6 | 0.0 | 1.7 |
| MARCH ODDS | 0.2 | +11.6 | 6.2 | 10.3 | 0.2 | +12.6 | 18.6 | 15.0 |
| MARCH OVER CASTS | 0.5 | +21.7 | 0.0 | 23.0 | 0.3 | -3.6 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.8 | +172.8 | 0.0 | 148.2 | 4.9 | +181.6 | 0.0 | 51.5 |
| MISSILES IN THE MOVE | 3.9 | +125.9 | 0.0 | 120.0 | 2.1 | +39.5 | 0.0 | 61.3 |
| MISSILES NEXT TURN | 4.5 | +87.4 | 0.0 | 157.5 | 2.9 | +29.5 | 0.0 | 72.2 |
| MODEL FACING | 0.1 | +17.3 | 0.0 | 5.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 0.0 | 6.5 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.5 | +26.9 | 0.0 | 16.8 | 0.3 | +8.9 | 0.0 | 3.2 |
| MOVE SPELL IN RANGE | 0.2 | +6.3 | 0.0 | 2.4 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.7 | -54.5 | 6.8 | 56.1 | 0.1 | -2.9 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.5 | +0.0 | 0.0 | 22.9 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 2.8 | +181.0 | 64.1 | 59.0 | 3.9 | +267.9 | 197.9 | 51.3 |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +0.3 | 0.0 | 5.1 | 0.2 | +22.1 | 12.2 | 0.0 |
| NO RALLY LEFT | 0.0 | +1.1 | 0.0 | 3.1 | - | - | - | - |
| NOT NEEDED | 0.2 | -4.8 | 29.1 | 1.8 | 0.6 | -28.9 | 110.9 | 4.4 |
| NOT TURNED | 6.2 | +101.5 | 0.0 | 176.9 | 5.6 | +47.1 | 0.0 | 56.5 |
| NOT WORTH A CAST | 0.5 | -0.4 | 0.0 | 0.0 | 0.2 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 16.5 | -819.9 | 10.9 | 325.3 | 15.5 | -876.3 | 18.2 | 153.4 |
| OPENS A LANE | 0.2 | +2.6 | 94.9 | 0.0 | 0.1 | +0.3 | 13.0 | 0.0 |
| OPENS UP | 0.1 | +4.7 | 5.6 | 0.0 | 0.1 | +9.2 | 6.4 | 0.0 |
| OVERRUNS AWAY | 0.4 | +10.0 | 31.2 | 8.6 | 0.3 | +3.6 | 42.7 | 3.5 |
| PATHS CROSS | 2.1 | +125.1 | 0.0 | 26.9 | 3.0 | +197.5 | 0.0 | 30.0 |
| PERIAPT WORTH | 0.1 | +4.9 | 0.0 | 15.0 | 0.1 | +6.1 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -3.1 | 0.0 | 0.0 | 0.1 | -1.1 | 0.0 | 15.7 |
| PLAN RESULT | 38.6 | +1552.5 | 1454.3 | 1185.7 | 40.9 | +1404.8 | 1647.2 | 802.3 |
| PURSUES BIG PREY | 0.0 | -4.6 | 0.0 | 0.0 | 0.1 | -14.5 | 0.0 | 13.9 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +8.2 | 0.0 | 0.0 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 1.0 | +15.9 | 0.0 | 53.2 | 1.8 | +30.4 | 0.0 | 46.7 |
| RANDOM MOVER NO PROMISE | 0.2 | -6.6 | 6.1 | 14.2 | 0.2 | -9.1 | 8.1 | 9.4 |
| REDIRECT BY WHAT IT STOPS | 0.3 | -8.9 | 0.0 | 7.1 | 0.7 | -0.8 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.3 | +182.3 | 0.0 | 49.5 | 4.1 | +283.4 | 0.0 | 75.2 |
| REDIRECT WEIGHED | 0.2 | +0.8 | 4.1 | 0.9 | 0.4 | -3.2 | 23.8 | 13.9 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 32.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.5 | +17.0 | 0.0 | 10.7 | 0.9 | +31.8 | 0.0 | 21.5 |
| RESTRAINS TO SHOOT | 0.0 | +0.8 | 0.0 | 4.5 | 0.1 | +0.7 | 0.0 | 0.0 |
| RISK BY ARC | 2.1 | +98.4 | 197.8 | 77.8 | 3.1 | +59.3 | 361.7 | 62.5 |
| SAFE SURE CHARGE | - | - | - | - | 0.0 | -1.9 | 0.0 | 0.0 |
| SAFER THAN THE JOB | 0.7 | +41.7 | 0.0 | 12.4 | 1.0 | +45.9 | 0.0 | 3.8 |
| SCOUT SPOT | 0.4 | +0.7 | 0.0 | 0.0 | 0.1 | -0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -6.0 | 0.0 | 1.5 | 0.4 | -22.4 | 0.0 | 0.8 |
| SEARCH SPOT | 2.3 | +132.2 | 0.0 | 29.7 | 2.8 | +94.0 | 0.0 | 50.7 |
| SECOND HUNTER | - | - | - | - | 0.0 | -0.2 | 3.5 | 0.0 |
| SELF MOVE SPELL | 0.1 | +8.9 | 0.0 | 11.0 | 0.6 | +25.8 | 0.0 | 18.1 |
| SET UP TOGETHER | 1.0 | +140.6 | 15.0 | 2.8 | 2.0 | +173.0 | 107.1 | 9.9 |
| SET-UP ANY TARGET | 0.6 | +84.4 | 51.2 | 15.2 | 0.1 | +24.3 | 0.0 | 0.0 |
| SET-UP MISSED | 0.0 | +1.7 | 0.0 | 0.0 | 0.0 | +4.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +0.5 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.9 | +25.7 | 40.5 | 8.1 | 0.9 | +16.8 | 47.6 | 3.6 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.3 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.4 | +0.0 | 135.6 | 0.0 | 0.2 | +0.0 | 21.6 | 0.0 |
| SHOTS IN THE MOVE | 14.5 | +683.2 | 0.0 | 286.2 | 7.9 | +176.5 | 0.0 | 120.3 |
| SPELL CATCH ODDS | 0.0 | -2.3 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.6 | +120.2 | 51.2 | 15.2 | 0.1 | +26.9 | 0.0 | 0.0 |
| SPELL WORTH | 1.2 | +21.3 | 63.8 | 41.1 | 2.4 | +44.7 | 47.2 | 47.2 |
| SPELLS IN THE FIGHT | 0.5 | +1.8 | 63.1 | 7.7 | 1.1 | -4.2 | 180.8 | 24.2 |
| STABLE ROLE | 11.7 | +0.0 | 367.4 | 229.2 | 11.1 | +0.0 | 417.8 | 118.7 |
| STAY WEIGHED | 0.1 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| STOPS | - | - | - | - | 0.1 | +6.3 | 16.1 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.7 | +24.0 | 0.0 | 39.4 | 0.4 | +18.2 | 0.0 | 1.8 |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 11.7 | 0.2 | +0.0 | 0.0 | 8.1 |
| SUPPORT NARROWED | 5.8 | -54.3 | 351.6 | 115.5 | 8.2 | -68.9 | 333.9 | 72.7 |
| SUPPORTS | 4.1 | +58.3 | 180.3 | 55.6 | 5.9 | +71.1 | 62.3 | 45.6 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -2.2 | 15.5 | 7.7 | 0.1 | -14.5 | 0.8 | 4.8 |
| SURE REACH TOGETHER | 0.4 | +11.0 | 0.0 | 2.4 | 0.6 | +1.0 | 0.0 | 0.0 |
| THROUGH LINE OF FIRE | 0.6 | +26.4 | 0.0 | 13.2 | 0.2 | +15.2 | 0.0 | 3.2 |
| TURN WORTH | 0.1 | -7.4 | 9.1 | 8.6 | 0.1 | -12.9 | 6.9 | 2.8 |
| TWO OR MORE ARRIVE | 0.4 | +4.0 | 0.0 | 0.0 | 0.6 | +3.7 | 45.9 | 1.2 |
| WAIT AFTER COSTS | 6.4 | -277.2 | 149.8 | 117.6 | 6.8 | -286.9 | 289.9 | 99.2 |
| WALKS TO THE FIGHT | 1.3 | +21.5 | 33.3 | 17.9 | 0.7 | +11.2 | 17.1 | 0.0 |
| WAR ENGINE CHARGES | 0.1 | +6.1 | 4.7 | 8.6 | - | - | - | - |
| WAR ENGINE JOBS | 0.7 | +0.0 | 22.1 | 12.6 | 0.2 | +0.0 | 7.6 | 12.1 |
| WEARS DOWN | 1.2 | +49.6 | 136.1 | 52.4 | 1.7 | +57.3 | 249.8 | 39.6 |
| WHO HITS BACK | 0.1 | +29.4 | 0.0 | 11.7 | 0.2 | +14.8 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.1 | +20.0 | 16.6 | 0.0 | 0.5 | +21.8 | 102.9 | 15.0 |
| WHOLE FIGHT GAIN | 0.2 | +13.0 | 16.6 | 5.9 | 1.1 | +90.9 | 121.5 | 7.1 |
| WIDER SPREAD | 2.3 | -7.8 | 220.7 | 80.2 | 3.6 | -11.3 | 461.9 | 70.1 |
| WOUNDED STAYS OUT | 0.1 | +0.0 | 4.0 | 0.0 | - | - | - | - |

### Rule changes: dep-opp-13df7bd-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1153 | 1153 | 1153 | 32.03 | -61065 | -53.0 |
| BEST FIRST | 349 | 349 | 349 | 9.69 | +12054 | +34.5 |
| PATHS CROSS | 182 | 182 | 182 | 5.06 | +11614 | +63.8 |
| SEARCH SPOT | 183 | 183 | 182 | 5.06 | +8144 | +44.7 |
| COUNTER-CHARGE COVER | 624 | 358 | 174 | 4.83 | +10927 | +62.8 |
| DEPLOY BY FIGURES | 281 | 281 | 170 | 4.72 | +2304 | +13.6 |
| FACES THE THREAT | 135 | 135 | 135 | 3.75 | +9759 | +72.3 |
| KILLS COUNT NEXT TURN | 412 | 412 | 135 | 3.75 | +3078 | +22.8 |
| MOVE TO CHARGE | 239 | 239 | 134 | 3.72 | +5779 | +43.1 |
| SUPPORTS | 360 | 360 | 130 | 3.61 | +1423 | +10.9 |
| FALLBACK BY WORTH | 404 | 404 | 79 | 2.19 | +4172 | +52.8 |
| FOLLOW UP WEIGHED | 78 | 78 | 78 | 2.17 | +11360 | +145.6 |
| ADVANCE LANE KEPT | 69 | 69 | 69 | 1.92 | +0 | +0.0 |
| SHOTS IN THE MOVE | 808 | 519 | 64 | 1.78 | +1557 | +24.3 |
| BEST FACING | 63 | 63 | 63 | 1.75 | +1976 | +31.4 |
| SAFER THAN THE JOB | 61 | 61 | 61 | 1.69 | +3154 | +51.7 |
| ARTILLERY RE-ROLL WEIGHED | 59 | 59 | 59 | 1.64 | +0 | +0.0 |
| WAIT AFTER COSTS | 475 | 475 | 58 | 1.61 | +1191 | +20.5 |
| RANDOM MOVE BY FIGURES | 100 | 100 | 52 | 1.44 | +1666 | +32.0 |
| RESERVE FALL BACK | 52 | 52 | 52 | 1.44 | +1759 | +33.8 |
| SET UP TOGETHER | 108 | 95 | 52 | 1.44 | +3435 | +66.1 |
| CHARGE NOW FIRST | 185 | 185 | 51 | 1.42 | -2742 | -53.8 |
| MAX FOR POSITIONING | 349 | 215 | 51 | 1.42 | +517 | +10.1 |
| BEST OVERALL | 50 | 50 | 50 | 1.39 | +3268 | +65.4 |
| CANNON SIGHT KEPT | 47 | 47 | 47 | 1.31 | +0 | +0.0 |
| REDIRECT COUNTER | 233 | 133 | 47 | 1.31 | +3219 | +68.5 |
| CHARGE NOW WEIGHED | 41 | 41 | 41 | 1.14 | +3150 | +76.8 |
| LANE BY FIGURES | 40 | 40 | 40 | 1.11 | +2343 | +58.6 |
| STOPS SHORT OF THE FLANK | 40 | 40 | 40 | 1.11 | +1518 | +38.0 |
| WALKS TO THE FIGHT | 72 | 72 | 40 | 1.11 | +458 | +11.4 |
| MISSILES IN THE MOVE | 215 | 132 | 37 | 1.03 | +725 | +19.6 |
| RISK BY ARC | 187 | 179 | 37 | 1.03 | +1245 | +33.7 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| COMBAT PIVOT | 34 | 34 | 34 | 0.94 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 62 | 62 | 34 | 0.94 | +578 | +17.0 |
| KILLS COUNT | 117 | 115 | 33 | 0.92 | +1325 | +40.1 |
| MARCH CHECK | 33 | 33 | 32 | 0.89 | +2024 | +63.3 |
| HONEST WORTH | 554 | 549 | 31 | 0.86 | +214 | +6.9 |
| CAST JOB | 55 | 55 | 30 | 0.83 | +817 | +27.2 |
| MOVE AND CAST | 30 | 30 | 30 | 0.83 | +1287 | +42.9 |
| BLOCKED WHEEL | 29 | 29 | 29 | 0.81 | +533 | +18.4 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| MAKE SURE TOGETHER | 67 | 48 | 28 | 0.78 | +2254 | +80.5 |
| THROUGH LINE OF FIRE | 28 | 28 | 28 | 0.78 | +1498 | +53.5 |
| WHOLE FIGHT GAIN | 47 | 46 | 27 | 0.75 | +1246 | +46.1 |
| BEST PREY | 65 | 65 | 26 | 0.72 | +972 | +37.4 |
| CANNON PLANNED TARGET | 219 | 219 | 25 | 0.69 | -434 | -17.4 |
| SHOT REPLANNED | 23 | 23 | 23 | 0.64 | +0 | +0.0 |
| INVITES THE FIGHT | 105 | 105 | 22 | 0.61 | +434 | +19.7 |
| KEEPS ITS TARGET | 125 | 124 | 22 | 0.61 | +455 | +20.7 |
| REDIRECT WEIGHED | 21 | 21 | 21 | 0.58 | +439 | +20.9 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 20 | 20 | 20 | 0.56 | +1116 | +55.8 |
| HOLDER AT DEPLOYMENT | 31 | 31 | 20 | 0.56 | +851 | +42.6 |
| BIG CHARACTER SAFETY | 19 | 19 | 19 | 0.53 | +7 | +0.4 |
| SHOOTERS IN TWO RANKS | 19 | 19 | 19 | 0.53 | +46 | +2.4 |
| WEARS DOWN | 102 | 98 | 19 | 0.53 | +687 | +36.2 |
| CASTER AWAY FROM SCREEN | 18 | 18 | 18 | 0.50 | +0 | +0.0 |
| MARCH ODDS | 16 | 16 | 16 | 0.44 | +164 | +10.3 |
| STUCK PIVOT | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| MISSILES NEXT TURN | 265 | 154 | 13 | 0.36 | +71 | +5.4 |
| REFUSING RETIRES | 24 | 24 | 12 | 0.33 | -4 | -0.4 |
| BEST PRIZE | 11 | 11 | 11 | 0.31 | -664 | -60.4 |
| SURE CHARGE BEATS ADVANCE | 11 | 11 | 11 | 0.31 | -603 | -54.8 |
| WHO HITS BACK | 11 | 11 | 11 | 0.31 | +1285 | +116.8 |
| BLOCKED CHARGE SKIPPED | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| CHAFF PASSED | 10 | 10 | 10 | 0.28 | -7 | -0.7 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| LOST CHARGE | 173 | 173 | 9 | 0.25 | +275 | +30.6 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| WIDER SPREAD | 211 | 203 | 9 | 0.25 | +25 | +2.8 |
| CASTING BLOCK | 12 | 12 | 8 | 0.22 | +115 | +14.3 |
| HUNT IN PAIRS | 28 | 18 | 8 | 0.22 | +282 | +35.3 |
| PIVOT GUARDS FLANK | 8 | 8 | 8 | 0.22 | -151 | -18.9 |
| WAR ENGINE JOBS | 33 | 33 | 8 | 0.22 | -377 | -47.1 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| SUPPORT NARROWED | 505 | 505 | 7 | 0.19 | -107 | -15.3 |
| WHOLE FIGHT | 22 | 20 | 7 | 0.19 | +570 | +81.5 |
| NEEDED THERE | 7 | 7 | 6 | 0.17 | +0 | +0.0 |
| BACKUP TARGETS | 77 | 45 | 5 | 0.14 | +16 | +3.2 |
| MODEL FACING | 5 | 5 | 5 | 0.14 | +621 | +124.2 |
| MANOEUVRE | 7 | 7 | 4 | 0.11 | +177 | +44.2 |
| OPENS UP | 8 | 8 | 4 | 0.11 | +168 | +41.9 |
| PERIAPT WORTH | 4 | 4 | 4 | 0.11 | +399 | +99.7 |
| PURSUES BIG PREY | 4 | 4 | 4 | 0.11 | -687 | -171.8 |
| CHARGER SLAIN LOST | 49 | 47 | 3 | 0.08 | +82 | +27.4 |
| DEFENSIVE ARMY | 9 | 9 | 3 | 0.08 | -283 | -94.3 |
| JOINT CHARGE PLAN | 12 | 12 | 3 | 0.08 | +176 | +58.8 |
| KEEP FALLS | 3 | 3 | 3 | 0.08 | +193 | +64.3 |
| RESTRAINS TO SHOOT | 3 | 3 | 3 | 0.08 | +55 | +18.4 |
| SPELLS IN THE FIGHT | 57 | 55 | 3 | 0.08 | +23 | +7.8 |
| SURE REACH TOGETHER | 37 | 25 | 3 | 0.08 | +82 | +27.4 |
| BLOWS WHERE AIMED | 21 | 18 | 2 | 0.06 | +228 | +114.2 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +23 | +11.6 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +8 | +3.9 |
| HUNT ADVANCE | 7 | 7 | 2 | 0.06 | +52 | +25.9 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 17 | 17 | 2 | 0.06 | -201 | -100.4 |
| LONG SHOT | 27 | 24 | 2 | 0.06 | -102 | -51.1 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 2 | 0.06 | +180 | +90.1 |
| REDIRECT BY WHAT IT STOPS | 36 | 36 | 2 | 0.06 | +149 | +74.5 |
| STAY WEIGHED | 2 | 2 | 2 | 0.06 | +9 | +4.3 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +14 | +13.8 |
| CARRIES OUT COUNTER | 2 | 2 | 1 | 0.03 | -37 | -36.8 |
| CARRIES OUT SET-UP | 11 | 11 | 1 | 0.03 | -42 | -41.8 |
| DEFENSIVE FLOOR | 1 | 1 | 1 | 0.03 | +118 | +118.4 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +23 | +23.0 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -66 | -65.7 |
| STOPS | 4 | 4 | 1 | 0.03 | +74 | +74.4 |
| TWO OR MORE ARRIVE | 39 | 35 | 1 | 0.03 | +1 | +0.9 |
| WOUNDED STAYS OUT | 2 | 2 | 1 | 0.03 | -121 | -120.9 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 25 | 25 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 37 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 12 | 12 | 0 | 0.00 | - | - |
| CHEAP HELPER | 8 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 38 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 14 | 14 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 433 | not checked | - | - | - | - |
| GIVES UP | 7 | 5 | 0 | 0.00 | - | - |
| GROUND FLIERS | 5 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 9 | not checked | - | - | - | - |
| HELPER UNSEEN | 31 | 31 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 28 | 28 | 0 | 0.00 | - | - |
| HUNT DROPPED | 6 | trace | - | - | - | - |
| HUNT KEPT | 2 | trace | - | - | - | - |
| HUNT RESULT | 10 | trace | - | - | - | - |
| HUNT THE GUNS | 10 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 6 | 4 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 4 | 4 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 22 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 5 | trace | - | - | - | - |
| MARCH OVER CASTS | 29 | 29 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 14 | 14 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 8 | 2 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 28 | trace | - | - | - | - |
| MOVE SPELL SPOT | 20 | not checked | - | - | - | - |
| NOT NEEDED | 26 | 26 | 0 | 0.00 | - | - |
| NOT TURNED | 426 | 426 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 26 | not checked | - | - | - | - |
| OPENS A LANE | 11 | 10 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 26 | 25 | 0 | 0.00 | - | - |
| PLAN RESULT | 2861 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 15 | 15 | 0 | 0.00 | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 18 | 18 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 25 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 24 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 28 | not checked | - | - | - | - |
| SPELL WORTH | 129 | not checked | - | - | - | - |
| STABLE ROLE | 823 | 819 | 0 | 0.00 | - | - |
| TURN WORTH | 10 | 10 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 4 | 4 | 0 | 0.00 | - | - |

### Off best figure: dep-opp-13df7bd-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.75 | 13.42 | 54.6 |
| FALLBACK | gate | 0.67 | 0.78 | 33.3 |
| CHARGE NOW FIRST | rule | 0.75 | 0.67 | 53.8 |
| TURN GATE | gate | 0.61 | 0.78 | 41.0 |
| BEST PRIZE | rule | 0.08 | 0.22 | 60.4 |
| LONE CHARACTER SAFE SPOT | gate | 0.17 | 0.14 | 91.3 |
| SURE CHARGE BEATS ADVANCE | rule | 0.17 | 0.14 | 54.8 |
| PATHS CROSS | rule | 0.14 | 0.14 | 20.4 |
| PIVOT GUARDS FLANK | rule | 0.14 | 0.08 | 18.9 |
| SUPPORT REQUEST | gate | 0.03 | 0.19 | 50.1 |
| BIG CHARACTER SAFETY | rule | 0.08 | 0.11 | 10.1 |
| CHARGE NOW WEIGHED | rule | 0.17 | 0.03 | 33.8 |
| SUPPORT NARROWED | rule | 0.06 | 0.14 | 15.3 |
| WAR ENGINE JOBS | rule | 0.19 | - | 53.8 |
| AFTERMATH BAND | gate | 0.11 | 0.03 | 2.8 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.08 | 0.06 | 85.4 |
| CANNON PLANNED TARGET | rule | 0.14 | - | 101.1 |
| BLOCKED WHEEL | rule | 0.08 | 0.03 | 9.8 |
| DEPLOY BY FIGURES | rule | - | 0.11 | 19.3 |
| FIGHT ORDER BAND | gate | 0.03 | 0.08 | 2.2 |
| PURSUES BIG PREY | rule | 0.03 | 0.08 | 171.8 |
| REDIRECT WEIGHED | rule | 0.03 | 0.08 | 42.8 |
| STOPS SHORT OF THE FLANK | rule | 0.06 | 0.06 | 8.9 |
| DEFENSIVE ARMY | rule | 0.08 | - | 94.3 |
| REFUSING RETIRES | rule | 0.08 | - | 0.9 |
| SAFER THAN THE JOB | rule | 0.03 | 0.06 | 11.6 |
| THROUGH LINE OF FIRE | rule | 0.08 | - | 3.2 |
| CHAFF PASSED | rule | 0.06 | - | 3.2 |
| NO REASON | gate | - | 0.06 | 26.0 |
| RULE SWITCHED OFF | gate | 0.06 | - | 13.2 |
| CARRIES OUT COUNTER | rule | - | 0.03 | 36.8 |
| CARRIES OUT SET-UP | rule | 0.03 | - | 41.8 |
| LONE WIZARD HOLDS BACK | rule | 0.03 | - | 200.8 |
| LONG SHOT | rule | 0.03 | - | 112.1 |
| SAFE SURE CHARGE | rule | - | 0.03 | 65.7 |
| WOUNDED STAYS OUT | rule | 0.03 | - | 120.9 |

### Plans: dep-opp-13df7bd-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.4 | 15% | 338 | 305 | 90% |
| Mine | charge | 2.6 | 59% | 205 | 252 | 123% |
| Mine | close in | 4.0 | 21% | 225 | 83 | 37% |
| Mine | hold | 4.7 | 32% | 265 | 0 | 0% |
| Mine | join | 0.5 | 89% | 10 | 0 | 0% |
| Mine | shoot | 9.9 | 55% | 447 | 913 | 204% |
| Mine | support | 4.4 | 92% | 36 | 0 | 0% |
| Opponent | advance | 13.9 | 19% | 338 | 456 | 135% |
| Opponent | charge | 4.8 | 69% | 396 | 556 | 141% |
| Opponent | close in | 5.9 | 27% | 360 | 172 | 48% |
| Opponent | hold | 5.1 | 38% | 319 | 0 | 0% |
| Opponent | join | 0.7 | 96% | 35 | 0 | 0% |
| Opponent | shoot | 3.8 | 61% | 68 | 224 | 330% |
| Opponent | support | 6.6 | 92% | 63 | 0 | 0% |

### Packages: hunt the guns, dep-opp-13df7bd-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 3 |
| Opponent | 0.3 | 10 | 0 | 30% | 40% | 0% | 2.2 | 313 | 84 | 10% | 104 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 40 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 21 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.2 | 2 | 0 | 0% | 0% | 0% | - | 245 | 0 | 0% | 117 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 252 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 46 |
| Tomb Kings of Khemri | 0.2 | 1 | 0 | 0% | 100% | 0% | 2.0 | 434 | 424 | 100% | 0 |
| Vampire Counts | 0.6 | 5 | 0 | 60% | 60% | 0% | 2.3 | 266 | 83 | 0% | 22 |
| Warriors of Chaos | 0.2 | 2 | 0 | 0% | 0% | 0% | - | 436 | 0 | 0% | 70 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 121 |

### Battle groups: dep-opp-13df7bd-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.3 | 29% | 48% | 4% | 25% | 33% | 17% | 13% | 37% | 0% |
| Mine | REDIRECT COUNTER | 2.3 | 19% | 50% | 0% | - | 25% | 0% | 12% | 62% | 0% |
| Opponent | COUNTER-CHARGE COVER | 8.1 | 17% | 64% | 26% | 23% | 46% | 3% | 14% | 38% | 0% |
| Opponent | REDIRECT COUNTER | 4.1 | 19% | 79% | 21% | 50% | 41% | 0% | 5% | 55% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: dep-opp-13df7bd-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 0 (4) | 0 | 0 | 0 | 75% | 5.0 | - | 0 (4) | - | 0 (1) | 0 (3) |
| Mine | Chaff | 31 | 73 (31) | 20 | 53 | 62 | 19% | 2.7 | 44 (15) | 0 (4) | 126 (12) | 93 (22) | 15 (9) |
| Mine | Character | 106 | 36 (106) | 35 | 1 | 41 | 18% | 2.4 | 14 (29) | 56 (56) | 0 (6) | 52 (46) | 25 (45) |
| Mine | Clean-up | 24 | 26 (24) | 7 | 19 | 69 | 50% | 3.0 | 0 (4) | 41 (16) | 0 (4) | 8 (12) | 40 (12) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast | 4 | 110 (4) | 110 | 0 | 73 | 50% | 2.5 | 0 (1) | 220 (2) | 0 (1) | 0 (2) | 220 (2) |
| Mine | Fast Hammer | 40 | 28 (40) | 23 | 6 | 50 | 25% | 2.7 | 17 (21) | 42 (12) | 43 (7) | 27 (26) | 31 (14) |
| Mine | Fragile | 4 | 0 (4) | 0 | 0 | 54 | 25% | 2.3 | 0 (2) | 0 (2) | - | 0 (1) | 0 (3) |
| Mine | Hammer | 66 | 29 (66) | 12 | 17 | 45 | 15% | 2.7 | 3 (11) | 35 (45) | 24 (10) | 29 (43) | 29 (23) |
| Mine | Holder | 31 | 74 (31) | 6 | 67 | 27 | 35% | 2.6 | 27 (8) | 99 (18) | 65 (4) | 86 (20) | 47 (10) |
| Mine | Shooter | 35 | 44 (35) | 8 | 36 | 51 | 11% | 1.8 | 14 (9) | 61 (22) | 20 (4) | 44 (26) | 45 (9) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | War machine | 56 | 55 (56) | 55 | 0 | 45 | 2% | 1.3 | 94 (16) | 48 (29) | 5 (11) | 48 (10) | 56 (46) |
| Mine | Wizard | 17 | 3 (17) | 3 | 0 | 34 | 12% | 2.1 | 0 (2) | 5 (10) | 0 (1) | 9 (5) | 0 (8) |
| Opponent | Blocker | 1 | 35 (1) | 35 | 0 | 0 | 0% | 6.0 | 35 (1) | - | - | 35 (1) | - |
| Opponent | Chaff | 73 | 54 (73) | 22 | 32 | 43 | 45% | 2.8 | 62 (21) | 67 (25) | 35 (27) | 67 (55) | 13 (18) |
| Opponent | Character | 97 | 55 (97) | 55 | 0 | 24 | 16% | 2.4 | 54 (47) | 55 (26) | 62 (19) | 56 (40) | 56 (52) |
| Opponent | Clean-up | 14 | 72 (14) | 33 | 39 | 21 | 36% | 3.1 | 0 (3) | 93 (9) | 65 (2) | 120 (8) | 44 (6) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Opponent | Fast Hammer | 57 | 60 (57) | 38 | 22 | 28 | 21% | 3.0 | 41 (17) | 80 (34) | 8 (6) | 59 (29) | 61 (28) |
| Opponent | Fragile | 17 | 84 (17) | 84 | 0 | 38 | 24% | 1.8 | 0 (2) | 0 (7) | 179 (8) | 109 (12) | 26 (5) |
| Opponent | Hammer | 65 | 49 (65) | 34 | 15 | 33 | 26% | 3.2 | 65 (26) | 38 (32) | 44 (7) | 55 (39) | 40 (26) |
| Opponent | Holder | 29 | 25 (29) | 16 | 9 | 21 | 45% | 4.5 | 24 (10) | 16 (11) | 46 (7) | 31 (16) | 20 (12) |
| Opponent | Shooter | 35 | 65 (35) | 29 | 36 | 33 | 3% | 1.6 | 47 (12) | 89 (17) | 39 (6) | 70 (20) | 60 (15) |
| Opponent | Support | 6 | 0 (6) | 0 | 0 | 82 | 33% | 3.0 | 0 (1) | 0 (4) | 0 (1) | 0 (1) | 0 (5) |
| Opponent | War machine | 6 | 18 (6) | 18 | 0 | 30 | 0% | 2.0 | 48 (2) | 0 (2) | 0 (2) | 31 (3) | 0 (3) |
| Opponent | Wizard | 19 | 28 (19) | 28 | 0 | 45 | 0% | 2.1 | 49 (10) | 6 (5) | - | 7 (5) | 48 (10) |

### Charged fights: dep-opp-13df7bd-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 31 | 24 | 0.2 | 2.0 | 98 | 0 | +98 | 0 of 1 | 1 of 1 | +98 | - |
| Mine | Chaos Dwarfs | 4 | 68 | 189 | 2.2 | 1.4 | 84 | 32 | +52 | 3 of 9 | 7 of 9 | +136 | +10 |
| Mine | Dwarfen Mountain Holds | 3 | 373 | 20 | 0.7 | 1.0 | 30 | 0 | +30 | 0 of 2 | 2 of 2 | - | +30 |
| Mine | Empire of Man | 5 | 362 | 49 | 1.8 | 1.0 | 27 | 65 | -37 | 2 of 9 | 6 of 9 | - | -37 |
| Mine | Grand Cathay | 4 | 392 | 217 | 2.0 | 1.1 | 108 | 148 | -39 | 3 of 8 | 5 of 8 | +575 | -127 |
| Mine | High Elf Realms | 4 | 200 | 195 | 2.5 | 1.1 | 78 | 44 | +34 | 1 of 10 | 7 of 10 | -442 | +87 |
| Mine | Kingdom of Bretonnia | 1 | 355 | 0 | 3.0 | 1.3 | 0 | 0 | +0 | 2 of 3 | 2 of 3 | +0 | +0 |
| Mine | Lizardmen | 1 | 0 | 460 | 5.0 | 1.6 | 92 | 63 | +29 | 4 of 5 | 5 of 5 | +88 | -10 |
| Mine | Ogre Kingdoms | 2 | 28 | 620 | 3.0 | 1.3 | 207 | 56 | +151 | 4 of 6 | 3 of 6 | +1240 | -67 |
| Mine | Skaven | 2 | 155 | 72 | 0.5 | 1.0 | 145 | 0 | +145 | 0 of 1 | 1 of 1 | - | +145 |
| Mine | Tomb Kings of Khemri | 2 | 68 | 878 | 3.5 | 1.1 | 251 | 105 | +146 | 2 of 7 | 4 of 7 | -119 | +190 |
| Mine | Vampire Counts | 2 | 28 | 209 | 4.0 | 1.0 | 52 | 6 | +47 | 2 of 8 | 6 of 8 | - | +47 |
| Mine | Warriors of Chaos | 2 | 54 | 178 | 4.0 | 1.0 | 44 | 66 | -21 | 2 of 8 | 5 of 8 | - | -21 |
| **Mine** | all armies | 36 | 186 | 200 | 2.1 | 1.2 | 93 | 58 | +35 | 25 of 77 | 54 of 77 | +176 | +12 |
| Opponent | Empire of Man | 1 | 345 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | High Elf Realms | 5 | 94 | 649 | 3.6 | 1.5 | 180 | 52 | +129 | 9 of 18 | 13 of 18 | +176 | +99 |
| Opponent | Lizardmen | 2 | 0 | 473 | 3.5 | 1.6 | 135 | 0 | +135 | 3 of 7 | 7 of 7 | +159 | +103 |
| Opponent | Orc & Goblin Tribes | 3 | 225 | 430 | 4.7 | 1.1 | 92 | 12 | +80 | 5 of 14 | 8 of 14 | +85 | +80 |
| Opponent | Skaven | 4 | 215 | 117 | 2.0 | 1.2 | 58 | 78 | -20 | 5 of 8 | 6 of 8 | -126 | +16 |
| Opponent | Tomb Kings of Khemri | 2 | 140 | 1209 | 4.5 | 1.6 | 269 | 0 | +269 | 4 of 9 | 9 of 9 | +304 | +224 |
| Opponent | Vampire Counts | 6 | 38 | 463 | 4.7 | 1.2 | 99 | 27 | +72 | 17 of 28 | 22 of 28 | +154 | +54 |
| Opponent | Warriors of Chaos | 7 | 0 | 421 | 3.6 | 1.0 | 118 | 21 | +97 | 11 of 25 | 18 of 25 | +772 | +69 |
| Opponent | Wood Elf Realms | 6 | 42 | 541 | 4.3 | 1.3 | 125 | 25 | +100 | 11 of 26 | 21 of 26 | +57 | +112 |
| **Opponent** | all armies | 36 | 87 | 482 | 3.8 | 1.3 | 127 | 27 | +101 | 66 of 136 | 104 of 136 | +165 | +82 |

### Effective charges: dep-opp-13df7bd-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +98) | 0 | 0% (0 of 1) |
| Mine | Chaos Dwarfs | 9 | 1 (net +0) | 0 | 1 (net -112) | 1 (net +0) | 2 (net +146) | 4 (net +72) | 0 | 11% (1 of 9) |
| Mine | Dwarfen Mountain Holds | 2 | 0 | 0 | 0 | 2 (net +30) | 0 | 0 | 0 | 0% (0 of 2) |
| Mine | Empire of Man | 9 | 0 | 1 (net -265) | 0 | 4 (net -22) | 0 | 2 (net +0) | 2 | 0% (0 of 7) |
| Mine | Grand Cathay | 8 | 1 (net +0) | 1 (net -7) | 0 | 4 (net -128) | 0 | 1 (net +575) | 1 | 0% (0 of 7) |
| Mine | High Elf Realms | 10 | 0 | 0 | 2 (net -126) | 4 (net +99) | 2 (net +76) | 1 (net +0) | 1 | 22% (2 of 9) |
| Mine | Kingdom of Bretonnia | 3 | 0 | 0 | 0 | 0 | 2 (net +0) | 1 (net +0) | 0 | 0% (0 of 3) |
| Mine | Lizardmen | 5 | 0 | 0 | 0 | 3 (net +95) | 0 | 1 (net -141) | 1 | 0% (0 of 4) |
| Mine | Ogre Kingdoms | 6 | 1 (net +1240) | 1 (net -234) | 0 | 0 | 0 | 0 | 4 | 0% (0 of 2) |
| Mine | Skaven | 1 | 0 | 0 | 1 (net +145) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Mine | Tomb Kings of Khemri | 7 | 2 (net +272) | 0 | 1 (net +244) | 3 (net +77) | 1 (net +0) | 0 | 0 | 14% (1 of 7) |
| Mine | Vampire Counts | 8 | 0 | 0 | 1 (net -45) | 3 (net +73) | 0 | 2 (net +54) | 2 | 17% (1 of 6) |
| Mine | Warriors of Chaos | 8 | 1 (net -30) | 0 | 3 (net -70) | 2 (net +35) | 0 | 2 (net +0) | 0 | 38% (3 of 8) |
| Opponent | Empire of Man | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | High Elf Realms | 18 | 2 (net +81) | 0 | 3 (net +73) | 5 (net +85) | 1 (net +30) | 5 (net +296) | 2 | 19% (3 of 16) |
| Opponent | Lizardmen | 7 | 1 (net +0) | 1 (net +0) | 1 (net +0) | 2 (net +320) | 2 (net +153) | 0 | 0 | 14% (1 of 7) |
| Opponent | Orc & Goblin Tribes | 14 | 0 | 1 (net +0) | 2 (net +152) | 1 (net +185) | 1 (net +85) | 2 (net +40) | 7 | 29% (2 of 7) |
| Opponent | Skaven | 8 | 1 (net -262) | 0 | 1 (net -112) | 2 (net +84) | 1 (net +185) | 3 (net -46) | 0 | 12% (1 of 8) |
| Opponent | Tomb Kings of Khemri | 9 | 0 | 0 | 2 (net +340) | 0 | 2 (net +178) | 4 (net +314) | 1 | 25% (2 of 8) |
| Opponent | Vampire Counts | 28 | 4 (net -51) | 1 (net +365) | 6 (net +146) | 6 (net +94) | 0 | 5 (net +29) | 6 | 27% (6 of 22) |
| Opponent | Warriors of Chaos | 25 | 3 (net +28) | 0 | 4 (net +187) | 6 (net +18) | 1 (net +0) | 7 (net +205) | 4 | 19% (4 of 21) |
| Opponent | Wood Elf Realms | 26 | 4 (net +34) | 0 | 8 (net +101) | 8 (net +176) | 2 (net +20) | 1 (net +0) | 3 | 35% (8 of 23) |

### Charged fights, damage counted: dep-opp-13df7bd-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 6 | 408 | 287 | +292 | 432 | 137 | +294 | +72.2 |
| Mine | 50-54% | 3 | 239 | 272 | -169 | 142 | 280 | -138 | -57.8 |
| Mine | Effective (55-75%) | 9 | 307 | 198 | -25 | 126 | 121 | +5 | +1.6 |
| Mine | 76-89% | 26 | 297 | 158 | +25 | 100 | 50 | +50 | +16.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 15 | 267 | 200 | +62 | 135 | 20 | +115 | +43.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 550 | 104 | +63 | 89 | 40 | +49 | +8.9 |
| Mine | No odds | 11 | 204 | 192 | -29 | 31 | 59 | -28 | -13.9 |
| Mine | All fights | 77 | 308 | 185 | +35 | 126 | 69 | +58 | +18.8 |
| Opponent | Long shot (under 50%) | 16 | 238 | 285 | -5 | 95 | 95 | +0 | +0.1 |
| Opponent | 50-54% | 3 | 407 | 269 | +122 | 187 | 111 | +76 | +18.7 |
| Opponent | Effective (55-75%) | 27 | 341 | 246 | +130 | 196 | 65 | +131 | +38.3 |
| Opponent | 76-89% | 30 | 307 | 205 | +116 | 143 | 49 | +94 | +30.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 27 | 319 | 187 | +158 | 195 | 25 | +169 | +53.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 10 | 500 | 116 | +100 | 130 | 23 | +106 | +21.2 |
| Opponent | No odds | 23 | 280 | 213 | +49 | 92 | 35 | +58 | +20.6 |
| Opponent | All fights | 136 | 320 | 215 | +101 | 150 | 50 | +100 | +31.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| dep-opp-13df7bd-p4 | move | 430 | 93 (22%) | 64 (15%) | 46 (11%) | 291 (68%) |
| dep-opp-13df7bd-p4 | objective | 360 | 57 (16%) | 46 (13%) | 39 (11%) | 264 (73%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

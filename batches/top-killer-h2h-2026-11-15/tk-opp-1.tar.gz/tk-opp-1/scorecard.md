# Doctrine scorecard: tk-h2h-opp-949ddcd-p1

### Scorecard: tk-h2h-opp-949ddcd-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 5 | 3 | 0 | 1 | 0 | 0 | 0 | 65 |
| L0102 | 6 | 1 | Opponent | no | 8 | 1 | 2 | 3 | 0 | 0 | 0 | 222 |
| L0118 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 6 | 4 | 4 | 2 | 0 | 0 | 0 | 268 |
| L0135 | 3 | 1 | Mine | no | 5 | - | 0 | 1 | 1 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 2 | 0 | 5 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Opponent | - | - | 2 | 0 | 4 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Opponent | no | 4 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 5 | 2 | 3 | 0 | 0 | 0 | 0 | 985 |
| L0319 | 1 | 1 | Opponent | no | 2 | 2 | 3 | 0 | 0 | 0 | 0 | 226 |
| L0405 | 3 | 1 | Mine | yes | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 2 | 4 | 1 | 1 | 0 | 0 | 0 | 1343 |
| L0421 | 1 | 1 | Mine | no | 0 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 2 | - | 0 | 5 | 1 | 0 | 0 | 355 |
| L0508 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 1416 |
| L0508 | 4 | 1 | Opponent | no | 0 | 3 | 2 | 4 | 0 | 0 | 0 | 385 |
| L0524 | 2 | 1 | Mine | - | - | 5 | 3 | 0 | 0 | 0 | 0 | 613 |
| L0524 | 2 | 1 | Opponent | - | - | 2 | 4 | 3 | 1 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 4 | - | 1 | 2 | 0 | 0 | 0 | 615 |
| L0612 | 6 | 1 | Opponent | no | 6 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | 6 | 0 | 1 | 0 | 0 | 0 | 984 |
| L0628 | 4 | 1 | Opponent | no | 1 | - | 1 | 2 | 0 | 0 | 0 | 0 |
| L0717 | 3 | 1 | Mine | yes | 2 | 2 | 2 | 0 | 1 | 0 | 0 | 420 |
| L0717 | 3 | 1 | Opponent | yes | 9 | 2 | 4 | 0 | 1 | 0 | 0 | 184 |
| L0733 | 1 | 1 | Mine | no | 9 | 4 | 3 | 1 | 0 | 0 | 0 | 375 |
| L0733 | 1 | 1 | Opponent | no | 4 | 3 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 1 | - | 0 | 1 | 0 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 7 | 2 | 5 | 5 | 1 | 0 | 0 | 0 |
| L0913 | 1 | 1 | Mine | no | 1 | 2 | 1 | 0 | 0 | 0 | 0 | 492 |
| L0913 | 1 | 1 | Opponent | no | 5 | 2 | 6 | 0 | 0 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 994 |
| L0930 | 6 | 1 | Opponent | no | 3 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 0 | 2 | 4 | 0 | 1 | 0 | 0 | 501 |
| L1021 | 1 | 1 | Opponent | no | 0 | 6 | 5 | 5 | 0 | 0 | 0 | 355 |
| L1114 | 4 | 1 | Mine | no | 3 | 2 | 4 | 0 | 1 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | no | 5 | 2 | 2 | 2 | 0 | 0 | 0 | 500 |
| L1131 | 3 | 1 | Mine | no | 2 | - | 1 | 0 | 0 | 0 | 0 | 526 |
| L1131 | 3 | 1 | Opponent | no | 3 | 5 | 1 | 2 | 0 | 0 | 0 | 286 |
| L1224 | 6 | 1 | Mine | no | 10 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 5 | 2 | 3 | 2 | 2 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | yes | - | 3 | 3 | 2 | 0 | 0 | 0 | 140 |
| L1319 | 5 | 1 | Opponent | no | - | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 5 | 3 | 1 | 0 | 0 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 0 | 3 | 4 | 1 | 0 | 0 | 0 | 126 |
| L1431 | 3 | 1 | Mine | yes | 9 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 0 | 5 | 1 | 0 | 2 | 0 | 0 | 460 |
| L1527 | 3 | 1 | Mine | yes | 3 | 4 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | yes | - | 3 | 4 | 0 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | yes | - | 1 | 2 | 3 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | no | 0 | 1 | 3 | 0 | 3 | 0 | 0 | 72 |
| L1723 | 1 | 1 | Opponent | yes | 10 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | yes | - | 4 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 6 | 2 | 0 | 0 | 0 | 70 |
| L1923 | 3 | 1 | Mine | no | 0 | 2 | 6 | 0 | 0 | 0 | 0 | 255 |
| L1923 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2025 | 3 | 1 | Mine | yes | 7 | 4 | 2 | 2 | 1 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 5 | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | yes | 7 | 4 | 1 | 4 | 0 | 0 | 0 | 500 |
| L2127 | 3 | 1 | Opponent | no | 2 | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 2 | 1 | 0 | 0 | 0 | 0 | 55 |
| L2231 | 5 | 1 | Opponent | yes | - | 2 | 4 | 2 | 1 | 0 | 0 | 933 |
| L2335 | 1 | 1 | Mine | no | 5 | 2 | 2 | 1 | 0 | 0 | 0 | 185 |
| L2335 | 1 | 1 | Opponent | no | 0 | 3 | 2 | 1 | 1 | 0 | 0 | 126 |
| L2531 | 5 | 1 | Mine | yes | - | 4 | 4 | 4 | 1 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | no | - | 4 | 0 | 2 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Mine | no | 1 | 1 | 9 | 3 | 0 | 0 | 0 | 60 |
| L2730 | 6 | 1 | Opponent | no | 4 | 4 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 1 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Opponent | no | 0 | 1 | 2 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 32% | 2.9 | 2.8 | 2.3 | 1.1 | 0.3 | 0.0 | 0.0 | 310.8 |
| **Average** | | | Opponent | 15% | 3.2 | 2.6 | 3.0 | 2.0 | 0.3 | 0.0 | 0.0 | 175.2 |

### KPIs: tk-h2h-opp-949ddcd-p1

Rules off - Mine only: STAY WORTH, BEST MOVE FOR SHOOTERS, THREAT IN THE KILL, FOCUS OVER TURNS, MISSILES IN THE PLAN, FACE THE CAST, WIZARD FRONT RANK, THREAT OVER THE TURNS, THREAT TO WORN DOWN.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 30% (54 of 178) | 3% (5 of 181) | 16% (59 of 359) |
| Winner chose to follow up after the loser gave ground |  | 95% (78 of 82); on the table 99% | 100% (52 of 52); on the table 100% | 97% (130 of 134); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 81% (17 of 21); on the table 81% | 95% (19 of 20); on the table 95% | 88% (36 of 41); on the table 88% |
| Winner chose to pursue after the loser fled |  | 74% (26 of 35); on the table 86% | 93% (38 of 41); on the table 95% | 84% (64 of 76); on the table 91% |
| Winner chose to follow up or pursue (all three) |  | 88% (121 of 138); on the table 93% | 96% (109 of 113); on the table 97% | 92% (230 of 251); on the table 95% |
| Magic missiles tried each own turn | 50%+ | 33% (110 of 330) | 28% (58 of 210) | 31% (168 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 49% (110 of 226) | 38% (58 of 152) | 44% (168 of 378) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 31% (47 of 150) | 20% (17 of 84) | 27% (64 of 234) |
|     round 1 |  | 24% (6 of 25) | 14% (2 of 14) | 21% (8 of 39) |
|     rounds 2+ |  | 33% (41 of 125) | 21% (15 of 70) | 29% (56 of 195) |
|   other wizards | 50%+ | 35% (63 of 180) | 33% (41 of 126) | 34% (104 of 306) |
|     round 1 |  | 23% (7 of 30) | 38% (8 of 21) | 29% (15 of 51) |
|     rounds 2+ |  | 37% (56 of 150) | 31% (33 of 105) | 35% (89 of 255) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 71% (24 of 34) | 66% (29 of 44) | 68% (53 of 78) |
| Points that never fought | lower | 35% (24885 of 71484) | 40% (29100 of 71889) | 38% (53985 of 143373) |
|   infantry points that never fought | lower | 44% (7376 of 16863) | 58% (7778 of 13348) | 50% (15154 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 53% (147 of 279) | 61% (179 of 295) | 57% (326 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 91% (20 of 22); 2.0 uses a game | 80% (16 of 20); 1.7 uses a game | 86% (36 of 42); 1.8 uses a game |
| Bound items with another spell used |  | 69% (11 of 16); 0.7 uses a game | 38% (3 of 8); 0.1 uses a game | 58% (14 of 24); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 74% (14 of 19); 0.4 uses a game | 67% (8 of 12); 0.2 uses a game | 71% (22 of 31); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 47% (28170 of 59666) | 54% (34162 of 62699) | 51% (62332 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.9 (31%) | 1.5 (36%) | 3.4 (33%) |
| MARCHED: its unit marched | 1.0 (16%) | 0.7 (17%) | 1.7 (16%) |
| CHARGED: its unit charged | 0.2 (4%) | 0.2 (4%) | 0.4 (4%) |
| IN COMBAT: engaged in combat | 1.8 (29%) | 0.6 (14%) | 2.3 (23%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.1 (3%) | 0.2 (2%) |
| GONE: slain | 0.5 (8%) | 0.8 (20%) | 1.3 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.7 (11%) | 0.2 (5%) | 0.9 (8%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.4 | 1.6 | 1.4 | 4.7 | 0.5 | 2.0 |
| not cast | 3.6 | 2.8 | 3.2 | 10.3 | 1.8 | 22.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.8 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.8 (30%) | 0.3 (9%) | 3.4 (33%) | 0.3 (18%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (16%) | 0.3 (15%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (4%) | 0.1 (5%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (5%) | 0.3 (12%) | 0.5 (15%) | 2.3 (23%) | 0.5 (27%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (5%) | 0.3 (12%) | 0.4 (13%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (5%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 0.8 (22%) | 0.6 (22%) | 0.4 (13%) | 1.3 (13%) | 0.2 (9%) | 2.4 (11%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (12%) | 0.2 (6%) | 0.3 (9%) | 0.9 (8%) | 0.0 (2%) | 0.9 (4%) |
| STUPIDITY: Stupidity | 0.0 (1%) | 0.1 (4%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.3 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.2 (6%) | 0.0 (0%) | 0.0 (0%) | 0.4 (20%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (57%) | 0.2 (8%) | 1.3 (41%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.4 (75%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.4 a game | 0.9 a game |
| stood (cast and not dispelled) | 64% (27 of 42) | 54% (7 of 13) | 62% (34 of 55) |
| the unit moved after it | 63% (17 of 27) | 57% (4 of 7) | 62% (21 of 34) |
| it charged on its next turn | 0% (0 of 27) | 0% (0 of 7) | 0% (0 of 34) |
| the enemy charged it first | 33% (9 of 27) | 0% (0 of 7) | 26% (9 of 34) |
| it fought by the end of its next turn | 22% (6 of 27) | 0% (0 of 7) | 18% (6 of 34) |
| it moved out of a charge the enemy had planned (not charged first) | 11% (3 of 27) | 14% (1 of 7) | 12% (4 of 34) |
| none of these (no charge, no fight, no charge escaped) | 56% (15 of 27) | 86% (6 of 7) | 62% (21 of 34) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (555 of 876) | 60% (356 of 589) | 62% (911 of 1465) |
|   cavalry | 65% (47 of 72) | 70% (90 of 128) | 68% (137 of 200) |
|   character | 42% (41 of 97) | 29% (35 of 119) | 35% (76 of 216) |
|   chariot | 51% (46 of 90) | 71% (29 of 41) | 57% (75 of 131) |
|   infantry | 57% (172 of 302) | 65% (144 of 220) | 61% (316 of 522) |
|   monster | 53% (19 of 36) | 46% (12 of 26) | 50% (31 of 62) |
|   war machine | 82% (230 of 279) | 84% (46 of 55) | 83% (276 of 334) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.5 (28%) | 1.2 (19%) | 3.8 (24%) |
| CHARGED: it charged | 1.1 (13%) | 1.5 (23%) | 2.6 (17%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.9 (10%) | 0.4 (6%) | 1.2 (8%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.6 (18%) | 1.7 (26%) | 3.3 (21%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (5%) | 0.6 (9%) | 1.1 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (16%) | 0.6 (9%) | 2.0 (13%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.3 (5%) | 0.6 (4%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| OTHER BAR | 0.4 (4%) | 0.1 (1%) | 0.4 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.2 | 1.4 | 79% | 5.0 pts | 26 pts |
| character | 2.4 | 0.6 | 80% | 4.6 pts | 11 pts |
| chariot | 2.1 | 1.9 | 59% | 13.7 pts | 29 pts |
| infantry | 13.0 | 4.3 | 77% | 8.0 pts | 104 pts |
| monster | 0.9 | 0.2 | 79% | 5.3 pts | 5 pts |
| war machine | 7.7 | 5.2 | 67% | 21.8 pts | 167 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.4 | 5.9 | 5.1 |
| Charges that made contact a game | 3.1 | 4.1 | 3.6 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.32 declared, 1.05 contact (22 units) | 0.43 declared, 0.21 contact (14 units) | 0.97 declared, 0.72 contact (36 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.50 declared, 0.33 contact (6 units) | 1.62 declared, 1.25 contact (8 units) | 1.14 declared, 0.86 contact (14 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.49 declared, 0.35 contact (253 units) | 0.66 declared, 0.47 contact (292 units) | 0.59 declared, 0.41 contact (545 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 54% (38 of 70) | 57% (12 of 21) | 62% (5 of 8) | 56% (55 of 99) |
| Character in a unit | 79% (23 of 29) | 65% (15 of 23) | 50% (2 of 4) | 71% (40 of 56) |
| Character on its own | 81% (47 of 58) | 54% (20 of 37) | 27% (17 of 62) | 54% (84 of 157) |
| Chariot | 62% (10 of 16) | 20% (2 of 10) | - | 46% (12 of 26) |
| Infantry | 55% (49 of 89) | 33% (12 of 36) | 50% (1 of 2) | 49% (62 of 127) |
| Monster | 69% (22 of 32) | 70% (7 of 10) | - | 69% (29 of 42) |
| Monstrous | 55% (6 of 11) | 57% (8 of 14) | - | 56% (14 of 25) |
| War Machines | 71% (29 of 41) | 100% (1 of 1) | - | 71% (30 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 88% (14 of 16); on the table 100% | 44% (61 of 138) | 41% | 58% (19 of 33) | 100% (9 of 9); 6.3 uses a game | 100% (3 of 3); 1.7 uses a game | 89% (8 of 9); 1.3 uses a game |
| Chaos Dwarfs | 3 | 60% (6 of 10); on the table 60% | 29% (7 of 24) | 36% | 33% (8 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |
| Dwarfen Mountain Holds | 5 | 77% (10 of 13); on the table 85% | - | 49% | 71% (29 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 94% (15 of 16); on the table 100% | 31% (11 of 36) | 63% | 61% (39 of 64) | 0.0 uses a game | 100% (2 of 2); 0.7 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 5 | 95% (21 of 22); on the table 95% | 28% (30 of 108) | 42% | 41% (18 of 44) | 92% (11 of 12); 7.6 uses a game | 0% (0 of 1); 0.0 uses a game | 60% (3 of 5); 0.6 uses a game |
| High Elf Realms | 6 | 76% (13 of 17); on the table 82% | 30% (9 of 30) | 32% | 37% (18 of 49) | 100% (5 of 5); 2.5 uses a game | 50% (9 of 18); 2.2 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (2 of 2); on the table 100% | - | 18% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 100% (5 of 5); on the table 100% | - | 36% | 71% (10 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 100% (6 of 6); on the table 100% | 17% (2 of 12) | 52% | 67% (14 of 21) | 67% (2 of 3); 2.7 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (14 of 14); on the table 100% | 8% (3 of 36) | 6% | 75% (18 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 4 | 85% (11 of 13); on the table 100% | 40% (12 of 30) | 32% | 65% (22 of 34) | 100% (3 of 3); 2.0 uses a game | 0.0 uses a game | 100% (4 of 4); 1.0 uses a game |
| Tomb Kings of Khemri | 6 | 94% (29 of 31); on the table 94% | 8% (1 of 12) | 33% | 37% (11 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 98% (39 of 40); on the table 100% | 31% (17 of 54) | 27% | 56% (28 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 97% (29 of 30); on the table 97% | 27% (8 of 30) | 38% | 64% (47 of 74) | 100% (4 of 4); 2.1 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 100% (16 of 16); on the table 100% | 23% (7 of 30) | 37% | 62% (41 of 66) | 33% (2 of 6); 1.5 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |

Flank and rear charges a unit could have turned to face (tk-h2h-opp-949ddcd-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 54% (46) | 33% (22) | 45% (68) |
| ...free all their last turn and able to turn (per game) | 0.72 | 0.39 | 1.11 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.25 | 0.08 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.42 | 0.33 | 0.75 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.31 | 1.47 | 2.78 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.97 | 0.67 | 1.64 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 4.81 | 4.86 | 9.67 |

### Quality by phase: tk-h2h-opp-949ddcd-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 51% (77 of 151) | 42% (85 of 202) |
| Strategy | Shoot objectives carried out (shot that target) | 48% (178 of 371) | 56% (105 of 189) |
| Strategy | Close-in objectives charged next turn | 13% (16 of 122) | 17% (34 of 196) |
| Strategy | Support requests answered (helper made contact too) | 44% (8 of 18) | 54% (15 of 28) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | 0% (0 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 41% (7 of 17) | 60% (6 of 10) |
| Strategy | Joined characters whose unit fought | 43% (21 of 49) | 39% (13 of 33) |
| Strategy | Lone characters that fought | 84% (81 of 97) | 74% (76 of 103) |
| Movement | Charges halted short of contact | 0.1 | 0.1 |
| Movement | Idle units | 1.1 | 2.0 |
| Movement | Points that never moved of their own | 310.8 | 175.2 |
| Movement | Fights charged into per game | 2.6 | 3.6 |
| Movement | Charges with odds: long shots (under 50%) | 16 of 85, net +69 | 22 of 112, net +51 |
| Movement | Charges with odds: sweet spot (55-75%) | 13 of 85, net +207 | 17 of 112, net +83 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 7 of 85, net +74 | 4 of 112, net +46 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 32 of 85, net +50 | 43 of 112, net +127 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.0 | 9.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (158 of 360) | 43% (147 of 338) |
| Shooting | Points destroyed by shooting units | 93.6 | 42.2 |
| Shooting | War machine shots | 6.4 | 1.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (102 of 230) | 48% (22 of 46) |
| Shooting | Points destroyed by war machines | 70.6 | 8.1 |
| Magic | Magic missiles cast | 2.1 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 34% (26 of 77) | 35% (14 of 40) |
| Magic | Wounds caused by magic missiles | 4.9 | 1.9 |
| Magic | Wounds caused by other spells | 2.2 | 0.5 |
| Magic | Points destroyed by magic (all spells) | 110.2 | 22.4 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.6 / 0.5 / 1.0 / 0.1 | 1.4 / 0.4 / 0.4 / 0.1 |
| Combat | Points destroyed in combat | 323.5 | 388.2 |
| Combat | Points run down | 110.9 | 159.4 |
| Combat | Net points per charged fight, damage counted | +62 | +78 |
| Combat | Net per 100 charger points, damage counted | +21.4 | +32.2 |
| Combat | First round won (charged fights) | 72% | 61% |
| Combat | Net points per charged fight | +65 | +86 |
| Combat | Net points per supported fight / lone fight | +205 / +32 | +82 / +87 |
| Combat | Charged fights on a top-3 enemy unit | 38 of 95 | 53 of 129 |
| Game | Points lost | 747.7 | 831.7 |
| Game | VP from objectives | 587.2 | 646.7 |
| Game | Lone holders (player turns) | 2.9 | 3.2 |

- Mine won / drew / lost: 17 / 4 / 15 of 36 ended games (of 36); mean margin (Mine - Opponent) +17 VP
- The side that went first won 14 of 32 games with a winner
- Points traded per game (both sides' losses): 1579
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: tk-h2h-opp-949ddcd-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 3.5 |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 25.3 | 0.2 | +0.0 | 0.0 | 6.2 |
| BACKUP TARGETS | 0.6 | +4.6 | 0.0 | 9.6 | 0.9 | +10.2 | 0.0 | 35.3 |
| BEST FACING | 0.3 | +20.8 | 0.0 | 20.4 | 0.7 | +37.7 | 0.0 | 39.8 |
| BEST FIRST | 4.3 | +223.8 | 177.7 | 60.9 | 3.9 | +201.9 | 87.0 | 76.9 |
| BEST MOVE FOR SHOOTERS | - | - | - | - | 0.8 | +58.1 | 0.0 | 17.1 |
| BEST OVERALL | 0.3 | +14.7 | 0.0 | 9.3 | 0.5 | +52.9 | 0.0 | 15.1 |
| BEST PREY | 0.7 | +44.2 | 48.3 | 14.4 | 1.0 | +50.2 | 13.2 | 30.7 |
| BEST PRIZE | 0.1 | +3.1 | 4.7 | 13.7 | 0.0 | -0.4 | 0.0 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | -0.0 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 2.4 | 0.0 | +0.0 | 11.1 | 0.0 |
| BLOCKED WHEEL | 0.3 | +13.5 | 0.0 | 13.8 | 0.4 | +16.5 | 0.0 | 1.9 |
| BOMBING RUN | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.6 | +0.0 | 67.2 | 16.5 | 0.1 | +0.0 | 13.0 | 0.0 |
| CANNON PLANNED TARGET | 5.1 | +133.1 | 324.3 | 85.8 | 1.0 | +22.0 | 43.2 | 21.1 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 3.5 | 0.4 | +0.0 | 0.0 | 7.2 |
| CARRIES OUT COUNTER | 0.0 | -1.4 | 0.0 | 0.0 | 0.1 | +0.0 | 9.6 | 0.0 |
| CARRIES OUT SET-UP | 0.0 | +0.0 | 5.1 | 0.0 | 0.1 | -5.0 | 3.9 | 0.0 |
| CAST JOB | 0.7 | +29.7 | 80.9 | 12.3 | 0.3 | +3.7 | 4.9 | 12.3 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +48.0 | 22.9 | 0.0 | 0.2 | +5.6 | 11.4 | 4.4 |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 3.6 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.2 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| CATCH ODDS | - | - | - | - | 0.1 | +1.8 | 0.0 | 0.0 |
| CHAFF PASSED | 0.1 | -0.3 | 0.0 | 0.0 | 0.2 | -0.0 | 0.0 | 5.1 |
| CHARGE NOW FIRST | 3.0 | +0.0 | 249.7 | 77.2 | 3.0 | +0.0 | 279.6 | 42.4 |
| CHARGE NOW WEIGHED | 0.4 | -23.0 | 21.3 | 10.4 | 0.6 | -31.6 | 10.8 | 24.1 |
| CHARIOT WIZARD CAREFUL | 0.2 | -3.1 | 16.8 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 9.6 | 0.0 | 0.1 | +0.0 | 18.3 | 1.4 |
| COMBAT PIVOT | 0.3 | +0.0 | 33.3 | 5.8 | 0.5 | +0.0 | 47.3 | 31.1 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.7 | +119.0 | 5.1 | 3.6 | 0.2 | +72.1 | 4.4 | 15.2 |
| COUNTER-CHARGE COVER | 8.9 | +615.7 | 0.0 | 251.4 | 6.6 | +651.6 | 0.0 | 190.6 |
| DEFENSIVE ARMY | 0.4 | +0.0 | 37.4 | 6.1 | - | - | - | - |
| DEFENSIVE FLOOR | 0.1 | +1.2 | 4.0 | 1.5 | 0.0 | +1.5 | 2.4 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +10.9 | 14.5 | 6.5 | 0.2 | +10.7 | 22.1 | 0.0 |
| ELIXIR WORTH | 0.1 | +4.2 | 0.0 | 0.0 | 0.0 | +1.3 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.3 | +102.3 | 0.0 | 47.9 | 1.5 | +164.5 | 0.0 | 76.9 |
| FALLBACK BY WORTH | 4.7 | +62.0 | 0.0 | 59.2 | 5.4 | +54.0 | 0.0 | 57.2 |
| FIGHT LIFT | 0.0 | +0.7 | 7.0 | 0.0 | - | - | - | - |
| FIRE AND FLEE | 0.0 | +0.1 | 0.0 | 0.0 | 0.1 | +1.8 | 4.5 | 8.3 |
| FLANK NOT WEIGHED | 4.8 | +0.0 | 0.0 | 168.9 | 4.8 | +0.0 | 0.0 | 189.5 |
| FOCUS FIRE | 0.0 | +0.8 | 3.1 | 0.0 | 0.1 | +0.5 | 1.8 | 0.0 |
| FOCUS OVER TURNS | - | - | - | - | 0.5 | +14.2 | 17.1 | 6.9 |
| FOLLOW UP WEIGHED | 1.2 | +175.3 | 0.0 | 24.8 | 0.9 | +144.6 | 0.0 | 34.5 |
| FRIENDS SHOTS CHECKED | 0.4 | +21.7 | 0.0 | 30.1 | 0.2 | +10.9 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -0.4 | 0.0 | 2.8 | 0.2 | -3.1 | 16.6 | 9.4 |
| GIVES UP ITS SCREEN | 0.0 | -0.0 | 7.0 | 1.5 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 13.4 | 0.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 30.0 | 0.0 | 0.4 | +0.0 | 27.4 | 24.8 |
| HILL BY ITS CHANCE | - | - | - | - | 0.2 | -17.7 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.0 | +0.0 | 0.0 | 0.0 | 0.3 | +10.5 | 6.9 | 11.3 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 6.4 |
| HUNT IN PAIRS | 0.4 | +33.1 | 0.0 | 12.1 | 0.2 | +14.7 | 0.0 | 12.8 |
| HUNT KEPT | 0.1 | +0.0 | 0.0 | 3.3 | 0.1 | +0.8 | 3.5 | 0.0 |
| HUNT RESULT | 0.0 | +0.0 | 0.0 | 0.0 | 0.4 | +25.6 | 10.2 | 14.2 |
| HUNT THE GUNS | 0.0 | +5.7 | 0.0 | 0.0 | 0.4 | +142.9 | 18.5 | 13.9 |
| INVITES THE FIGHT | 1.8 | +36.2 | 62.6 | 71.4 | 1.4 | +24.8 | 36.4 | 12.1 |
| JOINT CHARGE PLAN | - | - | - | - | 0.3 | +38.2 | 10.2 | 0.0 |
| KEEP FALLS | 0.1 | +0.5 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.7 | +50.0 | 124.3 | 49.1 | 2.2 | +67.5 | 167.7 | 45.6 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.9 | +69.6 | 134.6 | 15.9 | 2.2 | +91.8 | 171.5 | 59.8 |
| KILLS COUNT NEXT TURN | 4.5 | +191.0 | 233.3 | 106.1 | 6.2 | +242.7 | 208.5 | 170.2 |
| LONE CHARACTER SAFE SPOT | 0.3 | +24.9 | 1.2 | 1.2 | 0.5 | +6.3 | 24.1 | 13.8 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 5.4 |
| LONE WIZARD KEPT IN | 0.7 | +49.1 | 0.0 | 0.0 | 0.2 | +24.5 | 0.0 | 0.0 |
| LONG SHOT | 0.6 | +0.6 | 30.7 | 2.1 | 0.4 | +0.1 | 17.4 | 0.0 |
| LOST CHARGE | 2.4 | -33.2 | 99.2 | 86.6 | 2.8 | -52.9 | 97.9 | 67.6 |
| LURE BY WHAT IT DRAWS | 0.1 | -7.0 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 0.3 | +39.0 | 22.6 | 3.2 | 0.6 | +77.3 | 11.1 | 4.4 |
| MANOEUVRE | 0.2 | +10.8 | 0.0 | 9.0 | 0.2 | +2.1 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.5 | 0.0 | 0.0 |
| MARCH CHECK | 0.6 | +18.1 | 0.0 | 15.0 | 0.5 | +34.6 | 0.0 | 0.0 |
| MARCH ODDS | 0.2 | +16.1 | 4.9 | 0.0 | 0.2 | +8.9 | 6.4 | 0.0 |
| MARCH OVER CASTS | 0.4 | +21.8 | 0.0 | 25.6 | 0.4 | +23.8 | 0.0 | 9.9 |
| MAX FOR POSITIONING | 4.7 | +176.3 | 0.0 | 154.2 | 4.4 | +156.4 | 0.0 | 107.3 |
| MISSILES IN THE MOVE | 4.1 | +168.5 | 0.0 | 83.2 | 3.4 | +82.3 | 0.0 | 67.3 |
| MISSILES IN THE PLAN | - | - | - | - | 0.4 | +2.2 | 2.4 | 0.0 |
| MISSILES NEXT TURN | 4.8 | +113.1 | 0.0 | 119.9 | 4.2 | +56.0 | 0.0 | 76.5 |
| MODEL FACING | 0.2 | +70.7 | 0.0 | 1.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 12.4 | 0.0 | 0.4 | +0.0 | 15.2 | 0.0 |
| MOVE AND CAST | 0.2 | +16.3 | 0.0 | 6.8 | 0.5 | +27.2 | 0.0 | 19.3 |
| MOVE SPELL IN RANGE | 0.1 | +5.4 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -45.8 | 0.0 | 13.5 | 0.1 | -3.9 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 2.4 | +153.4 | 90.5 | 43.2 | 4.2 | +350.3 | 146.6 | 112.7 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.1 | +12.3 | 16.4 | 15.9 |
| NO RALLY LEFT | 0.1 | +1.4 | 0.0 | 0.0 | 0.1 | +8.4 | 0.0 | 11.2 |
| NOT NEEDED | 0.3 | -14.0 | 25.8 | 3.4 | 0.4 | -15.6 | 38.4 | 8.6 |
| NOT TURNED | 4.8 | +84.3 | 0.0 | 135.1 | 4.9 | +68.3 | 0.0 | 178.7 |
| NOT WORTH A CAST | 0.8 | -0.7 | 0.0 | 23.8 | 0.3 | -0.3 | 0.0 | 0.0 |
| OFF BEST | 16.1 | -836.9 | 37.7 | 333.6 | 14.8 | -754.0 | 15.8 | 281.1 |
| OPENS A LANE | 0.2 | +0.9 | 30.7 | 0.0 | 0.1 | +0.8 | 5.4 | 0.0 |
| OPENS UP | 0.2 | +16.4 | 16.7 | 27.4 | 0.3 | +27.6 | 12.0 | 7.9 |
| OVERRUNS AWAY | 0.4 | +4.0 | 54.9 | 21.7 | 0.6 | +8.2 | 33.2 | 14.1 |
| PATHS CROSS | 1.8 | +111.4 | 0.0 | 13.4 | 2.3 | +177.3 | 0.0 | 48.8 |
| PERIAPT WORTH | 0.1 | +6.8 | 0.0 | 0.0 | 0.1 | +4.9 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -0.6 | 0.0 | 2.2 | 0.0 | -0.2 | 0.0 | 2.9 |
| PLAN RESULT | 37.0 | +1348.1 | 1429.4 | 973.4 | 37.9 | +1249.4 | 1566.8 | 981.8 |
| PURSUES BIG PREY | 0.1 | -2.4 | 0.0 | 5.2 | 0.2 | -14.0 | 0.0 | 16.6 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.1 | +11.5 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +2.4 | 0.0 | 0.0 | 0.1 | +4.9 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.9 | +14.3 | 0.0 | 5.8 | 1.2 | +18.1 | 0.0 | 65.6 |
| RANDOM MOVER NO PROMISE | 0.2 | -11.1 | 7.8 | 0.0 | 0.2 | -9.2 | 0.0 | 20.0 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -4.2 | 0.0 | 2.8 | 0.5 | -7.5 | 0.0 | 11.6 |
| REDIRECT COUNTER | 2.2 | +143.8 | 0.0 | 52.1 | 4.0 | +344.6 | 0.0 | 54.5 |
| REDIRECT WEIGHED | 0.2 | +5.4 | 7.4 | 18.2 | 0.4 | +17.1 | 26.1 | 2.5 |
| RESERVE FALL BACK | 0.4 | +9.6 | 0.0 | 7.1 | 1.0 | +39.2 | 0.0 | 23.2 |
| RESTRAINS TO SHOOT | 0.1 | +1.2 | 0.0 | 5.8 | 0.1 | +4.2 | 0.0 | 5.1 |
| RISK BY ARC | 2.7 | +105.2 | 214.1 | 77.4 | 3.4 | +99.3 | 287.4 | 90.2 |
| SAFER THAN THE JOB | 1.0 | +50.3 | 0.0 | 53.3 | 0.7 | +30.3 | 0.0 | 3.5 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.9 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.9 |
| SCREEN BY WHAT IT SAVES | 0.2 | -4.3 | 0.0 | 0.0 | 0.1 | -1.3 | 0.0 | 0.0 |
| SEARCH SPOT | 1.8 | +82.6 | 0.0 | 40.7 | 2.8 | +147.7 | 0.0 | 20.9 |
| SELF MOVE SPELL | 0.2 | +11.0 | 0.0 | 18.1 | 0.2 | -0.1 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.7 | +94.6 | 53.5 | 3.2 | 1.5 | +160.4 | 33.8 | 7.4 |
| SET-UP ANY TARGET | 0.3 | +34.8 | 5.1 | 3.6 | 0.1 | +16.9 | 4.4 | 7.6 |
| SET-UP MISSED | 0.1 | +2.4 | 0.0 | 0.0 | 0.1 | +9.3 | 0.0 | 15.2 |
| SHOOTER COUNTED ONCE | 0.0 | -0.5 | 0.0 | 0.0 | 0.0 | -0.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +54.0 | 111.7 | 26.3 | 0.6 | +35.9 | 49.9 | 8.3 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 3.8 |
| SHOT OPTIONS | 15.3 | +0.0 | 843.2 | 310.5 | 9.9 | +0.0 | 408.0 | 237.7 |
| SHOT REPLANNED | 0.7 | +0.0 | 169.9 | 3.5 | 0.2 | +0.0 | 24.6 | 0.0 |
| SHOTS IN THE MOVE | 14.2 | +523.5 | 0.0 | 262.4 | 9.2 | +203.5 | 0.0 | 158.6 |
| SPELL SETS UP CHARGE | 0.5 | +108.8 | 5.1 | 3.6 | 0.2 | +74.5 | 4.4 | 7.6 |
| SPELL WORTH | 1.5 | +19.8 | 78.2 | 48.9 | 1.7 | +38.1 | 92.1 | 102.1 |
| STABLE ROLE | 11.1 | +0.0 | 434.8 | 166.6 | 11.5 | +0.0 | 450.0 | 137.7 |
| STANDS TO CAST | 0.1 | +3.4 | 0.0 | 0.0 | 0.0 | +1.4 | 3.2 | 0.0 |
| STAY WEIGHED | - | - | - | - | 0.1 | +4.4 | 0.0 | 0.0 |
| STAY WORTH | - | - | - | - | 11.3 | +203.3 | 240.5 | 137.1 |
| STOPS | 0.0 | +0.0 | 0.0 | 1.7 | 0.1 | +2.1 | 15.0 | 2.6 |
| STOPS SHORT OF THE FLANK | 0.5 | +26.7 | 0.0 | 24.1 | 0.4 | +27.7 | 0.0 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 4.0 |
| SUPPORT NARROWED | 5.4 | -35.6 | 290.0 | 97.8 | 7.2 | -50.4 | 424.0 | 102.0 |
| SUPPORTS | 3.3 | +37.5 | 165.5 | 63.4 | 4.3 | +50.4 | 177.7 | 57.2 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -5.3 | 8.3 | 9.6 | 0.0 | -0.6 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.6 | -0.9 | 7.0 | 0.0 | 0.6 | +2.6 | 0.0 | 18.2 |
| THREAT IN THE KILL | - | - | - | - | 7.3 | +49.8 | 408.8 | 178.4 |
| THREAT OVER THE TURNS | - | - | - | - | 5.8 | +32.5 | 357.1 | 159.8 |
| THREAT TO WORN DOWN | - | - | - | - | 7.1 | +59.6 | 397.1 | 178.4 |
| THROUGH LINE OF FIRE | 0.7 | +40.1 | 0.0 | 29.3 | 0.1 | +4.3 | 0.0 | 0.0 |
| TURN WORTH | 0.6 | -42.3 | 45.5 | 26.8 | 0.6 | -39.6 | 39.7 | 15.2 |
| TWO OR MORE ARRIVE | 0.2 | +2.0 | 12.4 | 3.2 | 0.2 | +0.8 | 5.8 | 0.0 |
| WAIT AFTER COSTS | 6.3 | -274.8 | 238.8 | 148.7 | 7.7 | -391.9 | 266.5 | 157.1 |
| WALKS TO THE FIGHT | 1.9 | +50.5 | 71.7 | 28.3 | 1.3 | +49.8 | 53.8 | 25.1 |
| WAR ENGINE CHARGES | 0.1 | +10.2 | 13.1 | 1.8 | 0.1 | +3.8 | 0.0 | 2.1 |
| WAR ENGINE JOBS | 0.6 | +0.0 | 54.6 | 16.2 | 0.6 | +0.0 | 22.6 | 6.9 |
| WEARS DOWN | 1.2 | +73.7 | 111.3 | 50.6 | 1.6 | +60.7 | 128.6 | 44.5 |
| WHO HITS BACK | 0.3 | +16.2 | 0.0 | 10.6 | 0.2 | +23.8 | 0.0 | 13.1 |
| WHOLE FIGHT | 0.2 | +12.0 | 31.9 | 8.5 | 0.5 | +27.1 | 72.8 | 7.6 |
| WHOLE FIGHT GAIN | 0.2 | +11.9 | 31.8 | 1.2 | 0.7 | +65.9 | 98.7 | 19.4 |

### Rule changes: tk-h2h-opp-949ddcd-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1113 | 1113 | 1113 | 30.92 | -57275 | -51.5 |
| BEST FIRST | 295 | 295 | 295 | 8.19 | +15326 | +52.0 |
| COUNTER-CHARGE COVER | 557 | 305 | 164 | 4.56 | +10617 | +64.7 |
| SEARCH SPOT | 166 | 166 | 164 | 4.56 | +8289 | +50.5 |
| PATHS CROSS | 146 | 146 | 146 | 4.06 | +10392 | +71.2 |
| KILLS COUNT NEXT TURN | 383 | 383 | 124 | 3.44 | +4856 | +39.2 |
| MOVE TO CHARGE | 235 | 235 | 111 | 3.08 | +7736 | +69.7 |
| FACES THE THREAT | 100 | 100 | 100 | 2.78 | +9606 | +96.1 |
| SUPPORTS | 275 | 275 | 84 | 2.33 | +721 | +8.6 |
| FALLBACK BY WORTH | 365 | 365 | 82 | 2.28 | +4176 | +50.9 |
| FOLLOW UP WEIGHED | 76 | 76 | 76 | 2.11 | +11517 | +151.5 |
| WALKS TO THE FIGHT | 115 | 115 | 72 | 2.00 | +1581 | +22.0 |
| WAIT AFTER COSTS | 503 | 503 | 67 | 1.86 | +1280 | +19.1 |
| SAFER THAN THE JOB | 59 | 59 | 59 | 1.64 | +2903 | +49.2 |
| SHOTS IN THE MOVE | 843 | 560 | 58 | 1.61 | +1209 | +20.8 |
| CHARGE NOW FIRST | 217 | 217 | 56 | 1.56 | -5256 | -93.9 |
| ARTILLERY RE-ROLL WEIGHED | 54 | 54 | 54 | 1.50 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 78 | 78 | 53 | 1.47 | +1166 | +22.0 |
| REDIRECT COUNTER | 225 | 127 | 53 | 1.47 | +4102 | +77.4 |
| CANNON SIGHT KEPT | 52 | 52 | 52 | 1.44 | +0 | +0.0 |
| RESERVE FALL BACK | 50 | 50 | 50 | 1.39 | +1756 | +35.1 |
| ADVANCE LANE KEPT | 49 | 49 | 49 | 1.36 | +0 | +0.0 |
| CANNON PLANNED TARGET | 219 | 219 | 45 | 1.25 | +67 | +1.5 |
| MAX FOR POSITIONING | 325 | 194 | 45 | 1.25 | +579 | +12.9 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| RISK BY ARC | 218 | 208 | 43 | 1.19 | +1394 | +32.4 |
| BEST FACING | 38 | 38 | 38 | 1.06 | +2109 | +55.5 |
| SET UP TOGETHER | 77 | 65 | 36 | 1.00 | +4649 | +129.1 |
| CHARGE NOW WEIGHED | 35 | 35 | 35 | 0.97 | +1775 | +50.7 |
| MARCH CHECK | 38 | 37 | 35 | 0.97 | +2185 | +62.4 |
| LONE WIZARD KEPT IN | 34 | 34 | 34 | 0.94 | +2648 | +77.9 |
| SHOOTS FROM THE BEST SPOT | 68 | 68 | 34 | 0.94 | +1299 | +38.2 |
| STAY WORTH | 407 | 326 | 32 | 0.89 | +569 | +17.8 |
| STOPS SHORT OF THE FLANK | 31 | 31 | 31 | 0.86 | +1957 | +63.1 |
| BEST OVERALL | 30 | 30 | 30 | 0.83 | +2433 | +81.1 |
| INVITES THE FIGHT | 113 | 113 | 30 | 0.83 | +380 | +12.7 |
| SHOT REPLANNED | 30 | 30 | 30 | 0.83 | +0 | +0.0 |
| BEST MOVE FOR SHOOTERS | 29 | 29 | 29 | 0.81 | +2092 | +72.1 |
| KILLS COUNT | 147 | 144 | 29 | 0.81 | +1010 | +34.8 |
| COMBAT PIVOT | 28 | 28 | 28 | 0.78 | +0 | +0.0 |
| MISSILES IN THE MOVE | 270 | 158 | 27 | 0.75 | +927 | +34.3 |
| THROUGH LINE OF FIRE | 27 | 27 | 27 | 0.75 | +1597 | +59.1 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| MOVE AND CAST | 25 | 25 | 25 | 0.69 | +1563 | +62.5 |
| REDIRECT WEIGHED | 25 | 25 | 25 | 0.69 | +1272 | +50.9 |
| BLOCKED WHEEL | 24 | 24 | 24 | 0.67 | +1080 | +45.0 |
| SHOOTERS IN TWO RANKS | 24 | 24 | 24 | 0.67 | +58 | +2.4 |
| BEST PREY | 61 | 61 | 21 | 0.58 | +1150 | +54.8 |
| CAST JOB | 35 | 35 | 21 | 0.58 | +341 | +16.2 |
| KEEPS ITS TARGET | 141 | 139 | 21 | 0.58 | +276 | +13.1 |
| THREAT TO WORN DOWN | 257 | 209 | 21 | 0.58 | +109 | +5.2 |
| FRIENDS SHOTS CHECKED | 20 | 20 | 20 | 0.56 | +1175 | +58.7 |
| WHO HITS BACK | 18 | 18 | 18 | 0.50 | +1062 | +59.0 |
| MARCH ODDS | 15 | 15 | 15 | 0.42 | +161 | +10.7 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| MAKE SURE TOGETHER | 34 | 25 | 13 | 0.36 | +2469 | +189.9 |
| MANOEUVRE | 15 | 15 | 13 | 0.36 | +463 | +35.6 |
| THREAT IN THE KILL | 264 | 211 | 13 | 0.36 | +101 | +7.8 |
| WAR ENGINE JOBS | 43 | 43 | 13 | 0.36 | -1448 | -111.4 |
| WEARS DOWN | 100 | 95 | 13 | 0.36 | +433 | +33.3 |
| BIG CHARACTER SAFETY | 12 | 12 | 12 | 0.33 | +2 | +0.2 |
| CASTING BLOCK | 23 | 23 | 12 | 0.33 | +670 | +55.8 |
| WHOLE FIGHT GAIN | 32 | 27 | 12 | 0.33 | +527 | +43.9 |
| STUCK PIVOT | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| FOCUS OVER TURNS | 18 | 18 | 10 | 0.28 | +259 | +25.9 |
| OPENS UP | 18 | 18 | 10 | 0.28 | +499 | +49.9 |
| CHAFF PASSED | 9 | 9 | 9 | 0.25 | -11 | -1.3 |
| MODEL FACING | 9 | 9 | 9 | 0.25 | +2546 | +282.8 |
| HUNT IN PAIRS | 24 | 17 | 8 | 0.22 | +286 | +35.8 |
| PURSUES BIG PREY | 8 | 8 | 8 | 0.22 | -589 | -73.7 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| SURE REACH TOGETHER | 41 | 27 | 8 | 0.22 | +19 | +2.4 |
| THREAT OVER THE TURNS | 207 | 174 | 8 | 0.22 | +26 | +3.3 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| SUPPORT NARROWED | 454 | 454 | 7 | 0.19 | -70 | -10.0 |
| WHOLE FIGHT | 27 | 25 | 7 | 0.19 | +151 | +21.6 |
| BACKUP TARGETS | 52 | 29 | 6 | 0.17 | +42 | +7.1 |
| MISSILES NEXT TURN | 325 | 188 | 6 | 0.17 | +40 | +6.6 |
| RESTRAINS TO SHOOT | 6 | 6 | 6 | 0.17 | +196 | +32.6 |
| HUNT ADVANCE | 11 | 11 | 5 | 0.14 | +170 | +33.9 |
| KEEP FALLS | 5 | 5 | 5 | 0.14 | +199 | +39.8 |
| PIVOT GUARDS FLANK | 5 | 5 | 5 | 0.14 | -30 | -5.9 |
| BLOCKED CHARGE SKIPPED | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| NO RALLY LEFT | 4 | 4 | 4 | 0.11 | +279 | +69.9 |
| OVERRUNS AWAY | 36 | 36 | 4 | 0.11 | +135 | +33.9 |
| PERIAPT WORTH | 4 | 4 | 4 | 0.11 | +423 | +105.9 |
| BEST PRIZE | 3 | 3 | 3 | 0.08 | -60 | -20.2 |
| DEFENSIVE ARMY | 15 | 15 | 3 | 0.08 | -154 | -51.3 |
| ELIXIR WORTH | 3 | 3 | 3 | 0.08 | +197 | +65.8 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.08 | +67 | +22.4 |
| FOCUS FIRE | 3 | 3 | 3 | 0.08 | +46 | +15.3 |
| LOST CHARGE | 187 | 187 | 3 | 0.08 | +68 | +22.5 |
| NEEDED THERE | 4 | 4 | 3 | 0.08 | +0 | +0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 3 | 0.08 | +110 | +36.8 |
| STANDS TO CAST | 3 | 3 | 3 | 0.08 | +13 | +4.3 |
| SURE CHARGE BEATS ADVANCE | 3 | 3 | 3 | 0.08 | -212 | -70.5 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -27 | -13.3 |
| DEFENSIVE FLOOR | 3 | 3 | 2 | 0.06 | +8 | +3.8 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| MOVE SPELL IN RANGE | 4 | 3 | 2 | 0.06 | +6 | +3.2 |
| RAIDS THE BAGGAGE | 2 | 2 | 2 | 0.06 | +255 | +127.4 |
| REDIRECT BY WHAT IT STOPS | 28 | 28 | 2 | 0.06 | +88 | +44.0 |
| STAY WEIGHED | 2 | 2 | 2 | 0.06 | +159 | +79.7 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +6 | +6.3 |
| CARRIES OUT COUNTER | 3 | 3 | 1 | 0.03 | -49 | -49.4 |
| CARRIES OUT SET-UP | 6 | 6 | 1 | 0.03 | -178 | -178.3 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| EDGE GIVE GROUND | 9 | 9 | 1 | 0.03 | +5 | +5.4 |
| JOINT CHARGE PLAN | 11 | 11 | 1 | 0.03 | +75 | +74.8 |
| LONE WIZARD HOLDS BACK | 19 | 19 | 1 | 0.03 | -51 | -51.0 |
| OPENS A LANE | 9 | 3 | 1 | 0.03 | +10 | +10.4 |
| TWO OR MORE ARRIVE | 12 | 10 | 1 | 0.03 | +36 | +35.9 |
| WAR ENGINE CHARGES | 5 | 5 | 1 | 0.03 | +139 | +138.6 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 24 | 24 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 35 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 7 | 7 | 0 | 0.00 | - | - |
| CHEAP HELPER | 8 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 33 | not checked | - | - | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 347 | not checked | - | - | - | - |
| GIVES UP | 9 | 8 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 22 | 19 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 7 | 7 | 0 | 0.00 | - | - |
| HUNT DROPPED | 4 | trace | - | - | - | - |
| HUNT KEPT | 4 | trace | - | - | - | - |
| HUNT RESULT | 14 | trace | - | - | - | - |
| HUNT THE GUNS | 14 | trace | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 29 | not checked | - | - | - | - |
| LONG SHOT | 35 | 35 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 29 | 29 | 0 | 0.00 | - | - |
| MISSILES IN THE PLAN | 15 | 3 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 17 | 17 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 13 | trace | - | - | - | - |
| MOVE SPELL SPOT | 10 | not checked | - | - | - | - |
| NOT NEEDED | 25 | 25 | 0 | 0.00 | - | - |
| NOT TURNED | 348 | 348 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 38 | not checked | - | - | - | - |
| PLAN RESULT | 2695 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 15 | 15 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 11 | 11 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 18 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 15 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOT OPTIONS | 908 | 908 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 23 | not checked | - | - | - | - |
| SPELL WORTH | 113 | not checked | - | - | - | - |
| STABLE ROLE | 814 | 809 | 0 | 0.00 | - | - |
| STOPS | 6 | 6 | 0 | 0.00 | - | - |
| TURN WORTH | 41 | 40 | 0 | 0.00 | - | - |

### Off best figure: tk-h2h-opp-949ddcd-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.39 | 13.06 | 52.4 |
| CHARGE NOW FIRST | rule | 0.64 | 0.92 | 93.9 |
| FALLBACK | gate | 0.69 | 0.61 | 41.0 |
| TURN GATE | gate | 0.28 | 0.42 | 24.8 |
| SUPPORT REQUEST | gate | 0.17 | 0.22 | 125.3 |
| LONE CHARACTER SAFE SPOT | gate | 0.14 | 0.22 | 32.2 |
| WAR ENGINE JOBS | rule | 0.25 | 0.11 | 111.4 |
| AFTERMATH BAND | gate | 0.14 | 0.17 | 2.5 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.22 | 0.03 | 82.4 |
| CHARGE NOW WEIGHED | rule | 0.11 | 0.14 | 42.4 |
| PURSUES BIG PREY | rule | 0.06 | 0.17 | 73.7 |
| SUPPORT NARROWED | rule | 0.11 | 0.08 | 10.0 |
| FIGHT ORDER BAND | gate | 0.08 | 0.08 | 2.2 |
| PATHS CROSS | rule | 0.17 | - | 62.1 |
| BIG CHARACTER SAFETY | rule | 0.11 | 0.03 | 10.0 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.03 | 5.9 |
| CANNON PLANNED TARGET | rule | 0.11 | - | 44.5 |
| MARCH ODDS | rule | - | 0.11 | 10.9 |
| BEST PRIZE | rule | 0.06 | 0.03 | 20.2 |
| DEFENSIVE ARMY | rule | 0.08 | - | 51.3 |
| SURE CHARGE BEATS ADVANCE | rule | 0.06 | 0.03 | 70.5 |
| THROUGH LINE OF FIRE | rule | 0.08 | - | 24.1 |
| CHAFF PASSED | rule | 0.03 | 0.03 | 5.5 |
| FACES THE THREAT | rule | 0.06 | - | 11.5 |
| REDIRECT WEIGHED | rule | 0.06 | - | 22.7 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.03 | 8.2 |
| BLOCKED WHEEL | rule | 0.03 | - | 2.9 |
| CARRIES OUT COUNTER | rule | 0.03 | - | 49.4 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 178.3 |
| CATCH ODDS | rule | - | 0.03 | 26.4 |
| FALLBACK BY WORTH | rule | 0.03 | - | 35.1 |
| FOLLOW UP WEIGHED | rule | 0.03 | - | 4.8 |
| LONE WIZARD HOLDS BACK | rule | - | 0.03 | 51.0 |
| SAFER THAN THE JOB | rule | 0.03 | - | 10.3 |
| STANDS TO CAST | rule | 0.03 | - | 10.0 |

### Plans: tk-h2h-opp-949ddcd-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.8 | 19% | 505 | 274 | 54% |
| Mine | charge | 3.4 | 61% | 333 | 317 | 95% |
| Mine | close in | 3.4 | 22% | 243 | 72 | 30% |
| Mine | hold | 5.1 | 48% | 321 | 0 | 0% |
| Mine | join | 0.7 | 96% | 21 | 0 | 0% |
| Mine | shoot | 9.0 | 59% | 316 | 685 | 217% |
| Mine | support | 3.7 | 84% | 23 | 0 | 0% |
| Opponent | advance | 12.7 | 13% | 444 | 275 | 62% |
| Opponent | charge | 5.0 | 59% | 533 | 447 | 84% |
| Opponent | close in | 5.4 | 29% | 503 | 177 | 35% |
| Opponent | hold | 4.0 | 48% | 283 | 0 | 0% |
| Opponent | join | 1.2 | 91% | 53 | 0 | 0% |
| Opponent | shoot | 4.7 | 69% | 269 | 350 | 130% |
| Opponent | support | 4.8 | 85% | 42 | 0 | 0% |

### Packages: hunt the guns, tk-h2h-opp-949ddcd-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 100% | 0% | 0% | - | 206 | 0 | 0% | 13 |
| Opponent | 0.4 | 13 | 0 | 15% | 23% | 8% | 2.3 | 396 | 71 | 23% | 98 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 48 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 124 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.2 | 1 | 0 | 100% | 0% | 0% | - | 206 | 0 | 0% | 83 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 88 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.7 | 2 | 0 | 50% | 50% | 0% | 2.0 | 135 | 70 | 50% | 0 |
| Skaven | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 463 | 0 | 0% | 69 |
| Tomb Kings of Khemri | 0.3 | 2 | 0 | 0% | 50% | 0% | 3.0 | 344 | 128 | 50% | 65 |
| Vampire Counts | 0.2 | 2 | 0 | 0% | 0% | 50% | - | 399 | 47 | 0% | 27 |
| Warriors of Chaos | 0.5 | 4 | 0 | 0% | 0% | 0% | - | 539 | 0 | 0% | 87 |
| Wood Elf Realms | 0.3 | 2 | 0 | 50% | 50% | 0% | 2.0 | 385 | 216 | 50% | 124 |

### Battle groups: tk-h2h-opp-949ddcd-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 8.9 | 28% | 56% | 7% | 33% | 38% | 15% | 7% | 39% | 0% |
| Mine | REDIRECT COUNTER | 2.2 | 37% | 73% | 7% | 0% | 32% | 4% | 4% | 54% | 7% |
| Opponent | COUNTER-CHARGE COVER | 6.6 | 20% | 62% | 28% | 38% | 38% | 6% | 9% | 47% | 0% |
| Opponent | REDIRECT COUNTER | 4.0 | 19% | 78% | 19% | 0% | 18% | 0% | 9% | 73% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: tk-h2h-opp-949ddcd-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 44 | 67% | 3.0 | 0 (1) | 0 (2) | - | - | 0 (3) |
| Mine | Chaff | 36 | 24 (36) | 11 | 13 | 46 | 44% | 2.1 | 16 (15) | 5 (10) | 49 (11) | 20 (22) | 31 (14) |
| Mine | Character | 123 | 56 (123) | 56 | 0 | 36 | 15% | 2.5 | 63 (37) | 63 (59) | 33 (10) | 68 (62) | 53 (44) |
| Mine | Clean-up | 26 | 83 (26) | 40 | 43 | 27 | 46% | 3.0 | 98 (10) | 83 (12) | 0 (4) | 104 (13) | 65 (13) |
| Mine | Fast | 4 | 18 (4) | 18 | 0 | 47 | 0% | 1.5 | 33 (1) | 0 (2) | 0 (1) | 18 (4) | - |
| Mine | Fast Hammer | 40 | 23 (40) | 10 | 13 | 57 | 30% | 2.5 | 33 (18) | 14 (11) | 13 (11) | 30 (29) | 7 (11) |
| Mine | Fragile | 5 | 14 (5) | 14 | 0 | 60 | 0% | 1.2 | - | 17 (4) | 0 (1) | 69 (1) | 0 (4) |
| Mine | Hammer | 56 | 49 (56) | 41 | 9 | 40 | 9% | 2.6 | 26 (11) | 60 (37) | 29 (8) | 50 (34) | 49 (22) |
| Mine | Holder | 26 | 77 (26) | 3 | 74 | 25 | 46% | 3.1 | 57 (8) | 81 (11) | 110 (6) | 104 (12) | 56 (13) |
| Mine | Shooter | 45 | 115 (45) | 53 | 63 | 49 | 4% | 1.8 | 11 (5) | 143 (33) | 95 (7) | 134 (23) | 98 (22) |
| Mine | Support | 5 | 24 (5) | 24 | 0 | 42 | 20% | 2.8 | - | 42 (2) | - | 42 (2) | - |
| Mine | War machine | 56 | 53 (56) | 53 | 0 | 42 | 4% | 1.3 | 87 (14) | 45 (37) | 23 (5) | 51 (11) | 54 (45) |
| Mine | Wizard | 23 | 18 (23) | 18 | 0 | 47 | 13% | 2.4 | 63 (5) | 3 (7) | 0 (2) | 95 (2) | 7 (12) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Chaff | 68 | 73 (68) | 24 | 50 | 52 | 38% | 2.6 | 112 (30) | 32 (16) | 55 (22) | 91 (50) | 19 (18) |
| Opponent | Character | 113 | 64 (113) | 64 | 0 | 40 | 21% | 2.5 | 76 (36) | 62 (58) | 70 (5) | 65 (66) | 73 (33) |
| Opponent | Clean-up | 18 | 33 (18) | 28 | 5 | 48 | 33% | 3.0 | 14 (5) | 36 (10) | 56 (3) | 47 (11) | 12 (7) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 53 | 46 (53) | 23 | 24 | 53 | 36% | 2.6 | 40 (20) | 50 (18) | 52 (15) | 48 (37) | 43 (16) |
| Opponent | Fragile | 10 | 35 (10) | 35 | 0 | 73 | 50% | 1.8 | 75 (3) | 0 (2) | 31 (5) | 24 (6) | 57 (4) |
| Opponent | Hammer | 63 | 34 (63) | 22 | 12 | 49 | 24% | 2.8 | 34 (16) | 30 (40) | 78 (7) | 29 (39) | 46 (24) |
| Opponent | Holder | 40 | 67 (40) | 4 | 62 | 25 | 40% | 3.3 | 44 (8) | 90 (20) | 34 (12) | 97 (23) | 26 (17) |
| Opponent | Shooter | 32 | 63 (32) | 18 | 45 | 53 | 0% | 1.4 | 78 (8) | 61 (18) | 51 (6) | 46 (17) | 86 (15) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (2) | - | - | - | 0 (2) |
| Opponent | War machine | 13 | 32 (13) | 32 | 0 | 61 | 23% | 1.1 | 12 (5) | 10 (5) | 112 (3) | 69 (3) | 21 (10) |
| Opponent | Wizard | 24 | 6 (24) | 6 | 0 | 37 | 8% | 2.2 | 3 (11) | 21 (6) | 0 (3) | 8 (11) | 5 (9) |

### Charged fights: tk-h2h-opp-949ddcd-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 367 | 54 | 1.2 | 1.2 | 45 | 17 | +28 | 0 of 6 | 4 of 6 | +77 | +18 |
| Mine | Chaos Dwarfs | 3 | 92 | 748 | 3.3 | 1.2 | 224 | 0 | +224 | 5 of 10 | 9 of 10 | +504 | +155 |
| Mine | Dwarfen Mountain Holds | 4 | 609 | 111 | 2.0 | 1.4 | 56 | 8 | +48 | 2 of 8 | 5 of 8 | +114 | +8 |
| Mine | Empire of Man | 5 | 267 | 124 | 1.0 | 1.4 | 124 | 0 | +124 | 1 of 5 | 5 of 5 | +160 | +100 |
| Mine | Grand Cathay | 4 | 734 | 282 | 3.8 | 1.2 | 75 | 104 | -28 | 7 of 15 | 11 of 15 | -42 | -25 |
| Mine | High Elf Realms | 4 | 164 | 660 | 3.5 | 1.2 | 189 | 14 | +174 | 6 of 14 | 8 of 14 | +288 | +143 |
| Mine | Kingdom of Bretonnia | 1 | 218 | 153 | 4.0 | 1.0 | 38 | 153 | -115 | 3 of 4 | 2 of 4 | - | -115 |
| Mine | Lizardmen | 1 | 70 | 540 | 2.0 | 1.0 | 270 | 158 | +112 | 2 of 2 | 2 of 2 | - | +112 |
| Mine | Ogre Kingdoms | 1 | 70 | 138 | 2.0 | 1.0 | 69 | 0 | +69 | 0 of 2 | 2 of 2 | - | +69 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 666 | 5.0 | 1.2 | 133 | 208 | -75 | 2 of 5 | 3 of 5 | +265 | -160 |
| Mine | Skaven | 2 | 22 | 38 | 2.0 | 1.2 | 19 | 0 | +19 | 3 of 4 | 3 of 4 | +0 | +25 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 880 | 3.0 | 1.2 | 293 | 0 | +293 | 2 of 6 | 5 of 6 | +938 | +164 |
| Mine | Vampire Counts | 2 | 0 | 85 | 6.5 | 1.1 | 13 | 62 | -49 | 5 of 13 | 8 of 13 | +0 | -53 |
| Mine | Warriors of Chaos | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| **Mine** | all armies | 36 | 274 | 301 | 2.6 | 1.2 | 114 | 49 | +65 | 38 of 95 | 68 of 95 | +205 | +32 |
| Opponent | Beastmen Brayherds | 1 | 0 | 130 | 2.0 | 1.5 | 65 | 111 | -46 | 2 of 2 | 1 of 2 | -137 | +45 |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 112 | 2.0 | 1.5 | 56 | 92 | -36 | 0 of 2 | 2 of 2 | +0 | -73 |
| Opponent | Empire of Man | 1 | 65 | 427 | 2.0 | 1.0 | 214 | 0 | +214 | 1 of 2 | 2 of 2 | - | +214 |
| Opponent | Grand Cathay | 1 | 340 | 235 | 4.0 | 1.0 | 59 | 0 | +59 | 1 of 4 | 4 of 4 | - | +59 |
| Opponent | High Elf Realms | 2 | 136 | 465 | 2.5 | 1.0 | 186 | 0 | +186 | 2 of 5 | 4 of 5 | - | +186 |
| Opponent | Lizardmen | 1 | 380 | 376 | 4.0 | 1.0 | 94 | 71 | +23 | 2 of 4 | 3 of 4 | - | +23 |
| Opponent | Ogre Kingdoms | 2 | 120 | 58 | 3.5 | 1.1 | 16 | 5 | +12 | 1 of 7 | 3 of 7 | +85 | -1 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 342 | 4.5 | 1.1 | 76 | 179 | -103 | 4 of 9 | 5 of 9 | -435 | -61 |
| Opponent | Skaven | 2 | 119 | 0 | 2.0 | 1.0 | 0 | 211 | -211 | 3 of 4 | 1 of 4 | - | -211 |
| Opponent | Tomb Kings of Khemri | 4 | 80 | 812 | 4.5 | 1.1 | 180 | 11 | +170 | 9 of 18 | 12 of 18 | +177 | +169 |
| Opponent | Vampire Counts | 6 | 23 | 700 | 4.8 | 1.3 | 145 | 35 | +110 | 12 of 29 | 21 of 29 | +107 | +111 |
| Opponent | Warriors of Chaos | 7 | 15 | 399 | 2.4 | 1.1 | 164 | 0 | +164 | 4 of 17 | 8 of 17 | +350 | +140 |
| Opponent | Wood Elf Realms | 6 | 87 | 510 | 4.3 | 1.1 | 118 | 31 | +87 | 12 of 26 | 13 of 26 | +53 | +91 |
| **Opponent** | all armies | 36 | 73 | 453 | 3.6 | 1.2 | 126 | 40 | +86 | 53 of 129 | 79 of 129 | +82 | +87 |

### Effective charges: tk-h2h-opp-949ddcd-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 0 | 0 | 1 (net +140) | 0 | 0 | 3 (net +8) | 2 | 25% (1 of 4) |
| Mine | Chaos Dwarfs | 10 | 1 (net +912) | 0 | 0 | 2 (net +0) | 0 | 5 (net +229) | 2 | 0% (0 of 8) |
| Mine | Dwarfen Mountain Holds | 8 | 1 (net +0) | 0 | 0 | 2 (net -30) | 0 | 5 (net +89) | 0 | 0% (0 of 8) |
| Mine | Empire of Man | 5 | 1 (net +0) | 0 | 0 | 1 (net +299) | 1 (net +83) | 2 (net +118) | 0 | 0% (0 of 5) |
| Mine | Grand Cathay | 15 | 1 (net -328) | 0 | 1 (net +116) | 5 (net +83) | 2 (net +46) | 6 (net -120) | 0 | 7% (1 of 15) |
| Mine | High Elf Realms | 14 | 4 (net +356) | 0 | 4 (net +216) | 0 | 0 | 4 (net +31) | 2 | 33% (4 of 12) |
| Mine | Kingdom of Bretonnia | 4 | 1 (net -277) | 0 | 1 (net -336) | 1 (net +0) | 1 (net +153) | 0 | 0 | 25% (1 of 4) |
| Mine | Lizardmen | 2 | 0 | 1 (net +365) | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Mine | Ogre Kingdoms | 2 | 0 | 0 | 0 | 1 (net +66) | 1 (net +72) | 0 | 0 | 0% (0 of 2) |
| Mine | Orc & Goblin Tribes | 5 | 0 | 0 | 1 (net +265) | 0 | 0 | 1 (net +275) | 3 | 50% (1 of 2) |
| Mine | Skaven | 4 | 0 | 0 | 0 | 1 (net +0) | 0 | 3 (net +25) | 0 | 0% (0 of 4) |
| Mine | Tomb Kings of Khemri | 6 | 0 | 0 | 4 (net +410) | 1 (net +0) | 1 (net +120) | 0 | 0 | 67% (4 of 6) |
| Mine | Vampire Counts | 13 | 7 (net -89) | 0 | 1 (net +0) | 2 (net +0) | 0 | 3 (net -5) | 0 | 8% (1 of 13) |
| Mine | Warriors of Chaos | 1 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0% (0 of 1) |
| Opponent | Beastmen Brayherds | 2 | 1 (net -137) | 0 | 0 | 0 | 0 | 1 (net +45) | 0 | 0% (0 of 2) |
| Opponent | Dwarfen Mountain Holds | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net -36) | 0 | 0% (0 of 2) |
| Opponent | Empire of Man | 2 | 0 | 0 | 0 | 1 (net +427) | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Grand Cathay | 4 | 0 | 0 | 1 (net +0) | 0 | 0 | 2 (net +58) | 1 | 33% (1 of 3) |
| Opponent | High Elf Realms | 5 | 1 (net +296) | 1 (net +509) | 0 | 0 | 0 | 3 (net +42) | 0 | 0% (0 of 5) |
| Opponent | Lizardmen | 4 | 1 (net -283) | 0 | 0 | 0 | 0 | 1 (net +110) | 2 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 7 | 2 (net -17) | 0 | 0 | 2 (net +42) | 0 | 3 (net +10) | 0 | 0% (0 of 7) |
| Opponent | Orc & Goblin Tribes | 9 | 3 (net -98) | 0 | 0 | 1 (net +230) | 0 | 0 | 5 | 0% (0 of 4) |
| Opponent | Skaven | 4 | 0 | 1 (net -732) | 0 | 1 (net -112) | 0 | 2 (net +0) | 0 | 0% (0 of 4) |
| Opponent | Tomb Kings of Khemri | 18 | 1 (net +776) | 2 (net +0) | 2 (net +0) | 7 (net +151) | 0 | 4 (net +151) | 2 | 12% (2 of 16) |
| Opponent | Vampire Counts | 29 | 6 (net -52) | 0 | 7 (net +149) | 3 (net +63) | 1 (net +126) | 12 (net +178) | 0 | 24% (7 of 29) |
| Opponent | Warriors of Chaos | 17 | 3 (net +271) | 0 | 3 (net +42) | 2 (net +308) | 1 (net +104) | 6 (net +144) | 2 | 20% (3 of 15) |
| Opponent | Wood Elf Realms | 26 | 4 (net +75) | 2 (net +0) | 4 (net +59) | 3 (net +20) | 2 (net -22) | 7 (net +218) | 4 | 18% (4 of 22) |

### Charged fights, damage counted: tk-h2h-opp-949ddcd-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 16 | 301 | 278 | +69 | 167 | 93 | +74 | +24.4 |
| Mine | 50-54% | 1 | 405 | 440 | +365 | 540 | 175 | +365 | +90.1 |
| Mine | Effective (55-75%) | 13 | 373 | 221 | +207 | 251 | 96 | +154 | +41.4 |
| Mine | 76-89% | 16 | 267 | 271 | +45 | 77 | 39 | +38 | +14.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 32 | 239 | 192 | +50 | 112 | 48 | +65 | +27.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 346 | 84 | +74 | 74 | 9 | +65 | +18.9 |
| Mine | No odds | 10 | 328 | 140 | -84 | 62 | 139 | -77 | -23.5 |
| Mine | All fights | 95 | 291 | 213 | +65 | 131 | 69 | +62 | +21.4 |
| Opponent | Long shot (under 50%) | 22 | 208 | 264 | +51 | 150 | 137 | +12 | +6.0 |
| Opponent | 50-54% | 6 | 290 | 398 | -37 | 98 | 221 | -122 | -42.2 |
| Opponent | Effective (55-75%) | 17 | 249 | 211 | +83 | 105 | 35 | +70 | +28.1 |
| Opponent | 76-89% | 20 | 294 | 208 | +128 | 149 | 19 | +131 | +44.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 43 | 247 | 171 | +127 | 179 | 37 | +141 | +57.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 370 | 94 | +46 | 89 | 32 | +57 | +15.4 |
| Opponent | No odds | 17 | 168 | 190 | +35 | 110 | 83 | +27 | +15.8 |
| Opponent | All fights | 129 | 243 | 208 | +86 | 144 | 65 | +78 | +32.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| tk-h2h-opp-949ddcd-p1 | move | 444 | 102 (23%) | 73 (16%) | 50 (11%) | 292 (66%) |
| tk-h2h-opp-949ddcd-p1 | objective | 318 | 50 (16%) | 32 (10%) | 38 (12%) | 230 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

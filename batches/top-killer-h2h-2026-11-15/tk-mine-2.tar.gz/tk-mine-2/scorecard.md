# Doctrine scorecard: tk-h2h-mine-949ddcd-p2

### Scorecard: tk-h2h-mine-949ddcd-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 3 | - | 0 | 3 | 0 | 0 | 0 | 65 |
| L0106 | 4 | 1 | Opponent | no | 0 | 2 | 0 | 3 | 1 | 0 | 0 | 981 |
| L0122 | 2 | 1 | Mine | - | - | 6 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 1 | 0 | 1 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | - | 1 | 2 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 615 |
| L0222 | 6 | 1 | Mine | no | 9 | 3 | 4 | 1 | 2 | 0 | 0 | 170 |
| L0222 | 6 | 1 | Opponent | no | 12 | 2 | 4 | 0 | 0 | 0 | 0 | 127 |
| L0307 | 1 | 1 | Mine | yes | 4 | 2 | 4 | 0 | 0 | 0 | 0 | 760 |
| L0307 | 1 | 1 | Opponent | yes | 3 | 3 | 2 | 2 | 1 | 0 | 0 | 375 |
| L0323 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 590 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 7 | 1 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 3 | 2 | 2 | 3 | 1 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 6 | 3 | 0 | 1 | 0 | 0 | 0 | 913 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | no | - | 2 | 2 | 3 | 0 | 0 | 0 | 50 |
| L0512 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 1257 |
| L0512 | 2 | 1 | Opponent | - | - | - | 1 | 1 | 0 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 10 | 5 | 2 | 1 | 0 | 0 | 0 | 475 |
| L0528 | 6 | 1 | Opponent | no | 3 | 5 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 7 | 2 | 1 | 0 | 0 | 0 | 0 | 615 |
| L0616 | 4 | 1 | Opponent | no | 2 | 2 | 5 | 1 | 0 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 828 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 0 | 5 | 2 | 0 | 0 | 0 |
| L0721 | 1 | 1 | Mine | yes | 3 | 2 | 4 | 0 | 0 | 0 | 0 | 420 |
| L0721 | 1 | 1 | Opponent | yes | 5 | - | 0 | 2 | 0 | 0 | 0 | 355 |
| L0810 | 6 | 1 | Mine | no | 0 | 5 | 1 | 2 | 0 | 0 | 0 | 605 |
| L0810 | 6 | 1 | Opponent | no | 19 | 2 | 2 | 0 | 1 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | 4 | 1 | 1 | 0 | 0 | 0 | 881 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 1 | 3 | 2 | 0 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 13 | 2 | 6 | 0 | 0 | 0 | 0 | 185 |
| L0934 | 4 | 1 | Mine | no | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 736 |
| L0934 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 4 | 0 | 0 | 0 | 160 |
| L1026 | 6 | 1 | Mine | no | 0 | 2 | 3 | 1 | 1 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 5 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 5 | 1 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 4 | 3 | 3 | 0 | 0 | 0 | 185 |
| L1135 | 1 | 1 | Mine | yes | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1135 | 1 | 1 | Opponent | yes | 1 | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 1 | 6 | 2 | 1 | 0 | 0 | 0 | 524 |
| L1228 | 4 | 1 | Opponent | no | 3 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 25% | 3.2 | 3.0 | 2.0 | 1.2 | 0.2 | 0.0 | 0.0 | 444.6 |
| **Average** | | | Opponent | 31% | 5.5 | 2.4 | 2.3 | 1.7 | 0.3 | 0.0 | 0.0 | 228.9 |

### KPIs: tk-h2h-mine-949ddcd-p2

Rules off - Opponent only: STAY WORTH, BEST MOVE FOR SHOOTERS, THREAT IN THE KILL, FOCUS OVER TURNS, MISSILES IN THE PLAN, FACE THE CAST, WIZARD FRONT RANK, THREAT OVER THE TURNS, THREAT TO WORN DOWN.

Morten 2026-11-10; 21 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 39% (39 of 101) | 21% (21 of 100) | 30% (60 of 201) |
| Winner chose to follow up after the loser gave ground |  | 88% (45 of 51); on the table 92% | 100% (33 of 33); on the table 100% | 93% (78 of 84); on the table 95% |
| Winner chose to pursue after the loser fell back in good order |  | 70% (7 of 10); on the table 70% | 100% (11 of 11); on the table 100% | 86% (18 of 21); on the table 86% |
| Winner chose to pursue after the loser fled |  | 86% (12 of 14); on the table 86% | 67% (10 of 15); on the table 67% | 76% (22 of 29); on the table 76% |
| Winner chose to follow up or pursue (all three) |  | 85% (64 of 75); on the table 88% | 92% (54 of 59); on the table 92% | 88% (118 of 134); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 38% (100 of 264) | 26% (30 of 114) | 34% (130 of 378) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 54% (100 of 184) | 35% (30 of 85) | 48% (130 of 269) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 34% (35 of 102) | 18% (13 of 72) | 28% (48 of 174) |
|     round 1 |  | 18% (3 of 17) | 0% (0 of 12) | 10% (3 of 29) |
|     rounds 2+ |  | 38% (32 of 85) | 22% (13 of 60) | 31% (45 of 145) |
|   other wizards | 50%+ | 40% (65 of 162) | 40% (17 of 42) | 40% (82 of 204) |
|     round 1 |  | 44% (12 of 27) | 71% (5 of 7) | 50% (17 of 34) |
|     rounds 2+ |  | 39% (53 of 135) | 34% (12 of 35) | 38% (65 of 170) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 50% (4 of 8) | 50% (11 of 22) | 50% (15 of 30) |
| Points that never fought | lower | 46% (19117 of 41588) | 50% (21088 of 41992) | 48% (40205 of 83580) |
|   infantry points that never fought | lower | 50% (5301 of 10621) | 72% (5788 of 7998) | 60% (11089 of 18619) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 67% (118 of 177) | 54% (89 of 164) | 61% (207 of 341) |
| Bound items with a magic missile used (at least once a game) |  | 87% (13 of 15); 1.9 uses a game | 89% (8 of 9); 1.0 uses a game | 88% (21 of 24); 1.5 uses a game |
| Bound items with another spell used |  | 100% (4 of 4); 0.3 uses a game | 50% (1 of 2); 0.1 uses a game | 83% (5 of 6); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 53% (8 of 15); 0.4 uses a game | 33% (2 of 6); 0.1 uses a game | 48% (10 of 21); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 62% (21255 of 34411) | 46% (16398 of 35898) | 54% (37653 of 70309) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.0 (26%) | 1.1 (29%) | 3.2 (27%) |
| MARCHED: its unit marched | 1.3 (17%) | 0.7 (17%) | 2.0 (17%) |
| CHARGED: its unit charged | 0.3 (4%) | 0.2 (5%) | 0.5 (4%) |
| IN COMBAT: engaged in combat | 2.0 (25%) | 0.9 (23%) | 2.9 (24%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (5%) | 0.2 (2%) |
| FLEEING: fleeing | 0.4 (5%) | 0.0 (1%) | 0.5 (4%) |
| GONE: slain | 1.0 (12%) | 0.3 (7%) | 1.2 (10%) |
| OFF THE TABLE: off the table or not arrived | 0.5 (6%) | 0.1 (4%) | 0.6 (5%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.0 (1%) | 0.2 (2%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.4 (10%) | 0.4 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 2.0 | 1.2 | 6.2 | 0.4 | 1.4 |
| not cast | 2.2 | 3.2 | 3.3 | 11.8 | 2.1 | 17.4 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.0 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.2 (39%) | 0.3 (10%) | 3.2 (27%) | 0.2 (11%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (17%) | 0.3 (16%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (4%) | 0.1 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (9%) | 0.2 (7%) | 0.7 (20%) | 2.9 (24%) | 0.5 (24%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (13%) | 0.6 (18%) | 0.3 (9%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (2%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (2%) | 0.2 (6%) | 0.0 (0%) | 0.5 (4%) | 0.2 (9%) | 0.6 (3%) |
| GONE: slain | 0.1 (4%) | 0.2 (6%) | 0.6 (17%) | 1.2 (10%) | 0.4 (20%) | 2.1 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.2 (6%) | 0.0 (1%) | 0.6 (5%) | 0.0 (0%) | 0.1 (1%) |
| STUPIDITY: Stupidity | 0.0 (2%) | 0.1 (3%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.2 (9%) | 0.3 (9%) | 0.0 (0%) | 0.2 (2%) | 0.3 (13%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (3%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.4 (62%) | 0.2 (6%) | 1.3 (40%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.5 (78%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.8 a game | 0.6 a game | 0.7 a game |
| stood (cast and not dispelled) | 75% (12 of 16) | 69% (9 of 13) | 72% (21 of 29) |
| the unit moved after it | 75% (9 of 12) | 56% (5 of 9) | 67% (14 of 21) |
| it charged on its next turn | 0% (0 of 12) | 11% (1 of 9) | 5% (1 of 21) |
| the enemy charged it first | 0% (0 of 12) | 11% (1 of 9) | 5% (1 of 21) |
| it fought by the end of its next turn | 0% (0 of 12) | 0% (0 of 9) | 0% (0 of 21) |
| it moved out of a charge the enemy had planned (not charged first) | 25% (3 of 12) | 0% (0 of 9) | 14% (3 of 21) |
| none of these (no charge, no fight, no charge escaped) | 75% (9 of 12) | 78% (7 of 9) | 76% (16 of 21) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 69% (390 of 568) | 57% (320 of 563) | 63% (710 of 1131) |
|   cavalry | 44% (14 of 32) | 65% (53 of 82) | 59% (67 of 114) |
|   character | 83% (45 of 54) | 35% (20 of 57) | 59% (65 of 111) |
|   chariot | 42% (32 of 76) | 52% (17 of 33) | 45% (49 of 109) |
|   infantry | 61% (88 of 144) | 54% (122 of 224) | 57% (210 of 368) |
|   monster | 55% (11 of 20) | 58% (19 of 33) | 57% (30 of 53) |
|   war machine | 83% (200 of 242) | 66% (89 of 134) | 77% (289 of 376) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.1 (25%) | 3.0 (26%) | 5.2 (26%) |
| CHARGED: it charged | 1.3 (15%) | 2.0 (17%) | 3.2 (16%) |
| FLEEING: it fled or was fleeing | 0.0 (1%) | 0.1 (1%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 1.3 (16%) | 0.4 (4%) | 1.8 (9%) |
| MOVED: a war machine that moved | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 0.7 (8%) | 2.5 (21%) | 3.2 (16%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (5%) | 0.8 (7%) | 1.2 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.6 (19%) | 1.4 (12%) | 3.0 (15%) |
| SHELTERED: the target was sheltered | 0.3 (4%) | 0.6 (5%) | 0.9 (5%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| OTHER BAR | 0.4 (5%) | 0.7 (6%) | 1.1 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.0 | 0.9 | 86% | 4.0 pts | 20 pts |
| character | 3.1 | 1.7 | 62% | 13.6 pts | 42 pts |
| chariot | 2.3 | 0.7 | 78% | 9.2 pts | 22 pts |
| infantry | 14.4 | 5.5 | 73% | 7.5 pts | 108 pts |
| monster | 2.0 | 1.0 | 67% | 9.9 pts | 20 pts |
| war machine | 13.8 | 12.0 | 61% | 23.5 pts | 323 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 5.5 | 4.6 |
| Charges that made contact a game | 2.1 | 3.6 | 2.9 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.86 declared, 0.50 contact (14 units) | 1.22 declared, 1.00 contact (9 units) | 1.00 declared, 0.70 contact (23 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.25 declared, 0.75 contact (4 units) | 1.25 declared, 0.75 contact (4 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.50 declared, 0.29 contact (131 units) | 0.59 declared, 0.37 contact (169 units) | 0.55 declared, 0.34 contact (300 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 53% (16 of 30) | 67% (4 of 6) | 29% (2 of 7) | 51% (22 of 43) |
| Character in a unit | 100% (23 of 23) | 71% (5 of 7) | 100% (1 of 1) | 94% (29 of 31) |
| Character on its own | 82% (18 of 22) | 45% (13 of 29) | 21% (6 of 28) | 47% (37 of 79) |
| Chariot | 80% (8 of 10) | 85% (11 of 13) | - | 83% (19 of 23) |
| Infantry | 50% (25 of 50) | 50% (11 of 22) | 0% (0 of 3) | 48% (36 of 75) |
| Monster | 47% (7 of 15) | 67% (2 of 3) | - | 50% (9 of 18) |
| Monstrous | 80% (4 of 5) | 50% (4 of 8) | - | 62% (8 of 13) |
| War Machines | 81% (46 of 57) | 50% (1 of 2) | - | 80% (47 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (10 of 10); on the table 100% | 34% (35 of 102) | 47% | 55% (12 of 22) | 83% (5 of 6); 3.5 uses a game | 100% (2 of 2); 0.8 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 100% (24 of 24); on the table 100% | 56% (20 of 36) | 55% | 66% (21 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 6 | 73% (19 of 26); on the table 77% | - | 47% | 78% (42 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 67% (8 of 12); on the table 75% | 31% (15 of 48) | 50% | 66% (50 of 76) | 0.0 uses a game | 100% (2 of 2); 0.7 uses a game | 50% (2 of 4); 0.3 uses a game |
| Grand Cathay | 6 | 89% (17 of 19); on the table 89% | 32% (44 of 138) | 53% | 52% (28 of 54) | 93% (13 of 14); 6.3 uses a game | 50% (1 of 2); 0.2 uses a game | 0% (0 of 6); 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 86% (6 of 7); on the table 86% | - | 43% | 17% (1 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Ogre Kingdoms | 2 | 100% (6 of 6); on the table 100% | 0% (0 of 12) | 49% | 86% (12 of 14) | 100% (2 of 2); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Skaven | 1 | 75% (3 of 4); on the table 75% | 33% (2 of 6) | 29% | 44% (4 of 9) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 3 | 100% (5 of 5); on the table 100% | - | 35% | 13% (2 of 15) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 3 | 89% (8 of 9); on the table 89% | 22% (4 of 18) | 38% | 59% (10 of 17) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 3 | 100% (6 of 6); on the table 100% | 75% (9 of 12) | 51% | 59% (13 of 22) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 2 | 100% (6 of 6); on the table 100% | 17% (1 of 6) | 57% | 60% (12 of 20) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (tk-h2h-mine-949ddcd-p2, 21 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 40% (19) | 54% (14) | 45% (33) |
| ...free all their last turn and able to turn (per game) | 0.48 | 0.33 | 0.81 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.24 | 0.19 | 0.43 |
| ...with the charger already in that arc before they moved (per game) | 0.29 | 0.29 | 0.57 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.71 | 1.48 | 3.19 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.62 | 1.05 | 1.67 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 4.71 | 4.43 | 9.14 |

### Quality by phase: tk-h2h-mine-949ddcd-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.1 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 34% (24 of 70) | 45% (54 of 121) |
| Strategy | Shoot objectives carried out (shot that target) | 39% (111 of 287) | 52% (85 of 163) |
| Strategy | Close-in objectives charged next turn | 17% (9 of 52) | 21% (27 of 127) |
| Strategy | Support requests answered (helper made contact too) | 33% (3 of 9) | 50% (8 of 16) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 17% (3 of 18) | 33% (1 of 3) |
| Strategy | Joined characters whose unit fought | 46% (13 of 28) | 21% (6 of 28) |
| Strategy | Lone characters that fought | 61% (40 of 66) | 75% (33 of 44) |
| Movement | Charges halted short of contact | 0.2 | 0.4 |
| Movement | Idle units | 1.2 | 1.7 |
| Movement | Points that never moved of their own | 444.6 | 228.9 |
| Movement | Fights charged into per game | 1.9 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 6 of 37, net +82 | 14 of 60, net +77 |
| Movement | Charges with odds: sweet spot (55-75%) | 5 of 37, net +51 | 8 of 60, net +66 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 37, net +55 | 1 of 60, net +165 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 14 of 37, net +49 | 24 of 60, net +162 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.5 | 11.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 54% (109 of 200) | 44% (109 of 246) |
| Shooting | Points destroyed by shooting units | 118.4 | 22.0 |
| Shooting | War machine shots | 9.5 | 4.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 47% (94 of 200) | 63% (56 of 89) |
| Shooting | Points destroyed by war machines | 47.0 | 118.9 |
| Magic | Magic missiles cast | 2.6 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 47% (26 of 55) | 32% (7 of 22) |
| Magic | Wounds caused by magic missiles | 4.3 | 1.2 |
| Magic | Wounds caused by other spells | 1.6 | 1.3 |
| Magic | Points destroyed by magic (all spells) | 44.9 | 48.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.4 / 0.9 / 0.5 / 0.1 | 2.6 / 0.1 / 0.5 / 0.1 |
| Combat | Points destroyed in combat | 238.0 | 434.5 |
| Combat | Points run down | 82.8 | 89.9 |
| Combat | Net points per charged fight, damage counted | +57 | +119 |
| Combat | Net per 100 charger points, damage counted | +26.5 | +38.3 |
| Combat | First round won (charged fights) | 70% | 70% |
| Combat | Net points per charged fight | +59 | +140 |
| Combat | Net points per supported fight / lone fight | -100 / +77 | +354 / +100 |
| Combat | Charged fights on a top-3 enemy unit | 15 of 40 | 33 of 64 |
| Game | Points lost | 846.7 | 596.6 |
| Game | VP from objectives | 506.2 | 763.3 |
| Game | Lone holders (player turns) | 3.2 | 5.5 |

- Mine won / drew / lost: 7 / 1 / 13 of 21 ended games (of 21); mean margin (Mine - Opponent) -490 VP
- The side that went first won 10 of 20 games with a winner
- Points traded per game (both sides' losses): 1443
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: tk-h2h-mine-949ddcd-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +6.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.6 | +0.0 | 0.0 | 41.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.0 | +5.2 | 0.0 | 42.4 | 1.0 | +14.3 | 0.0 | 28.5 |
| BEST FACING | 0.6 | +19.4 | 0.0 | 17.8 | 0.8 | +20.5 | 0.0 | 4.4 |
| BEST FIRST | 4.5 | +230.7 | 137.1 | 105.3 | 4.3 | +198.5 | 130.6 | 70.0 |
| BEST MOVE FOR SHOOTERS | 1.0 | +68.8 | 0.0 | 37.7 | - | - | - | - |
| BEST OVERALL | 0.5 | +41.5 | 0.0 | 15.4 | 0.7 | +45.2 | 0.0 | 30.4 |
| BEST PREY | 0.6 | +29.9 | 26.2 | 17.3 | 0.9 | +44.2 | 6.0 | 8.4 |
| BEST PRIZE | - | - | - | - | 0.1 | -7.6 | 28.3 | 0.0 |
| BIG CHARACTER SAFETY | 0.1 | -1.1 | 0.0 | 27.6 | 0.1 | -0.8 | 0.0 | 20.7 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 14.8 | 0.0 |
| BLOCKED WHEEL | 0.4 | +8.3 | 0.0 | 0.0 | 0.4 | +4.5 | 0.0 | 0.0 |
| BOMBING RUN | 0.0 | +1.6 | 0.0 | 7.1 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 6.0 | - | - | - | - |
| CANNON PLAN MISSED | 1.3 | +0.0 | 193.1 | 44.8 | 0.3 | +0.0 | 60.6 | 0.0 |
| CANNON PLANNED TARGET | 7.1 | +245.7 | 352.3 | 149.5 | 3.5 | +160.9 | 375.3 | 5.0 |
| CANNON SIGHT KEPT | 2.0 | +0.0 | 0.0 | 6.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | - | - | - | - | 0.0 | +0.0 | 0.0 | 15.7 |
| CARRIES OUT SET-UP | - | - | - | - | 0.1 | +0.0 | 37.7 | 0.0 |
| CAST JOB | 1.1 | +21.1 | 3.3 | 8.0 | 0.6 | +16.7 | 98.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.5 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +27.5 | 17.7 | 0.0 | 0.1 | +2.4 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.5 | +0.0 | 0.0 | 10.5 | 0.4 | +0.0 | 0.0 | 33.7 |
| CASTS FROM BEHIND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +2.6 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | - | - | - | - | 0.0 | +4.4 | 0.0 | 0.0 |
| CHAFF PASSED | 0.1 | -2.8 | 0.0 | 19.8 | 0.3 | -0.3 | 6.0 | 0.0 |
| CHARGE NOW FIRST | 3.0 | +0.0 | 145.9 | 50.0 | 3.7 | +0.0 | 397.3 | 150.0 |
| CHARGE NOW WEIGHED | 0.5 | -56.3 | 28.5 | 1.4 | 0.7 | -109.4 | 8.1 | 46.0 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | - | - | - | - | 0.1 | -0.9 | 0.0 | 0.0 |
| CHEAP HELPER | 0.0 | +0.0 | 0.0 | 5.0 | 0.3 | +0.0 | 3.1 | 9.8 |
| COMBAT PIVOT | 0.3 | +0.0 | 19.0 | 39.1 | 0.6 | +0.0 | 85.9 | 24.3 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.5 | +92.9 | 13.0 | 31.9 | 0.5 | +86.7 | 33.6 | 33.7 |
| COUNTER-CHARGE COVER | 10.1 | +804.5 | 0.0 | 234.6 | 6.1 | +611.4 | 0.0 | 147.9 |
| DEFENSIVE ARMY | 0.4 | +0.0 | 57.0 | 0.0 | 0.3 | +0.0 | 27.6 | 0.0 |
| DEFENSIVE FLOOR | 0.0 | +1.2 | 20.5 | 2.6 | - | - | - | - |
| EDGE GIVE GROUND | 0.0 | +1.9 | 0.0 | 0.0 | 0.5 | +6.0 | 40.1 | 1.6 |
| ENGINEER BY LORE | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.7 | +145.5 | 0.0 | 77.3 | 1.5 | +124.6 | 0.0 | 18.6 |
| FALLBACK BY WORTH | 3.4 | +41.1 | 0.0 | 45.3 | 5.9 | +49.6 | 0.0 | 32.9 |
| FIGHT LIFT | 0.1 | +0.1 | 2.9 | 0.0 | 0.0 | +2.2 | 0.0 | 0.0 |
| FIRE AND FLEE | - | - | - | - | 0.1 | +0.8 | 0.0 | 0.0 |
| FLANK NOT WEIGHED | 5.0 | +0.0 | 0.0 | 84.4 | 4.5 | +0.0 | 0.0 | 121.2 |
| FOCUS FIRE | - | - | - | - | 0.0 | +1.7 | 2.6 | 0.0 |
| FOCUS OVER TURNS | 1.2 | +33.1 | 62.0 | 23.2 | - | - | - | - |
| FOLLOW UP WEIGHED | 1.5 | +279.9 | 0.0 | 44.3 | 1.2 | +176.8 | 0.0 | 42.7 |
| FRIENDS SHOTS CHECKED | 0.5 | +45.2 | 0.0 | 0.0 | 0.1 | +2.6 | 0.0 | 9.0 |
| GIVES UP | - | - | - | - | 0.0 | -0.1 | 0.0 | 0.0 |
| GROUND FLIERS | 0.0 | +0.8 | 0.0 | 12.9 | - | - | - | - |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 13.8 | 0.0 |
| HELPER UNSEEN | 0.1 | +0.0 | 0.0 | 2.5 | 0.4 | +0.0 | 14.8 | 6.5 |
| HILL BY ITS CHANCE | 0.5 | -38.8 | 0.0 | 0.0 | 1.0 | -115.6 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.0 | +0.1 | 0.0 | 0.0 | 0.4 | +9.8 | 8.1 | 13.7 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 7.9 | 8.4 |
| HUNT IN PAIRS | 0.8 | +78.3 | 0.0 | 27.9 | 0.7 | +36.2 | 0.0 | 39.1 |
| HUNT KEPT | 0.0 | +0.0 | 0.0 | 0.0 | 0.3 | +3.2 | 24.0 | 0.0 |
| HUNT RESULT | - | - | - | - | 0.4 | +31.3 | 23.6 | 15.3 |
| HUNT THE GUNS | 0.0 | +21.2 | 0.0 | 0.0 | 0.4 | +153.7 | 0.0 | 15.3 |
| INVITES THE FIGHT | 1.1 | +17.3 | 25.7 | 17.6 | 0.8 | +8.1 | 39.3 | 23.8 |
| JOINT CHARGE PLAN | - | - | - | - | 0.0 | +3.5 | 13.8 | 10.3 |
| KEEP FALLS | 0.1 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.0 | +0.3 | 0.0 | 13.0 | - | - | - | - |
| KEEPS ITS TARGET | 0.8 | +24.3 | 45.7 | 48.2 | 2.2 | +67.1 | 226.9 | 91.7 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 1.7 | +68.5 | 87.0 | 45.0 | 2.6 | +105.0 | 203.8 | 35.9 |
| KILLS COUNT NEXT TURN | 3.1 | +122.9 | 66.8 | 105.9 | 7.1 | +267.0 | 180.2 | 141.6 |
| LONE CHARACTER SAFE SPOT | 0.3 | +1.4 | 17.7 | 4.3 | 0.1 | +1.4 | 0.0 | 0.0 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.9 | +58.3 | 0.0 | 0.0 | 0.4 | +36.0 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | -5.1 | 14.1 | 3.1 | 0.8 | +0.8 | 52.1 | 13.5 |
| LOST CHARGE | 3.3 | -58.5 | 63.0 | 102.3 | 2.0 | -55.6 | 99.0 | 45.0 |
| LURE BY WHAT IT DRAWS | 0.0 | -3.1 | 0.0 | 3.1 | - | - | - | - |
| MAKE SURE TOGETHER | 0.3 | +57.6 | 0.0 | 16.2 | 0.6 | +70.9 | 15.9 | 25.7 |
| MANOEUVRE | 0.1 | +0.2 | 0.0 | 8.1 | - | - | - | - |
| MARCH AT ESCAPER | 0.0 | +1.6 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.5 | +15.7 | 0.0 | 0.0 | 0.4 | +22.5 | 0.0 | 0.0 |
| MARCH ODDS | 0.5 | +43.1 | 4.9 | 40.6 | 0.4 | +52.8 | 14.0 | 20.7 |
| MARCH OVER CASTS | 0.4 | +32.6 | 0.0 | 13.0 | 0.1 | +17.4 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.0 | +93.2 | 0.0 | 123.0 | 4.0 | +169.2 | 0.0 | 137.5 |
| MISSILES IN THE MOVE | 5.0 | +194.1 | 0.0 | 132.8 | 3.0 | +50.7 | 0.0 | 68.2 |
| MISSILES IN THE PLAN | 1.0 | +10.0 | 62.7 | 43.5 | - | - | - | - |
| MISSILES NEXT TURN | 5.4 | +141.1 | 0.0 | 158.1 | 3.7 | +41.2 | 0.0 | 68.2 |
| MODEL FACING | 0.5 | +137.0 | 0.0 | 2.9 | 0.4 | +149.9 | 0.0 | 5.7 |
| MONSTER WIZARD ROAMS | 0.6 | +0.0 | 19.4 | 17.6 | 0.3 | +0.0 | 41.3 | 0.0 |
| MOVE AND CAST | 0.4 | +19.2 | 0.0 | 0.0 | 0.3 | +20.9 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.3 | +13.3 | 0.0 | 55.2 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -8.6 | 3.9 | 15.0 | 0.1 | -6.5 | 0.0 | 13.0 |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 25.9 | 0.1 | +0.0 | 0.0 | 20.7 |
| MOVE TO CHARGE | 2.0 | +159.2 | 44.7 | 105.3 | 5.5 | +368.6 | 223.8 | 166.6 |
| MOVES UNITS SPELL | 0.1 | +5.2 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | - | - | - | - | 0.1 | +15.5 | 29.5 | 0.0 |
| NO RALLY LEFT | 0.0 | +1.0 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| NOT NEEDED | 0.1 | -2.9 | 6.7 | 2.9 | 0.3 | -14.2 | 35.8 | 17.2 |
| NOT TURNED | 4.7 | +142.8 | 0.0 | 126.5 | 4.4 | +137.0 | 0.0 | 83.4 |
| NOT WORTH A CAST | 0.2 | -0.1 | 0.0 | 0.0 | 0.2 | -0.3 | 0.0 | 0.0 |
| OFF BEST | 15.9 | -752.2 | 0.0 | 291.4 | 16.2 | -957.6 | 14.8 | 222.9 |
| OPENS A LANE | 0.0 | +0.5 | 8.1 | 0.0 | - | - | - | - |
| OPENS UP | 0.0 | +2.2 | 0.0 | 0.0 | 0.4 | +35.8 | 21.5 | 0.0 |
| OVERRUNS AWAY | 0.5 | +4.5 | 22.1 | 2.5 | 0.6 | +9.8 | 67.3 | 3.1 |
| PATHS CROSS | 1.1 | +83.8 | 0.0 | 27.0 | 2.7 | +149.7 | 0.0 | 36.6 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +0.4 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.6 | 0.0 | 21.9 | 0.1 | -0.8 | 0.0 | 0.0 |
| PLAN RESULT | 35.3 | +1524.1 | 1286.7 | 963.1 | 40.2 | +1291.4 | 1791.9 | 799.7 |
| PURSUES BIG PREY | - | - | - | - | 0.1 | -9.1 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.0 | +4.2 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.4 | +0.2 | 0.0 | 8.1 | 1.0 | +6.8 | 0.0 | 30.0 |
| RANDOM MOVER NO PROMISE | 0.0 | -1.8 | 3.4 | 8.1 | 0.2 | -20.8 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.0 | -0.6 | 0.0 | 0.0 | 0.2 | -5.4 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.5 | +134.1 | 0.0 | 30.9 | 3.7 | +291.8 | 0.0 | 65.6 |
| REDIRECT WEIGHED | 0.3 | +4.4 | 3.1 | 17.6 | 0.3 | +14.9 | 7.9 | 0.0 |
| RESERVE FALL BACK | 0.2 | +3.7 | 0.0 | 0.0 | 1.1 | +18.6 | 0.0 | 16.7 |
| RESTRAINS TO SHOOT | 0.4 | +52.0 | 0.0 | 0.0 | 0.0 | +2.8 | 0.0 | 0.0 |
| RISK BY ARC | 2.4 | +52.0 | 179.9 | 36.4 | 3.2 | +47.5 | 296.3 | 140.2 |
| SAFER THAN THE JOB | 0.6 | +29.3 | 0.0 | 27.6 | 1.0 | +70.1 | 0.0 | 49.0 |
| SCOUT SPOT | 0.3 | +1.3 | 0.0 | 0.0 | 0.7 | +3.5 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -10.1 | 0.0 | 0.0 | 0.4 | -38.9 | 0.0 | 1.3 |
| SEARCH SPOT | 2.6 | +106.8 | 0.0 | 45.6 | 2.5 | +142.3 | 0.0 | 29.7 |
| SECOND HUNTER | - | - | - | - | 0.1 | -0.5 | 0.0 | 1.6 |
| SET UP TOGETHER | 0.6 | +74.6 | 19.4 | 16.2 | 2.0 | +186.3 | 85.2 | 65.2 |
| SET-UP ANY TARGET | 0.0 | +2.1 | 0.0 | 0.0 | 0.1 | +15.1 | 5.4 | 0.0 |
| SET-UP MISSED | 0.1 | +15.0 | 30.7 | 15.0 | 0.0 | +5.8 | 0.0 | 13.0 |
| SHOOTER COUNTED ONCE | 0.0 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.5 | +1.0 | 0.0 | 0.0 | 0.3 | +0.5 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +45.1 | 42.6 | 7.1 | 0.4 | +9.9 | 33.1 | 6.0 |
| SHORT GUN FORWARD | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOT OPTIONS | 17.4 | +0.0 | 660.8 | 374.2 | 15.4 | +0.0 | 569.4 | 255.6 |
| SHOT REPLANNED | 1.0 | +0.0 | 215.3 | 39.5 | 0.4 | +0.0 | 77.2 | 5.2 |
| SHOTS IN THE MOVE | 16.6 | +864.5 | 0.0 | 313.4 | 14.1 | +470.1 | 0.0 | 181.0 |
| SPELL CATCH ODDS | 0.0 | -0.6 | 13.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.2 | +67.1 | 0.0 | 0.0 | 0.2 | +58.8 | 26.1 | 20.7 |
| SPELL WORTH | 0.7 | +4.7 | 14.4 | 25.0 | 2.2 | +31.8 | 13.0 | 29.8 |
| STABLE ROLE | 11.4 | +0.0 | 230.2 | 203.5 | 11.4 | +0.0 | 451.6 | 125.2 |
| STANDS TO CAST | 0.0 | +0.8 | 0.0 | 3.9 | 0.0 | +4.2 | 0.0 | 0.0 |
| STAY WEIGHED | 0.1 | +0.5 | 0.0 | 0.0 | 0.0 | +4.1 | 0.0 | 0.0 |
| STAY WORTH | 19.0 | +396.6 | 448.9 | 357.7 | - | - | - | - |
| STOPS | - | - | - | - | 0.1 | +9.6 | 7.9 | 1.6 |
| STOPS SHORT OF THE FLANK | 0.2 | +4.5 | 0.0 | 0.0 | 0.3 | +17.0 | 0.0 | 31.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 15.0 |
| SUPPORT NARROWED | 5.0 | -23.5 | 222.2 | 60.5 | 5.9 | -42.9 | 496.7 | 147.7 |
| SUPPORTS | 2.7 | +23.5 | 98.8 | 35.3 | 3.4 | +42.9 | 227.0 | 37.7 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -13.7 | 0.0 | 0.0 | 0.1 | -2.3 | 22.6 | 0.0 |
| SURE REACH TOGETHER | 0.5 | +0.6 | 0.0 | 8.1 | 1.0 | +7.8 | 3.1 | 21.9 |
| THREAT IN THE KILL | 15.2 | +193.3 | 792.7 | 376.3 | - | - | - | - |
| THREAT OVER THE TURNS | 12.6 | +127.4 | 700.7 | 376.3 | - | - | - | - |
| THREAT TO WORN DOWN | 14.5 | +204.8 | 764.1 | 371.8 | - | - | - | - |
| THROUGH LINE OF FIRE | 0.2 | +32.7 | 0.0 | 5.0 | 0.4 | +5.7 | 0.0 | 0.0 |
| TURN WORTH | 0.4 | -28.7 | 22.0 | 29.5 | 0.7 | -48.7 | 49.7 | 2.9 |
| TWO OR MORE ARRIVE | 0.0 | +0.2 | 0.0 | 0.0 | 0.5 | +1.0 | 30.0 | 16.8 |
| WAIT AFTER COSTS | 4.8 | -196.3 | 123.0 | 146.4 | 8.6 | -460.2 | 355.3 | 211.6 |
| WALKS TO THE FIGHT | 1.6 | +38.4 | 56.0 | 23.5 | 1.3 | +37.5 | 58.1 | 8.8 |
| WAR ENGINE CHARGES | 0.1 | +19.4 | 0.0 | 0.0 | 0.0 | +0.8 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 1.0 | +0.0 | 34.8 | 16.4 | 0.3 | +0.0 | 19.2 | 17.6 |
| WEARS DOWN | 1.0 | +28.5 | 82.3 | 18.3 | 1.3 | +34.0 | 161.3 | 120.9 |
| WHO HITS BACK | 0.0 | +3.0 | 0.0 | 0.0 | 0.1 | +6.0 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.4 | +14.7 | 47.8 | 2.6 | 0.5 | +32.4 | 83.5 | 38.4 |
| WHOLE FIGHT GAIN | 0.3 | +19.6 | 23.0 | 2.9 | 0.5 | +26.3 | 17.7 | 13.6 |

### Rule changes: tk-h2h-mine-949ddcd-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 674 | 674 | 674 | 32.10 | -35905 | -53.3 |
| BEST FIRST | 186 | 186 | 186 | 8.86 | +9014 | +48.5 |
| SEARCH SPOT | 106 | 106 | 102 | 4.86 | +5241 | +51.4 |
| PATHS CROSS | 80 | 80 | 80 | 3.81 | +4904 | +61.3 |
| MOVE TO CHARGE | 159 | 159 | 76 | 3.62 | +3652 | +48.0 |
| COUNTER-CHARGE COVER | 342 | 180 | 70 | 3.33 | +4527 | +64.7 |
| KILLS COUNT NEXT TURN | 215 | 215 | 69 | 3.29 | +2293 | +33.2 |
| FACES THE THREAT | 67 | 67 | 67 | 3.19 | +5674 | +84.7 |
| CANNON SIGHT KEPT | 65 | 65 | 65 | 3.10 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 64 | 64 | 64 | 3.05 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 57 | 57 | 57 | 2.71 | +9590 | +168.2 |
| CANNON PLANNED TARGET | 223 | 223 | 41 | 1.95 | -243 | -5.9 |
| SUPPORTS | 128 | 128 | 39 | 1.86 | +389 | +10.0 |
| SHOTS IN THE MOVE | 645 | 413 | 37 | 1.76 | +1798 | +48.6 |
| WAIT AFTER COSTS | 281 | 281 | 37 | 1.76 | +880 | +23.8 |
| SAFER THAN THE JOB | 35 | 35 | 35 | 1.67 | +2088 | +59.7 |
| FALLBACK BY WORTH | 194 | 194 | 34 | 1.62 | +1906 | +56.1 |
| SET UP TOGETHER | 54 | 52 | 33 | 1.57 | +2955 | +89.5 |
| WALKS TO THE FIGHT | 61 | 61 | 32 | 1.52 | +564 | +17.6 |
| SHOT REPLANNED | 29 | 29 | 29 | 1.38 | +0 | +0.0 |
| BEST FACING | 28 | 28 | 28 | 1.33 | +838 | +29.9 |
| RESERVE FALL BACK | 28 | 28 | 28 | 1.33 | +468 | +16.7 |
| STAY WORTH | 399 | 321 | 28 | 1.33 | +597 | +21.3 |
| LONE WIZARD KEPT IN | 27 | 27 | 27 | 1.29 | +1980 | +73.3 |
| MISSILES IN THE MOVE | 169 | 92 | 26 | 1.24 | +661 | +25.4 |
| BEST OVERALL | 25 | 25 | 25 | 1.19 | +1822 | +72.9 |
| CHARGE NOW WEIGHED | 25 | 25 | 25 | 1.19 | +3067 | +122.7 |
| REDIRECT COUNTER | 108 | 56 | 25 | 1.19 | +2899 | +116.0 |
| THREAT TO WORN DOWN | 304 | 235 | 25 | 1.19 | +224 | +9.0 |
| SCOUT WAITS | 22 | 22 | 22 | 1.05 | +0 | +0.0 |
| BEST MOVE FOR SHOOTERS | 21 | 21 | 21 | 1.00 | +1446 | +68.8 |
| CHARGE NOW FIRST | 140 | 140 | 21 | 1.00 | -1029 | -49.0 |
| KILLS COUNT | 91 | 88 | 21 | 1.00 | +577 | +27.5 |
| ADVANCE LANE KEPT | 20 | 20 | 20 | 0.95 | +0 | +0.0 |
| COMBAT PIVOT | 20 | 20 | 20 | 0.95 | +0 | +0.0 |
| MARCH CHECK | 20 | 20 | 20 | 0.95 | +864 | +43.2 |
| HOLDS AMBUSHERS | 19 | 19 | 19 | 0.90 | +0 | +0.0 |
| MARCH ODDS | 19 | 19 | 19 | 0.90 | +512 | +26.9 |
| MODEL FACING | 19 | 19 | 19 | 0.90 | +6025 | +317.1 |
| BLOCKED WHEEL | 18 | 18 | 18 | 0.86 | +268 | +14.9 |
| SHOOTERS IN TWO RANKS | 16 | 16 | 16 | 0.76 | +31 | +1.9 |
| CAST JOB | 36 | 36 | 15 | 0.71 | +245 | +16.3 |
| MOVE AND CAST | 15 | 15 | 15 | 0.71 | +841 | +56.1 |
| RANDOM MOVE BY FIGURES | 30 | 30 | 15 | 0.71 | +147 | +9.8 |
| RISK BY ARC | 117 | 114 | 15 | 0.71 | +555 | +37.0 |
| FRIENDS SHOTS CHECKED | 14 | 14 | 14 | 0.67 | +1004 | +71.7 |
| KEEPS ITS TARGET | 64 | 64 | 14 | 0.67 | +235 | +16.8 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.67 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 14 | 14 | 14 | 0.67 | +807 | +57.6 |
| BEST PREY | 31 | 31 | 13 | 0.62 | +469 | +36.1 |
| REDIRECT WEIGHED | 13 | 13 | 13 | 0.62 | +388 | +29.9 |
| CASTER AWAY FROM SCREEN | 12 | 12 | 12 | 0.57 | +0 | +0.0 |
| MAX FOR POSITIONING | 146 | 82 | 12 | 0.57 | +197 | +16.4 |
| SHOOTS FROM THE BEST SPOT | 23 | 23 | 12 | 0.57 | +250 | +20.8 |
| STOPS SHORT OF THE FLANK | 11 | 11 | 11 | 0.52 | +451 | +41.0 |
| THREAT IN THE KILL | 319 | 247 | 11 | 0.52 | +122 | +11.1 |
| WAR ENGINE JOBS | 28 | 28 | 11 | 0.52 | -292 | -26.6 |
| INVITES THE FIGHT | 40 | 40 | 10 | 0.48 | +56 | +5.6 |
| THREAT OVER THE TURNS | 264 | 204 | 10 | 0.48 | +106 | +10.6 |
| CHAFF PASSED | 9 | 9 | 9 | 0.43 | -66 | -7.3 |
| MAKE SURE TOGETHER | 20 | 16 | 9 | 0.43 | +1254 | +139.4 |
| RESTRAINS TO SHOOT | 9 | 9 | 9 | 0.43 | +1152 | +127.9 |
| WHOLE FIGHT GAIN | 17 | 15 | 9 | 0.43 | +325 | +36.1 |
| CASTING BLOCK | 13 | 13 | 8 | 0.38 | +175 | +21.9 |
| FOCUS OVER TURNS | 26 | 26 | 8 | 0.38 | +163 | +20.4 |
| WHOLE FIGHT | 18 | 18 | 7 | 0.33 | +319 | +45.6 |
| BIG CHARACTER SAFETY | 5 | 5 | 5 | 0.24 | -41 | -8.2 |
| DEFENSIVE ARMY | 14 | 14 | 5 | 0.24 | -327 | -65.4 |
| LOST CHARGE | 112 | 112 | 5 | 0.24 | +107 | +21.4 |
| PIVOT GUARDS FLANK | 5 | 5 | 5 | 0.24 | -50 | -10.1 |
| STUCK PIVOT | 5 | 5 | 5 | 0.24 | +0 | +0.0 |
| SURE CHARGE BEATS ADVANCE | 5 | 5 | 5 | 0.24 | -336 | -67.2 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 0.19 | +0 | +0.0 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.19 | +0 | +0.0 |
| OPENS UP | 10 | 10 | 4 | 0.19 | +156 | +39.0 |
| OVERRUNS AWAY | 24 | 23 | 4 | 0.19 | +59 | +14.7 |
| SURE REACH TOGETHER | 31 | 23 | 4 | 0.19 | +47 | +11.9 |
| BEST PRIZE | 3 | 3 | 3 | 0.14 | -498 | -166.1 |
| BLOCKED CHARGE SKIPPED | 3 | 3 | 3 | 0.14 | +0 | +0.0 |
| MISSILES NEXT TURN | 191 | 108 | 3 | 0.14 | +7 | +2.2 |
| NEEDED THERE | 3 | 3 | 3 | 0.14 | +0 | +0.0 |
| PURSUES BIG PREY | 3 | 3 | 3 | 0.14 | -191 | -63.8 |
| STAY WEIGHED | 3 | 3 | 3 | 0.14 | +96 | +32.1 |
| WEARS DOWN | 49 | 48 | 3 | 0.14 | +48 | +15.8 |
| WHO HITS BACK | 3 | 3 | 3 | 0.14 | +110 | +36.8 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.10 | +16 | +8.0 |
| HUNT ADVANCE | 10 | 10 | 2 | 0.10 | +60 | +30.2 |
| HUNT IN PAIRS | 31 | 14 | 2 | 0.10 | +152 | +76.0 |
| KEEP FALLS | 2 | 2 | 2 | 0.10 | +76 | +38.2 |
| MOVES UNITS SPELL | 2 | 2 | 2 | 0.10 | +110 | +55.1 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.10 | +14 | +6.9 |
| STANDS TO CAST | 2 | 2 | 2 | 0.10 | -15 | -7.4 |
| SUPPORT NARROWED | 229 | 229 | 2 | 0.10 | -131 | -65.7 |
| WAR ENGINE CHARGES | 3 | 3 | 2 | 0.10 | +324 | +161.9 |
| BACKUP TARGETS | 40 | 22 | 1 | 0.05 | +4 | +4.3 |
| BOMBING RUN | 1 | 1 | 1 | 0.05 | +33 | +32.7 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.05 | +0 | +0.1 |
| CATCH ODDS | 1 | 1 | 1 | 0.05 | -30 | -29.5 |
| CHARIOT NO STATIC JOB | 1 | 1 | 1 | 0.05 | -30 | -30.1 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.05 | +0 | +0.0 |
| EDGE GIVE GROUND | 11 | 11 | 1 | 0.05 | +14 | +14.4 |
| FOCUS FIRE | 1 | 1 | 1 | 0.05 | +36 | +36.2 |
| HILL BY ITS CHANCE | 32 | 32 | 1 | 0.05 | +3 | +3.1 |
| LONE WIZARD HOLDS BACK | 2 | 2 | 1 | 0.05 | +0 | +0.0 |
| LONG SHOT | 27 | 26 | 1 | 0.05 | -4 | -4.2 |
| MANOEUVRE | 2 | 2 | 1 | 0.05 | +5 | +5.2 |
| MISSILES IN THE PLAN | 20 | 1 | 1 | 0.05 | +32 | +31.9 |
| MOVE SPELL IN RANGE | 6 | 2 | 1 | 0.05 | +0 | +0.4 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.05 | +8 | +7.9 |
| RAIDS THE BAGGAGE NEXT TURN | 1 | 1 | 1 | 0.05 | +7 | +7.0 |
| TURN WORTH | 23 | 23 | 1 | 0.05 | +2 | +1.9 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 34 | 34 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 3 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 19 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 2 | 2 | 0 | 0.00 | - | - |
| CHEAP HELPER | 7 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 22 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 201 | not checked | - | - | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 10 | 8 | 0 | 0.00 | - | - |
| HUNT DROPPED | 3 | trace | - | - | - | - |
| HUNT KEPT | 7 | trace | - | - | - | - |
| HUNT RESULT | 8 | trace | - | - | - | - |
| HUNT THE GUNS | 10 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 1 | 1 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 8 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 12 | 12 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 19 | 19 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 9 | trace | - | - | - | - |
| MOVE SPELL SPOT | 8 | not checked | - | - | - | - |
| NOT NEEDED | 9 | 9 | 0 | 0.00 | - | - |
| NOT TURNED | 192 | 192 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 9 | not checked | - | - | - | - |
| OPENS A LANE | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 1586 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 6 | 6 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 5 | 5 | 0 | 0.00 | - | - |
| SCOUT SPOT | 20 | 20 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 12 | 12 | 0 | 0.00 | - | - |
| SECOND HUNTER | 2 | 2 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 4 | not checked | - | - | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOT OPTIONS | 690 | 690 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 9 | not checked | - | - | - | - |
| SPELL WORTH | 60 | not checked | - | - | - | - |
| STABLE ROLE | 480 | 480 | 0 | 0.00 | - | - |
| STOPS | 3 | 3 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 11 | 8 | 0 | 0.00 | - | - |

### Off best figure: tk-h2h-mine-949ddcd-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.52 | 14.43 | 56.1 |
| TURN GATE | gate | 0.62 | 0.57 | 13.6 |
| FALLBACK | gate | 0.43 | 0.71 | 35.5 |
| CHARGE NOW FIRST | rule | 0.48 | 0.52 | 49.0 |
| CANNON PLANNED TARGET | rule | 0.71 | 0.10 | 27.4 |
| WAR ENGINE JOBS | rule | 0.43 | 0.10 | 26.6 |
| AFTERMATH BAND | gate | 0.10 | 0.19 | 2.2 |
| CHAFF PASSED | rule | 0.14 | 0.14 | 10.9 |
| DEFENSIVE ARMY | rule | - | 0.24 | 65.4 |
| PIVOT GUARDS FLANK | rule | 0.14 | 0.10 | 10.1 |
| SUPPORT REQUEST | gate | - | 0.24 | 74.3 |
| SURE CHARGE BEATS ADVANCE | rule | 0.10 | 0.14 | 67.2 |
| BIG CHARACTER SAFETY | rule | 0.10 | 0.10 | 10.7 |
| PATHS CROSS | rule | 0.05 | 0.14 | 11.4 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.10 | 0.05 | 55.0 |
| BEST PRIZE | rule | - | 0.14 | 166.1 |
| PURSUES BIG PREY | rule | - | 0.14 | 63.8 |
| CHARGE NOW WEIGHED | rule | - | 0.10 | 22.1 |
| LONE CHARACTER SAFE SPOT | gate | 0.05 | 0.05 | 22.9 |
| SAFER THAN THE JOB | rule | 0.05 | 0.05 | 12.5 |
| STANDS TO CAST | rule | 0.05 | 0.05 | 7.4 |
| STOPS SHORT OF THE FLANK | rule | 0.05 | 0.05 | 8.8 |
| SUPPORT NARROWED | rule | 0.05 | 0.05 | 65.7 |
| THROUGH LINE OF FIRE | rule | 0.05 | 0.05 | 32.9 |
| CATCH ODDS | rule | - | 0.05 | 29.5 |
| CHARIOT NO STATIC JOB | rule | 0.05 | - | 30.1 |
| FRIENDS SHOTS CHECKED | rule | - | 0.05 | 2.0 |
| LONG SHOT | rule | 0.05 | - | 4.2 |
| MARCH ODDS | rule | - | 0.05 | 29.8 |
| NO REASON | gate | 0.05 | - | 9.6 |

### Plans: tk-h2h-mine-949ddcd-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 9.9 | 16% | 374 | 261 | 70% |
| Mine | charge | 3.1 | 52% | 280 | 211 | 75% |
| Mine | close in | 2.5 | 23% | 179 | 49 | 27% |
| Mine | hold | 4.0 | 38% | 299 | 0 | 0% |
| Mine | join | 0.9 | 89% | 19 | 0 | 0% |
| Mine | shoot | 12.1 | 59% | 790 | 1002 | 127% |
| Mine | support | 2.8 | 90% | 10 | 0 | 0% |
| Opponent | advance | 12.8 | 17% | 376 | 264 | 70% |
| Opponent | charge | 4.8 | 52% | 555 | 423 | 76% |
| Opponent | close in | 6.0 | 30% | 481 | 107 | 22% |
| Opponent | hold | 6.0 | 43% | 477 | 0 | 0% |
| Opponent | join | 0.4 | 100% | 14 | 0 | 0% |
| Opponent | shoot | 6.4 | 64% | 237 | 498 | 210% |
| Opponent | support | 3.9 | 88% | 25 | 0 | 0% |

### Packages: hunt the guns, tk-h2h-mine-949ddcd-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 1 | - | - | - | - | - | - | - | 118 |
| Opponent | 0.4 | 9 | 1 | 12% | 38% | 0% | 3.7 | 372 | 82 | 38% | 79 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 116 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 378 |
| Dwarfen Mountain Holds | 0.2 | 1 | 1 | - | - | - | - | - | - | - | 64 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 99 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 108 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.0 | 2 | 0 | 50% | 50% | 0% | 3.0 | 633 | 238 | 50% | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 65 |
| Tomb Kings of Khemri | 1.0 | 3 | 0 | 0% | 67% | 0% | 4.0 | 132 | 60 | 67% | 0 |
| Vampire Counts | 0.3 | 1 | 0 | 0% | 0% | 0% | - | 416 | 0 | 0% | 0 |
| Warriors of Chaos | 0.3 | 1 | 0 | 0% | 0% | 0% | - | 450 | 0 | 0% | 123 |
| Wood Elf Realms | 1.0 | 2 | 1 | 0% | 0% | 0% | - | 446 | 0 | 0% | 0 |

### Battle groups: tk-h2h-mine-949ddcd-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 10.1 | 24% | 46% | 12% | 67% | 22% | 11% | 11% | 57% | 0% |
| Mine | REDIRECT COUNTER | 1.5 | 32% | 60% | 10% | 0% | 0% | 0% | 0% | 100% | 0% |
| Opponent | COUNTER-CHARGE COVER | 6.1 | 22% | 69% | 10% | 67% | 42% | 4% | 8% | 46% | 0% |
| Opponent | REDIRECT COUNTER | 3.7 | 21% | 62% | 0% | - | 0% | 0% | 25% | 75% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: tk-h2h-mine-949ddcd-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 13 (9) | 13 | 0 | 68 | 67% | 2.7 | 0 (4) | 0 (3) | 44 (2) | 20 (5) | 0 (4) |
| Mine | Character | 82 | 46 (82) | 46 | 0 | 47 | 22% | 2.3 | 49 (13) | 54 (38) | 39 (10) | 65 (33) | 30 (28) |
| Mine | Clean-up | 13 | 61 (13) | 10 | 51 | 46 | 54% | 2.0 | 21 (2) | 40 (9) | 200 (2) | 85 (9) | 12 (4) |
| Mine | Fast Hammer | 21 | 39 (21) | 21 | 18 | 43 | 14% | 2.5 | 37 (9) | 49 (7) | 31 (5) | 46 (16) | 8 (5) |
| Mine | Hammer | 40 | 31 (40) | 14 | 17 | 52 | 25% | 2.5 | 7 (10) | 26 (21) | 76 (9) | 16 (27) | 55 (13) |
| Mine | Holder | 15 | 57 (15) | 8 | 49 | 18 | 47% | 2.9 | 15 (4) | 110 (6) | 5 (5) | 68 (12) | 0 (3) |
| Mine | Shooter | 27 | 103 (27) | 35 | 68 | 31 | 0% | 1.6 | 42 (2) | 126 (20) | 35 (5) | 133 (17) | 55 (10) |
| Mine | War machine | 55 | 24 (55) | 24 | 0 | 56 | 2% | 1.2 | 15 (8) | 25 (35) | 29 (12) | 6 (9) | 27 (46) |
| Mine | Wizard | 12 | 0 (12) | 0 | 0 | 23 | 42% | 2.0 | 0 (1) | 0 (5) | 0 (2) | 0 (2) | 0 (6) |
| Opponent | Chaff | 49 | 53 (49) | 19 | 33 | 48 | 43% | 2.6 | 60 (19) | 44 (15) | 53 (15) | 53 (39) | 50 (10) |
| Opponent | Character | 55 | 65 (55) | 65 | 0 | 34 | 24% | 2.5 | 82 (17) | 59 (28) | 96 (4) | 54 (35) | 97 (14) |
| Opponent | Clean-up | 17 | 27 (17) | 18 | 9 | 34 | 41% | 2.1 | 15 (6) | 38 (11) | - | 34 (13) | 12 (4) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (2) | - | - | 0 (2) |
| Opponent | Fast Hammer | 21 | 54 (21) | 39 | 15 | 45 | 38% | 2.3 | 65 (7) | 28 (9) | 94 (5) | 40 (14) | 94 (7) |
| Opponent | Fragile | 5 | 0 (5) | 0 | 0 | 61 | 40% | 2.0 | - | 0 (3) | 0 (1) | 0 (4) | - |
| Opponent | Hammer | 32 | 34 (32) | 22 | 12 | 32 | 25% | 2.8 | 72 (4) | 36 (21) | 0 (7) | 40 (23) | 15 (9) |
| Opponent | Holder | 20 | 124 (20) | 3 | 121 | 30 | 30% | 3.4 | 158 (3) | 127 (11) | 122 (5) | 185 (12) | 39 (7) |
| Opponent | Shooter | 18 | 99 (18) | 5 | 94 | 15 | 0% | 2.3 | 29 (3) | 126 (12) | 51 (3) | 134 (14) | 10 (4) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Opponent | War machine | 24 | 88 (24) | 88 | 0 | 8 | 12% | 1.5 | 151 (6) | 79 (14) | 42 (4) | 0 (3) | 100 (21) |
| Opponent | Wizard | 17 | 49 (17) | 49 | 0 | 15 | 0% | 1.4 | 0 (5) | 112 (7) | 0 (3) | 96 (6) | 0 (9) |

### Charged fights: tk-h2h-mine-949ddcd-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 106 | 218 | 1.8 | 1.0 | 124 | 0 | +124 | 1 of 7 | 4 of 7 | - | +124 |
| Mine | Chaos Dwarfs | 4 | 171 | 214 | 1.8 | 1.0 | 122 | 0 | +122 | 3 of 7 | 5 of 7 | - | +122 |
| Mine | Dwarfen Mountain Holds | 4 | 440 | 28 | 1.5 | 1.8 | 18 | 67 | -48 | 2 of 6 | 6 of 6 | -100 | +56 |
| Mine | Empire of Man | 5 | 204 | 57 | 1.6 | 1.0 | 36 | 46 | -11 | 6 of 8 | 4 of 8 | - | -11 |
| Mine | Grand Cathay | 4 | 132 | 307 | 3.0 | 1.0 | 102 | 18 | +84 | 3 of 12 | 9 of 12 | - | +84 |
| **Mine** | all armies | 21 | 210 | 159 | 1.9 | 1.1 | 84 | 25 | +59 | 15 of 40 | 28 of 40 | -100 | +77 |
| Opponent | Dwarfen Mountain Holds | 2 | 300 | 74 | 4.0 | 1.1 | 18 | 8 | +11 | 0 of 8 | 8 of 8 | +0 | +12 |
| Opponent | Empire of Man | 2 | 755 | 325 | 2.0 | 1.0 | 162 | 0 | +162 | 1 of 4 | 3 of 4 | - | +162 |
| Opponent | Grand Cathay | 2 | 458 | 770 | 3.5 | 1.4 | 220 | 0 | +220 | 3 of 7 | 6 of 7 | +320 | +180 |
| Opponent | Kingdom of Bretonnia | 1 | 205 | 270 | 6.0 | 1.0 | 45 | 0 | +45 | 5 of 6 | 5 of 6 | - | +45 |
| Opponent | Ogre Kingdoms | 2 | 0 | 320 | 3.0 | 1.0 | 107 | 44 | +63 | 3 of 6 | 4 of 6 | - | +63 |
| Opponent | Skaven | 1 | 281 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 3 | 40 | 1424 | 5.3 | 1.2 | 267 | 95 | +172 | 9 of 16 | 8 of 16 | +487 | +100 |
| Opponent | Vampire Counts | 3 | 42 | 525 | 2.7 | 1.2 | 197 | 55 | +141 | 6 of 8 | 7 of 8 | +414 | +50 |
| Opponent | Warriors of Chaos | 3 | 22 | 249 | 1.0 | 1.3 | 249 | 0 | +249 | 2 of 3 | 1 of 3 | +613 | +66 |
| Opponent | Wood Elf Realms | 2 | 75 | 697 | 3.0 | 1.2 | 232 | 0 | +232 | 4 of 6 | 3 of 6 | +0 | +279 |
| **Opponent** | all armies | 21 | 189 | 535 | 3.0 | 1.2 | 176 | 36 | +140 | 33 of 64 | 45 of 64 | +354 | +100 |

### Effective charges: tk-h2h-mine-949ddcd-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 7 | 0 | 0 | 1 (net +122) | 2 (net +28) | 0 | 2 (net +64) | 2 | 20% (1 of 5) |
| Mine | Chaos Dwarfs | 7 | 2 (net +270) | 0 | 1 (net +268) | 2 (net +0) | 0 | 2 (net +22) | 0 | 14% (1 of 7) |
| Mine | Dwarfen Mountain Holds | 6 | 1 (net -340) | 0 | 0 | 0 | 0 | 5 (net +10) | 0 | 0% (0 of 6) |
| Mine | Empire of Man | 8 | 0 | 1 (net +0) | 2 (net -186) | 1 (net +145) | 0 | 4 (net +35) | 0 | 25% (2 of 8) |
| Mine | Grand Cathay | 12 | 3 (net +97) | 0 | 1 (net +234) | 4 (net +11) | 2 (net +55) | 1 (net +329) | 1 | 9% (1 of 11) |
| Opponent | Dwarfen Mountain Holds | 8 | 1 (net +65) | 0 | 1 (net +0) | 0 | 0 | 6 (net +4) | 0 | 12% (1 of 8) |
| Opponent | Empire of Man | 4 | 2 (net +155) | 0 | 1 (net +230) | 1 (net +110) | 0 | 0 | 0 | 25% (1 of 4) |
| Opponent | Grand Cathay | 7 | 2 (net +306) | 0 | 0 | 4 (net +156) | 0 | 1 (net +304) | 0 | 0% (0 of 7) |
| Opponent | Kingdom of Bretonnia | 6 | 1 (net +0) | 1 (net +115) | 0 | 1 (net +0) | 0 | 1 (net +60) | 2 | 0% (0 of 4) |
| Opponent | Ogre Kingdoms | 6 | 1 (net +330) | 0 | 0 | 1 (net +11) | 0 | 4 (net +9) | 0 | 0% (0 of 6) |
| Opponent | Tomb Kings of Khemri | 16 | 4 (net +22) | 0 | 3 (net +23) | 1 (net +110) | 0 | 7 (net +311) | 1 | 20% (3 of 15) |
| Opponent | Vampire Counts | 8 | 2 (net -199) | 1 (net +524) | 1 (net +167) | 0 | 1 (net +165) | 3 (net +224) | 0 | 12% (1 of 8) |
| Opponent | Warriors of Chaos | 3 | 1 (net +73) | 0 | 1 (net +60) | 0 | 0 | 1 (net +613) | 0 | 33% (1 of 3) |
| Opponent | Wood Elf Realms | 6 | 0 | 0 | 1 (net +0) | 3 (net +293) | 0 | 1 (net +0) | 1 | 20% (1 of 5) |

### Charged fights, damage counted: tk-h2h-mine-949ddcd-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 6 | 233 | 265 | +82 | 175 | 118 | +57 | +24.5 |
| Mine | 50-54% | 1 | 189 | 222 | +0 | 82 | 42 | +40 | +21.1 |
| Mine | Effective (55-75%) | 5 | 243 | 269 | +51 | 125 | 106 | +19 | +7.7 |
| Mine | 76-89% | 9 | 227 | 189 | +27 | 52 | 0 | +52 | +22.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 14 | 183 | 173 | +49 | 71 | 24 | +47 | +25.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 260 | 75 | +55 | 65 | 0 | +65 | +25.0 |
| Mine | No odds | 3 | 232 | 121 | +189 | 224 | 37 | +187 | +80.5 |
| Mine | All fights | 40 | 216 | 195 | +59 | 100 | 43 | +57 | +26.5 |
| Opponent | Long shot (under 50%) | 14 | 306 | 239 | +77 | 158 | 130 | +28 | +9.2 |
| Opponent | 50-54% | 2 | 396 | 243 | +320 | 342 | 22 | +320 | +80.8 |
| Opponent | Effective (55-75%) | 8 | 285 | 237 | +66 | 146 | 89 | +58 | +20.2 |
| Opponent | 76-89% | 11 | 275 | 137 | +158 | 166 | 20 | +146 | +53.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 24 | 312 | 184 | +162 | 210 | 58 | +152 | +48.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 499 | 165 | +165 | 165 | 0 | +165 | +33.1 |
| Opponent | No odds | 4 | 356 | 233 | +230 | 256 | 88 | +167 | +47.0 |
| Opponent | All fights | 64 | 309 | 199 | +140 | 189 | 71 | +119 | +38.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| tk-h2h-mine-949ddcd-p2 | move | 216 | 53 (25%) | 35 (16%) | 32 (15%) | 131 (61%) |
| tk-h2h-mine-949ddcd-p2 | objective | 179 | 36 (20%) | 24 (13%) | 29 (16%) | 114 (64%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135 |
| Fistful of Laurels | Opponent | L0918, L1118 |
| Invocation of Nehek | Opponent | L0425, L0827 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228 |
| Ring of Doom | Opponent | L0512 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

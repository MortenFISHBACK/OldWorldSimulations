# Doctrine scorecard: tk-h2h-mine-949ddcd-p3

### Scorecard: tk-h2h-mine-949ddcd-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | - | 0 | 2 | 1 | 0 | 0 | 0 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 0 | 5 | 0 | 1 | 0 | 0 | 0 | 322 |
| L0126 | 6 | 1 | Opponent | no | 18 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 2 | - | 1 | 5 | 1 | 0 | 0 | 30 |
| L0210 | 6 | 1 | Opponent | no | 5 | 2 | 3 | 1 | 0 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | no | 1 | 3 | 1 | 0 | 1 | 0 | 0 | 523 |
| L0226 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | no | - | 3 | 4 | 1 | 0 | 0 | 0 | 480 |
| L0311 | 5 | 1 | Opponent | no | - | 3 | 3 | 0 | 1 | 0 | 0 | 526 |
| L0327 | 3 | 1 | Mine | no | 1 | 6 | 1 | 0 | 0 | 0 | 0 | 685 |
| L0327 | 3 | 1 | Opponent | no | 7 | 2 | 2 | 3 | 1 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | no | - | 2 | 4 | 1 | 0 | 0 | 0 | 317 |
| L0429 | 3 | 1 | Mine | yes | 5 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 881 |
| L0516 | 6 | 1 | Opponent | no | 2 | 2 | 4 | 1 | 1 | 0 | 0 | 200 |
| L0533 | 5 | 1 | Mine | yes | - | - | 0 | 2 | 0 | 0 | 0 | 1193 |
| L0533 | 5 | 1 | Opponent | yes | - | 2 | 5 | 5 | 0 | 0 | 0 | 334 |
| L0620 | 2 | 1 | Mine | - | - | 3 | 2 | 1 | 0 | 0 | 0 | 615 |
| L0620 | 2 | 1 | Opponent | - | - | 3 | 2 | 3 | 0 | 0 | 0 | 210 |
| L0709 | 1 | 1 | Mine | yes | 2 | 2 | 5 | 0 | 0 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 641 |
| L0725 | 5 | 1 | Mine | no | - | 3 | 2 | 1 | 0 | 0 | 0 | 375 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 560 |
| L0815 | 5 | 1 | Opponent | yes | - | 2 | 3 | 2 | 1 | 0 | 0 | 115 |
| L0831 | 3 | 1 | Mine | no | 1 | 3 | 2 | 0 | 0 | 0 | 0 | 807 |
| L0831 | 3 | 1 | Opponent | no | 2 | 6 | 2 | 1 | 1 | 0 | 0 | 340 |
| L0922 | 4 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 677 |
| L0922 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 1 | 0 | 0 | 55 |
| L1013 | 5 | 1 | Mine | yes | - | 3 | 3 | 1 | 0 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | yes | - | 1 | 3 | 1 | 1 | 0 | 0 | 317 |
| L1030 | 4 | 1 | Mine | no | 0 | 2 | 6 | 0 | 0 | 0 | 0 | 330 |
| L1030 | 4 | 1 | Opponent | no | 1 | 3 | 2 | 2 | 1 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 6 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1122 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 1 | 0 | 0 | 199 |
| L1216 | 4 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 524 |
| L1216 | 4 | 1 | Opponent | no | 0 | 4 | 1 | 0 | 0 | 0 | 0 | 536 |
| L1232 | 2 | 1 | Mine | - | - | 3 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 3 | 3 | 3 | 0 | 0 | 0 | 340 |
| L1327 | 1 | 1 | Mine | no | 9 | 3 | 2 | 0 | 0 | 0 | 0 | 317 |
| L1327 | 1 | 1 | Opponent | no | 2 | 1 | 5 | 3 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Mine | no | 11 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 127 |
| L1519 | 1 | 1 | Mine | no | 3 | 2 | 3 | 1 | 0 | 0 | 0 | 199 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 7 | 0 | 1 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | yes | - | 3 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 3 | 3 | 1 | 0 | 0 | 0 | 125 |
| L1633 | 1 | 1 | Mine | yes | 6 | 2 | 4 | 1 | 1 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 0 | 1 | 4 | 2 | 0 | 0 | 0 | 893 |
| L1731 | 3 | 1 | Mine | no | 2 | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Opponent | no | 0 | 2 | 1 | 0 | 3 | 0 | 0 | 340 |
| L1831 | 1 | 1 | Mine | no | 4 | 3 | 5 | 0 | 2 | 0 | 0 | 305 |
| L1831 | 1 | 1 | Opponent | no | 4 | 2 | 3 | 0 | 0 | 0 | 0 | 170 |
| L1932 | 6 | 1 | Mine | no | 2 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1932 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 170 |
| L2033 | 5 | 1 | Mine | yes | - | - | 0 | 3 | 1 | 0 | 0 | 617 |
| L2033 | 5 | 1 | Opponent | yes | - | 5 | 1 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 30% | 2.9 | 2.7 | 2.4 | 0.9 | 0.3 | 0.0 | 0.0 | 368.3 |
| **Average** | | | Opponent | 22% | 2.2 | 2.4 | 3.1 | 1.4 | 0.4 | 0.0 | 0.0 | 226.2 |

### KPIs: tk-h2h-mine-949ddcd-p3

Rules off - Opponent only: STAY WORTH, BEST MOVE FOR SHOOTERS, THREAT IN THE KILL, FOCUS OVER TURNS, MISSILES IN THE PLAN, FACE THE CAST, WIZARD FRONT RANK, THREAT OVER THE TURNS, THREAT TO WORN DOWN.

Morten 2026-11-10; 30 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 30% (43 of 144) | 8% (12 of 147) | 19% (55 of 291) |
| Winner chose to follow up after the loser gave ground |  | 98% (58 of 59); on the table 98% | 100% (52 of 52); on the table 100% | 99% (110 of 111); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 82% (9 of 11); on the table 82% | 94% (16 of 17); on the table 94% | 89% (25 of 28); on the table 89% |
| Winner chose to pursue after the loser fled |  | 85% (22 of 26); on the table 88% | 69% (27 of 39); on the table 74% | 75% (49 of 65); on the table 80% |
| Winner chose to follow up or pursue (all three) |  | 93% (89 of 96); on the table 94% | 88% (95 of 108); on the table 90% | 90% (184 of 204); on the table 92% |
| Magic missiles tried each own turn | 50%+ | 31% (96 of 312) | 25% (47 of 186) | 29% (143 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 48% (96 of 200) | 41% (47 of 116) | 45% (143 of 316) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 29% (49 of 168) | 20% (28 of 138) | 25% (77 of 306) |
|     round 1 |  | 11% (3 of 28) | 35% (8 of 23) | 22% (11 of 51) |
|     rounds 2+ |  | 33% (46 of 140) | 17% (20 of 115) | 26% (66 of 255) |
|   other wizards | 50%+ | 33% (47 of 144) | 40% (19 of 48) | 34% (66 of 192) |
|     round 1 |  | 38% (9 of 24) | 12% (1 of 8) | 31% (10 of 32) |
|     rounds 2+ |  | 32% (38 of 120) | 45% (18 of 40) | 35% (56 of 160) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 53% (8 of 15) | 38% (19 of 50) | 42% (27 of 65) |
| Points that never fought | lower | 32% (18767 of 58694) | 36% (21870 of 59991) | 34% (40637 of 118685) |
|   infantry points that never fought | lower | 37% (4585 of 12529) | 52% (6179 of 11947) | 44% (10764 of 24476) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 55% (130 of 237) | 58% (138 of 240) | 56% (268 of 477) |
| Bound items with a magic missile used (at least once a game) |  | 100% (24 of 24); 2.1 uses a game | 90% (18 of 20); 2.3 uses a game | 95% (42 of 44); 2.2 uses a game |
| Bound items with another spell used |  | 43% (6 of 14); 0.2 uses a game | 33% (2 of 6); 0.2 uses a game | 40% (8 of 20); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 40% (8 of 20); 0.3 uses a game | 27% (3 of 11); 0.1 uses a game | 35% (11 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 48% (24022 of 50471) | 51% (27343 of 53597) | 49% (51365 of 104068) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.5 (20%) | 1.0 (22%) | 2.5 (21%) |
| MARCHED: its unit marched | 1.4 (19%) | 0.9 (20%) | 2.3 (20%) |
| CHARGED: its unit charged | 0.3 (4%) | 0.2 (4%) | 0.4 (4%) |
| IN COMBAT: engaged in combat | 2.1 (29%) | 1.2 (26%) | 3.3 (28%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.2 (4%) | 0.3 (3%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| GONE: slain | 1.4 (19%) | 1.1 (23%) | 2.5 (21%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.9 | 1.3 | 2.2 | 4.8 | 0.7 | 2.2 |
| not cast | 4.1 | 1.4 | 4.6 | 11.8 | 2.8 | 19.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.7 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.4 (32%) | 0.3 (7%) | 2.5 (21%) | 0.1 (5%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (20%) | 0.5 (19%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (4%) | 0.1 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (6%) | 0.1 (10%) | 0.9 (20%) | 3.3 (28%) | 0.9 (33%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.0 (0%) | 0.3 (7%) | 0.3 (3%) | 0.1 (5%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.1 (2%) | 0.6 (3%) |
| GONE: slain | 1.0 (25%) | 0.4 (32%) | 1.1 (23%) | 2.5 (21%) | 0.3 (10%) | 1.6 (8%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (6%) | 0.0 (0%) | 0.4 (8%) | 0.2 (2%) | 0.2 (6%) | 0.7 (3%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.1 (10%) | 0.0 (1%) | 0.1 (1%) | 0.5 (17%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.2 (55%) | 0.2 (17%) | 1.4 (31%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.2 (77%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.6 a game | 0.6 a game | 1.1 a game |
| stood (cast and not dispelled) | 54% (19 of 35) | 53% (8 of 15) | 54% (27 of 50) |
| the unit moved after it | 79% (15 of 19) | 100% (8 of 8) | 85% (23 of 27) |
| it charged on its next turn | 11% (2 of 19) | 12% (1 of 8) | 11% (3 of 27) |
| the enemy charged it first | 37% (7 of 19) | 12% (1 of 8) | 30% (8 of 27) |
| it fought by the end of its next turn | 16% (3 of 19) | 12% (1 of 8) | 15% (4 of 27) |
| it moved out of a charge the enemy had planned (not charged first) | 16% (3 of 19) | 50% (4 of 8) | 26% (7 of 27) |
| none of these (no charge, no fight, no charge escaped) | 37% (7 of 19) | 25% (2 of 8) | 33% (9 of 27) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 69% (502 of 728) | 59% (286 of 483) | 65% (788 of 1211) |
|   cavalry | 70% (35 of 50) | 58% (45 of 78) | 62% (80 of 128) |
|   character | 71% (76 of 107) | 22% (18 of 82) | 50% (94 of 189) |
|   chariot | 44% (39 of 89) | 71% (22 of 31) | 51% (61 of 120) |
|   infantry | 59% (107 of 181) | 62% (123 of 197) | 61% (230 of 378) |
|   monster | 46% (16 of 35) | 100% (1 of 1) | 47% (17 of 36) |
|   war machine | 86% (229 of 266) | 82% (77 of 94) | 85% (306 of 360) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.1 (28%) | 1.7 (25%) | 3.8 (27%) |
| CHARGED: it charged | 1.1 (14%) | 1.5 (23%) | 2.6 (18%) |
| FLEEING: it fled or was fleeing | 0.2 (3%) | 0.0 (1%) | 0.2 (2%) |
| IN COMBAT: it fought this turn or the last | 0.8 (10%) | 0.5 (8%) | 1.3 (9%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.0 (14%) | 0.7 (11%) | 1.8 (13%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (5%) | 0.5 (8%) | 0.9 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (17%) | 1.2 (18%) | 2.4 (17%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.2 (3%) | 0.4 (3%) |
| OTHER BAR | 0.4 (5%) | 0.2 (4%) | 0.6 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.4 | 1.1 | 81% | 5.3 pts | 23 pts |
| character | 3.7 | 2.0 | 71% | 9.7 pts | 36 pts |
| chariot | 2.0 | 0.6 | 79% | 6.2 pts | 13 pts |
| infantry | 11.8 | 4.0 | 74% | 8.6 pts | 101 pts |
| monster | 0.7 | 0.2 | 82% | 5.6 pts | 4 pts |
| war machine | 10.6 | 9.4 | 61% | 27.6 pts | 291 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.6 | 6.1 | 4.9 |
| Charges that made contact a game | 3.0 | 4.0 | 3.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.05 declared, 0.82 contact (22 units) | 1.11 declared, 0.89 contact (18 units) | 1.07 declared, 0.85 contact (40 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.25 declared, 1.25 contact (4 units) | 1.20 declared, 0.80 contact (5 units) | 1.22 declared, 1.00 contact (9 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.42 declared, 0.35 contact (189 units) | 0.73 declared, 0.47 contact (215 units) | 0.59 declared, 0.41 contact (404 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 59% (37 of 63) | 38% (5 of 13) | 14% (1 of 7) | 52% (43 of 83) |
| Character in a unit | 91% (21 of 23) | 100% (8 of 8) | 33% (1 of 3) | 88% (30 of 34) |
| Character on its own | 79% (33 of 42) | 49% (21 of 43) | 27% (15 of 56) | 49% (69 of 141) |
| Chariot | 91% (10 of 11) | 75% (9 of 12) | - | 83% (19 of 23) |
| Infantry | 60% (39 of 65) | 44% (15 of 34) | 0% (0 of 4) | 52% (54 of 103) |
| Monster | 44% (11 of 25) | 50% (3 of 6) | - | 45% (14 of 31) |
| Monstrous | 71% (5 of 7) | 50% (5 of 10) | - | 59% (10 of 17) |
| War Machines | 63% (27 of 43) | 100% (2 of 2) | - | 64% (29 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 88% (15 of 17); on the table 88% | 29% (28 of 96) | 21% | 59% (13 of 22) | 100% (6 of 6); 3.2 uses a game | 50% (1 of 2); 0.2 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 80% (8 of 10); on the table 80% | 53% (19 of 36) | 29% | 53% (17 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (3 of 3); on the table 100% | - | 63% | 62% (15 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 88% (14 of 16); on the table 94% | 43% (13 of 30) | 41% | 66% (39 of 59) | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 4); 0.0 uses a game |
| Grand Cathay | 8 | 90% (27 of 30); on the table 90% | 23% (45 of 192) | 40% | 50% (37 of 74) | 94% (17 of 18); 6.4 uses a game | 25% (1 of 4); 0.1 uses a game | 12% (1 of 8); 0.1 uses a game |
| High Elf Realms | 7 | 92% (11 of 12); on the table 92% | 29% (12 of 42) | 28% | 56% (30 of 54) | 100% (9 of 9); 4.1 uses a game | 50% (6 of 12); 1.7 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 100% (9 of 9); on the table 100% | - | 38% | 33% (6 of 18) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Lizardmen | 1 | 100% (5 of 5); on the table 100% | 17% (1 of 6) | 8% | 0% (0 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (5 of 5); on the table 100% | 17% (1 of 6) | 6% | 71% (5 of 7) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 91% (10 of 11); on the table 100% | 17% (2 of 12) | 2% | 69% (11 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Skaven | 2 | 88% (7 of 8); on the table 88% | 17% (2 of 12) | 63% | 57% (8 of 14) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Tomb Kings of Khemri | 3 | 100% (8 of 8); on the table 100% | 0% (0 of 6) | 31% | 33% (5 of 15) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 5 | 100% (28 of 28); on the table 100% | 36% (13 of 36) | 36% | 50% (14 of 28) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 7 | 82% (31 of 38); on the table 84% | 33% (6 of 18) | 29% | 55% (36 of 65) | 100% (3 of 3); 2.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 4 | 75% (3 of 4); on the table 75% | 17% (1 of 6) | 45% | 76% (32 of 42) | 86% (6 of 7); 6.2 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (tk-h2h-mine-949ddcd-p3, 30 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 43% (34) | 48% (31) | 45% (65) |
| ...free all their last turn and able to turn (per game) | 0.63 | 0.67 | 1.30 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.13 | 0.27 | 0.40 |
| ...with the charger already in that arc before they moved (per game) | 0.53 | 0.50 | 1.03 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.53 | 1.10 | 2.63 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.70 | 0.73 | 1.43 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.00 | 3.80 | 8.80 |

### Quality by phase: tk-h2h-mine-949ddcd-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.8 |
| Strategy | Charge objectives carried out (made contact) | 57% (58 of 102) | 37% (65 of 174) |
| Strategy | Shoot objectives carried out (shot that target) | 49% (180 of 366) | 50% (100 of 199) |
| Strategy | Close-in objectives charged next turn | 13% (17 of 126) | 22% (39 of 177) |
| Strategy | Support requests answered (helper made contact too) | 71% (5 of 7) | 28% (5 of 18) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 75% (3 of 4) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 57% (4 of 7) | 67% (6 of 9) |
| Strategy | Joined characters whose unit fought | 50% (16 of 32) | 27% (7 of 26) |
| Strategy | Lone characters that fought | 82% (70 of 85) | 80% (69 of 86) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 0.9 | 1.4 |
| Movement | Points that never moved of their own | 368.3 | 226.2 |
| Movement | Fights charged into per game | 2.8 | 3.3 |
| Movement | Charges with odds: long shots (under 50%) | 8 of 69, net +93 | 16 of 89, net +134 |
| Movement | Charges with odds: sweet spot (55-75%) | 8 of 69, net +77 | 15 of 89, net +100 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 7 of 69, net +73 | 7 of 89, net +51 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 34 of 69, net +130 | 32 of 89, net +128 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.6 | 8.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 36% (105 of 289) | 47% (114 of 245) |
| Shooting | Points destroyed by shooting units | 39.9 | 42.4 |
| Shooting | War machine shots | 7.6 | 2.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (114 of 229) | 41% (36 of 88) |
| Shooting | Points destroyed by war machines | 95.8 | 19.8 |
| Magic | Magic missiles cast | 2.1 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 52% (32 of 62) | 47% (15 of 32) |
| Magic | Wounds caused by magic missiles | 4.0 | 2.2 |
| Magic | Wounds caused by other spells | 1.8 | 1.5 |
| Magic | Points destroyed by magic (all spells) | 114.2 | 20.9 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.2 / 0.9 / 0.2 | 1.7 / 0.3 / 0.4 / 0.3 |
| Combat | Points destroyed in combat | 433.6 | 467.5 |
| Combat | Points run down | 59.7 | 147.8 |
| Combat | Net points per charged fight, damage counted | +84 | +107 |
| Combat | Net per 100 charger points, damage counted | +29.4 | +33.9 |
| Combat | First round won (charged fights) | 75% | 62% |
| Combat | Net points per charged fight | +86 | +106 |
| Combat | Net points per supported fight / lone fight | +284 / +74 | +185 / +89 |
| Combat | Charged fights on a top-3 enemy unit | 26 of 84 | 50 of 100 |
| Game | Points lost | 761.8 | 789.6 |
| Game | VP from objectives | 544.3 | 548.0 |
| Game | Lone holders (player turns) | 2.9 | 2.2 |

- Mine won / drew / lost: 12 / 7 / 11 of 30 ended games (of 30); mean margin (Mine - Opponent) +13 VP
- The side that went first won 12 of 23 games with a winner
- Points traded per game (both sides' losses): 1551
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: tk-h2h-mine-949ddcd-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.5 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 2.2 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.4 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.1 | +0.0 | 0.0 | 42.2 | 0.3 | +0.0 | 0.0 | 4.2 |
| BACKUP TARGETS | 0.8 | +7.3 | 0.0 | 24.4 | 0.8 | +12.1 | 0.0 | 16.7 |
| BEST FACING | 0.8 | +40.3 | 0.0 | 20.5 | 0.6 | +31.6 | 0.0 | 24.0 |
| BEST FIRST | 4.2 | +202.6 | 117.7 | 93.2 | 3.0 | +134.2 | 70.1 | 24.5 |
| BEST MOVE FOR SHOOTERS | 1.2 | +111.8 | 0.0 | 25.4 | - | - | - | - |
| BEST OVERALL | 0.5 | +29.9 | 0.0 | 30.0 | 0.6 | +27.7 | 0.0 | 23.9 |
| BEST PREY | 0.6 | +43.9 | 14.0 | 17.8 | 0.8 | +35.2 | 49.7 | 7.0 |
| BEST PRIZE | 0.1 | +1.2 | 3.5 | 0.0 | 0.0 | -7.7 | 0.0 | 6.5 |
| BIG CHARACTER SAFETY | 0.2 | -0.9 | 0.0 | 0.0 | 0.2 | -0.6 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 11.0 |
| BLOCKED WHEEL | 0.4 | +5.3 | 0.0 | 0.0 | 0.3 | +12.6 | 0.0 | 14.5 |
| BOMBING RUN | 0.0 | +0.3 | 1.8 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 5.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 72.4 | 18.7 | 0.3 | +0.0 | 16.9 | 5.5 |
| CANNON PLANNED TARGET | 6.5 | +170.8 | 507.6 | 105.0 | 2.0 | +72.1 | 63.4 | 16.3 |
| CANNON SIGHT KEPT | 1.6 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 0.0 | 2.2 | 0.1 | +0.0 | 16.1 | 0.0 |
| CARRIES OUT SET-UP | 0.2 | -12.7 | 32.1 | 0.0 | 0.2 | -3.1 | 43.4 | 3.9 |
| CAST JOB | 1.1 | +65.2 | 126.4 | 17.3 | 0.9 | +14.1 | 46.7 | 5.4 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +21.2 | 17.8 | 7.4 | 0.0 | +0.7 | 2.2 | 3.6 |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 23.7 | 0.3 | +0.0 | 0.0 | 13.3 |
| CASTS FROM BEHIND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +1.7 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | 0.0 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.1 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE NOW FIRST | 3.0 | +0.0 | 351.3 | 90.5 | 3.5 | +0.0 | 304.5 | 134.8 |
| CHARGE NOW WEIGHED | 0.4 | -26.1 | 25.9 | 0.0 | 0.6 | -29.7 | 38.5 | 7.5 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 0.0 | 5.7 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.0 | -0.3 | 0.0 | 0.0 | 0.2 | -0.4 | 0.0 | 13.3 |
| CHEAP HELPER | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 17.5 | 0.0 |
| COMBAT PIVOT | 0.4 | +0.0 | 20.9 | 35.2 | 0.5 | +0.0 | 14.8 | 29.0 |
| CONVEYANCE SEARCH | 0.8 | +136.3 | 15.9 | 28.5 | 0.5 | +40.6 | 3.6 | 15.6 |
| COUNTER-CHARGE COVER | 9.6 | +862.8 | 0.0 | 179.2 | 6.9 | +689.2 | 0.0 | 126.7 |
| DEFENSIVE ARMY | 0.1 | -0.1 | 12.4 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.0 | +1.6 | 0.0 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.2 | +19.1 | 17.4 | 16.7 | 0.1 | +1.3 | 15.1 | 0.0 |
| ELIXIR WORTH | 0.0 | +0.1 | 0.0 | 11.7 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACE THE CAST | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.5 | +126.5 | 0.0 | 44.0 | 1.1 | +68.2 | 0.0 | 36.6 |
| FALLBACK BY WORTH | 4.5 | +37.8 | 0.0 | 49.0 | 4.9 | +64.8 | 0.0 | 48.1 |
| FIGHT LIFT | 0.0 | +0.1 | 9.2 | 0.0 | - | - | - | - |
| FIRE AND FLEE | 0.0 | +0.5 | 3.5 | 2.7 | - | - | - | - |
| FLANK NOT WEIGHED | 4.9 | +0.0 | 0.0 | 146.1 | 3.6 | +0.0 | 0.0 | 56.6 |
| FOCUS FIRE | - | - | - | - | 0.1 | +4.8 | 9.7 | 0.0 |
| FOCUS OVER TURNS | 1.4 | +31.7 | 78.6 | 31.3 | - | - | - | - |
| FOLLOW UP WEIGHED | 1.3 | +193.9 | 0.0 | 66.9 | 1.4 | +299.2 | 0.0 | 54.2 |
| FRIENDS SHOTS CHECKED | 0.3 | +11.4 | 0.0 | 16.1 | 0.1 | +5.7 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -1.0 | 10.7 | 0.0 | 0.1 | -2.2 | 23.4 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -0.5 | 18.1 | 0.6 |
| HELPER ALREADY ASKED | - | - | - | - | 0.0 | +0.0 | 16.7 | 0.0 |
| HELPER UNSEEN | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 79.5 | 10.4 |
| HILL BY ITS CHANCE | 0.3 | -25.7 | 0.0 | 0.0 | 0.4 | -47.2 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +4.7 | 0.0 | 1.7 | 0.1 | +4.4 | 0.0 | 5.9 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 3.5 | - | - | - | - |
| HUNT IN PAIRS | 0.2 | +1.9 | 0.0 | 20.5 | 0.8 | +43.1 | 0.0 | 54.5 |
| HUNT KEPT | 0.2 | +4.2 | 0.0 | 1.7 | 0.1 | +2.5 | 0.0 | 6.1 |
| HUNT RESULT | 0.1 | +0.0 | 0.0 | 3.5 | 0.2 | +8.2 | 0.0 | 9.9 |
| HUNT THE GUNS | 0.1 | +39.1 | 0.0 | 1.7 | 0.2 | +48.9 | 4.2 | 7.5 |
| INVITES THE FIGHT | 1.2 | +27.3 | 67.8 | 6.5 | 1.3 | +23.0 | 46.4 | 14.7 |
| JOINT CHARGE PLAN | 0.1 | +16.5 | 15.1 | 4.5 | 0.2 | +3.7 | 0.0 | 7.7 |
| KEEP FALLS | 0.1 | +1.0 | 0.0 | 7.3 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS TARGET | 1.8 | +54.0 | 174.8 | 8.3 | 2.3 | +69.0 | 243.0 | 41.9 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.7 | +74.8 | 142.6 | 41.5 | 2.3 | +104.0 | 183.0 | 54.0 |
| KILLS COUNT NEXT TURN | 4.5 | +169.2 | 228.0 | 96.6 | 7.3 | +248.2 | 276.3 | 261.1 |
| LONE CHARACTER SAFE SPOT | 0.5 | +26.8 | 19.0 | 13.6 | 0.3 | +9.6 | 16.2 | 4.2 |
| LONE WIZARD HOLDS BACK | 0.0 | +0.0 | 8.5 | 0.0 | 0.4 | +0.0 | 7.6 | 0.0 |
| LONE WIZARD KEPT IN | 0.6 | +42.9 | 0.0 | 0.0 | 0.4 | +29.7 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | +1.9 | 14.8 | 5.2 | 0.5 | -5.4 | 44.6 | 8.0 |
| LOST CHARGE | 3.2 | -63.3 | 164.5 | 104.6 | 2.3 | -31.8 | 59.0 | 70.5 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.0 | -19.3 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.6 | +61.3 | 51.6 | 0.0 | 1.0 | +67.1 | 48.8 | 29.0 |
| MANOEUVRE | 0.2 | +9.6 | 0.0 | 9.9 | 0.1 | +2.7 | 0.0 | 2.3 |
| MARCH AT ESCAPER | 0.1 | +2.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.6 | +34.7 | 0.0 | 23.4 | 0.8 | +69.6 | 0.0 | 0.0 |
| MARCH ODDS | 0.3 | +15.4 | 11.6 | 0.0 | 0.5 | +29.0 | 20.5 | 12.3 |
| MARCH OVER CASTS | 0.5 | +48.5 | 0.0 | 0.0 | 0.5 | +36.3 | 0.0 | 21.7 |
| MAX FOR POSITIONING | 4.7 | +155.6 | 0.0 | 99.8 | 4.7 | +237.2 | 0.0 | 82.1 |
| MISSILES IN THE MOVE | 4.4 | +282.7 | 0.0 | 154.0 | 4.3 | +64.3 | 0.0 | 40.5 |
| MISSILES IN THE PLAN | 0.8 | +11.7 | 48.4 | 14.5 | - | - | - | - |
| MISSILES NEXT TURN | 5.4 | +189.3 | 0.0 | 160.5 | 5.3 | +45.7 | 0.0 | 96.6 |
| MODEL FACING | 0.2 | +34.5 | 0.0 | 2.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.4 | +0.0 | 60.6 | 6.8 | 0.0 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.5 | +41.5 | 0.0 | 27.7 | 0.6 | +23.8 | 0.0 | 9.0 |
| MOVE SPELL IN RANGE | 0.2 | +8.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL NOT WORTH | - | - | - | - | 0.0 | -0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.6 | -25.4 | 0.0 | 54.8 | 0.2 | -5.6 | 0.0 | 7.8 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 2.2 | 0.1 | +0.0 | 0.0 | 13.3 |
| MOVE TO CHARGE | 2.9 | +209.4 | 170.0 | 48.9 | 5.2 | +401.3 | 232.9 | 152.9 |
| MOVES UNITS SPELL | 0.2 | +4.3 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +4.2 | 0.0 | 6.8 | 0.1 | +0.0 | 5.0 | 0.0 |
| NO RALLY LEFT | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| NOT NEEDED | 0.2 | -11.3 | 21.6 | 0.0 | 0.6 | -54.2 | 100.7 | 0.0 |
| NOT TURNED | 5.0 | +107.7 | 0.0 | 121.6 | 3.8 | +0.3 | 0.0 | 64.1 |
| NOT WORTH A CAST | 0.7 | -0.5 | 0.0 | 11.8 | 0.8 | -0.8 | 0.0 | 0.0 |
| OFF BEST | 14.9 | -720.1 | 0.0 | 293.6 | 14.5 | -875.3 | 5.0 | 250.9 |
| OPENS A LANE | 0.3 | +1.3 | 49.0 | 14.5 | 0.4 | +3.0 | 17.3 | 0.0 |
| OPENS UP | 0.1 | +8.0 | 3.8 | 0.0 | 0.4 | +27.0 | 19.1 | 12.3 |
| OVERRUN THREAT | - | - | - | - | 0.0 | +0.8 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.5 | +30.2 | 63.7 | 31.4 | 0.6 | +13.6 | 31.2 | 44.2 |
| PATHS CROSS | 1.5 | +84.1 | 0.0 | 17.3 | 2.5 | +205.9 | 0.0 | 39.6 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +4.1 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.0 | -0.6 | 0.0 | 0.0 | 0.1 | -1.2 | 0.0 | 9.5 |
| PLAN RESULT | 36.4 | +1519.3 | 1633.5 | 1015.2 | 37.2 | +1213.6 | 1440.0 | 1072.3 |
| PURSUES BIG PREY | 0.1 | -3.9 | 0.0 | 0.0 | 0.2 | -9.7 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.1 | +13.8 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +9.8 | 0.0 | 5.8 | 0.1 | +4.1 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.5 | +8.5 | 0.0 | 12.7 | 1.7 | +7.9 | 0.0 | 65.0 |
| RANDOM MOVER NO PROMISE | 0.1 | -4.1 | 0.0 | 5.7 | 0.6 | -44.7 | 27.6 | 12.7 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -0.4 | 0.0 | 0.0 | 0.3 | -14.0 | 0.0 | 6.3 |
| REDIRECT COUNTER | 1.8 | +176.7 | 0.0 | 48.3 | 3.6 | +370.5 | 0.0 | 48.8 |
| REDIRECT WEIGHED | 0.1 | +5.4 | 7.1 | 0.0 | 0.4 | -2.0 | 8.3 | 24.9 |
| RESERVE FALL BACK | 0.2 | +2.5 | 0.0 | 0.0 | 1.0 | +21.0 | 0.0 | 11.6 |
| RESTRAINS TO SHOOT | 0.1 | +2.3 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.5 | +77.9 | 237.3 | 56.4 | 3.4 | +62.1 | 344.4 | 146.2 |
| SAFER THAN THE JOB | 0.7 | +74.2 | 0.0 | 10.6 | 0.7 | +47.6 | 0.0 | 17.6 |
| SCOUT SPOT | 0.3 | +0.5 | 0.0 | 1.1 | 0.3 | +1.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 1.1 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | -1.0 | 0.0 | 1.1 | 0.3 | -25.3 | 0.0 | 0.0 |
| SEARCH SPOT | 2.7 | +142.3 | 0.0 | 66.1 | 2.1 | +107.4 | 0.0 | 22.1 |
| SECOND HUNTER | 0.0 | -1.5 | 0.0 | 0.0 | 0.0 | -0.2 | 0.0 | 0.0 |
| SELF MOVE SPELL | 0.6 | +70.1 | 0.0 | 0.0 | 0.1 | +52.6 | 0.0 | 13.2 |
| SET UP TOGETHER | 1.1 | +104.3 | 92.7 | 12.8 | 1.8 | +128.1 | 69.1 | 47.4 |
| SET-UP ANY TARGET | 0.7 | +145.5 | 4.3 | 0.0 | 0.2 | +15.8 | 0.0 | 7.8 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.7 | 0.0 | 0.0 | 0.1 | +0.2 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.1 | +59.0 | 62.0 | 31.7 | 0.7 | +14.2 | 4.8 | 13.1 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OPTIONS | 16.0 | +0.0 | 783.7 | 287.1 | 10.3 | +0.0 | 380.6 | 135.2 |
| SHOT REPLANNED | 0.6 | +0.0 | 108.1 | 11.8 | 0.2 | +0.0 | 19.3 | 0.0 |
| SHOTS IN THE MOVE | 15.1 | +572.9 | 0.0 | 246.3 | 9.4 | +291.5 | 0.0 | 129.3 |
| SPELL CATCH ODDS | 0.1 | -0.9 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.7 | +159.7 | 15.9 | 13.5 | 0.2 | +15.8 | 0.0 | 7.8 |
| SPELL WORTH | 1.1 | +22.1 | 40.1 | 42.7 | 1.9 | +25.1 | 112.8 | 98.7 |
| STABLE ROLE | 9.9 | +0.0 | 339.3 | 124.9 | 7.8 | +0.0 | 355.6 | 148.5 |
| STAY WEIGHED | - | - | - | - | 0.0 | +0.5 | 0.0 | 4.8 |
| STAY WORTH | 19.0 | +350.0 | 615.5 | 209.6 | - | - | - | - |
| STOPS | 0.2 | +5.1 | 0.0 | 0.0 | 0.1 | +2.5 | 4.2 | 5.9 |
| STOPS SHORT OF THE FLANK | 0.5 | +23.7 | 0.0 | 31.7 | 0.3 | +25.4 | 0.0 | 5.9 |
| STUCK PIVOT | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 5.1 | -34.8 | 311.1 | 111.1 | 6.4 | -39.2 | 458.1 | 111.9 |
| SUPPORTS | 3.0 | +46.5 | 127.5 | 62.0 | 3.7 | +40.2 | 188.7 | 38.1 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -11.3 | 12.4 | 11.7 | 0.1 | -8.2 | 0.0 | 9.1 |
| SURE REACH TOGETHER | 0.3 | +1.0 | 0.0 | 0.0 | 1.0 | +11.5 | 0.0 | 29.4 |
| THREAT IN THE KILL | 13.7 | +200.3 | 1010.9 | 321.3 | - | - | - | - |
| THREAT OVER THE TURNS | 11.0 | +154.6 | 912.4 | 264.8 | - | - | - | - |
| THREAT TO WORN DOWN | 13.1 | +184.5 | 986.7 | 321.3 | - | - | - | - |
| THROUGH LINE OF FIRE | 0.3 | +17.7 | 0.0 | 0.0 | 0.3 | +11.7 | 0.0 | 0.0 |
| TURN WORTH | 0.8 | -61.4 | 84.4 | 6.8 | 0.3 | -22.0 | 23.2 | 12.3 |
| TWO OR MORE ARRIVE | 0.4 | +3.1 | 39.5 | 1.5 | 0.7 | +8.9 | 12.1 | 20.8 |
| WAIT AFTER COSTS | 6.3 | -254.1 | 310.7 | 70.5 | 8.1 | -416.5 | 320.9 | 191.1 |
| WALKS TO THE FIGHT | 1.8 | +38.6 | 65.0 | 15.1 | 0.9 | +12.6 | 27.8 | 11.1 |
| WAR ENGINE CHARGES | 0.2 | +27.2 | 13.6 | 16.5 | 0.0 | +3.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.6 | +0.0 | 40.5 | 23.2 | 0.2 | +0.0 | 2.8 | 0.0 |
| WEARS DOWN | 0.7 | +30.7 | 99.9 | 14.7 | 1.6 | +54.9 | 119.1 | 83.1 |
| WHO HITS BACK | 0.2 | +17.5 | 0.0 | 0.0 | 0.3 | +29.0 | 0.0 | 19.1 |
| WHOLE FIGHT | 0.3 | +13.9 | 87.9 | 6.8 | 0.7 | +22.3 | 112.2 | 14.9 |
| WHOLE FIGHT GAIN | 0.2 | +23.9 | 18.9 | 0.0 | 0.6 | +63.4 | 72.0 | 1.0 |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 3.6 | 9.2 | 0.1 | +0.0 | 3.2 | 4.2 |

### Rule changes: tk-h2h-mine-949ddcd-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 884 | 884 | 884 | 29.47 | -47860 | -54.1 |
| BEST FIRST | 215 | 215 | 215 | 7.17 | +10104 | +47.0 |
| SEARCH SPOT | 144 | 144 | 143 | 4.77 | +7489 | +52.4 |
| MOVE TO CHARGE | 243 | 243 | 124 | 4.13 | +7396 | +59.6 |
| PATHS CROSS | 121 | 121 | 121 | 4.03 | +8700 | +71.9 |
| COUNTER-CHARGE COVER | 495 | 266 | 108 | 3.60 | +8469 | +78.4 |
| KILLS COUNT NEXT TURN | 356 | 356 | 86 | 2.87 | +1941 | +22.6 |
| FOLLOW UP WEIGHED | 80 | 80 | 80 | 2.67 | +14792 | +184.9 |
| FACES THE THREAT | 79 | 79 | 79 | 2.63 | +5841 | +73.9 |
| SUPPORTS | 201 | 201 | 75 | 2.50 | +631 | +8.4 |
| ARTILLERY RE-ROLL WEIGHED | 74 | 74 | 74 | 2.47 | +0 | +0.0 |
| SHOTS IN THE MOVE | 735 | 477 | 62 | 2.07 | +1382 | +22.3 |
| FALLBACK BY WORTH | 280 | 280 | 58 | 1.93 | +3078 | +53.1 |
| CANNON SIGHT KEPT | 57 | 57 | 57 | 1.90 | +0 | +0.0 |
| WAIT AFTER COSTS | 431 | 431 | 56 | 1.87 | +963 | +17.2 |
| WALKS TO THE FIGHT | 82 | 82 | 46 | 1.53 | +566 | +12.3 |
| CANNON PLANNED TARGET | 254 | 254 | 44 | 1.47 | -32 | -0.7 |
| MISSILES IN THE MOVE | 259 | 155 | 43 | 1.43 | +1515 | +35.2 |
| SAFER THAN THE JOB | 43 | 43 | 43 | 1.43 | +3655 | +85.0 |
| BEST FACING | 41 | 41 | 41 | 1.37 | +2157 | +52.6 |
| CHARGE NOW FIRST | 194 | 194 | 40 | 1.33 | -2942 | -73.5 |
| MAX FOR POSITIONING | 280 | 162 | 40 | 1.33 | +468 | +11.7 |
| SET UP TOGETHER | 88 | 76 | 40 | 1.33 | +1994 | +49.9 |
| BEST MOVE FOR SHOOTERS | 37 | 37 | 37 | 1.23 | +3354 | +90.6 |
| RISK BY ARC | 176 | 169 | 37 | 1.23 | +1274 | +34.4 |
| RESERVE FALL BACK | 36 | 36 | 36 | 1.20 | +705 | +19.6 |
| MOVE AND CAST | 35 | 35 | 35 | 1.17 | +1959 | +56.0 |
| MARCH CHECK | 41 | 38 | 33 | 1.10 | +2539 | +76.9 |
| BEST OVERALL | 32 | 32 | 32 | 1.07 | +1727 | +54.0 |
| CHARGE NOW WEIGHED | 31 | 31 | 31 | 1.03 | +1393 | +44.9 |
| HOLDS AMBUSHERS | 30 | 30 | 30 | 1.00 | +0 | +0.0 |
| CAST JOB | 62 | 62 | 29 | 0.97 | +627 | +21.6 |
| LONE WIZARD KEPT IN | 29 | 29 | 29 | 0.97 | +2178 | +75.1 |
| REDIRECT COUNTER | 164 | 84 | 29 | 0.97 | +2166 | +74.7 |
| ADVANCE LANE KEPT | 27 | 27 | 27 | 0.90 | +0 | +0.0 |
| COMBAT PIVOT | 27 | 27 | 27 | 0.90 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 65 | 65 | 27 | 0.90 | +493 | +18.3 |
| SHOOTS FROM THE BEST SPOT | 55 | 55 | 27 | 0.90 | +732 | +27.1 |
| SHOT REPLANNED | 24 | 24 | 24 | 0.80 | +0 | +0.0 |
| STAY WORTH | 571 | 471 | 24 | 0.80 | +683 | +28.5 |
| STOPS SHORT OF THE FLANK | 24 | 24 | 24 | 0.80 | +1473 | +61.4 |
| THREAT TO WORN DOWN | 393 | 304 | 24 | 0.80 | +190 | +7.9 |
| KILLS COUNT | 120 | 116 | 23 | 0.77 | +1152 | +50.1 |
| MARCH ODDS | 23 | 23 | 23 | 0.77 | +238 | +10.4 |
| BLOCKED WHEEL | 22 | 22 | 22 | 0.73 | +536 | +24.4 |
| KEEPS ITS TARGET | 123 | 120 | 22 | 0.73 | +424 | +19.3 |
| INVITES THE FIGHT | 75 | 75 | 20 | 0.67 | +291 | +14.5 |
| SCOUT WAITS | 19 | 19 | 19 | 0.63 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 19 | 19 | 19 | 0.63 | +884 | +46.5 |
| MAKE SURE TOGETHER | 49 | 36 | 18 | 0.60 | +916 | +50.9 |
| SHOOTERS IN TWO RANKS | 16 | 16 | 16 | 0.53 | +27 | +1.7 |
| FOCUS OVER TURNS | 42 | 42 | 15 | 0.50 | +312 | +20.8 |
| REDIRECT WEIGHED | 14 | 14 | 14 | 0.47 | +166 | +11.9 |
| WHO HITS BACK | 14 | 14 | 14 | 0.47 | +1006 | +71.9 |
| BEST PREY | 43 | 43 | 13 | 0.43 | +680 | +52.3 |
| THREAT IN THE KILL | 412 | 322 | 13 | 0.43 | +60 | +4.7 |
| BIG CHARACTER SAFETY | 11 | 11 | 11 | 0.37 | -45 | -4.1 |
| FRIENDS SHOTS CHECKED | 11 | 11 | 11 | 0.37 | +512 | +46.6 |
| THREAT OVER THE TURNS | 329 | 259 | 11 | 0.37 | +55 | +5.0 |
| WAR ENGINE JOBS | 24 | 24 | 11 | 0.37 | -440 | -40.0 |
| MANOEUVRE | 10 | 10 | 10 | 0.33 | +367 | +36.7 |
| WHOLE FIGHT GAIN | 23 | 21 | 10 | 0.33 | +467 | +46.7 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.30 | +0 | +0.0 |
| PURSUES BIG PREY | 9 | 9 | 9 | 0.30 | -409 | -45.4 |
| WEARS DOWN | 68 | 64 | 9 | 0.30 | +325 | +36.1 |
| LONE WIZARD HOLDS BACK | 14 | 14 | 7 | 0.23 | -241 | -34.4 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.23 | +141 | +20.1 |
| OPENS UP | 15 | 14 | 7 | 0.23 | +449 | +64.1 |
| SURE CHARGE BEATS ADVANCE | 7 | 7 | 7 | 0.23 | -586 | -83.7 |
| CASTS FROM BEHIND | 6 | 6 | 6 | 0.20 | +0 | +0.0 |
| HUNT IN PAIRS | 31 | 20 | 6 | 0.20 | +201 | +33.4 |
| STUCK PIVOT | 6 | 6 | 6 | 0.20 | +0 | +0.0 |
| SURE REACH TOGETHER | 39 | 31 | 6 | 0.20 | +51 | +8.5 |
| WHOLE FIGHT | 30 | 30 | 6 | 0.20 | +346 | +57.6 |
| CARRIES OUT SET-UP | 13 | 13 | 5 | 0.17 | -472 | -94.5 |
| CASTING BLOCK | 8 | 8 | 5 | 0.17 | +232 | +46.5 |
| LOST CHARGE | 165 | 164 | 5 | 0.17 | +175 | +35.0 |
| MODEL FACING | 5 | 5 | 5 | 0.17 | +1036 | +207.1 |
| RAIDS THE BAGGAGE NEXT TURN | 5 | 5 | 5 | 0.17 | +116 | +23.2 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.17 | +0 | +0.0 |
| BLOCKED CHARGE SKIPPED | 4 | 4 | 4 | 0.13 | +0 | +0.0 |
| PIVOT GUARDS FLANK | 4 | 4 | 4 | 0.13 | -52 | -13.1 |
| SUPPORT NARROWED | 346 | 346 | 4 | 0.13 | -90 | -22.5 |
| WAR ENGINE CHARGES | 7 | 7 | 4 | 0.13 | +583 | +145.7 |
| BEST PRIZE | 3 | 3 | 3 | 0.10 | -303 | -101.0 |
| EDGE GIVE GROUND | 11 | 11 | 3 | 0.10 | +491 | +163.7 |
| FOCUS FIRE | 3 | 3 | 3 | 0.10 | +146 | +48.5 |
| KEEP FALLS | 3 | 3 | 3 | 0.10 | +69 | +23.1 |
| MISSILES NEXT TURN | 319 | 181 | 3 | 0.10 | +62 | +20.8 |
| OVERRUNS AWAY | 33 | 30 | 3 | 0.10 | +525 | +175.1 |
| RESTRAINS TO SHOOT | 3 | 3 | 3 | 0.10 | +69 | +23.1 |
| WOUNDED STAYS OUT | 3 | 3 | 3 | 0.10 | -106 | -35.5 |
| CHAFF PASSED | 2 | 2 | 2 | 0.07 | -0 | -0.2 |
| CHARIOT NO STATIC JOB | 2 | 2 | 2 | 0.07 | -92 | -46.1 |
| HUNT ADVANCE | 6 | 6 | 2 | 0.07 | +61 | +30.3 |
| TWO OR MORE ARRIVE | 34 | 26 | 2 | 0.07 | +16 | +8.2 |
| BACKUP TARGETS | 48 | 20 | 1 | 0.03 | +1 | +0.9 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +9 | +9.2 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.1 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -1 | -1.4 |
| DEFENSIVE ARMY | 5 | 5 | 1 | 0.03 | -45 | -45.4 |
| DEFENSIVE FLOOR | 1 | 1 | 1 | 0.03 | +3 | +2.6 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +2 | +2.3 |
| FACE THE CAST | 1 | 1 | 1 | 0.03 | +6 | +5.8 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +15 | +15.1 |
| HILL BY ITS CHANCE | 20 | 20 | 1 | 0.03 | +32 | +32.1 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| LONG SHOT | 22 | 21 | 1 | 0.03 | +46 | +45.6 |
| MISSILES IN THE PLAN | 24 | 1 | 1 | 0.03 | +22 | +21.7 |
| NEEDED THERE | 3 | 3 | 1 | 0.03 | +0 | +0.0 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +0 | +0.3 |
| OPENS A LANE | 21 | 16 | 1 | 0.03 | +19 | +18.7 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +122 | +121.9 |
| RAIDS THE BAGGAGE | 2 | 2 | 1 | 0.03 | +173 | +173.1 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +15 | +15.0 |
| STOPS | 9 | 9 | 1 | 0.03 | +8 | +8.1 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 32 | 32 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 3 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 33 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 6 | 6 | 0 | 0.00 | - | - |
| CHEAP HELPER | 4 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 39 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 255 | not checked | - | - | - | - |
| GIVES UP | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 3 | 3 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 17 | 15 | 0 | 0.00 | - | - |
| HUNT DROPPED | 2 | trace | - | - | - | - |
| HUNT KEPT | 10 | trace | - | - | - | - |
| HUNT RESULT | 7 | trace | - | - | - | - |
| HUNT THE GUNS | 8 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 9 | 9 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 26 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 6 | trace | - | - | - | - |
| MARCH OVER CASTS | 31 | 31 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 12 | 12 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 7 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 24 | trace | - | - | - | - |
| MOVE SPELL SPOT | 17 | not checked | - | - | - | - |
| NOT NEEDED | 25 | 25 | 0 | 0.00 | - | - |
| NOT TURNED | 264 | 264 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 45 | not checked | - | - | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 2208 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 22 | 22 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 13 | 13 | 0 | 0.00 | - | - |
| SCOUT SPOT | 18 | 18 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 13 | 13 | 0 | 0.00 | - | - |
| SECOND HUNTER | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 22 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 25 | not checked | - | - | - | - |
| SHOT OPTIONS | 789 | 789 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 2 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 26 | not checked | - | - | - | - |
| SPELL WORTH | 92 | not checked | - | - | - | - |
| STABLE ROLE | 532 | 530 | 0 | 0.00 | - | - |
| TURN WORTH | 31 | 29 | 0 | 0.00 | - | - |

### Off best figure: tk-h2h-mine-949ddcd-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.33 | 12.70 | 56.4 |
| CHARGE NOW FIRST | rule | 0.63 | 0.67 | 75.4 |
| TURN GATE | gate | 0.53 | 0.70 | 47.1 |
| FALLBACK | gate | 0.47 | 0.67 | 33.8 |
| LONE CHARACTER SAFE SPOT | gate | 0.30 | 0.17 | 40.4 |
| WAR ENGINE JOBS | rule | 0.27 | 0.10 | 40.0 |
| AFTERMATH BAND | gate | 0.20 | 0.13 | 2.5 |
| PURSUES BIG PREY | rule | 0.10 | 0.17 | 54.3 |
| CANNON PLANNED TARGET | rule | 0.13 | 0.10 | 71.5 |
| CHARGE NOW WEIGHED | rule | 0.03 | 0.20 | 42.2 |
| SURE CHARGE BEATS ADVANCE | rule | 0.10 | 0.13 | 83.7 |
| BIG CHARACTER SAFETY | rule | 0.10 | 0.10 | 13.7 |
| CARRIES OUT SET-UP | rule | 0.13 | 0.03 | 94.5 |
| LONE WIZARD HOLDS BACK | rule | 0.03 | 0.13 | 48.2 |
| PATHS CROSS | rule | 0.03 | 0.13 | 42.8 |
| PIVOT GUARDS FLANK | rule | 0.03 | 0.10 | 13.1 |
| SUPPORT NARROWED | rule | 0.07 | 0.07 | 22.5 |
| SUPPORT REQUEST | gate | - | 0.13 | 87.3 |
| BEST PRIZE | rule | 0.07 | 0.03 | 101.0 |
| BLOCKED WHEEL | rule | 0.03 | 0.07 | 29.4 |
| MARCH ODDS | rule | 0.03 | 0.07 | 11.6 |
| SAFER THAN THE JOB | rule | 0.03 | 0.07 | 11.1 |
| WOUNDED STAYS OUT | rule | 0.03 | 0.07 | 35.5 |
| CHARIOT NO STATIC JOB | rule | 0.07 | - | 46.1 |
| FACES THE THREAT | rule | 0.03 | 0.03 | 9.6 |
| FIGHT ORDER BAND | gate | 0.07 | - | 1.9 |
| THROUGH LINE OF FIRE | rule | 0.03 | 0.03 | 51.1 |
| CATCH ODDS | rule | 0.03 | - | 1.4 |
| DEFENSIVE ARMY | rule | - | 0.03 | 45.4 |
| FOLLOW UP WEIGHED | rule | 0.03 | - | 4.9 |
| MOVE AND CAST | rule | 0.03 | - | 36.5 |
| NO REASON | gate | 0.03 | - | 0.5 |
| REDIRECT WEIGHED | rule | - | 0.03 | 142.0 |
| RULE SWITCHED OFF | gate | - | 0.03 | 3.7 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | - | 29.3 |
| WHO HITS BACK | rule | - | 0.03 | 2.7 |

### Plans: tk-h2h-mine-949ddcd-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 10.7 | 19% | 387 | 327 | 84% |
| Mine | charge | 2.9 | 55% | 255 | 241 | 94% |
| Mine | close in | 4.2 | 33% | 343 | 145 | 42% |
| Mine | hold | 4.5 | 37% | 288 | 0 | 0% |
| Mine | join | 0.4 | 92% | 9 | 0 | 0% |
| Mine | shoot | 10.6 | 61% | 726 | 807 | 111% |
| Mine | support | 3.2 | 94% | 34 | 0 | 0% |
| Opponent | advance | 11.9 | 19% | 405 | 287 | 71% |
| Opponent | charge | 4.8 | 55% | 596 | 465 | 78% |
| Opponent | close in | 5.9 | 27% | 407 | 183 | 45% |
| Opponent | hold | 3.8 | 25% | 285 | 0 | 0% |
| Opponent | join | 0.8 | 92% | 30 | 0 | 0% |
| Opponent | shoot | 5.6 | 57% | 105 | 284 | 270% |
| Opponent | support | 4.2 | 89% | 27 | 0 | 0% |

### Packages: hunt the guns, tk-h2h-mine-949ddcd-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 3 | 1 | 0% | 0% | 0% | - | 448 | 0 | 0% | 36 |
| Opponent | 0.2 | 5 | 0 | 40% | 20% | 0% | 2.0 | 294 | 49 | 20% | 93 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.8 | 3 | 1 | 0% | 0% | 0% | - | 448 | 0 | 0% | 26 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 58 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 32 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 47 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 65 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 81 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 217 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 155 |
| Tomb Kings of Khemri | 1.3 | 4 | 0 | 50% | 25% | 0% | 2.0 | 292 | 61 | 25% | 89 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 24 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 89 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 299 | 0 | 0% | 26 |

### Battle groups: tk-h2h-mine-949ddcd-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.6 | 22% | 58% | 9% | 17% | 43% | 17% | 5% | 34% | 0% |
| Mine | REDIRECT COUNTER | 1.8 | 38% | 71% | 0% | - | 24% | 0% | 19% | 52% | 5% |
| Opponent | COUNTER-CHARGE COVER | 6.9 | 19% | 64% | 13% | 80% | 35% | 9% | 24% | 32% | 0% |
| Opponent | REDIRECT COUNTER | 3.6 | 24% | 62% | 19% | 40% | 29% | 10% | 14% | 48% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: tk-h2h-mine-949ddcd-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 160 (1) | 160 | 0 | 100 | 0% | 4.0 | - | 160 (1) | - | - | 160 (1) |
| Mine | Chaff | 24 | 67 (24) | 22 | 46 | 53 | 25% | 2.9 | 85 (15) | 11 (4) | 46 (5) | 100 (17) | 0 (7) |
| Mine | Character | 106 | 56 (106) | 54 | 2 | 40 | 12% | 2.5 | 64 (32) | 65 (48) | 21 (6) | 59 (49) | 68 (37) |
| Mine | Clean-up | 15 | 51 (15) | 18 | 33 | 27 | 40% | 3.1 | 42 (4) | 60 (9) | 21 (2) | 48 (9) | 54 (6) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 37 | 53 (37) | 30 | 23 | 50 | 19% | 3.4 | 44 (16) | 64 (17) | 51 (4) | 71 (27) | 19 (10) |
| Mine | Fragile | 3 | 0 (3) | 0 | 0 | 33 | 0% | 5.0 | 0 (3) | - | - | 0 (1) | 0 (2) |
| Mine | Hammer | 46 | 48 (46) | 39 | 9 | 40 | 11% | 2.4 | 29 (10) | 54 (32) | 49 (4) | 44 (30) | 55 (16) |
| Mine | Holder | 17 | 66 (17) | 27 | 39 | 35 | 47% | 4.2 | 40 (7) | 50 (8) | 257 (2) | 102 (9) | 14 (8) |
| Mine | Shooter | 35 | 43 (35) | 12 | 30 | 50 | 3% | 1.8 | 8 (5) | 54 (27) | 0 (2) | 51 (21) | 32 (13) |
| Mine | Support | 4 | 80 (4) | 80 | 0 | 58 | 25% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | War machine | 52 | 43 (52) | 43 | 0 | 40 | 2% | 1.1 | 53 (13) | 42 (35) | 11 (4) | 17 (13) | 52 (39) |
| Mine | Wizard | 11 | 20 (11) | 20 | 0 | 53 | 9% | 2.4 | 0 (2) | 33 (6) | - | 37 (5) | 0 (3) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 52 | 66 (52) | 38 | 27 | 54 | 40% | 2.9 | 99 (24) | 46 (8) | 42 (20) | 74 (37) | 48 (15) |
| Opponent | Character | 84 | 54 (84) | 54 | 0 | 39 | 15% | 2.4 | 50 (28) | 66 (43) | 35 (5) | 59 (42) | 58 (34) |
| Opponent | Clean-up | 10 | 45 (10) | 16 | 29 | 40 | 30% | 2.6 | 0 (4) | 53 (5) | 177 (1) | 37 (6) | 53 (4) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 44 | 54 (44) | 38 | 16 | 42 | 27% | 2.6 | 57 (19) | 40 (18) | 84 (7) | 77 (21) | 30 (23) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 67 | 33% | 3.0 | - | 0 (2) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Hammer | 40 | 49 (40) | 43 | 5 | 48 | 22% | 3.0 | 34 (15) | 52 (23) | 83 (2) | 67 (25) | 16 (15) |
| Opponent | Holder | 38 | 98 (38) | 21 | 77 | 35 | 29% | 2.9 | 69 (7) | 112 (21) | 90 (10) | 124 (27) | 47 (11) |
| Opponent | Shooter | 23 | 20 (23) | 13 | 7 | 52 | 4% | 1.2 | 26 (7) | 9 (14) | 115 (2) | 21 (15) | 20 (8) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 40 | 67% | 4.0 | - | 0 (1) | 0 (2) | 0 (2) | 0 (1) |
| Opponent | War machine | 17 | 53 (17) | 53 | 0 | 32 | 6% | 1.2 | 75 (3) | 59 (10) | 26 (4) | 0 (3) | 62 (14) |
| Opponent | Wizard | 28 | 8 (28) | 8 | 0 | 49 | 25% | 1.8 | 9 (11) | 14 (8) | 0 (2) | 10 (12) | 10 (9) |

### Charged fights: tk-h2h-mine-949ddcd-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 83 | 130 | 1.0 | 1.2 | 130 | 0 | +130 | 1 of 4 | 4 of 4 | +40 | +160 |
| Mine | Chaos Dwarfs | 4 | 282 | 456 | 3.2 | 1.1 | 140 | 39 | +101 | 8 of 13 | 8 of 13 | +924 | +33 |
| Mine | Dwarfen Mountain Holds | 3 | 534 | 0 | 0.7 | 1.0 | 0 | 82 | -82 | 0 of 2 | 1 of 2 | - | -82 |
| Mine | Empire of Man | 5 | 383 | 158 | 1.8 | 1.0 | 88 | 34 | +54 | 2 of 9 | 8 of 9 | - | +54 |
| Mine | Grand Cathay | 5 | 339 | 462 | 3.6 | 1.1 | 128 | 11 | +117 | 4 of 18 | 15 of 18 | +173 | +114 |
| Mine | High Elf Realms | 4 | 148 | 445 | 3.8 | 1.0 | 119 | 42 | +77 | 6 of 15 | 11 of 15 | - | +77 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 1161 | 5.0 | 1.2 | 232 | 55 | +177 | 1 of 5 | 4 of 5 | +141 | +186 |
| Mine | Lizardmen | 1 | 116 | 1491 | 7.0 | 1.1 | 213 | 26 | +187 | 2 of 7 | 5 of 7 | +144 | +194 |
| Mine | Ogre Kingdoms | 1 | 116 | 144 | 5.0 | 1.0 | 29 | 109 | -80 | 2 of 5 | 2 of 5 | - | -80 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 137 | 4.0 | 1.0 | 34 | 28 | +7 | 0 of 4 | 3 of 4 | - | +7 |
| Mine | Skaven | 1 | 0 | 19 | 2.0 | 1.0 | 10 | 0 | +10 | 0 of 2 | 2 of 2 | - | +10 |
| **Mine** | all armies | 30 | 250 | 339 | 2.8 | 1.1 | 121 | 35 | +86 | 26 of 84 | 63 of 84 | +284 | +74 |
| Opponent | Empire of Man | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 3 | 232 | 272 | 4.0 | 1.3 | 68 | 62 | +7 | 4 of 12 | 9 of 12 | +29 | -5 |
| Opponent | High Elf Realms | 3 | 183 | 423 | 3.0 | 1.0 | 141 | 69 | +72 | 5 of 9 | 5 of 9 | - | +72 |
| Opponent | Kingdom of Bretonnia | 2 | 130 | 532 | 3.0 | 1.2 | 178 | 0 | +178 | 2 of 6 | 4 of 6 | +194 | +174 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 561 | 5.0 | 1.6 | 112 | 0 | +112 | 1 of 5 | 5 of 5 | +151 | +86 |
| Opponent | Skaven | 1 | 0 | 186 | 2.0 | 1.0 | 93 | 0 | +93 | 2 of 2 | 2 of 2 | - | +93 |
| Opponent | Tomb Kings of Khemri | 3 | 97 | 856 | 3.7 | 1.1 | 233 | 87 | +147 | 7 of 11 | 5 of 11 | +500 | +111 |
| Opponent | Vampire Counts | 5 | 40 | 887 | 4.6 | 1.2 | 193 | 69 | +124 | 12 of 23 | 11 of 23 | +100 | +129 |
| Opponent | Warriors of Chaos | 7 | 0 | 658 | 3.3 | 1.3 | 200 | 23 | +178 | 13 of 23 | 18 of 23 | +302 | +134 |
| Opponent | Wood Elf Realms | 4 | 124 | 181 | 2.2 | 1.0 | 81 | 131 | -50 | 4 of 9 | 3 of 9 | - | -50 |
| **Opponent** | all armies | 30 | 83 | 541 | 3.3 | 1.2 | 162 | 56 | +106 | 50 of 100 | 62 of 100 | +185 | +89 |

### Effective charges: tk-h2h-mine-949ddcd-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 1 (net +0) | 0 | 0 | 0 | 0 | 2 (net +237) | 1 | 0% (0 of 3) |
| Mine | Chaos Dwarfs | 13 | 1 (net +0) | 0 | 2 (net -56) | 4 (net -6) | 0 | 6 (net +242) | 0 | 15% (2 of 13) |
| Mine | Dwarfen Mountain Holds | 2 | 1 (net -165) | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 2) |
| Mine | Empire of Man | 9 | 1 (net +211) | 0 | 1 (net +0) | 3 (net -38) | 0 | 3 (net +23) | 1 | 12% (1 of 8) |
| Mine | Grand Cathay | 18 | 1 (net +0) | 1 (net +280) | 2 (net +22) | 1 (net +151) | 4 (net +74) | 7 (net +160) | 2 | 12% (2 of 16) |
| Mine | High Elf Realms | 15 | 2 (net +256) | 0 | 0 | 2 (net +52) | 2 (net +108) | 5 (net +32) | 4 | 0% (0 of 11) |
| Mine | Kingdom of Bretonnia | 5 | 1 (net +190) | 0 | 0 | 0 | 0 | 4 (net +174) | 0 | 0% (0 of 5) |
| Mine | Lizardmen | 7 | 0 | 0 | 1 (net +662) | 1 (net +0) | 0 | 3 (net +91) | 2 | 20% (1 of 5) |
| Mine | Ogre Kingdoms | 5 | 0 | 0 | 1 (net +0) | 0 | 0 | 1 (net +144) | 3 | 50% (1 of 2) |
| Mine | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 0 | 0 | 2 (net +14) | 2 | 0% (0 of 2) |
| Mine | Skaven | 2 | 0 | 0 | 1 (net +19) | 0 | 1 (net +0) | 0 | 0 | 50% (1 of 2) |
| Opponent | Grand Cathay | 12 | 2 (net -7) | 0 | 2 (net -57) | 2 (net +65) | 2 (net +0) | 3 (net +26) | 1 | 18% (2 of 11) |
| Opponent | High Elf Realms | 9 | 3 (net +98) | 0 | 1 (net -347) | 3 (net +116) | 1 (net +390) | 1 (net -39) | 0 | 11% (1 of 9) |
| Opponent | Kingdom of Bretonnia | 6 | 2 (net +253) | 1 (net +160) | 1 (net +194) | 1 (net +205) | 1 (net +0) | 0 | 0 | 17% (1 of 6) |
| Opponent | Orc & Goblin Tribes | 5 | 0 | 0 | 1 (net +0) | 1 (net +199) | 0 | 0 | 3 | 50% (1 of 2) |
| Opponent | Skaven | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +93) | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 11 | 1 (net +296) | 0 | 2 (net +366) | 2 (net +125) | 1 (net +125) | 4 (net +101) | 1 | 20% (2 of 10) |
| Opponent | Vampire Counts | 23 | 6 (net +182) | 1 (net +902) | 5 (net +88) | 3 (net +60) | 2 (net -80) | 5 (net +111) | 1 | 23% (5 of 22) |
| Opponent | Warriors of Chaos | 23 | 1 (net -30) | 1 (net -144) | 2 (net +232) | 3 (net +143) | 0 | 15 (net +224) | 1 | 9% (2 of 22) |
| Opponent | Wood Elf Realms | 9 | 1 (net +0) | 0 | 1 (net +126) | 1 (net +482) | 0 | 2 (net -232) | 4 | 20% (1 of 5) |

### Charged fights, damage counted: tk-h2h-mine-949ddcd-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 8 | 262 | 278 | +93 | 118 | 81 | +37 | +14.2 |
| Mine | 50-54% | 1 | 334 | 230 | +280 | 280 | 0 | +280 | +83.8 |
| Mine | Effective (55-75%) | 8 | 199 | 169 | +77 | 149 | 66 | +83 | +41.6 |
| Mine | 76-89% | 11 | 300 | 186 | +10 | 83 | 79 | +3 | +1.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 34 | 290 | 200 | +130 | 186 | 52 | +134 | +46.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 409 | 86 | +73 | 73 | 0 | +73 | +18.0 |
| Mine | No odds | 15 | 268 | 133 | +38 | 99 | 51 | +48 | +17.7 |
| Mine | All fights | 84 | 286 | 182 | +86 | 139 | 55 | +84 | +29.4 |
| Opponent | Long shot (under 50%) | 16 | 289 | 257 | +134 | 168 | 58 | +110 | +38.0 |
| Opponent | 50-54% | 3 | 306 | 227 | +306 | 354 | 48 | +306 | +100.0 |
| Opponent | Effective (55-75%) | 15 | 262 | 222 | +100 | 194 | 120 | +73 | +28.0 |
| Opponent | 76-89% | 16 | 316 | 243 | +139 | 175 | 52 | +123 | +38.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 32 | 351 | 235 | +128 | 215 | 66 | +149 | +42.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 434 | 91 | +51 | 126 | 47 | +79 | +18.3 |
| Opponent | No odds | 11 | 243 | 226 | -54 | 116 | 153 | -37 | -15.3 |
| Opponent | All fights | 100 | 315 | 227 | +106 | 185 | 78 | +107 | +33.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| tk-h2h-mine-949ddcd-p3 | move | 369 | 87 (24%) | 65 (18%) | 48 (13%) | 234 (63%) |
| tk-h2h-mine-949ddcd-p3 | objective | 303 | 56 (18%) | 39 (13%) | 38 (13%) | 209 (69%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

# Doctrine scorecard: tk-h2h-mine-949ddcd-p4

### Scorecard: tk-h2h-mine-949ddcd-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 7 | - | 0 | 1 | 1 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 13 | 1 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | yes | 10 | - | 0 | 1 | 0 | 0 | 0 | 65 |
| L0130 | 4 | 1 | Opponent | no | 2 | 1 | 8 | 1 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | no | 0 | - | 1 | 3 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Opponent | no | 2 | 2 | 3 | 0 | 0 | 0 | 0 | 177 |
| L0230 | 2 | 1 | Mine | - | - | 3 | 4 | 3 | 0 | 0 | 0 | 170 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | no | 0 | - | 1 | 0 | 0 | 0 | 0 | 590 |
| L0315 | 3 | 1 | Opponent | yes | 10 | 2 | 1 | 2 | 1 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | 4 | 1 | 1 | 1 | 0 | 0 | 590 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 3 | 7 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | yes | 1 | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 0 | 2 | 7 | 0 | 1 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Mine | - | - | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 548 |
| L0520 | 4 | 1 | Opponent | no | 0 | - | 0 | 6 | 2 | 0 | 0 | 210 |
| L0608 | 2 | 1 | Mine | - | - | 6 | 1 | 2 | 0 | 0 | 0 | 906 |
| L0608 | 2 | 1 | Opponent | - | - | 4 | 1 | 2 | 0 | 0 | 0 | 605 |
| L0624 | 6 | 1 | Mine | no | 5 | 3 | 2 | 0 | 0 | 0 | 0 | 1086 |
| L0624 | 6 | 1 | Opponent | no | 7 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | no | - | 5 | 4 | 1 | 1 | 0 | 0 | 420 |
| L0713 | 5 | 1 | Opponent | no | - | 2 | 4 | 0 | 1 | 0 | 0 | 140 |
| L0729 | 3 | 1 | Mine | no | 2 | 4 | 1 | 0 | 0 | 0 | 0 | 375 |
| L0729 | 3 | 1 | Opponent | no | 1 | 3 | 3 | 0 | 1 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 511 |
| L0819 | 3 | 1 | Opponent | no | 2 | 2 | 3 | 2 | 2 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 0 | - | 0 | 0 | 1 | 0 | 0 | 679 |
| L0835 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | 3 | 1 | 3 | 0 | 0 | 0 | 908 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | no | 0 | 2 | 2 | 0 | 2 | 0 | 0 | 330 |
| L1017 | 3 | 1 | Opponent | yes | 7 | 2 | 2 | 0 | 1 | 0 | 0 | 273 |
| L1034 | 2 | 1 | Mine | - | - | 1 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1126 | 4 | 1 | Mine | no | 0 | - | 0 | 0 | 1 | 0 | 0 | 330 |
| L1126 | 4 | 1 | Opponent | no | 4 | 2 | 10 | 3 | 1 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 3 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 5 | 3 | 0 | 0 | 0 | 472 |
| L1314 | 6 | 1 | Mine | no | 10 | 2 | 4 | 0 | 1 | 0 | 0 | 140 |
| L1314 | 6 | 1 | Opponent | no | 3 | 1 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1331 | 5 | 1 | Mine | no | - | 6 | 1 | 3 | 0 | 0 | 0 | 140 |
| L1331 | 5 | 1 | Opponent | yes | - | - | 1 | 3 | 2 | 0 | 0 | 340 |
| L1427 | 5 | 1 | Mine | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | yes | - | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | yes | - | 2 | 8 | 0 | 1 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 3 | 3 | 2 | 1 | 0 | 0 | 251 |
| L1621 | 1 | 1 | Mine | no | 1 | 2 | 6 | 0 | 0 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 0 | - | 3 | 3 | 0 | 0 | 0 | 500 |
| L1719 | 3 | 1 | Mine | no | 0 | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Opponent | yes | 2 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Mine | no | 0 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | no | - | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | yes | - | 1 | 5 | 3 | 0 | 0 | 0 | 0 |
| L2021 | 5 | 1 | Mine | yes | - | - | 0 | 4 | 1 | 0 | 0 | 420 |
| L2021 | 5 | 1 | Opponent | yes | - | - | 0 | 5 | 0 | 0 | 0 | 355 |
| L2123 | 5 | 1 | Mine | yes | - | - | 1 | 4 | 1 | 0 | 0 | 290 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | no | 0 | 3 | 1 | 0 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | yes | 3 | 1 | 4 | 4 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Mine | no | 1 | 2 | 4 | 0 | 2 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Opponent | yes | 3 | 5 | 2 | 1 | 2 | 0 | 0 | 170 |
| L2527 | 1 | 1 | Mine | no | 0 | 3 | 1 | 0 | 0 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 0 | 1 | 4 | 1 | 1 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Mine | no | 7 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 3 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Mine | - | - | 2 | 6 | 0 | 1 | 0 | 0 | 323 |
| L2930 | 2 | 1 | Opponent | - | - | 2 | 6 | 3 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 3 | 2 | 3 | 2 | 0 | 0 | 0 | 170 |
| L3234 | 6 | 1 | Opponent | no | 0 | 2 | 1 | 3 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 21% | 2.2 | 2.8 | 2.6 | 1.0 | 0.4 | 0.0 | 0.0 | 273.6 |
| **Average** | | | Opponent | 43% | 3.0 | 2.0 | 3.6 | 1.8 | 0.5 | 0.0 | 0.0 | 101.8 |

### KPIs: tk-h2h-mine-949ddcd-p4

Rules off - Opponent only: STAY WORTH, BEST MOVE FOR SHOOTERS, THREAT IN THE KILL, FOCUS OVER TURNS, MISSILES IN THE PLAN, FACE THE CAST, WIZARD FRONT RANK, THREAT OVER THE TURNS, THREAT TO WORN DOWN.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 27% (46 of 173) | 1% (1 of 181) | 13% (47 of 354) |
| Winner chose to follow up after the loser gave ground |  | 97% (59 of 61); on the table 97% | 91% (60 of 66); on the table 94% | 94% (119 of 127); on the table 95% |
| Winner chose to pursue after the loser fell back in good order |  | 94% (15 of 16); on the table 94% | 79% (19 of 24); on the table 88% | 85% (34 of 40); on the table 90% |
| Winner chose to pursue after the loser fled |  | 74% (20 of 27); on the table 78% | 87% (26 of 30); on the table 87% | 81% (46 of 57); on the table 82% |
| Winner chose to follow up or pursue (all three) |  | 90% (94 of 104); on the table 91% | 88% (105 of 120); on the table 91% | 89% (199 of 224); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 32% (86 of 268) | 36% (62 of 172) | 34% (148 of 440) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 52% (86 of 166) | 49% (62 of 126) | 51% (148 of 292) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 31% (40 of 131) | 36% (32 of 88) | 33% (72 of 219) |
|     round 1 |  | 14% (3 of 22) | 33% (5 of 15) | 22% (8 of 37) |
|     rounds 2+ |  | 34% (37 of 109) | 37% (27 of 73) | 35% (64 of 182) |
|   other wizards | 50%+ | 34% (46 of 137) | 32% (26 of 80) | 33% (72 of 217) |
|     round 1 |  | 13% (3 of 23) | 29% (4 of 14) | 19% (7 of 37) |
|     rounds 2+ |  | 38% (43 of 114) | 33% (22 of 66) | 36% (65 of 180) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 47% (20 of 43) | 63% (39 of 62) | 56% (59 of 105) |
| Points that never fought | lower | 33% (22145 of 67942) | 35% (25319 of 71984) | 34% (47464 of 139926) |
|   infantry points that never fought | lower | 39% (6057 of 15347) | 58% (8025 of 13804) | 48% (14082 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 60% (162 of 270) | 54% (150 of 280) | 57% (312 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 91% (20 of 22); 1.6 uses a game | 89% (8 of 9); 0.6 uses a game | 90% (28 of 31); 1.1 uses a game |
| Bound items with another spell used |  | 31% (5 of 16); 0.4 uses a game | 50% (10 of 20); 0.4 uses a game | 42% (15 of 36); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 58% (11 of 19); 0.3 uses a game | 80% (12 of 15); 0.4 uses a game | 68% (23 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 55% (31542 of 57750) | 48% (30381 of 63347) | 51% (61923 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.1 (21%) | 1.1 (36%) | 2.2 (27%) |
| MARCHED: its unit marched | 1.1 (21%) | 0.4 (12%) | 1.4 (17%) |
| CHARGED: its unit charged | 0.1 (2%) | 0.1 (4%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 1.9 (38%) | 0.5 (17%) | 2.4 (30%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (5%) | 0.2 (2%) |
| FLEEING: fleeing | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.8 (15%) | 0.7 (24%) | 1.5 (18%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.0 (1%) | 0.1 (2%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.1 | 1.4 | 1.9 | 4.1 | 0.4 | 2.2 |
| not cast | 3.1 | 2.6 | 2.9 | 8.1 | 1.6 | 20.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.6 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (51%) | 0.2 (7%) | 2.2 (27%) | 0.4 (23%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (17%) | 0.3 (18%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (5%) | 0.2 (7%) | 0.8 (27%) | 2.4 (30%) | 0.5 (30%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (5%) | 0.2 (6%) | 0.2 (9%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (4%) | 0.1 (4%) | 0.1 (4%) | 0.0 (0%) | 0.0 (0%) | 0.5 (3%) |
| GONE: slain | 1.0 (31%) | 0.5 (20%) | 0.4 (12%) | 1.5 (18%) | 0.2 (12%) | 3.6 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.2 (1%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.2 (7%) | 0.0 (0%) | 0.0 (0%) | 0.2 (16%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.5 (49%) | 0.1 (3%) | 1.2 (42%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.5 (70%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.7 a game | 1.0 a game |
| stood (cast and not dispelled) | 70% (31 of 44) | 67% (10 of 15) | 69% (41 of 59) |
| the unit moved after it | 77% (24 of 31) | 70% (7 of 10) | 76% (31 of 41) |
| it charged on its next turn | 0% (0 of 31) | 0% (0 of 10) | 0% (0 of 41) |
| the enemy charged it first | 26% (8 of 31) | 0% (0 of 10) | 20% (8 of 41) |
| it fought by the end of its next turn | 26% (8 of 31) | 20% (2 of 10) | 24% (10 of 41) |
| it moved out of a charge the enemy had planned (not charged first) | 13% (4 of 31) | 0% (0 of 10) | 10% (4 of 41) |
| none of these (no charge, no fight, no charge escaped) | 48% (15 of 31) | 80% (8 of 10) | 56% (23 of 41) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (552 of 853) | 52% (277 of 537) | 60% (829 of 1390) |
|   cavalry | 67% (58 of 87) | 64% (75 of 117) | 65% (133 of 204) |
|   character | 44% (39 of 89) | 13% (18 of 135) | 25% (57 of 224) |
|   chariot | 50% (51 of 101) | 61% (11 of 18) | 52% (62 of 119) |
|   infantry | 62% (167 of 270) | 65% (142 of 217) | 63% (309 of 487) |
|   monster | 48% (21 of 44) | 32% (6 of 19) | 43% (27 of 63) |
|   war machine | 82% (216 of 262) | 81% (25 of 31) | 82% (241 of 293) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (24%) | 1.5 (21%) | 3.5 (22%) |
| CHARGED: it charged | 1.3 (15%) | 2.1 (29%) | 3.4 (22%) |
| FLEEING: it fled or was fleeing | 0.1 (2%) | 0.1 (2%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.8 (9%) | 0.5 (7%) | 1.3 (8%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.8 (22%) | 1.0 (14%) | 2.8 (18%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (6%) | 0.7 (10%) | 1.2 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (16%) | 1.1 (15%) | 2.5 (16%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.1 (2%) | 0.3 (2%) |
| OTHER BAR | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.9 | 1.4 | 80% | 5.1 pts | 30 pts |
| character | 1.9 | 0.6 | 77% | 6.6 pts | 13 pts |
| chariot | 1.8 | 1.1 | 63% | 16.4 pts | 29 pts |
| infantry | 12.7 | 5.1 | 71% | 10.5 pts | 133 pts |
| monster | 0.8 | 0.2 | 82% | 5.9 pts | 5 pts |
| war machine | 6.7 | 5.1 | 65% | 23.4 pts | 157 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.9 | 7.1 | 5.5 |
| Charges that made contact a game | 3.0 | 4.6 | 3.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.76 declared, 0.65 contact (17 units) | 0.31 declared, 0.19 contact (16 units) | 0.55 declared, 0.42 contact (33 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.10 declared, 0.80 contact (10 units) | 1.62 declared, 1.23 contact (13 units) | 1.39 declared, 1.04 contact (23 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.48 declared, 0.36 contact (245 units) | 0.78 declared, 0.49 contact (296 units) | 0.65 declared, 0.43 contact (541 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 53% (43 of 81) | 38% (6 of 16) | 33% (2 of 6) | 50% (51 of 103) |
| Character in a unit | 66% (19 of 29) | 88% (15 of 17) | 100% (1 of 1) | 74% (35 of 47) |
| Character on its own | 94% (34 of 36) | 40% (10 of 25) | 35% (27 of 77) | 51% (71 of 138) |
| Chariot | 73% (11 of 15) | 42% (5 of 12) | - | 59% (16 of 27) |
| Infantry | 55% (46 of 83) | 40% (10 of 25) | 33% (2 of 6) | 51% (58 of 114) |
| Monster | 56% (19 of 34) | 86% (12 of 14) | - | 65% (31 of 48) |
| Monstrous | 71% (10 of 14) | 57% (8 of 14) | - | 64% (18 of 28) |
| War Machines | 72% (31 of 43) | 50% (1 of 2) | - | 71% (32 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 85% (17 of 20); on the table 90% | 34% (35 of 102) | 23% | 68% (15 of 22) | 100% (6 of 6); 4.0 uses a game | 50% (1 of 2); 0.5 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 100% (9 of 9); on the table 100% | 46% (11 of 24) | 29% | 50% (16 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 67% (2 of 3); on the table 67% | - | 62% | 70% (19 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 58% (7 of 12); on the table 75% | 44% (8 of 18) | 48% | 60% (37 of 62) | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game | 80% (4 of 5); 0.7 uses a game |
| Grand Cathay | 4 | 100% (22 of 22); on the table 100% | 31% (26 of 84) | 24% | 46% (17 of 37) | 100% (9 of 9); 6.0 uses a game | 50% (1 of 2); 0.2 uses a game | 25% (1 of 4); 0.2 uses a game |
| High Elf Realms | 9 | 92% (24 of 26); on the table 92% | 25% (9 of 36) | 39% | 46% (32 of 70) | 86% (6 of 7); 2.7 uses a game | 37% (11 of 30); 2.4 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (3 of 3); on the table 100% | - | 34% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 88% (7 of 8); on the table 88% | 17% (1 of 6) | 22% | 52% (11 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 100% (1 of 1); on the table 100% | 50% (3 of 6) | 35% | 71% (10 of 14) | 50% (1 of 2); 0.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (11 of 11); on the table 100% | 45% (19 of 42) | 31% | 58% (14 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 6 | 79% (11 of 14); on the table 86% | 38% (15 of 39) | 46% | 80% (36 of 45) | 100% (3 of 3); 0.8 uses a game | 0.0 uses a game | 67% (4 of 6); 0.8 uses a game |
| Tomb Kings of Khemri | 4 | 82% (9 of 11); on the table 82% | 17% (1 of 6) | 26% | 45% (9 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 95% (20 of 21); on the table 95% | 25% (15 of 59) | 20% | 45% (19 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 91% (31 of 34); on the table 94% | 42% (5 of 12) | 32% | 62% (45 of 72) | 100% (2 of 2); 0.6 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 86% (25 of 29); on the table 86% | 0% (0 of 6) | 35% | 54% (30 of 56) | 50% (1 of 2); 0.8 uses a game | 0.0 uses a game | 50% (2 of 4); 0.3 uses a game |

Flank and rear charges a unit could have turned to face (tk-h2h-mine-949ddcd-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 48% (51) | 53% (36) | 50% (87) |
| ...free all their last turn and able to turn (per game) | 0.81 | 0.47 | 1.28 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.25 | 0.22 | 0.47 |
| ...with the charger already in that arc before they moved (per game) | 0.53 | 0.25 | 0.78 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.69 | 1.25 | 2.94 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.78 | 0.44 | 1.22 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.39 | 4.89 | 10.28 |

### Quality by phase: tk-h2h-mine-949ddcd-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 46% (65 of 141) | 39% (87 of 224) |
| Strategy | Shoot objectives carried out (shot that target) | 44% (167 of 380) | 43% (58 of 135) |
| Strategy | Close-in objectives charged next turn | 13% (19 of 150) | 16% (34 of 210) |
| Strategy | Support requests answered (helper made contact too) | 58% (11 of 19) | 32% (12 of 38) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 58% (7 of 12) | 75% (3 of 4) |
| Strategy | Joined characters whose unit fought | 53% (17 of 32) | 42% (14 of 33) |
| Strategy | Lone characters that fought | 77% (70 of 91) | 81% (67 of 83) |
| Movement | Charges halted short of contact | 0.1 | 0.1 |
| Movement | Idle units | 1.0 | 1.8 |
| Movement | Points that never moved of their own | 273.6 | 101.8 |
| Movement | Fights charged into per game | 2.8 | 3.8 |
| Movement | Charges with odds: long shots (under 50%) | 13 of 90, net +138 | 22 of 119, net +26 |
| Movement | Charges with odds: sweet spot (55-75%) | 14 of 90, net +86 | 25 of 119, net +13 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 9 of 90, net +53 | 11 of 119, net +91 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 32 of 90, net +70 | 30 of 119, net +89 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.2 | 8.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (166 of 368) | 38% (112 of 292) |
| Shooting | Points destroyed by shooting units | 92.5 | 63.6 |
| Shooting | War machine shots | 6.0 | 0.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 56% (121 of 216) | 16% (4 of 25) |
| Shooting | Points destroyed by war machines | 56.3 | 16.7 |
| Magic | Magic missiles cast | 1.6 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 40% (23 of 58) | 46% (19 of 41) |
| Magic | Wounds caused by magic missiles | 3.2 | 1.1 |
| Magic | Wounds caused by other spells | 1.9 | 1.7 |
| Magic | Points destroyed by magic (all spells) | 82.2 | 20.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.4 / 0.9 / 0.2 | 1.8 / 0.4 / 0.6 / 0.1 |
| Combat | Points destroyed in combat | 367.1 | 369.4 |
| Combat | Points run down | 74.2 | 158.2 |
| Combat | Net points per charged fight, damage counted | +76 | +73 |
| Combat | Net per 100 charger points, damage counted | +27.8 | +23.4 |
| Combat | First round won (charged fights) | 72% | 65% |
| Combat | Net points per charged fight | +72 | +74 |
| Combat | Net points per supported fight / lone fight | +181 / +60 | +126 / +65 |
| Combat | Charged fights on a top-3 enemy unit | 36 of 101 | 71 of 138 |
| Game | Points lost | 813.3 | 729.4 |
| Game | VP from objectives | 470.8 | 536.7 |
| Game | Lone holders (player turns) | 2.2 | 3.0 |

- Mine won / drew / lost: 13 / 7 / 16 of 36 ended games (of 36); mean margin (Mine - Opponent) -175 VP
- The side that went first won 16 of 29 games with a winner
- Points traded per game (both sides' losses): 1543
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: tk-h2h-mine-949ddcd-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.0 | +0.0 | 0.0 | 11.2 | 0.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.8 | +4.4 | 0.0 | 27.8 | 0.9 | +11.3 | 0.0 | 7.7 |
| BEST FACING | 0.5 | +24.4 | 0.0 | 47.9 | 0.6 | +10.4 | 0.0 | 72.0 |
| BEST FIRST | 3.6 | +133.4 | 138.1 | 72.7 | 3.8 | +147.7 | 119.2 | 56.8 |
| BEST MOVE FOR SHOOTERS | 1.2 | +65.9 | 0.0 | 25.7 | - | - | - | - |
| BEST OVERALL | 0.5 | +33.1 | 0.0 | 19.4 | 0.7 | +50.1 | 0.0 | 66.6 |
| BEST PREY | 0.4 | +29.4 | 0.0 | 3.5 | 0.8 | +49.6 | 19.4 | 21.1 |
| BEST PRIZE | 0.1 | +3.0 | 12.5 | 7.2 | 0.1 | -14.6 | 10.5 | 11.1 |
| BIG CHARACTER SAFETY | 0.2 | -0.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 15.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 14.2 | 0.0 |
| BLOCKED WHEEL | 0.6 | +6.0 | 0.0 | 6.7 | 0.5 | +11.2 | 0.0 | 0.0 |
| BOMBING RUN | 0.1 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.6 | +0.0 | 103.4 | 9.2 | 0.1 | +0.0 | 15.6 | 0.0 |
| CANNON PLANNED TARGET | 4.5 | +134.6 | 375.8 | 93.2 | 0.4 | +20.9 | 35.6 | 0.0 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 3.2 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | -1.8 | 0.0 | 13.9 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 16.6 | 0.0 | 0.1 | +0.0 | 8.3 | 0.0 |
| CAST JOB | 0.9 | +32.3 | 86.7 | 32.9 | 0.4 | +12.5 | 12.3 | 3.2 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +21.7 | 10.2 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.9 | +0.0 | 0.0 | 21.2 | 0.4 | +0.0 | 0.0 | 18.1 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | 0.0 | +0.1 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 3.2 |
| CHAFF PASSED | 0.2 | -0.9 | 3.8 | 3.5 | 0.1 | -0.1 | 0.0 | 3.8 |
| CHARGE NOW FIRST | 2.8 | +0.0 | 240.6 | 82.1 | 2.9 | +0.0 | 260.9 | 122.9 |
| CHARGE NOW WEIGHED | 0.2 | -8.8 | 0.0 | 1.7 | 0.4 | -27.0 | 13.8 | 2.7 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.4 | 0.0 | 0.0 | 0.2 | -2.2 | 6.6 | 26.1 |
| CHEAP HELPER | 0.1 | +0.0 | 8.2 | 1.9 | 0.1 | +0.0 | 2.2 | 1.9 |
| COMBAT PIVOT | 0.7 | +0.0 | 32.5 | 51.9 | 0.6 | +0.0 | 17.7 | 15.8 |
| CONVEYANCE SEARCH | 0.8 | +111.3 | 25.7 | 10.2 | 0.3 | +69.3 | 0.0 | 0.0 |
| COUNTER-CHARGE COVER | 7.7 | +485.9 | 0.0 | 261.5 | 6.0 | +530.1 | 0.0 | 133.8 |
| DEFENSIVE ARMY | 0.4 | +0.0 | 76.8 | 10.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.1 | +4.4 | 9.7 | 0.0 | 0.1 | +9.2 | 16.1 | 2.3 |
| EDGE GIVE GROUND | - | - | - | - | 0.2 | +7.2 | 23.5 | 2.5 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +2.1 | 0.0 | 9.7 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACE THE CAST | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.7 | +119.6 | 0.0 | 82.7 | 1.2 | +96.4 | 0.0 | 99.8 |
| FALLBACK BY WORTH | 4.8 | +46.1 | 0.0 | 60.8 | 5.8 | +62.2 | 0.0 | 49.9 |
| FIGHT LIFT | 0.1 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| FIRE AND FLEE | - | - | - | - | 0.0 | +0.3 | 0.0 | 0.0 |
| FLANK NOT WEIGHED | 5.5 | +0.0 | 0.0 | 199.9 | 4.8 | +0.0 | 0.0 | 114.4 |
| FOCUS FIRE | 0.0 | +0.2 | 1.2 | 0.0 | 0.0 | +0.4 | 1.8 | 0.0 |
| FOCUS OVER TURNS | 1.1 | +20.8 | 38.4 | 18.9 | - | - | - | - |
| FOLLOW UP WEIGHED | 1.2 | +183.8 | 0.0 | 64.9 | 1.4 | +278.4 | 0.0 | 73.6 |
| FRIENDS SHOTS CHECKED | 0.3 | +13.9 | 0.0 | 5.2 | 0.2 | +7.1 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -3.2 | 20.7 | 0.0 | 0.2 | -1.9 | 23.4 | 0.0 |
| GROUND FLIERS | 0.1 | +1.2 | 0.0 | 6.1 | 0.1 | +2.8 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 6.2 | 2.8 |
| HELPER UNSEEN | 0.3 | +0.0 | 53.5 | 5.2 | 0.3 | +0.0 | 4.3 | 1.4 |
| HILL BY ITS CHANCE | 0.6 | -53.0 | 0.0 | 22.5 | 0.6 | -44.2 | 0.0 | 15.8 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.0 | +0.1 | 0.0 | 0.0 | 0.1 | +4.0 | 14.4 | 1.2 |
| HUNT DROPPED | 0.1 | +0.0 | 5.4 | 0.0 | 0.1 | +0.0 | 3.5 | 3.1 |
| HUNT IN PAIRS | 0.3 | +14.5 | 0.0 | 0.0 | 0.3 | +19.3 | 0.0 | 0.0 |
| HUNT KEPT | - | - | - | - | 0.1 | +0.4 | 0.0 | 2.5 |
| HUNT RESULT | 0.1 | +5.7 | 5.4 | 0.0 | 0.2 | +27.5 | 3.5 | 4.3 |
| HUNT THE GUNS | 0.1 | +27.9 | 5.4 | 0.0 | 0.2 | +61.8 | 17.9 | 1.2 |
| INVITES THE FIGHT | 1.7 | +24.3 | 60.1 | 41.5 | 1.4 | +21.1 | 29.1 | 30.4 |
| JOINT CHARGE PLAN | 0.2 | +2.3 | 0.0 | 7.8 | 0.1 | +3.6 | 8.3 | 0.0 |
| KEEP FALLS | 0.1 | +2.3 | 0.0 | 6.1 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.1 | +0.3 | 3.4 | 0.0 | 0.1 | +0.4 | 0.0 | 10.6 |
| KEEPS ITS TARGET | 1.9 | +55.8 | 127.3 | 47.6 | 2.2 | +65.0 | 158.1 | 48.2 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.9 | +79.6 | 172.8 | 44.4 | 2.5 | +130.8 | 202.8 | 71.3 |
| KILLS COUNT NEXT TURN | 5.3 | +182.6 | 135.3 | 74.0 | 6.6 | +248.3 | 214.7 | 113.9 |
| LINE HITS NO ONE | - | - | - | - | 0.0 | -0.1 | 0.0 | 0.0 |
| LONE CHARACTER SAFE SPOT | 0.3 | +6.6 | 9.2 | 3.6 | 0.3 | +17.4 | 6.6 | 27.3 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 10.7 |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | -3.7 | 31.7 | 4.9 | 0.7 | +2.6 | 22.8 | 13.4 |
| LOST CHARGE | 2.4 | -37.6 | 79.4 | 129.8 | 2.0 | -51.5 | 47.4 | 22.2 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.0 | -3.9 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.7 | +44.3 | 0.0 | 16.2 | 0.5 | +60.5 | 14.9 | 30.3 |
| MANOEUVRE | 0.3 | +5.7 | 0.0 | 17.9 | 0.1 | +3.4 | 0.0 | 4.6 |
| MARCH AT ESCAPER | 0.1 | +0.8 | 0.0 | 11.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| MARCH CHECK | 0.5 | +30.5 | 0.0 | 4.6 | 0.4 | +24.1 | 0.0 | 8.5 |
| MARCH ODDS | 0.2 | +8.1 | 0.0 | 0.0 | 0.2 | +10.6 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.4 | +7.2 | 0.0 | 15.7 | 0.3 | +20.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.1 | +121.7 | 0.0 | 100.5 | 4.3 | +149.2 | 0.0 | 57.6 |
| MISSILES IN THE MOVE | 3.7 | +200.8 | 0.0 | 68.5 | 2.4 | +50.2 | 0.0 | 63.2 |
| MISSILES IN THE PLAN | 0.9 | +21.5 | 41.3 | 16.8 | - | - | - | - |
| MISSILES NEXT TURN | 4.5 | +138.0 | 0.0 | 114.2 | 3.0 | +32.1 | 0.0 | 63.2 |
| MODEL FACING | 0.2 | +23.7 | 0.0 | 3.3 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 10.5 | 0.0 |
| MOVE AND CAST | 0.3 | +25.8 | 0.0 | 4.5 | 0.1 | +7.0 | 0.0 | 3.2 |
| MOVE SPELL IN RANGE | 0.3 | +5.2 | 0.0 | 4.7 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.7 | -28.3 | 28.0 | 2.4 | 0.1 | -6.9 | 0.0 | 2.6 |
| MOVE SPELL SPOT | 0.6 | +0.0 | 0.0 | 19.9 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 3.5 | +172.9 | 83.1 | 57.1 | 4.3 | +389.0 | 167.5 | 116.6 |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +3.2 | 4.7 | 0.0 | 0.1 | +3.7 | 8.6 | 0.0 |
| NO RALLY LEFT | 0.0 | +0.2 | 0.0 | 0.0 | 0.0 | +4.7 | 0.0 | 0.0 |
| NOT NEEDED | 0.3 | -12.9 | 24.6 | 3.2 | 0.6 | -26.4 | 75.2 | 9.6 |
| NOT TURNED | 5.4 | +110.0 | 0.0 | 139.5 | 4.9 | +29.2 | 0.0 | 53.9 |
| NOT WORTH A CAST | 0.8 | -0.5 | 0.0 | 11.0 | 0.4 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 14.8 | -797.0 | 6.4 | 263.7 | 14.4 | -835.1 | 0.0 | 235.5 |
| OPENS A LANE | 0.2 | +0.8 | 25.9 | 3.2 | 0.1 | +0.1 | 0.0 | 1.6 |
| OPENS UP | 0.3 | +18.8 | 21.1 | 0.0 | 0.1 | +14.8 | 4.8 | 0.0 |
| OVERRUN THREAT | 0.0 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.4 | +4.9 | 35.3 | 30.3 | 0.7 | +12.2 | 75.5 | 29.8 |
| PATHS CROSS | 2.3 | +201.6 | 0.0 | 30.9 | 2.7 | +244.0 | 0.0 | 63.4 |
| PERIAPT WORTH | 0.0 | +3.4 | 0.0 | 0.0 | 0.1 | +9.1 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.2 | -2.7 | 0.0 | 0.0 | 0.1 | -0.9 | 0.0 | 7.9 |
| PLAN RESULT | 37.2 | +1592.1 | 1560.3 | 1024.2 | 38.6 | +1203.0 | 1361.4 | 1032.5 |
| PURSUES BIG PREY | 0.1 | -7.1 | 0.0 | 0.0 | 0.1 | -11.4 | 0.0 | 13.1 |
| RAIDS THE BAGGAGE NEXT TURN | 0.2 | +13.5 | 0.0 | 2.2 | 0.1 | +9.1 | 0.0 | 3.4 |
| RANDOM MOVE BY FIGURES | 1.2 | +12.9 | 0.0 | 24.4 | 1.7 | +33.3 | 0.0 | 72.2 |
| RANDOM MOVER NO PROMISE | 0.5 | -32.2 | 21.0 | 0.0 | 0.2 | -11.3 | 0.0 | 15.7 |
| REDIRECT BY WHAT IT STOPS | 0.2 | +5.2 | 0.0 | 4.8 | 0.5 | -20.4 | 0.0 | 4.9 |
| REDIRECT COUNTER | 2.5 | +165.5 | 0.0 | 24.8 | 3.9 | +354.3 | 0.0 | 64.6 |
| REDIRECT WEIGHED | 0.4 | +16.4 | 23.4 | 26.0 | 0.5 | +13.0 | 14.9 | 5.2 |
| RESERVE FALL BACK | 0.5 | +22.8 | 0.0 | 5.1 | 0.7 | +24.7 | 0.0 | 7.8 |
| RESTRAINS TO SHOOT | 0.2 | +9.5 | 0.0 | 0.0 | 0.2 | +5.6 | 0.0 | 6.5 |
| RISK BY ARC | 2.5 | +110.6 | 238.9 | 82.4 | 3.4 | +35.2 | 288.0 | 144.4 |
| SAFER THAN THE JOB | 0.8 | +49.7 | 0.0 | 37.0 | 0.4 | +37.9 | 0.0 | 17.9 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.9 | 0.1 | +0.0 | 0.0 | 1.8 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.9 | 0.1 | +0.0 | 0.0 | 1.8 |
| SCREEN BY WHAT IT SAVES | 0.1 | -4.5 | 0.0 | 0.0 | 0.4 | -20.2 | 0.0 | 1.9 |
| SEARCH SPOT | 3.1 | +142.1 | 0.0 | 48.5 | 2.3 | +139.0 | 0.0 | 21.7 |
| SELF MOVE SPELL | 0.1 | +16.2 | 0.0 | 21.9 | 0.6 | +15.2 | 0.0 | 36.2 |
| SET UP TOGETHER | 1.2 | +75.5 | 9.5 | 27.3 | 1.0 | +82.3 | 26.3 | 42.4 |
| SET-UP ANY TARGET | 0.5 | +72.0 | 24.6 | 10.2 | 0.2 | +37.8 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +10.7 | 2.5 | 0.0 | 0.0 | +5.6 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +93.4 | 106.2 | 9.1 | 0.7 | +15.1 | 31.8 | 7.2 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 3.8 |
| SHOT OPTIONS | 15.7 | +0.0 | 803.1 | 308.6 | 8.0 | +0.0 | 395.0 | 194.3 |
| SHOT REPLANNED | 0.4 | +0.0 | 93.4 | 0.0 | 0.2 | +0.0 | 36.6 | 11.1 |
| SHOTS IN THE MOVE | 14.5 | +604.4 | 0.0 | 270.8 | 6.6 | +205.6 | 0.0 | 97.5 |
| SPELL SETS UP CHARGE | 0.5 | +72.0 | 24.6 | 10.2 | 0.2 | +43.8 | 0.0 | 0.0 |
| SPELL WORTH | 1.1 | +21.0 | 69.3 | 87.9 | 2.2 | +40.0 | 106.1 | 108.8 |
| STABLE ROLE | 10.0 | +0.0 | 451.3 | 239.0 | 9.1 | +0.0 | 285.7 | 127.3 |
| STANDS TO CAST | 0.0 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| STAY WEIGHED | 0.1 | +4.5 | 0.0 | 2.1 | - | - | - | - |
| STAY WORTH | 19.1 | +361.6 | 533.1 | 288.6 | - | - | - | - |
| STOPS | 0.1 | +0.6 | 5.4 | 0.0 | 0.1 | +1.3 | 3.5 | 1.2 |
| STOPS SHORT OF THE FLANK | 0.6 | +18.0 | 0.0 | 21.4 | 0.3 | +10.2 | 0.0 | 3.9 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 4.0 |
| SUPPORT JOB KEPT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT NARROWED | 5.6 | -49.4 | 331.6 | 130.6 | 8.4 | -50.5 | 393.1 | 177.9 |
| SUPPORTS | 3.5 | +53.6 | 136.1 | 66.5 | 5.3 | +50.5 | 171.6 | 71.6 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -2.3 | 24.7 | 1.4 | 0.1 | -9.7 | 1.5 | 0.0 |
| SURE REACH TOGETHER | 0.3 | -1.0 | 9.5 | 14.4 | 0.4 | -0.1 | 0.0 | 3.2 |
| THREAT IN THE KILL | 12.7 | +147.6 | 988.2 | 296.2 | - | - | - | - |
| THREAT OVER THE TURNS | 10.3 | +110.5 | 798.2 | 270.1 | - | - | - | - |
| THREAT TO WORN DOWN | 12.4 | +149.1 | 956.4 | 285.4 | - | - | - | - |
| THROUGH LINE OF FIRE | 0.4 | +22.2 | 0.0 | 11.7 | 0.2 | +7.1 | 0.0 | 0.0 |
| TURN WORTH | 0.6 | -44.8 | 46.3 | 17.8 | 0.4 | -35.3 | 40.4 | 1.2 |
| TWO OR MORE ARRIVE | 0.5 | +2.3 | 0.0 | 9.6 | 0.2 | +1.1 | 6.1 | 15.0 |
| WAIT AFTER COSTS | 6.9 | -247.9 | 181.8 | 131.3 | 7.3 | -386.2 | 214.3 | 185.8 |
| WALKS TO THE FIGHT | 1.6 | +25.7 | 48.5 | 54.2 | 0.9 | +13.9 | 6.4 | 9.8 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 51.1 | 9.6 | 0.1 | +0.0 | 7.5 | 8.1 |
| WEARS DOWN | 0.9 | +33.1 | 72.9 | 38.9 | 1.7 | +54.7 | 105.9 | 58.8 |
| WHO HITS BACK | 0.3 | +16.9 | 0.0 | 2.0 | 0.2 | +15.3 | 0.0 | 18.4 |
| WHOLE FIGHT | 0.3 | +7.9 | 39.0 | 4.6 | 0.6 | +35.1 | 39.4 | 6.3 |
| WHOLE FIGHT GAIN | 0.2 | +17.4 | 15.8 | 5.7 | 0.8 | +60.5 | 56.6 | 42.5 |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 2.3 | 4.5 | 0.0 | +0.0 | 8.6 | 0.0 |

### Rule changes: tk-h2h-mine-949ddcd-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1048 | 1048 | 1048 | 29.11 | -58755 | -56.1 |
| BEST FIRST | 263 | 263 | 263 | 7.31 | +10122 | +38.5 |
| SEARCH SPOT | 193 | 193 | 190 | 5.28 | +10152 | +53.4 |
| PATHS CROSS | 181 | 181 | 181 | 5.03 | +16044 | +88.6 |
| MOVE TO CHARGE | 283 | 283 | 154 | 4.28 | +7250 | +47.1 |
| KILLS COUNT NEXT TURN | 427 | 427 | 127 | 3.53 | +5026 | +39.6 |
| COUNTER-CHARGE COVER | 495 | 272 | 124 | 3.44 | +7258 | +58.5 |
| FACES THE THREAT | 106 | 106 | 106 | 2.94 | +7774 | +73.3 |
| FOLLOW UP WEIGHED | 91 | 91 | 91 | 2.53 | +16636 | +182.8 |
| SUPPORTS | 318 | 318 | 88 | 2.44 | +878 | +10.0 |
| FALLBACK BY WORTH | 379 | 379 | 79 | 2.19 | +3898 | +49.3 |
| SHOTS IN THE MOVE | 759 | 510 | 78 | 2.17 | +2744 | +35.2 |
| RANDOM MOVE BY FIGURES | 105 | 105 | 59 | 1.64 | +1664 | +28.2 |
| WALKS TO THE FIGHT | 89 | 89 | 59 | 1.64 | +557 | +9.4 |
| ADVANCE LANE KEPT | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| REDIRECT COUNTER | 232 | 126 | 55 | 1.53 | +4087 | +74.3 |
| WAIT AFTER COSTS | 510 | 510 | 55 | 1.53 | +1009 | +18.3 |
| CHARGE NOW FIRST | 207 | 207 | 47 | 1.31 | -3366 | -71.6 |
| COMBAT PIVOT | 46 | 46 | 46 | 1.28 | +0 | +0.0 |
| BEST MOVE FOR SHOOTERS | 45 | 45 | 45 | 1.25 | +2372 | +52.7 |
| BEST OVERALL | 44 | 44 | 44 | 1.22 | +2995 | +68.1 |
| RESERVE FALL BACK | 44 | 44 | 44 | 1.22 | +1709 | +38.8 |
| SAFER THAN THE JOB | 44 | 44 | 44 | 1.22 | +3153 | +71.7 |
| CANNON SIGHT KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| BEST FACING | 41 | 41 | 41 | 1.14 | +1253 | +30.6 |
| BLOCKED WHEEL | 39 | 39 | 39 | 1.08 | +619 | +15.9 |
| ARTILLERY RE-ROLL WEIGHED | 38 | 38 | 38 | 1.06 | +0 | +0.0 |
| THREAT TO WORN DOWN | 445 | 365 | 38 | 1.06 | +211 | +5.6 |
| RISK BY ARC | 213 | 208 | 37 | 1.03 | +1283 | +34.7 |
| STAY WORTH | 686 | 562 | 36 | 1.00 | +491 | +13.6 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| CANNON PLANNED TARGET | 178 | 178 | 33 | 0.92 | -219 | -6.6 |
| KILLS COUNT | 159 | 157 | 33 | 0.92 | +1566 | +47.5 |
| REDIRECT WEIGHED | 33 | 33 | 33 | 0.92 | +1685 | +51.1 |
| SET UP TOGETHER | 79 | 64 | 32 | 0.89 | +2324 | +72.6 |
| STOPS SHORT OF THE FLANK | 31 | 31 | 31 | 0.86 | +1015 | +32.8 |
| MISSILES IN THE MOVE | 218 | 122 | 30 | 0.83 | +915 | +30.5 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| MAX FOR POSITIONING | 303 | 156 | 28 | 0.78 | +358 | +12.8 |
| SHOOTS FROM THE BEST SPOT | 60 | 60 | 27 | 0.75 | +1285 | +47.6 |
| WHOLE FIGHT GAIN | 36 | 35 | 27 | 0.75 | +1278 | +47.4 |
| KEEPS ITS TARGET | 145 | 145 | 25 | 0.69 | +414 | +16.5 |
| THREAT IN THE KILL | 457 | 377 | 24 | 0.67 | +150 | +6.2 |
| CHARGE NOW WEIGHED | 22 | 22 | 22 | 0.61 | +876 | +39.8 |
| INVITES THE FIGHT | 111 | 111 | 22 | 0.61 | +276 | +12.5 |
| MARCH CHECK | 31 | 27 | 22 | 0.61 | +1750 | +79.6 |
| SHOT REPLANNED | 22 | 22 | 22 | 0.61 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 22 | 22 | 22 | 0.61 | +1052 | +47.8 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| CAST JOB | 46 | 46 | 18 | 0.50 | +436 | +24.2 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +41 | +2.3 |
| WHO HITS BACK | 18 | 18 | 18 | 0.50 | +869 | +48.3 |
| CASTER AWAY FROM SCREEN | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| FOCUS OVER TURNS | 40 | 40 | 17 | 0.47 | +161 | +9.5 |
| MOVE AND CAST | 17 | 17 | 17 | 0.47 | +1180 | +69.4 |
| FRIENDS SHOTS CHECKED | 16 | 16 | 16 | 0.44 | +758 | +47.4 |
| THREAT OVER THE TURNS | 370 | 307 | 16 | 0.44 | +79 | +4.9 |
| MANOEUVRE | 15 | 15 | 15 | 0.42 | +328 | +21.9 |
| WEARS DOWN | 93 | 92 | 15 | 0.42 | +493 | +32.8 |
| BEST PREY | 44 | 44 | 14 | 0.39 | +965 | +69.0 |
| CHAFF PASSED | 14 | 14 | 14 | 0.39 | -37 | -2.6 |
| MAKE SURE TOGETHER | 43 | 30 | 14 | 0.39 | +1536 | +109.7 |
| MARCH ODDS | 13 | 13 | 13 | 0.36 | +203 | +15.6 |
| RESTRAINS TO SHOOT | 13 | 13 | 13 | 0.36 | +544 | +41.8 |
| PIVOT GUARDS FLANK | 12 | 12 | 12 | 0.33 | -131 | -10.9 |
| LOST CHARGE | 156 | 156 | 11 | 0.31 | +364 | +33.1 |
| BIG CHARACTER SAFETY | 10 | 10 | 10 | 0.28 | +13 | +1.3 |
| STUCK PIVOT | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| BEST PRIZE | 9 | 9 | 9 | 0.25 | -811 | -90.1 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 10 | 10 | 9 | 0.25 | +537 | +59.7 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SURE CHARGE BEATS ADVANCE | 9 | 9 | 9 | 0.25 | -432 | -48.0 |
| WAR ENGINE JOBS | 28 | 28 | 9 | 0.25 | -332 | -36.8 |
| WHOLE FIGHT | 35 | 33 | 9 | 0.25 | +504 | +56.0 |
| BLOCKED CHARGE SKIPPED | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| MODEL FACING | 8 | 8 | 8 | 0.22 | +854 | +106.7 |
| OVERRUNS AWAY | 38 | 38 | 8 | 0.22 | +93 | +11.7 |
| MISSILES NEXT TURN | 272 | 149 | 7 | 0.19 | +7 | +1.1 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| PURSUES BIG PREY | 7 | 7 | 7 | 0.19 | -668 | -95.4 |
| SUPPORT NARROWED | 502 | 502 | 7 | 0.19 | -122 | -17.4 |
| CASTING BLOCK | 10 | 10 | 5 | 0.14 | +326 | +65.3 |
| DEFENSIVE ARMY | 14 | 14 | 5 | 0.14 | -331 | -66.1 |
| OPENS UP | 15 | 15 | 5 | 0.14 | +196 | +39.1 |
| PERIAPT WORTH | 5 | 5 | 5 | 0.14 | +449 | +89.7 |
| HUNT IN PAIRS | 22 | 13 | 4 | 0.11 | +275 | +68.8 |
| KEEP FALLS | 4 | 4 | 4 | 0.11 | +278 | +69.5 |
| LONE WIZARD HOLDS BACK | 9 | 9 | 3 | 0.08 | -168 | -56.2 |
| MISSILES IN THE PLAN | 34 | 6 | 3 | 0.08 | +86 | +28.8 |
| BACKUP TARGETS | 62 | 27 | 2 | 0.06 | +2 | +0.9 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +36 | +18.0 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -9 | -4.6 |
| DEFENSIVE FLOOR | 4 | 3 | 2 | 0.06 | +276 | +138.0 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +77 | +38.4 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +21 | +10.7 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| NEEDED THERE | 5 | 5 | 2 | 0.06 | +0 | +0.0 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +141 | +70.7 |
| SCREEN BY WHAT IT SAVES | 20 | 20 | 2 | 0.06 | +6 | +2.8 |
| STAY WEIGHED | 2 | 2 | 2 | 0.06 | +164 | +81.8 |
| SURE REACH TOGETHER | 25 | 21 | 2 | 0.06 | +8 | +3.9 |
| CARRIES OUT COUNTER | 4 | 4 | 1 | 0.03 | -67 | -66.6 |
| CHARIOT NO STATIC JOB | 1 | 1 | 1 | 0.03 | -24 | -24.4 |
| FACE THE CAST | 1 | 1 | 1 | 0.03 | +13 | +13.1 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +12 | +12.3 |
| HILL BY ITS CHANCE | 41 | 41 | 1 | 0.03 | +12 | +12.0 |
| HUNT ADVANCE | 6 | 6 | 1 | 0.03 | +1 | +0.9 |
| JOINT CHARGE PLAN | 9 | 9 | 1 | 0.03 | +17 | +17.0 |
| LINE HITS NO ONE | 1 | 1 | 1 | 0.03 | +4 | +4.3 |
| LONG SHOT | 42 | 40 | 1 | 0.03 | +8 | +8.0 |
| REDIRECT BY WHAT IT STOPS | 26 | 26 | 1 | 0.03 | +114 | +114.4 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | +28 | +27.9 |
| STOPS | 6 | 5 | 1 | 0.03 | +11 | +11.1 |
| SUPPORT JOB KEPT | 1 | 1 | 1 | 0.03 | +87 | +87.1 |
| WOUNDED STAYS OUT | 2 | 2 | 1 | 0.03 | -174 | -173.9 |
| ALREADY CARRIED | 3 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 24 | 24 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 6 | 6 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 47 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 12 | 12 | 0 | 0.00 | - | - |
| CHEAP HELPER | 6 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 41 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 7 | 6 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 372 | not checked | - | - | - | - |
| GIVES UP | 11 | 10 | 0 | 0.00 | - | - |
| GROUND FLIERS | 4 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 6 | not checked | - | - | - | - |
| HELPER UNSEEN | 20 | 19 | 0 | 0.00 | - | - |
| HUNT DROPPED | 5 | trace | - | - | - | - |
| HUNT KEPT | 2 | trace | - | - | - | - |
| HUNT RESULT | 11 | trace | - | - | - | - |
| HUNT THE GUNS | 11 | trace | - | - | - | - |
| KEEPS ITS PREY | 4 | 4 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 20 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 6 | trace | - | - | - | - |
| MARCH OVER CASTS | 26 | 26 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 15 | 15 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 10 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 28 | trace | - | - | - | - |
| MOVE SPELL SPOT | 28 | not checked | - | - | - | - |
| NOT NEEDED | 31 | 31 | 0 | 0.00 | - | - |
| NOT TURNED | 370 | 370 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 42 | not checked | - | - | - | - |
| OPENS A LANE | 10 | 6 | 0 | 0.00 | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 2731 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 26 | 26 | 0 | 0.00 | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 22 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 23 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SHOT OPTIONS | 853 | 853 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 24 | not checked | - | - | - | - |
| SPELL WORTH | 121 | not checked | - | - | - | - |
| STABLE ROLE | 686 | 684 | 0 | 0.00 | - | - |
| TURN WORTH | 38 | 38 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 23 | 19 | 0 | 0.00 | - | - |

### Off best figure: tk-h2h-mine-949ddcd-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.19 | 12.89 | 56.6 |
| CHARGE NOW FIRST | rule | 0.64 | 0.64 | 73.2 |
| TURN GATE | gate | 0.61 | 0.47 | 38.0 |
| FALLBACK | gate | 0.36 | 0.53 | 58.8 |
| PIVOT GUARDS FLANK | rule | 0.25 | 0.08 | 10.9 |
| CANNON PLANNED TARGET | rule | 0.31 | - | 27.7 |
| BEST PRIZE | rule | 0.11 | 0.14 | 90.1 |
| SURE CHARGE BEATS ADVANCE | rule | 0.17 | 0.08 | 48.0 |
| WAR ENGINE JOBS | rule | 0.25 | - | 36.8 |
| SUPPORT REQUEST | gate | 0.11 | 0.11 | 88.9 |
| LONE CHARACTER SAFE SPOT | gate | 0.11 | 0.08 | 150.9 |
| PATHS CROSS | rule | 0.06 | 0.14 | 11.0 |
| PURSUES BIG PREY | rule | 0.06 | 0.14 | 95.4 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.11 | 0.06 | 62.2 |
| FIGHT ORDER BAND | gate | 0.06 | 0.11 | 2.8 |
| SUPPORT NARROWED | rule | 0.08 | 0.08 | 20.3 |
| AFTERMATH BAND | gate | 0.08 | 0.06 | 2.1 |
| CHAFF PASSED | rule | 0.08 | 0.06 | 7.3 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.08 | 14.4 |
| DEFENSIVE ARMY | rule | 0.11 | 0.03 | 66.1 |
| BIG CHARACTER SAFETY | rule | 0.08 | 0.03 | 6.4 |
| NO REASON | gate | 0.11 | - | 4.0 |
| STOPS SHORT OF THE FLANK | rule | 0.06 | 0.03 | 3.7 |
| BLOCKED WHEEL | rule | 0.06 | - | 3.0 |
| CATCH ODDS | rule | 0.03 | 0.03 | 4.6 |
| FALLBACK BY WORTH | rule | 0.06 | - | 98.8 |
| REDIRECT WEIGHED | rule | 0.06 | - | 4.8 |
| RULE SWITCHED OFF | gate | - | 0.06 | 7.3 |
| CARRIES OUT COUNTER | rule | 0.03 | - | 66.6 |
| CHARIOT NO STATIC JOB | rule | 0.03 | - | 24.4 |
| FACES THE THREAT | rule | 0.03 | - | 14.4 |
| LONE WIZARD HOLDS BACK | rule | - | 0.03 | 168.0 |
| WOUNDED STAYS OUT | rule | 0.03 | - | 173.9 |

### Plans: tk-h2h-mine-949ddcd-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.9 | 16% | 390 | 320 | 82% |
| Mine | charge | 3.4 | 63% | 267 | 309 | 116% |
| Mine | close in | 4.2 | 27% | 284 | 162 | 57% |
| Mine | hold | 4.5 | 28% | 267 | 0 | 0% |
| Mine | join | 0.5 | 95% | 10 | 0 | 0% |
| Mine | shoot | 9.0 | 60% | 759 | 801 | 106% |
| Mine | support | 3.8 | 86% | 47 | 0 | 0% |
| Opponent | advance | 12.9 | 18% | 322 | 373 | 116% |
| Opponent | charge | 5.4 | 55% | 592 | 497 | 84% |
| Opponent | close in | 5.8 | 27% | 443 | 129 | 29% |
| Opponent | hold | 4.8 | 30% | 323 | 0 | 0% |
| Opponent | join | 0.6 | 90% | 26 | 0 | 0% |
| Opponent | shoot | 3.1 | 65% | 89 | 213 | 240% |
| Opponent | support | 5.9 | 91% | 34 | 0 | 0% |

### Packages: hunt the guns, tk-h2h-mine-949ddcd-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 4 | 0 | 25% | 25% | 0% | 2.0 | 251 | 51 | 25% | 16 |
| Opponent | 0.2 | 7 | 0 | 29% | 43% | 0% | 2.0 | 318 | 141 | 43% | 79 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 152 |
| Empire of Man | 0.3 | 2 | 0 | 0% | 0% | 0% | - | 286 | 0 | 0% | 21 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 7 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 58 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 117 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 101 |
| Tomb Kings of Khemri | 0.8 | 3 | 0 | 33% | 67% | 0% | 2.0 | 297 | 217 | 67% | 0 |
| Vampire Counts | 0.8 | 6 | 0 | 33% | 33% | 0% | 2.0 | 294 | 90 | 33% | 64 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 115 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 17 |

### Battle groups: tk-h2h-mine-949ddcd-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 7.7 | 34% | 39% | 16% | 33% | 30% | 15% | 9% | 46% | 0% |
| Mine | REDIRECT COUNTER | 2.5 | 31% | 61% | 4% | 100% | 30% | 0% | 4% | 67% | 0% |
| Opponent | COUNTER-CHARGE COVER | 6.0 | 19% | 71% | 29% | 42% | 52% | 7% | 21% | 21% | 0% |
| Opponent | REDIRECT COUNTER | 3.9 | 25% | 58% | 22% | 0% | 18% | 0% | 11% | 68% | 4% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: tk-h2h-mine-949ddcd-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 0 (4) | 0 | 0 | 0 | 25% | 2.0 | - | 0 (4) | - | 0 (3) | 0 (1) |
| Mine | Chaff | 34 | 36 (34) | 29 | 7 | 54 | 29% | 2.9 | 21 (14) | 0 (5) | 61 (15) | 30 (20) | 45 (14) |
| Mine | Character | 106 | 40 (106) | 40 | 0 | 40 | 12% | 2.4 | 37 (31) | 49 (49) | 21 (7) | 33 (41) | 52 (46) |
| Mine | Clean-up | 23 | 57 (23) | 22 | 35 | 46 | 17% | 2.5 | 0 (2) | 66 (17) | 55 (4) | 87 (11) | 39 (12) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast | 4 | 376 (4) | 376 | 0 | 73 | 0% | 2.8 | 677 (2) | 75 (2) | - | 463 (3) | 140 (1) |
| Mine | Fast Hammer | 40 | 45 (40) | 37 | 9 | 55 | 15% | 2.5 | 51 (25) | 53 (9) | 6 (6) | 52 (25) | 35 (15) |
| Mine | Fragile | 4 | 0 (4) | 0 | 0 | 54 | 50% | 2.5 | 0 (1) | 0 (3) | - | 0 (1) | 0 (3) |
| Mine | Hammer | 64 | 42 (64) | 32 | 10 | 45 | 20% | 2.5 | 51 (13) | 38 (42) | 47 (9) | 40 (39) | 45 (25) |
| Mine | Holder | 31 | 58 (31) | 6 | 53 | 25 | 29% | 3.0 | 58 (8) | 74 (16) | 17 (7) | 88 (20) | 11 (11) |
| Mine | Shooter | 35 | 76 (35) | 38 | 38 | 50 | 6% | 1.5 | 32 (8) | 109 (22) | 17 (5) | 95 (26) | 22 (9) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | - | 0 (1) | - | 0 (1) |
| Mine | War machine | 56 | 42 (56) | 42 | 0 | 52 | 4% | 1.2 | 30 (16) | 45 (30) | 53 (10) | 10 (9) | 47 (47) |
| Mine | Wizard | 17 | 15 (17) | 15 | 0 | 41 | 6% | 2.1 | 0 (5) | 18 (7) | - | 0 (5) | 17 (7) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Chaff | 77 | 44 (77) | 21 | 23 | 56 | 39% | 2.9 | 57 (32) | 37 (18) | 34 (27) | 45 (58) | 40 (19) |
| Opponent | Character | 97 | 52 (97) | 52 | 0 | 36 | 21% | 2.2 | 61 (45) | 43 (40) | 69 (6) | 54 (50) | 54 (41) |
| Opponent | Clean-up | 12 | 63 (12) | 31 | 32 | 32 | 33% | 2.4 | 21 (4) | 43 (5) | 133 (3) | 24 (7) | 88 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 54 | 46 (54) | 26 | 20 | 37 | 24% | 2.9 | 37 (23) | 54 (23) | 61 (8) | 50 (33) | 40 (21) |
| Opponent | Fragile | 17 | 27 (17) | 27 | 0 | 71 | 24% | 2.3 | 59 (2) | 32 (11) | 0 (4) | 26 (13) | 28 (4) |
| Opponent | Hammer | 65 | 36 (65) | 23 | 12 | 42 | 31% | 3.1 | 38 (20) | 37 (38) | 9 (7) | 36 (41) | 34 (24) |
| Opponent | Holder | 30 | 26 (30) | 8 | 18 | 12 | 57% | 4.3 | 29 (9) | 29 (15) | 6 (6) | 34 (17) | 15 (13) |
| Opponent | Shooter | 34 | 127 (34) | 61 | 66 | 38 | 0% | 1.4 | 51 (10) | 166 (21) | 110 (3) | 134 (19) | 118 (15) |
| Opponent | Support | 6 | 0 (6) | 0 | 0 | 49 | 100% | - | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |
| Opponent | War machine | 6 | 89 (6) | 89 | 0 | 21 | 0% | 1.0 | 91 (3) | 85 (3) | - | 91 (3) | 85 (3) |
| Opponent | Wizard | 20 | 7 (20) | 7 | 0 | 50 | 5% | 2.8 | 12 (10) | 12 (2) | 0 (2) | 13 (9) | 0 (5) |

### Charged fights: tk-h2h-mine-949ddcd-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 91 | 66 | 1.8 | 1.1 | 38 | 12 | +26 | 1 of 7 | 6 of 7 | +266 | -14 |
| Mine | Chaos Dwarfs | 4 | 220 | 174 | 2.0 | 1.1 | 87 | 36 | +51 | 4 of 8 | 5 of 8 | +109 | +43 |
| Mine | Dwarfen Mountain Holds | 3 | 485 | 20 | 1.3 | 1.0 | 15 | 58 | -43 | 2 of 4 | 1 of 4 | - | -43 |
| Mine | Empire of Man | 5 | 272 | 275 | 1.8 | 1.1 | 153 | 60 | +93 | 4 of 9 | 6 of 9 | +156 | +85 |
| Mine | Grand Cathay | 4 | 363 | 165 | 3.0 | 1.2 | 55 | 11 | +44 | 3 of 12 | 6 of 12 | +0 | +52 |
| Mine | High Elf Realms | 4 | 369 | 445 | 4.0 | 1.1 | 111 | 40 | +71 | 3 of 16 | 13 of 16 | +186 | +64 |
| Mine | Kingdom of Bretonnia | 1 | 65 | 987 | 8.0 | 1.0 | 123 | 0 | +123 | 2 of 8 | 8 of 8 | - | +123 |
| Mine | Lizardmen | 1 | 458 | 676 | 6.0 | 1.2 | 113 | 114 | -1 | 4 of 6 | 5 of 6 | -173 | +33 |
| Mine | Ogre Kingdoms | 2 | 63 | 420 | 2.5 | 1.0 | 168 | 25 | +143 | 4 of 5 | 2 of 5 | - | +143 |
| Mine | Skaven | 2 | 72 | 72 | 1.5 | 1.0 | 48 | 0 | +48 | 0 of 3 | 3 of 3 | - | +48 |
| Mine | Tomb Kings of Khemri | 2 | 122 | 823 | 3.5 | 1.6 | 235 | 20 | +215 | 4 of 7 | 5 of 7 | +423 | +58 |
| Mine | Vampire Counts | 2 | 0 | 101 | 3.0 | 1.0 | 34 | 69 | -35 | 2 of 6 | 5 of 6 | - | -35 |
| Mine | Warriors of Chaos | 2 | 142 | 630 | 5.0 | 1.0 | 126 | 0 | +126 | 3 of 10 | 8 of 10 | - | +126 |
| **Mine** | all armies | 36 | 231 | 294 | 2.8 | 1.1 | 105 | 32 | +72 | 36 of 101 | 73 of 101 | +181 | +60 |
| Opponent | Empire of Man | 1 | 575 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 5 | 272 | 632 | 4.0 | 1.1 | 158 | 34 | +124 | 11 of 20 | 12 of 20 | -250 | +144 |
| Opponent | Lizardmen | 2 | 0 | 984 | 3.5 | 1.3 | 281 | 54 | +227 | 3 of 7 | 4 of 7 | +251 | +218 |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 52 | 3.0 | 1.0 | 17 | 0 | +17 | 4 of 9 | 9 of 9 | - | +17 |
| Opponent | Skaven | 4 | 0 | 71 | 0.8 | 1.0 | 95 | 140 | -45 | 1 of 3 | 2 of 3 | - | -45 |
| Opponent | Tomb Kings of Khemri | 2 | 426 | 260 | 3.5 | 1.3 | 74 | 19 | +55 | 1 of 7 | 5 of 7 | +0 | +77 |
| Opponent | Vampire Counts | 6 | 10 | 477 | 6.0 | 1.2 | 80 | 18 | +62 | 24 of 36 | 20 of 36 | +106 | +53 |
| Opponent | Warriors of Chaos | 7 | 12 | 485 | 3.7 | 1.1 | 130 | 54 | +76 | 15 of 26 | 16 of 26 | +230 | +63 |
| Opponent | Wood Elf Realms | 6 | 114 | 444 | 5.0 | 1.2 | 89 | 37 | +52 | 12 of 30 | 22 of 30 | +167 | +17 |
| **Opponent** | all armies | 36 | 100 | 417 | 3.8 | 1.2 | 109 | 35 | +74 | 71 of 138 | 90 of 138 | +126 | +65 |

### Effective charges: tk-h2h-mine-949ddcd-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 7 | 1 (net +0) | 0 | 0 | 2 (net +0) | 0 | 4 (net +45) | 0 | 0% (0 of 7) |
| Mine | Chaos Dwarfs | 8 | 1 (net +0) | 0 | 2 (net +45) | 1 (net +109) | 1 (net +91) | 2 (net -32) | 1 | 29% (2 of 7) |
| Mine | Dwarfen Mountain Holds | 4 | 2 (net +0) | 0 | 1 (net -233) | 1 (net +60) | 0 | 0 | 0 | 25% (1 of 4) |
| Mine | Empire of Man | 9 | 2 (net +302) | 1 (net +0) | 3 (net -74) | 1 (net +122) | 0 | 1 (net +329) | 1 | 38% (3 of 8) |
| Mine | Grand Cathay | 12 | 0 | 0 | 2 (net +0) | 3 (net +58) | 3 (net +16) | 4 (net +75) | 0 | 17% (2 of 12) |
| Mine | High Elf Realms | 16 | 1 (net +0) | 0 | 1 (net +540) | 5 (net +56) | 3 (net +102) | 6 (net +3) | 0 | 6% (1 of 16) |
| Mine | Kingdom of Bretonnia | 8 | 0 | 0 | 0 | 0 | 0 | 5 (net +89) | 3 | 0% (0 of 5) |
| Mine | Lizardmen | 6 | 2 (net +82) | 0 | 0 | 2 (net -86) | 0 | 1 (net +0) | 1 | 0% (0 of 5) |
| Mine | Ogre Kingdoms | 5 | 0 | 0 | 1 (net +350) | 0 | 0 | 2 (net +245) | 2 | 33% (1 of 3) |
| Mine | Skaven | 3 | 0 | 0 | 0 | 0 | 0 | 3 (net +48) | 0 | 0% (0 of 3) |
| Mine | Tomb Kings of Khemri | 7 | 1 (net +959) | 1 (net +44) | 1 (net +0) | 1 (net +116) | 0 | 3 (net +128) | 0 | 14% (1 of 7) |
| Mine | Vampire Counts | 6 | 1 (net -40) | 0 | 1 (net +60) | 1 (net +97) | 1 (net +0) | 1 (net +0) | 1 | 20% (1 of 5) |
| Mine | Warriors of Chaos | 10 | 2 (net +54) | 0 | 2 (net +313) | 3 (net +0) | 1 (net +27) | 0 | 2 | 25% (2 of 8) |
| Opponent | High Elf Realms | 20 | 3 (net +155) | 1 (net +0) | 3 (net -83) | 6 (net +287) | 0 | 6 (net +90) | 1 | 16% (3 of 19) |
| Opponent | Lizardmen | 7 | 0 | 0 | 2 (net +404) | 1 (net +0) | 0 | 0 | 4 | 67% (2 of 3) |
| Opponent | Orc & Goblin Tribes | 9 | 0 | 0 | 0 | 1 (net +0) | 1 (net +83) | 3 (net +13) | 4 | 0% (0 of 5) |
| Opponent | Skaven | 3 | 2 (net -108) | 0 | 1 (net +80) | 0 | 0 | 0 | 0 | 33% (1 of 3) |
| Opponent | Tomb Kings of Khemri | 7 | 1 (net -66) | 0 | 0 | 2 (net +72) | 0 | 3 (net +125) | 1 | 0% (0 of 6) |
| Opponent | Vampire Counts | 36 | 6 (net +117) | 0 | 12 (net -4) | 8 (net +112) | 4 (net +63) | 5 (net +42) | 1 | 34% (12 of 35) |
| Opponent | Warriors of Chaos | 26 | 5 (net +4) | 0 | 1 (net +0) | 7 (net +30) | 2 (net +160) | 6 (net +196) | 5 | 5% (1 of 21) |
| Opponent | Wood Elf Realms | 30 | 5 (net -66) | 0 | 6 (net -43) | 5 (net +237) | 4 (net +88) | 7 (net +46) | 3 | 22% (6 of 27) |

### Charged fights, damage counted: tk-h2h-mine-949ddcd-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 13 | 217 | 312 | +138 | 178 | 52 | +126 | +58.0 |
| Mine | 50-54% | 2 | 283 | 230 | +22 | 58 | 68 | -10 | -3.7 |
| Mine | Effective (55-75%) | 14 | 302 | 292 | +86 | 186 | 113 | +73 | +24.3 |
| Mine | 76-89% | 20 | 330 | 165 | +39 | 121 | 63 | +58 | +17.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 32 | 199 | 147 | +70 | 110 | 35 | +75 | +37.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 455 | 98 | +53 | 74 | 12 | +62 | +13.5 |
| Mine | No odds | 11 | 257 | 278 | +70 | 125 | 45 | +80 | +31.4 |
| Mine | All fights | 101 | 272 | 203 | +72 | 129 | 53 | +76 | +27.8 |
| Opponent | Long shot (under 50%) | 22 | 219 | 265 | +26 | 150 | 118 | +32 | +14.8 |
| Opponent | 50-54% | 1 | 151 | 138 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Effective (55-75%) | 25 | 290 | 271 | +13 | 110 | 106 | +4 | +1.3 |
| Opponent | 76-89% | 30 | 344 | 203 | +138 | 176 | 48 | +127 | +37.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 30 | 271 | 188 | +89 | 120 | 30 | +90 | +33.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 555 | 129 | +91 | 109 | 0 | +109 | +19.5 |
| Opponent | No odds | 19 | 318 | 247 | +80 | 125 | 45 | +80 | +25.1 |
| Opponent | All fights | 138 | 310 | 221 | +74 | 134 | 61 | +73 | +23.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| tk-h2h-mine-949ddcd-p4 | move | 426 | 97 (23%) | 68 (16%) | 67 (16%) | 262 (62%) |
| tk-h2h-mine-949ddcd-p4 | objective | 360 | 53 (15%) | 37 (10%) | 54 (15%) | 253 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

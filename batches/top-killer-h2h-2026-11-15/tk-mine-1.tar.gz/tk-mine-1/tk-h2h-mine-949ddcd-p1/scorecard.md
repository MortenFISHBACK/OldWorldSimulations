# Doctrine scorecard: tk-h2h-mine-949ddcd-p1

### Scorecard: tk-h2h-mine-949ddcd-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 8 | - | 0 | 0 | 0 | 0 | 0 | 77 |
| L0102 | 6 | 1 | Opponent | no | 6 | 1 | 3 | 1 | 1 | 0 | 0 | 170 |
| L0118 | 4 | 1 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 639 |
| L0118 | 4 | 1 | Opponent | no | 3 | 2 | 2 | 4 | 0 | 0 | 0 | 68 |
| L0135 | 3 | 1 | Mine | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Opponent | no | 4 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Opponent | - | - | 4 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | yes | 2 | 2 | 3 | 3 | 0 | 0 | 0 | 170 |
| L0235 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 1 | 3 | 6 | 0 | 0 | 0 | 0 | 590 |
| L0319 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 1 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Mine | yes | 6 | 2 | 7 | 2 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 4 | - | 1 | 0 | 0 | 0 | 0 | 1120 |
| L0421 | 1 | 1 | Mine | no | 0 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 0 | 4 | 0 | 0 | 0 | 355 |
| L0508 | 4 | 1 | Mine | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 1416 |
| L0508 | 4 | 1 | Opponent | no | 3 | - | 0 | 4 | 0 | 0 | 0 | 515 |
| L0524 | 2 | 1 | Mine | - | - | 3 | 3 | 1 | 0 | 0 | 0 | 698 |
| L0524 | 2 | 1 | Opponent | - | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 0 | - | 2 | 2 | 0 | 0 | 0 | 828 |
| L0612 | 6 | 1 | Opponent | no | 4 | 3 | 2 | 0 | 0 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | 5 | 2 | 0 | 0 | 0 | 0 | 981 |
| L0628 | 4 | 1 | Opponent | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0717 | 3 | 1 | Mine | yes | 3 | 2 | 2 | 0 | 1 | 0 | 0 | 420 |
| L0717 | 3 | 1 | Opponent | yes | 1 | 5 | 2 | 0 | 3 | 0 | 0 | 0 |
| L0733 | 1 | 1 | Mine | no | 7 | 3 | 2 | 1 | 0 | 0 | 0 | 375 |
| L0733 | 1 | 1 | Opponent | no | 0 | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 10 | 5 | 1 | 1 | 0 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 5 | 2 | 0 | 0 | 60 |
| L0913 | 1 | 1 | Mine | no | 3 | - | 0 | 1 | 0 | 0 | 0 | 524 |
| L0913 | 1 | 1 | Opponent | no | 3 | - | 1 | 1 | 1 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 793 |
| L0930 | 6 | 1 | Opponent | no | 2 | 2 | 3 | 3 | 1 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 501 |
| L1021 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 4 | 0 | 0 | 0 | 355 |
| L1114 | 4 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 500 |
| L1131 | 3 | 1 | Mine | no | 0 | - | 3 | 0 | 0 | 0 | 0 | 330 |
| L1131 | 3 | 1 | Opponent | no | 0 | - | 2 | 2 | 2 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 8 | 2 | 6 | 1 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 0 | - | 1 | 1 | 0 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | yes | - | 3 | 3 | 2 | 0 | 0 | 0 | 479 |
| L1319 | 5 | 1 | Opponent | no | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 3 | 4 | 0 | 0 | 1 | 0 | 0 | 317 |
| L1335 | 3 | 1 | Opponent | no | 0 | 3 | 3 | 3 | 0 | 0 | 0 | 251 |
| L1431 | 3 | 1 | Mine | no | 2 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 0 | 4 | 3 | 1 | 4 | 0 | 0 | 340 |
| L1527 | 3 | 1 | Mine | yes | 9 | 4 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 0 | 2 | 6 | 2 | 1 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | yes | - | 3 | 1 | 1 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | yes | - | 1 | 3 | 5 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | no | 6 | 1 | 3 | 0 | 1 | 0 | 0 | 135 |
| L1723 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 0 | 2 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | no | - | 3 | 2 | 2 | 1 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 5 | 2 | 0 | 0 | 0 | 70 |
| L1923 | 3 | 1 | Mine | yes | 4 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | no | 4 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2025 | 3 | 1 | Mine | yes | 1 | 2 | 3 | 1 | 1 | 0 | 0 | 955 |
| L2025 | 3 | 1 | Opponent | no | 5 | 4 | 8 | 3 | 0 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | yes | 9 | - | 1 | 3 | 1 | 0 | 0 | 500 |
| L2127 | 3 | 1 | Opponent | no | 2 | 2 | 5 | 2 | 2 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 2 | 3 | 0 | 0 | 0 | 0 | 72 |
| L2231 | 5 | 1 | Opponent | no | - | 2 | 5 | 1 | 3 | 0 | 0 | 1248 |
| L2335 | 1 | 1 | Mine | no | 0 | 2 | 2 | 0 | 1 | 0 | 0 | 72 |
| L2335 | 1 | 1 | Opponent | no | 2 | 2 | 4 | 3 | 1 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | 4 | 0 | 2 | 0 | 0 | 0 | 68 |
| L2531 | 5 | 1 | Opponent | no | - | 5 | 0 | 4 | 1 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Mine | no | 1 | 1 | 9 | 3 | 0 | 0 | 0 | 60 |
| L2730 | 6 | 1 | Opponent | no | 4 | 4 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 6 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Opponent | no | 2 | 1 | 2 | 0 | 0 | 0 | 0 | 56 |
| **Average** | | | Mine | 32% | 3.1 | 2.7 | 2.7 | 1.0 | 0.2 | 0.0 | 0.0 | 343.8 |
| **Average** | | | Opponent | 9% | 1.7 | 2.5 | 2.9 | 2.0 | 0.7 | 0.0 | 0.0 | 159.7 |

### KPIs: tk-h2h-mine-949ddcd-p1

Rules off - Opponent only: STAY WORTH, BEST MOVE FOR SHOOTERS, THREAT IN THE KILL, FOCUS OVER TURNS, MISSILES IN THE PLAN, FACE THE CAST, WIZARD FRONT RANK, THREAT OVER THE TURNS, THREAT TO WORN DOWN.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 33% (58 of 176) | 3% (6 of 177) | 18% (64 of 353) |
| Winner chose to follow up after the loser gave ground |  | 99% (70 of 71); on the table 100% | 97% (58 of 60); on the table 97% | 98% (128 of 131); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 80% (16 of 20); on the table 85% | 67% (8 of 12); on the table 67% | 75% (24 of 32); on the table 78% |
| Winner chose to pursue after the loser fled |  | 57% (16 of 28); on the table 61% | 75% (24 of 32); on the table 75% | 67% (40 of 60); on the table 68% |
| Winner chose to follow up or pursue (all three) |  | 86% (102 of 119); on the table 88% | 87% (90 of 104); on the table 87% | 86% (192 of 223); on the table 87% |
| Magic missiles tried each own turn | 50%+ | 35% (117 of 330) | 37% (78 of 210) | 36% (195 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 51% (117 of 230) | 50% (72 of 144) | 51% (189 of 374) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 24% (36 of 150) | 26% (22 of 84) | 25% (58 of 234) |
|     round 1 |  | 16% (4 of 25) | 14% (2 of 14) | 15% (6 of 39) |
|     rounds 2+ |  | 26% (32 of 125) | 29% (20 of 70) | 27% (52 of 195) |
|   other wizards | 50%+ | 45% (81 of 180) | 42% (50 of 120) | 44% (131 of 300) |
|     round 1 |  | 27% (8 of 30) | 20% (4 of 20) | 24% (12 of 50) |
|     rounds 2+ |  | 49% (73 of 150) | 46% (46 of 100) | 48% (119 of 250) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 55% (17 of 31) | 58% (28 of 48) | 57% (45 of 79) |
| Points that never fought | lower | 39% (27929 of 71484) | 35% (25066 of 71889) | 37% (52995 of 143373) |
|   infantry points that never fought | lower | 48% (8166 of 16863) | 50% (6643 of 13348) | 49% (14809 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 51% (141 of 279) | 60% (177 of 295) | 55% (318 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 95% (21 of 22); 2.1 uses a game | 80% (16 of 20); 1.5 uses a game | 88% (37 of 42); 1.8 uses a game |
| Bound items with another spell used |  | 56% (9 of 16); 0.7 uses a game | 25% (2 of 8); 0.1 uses a game | 46% (11 of 24); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 53% (10 of 19); 0.3 uses a game | 58% (7 of 12); 0.2 uses a game | 55% (17 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 45% (26800 of 59666) | 56% (34968 of 62699) | 50% (61768 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.1 (36%) | 1.1 (30%) | 3.2 (34%) |
| MARCHED: its unit marched | 0.9 (15%) | 0.5 (13%) | 1.4 (14%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.2 (5%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 1.4 (23%) | 0.7 (18%) | 2.1 (21%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.1 (4%) | 0.1 (1%) |
| FLEEING: fleeing | 0.3 (6%) | 0.2 (5%) | 0.5 (5%) |
| GONE: slain | 0.8 (14%) | 0.7 (20%) | 1.6 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (4%) | 0.1 (3%) | 0.3 (3%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.2 | 1.1 | 1.6 | 5.4 | 0.5 | 1.8 |
| not cast | 3.8 | 3.2 | 3.1 | 9.6 | 1.9 | 22.2 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.8 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 1.1 (33%) | 0.3 (10%) | 3.2 (34%) | 0.4 (21%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (14%) | 0.2 (13%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.1 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (4%) | 0.4 (12%) | 0.2 (7%) | 2.1 (21%) | 0.6 (30%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.3 (10%) | 0.4 (12%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.3 (9%) | 0.0 (1%) | 0.5 (5%) | 0.0 (0%) | 0.7 (3%) |
| GONE: slain | 1.2 (32%) | 0.5 (16%) | 0.6 (21%) | 1.6 (16%) | 0.2 (12%) | 3.1 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (1%) | 0.1 (2%) | 0.1 (3%) | 0.3 (3%) | 0.0 (0%) | 0.2 (1%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.2 (5%) | 0.0 (0%) | 0.0 (0%) | 0.4 (19%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (54%) | 0.4 (11%) | 1.4 (46%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.2 (73%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.4 a game | 0.5 a game | 1.0 a game |
| stood (cast and not dispelled) | 60% (26 of 43) | 64% (9 of 14) | 61% (35 of 57) |
| the unit moved after it | 62% (16 of 26) | 56% (5 of 9) | 60% (21 of 35) |
| it charged on its next turn | 0% (0 of 26) | 0% (0 of 9) | 0% (0 of 35) |
| the enemy charged it first | 19% (5 of 26) | 11% (1 of 9) | 17% (6 of 35) |
| it fought by the end of its next turn | 12% (3 of 26) | 0% (0 of 9) | 9% (3 of 35) |
| it moved out of a charge the enemy had planned (not charged first) | 19% (5 of 26) | 11% (1 of 9) | 17% (6 of 35) |
| none of these (no charge, no fight, no charge escaped) | 62% (16 of 26) | 78% (7 of 9) | 66% (23 of 35) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (613 of 939) | 57% (338 of 588) | 62% (951 of 1527) |
|   cavalry | 58% (45 of 78) | 72% (84 of 117) | 66% (129 of 195) |
|   character | 52% (59 of 113) | 28% (30 of 106) | 41% (89 of 219) |
|   chariot | 42% (40 of 95) | 70% (21 of 30) | 49% (61 of 125) |
|   infantry | 65% (196 of 302) | 55% (132 of 239) | 61% (328 of 541) |
|   monster | 57% (24 of 42) | 57% (20 of 35) | 57% (44 of 77) |
|   war machine | 81% (249 of 309) | 84% (51 of 61) | 81% (300 of 370) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (18%) | 1.8 (25%) | 3.4 (21%) |
| CHARGED: it charged | 1.1 (13%) | 1.2 (17%) | 2.3 (15%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.8 (9%) | 0.6 (9%) | 1.4 (9%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 1.8 (20%) | 1.4 (20%) | 3.2 (20%) |
| ONLY IN COMBAT: the only targets were in combat | 0.8 (9%) | 0.5 (7%) | 1.2 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.2 (24%) | 0.9 (12%) | 3.0 (19%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.4 (5%) | 0.6 (4%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| OTHER BAR | 0.3 (4%) | 0.1 (2%) | 0.5 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.3 | 1.2 | 81% | 5.1 pts | 27 pts |
| character | 2.9 | 1.1 | 73% | 7.7 pts | 22 pts |
| chariot | 1.7 | 1.0 | 69% | 11.6 pts | 20 pts |
| infantry | 13.2 | 5.0 | 74% | 8.8 pts | 116 pts |
| monster | 1.5 | 0.3 | 83% | 4.0 pts | 6 pts |
| war machine | 8.3 | 7.2 | 58% | 25.8 pts | 215 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.7 | 5.1 | 4.9 |
| Charges that made contact a game | 3.7 | 3.7 | 3.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.95 declared, 0.91 contact (22 units) | 0.36 declared, 0.14 contact (14 units) | 0.72 declared, 0.61 contact (36 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.67 declared, 0.50 contact (6 units) | 1.20 declared, 1.00 contact (10 units) | 1.00 declared, 0.81 contact (16 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.57 declared, 0.44 contact (253 units) | 0.59 declared, 0.43 contact (283 units) | 0.58 declared, 0.43 contact (536 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 63% (44 of 70) | 57% (12 of 21) | 25% (2 of 8) | 59% (58 of 99) |
| Character in a unit | 75% (27 of 36) | 57% (13 of 23) | 100% (4 of 4) | 70% (44 of 63) |
| Character on its own | 76% (39 of 51) | 43% (16 of 37) | 31% (19 of 62) | 49% (74 of 150) |
| Chariot | 56% (9 of 16) | 60% (6 of 10) | - | 58% (15 of 26) |
| Infantry | 51% (45 of 89) | 36% (13 of 36) | 50% (1 of 2) | 46% (59 of 127) |
| Monster | 53% (17 of 32) | 90% (9 of 10) | - | 62% (26 of 42) |
| Monstrous | 64% (7 of 11) | 43% (6 of 14) | - | 52% (13 of 25) |
| War Machines | 68% (28 of 41) | 100% (1 of 1) | - | 69% (29 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 88% (21 of 24); on the table 96% | 51% (71 of 138) | 41% | 45% (15 of 33) | 100% (9 of 9); 5.8 uses a game | 100% (3 of 3); 2.2 uses a game | 78% (7 of 9); 1.2 uses a game |
| Chaos Dwarfs | 3 | 70% (7 of 10); on the table 70% | 17% (4 of 24) | 35% | 46% (11 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |
| Dwarfen Mountain Holds | 5 | 100% (12 of 12); on the table 100% | - | 51% | 61% (25 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 78% (7 of 9); on the table 89% | 50% (18 of 36) | 58% | 61% (39 of 64) | 0.0 uses a game | 50% (1 of 2); 0.7 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 5 | 88% (14 of 16); on the table 88% | 22% (24 of 108) | 39% | 36% (16 of 44) | 92% (11 of 12); 8.4 uses a game | 100% (1 of 1); 0.2 uses a game | 20% (1 of 5); 0.2 uses a game |
| High Elf Realms | 6 | 100% (18 of 18); on the table 100% | 27% (8 of 30) | 38% | 51% (25 of 49) | 100% (5 of 5); 2.5 uses a game | 33% (6 of 18); 1.7 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | - | - | 61% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 82% (9 of 11); on the table 82% | - | 21% | 43% (6 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 100% (7 of 7); on the table 100% | 17% (2 of 12) | 39% | 62% (13 of 21) | 100% (3 of 3); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (13 of 13); on the table 100% | 19% (7 of 36) | 6% | 62% (15 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Skaven | 4 | 90% (18 of 20); on the table 90% | 43% (13 of 30) | 22% | 53% (18 of 34) | 100% (3 of 3); 2.5 uses a game | 0.0 uses a game | 50% (2 of 4); 0.5 uses a game |
| Tomb Kings of Khemri | 6 | 52% (11 of 21); on the table 52% | 0% (0 of 12) | 34% | 40% (12 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 88% (21 of 24); on the table 88% | 41% (22 of 54) | 31% | 64% (32 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 93% (25 of 27); on the table 93% | 43% (13 of 30) | 34% | 66% (49 of 74) | 100% (4 of 4); 1.9 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 82% (9 of 11); on the table 82% | 43% (13 of 30) | 37% | 56% (37 of 66) | 33% (2 of 6); 1.2 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (tk-h2h-mine-949ddcd-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 54% (44) | 42% (35) | 48% (79) |
| ...free all their last turn and able to turn (per game) | 0.53 | 0.53 | 1.06 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.28 | 0.17 | 0.44 |
| ...with the charger already in that arc before they moved (per game) | 0.25 | 0.33 | 0.58 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.08 | 1.36 | 2.44 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.83 | 0.75 | 1.58 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 4.89 | 5.36 | 10.25 |

### Quality by phase: tk-h2h-mine-949ddcd-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 57% (85 of 148) | 46% (82 of 177) |
| Strategy | Shoot objectives carried out (shot that target) | 49% (228 of 465) | 60% (107 of 177) |
| Strategy | Close-in objectives charged next turn | 13% (17 of 135) | 13% (28 of 211) |
| Strategy | Support requests answered (helper made contact too) | 60% (9 of 15) | 52% (12 of 23) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (4 of 4) | 25% (1 of 4) |
| Strategy | Hexes on a unit its side charged or shot that turn | 82% (9 of 11) | 45% (5 of 11) |
| Strategy | Joined characters whose unit fought | 37% (20 of 54) | 62% (23 of 37) |
| Strategy | Lone characters that fought | 79% (73 of 92) | 75% (74 of 99) |
| Movement | Charges halted short of contact | 0.0 | 0.2 |
| Movement | Idle units | 1.0 | 2.0 |
| Movement | Points that never moved of their own | 343.8 | 159.7 |
| Movement | Fights charged into per game | 3.2 | 3.2 |
| Movement | Charges with odds: long shots (under 50%) | 16 of 107, net +48 | 26 of 102, net +38 |
| Movement | Charges with odds: sweet spot (55-75%) | 19 of 107, net +145 | 11 of 102, net -51 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 13 of 107, net +127 | 4 of 102, net +68 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 42 of 107, net +89 | 39 of 102, net +186 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.0 | 8.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (170 of 395) | 47% (152 of 321) |
| Shooting | Points destroyed by shooting units | 68.6 | 36.3 |
| Shooting | War machine shots | 6.9 | 1.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 42% (104 of 249) | 27% (14 of 51) |
| Shooting | Points destroyed by war machines | 113.4 | 5.0 |
| Magic | Magic missiles cast | 2.1 | 1.5 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 55% (42 of 76) | 25% (14 of 55) |
| Magic | Wounds caused by magic missiles | 4.4 | 1.7 |
| Magic | Wounds caused by other spells | 1.8 | 0.9 |
| Magic | Points destroyed by magic (all spells) | 135.2 | 36.8 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.5 / 0.3 / 0.8 / 0.1 | 1.5 / 0.4 / 0.4 / 0.1 |
| Combat | Points destroyed in combat | 381.6 | 305.5 |
| Combat | Points run down | 41.9 | 164.1 |
| Combat | Net points per charged fight, damage counted | +77 | +79 |
| Combat | Net per 100 charger points, damage counted | +29.0 | +32.2 |
| Combat | First round won (charged fights) | 75% | 58% |
| Combat | Net points per charged fight | +82 | +80 |
| Combat | Net points per supported fight / lone fight | +139 / +73 | +155 / +67 |
| Combat | Charged fights on a top-3 enemy unit | 45 of 115 | 56 of 116 |
| Game | Points lost | 604.6 | 841.0 |
| Game | VP from objectives | 689.2 | 519.4 |
| Game | Lone holders (player turns) | 3.1 | 1.7 |

- Mine won / drew / lost: 19 / 7 / 10 of 36 ended games (of 36); mean margin (Mine - Opponent) +409 VP
- The side that went first won 14 of 29 games with a winner
- Points traded per game (both sides' losses): 1446
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: tk-h2h-mine-949ddcd-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 1.8 | 0.8 | +0.0 | 0.0 | 3.5 |
| ARRIVAL HUNT | 0.0 | +0.1 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 6.4 | 0.3 | +0.0 | 0.0 | 3.6 |
| BACKUP TARGETS | 0.9 | +8.0 | 0.0 | 14.7 | 0.8 | +3.9 | 0.0 | 16.3 |
| BEST FACING | 0.4 | +12.0 | 0.0 | 17.2 | 0.6 | +18.7 | 0.0 | 31.9 |
| BEST FIRST | 3.4 | +162.5 | 135.4 | 15.4 | 4.1 | +190.5 | 86.6 | 81.1 |
| BEST MOVE FOR SHOOTERS | 1.0 | +104.3 | 0.0 | 18.4 | - | - | - | - |
| BEST OVERALL | 0.4 | +22.2 | 0.0 | 5.2 | 0.4 | +41.7 | 0.0 | 11.4 |
| BEST PREY | 0.8 | +49.1 | 40.8 | 14.1 | 1.0 | +65.5 | 26.7 | 31.1 |
| BEST PRIZE | 0.1 | -2.7 | 1.8 | 0.0 | - | - | - | - |
| BIG CHARACTER SAFETY | 0.1 | -0.7 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 24.2 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 15.9 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.2 | +12.7 | 0.0 | 0.0 | 0.4 | +4.5 | 0.0 | 1.8 |
| BOMBING RUN | 0.1 | +2.2 | 0.0 | 4.2 | - | - | - | - |
| CANNON PLAN MISSED | 1.0 | +0.0 | 147.0 | 3.5 | 0.1 | +0.0 | 6.3 | 0.0 |
| CANNON PLANNED TARGET | 5.4 | +130.9 | 434.7 | 30.6 | 1.2 | +25.7 | 19.7 | 8.9 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 3.5 | 0.4 | +0.0 | 0.0 | 7.2 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 10.2 | 0.0 |
| CARRIES OUT SET-UP | 0.0 | +0.0 | 0.0 | 10.6 | 0.1 | +0.0 | 8.1 | 0.0 |
| CAST JOB | 0.9 | +36.1 | 82.8 | 0.0 | 0.4 | +11.7 | 30.8 | 29.6 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +64.7 | 26.9 | 0.0 | 0.2 | +4.4 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 31.3 | 0.4 | +0.0 | 0.0 | 15.2 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | - | - | - | - | 0.0 | +1.1 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | -0.6 | 4.7 | 1.8 | 0.2 | -0.1 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 3.1 | +0.0 | 256.9 | 86.7 | 2.7 | +0.0 | 246.3 | 100.1 |
| CHARGE NOW WEIGHED | 0.3 | -24.7 | 1.4 | 26.8 | 0.5 | -31.1 | 25.8 | 12.4 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -2.0 | 0.0 | 22.2 | 0.1 | -2.4 | 0.0 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 1.7 | 0.1 | +0.0 | 8.0 | 2.7 |
| COMBAT PIVOT | 0.6 | +0.0 | 40.2 | 9.3 | 0.3 | +0.0 | 23.6 | 34.5 |
| CONVEYANCE SEARCH | 0.7 | +68.9 | 19.5 | 11.1 | 0.3 | +92.7 | 31.9 | 15.2 |
| COUNTER-CHARGE COVER | 9.2 | +857.4 | 0.0 | 136.8 | 7.7 | +789.4 | 0.0 | 164.4 |
| DEFENSIVE ARMY | 0.4 | +0.0 | 42.8 | 5.1 | 0.0 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.1 | +0.8 | 0.0 | 6.7 | 0.0 | +0.1 | 0.0 | 3.0 |
| EDGE GIVE GROUND | 0.1 | +1.0 | 3.5 | 0.0 | 0.1 | +6.5 | 4.1 | 0.0 |
| ELIXIR WORTH | 0.0 | +0.4 | 0.0 | 0.0 | 0.1 | +0.9 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACE THE CAST | 0.1 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.1 | +90.8 | 0.0 | 33.1 | 1.4 | +109.3 | 0.0 | 56.0 |
| FALLBACK BY WORTH | 4.3 | +69.0 | 0.0 | 59.9 | 5.6 | +74.6 | 0.0 | 71.8 |
| FIGHT LIFT | 0.1 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| FIRE AND FLEE | - | - | - | - | 0.0 | +0.3 | 0.0 | 4.4 |
| FLANK NOT WEIGHED | 4.4 | +0.0 | 0.0 | 80.7 | 5.6 | +0.0 | 0.0 | 149.6 |
| FOCUS FIRE | 0.1 | +1.8 | 1.9 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| FOCUS OVER TURNS | 2.2 | +76.2 | 154.2 | 16.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.9 | +134.2 | 0.0 | 52.4 | 1.1 | +159.2 | 0.0 | 55.9 |
| FRIENDS SHOTS CHECKED | 0.2 | +25.5 | 0.0 | 2.1 | 0.1 | +12.8 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -0.5 | 3.1 | 1.4 | 0.1 | -3.9 | 14.3 | 1.4 |
| GROUND FLIERS | - | - | - | - | 0.0 | +0.7 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 0.0 | 2.6 |
| HELPER UNSEEN | 0.1 | +0.0 | 38.1 | 5.7 | 0.4 | +0.0 | 13.2 | 23.5 |
| HILL BY ITS CHANCE | - | - | - | - | 0.2 | -16.9 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +0.4 | 0.0 | 0.0 | 0.2 | +10.7 | 0.0 | 10.0 |
| HUNT DROPPED | 0.1 | +0.0 | 7.6 | 0.0 | 0.1 | +0.0 | 0.0 | 5.2 |
| HUNT IN PAIRS | 0.4 | +36.2 | 0.0 | 10.2 | 0.3 | +23.0 | 0.0 | 0.0 |
| HUNT KEPT | 0.1 | +0.8 | 10.6 | 0.0 | 0.1 | +1.5 | 2.8 | 1.2 |
| HUNT RESULT | 0.1 | +5.5 | 7.6 | 0.0 | 0.2 | +8.0 | 2.8 | 12.0 |
| HUNT THE GUNS | 0.1 | +25.5 | 0.0 | 0.0 | 0.2 | +93.7 | 0.0 | 11.7 |
| INVITES THE FIGHT | 1.9 | +49.6 | 70.8 | 45.0 | 1.8 | +30.5 | 57.2 | 31.1 |
| JOINT CHARGE PLAN | 0.1 | +9.5 | 0.0 | 0.0 | 0.2 | +18.9 | 0.0 | 17.6 |
| KEEP FALLS | 0.1 | +0.1 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | - | - | - | - | 0.2 | +0.9 | 1.8 | 0.0 |
| KEEPS ITS TARGET | 1.6 | +48.3 | 124.0 | 62.8 | 1.9 | +58.3 | 127.6 | 62.1 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.9 | +72.4 | 148.8 | 44.8 | 2.0 | +97.9 | 153.2 | 63.2 |
| KILLS COUNT NEXT TURN | 4.2 | +152.4 | 195.1 | 92.2 | 7.1 | +251.0 | 286.7 | 219.9 |
| LONE CHARACTER SAFE SPOT | 0.4 | +8.6 | 2.0 | 15.0 | 0.9 | +14.6 | 31.4 | 33.6 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 47.3 | 20.5 |
| LONE WIZARD KEPT IN | 0.7 | +49.1 | 0.0 | 0.0 | 0.2 | +24.5 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | -4.6 | 50.2 | 21.9 | 0.5 | -2.6 | 29.7 | 17.1 |
| LOST CHARGE | 2.6 | -37.1 | 90.0 | 52.6 | 3.0 | -43.7 | 55.3 | 103.1 |
| LURE BY WHAT IT DRAWS | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | -2.8 | 0.0 | 4.0 |
| MAKE SURE TOGETHER | 0.3 | +29.7 | 4.7 | 7.2 | 0.6 | +97.4 | 25.4 | 20.9 |
| MANOEUVRE | 0.3 | +9.9 | 0.0 | 0.0 | 0.2 | +3.3 | 0.0 | 5.1 |
| MARCH AT ESCAPER | 0.1 | +0.4 | 0.0 | 25.9 | 0.0 | +0.0 | 0.0 | 3.2 |
| MARCH CHECK | 0.4 | +25.0 | 0.0 | 5.5 | 0.7 | +42.5 | 0.0 | 0.0 |
| MARCH ODDS | 0.2 | +12.4 | 4.4 | 10.9 | 0.3 | +19.6 | 14.5 | 15.5 |
| MARCH OVER CASTS | 0.3 | +26.2 | 0.0 | 5.5 | 0.3 | +18.5 | 0.0 | 25.1 |
| MAX FOR POSITIONING | 4.0 | +176.2 | 0.0 | 72.4 | 5.0 | +171.5 | 0.0 | 114.0 |
| MISSILES IN THE MOVE | 4.5 | +291.7 | 0.0 | 46.2 | 4.0 | +76.7 | 0.0 | 98.3 |
| MISSILES IN THE PLAN | 1.4 | +29.6 | 120.1 | 3.6 | - | - | - | - |
| MISSILES NEXT TURN | 4.9 | +180.1 | 0.0 | 112.5 | 4.3 | +46.3 | 0.0 | 115.7 |
| MODEL FACING | 0.3 | +95.7 | 0.0 | 0.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.4 | +36.9 | 0.0 | 11.1 | 0.4 | +30.1 | 0.0 | 26.3 |
| MOVE SPELL IN RANGE | 0.1 | +5.3 | 0.0 | 0.0 | 0.1 | +1.2 | 0.0 | 15.2 |
| MOVE SPELL OUT OF RANGE | 0.3 | -70.1 | 0.0 | 7.2 | 0.1 | -13.6 | 10.3 | 7.6 |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 22.2 | 0.1 | +0.0 | 0.0 | 12.3 |
| MOVE TO CHARGE | 2.7 | +175.6 | 59.8 | 88.1 | 4.8 | +410.7 | 203.9 | 145.9 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +18.6 | 1.7 | 0.0 | 0.1 | +6.8 | 13.9 | 3.2 |
| NO RALLY LEFT | 0.0 | +3.2 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.1 | -2.7 | 8.7 | 1.2 | 0.2 | -13.8 | 33.0 | 2.5 |
| NOT TURNED | 4.9 | +144.2 | 0.0 | 116.6 | 5.4 | +38.6 | 0.0 | 101.4 |
| NOT WORTH A CAST | 0.9 | -0.9 | 0.0 | 36.1 | 0.2 | -0.3 | 0.0 | 15.2 |
| OFF BEST | 15.8 | -880.1 | 14.7 | 293.0 | 15.6 | -892.5 | 8.8 | 331.1 |
| OPENS A LANE | 0.2 | +1.7 | 23.1 | 4.9 | 0.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +28.4 | 15.2 | 0.0 | 0.2 | +20.1 | 7.3 | 7.9 |
| OVERRUNS AWAY | 0.6 | +25.8 | 48.1 | 26.5 | 0.6 | +8.0 | 49.8 | 4.7 |
| PATHS CROSS | 1.8 | +118.0 | 0.0 | 29.9 | 2.3 | +152.8 | 0.0 | 52.1 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +5.1 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -0.7 | 0.0 | 7.1 | 0.1 | -0.8 | 0.0 | 2.9 |
| PLAN RESULT | 38.2 | +1702.0 | 1357.7 | 790.0 | 37.7 | +1031.5 | 1316.7 | 1086.4 |
| PURSUES BIG PREY | 0.1 | -3.2 | 0.0 | 5.2 | 0.1 | -6.7 | 0.0 | 12.0 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.1 | +5.7 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.9 | +7.2 | 0.0 | 9.9 | 1.3 | +13.6 | 0.0 | 50.7 |
| RANDOM MOVER NO PROMISE | 0.2 | -9.5 | 15.1 | 4.0 | 0.3 | -12.0 | 0.0 | 14.6 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -1.9 | 0.0 | 1.5 | 0.4 | -5.7 | 0.0 | 4.2 |
| REDIRECT COUNTER | 1.8 | +120.7 | 0.0 | 42.6 | 4.3 | +394.0 | 0.0 | 85.4 |
| REDIRECT WEIGHED | 0.2 | +2.7 | 3.0 | 0.0 | 0.2 | +0.4 | 0.0 | 4.0 |
| RESERVE FALL BACK | 0.3 | +3.7 | 0.0 | 7.4 | 1.0 | +30.5 | 0.0 | 22.4 |
| RESTRAINS TO SHOOT | 0.1 | +3.6 | 0.0 | 7.2 | 0.1 | +8.1 | 0.0 | 3.1 |
| RISK BY ARC | 2.7 | +84.8 | 220.2 | 112.2 | 3.1 | +79.7 | 226.2 | 95.6 |
| SAFER THAN THE JOB | 0.8 | +52.2 | 0.0 | 6.5 | 0.8 | +36.1 | 0.0 | 12.4 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 1.9 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 1.9 |
| SCREEN BY WHAT IT SAVES | 0.1 | -8.3 | 0.0 | 0.0 | 0.2 | -8.4 | 0.0 | 1.0 |
| SEARCH SPOT | 2.2 | +79.1 | 0.0 | 18.3 | 2.9 | +148.8 | 0.0 | 40.6 |
| SELF MOVE SPELL | 0.2 | +24.8 | 0.0 | 18.1 | 0.3 | +16.7 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.5 | +73.7 | 4.7 | 35.8 | 1.8 | +173.4 | 25.4 | 71.5 |
| SET-UP ANY TARGET | 0.3 | +36.5 | 11.1 | 11.1 | 0.1 | +2.7 | 0.0 | 0.0 |
| SET-UP MISSED | 0.0 | +4.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTER COUNTED ONCE | 0.0 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.4 | +52.5 | 93.9 | 8.8 | 0.7 | +35.0 | 55.1 | 9.7 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 3.8 |
| SHOT OPTIONS | 16.5 | +0.0 | 896.5 | 235.1 | 9.7 | +0.0 | 255.9 | 256.5 |
| SHOT REPLANNED | 0.9 | +0.0 | 164.2 | 9.0 | 0.2 | +0.0 | 25.5 | 3.9 |
| SHOTS IN THE MOVE | 15.9 | +546.4 | 0.0 | 223.0 | 8.4 | +203.2 | 0.0 | 155.2 |
| SPELL CATCH ODDS | 0.0 | -0.3 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.3 | +52.0 | 11.1 | 11.1 | 0.2 | +81.1 | 12.3 | 0.0 |
| SPELL WORTH | 1.3 | +18.4 | 64.2 | 64.2 | 1.7 | +33.6 | 115.6 | 122.6 |
| STABLE ROLE | 11.6 | +0.0 | 477.4 | 115.3 | 10.1 | +0.0 | 303.3 | 215.1 |
| STANDS TO CAST | 0.1 | +6.0 | 0.0 | 0.0 | 0.0 | +0.8 | 0.0 | 0.0 |
| STAY WEIGHED | 0.1 | +6.7 | 0.0 | 0.0 | - | - | - | - |
| STAY WORTH | 21.5 | +303.7 | 638.2 | 224.4 | - | - | - | - |
| STOPS | 0.1 | +1.9 | 5.3 | 0.0 | 0.1 | +2.2 | 0.0 | 1.7 |
| STOPS SHORT OF THE FLANK | 0.3 | +10.9 | 0.0 | 0.0 | 0.5 | +36.7 | 0.0 | 26.2 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 4.0 |
| SUPPORT NARROWED | 5.9 | -52.1 | 315.6 | 113.1 | 7.7 | -53.9 | 345.2 | 95.9 |
| SUPPORTS | 3.7 | +55.6 | 139.5 | 42.4 | 5.2 | +58.9 | 167.1 | 61.4 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -8.7 | 3.8 | 0.0 | 0.1 | -3.5 | 0.0 | 2.4 |
| SURE REACH TOGETHER | 0.3 | -1.8 | 7.0 | 15.5 | 0.6 | +0.6 | 3.8 | 27.3 |
| THREAT IN THE KILL | 12.5 | +191.1 | 870.7 | 206.4 | - | - | - | - |
| THREAT OVER THE TURNS | 9.8 | +130.1 | 827.4 | 160.0 | - | - | - | - |
| THREAT TO WORN DOWN | 11.8 | +164.8 | 851.1 | 192.6 | - | - | - | - |
| THROUGH LINE OF FIRE | 0.5 | +19.6 | 0.0 | 1.0 | 0.2 | +6.4 | 0.0 | 0.0 |
| TURN WORTH | 0.7 | -43.4 | 45.6 | 12.9 | 0.4 | -24.2 | 29.8 | 7.8 |
| TWO OR MORE ARRIVE | 0.1 | +0.7 | 4.7 | 12.4 | 0.4 | +10.8 | 21.8 | 12.7 |
| WAIT AFTER COSTS | 6.7 | -297.7 | 213.0 | 155.7 | 8.3 | -438.8 | 305.3 | 189.4 |
| WALKS TO THE FIGHT | 1.8 | +36.1 | 58.8 | 12.4 | 1.1 | +24.8 | 5.8 | 10.0 |
| WAR ENGINE CHARGES | 0.1 | +19.1 | 1.8 | 0.0 | 0.2 | +6.0 | 0.0 | 2.1 |
| WAR ENGINE JOBS | 0.6 | +0.0 | 24.7 | 15.3 | 0.4 | +0.0 | 1.4 | 11.0 |
| WEARS DOWN | 1.1 | +51.3 | 107.4 | 56.0 | 1.4 | +33.3 | 107.6 | 42.0 |
| WHO HITS BACK | 0.4 | +27.8 | 0.0 | 20.0 | 0.3 | +15.3 | 0.0 | 4.7 |
| WHOLE FIGHT | 0.4 | +20.5 | 73.4 | 11.9 | 0.5 | +37.8 | 83.2 | 4.4 |
| WHOLE FIGHT GAIN | 0.2 | +18.5 | 6.4 | 10.2 | 0.6 | +70.2 | 54.7 | 18.2 |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |

### Rule changes: tk-h2h-mine-949ddcd-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1131 | 1131 | 1131 | 31.42 | -63811 | -56.4 |
| BEST FIRST | 270 | 270 | 270 | 7.50 | +12709 | +47.1 |
| SEARCH SPOT | 184 | 184 | 183 | 5.08 | +8290 | +45.3 |
| COUNTER-CHARGE COVER | 610 | 348 | 161 | 4.47 | +10031 | +62.3 |
| PATHS CROSS | 148 | 148 | 148 | 4.11 | +9746 | +65.9 |
| MOVE TO CHARGE | 268 | 268 | 143 | 3.97 | +7710 | +53.9 |
| KILLS COUNT NEXT TURN | 408 | 408 | 121 | 3.36 | +4278 | +35.4 |
| SUPPORTS | 318 | 318 | 112 | 3.11 | +1300 | +11.6 |
| FACES THE THREAT | 88 | 88 | 88 | 2.44 | +7202 | +81.8 |
| SHOTS IN THE MOVE | 877 | 572 | 81 | 2.25 | +1687 | +20.8 |
| FALLBACK BY WORTH | 356 | 356 | 76 | 2.11 | +5168 | +68.0 |
| FOLLOW UP WEIGHED | 75 | 75 | 75 | 2.08 | +10562 | +140.8 |
| WAIT AFTER COSTS | 542 | 542 | 67 | 1.86 | +1415 | +21.1 |
| CANNON PLANNED TARGET | 239 | 239 | 58 | 1.61 | -734 | -12.6 |
| REDIRECT COUNTER | 219 | 127 | 58 | 1.61 | +4461 | +76.9 |
| WALKS TO THE FIGHT | 102 | 102 | 58 | 1.61 | +823 | +14.2 |
| SAFER THAN THE JOB | 57 | 57 | 57 | 1.58 | +3178 | +55.8 |
| ARTILLERY RE-ROLL WEIGHED | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| CANNON SIGHT KEPT | 52 | 52 | 52 | 1.44 | +0 | +0.0 |
| ADVANCE LANE KEPT | 49 | 49 | 49 | 1.36 | +0 | +0.0 |
| RESERVE FALL BACK | 48 | 48 | 48 | 1.33 | +1233 | +25.7 |
| RANDOM MOVE BY FIGURES | 79 | 79 | 45 | 1.25 | +750 | +16.7 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| STAY WORTH | 775 | 628 | 44 | 1.22 | +997 | +22.7 |
| MISSILES IN THE MOVE | 306 | 182 | 42 | 1.17 | +2033 | +48.4 |
| RISK BY ARC | 206 | 200 | 42 | 1.17 | +1210 | +28.8 |
| CHARGE NOW FIRST | 206 | 206 | 41 | 1.14 | -3849 | -93.9 |
| INVITES THE FIGHT | 133 | 133 | 40 | 1.11 | +704 | +17.6 |
| KILLS COUNT | 141 | 141 | 40 | 1.11 | +1488 | +37.2 |
| SHOT REPLANNED | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| FOCUS OVER TURNS | 78 | 78 | 37 | 1.03 | +1012 | +27.4 |
| SET UP TOGETHER | 80 | 67 | 37 | 1.03 | +3341 | +90.3 |
| BEST FACING | 36 | 36 | 36 | 1.00 | +1103 | +30.6 |
| SHOOTS FROM THE BEST SPOT | 74 | 74 | 36 | 1.00 | +1400 | +38.9 |
| BEST MOVE FOR SHOOTERS | 35 | 35 | 35 | 0.97 | +3756 | +107.3 |
| LONE WIZARD KEPT IN | 34 | 34 | 34 | 0.94 | +2648 | +77.9 |
| MAX FOR POSITIONING | 325 | 176 | 33 | 0.92 | +443 | +13.4 |
| COMBAT PIVOT | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| MARCH CHECK | 37 | 36 | 32 | 0.89 | +1897 | +59.3 |
| MOVE AND CAST | 31 | 31 | 31 | 0.86 | +2410 | +77.7 |
| STOPS SHORT OF THE FLANK | 30 | 30 | 30 | 0.83 | +1713 | +57.1 |
| CHARGE NOW WEIGHED | 29 | 29 | 29 | 0.81 | +1931 | +66.6 |
| BEST OVERALL | 28 | 28 | 28 | 0.78 | +2299 | +82.1 |
| CAST JOB | 49 | 49 | 28 | 0.78 | +582 | +20.8 |
| THROUGH LINE OF FIRE | 27 | 27 | 27 | 0.75 | +937 | +34.7 |
| BEST PREY | 64 | 64 | 26 | 0.72 | +1375 | +52.9 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| THREAT TO WORN DOWN | 426 | 329 | 26 | 0.72 | +176 | +6.8 |
| CASTER AWAY FROM SCREEN | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| WHO HITS BACK | 25 | 25 | 25 | 0.69 | +1103 | +44.1 |
| SHOOTERS IN TWO RANKS | 24 | 24 | 24 | 0.67 | +58 | +2.4 |
| BLOCKED WHEEL | 23 | 23 | 23 | 0.64 | +618 | +26.9 |
| KEEPS ITS TARGET | 128 | 127 | 21 | 0.58 | +324 | +15.4 |
| THREAT IN THE KILL | 450 | 348 | 20 | 0.56 | +184 | +9.2 |
| MARCH ODDS | 19 | 19 | 19 | 0.53 | +302 | +15.9 |
| WHOLE FIGHT GAIN | 32 | 30 | 19 | 0.53 | +1001 | +52.7 |
| CHAFF PASSED | 18 | 18 | 18 | 0.50 | -24 | -1.3 |
| MANOEUVRE | 16 | 16 | 16 | 0.44 | +476 | +29.8 |
| REDIRECT WEIGHED | 16 | 16 | 16 | 0.44 | +376 | +23.5 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| CASTING BLOCK | 26 | 26 | 13 | 0.36 | +725 | +55.8 |
| LOST CHARGE | 201 | 200 | 13 | 0.36 | +187 | +14.4 |
| MAKE SURE TOGETHER | 34 | 24 | 13 | 0.36 | +1708 | +131.3 |
| OPENS UP | 17 | 17 | 11 | 0.31 | +747 | +67.9 |
| THREAT OVER THE TURNS | 354 | 275 | 11 | 0.31 | +102 | +9.3 |
| WAR ENGINE JOBS | 33 | 33 | 11 | 0.31 | -870 | -79.1 |
| BIG CHARACTER SAFETY | 10 | 10 | 10 | 0.28 | -9 | -0.9 |
| FRIENDS SHOTS CHECKED | 10 | 10 | 10 | 0.28 | +1378 | +137.8 |
| MODEL FACING | 10 | 10 | 10 | 0.28 | +3446 | +344.6 |
| PIVOT GUARDS FLANK | 9 | 9 | 9 | 0.25 | -55 | -6.1 |
| STUCK PIVOT | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| RESTRAINS TO SHOOT | 8 | 8 | 8 | 0.22 | +422 | +52.8 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| SURE CHARGE BEATS ADVANCE | 8 | 8 | 8 | 0.22 | -438 | -54.7 |
| HUNT IN PAIRS | 26 | 17 | 7 | 0.19 | +792 | +113.1 |
| MISSILES NEXT TURN | 333 | 201 | 7 | 0.19 | +27 | +3.8 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| PURSUES BIG PREY | 7 | 7 | 7 | 0.19 | -354 | -50.6 |
| WEARS DOWN | 91 | 86 | 7 | 0.19 | +327 | +46.7 |
| BLOCKED CHARGE SKIPPED | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| SUPPORT NARROWED | 488 | 488 | 6 | 0.17 | -72 | -11.9 |
| HUNT ADVANCE | 9 | 9 | 5 | 0.14 | +142 | +28.3 |
| OVERRUNS AWAY | 43 | 42 | 5 | 0.14 | +73 | +14.6 |
| SURE REACH TOGETHER | 33 | 27 | 5 | 0.14 | +6 | +1.3 |
| WHOLE FIGHT | 32 | 32 | 5 | 0.14 | +149 | +29.8 |
| BOMBING RUN | 4 | 4 | 4 | 0.11 | +78 | +19.4 |
| LONE WIZARD HOLDS BACK | 24 | 24 | 4 | 0.11 | -179 | -44.7 |
| NEEDED THERE | 7 | 7 | 4 | 0.11 | +0 | +0.0 |
| ELIXIR WORTH | 3 | 3 | 3 | 0.08 | +49 | +16.4 |
| FOCUS FIRE | 3 | 3 | 3 | 0.08 | +67 | +22.3 |
| JOINT CHARGE PLAN | 10 | 10 | 3 | 0.08 | +196 | +65.4 |
| KEEP FALLS | 3 | 3 | 3 | 0.08 | +37 | +12.5 |
| LONG SHOT | 36 | 35 | 3 | 0.08 | +34 | +11.2 |
| STANDS TO CAST | 3 | 3 | 3 | 0.08 | +61 | +20.3 |
| WAR ENGINE CHARGES | 10 | 10 | 3 | 0.08 | +493 | +164.3 |
| BACKUP TARGETS | 60 | 33 | 2 | 0.06 | +9 | +4.6 |
| BEST PRIZE | 2 | 2 | 2 | 0.06 | -752 | -376.1 |
| DEFENSIVE ARMY | 14 | 14 | 2 | 0.06 | -43 | -21.3 |
| EDGE GIVE GROUND | 7 | 7 | 2 | 0.06 | +164 | +82.1 |
| FACE THE CAST | 2 | 2 | 2 | 0.06 | +35 | +17.6 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +183 | +91.3 |
| RAIDS THE BAGGAGE NEXT TURN | 2 | 2 | 2 | 0.06 | +144 | +72.1 |
| STAY WEIGHED | 2 | 2 | 2 | 0.06 | +239 | +119.7 |
| WOUNDED STAYS OUT | 2 | 2 | 2 | 0.06 | -161 | -80.3 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -28 | -27.5 |
| CHARIOT NO STATIC JOB | 1 | 1 | 1 | 0.03 | -51 | -51.4 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +12 | +11.8 |
| MISSILES IN THE PLAN | 52 | 4 | 1 | 0.03 | +12 | +12.3 |
| MOVE SPELL IN RANGE | 6 | 3 | 1 | 0.03 | +4 | +3.9 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +66 | +66.1 |
| REDIRECT BY WHAT IT STOPS | 18 | 18 | 1 | 0.03 | +29 | +28.9 |
| STOPS | 5 | 5 | 1 | 0.03 | +13 | +13.1 |
| TWO OR MORE ARRIVE | 17 | 16 | 1 | 0.03 | +5 | +5.1 |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 39 | 39 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 2 | 2 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 4 | 4 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 41 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 6 | 6 | 0 | 0.00 | - | - |
| CHEAP HELPER | 7 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 38 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 3 | 3 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 357 | not checked | - | - | - | - |
| GIVES UP | 7 | 6 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 19 | 19 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 6 | 6 | 0 | 0.00 | - | - |
| HUNT DROPPED | 4 | trace | - | - | - | - |
| HUNT KEPT | 6 | trace | - | - | - | - |
| HUNT RESULT | 11 | trace | - | - | - | - |
| HUNT THE GUNS | 11 | trace | - | - | - | - |
| KEEPS ITS PREY | 6 | 6 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 45 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 23 | 23 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 7 | 7 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 15 | trace | - | - | - | - |
| MOVE SPELL SPOT | 16 | not checked | - | - | - | - |
| NOT NEEDED | 13 | 13 | 0 | 0.00 | - | - |
| NOT TURNED | 369 | 369 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 41 | not checked | - | - | - | - |
| OPENS A LANE | 8 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 2730 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 16 | 16 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 12 | 12 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 18 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 12 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOT OPTIONS | 944 | 944 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 19 | not checked | - | - | - | - |
| SPELL WORTH | 108 | not checked | - | - | - | - |
| STABLE ROLE | 782 | 778 | 0 | 0.00 | - | - |
| TURN WORTH | 38 | 38 | 0 | 0.00 | - | - |

### Off best figure: tk-h2h-mine-949ddcd-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.17 | 13.39 | 57.4 |
| FALLBACK | gate | 0.53 | 0.67 | 52.2 |
| TURN GATE | gate | 0.44 | 0.75 | 43.8 |
| CHARGE NOW FIRST | rule | 0.64 | 0.44 | 98.7 |
| LONE CHARACTER SAFE SPOT | gate | 0.08 | 0.44 | 60.9 |
| CANNON PLANNED TARGET | rule | 0.22 | 0.08 | 75.6 |
| WAR ENGINE JOBS | rule | 0.14 | 0.17 | 79.1 |
| SUPPORT REQUEST | gate | 0.14 | 0.14 | 111.3 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.14 | 6.1 |
| FIGHT ORDER BAND | gate | 0.14 | 0.08 | 2.4 |
| SURE CHARGE BEATS ADVANCE | rule | 0.17 | 0.06 | 54.7 |
| PURSUES BIG PREY | rule | 0.06 | 0.14 | 50.6 |
| PATHS CROSS | rule | 0.06 | 0.11 | 30.2 |
| SUPPORT NARROWED | rule | 0.08 | 0.08 | 11.9 |
| AFTERMATH BAND | gate | 0.08 | 0.06 | 2.4 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.14 | - | 41.1 |
| BIG CHARACTER SAFETY | rule | 0.11 | - | 7.9 |
| LONE WIZARD HOLDS BACK | rule | - | 0.11 | 44.7 |
| RULE SWITCHED OFF | gate | - | 0.11 | 12.0 |
| THROUGH LINE OF FIRE | rule | 0.08 | 0.03 | 2.4 |
| CHAFF PASSED | rule | 0.03 | 0.06 | 7.9 |
| CHARGE NOW WEIGHED | rule | - | 0.08 | 27.6 |
| MARCH ODDS | rule | - | 0.08 | 10.8 |
| SAFER THAN THE JOB | rule | 0.08 | - | 10.3 |
| BEST PRIZE | rule | 0.06 | - | 376.1 |
| BLOCKED WHEEL | rule | - | 0.06 | 32.9 |
| DEFENSIVE ARMY | rule | 0.06 | - | 21.3 |
| NO REASON | gate | 0.06 | - | 75.2 |
| WOUNDED STAYS OUT | rule | 0.03 | 0.03 | 80.3 |
| CATCH ODDS | rule | - | 0.03 | 27.5 |
| CHARIOT NO STATIC JOB | rule | 0.03 | - | 51.4 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | - | 4.0 |
| MOVE AND CAST | rule | - | 0.03 | 5.8 |
| STANDS TO CAST | rule | - | 0.03 | 21.7 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | - | 0.6 |

### Plans: tk-h2h-mine-949ddcd-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 10.8 | 16% | 523 | 263 | 50% |
| Mine | charge | 3.3 | 61% | 386 | 303 | 78% |
| Mine | close in | 3.7 | 32% | 240 | 141 | 59% |
| Mine | hold | 5.1 | 37% | 325 | 0 | 0% |
| Mine | join | 0.6 | 95% | 18 | 0 | 0% |
| Mine | shoot | 10.8 | 67% | 806 | 995 | 123% |
| Mine | support | 3.9 | 89% | 40 | 0 | 0% |
| Opponent | advance | 12.7 | 14% | 454 | 294 | 65% |
| Opponent | charge | 4.1 | 54% | 459 | 335 | 73% |
| Opponent | close in | 5.9 | 23% | 475 | 165 | 35% |
| Opponent | hold | 4.0 | 42% | 291 | 0 | 0% |
| Opponent | join | 1.2 | 95% | 48 | 0 | 0% |
| Opponent | shoot | 4.3 | 54% | 109 | 237 | 218% |
| Opponent | support | 5.6 | 88% | 52 | 0 | 0% |

### Packages: hunt the guns, tk-h2h-mine-949ddcd-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 3 | 0 | 33% | 33% | 0% | 4.0 | 306 | 66 | 33% | 8 |
| Opponent | 0.2 | 8 | 0 | 12% | 12% | 0% | 4.0 | 422 | 36 | 0% | 134 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 395 | 0 | 0% | 36 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 86 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.2 | 1 | 0 | 100% | 100% | 0% | 4.0 | 206 | 196 | 100% | 157 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 158 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 89 |
| Tomb Kings of Khemri | 0.7 | 4 | 0 | 0% | 0% | 0% | - | 312 | 0 | 0% | 65 |
| Vampire Counts | 0.2 | 2 | 0 | 50% | 50% | 0% | 4.0 | 396 | 144 | 0% | 152 |
| Warriors of Chaos | 0.2 | 2 | 0 | 0% | 0% | 0% | - | 662 | 0 | 0% | 98 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 329 | 0 | 0% | 70 |

### Battle groups: tk-h2h-mine-949ddcd-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.2 | 20% | 53% | 9% | 33% | 48% | 8% | 3% | 40% | 0% |
| Mine | REDIRECT COUNTER | 1.8 | 28% | 61% | 17% | 33% | 47% | 0% | 7% | 40% | 7% |
| Opponent | COUNTER-CHARGE COVER | 7.7 | 17% | 68% | 17% | 12% | 36% | 10% | 10% | 44% | 0% |
| Opponent | REDIRECT COUNTER | 4.3 | 25% | 64% | 18% | 29% | 9% | 3% | 6% | 75% | 6% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: tk-h2h-mine-949ddcd-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 0 | 67% | 3.0 | 0 (2) | 0 (1) | - | - | 0 (3) |
| Mine | Chaff | 36 | 24 (36) | 14 | 11 | 63 | 39% | 2.3 | 42 (15) | 0 (10) | 26 (11) | 25 (22) | 24 (14) |
| Mine | Character | 123 | 47 (123) | 47 | 0 | 29 | 18% | 2.4 | 43 (33) | 58 (66) | 20 (12) | 46 (60) | 55 (51) |
| Mine | Clean-up | 26 | 49 (26) | 8 | 41 | 21 | 35% | 3.2 | 61 (10) | 45 (12) | 0 (4) | 99 (13) | 7 (13) |
| Mine | Fast | 4 | 35 (4) | 35 | 0 | 34 | 0% | 1.5 | 67 (1) | 0 (2) | 0 (1) | 35 (4) | - |
| Mine | Fast Hammer | 40 | 41 (40) | 24 | 17 | 57 | 25% | 2.6 | 46 (18) | 29 (11) | 41 (11) | 49 (29) | 24 (11) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 80 | 0% | 2.0 | - | 0 (4) | 0 (1) | 0 (1) | 0 (4) |
| Mine | Hammer | 56 | 50 (56) | 36 | 15 | 28 | 18% | 2.5 | 69 (11) | 48 (37) | 35 (8) | 57 (34) | 43 (22) |
| Mine | Holder | 26 | 124 (26) | 19 | 105 | 15 | 38% | 3.6 | 92 (8) | 153 (11) | 110 (7) | 118 (13) | 130 (13) |
| Mine | Shooter | 45 | 108 (45) | 47 | 61 | 45 | 2% | 1.7 | 43 (6) | 139 (32) | 50 (7) | 156 (24) | 56 (21) |
| Mine | Support | 5 | 41 (5) | 41 | 0 | 42 | 20% | 2.0 | - | 72 (2) | - | 72 (2) | - |
| Mine | War machine | 56 | 73 (56) | 73 | 0 | 19 | 4% | 1.3 | 55 (14) | 83 (37) | 46 (5) | 65 (11) | 75 (45) |
| Mine | Wizard | 23 | 58 (23) | 58 | 0 | 48 | 9% | 2.2 | 41 (4) | 94 (11) | 49 (3) | 152 (4) | 40 (14) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Chaff | 68 | 36 (68) | 16 | 20 | 57 | 38% | 2.7 | 52 (30) | 38 (16) | 15 (22) | 45 (50) | 9 (18) |
| Opponent | Character | 113 | 41 (113) | 41 | 0 | 43 | 21% | 2.6 | 45 (39) | 43 (55) | 9 (7) | 41 (70) | 45 (31) |
| Opponent | Clean-up | 18 | 33 (18) | 10 | 23 | 39 | 39% | 2.8 | 25 (5) | 45 (10) | 15 (3) | 55 (11) | 0 (7) |
| Opponent | Early | 1 | 72 (1) | 72 | 0 | 0 | 0% | 4.0 | - | - | 72 (1) | 72 (1) | - |
| Opponent | Fast Hammer | 53 | 52 (53) | 37 | 15 | 52 | 32% | 2.4 | 46 (20) | 28 (18) | 90 (15) | 28 (37) | 102 (16) |
| Opponent | Fragile | 10 | 67 (10) | 67 | 0 | 65 | 40% | 1.8 | 194 (3) | 0 (3) | 37 (4) | 73 (9) | 0 (1) |
| Opponent | Hammer | 63 | 27 (63) | 18 | 9 | 44 | 27% | 2.7 | 27 (16) | 23 (40) | 69 (7) | 23 (39) | 35 (24) |
| Opponent | Holder | 40 | 56 (40) | 2 | 55 | 36 | 35% | 3.5 | 0 (8) | 86 (23) | 7 (9) | 94 (21) | 15 (19) |
| Opponent | Shooter | 32 | 60 (32) | 21 | 39 | 54 | 3% | 1.5 | 53 (8) | 64 (18) | 56 (6) | 65 (17) | 53 (15) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 50 | 50% | 6.0 | 0 (2) | - | - | - | 0 (2) |
| Opponent | War machine | 13 | 21 (13) | 21 | 0 | 42 | 23% | 1.0 | 12 (5) | 0 (5) | 79 (3) | 38 (3) | 16 (10) |
| Opponent | Wizard | 24 | 13 (24) | 13 | 0 | 33 | 4% | 2.0 | 19 (12) | 24 (4) | 0 (3) | 24 (11) | 0 (8) |

### Charged fights: tk-h2h-mine-949ddcd-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 355 | 128 | 2.4 | 1.2 | 53 | 14 | +39 | 1 of 12 | 9 of 12 | -42 | +55 |
| Mine | Chaos Dwarfs | 3 | 292 | 719 | 5.0 | 1.1 | 144 | 0 | +144 | 11 of 15 | 9 of 14 | +0 | +166 |
| Mine | Dwarfen Mountain Holds | 4 | 436 | 119 | 2.0 | 1.4 | 60 | 44 | +16 | 3 of 8 | 4 of 8 | +3 | +20 |
| Mine | Empire of Man | 5 | 543 | 253 | 1.6 | 1.1 | 158 | 48 | +111 | 2 of 8 | 8 of 8 | +83 | +115 |
| Mine | Grand Cathay | 4 | 709 | 399 | 4.8 | 1.0 | 84 | 7 | +77 | 8 of 19 | 14 of 19 | - | +77 |
| Mine | High Elf Realms | 4 | 278 | 186 | 3.5 | 1.2 | 53 | 42 | +11 | 5 of 14 | 11 of 14 | +60 | +7 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Mine | Lizardmen | 1 | 142 | 886 | 3.0 | 1.0 | 295 | 105 | +190 | 2 of 3 | 2 of 3 | - | +190 |
| Mine | Ogre Kingdoms | 1 | 70 | 204 | 3.0 | 1.3 | 68 | 0 | +68 | 0 of 3 | 3 of 3 | +66 | +69 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 567 | 6.0 | 1.3 | 94 | 9 | +85 | 2 of 6 | 5 of 6 | +72 | +92 |
| Mine | Skaven | 2 | 25 | 93 | 1.5 | 1.0 | 62 | 0 | +62 | 2 of 3 | 3 of 3 | - | +62 |
| Mine | Tomb Kings of Khemri | 2 | 51 | 1206 | 4.0 | 1.4 | 302 | 8 | +293 | 3 of 8 | 6 of 8 | +547 | +141 |
| Mine | Vampire Counts | 2 | 0 | 157 | 5.5 | 1.2 | 29 | 21 | +8 | 4 of 11 | 7 of 11 | +157 | -26 |
| Mine | Warriors of Chaos | 1 | 0 | 307 | 4.0 | 1.0 | 77 | 0 | +77 | 1 of 4 | 4 of 4 | - | +77 |
| **Mine** | all armies | 36 | 317 | 327 | 3.2 | 1.2 | 102 | 20 | +82 | 45 of 115 | 85 of 114 | +139 | +73 |
| Opponent | Beastmen Brayherds | 1 | 0 | 337 | 6.0 | 1.3 | 56 | 46 | +10 | 2 of 6 | 4 of 6 | -46 | +39 |
| Opponent | Dwarfen Mountain Holds | 1 | 112 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Empire of Man | 1 | 304 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 358 | 614 | 3.0 | 1.3 | 205 | 0 | +205 | 2 of 3 | 2 of 3 | +313 | +150 |
| Opponent | High Elf Realms | 2 | 114 | 148 | 2.0 | 1.0 | 74 | 66 | +8 | 4 of 4 | 1 of 4 | - | +8 |
| Opponent | Lizardmen | 1 | 110 | 659 | 5.0 | 1.2 | 132 | 0 | +132 | 2 of 5 | 5 of 5 | +0 | +165 |
| Opponent | Ogre Kingdoms | 2 | 28 | 184 | 4.0 | 1.4 | 46 | 23 | +23 | 0 of 8 | 6 of 8 | +56 | +3 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 630 | 5.0 | 1.0 | 126 | 40 | +86 | 5 of 10 | 7 of 10 | - | +86 |
| Opponent | Skaven | 2 | 0 | 266 | 2.5 | 1.0 | 106 | 0 | +106 | 2 of 5 | 3 of 5 | - | +106 |
| Opponent | Tomb Kings of Khemri | 4 | 26 | 874 | 2.2 | 1.3 | 388 | 60 | +328 | 5 of 9 | 6 of 9 | +182 | +402 |
| Opponent | Vampire Counts | 6 | 57 | 429 | 4.5 | 1.1 | 95 | 63 | +32 | 15 of 27 | 13 of 27 | +281 | +1 |
| Opponent | Warriors of Chaos | 7 | 14 | 418 | 2.9 | 1.1 | 146 | 20 | +126 | 8 of 20 | 11 of 20 | +153 | +125 |
| Opponent | Wood Elf Realms | 6 | 184 | 183 | 3.0 | 1.2 | 61 | 59 | +2 | 11 of 18 | 8 of 18 | +234 | -45 |
| **Opponent** | all armies | 36 | 78 | 393 | 3.2 | 1.2 | 122 | 42 | +80 | 56 of 116 | 67 of 116 | +155 | +67 |

### Effective charges: tk-h2h-mine-949ddcd-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 12 | 1 (net +185) | 1 (net +0) | 0 | 1 (net +0) | 0 | 7 (net +20) | 2 | 0% (0 of 10) |
| Mine | Chaos Dwarfs | 15 | 2 (net +164) | 0 | 1 (net +261) | 2 (net +0) | 0 | 9 (net +167) | 1 | 7% (1 of 14) |
| Mine | Dwarfen Mountain Holds | 8 | 2 (net -176) | 0 | 0 | 0 | 0 | 6 (net +80) | 0 | 0% (0 of 8) |
| Mine | Empire of Man | 8 | 2 (net +26) | 0 | 1 (net +175) | 0 | 2 (net +212) | 3 (net +79) | 0 | 12% (1 of 8) |
| Mine | Grand Cathay | 19 | 0 | 0 | 9 (net +126) | 4 (net -32) | 1 (net +41) | 5 (net +84) | 0 | 47% (9 of 19) |
| Mine | High Elf Realms | 14 | 2 (net +0) | 0 | 3 (net -94) | 3 (net +42) | 3 (net +56) | 3 (net +48) | 0 | 21% (3 of 14) |
| Mine | Kingdom of Bretonnia | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Lizardmen | 3 | 0 | 0 | 1 (net +256) | 0 | 1 (net +455) | 0 | 1 | 50% (1 of 2) |
| Mine | Ogre Kingdoms | 3 | 0 | 0 | 0 | 2 (net +69) | 1 (net +66) | 0 | 0 | 0% (0 of 3) |
| Mine | Orc & Goblin Tribes | 6 | 0 | 0 | 0 | 0 | 2 (net +70) | 1 (net +301) | 3 | 0% (0 of 3) |
| Mine | Skaven | 3 | 0 | 0 | 1 (net +0) | 0 | 0 | 2 (net +93) | 0 | 33% (1 of 3) |
| Mine | Tomb Kings of Khemri | 8 | 1 (net +599) | 0 | 2 (net +521) | 1 (net +170) | 1 (net +120) | 3 (net +139) | 0 | 25% (2 of 8) |
| Mine | Vampire Counts | 11 | 5 (net -9) | 0 | 1 (net +170) | 2 (net +0) | 1 (net +144) | 2 (net -93) | 0 | 9% (1 of 11) |
| Mine | Warriors of Chaos | 4 | 0 | 0 | 0 | 1 (net +0) | 1 (net +91) | 1 (net +107) | 1 | 0% (0 of 3) |
| Opponent | Beastmen Brayherds | 6 | 1 (net -137) | 0 | 2 (net +12) | 2 (net +65) | 0 | 1 (net +45) | 0 | 33% (2 of 6) |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | Grand Cathay | 3 | 1 (net +313) | 0 | 0 | 2 (net +150) | 0 | 0 | 0 | 0% (0 of 3) |
| Opponent | High Elf Realms | 4 | 2 (net +15) | 0 | 0 | 0 | 0 | 2 (net +0) | 0 | 0% (0 of 4) |
| Opponent | Lizardmen | 5 | 1 (net +281) | 0 | 0 | 2 (net +0) | 0 | 2 (net +189) | 0 | 0% (0 of 5) |
| Opponent | Ogre Kingdoms | 8 | 1 (net +85) | 0 | 1 (net +52) | 0 | 2 (net +68) | 3 (net -52) | 1 | 14% (1 of 7) |
| Opponent | Orc & Goblin Tribes | 10 | 0 | 0 | 1 (net +0) | 1 (net +70) | 1 (net +95) | 2 (net +421) | 5 | 20% (1 of 5) |
| Opponent | Skaven | 5 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 3 (net +177) | 0 | 0% (0 of 5) |
| Opponent | Tomb Kings of Khemri | 9 | 1 (net +776) | 1 (net -135) | 0 | 3 (net +103) | 0 | 3 (net +528) | 1 | 0% (0 of 8) |
| Opponent | Vampire Counts | 27 | 9 (net -23) | 0 | 4 (net -178) | 3 (net -113) | 1 (net +38) | 9 (net +232) | 1 | 15% (4 of 26) |
| Opponent | Warriors of Chaos | 20 | 4 (net +162) | 1 (net +199) | 2 (net +36) | 2 (net +215) | 0 | 7 (net +154) | 4 | 12% (2 of 16) |
| Opponent | Wood Elf Realms | 18 | 5 (net -162) | 1 (net -27) | 1 (net +0) | 3 (net +42) | 0 | 6 (net +144) | 2 | 6% (1 of 16) |

### Charged fights, damage counted: tk-h2h-mine-949ddcd-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 16 | 264 | 320 | +48 | 111 | 77 | +34 | +12.8 |
| Mine | 50-54% | 1 | 52 | 251 | +0 | 126 | 0 | +126 | +241.3 |
| Mine | Effective (55-75%) | 19 | 306 | 231 | +145 | 205 | 72 | +132 | +43.2 |
| Mine | 76-89% | 16 | 184 | 222 | +19 | 34 | 18 | +17 | +9.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 42 | 236 | 186 | +89 | 116 | 26 | +90 | +38.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 13 | 432 | 79 | +127 | 131 | 23 | +108 | +25.0 |
| Mine | No odds | 8 | 244 | 164 | +30 | 48 | 21 | +27 | +11.0 |
| Mine | All fights | 115 | 265 | 204 | +82 | 116 | 39 | +77 | +29.0 |
| Opponent | Long shot (under 50%) | 26 | 186 | 270 | +38 | 115 | 97 | +18 | +9.6 |
| Opponent | 50-54% | 3 | 453 | 366 | +12 | 263 | 246 | +18 | +3.9 |
| Opponent | Effective (55-75%) | 11 | 221 | 218 | -51 | 32 | 86 | -54 | -24.6 |
| Opponent | 76-89% | 19 | 281 | 170 | +54 | 108 | 32 | +76 | +27.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 39 | 284 | 203 | +186 | 216 | 32 | +184 | +64.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 356 | 74 | +68 | 71 | 20 | +52 | +14.6 |
| Opponent | No odds | 14 | 152 | 210 | +22 | 108 | 77 | +30 | +19.9 |
| Opponent | All fights | 116 | 246 | 215 | +80 | 141 | 62 | +79 | +32.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| tk-h2h-mine-949ddcd-p1 | move | 446 | 104 (23%) | 78 (17%) | 43 (10%) | 299 (67%) |
| tk-h2h-mine-949ddcd-p1 | objective | 346 | 45 (13%) | 33 (10%) | 46 (13%) | 255 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

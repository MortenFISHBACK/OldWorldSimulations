import csv,glob,statistics as st,math,collections
def pairs(D,mine,opp):
  by=collections.defaultdict(dict)
  for arm,fw in ((mine,'mine'),(opp,'opponent')):
    for f in glob.glob(f'{D}/{arm}/games.csv'):
      for r in csv.DictReader(open(f)):
        m,o=map(int,r['vp_mine_opponent'].split('-')); v={'mine':m,'opponent':o}
        by[r['pair']][arm]=v[fw]-v['opponent' if fw=='mine' else 'mine']
  return {p:sum(x.values()) for p,x in by.items() if len(x)==2}
a=pairs('/root/merged','tk-mine-all','tk-opp-all')
import os
b=pairs('/mnt/project-files/shots-head-to-head-2026-11-15','shots-mine-*','shots-opp-*')
for n,x in (('now',list(a.values())),('prev',list(b.values())),('pool',list(a.values())+list(b.values()))):
  print(n,len(x),f"{st.mean(x)/2:+.0f} ±{1.96*st.stdev(x)/math.sqrt(len(x))/2:.0f}")

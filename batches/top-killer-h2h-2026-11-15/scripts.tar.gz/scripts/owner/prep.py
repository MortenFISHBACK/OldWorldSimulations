# prep.py H arm partdir [partdir...] : symlink game logs into H/arm and split units.jsonl into units-<pair>.jsonl
import sys,os,glob,json,re,collections
H,arm,parts=sys.argv[1],sys.argv[2],sys.argv[3:]
out=os.path.join(H,arm); os.makedirs(out,exist_ok=True)
miss=0;n=0
for part in parts:
    U=collections.defaultdict(list)
    for l in open(part+'/units.jsonl'):
        d=json.loads(l); U[d['game']].append(d)
    games={}
    for g,us in U.items(): games.setdefault(tuple(sorted((u['side'],u['unit']) for u in us)),[]).append(g)
    for lf in sorted(glob.glob(part+'/game-*.log.jsonl')):
        pair=re.search(r'game-(L\d+)-',lf).group(1)
        dst=os.path.join(out,os.path.basename(lf))
        if os.path.exists(dst): continue
        with open(lf) as fh:
            board=json.loads(fh.readline())
        if board.get('kind')!='board':
            board=next(json.loads(l) for l in open(lf) if '"kind":"board"' in l)
        k=tuple(sorted((u['s'],u['lk']['cn']) for u in board['units']))
        if not games.get(k): miss+=1; print('no units for',lf); continue
        gid=games[k].pop(0)
        os.symlink(os.path.abspath(lf),dst); n+=1
        with open(os.path.join(out,f'units-{pair}.jsonl'),'w') as f:
            for u in U[gid]: f.write(json.dumps(u)+'\n')
print(arm,n,'games',miss,'unmatched')

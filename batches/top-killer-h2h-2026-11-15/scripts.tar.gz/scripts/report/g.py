import csv,json,statistics as st,math,collections
R=json.load(open('/root/h2h/rows.json'))
DEF=[(r['arm'],r['pair'],r['side']) for r in R if r['sh']>=0.5]
print('DEF sides match arm:',collections.Counter((a,s) for a,p,s in DEF))
G={}
for arm,a2 in (('fwmine','shots-mine'),('fwopp','shots-opp')):
  for r in csv.DictReader(open(f'/root/an/{a2}-all/games.csv')):
    m,o=map(int,r['vp_mine_opponent'].split('-'))
    d={'Mine':{},'Opponent':{}}
    for s,k in (('Mine','mine'),('Opponent','opponent')):
      d[s]=dict(vp=m if s=='Mine' else o,kills=float(r['vp_kills_'+k]),obj=float(r['vp_objectives_'+k]),lead=float(r['vp_leaders_'+k]),lost=float(r['points_lost_'+k]))
    G[(arm,r['pair'])]=d
def band(x): return 1.96*st.stdev(x)/math.sqrt(len(x)) if len(x)>1 else 0
other=lambda s:'Opponent' if s=='Mine' else 'Mine'
def table(lbl,keys):
  ms=[G[k][s]['vp']-G[k][other(s)]['vp'] for k,s in keys]
  f=lambda f_,who: st.mean(G[k][s if who else other(s)][f_] for k,s in keys)
  print(f"| {lbl} | {len(ms)} | {st.mean(ms):+.0f} ±{band(ms):.0f} | {sum(x>0 for x in ms)} | {f('kills',1):.0f} | {f('obj',1):.0f} | {f('lead',1):.0f} | {f('lost',1):.0f} | {f('kills',0):.0f} | {f('obj',0):.0f} | {f('lost',0):.0f} |")
chg=lambda arm:'Mine' if arm=='fwmine' else 'Opponent'
gun_ch=[((a,p),s) for a,p,s in DEF]
gun_main=[(('fwopp' if a=='fwmine' else 'fwmine',p),s) for a,p,s in DEF]
gset={(p,s) for a,p,s in DEF}
# offensive: changes side army-games whose army (pair,side) is not a gunline army
off_ch=[((a,p),chg(a)) for (a,p) in G if (p,chg(a)) not in gset]
off_main=[((a,p),other(chg(a))) for (a,p) in G if (p,other(chg(a))) not in gset]
print('| Set | Army-games | VP margin of that army | Ahead | Kills VP | Objectives VP | Leaders VP | Points lost | Enemy kills VP | Enemy objectives VP | Enemy points lost |')
print('|'+' --- |'*11)
table('Gunline armies, with the changes',gun_ch); table('Same gunline armies, as main',gun_main)
table('Other armies, with the changes',off_ch); table('Other armies, as main',off_main)
def paired(lbl,setsel):
  ds=[]
  for p in {p for a,p in G}:
    for s in ('Mine','Opponent'):
      if not setsel(p,s): continue
      ach='fwmine' if s=='Mine' else 'fwopp'; amn='fwopp' if s=='Mine' else 'fwmine'
      if (ach,p) not in G or (amn,p) not in G: continue
      ds.append((G[(ach,p)][s]['vp']-G[(ach,p)][other(s)]['vp'])-(G[(amn,p)][s]['vp']-G[(amn,p)][other(s)]['vp']))
  print(f"{lbl}: {len(ds)} army pairs, changes minus main {st.mean(ds):+.0f} ±{band(ds):.0f} per army-game; better {sum(d>0 for d in ds)}, worse {sum(d<0 for d in ds)}")
paired('gunline',lambda p,s:(p,s) in gset); paired('other',lambda p,s:(p,s) not in gset); paired('all',lambda p,s:True)
ds=[];kd=[];od=[]
for p in {p for a,p in G}:
  if ('fwmine',p) in G and ('fwopp',p) in G:
    a,b=G[('fwmine',p)],G[('fwopp',p)]
    ds.append((a['Mine']['lost']+b['Opponent']['lost'])-(a['Opponent']['lost']+b['Mine']['lost']))
    kd.append((a['Mine']['kills']+b['Opponent']['kills'])-(a['Opponent']['kills']+b['Mine']['kills']))
    od.append((a['Mine']['obj']+b['Opponent']['obj'])-(a['Opponent']['obj']+b['Mine']['obj']))
for n,x in (('points lost',ds),('kills vp',kd),('objective vp',od)): print(n, f"{st.mean(x)/2:+.0f} ±{band(x)/2:.0f} a game (changes minus main)")

import json,glob,os,re,collections,statistics as st,sys
B='/tmp/claude-0/-home-user/23b5e038-3306-5d2c-8f3f-0eba488acd15/scratchpad/an/h2h'
TAKES=re.compile(r'THREAT IN THE KILL: it takes ~([\d.]+) VP when it gets there \(#(\d+) ([^)]*)\), this shot ~([\d.]+) of it')
out=collections.defaultdict(collections.Counter); lists=collections.defaultdict(list); ex=[]
for part in sorted(glob.glob(B+'/shots-*-[0-9]')):
    changed='Mine' if '/shots-mine-' in part else 'Opponent'
    U=collections.defaultdict(list)
    for l in open(part+'/units.jsonl'):
        d=json.loads(l); U[d['game']].append(d)
    games={}
    for g,us in U.items(): games.setdefault(tuple(sorted((u['side'],u['unit']) for u in us)),[]).append(g)
    for lf in sorted(glob.glob(part+'/game-*.log.jsonl')):
        rows=[json.loads(l) for l in open(lf)]
        board=next(r for r in rows if r.get('kind')=='board')
        k=tuple(sorted((u['s'],u['lk']['cn']) for u in board['units']))
        if not games.get(k): out['x']['no units match']+=1; continue
        gid=games[k].pop(0); us=U[gid]
        names=collections.defaultdict(set)
        for b in board['units']: names[b['lk']['cn']].add(b['n']); names[b['n']].add(b['n'])
        acts=[r for r in rows if r.get('kind')=='action']
        wmnames={(u['side'],u['unit']) for u in us if u['troopType']=='War Machine' or 'War Machine' in (u.get('kind') or '')}
        for side in ('Mine','Opponent'):
            key='changed' if side==changed else 'main'
            C=out[key]
            kb=collections.Counter()
            for u in us:
                if u['side']==side and u['gone'] and u['goneCause'] in ('Combat','RunDown','FledOff') and u['goneBy']: kb[u['goneBy']]+=u['vpGivenUp']
            C['sides']+=1
            if not kb: C['no top killer']+=1; continue
            top,took=kb.most_common(1)[0]
            tu=next((u for u in us if u['side']!=side and (u['unit']==top or top in names[u['unit']])),None)
            topn=names[top]|names[tu['unit']] if tu else set()
            if tu is None: C['top killer not found']+=1; continue
            C['top is character']+=tu['isCharacter']; C['top joined']+= tu['joinedTo'] is not None
            lists[key+'|took'].append(took)
            tdead=tu['goneRound'] if tu['gone'] else 99
            # takes figures said for the top killer (any row naming it as target) by turn
            said={}
            for r in acts:
                if r.get('side')==side and r.get('target') in topn and r.get('summary'):
                    m=TAKES.search(r['summary'])
                    if m: said.setdefault(r['turn'],[]).append((float(m.group(1)),float(m.group(4)),r['type'],r['actor']))
            for t,v in said.items(): lists[key+'|takes said'].append(max(x[0] for x in v)); lists[key+'|ratio'].append(max(x[0] for x in v)/max(1,took))
            wmset={b['n'] for b in board['units'] if b['lk']['tt'].startswith('War Machine')}
            for r in acts:
                ss=r.get('summary') or ''
                if r.get('side')==side and r.get('type')=='OpponentRule' and ss.startswith('THREAT IN THE KILL') and r.get('actor') in wmset and r['turn']<=tdead:
                    m=re.match(r'THREAT IN THE KILL: \+?(-?[\d.]+) VP',ss); v=float(m.group(1)) if m else 0
                    at=r.get('target') in topn
                    C['wm threat rows']+=1; C['wm threat rows at top']+=at; C['wm threat rows CHANGED']+='| CHANGED' in ss; C['wm threat rows CHANGED at top']+=at and '| CHANGED' in ss
                    lists[key+'|wm threat vp '+('at top' if at else 'elsewhere')].append(v)
            opts={}
            for r in acts:
                if r.get('type')=='OpponentRule' and r.get('side')==side and (r.get('summary') or '').startswith('SHOT OPTIONS'): opts[(r['turn'],r['actor'])]=r
            for r in acts:
                if r.get('type')!='WarMachineShot' or r.get('side')!=side: continue
                C['wm shots']+=1
                if r['turn']>tdead: C['wm shots, top killer gone']+=1; continue
                C['wm shots, top alive']+=1
                at = r.get('target') in topn
                C['wm at top']+=at
                o=opts.get((r['turn'],r['actor']))
                why=(o or {}).get('summary','')
                kind=('objective' if 'its objective this turn' in why else 'chaff passed' if 'CHAFF PASSED' in why else 'focus' if 'FOCUS' in why else 'no row' if not o else 'own best shot')
                C['wm path: '+kind]+=1; C[f'wm path: {kind} | at top']+=at
                m=TAKES.search(why)
                if at:
                    C['wm at top: shot said threat']+= bool(m)
                    if m: lists[key+'|share at top'].append(float(m.group(4)))
                else:
                    C['wm elsewhere: shot said threat']+=bool(m)
                    if t:=said.get(r['turn']): C['wm elsewhere: top killer had a threat figure this turn']+=1; lists[key+'|top threat share when elsewhere'].append(max(x[1] for x in t))
                    else: C['wm elsewhere: no threat figure for top this turn']+=1
                    w=re.search(r'about ([\d.]+) victory points',why); lists[key+'|elsewhere vp'].append(float(w.group(1)) if w else 0)
                    if len(ex)<12 and key=='changed': ex.append((os.path.basename(lf),r['turn'],r['actor'],r.get('target'),top,took,why[:300]))
for k,C in out.items():
    print('==',k); [print(f'  {a}: {b}') for a,b in C.items()]
for k,v in sorted(lists.items()):
    if v: print(f'{k}: n={len(v)} median {st.median(v):.1f} mean {st.mean(v):.1f}')
for e in ex: print(e)

# THREAT rows by shooter kind and target, changed side
print('\n== THREAT IN THE KILL rows, changed side')
T=collections.Counter(); vals=collections.defaultdict(list)
for part in sorted(glob.glob(B+'/shots-*-[0-9]')):
    changed='Mine' if '/shots-mine-' in part else 'Opponent'
    for lf in sorted(glob.glob(part+'/game-*.log.jsonl')):
        rows=[json.loads(l) for l in open(lf)]
        board=next(r for r in rows if r.get('kind')=='board')
        tt={b['n']:(b['lk']['tt'],b['lk'].get('w'),b['lk']['cn']) for b in board['units']}
        for r in rows:
            if r.get('kind')!='action' or r.get('side')!=changed: continue
            s=r.get('summary') or ''
            if r.get('type')=='OpponentRule' and s.startswith('THREAT IN THE KILL'):
                wm=tt.get(r.get('actor'),('?',))[0].startswith('War Machine')
                k=('wm' if wm else 'other')+' '+r['phase']
                T[k]+=1; T[k+' CHANGED']+='| CHANGED' in s
                m=re.match(r'THREAT IN THE KILL: \+?(-?[\d.]+) VP',s); vals[k].append(float(m.group(1)) if m else 0)
            if r.get('type')=='WarMachineShot':
                tgt=tt.get(r.get('target'))
                if tgt: T['wm shot target wounds/model '+('3+' if (tgt[1] or 1)>=3 else '1-2')]+=1; T['wm shot target is '+tgt[0]]+=1
for k,v in sorted(T.items()): print(f'  {k}: {v}')
for k,v in vals.items(): print(f'  {k} vp: n={len(v)} median {st.median(v):.1f} mean {st.mean(v):.1f}')

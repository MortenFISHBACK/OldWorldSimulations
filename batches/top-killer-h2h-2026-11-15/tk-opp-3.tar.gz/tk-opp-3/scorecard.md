# Doctrine scorecard: tk-h2h-opp-949ddcd-p3

### Scorecard: tk-h2h-opp-949ddcd-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 9 | 6 | 1 | 0 | 0 | 0 | 0 | 322 |
| L0126 | 6 | 1 | Opponent | no | 8 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 0 | 5 | 0 | 4 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Opponent | no | 0 | 2 | 0 | 0 | 0 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | no | 0 | 5 | 1 | 2 | 0 | 0 | 0 | 251 |
| L0226 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | no | - | - | 1 | 1 | 0 | 0 | 0 | 590 |
| L0311 | 5 | 1 | Opponent | yes | - | 4 | 5 | 0 | 1 | 0 | 0 | 330 |
| L0327 | 3 | 1 | Mine | no | 1 | 6 | 1 | 0 | 0 | 0 | 0 | 685 |
| L0327 | 3 | 1 | Opponent | no | 8 | 2 | 2 | 2 | 1 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | no | - | 2 | 2 | 0 | 1 | 0 | 0 | 317 |
| L0429 | 3 | 1 | Mine | yes | 13 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 2 | 2 | 5 | 1 | 1 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 2 | 3 | 1 | 1 | 0 | 0 | 0 | 475 |
| L0516 | 6 | 1 | Opponent | no | 1 | 2 | 6 | 1 | 1 | 0 | 0 | 200 |
| L0533 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 1193 |
| L0533 | 5 | 1 | Opponent | yes | - | 2 | 4 | 5 | 0 | 0 | 0 | 144 |
| L0620 | 2 | 1 | Mine | - | - | 3 | 5 | 0 | 0 | 0 | 0 | 929 |
| L0620 | 2 | 1 | Opponent | - | - | 3 | 3 | 1 | 1 | 0 | 0 | 210 |
| L0709 | 1 | 1 | Mine | yes | 2 | 2 | 6 | 0 | 1 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | no | 0 | - | 2 | 1 | 0 | 0 | 0 | 830 |
| L0725 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 513 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 4 | 5 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | 3 | 2 | 1 | 0 | 0 | 0 | 515 |
| L0815 | 5 | 1 | Opponent | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 115 |
| L0831 | 3 | 1 | Mine | no | 0 | 6 | 1 | 1 | 0 | 0 | 0 | 605 |
| L0831 | 3 | 1 | Opponent | no | 0 | - | 0 | 3 | 2 | 0 | 0 | 314 |
| L0922 | 4 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 668 |
| L0922 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 1 | 0 | 0 | 55 |
| L1013 | 5 | 1 | Mine | yes | - | 2 | 1 | 1 | 0 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | no | - | 1 | 1 | 2 | 1 | 0 | 0 | 302 |
| L1030 | 4 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 492 |
| L1030 | 4 | 1 | Opponent | yes | 3 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 4 | 2 | 7 | 0 | 0 | 0 | 0 | 427 |
| L1122 | 6 | 1 | Opponent | no | 3 | 2 | 3 | 2 | 1 | 0 | 0 | 162 |
| L1216 | 4 | 1 | Mine | no | 2 | 2 | 6 | 0 | 1 | 0 | 0 | 330 |
| L1216 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 3 | 1 | 0 | 0 | 200 |
| L1232 | 2 | 1 | Mine | - | - | 3 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 3 | 4 | 3 | 3 | 0 | 0 | 340 |
| L1327 | 1 | 1 | Mine | no | 6 | 4 | 3 | 0 | 0 | 0 | 0 | 140 |
| L1327 | 1 | 1 | Opponent | no | 3 | 1 | 6 | 1 | 2 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Mine | no | 5 | 3 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 170 |
| L1519 | 1 | 1 | Mine | no | 1 | 2 | 2 | 1 | 0 | 0 | 0 | 199 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 8 | 1 | 1 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | yes | - | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1633 | 1 | 1 | Mine | yes | 12 | 2 | 3 | 1 | 0 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 0 | 1 | 4 | 2 | 1 | 0 | 0 | 657 |
| L1731 | 3 | 1 | Mine | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 98 |
| L1731 | 3 | 1 | Opponent | no | 9 | 2 | 2 | 0 | 2 | 0 | 0 | 340 |
| L1831 | 1 | 1 | Mine | no | 3 | 3 | 6 | 1 | 0 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 2 | 6 | 1 | 1 | 0 | 0 | 0 | 170 |
| L1932 | 6 | 1 | Mine | no | 3 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1932 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 3 | 0 | 0 | 0 | 170 |
| L2033 | 5 | 1 | Mine | yes | - | - | 1 | 7 | 1 | 0 | 0 | 420 |
| L2033 | 5 | 1 | Opponent | no | - | 3 | 1 | 5 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Mine | yes | 0 | 1 | 5 | 1 | 1 | 0 | 0 | 72 |
| L2223 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 185 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Opponent | yes | - | 2 | 6 | 3 | 1 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Mine | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 1 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Mine | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 6 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Opponent | no | 2 | 1 | 4 | 2 | 0 | 0 | 0 | 0 |
| L3133 | 1 | 1 | Mine | no | 2 | 3 | 2 | 1 | 4 | 0 | 0 | 340 |
| L3133 | 1 | 1 | Opponent | no | 6 | 5 | 2 | 4 | 0 | 0 | 0 | 334 |
| **Average** | | | Mine | 28% | 3.1 | 3.0 | 2.6 | 0.9 | 0.2 | 0.0 | 0.0 | 292.9 |
| **Average** | | | Opponent | 22% | 2.1 | 2.3 | 3.1 | 1.8 | 0.6 | 0.0 | 0.0 | 177.1 |

### KPIs: tk-h2h-opp-949ddcd-p3

Rules off - Mine only: STAY WORTH, BEST MOVE FOR SHOOTERS, THREAT IN THE KILL, FOCUS OVER TURNS, MISSILES IN THE PLAN, FACE THE CAST, WIZARD FRONT RANK, THREAT OVER THE TURNS, THREAT TO WORN DOWN.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 28% (51 of 179) | 9% (16 of 173) | 19% (67 of 352) |
| Winner chose to follow up after the loser gave ground |  | 97% (84 of 87); on the table 97% | 100% (47 of 47); on the table 100% | 98% (131 of 134); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 79% (11 of 14); on the table 79% | 94% (17 of 18); on the table 94% | 88% (28 of 32); on the table 88% |
| Winner chose to pursue after the loser fled |  | 78% (14 of 18); on the table 83% | 73% (27 of 37); on the table 78% | 75% (41 of 55); on the table 80% |
| Winner chose to follow up or pursue (all three) |  | 92% (109 of 119); on the table 92% | 89% (91 of 102); on the table 91% | 90% (200 of 221); on the table 92% |
| Magic missiles tried each own turn | 50%+ | 25% (86 of 342) | 35% (68 of 192) | 29% (154 of 534) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 42% (86 of 205) | 48% (68 of 141) | 45% (154 of 346) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 21% (40 of 192) | 38% (52 of 138) | 28% (92 of 330) |
|     round 1 |  | 16% (5 of 32) | 39% (9 of 23) | 25% (14 of 55) |
|     rounds 2+ |  | 22% (35 of 160) | 37% (43 of 115) | 28% (78 of 275) |
|   other wizards | 50%+ | 31% (46 of 150) | 30% (16 of 54) | 30% (62 of 204) |
|     round 1 |  | 36% (9 of 25) | 11% (1 of 9) | 29% (10 of 34) |
|     rounds 2+ |  | 30% (37 of 125) | 33% (15 of 45) | 31% (52 of 170) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 58% (11 of 19) | 49% (30 of 61) | 51% (41 of 80) |
| Points that never fought | lower | 33% (22954 of 68801) | 39% (28136 of 71990) | 36% (51090 of 140791) |
|   infantry points that never fought | lower | 40% (5689 of 14174) | 49% (7034 of 14220) | 45% (12723 of 28394) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 57% (156 of 272) | 60% (170 of 285) | 59% (326 of 557) |
| Bound items with a magic missile used (at least once a game) |  | 80% (20 of 25); 1.5 uses a game | 83% (20 of 24); 1.8 uses a game | 82% (40 of 49); 1.6 uses a game |
| Bound items with another spell used |  | 36% (5 of 14); 0.2 uses a game | 33% (2 of 6); 0.1 uses a game | 35% (7 of 20); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 60% (12 of 20); 0.3 uses a game | 43% (6 of 14); 0.2 uses a game | 53% (18 of 34); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 53% (31521 of 59391) | 54% (34562 of 64043) | 54% (66083 of 123434) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (18%) | 1.1 (31%) | 2.4 (22%) |
| MARCHED: its unit marched | 1.4 (20%) | 0.8 (23%) | 2.2 (21%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.1 (3%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.7 (24%) | 0.7 (21%) | 2.4 (23%) |
| REAR RANK: in a rear rank | 0.1 (2%) | 0.1 (2%) | 0.2 (2%) |
| FLEEING: fleeing | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| GONE: slain | 1.5 (21%) | 0.6 (18%) | 2.1 (20%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (5%) | 0.1 (2%) | 0.4 (4%) |
| STUPIDITY: Stupidity | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.4 | 0.9 | 1.4 | 4.3 | 0.8 | 1.8 |
| not cast | 4.4 | 1.7 | 4.7 | 10.6 | 2.5 | 18.9 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.4 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 0.7 (39%) | 0.4 (9%) | 2.4 (22%) | 0.2 (10%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.2 (21%) | 0.4 (18%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.4 (9%) | 0.2 (13%) | 0.8 (17%) | 2.4 (23%) | 0.5 (19%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.0 (0%) | 0.2 (5%) | 0.2 (2%) | 0.1 (3%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.1 (5%) | 0.1 (2%) | 0.2 (2%) | 0.0 (1%) | 0.8 (4%) |
| GONE: slain | 1.3 (30%) | 0.3 (18%) | 1.3 (27%) | 2.1 (20%) | 0.3 (12%) | 2.7 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (6%) | 0.1 (7%) | 0.3 (6%) | 0.4 (4%) | 0.3 (12%) | 1.0 (5%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (0%) | 0.1 (3%) | 0.2 (2%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.1 (3%) | 0.0 (0%) | 0.1 (1%) | 0.5 (21%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.9 (44%) | 0.2 (15%) | 1.4 (31%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.9 (68%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 0.5 a game | 0.7 a game |
| stood (cast and not dispelled) | 73% (22 of 30) | 45% (5 of 11) | 66% (27 of 41) |
| the unit moved after it | 86% (19 of 22) | 80% (4 of 5) | 85% (23 of 27) |
| it charged on its next turn | 0% (0 of 22) | 20% (1 of 5) | 4% (1 of 27) |
| the enemy charged it first | 14% (3 of 22) | 20% (1 of 5) | 15% (4 of 27) |
| it fought by the end of its next turn | 5% (1 of 22) | 20% (1 of 5) | 7% (2 of 27) |
| it moved out of a charge the enemy had planned (not charged first) | 27% (6 of 22) | 20% (1 of 5) | 26% (7 of 27) |
| none of these (no charge, no fight, no charge escaped) | 59% (13 of 22) | 40% (2 of 5) | 56% (15 of 27) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (485 of 746) | 59% (362 of 612) | 62% (847 of 1358) |
|   cavalry | 63% (38 of 60) | 64% (78 of 122) | 64% (116 of 182) |
|   character | 53% (40 of 76) | 21% (24 of 117) | 33% (64 of 193) |
|   chariot | 51% (49 of 97) | 71% (22 of 31) | 55% (71 of 128) |
|   infantry | 51% (106 of 206) | 67% (168 of 250) | 60% (274 of 456) |
|   monster | 39% (11 of 28) | 100% (3 of 3) | 45% (14 of 31) |
|   war machine | 86% (241 of 279) | 75% (67 of 89) | 84% (308 of 368) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.4 (33%) | 1.3 (18%) | 3.7 (26%) |
| CHARGED: it charged | 1.0 (13%) | 1.7 (24%) | 2.7 (19%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| IN COMBAT: it fought this turn or the last | 0.9 (12%) | 0.8 (11%) | 1.6 (12%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 0.8 (10%) | 0.8 (11%) | 1.5 (11%) |
| ONLY IN COMBAT: the only targets were in combat | 0.2 (3%) | 0.4 (6%) | 0.7 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.5 (21%) | 1.4 (21%) | 2.9 (21%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.2 (3%) | 0.4 (3%) |
| OTHER BAR | 0.3 (4%) | 0.3 (4%) | 0.6 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.7 | 1.2 | 83% | 4.4 pts | 21 pts |
| character | 2.0 | 0.3 | 86% | 4.5 pts | 9 pts |
| chariot | 2.0 | 1.1 | 69% | 12.5 pts | 25 pts |
| infantry | 11.8 | 4.1 | 75% | 9.5 pts | 112 pts |
| monster | 0.5 | 0.0 | 94% | 1.1 pts | 1 pts |
| war machine | 8.8 | 7.3 | 60% | 26.7 pts | 234 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 5.9 | 4.8 |
| Charges that made contact a game | 2.8 | 4.4 | 3.6 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.88 declared, 0.73 contact (26 units) | 0.71 declared, 0.59 contact (17 units) | 0.81 declared, 0.67 contact (43 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.25 declared, 1.00 contact (4 units) | 1.60 declared, 1.00 contact (10 units) | 1.50 declared, 1.00 contact (14 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.46 declared, 0.33 contact (227 units) | 0.72 declared, 0.53 contact (257 units) | 0.60 declared, 0.44 contact (484 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 49% (38 of 77) | 53% (8 of 15) | 40% (4 of 10) | 49% (50 of 102) |
| Character in a unit | 85% (29 of 34) | 69% (11 of 16) | 62% (5 of 8) | 78% (45 of 58) |
| Character on its own | 81% (35 of 43) | 55% (22 of 40) | 31% (21 of 67) | 52% (78 of 150) |
| Chariot | 82% (9 of 11) | 75% (9 of 12) | - | 78% (18 of 23) |
| Infantry | 63% (44 of 70) | 48% (20 of 42) | 40% (2 of 5) | 56% (66 of 117) |
| Monster | 65% (22 of 34) | 57% (4 of 7) | - | 63% (26 of 41) |
| Monstrous | 70% (7 of 10) | 55% (6 of 11) | - | 62% (13 of 21) |
| War Machines | 65% (28 of 43) | 100% (2 of 2) | - | 67% (30 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (14 of 14); on the table 100% | 19% (18 of 96) | 25% | 68% (15 of 22) | 83% (5 of 6); 2.5 uses a game | 50% (1 of 2); 0.2 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 89% (16 of 18); on the table 89% | 58% (21 of 36) | 36% | 53% (17 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 3 | 83% (5 of 6); on the table 83% | - | 50% | 79% (19 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 89% (8 of 9); on the table 89% | 50% (15 of 30) | 53% | 71% (42 of 59) | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 8 | 100% (26 of 26); on the table 100% | 25% (48 of 192) | 42% | 47% (35 of 74) | 83% (15 of 18); 5.2 uses a game | 25% (1 of 4); 0.1 uses a game | 38% (3 of 8); 0.4 uses a game |
| High Elf Realms | 7 | 76% (13 of 17); on the table 88% | 14% (6 of 42) | 27% | 56% (30 of 54) | 67% (6 of 9); 2.6 uses a game | 42% (5 of 12); 1.3 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 100% (9 of 9); on the table 100% | - | 45% | 39% (7 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Lizardmen | 1 | 60% (3 of 5); on the table 60% | 67% (4 of 6) | 31% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (3 of 3); on the table 100% | 0% (0 of 6) | 19% | 71% (5 of 7) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (6 of 6); on the table 100% | 8% (1 of 12) | 9% | 69% (11 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Skaven | 2 | 80% (4 of 5); on the table 100% | 25% (3 of 12) | 43% | 50% (7 of 14) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Tomb Kings of Khemri | 6 | 94% (17 of 18); on the table 94% | 17% (1 of 6) | 25% | 65% (17 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 100% (36 of 36); on the table 100% | 31% (17 of 54) | 25% | 46% (21 of 46) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 11 | 80% (35 of 44); on the table 80% | 57% (17 of 30) | 43% | 55% (53 of 96) | 100% (4 of 4); 1.4 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 6 | 100% (5 of 5); on the table 100% | 25% (3 of 12) | 44% | 69% (43 of 62) | 82% (9 of 11); 5.0 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (tk-h2h-opp-949ddcd-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 48% (48) | 49% (32) | 49% (80) |
| ...free all their last turn and able to turn (per game) | 0.75 | 0.53 | 1.28 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.25 | 0.22 | 0.47 |
| ...with the charger already in that arc before they moved (per game) | 0.56 | 0.39 | 0.94 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.97 | 1.03 | 3.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.69 | 0.64 | 1.33 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.06 | 4.86 | 10.92 |

### Quality by phase: tk-h2h-opp-949ddcd-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.2 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 55% (68 of 123) | 52% (87 of 168) |
| Strategy | Shoot objectives carried out (shot that target) | 47% (167 of 358) | 50% (112 of 225) |
| Strategy | Close-in objectives charged next turn | 13% (22 of 164) | 18% (45 of 249) |
| Strategy | Support requests answered (helper made contact too) | 31% (4 of 13) | 23% (5 of 22) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (4 of 4) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 50% (4 of 8) | 67% (4 of 6) |
| Strategy | Joined characters whose unit fought | 52% (22 of 42) | 25% (10 of 40) |
| Strategy | Lone characters that fought | 78% (73 of 93) | 77% (72 of 94) |
| Movement | Charges halted short of contact | 0.1 | 0.3 |
| Movement | Idle units | 0.9 | 1.8 |
| Movement | Points that never moved of their own | 292.9 | 177.1 |
| Movement | Fights charged into per game | 2.7 | 3.7 |
| Movement | Charges with odds: long shots (under 50%) | 11 of 90, net +109 | 29 of 114, net +51 |
| Movement | Charges with odds: sweet spot (55-75%) | 13 of 90, net -3 | 16 of 114, net -15 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 14 of 90, net +18 | 10 of 114, net +84 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 32 of 90, net +135 | 32 of 114, net +118 |
| Shooting | Shots by shooting units (incl. breath weapons) | 7.6 | 9.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 40% (111 of 275) | 43% (147 of 345) |
| Shooting | Points destroyed by shooting units | 52.9 | 36.6 |
| Shooting | War machine shots | 6.7 | 2.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 55% (133 of 241) | 45% (33 of 74) |
| Shooting | Points destroyed by war machines | 103.2 | 38.2 |
| Magic | Magic missiles cast | 1.4 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 42% (21 of 50) | 29% (14 of 48) |
| Magic | Wounds caused by magic missiles | 3.1 | 2.6 |
| Magic | Wounds caused by other spells | 1.6 | 1.1 |
| Magic | Points destroyed by magic (all spells) | 72.2 | 37.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.2 / 0.7 / 0.1 | 1.7 / 0.2 / 0.3 / 0.4 |
| Combat | Points destroyed in combat | 353.8 | 353.3 |
| Combat | Points run down | 39.7 | 172.8 |
| Combat | Net points per charged fight, damage counted | +70 | +77 |
| Combat | Net per 100 charger points, damage counted | +25.8 | +27.2 |
| Combat | First round won (charged fights) | 81% | 66% |
| Combat | Net points per charged fight | +73 | +76 |
| Combat | Net points per supported fight / lone fight | +120 / +70 | +282 / +56 |
| Combat | Charged fights on a top-3 enemy unit | 21 of 98 | 63 of 132 |
| Game | Points lost | 734.9 | 707.4 |
| Game | VP from objectives | 503.6 | 556.1 |
| Game | Lone holders (player turns) | 3.1 | 2.1 |

- Mine won / drew / lost: 14 / 4 / 18 of 36 ended games (of 36); mean margin (Mine - Opponent) -117 VP
- The side that went first won 17 of 32 games with a winner
- Points traded per game (both sides' losses): 1442
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: tk-h2h-opp-949ddcd-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 10.3 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.9 | +0.0 | 0.0 | 21.5 | 0.1 | +0.0 | 0.0 | 8.1 |
| BACKUP TARGETS | 0.8 | +8.3 | 0.0 | 37.0 | 0.8 | +10.7 | 0.0 | 17.5 |
| BEST FACING | 0.9 | +37.0 | 0.0 | 31.9 | 0.4 | +20.4 | 0.0 | 29.7 |
| BEST FIRST | 4.1 | +195.3 | 175.7 | 140.8 | 3.3 | +193.9 | 188.1 | 100.7 |
| BEST MOVE FOR SHOOTERS | - | - | - | - | 0.4 | +70.3 | 0.0 | 9.4 |
| BEST OVERALL | 0.6 | +40.1 | 0.0 | 27.9 | 0.6 | +47.9 | 0.0 | 50.4 |
| BEST PREY | 0.9 | +55.4 | 13.1 | 25.6 | 0.8 | +30.1 | 19.4 | 6.6 |
| BEST PRIZE | 0.1 | -6.1 | 0.0 | 6.5 | 0.0 | -0.8 | 0.0 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | -0.4 | 0.0 | 12.1 | 0.2 | +0.3 | 0.0 | 13.1 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 1.4 |
| BLOCKED WHEEL | 0.4 | +1.4 | 0.0 | 1.4 | 0.4 | +2.7 | 0.0 | 0.0 |
| BOMBING RUN | 0.0 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 80.8 | 14.4 | 0.2 | +0.0 | 4.7 | 4.6 |
| CANNON PLANNED TARGET | 5.9 | +172.4 | 412.6 | 64.9 | 1.1 | +55.7 | 71.2 | 29.2 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | -3.8 | 9.6 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.2 | -6.2 | 26.3 | 10.2 | 0.1 | -2.5 | 15.2 | 3.2 |
| CAST JOB | 0.9 | +38.6 | 90.7 | 7.5 | 1.1 | +16.0 | 29.9 | 6.4 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +25.9 | 9.2 | 0.0 | 0.1 | +0.5 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 22.4 | 0.2 | +0.0 | 0.0 | 11.1 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +1.5 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.1 | -0.1 | 5.4 | 0.0 | 0.2 | -0.8 | 0.0 | 1.8 |
| CHAMPION TAKES THE CHALLENGE | 0.0 | +0.0 | 6.1 | 0.0 | - | - | - | - |
| CHARGE NOW FIRST | 2.1 | +0.0 | 215.1 | 38.9 | 2.9 | +0.0 | 206.9 | 69.2 |
| CHARGE NOW WEIGHED | 0.5 | -47.9 | 20.6 | 16.4 | 0.6 | -61.4 | 36.1 | 22.1 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 1.2 | 2.4 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | -1.9 | 0.0 | 11.1 |
| CHEAP HELPER | 0.1 | +0.0 | 5.2 | 0.0 | 0.1 | +0.0 | 10.1 | 0.0 |
| COMBAT PIVOT | 0.5 | +0.0 | 45.3 | 13.3 | 0.4 | +0.0 | 26.6 | 14.2 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 2.9 | - | - | - | - |
| CONVEYANCE SEARCH | 0.7 | +78.0 | 32.7 | 12.5 | 0.2 | +24.1 | 11.1 | 17.6 |
| COUNTER-CHARGE COVER | 9.4 | +704.5 | 0.0 | 192.8 | 6.8 | +599.8 | 0.0 | 157.9 |
| DEFENSIVE ARMY | 0.1 | -0.0 | 19.2 | 0.0 | 0.1 | +0.0 | 5.8 | 0.0 |
| DEFENSIVE FLOOR | 0.0 | +1.9 | 0.0 | 0.0 | 0.0 | +2.9 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +5.4 | 14.4 | 4.0 | 0.2 | +2.8 | 19.2 | 1.2 |
| ELIXIR WORTH | 0.0 | +0.1 | 0.0 | 9.7 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACE THE CAST | - | - | - | - | 0.2 | +3.8 | 0.0 | 3.2 |
| FACES THE THREAT | 2.0 | +134.6 | 0.0 | 50.3 | 1.0 | +98.1 | 0.0 | 50.6 |
| FALLBACK BY WORTH | 5.0 | +44.2 | 0.0 | 117.6 | 5.2 | +74.0 | 0.0 | 61.5 |
| FIGHT LIFT | 0.0 | +0.1 | 0.8 | 0.0 | 0.1 | +3.0 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.0 | +0.4 | 2.9 | 2.2 | - | - | - | - |
| FLANK NOT WEIGHED | 6.1 | +0.0 | 0.0 | 128.4 | 4.8 | +0.0 | 0.0 | 120.8 |
| FOCUS OVER TURNS | - | - | - | - | 0.4 | +9.7 | 16.6 | 0.0 |
| FOLLOW UP WEIGHED | 1.5 | +225.7 | 0.0 | 122.2 | 1.1 | +136.3 | 0.0 | 14.9 |
| FRIENDS SHOTS CHECKED | 0.3 | +13.7 | 0.0 | 1.7 | 0.2 | +22.8 | 0.0 | 4.2 |
| GIVES UP | 0.1 | -0.3 | 7.0 | 0.0 | 0.1 | -0.7 | 21.1 | 9.1 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -1.4 | 18.0 | 0.0 |
| GROUND FLIERS | 0.0 | +1.6 | 0.0 | 7.5 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.2 | +0.0 | 45.1 | 2.2 |
| HELPER UNSEEN | 0.2 | +0.0 | 7.7 | 0.0 | 0.2 | +0.0 | 14.4 | 2.6 |
| HILL BY ITS CHANCE | 0.2 | -19.3 | 0.0 | 1.8 | 0.4 | -44.5 | 0.0 | 14.1 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.1 | +2.0 | 0.0 | 14.0 |
| HUNT ADVANCE | 0.2 | +12.6 | 0.0 | 5.8 | 0.2 | +6.1 | 0.0 | 0.0 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.2 | +8.9 | 0.0 | 17.5 | 0.8 | +49.1 | 0.0 | 38.4 |
| HUNT KEPT | 0.2 | +6.4 | 0.0 | 4.3 | 0.1 | +3.7 | 0.0 | 0.0 |
| HUNT RESULT | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +9.7 | 0.0 | 0.0 |
| HUNT THE GUNS | 0.2 | +81.6 | 0.0 | 2.9 | 0.1 | +41.2 | 8.1 | 0.0 |
| INVITES THE FIGHT | 1.6 | +35.4 | 62.2 | 13.7 | 1.2 | +25.5 | 50.9 | 8.2 |
| JOINT CHARGE PLAN | 0.1 | +13.7 | 0.0 | 0.0 | 0.4 | +18.9 | 20.4 | 16.9 |
| KEEP FALLS | 0.1 | +1.0 | 0.0 | 6.1 | 0.0 | +0.3 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.4 | +43.3 | 95.6 | 18.9 | 2.1 | +64.2 | 141.8 | 35.3 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.7 | +64.0 | 100.5 | 44.2 | 1.9 | +98.4 | 131.7 | 29.4 |
| KILLS COUNT NEXT TURN | 5.9 | +191.6 | 180.0 | 180.0 | 7.8 | +259.9 | 326.9 | 173.9 |
| LONE CHARACTER SAFE SPOT | 0.6 | +12.4 | 22.9 | 4.9 | 0.4 | +12.4 | 15.4 | 15.7 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 5.3 | 0.0 | 0.3 | +0.0 | 16.7 | 0.0 |
| LONE WIZARD KEPT IN | 0.6 | +37.3 | 0.0 | 0.0 | 0.4 | +25.4 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | -0.0 | 15.4 | 7.4 | 0.2 | -2.7 | 4.8 | 1.4 |
| LOST CHARGE | 2.6 | -46.0 | 128.0 | 78.9 | 2.4 | -40.8 | 81.5 | 58.5 |
| MAKE SURE TOGETHER | 0.7 | +62.9 | 41.4 | 13.7 | 1.2 | +119.4 | 40.6 | 11.5 |
| MANOEUVRE | 0.3 | +12.8 | 0.0 | 0.0 | 0.1 | +6.4 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +1.1 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.5 | +39.1 | 0.0 | 16.9 | 0.5 | +38.2 | 0.0 | 10.2 |
| MARCH ODDS | 0.3 | +20.5 | 30.2 | 0.0 | 0.3 | +17.6 | 10.3 | 0.0 |
| MARCH OVER CASTS | 0.5 | +49.1 | 0.0 | 57.0 | 0.2 | +21.9 | 0.0 | 3.2 |
| MAX FOR POSITIONING | 4.8 | +153.0 | 0.0 | 158.9 | 4.8 | +183.5 | 0.0 | 139.4 |
| MISSILES IN THE MOVE | 3.7 | +138.1 | 0.0 | 112.3 | 4.0 | +138.9 | 0.0 | 77.6 |
| MISSILES IN THE PLAN | - | - | - | - | 0.4 | +3.0 | 11.3 | 0.0 |
| MISSILES NEXT TURN | 4.8 | +87.4 | 0.0 | 182.7 | 4.7 | +92.6 | 0.0 | 98.6 |
| MODEL FACING | 0.1 | +12.8 | 0.0 | 1.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.3 | +0.0 | 47.7 | 12.1 | 0.2 | +0.0 | 49.7 | 10.2 |
| MOVE AND CAST | 0.5 | +24.6 | 0.0 | 0.0 | 0.5 | +32.5 | 0.0 | 3.2 |
| MOVE SPELL IN RANGE | 0.3 | +9.8 | 0.0 | 10.6 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.4 | -10.4 | 4.3 | 44.9 | 0.1 | -2.6 | 0.0 | 21.7 |
| MOVE SPELL SPOT | 0.5 | +0.0 | 0.0 | 34.4 | 0.1 | +0.0 | 0.0 | 11.1 |
| MOVE TO CHARGE | 3.2 | +207.8 | 140.2 | 92.4 | 5.8 | +602.5 | 247.9 | 132.7 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +14.5 | 16.6 | 0.0 | 0.1 | +10.5 | 18.1 | 0.0 |
| NO RALLY LEFT | 0.0 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.1 | -1.1 | 11.1 | 0.0 | 0.4 | -40.8 | 75.2 | 1.1 |
| NOT TURNED | 6.1 | +110.8 | 0.0 | 133.2 | 4.9 | +38.1 | 0.0 | 93.6 |
| NOT WORTH A CAST | 0.6 | -0.5 | 0.0 | 31.0 | 0.8 | -0.8 | 0.0 | 0.0 |
| OFF BEST | 15.6 | -721.0 | 9.3 | 292.8 | 14.0 | -814.0 | 14.3 | 214.5 |
| OPENS A LANE | 0.2 | +0.2 | 0.5 | 0.0 | 0.1 | +0.2 | 3.2 | 0.0 |
| OPENS UP | 0.2 | +16.8 | 9.9 | 6.5 | 0.2 | +16.7 | 9.9 | 10.2 |
| OVERRUNS AWAY | 0.5 | +13.6 | 58.5 | 37.4 | 0.4 | +15.0 | 21.0 | 19.9 |
| PATHS CROSS | 1.8 | +105.6 | 0.0 | 5.2 | 2.6 | +223.2 | 0.0 | 51.8 |
| PERIAPT WORTH | 0.0 | +2.8 | 0.0 | 0.0 | 0.0 | +1.5 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -3.0 | 0.0 | 5.2 | 0.2 | -6.2 | 0.0 | 0.0 |
| PLAN RESULT | 36.2 | +1308.9 | 1353.5 | 914.2 | 37.2 | +1395.2 | 1382.0 | 956.2 |
| PURSUES BIG PREY | - | - | - | - | 0.1 | -1.9 | 0.0 | 5.4 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.1 | +11.5 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +4.9 | 0.0 | 0.0 | 0.1 | +4.3 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.5 | +2.2 | 0.0 | 29.4 | 1.7 | +27.3 | 0.0 | 38.9 |
| RANDOM MOVER NO PROMISE | 0.2 | -14.3 | 0.0 | 9.4 | 0.6 | -35.9 | 35.0 | 4.7 |
| REDIRECT BY WHAT IT STOPS | 0.3 | -8.0 | 0.0 | 5.0 | 0.5 | -3.8 | 0.0 | 1.6 |
| REDIRECT COUNTER | 1.8 | +154.3 | 0.0 | 47.8 | 3.5 | +296.9 | 0.0 | 51.4 |
| REDIRECT WEIGHED | 0.2 | -1.6 | 7.3 | 6.5 | 0.4 | +9.0 | 21.2 | 1.1 |
| RESERVE FALL BACK | 0.4 | +5.1 | 0.0 | 7.1 | 0.8 | +34.2 | 0.0 | 3.3 |
| RESTRAINS TO SHOOT | 0.1 | +2.4 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| RISK BY ARC | 2.5 | +100.8 | 245.9 | 59.7 | 2.5 | +75.5 | 252.1 | 66.6 |
| SAFER THAN THE JOB | 0.7 | +46.9 | 0.0 | 34.0 | 0.6 | +37.3 | 0.0 | 22.2 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.9 | 0.3 | +0.8 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.9 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -0.0 | 0.0 | 0.0 | 0.2 | -7.8 | 0.0 | 0.5 |
| SEARCH SPOT | 2.4 | +101.3 | 0.0 | 52.3 | 2.4 | +129.3 | 0.0 | 40.2 |
| SECOND HUNTER | 0.1 | -2.3 | 0.0 | 2.9 | - | - | - | - |
| SELF MOVE SPELL | 0.2 | +31.9 | 0.0 | 32.9 | 0.2 | +61.9 | 0.0 | 9.1 |
| SET UP TOGETHER | 1.0 | +92.9 | 69.4 | 30.6 | 2.2 | +246.6 | 91.6 | 49.5 |
| SET-UP ANY TARGET | 0.3 | +65.1 | 32.7 | 2.6 | 0.2 | +19.3 | 11.1 | 17.6 |
| SET-UP MISSED | 0.0 | +6.0 | 0.0 | 0.0 | 0.0 | +2.2 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.7 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +30.6 | 87.5 | 18.4 | 0.6 | +17.1 | 25.4 | 3.8 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OPTIONS | 14.3 | +0.0 | 571.7 | 267.1 | 10.4 | +0.0 | 413.1 | 222.4 |
| SHOT REPLANNED | 0.5 | +0.0 | 90.3 | 0.0 | 0.3 | +0.0 | 40.6 | 18.3 |
| SHOTS IN THE MOVE | 13.2 | +525.7 | 0.0 | 257.0 | 9.6 | +341.7 | 0.0 | 193.7 |
| SPELL SETS UP CHARGE | 0.5 | +101.1 | 32.7 | 2.6 | 0.2 | +19.3 | 11.1 | 17.6 |
| SPELL WORTH | 1.2 | +17.6 | 59.4 | 58.1 | 2.2 | +35.7 | 105.9 | 83.1 |
| STABLE ROLE | 10.4 | +0.0 | 311.6 | 171.8 | 8.5 | +0.0 | 297.1 | 122.4 |
| STANDS TO CAST | 0.0 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| STAY WORTH | - | - | - | - | 12.0 | +267.7 | 247.1 | 161.9 |
| STOPS | 0.2 | +4.3 | 0.0 | 0.0 | 0.1 | +3.0 | 8.1 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.4 | +9.9 | 0.0 | 21.0 | 0.4 | +33.1 | 0.0 | 32.0 |
| STUCK PIVOT | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 4.7 |
| SUPPORT NARROWED | 5.0 | -46.7 | 279.3 | 68.7 | 5.9 | -34.5 | 438.6 | 114.6 |
| SUPPORTS | 3.5 | +60.0 | 144.6 | 43.8 | 3.5 | +34.5 | 189.8 | 42.5 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -4.3 | 3.8 | 9.7 | 0.1 | -2.0 | 6.8 | 2.7 |
| SURE REACH TOGETHER | 0.4 | +5.0 | 0.0 | 16.9 | 0.8 | +4.4 | 0.0 | 15.3 |
| THREAT IN THE KILL | - | - | - | - | 8.4 | +124.6 | 436.0 | 157.3 |
| THREAT OVER THE TURNS | - | - | - | - | 7.2 | +72.6 | 385.4 | 137.1 |
| THREAT TO WORN DOWN | - | - | - | - | 8.4 | +110.1 | 433.1 | 157.3 |
| THROUGH LINE OF FIRE | 0.3 | +15.4 | 0.0 | 14.7 | 0.2 | +14.0 | 0.0 | 0.0 |
| TURN WORTH | 0.5 | -39.7 | 38.6 | 0.0 | 0.2 | -19.2 | 19.9 | 3.8 |
| TWO OR MORE ARRIVE | 0.4 | +2.7 | 14.7 | 0.0 | 0.7 | +11.3 | 61.1 | 23.4 |
| WAIT AFTER COSTS | 7.0 | -289.7 | 231.8 | 160.6 | 8.4 | -540.9 | 353.7 | 173.9 |
| WALKS TO THE FIGHT | 1.9 | +41.0 | 28.0 | 33.8 | 0.9 | +16.9 | 26.4 | 11.8 |
| WAR ENGINE CHARGES | 0.1 | +8.3 | 0.0 | 5.1 | 0.1 | +0.7 | 1.7 | 2.1 |
| WAR ENGINE JOBS | 0.5 | +0.0 | 41.0 | 28.5 | 0.1 | +0.0 | 3.8 | 3.8 |
| WEARS DOWN | 0.6 | +23.3 | 85.2 | 14.9 | 1.4 | +65.9 | 125.2 | 58.1 |
| WHO HITS BACK | 0.4 | +52.2 | 0.0 | 33.2 | 0.2 | +16.9 | 0.0 | 25.4 |
| WHOLE FIGHT | 0.4 | +6.8 | 64.7 | 3.8 | 0.4 | +9.3 | 81.1 | 17.7 |
| WHOLE FIGHT GAIN | 0.2 | +16.7 | 14.5 | 0.0 | 0.7 | +86.7 | 100.1 | 10.4 |
| WIZARD FRONT RANK | - | - | - | - | 0.0 | +0.0 | 0.0 | 9.1 |

### Rule changes: tk-h2h-opp-949ddcd-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1067 | 1067 | 1067 | 29.64 | -55262 | -51.8 |
| BEST FIRST | 268 | 268 | 268 | 7.44 | +14010 | +52.3 |
| MOVE TO CHARGE | 326 | 326 | 172 | 4.78 | +11349 | +66.0 |
| SEARCH SPOT | 170 | 170 | 164 | 4.56 | +8413 | +51.3 |
| PATHS CROSS | 155 | 155 | 155 | 4.31 | +11836 | +76.4 |
| COUNTER-CHARGE COVER | 584 | 308 | 121 | 3.36 | +6800 | +56.2 |
| FACES THE THREAT | 108 | 108 | 108 | 3.00 | +8376 | +77.6 |
| KILLS COUNT NEXT TURN | 491 | 491 | 104 | 2.89 | +2927 | +28.1 |
| FOLLOW UP WEIGHED | 93 | 93 | 93 | 2.58 | +13032 | +140.1 |
| SUPPORTS | 252 | 252 | 75 | 2.08 | +886 | +11.8 |
| ARTILLERY RE-ROLL WEIGHED | 72 | 72 | 72 | 2.00 | +0 | +0.0 |
| FALLBACK BY WORTH | 367 | 367 | 72 | 2.00 | +4256 | +59.1 |
| SHOTS IN THE MOVE | 820 | 558 | 63 | 1.75 | +1640 | +26.0 |
| CANNON SIGHT KEPT | 57 | 57 | 57 | 1.58 | +0 | +0.0 |
| WALKS TO THE FIGHT | 99 | 99 | 55 | 1.53 | +909 | +16.5 |
| SET UP TOGETHER | 116 | 100 | 54 | 1.50 | +4437 | +82.2 |
| WAIT AFTER COSTS | 555 | 555 | 54 | 1.50 | +1066 | +19.7 |
| SAFER THAN THE JOB | 48 | 48 | 48 | 1.33 | +3033 | +63.2 |
| BEST FACING | 46 | 46 | 46 | 1.28 | +2065 | +44.9 |
| CANNON PLANNED TARGET | 252 | 252 | 45 | 1.25 | +105 | +2.3 |
| BEST OVERALL | 42 | 42 | 42 | 1.17 | +3168 | +75.4 |
| RESERVE FALL BACK | 42 | 42 | 42 | 1.17 | +1413 | +33.6 |
| MAX FOR POSITIONING | 344 | 183 | 41 | 1.14 | +640 | +15.6 |
| RANDOM MOVE BY FIGURES | 80 | 80 | 41 | 1.14 | +1063 | +25.9 |
| REDIRECT COUNTER | 192 | 93 | 40 | 1.11 | +4004 | +100.1 |
| CHARGE NOW WEIGHED | 39 | 39 | 39 | 1.08 | +2758 | +70.7 |
| HOLDS AMBUSHERS | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| CHARGE NOW FIRST | 180 | 180 | 38 | 1.06 | -2164 | -56.9 |
| ADVANCE LANE KEPT | 37 | 37 | 37 | 1.03 | +0 | +0.0 |
| MOVE AND CAST | 37 | 37 | 37 | 1.03 | +2056 | +55.6 |
| RISK BY ARC | 182 | 172 | 36 | 1.00 | +1224 | +34.0 |
| COMBAT PIVOT | 34 | 34 | 34 | 0.94 | +0 | +0.0 |
| INVITES THE FIGHT | 100 | 100 | 33 | 0.92 | +502 | +15.2 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2259 | +68.5 |
| STOPS SHORT OF THE FLANK | 32 | 32 | 32 | 0.89 | +1547 | +48.4 |
| BLOCKED WHEEL | 30 | 30 | 30 | 0.83 | +148 | +4.9 |
| MISSILES IN THE MOVE | 277 | 166 | 30 | 0.83 | +716 | +23.9 |
| MAKE SURE TOGETHER | 68 | 51 | 29 | 0.81 | +2556 | +88.1 |
| SHOT REPLANNED | 28 | 28 | 28 | 0.78 | +0 | +0.0 |
| KILLS COUNT | 129 | 126 | 26 | 0.72 | +1288 | +49.5 |
| SHOOTS FROM THE BEST SPOT | 48 | 48 | 26 | 0.72 | +626 | +24.1 |
| MARCH CHECK | 38 | 34 | 25 | 0.69 | +2114 | +84.6 |
| SCOUT WAITS | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| CAST JOB | 71 | 71 | 24 | 0.67 | +594 | +24.7 |
| STAY WORTH | 433 | 352 | 23 | 0.64 | +343 | +14.9 |
| WHO HITS BACK | 23 | 23 | 23 | 0.64 | +1544 | +67.1 |
| MARCH ODDS | 22 | 22 | 22 | 0.61 | +254 | +11.6 |
| REDIRECT WEIGHED | 22 | 22 | 22 | 0.61 | +429 | +19.5 |
| THREAT TO WORN DOWN | 301 | 234 | 22 | 0.61 | +289 | +13.1 |
| THROUGH LINE OF FIRE | 20 | 20 | 20 | 0.56 | +1057 | +52.9 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +36 | +2.0 |
| WHOLE FIGHT GAIN | 33 | 30 | 18 | 0.50 | +1012 | +56.2 |
| FRIENDS SHOTS CHECKED | 17 | 17 | 17 | 0.47 | +1315 | +77.3 |
| KEEPS ITS TARGET | 129 | 125 | 15 | 0.42 | +237 | +15.8 |
| BEST MOVE FOR SHOOTERS | 14 | 14 | 14 | 0.39 | +2530 | +180.8 |
| BEST PREY | 61 | 61 | 14 | 0.39 | +1249 | +89.2 |
| BIG CHARACTER SAFETY | 14 | 14 | 14 | 0.39 | -4 | -0.3 |
| THREAT IN THE KILL | 303 | 235 | 14 | 0.39 | +127 | +9.1 |
| WAR ENGINE JOBS | 24 | 24 | 14 | 0.39 | -661 | -47.2 |
| WEARS DOWN | 72 | 67 | 14 | 0.39 | +731 | +52.2 |
| CHAFF PASSED | 13 | 13 | 13 | 0.36 | -33 | -2.5 |
| MANOEUVRE | 13 | 13 | 13 | 0.36 | +690 | +53.1 |
| PIVOT GUARDS FLANK | 10 | 10 | 10 | 0.28 | -332 | -33.2 |
| STUCK PIVOT | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTING BLOCK | 14 | 14 | 9 | 0.25 | +370 | +41.1 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| THREAT OVER THE TURNS | 259 | 207 | 9 | 0.25 | +51 | +5.7 |
| FOCUS OVER TURNS | 14 | 14 | 8 | 0.22 | +137 | +17.1 |
| MISSILES NEXT TURN | 341 | 195 | 7 | 0.19 | +37 | +5.3 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +141 | +20.1 |
| NEEDED THERE | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| SURE CHARGE BEATS ADVANCE | 7 | 7 | 7 | 0.19 | -226 | -32.2 |
| WHOLE FIGHT | 30 | 29 | 7 | 0.19 | +279 | +39.8 |
| BACKUP TARGETS | 59 | 27 | 6 | 0.17 | +74 | +12.3 |
| FACE THE CAST | 6 | 6 | 6 | 0.17 | +137 | +22.8 |
| HUNT IN PAIRS | 35 | 17 | 6 | 0.17 | +212 | +35.4 |
| LONE WIZARD HOLDS BACK | 17 | 17 | 6 | 0.17 | -380 | -63.4 |
| OPENS UP | 13 | 12 | 6 | 0.17 | +364 | +60.7 |
| BLOCKED CHARGE SKIPPED | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| KEEP FALLS | 5 | 5 | 5 | 0.14 | +122 | +24.4 |
| RESTRAINS TO SHOOT | 5 | 5 | 5 | 0.14 | +91 | +18.2 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| SUPPORT NARROWED | 394 | 394 | 5 | 0.14 | -71 | -14.2 |
| CARRIES OUT SET-UP | 11 | 11 | 4 | 0.11 | -315 | -78.7 |
| JOINT CHARGE PLAN | 15 | 15 | 4 | 0.11 | +161 | +40.2 |
| RAIDS THE BAGGAGE NEXT TURN | 4 | 4 | 4 | 0.11 | +131 | +32.9 |
| BEST PRIZE | 3 | 3 | 3 | 0.08 | -315 | -104.9 |
| HORN WORTH | 3 | 3 | 3 | 0.08 | +70 | +23.5 |
| LOST CHARGE | 181 | 180 | 3 | 0.08 | +40 | +13.3 |
| MODEL FACING | 3 | 3 | 3 | 0.08 | +460 | +153.2 |
| MOVE SPELL IN RANGE | 10 | 9 | 3 | 0.08 | +72 | +23.9 |
| OVERRUNS AWAY | 32 | 30 | 3 | 0.08 | +284 | +94.6 |
| PURSUES BIG PREY | 3 | 3 | 3 | 0.08 | -69 | -22.9 |
| CHARIOT NO STATIC JOB | 3 | 3 | 2 | 0.06 | -82 | -41.1 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +154 | +76.9 |
| TWO OR MORE ARRIVE | 41 | 35 | 2 | 0.06 | +27 | +13.7 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +9 | +9.2 |
| CARRIES OUT COUNTER | 2 | 2 | 1 | 0.03 | -136 | -136.4 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -2 | -1.5 |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| DEFENSIVE ARMY | 9 | 9 | 1 | 0.03 | -12 | -12.2 |
| DEFENSIVE FLOOR | 2 | 2 | 1 | 0.03 | +50 | +49.8 |
| EDGE GIVE GROUND | 13 | 12 | 1 | 0.03 | +16 | +16.0 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +2 | +2.3 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +15 | +15.1 |
| HUNT ADVANCE | 13 | 13 | 1 | 0.03 | +25 | +25.0 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| LONG SHOT | 26 | 25 | 1 | 0.03 | +14 | +14.0 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +11 | +10.7 |
| OPENS A LANE | 8 | 1 | 1 | 0.03 | +5 | +4.9 |
| RAIDS THE BAGGAGE | 2 | 2 | 1 | 0.03 | +144 | +143.7 |
| SCREEN BY WHAT IT SAVES | 9 | 9 | 1 | 0.03 | +2 | +1.5 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | -4 | -4.1 |
| STOPS | 9 | 9 | 1 | 0.03 | +24 | +24.3 |
| SURE REACH TOGETHER | 41 | 29 | 1 | 0.03 | +59 | +59.4 |
| WAR ENGINE CHARGES | 4 | 4 | 1 | 0.03 | +237 | +236.9 |
| WIZARD FRONT RANK | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 33 | 33 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 30 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 6 | 6 | 0 | 0.00 | - | - |
| CHEAP HELPER | 6 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 34 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 390 | not checked | - | - | - | - |
| GIVES UP | 6 | 5 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 3 | 3 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 7 | not checked | - | - | - | - |
| HELPER UNSEEN | 15 | 15 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 22 | 22 | 0 | 0.00 | - | - |
| HUNT DROPPED | 6 | trace | - | - | - | - |
| HUNT KEPT | 12 | trace | - | - | - | - |
| HUNT RESULT | 11 | trace | - | - | - | - |
| HUNT THE GUNS | 12 | trace | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 36 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 28 | 28 | 0 | 0.00 | - | - |
| MISSILES IN THE PLAN | 13 | 1 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 18 | 18 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 17 | trace | - | - | - | - |
| MOVE SPELL SPOT | 21 | not checked | - | - | - | - |
| NOT NEEDED | 16 | 16 | 0 | 0.00 | - | - |
| NOT TURNED | 393 | 393 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 50 | not checked | - | - | - | - |
| PLAN RESULT | 2640 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 29 | 29 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 28 | 28 | 0 | 0.00 | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SECOND HUNTER | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 16 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 18 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOT OPTIONS | 889 | 889 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 23 | not checked | - | - | - | - |
| SPELL WORTH | 122 | not checked | - | - | - | - |
| STABLE ROLE | 678 | 676 | 0 | 0.00 | - | - |
| TURN WORTH | 26 | 24 | 0 | 0.00 | - | - |

### Off best figure: tk-h2h-opp-949ddcd-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.56 | 12.42 | 52.4 |
| FALLBACK | gate | 0.75 | 0.67 | 60.0 |
| CHARGE NOW FIRST | rule | 0.47 | 0.58 | 56.9 |
| TURN GATE | gate | 0.61 | 0.33 | 44.7 |
| LONE CHARACTER SAFE SPOT | gate | 0.33 | 0.11 | 72.7 |
| WAR ENGINE JOBS | rule | 0.36 | 0.03 | 47.2 |
| PIVOT GUARDS FLANK | rule | 0.08 | 0.19 | 33.2 |
| AFTERMATH BAND | gate | 0.14 | 0.06 | 4.0 |
| CHARGE NOW WEIGHED | rule | 0.14 | 0.06 | 45.5 |
| NO REASON | gate | - | 0.19 | 19.9 |
| SUPPORT REQUEST | gate | 0.03 | 0.17 | 38.2 |
| SURE CHARGE BEATS ADVANCE | rule | 0.08 | 0.11 | 32.2 |
| CANNON PLANNED TARGET | rule | 0.17 | - | 29.3 |
| CHAFF PASSED | rule | 0.03 | 0.14 | 5.5 |
| FIGHT ORDER BAND | gate | 0.11 | 0.06 | 2.0 |
| LONE WIZARD HOLDS BACK | rule | 0.06 | 0.11 | 63.4 |
| BLOCKED WHEEL | rule | 0.08 | 0.06 | 36.3 |
| SUPPORT NARROWED | rule | 0.06 | 0.08 | 14.2 |
| CARRIES OUT SET-UP | rule | 0.08 | 0.03 | 78.7 |
| PATHS CROSS | rule | 0.06 | 0.06 | 42.0 |
| BEST PRIZE | rule | 0.06 | 0.03 | 104.9 |
| BIG CHARACTER SAFETY | rule | 0.03 | 0.06 | 14.2 |
| MARCH ODDS | rule | 0.06 | 0.03 | 15.0 |
| PURSUES BIG PREY | rule | - | 0.08 | 22.9 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.06 | 14.2 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | 0.03 | 33.1 |
| CHARIOT NO STATIC JOB | rule | 0.06 | - | 41.1 |
| REDIRECT WEIGHED | rule | 0.03 | 0.03 | 130.3 |
| RULE SWITCHED OFF | gate | 0.06 | - | 6.1 |
| CARRIES OUT COUNTER | rule | 0.03 | - | 136.4 |
| CATCH ODDS | rule | 0.03 | - | 1.5 |
| DEFENSIVE ARMY | rule | - | 0.03 | 12.2 |
| FALLBACK BY WORTH | rule | - | 0.03 | 323.2 |
| FOLLOW UP WEIGHED | rule | 0.03 | - | 4.9 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | - | 4.4 |
| MOVE AND CAST | rule | - | 0.03 | 6.0 |
| STANDS TO CAST | rule | 0.03 | - | 4.1 |
| THROUGH LINE OF FIRE | rule | 0.03 | - | 4.2 |

### Plans: tk-h2h-opp-949ddcd-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.0 | 16% | 401 | 319 | 80% |
| Mine | charge | 3.0 | 62% | 279 | 277 | 99% |
| Mine | close in | 4.6 | 27% | 314 | 132 | 42% |
| Mine | hold | 4.1 | 32% | 238 | 0 | 0% |
| Mine | join | 0.4 | 87% | 10 | 0 | 0% |
| Mine | shoot | 8.4 | 58% | 188 | 581 | 310% |
| Mine | support | 3.7 | 96% | 40 | 0 | 0% |
| Opponent | advance | 12.1 | 17% | 407 | 370 | 91% |
| Opponent | charge | 4.1 | 57% | 419 | 433 | 103% |
| Opponent | close in | 6.9 | 27% | 645 | 229 | 35% |
| Opponent | hold | 3.7 | 25% | 285 | 0 | 0% |
| Opponent | join | 0.9 | 97% | 30 | 0 | 0% |
| Opponent | shoot | 5.5 | 54% | 393 | 365 | 93% |
| Opponent | support | 4.0 | 87% | 29 | 0 | 0% |

### Packages: hunt the guns, tk-h2h-opp-949ddcd-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.2 | 7 | 1 | 0% | 0% | 0% | - | 444 | 0 | 0% | 50 |
| Opponent | 0.1 | 5 | 0 | 40% | 40% | 0% | 2.0 | 297 | 70 | 20% | 116 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1.5 | 6 | 1 | 0% | 0% | 0% | - | 457 | 0 | 0% | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 155 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Empire of Man | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 375 | 0 | 0% | 134 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 89 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 90 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 239 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 138 |
| Tomb Kings of Khemri | 0.5 | 3 | 0 | 33% | 33% | 0% | 2.0 | 311 | 42 | 0% | 77 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 9 |
| Warriors of Chaos | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 252 | 223 | 100% | 106 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 299 | 0 | 0% | 84 |

### Battle groups: tk-h2h-opp-949ddcd-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.4 | 22% | 50% | 16% | 42% | 45% | 8% | 12% | 34% | 0% |
| Mine | REDIRECT COUNTER | 1.8 | 34% | 82% | 14% | 67% | 58% | 0% | 0% | 42% | 0% |
| Opponent | COUNTER-CHARGE COVER | 6.8 | 19% | 66% | 21% | 20% | 35% | 3% | 14% | 49% | 0% |
| Opponent | REDIRECT COUNTER | 3.5 | 24% | 71% | 16% | 60% | 8% | 0% | 8% | 81% | 4% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: tk-h2h-opp-949ddcd-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 34 | 59 (34) | 22 | 37 | 49 | 32% | 2.4 | 52 (21) | 0 (4) | 95 (9) | 87 (24) | 0 (10) |
| Mine | Character | 119 | 45 (119) | 45 | 0 | 40 | 17% | 2.5 | 41 (39) | 61 (52) | 30 (8) | 53 (57) | 48 (42) |
| Mine | Clean-up | 20 | 41 (20) | 10 | 31 | 42 | 45% | 2.7 | 48 (5) | 39 (13) | 21 (2) | 59 (13) | 14 (7) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 44 | 38 (44) | 22 | 15 | 41 | 23% | 3.1 | 25 (20) | 45 (18) | 57 (6) | 42 (31) | 29 (13) |
| Mine | Fragile | 3 | 10 (3) | 10 | 0 | 33 | 67% | 3.0 | 10 (3) | - | - | 29 (1) | 0 (2) |
| Mine | Hammer | 50 | 39 (50) | 30 | 9 | 44 | 6% | 2.6 | 13 (11) | 45 (35) | 61 (4) | 32 (34) | 54 (16) |
| Mine | Holder | 25 | 58 (25) | 17 | 41 | 29 | 40% | 3.6 | 39 (8) | 42 (12) | 159 (5) | 87 (14) | 24 (11) |
| Mine | Shooter | 37 | 47 (37) | 20 | 27 | 60 | 5% | 1.8 | 28 (6) | 54 (28) | 19 (3) | 49 (22) | 44 (15) |
| Mine | Support | 4 | 23 (4) | 23 | 0 | 39 | 25% | 2.0 | 0 (2) | 59 (2) | - | 59 (2) | 0 (2) |
| Mine | War machine | 52 | 64 (52) | 64 | 0 | 28 | 2% | 1.1 | 67 (13) | 50 (35) | 191 (4) | 63 (13) | 64 (39) |
| Mine | Wizard | 16 | 10 (16) | 10 | 0 | 12 | 19% | 1.5 | 22 (4) | 0 (7) | 14 (4) | 7 (10) | 20 (5) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 68 | 60 (68) | 34 | 26 | 47 | 47% | 2.9 | 95 (29) | 86 (11) | 18 (28) | 82 (48) | 9 (20) |
| Opponent | Character | 101 | 47 (101) | 47 | 0 | 29 | 23% | 2.0 | 50 (36) | 48 (53) | 17 (5) | 41 (49) | 54 (45) |
| Opponent | Clean-up | 10 | 41 (10) | 19 | 22 | 48 | 30% | 2.4 | 18 (4) | 58 (5) | 19 (1) | 32 (6) | 50 (4) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 59 | 51 (59) | 26 | 25 | 36 | 27% | 2.6 | 52 (28) | 64 (21) | 17 (10) | 75 (26) | 31 (33) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 100 | 33% | 2.0 | - | 0 (2) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Hammer | 47 | 54 (47) | 50 | 4 | 45 | 26% | 3.1 | 35 (16) | 57 (28) | 107 (3) | 81 (29) | 9 (18) |
| Opponent | Holder | 42 | 84 (42) | 15 | 69 | 33 | 31% | 2.6 | 21 (8) | 118 (24) | 68 (9) | 70 (28) | 116 (13) |
| Opponent | Shooter | 30 | 45 (30) | 28 | 17 | 49 | 3% | 1.0 | 49 (8) | 32 (20) | 236 (2) | 51 (18) | 37 (12) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 17 | 75% | 6.0 | 0 (2) | 0 (1) | 0 (1) | 0 (2) | 0 (2) |
| Opponent | War machine | 17 | 88 (17) | 88 | 0 | 48 | 6% | 1.3 | 203 (3) | 32 (10) | 145 (4) | 102 (3) | 86 (14) |
| Opponent | Wizard | 33 | 4 (33) | 4 | 0 | 50 | 24% | 1.7 | 5 (13) | 7 (8) | 0 (2) | 5 (11) | 5 (12) |

### Charged fights: tk-h2h-opp-949ddcd-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 0 | 210 | 1.8 | 1.1 | 120 | 93 | +27 | 3 of 7 | 6 of 7 | +40 | +25 |
| Mine | Chaos Dwarfs | 4 | 264 | 288 | 2.8 | 1.0 | 105 | 11 | +94 | 5 of 11 | 9 of 11 | - | +94 |
| Mine | Dwarfen Mountain Holds | 3 | 588 | 33 | 2.0 | 1.0 | 17 | 10 | +7 | 2 of 6 | 4 of 6 | - | +7 |
| Mine | Empire of Man | 5 | 291 | 72 | 0.8 | 1.0 | 90 | 0 | +90 | 0 of 4 | 2 of 4 | - | +90 |
| Mine | Grand Cathay | 5 | 707 | 321 | 3.6 | 1.1 | 89 | 36 | +54 | 3 of 18 | 17 of 18 | -434 | +82 |
| Mine | High Elf Realms | 4 | 12 | 449 | 3.0 | 1.0 | 150 | 0 | +150 | 3 of 12 | 10 of 12 | - | +150 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 542 | 3.0 | 1.3 | 181 | 0 | +181 | 0 of 3 | 1 of 3 | +334 | +104 |
| Mine | Lizardmen | 1 | 0 | 430 | 5.0 | 1.0 | 86 | 141 | -55 | 0 of 5 | 5 of 5 | - | -55 |
| Mine | Ogre Kingdoms | 1 | 116 | 170 | 4.0 | 1.0 | 42 | 58 | -16 | 1 of 4 | 3 of 4 | - | -16 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 272 | 4.0 | 1.0 | 68 | 0 | +68 | 0 of 4 | 3 of 4 | - | +68 |
| Mine | Skaven | 1 | 19 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 2 | 0 | 413 | 5.5 | 1.2 | 75 | 46 | +29 | 2 of 11 | 8 of 11 | +135 | +5 |
| Mine | Vampire Counts | 2 | 49 | 470 | 4.5 | 1.1 | 104 | 7 | +98 | 1 of 9 | 7 of 9 | +19 | +108 |
| Mine | Warriors of Chaos | 2 | 62 | 566 | 2.0 | 1.2 | 283 | 0 | +283 | 1 of 4 | 4 of 4 | +608 | +175 |
| **Mine** | all armies | 36 | 228 | 282 | 2.7 | 1.1 | 104 | 30 | +73 | 21 of 98 | 79 of 98 | +120 | +70 |
| Opponent | Empire of Man | 1 | 618 | 0 | 2.0 | 1.0 | 0 | 94 | -94 | 0 of 2 | 0 of 2 | - | -94 |
| Opponent | Grand Cathay | 3 | 424 | 402 | 3.0 | 1.3 | 134 | 59 | +75 | 3 of 9 | 8 of 9 | +476 | -39 |
| Opponent | High Elf Realms | 3 | 163 | 279 | 2.3 | 1.1 | 120 | 50 | +70 | 6 of 7 | 5 of 7 | +0 | +82 |
| Opponent | Kingdom of Bretonnia | 2 | 224 | 286 | 3.5 | 1.0 | 82 | 40 | +42 | 4 of 7 | 5 of 7 | - | +42 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 561 | 5.0 | 1.0 | 112 | 0 | +112 | 1 of 5 | 5 of 5 | - | +112 |
| Opponent | Skaven | 1 | 60 | 338 | 3.0 | 1.0 | 113 | 0 | +113 | 1 of 3 | 2 of 3 | - | +113 |
| Opponent | Tomb Kings of Khemri | 4 | 98 | 322 | 3.8 | 1.2 | 86 | 48 | +38 | 9 of 15 | 12 of 15 | +250 | +5 |
| Opponent | Vampire Counts | 6 | 0 | 670 | 6.0 | 1.2 | 112 | 19 | +93 | 18 of 36 | 17 of 36 | +197 | +84 |
| Opponent | Warriors of Chaos | 9 | 0 | 535 | 3.8 | 1.1 | 142 | 32 | +109 | 16 of 34 | 23 of 34 | +321 | +96 |
| Opponent | Wood Elf Realms | 6 | 125 | 293 | 2.3 | 1.2 | 126 | 105 | +21 | 5 of 14 | 9 of 13 | +352 | -34 |
| **Opponent** | all armies | 36 | 112 | 428 | 3.7 | 1.1 | 117 | 40 | +76 | 63 of 132 | 86 of 131 | +282 | +56 |

### Effective charges: tk-h2h-opp-949ddcd-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 7 | 1 (net +135) | 0 | 1 (net +0) | 1 (net +165) | 0 | 2 (net +270) | 2 | 20% (1 of 5) |
| Mine | Chaos Dwarfs | 11 | 2 (net +0) | 0 | 1 (net +0) | 2 (net +0) | 1 (net +230) | 5 (net +160) | 0 | 9% (1 of 11) |
| Mine | Dwarfen Mountain Holds | 6 | 1 (net -60) | 1 (net +0) | 1 (net +65) | 1 (net +0) | 0 | 2 (net +18) | 0 | 17% (1 of 6) |
| Mine | Empire of Man | 4 | 1 (net +217) | 0 | 1 (net +0) | 1 (net +0) | 0 | 1 (net +144) | 0 | 25% (1 of 4) |
| Mine | Grand Cathay | 18 | 0 | 0 | 3 (net +7) | 2 (net +155) | 4 (net -59) | 7 (net +87) | 2 | 19% (3 of 16) |
| Mine | High Elf Realms | 12 | 0 | 0 | 0 | 3 (net +225) | 4 (net +96) | 5 (net +147) | 0 | 0% (0 of 12) |
| Mine | Kingdom of Bretonnia | 3 | 0 | 0 | 1 (net +334) | 1 (net +208) | 0 | 1 (net +0) | 0 | 33% (1 of 3) |
| Mine | Lizardmen | 5 | 0 | 0 | 2 (net -352) | 1 (net +144) | 0 | 1 (net +170) | 1 | 50% (2 of 4) |
| Mine | Ogre Kingdoms | 4 | 0 | 0 | 1 (net +0) | 0 | 0 | 2 (net +85) | 1 | 33% (1 of 3) |
| Mine | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 0 | 0 | 2 (net +136) | 2 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 11 | 2 (net +0) | 0 | 0 | 5 (net +76) | 3 (net -47) | 1 (net +75) | 0 | 0% (0 of 11) |
| Mine | Vampire Counts | 9 | 2 (net +19) | 0 | 2 (net +126) | 1 (net +19) | 2 (net +10) | 2 (net +275) | 0 | 22% (2 of 9) |
| Mine | Warriors of Chaos | 4 | 2 (net +433) | 1 (net +30) | 0 | 0 | 0 | 1 (net +236) | 0 | 0% (0 of 4) |
| Opponent | Empire of Man | 2 | 0 | 0 | 1 (net -189) | 0 | 0 | 1 (net +0) | 0 | 50% (1 of 2) |
| Opponent | Grand Cathay | 9 | 0 | 0 | 1 (net +85) | 4 (net +126) | 2 (net +0) | 2 (net +42) | 0 | 11% (1 of 9) |
| Opponent | High Elf Realms | 7 | 1 (net +270) | 0 | 3 (net -116) | 0 | 0 | 2 (net +177) | 1 | 50% (3 of 6) |
| Opponent | Kingdom of Bretonnia | 7 | 4 (net +74) | 1 (net +0) | 0 | 1 (net +0) | 0 | 0 | 1 | 0% (0 of 6) |
| Opponent | Orc & Goblin Tribes | 5 | 0 | 0 | 1 (net +0) | 1 (net +199) | 0 | 0 | 3 | 50% (1 of 2) |
| Opponent | Skaven | 3 | 1 (net +0) | 0 | 0 | 0 | 0 | 2 (net +169) | 0 | 0% (0 of 3) |
| Opponent | Tomb Kings of Khemri | 15 | 2 (net -322) | 0 | 3 (net +162) | 2 (net +0) | 2 (net +114) | 6 (net +83) | 0 | 20% (3 of 15) |
| Opponent | Vampire Counts | 36 | 10 (net +105) | 3 (net +164) | 5 (net +12) | 8 (net +68) | 4 (net +89) | 4 (net +182) | 2 | 15% (5 of 34) |
| Opponent | Warriors of Chaos | 34 | 9 (net +67) | 2 (net +268) | 2 (net -164) | 3 (net +171) | 1 (net +135) | 12 (net +118) | 5 | 7% (2 of 29) |
| Opponent | Wood Elf Realms | 14 | 2 (net -52) | 0 | 0 | 2 (net +116) | 1 (net +115) | 3 (net +120) | 6 | 0% (0 of 8) |

### Charged fights, damage counted: tk-h2h-opp-949ddcd-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 11 | 175 | 227 | +109 | 122 | 36 | +87 | +49.6 |
| Mine | 50-54% | 2 | 53 | 67 | +15 | 54 | 14 | +40 | +75.0 |
| Mine | Effective (55-75%) | 13 | 254 | 205 | -3 | 100 | 102 | -3 | -1.0 |
| Mine | 76-89% | 18 | 325 | 164 | +106 | 120 | 15 | +105 | +32.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 32 | 237 | 180 | +135 | 156 | 20 | +136 | +57.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 14 | 386 | 83 | +18 | 91 | 78 | +13 | +3.4 |
| Mine | No odds | 8 | 291 | 188 | -63 | 68 | 144 | -76 | -25.9 |
| Mine | All fights | 98 | 270 | 170 | +73 | 120 | 50 | +70 | +25.8 |
| Opponent | Long shot (under 50%) | 29 | 212 | 236 | +51 | 104 | 67 | +37 | +17.5 |
| Opponent | 50-54% | 6 | 383 | 361 | +172 | 243 | 79 | +165 | +43.0 |
| Opponent | Effective (55-75%) | 16 | 243 | 244 | -15 | 101 | 99 | +2 | +0.7 |
| Opponent | 76-89% | 21 | 268 | 254 | +95 | 150 | 68 | +82 | +30.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 32 | 326 | 229 | +118 | 196 | 65 | +131 | +40.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 10 | 568 | 110 | +84 | 92 | 15 | +77 | +13.5 |
| Opponent | No odds | 18 | 175 | 173 | +68 | 134 | 59 | +75 | +43.0 |
| Opponent | All fights | 132 | 282 | 226 | +76 | 143 | 66 | +77 | +27.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| tk-h2h-opp-949ddcd-p3 | move | 454 | 86 (19%) | 67 (15%) | 64 (14%) | 304 (67%) |
| tk-h2h-opp-949ddcd-p3 | objective | 413 | 66 (16%) | 50 (12%) | 59 (14%) | 288 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

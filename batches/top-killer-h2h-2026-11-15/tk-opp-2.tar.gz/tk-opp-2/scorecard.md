# Doctrine scorecard: tk-h2h-opp-949ddcd-p2

### Scorecard: tk-h2h-opp-949ddcd-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 0 | 6 | 0 | 2 | 0 | 0 | 0 | 387 |
| L0106 | 4 | 1 | Opponent | no | 0 | 2 | 0 | 1 | 0 | 0 | 0 | 615 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 639 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | - | 0 | 6 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 2 | 0 | 1 | 1 | 0 | 0 | 615 |
| L0222 | 6 | 1 | Mine | no | 5 | 3 | 3 | 2 | 0 | 0 | 0 | 170 |
| L0222 | 6 | 1 | Opponent | no | 3 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 675 |
| L0307 | 1 | 1 | Opponent | yes | 2 | 2 | 0 | 1 | 1 | 0 | 0 | 420 |
| L0323 | 5 | 1 | Mine | no | - | - | 0 | 0 | 0 | 0 | 0 | 590 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 5 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 4 | 3 | 1 | 0 | 0 | 0 | 0 | 808 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | no | - | 2 | 1 | 5 | 1 | 0 | 0 | 348 |
| L0512 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 1042 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 2 | 2 | 1 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | yes | 7 | 5 | 2 | 1 | 0 | 0 | 0 | 475 |
| L0528 | 6 | 1 | Opponent | no | 6 | - | 1 | 1 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 1 | 6 | 1 | 0 | 0 | 0 | 0 | 926 |
| L0616 | 4 | 1 | Opponent | no | 3 | 3 | 2 | 2 | 1 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 2 | 1 | 0 | 0 | 0 | 0 | 743 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L0721 | 1 | 1 | Mine | yes | 1 | 2 | 2 | 1 | 0 | 0 | 0 | 375 |
| L0721 | 1 | 1 | Opponent | yes | 0 | - | 0 | 3 | 1 | 0 | 0 | 355 |
| L0810 | 6 | 1 | Mine | no | 4 | 2 | 1 | 2 | 0 | 0 | 0 | 515 |
| L0810 | 6 | 1 | Opponent | no | 11 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 886 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 6 | 4 | 1 | 3 | 0 | 0 | 0 | 234 |
| L0934 | 4 | 1 | Mine | no | 1 | 1 | 2 | 0 | 0 | 0 | 0 | 840 |
| L0934 | 4 | 1 | Opponent | no | 5 | 2 | 3 | 3 | 1 | 0 | 0 | 216 |
| L1026 | 6 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 6 | 2 | 6 | 0 | 1 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 6 | 0 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 40 |
| L1135 | 1 | 1 | Mine | yes | 5 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1135 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 1 | 0 | 0 | 274 |
| L1228 | 4 | 1 | Mine | no | 3 | 4 | 0 | 1 | 0 | 0 | 0 | 858 |
| L1228 | 4 | 1 | Opponent | no | 7 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1323 | 3 | 1 | Mine | no | 2 | 2 | 2 | 1 | 0 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | no | 1 | 2 | 3 | 1 | 0 | 0 | 0 | 66 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 7 | 1 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | - | 2 | 2 | 2 | 0 | 0 | 305 |
| L1435 | 1 | 1 | Mine | no | 0 | 4 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 1 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 1 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | yes | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 484 |
| L1629 | 3 | 1 | Mine | no | 2 | 1 | 3 | 1 | 0 | 0 | 0 | 200 |
| L1629 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | yes | - | 3 | 2 | 0 | 0 | 0 | 0 | 135 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 0 | 4 | 1 | 0 | 0 | 0 | 0 | 602 |
| L1827 | 3 | 1 | Opponent | no | 8 | 2 | 8 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 1 | 1 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Opponent | no | 2 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 0 | 0 | 1 | 0 | 0 | 420 |
| L2029 | 1 | 1 | Opponent | no | 0 | 2 | 6 | 0 | 0 | 0 | 0 | 170 |
| L2131 | 1 | 1 | Mine | yes | 2 | - | 2 | 2 | 0 | 0 | 0 | 0 |
| L2131 | 1 | 1 | Opponent | no | 1 | 2 | 0 | 1 | 1 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | no | 3 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 126 |
| L2429 | 5 | 1 | Mine | yes | - | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | no | - | 3 | 4 | 1 | 1 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Mine | no | 6 | 3 | 2 | 1 | 1 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 2 | 1 | 6 | 0 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | yes | - | 5 | 2 | 6 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 1 | 2 | 4 | 1 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 9 | 2 | 2 | 0 | 0 | 0 | 0 | 312 |
| L3033 | 3 | 1 | Opponent | no | 0 | 1 | 6 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 30% | 2.4 | 2.8 | 1.8 | 1.1 | 0.1 | 0.0 | 0.0 | 342.8 |
| **Average** | | | Opponent | 23% | 2.8 | 2.1 | 3.1 | 1.6 | 0.4 | 0.0 | 0.0 | 174.3 |

### KPIs: tk-h2h-opp-949ddcd-p2

Rules off - Mine only: STAY WORTH, BEST MOVE FOR SHOOTERS, THREAT IN THE KILL, FOCUS OVER TURNS, MISSILES IN THE PLAN, FACE THE CAST, WIZARD FRONT RANK, THREAT OVER THE TURNS, THREAT TO WORN DOWN.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 30% (53 of 174) | 14% (26 of 182) | 22% (79 of 356) |
| Winner chose to follow up after the loser gave ground |  | 96% (71 of 74); on the table 97% | 100% (43 of 43); on the table 100% | 97% (114 of 117); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (8 of 8); on the table 100% | 88% (14 of 16); on the table 94% | 92% (22 of 24); on the table 96% |
| Winner chose to pursue after the loser fled |  | 76% (22 of 29); on the table 83% | 64% (30 of 47); on the table 70% | 68% (52 of 76); on the table 75% |
| Winner chose to follow up or pursue (all three) |  | 91% (101 of 111); on the table 94% | 82% (87 of 106); on the table 86% | 87% (188 of 217); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 28% (96 of 342) | 35% (55 of 156) | 30% (151 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 48% (96 of 199) | 50% (55 of 109) | 49% (151 of 308) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 21% (32 of 150) | 27% (21 of 78) | 23% (53 of 228) |
|     round 1 |  | 24% (6 of 25) | 15% (2 of 13) | 21% (8 of 38) |
|     rounds 2+ |  | 21% (26 of 125) | 29% (19 of 65) | 24% (45 of 190) |
|   other wizards | 50%+ | 33% (64 of 192) | 44% (34 of 78) | 36% (98 of 270) |
|     round 1 |  | 44% (14 of 32) | 54% (7 of 13) | 47% (21 of 45) |
|     rounds 2+ |  | 31% (50 of 160) | 42% (27 of 65) | 34% (77 of 225) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 47% (15 of 32) | 63% (33 of 52) | 57% (48 of 84) |
| Points that never fought | lower | 32% (22551 of 71583) | 35% (25397 of 71989) | 33% (47948 of 143572) |
|   infantry points that never fought | lower | 40% (6603 of 16324) | 54% (7644 of 14029) | 47% (14247 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% (173 of 284) | 56% (167 of 297) | 59% (340 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 95% (19 of 20); 1.1 uses a game | 72% (13 of 18); 1.0 uses a game | 84% (32 of 38); 1.1 uses a game |
| Bound items with another spell used |  | 56% (10 of 18); 0.4 uses a game | 50% (1 of 2); 0.0 uses a game | 55% (11 of 20); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 45% (9 of 20); 0.2 uses a game | 14% (1 of 7); 0.0 uses a game | 37% (10 of 27); 0.1 uses a game |
|   their share of the points of units over 100 pts | lower | 56% (33637 of 60231) | 50% (31392 of 63281) | 53% (65029 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.6 (24%) | 0.6 (23%) | 2.3 (24%) |
| MARCHED: its unit marched | 0.8 (11%) | 0.4 (14%) | 1.1 (12%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.1 (2%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.8 (26%) | 0.8 (29%) | 2.6 (27%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (6%) | 0.2 (2%) |
| FLEEING: fleeing | 0.5 (7%) | 0.0 (0%) | 0.5 (5%) |
| GONE: slain | 1.4 (20%) | 0.3 (11%) | 1.7 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (5%) | 0.2 (7%) | 0.5 (5%) |
| STUPIDITY: Stupidity | 0.2 (2%) | 0.1 (2%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.2 (6%) | 0.2 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.1 | 1.8 | 1.2 | 4.2 | 0.4 | 1.8 |
| not cast | 3.7 | 3.2 | 3.8 | 9.6 | 1.9 | 19.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) | 1.9 (10%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.5 (46%) | 0.2 (6%) | 2.3 (24%) | 0.6 (29%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.1 (12%) | 0.3 (17%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (1%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (4%) | 0.3 (10%) | 0.6 (16%) | 2.6 (27%) | 0.3 (14%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.4 (10%) | 0.3 (11%) | 0.3 (9%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) |
| FLEEING: fleeing | 0.3 (7%) | 0.2 (5%) | 0.2 (6%) | 0.5 (5%) | 0.1 (4%) | 1.0 (5%) |
| GONE: slain | 0.5 (14%) | 0.4 (14%) | 0.4 (12%) | 1.7 (17%) | 0.1 (7%) | 3.1 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (1%) | 0.0 (0%) | 0.3 (8%) | 0.5 (5%) | 0.2 (12%) | 0.7 (3%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.1 (2%) | 0.1 (2%) | 0.2 (2%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.2 (6%) | 0.3 (10%) | 0.0 (1%) | 0.0 (0%) | 0.2 (12%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (55%) | 0.1 (3%) | 1.4 (39%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.8 (65%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.6 a game | 0.7 a game | 0.6 a game |
| stood (cast and not dispelled) | 72% (13 of 18) | 58% (14 of 24) | 64% (27 of 42) |
| the unit moved after it | 92% (12 of 13) | 64% (9 of 14) | 78% (21 of 27) |
| it charged on its next turn | 0% (0 of 13) | 14% (2 of 14) | 7% (2 of 27) |
| the enemy charged it first | 23% (3 of 13) | 7% (1 of 14) | 15% (4 of 27) |
| it fought by the end of its next turn | 15% (2 of 13) | 7% (1 of 14) | 11% (3 of 27) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 13) | 7% (1 of 14) | 4% (1 of 27) |
| none of these (no charge, no fight, no charge escaped) | 77% (10 of 13) | 71% (10 of 14) | 74% (20 of 27) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (542 of 836) | 55% (446 of 805) | 60% (988 of 1641) |
|   cavalry | 69% (51 of 74) | 63% (113 of 178) | 65% (164 of 252) |
|   character | 52% (55 of 106) | 29% (34 of 116) | 40% (89 of 222) |
|   chariot | 50% (53 of 106) | 56% (27 of 48) | 52% (80 of 154) |
|   infantry | 62% (152 of 247) | 55% (166 of 301) | 58% (318 of 548) |
|   monster | 33% (12 of 36) | 60% (21 of 35) | 46% (33 of 71) |
|   war machine | 82% (219 of 267) | 67% (85 of 127) | 77% (304 of 394) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.6 (32%) | 1.9 (19%) | 4.5 (25%) |
| CHARGED: it charged | 0.8 (10%) | 1.9 (19%) | 2.7 (15%) |
| FLEEING: it fled or was fleeing | 0.1 (2%) | 0.3 (3%) | 0.4 (2%) |
| IN COMBAT: it fought this turn or the last | 1.1 (13%) | 0.6 (6%) | 1.6 (9%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 1.3 (16%) | 2.4 (24%) | 3.8 (21%) |
| ONLY IN COMBAT: the only targets were in combat | 0.2 (3%) | 0.5 (5%) | 0.8 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (16%) | 1.4 (14%) | 2.7 (15%) |
| SHELTERED: the target was sheltered | 0.3 (4%) | 0.6 (6%) | 0.9 (5%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.3 (4%) | 0.4 (4%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.8 | 1.4 | 82% | 4.2 pts | 29 pts |
| character | 2.7 | 0.9 | 71% | 11.1 pts | 30 pts |
| chariot | 2.2 | 1.8 | 72% | 13.3 pts | 30 pts |
| infantry | 12.1 | 4.7 | 72% | 8.6 pts | 103 pts |
| monster | 1.1 | 0.2 | 80% | 7.7 pts | 9 pts |
| war machine | 8.4 | 6.7 | 62% | 23.7 pts | 200 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.5 | 6.9 | 5.2 |
| Charges that made contact a game | 2.7 | 5.0 | 3.9 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.83 declared, 0.62 contact (24 units) | 1.15 declared, 0.92 contact (13 units) | 0.95 declared, 0.73 contact (37 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.57 declared, 0.57 contact (7 units) | 1.73 declared, 1.09 contact (11 units) | 1.28 declared, 0.89 contact (18 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.42 declared, 0.32 contact (245 units) | 0.74 declared, 0.54 contact (290 units) | 0.59 declared, 0.44 contact (535 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 60% (44 of 73) | 50% (9 of 18) | 42% (5 of 12) | 56% (58 of 103) |
| Character in a unit | 77% (23 of 30) | 62% (10 of 16) | 75% (3 of 4) | 72% (36 of 50) |
| Character on its own | 76% (32 of 42) | 55% (21 of 38) | 23% (14 of 62) | 47% (67 of 142) |
| Chariot | 59% (10 of 17) | 85% (11 of 13) | - | 70% (21 of 30) |
| Infantry | 55% (52 of 94) | 62% (21 of 34) | 33% (1 of 3) | 56% (74 of 131) |
| Monster | 59% (17 of 29) | 67% (6 of 9) | - | 61% (23 of 38) |
| Monstrous | 50% (7 of 14) | 57% (8 of 14) | - | 54% (15 of 28) |
| War Machines | 79% (45 of 57) | 50% (1 of 2) | - | 78% (46 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 93% (14 of 15); on the table 100% | 25% (26 of 102) | 38% | 73% (16 of 22) | 100% (6 of 6); 2.8 uses a game | 50% (1 of 2); 0.2 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 100% (11 of 11); on the table 100% | 39% (14 of 36) | 46% | 66% (21 of 32) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 6 | 85% (11 of 13); on the table 85% | - | 48% | 61% (33 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 85% (11 of 13); on the table 92% | 33% (16 of 48) | 43% | 64% (49 of 76) | 0.0 uses a game | 100% (2 of 2); 0.3 uses a game | 50% (2 of 4); 0.3 uses a game |
| Grand Cathay | 6 | 92% (24 of 26); on the table 92% | 26% (36 of 138) | 39% | 44% (24 of 54) | 79% (11 of 14); 5.3 uses a game | 50% (1 of 2); 0.2 uses a game | 0% (0 of 6); 0.0 uses a game |
| High Elf Realms | 4 | 100% (16 of 16); on the table 100% | 17% (3 of 18) | 17% | 52% (17 of 33) | 100% (3 of 3); 1.5 uses a game | 50% (7 of 14); 3.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 80% (4 of 5); on the table 80% | - | 44% | 42% (5 of 12) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Lizardmen | 1 | 100% (2 of 2); on the table 100% | - | 35% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 80% (8 of 10); on the table 90% | 0% (0 of 18) | 28% | 79% (22 of 28) | 100% (4 of 4); 2.2 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (3 of 3); on the table 100% | 17% (2 of 12) | 0% | 25% (2 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 3 | 89% (8 of 9); on the table 89% | 44% (8 of 18) | 47% | 64% (16 of 25) | 100% (2 of 2); 1.3 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Tomb Kings of Khemri | 5 | 69% (9 of 13); on the table 69% | - | 29% | 32% (8 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 81% (29 of 36); on the table 89% | 44% (29 of 66) | 26% | 61% (33 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 75% (18 of 24); on the table 79% | 50% (9 of 18) | 25% | 56% (41 of 73) | 100% (2 of 2); 0.7 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 95% (20 of 21); on the table 95% | 33% (8 of 24) | 28% | 64% (50 of 78) | 57% (4 of 7); 1.4 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (tk-h2h-opp-949ddcd-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (53) | 51% (30) | 50% (83) |
| ...free all their last turn and able to turn (per game) | 0.89 | 0.61 | 1.50 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.31 | 0.08 | 0.39 |
| ...with the charger already in that arc before they moved (per game) | 0.64 | 0.39 | 1.03 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.81 | 1.14 | 2.94 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.19 | 0.56 | 1.75 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.31 | 4.94 | 11.25 |

### Quality by phase: tk-h2h-opp-949ddcd-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 55% (61 of 111) | 49% (119 of 241) |
| Strategy | Shoot objectives carried out (shot that target) | 45% (140 of 309) | 56% (129 of 231) |
| Strategy | Close-in objectives charged next turn | 13% (15 of 116) | 25% (56 of 222) |
| Strategy | Support requests answered (helper made contact too) | 80% (8 of 10) | 48% (16 of 33) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (5 of 5) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 20% (3 of 15) | 57% (8 of 14) |
| Strategy | Joined characters whose unit fought | 60% (25 of 42) | 44% (17 of 39) |
| Strategy | Lone characters that fought | 80% (82 of 103) | 83% (70 of 84) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 1.1 | 1.6 |
| Movement | Points that never moved of their own | 342.8 | 174.3 |
| Movement | Fights charged into per game | 2.3 | 4.1 |
| Movement | Charges with odds: long shots (under 50%) | 8 of 78, net +220 | 24 of 144, net -13 |
| Movement | Charges with odds: sweet spot (55-75%) | 8 of 78, net +90 | 32 of 144, net +134 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 17 of 78, net +58 | 13 of 144, net +130 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 21 of 78, net +19 | 45 of 144, net +173 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.8 | 10.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 42% (149 of 351) | 44% (169 of 386) |
| Shooting | Points destroyed by shooting units | 44.4 | 44.3 |
| Shooting | War machine shots | 6.1 | 2.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 57% (124 of 219) | 54% (46 of 85) |
| Shooting | Points destroyed by war machines | 92.9 | 26.4 |
| Magic | Magic missiles cast | 1.7 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 32% (20 of 62) | 37% (15 of 41) |
| Magic | Wounds caused by magic missiles | 2.4 | 1.4 |
| Magic | Wounds caused by other spells | 1.7 | 0.6 |
| Magic | Points destroyed by magic (all spells) | 69.6 | 30.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.1 / 0.6 / 0.9 / 0.1 | 2.0 / 0.4 / 0.5 / 0.1 |
| Combat | Points destroyed in combat | 358.3 | 423.2 |
| Combat | Points run down | 34.5 | 120.2 |
| Combat | Net points per charged fight, damage counted | +82 | +105 |
| Combat | Net per 100 charger points, damage counted | +28.4 | +35.2 |
| Combat | First round won (charged fights) | 76% | 64% |
| Combat | Net points per charged fight | +75 | +103 |
| Combat | Net points per supported fight / lone fight | -19 / +93 | +205 / +82 |
| Combat | Charged fights on a top-3 enemy unit | 20 of 83 | 58 of 149 |
| Game | Points lost | 865.1 | 693.6 |
| Game | VP from objectives | 522.2 | 615.0 |
| Game | Lone holders (player turns) | 2.4 | 2.8 |

- Mine won / drew / lost: 12 / 7 / 17 of 36 ended games (of 36); mean margin (Mine - Opponent) -287 VP
- The side that went first won 15 of 29 games with a winner
- Points traded per game (both sides' losses): 1559
- Games not ended: 0; findings 0, warnings 1

### Opponent rules: tk-h2h-opp-949ddcd-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +5.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 35.6 | 0.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.9 | +4.8 | 0.0 | 33.0 | 1.0 | +12.2 | 0.0 | 34.9 |
| BEST FACING | 0.6 | +23.1 | 0.0 | 37.8 | 0.4 | +15.2 | 0.0 | 22.9 |
| BEST FIRST | 4.9 | +211.6 | 144.5 | 151.8 | 3.8 | +169.3 | 128.2 | 43.6 |
| BEST MOVE FOR SHOOTERS | - | - | - | - | 1.0 | +108.0 | 0.0 | 27.6 |
| BEST OVERALL | 0.7 | +43.5 | 0.0 | 39.1 | 0.3 | +11.1 | 0.0 | 19.8 |
| BEST PREY | 0.8 | +51.5 | 22.1 | 9.8 | 0.8 | +37.4 | 28.3 | 23.6 |
| BEST PRIZE | - | - | - | - | 0.1 | +7.0 | 8.0 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | +0.2 | 0.0 | 0.0 | 0.1 | -0.3 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | - | - | - | - | 0.1 | +0.0 | 8.9 | 0.0 |
| BLOCKED WHEEL | 0.6 | +5.9 | 0.0 | 1.4 | 0.5 | +4.7 | 0.0 | 0.0 |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 6.9 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 113.1 | 18.6 | 0.3 | +0.0 | 42.8 | 0.0 |
| CANNON PLANNED TARGET | 4.6 | +106.4 | 276.2 | 103.2 | 1.8 | +100.6 | 133.9 | 21.7 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 7.7 |
| CARRIES OUT COUNTER | 0.1 | -1.4 | 0.0 | 4.8 | 0.1 | +0.0 | 7.1 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.2 | -1.3 | 50.6 | 0.0 |
| CAST JOB | 0.4 | +11.4 | 56.0 | 15.1 | 0.2 | +3.5 | 7.4 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +29.0 | 13.7 | 0.0 | 0.2 | +8.8 | 23.6 | 4.4 |
| CASTS AFTER FRIENDS | 0.4 | +0.0 | 0.0 | 49.3 | 0.4 | +0.0 | 0.0 | 18.9 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +2.2 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | - | - | - | - | 0.0 | +2.5 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.5 | 0.0 | 13.1 | 0.1 | -1.0 | 0.0 | 3.2 |
| CHARGE NOW FIRST | 2.2 | +0.0 | 229.1 | 74.8 | 3.6 | +0.0 | 424.1 | 126.6 |
| CHARGE NOW WEIGHED | 0.6 | -57.7 | 3.5 | 24.8 | 0.5 | -54.5 | 24.9 | 18.4 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 2.4 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.6 | 0.0 | 15.0 | - | - | - | - |
| CHEAP HELPER | - | - | - | - | 0.2 | +0.0 | 15.0 | 3.9 |
| COMBAT PIVOT | 0.4 | +0.0 | 49.2 | 2.9 | 0.7 | +0.0 | 98.7 | 32.1 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.2 | +42.4 | 0.0 | 0.0 | 0.5 | +58.4 | 0.0 | 18.9 |
| COUNTER-CHARGE COVER | 9.8 | +800.5 | 0.0 | 282.0 | 6.2 | +511.7 | 0.0 | 139.7 |
| DEFENSIVE ARMY | 0.3 | +0.0 | 13.9 | 8.0 | 0.1 | +0.0 | 27.1 | 2.9 |
| EDGE GIVE GROUND | 0.1 | +3.3 | 8.8 | 0.0 | 0.4 | +9.7 | 47.3 | 0.9 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACE THE CAST | - | - | - | - | 0.0 | +0.6 | 0.0 | 0.0 |
| FACES THE THREAT | 1.8 | +140.4 | 0.0 | 101.5 | 1.1 | +71.7 | 0.0 | 48.8 |
| FALLBACK BY WORTH | 4.4 | +64.4 | 0.0 | 52.5 | 5.2 | +51.3 | 0.0 | 32.4 |
| FIGHT LIFT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.1 | +1.1 | 1.2 | 1.7 | 0.1 | +1.4 | 11.1 | 3.1 |
| FLANK NOT WEIGHED | 6.3 | +0.0 | 0.0 | 179.2 | 4.4 | +0.0 | 0.0 | 151.6 |
| FOCUS OVER TURNS | - | - | - | - | 0.6 | +12.4 | 29.7 | 2.9 |
| FOLLOW UP WEIGHED | 1.1 | +165.5 | 0.0 | 66.8 | 1.1 | +207.1 | 0.0 | 57.1 |
| FRIENDS SHOTS CHECKED | 0.2 | +15.8 | 0.0 | 15.3 | 0.2 | +18.1 | 0.0 | 7.8 |
| GIVES UP | 0.1 | -0.8 | 6.5 | 10.2 | 0.2 | -3.0 | 9.2 | 0.0 |
| GIVES UP ITS SCREEN | 0.1 | -0.3 | 8.5 | 0.0 | 0.0 | -0.4 | 5.5 | 0.0 |
| GROUND FLIERS | 0.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 10.7 | 0.0 |
| HELPER UNSEEN | 0.1 | +0.0 | 32.8 | 4.0 | 0.4 | +0.0 | 60.2 | 7.2 |
| HILL BY ITS CHANCE | 0.5 | -41.0 | 0.0 | 5.1 | 0.5 | -64.1 | 0.0 | 3.8 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 14.0 |
| HUNT ADVANCE | 0.1 | +1.1 | 0.0 | 2.9 | 0.3 | +2.3 | 28.5 | 8.9 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 0.9 | 0.1 | +0.0 | 2.4 | 5.8 |
| HUNT IN PAIRS | 0.3 | +14.5 | 0.0 | 0.0 | 0.4 | +10.4 | 0.0 | 5.4 |
| HUNT KEPT | 0.1 | +0.9 | 10.8 | 2.9 | 0.2 | +2.3 | 30.0 | 0.0 |
| HUNT RESULT | 0.1 | +5.9 | 0.0 | 0.9 | 0.4 | +70.6 | 21.1 | 10.8 |
| HUNT THE GUNS | 0.1 | +29.8 | 0.0 | 2.9 | 0.4 | +168.2 | 62.5 | 10.9 |
| INVITES THE FIGHT | 1.4 | +21.1 | 38.9 | 19.8 | 1.1 | +21.3 | 34.2 | 24.6 |
| JOINT CHARGE PLAN | 0.1 | +2.8 | 0.0 | 0.0 | 0.1 | +8.0 | 8.0 | 6.0 |
| KEEP FALLS | 0.1 | +4.6 | 0.0 | 7.5 | - | - | - | - |
| KEEPS ITS PREY | 0.1 | +0.8 | 0.0 | 2.4 | 0.1 | +0.1 | 5.2 | 5.8 |
| KEEPS ITS TARGET | 1.2 | +37.5 | 101.9 | 49.2 | 2.7 | +80.8 | 300.5 | 89.0 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 1.8 | +60.7 | 155.7 | 54.7 | 2.6 | +104.2 | 203.0 | 63.0 |
| KILLS COUNT NEXT TURN | 4.3 | +154.1 | 109.4 | 90.8 | 7.9 | +287.3 | 339.9 | 108.8 |
| LONE CHARACTER SAFE SPOT | 0.3 | +13.4 | 21.7 | 22.4 | 0.1 | +0.4 | 0.0 | 0.0 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 3.3 | 5.4 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +23.5 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | -3.0 | 16.4 | 4.8 | 0.6 | +1.0 | 22.6 | 3.5 |
| LOST CHARGE | 3.0 | -47.1 | 79.5 | 139.9 | 2.2 | -49.6 | 74.9 | 52.4 |
| LURE BY WHAT IT DRAWS | 0.0 | -3.4 | 0.0 | 1.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.3 | +8.8 | 9.6 | 9.5 | 0.9 | +51.0 | 10.9 | 36.5 |
| MANOEUVRE | 0.2 | +1.0 | 0.0 | 4.8 | 0.2 | +8.3 | 0.0 | 8.6 |
| MARCH AT ESCAPER | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.5 | +21.1 | 0.0 | 44.9 | 0.4 | +18.5 | 0.0 | 3.2 |
| MARCH ODDS | 0.2 | +21.2 | 5.8 | 2.2 | 0.2 | +37.3 | 4.6 | 0.0 |
| MARCH OVER CASTS | 0.5 | +63.1 | 0.0 | 30.0 | 0.2 | +11.2 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.8 | +152.8 | 0.0 | 167.3 | 4.4 | +168.4 | 0.0 | 80.1 |
| MISSILES IN THE MOVE | 3.1 | +87.6 | 0.0 | 170.2 | 2.9 | +64.9 | 0.0 | 78.8 |
| MISSILES IN THE PLAN | - | - | - | - | 0.4 | +4.0 | 20.7 | 0.0 |
| MISSILES NEXT TURN | 3.7 | +56.2 | 0.0 | 191.1 | 3.2 | +53.2 | 0.0 | 92.7 |
| MODEL FACING | 0.3 | +52.3 | 0.0 | 5.0 | 0.2 | +38.7 | 0.0 | 1.7 |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 0.0 | 10.2 | 0.2 | +0.0 | 24.1 | 0.0 |
| MOVE AND CAST | 0.2 | +7.8 | 0.0 | 2.4 | 0.1 | +4.0 | 0.0 | 7.2 |
| MOVE SPELL IN RANGE | 0.2 | +8.5 | 0.0 | 32.2 | - | - | - | - |
| MOVE SPELL NOT WORTH | - | - | - | - | 0.0 | -0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.2 | -12.8 | 1.8 | 12.5 | 0.1 | -1.5 | 0.0 | 6.5 |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 22.2 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 2.2 | +106.2 | 53.6 | 90.9 | 5.1 | +331.6 | 236.7 | 87.8 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.1 | +5.1 | 0.0 | 0.0 | 0.1 | +10.5 | 7.0 | 0.0 |
| NO RALLY LEFT | 0.0 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.2 | -15.0 | 25.2 | 12.2 | 0.6 | -45.4 | 105.4 | 1.2 |
| NOT TURNED | 6.3 | +113.1 | 0.0 | 156.5 | 4.9 | +80.3 | 0.0 | 115.7 |
| NOT WORTH A CAST | 0.4 | -0.2 | 0.0 | 12.1 | 0.7 | -0.7 | 0.0 | 7.6 |
| OFF BEST | 14.9 | -680.7 | 12.9 | 331.0 | 14.9 | -838.6 | 10.0 | 230.2 |
| OPENS A LANE | 0.1 | +0.4 | 39.2 | 0.0 | 0.0 | +0.1 | 2.4 | 0.0 |
| OPENS UP | 0.2 | +16.4 | 18.3 | 0.0 | 0.4 | +30.9 | 23.5 | 12.9 |
| OVERRUNS AWAY | 0.5 | +6.3 | 65.3 | 19.1 | 0.6 | +6.2 | 49.9 | 60.9 |
| PATHS CROSS | 1.9 | +146.9 | 0.0 | 57.0 | 2.6 | +177.5 | 0.0 | 26.6 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +1.4 | 0.0 | 15.0 |
| PIVOT GUARDS FLANK | 0.1 | -2.8 | 0.0 | 2.7 | - | - | - | - |
| PLAN RESULT | 35.7 | +1352.3 | 1389.5 | 1080.8 | 40.9 | +1422.8 | 1695.2 | 887.9 |
| PURSUES BIG PREY | 0.1 | -2.9 | 0.0 | 0.0 | 0.2 | -14.5 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +8.3 | 0.0 | 3.4 | 0.1 | +4.9 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.9 | +11.3 | 0.0 | 15.3 | 1.4 | +29.2 | 0.0 | 43.3 |
| RANDOM MOVER NO PROMISE | 0.3 | -31.7 | 0.0 | 4.7 | 0.4 | -25.2 | 39.2 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.1 | +1.4 | 0.0 | 0.0 | 0.3 | -7.6 | 0.0 | 3.0 |
| REDIRECT COUNTER | 2.2 | +149.6 | 0.0 | 54.8 | 3.9 | +329.3 | 0.0 | 57.8 |
| REDIRECT WEIGHED | 0.1 | +0.0 | 0.0 | 1.4 | 0.4 | +15.6 | 11.7 | 13.7 |
| RESERVE FALL BACK | 0.4 | +10.3 | 0.0 | 2.0 | 0.9 | +18.9 | 0.0 | 4.4 |
| RESTRAINS TO SHOOT | 0.0 | +2.3 | 0.0 | 0.0 | 0.1 | +1.7 | 0.0 | 0.0 |
| RISK BY ARC | 2.2 | +85.3 | 193.1 | 86.4 | 3.6 | +68.8 | 397.4 | 107.3 |
| SAFER THAN THE JOB | 1.2 | +83.8 | 0.0 | 18.2 | 0.6 | +31.8 | 0.0 | 21.7 |
| SCOUT SPOT | 0.3 | +0.8 | 0.0 | 0.0 | 0.5 | +2.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -2.4 | 0.0 | 1.2 | 0.4 | -16.8 | 0.0 | 3.8 |
| SEARCH SPOT | 2.7 | +154.1 | 0.0 | 46.1 | 3.1 | +134.7 | 0.0 | 39.6 |
| SECOND HUNTER | 0.0 | -0.0 | 0.0 | 0.0 | 0.1 | -0.5 | 26.8 | 0.9 |
| SELF MOVE SPELL | 0.2 | +21.6 | 0.0 | 31.0 | - | - | - | - |
| SET UP TOGETHER | 0.6 | +17.2 | 9.6 | 11.7 | 1.9 | +126.3 | 48.1 | 48.6 |
| SET-UP ANY TARGET | 0.1 | +8.9 | 0.0 | 0.0 | 0.1 | +7.8 | 0.0 | 11.2 |
| SET-UP MISSED | - | - | - | - | 0.0 | +0.6 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.0 | -0.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.9 | +30.9 | 24.9 | 18.2 | 0.4 | +14.3 | 11.6 | 10.9 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT OPTIONS | 14.5 | +0.0 | 487.3 | 296.5 | 12.7 | +0.0 | 469.8 | 182.8 |
| SHOT REPLANNED | 0.3 | +0.0 | 66.6 | 9.4 | 0.3 | +0.0 | 56.0 | 0.0 |
| SHOTS IN THE MOVE | 13.1 | +484.8 | 0.0 | 270.0 | 12.1 | +373.4 | 0.0 | 164.2 |
| SPELL CATCH ODDS | 0.0 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.2 | +44.0 | 0.0 | 0.0 | 0.2 | +47.6 | 0.0 | 11.2 |
| SPELL WORTH | 0.9 | +18.8 | 56.0 | 63.9 | 1.7 | +27.5 | 71.1 | 71.1 |
| STABLE ROLE | 11.0 | +0.0 | 358.6 | 195.1 | 12.4 | +0.0 | 496.9 | 113.7 |
| STANDS TO CAST | 0.1 | +1.7 | 0.0 | 2.2 | 0.1 | +3.9 | 0.0 | 3.2 |
| STAY WEIGHED | - | - | - | - | 0.1 | +5.2 | 0.0 | 0.0 |
| STAY WORTH | - | - | - | - | 15.5 | +277.6 | 301.2 | 140.9 |
| STOPS | 0.1 | +0.6 | 5.4 | 1.4 | 0.2 | +7.8 | 49.6 | 2.1 |
| STOPS SHORT OF THE FLANK | 0.6 | +21.9 | 0.0 | 33.8 | 0.3 | +14.2 | 0.0 | 16.8 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 8.8 |
| SUPPORT NARROWED | 6.4 | -47.8 | 471.8 | 140.9 | 7.4 | -57.1 | 507.9 | 138.9 |
| SUPPORTS | 4.4 | +47.8 | 286.1 | 61.9 | 4.4 | +59.4 | 202.3 | 72.4 |
| SURE CHARGE BEATS ADVANCE | - | - | - | - | 0.1 | -8.5 | 20.1 | 0.0 |
| SURE REACH TOGETHER | 0.3 | -3.4 | 9.6 | 1.7 | 0.8 | +10.6 | 0.0 | 12.5 |
| THREAT IN THE KILL | - | - | - | - | 8.3 | +100.0 | 456.4 | 131.5 |
| THREAT OVER THE TURNS | - | - | - | - | 6.9 | +65.8 | 361.0 | 131.5 |
| THREAT TO WORN DOWN | - | - | - | - | 8.1 | +90.8 | 456.4 | 131.5 |
| THROUGH LINE OF FIRE | 0.2 | +7.7 | 0.0 | 0.0 | 0.2 | +6.5 | 0.0 | 0.0 |
| TURN WORTH | 0.5 | -35.5 | 49.4 | 1.4 | 0.5 | -38.2 | 41.8 | 16.1 |
| TWO OR MORE ARRIVE | 0.1 | +0.6 | 9.6 | 0.0 | 0.6 | +2.1 | 19.5 | 6.0 |
| WAIT AFTER COSTS | 5.3 | -206.5 | 144.1 | 138.0 | 8.6 | -410.9 | 384.2 | 127.2 |
| WALKS TO THE FIGHT | 1.6 | +30.3 | 51.3 | 34.7 | 1.6 | +27.1 | 55.9 | 10.4 |
| WAR ENGINE CHARGES | 0.1 | +6.1 | 16.1 | 2.1 | 0.0 | +0.5 | 0.9 | 0.0 |
| WAR ENGINE JOBS | 0.5 | +0.0 | 45.8 | 7.2 | 0.2 | +0.0 | 36.5 | 5.1 |
| WEARS DOWN | 0.8 | +39.2 | 104.9 | 43.2 | 2.1 | +57.7 | 317.2 | 73.4 |
| WHO HITS BACK | 0.2 | +16.8 | 0.0 | 10.2 | 0.1 | +13.9 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.1 | +1.9 | 21.2 | 0.0 | 0.6 | +21.6 | 86.8 | 13.2 |
| WHOLE FIGHT GAIN | 0.2 | +19.1 | 25.7 | 10.5 | 0.8 | +60.9 | 66.1 | 16.7 |
| WOUNDED STAYS OUT | 0.1 | +0.0 | 7.2 | 1.7 | - | - | - | - |

### Rule changes: tk-h2h-opp-949ddcd-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1072 | 1072 | 1072 | 29.78 | -54697 | -51.0 |
| BEST FIRST | 311 | 311 | 311 | 8.64 | +13717 | +44.1 |
| SEARCH SPOT | 209 | 209 | 208 | 5.78 | +10406 | +50.0 |
| PATHS CROSS | 160 | 160 | 160 | 4.44 | +11679 | +73.0 |
| COUNTER-CHARGE COVER | 574 | 329 | 134 | 3.72 | +8610 | +64.3 |
| KILLS COUNT NEXT TURN | 440 | 440 | 129 | 3.58 | +4268 | +33.1 |
| MOVE TO CHARGE | 264 | 264 | 127 | 3.53 | +4585 | +36.1 |
| SUPPORTS | 320 | 320 | 117 | 3.25 | +1080 | +9.2 |
| FACES THE THREAT | 106 | 106 | 106 | 2.94 | +7638 | +72.1 |
| FOLLOW UP WEIGHED | 80 | 80 | 80 | 2.22 | +13413 | +167.7 |
| FALLBACK BY WORTH | 345 | 345 | 72 | 2.00 | +4166 | +57.9 |
| WAIT AFTER COSTS | 500 | 500 | 71 | 1.97 | +1224 | +17.2 |
| CANNON SIGHT KEPT | 70 | 70 | 70 | 1.94 | +0 | +0.0 |
| SAFER THAN THE JOB | 63 | 63 | 63 | 1.75 | +4160 | +66.0 |
| WALKS TO THE FIGHT | 113 | 113 | 62 | 1.72 | +678 | +10.9 |
| SHOTS IN THE MOVE | 907 | 577 | 61 | 1.69 | +1608 | +26.4 |
| ARTILLERY RE-ROLL WEIGHED | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| REDIRECT COUNTER | 222 | 124 | 49 | 1.36 | +3292 | +67.2 |
| RANDOM MOVE BY FIGURES | 84 | 84 | 48 | 1.33 | +1460 | +30.4 |
| RESERVE FALL BACK | 45 | 45 | 45 | 1.25 | +1048 | +23.3 |
| ADVANCE LANE KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| RISK BY ARC | 209 | 206 | 42 | 1.17 | +1256 | +29.9 |
| BLOCKED WHEEL | 41 | 41 | 41 | 1.14 | +381 | +9.3 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| COMBAT PIVOT | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| MAX FOR POSITIONING | 332 | 200 | 39 | 1.08 | +362 | +9.3 |
| CHARGE NOW FIRST | 208 | 208 | 38 | 1.06 | -2189 | -57.6 |
| CHARGE NOW WEIGHED | 37 | 37 | 37 | 1.03 | +4901 | +132.4 |
| BEST OVERALL | 36 | 36 | 36 | 1.00 | +1965 | +54.6 |
| KILLS COUNT | 160 | 159 | 36 | 1.00 | +899 | +25.0 |
| SET UP TOGETHER | 90 | 73 | 36 | 1.00 | +1935 | +53.7 |
| BEST MOVE FOR SHOOTERS | 35 | 35 | 35 | 0.97 | +3888 | +111.1 |
| CANNON PLANNED TARGET | 230 | 230 | 35 | 0.97 | -125 | -3.6 |
| BEST FACING | 34 | 34 | 34 | 0.94 | +1378 | +40.5 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2266 | +68.7 |
| STOPS SHORT OF THE FLANK | 33 | 33 | 33 | 0.92 | +1298 | +39.3 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| STAY WORTH | 557 | 425 | 32 | 0.89 | +722 | +22.6 |
| MARCH CHECK | 34 | 32 | 30 | 0.83 | +869 | +29.0 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +50 | +2.0 |
| KEEPS ITS TARGET | 142 | 141 | 24 | 0.67 | +398 | +16.6 |
| MISSILES IN THE MOVE | 217 | 130 | 24 | 0.67 | +708 | +29.5 |
| SHOT REPLANNED | 23 | 23 | 23 | 0.64 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 49 | 49 | 20 | 0.56 | +672 | +33.6 |
| WHOLE FIGHT GAIN | 36 | 34 | 20 | 0.56 | +826 | +41.3 |
| INVITES THE FIGHT | 91 | 91 | 19 | 0.53 | +366 | +19.3 |
| MODEL FACING | 19 | 19 | 19 | 0.53 | +3276 | +172.4 |
| BEST PREY | 56 | 56 | 18 | 0.50 | +805 | +44.7 |
| REDIRECT WEIGHED | 18 | 18 | 18 | 0.50 | +292 | +16.2 |
| FRIENDS SHOTS CHECKED | 17 | 17 | 17 | 0.47 | +1220 | +71.8 |
| MARCH ODDS | 17 | 17 | 17 | 0.47 | +533 | +31.3 |
| CASTER AWAY FROM SCREEN | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| FOCUS OVER TURNS | 21 | 21 | 15 | 0.42 | +174 | +11.6 |
| THREAT TO WORN DOWN | 293 | 250 | 15 | 0.42 | +120 | +8.0 |
| THROUGH LINE OF FIRE | 15 | 15 | 15 | 0.42 | +511 | +34.1 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| CASTING BLOCK | 19 | 19 | 13 | 0.36 | +721 | +55.5 |
| WEARS DOWN | 103 | 100 | 13 | 0.36 | +284 | +21.9 |
| WHO HITS BACK | 13 | 13 | 13 | 0.36 | +824 | +63.3 |
| BIG CHARACTER SAFETY | 12 | 12 | 12 | 0.33 | -2 | -0.2 |
| OPENS UP | 21 | 21 | 12 | 0.33 | +524 | +43.7 |
| CHAFF PASSED | 11 | 11 | 11 | 0.31 | -52 | -4.8 |
| LOST CHARGE | 188 | 187 | 11 | 0.31 | +228 | +20.7 |
| MAKE SURE TOGETHER | 42 | 24 | 11 | 0.31 | +245 | +22.2 |
| MOVE AND CAST | 11 | 11 | 11 | 0.31 | +426 | +38.7 |
| STUCK PIVOT | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| CAST JOB | 21 | 21 | 10 | 0.28 | +240 | +24.0 |
| PURSUES BIG PREY | 10 | 10 | 10 | 0.28 | -627 | -62.7 |
| MANOEUVRE | 13 | 13 | 8 | 0.22 | +336 | +42.0 |
| SUPPORT NARROWED | 496 | 496 | 8 | 0.22 | -112 | -14.1 |
| THREAT IN THE KILL | 298 | 253 | 8 | 0.22 | +49 | +6.1 |
| FIRE AND FLEE | 6 | 6 | 6 | 0.17 | +90 | +15.0 |
| BEST PRIZE | 5 | 5 | 5 | 0.14 | -97 | -19.4 |
| NEEDED THERE | 6 | 6 | 5 | 0.14 | +0 | +0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 5 | 5 | 5 | 0.14 | +280 | +56.1 |
| STAY WEIGHED | 5 | 5 | 5 | 0.14 | +186 | +37.2 |
| SURE REACH TOGETHER | 42 | 27 | 5 | 0.14 | +68 | +13.7 |
| THREAT OVER THE TURNS | 247 | 216 | 5 | 0.14 | +13 | +2.6 |
| BOUND ASSAILMENT | 4 | 4 | 4 | 0.11 | +1 | +0.2 |
| HUNT IN PAIRS | 25 | 17 | 4 | 0.11 | +161 | +40.1 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| PIVOT GUARDS FLANK | 4 | 4 | 4 | 0.11 | -102 | -25.4 |
| STANDS TO CAST | 4 | 4 | 4 | 0.11 | -66 | -16.6 |
| SURE CHARGE BEATS ADVANCE | 4 | 4 | 4 | 0.11 | -305 | -76.3 |
| WAR ENGINE JOBS | 27 | 27 | 4 | 0.11 | -131 | -32.8 |
| JOINT CHARGE PLAN | 6 | 6 | 3 | 0.08 | +167 | +55.7 |
| RESTRAINS TO SHOOT | 3 | 3 | 3 | 0.08 | +146 | +48.8 |
| WHOLE FIGHT | 25 | 23 | 3 | 0.08 | +157 | +52.2 |
| BACKUP TARGETS | 68 | 33 | 2 | 0.06 | +3 | +1.4 |
| BLOCKED CHARGE SKIPPED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| CARRIES OUT SET-UP | 9 | 9 | 2 | 0.06 | -47 | -23.5 |
| EDGE GIVE GROUND | 16 | 16 | 2 | 0.06 | +31 | +15.5 |
| HUNT ADVANCE | 15 | 15 | 2 | 0.06 | +35 | +17.5 |
| KEEP FALLS | 2 | 2 | 2 | 0.06 | +205 | +102.5 |
| MISSILES NEXT TURN | 249 | 140 | 2 | 0.06 | +11 | +5.3 |
| MOVE SPELL IN RANGE | 6 | 4 | 2 | 0.06 | +31 | +15.4 |
| OVERRUNS AWAY | 40 | 40 | 2 | 0.06 | +32 | +16.2 |
| CARRIES OUT COUNTER | 6 | 6 | 1 | 0.03 | -52 | -51.6 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -19 | -19.3 |
| CHARIOT NO STATIC JOB | 1 | 1 | 1 | 0.03 | -55 | -54.8 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| DEFENSIVE ARMY | 15 | 15 | 1 | 0.03 | -69 | -68.7 |
| FACE THE CAST | 1 | 1 | 1 | 0.03 | +20 | +20.2 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +5 | +4.6 |
| LONG SHOT | 35 | 34 | 1 | 0.03 | -3 | -3.1 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +6 | +6.3 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +52 | +51.9 |
| REDIRECT BY WHAT IT STOPS | 15 | 15 | 1 | 0.03 | +43 | +42.9 |
| STOPS | 11 | 11 | 1 | 0.03 | +21 | +21.0 |
| WOUNDED STAYS OUT | 2 | 2 | 1 | 0.03 | -95 | -95.3 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 3 | 3 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 37 | 37 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 29 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 4 | 4 | 0 | 0.00 | - | - |
| CHEAP HELPER | 8 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 28 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 384 | not checked | - | - | - | - |
| GIVES UP | 9 | 8 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 3 | 3 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 19 | 18 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 36 | 36 | 0 | 0.00 | - | - |
| HUNT DROPPED | 7 | trace | - | - | - | - |
| HUNT KEPT | 11 | trace | - | - | - | - |
| HUNT RESULT | 20 | trace | - | - | - | - |
| HUNT THE GUNS | 21 | trace | - | - | - | - |
| KEEPS ITS PREY | 5 | 5 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 14 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 13 | 13 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 23 | 23 | 0 | 0.00 | - | - |
| MISSILES IN THE PLAN | 14 | 1 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 15 | 15 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 10 | trace | - | - | - | - |
| MOVE SPELL SPOT | 15 | not checked | - | - | - | - |
| NOT NEEDED | 29 | 27 | 0 | 0.00 | - | - |
| NOT TURNED | 405 | 405 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 39 | not checked | - | - | - | - |
| OPENS A LANE | 4 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 2757 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 23 | 23 | 0 | 0.00 | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 17 | 17 | 0 | 0.00 | - | - |
| SECOND HUNTER | 5 | 5 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 8 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 6 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOT OPTIONS | 977 | 977 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 13 | not checked | - | - | - | - |
| SPELL WORTH | 92 | not checked | - | - | - | - |
| STABLE ROLE | 843 | 840 | 0 | 0.00 | - | - |
| TURN WORTH | 37 | 37 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 25 | 19 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 3 | 3 | 0 | 0.00 | - | - |

### Off best figure: tk-h2h-opp-949ddcd-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.39 | 13.58 | 53.3 |
| FALLBACK | gate | 0.47 | 0.61 | 32.9 |
| TURN GATE | gate | 0.69 | 0.39 | 28.3 |
| CHARGE NOW FIRST | rule | 0.42 | 0.64 | 57.6 |
| PURSUES BIG PREY | rule | 0.11 | 0.17 | 62.7 |
| CANNON PLANNED TARGET | rule | 0.25 | - | 17.0 |
| SUPPORT NARROWED | rule | 0.14 | 0.08 | 14.1 |
| AFTERMATH BAND | gate | 0.11 | 0.08 | 2.3 |
| BLOCKED WHEEL | rule | 0.14 | 0.06 | 12.9 |
| PATHS CROSS | rule | 0.11 | 0.08 | 31.2 |
| BEST PRIZE | rule | - | 0.14 | 19.4 |
| BIG CHARACTER SAFETY | rule | 0.06 | 0.08 | 6.1 |
| CHAFF PASSED | rule | 0.11 | 0.03 | 10.4 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.08 | 16.2 |
| FIGHT ORDER BAND | gate | 0.06 | 0.08 | 1.5 |
| LONE CHARACTER SAFE SPOT | gate | 0.08 | 0.03 | 84.6 |
| PIVOT GUARDS FLANK | rule | 0.11 | - | 25.4 |
| STANDS TO CAST | rule | 0.06 | 0.06 | 16.6 |
| SUPPORT REQUEST | gate | 0.03 | 0.08 | 39.4 |
| SURE CHARGE BEATS ADVANCE | rule | - | 0.11 | 76.3 |
| WAR ENGINE JOBS | rule | 0.06 | 0.06 | 32.8 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.08 | - | 16.7 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.06 | 5.1 |
| CARRIES OUT SET-UP | rule | - | 0.06 | 23.5 |
| MARCH ODDS | rule | 0.03 | 0.03 | 9.3 |
| REDIRECT WEIGHED | rule | - | 0.06 | 33.8 |
| SAFER THAN THE JOB | rule | 0.03 | 0.03 | 7.6 |
| CARRIES OUT COUNTER | rule | 0.03 | - | 51.6 |
| CATCH ODDS | rule | - | 0.03 | 19.3 |
| CHARIOT NO STATIC JOB | rule | 0.03 | - | 54.8 |
| DEFENSIVE ARMY | rule | 0.03 | - | 68.7 |
| FOLLOW UP WEIGHED | rule | - | 0.03 | 2.9 |
| LONG SHOT | rule | - | 0.03 | 3.1 |
| THROUGH LINE OF FIRE | rule | 0.03 | - | 127.3 |
| WHO HITS BACK | rule | 0.03 | - | 3.7 |
| WOUNDED STAYS OUT | rule | 0.03 | - | 95.3 |

### Plans: tk-h2h-opp-949ddcd-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.2 | 18% | 437 | 373 | 85% |
| Mine | charge | 2.8 | 62% | 277 | 251 | 91% |
| Mine | close in | 3.2 | 22% | 162 | 86 | 53% |
| Mine | hold | 4.5 | 34% | 316 | 0 | 0% |
| Mine | join | 1.0 | 100% | 32 | 0 | 0% |
| Mine | shoot | 7.5 | 67% | 194 | 642 | 330% |
| Mine | support | 4.6 | 91% | 28 | 0 | 0% |
| Opponent | advance | 13.6 | 17% | 433 | 387 | 89% |
| Opponent | charge | 5.8 | 63% | 645 | 589 | 91% |
| Opponent | close in | 6.1 | 31% | 477 | 138 | 29% |
| Opponent | hold | 4.2 | 41% | 316 | 0 | 0% |
| Opponent | join | 0.8 | 93% | 35 | 0 | 0% |
| Opponent | shoot | 5.4 | 64% | 381 | 309 | 81% |
| Opponent | support | 5.0 | 89% | 54 | 0 | 0% |

### Packages: hunt the guns, tk-h2h-opp-949ddcd-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 5 | 0 | 20% | 20% | 0% | 4.0 | 214 | 43 | 20% | 29 |
| Opponent | 0.4 | 16 | 1 | 27% | 40% | 0% | 2.3 | 371 | 170 | 40% | 104 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.5 | 2 | 0 | 0% | 0% | 0% | - | 225 | 0 | 0% | 34 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 78 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 76 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 36 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 55 |
| High Elf Realms | 0.2 | 1 | 0 | 100% | 100% | 0% | 4.0 | 233 | 214 | 100% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 374 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.5 | 6 | 0 | 50% | 50% | 0% | 2.7 | 428 | 204 | 50% | 105 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 312 |
| Tomb Kings of Khemri | 1.6 | 8 | 0 | 12% | 38% | 0% | 2.0 | 254 | 165 | 38% | 14 |
| Vampire Counts | 0.2 | 2 | 0 | 0% | 0% | 0% | - | 431 | 0 | 0% | 0 |
| Warriors of Chaos | 0.2 | 2 | 1 | 0% | 0% | 0% | - | 490 | 0 | 0% | 70 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 71 |

### Battle groups: tk-h2h-opp-949ddcd-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.8 | 28% | 46% | 9% | 11% | 36% | 24% | 6% | 35% | 0% |
| Mine | REDIRECT COUNTER | 2.2 | 26% | 62% | 0% | - | 24% | 0% | 19% | 57% | 0% |
| Opponent | COUNTER-CHARGE COVER | 6.2 | 18% | 60% | 35% | 43% | 23% | 8% | 19% | 50% | 0% |
| Opponent | REDIRECT COUNTER | 3.9 | 23% | 62% | 16% | 20% | 15% | 4% | 26% | 52% | 4% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: tk-h2h-opp-949ddcd-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 0 (5) | 0 | 0 | 52 | 20% | 3.8 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | Chaff | 35 | 40 (35) | 4 | 36 | 67 | 43% | 2.6 | 36 (19) | 68 (7) | 27 (9) | 42 (24) | 33 (11) |
| Mine | Character | 123 | 56 (123) | 54 | 2 | 42 | 20% | 2.4 | 77 (36) | 58 (53) | 11 (10) | 71 (47) | 54 (52) |
| Mine | Clean-up | 20 | 35 (20) | 2 | 32 | 38 | 55% | 2.4 | 18 (5) | 35 (12) | 79 (3) | 74 (12) | 0 (8) |
| Mine | Fast | 1 | 40 (1) | 40 | 0 | 100 | 0% | 3.0 | - | 40 (1) | - | 40 (1) | - |
| Mine | Fast Hammer | 44 | 47 (44) | 29 | 18 | 54 | 27% | 2.7 | 38 (21) | 72 (16) | 23 (7) | 43 (27) | 53 (17) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 40 | 0% | 1.6 | - | 0 (3) | 0 (2) | 0 (5) | - |
| Mine | Hammer | 57 | 23 (57) | 13 | 10 | 50 | 14% | 2.8 | 14 (18) | 30 (29) | 20 (10) | 22 (38) | 24 (19) |
| Mine | Holder | 29 | 46 (29) | 3 | 43 | 35 | 34% | 3.1 | 40 (11) | 65 (12) | 9 (6) | 56 (19) | 27 (10) |
| Mine | Shooter | 44 | 75 (44) | 19 | 56 | 45 | 2% | 1.6 | 65 (7) | 86 (30) | 34 (7) | 112 (26) | 22 (18) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 50% | 5.0 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | War machine | 59 | 52 (59) | 52 | 0 | 54 | 2% | 1.3 | 25 (10) | 66 (37) | 24 (12) | 56 (10) | 52 (49) |
| Mine | Wizard | 22 | 23 (22) | 23 | 0 | 53 | 0% | 2.5 | 0 (5) | 69 (7) | 23 (4) | 48 (5) | 24 (11) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Chaff | 76 | 60 (76) | 27 | 33 | 43 | 39% | 2.7 | 53 (32) | 80 (19) | 50 (25) | 78 (54) | 19 (22) |
| Opponent | Character | 94 | 65 (94) | 65 | 0 | 40 | 18% | 2.6 | 68 (39) | 77 (41) | 41 (4) | 61 (58) | 85 (26) |
| Opponent | Clean-up | 21 | 40 (21) | 25 | 15 | 47 | 33% | 2.8 | 40 (9) | 40 (12) | - | 47 (15) | 25 (6) |
| Opponent | Early | 2 | 51 (2) | 51 | 0 | 0 | 0% | 4.0 | - | 0 (1) | 102 (1) | 0 (1) | 102 (1) |
| Opponent | Fast Hammer | 48 | 58 (48) | 48 | 11 | 31 | 17% | 2.6 | 39 (22) | 51 (16) | 116 (10) | 47 (28) | 78 (20) |
| Opponent | Fragile | 5 | 0 (5) | 0 | 0 | 80 | 20% | 2.8 | - | 0 (3) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | Hammer | 68 | 39 (68) | 33 | 5 | 41 | 25% | 2.7 | 43 (17) | 38 (40) | 36 (11) | 52 (42) | 17 (26) |
| Opponent | Holder | 35 | 83 (35) | 9 | 74 | 32 | 31% | 3.0 | 109 (6) | 114 (18) | 32 (7) | 124 (18) | 57 (13) |
| Opponent | Shooter | 33 | 48 (33) | 3 | 44 | 26 | 3% | 1.9 | 26 (8) | 57 (19) | 42 (6) | 71 (22) | 12 (11) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | 0 (2) | 0 (1) | - | - | 0 (3) |
| Opponent | War machine | 24 | 36 (24) | 36 | 0 | 29 | 8% | 1.6 | 22 (6) | 47 (14) | 21 (4) | 0 (3) | 42 (21) |
| Opponent | Wizard | 29 | 24 (29) | 24 | 0 | 33 | 7% | 1.4 | 0 (10) | 58 (9) | 0 (8) | 26 (11) | 23 (16) |

### Charged fights: tk-h2h-opp-949ddcd-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 112 | 46 | 0.8 | 1.0 | 61 | 0 | +61 | 0 of 3 | 0 of 3 | - | +61 |
| Mine | Chaos Dwarfs | 4 | 195 | 408 | 1.8 | 1.0 | 233 | 0 | +233 | 6 of 7 | 6 of 7 | - | +233 |
| Mine | Dwarfen Mountain Holds | 4 | 465 | 44 | 1.2 | 1.2 | 36 | 0 | +36 | 0 of 5 | 5 of 5 | +0 | +44 |
| Mine | Empire of Man | 5 | 426 | 31 | 0.6 | 1.3 | 52 | 408 | -356 | 1 of 3 | 2 of 3 | -960 | -54 |
| Mine | Grand Cathay | 4 | 268 | 151 | 3.5 | 1.1 | 43 | 0 | +43 | 2 of 14 | 12 of 14 | +114 | +31 |
| Mine | High Elf Realms | 4 | 148 | 391 | 3.2 | 1.1 | 120 | 53 | +67 | 4 of 13 | 9 of 13 | +60 | +68 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 1334 | 5.0 | 1.0 | 267 | 16 | +251 | 2 of 5 | 4 of 5 | - | +251 |
| Mine | Lizardmen | 1 | 45 | 1023 | 3.0 | 1.0 | 341 | 0 | +341 | 1 of 3 | 1 of 3 | - | +341 |
| Mine | Ogre Kingdoms | 1 | 0 | 75 | 6.0 | 1.3 | 12 | 0 | +12 | 0 of 6 | 2 of 2 | +0 | +19 |
| Mine | Orc & Goblin Tribes | 1 | 50 | 105 | 3.0 | 1.3 | 35 | 0 | +35 | 0 of 3 | 2 of 3 | +45 | +30 |
| Mine | Skaven | 2 | 143 | 0 | 1.0 | 1.0 | 0 | 46 | -46 | 0 of 2 | 1 of 2 | - | -46 |
| Mine | Tomb Kings of Khemri | 1 | 0 | 542 | 3.0 | 2.0 | 181 | 0 | +181 | 1 of 3 | 3 of 3 | +271 | +0 |
| Mine | Vampire Counts | 3 | 57 | 492 | 4.7 | 1.3 | 106 | 28 | +77 | 3 of 14 | 12 of 14 | -53 | +113 |
| Mine | Warriors of Chaos | 1 | 19 | 342 | 2.0 | 1.0 | 171 | 240 | -68 | 0 of 2 | 1 of 2 | - | -68 |
| **Mine** | all armies | 36 | 207 | 256 | 2.3 | 1.2 | 111 | 36 | +75 | 20 of 83 | 60 of 79 | -19 | +93 |
| Opponent | Dwarfen Mountain Holds | 2 | 190 | 40 | 2.5 | 1.2 | 16 | 21 | -5 | 1 of 5 | 2 of 5 | -105 | +20 |
| Opponent | Empire of Man | 2 | 488 | 370 | 2.5 | 1.6 | 148 | 69 | +79 | 1 of 5 | 4 of 5 | +144 | -17 |
| Opponent | Grand Cathay | 2 | 334 | 906 | 3.5 | 1.7 | 259 | 60 | +198 | 4 of 7 | 6 of 7 | +383 | +60 |
| Opponent | Kingdom of Bretonnia | 1 | 340 | 628 | 4.0 | 1.2 | 157 | 0 | +157 | 2 of 4 | 2 of 4 | +95 | +178 |
| Opponent | Ogre Kingdoms | 3 | 61 | 316 | 3.0 | 1.3 | 105 | 0 | +105 | 3 of 9 | 5 of 9 | +123 | +96 |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 34 | 1072 | 5.8 | 1.3 | 186 | 52 | +134 | 9 of 23 | 12 of 23 | +233 | +113 |
| Opponent | Vampire Counts | 6 | 57 | 869 | 5.5 | 1.2 | 158 | 40 | +118 | 14 of 33 | 20 of 33 | +190 | +108 |
| Opponent | Warriors of Chaos | 8 | 7 | 431 | 3.5 | 1.1 | 123 | 5 | +118 | 12 of 28 | 20 of 28 | +100 | +120 |
| Opponent | Wood Elf Realms | 7 | 78 | 587 | 5.0 | 1.1 | 117 | 70 | +47 | 12 of 35 | 25 of 35 | +325 | +11 |
| **Opponent** | all armies | 36 | 101 | 591 | 4.1 | 1.2 | 143 | 40 | +103 | 58 of 149 | 96 of 149 | +205 | +82 |

### Effective charges: tk-h2h-opp-949ddcd-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 0 | 0 | 0 | 2 (net +55) | 0 | 1 (net +72) | 0 | 0% (0 of 3) |
| Mine | Chaos Dwarfs | 7 | 2 (net +233) | 0 | 0 | 5 (net +233) | 0 | 0 | 0 | 0% (0 of 7) |
| Mine | Dwarfen Mountain Holds | 5 | 0 | 0 | 0 | 3 (net +46) | 0 | 2 (net +20) | 0 | 0% (0 of 5) |
| Mine | Empire of Man | 3 | 0 | 0 | 1 (net -265) | 0 | 1 (net -960) | 1 (net +157) | 0 | 33% (1 of 3) |
| Mine | Grand Cathay | 14 | 0 | 0 | 1 (net +0) | 3 (net +13) | 4 (net +67) | 6 (net +49) | 0 | 7% (1 of 14) |
| Mine | High Elf Realms | 13 | 1 (net -143) | 0 | 2 (net -72) | 4 (net +150) | 4 (net +103) | 1 (net +144) | 1 | 17% (2 of 12) |
| Mine | Kingdom of Bretonnia | 5 | 0 | 0 | 2 (net +542) | 1 (net +0) | 0 | 1 (net +0) | 1 | 50% (2 of 4) |
| Mine | Lizardmen | 3 | 2 (net +486) | 0 | 0 | 0 | 1 (net +50) | 0 | 0 | 0% (0 of 3) |
| Mine | Ogre Kingdoms | 6 | 0 | 0 | 0 | 3 (net +0) | 0 | 2 (net +38) | 1 | 0% (0 of 5) |
| Mine | Orc & Goblin Tribes | 3 | 0 | 0 | 1 (net +45) | 0 | 0 | 0 | 2 | 100% (1 of 1) |
| Mine | Skaven | 2 | 0 | 0 | 0 | 1 (net -92) | 0 | 1 (net +0) | 0 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 3 | 0 | 0 | 0 | 0 | 2 (net +216) | 1 (net +110) | 0 | 0% (0 of 3) |
| Mine | Vampire Counts | 14 | 3 (net +155) | 0 | 1 (net +0) | 2 (net +102) | 5 (net +155) | 3 (net -121) | 0 | 7% (1 of 14) |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net -68) | 0 | 0% (0 of 2) |
| Opponent | Dwarfen Mountain Holds | 5 | 2 (net -52) | 0 | 1 (net +81) | 1 (net +0) | 0 | 1 (net +0) | 0 | 20% (1 of 5) |
| Opponent | Empire of Man | 5 | 0 | 0 | 1 (net -34) | 2 (net +115) | 2 (net +100) | 0 | 0 | 20% (1 of 5) |
| Opponent | Grand Cathay | 7 | 1 (net +210) | 0 | 1 (net +95) | 2 (net +540) | 2 (net +104) | 0 | 1 | 17% (1 of 6) |
| Opponent | Kingdom of Bretonnia | 4 | 1 (net +313) | 2 (net +110) | 0 | 0 | 1 (net +95) | 0 | 0 | 0% (0 of 4) |
| Opponent | Ogre Kingdoms | 9 | 2 (net +228) | 0 | 1 (net +0) | 0 | 0 | 5 (net +98) | 1 | 12% (1 of 8) |
| Opponent | Tomb Kings of Khemri | 23 | 4 (net -32) | 0 | 5 (net +222) | 2 (net +42) | 1 (net +91) | 11 (net +175) | 0 | 22% (5 of 23) |
| Opponent | Vampire Counts | 33 | 7 (net -92) | 1 (net -54) | 10 (net +228) | 9 (net +83) | 2 (net +56) | 4 (net +364) | 0 | 30% (10 of 33) |
| Opponent | Warriors of Chaos | 28 | 3 (net +62) | 0 | 7 (net +51) | 2 (net +158) | 3 (net +0) | 13 (net +188) | 0 | 25% (7 of 28) |
| Opponent | Wood Elf Realms | 35 | 4 (net -150) | 1 (net -31) | 6 (net +64) | 8 (net +48) | 2 (net +493) | 11 (net +134) | 3 | 19% (6 of 32) |

### Charged fights, damage counted: tk-h2h-opp-949ddcd-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 8 | 243 | 274 | +220 | 280 | 34 | +246 | +101.3 |
| Mine | Effective (55-75%) | 8 | 306 | 220 | +90 | 170 | 61 | +110 | +35.8 |
| Mine | 76-89% | 24 | 213 | 179 | +90 | 114 | 28 | +86 | +40.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 21 | 217 | 121 | +19 | 68 | 52 | +16 | +7.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 17 | 495 | 106 | +58 | 145 | 78 | +67 | +13.6 |
| Mine | No odds | 5 | 273 | 186 | +46 | 75 | 0 | +75 | +27.6 |
| Mine | All fights | 83 | 287 | 163 | +75 | 128 | 46 | +82 | +28.4 |
| Opponent | Long shot (under 50%) | 24 | 250 | 251 | -13 | 148 | 168 | -20 | -8.1 |
| Opponent | 50-54% | 4 | 182 | 139 | +34 | 87 | 56 | +31 | +16.7 |
| Opponent | Effective (55-75%) | 32 | 304 | 223 | +134 | 209 | 54 | +155 | +50.8 |
| Opponent | 76-89% | 26 | 288 | 172 | +109 | 117 | 18 | +99 | +34.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 45 | 288 | 204 | +173 | 202 | 30 | +171 | +59.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 13 | 535 | 112 | +130 | 145 | 14 | +131 | +24.5 |
| Opponent | No odds | 5 | 98 | 253 | -228 | 37 | 228 | -192 | -196.1 |
| Opponent | All fights | 149 | 298 | 202 | +103 | 166 | 61 | +105 | +35.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| tk-h2h-opp-949ddcd-p2 | move | 452 | 108 (24%) | 78 (17%) | 74 (16%) | 270 (60%) |
| tk-h2h-opp-949ddcd-p2 | objective | 338 | 71 (21%) | 55 (16%) | 49 (14%) | 218 (64%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

# Doctrine scorecard: tk-h2h-mine-949ddcd-p2b

### Scorecard: tk-h2h-mine-949ddcd-p2b

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1323 | 3 | 1 | Mine | yes | 4 | 2 | 2 | 1 | 0 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 2 | 2 | 1 | 1 | 0 | 0 | 305 |
| L1435 | 1 | 1 | Mine | no | 0 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 0 | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 1 | 4 | 3 | 0 | 3 | 0 | 0 | 0 |
| L1629 | 3 | 1 | Mine | no | 1 | 1 | 3 | 2 | 0 | 0 | 0 | 536 |
| L1629 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 255 |
| L1727 | 5 | 1 | Mine | yes | - | 3 | 1 | 1 | 0 | 0 | 0 | 135 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 5 | 3 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 297 |
| L1827 | 3 | 1 | Opponent | no | 8 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 1 | 1 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 3 | 1 | 0 | 0 | 0 |
| L2029 | 1 | 1 | Mine | no | 2 | - | 1 | 2 | 0 | 0 | 0 | 715 |
| L2029 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 170 |
| L2131 | 1 | 1 | Mine | yes | 3 | 6 | 2 | 2 | 0 | 0 | 0 | 290 |
| L2131 | 1 | 1 | Opponent | no | 3 | 3 | 4 | 1 | 1 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | yes | 1 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 0 | 3 | 6 | 2 | 0 | 0 | 0 | 126 |
| L2429 | 5 | 1 | Mine | yes | - | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 4 | 1 | 1 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Mine | no | 8 | 3 | 1 | 0 | 0 | 0 | 0 | 168 |
| L2535 | 3 | 1 | Opponent | no | 0 | 1 | 6 | 0 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | no | - | 5 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 1 | 3 | 3 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 6 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 0 | 1 | 7 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 43% | 2.4 | 2.7 | 2.3 | 1.1 | 0.1 | 0.0 | 0.0 | 152.1 |
| **Average** | | | Opponent | 21% | 1.1 | 2.1 | 4.1 | 1.4 | 0.5 | 0.0 | 0.0 | 68.4 |

### KPIs: tk-h2h-mine-949ddcd-p2b

Rules off - Opponent only: STAY WORTH, BEST MOVE FOR SHOOTERS, THREAT IN THE KILL, FOCUS OVER TURNS, MISSILES IN THE PLAN, FACE THE CAST, WIZARD FRONT RANK, THREAT OVER THE TURNS, THREAT TO WORN DOWN.

Morten 2026-11-10; 15 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 9% (7 of 79) | 8% (6 of 79) | 8% (13 of 158) |
| Winner chose to follow up after the loser gave ground |  | 97% (29 of 30); on the table 97% | 100% (28 of 28); on the table 100% | 98% (57 of 58); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (9 of 9); on the table 100% | 60% (3 of 5); on the table 100% | 86% (12 of 14); on the table 100% |
| Winner chose to pursue after the loser fled |  | 70% (14 of 20); on the table 75% | 78% (7 of 9); on the table 89% | 72% (21 of 29); on the table 79% |
| Winner chose to follow up or pursue (all three) |  | 88% (52 of 59); on the table 90% | 90% (38 of 42); on the table 98% | 89% (90 of 101); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 32% (25 of 78) | 50% (21 of 42) | 38% (46 of 120) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 50% (25 of 50) | 58% (21 of 36) | 53% (46 of 86) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 19% (9 of 48) | 33% (2 of 6) | 20% (11 of 54) |
|     round 1 |  | 25% (2 of 8) | 0% (0 of 1) | 22% (2 of 9) |
|     rounds 2+ |  | 18% (7 of 40) | 40% (2 of 5) | 20% (9 of 45) |
|   other wizards | 50%+ | 53% (16 of 30) | 53% (19 of 36) | 53% (35 of 66) |
|     round 1 |  | 20% (1 of 5) | 33% (2 of 6) | 27% (3 of 11) |
|     rounds 2+ |  | 60% (15 of 25) | 57% (17 of 30) | 58% (32 of 55) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 45% (10 of 22) | 36% (9 of 25) | 40% (19 of 47) |
| Points that never fought | lower | 24% (7224 of 29995) | 31% (9384 of 29997) | 28% (16608 of 59992) |
|   infantry points that never fought | lower | 42% (2405 of 5703) | 49% (2943 of 6031) | 46% (5348 of 11734) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 53% (57 of 107) | 60% (80 of 133) | 57% (137 of 240) |
| Bound items with a magic missile used (at least once a game) |  | 100% (5 of 5); 1.3 uses a game | 78% (7 of 9); 1.4 uses a game | 86% (12 of 14); 1.3 uses a game |
| Bound items with another spell used |  | 50% (7 of 14); 0.8 uses a game | 0.0 uses a game | 50% (7 of 14); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 40% (2 of 5); 0.1 uses a game | 0% (0 of 1); 0.0 uses a game | 33% (2 of 6); 0.1 uses a game |
|   their share of the points of units over 100 pts | lower | 50% (12872 of 25820) | 54% (14754 of 27383) | 52% (27626 of 53203) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.5 (15%) | 0.7 (48%) | 1.2 (24%) |
| MARCHED: its unit marched | 0.7 (19%) | 0.3 (19%) | 0.9 (19%) |
| CHARGED: its unit charged | 0.1 (2%) | 0.1 (5%) | 0.1 (3%) |
| IN COMBAT: engaged in combat | 0.6 (17%) | 0.1 (10%) | 0.7 (15%) |
| REAR RANK: in a rear rank | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 0.8 (23%) | 0.3 (19%) | 1.1 (22%) |
| OFF THE TABLE: off the table or not arrived | 0.5 (13%) | 0.0 (0%) | 0.5 (9%) |
| STUPIDITY: Stupidity | 0.1 (4%) | 0.0 (0%) | 0.1 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (4%) | 0.0 (0%) | 0.1 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.9 | 1.9 | 1.7 | 3.1 | 0.3 | 1.7 |
| not cast | 5.7 | 2.8 | 3.9 | 4.9 | 1.7 | 23.9 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 1.1 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (48%) | 0.1 (2%) | 1.2 (24%) | 0.7 (42%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.9 (19%) | 0.3 (19%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (1%) | 0.1 (2%) | 0.2 (5%) | 0.7 (15%) | 0.0 (0%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.0 (0%) | 0.2 (5%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.3 (5%) | 0.2 (7%) | 0.2 (5%) | 0.0 (0%) | 0.0 (0%) | 0.9 (4%) |
| GONE: slain | 1.8 (32%) | 0.8 (29%) | 1.1 (27%) | 1.1 (22%) | 0.1 (4%) | 5.3 (22%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (7%) | 0.0 (0%) | 0.2 (5%) | 0.5 (9%) | 0.2 (12%) | 0.5 (2%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.4 (14%) | 0.0 (0%) | 0.1 (1%) | 0.4 (23%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.9 (51%) | 0.0 (0%) | 1.9 (49%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.3 (64%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.8 a game | 0.9 a game | 0.8 a game |
| stood (cast and not dispelled) | 67% (6 of 9) | 69% (9 of 13) | 68% (15 of 22) |
| the unit moved after it | 83% (5 of 6) | 33% (3 of 9) | 53% (8 of 15) |
| it charged on its next turn | 0% (0 of 6) | 0% (0 of 9) | 0% (0 of 15) |
| the enemy charged it first | 50% (3 of 6) | 11% (1 of 9) | 27% (4 of 15) |
| it fought by the end of its next turn | 17% (1 of 6) | 11% (1 of 9) | 13% (2 of 15) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 6) | 11% (1 of 9) | 7% (1 of 15) |
| none of these (no charge, no fight, no charge escaped) | 50% (3 of 6) | 78% (7 of 9) | 67% (10 of 15) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (166 of 274) | 55% (134 of 243) | 58% (300 of 517) |
|   cavalry | 79% (26 of 33) | 60% (53 of 88) | 65% (79 of 121) |
|   character | 22% (10 of 46) | 12% (5 of 43) | 17% (15 of 89) |
|   chariot | 72% (18 of 25) | 75% (6 of 8) | 73% (24 of 33) |
|   infantry | 71% (84 of 118) | 68% (65 of 95) | 70% (149 of 213) |
|   monster | 29% (8 of 28) | 56% (5 of 9) | 35% (13 of 37) |
|   war machine | 83% (20 of 24) | - | 83% (20 of 24) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.9 (13%) | 1.9 (26%) | 2.8 (19%) |
| CHARGED: it charged | 1.1 (16%) | 1.8 (25%) | 2.9 (20%) |
| IN COMBAT: it fought this turn or the last | 0.9 (13%) | 0.5 (6%) | 1.4 (10%) |
| NO TARGET IN RANGE | 2.6 (36%) | 1.1 (15%) | 3.7 (25%) |
| ONLY IN COMBAT: the only targets were in combat | 0.2 (3%) | 0.6 (8%) | 0.8 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (19%) | 1.5 (20%) | 2.8 (19%) |
| OTHER BAR | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 8.1 | 1.1 | 88% | 2.5 pts | 20 pts |
| character | 1.3 | 0.4 | 85% | 16.0 pts | 21 pts |
| chariot | 1.6 | 0.1 | 96% | 2.0 pts | 3 pts |
| infantry | 13.4 | 5.3 | 73% | 9.0 pts | 120 pts |
| monster | 0.9 | 0.2 | 86% | 3.2 pts | 3 pts |
| war machine | 1.3 | 0.7 | 75% | 13.2 pts | 18 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.0 | 8.0 | 6.5 |
| Charges that made contact a game | 3.9 | 4.9 | 4.4 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.60 declared, 0.50 contact (10 units) | 0.50 declared, 0.00 contact (4 units) | 0.57 declared, 0.36 contact (14 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.33 declared, 0.33 contact (6 units) | 1.71 declared, 1.00 contact (7 units) | 1.08 declared, 0.69 contact (13 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.57 declared, 0.44 contact (117 units) | 0.83 declared, 0.53 contact (127 units) | 0.71 declared, 0.49 contact (244 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 63% (27 of 43) | 75% (9 of 12) | 80% (4 of 5) | 67% (40 of 60) |
| Character in a unit | 75% (3 of 4) | 0% (0 of 5) | 0% (0 of 1) | 30% (3 of 10) |
| Character on its own | 74% (17 of 23) | 77% (10 of 13) | 31% (11 of 36) | 53% (38 of 72) |
| Chariot | 57% (4 of 7) | - | - | 57% (4 of 7) |
| Infantry | 64% (28 of 44) | 67% (8 of 12) | - | 64% (36 of 56) |
| Monster | 57% (8 of 14) | 33% (2 of 6) | - | 50% (10 of 20) |
| Monstrous | 22% (2 of 9) | 67% (4 of 6) | - | 40% (6 of 15) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 4 | 85% (17 of 20); on the table 90% | 6% (1 of 18) | 25% | 58% (19 of 33) | 100% (3 of 3); 3.5 uses a game | 50% (7 of 14); 3.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (4 of 4); on the table 100% | - | 39% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | 100% (2 of 2); on the table 100% | - | 46% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 24% | 79% (11 of 14) | 100% (2 of 2); 1.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (1 of 1); on the table 100% | 17% (2 of 12) | 3% | 25% (2 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 2 | 86% (6 of 7); on the table 86% | 33% (4 of 12) | 35% | 50% (8 of 16) | 100% (1 of 1); 1.5 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Tomb Kings of Khemri | 2 | 83% (5 of 6); on the table 83% | - | 52% | 40% (4 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 6 | 93% (28 of 30); on the table 97% | 54% (26 of 48) | 22% | 62% (23 of 37) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 6 | 80% (16 of 20); on the table 90% | 33% (2 of 6) | 24% | 55% (28 of 51) | 100% (2 of 2); 1.5 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
| Wood Elf Realms | 5 | 100% (10 of 10); on the table 100% | 61% (11 of 18) | 30% | 62% (36 of 58) | 67% (4 of 6); 2.2 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (tk-h2h-mine-949ddcd-p2b, 15 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 58% (21) | 49% (17) | 54% (38) |
| ...free all their last turn and able to turn (per game) | 1.07 | 0.80 | 1.87 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.07 | 0.27 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.87 | 0.40 | 1.27 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.00 | 1.60 | 3.60 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.80 | 0.93 | 1.73 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 8.40 | 6.40 | 14.80 |

### Quality by phase: tk-h2h-mine-949ddcd-p2b

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 66% (44 of 67) | 42% (47 of 111) |
| Strategy | Shoot objectives carried out (shot that target) | 64% (47 of 73) | 33% (24 of 73) |
| Strategy | Close-in objectives charged next turn | 15% (11 of 74) | 20% (18 of 88) |
| Strategy | Support requests answered (helper made contact too) | 40% (2 of 5) | 70% (7 of 10) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 50% (4 of 8) | 88% (7 of 8) |
| Strategy | Joined characters whose unit fought | 60% (3 of 5) | 27% (3 of 11) |
| Strategy | Lone characters that fought | 78% (36 of 46) | 78% (31 of 40) |
| Movement | Charges halted short of contact | 0.1 | 0.3 |
| Movement | Idle units | 1.1 | 1.4 |
| Movement | Points that never moved of their own | 152.1 | 68.4 |
| Movement | Fights charged into per game | 3.3 | 4.1 |
| Movement | Charges with odds: long shots (under 50%) | 7 of 48, net +34 | 7 of 58, net +252 |
| Movement | Charges with odds: sweet spot (55-75%) | 4 of 48, net +164 | 7 of 58, net +48 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 8 of 48, net +112 | 5 of 58, net +105 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 18 of 48, net +106 | 24 of 58, net +118 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.1 | 10.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 28% (47 of 166) | 52% (78 of 151) |
| Shooting | Points destroyed by shooting units | 48.7 | 14.9 |
| Shooting | War machine shots | 1.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 80% (16 of 20) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.1 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 24% (4 of 17) | 35% (6 of 17) |
| Magic | Wounds caused by magic missiles | 1.5 | 2.5 |
| Magic | Wounds caused by other spells | 2.9 | 0.6 |
| Magic | Points destroyed by magic (all spells) | 61.6 | 39.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.7 / 0.9 / 0.5 / 0.1 | 1.2 / 0.5 / 0.6 / 0.1 |
| Combat | Points destroyed in combat | 391.1 | 498.5 |
| Combat | Points run down | 63.9 | 106.6 |
| Combat | Net points per charged fight, damage counted | +97 | +129 |
| Combat | Net per 100 charger points, damage counted | +33.6 | +51.9 |
| Combat | First round won (charged fights) | 80% | 69% |
| Combat | Net points per charged fight | +87 | +131 |
| Combat | Net points per supported fight / lone fight | +116 / +82 | +194 / +115 |
| Combat | Charged fights on a top-3 enemy unit | 12 of 50 | 18 of 62 |
| Game | Points lost | 886.5 | 647.4 |
| Game | VP from objectives | 561.3 | 522.0 |
| Game | Lone holders (player turns) | 2.4 | 1.1 |

- Mine won / drew / lost: 9 / 0 / 6 of 15 ended games (of 15); mean margin (Mine - Opponent) -185 VP
- The side that went first won 7 of 15 games with a winner
- Points traded per game (both sides' losses): 1534
- Games not ended: 0; findings 0, warnings 1

### Opponent rules: tk-h2h-mine-949ddcd-p2b

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 0.0 | 0.0 |
| ARRIVAL HUNT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.7 | +10.1 | 0.0 | 51.9 | 1.2 | +13.7 | 0.0 | 8.4 |
| BEST FACING | 0.6 | +24.2 | 0.0 | 15.7 | 0.7 | +10.1 | 0.0 | 15.1 |
| BEST FIRST | 5.7 | +234.9 | 83.7 | 108.3 | 4.9 | +237.6 | 338.3 | 94.7 |
| BEST MOVE FOR SHOOTERS | 0.8 | +18.5 | 0.0 | 8.2 | - | - | - | - |
| BEST OVERALL | 0.6 | +30.0 | 0.0 | 21.8 | 0.8 | +29.1 | 0.0 | 27.8 |
| BEST PREY | 1.0 | +87.1 | 7.2 | 15.1 | 0.9 | +31.6 | 76.6 | 0.0 |
| BEST PRIZE | 0.1 | -1.9 | 0.0 | 0.0 | - | - | - | - |
| BIG CHARACTER SAFETY | 0.1 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 14.8 | - | - | - | - |
| BLOCKED WHEEL | 0.3 | +0.1 | 0.0 | 0.0 | 0.7 | +11.1 | 0.0 | 0.0 |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 0.9 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 8.1 | 0.0 | 0.2 | -1.4 | 14.8 | 0.0 |
| CAST JOB | 0.3 | +11.4 | 30.4 | 40.0 | 0.3 | +3.2 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.1 | +4.1 | 0.0 | 0.0 | 0.3 | +14.0 | 41.7 | 0.0 |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 26.7 | 0.4 | +0.0 | 0.0 | 18.3 |
| CASTS FROM BEHIND | 0.3 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CHAFF PASSED | 0.1 | -0.1 | 0.0 | 0.0 | 0.1 | -0.1 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 3.1 | +0.0 | 270.2 | 115.6 | 3.5 | +0.0 | 424.7 | 31.0 |
| CHARGE NOW WEIGHED | 0.5 | -21.2 | 12.1 | 6.0 | 0.5 | -13.1 | 33.2 | 16.1 |
| CHARIOT WIZARD CAREFUL | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 18.3 | 14.0 | 0.5 | +0.0 | 17.0 | 0.0 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.2 | +20.5 | 0.0 | 0.0 | 0.9 | +103.0 | 10.5 | 45.3 |
| COUNTER-CHARGE COVER | 11.1 | +788.3 | 0.0 | 334.0 | 7.3 | +652.5 | 0.0 | 186.7 |
| DEFENSIVE ARMY | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.2 | +7.3 | 16.2 | 3.0 | 0.1 | +1.0 | 20.7 | 4.0 |
| FACES THE THREAT | 2.0 | +191.7 | 0.0 | 59.3 | 1.6 | +118.5 | 0.0 | 25.6 |
| FALLBACK BY WORTH | 5.7 | +56.1 | 0.0 | 143.6 | 6.3 | +59.5 | 0.0 | 50.7 |
| FLANK NOT WEIGHED | 7.3 | +0.0 | 0.0 | 322.3 | 6.5 | +0.0 | 0.0 | 125.8 |
| FOCUS OVER TURNS | 0.7 | +32.0 | 19.6 | 11.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 1.4 | +199.9 | 0.0 | 120.3 | 1.8 | +243.4 | 0.0 | 55.5 |
| FRIENDS SHOTS CHECKED | 0.1 | +0.2 | 0.0 | 0.0 | 0.3 | +13.2 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.3 | -6.8 | 23.1 | 0.0 |
| GIVES UP ITS SCREEN | 0.1 | -0.5 | 0.0 | 7.7 | 0.2 | -0.2 | 10.1 | 0.0 |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 7.6 | 0.0 | - | - | - | - |
| HELPER UNSEEN | 0.1 | +0.0 | 0.0 | 7.7 | 0.3 | +0.0 | 32.3 | 0.0 |
| HILL BY ITS CHANCE | 0.3 | -22.1 | 0.0 | 0.0 | 0.2 | -6.2 | 0.0 | 5.1 |
| HOLDS AMBUSHERS | 0.5 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.1 | +0.3 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.3 | +0.8 | 0.0 | 11.7 | 0.3 | +0.3 | 26.7 | 0.0 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 2.3 | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 0.1 | +4.7 | 0.0 | 0.0 |
| HUNT KEPT | 0.3 | +1.2 | 0.0 | 11.7 | 0.1 | +0.1 | 0.0 | 0.0 |
| HUNT RESULT | 0.3 | +0.0 | 0.0 | 2.3 | 0.2 | +60.3 | 0.0 | 0.0 |
| HUNT THE GUNS | 0.3 | +55.7 | 0.0 | 11.7 | 0.2 | +67.2 | 53.3 | 0.0 |
| INVITES THE FIGHT | 1.7 | +35.6 | 36.4 | 32.7 | 1.2 | +22.9 | 62.5 | 0.0 |
| JOINT CHARGE PLAN | - | - | - | - | 0.1 | +5.4 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS TARGET | 2.2 | +66.0 | 185.3 | 79.0 | 2.4 | +72.0 | 270.1 | 21.6 |
| KILLS COUNT | 2.5 | +94.9 | 181.8 | 57.5 | 3.7 | +183.7 | 303.1 | 61.1 |
| KILLS COUNT NEXT TURN | 6.2 | +181.9 | 163.4 | 128.7 | 7.5 | +280.2 | 303.2 | 140.1 |
| LONE CHARACTER SAFE SPOT | 0.2 | +37.3 | 4.0 | 0.0 | 0.3 | +21.8 | 10.1 | 0.0 |
| LONE WIZARD HOLDS BACK | 0.2 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 15.4 | 38.3 |
| LONE WIZARD KEPT IN | 0.3 | +13.0 | 0.0 | 0.0 | 0.1 | +6.0 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | +4.8 | 7.6 | 4.3 | 1.0 | +14.1 | 44.6 | 2.7 |
| LOST CHARGE | 2.2 | -32.6 | 32.6 | 140.0 | 3.2 | -64.8 | 93.5 | 64.5 |
| LURE BY WHAT IT DRAWS | 0.1 | -2.3 | 0.0 | 0.0 | 0.3 | -25.1 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.3 | +6.5 | 16.3 | 38.6 | 0.3 | +26.5 | 19.8 | 0.0 |
| MANOEUVRE | 0.2 | +2.4 | 0.0 | 6.5 | 0.5 | +2.0 | 0.0 | 8.3 |
| MARCH AT ESCAPER | - | - | - | - | 0.1 | +1.4 | 0.0 | 0.0 |
| MARCH CHECK | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +27.1 | 0.0 | 32.5 |
| MARCH ODDS | 0.2 | +29.3 | 15.5 | 0.0 | 0.1 | +0.8 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.6 | +139.9 | 0.0 | 0.0 | 0.3 | +21.7 | 0.0 | 7.7 |
| MAX FOR POSITIONING | 6.8 | +284.2 | 0.0 | 163.1 | 5.4 | +230.3 | 0.0 | 133.1 |
| MISSILES IN THE MOVE | 2.9 | +68.1 | 0.0 | 161.7 | 2.9 | +46.4 | 0.0 | 66.2 |
| MISSILES IN THE PLAN | 0.1 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| MISSILES NEXT TURN | 3.5 | +41.9 | 0.0 | 161.8 | 3.3 | +34.4 | 0.0 | 84.5 |
| MONSTER WIZARD ROAMS | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.3 | +17.3 | 0.0 | 4.0 | 0.5 | +10.5 | 0.0 | 10.5 |
| MOVE SPELL OUT OF RANGE | 0.1 | -0.7 | 0.0 | 6.3 | 0.3 | -10.7 | 6.9 | 0.0 |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 26.7 | - | - | - | - |
| MOVE TO CHARGE | 3.9 | +200.2 | 88.8 | 163.5 | 3.8 | +255.6 | 180.6 | 60.7 |
| MOVES UNITS SPELL | 0.1 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.1 | +8.2 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.3 | -12.4 | 29.2 | 3.3 | 1.3 | -51.6 | 153.0 | 0.0 |
| NOT TURNED | 8.4 | +163.2 | 0.0 | 295.2 | 6.4 | +58.7 | 0.0 | 103.5 |
| NOT WORTH A CAST | 0.6 | -0.3 | 0.0 | 0.0 | 1.3 | -0.9 | 0.0 | 0.0 |
| OFF BEST | 12.9 | -553.4 | 0.0 | 316.8 | 15.4 | -844.5 | 0.0 | 212.7 |
| OPENS A LANE | 0.1 | +0.1 | 7.6 | 3.7 | 0.1 | +1.4 | 4.8 | 0.0 |
| OPENS UP | 0.4 | +46.0 | 15.0 | 0.0 | 0.2 | +14.4 | 9.7 | 0.0 |
| OVERRUNS AWAY | 0.7 | +10.1 | 118.9 | 49.6 | 0.9 | +17.9 | 120.0 | 9.6 |
| PATHS CROSS | 2.5 | +182.2 | 0.0 | 43.5 | 3.0 | +170.1 | 0.0 | 22.3 |
| PIVOT GUARDS FLANK | 0.3 | -5.9 | 0.0 | 4.8 | 0.1 | -3.6 | 0.0 | 0.0 |
| PLAN RESULT | 37.7 | +838.3 | 1371.5 | 1263.7 | 42.5 | +1369.1 | 1650.7 | 749.1 |
| PURSUES BIG PREY | 0.1 | -1.7 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE NEXT TURN | 0.2 | +19.9 | 0.0 | 16.4 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 1.5 | +40.0 | 0.0 | 9.7 | 1.7 | +23.0 | 0.0 | 79.3 |
| RANDOM MOVER NO PROMISE | 0.7 | -50.0 | 9.6 | 9.7 | 0.3 | -18.1 | 8.4 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -1.5 | 0.0 | 0.0 | 0.1 | -4.1 | 0.0 | 0.0 |
| REDIRECT COUNTER | 3.4 | +205.8 | 0.0 | 86.5 | 4.5 | +466.1 | 0.0 | 62.1 |
| REDIRECT WEIGHED | 0.1 | +0.2 | 0.0 | 0.0 | 0.6 | +24.2 | 28.1 | 22.3 |
| RESERVE FALL BACK | 0.6 | +18.7 | 0.0 | 19.4 | 1.0 | +66.6 | 0.0 | 21.1 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.2 | +3.6 | 0.0 | 0.0 |
| RISK BY ARC | 3.2 | +118.2 | 280.3 | 111.6 | 4.5 | +80.2 | 458.1 | 64.1 |
| SAFER THAN THE JOB | 0.8 | +51.4 | 0.0 | 18.0 | 0.9 | +74.2 | 0.0 | 16.1 |
| SCOUT SPOT | 0.3 | +0.2 | 0.0 | 0.0 | 0.3 | +0.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -3.6 | 0.0 | 0.0 | 0.3 | -16.4 | 0.0 | 0.0 |
| SEARCH SPOT | 4.8 | +197.9 | 0.0 | 77.1 | 3.5 | +107.8 | 0.0 | 47.5 |
| SECOND HUNTER | 0.1 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | 0.5 | +42.6 | 0.0 | 21.7 | - | - | - | - |
| SET UP TOGETHER | 0.5 | +12.6 | 16.3 | 38.6 | 0.7 | +38.6 | 19.8 | 0.0 |
| SET-UP ANY TARGET | 0.1 | +12.4 | 0.0 | 0.0 | 0.2 | +14.8 | 0.0 | 27.0 |
| SET-UP MISSED | - | - | - | - | 0.2 | +14.9 | 0.0 | 27.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.1 | -0.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.7 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.9 | +41.5 | 52.0 | 12.7 | 0.5 | +15.5 | 3.7 | 12.7 |
| SHOT OPTIONS | 11.5 | +0.0 | 217.5 | 284.0 | 9.5 | +0.0 | 250.9 | 126.5 |
| SHOT REPLANNED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOTS IN THE MOVE | 10.1 | +243.3 | 0.0 | 201.9 | 8.0 | +131.5 | 0.0 | 133.2 |
| SPELL SETS UP CHARGE | 0.1 | +12.4 | 0.0 | 0.0 | 0.2 | +14.8 | 0.0 | 27.0 |
| SPELL WORTH | 1.5 | +32.4 | 123.1 | 101.3 | 1.0 | +41.1 | 92.9 | 92.9 |
| STABLE ROLE | 9.8 | +0.0 | 317.8 | 254.6 | 13.8 | +0.0 | 473.3 | 132.8 |
| STANDS TO CAST | - | - | - | - | 0.1 | +3.8 | 0.0 | 10.5 |
| STAY WORTH | 9.7 | +95.2 | 46.3 | 190.7 | - | - | - | - |
| STOPS | 0.1 | +1.1 | 0.0 | 11.7 | 0.1 | +0.1 | 26.7 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.9 | +81.7 | 0.0 | 46.3 | 0.1 | +2.0 | 0.0 | 12.3 |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 22.7 |
| SUPPORT NARROWED | 9.1 | -65.4 | 521.8 | 178.4 | 10.3 | -73.5 | 534.1 | 82.9 |
| SUPPORTS | 6.5 | +71.8 | 329.2 | 71.9 | 6.6 | +73.5 | 246.0 | 39.9 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -4.2 | 18.8 | 0.0 | - | - | - | - |
| SURE REACH TOGETHER | 0.4 | -0.6 | 0.0 | 0.0 | 0.6 | +9.5 | 0.0 | 7.7 |
| THREAT IN THE KILL | 8.5 | +42.7 | 229.6 | 278.7 | - | - | - | - |
| THREAT OVER THE TURNS | 5.8 | +29.3 | 184.3 | 230.5 | - | - | - | - |
| THREAT TO WORN DOWN | 7.8 | +56.6 | 229.6 | 278.7 | - | - | - | - |
| THROUGH LINE OF FIRE | 0.3 | +39.7 | 0.0 | 22.9 | 0.1 | +0.0 | 0.0 | 0.0 |
| TURN WORTH | 0.6 | -39.3 | 49.5 | 23.1 | 0.5 | -25.6 | 41.4 | 0.0 |
| TWO OR MORE ARRIVE | 0.3 | +0.3 | 16.3 | 11.9 | 0.1 | +0.1 | 0.0 | 0.0 |
| WAIT AFTER COSTS | 7.2 | -325.0 | 125.2 | 215.3 | 8.1 | -319.5 | 302.7 | 120.1 |
| WALKS TO THE FIGHT | 1.2 | +20.9 | 0.0 | 9.0 | 2.4 | +40.3 | 46.9 | 40.7 |
| WAR ENGINE CHARGES | 0.1 | +2.7 | 0.0 | 0.0 | 0.1 | +1.1 | 0.0 | 5.0 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 65.8 | 24.7 | 0.1 | +0.0 | 0.0 | 12.3 |
| WEARS DOWN | 0.9 | +48.3 | 92.5 | 27.3 | 1.9 | +74.4 | 243.6 | 6.9 |
| WHO HITS BACK | 0.3 | +42.3 | 0.0 | 0.0 | 0.1 | +2.6 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.3 | +16.3 | 54.4 | 10.7 | 0.2 | -0.2 | 27.7 | 0.0 |
| WHOLE FIGHT GAIN | 0.4 | +32.2 | 23.5 | 26.9 | 0.3 | +44.7 | 48.8 | 0.0 |
| WOUNDED STAYS OUT | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |

### Rule changes: tk-h2h-mine-949ddcd-p2b

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 424 | 424 | 424 | 28.27 | -20968 | -49.5 |
| BEST FIRST | 158 | 158 | 158 | 10.53 | +7088 | +44.9 |
| SEARCH SPOT | 124 | 124 | 123 | 8.20 | +4612 | +37.5 |
| PATHS CROSS | 82 | 82 | 82 | 5.47 | +5285 | +64.5 |
| COUNTER-CHARGE COVER | 276 | 166 | 78 | 5.20 | +4826 | +61.9 |
| SUPPORTS | 197 | 197 | 75 | 5.00 | +542 | +7.2 |
| MOVE TO CHARGE | 115 | 115 | 58 | 3.87 | +2314 | +39.9 |
| FACES THE THREAT | 54 | 54 | 54 | 3.60 | +4652 | +86.2 |
| KILLS COUNT NEXT TURN | 206 | 206 | 53 | 3.53 | +1707 | +32.2 |
| FOLLOW UP WEIGHED | 48 | 48 | 48 | 3.20 | +6648 | +138.5 |
| FALLBACK BY WORTH | 180 | 180 | 38 | 2.53 | +1734 | +45.6 |
| WAIT AFTER COSTS | 230 | 230 | 36 | 2.40 | +774 | +21.5 |
| WALKS TO THE FIGHT | 54 | 54 | 31 | 2.07 | +337 | +10.9 |
| SHOTS IN THE MOVE | 272 | 177 | 28 | 1.87 | +238 | +8.5 |
| REDIRECT COUNTER | 119 | 67 | 27 | 1.80 | +1818 | +67.3 |
| SAFER THAN THE JOB | 26 | 26 | 26 | 1.73 | +1883 | +72.4 |
| MAX FOR POSITIONING | 183 | 115 | 24 | 1.60 | +427 | +17.8 |
| RESERVE FALL BACK | 24 | 24 | 24 | 1.60 | +1279 | +53.3 |
| CHARGE NOW FIRST | 99 | 99 | 23 | 1.53 | -2264 | -98.5 |
| RISK BY ARC | 115 | 114 | 23 | 1.53 | +957 | +41.6 |
| ADVANCE LANE KEPT | 22 | 22 | 22 | 1.47 | +0 | +0.0 |
| BEST OVERALL | 21 | 21 | 21 | 1.40 | +888 | +42.3 |
| HOLDS AMBUSHERS | 21 | 21 | 21 | 1.40 | +0 | +0.0 |
| KILLS COUNT | 93 | 93 | 21 | 1.40 | +1034 | +49.2 |
| BEST FACING | 20 | 20 | 20 | 1.33 | +515 | +25.8 |
| RANDOM MOVE BY FIGURES | 47 | 47 | 19 | 1.27 | +945 | +49.7 |
| BLOCKED WHEEL | 15 | 15 | 15 | 1.00 | +167 | +11.1 |
| CHARGE NOW WEIGHED | 15 | 15 | 15 | 1.00 | +689 | +45.9 |
| STOPS SHORT OF THE FLANK | 15 | 15 | 15 | 1.00 | +1255 | +83.7 |
| BEST MOVE FOR SHOOTERS | 12 | 12 | 12 | 0.80 | +278 | +23.2 |
| COMBAT PIVOT | 12 | 12 | 12 | 0.80 | +0 | +0.0 |
| CASTS FROM BEHIND | 11 | 11 | 11 | 0.73 | +0 | +0.0 |
| MISSILES IN THE MOVE | 87 | 56 | 11 | 0.73 | +165 | +15.0 |
| MOVE AND CAST | 11 | 11 | 11 | 0.73 | +418 | +38.0 |
| REDIRECT WEIGHED | 11 | 11 | 11 | 0.73 | +624 | +56.8 |
| STAY WORTH | 146 | 113 | 11 | 0.73 | +189 | +17.2 |
| THREAT TO WORN DOWN | 117 | 92 | 11 | 0.73 | +80 | +7.2 |
| SCOUT WAITS | 10 | 10 | 10 | 0.67 | +0 | +0.0 |
| KEEPS ITS TARGET | 69 | 68 | 9 | 0.60 | +177 | +19.7 |
| SHOOTERS IN TWO RANKS | 9 | 9 | 9 | 0.60 | +19 | +2.1 |
| FOCUS OVER TURNS | 11 | 11 | 8 | 0.53 | +229 | +28.6 |
| INVITES THE FIGHT | 44 | 44 | 8 | 0.53 | +122 | +15.3 |
| SHOOTS FROM THE BEST SPOT | 20 | 20 | 8 | 0.53 | +362 | +45.2 |
| THREAT IN THE KILL | 128 | 102 | 8 | 0.53 | +14 | +1.8 |
| WHOLE FIGHT GAIN | 11 | 10 | 8 | 0.53 | +581 | +72.6 |
| LOST CHARGE | 81 | 80 | 7 | 0.47 | +121 | +17.2 |
| MARCH CHECK | 7 | 7 | 7 | 0.47 | +255 | +36.4 |
| STUCK PIVOT | 7 | 7 | 7 | 0.47 | +0 | +0.0 |
| WHO HITS BACK | 7 | 7 | 7 | 0.47 | +361 | +51.6 |
| LONE WIZARD KEPT IN | 6 | 6 | 6 | 0.40 | +286 | +47.6 |
| MANOEUVRE | 10 | 10 | 6 | 0.40 | +66 | +11.0 |
| OPENS UP | 9 | 9 | 6 | 0.40 | +281 | +46.8 |
| PIVOT GUARDS FLANK | 6 | 6 | 6 | 0.40 | -142 | -23.7 |
| THROUGH LINE OF FIRE | 6 | 6 | 6 | 0.40 | +596 | +99.2 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 0.33 | +0 | +0.0 |
| CASTING BLOCK | 5 | 5 | 5 | 0.33 | +172 | +34.5 |
| FRIENDS SHOTS CHECKED | 5 | 5 | 5 | 0.33 | +202 | +40.3 |
| SET UP TOGETHER | 19 | 17 | 5 | 0.33 | +184 | +36.7 |
| BEST PREY | 29 | 29 | 4 | 0.27 | +154 | +38.6 |
| MARCH ODDS | 4 | 4 | 4 | 0.27 | +135 | +33.7 |
| SUPPORT NARROWED | 290 | 290 | 4 | 0.27 | -66 | -16.5 |
| THREAT OVER THE TURNS | 87 | 71 | 4 | 0.27 | +7 | +1.8 |
| WEARS DOWN | 41 | 39 | 4 | 0.27 | +236 | +59.1 |
| BACKUP TARGETS | 43 | 22 | 3 | 0.20 | +45 | +14.9 |
| CAST JOB | 10 | 10 | 3 | 0.20 | +29 | +9.8 |
| CASTER AWAY FROM SCREEN | 3 | 3 | 3 | 0.20 | +0 | +0.0 |
| CHAFF PASSED | 3 | 3 | 3 | 0.20 | -2 | -0.7 |
| OVERRUNS AWAY | 24 | 23 | 3 | 0.20 | +75 | +25.0 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 3 | 0.20 | +211 | +70.2 |
| RESTRAINS TO SHOOT | 3 | 3 | 3 | 0.20 | +54 | +18.0 |
| SURE CHARGE BEATS ADVANCE | 3 | 3 | 3 | 0.20 | -63 | -20.9 |
| SURE REACH TOGETHER | 15 | 11 | 3 | 0.20 | +27 | +9.1 |
| BEST PRIZE | 2 | 2 | 2 | 0.13 | -28 | -14.1 |
| BLOCKED CHARGE SKIPPED | 2 | 2 | 2 | 0.13 | +0 | +0.0 |
| DEFENSIVE ARMY | 8 | 8 | 2 | 0.13 | -22 | -11.2 |
| MOVES UNITS SPELL | 2 | 2 | 2 | 0.13 | +12 | +5.8 |
| PURSUES BIG PREY | 2 | 2 | 2 | 0.13 | -26 | -12.9 |
| SHOT REPLANNED | 2 | 2 | 2 | 0.13 | +0 | +0.0 |
| WAR ENGINE JOBS | 11 | 11 | 2 | 0.13 | -129 | -64.5 |
| WHOLE FIGHT | 7 | 7 | 2 | 0.13 | +258 | +129.2 |
| BIG CHARACTER SAFETY | 1 | 1 | 1 | 0.07 | -1 | -1.2 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.07 | +0 | +0.2 |
| CANNON PLANNED TARGET | 14 | 14 | 1 | 0.07 | +0 | +0.0 |
| CARRIES OUT SET-UP | 4 | 4 | 1 | 0.07 | -21 | -21.3 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.07 | +0 | +0.0 |
| EDGE GIVE GROUND | 5 | 5 | 1 | 0.07 | +16 | +15.8 |
| HORN WORTH | 1 | 1 | 1 | 0.07 | +5 | +4.6 |
| HUNT IN PAIRS | 2 | 2 | 1 | 0.07 | +20 | +20.2 |
| JOINT CHARGE PLAN | 2 | 2 | 1 | 0.07 | +62 | +62.3 |
| LONE WIZARD HOLDS BACK | 11 | 11 | 1 | 0.07 | -291 | -291.0 |
| LONG SHOT | 18 | 18 | 1 | 0.07 | +92 | +92.4 |
| MAKE SURE TOGETHER | 10 | 7 | 1 | 0.07 | +90 | +89.6 |
| MISSILES NEXT TURN | 102 | 56 | 1 | 0.07 | +0 | +0.0 |
| NEEDED THERE | 1 | 1 | 1 | 0.07 | +0 | +0.0 |
| STANDS TO CAST | 1 | 1 | 1 | 0.07 | +2 | +2.2 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.07 | -301 | -301.3 |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 15 | trace | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 1 | 1 | 0 | 0.00 | - | - |
| CHEAP HELPER | 2 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 16 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 207 | not checked | - | - | - | - |
| GIVES UP | 4 | 3 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 4 | 4 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 7 | 7 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 8 | 8 | 0 | 0.00 | - | - |
| HUNT ADVANCE | 9 | 9 | 0 | 0.00 | - | - |
| HUNT DROPPED | 3 | trace | - | - | - | - |
| HUNT KEPT | 6 | trace | - | - | - | - |
| HUNT RESULT | 7 | trace | - | - | - | - |
| HUNT THE GUNS | 7 | trace | - | - | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 7 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 14 | 14 | 0 | 0.00 | - | - |
| MISSILES IN THE PLAN | 1 | not checked | - | - | - | - |
| MONSTER WIZARD ROAMS | 1 | 1 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 7 | trace | - | - | - | - |
| MOVE SPELL SPOT | 5 | not checked | - | - | - | - |
| NOT NEEDED | 24 | 23 | 0 | 0.00 | - | - |
| NOT TURNED | 222 | 222 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 28 | not checked | - | - | - | - |
| OPENS A LANE | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 1202 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 16 | 16 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 3 | 3 | 0 | 0.00 | - | - |
| SCOUT SPOT | 8 | 8 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 8 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 4 | not checked | - | - | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOT OPTIONS | 314 | 314 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 4 | not checked | - | - | - | - |
| SPELL WORTH | 37 | not checked | - | - | - | - |
| STABLE ROLE | 354 | 352 | 0 | 0.00 | - | - |
| STOPS | 3 | 3 | 0 | 0.00 | - | - |
| TURN WORTH | 16 | 16 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 5 | 5 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: tk-h2h-mine-949ddcd-p2b

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 11.27 | 13.33 | 51.3 |
| FALLBACK | gate | 0.73 | 1.00 | 58.4 |
| CHARGE NOW FIRST | rule | 0.67 | 0.87 | 98.5 |
| TURN GATE | gate | 0.67 | 0.53 | 20.0 |
| PIVOT GUARDS FLANK | rule | 0.33 | 0.07 | 23.7 |
| LONE CHARACTER SAFE SPOT | gate | 0.07 | 0.27 | 25.6 |
| PATHS CROSS | rule | 0.20 | 0.13 | 14.2 |
| AFTERMATH BAND | gate | 0.07 | 0.20 | 2.8 |
| SUPPORT NARROWED | rule | 0.20 | 0.07 | 16.4 |
| SURE CHARGE BEATS ADVANCE | rule | 0.20 | - | 20.9 |
| BEST PRIZE | rule | 0.13 | - | 14.1 |
| BLOCKED WHEEL | rule | 0.07 | 0.07 | 18.7 |
| CHAFF PASSED | rule | 0.07 | 0.07 | 1.0 |
| CHARGE NOW WEIGHED | rule | - | 0.13 | 13.3 |
| DEFENSIVE ARMY | rule | 0.13 | - | 11.2 |
| PURSUES BIG PREY | rule | 0.13 | - | 12.9 |
| WAR ENGINE JOBS | rule | 0.07 | 0.07 | 64.5 |
| BIG CHARACTER SAFETY | rule | 0.07 | - | 1.2 |
| CARRIES OUT SET-UP | rule | - | 0.07 | 21.3 |
| FIGHT ORDER BAND | gate | 0.07 | - | 4.5 |
| LONE WIZARD HOLDS BACK | rule | 0.07 | - | 291.0 |
| MARCH ODDS | rule | - | 0.07 | 10.5 |
| RULE SWITCHED OFF | gate | - | 0.07 | 3.8 |
| STOPS SHORT OF THE FLANK | rule | 0.07 | - | 1.2 |
| THROUGH LINE OF FIRE | rule | 0.07 | - | 5.1 |
| WOUNDED STAYS OUT | rule | 0.07 | - | 301.3 |

### Plans: tk-h2h-mine-949ddcd-p2b

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 13.5 | 14% | 675 | 272 | 40% |
| Mine | charge | 3.7 | 61% | 375 | 303 | 81% |
| Mine | close in | 4.9 | 22% | 262 | 92 | 35% |
| Mine | hold | 4.0 | 27% | 221 | 0 | 0% |
| Mine | join | 0.6 | 100% | 24 | 0 | 0% |
| Mine | shoot | 4.2 | 52% | 157 | 172 | 110% |
| Mine | support | 6.7 | 92% | 51 | 0 | 0% |
| Opponent | advance | 15.2 | 19% | 435 | 493 | 113% |
| Opponent | charge | 6.2 | 58% | 627 | 573 | 91% |
| Opponent | close in | 5.9 | 31% | 390 | 136 | 35% |
| Opponent | hold | 2.9 | 23% | 161 | 0 | 0% |
| Opponent | join | 1.6 | 92% | 97 | 0 | 0% |
| Opponent | shoot | 3.8 | 39% | 79 | 167 | 210% |
| Opponent | support | 6.9 | 92% | 60 | 0 | 0% |

### Packages: hunt the guns, tk-h2h-mine-949ddcd-p2b

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.3 | 4 | 0 | 0% | 0% | 0% | - | 209 | 0 | 0% | 0 |
| Opponent | 0.2 | 3 | 0 | 33% | 67% | 0% | 2.0 | 336 | 301 | 67% | 0 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 0.5 | 2 | 0 | 0% | 0% | 0% | - | 223 | 0 | 0% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.0 | 2 | 0 | 0% | 0% | 0% | - | 194 | 0 | 0% | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 1.5 | 3 | 0 | 33% | 67% | 0% | 2.0 | 336 | 301 | 67% | 0 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: tk-h2h-mine-949ddcd-p2b

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 11.1 | 37% | 43% | 7% | 0% | 23% | 23% | 12% | 42% | 0% |
| Mine | REDIRECT COUNTER | 3.4 | 43% | 50% | 5% | 0% | 10% | 0% | 14% | 76% | 0% |
| Opponent | COUNTER-CHARGE COVER | 7.3 | 26% | 69% | 14% | 0% | 12% | 4% | 20% | 64% | 0% |
| Opponent | REDIRECT COUNTER | 4.5 | 29% | 70% | 25% | 20% | 20% | 0% | 7% | 73% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: tk-h2h-mine-949ddcd-p2b

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 0 (5) | 0 | 0 | 52 | 20% | 3.5 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | Chaff | 26 | 58 (26) | 20 | 38 | 72 | 31% | 2.6 | 79 (15) | 93 (4) | 6 (7) | 78 (19) | 6 (7) |
| Mine | Character | 41 | 51 (41) | 49 | 2 | 29 | 12% | 2.3 | 66 (23) | 33 (11) | - | 79 (16) | 34 (18) |
| Mine | Clean-up | 7 | 18 (7) | 6 | 12 | 70 | 29% | 2.6 | 36 (3) | 4 (3) | 0 (1) | 34 (3) | 10 (4) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 23 | 54 (23) | 32 | 23 | 70 | 26% | 2.6 | 14 (12) | 132 (9) | 30 (2) | 22 (11) | 82 (12) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 20 | 0% | 1.6 | - | 0 (3) | 0 (2) | 0 (5) | - |
| Mine | Hammer | 17 | 36 (17) | 26 | 10 | 61 | 12% | 2.4 | 22 (8) | 36 (8) | 179 (1) | 46 (11) | 20 (6) |
| Mine | Holder | 14 | 49 (14) | 3 | 46 | 36 | 29% | 3.7 | 92 (7) | 0 (4) | 28 (3) | 48 (10) | 51 (4) |
| Mine | Shooter | 17 | 46 (17) | 19 | 27 | 58 | 6% | 1.6 | 43 (5) | 53 (10) | 0 (2) | 82 (9) | 3 (8) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | War machine | 4 | 0 (4) | 0 | 0 | 0 | 0% | 1.2 | 0 (2) | 0 (2) | - | 0 (1) | 0 (3) |
| Mine | Wizard | 10 | 11 (10) | 11 | 0 | 72 | 20% | 1.8 | 0 (5) | - | 148 (1) | 0 (3) | 26 (3) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Chaff | 27 | 68 (27) | 38 | 30 | 38 | 37% | 2.7 | 116 (13) | 13 (4) | 31 (10) | 122 (15) | 8 (12) |
| Opponent | Character | 39 | 63 (39) | 63 | 0 | 25 | 23% | 2.5 | 83 (24) | 33 (10) | - | 80 (21) | 65 (13) |
| Opponent | Clean-up | 4 | 36 (4) | 36 | 0 | 0 | 25% | 3.0 | 44 (3) | 0 (1) | - | 75 (2) | 0 (2) |
| Opponent | Fast Hammer | 27 | 50 (27) | 41 | 8 | 35 | 19% | 2.6 | 45 (15) | 57 (7) | 56 (5) | 41 (14) | 60 (13) |
| Opponent | Hammer | 36 | 31 (36) | 30 | 1 | 41 | 28% | 3.2 | 24 (13) | 35 (19) | 27 (4) | 47 (19) | 18 (17) |
| Opponent | Holder | 15 | 44 (15) | 18 | 26 | 38 | 20% | 4.4 | 8 (3) | 59 (11) | 0 (1) | 49 (8) | 37 (7) |
| Opponent | Shooter | 15 | 25 (15) | 3 | 22 | 28 | 0% | 1.5 | 71 (5) | 7 (7) | 0 (3) | 45 (8) | 7 (7) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 50 | 50% | 6.0 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Opponent | Wizard | 12 | 18 (12) | 18 | 0 | 75 | 17% | 1.5 | 0 (5) | - | 33 (5) | 65 (4) | 0 (6) |

### Charged fights: tk-h2h-mine-949ddcd-p2b

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 4 | 218 | 533 | 4.5 | 1.1 | 118 | 42 | +76 | 7 of 18 | 14 of 18 | +492 | +52 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 617 | 4.0 | 1.2 | 154 | 66 | +88 | 0 of 4 | 4 of 4 | -59 | +137 |
| Mine | Lizardmen | 1 | 45 | 1027 | 3.0 | 1.3 | 342 | 0 | +342 | 1 of 3 | 1 of 3 | +54 | +486 |
| Mine | Ogre Kingdoms | 1 | 75 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 0 | - | +0 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 235 | 3.0 | 1.3 | 78 | 0 | +78 | 1 of 3 | 2 of 3 | +45 | +95 |
| Mine | Skaven | 2 | 215 | 130 | 2.5 | 1.0 | 52 | 0 | +52 | 0 of 5 | 4 of 5 | - | +52 |
| Mine | Tomb Kings of Khemri | 1 | 110 | 546 | 4.0 | 1.0 | 136 | 0 | +136 | 1 of 4 | 3 of 4 | - | +136 |
| Mine | Vampire Counts | 3 | 41 | 148 | 3.3 | 1.5 | 44 | 49 | -4 | 2 of 10 | 9 of 10 | +98 | -73 |
| Mine | Warriors of Chaos | 1 | 0 | 608 | 2.0 | 1.0 | 304 | 0 | +304 | 0 of 2 | 2 of 2 | - | +304 |
| **Mine** | all armies | 15 | 110 | 391 | 3.3 | 1.2 | 117 | 30 | +87 | 12 of 50 | 39 of 49 | +116 | +82 |
| Opponent | Ogre Kingdoms | 1 | 0 | 443 | 5.0 | 1.2 | 89 | 8 | +81 | 2 of 5 | 2 of 5 | +143 | +65 |
| Opponent | Tomb Kings of Khemri | 1 | 151 | 577 | 4.0 | 1.2 | 144 | 0 | +144 | 1 of 4 | 3 of 4 | +400 | +59 |
| Opponent | Vampire Counts | 3 | 0 | 1047 | 5.0 | 1.3 | 209 | 4 | +205 | 5 of 15 | 11 of 15 | +168 | +219 |
| Opponent | Warriors of Chaos | 5 | 68 | 320 | 2.6 | 1.0 | 123 | 13 | +110 | 4 of 13 | 8 of 13 | - | +110 |
| Opponent | Wood Elf Realms | 5 | 66 | 671 | 5.0 | 1.2 | 134 | 30 | +104 | 6 of 25 | 19 of 25 | +186 | +78 |
| **Opponent** | all armies | 15 | 55 | 608 | 4.1 | 1.2 | 147 | 17 | +131 | 18 of 62 | 43 of 62 | +194 | +115 |

### Effective charges: tk-h2h-mine-949ddcd-p2b

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 18 | 1 (net -294) | 2 (net -58) | 1 (net +405) | 1 (net +0) | 6 (net +128) | 6 (net +84) | 1 | 6% (1 of 17) |
| Mine | Kingdom of Bretonnia | 4 | 0 | 0 | 1 (net +205) | 1 (net +85) | 0 | 2 (net +32) | 0 | 25% (1 of 4) |
| Mine | Lizardmen | 3 | 2 (net +486) | 0 | 0 | 0 | 1 (net +54) | 0 | 0 | 0% (0 of 3) |
| Mine | Ogre Kingdoms | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Orc & Goblin Tribes | 3 | 0 | 0 | 1 (net +45) | 0 | 0 | 1 (net +190) | 1 | 50% (1 of 2) |
| Mine | Skaven | 5 | 1 (net +0) | 0 | 0 | 2 (net +130) | 0 | 2 (net +0) | 0 | 0% (0 of 5) |
| Mine | Tomb Kings of Khemri | 4 | 0 | 0 | 0 | 0 | 0 | 4 (net +136) | 0 | 0% (0 of 4) |
| Mine | Vampire Counts | 10 | 3 (net -146) | 1 (net +114) | 1 (net +0) | 3 (net +68) | 1 (net +75) | 1 (net +0) | 0 | 10% (1 of 10) |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +304) | 0 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 5 | 0 | 0 | 0 | 0 | 0 | 4 (net +101) | 1 | 0% (0 of 4) |
| Opponent | Tomb Kings of Khemri | 4 | 0 | 0 | 0 | 1 (net +0) | 0 | 2 (net +288) | 1 | 0% (0 of 3) |
| Opponent | Vampire Counts | 15 | 3 (net +373) | 1 (net +0) | 1 (net +55) | 6 (net +163) | 0 | 4 (net +233) | 0 | 7% (1 of 15) |
| Opponent | Warriors of Chaos | 13 | 1 (net +0) | 0 | 3 (net +43) | 2 (net +118) | 1 (net +80) | 6 (net +164) | 0 | 23% (3 of 13) |
| Opponent | Wood Elf Realms | 25 | 3 (net +215) | 0 | 3 (net +50) | 5 (net +256) | 4 (net +111) | 8 (net -7) | 2 | 13% (3 of 23) |

### Charged fights, damage counted: tk-h2h-mine-949ddcd-p2b

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 7 | 168 | 204 | +34 | 175 | 105 | +71 | +42.3 |
| Mine | 50-54% | 3 | 232 | 168 | -0 | 38 | 38 | -0 | -0.1 |
| Mine | Effective (55-75%) | 4 | 317 | 167 | +164 | 223 | 0 | +223 | +70.4 |
| Mine | 76-89% | 8 | 294 | 125 | +69 | 69 | 40 | +29 | +9.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 18 | 263 | 161 | +106 | 149 | 29 | +120 | +45.8 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 495 | 111 | +112 | 174 | 57 | +116 | +23.5 |
| Mine | No odds | 2 | 99 | 92 | +55 | 55 | 0 | +55 | +55.6 |
| Mine | All fights | 50 | 288 | 151 | +87 | 139 | 43 | +97 | +33.6 |
| Opponent | Long shot (under 50%) | 7 | 304 | 373 | +252 | 255 | 11 | +244 | +80.2 |
| Opponent | 50-54% | 1 | 186 | 90 | +0 | 36 | 0 | +36 | +19.4 |
| Opponent | Effective (55-75%) | 7 | 259 | 256 | +48 | 96 | 77 | +19 | +7.3 |
| Opponent | 76-89% | 14 | 219 | 183 | +178 | 219 | 27 | +192 | +87.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 24 | 207 | 163 | +118 | 155 | 39 | +116 | +55.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 509 | 84 | +105 | 105 | 0 | +105 | +20.6 |
| Opponent | No odds | 4 | 182 | 290 | +36 | 36 | 0 | +36 | +19.6 |
| Opponent | All fights | 62 | 249 | 202 | +131 | 160 | 31 | +129 | +51.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| tk-h2h-mine-949ddcd-p2b | move | 218 | 47 (22%) | 32 (15%) | 26 (12%) | 145 (67%) |
| tk-h2h-mine-949ddcd-p2b | objective | 162 | 29 (18%) | 20 (12%) | 17 (10%) | 116 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2429, L2535, L2735 |
| Charmed Shield | Opponent | L1727, L1827, L1927 |
| Elixir of Power | Mine | L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Ring of Doom | Mine | L1531 |
| Ring of Doom | Opponent | L1531, L2131, L3033 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |

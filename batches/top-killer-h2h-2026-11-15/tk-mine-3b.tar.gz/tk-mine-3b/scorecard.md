# Doctrine scorecard: tk-h2h-mine-949ddcd-p3b

### Scorecard: tk-h2h-mine-949ddcd-p3b

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1327 | 1 | 1 | Mine | no | 9 | 3 | 2 | 0 | 0 | 0 | 0 | 317 |
| L1327 | 1 | 1 | Opponent | no | 2 | 1 | 5 | 3 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Mine | no | 11 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 127 |
| L1519 | 1 | 1 | Mine | no | 3 | 2 | 3 | 1 | 0 | 0 | 0 | 199 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 7 | 0 | 1 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | yes | - | 3 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 3 | 3 | 1 | 0 | 0 | 0 | 125 |
| L1633 | 1 | 1 | Mine | yes | 6 | 2 | 4 | 1 | 1 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 0 | 1 | 4 | 2 | 0 | 0 | 0 | 893 |
| L1731 | 3 | 1 | Mine | no | 2 | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Opponent | no | 0 | 2 | 1 | 0 | 3 | 0 | 0 | 340 |
| L1831 | 1 | 1 | Mine | no | 4 | 3 | 5 | 0 | 2 | 0 | 0 | 305 |
| L1831 | 1 | 1 | Opponent | no | 4 | 2 | 3 | 0 | 0 | 0 | 0 | 170 |
| L1932 | 6 | 1 | Mine | no | 2 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1932 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 170 |
| L2033 | 5 | 1 | Mine | yes | - | - | 0 | 3 | 1 | 0 | 0 | 617 |
| L2033 | 5 | 1 | Opponent | yes | - | 5 | 1 | 1 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Mine | no | 2 | 1 | 7 | 0 | 0 | 0 | 0 | 72 |
| L2223 | 3 | 1 | Opponent | no | 1 | 2 | 3 | 0 | 3 | 0 | 0 | 72 |
| L2327 | 5 | 1 | Mine | yes | - | 3 | 6 | 0 | 1 | 0 | 0 | 72 |
| L2327 | 5 | 1 | Opponent | yes | - | 2 | 5 | 2 | 2 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Mine | no | 0 | 4 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 0 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Mine | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Opponent | no | 5 | 1 | 5 | 2 | 0 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Mine | no | 5 | 3 | 3 | 1 | 2 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Opponent | no | 4 | 4 | 2 | 2 | 0 | 0 | 0 | 144 |
| **Average** | | | Mine | 29% | 4.2 | 2.5 | 3.6 | 0.6 | 0.5 | 0.0 | 0.0 | 130.1 |
| **Average** | | | Opponent | 21% | 1.5 | 2.2 | 3.9 | 1.2 | 0.6 | 0.0 | 0.0 | 147.4 |

### KPIs: tk-h2h-mine-949ddcd-p3b

Rules off - Opponent only: STAY WORTH, BEST MOVE FOR SHOOTERS, THREAT IN THE KILL, FOCUS OVER TURNS, MISSILES IN THE PLAN, FACE THE CAST, WIZARD FRONT RANK, THREAT OVER THE TURNS, THREAT TO WORN DOWN.

Morten 2026-11-10; 15 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 5% (4 of 78) | 19% (14 of 74) | 12% (18 of 152) |
| Winner chose to follow up after the loser gave ground |  | 100% (32 of 32); on the table 100% | 100% (39 of 39); on the table 100% | 100% (71 of 71); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 86% (6 of 7); on the table 86% | 89% (8 of 9); on the table 89% | 88% (14 of 16); on the table 88% |
| Winner chose to pursue after the loser fled |  | 100% (13 of 13); on the table 100% | 62% (13 of 21); on the table 67% | 76% (26 of 34); on the table 79% |
| Winner chose to follow up or pursue (all three) |  | 98% (51 of 52); on the table 98% | 87% (60 of 69); on the table 88% | 92% (111 of 121); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 33% (26 of 78) | 37% (11 of 30) | 34% (37 of 108) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 40% (26 of 65) | 44% (11 of 25) | 41% (37 of 90) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 32% (21 of 66) | 50% (6 of 12) | 35% (27 of 78) |
|     round 1 |  | 27% (3 of 11) | 50% (1 of 2) | 31% (4 of 13) |
|     rounds 2+ |  | 33% (18 of 55) | 50% (5 of 10) | 35% (23 of 65) |
|   other wizards | 50%+ | 42% (5 of 12) | 28% (5 of 18) | 33% (10 of 30) |
|     round 1 |  | 50% (1 of 2) | 0% (0 of 3) | 20% (1 of 5) |
|     rounds 2+ |  | 40% (4 of 10) | 33% (5 of 15) | 36% (9 of 25) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 33% (4 of 12) | 40% (14 of 35) | 38% (18 of 47) |
| Points that never fought | lower | 20% (5578 of 28106) | 28% (8504 of 29998) | 24% (14082 of 58104) |
|   infantry points that never fought | lower | 29% (1447 of 5018) | 44% (2403 of 5410) | 37% (3850 of 10428) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 42% (42 of 101) | 59% (76 of 128) | 52% (118 of 229) |
| Bound items with a magic missile used (at least once a game) |  | 100% (7 of 7); 1.2 uses a game | 91% (10 of 11); 2.8 uses a game | 94% (17 of 18); 2.0 uses a game |
| Bound items with another spell used |  | 50% (4 of 8); 0.3 uses a game | 0.0 uses a game | 50% (4 of 8); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 67% (2 of 3); 0.1 uses a game | 17% (1 of 6); 0.1 uses a game | 33% (3 of 9); 0.1 uses a game |
|   their share of the points of units over 100 pts | lower | 36% (9075 of 25006) | 53% (14443 of 27024) | 45% (23518 of 52030) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.2 (35%) | 0.5 (37%) | 1.7 (35%) |
| MARCHED: its unit marched | 0.9 (25%) | 0.1 (5%) | 0.9 (20%) |
| CHARGED: its unit charged | 0.2 (6%) | 0.0 (0%) | 0.2 (4%) |
| IN COMBAT: engaged in combat | 0.5 (15%) | 0.2 (16%) | 0.7 (15%) |
| REAR RANK: in a rear rank | 0.2 (6%) | 0.4 (32%) | 0.6 (13%) |
| GONE: slain | 0.2 (6%) | 0.1 (11%) | 0.3 (7%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (4%) | 0.0 (0%) | 0.1 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.0 | 0.9 | 2.1 | 2.5 | 1.0 | 0.8 |
| not cast | 5.0 | 1.4 | 3.1 | 4.7 | 1.7 | 19.2 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (4%) | 0.0 (0%) | 0.0 (0%) | 1.6 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.1 (1%) | 0.7 (48%) | 0.3 (9%) | 1.7 (35%) | 0.1 (4%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.9 (20%) | 0.1 (8%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (4%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.0 (0%) | 0.2 (7%) | 0.7 (15%) | 0.2 (12%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (7%) | 0.0 (0%) | 0.7 (22%) | 0.6 (13%) | 0.3 (16%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (4%) | 0.6 (3%) |
| GONE: slain | 0.4 (8%) | 0.2 (14%) | 0.3 (9%) | 0.3 (7%) | 0.1 (8%) | 2.1 (11%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (3%) | 0.1 (10%) | 0.5 (15%) | 0.1 (3%) | 0.3 (20%) | 0.9 (5%) |
| STUPIDITY: Stupidity | 0.4 (8%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) | 0.5 (28%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.5 (71%) | 0.4 (29%) | 1.0 (33%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.0 (73%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.5 a game | 0.7 a game | 1.1 a game |
| stood (cast and not dispelled) | 60% (6 of 10) | 50% (5 of 10) | 55% (11 of 20) |
| the unit moved after it | 83% (5 of 6) | 100% (5 of 5) | 91% (10 of 11) |
| it charged on its next turn | 0% (0 of 6) | 0% (0 of 5) | 0% (0 of 11) |
| the enemy charged it first | 17% (1 of 6) | 20% (1 of 5) | 18% (2 of 11) |
| it fought by the end of its next turn | 17% (1 of 6) | 20% (1 of 5) | 18% (2 of 11) |
| it moved out of a charge the enemy had planned (not charged first) | 17% (1 of 6) | 80% (4 of 5) | 45% (5 of 11) |
| none of these (no charge, no fight, no charge escaped) | 67% (4 of 6) | 0% (0 of 5) | 36% (4 of 11) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 53% (143 of 271) | 60% (136 of 226) | 56% (279 of 497) |
|   cavalry | 61% (17 of 28) | 62% (36 of 58) | 62% (53 of 86) |
|   character | 33% (19 of 57) | 24% (13 of 55) | 29% (32 of 112) |
|   chariot | 57% (13 of 23) | 67% (4 of 6) | 59% (17 of 29) |
|   infantry | 58% (66 of 114) | 78% (83 of 107) | 67% (149 of 221) |
|   monster | 37% (10 of 27) | - | 37% (10 of 27) |
|   war machine | 82% (18 of 22) | - | 82% (18 of 22) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (23%) | 1.3 (21%) | 3.3 (22%) |
| CHARGED: it charged | 1.5 (18%) | 2.0 (33%) | 3.5 (24%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.1 (2%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.7 (8%) | 0.9 (14%) | 1.5 (11%) |
| NO TARGET IN RANGE | 1.3 (16%) | 0.7 (12%) | 2.1 (14%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (7%) | 0.5 (9%) | 1.1 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.9 (22%) | 0.5 (8%) | 2.3 (16%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.5 | 1.0 | 83% | 5.3 pts | 29 pts |
| character | 3.0 | 1.1 | 71% | 10.2 pts | 31 pts |
| chariot | 1.1 | 0.1 | 88% | 2.4 pts | 3 pts |
| infantry | 16.2 | 7.0 | 72% | 8.9 pts | 144 pts |
| monster | 0.7 | 0.1 | 90% | 2.1 pts | 1 pts |
| war machine | 1.2 | 0.5 | 72% | 5.0 pts | 6 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.9 | 7.0 | 6.0 |
| Charges that made contact a game | 4.0 | 4.7 | 4.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.67 contact (9 units) | 0.67 declared, 0.33 contact (3 units) | 0.92 declared, 0.58 contact (12 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 1.00 contact (2 units) | 0.20 declared, 0.20 contact (5 units) | 0.43 declared, 0.43 contact (7 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.59 declared, 0.49 contact (106 units) | 0.84 declared, 0.56 contact (121 units) | 0.73 declared, 0.53 contact (227 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (20 of 40) | 33% (2 of 6) | 50% (3 of 6) | 48% (25 of 52) |
| Character in a unit | 70% (7 of 10) | 100% (6 of 6) | 25% (1 of 4) | 70% (14 of 20) |
| Character on its own | 83% (20 of 24) | 60% (6 of 10) | 20% (7 of 35) | 48% (33 of 69) |
| Chariot | 100% (4 of 4) | - | - | 100% (4 of 4) |
| Infantry | 52% (14 of 27) | 35% (6 of 17) | 100% (1 of 1) | 47% (21 of 45) |
| Monster | 50% (10 of 20) | 50% (2 of 4) | - | 50% (12 of 24) |
| Monstrous | 62% (5 of 8) | 57% (4 of 7) | - | 60% (9 of 15) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 4 | 89% (8 of 9); on the table 89% | 46% (11 of 24) | 24% | 39% (12 of 31) | 100% (5 of 5); 3.8 uses a game | 50% (4 of 8); 1.2 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (7 of 7); on the table 100% | - | 23% | 17% (1 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | 100% (5 of 5); on the table 100% | 17% (1 of 6) | 8% | 0% (0 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (5 of 5); on the table 100% | 17% (1 of 6) | 6% | 71% (5 of 7) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 91% (10 of 11); on the table 100% | 17% (2 of 12) | 2% | 69% (11 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Skaven | 1 | 100% (3 of 3); on the table 100% | 0% (0 of 6) | 67% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 4 | 100% (12 of 12); on the table 100% | - | 20% | 25% (4 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 4 | 100% (20 of 20); on the table 100% | 33% (8 of 24) | 23% | 62% (15 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 7 | 80% (28 of 35); on the table 80% | 54% (13 of 24) | 24% | 46% (29 of 63) | 100% (3 of 3); 1.4 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 5 | 93% (13 of 14); on the table 93% | 17% (1 of 6) | 36% | 69% (36 of 52) | 89% (8 of 9); 6.8 uses a game | 0.0 uses a game | 0% (0 of 4); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (tk-h2h-mine-949ddcd-p3b, 15 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (21) | 49% (27) | 49% (48) |
| ...free all their last turn and able to turn (per game) | 0.53 | 0.93 | 1.47 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.20 | 0.47 | 0.67 |
| ...with the charger already in that arc before they moved (per game) | 0.27 | 0.60 | 0.87 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.93 | 1.40 | 3.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.60 | 0.60 | 1.20 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.13 | 4.93 | 10.07 |

### Quality by phase: tk-h2h-mine-949ddcd-p3b

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 3.1 |
| Strategy | Charge objectives carried out (made contact) | 58% (40 of 69) | 42% (35 of 84) |
| Strategy | Shoot objectives carried out (shot that target) | 67% (50 of 75) | 51% (36 of 71) |
| Strategy | Close-in objectives charged next turn | 18% (16 of 91) | 29% (23 of 79) |
| Strategy | Support requests answered (helper made contact too) | 67% (6 of 9) | 50% (5 of 10) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 3) | 75% (3 of 4) |
| Strategy | Joined characters whose unit fought | 56% (5 of 9) | 53% (9 of 17) |
| Strategy | Lone characters that fought | 83% (29 of 35) | 88% (37 of 42) |
| Movement | Charges halted short of contact | 0.2 | 0.1 |
| Movement | Idle units | 0.6 | 1.2 |
| Movement | Points that never moved of their own | 130.1 | 147.4 |
| Movement | Fights charged into per game | 4.2 | 3.6 |
| Movement | Charges with odds: long shots (under 50%) | 8 of 52, net +102 | 9 of 42, net +45 |
| Movement | Charges with odds: sweet spot (55-75%) | 8 of 52, net +189 | 6 of 42, net +60 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 6 of 52, net +87 | 1 of 42, net +0 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 20 of 52, net +100 | 19 of 42, net +230 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.3 | 11.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 27% (37 of 139) | 39% (65 of 165) |
| Shooting | Points destroyed by shooting units | 28.4 | 42.7 |
| Shooting | War machine shots | 1.2 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (8 of 18) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.0 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (5 of 15) | 25% (1 of 4) |
| Magic | Wounds caused by magic missiles | 2.7 | 1.1 |
| Magic | Wounds caused by other spells | 1.0 | 0.3 |
| Magic | Points destroyed by magic (all spells) | 66.7 | 10.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.9 / 0.2 / 0.5 / 0.0 | 1.5 / 0.3 / 0.3 / 1.0 |
| Combat | Points destroyed in combat | 539.5 | 494.6 |
| Combat | Points run down | 59.9 | 159.8 |
| Combat | Net points per charged fight, damage counted | +98 | +124 |
| Combat | Net per 100 charger points, damage counted | +35.9 | +51.7 |
| Combat | First round won (charged fights) | 59% | 65% |
| Combat | Net points per charged fight | +89 | +112 |
| Combat | Net points per supported fight / lone fight | +164 / +85 | +278 / +83 |
| Combat | Charged fights on a top-3 enemy unit | 18 of 63 | 23 of 54 |
| Game | Points lost | 808.1 | 741.5 |
| Game | VP from objectives | 593.3 | 476.7 |
| Game | Lone holders (player turns) | 4.2 | 1.5 |

- Mine won / drew / lost: 6 / 3 / 6 of 15 ended games (of 15); mean margin (Mine - Opponent) +76 VP
- The side that went first won 2 of 12 games with a winner
- Points traded per game (both sides' losses): 1550
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: tk-h2h-mine-949ddcd-p3b

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.9 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.5 | +5.5 | 0.0 | 10.1 | 0.8 | +13.7 | 0.0 | 13.0 |
| BEST FACING | 0.7 | +29.0 | 0.0 | 37.6 | 0.5 | +10.6 | 0.0 | 13.9 |
| BEST FIRST | 4.5 | +178.3 | 82.9 | 172.5 | 2.7 | +162.6 | 106.5 | 23.2 |
| BEST MOVE FOR SHOOTERS | 0.9 | +56.1 | 0.0 | 17.6 | - | - | - | - |
| BEST OVERALL | 0.4 | +13.8 | 0.0 | 25.3 | 0.4 | +13.6 | 0.0 | 18.5 |
| BEST PREY | 0.9 | +76.5 | 16.7 | 18.6 | 0.7 | +21.5 | 34.9 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | +0.5 | 0.0 | 0.0 | 0.1 | +0.2 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.3 | +7.3 | 0.0 | 0.0 | 0.3 | +10.9 | 0.0 | 0.0 |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 10.1 | - | - | - | - |
| CANNON PLAN MISSED | 0.1 | +0.0 | 7.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 0.7 | +2.6 | 17.2 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT COUNTER | 0.1 | -2.1 | 12.4 | 0.0 | 0.1 | +0.0 | 32.1 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | -1.1 | 0.0 | 0.0 | 0.1 | -6.1 | 20.1 | 7.7 |
| CAST JOB | 0.1 | +2.4 | 8.4 | 0.0 | 0.9 | +31.2 | 64.1 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | - | - | - | - | 0.1 | +1.4 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.9 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | 0.1 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.5 | -3.9 | 0.0 | 8.8 | 0.1 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 2.7 | +0.0 | 281.4 | 148.5 | 2.4 | +0.0 | 313.9 | 42.9 |
| CHARGE NOW WEIGHED | 0.5 | -29.8 | 37.5 | 2.7 | 0.4 | -38.6 | 47.0 | 13.0 |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| CHEAP HELPER | 0.1 | +0.0 | 13.9 | 7.7 | 0.1 | +0.0 | 10.8 | 0.0 |
| COMBAT PIVOT | 0.9 | +0.0 | 0.0 | 64.1 | 0.2 | +0.0 | 8.2 | 11.3 |
| CONVEYANCE SEARCH | 0.5 | +55.1 | 23.1 | 27.0 | 0.6 | +54.7 | 0.0 | 15.6 |
| COUNTER-CHARGE COVER | 7.7 | +509.9 | 0.0 | 166.7 | 7.2 | +566.2 | 0.0 | 130.9 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 7.2 | 0.0 |
| DEFENSIVE FLOOR | 0.1 | +4.5 | 5.0 | 0.0 | 0.1 | +0.5 | 0.0 | 4.2 |
| EDGE GIVE GROUND | 0.5 | +39.0 | 25.2 | 37.3 | 0.1 | +1.8 | 23.8 | 0.0 |
| ELIXIR WORTH | 0.1 | +0.2 | 0.0 | 23.3 | - | - | - | - |
| FACES THE THREAT | 1.9 | +139.7 | 0.0 | 118.7 | 1.4 | +98.2 | 0.0 | 43.7 |
| FALLBACK BY WORTH | 4.9 | +24.8 | 0.0 | 105.6 | 5.9 | +53.5 | 0.0 | 55.7 |
| FIGHT LIFT | 0.1 | +0.5 | 18.5 | 0.0 | - | - | - | - |
| FIRE AND FLEE | 0.1 | +1.0 | 6.9 | 5.3 | - | - | - | - |
| FLANK NOT WEIGHED | 5.0 | +0.0 | 0.0 | 193.3 | 4.4 | +0.0 | 0.0 | 96.1 |
| FOCUS FIRE | - | - | - | - | 0.1 | +7.6 | 16.4 | 0.0 |
| FOCUS OVER TURNS | 1.1 | +27.5 | 31.9 | 19.2 | - | - | - | - |
| FOLLOW UP WEIGHED | 1.7 | +216.1 | 0.0 | 13.0 | 1.8 | +382.6 | 0.0 | 15.5 |
| FRIENDS SHOTS CHECKED | 0.4 | +39.5 | 0.0 | 47.2 | 0.1 | +1.9 | 0.0 | 0.0 |
| GATEWAY ESCAPE | - | - | - | - | 0.1 | +4.8 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -0.6 | 7.2 | 0.0 | 0.1 | -2.8 | 32.1 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -0.4 | 12.0 | 1.3 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 33.3 | 0.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 146.0 | 12.4 |
| HILL BY ITS CHANCE | - | - | - | - | 0.4 | -16.7 | 0.0 | 24.6 |
| HOLDS AMBUSHERS | 0.5 | +0.0 | 0.0 | 0.0 | 0.9 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.1 | +1.9 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.3 | +7.9 | 0.0 | 13.0 | 0.4 | +11.5 | 0.0 | 13.0 |
| INVITES THE FIGHT | 0.9 | +26.1 | 35.1 | 0.0 | 1.3 | +19.5 | 45.9 | 16.3 |
| JOINT CHARGE PLAN | 0.1 | +32.0 | 0.0 | 0.0 | 0.2 | +6.5 | 0.0 | 15.5 |
| KEEPS ITS TARGET | 2.9 | +86.0 | 214.1 | 39.5 | 1.9 | +58.0 | 233.7 | 27.2 |
| KILLS COUNT | 1.6 | +74.7 | 131.9 | 39.2 | 1.7 | +83.0 | 168.6 | 5.9 |
| KILLS COUNT NEXT TURN | 6.8 | +332.0 | 179.8 | 219.9 | 8.3 | +247.4 | 308.0 | 188.1 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.2 | +0.0 | 20.1 | 0.0 |
| LONE WIZARD HOLDS BACK | 0.4 | +0.0 | 17.0 | 0.0 | 0.9 | +0.0 | 15.2 | 0.0 |
| LONE WIZARD KEPT IN | 0.3 | +12.6 | 0.0 | 0.0 | 0.2 | +5.9 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | -4.2 | 13.0 | 4.0 | 0.4 | -5.5 | 76.7 | 0.0 |
| LOST CHARGE | 2.9 | -51.2 | 74.2 | 171.9 | 2.8 | -37.6 | 100.1 | 33.9 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.1 | -38.5 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.6 | +85.5 | 0.0 | 10.7 | 0.8 | +46.8 | 31.8 | 15.5 |
| MANOEUVRE | 0.1 | +2.2 | 0.0 | 0.0 | 0.1 | +0.8 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.3 | +11.0 | 0.0 | 13.3 | 0.2 | +17.3 | 0.0 | 0.0 |
| MARCH ODDS | 0.3 | +14.4 | 0.0 | 0.0 | 0.2 | +8.3 | 14.0 | 0.0 |
| MARCH OVER CASTS | 0.7 | +64.8 | 0.0 | 23.8 | 0.2 | +8.3 | 0.0 | 16.7 |
| MAX FOR POSITIONING | 5.7 | +209.8 | 0.0 | 177.1 | 5.7 | +206.6 | 0.0 | 76.0 |
| MISSILES IN THE MOVE | 2.7 | +50.7 | 0.0 | 123.7 | 4.0 | +80.0 | 0.0 | 42.1 |
| MISSILES IN THE PLAN | 0.1 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| MISSILES NEXT TURN | 3.9 | +40.4 | 0.0 | 160.5 | 3.9 | +44.1 | 0.0 | 58.9 |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE AND CAST | 0.2 | +7.4 | 0.0 | 0.0 | 0.7 | +34.2 | 0.0 | 13.9 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 0.1 | -5.2 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE | 4.7 | +410.4 | 131.1 | 122.3 | 4.1 | +353.4 | 181.3 | 77.5 |
| MOVES UNITS SPELL | 0.2 | +1.3 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.1 | +0.0 | 10.1 | 0.0 |
| NO RALLY LEFT | - | - | - | - | 0.1 | +0.1 | 0.0 | 0.0 |
| NOT NEEDED | 0.2 | -6.0 | 9.6 | 0.0 | 0.6 | -56.2 | 165.7 | 0.0 |
| NOT TURNED | 5.1 | +37.2 | 0.0 | 148.1 | 4.9 | +38.1 | 0.0 | 120.1 |
| NOT WORTH A CAST | 1.0 | -0.6 | 0.0 | 0.0 | 1.8 | -2.1 | 0.0 | 15.6 |
| OFF BEST | 14.4 | -673.5 | 18.9 | 192.5 | 13.6 | -654.8 | 10.1 | 178.5 |
| OPENS UP | 0.1 | +6.3 | 11.6 | 0.0 | 0.2 | +11.5 | 0.0 | 0.0 |
| OVERRUN THREAT | - | - | - | - | 0.1 | +1.5 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.5 | +33.0 | 28.3 | 62.8 | 0.5 | +4.5 | 7.1 | 7.7 |
| PATHS CROSS | 2.0 | +90.0 | 0.0 | 13.9 | 2.9 | +229.1 | 0.0 | 18.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.1 | -0.8 | 0.0 | 0.0 |
| PLAN RESULT | 35.0 | +858.9 | 1183.6 | 1237.6 | 38.0 | +1634.6 | 1929.7 | 773.2 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.1 | +11.7 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +11.7 | 0.0 | 0.0 | 0.1 | +8.3 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.8 | +12.8 | 0.0 | 25.3 | 2.3 | +10.8 | 0.0 | 34.0 |
| RANDOM MOVER NO PROMISE | 0.1 | -16.2 | 0.0 | 11.3 | 1.0 | -51.6 | 45.3 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -16.7 | 0.0 | 0.0 | 0.6 | -30.7 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.9 | +169.9 | 0.0 | 59.4 | 5.0 | +350.7 | 0.0 | 74.8 |
| REDIRECT WEIGHED | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 9.6 |
| RESERVE FALL BACK | 0.6 | +9.2 | 0.0 | 4.4 | 1.2 | +67.2 | 0.0 | 11.6 |
| RESTRAINS TO SHOOT | 0.1 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.4 | +66.8 | 156.1 | 87.9 | 3.3 | +56.3 | 418.7 | 37.7 |
| SAFER THAN THE JOB | 0.6 | +45.6 | 0.0 | 0.0 | 0.6 | +60.6 | 0.0 | 8.3 |
| SCOUT SPOT | 0.4 | +0.3 | 0.0 | 2.3 | 0.3 | +0.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 2.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.3 | -2.0 | 0.0 | 2.3 | 0.1 | -4.6 | 0.0 | 0.0 |
| SEARCH SPOT | 2.8 | +79.9 | 0.0 | 68.1 | 2.5 | +108.8 | 0.0 | 45.4 |
| SELF MOVE SPELL | 1.2 | +140.2 | 0.0 | 0.0 | - | - | - | - |
| SET UP TOGETHER | 0.8 | +106.5 | 0.0 | 10.7 | 1.4 | +122.9 | 31.8 | 15.5 |
| SET-UP ANY TARGET | 0.1 | +18.9 | 0.0 | 0.0 | 0.1 | +6.2 | 0.0 | 15.6 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.8 | +23.7 | 17.0 | 0.0 | 0.5 | +4.9 | 0.0 | 15.7 |
| SHOT OPTIONS | 11.7 | +0.0 | 249.1 | 192.7 | 9.4 | +0.0 | 541.0 | 162.7 |
| SHOT REPLANNED | 0.3 | +0.0 | 34.3 | 8.4 | 0.2 | +0.0 | 26.2 | 0.0 |
| SHOTS IN THE MOVE | 10.6 | +229.4 | 0.0 | 157.5 | 7.9 | +179.8 | 0.0 | 105.3 |
| SPELL SETS UP CHARGE | 0.4 | +133.9 | 23.1 | 27.0 | 0.1 | +6.2 | 0.0 | 15.6 |
| SPELL WORTH | 2.1 | +24.2 | 45.5 | 50.4 | 1.9 | +15.8 | 32.5 | 40.9 |
| STABLE ROLE | 8.5 | +0.0 | 336.3 | 186.6 | 7.8 | +0.0 | 217.3 | 165.9 |
| STAY WEIGHED | 0.1 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| STAY WORTH | 9.7 | +154.3 | 103.7 | 74.5 | - | - | - | - |
| STOPS SHORT OF THE FLANK | 0.5 | +17.0 | 0.0 | 46.2 | 0.1 | +8.1 | 0.0 | 7.7 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 5.9 | -40.2 | 333.7 | 124.1 | 8.5 | -51.8 | 610.2 | 96.3 |
| SUPPORTS | 3.9 | +50.9 | 183.3 | 77.5 | 5.4 | +51.8 | 201.5 | 50.4 |
| SURE CHARGE BEATS ADVANCE | 0.3 | -25.3 | 24.9 | 23.3 | 0.1 | -1.9 | 4.0 | 6.5 |
| SURE REACH TOGETHER | 0.4 | +8.5 | 0.0 | 10.7 | 0.5 | +11.1 | 0.0 | 9.7 |
| THREAT IN THE KILL | 7.8 | +37.9 | 215.9 | 206.9 | - | - | - | - |
| THREAT OVER THE TURNS | 4.7 | +21.0 | 152.7 | 150.1 | - | - | - | - |
| THREAT TO WORN DOWN | 7.2 | +43.4 | 206.5 | 206.9 | - | - | - | - |
| THROUGH LINE OF FIRE | 0.3 | +3.9 | 0.0 | 4.4 | 0.3 | +3.1 | 0.0 | 0.0 |
| TURN WORTH | 0.9 | -76.1 | 95.4 | 0.0 | 0.5 | -20.7 | 34.4 | 0.0 |
| TWO OR MORE ARRIVE | 0.3 | +3.6 | 0.0 | 0.0 | 0.6 | +9.3 | 0.0 | 0.0 |
| WAIT AFTER COSTS | 8.0 | -410.2 | 212.1 | 153.7 | 6.7 | -291.9 | 272.7 | 108.3 |
| WALKS TO THE FIGHT | 1.9 | +64.7 | 47.7 | 31.5 | 0.8 | +10.2 | 17.7 | 8.0 |
| WAR ENGINE CHARGES | 0.1 | +1.8 | 0.0 | 12.3 | 0.1 | +6.1 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.2 | +0.0 | 9.6 | 12.3 | 0.1 | +0.0 | 12.4 | 5.0 |
| WEARS DOWN | 1.3 | +43.8 | 93.0 | 41.2 | 1.8 | +101.7 | 214.4 | 29.3 |
| WHO HITS BACK | 0.1 | +9.3 | 0.0 | 7.7 | 0.3 | +5.4 | 0.0 | 5.0 |
| WHOLE FIGHT | 0.5 | +18.2 | 82.5 | 28.7 | 0.9 | +42.8 | 166.3 | 1.3 |
| WHOLE FIGHT GAIN | 0.3 | +48.7 | 30.9 | 0.0 | 0.7 | +87.2 | 121.1 | 1.3 |
| WOUNDED STAYS OUT | 0.1 | +0.0 | 7.3 | 18.5 | 0.1 | +0.0 | 0.0 | 8.4 |

### Rule changes: tk-h2h-mine-949ddcd-p3b

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 420 | 420 | 420 | 28.00 | -19925 | -47.4 |
| BEST FIRST | 107 | 107 | 107 | 7.13 | +5113 | +47.8 |
| SEARCH SPOT | 79 | 79 | 79 | 5.27 | +2831 | +35.8 |
| PATHS CROSS | 73 | 73 | 73 | 4.87 | +4787 | +65.6 |
| MOVE TO CHARGE | 133 | 133 | 70 | 4.67 | +5189 | +74.1 |
| KILLS COUNT NEXT TURN | 226 | 226 | 62 | 4.13 | +1352 | +21.8 |
| FOLLOW UP WEIGHED | 53 | 53 | 53 | 3.53 | +8981 | +169.5 |
| COUNTER-CHARGE COVER | 224 | 124 | 52 | 3.47 | +2008 | +38.6 |
| FACES THE THREAT | 50 | 50 | 50 | 3.33 | +3569 | +71.4 |
| SUPPORTS | 140 | 140 | 47 | 3.13 | +390 | +8.3 |
| SHOTS IN THE MOVE | 278 | 164 | 37 | 2.47 | +649 | +17.5 |
| FALLBACK BY WORTH | 161 | 161 | 32 | 2.13 | +1175 | +36.7 |
| REDIRECT COUNTER | 118 | 65 | 30 | 2.00 | +1843 | +61.4 |
| RESERVE FALL BACK | 27 | 27 | 27 | 1.80 | +1147 | +42.5 |
| MAX FOR POSITIONING | 170 | 102 | 26 | 1.73 | +254 | +9.8 |
| ADVANCE LANE KEPT | 21 | 21 | 21 | 1.40 | +0 | +0.0 |
| WAIT AFTER COSTS | 220 | 220 | 21 | 1.40 | +297 | +14.2 |
| WALKS TO THE FIGHT | 40 | 40 | 21 | 1.40 | +344 | +16.4 |
| HOLDS AMBUSHERS | 20 | 20 | 20 | 1.33 | +0 | +0.0 |
| BEST FACING | 19 | 19 | 19 | 1.27 | +595 | +31.3 |
| CHARGE NOW FIRST | 77 | 77 | 19 | 1.27 | -1578 | -83.1 |
| RANDOM MOVE BY FIGURES | 47 | 47 | 18 | 1.20 | +354 | +19.6 |
| SAFER THAN THE JOB | 18 | 18 | 18 | 1.20 | +1593 | +88.5 |
| COMBAT PIVOT | 17 | 17 | 17 | 1.13 | +0 | +0.0 |
| MISSILES IN THE MOVE | 100 | 59 | 16 | 1.07 | +185 | +11.5 |
| SET UP TOGETHER | 33 | 29 | 16 | 1.07 | +1143 | +71.4 |
| BEST MOVE FOR SHOOTERS | 14 | 14 | 14 | 0.93 | +842 | +60.1 |
| CHARGE NOW WEIGHED | 14 | 14 | 14 | 0.93 | +1172 | +83.8 |
| INVITES THE FIGHT | 34 | 34 | 14 | 0.93 | +190 | +13.6 |
| MOVE AND CAST | 14 | 14 | 14 | 0.93 | +624 | +44.6 |
| RISK BY ARC | 85 | 80 | 14 | 0.93 | +322 | +23.0 |
| CAST JOB | 16 | 16 | 13 | 0.87 | +244 | +18.7 |
| KEEPS ITS TARGET | 72 | 70 | 13 | 0.87 | +264 | +20.3 |
| KILLS COUNT | 49 | 46 | 13 | 0.87 | +685 | +52.7 |
| BEST OVERALL | 12 | 12 | 12 | 0.80 | +410 | +34.2 |
| FOCUS OVER TURNS | 16 | 16 | 12 | 0.80 | +199 | +16.6 |
| SCOUT WAITS | 11 | 11 | 11 | 0.73 | +0 | +0.0 |
| BLOCKED WHEEL | 10 | 10 | 10 | 0.67 | +273 | +27.3 |
| STOPS SHORT OF THE FLANK | 10 | 10 | 10 | 0.67 | +376 | +37.6 |
| BEST PREY | 24 | 24 | 9 | 0.60 | +558 | +62.0 |
| LONE WIZARD HOLDS BACK | 19 | 19 | 9 | 0.60 | -311 | -34.6 |
| STAY WORTH | 146 | 101 | 9 | 0.60 | +71 | +7.9 |
| THROUGH LINE OF FIRE | 9 | 9 | 9 | 0.60 | +104 | +11.6 |
| CHAFF PASSED | 8 | 8 | 8 | 0.53 | -58 | -7.3 |
| LONE WIZARD KEPT IN | 8 | 8 | 8 | 0.53 | +279 | +34.9 |
| MARCH CHECK | 8 | 8 | 8 | 0.53 | +255 | +31.9 |
| SHOOTERS IN TWO RANKS | 8 | 8 | 8 | 0.53 | +18 | +2.2 |
| SHOOTS FROM THE BEST SPOT | 19 | 19 | 8 | 0.53 | +38 | +4.8 |
| SHOT REPLANNED | 8 | 8 | 8 | 0.53 | +0 | +0.0 |
| THREAT TO WORN DOWN | 108 | 91 | 8 | 0.53 | +67 | +8.4 |
| WHOLE FIGHT GAIN | 16 | 14 | 8 | 0.53 | +454 | +56.7 |
| FRIENDS SHOTS CHECKED | 7 | 7 | 7 | 0.47 | +621 | +88.7 |
| MARCH ODDS | 7 | 7 | 7 | 0.47 | +5 | +0.7 |
| WEARS DOWN | 46 | 40 | 7 | 0.47 | +506 | +72.2 |
| WHO HITS BACK | 7 | 7 | 7 | 0.47 | +140 | +20.0 |
| REDIRECT WEIGHED | 6 | 6 | 6 | 0.40 | +36 | +6.0 |
| STUCK PIVOT | 6 | 6 | 6 | 0.40 | +0 | +0.0 |
| BIG CHARACTER SAFETY | 5 | 5 | 5 | 0.33 | +10 | +1.9 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 0.33 | +0 | +0.0 |
| CASTS FROM BEHIND | 5 | 5 | 5 | 0.33 | +0 | +0.0 |
| LOST CHARGE | 85 | 84 | 5 | 0.33 | +119 | +23.9 |
| SURE CHARGE BEATS ADVANCE | 5 | 5 | 5 | 0.33 | -408 | -81.7 |
| DEFENSIVE ARMY | 6 | 6 | 4 | 0.27 | -199 | -49.7 |
| MAKE SURE TOGETHER | 21 | 13 | 4 | 0.27 | +216 | +53.9 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.27 | +23 | +5.8 |
| RAIDS THE BAGGAGE NEXT TURN | 4 | 4 | 4 | 0.27 | +24 | +6.1 |
| CANNON PLANNED TARGET | 10 | 10 | 3 | 0.20 | +0 | +0.0 |
| MANOEUVRE | 3 | 3 | 3 | 0.20 | +45 | +14.8 |
| OPENS UP | 5 | 5 | 3 | 0.20 | +115 | +38.2 |
| SURE REACH TOGETHER | 14 | 9 | 3 | 0.20 | +110 | +36.7 |
| WOUNDED STAYS OUT | 3 | 3 | 3 | 0.20 | -306 | -102.0 |
| CARRIES OUT SET-UP | 3 | 3 | 2 | 0.13 | -108 | -53.9 |
| CASTING BLOCK | 2 | 2 | 2 | 0.13 | +1 | +0.6 |
| EDGE GIVE GROUND | 8 | 8 | 2 | 0.13 | +483 | +241.4 |
| FOCUS FIRE | 2 | 2 | 2 | 0.13 | +114 | +57.1 |
| HORN WORTH | 2 | 2 | 2 | 0.13 | +29 | +14.6 |
| HUNT IN PAIRS | 10 | 7 | 2 | 0.13 | +79 | +39.7 |
| MISSILES NEXT TURN | 118 | 66 | 2 | 0.13 | +2 | +0.9 |
| OVERRUNS AWAY | 15 | 14 | 2 | 0.13 | +293 | +146.4 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.13 | -12 | -5.8 |
| SUPPORT NARROWED | 216 | 216 | 2 | 0.13 | -24 | -11.9 |
| THREAT OVER THE TURNS | 70 | 67 | 2 | 0.13 | +5 | +2.7 |
| BACKUP TARGETS | 20 | 10 | 1 | 0.07 | +1 | +0.9 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.07 | +0 | +0.1 |
| CARRIES OUT COUNTER | 2 | 2 | 1 | 0.07 | -31 | -31.0 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.07 | +0 | +0.0 |
| CATCH ODDS | 1 | 1 | 1 | 0.07 | -1 | -1.4 |
| DEFENSIVE FLOOR | 3 | 2 | 1 | 0.07 | +3 | +2.6 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.07 | +2 | +2.3 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.07 | +15 | +15.1 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.07 | +0 | +0.3 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.07 | +21 | +21.0 |
| STAY WEIGHED | 1 | 1 | 1 | 0.07 | +8 | +7.5 |
| THREAT IN THE KILL | 117 | 99 | 1 | 0.07 | +2 | +2.3 |
| TURN WORTH | 21 | 21 | 1 | 0.07 | +4 | +4.0 |
| TWO OR MORE ARRIVE | 14 | 11 | 1 | 0.07 | +1 | +0.8 |
| WAR ENGINE JOBS | 5 | 5 | 1 | 0.07 | -35 | -34.6 |
| WHOLE FIGHT | 22 | 22 | 1 | 0.07 | +22 | +21.6 |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 19 | trace | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 1 | 1 | 0 | 0.00 | - | - |
| CHEAP HELPER | 2 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 16 | not checked | - | - | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 141 | not checked | - | - | - | - |
| GATEWAY ESCAPE | 1 | not checked | - | - | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 10 | 9 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 6 | 6 | 0 | 0.00 | - | - |
| JOINT CHARGE PLAN | 4 | 4 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 3 | not checked | - | - | - | - |
| LONG SHOT | 11 | 9 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 14 | 14 | 0 | 0.00 | - | - |
| MISSILES IN THE PLAN | 1 | not checked | - | - | - | - |
| MONSTER WIZARD ROAMS | 1 | 1 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 2 | trace | - | - | - | - |
| MOVE SPELL SPOT | 6 | not checked | - | - | - | - |
| NEEDED THERE | 2 | 2 | 0 | 0.00 | - | - |
| NOT NEEDED | 12 | 12 | 0 | 0.00 | - | - |
| NOT TURNED | 151 | 151 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 42 | not checked | - | - | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 1095 | trace | - | - | - | - |
| RAIDS THE BAGGAGE | 1 | 1 | 0 | 0.00 | - | - |
| RANDOM MOVER NO PROMISE | 17 | 17 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 12 | 12 | 0 | 0.00 | - | - |
| SCOUT SPOT | 10 | 10 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 18 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 3 | not checked | - | - | - | - |
| SHOT OPTIONS | 317 | 317 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 7 | not checked | - | - | - | - |
| SPELL WORTH | 59 | not checked | - | - | - | - |
| STABLE ROLE | 244 | 242 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: tk-h2h-mine-949ddcd-p3b

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 12.87 | 11.80 | 49.2 |
| CHARGE NOW FIRST | rule | 0.73 | 0.53 | 83.1 |
| FALLBACK | gate | 0.47 | 0.67 | 33.2 |
| TURN GATE | gate | 0.53 | 0.40 | 24.8 |
| LONE WIZARD HOLDS BACK | rule | 0.20 | 0.27 | 44.4 |
| AFTERMATH BAND | gate | 0.07 | 0.33 | 2.2 |
| CHAFF PASSED | rule | 0.40 | - | 9.7 |
| SUPPORT REQUEST | gate | 0.20 | 0.13 | 119.8 |
| SURE CHARGE BEATS ADVANCE | rule | 0.27 | 0.07 | 81.7 |
| DEFENSIVE ARMY | rule | - | 0.27 | 49.7 |
| FIGHT ORDER BAND | gate | 0.20 | - | 2.3 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.20 | 54.1 |
| MARCH ODDS | rule | 0.13 | 0.07 | 14.2 |
| PATHS CROSS | rule | 0.07 | 0.13 | 36.5 |
| THROUGH LINE OF FIRE | rule | 0.13 | 0.07 | 34.3 |
| WOUNDED STAYS OUT | rule | 0.13 | 0.07 | 102.0 |
| BIG CHARACTER SAFETY | rule | 0.07 | 0.07 | 2.6 |
| BLOCKED WHEEL | rule | 0.07 | 0.07 | 41.7 |
| CARRIES OUT SET-UP | rule | 0.07 | 0.07 | 53.9 |
| CHARGE NOW WEIGHED | rule | 0.07 | 0.07 | 22.1 |
| PIVOT GUARDS FLANK | rule | - | 0.13 | 5.8 |
| SUPPORT NARROWED | rule | 0.07 | 0.07 | 11.9 |
| CARRIES OUT COUNTER | rule | 0.07 | - | 31.0 |
| CATCH ODDS | rule | 0.07 | - | 1.4 |
| NO REASON | gate | 0.07 | - | 11.6 |
| RULE SWITCHED OFF | gate | - | 0.07 | 3.7 |
| SAFER THAN THE JOB | rule | - | 0.07 | 4.5 |
| STOPS SHORT OF THE FLANK | rule | 0.07 | - | 0.8 |
| WAR ENGINE JOBS | rule | - | 0.07 | 34.6 |
| WHO HITS BACK | rule | - | 0.07 | 2.7 |

### Plans: tk-h2h-mine-949ddcd-p3b

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.7 | 16% | 466 | 247 | 53% |
| Mine | charge | 3.8 | 68% | 311 | 299 | 96% |
| Mine | close in | 6.1 | 29% | 594 | 173 | 29% |
| Mine | hold | 4.1 | 47% | 216 | 0 | 0% |
| Mine | join | 0.2 | 100% | 9 | 0 | 0% |
| Mine | shoot | 3.9 | 59% | 141 | 140 | 100% |
| Mine | support | 4.2 | 92% | 42 | 0 | 0% |
| Opponent | advance | 13.9 | 22% | 413 | 652 | 158% |
| Opponent | charge | 5.1 | 57% | 559 | 606 | 108% |
| Opponent | close in | 5.2 | 31% | 415 | 175 | 42% |
| Opponent | hold | 3.0 | 29% | 225 | 0 | 0% |
| Opponent | join | 1.0 | 87% | 34 | 0 | 0% |
| Opponent | shoot | 3.9 | 56% | 59 | 202 | 343% |
| Opponent | support | 5.9 | 92% | 36 | 0 | 0% |

### Battle groups: tk-h2h-mine-949ddcd-p3b

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 7.7 | 22% | 69% | 12% | 0% | 39% | 22% | 13% | 26% | 0% |
| Mine | REDIRECT COUNTER | 2.9 | 33% | 64% | 21% | 33% | 18% | 0% | 27% | 45% | 9% |
| Opponent | COUNTER-CHARGE COVER | 7.2 | 26% | 46% | 18% | 20% | 35% | 9% | 17% | 39% | 0% |
| Opponent | REDIRECT COUNTER | 5.0 | 25% | 53% | 21% | 75% | 27% | 7% | 20% | 47% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: tk-h2h-mine-949ddcd-p3b

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 160 (1) | 160 | 0 | 100 | 0% | 4.0 | - | 160 (1) | - | - | 160 (1) |
| Mine | Chaff | 21 | 66 (21) | 18 | 47 | 52 | 14% | 2.4 | 73 (12) | 18 (3) | 64 (6) | 87 (16) | 6 (5) |
| Mine | Character | 35 | 63 (35) | 60 | 2 | 26 | 9% | 2.2 | 57 (17) | 75 (15) | - | 53 (15) | 75 (17) |
| Mine | Clean-up | 12 | 54 (12) | 35 | 19 | 7 | 8% | 3.9 | 0 (3) | 70 (9) | - | 54 (7) | 53 (5) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 22 | 41 (22) | 15 | 26 | 74 | 14% | 3.5 | 36 (9) | 39 (9) | 56 (4) | 50 (15) | 25 (7) |
| Mine | Fragile | 3 | 0 (3) | 0 | 0 | 33 | 0% | 5.0 | 0 (3) | - | - | 0 (1) | 0 (2) |
| Mine | Hammer | 16 | 49 (16) | 39 | 10 | 71 | 6% | 2.5 | 0 (4) | 63 (11) | 0 (1) | 40 (12) | 80 (4) |
| Mine | Holder | 8 | 47 (8) | 19 | 28 | 52 | 12% | 2.9 | 0 (1) | 6 (3) | 107 (4) | 60 (4) | 36 (4) |
| Mine | Shooter | 14 | 47 (14) | 13 | 33 | 54 | 0% | 1.5 | 47 (2) | 49 (11) | 0 (1) | 34 (8) | 70 (6) |
| Mine | Support | 4 | 80 (4) | 80 | 0 | 58 | 25% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | War machine | 4 | 13 (4) | 13 | 0 | 21 | 0% | 1.0 | - | 0 (3) | 64 (1) | - | 13 (4) |
| Mine | Wizard | 9 | 14 (9) | 14 | 0 | 33 | 11% | 1.4 | 0 (3) | 12 (4) | 63 (1) | 18 (4) | 12 (4) |
| Opponent | Chaff | 31 | 76 (31) | 61 | 14 | 36 | 39% | 3.0 | 133 (12) | 63 (6) | 47 (13) | 101 (22) | 19 (9) |
| Opponent | Character | 44 | 49 (44) | 49 | 0 | 37 | 9% | 2.4 | 26 (15) | 79 (21) | 0 (1) | 31 (25) | 95 (12) |
| Opponent | Fast Hammer | 31 | 64 (31) | 45 | 18 | 41 | 16% | 2.7 | 67 (16) | 48 (8) | 77 (7) | 101 (15) | 27 (16) |
| Opponent | Hammer | 28 | 45 (28) | 45 | 0 | 36 | 29% | 3.2 | 48 (12) | 40 (13) | 63 (3) | 78 (16) | 0 (12) |
| Opponent | Holder | 15 | 99 (15) | 36 | 62 | 51 | 27% | 2.8 | 95 (4) | 118 (6) | 81 (5) | 117 (10) | 56 (5) |
| Opponent | Shooter | 16 | 34 (16) | 7 | 27 | 53 | 0% | 1.2 | 9 (2) | 37 (14) | - | 55 (8) | 15 (8) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Wizard | 15 | 8 (15) | 8 | 0 | 41 | 13% | 2.2 | 0 (4) | 25 (5) | 0 (1) | 3 (6) | 32 (4) |

### Charged fights: tk-h2h-mine-949ddcd-p3b

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 4 | 148 | 445 | 3.8 | 1.0 | 119 | 42 | +77 | 6 of 15 | 11 of 15 | - | +77 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 1161 | 5.0 | 1.2 | 232 | 55 | +177 | 1 of 5 | 4 of 5 | +141 | +186 |
| Mine | Lizardmen | 1 | 116 | 1491 | 7.0 | 1.1 | 213 | 26 | +187 | 2 of 7 | 5 of 7 | +144 | +194 |
| Mine | Ogre Kingdoms | 1 | 116 | 144 | 5.0 | 1.0 | 29 | 109 | -80 | 2 of 5 | 2 of 5 | - | -80 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 137 | 4.0 | 1.0 | 34 | 28 | +7 | 0 of 4 | 3 of 4 | - | +7 |
| Mine | Skaven | 1 | 0 | 19 | 2.0 | 1.0 | 10 | 0 | +10 | 0 of 2 | 2 of 2 | - | +10 |
| Mine | Tomb Kings of Khemri | 2 | 190 | 830 | 7.0 | 1.0 | 119 | 5 | +114 | 5 of 14 | 6 of 14 | - | +114 |
| Mine | Vampire Counts | 2 | 49 | 185 | 3.5 | 1.0 | 53 | 9 | +44 | 1 of 7 | 3 of 7 | - | +44 |
| Mine | Warriors of Chaos | 2 | 62 | 347 | 2.0 | 1.2 | 174 | 0 | +174 | 1 of 4 | 1 of 4 | +208 | +162 |
| **Mine** | all armies | 15 | 95 | 497 | 4.2 | 1.0 | 118 | 30 | +89 | 18 of 63 | 37 of 63 | +164 | +85 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 561 | 5.0 | 1.6 | 112 | 0 | +112 | 1 of 5 | 5 of 5 | +151 | +86 |
| Opponent | Tomb Kings of Khemri | 2 | 123 | 326 | 2.5 | 1.4 | 130 | 0 | +130 | 2 of 5 | 3 of 5 | +250 | +50 |
| Opponent | Vampire Counts | 2 | 0 | 558 | 4.0 | 1.1 | 140 | 59 | +80 | 4 of 8 | 4 of 8 | +0 | +92 |
| Opponent | Warriors of Chaos | 5 | 0 | 853 | 4.0 | 1.2 | 213 | 21 | +193 | 12 of 20 | 15 of 20 | +475 | +143 |
| Opponent | Wood Elf Realms | 5 | 111 | 215 | 3.2 | 1.0 | 67 | 46 | +21 | 4 of 16 | 8 of 16 | - | +21 |
| **Opponent** | all armies | 15 | 53 | 511 | 3.6 | 1.2 | 142 | 30 | +112 | 23 of 54 | 35 of 54 | +278 | +83 |

### Effective charges: tk-h2h-mine-949ddcd-p3b

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 15 | 2 (net +256) | 0 | 0 | 2 (net +52) | 2 (net +108) | 5 (net +32) | 4 | 0% (0 of 11) |
| Mine | Kingdom of Bretonnia | 5 | 1 (net +190) | 0 | 0 | 0 | 0 | 4 (net +174) | 0 | 0% (0 of 5) |
| Mine | Lizardmen | 7 | 0 | 0 | 1 (net +662) | 1 (net +0) | 0 | 3 (net +91) | 2 | 20% (1 of 5) |
| Mine | Ogre Kingdoms | 5 | 0 | 0 | 1 (net +0) | 0 | 0 | 1 (net +144) | 3 | 50% (1 of 2) |
| Mine | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 0 | 0 | 2 (net +14) | 2 | 0% (0 of 2) |
| Mine | Skaven | 2 | 0 | 0 | 1 (net +19) | 0 | 1 (net +0) | 0 | 0 | 50% (1 of 2) |
| Mine | Tomb Kings of Khemri | 14 | 3 (net -22) | 0 | 2 (net +118) | 4 (net +154) | 2 (net +153) | 3 (net +168) | 0 | 14% (2 of 14) |
| Mine | Vampire Counts | 7 | 1 (net +38) | 0 | 2 (net +126) | 3 (net +6) | 1 (net +0) | 0 | 0 | 29% (2 of 7) |
| Mine | Warriors of Chaos | 4 | 1 (net +144) | 0 | 1 (net +342) | 0 | 0 | 2 (net +104) | 0 | 25% (1 of 4) |
| Opponent | Orc & Goblin Tribes | 5 | 0 | 0 | 1 (net +0) | 1 (net +199) | 0 | 0 | 3 | 50% (1 of 2) |
| Opponent | Tomb Kings of Khemri | 5 | 0 | 0 | 0 | 2 (net +0) | 1 (net +0) | 2 (net +326) | 0 | 0% (0 of 5) |
| Opponent | Vampire Counts | 8 | 4 (net -42) | 0 | 2 (net +186) | 1 (net +195) | 0 | 1 (net +247) | 0 | 25% (2 of 8) |
| Opponent | Warriors of Chaos | 20 | 3 (net +190) | 0 | 1 (net -116) | 1 (net +0) | 0 | 13 (net +258) | 2 | 6% (1 of 18) |
| Opponent | Wood Elf Realms | 16 | 2 (net +0) | 0 | 2 (net +54) | 2 (net +241) | 0 | 3 (net +39) | 7 | 22% (2 of 9) |

### Charged fights, damage counted: tk-h2h-mine-949ddcd-p3b

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 8 | 271 | 289 | +102 | 118 | 49 | +69 | +25.5 |
| Mine | Effective (55-75%) | 8 | 184 | 156 | +189 | 243 | 4 | +239 | +129.9 |
| Mine | 76-89% | 10 | 325 | 215 | +74 | 88 | 6 | +82 | +25.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 20 | 275 | 186 | +100 | 180 | 70 | +109 | +39.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 346 | 76 | +87 | 87 | 0 | +87 | +25.2 |
| Mine | No odds | 11 | 254 | 141 | -1 | 82 | 65 | +17 | +6.8 |
| Mine | All fights | 63 | 274 | 182 | +89 | 139 | 41 | +98 | +35.9 |
| Opponent | Long shot (under 50%) | 9 | 175 | 309 | +45 | 156 | 71 | +84 | +48.2 |
| Opponent | Effective (55-75%) | 6 | 95 | 266 | +60 | 124 | 89 | +35 | +36.5 |
| Opponent | 76-89% | 7 | 330 | 238 | +125 | 125 | 6 | +119 | +36.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 19 | 344 | 225 | +230 | 274 | 21 | +253 | +73.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 265 | 66 | +0 | 0 | 32 | -32 | -12.3 |
| Opponent | No odds | 12 | 140 | 183 | +4 | 89 | 80 | +8 | +5.9 |
| Opponent | All fights | 54 | 239 | 233 | +112 | 172 | 48 | +124 | +51.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| tk-h2h-mine-949ddcd-p3b | move | 228 | 58 (25%) | 44 (19%) | 26 (11%) | 144 (63%) |
| tk-h2h-mine-949ddcd-p3b | objective | 170 | 38 (22%) | 26 (15%) | 20 (12%) | 112 (66%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2433, L2630 |
| Charmed Shield | Opponent | L1327, L2327 |
| Elixir of Power | Mine | L1932 |
| Elixir of Power | Opponent | L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Ring of Doom | Mine | L1519, L1535, L3133 |
| Ring of Doom | Opponent | L1633, L1731, L1831, L2033, L2433, L3133 |
| Standard of the Fell Warrior | Mine | L1327 |

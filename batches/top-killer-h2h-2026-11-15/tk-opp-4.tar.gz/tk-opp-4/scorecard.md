# Doctrine scorecard: tk-h2h-opp-949ddcd-p4

### Scorecard: tk-h2h-opp-949ddcd-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 6 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 4 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | yes | 5 | - | 0 | 1 | 0 | 0 | 0 | 65 |
| L0130 | 4 | 1 | Opponent | no | 1 | 1 | 9 | 1 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | no | 1 | 3 | 2 | 2 | 1 | 0 | 0 | 170 |
| L0214 | 4 | 1 | Opponent | no | 3 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 4 | 2 | 4 | 0 | 0 | 0 | 442 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | no | 3 | - | 0 | 0 | 0 | 0 | 0 | 675 |
| L0315 | 3 | 1 | Opponent | yes | 13 | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | 4 | 1 | 1 | 0 | 0 | 0 | 675 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | yes | 2 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 0 | 3 | 5 | 0 | 1 | 0 | 0 | 184 |
| L0434 | 2 | 1 | Mine | - | - | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | 3 | 0 | 1 | 0 | 0 | 0 | 1416 |
| L0520 | 4 | 1 | Opponent | no | 0 | 4 | 0 | 6 | 2 | 0 | 0 | 210 |
| L0608 | 2 | 1 | Mine | - | - | 5 | 1 | 3 | 0 | 0 | 0 | 615 |
| L0608 | 2 | 1 | Opponent | - | - | 4 | 1 | 3 | 0 | 0 | 0 | 605 |
| L0624 | 6 | 1 | Mine | no | 0 | 5 | 1 | 0 | 0 | 0 | 0 | 615 |
| L0624 | 6 | 1 | Opponent | no | 6 | 3 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | no | - | 3 | 2 | 0 | 1 | 0 | 0 | 375 |
| L0713 | 5 | 1 | Opponent | yes | - | 2 | 8 | 0 | 0 | 0 | 0 | 140 |
| L0729 | 3 | 1 | Mine | no | 9 | 2 | 2 | 0 | 0 | 0 | 0 | 452 |
| L0729 | 3 | 1 | Opponent | no | 2 | 2 | 2 | 0 | 2 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | no | 0 | 3 | 1 | 0 | 0 | 0 | 0 | 386 |
| L0819 | 3 | 1 | Opponent | yes | 4 | 2 | 0 | 2 | 2 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 617 |
| L0835 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 515 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | no | 7 | 2 | 3 | 0 | 1 | 0 | 0 | 456 |
| L1017 | 3 | 1 | Opponent | yes | 2 | 2 | 3 | 0 | 2 | 0 | 0 | 0 |
| L1034 | 2 | 1 | Mine | - | - | 1 | 2 | 0 | 1 | 0 | 0 | 664 |
| L1034 | 2 | 1 | Opponent | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1126 | 4 | 1 | Mine | no | 2 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1126 | 4 | 1 | Opponent | no | 4 | 2 | 2 | 2 | 1 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 3 | 4 | 0 | 1 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 3 | 3 | 0 | 0 | 0 | 65 |
| L1314 | 6 | 1 | Mine | no | 4 | 2 | 2 | 0 | 0 | 0 | 0 | 302 |
| L1314 | 6 | 1 | Opponent | no | 1 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1331 | 5 | 1 | Mine | no | - | 3 | 1 | 2 | 1 | 0 | 0 | 140 |
| L1331 | 5 | 1 | Opponent | yes | - | 4 | 1 | 4 | 1 | 0 | 0 | 170 |
| L1427 | 5 | 1 | Mine | yes | - | 3 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | yes | - | 2 | 7 | 0 | 1 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 2 | 6 | 0 | 0 | 0 | 0 | 66 |
| L1621 | 1 | 1 | Mine | no | 0 | 3 | 7 | 0 | 1 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 3 | - | 1 | 2 | 0 | 0 | 0 | 420 |
| L1719 | 3 | 1 | Mine | no | 2 | 2 | 6 | 0 | 2 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Opponent | yes | 5 | 2 | 5 | 0 | 0 | 0 | 0 | 156 |
| L1819 | 1 | 1 | Mine | no | 1 | 3 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 7 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | yes | - | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | yes | - | 3 | 3 | 4 | 0 | 0 | 0 | 126 |
| L2021 | 5 | 1 | Mine | yes | - | 2 | 4 | 2 | 0 | 0 | 0 | 210 |
| L2021 | 5 | 1 | Opponent | no | - | 4 | 3 | 3 | 0 | 0 | 0 | 355 |
| L2123 | 5 | 1 | Mine | yes | - | - | 2 | 5 | 0 | 0 | 0 | 500 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | no | 2 | 3 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | yes | 2 | 1 | 1 | 3 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Mine | yes | 6 | 3 | 6 | 0 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Opponent | yes | 3 | 6 | 1 | 1 | 2 | 0 | 0 | 170 |
| L2527 | 1 | 1 | Mine | no | 0 | 6 | 2 | 3 | 0 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 0 | 1 | 1 | 4 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Mine | no | 7 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 5 | 2 | 2 | 3 | 0 | 0 | 0 | 216 |
| L2930 | 2 | 1 | Mine | - | - | 2 | 6 | 1 | 0 | 0 | 0 | 323 |
| L2930 | 2 | 1 | Opponent | - | - | 2 | 6 | 3 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 1 | 2 | 4 | 3 | 0 | 0 | 0 | 170 |
| L3234 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 29% | 2.8 | 2.8 | 2.7 | 1.0 | 0.3 | 0.0 | 0.0 | 295.6 |
| **Average** | | | Opponent | 46% | 3.1 | 2.3 | 3.0 | 1.8 | 0.5 | 0.0 | 0.0 | 84.8 |

### KPIs: tk-h2h-opp-949ddcd-p4

Rules off - Mine only: STAY WORTH, BEST MOVE FOR SHOOTERS, THREAT IN THE KILL, FOCUS OVER TURNS, MISSILES IN THE PLAN, FACE THE CAST, WIZARD FRONT RANK, THREAT OVER THE TURNS, THREAT TO WORN DOWN.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 24% (41 of 170) | 2% (4 of 177) | 13% (45 of 347) |
| Winner chose to follow up after the loser gave ground |  | 92% (68 of 74); on the table 93% | 91% (52 of 57); on the table 96% | 92% (120 of 131); on the table 95% |
| Winner chose to pursue after the loser fell back in good order |  | 69% (9 of 13); on the table 77% | 100% (17 of 17); on the table 100% | 87% (26 of 30); on the table 90% |
| Winner chose to pursue after the loser fled |  | 73% (19 of 26); on the table 85% | 90% (26 of 29); on the table 90% | 82% (45 of 55); on the table 87% |
| Winner chose to follow up or pursue (all three) |  | 85% (96 of 113); on the table 89% | 92% (95 of 103); on the table 95% | 88% (191 of 216); on the table 92% |
| Magic missiles tried each own turn | 50%+ | 26% (69 of 269) | 32% (54 of 170) | 28% (123 of 439) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 42% (69 of 164) | 46% (54 of 118) | 44% (123 of 282) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 24% (32 of 136) | 32% (27 of 85) | 27% (59 of 221) |
|     round 1 |  | 17% (4 of 23) | 14% (2 of 14) | 16% (6 of 37) |
|     rounds 2+ |  | 25% (28 of 113) | 35% (25 of 71) | 29% (53 of 184) |
|   other wizards | 50%+ | 28% (37 of 133) | 28% (22 of 80) | 28% (59 of 213) |
|     round 1 |  | 13% (3 of 23) | 36% (5 of 14) | 22% (8 of 37) |
|     rounds 2+ |  | 31% (34 of 110) | 26% (17 of 66) | 29% (51 of 176) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 65% (26 of 40) | 68% (44 of 65) | 67% (70 of 105) |
| Points that never fought | lower | 29% (20019 of 67942) | 31% (22151 of 71984) | 30% (42170 of 139926) |
|   infantry points that never fought | lower | 42% (6498 of 15347) | 54% (7523 of 13804) | 48% (14021 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% (164 of 270) | 54% (152 of 280) | 57% (316 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 86% (19 of 22); 1.1 uses a game | 78% (7 of 9); 0.6 uses a game | 84% (26 of 31); 0.8 uses a game |
| Bound items with another spell used |  | 56% (9 of 16); 0.4 uses a game | 50% (10 of 20); 0.6 uses a game | 53% (19 of 36); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 58% (11 of 19); 0.3 uses a game | 80% (12 of 15); 0.4 uses a game | 68% (23 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 55% (31713 of 57750) | 46% (29073 of 63347) | 50% (60786 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.5 (26%) | 0.8 (25%) | 2.3 (26%) |
| MARCHED: its unit marched | 1.0 (18%) | 0.6 (20%) | 1.7 (19%) |
| CHARGED: its unit charged | 0.1 (2%) | 0.2 (6%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.6 (28%) | 0.7 (22%) | 2.3 (26%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| GONE: slain | 1.2 (22%) | 0.7 (22%) | 1.9 (22%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.8 | 1.5 | 1.7 | 3.4 | 0.4 | 2.5 |
| not cast | 2.4 | 2.4 | 3.1 | 8.8 | 1.6 | 20.5 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.6 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.1 (45%) | 0.2 (7%) | 2.3 (26%) | 0.2 (15%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (19%) | 0.3 (20%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.2 (8%) | 0.7 (21%) | 2.3 (26%) | 0.4 (27%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.1 (5%) | 0.1 (5%) | 0.2 (5%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.4 (2%) |
| GONE: slain | 0.6 (23%) | 0.7 (29%) | 0.5 (16%) | 1.9 (22%) | 0.2 (15%) | 3.2 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.2 (5%) | 0.1 (1%) | 0.1 (3%) | 0.5 (3%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.2 (8%) | 0.0 (1%) | 0.1 (1%) | 0.3 (17%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.6 (66%) | 0.1 (6%) | 1.4 (44%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.5 (71%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.2 a game | 0.6 a game | 0.9 a game |
| stood (cast and not dispelled) | 75% (27 of 36) | 67% (8 of 12) | 73% (35 of 48) |
| the unit moved after it | 63% (17 of 27) | 88% (7 of 8) | 69% (24 of 35) |
| it charged on its next turn | 7% (2 of 27) | 0% (0 of 8) | 6% (2 of 35) |
| the enemy charged it first | 30% (8 of 27) | 0% (0 of 8) | 23% (8 of 35) |
| it fought by the end of its next turn | 26% (7 of 27) | 12% (1 of 8) | 23% (8 of 35) |
| it moved out of a charge the enemy had planned (not charged first) | 15% (4 of 27) | 0% (0 of 8) | 11% (4 of 35) |
| none of these (no charge, no fight, no charge escaped) | 41% (11 of 27) | 88% (7 of 8) | 51% (18 of 35) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (564 of 875) | 57% (308 of 543) | 61% (872 of 1418) |
|   cavalry | 70% (54 of 77) | 74% (88 of 119) | 72% (142 of 196) |
|   character | 42% (41 of 97) | 14% (19 of 132) | 26% (60 of 229) |
|   chariot | 55% (58 of 106) | 74% (20 of 27) | 59% (78 of 133) |
|   infantry | 60% (167 of 278) | 68% (147 of 216) | 64% (314 of 494) |
|   monster | 44% (18 of 41) | 46% (11 of 24) | 45% (29 of 65) |
|   war machine | 82% (226 of 276) | 92% (23 of 25) | 83% (249 of 301) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (27%) | 1.2 (18%) | 3.5 (23%) |
| CHARGED: it charged | 1.4 (17%) | 1.8 (28%) | 3.3 (22%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.8 (9%) | 0.5 (8%) | 1.2 (8%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.7 (20%) | 1.2 (18%) | 2.9 (19%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (6%) | 0.5 (7%) | 1.0 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.1 (13%) | 1.2 (18%) | 2.3 (15%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.1 (1%) | 0.3 (2%) |
| OTHER BAR | 0.3 (4%) | 0.0 (0%) | 0.4 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.4 | 1.6 | 80% | 5.6 pts | 35 pts |
| character | 1.9 | 0.6 | 79% | 7.3 pts | 14 pts |
| chariot | 2.2 | 1.0 | 66% | 12.0 pts | 27 pts |
| infantry | 12.6 | 4.2 | 76% | 8.4 pts | 106 pts |
| monster | 0.9 | 0.1 | 94% | 0.9 pts | 1 pts |
| war machine | 6.9 | 5.4 | 66% | 26.2 pts | 182 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.6 | 6.2 | 5.4 |
| Charges that made contact a game | 3.7 | 4.7 | 4.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.94 declared, 0.88 contact (17 units) | 0.81 declared, 0.50 contact (16 units) | 0.88 declared, 0.70 contact (33 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.60 declared, 1.10 contact (10 units) | 0.88 declared, 0.75 contact (8 units) | 1.28 declared, 0.94 contact (18 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.54 declared, 0.43 contact (249 units) | 0.69 declared, 0.52 contact (297 units) | 0.62 declared, 0.48 contact (546 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 52% (42 of 81) | 56% (9 of 16) | 50% (3 of 6) | 52% (54 of 103) |
| Character in a unit | 73% (19 of 26) | 60% (9 of 15) | 100% (1 of 1) | 69% (29 of 42) |
| Character on its own | 85% (33 of 39) | 52% (14 of 27) | 26% (20 of 77) | 47% (67 of 143) |
| Chariot | 93% (14 of 15) | 58% (7 of 12) | - | 78% (21 of 27) |
| Infantry | 59% (49 of 83) | 40% (10 of 25) | 33% (2 of 6) | 54% (61 of 114) |
| Monster | 62% (21 of 34) | 79% (11 of 14) | - | 67% (32 of 48) |
| Monstrous | 79% (11 of 14) | 57% (8 of 14) | - | 68% (19 of 28) |
| War Machines | 74% (32 of 43) | 50% (1 of 2) | - | 73% (33 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (15 of 15); on the table 100% | 25% (25 of 102) | 17% | 50% (11 of 22) | 83% (5 of 6); 1.8 uses a game | 50% (1 of 2); 0.8 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 83% (10 of 12); on the table 92% | 42% (10 of 24) | 35% | 44% (14 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 86% (6 of 7); on the table 86% | - | 74% | 67% (18 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 88% (7 of 8); on the table 100% | 39% (7 of 18) | 45% | 68% (42 of 62) | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game | 80% (4 of 5); 0.7 uses a game |
| Grand Cathay | 4 | 86% (6 of 7); on the table 86% | 25% (21 of 84) | 23% | 46% (17 of 37) | 89% (8 of 9); 5.0 uses a game | 50% (1 of 2); 0.5 uses a game | 25% (1 of 4); 0.2 uses a game |
| High Elf Realms | 9 | 88% (28 of 32); on the table 88% | 17% (6 of 36) | 23% | 54% (38 of 70) | 100% (7 of 7); 2.0 uses a game | 50% (15 of 30); 2.9 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (2 of 2); on the table 100% | - | 15% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 90% (9 of 10); on the table 100% | 50% (3 of 6) | 25% | 62% (13 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 67% (8 of 12); on the table 83% | 50% (3 of 6) | 21% | 86% (12 of 14) | 50% (1 of 2); 0.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (12 of 12); on the table 100% | 14% (6 of 42) | 31% | 46% (11 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 6 | 92% (11 of 12); on the table 100% | 29% (12 of 41) | 35% | 67% (30 of 45) | 100% (3 of 3); 0.7 uses a game | 0.0 uses a game | 67% (4 of 6); 0.8 uses a game |
| Tomb Kings of Khemri | 4 | 88% (14 of 16); on the table 88% | 17% (1 of 6) | 24% | 35% (7 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 80% (16 of 20); on the table 90% | 36% (20 of 56) | 23% | 55% (23 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 93% (27 of 29); on the table 93% | 33% (4 of 12) | 26% | 61% (44 of 72) | 50% (1 of 2); 0.6 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 91% (20 of 22); on the table 91% | 83% (5 of 6) | 34% | 59% (33 of 56) | 50% (1 of 2); 0.7 uses a game | 0.0 uses a game | 75% (3 of 4); 0.5 uses a game |

Flank and rear charges a unit could have turned to face (tk-h2h-opp-949ddcd-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 43% (43) | 44% (35) | 44% (78) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.50 | 1.17 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.19 | 0.25 | 0.44 |
| ...with the charger already in that arc before they moved (per game) | 0.47 | 0.33 | 0.81 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.75 | 1.33 | 3.08 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.25 | 0.47 | 1.72 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 4.92 | 6.53 | 11.44 |

### Quality by phase: tk-h2h-opp-949ddcd-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 51% (87 of 170) | 44% (89 of 201) |
| Strategy | Shoot objectives carried out (shot that target) | 46% (170 of 367) | 49% (76 of 154) |
| Strategy | Close-in objectives charged next turn | 13% (22 of 166) | 17% (34 of 198) |
| Strategy | Support requests answered (helper made contact too) | 68% (13 of 19) | 34% (10 of 29) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 64% (9 of 14) | 33% (3 of 9) |
| Strategy | Joined characters whose unit fought | 55% (18 of 33) | 37% (11 of 30) |
| Strategy | Lone characters that fought | 80% (72 of 90) | 80% (69 of 86) |
| Movement | Charges halted short of contact | 0.2 | 0.2 |
| Movement | Idle units | 1.0 | 1.8 |
| Movement | Points that never moved of their own | 295.6 | 84.8 |
| Movement | Fights charged into per game | 3.4 | 3.9 |
| Movement | Charges with odds: long shots (under 50%) | 13 of 110, net +25 | 21 of 119, net +16 |
| Movement | Charges with odds: sweet spot (55-75%) | 18 of 110, net -63 | 24 of 119, net +48 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 13 of 110, net +44 | 11 of 119, net +69 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 34 of 110, net +73 | 38 of 119, net +154 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.4 | 9.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 49% (181 of 373) | 42% (138 of 328) |
| Shooting | Points destroyed by shooting units | 101.4 | 21.4 |
| Shooting | War machine shots | 6.3 | 0.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 56% (126 of 226) | 13% (3 of 23) |
| Shooting | Points destroyed by war machines | 49.1 | 23.2 |
| Magic | Magic missiles cast | 1.2 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 36% (16 of 44) | 23% (9 of 39) |
| Magic | Wounds caused by magic missiles | 2.6 | 1.3 |
| Magic | Wounds caused by other spells | 2.0 | 1.5 |
| Magic | Points destroyed by magic (all spells) | 82.3 | 43.8 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.5 / 1.0 / 0.1 | 2.1 / 0.6 / 0.7 / 0.1 |
| Combat | Points destroyed in combat | 410.3 | 516.5 |
| Combat | Points run down | 100.2 | 152.0 |
| Combat | Net points per charged fight, damage counted | +38 | +81 |
| Combat | Net per 100 charger points, damage counted | +13.6 | +24.0 |
| Combat | First round won (charged fights) | 73% | 70% |
| Combat | Net points per charged fight | +33 | +81 |
| Combat | Net points per supported fight / lone fight | -53 / +46 | +161 / +64 |
| Combat | Charged fights on a top-3 enemy unit | 44 of 122 | 68 of 139 |
| Game | Points lost | 864.3 | 757.9 |
| Game | VP from objectives | 518.9 | 555.3 |
| Game | Lone holders (player turns) | 2.8 | 3.1 |

- Mine won / drew / lost: 12 / 10 / 14 of 36 ended games (of 36); mean margin (Mine - Opponent) -143 VP
- The side that went first won 14 of 26 games with a winner
- Points traded per game (both sides' losses): 1622
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: tk-h2h-opp-949ddcd-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 1.2 | +0.0 | 0.0 | 13.8 | 0.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.9 | +6.1 | 0.0 | 9.1 | 1.1 | +9.7 | 0.0 | 28.8 |
| BEST FACING | 0.8 | +30.3 | 0.0 | 14.4 | 0.7 | +38.1 | 0.0 | 31.4 |
| BEST FIRST | 3.7 | +153.2 | 149.9 | 110.0 | 4.1 | +181.6 | 98.9 | 51.6 |
| BEST MOVE FOR SHOOTERS | - | - | - | - | 0.8 | +59.8 | 0.0 | 13.0 |
| BEST OVERALL | 0.6 | +45.9 | 0.0 | 13.1 | 0.4 | +24.8 | 0.0 | 18.6 |
| BEST PREY | 0.6 | +36.3 | 19.1 | 15.3 | 0.8 | +39.9 | 9.3 | 14.2 |
| BEST PRIZE | 0.1 | -0.6 | 4.0 | 0.0 | 0.1 | +8.7 | 11.3 | 4.8 |
| BIG CHARACTER SAFETY | 0.2 | -0.4 | 0.0 | 0.0 | 0.2 | -0.2 | 0.0 | 13.7 |
| BLOCKED CHARGE SKIPPED | 0.2 | +0.0 | 5.1 | 0.0 | 0.2 | +0.0 | 1.4 | 21.8 |
| BLOCKED WHEEL | 0.5 | +3.2 | 0.0 | 4.9 | 0.5 | +22.8 | 0.0 | 0.0 |
| BOMBING RUN | 0.0 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 7.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.6 | +0.0 | 113.1 | 26.0 | 0.0 | +0.0 | 2.8 | 0.0 |
| CANNON PLANNED TARGET | 4.9 | +250.2 | 402.2 | 79.4 | 0.6 | +26.4 | 46.8 | 7.4 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.0 | +0.0 | 0.0 | 5.1 | 0.1 | -2.1 | 0.0 | 0.0 |
| CAST JOB | 0.6 | +33.1 | 32.8 | 23.1 | 0.3 | +10.1 | 12.3 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +33.2 | 16.7 | 0.0 | 0.1 | +5.5 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.9 | +0.0 | 0.0 | 30.1 | 0.3 | +0.0 | 0.0 | 31.0 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | - | - | - | - | 0.0 | +0.3 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | -0.6 | 8.9 | 11.8 | 0.1 | -0.6 | 0.0 | 0.0 |
| CHAMPION TAKES THE CHALLENGE | 0.0 | +0.0 | 11.3 | 0.0 | - | - | - | - |
| CHARGE NOW FIRST | 2.9 | +0.0 | 270.5 | 156.1 | 3.2 | +0.0 | 351.3 | 149.6 |
| CHARGE NOW WEIGHED | 0.5 | -34.7 | 1.5 | 17.4 | 0.3 | -44.3 | 18.4 | 24.6 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.2 | -2.8 | 13.9 | 13.9 | 0.2 | -3.7 | 0.0 | 0.0 |
| CHEAP HELPER | 0.2 | +0.0 | 9.4 | 5.1 | 0.1 | +0.0 | 7.8 | 0.8 |
| COMBAT PIVOT | 0.6 | +0.0 | 18.1 | 53.6 | 0.5 | +0.0 | 37.3 | 51.4 |
| CONVEYANCE SEARCH | 0.8 | +118.1 | 13.9 | 32.5 | 0.2 | +42.4 | 0.0 | 0.0 |
| COUNTER-CHARGE COVER | 8.3 | +590.3 | 0.0 | 175.1 | 7.5 | +648.6 | 0.0 | 160.4 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 13.7 | 3.5 | 0.0 | +0.0 | 1.2 | 0.0 |
| DEFENSIVE FLOOR | 0.1 | +0.9 | 2.7 | 1.8 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +10.7 | 3.4 | 0.0 | 0.3 | +12.8 | 36.0 | 1.2 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +1.3 | 0.0 | 9.7 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACE THE CAST | - | - | - | - | 0.0 | +0.8 | 0.0 | 0.0 |
| FACES THE THREAT | 1.8 | +156.2 | 0.0 | 46.1 | 1.3 | +96.3 | 0.0 | 46.7 |
| FALLBACK BY WORTH | 4.6 | +45.8 | 0.0 | 67.3 | 6.2 | +46.8 | 0.0 | 73.1 |
| FIGHT LIFT | 0.1 | +0.6 | 18.7 | 0.0 | - | - | - | - |
| FIRE AND FLEE | - | - | - | - | 0.0 | +0.5 | 0.0 | 0.0 |
| FLANK NOT WEIGHED | 4.7 | +0.0 | 0.0 | 124.2 | 6.2 | +0.0 | 0.0 | 150.1 |
| FOCUS FIRE | - | - | - | - | 0.1 | +0.8 | 1.2 | 0.0 |
| FOCUS OVER TURNS | - | - | - | - | 0.6 | +21.6 | 20.8 | 7.2 |
| FOLLOW UP WEIGHED | 1.1 | +191.9 | 0.0 | 78.3 | 1.1 | +161.1 | 0.0 | 24.7 |
| FRIENDS SHOTS CHECKED | 0.3 | +9.7 | 0.0 | 7.8 | 0.2 | +21.9 | 0.0 | 17.4 |
| GIVES UP | 0.1 | -1.2 | 13.3 | 0.0 | 0.1 | -3.5 | 20.3 | 15.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -0.1 | 3.4 | 0.0 |
| GROUND FLIERS | 0.0 | +1.4 | 0.0 | 0.0 | 0.1 | +1.9 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 4.6 | 1.7 |
| HELPER UNSEEN | 0.3 | +0.0 | 25.7 | 51.4 | 0.4 | +0.0 | 21.1 | 0.0 |
| HILL BY ITS CHANCE | 0.8 | -75.8 | 0.0 | 8.1 | 0.5 | -36.5 | 0.0 | 15.2 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.0 | +0.0 | 0.0 | 1.5 | 0.1 | +6.7 | 0.0 | 6.2 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HUNT IN PAIRS | 0.2 | +9.5 | 0.0 | 0.0 | 0.7 | +30.6 | 0.0 | 13.2 |
| HUNT KEPT | - | - | - | - | 0.1 | +7.8 | 6.9 | 3.1 |
| HUNT RESULT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +11.5 | 21.2 | 3.1 |
| HUNT THE GUNS | 0.1 | +29.7 | 0.0 | 1.5 | 0.1 | +54.0 | 21.2 | 3.9 |
| INVITES THE FIGHT | 1.6 | +29.9 | 54.6 | 4.8 | 1.4 | +22.3 | 62.6 | 27.3 |
| JOINT CHARGE PLAN | 0.2 | +2.8 | 0.0 | 0.0 | 0.2 | +18.9 | 13.7 | 0.0 |
| KEEP FALLS | 0.1 | +3.0 | 0.0 | 0.0 | 0.1 | +0.2 | 0.0 | 3.2 |
| KEEPS ITS PREY | 0.0 | +0.1 | 0.0 | 0.0 | 0.1 | +0.2 | 0.0 | 3.1 |
| KEEPS ITS TARGET | 1.6 | +47.5 | 88.6 | 31.2 | 2.2 | +65.0 | 238.9 | 57.6 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 2.2 | +84.3 | 201.3 | 73.4 | 2.1 | +112.8 | 216.2 | 48.5 |
| KILLS COUNT NEXT TURN | 5.3 | +182.4 | 116.2 | 138.4 | 6.5 | +252.3 | 252.1 | 115.8 |
| LONE CHARACTER SAFE SPOT | 0.3 | +10.0 | 9.8 | 25.4 | 0.1 | +0.0 | 6.6 | 0.0 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 10.7 |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| LONG SHOT | 0.7 | -8.5 | 55.1 | 25.4 | 0.6 | -0.3 | 43.3 | 5.4 |
| LOST CHARGE | 2.7 | -36.2 | 60.0 | 92.9 | 2.3 | -42.4 | 54.4 | 39.6 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.1 | -8.8 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.4 | +35.9 | 0.0 | 33.0 | 0.5 | +126.4 | 32.6 | 16.1 |
| MANOEUVRE | 0.3 | +11.5 | 0.0 | 1.8 | 0.1 | +3.6 | 0.0 | 6.2 |
| MARCH AT ESCAPER | 0.1 | +1.3 | 0.0 | 0.0 | 0.0 | +1.2 | 0.0 | 0.0 |
| MARCH CHECK | 0.5 | +25.1 | 0.0 | 10.2 | 0.2 | +5.5 | 0.0 | 10.7 |
| MARCH ODDS | 0.3 | +17.2 | 12.3 | 4.6 | 0.2 | +21.5 | 8.1 | 0.0 |
| MARCH OVER CASTS | 0.3 | +21.8 | 0.0 | 13.9 | 0.4 | +23.9 | 0.0 | 5.4 |
| MAX FOR POSITIONING | 4.5 | +152.1 | 0.0 | 101.0 | 5.1 | +183.1 | 0.0 | 113.0 |
| MISSILES IN THE MOVE | 3.4 | +127.9 | 0.0 | 87.4 | 2.2 | +53.6 | 0.0 | 36.8 |
| MISSILES IN THE PLAN | - | - | - | - | 0.1 | +3.0 | 5.4 | 0.0 |
| MISSILES NEXT TURN | 4.2 | +83.8 | 0.0 | 125.5 | 3.0 | +38.6 | 0.0 | 42.2 |
| MODEL FACING | 0.1 | +10.0 | 0.0 | 3.3 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.3 | +0.0 | 9.1 | 20.5 | 0.2 | +0.0 | 14.2 | 0.0 |
| MOVE AND CAST | 0.1 | +3.0 | 0.0 | 6.5 | 0.3 | +16.3 | 0.0 | 16.5 |
| MOVE SPELL IN RANGE | 0.3 | +6.6 | 0.0 | 4.7 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.6 | -27.6 | 10.1 | 0.0 | 0.1 | -7.3 | 16.6 | 0.0 |
| MOVE SPELL SPOT | 0.6 | +0.0 | 0.0 | 26.2 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 3.4 | +151.3 | 59.9 | 94.0 | 3.8 | +304.9 | 187.4 | 62.1 |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +5.0 | 0.0 | 0.0 | 0.1 | +6.4 | 9.5 | 0.0 |
| NO RALLY LEFT | 0.0 | +6.1 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.4 | -12.7 | 39.6 | 6.1 | 0.2 | -14.0 | 41.5 | 0.0 |
| NOT TURNED | 4.9 | +54.9 | 0.0 | 97.0 | 6.5 | +81.3 | 0.0 | 124.1 |
| NOT WORTH A CAST | 0.8 | -0.5 | 0.0 | 13.9 | 0.2 | -0.1 | 0.0 | 11.0 |
| OFF BEST | 14.7 | -717.7 | 15.1 | 282.0 | 13.5 | -718.7 | 1.7 | 190.7 |
| OPENS A LANE | 0.1 | +0.1 | 8.2 | 0.0 | 0.2 | +1.0 | 34.9 | 0.0 |
| OPENS UP | 0.4 | +30.6 | 26.1 | 13.1 | 0.3 | +33.2 | 26.6 | 25.4 |
| OVERRUNS AWAY | 0.5 | +5.9 | 47.3 | 13.1 | 0.7 | +15.9 | 60.5 | 44.0 |
| PATHS CROSS | 2.4 | +169.7 | 0.0 | 27.8 | 3.3 | +277.1 | 0.0 | 48.0 |
| PERIAPT WORTH | 0.1 | +6.8 | 0.0 | 15.0 | 0.1 | +9.7 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -0.6 | 0.0 | 0.0 | 0.1 | -1.4 | 0.0 | 1.5 |
| PLAN RESULT | 37.6 | +1475.0 | 1470.8 | 1179.8 | 39.4 | +1316.4 | 1618.0 | 1147.9 |
| PURSUES BIG PREY | 0.1 | -6.0 | 0.0 | 0.0 | 0.2 | -18.3 | 0.0 | 5.4 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.0 | +4.9 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +6.3 | 0.0 | 2.2 | 0.2 | +20.6 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 1.1 | +17.2 | 0.0 | 38.6 | 1.8 | +26.6 | 0.0 | 55.0 |
| RANDOM MOVER NO PROMISE | 0.5 | -26.2 | 20.5 | 0.0 | 0.2 | -21.1 | 0.0 | 4.0 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -0.4 | 0.0 | 2.0 | 0.5 | -8.6 | 0.0 | 14.6 |
| REDIRECT COUNTER | 2.1 | +120.4 | 0.0 | 26.8 | 3.9 | +294.3 | 0.0 | 56.6 |
| REDIRECT WEIGHED | 0.1 | +7.8 | 10.7 | 13.9 | 0.4 | +31.8 | 30.8 | 38.6 |
| RESERVE FALL BACK | 0.7 | +31.9 | 0.0 | 16.4 | 0.6 | +32.6 | 0.0 | 6.6 |
| RESTRAINS TO SHOOT | 0.2 | +10.7 | 0.0 | 15.2 | 0.1 | +3.9 | 0.0 | 4.5 |
| RISK BY ARC | 3.0 | +155.1 | 256.6 | 126.3 | 3.0 | +44.5 | 280.3 | 143.9 |
| SAFER THAN THE JOB | 1.2 | +91.0 | 0.0 | 44.0 | 0.5 | +38.1 | 0.0 | 8.3 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 3.7 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 3.7 |
| SCREEN BY WHAT IT SAVES | 0.0 | -1.3 | 0.0 | 0.0 | 0.2 | -14.5 | 0.0 | 0.8 |
| SEARCH SPOT | 2.4 | +87.1 | 0.0 | 22.8 | 3.6 | +150.1 | 0.0 | 41.0 |
| SELF MOVE SPELL | 0.2 | +52.0 | 0.0 | 0.0 | 0.4 | +15.1 | 0.0 | 58.2 |
| SET UP TOGETHER | 0.6 | +52.5 | 0.0 | 34.5 | 1.2 | +171.9 | 59.1 | 41.1 |
| SET-UP ANY TARGET | 0.5 | +78.2 | 13.9 | 18.6 | 0.1 | +12.6 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +14.0 | 2.5 | 2.4 | 0.0 | +2.6 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.6 | +28.0 | 36.7 | 6.3 | 0.6 | +17.8 | 63.1 | 22.3 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 3.8 |
| SHOT OPTIONS | 15.9 | +0.0 | 770.2 | 293.4 | 9.0 | +0.0 | 261.0 | 182.8 |
| SHOT REPLANNED | 0.5 | +0.0 | 126.4 | 13.1 | 0.2 | +0.0 | 25.6 | 9.0 |
| SHOTS IN THE MOVE | 14.6 | +813.3 | 0.0 | 254.8 | 7.7 | +195.2 | 0.0 | 144.7 |
| SPELL SETS UP CHARGE | 0.5 | +78.2 | 13.9 | 18.6 | 0.1 | +12.6 | 0.0 | 0.0 |
| SPELL WORTH | 1.4 | +24.7 | 66.6 | 76.4 | 2.7 | +51.9 | 15.0 | 15.0 |
| STABLE ROLE | 10.2 | +0.0 | 333.7 | 220.1 | 10.3 | +0.0 | 358.9 | 141.9 |
| STAY WEIGHED | 0.0 | +4.4 | 0.0 | 0.0 | - | - | - | - |
| STAY WORTH | - | - | - | - | 10.0 | +169.3 | 203.6 | 140.9 |
| STOPS | 0.0 | +0.3 | 0.0 | 0.0 | 0.1 | +5.6 | 28.2 | 0.8 |
| STOPS SHORT OF THE FLANK | 0.5 | +17.9 | 0.0 | 5.1 | 0.3 | +7.4 | 0.0 | 13.7 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 5.8 |
| SUPPORT JOB KEPT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT NARROWED | 5.6 | -45.1 | 308.8 | 101.3 | 8.3 | -66.5 | 450.4 | 139.9 |
| SUPPORTS | 3.4 | +50.7 | 120.6 | 38.7 | 5.7 | +66.5 | 192.0 | 65.1 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -2.7 | 3.4 | 11.9 | 0.1 | -6.8 | 8.9 | 0.0 |
| SURE REACH TOGETHER | 0.4 | +0.4 | 0.0 | 19.4 | 0.3 | +0.7 | 0.0 | 7.9 |
| THREAT IN THE KILL | - | - | - | - | 5.7 | +35.4 | 222.0 | 118.7 |
| THREAT OVER THE TURNS | - | - | - | - | 4.7 | +26.6 | 205.9 | 81.8 |
| THREAT TO WORN DOWN | - | - | - | - | 5.6 | +42.4 | 222.0 | 118.7 |
| THROUGH LINE OF FIRE | 0.4 | +19.2 | 0.0 | 17.6 | 0.2 | +12.8 | 0.0 | 5.6 |
| TURN WORTH | 0.6 | -43.5 | 53.1 | 4.7 | 0.7 | -65.3 | 62.7 | 27.4 |
| TWO OR MORE ARRIVE | 0.3 | +1.5 | 0.0 | 18.2 | 0.4 | +4.5 | 24.2 | 0.0 |
| WAIT AFTER COSTS | 6.9 | -271.1 | 156.2 | 142.7 | 7.0 | -339.7 | 338.2 | 126.2 |
| WALKS TO THE FIGHT | 1.7 | +31.1 | 27.3 | 38.7 | 0.9 | +18.4 | 25.8 | 4.9 |
| WAR ENGINE CHARGES | 0.1 | +10.3 | 8.5 | 18.9 | 0.0 | +1.5 | 0.0 | 2.1 |
| WAR ENGINE JOBS | 0.8 | +0.0 | 38.3 | 14.4 | 0.1 | +0.0 | 2.2 | 0.0 |
| WEARS DOWN | 1.3 | +51.1 | 108.8 | 82.0 | 1.5 | +43.8 | 125.8 | 98.8 |
| WHO HITS BACK | 0.3 | +23.9 | 0.0 | 1.4 | 0.4 | +22.0 | 0.0 | 15.5 |
| WHOLE FIGHT | 0.4 | +22.6 | 49.9 | 6.9 | 0.3 | +6.2 | 39.2 | 3.3 |
| WHOLE FIGHT GAIN | 0.3 | +25.8 | 34.2 | 13.2 | 0.7 | +57.7 | 44.4 | 10.2 |
| WIZARD FRONT RANK | - | - | - | - | 0.0 | +0.0 | 0.0 | 4.3 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 0.0 | 16.6 |

### Rule changes: tk-h2h-opp-949ddcd-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1013 | 1013 | 1013 | 28.14 | -51713 | -51.0 |
| BEST FIRST | 282 | 282 | 282 | 7.83 | +12056 | +42.8 |
| SEARCH SPOT | 217 | 217 | 213 | 5.92 | +8545 | +40.1 |
| PATHS CROSS | 206 | 206 | 206 | 5.72 | +16084 | +78.1 |
| COUNTER-CHARGE COVER | 568 | 324 | 165 | 4.58 | +9415 | +57.1 |
| MOVE TO CHARGE | 260 | 260 | 133 | 3.69 | +7212 | +54.2 |
| KILLS COUNT NEXT TURN | 425 | 425 | 115 | 3.19 | +4129 | +35.9 |
| FACES THE THREAT | 111 | 111 | 111 | 3.08 | +9092 | +81.9 |
| SUPPORTS | 328 | 328 | 111 | 3.08 | +1234 | +11.1 |
| FOLLOW UP WEIGHED | 82 | 82 | 82 | 2.28 | +12707 | +155.0 |
| SHOTS IN THE MOVE | 802 | 541 | 80 | 2.22 | +2999 | +37.5 |
| FALLBACK BY WORTH | 389 | 389 | 73 | 2.03 | +3334 | +45.7 |
| RANDOM MOVE BY FIGURES | 105 | 105 | 70 | 1.94 | +1578 | +22.5 |
| SAFER THAN THE JOB | 62 | 62 | 62 | 1.72 | +4650 | +75.0 |
| WAIT AFTER COSTS | 500 | 500 | 59 | 1.64 | +821 | +13.9 |
| CHARGE NOW FIRST | 219 | 219 | 56 | 1.56 | -2996 | -53.5 |
| ADVANCE LANE KEPT | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| WALKS TO THE FIGHT | 93 | 93 | 55 | 1.53 | +793 | +14.4 |
| BEST FACING | 53 | 53 | 53 | 1.47 | +2464 | +46.5 |
| RISK BY ARC | 218 | 214 | 53 | 1.47 | +2322 | +43.8 |
| REDIRECT COUNTER | 218 | 134 | 51 | 1.42 | +4260 | +83.5 |
| RESERVE FALL BACK | 48 | 48 | 48 | 1.33 | +2322 | +48.4 |
| MAX FOR POSITIONING | 348 | 202 | 47 | 1.31 | +557 | +11.9 |
| ARTILLERY RE-ROLL WEIGHED | 46 | 46 | 46 | 1.28 | +0 | +0.0 |
| CANNON SIGHT KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| KILLS COUNT | 158 | 154 | 39 | 1.08 | +1696 | +43.5 |
| COMBAT PIVOT | 38 | 38 | 38 | 1.06 | +0 | +0.0 |
| BEST OVERALL | 36 | 36 | 36 | 1.00 | +2544 | +70.7 |
| BLOCKED WHEEL | 36 | 36 | 36 | 1.00 | +936 | +26.0 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| CANNON PLANNED TARGET | 199 | 199 | 32 | 0.89 | -351 | -11.0 |
| STAY WORTH | 360 | 288 | 32 | 0.89 | +466 | +14.6 |
| MISSILES IN THE MOVE | 203 | 126 | 30 | 0.83 | +828 | +27.6 |
| CHARGE NOW WEIGHED | 29 | 29 | 29 | 0.81 | +2638 | +91.0 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| SHOT REPLANNED | 28 | 28 | 28 | 0.78 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 28 | 28 | 28 | 0.78 | +910 | +32.5 |
| BEST MOVE FOR SHOOTERS | 27 | 27 | 27 | 0.75 | +2154 | +79.8 |
| SET UP TOGETHER | 68 | 58 | 27 | 0.75 | +3367 | +124.7 |
| WHO HITS BACK | 24 | 24 | 24 | 0.67 | +1055 | +44.0 |
| INVITES THE FIGHT | 105 | 105 | 23 | 0.64 | +350 | +15.2 |
| KEEPS ITS TARGET | 135 | 134 | 23 | 0.64 | +400 | +17.4 |
| MARCH CHECK | 27 | 26 | 23 | 0.64 | +1075 | +46.7 |
| THROUGH LINE OF FIRE | 23 | 23 | 23 | 0.64 | +1153 | +50.1 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 35 | 32 | 21 | 0.58 | +1021 | +48.6 |
| REDIRECT WEIGHED | 20 | 20 | 20 | 0.56 | +774 | +38.7 |
| FRIENDS SHOTS CHECKED | 19 | 19 | 19 | 0.53 | +1138 | +59.9 |
| MARCH ODDS | 19 | 19 | 19 | 0.53 | +394 | +20.7 |
| WEARS DOWN | 102 | 99 | 19 | 0.53 | +328 | +17.3 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +41 | +2.3 |
| SHOOTS FROM THE BEST SPOT | 44 | 44 | 18 | 0.50 | +478 | +26.6 |
| CASTER AWAY FROM SCREEN | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| MOVE AND CAST | 16 | 16 | 16 | 0.44 | +694 | +43.4 |
| THREAT TO WORN DOWN | 202 | 181 | 15 | 0.42 | +69 | +4.6 |
| BLOCKED CHARGE SKIPPED | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| CAST JOB | 32 | 32 | 14 | 0.39 | +666 | +47.6 |
| FOCUS OVER TURNS | 21 | 21 | 13 | 0.36 | +269 | +20.7 |
| MANOEUVRE | 14 | 14 | 13 | 0.36 | +542 | +41.7 |
| STUCK PIVOT | 13 | 13 | 13 | 0.36 | +0 | +0.0 |
| BEST PREY | 51 | 51 | 12 | 0.33 | +440 | +36.7 |
| BIG CHARACTER SAFETY | 12 | 12 | 12 | 0.33 | -19 | -1.6 |
| CASTING BLOCK | 14 | 14 | 12 | 0.33 | +843 | +70.3 |
| CHAFF PASSED | 12 | 12 | 12 | 0.33 | -43 | -3.6 |
| OPENS UP | 27 | 27 | 12 | 0.33 | +671 | +55.9 |
| THREAT IN THE KILL | 206 | 183 | 12 | 0.33 | +98 | +8.2 |
| RESTRAINS TO SHOOT | 11 | 11 | 11 | 0.31 | +526 | +47.8 |
| MAKE SURE TOGETHER | 35 | 28 | 10 | 0.28 | +2202 | +220.2 |
| RAIDS THE BAGGAGE NEXT TURN | 10 | 10 | 10 | 0.28 | +530 | +53.0 |
| THREAT OVER THE TURNS | 170 | 155 | 10 | 0.28 | +96 | +9.6 |
| WAR ENGINE JOBS | 31 | 31 | 10 | 0.28 | -366 | -36.6 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| PURSUES BIG PREY | 9 | 9 | 9 | 0.25 | -875 | -97.2 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| BEST PRIZE | 8 | 8 | 8 | 0.22 | -699 | -87.4 |
| OVERRUNS AWAY | 41 | 40 | 8 | 0.22 | +68 | +8.5 |
| KEEP FALLS | 7 | 7 | 7 | 0.19 | +408 | +58.3 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| PIVOT GUARDS FLANK | 7 | 7 | 7 | 0.19 | -70 | -10.0 |
| SUPPORT NARROWED | 501 | 501 | 7 | 0.19 | -45 | -6.4 |
| HUNT IN PAIRS | 32 | 17 | 6 | 0.17 | +316 | +52.6 |
| MISSILES NEXT TURN | 260 | 154 | 6 | 0.17 | +8 | +1.4 |
| SURE CHARGE BEATS ADVANCE | 6 | 6 | 6 | 0.17 | -342 | -56.9 |
| PERIAPT WORTH | 5 | 5 | 5 | 0.14 | +595 | +119.1 |
| SURE REACH TOGETHER | 25 | 21 | 5 | 0.14 | +38 | +7.6 |
| WHOLE FIGHT | 26 | 26 | 5 | 0.14 | +305 | +61.0 |
| BACKUP TARGETS | 73 | 32 | 4 | 0.11 | +10 | +2.4 |
| LOST CHARGE | 179 | 178 | 4 | 0.11 | +32 | +8.1 |
| MODEL FACING | 4 | 4 | 4 | 0.11 | +361 | +90.2 |
| NEEDED THERE | 7 | 7 | 4 | 0.11 | +0 | +0.0 |
| EDGE GIVE GROUND | 14 | 14 | 3 | 0.08 | +17 | +5.8 |
| HUNT ADVANCE | 6 | 6 | 3 | 0.08 | +61 | +20.5 |
| JOINT CHARGE PLAN | 12 | 12 | 3 | 0.08 | +610 | +203.2 |
| LONG SHOT | 45 | 44 | 3 | 0.08 | +123 | +41.0 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.06 | +0 | +0.2 |
| CARRIES OUT SET-UP | 6 | 6 | 2 | 0.06 | -77 | -38.6 |
| DEFENSIVE FLOOR | 2 | 2 | 2 | 0.06 | +10 | +4.8 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +48 | +24.2 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +29 | +14.4 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 10 | 10 | 2 | 0.06 | -93 | -46.3 |
| REDIRECT BY WHAT IT STOPS | 27 | 27 | 2 | 0.06 | +120 | +59.9 |
| STOPS | 5 | 5 | 2 | 0.06 | +100 | +50.2 |
| WAR ENGINE CHARGES | 5 | 5 | 2 | 0.06 | +67 | +33.7 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +37 | +37.4 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -3 | -3.4 |
| DEFENSIVE ARMY | 7 | 7 | 1 | 0.03 | -3 | -2.8 |
| FACE THE CAST | 1 | 1 | 1 | 0.03 | +29 | +29.0 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +16 | +16.4 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +59 | +58.8 |
| RAIDS THE BAGGAGE | 1 | 1 | 1 | 0.03 | +165 | +164.6 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +160 | +159.7 |
| SUPPORT JOB KEPT | 1 | 1 | 1 | 0.03 | +87 | +87.1 |
| WIZARD FRONT RANK | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.03 | -270 | -270.2 |
| ALREADY CARRIED | 4 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 23 | 23 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 46 | trace | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT NO STATIC JOB | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 14 | 14 | 0 | 0.00 | - | - |
| CHEAP HELPER | 9 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 36 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 392 | not checked | - | - | - | - |
| GIVES UP | 9 | 7 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 3 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 26 | 25 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 46 | 46 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT KEPT | 4 | trace | - | - | - | - |
| HUNT RESULT | 7 | trace | - | - | - | - |
| HUNT THE GUNS | 7 | trace | - | - | - | - |
| KEEPS ITS PREY | 4 | 4 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 14 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 6 | trace | - | - | - | - |
| MARCH OVER CASTS | 25 | 25 | 0 | 0.00 | - | - |
| MISSILES IN THE PLAN | 5 | 1 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 16 | 16 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 10 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 26 | trace | - | - | - | - |
| MOVE SPELL SPOT | 24 | not checked | - | - | - | - |
| NOT NEEDED | 23 | 23 | 0 | 0.00 | - | - |
| NOT TURNED | 412 | 412 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 36 | not checked | - | - | - | - |
| OPENS A LANE | 10 | 7 | 0 | 0.00 | - | - |
| PLAN RESULT | 2769 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 27 | 27 | 0 | 0.00 | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 10 | 10 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 22 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 22 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SHOT OPTIONS | 894 | 894 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 22 | not checked | - | - | - | - |
| SPELL WORTH | 148 | not checked | - | - | - | - |
| STABLE ROLE | 737 | 735 | 0 | 0.00 | - | - |
| TURN WORTH | 47 | 46 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 25 | 25 | 0 | 0.00 | - | - |

### Off best figure: tk-h2h-opp-949ddcd-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.14 | 11.97 | 53.3 |
| CHARGE NOW FIRST | rule | 0.69 | 0.86 | 53.5 |
| FALLBACK | gate | 0.42 | 0.72 | 45.4 |
| TURN GATE | gate | 0.61 | 0.31 | 20.4 |
| PATHS CROSS | rule | 0.22 | 0.22 | 12.1 |
| WAR ENGINE JOBS | rule | 0.25 | 0.03 | 36.6 |
| AFTERMATH BAND | gate | 0.11 | 0.14 | 2.5 |
| CANNON PLANNED TARGET | rule | 0.19 | 0.06 | 52.2 |
| PURSUES BIG PREY | rule | 0.08 | 0.17 | 97.2 |
| BEST PRIZE | rule | 0.08 | 0.14 | 87.4 |
| FIGHT ORDER BAND | gate | 0.11 | 0.08 | 1.9 |
| PIVOT GUARDS FLANK | rule | 0.08 | 0.11 | 10.0 |
| SUPPORT NARROWED | rule | 0.06 | 0.14 | 6.4 |
| BIG CHARACTER SAFETY | rule | 0.11 | 0.06 | 8.4 |
| CHAFF PASSED | rule | 0.14 | 0.03 | 7.1 |
| SUPPORT REQUEST | gate | 0.08 | 0.08 | 57.4 |
| SURE CHARGE BEATS ADVANCE | rule | 0.11 | 0.06 | 56.9 |
| LONE CHARACTER SAFE SPOT | gate | 0.08 | 0.06 | 94.9 |
| STOPS SHORT OF THE FLANK | rule | 0.08 | 0.06 | 7.9 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | 0.06 | 22.7 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.03 | 10.7 |
| REDIRECT WEIGHED | rule | 0.03 | 0.06 | 138.4 |
| CARRIES OUT SET-UP | rule | - | 0.06 | 38.6 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | 0.03 | 2.5 |
| LONE WIZARD HOLDS BACK | rule | 0.03 | 0.03 | 46.3 |
| NO REASON | gate | - | 0.06 | 9.2 |
| RULE SWITCHED OFF | gate | 0.06 | - | 9.8 |
| THROUGH LINE OF FIRE | rule | 0.03 | 0.03 | 4.7 |
| BLOCKED WHEEL | rule | 0.03 | - | 2.0 |
| CATCH ODDS | rule | - | 0.03 | 3.4 |
| DEFENSIVE ARMY | rule | 0.03 | - | 2.8 |
| FALLBACK BY WORTH | rule | 0.03 | - | 15.9 |
| MARCH ODDS | rule | 0.03 | - | 17.3 |
| SAFER THAN THE JOB | rule | 0.03 | - | 11.1 |
| WHO HITS BACK | rule | 0.03 | - | 3.3 |
| WOUNDED STAYS OUT | rule | - | 0.03 | 270.2 |

### Plans: tk-h2h-opp-949ddcd-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.8 | 15% | 389 | 283 | 73% |
| Mine | charge | 3.8 | 57% | 312 | 343 | 110% |
| Mine | close in | 4.6 | 25% | 253 | 122 | 48% |
| Mine | hold | 4.4 | 34% | 289 | 0 | 0% |
| Mine | join | 0.6 | 95% | 10 | 0 | 0% |
| Mine | shoot | 8.7 | 61% | 377 | 727 | 193% |
| Mine | support | 3.6 | 92% | 40 | 0 | 0% |
| Opponent | advance | 13.7 | 17% | 404 | 421 | 104% |
| Opponent | charge | 4.8 | 59% | 631 | 473 | 75% |
| Opponent | close in | 5.4 | 31% | 457 | 196 | 43% |
| Opponent | hold | 4.6 | 28% | 339 | 0 | 0% |
| Opponent | join | 0.6 | 90% | 31 | 0 | 0% |
| Opponent | shoot | 3.8 | 62% | 192 | 231 | 120% |
| Opponent | support | 6.4 | 90% | 53 | 0 | 0% |

### Packages: hunt the guns, tk-h2h-opp-949ddcd-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 2 | 0 | 0% | 0% | 0% | - | 535 | 0 | 0% | 21 |
| Opponent | 0.1 | 5 | 0 | 40% | 40% | 0% | 3.5 | 389 | 83 | 20% | 98 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 579 | 0 | 0% | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 205 |
| Empire of Man | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 490 | 0 | 0% | 21 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 243 | 0 | 0% | 70 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 114 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 158 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.4 | 3 | 0 | 67% | 67% | 0% | 3.5 | 360 | 138 | 33% | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 114 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 620 | 0 | 0% | 100 |

### Battle groups: tk-h2h-opp-949ddcd-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 8.3 | 26% | 36% | 12% | 56% | 42% | 6% | 16% | 36% | 0% |
| Mine | REDIRECT COUNTER | 2.1 | 29% | 64% | 9% | 50% | 45% | 5% | 10% | 35% | 5% |
| Opponent | COUNTER-CHARGE COVER | 7.5 | 18% | 67% | 10% | 20% | 37% | 9% | 14% | 40% | 0% |
| Opponent | REDIRECT COUNTER | 3.9 | 20% | 71% | 18% | 40% | 22% | 0% | 4% | 70% | 4% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: tk-h2h-opp-949ddcd-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 110 (4) | 110 | 0 | 100 | 0% | 3.2 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 34 | 38 (34) | 18 | 20 | 65 | 35% | 2.1 | 41 (14) | 43 (5) | 34 (15) | 18 (20) | 69 (14) |
| Mine | Character | 106 | 50 (106) | 50 | 0 | 48 | 15% | 2.4 | 51 (36) | 61 (46) | 9 (7) | 50 (45) | 57 (44) |
| Mine | Clean-up | 23 | 61 (23) | 30 | 31 | 59 | 22% | 2.6 | 0 (2) | 58 (17) | 100 (4) | 104 (11) | 34 (12) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast | 4 | 120 (4) | 120 | 0 | 46 | 25% | 2.3 | 0 (2) | 239 (2) | - | 0 (3) | 444 (1) |
| Mine | Fast Hammer | 40 | 41 (40) | 27 | 14 | 54 | 5% | 2.8 | 45 (25) | 39 (9) | 27 (6) | 38 (25) | 46 (15) |
| Mine | Fragile | 4 | 0 (4) | 0 | 0 | 46 | 25% | 2.7 | 0 (1) | 0 (3) | - | 0 (1) | 0 (3) |
| Mine | Hammer | 64 | 41 (64) | 31 | 9 | 52 | 14% | 2.7 | 21 (13) | 43 (42) | 56 (9) | 33 (39) | 49 (25) |
| Mine | Holder | 31 | 87 (31) | 10 | 77 | 28 | 35% | 2.9 | 50 (7) | 130 (17) | 24 (6) | 105 (19) | 70 (11) |
| Mine | Shooter | 35 | 61 (35) | 23 | 38 | 37 | 0% | 1.9 | 16 (8) | 94 (22) | 5 (5) | 57 (26) | 76 (9) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | War machine | 56 | 52 (56) | 52 | 0 | 47 | 4% | 1.3 | 48 (16) | 66 (30) | 18 (10) | 64 (9) | 50 (47) |
| Mine | Wizard | 17 | 39 (17) | 39 | 0 | 56 | 0% | 2.2 | 0 (5) | 119 (6) | 0 (1) | 0 (6) | 113 (6) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Chaff | 77 | 62 (77) | 30 | 32 | 54 | 36% | 2.9 | 78 (32) | 63 (18) | 43 (27) | 58 (58) | 78 (19) |
| Opponent | Character | 97 | 63 (97) | 62 | 1 | 35 | 24% | 2.2 | 57 (42) | 74 (39) | 45 (6) | 52 (50) | 78 (37) |
| Opponent | Clean-up | 12 | 56 (12) | 29 | 28 | 67 | 8% | 2.8 | 21 (4) | 72 (5) | 54 (3) | 43 (7) | 65 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 54 | 46 (54) | 29 | 18 | 43 | 26% | 3.0 | 56 (23) | 36 (23) | 38 (8) | 44 (33) | 50 (21) |
| Opponent | Fragile | 17 | 0 (17) | 0 | 0 | 62 | 41% | 1.7 | 0 (5) | 0 (8) | 0 (4) | 0 (14) | 0 (3) |
| Opponent | Hammer | 65 | 52 (65) | 35 | 17 | 38 | 31% | 3.0 | 26 (20) | 65 (38) | 11 (7) | 59 (41) | 41 (24) |
| Opponent | Holder | 30 | 39 (30) | 8 | 31 | 18 | 50% | 3.9 | 38 (9) | 47 (14) | 18 (6) | 49 (17) | 30 (12) |
| Opponent | Shooter | 34 | 55 (34) | 12 | 44 | 50 | 0% | 1.5 | 60 (10) | 49 (21) | 92 (3) | 40 (19) | 73 (15) |
| Opponent | Support | 6 | 41 (6) | 41 | 0 | 66 | 33% | 2.2 | 0 (1) | 0 (4) | 228 (1) | 0 (4) | 124 (2) |
| Opponent | War machine | 6 | 113 (6) | 113 | 0 | 50 | 17% | 1.0 | 132 (3) | 85 (3) | - | 132 (3) | 85 (3) |
| Opponent | Wizard | 20 | 5 (20) | 5 | 0 | 52 | 5% | 2.5 | 5 (10) | 10 (4) | 0 (2) | 2 (11) | 18 (5) |

### Charged fights: tk-h2h-opp-949ddcd-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 151 | 291 | 2.5 | 1.0 | 116 | 17 | +99 | 3 of 10 | 6 of 10 | - | +99 |
| Mine | Chaos Dwarfs | 4 | 242 | 390 | 3.2 | 1.2 | 120 | 0 | +120 | 6 of 13 | 12 of 13 | +274 | +92 |
| Mine | Dwarfen Mountain Holds | 3 | 528 | 71 | 2.0 | 1.3 | 36 | 11 | +25 | 3 of 6 | 4 of 6 | -32 | +54 |
| Mine | Empire of Man | 5 | 450 | 159 | 2.0 | 1.3 | 80 | 157 | -78 | 3 of 10 | 5 of 10 | -214 | -43 |
| Mine | Grand Cathay | 4 | 135 | 384 | 3.5 | 1.1 | 110 | 16 | +94 | 5 of 14 | 12 of 14 | +88 | +95 |
| Mine | High Elf Realms | 4 | 383 | 384 | 4.2 | 1.1 | 90 | 26 | +64 | 2 of 17 | 15 of 17 | +0 | +73 |
| Mine | Kingdom of Bretonnia | 1 | 130 | 420 | 5.0 | 1.0 | 84 | 108 | -24 | 2 of 5 | 4 of 5 | - | -24 |
| Mine | Lizardmen | 1 | 0 | 1289 | 7.0 | 1.3 | 184 | 154 | +30 | 5 of 7 | 5 of 7 | -233 | +135 |
| Mine | Ogre Kingdoms | 2 | 62 | 28 | 4.0 | 1.4 | 7 | 203 | -196 | 4 of 8 | 4 of 8 | -277 | -169 |
| Mine | Skaven | 2 | 192 | 206 | 3.0 | 1.0 | 68 | 22 | +47 | 1 of 6 | 4 of 6 | - | +47 |
| Mine | Tomb Kings of Khemri | 2 | 38 | 729 | 5.0 | 1.0 | 146 | 54 | +92 | 6 of 10 | 7 of 10 | - | +92 |
| Mine | Vampire Counts | 2 | 95 | 394 | 4.0 | 1.1 | 99 | 147 | -48 | 1 of 8 | 4 of 8 | -5 | -54 |
| Mine | Warriors of Chaos | 2 | 0 | 500 | 4.0 | 1.0 | 125 | 75 | +50 | 3 of 8 | 7 of 8 | - | +50 |
| **Mine** | all armies | 36 | 233 | 340 | 3.4 | 1.1 | 100 | 67 | +33 | 44 of 122 | 89 of 122 | -53 | +46 |
| Opponent | Empire of Man | 1 | 675 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 5 | 109 | 545 | 4.8 | 1.0 | 113 | 82 | +32 | 14 of 24 | 13 of 24 | +0 | +33 |
| Opponent | Lizardmen | 2 | 56 | 541 | 2.5 | 1.0 | 216 | 65 | +151 | 3 of 5 | 4 of 5 | - | +151 |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 266 | 3.3 | 1.2 | 80 | 61 | +19 | 4 of 10 | 8 of 10 | +160 | -16 |
| Opponent | Skaven | 4 | 230 | 196 | 1.2 | 1.2 | 156 | 55 | +101 | 4 of 5 | 4 of 5 | +113 | +98 |
| Opponent | Tomb Kings of Khemri | 2 | 155 | 884 | 4.5 | 1.3 | 196 | 0 | +196 | 5 of 9 | 7 of 9 | +402 | +94 |
| Opponent | Vampire Counts | 6 | 22 | 375 | 4.8 | 1.3 | 78 | 16 | +62 | 13 of 29 | 20 of 29 | +96 | +46 |
| Opponent | Warriors of Chaos | 7 | 31 | 703 | 4.3 | 1.1 | 164 | 19 | +145 | 16 of 30 | 19 of 30 | +754 | +101 |
| Opponent | Wood Elf Realms | 6 | 44 | 424 | 4.5 | 1.2 | 94 | 52 | +42 | 9 of 27 | 22 of 27 | -26 | +62 |
| **Opponent** | all armies | 36 | 88 | 468 | 3.9 | 1.2 | 121 | 40 | +81 | 68 of 139 | 97 of 139 | +161 | +64 |

### Effective charges: tk-h2h-opp-949ddcd-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 10 | 1 (net +500) | 0 | 1 (net -85) | 2 (net +76) | 0 | 4 (net +27) | 2 | 12% (1 of 8) |
| Mine | Chaos Dwarfs | 13 | 3 (net +183) | 0 | 1 (net +0) | 5 (net +192) | 1 (net +49) | 3 (net +0) | 0 | 8% (1 of 13) |
| Mine | Dwarfen Mountain Holds | 6 | 2 (net +0) | 0 | 0 | 3 (net +50) | 0 | 1 (net +0) | 0 | 0% (0 of 6) |
| Mine | Empire of Man | 10 | 0 | 0 | 6 (net -64) | 3 (net -131) | 1 (net +0) | 0 | 0 | 60% (6 of 10) |
| Mine | Grand Cathay | 14 | 0 | 0 | 3 (net -36) | 2 (net +175) | 2 (net +59) | 7 (net +137) | 0 | 21% (3 of 14) |
| Mine | High Elf Realms | 17 | 1 (net +0) | 0 | 0 | 3 (net -67) | 5 (net +38) | 8 (net +138) | 0 | 0% (0 of 17) |
| Mine | Kingdom of Bretonnia | 5 | 1 (net -67) | 0 | 0 | 1 (net -264) | 1 (net +0) | 0 | 2 | 0% (0 of 3) |
| Mine | Lizardmen | 7 | 0 | 0 | 1 (net -29) | 2 (net -158) | 0 | 3 (net +57) | 1 | 17% (1 of 6) |
| Mine | Ogre Kingdoms | 8 | 0 | 0 | 2 (net -65) | 1 (net -219) | 0 | 1 (net -335) | 4 | 50% (2 of 4) |
| Mine | Skaven | 6 | 1 (net +0) | 0 | 0 | 2 (net -11) | 0 | 2 (net +46) | 1 | 0% (0 of 5) |
| Mine | Tomb Kings of Khemri | 10 | 1 (net -48) | 0 | 2 (net +98) | 3 (net +126) | 0 | 4 (net +98) | 0 | 20% (2 of 10) |
| Mine | Vampire Counts | 8 | 2 (net -306) | 0 | 1 (net +0) | 2 (net -64) | 1 (net -5) | 0 | 2 | 17% (1 of 6) |
| Mine | Warriors of Chaos | 8 | 1 (net +0) | 0 | 1 (net -599) | 3 (net +262) | 2 (net +107) | 1 (net +0) | 0 | 12% (1 of 8) |
| Opponent | High Elf Realms | 24 | 7 (net -99) | 1 (net +170) | 2 (net -51) | 4 (net +18) | 0 | 7 (net +131) | 3 | 10% (2 of 21) |
| Opponent | Lizardmen | 5 | 0 | 0 | 0 | 1 (net +458) | 0 | 1 (net +369) | 3 | 0% (0 of 2) |
| Opponent | Orc & Goblin Tribes | 10 | 2 (net -42) | 0 | 2 (net +38) | 2 (net +160) | 0 | 1 (net +40) | 3 | 29% (2 of 7) |
| Opponent | Skaven | 5 | 0 | 0 | 1 (net +80) | 1 (net +0) | 0 | 2 (net +246) | 1 | 25% (1 of 4) |
| Opponent | Tomb Kings of Khemri | 9 | 1 (net +0) | 0 | 2 (net +318) | 4 (net +104) | 0 | 1 (net +540) | 1 | 25% (2 of 8) |
| Opponent | Vampire Counts | 29 | 4 (net -15) | 2 (net +0) | 6 (net +90) | 4 (net +60) | 6 (net +84) | 5 (net +35) | 2 | 22% (6 of 27) |
| Opponent | Warriors of Chaos | 30 | 5 (net +182) | 0 | 3 (net +104) | 0 | 1 (net +110) | 14 (net +186) | 7 | 13% (3 of 23) |
| Opponent | Wood Elf Realms | 27 | 2 (net +136) | 0 | 8 (net -49) | 6 (net +68) | 4 (net +36) | 7 (net +102) | 0 | 30% (8 of 27) |

### Charged fights, damage counted: tk-h2h-opp-949ddcd-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 13 | 318 | 322 | +25 | 148 | 137 | +11 | +3.4 |
| Mine | Effective (55-75%) | 18 | 271 | 230 | -63 | 77 | 128 | -51 | -18.8 |
| Mine | 76-89% | 32 | 274 | 193 | +38 | 138 | 79 | +59 | +21.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 34 | 224 | 179 | +73 | 118 | 45 | +73 | +32.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 13 | 455 | 80 | +44 | 60 | 9 | +51 | +11.1 |
| Mine | No odds | 12 | 249 | 213 | +50 | 161 | 125 | +36 | +14.5 |
| Mine | All fights | 122 | 281 | 198 | +33 | 118 | 80 | +38 | +13.6 |
| Opponent | Long shot (under 50%) | 21 | 306 | 296 | +16 | 156 | 128 | +28 | +9.3 |
| Opponent | 50-54% | 3 | 82 | 131 | +57 | 57 | 0 | +57 | +68.8 |
| Opponent | Effective (55-75%) | 24 | 271 | 226 | +48 | 130 | 83 | +47 | +17.3 |
| Opponent | 76-89% | 22 | 353 | 226 | +87 | 90 | 11 | +79 | +22.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 38 | 355 | 211 | +154 | 195 | 37 | +159 | +44.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 562 | 137 | +69 | 97 | 28 | +70 | +12.4 |
| Opponent | No odds | 20 | 312 | 204 | +53 | 114 | 72 | +42 | +13.4 |
| Opponent | All fights | 139 | 337 | 220 | +81 | 139 | 58 | +81 | +24.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| tk-h2h-opp-949ddcd-p4 | move | 456 | 102 (22%) | 79 (17%) | 61 (13%) | 293 (64%) |
| tk-h2h-opp-949ddcd-p4 | objective | 364 | 56 (15%) | 43 (12%) | 55 (15%) | 253 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

# Doctrine scorecard: gs3-83c8646-p48

### Scorecard: gs3-83c8646-p48

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2634 | 6 | 1 | Mine | no | 9 | 3 | 1 | 0 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Mine | - | - | 3 | 4 | 3 | 1 | 0 | 0 | 170 |
| L2930 | 2 | 1 | Opponent | - | - | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 8 | 2 | 1 | 4 | 1 | 0 | 0 | 307 |
| L3234 | 6 | 1 | Opponent | no | 2 | 2 | 4 | 5 | 0 | 0 | 0 | 27 |
| **Average** | | | Mine | 0% | 8.5 | 2.7 | 2.0 | 2.3 | 0.7 | 0.0 | 0.0 | 159.0 |
| **Average** | | | Opponent | 0% | 1.0 | 2.0 | 3.3 | 3.0 | 0.3 | 0.0 | 0.0 | 9.0 |

### KPIs: gs3-83c8646-p48

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 16) | 0% (0 of 15) | 0% (0 of 31) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 100% (9 of 9); on the table 100% | 100% (10 of 10); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (4 of 4); on the table 100% | - | 100% (4 of 4); on the table 100% |
| Winner chose to pursue after the loser fled |  | 20% (1 of 5); on the table 20% | 67% (2 of 3); on the table 100% | 38% (3 of 8); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 60% (6 of 10); on the table 60% | 92% (11 of 12); on the table 100% | 77% (17 of 22); on the table 82% |
| Magic missiles tried each own turn | 50%+ | 17% (1 of 6) | - | 17% (1 of 6) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 25% (1 of 4) | - | 25% (1 of 4) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (6 of 9) | - | 67% (6 of 9) |
| Points that never fought | lower | 31% (1870 of 5998) | 27% (1594 of 5996) | 29% (3464 of 11994) |
|   infantry points that never fought | lower | 94% (922 of 985) | 59% (796 of 1349) | 74% (1718 of 2334) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 50% (10 of 20) | 45% (10 of 22) | 48% (20 of 42) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game | 67% (2 of 3); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 39% (2144 of 5555) | 31% (1548 of 5066) | 35% (3692 of 10621) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (60%) | - | 1.0 (60%) |
| IN COMBAT: engaged in combat | 0.7 (40%) | - | 0.7 (40%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Assailments |
| --- | --- | --- | --- | --- |
| tried | 2.0 | 1.3 | 0.3 | 4.7 |
| not cast | 0.0 | 0.0 | 1.7 | 7.3 |
| NOT CHOSEN: could have been cast at a target | - | - | 0.0 (0%) | 0.3 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | - | - | 1.0 (60%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | - | - | 0.7 (40%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | - | - | 0.0 (0%) | 7.0 (95%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 6% (1 of 18) | 59% (42 of 71) | 48% (43 of 89) |
|   cavalry | 20% (1 of 5) | 76% (16 of 21) | 65% (17 of 26) |
|   character | 0% (0 of 13) | 27% (7 of 26) | 18% (7 of 39) |
|   infantry | - | 79% (19 of 24) | 79% (19 of 24) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.3 (6%) | 3.0 (31%) | 3.3 (22%) |
| CHARGED: it charged | 2.0 (35%) | 4.0 (41%) | 6.0 (39%) |
| NO TARGET IN RANGE | 1.3 (24%) | 1.0 (10%) | 2.3 (15%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.0 (35%) | 1.3 (14%) | 3.3 (22%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 11.7 | 1.3 | 89% | 1.9 pts | 23 pts |
| character | 2.3 | 0.3 | 86% | 3.9 pts | 9 pts |
| infantry | 10.0 | 1.0 | 90% | 1.3 pts | 13 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 6.0 | 5.7 | 5.8 |
| Charges that made contact a game | 3.0 | 5.0 | 4.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | - | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, units carrying another wizard (or one alone) | 3.00 declared, 3.00 contact (2 units) | 1.00 declared, 1.00 contact (1 units) | 2.33 declared, 2.33 contact (3 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.50 declared, 0.12 contact (24 units) | 0.50 declared, 0.44 contact (32 units) | 0.50 declared, 0.30 contact (56 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 38% (3 of 8) | 100% (2 of 2) | - | 50% (5 of 10) |
| Character on its own | - | 100% (2 of 2) | 9% (1 of 11) | 23% (3 of 13) |
| Infantry | 50% (3 of 6) | 0% (0 of 1) | 0% (0 of 1) | 38% (3 of 8) |
| Monster | 75% (3 of 4) | 0% (0 of 1) | - | 60% (3 of 5) |
| Monstrous | 100% (5 of 5) | 100% (1 of 1) | - | 100% (6 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vampire Counts | 1 | 100% (4 of 4); on the table 100% | 17% (1 of 6) | 24% | 20% (1 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 3 | 60% (6 of 10); on the table 60% | - | 25% | 62% (13 of 21) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |
| Wood Elf Realms | 2 | 88% (7 of 8); on the table 100% | - | 37% | 38% (6 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p48, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 46% (6) | 83% (5) | 58% (11) |
| ...free all their last turn and able to turn (per game) | 1.00 | 1.67 | 2.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.67 | 0.00 | 0.67 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 1.33 | 1.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.33 | 0.67 |

### Quality by phase: gs3-83c8646-p48

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 1.7 |
| Strategy | Charge objectives carried out (made contact) | 67% (8 of 12) | 69% (9 of 13) |
| Strategy | Shoot objectives carried out (shot that target) | 0% (0 of 1) | 38% (5 of 13) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | 50% (1 of 2) |
| Strategy | Lone characters that fought | 83% (5 of 6) | 100% (7 of 7) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 2.3 | 3.0 |
| Movement | Points that never moved of their own | 159.0 | 9.0 |
| Movement | Fights charged into per game | 2.7 | 4.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 7 | 2 of 10, net -304 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 7, net +0 | 2 of 10, net +22 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 7, net +0 | 2 of 10, net +31 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 7, net +289 | 3 of 10, net +235 |
| Shooting | Shots by shooting units (incl. breath weapons) | 1.7 | 15.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 5) | 50% (23 of 46) |
| Shooting | Points destroyed by shooting units | 0.0 | 10.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Wounds caused by other spells | 6.7 | - |
| Magic | Points destroyed by magic (all spells) | 208.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.7 / 0.0 / 3.3 / 0.0 | 0.0 / 1.3 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 275.3 | 518.3 |
| Combat | Points run down | 96.0 | 89.3 |
| Combat | Net points per charged fight, damage counted | +101 | +82 |
| Combat | Net per 100 charger points, damage counted | +24.8 | +19.3 |
| Combat | First round won (charged fights) | 75% | 86% |
| Combat | Net points per charged fight | +86 | +88 |
| Combat | Net points per supported fight / lone fight | +0 / +98 | +45 / +92 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 8 | 6 of 14 |
| Game | Points lost | 673.3 | 647.7 |
| Game | VP from objectives | 573.3 | 536.7 |
| Game | Lone holders (player turns) | 8.5 | 1.0 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +179 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1321
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: gs3-83c8646-p48

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH WITH FRIENDS | 0.3 | +32.5 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 18.3 | +99.6 | 0.0 | 140.7 | 30.3 | +37.0 | 0.0 | 175.3 |
| ASSAILMENT BY POINTS | 0.7 | +3.6 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | 0.7 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | 0.3 | +3.4 | 0.0 | 0.0 | 0.3 | -5.0 | 0.0 | 0.0 |
| CAST JOB | 0.7 | +1.9 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.3 | +3.0 | 0.0 | 10.0 | 2.0 | +84.4 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 0.7 | -3.1 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 2.3 | +83.1 | 0.0 | 455.0 | 0.7 | +39.2 | 0.0 | 74.7 |
| CHARGE LOSSES | 17.3 | -373.0 | 0.0 | 412.7 | 3.7 | -551.9 | 0.0 | 32.7 |
| CHARGE NOW FIRST | 3.0 | +0.0 | 303.3 | 164.7 | 3.3 | +0.0 | 413.7 | 199.7 |
| CHARGER SLAIN LOST | 0.7 | -5.3 | 132.0 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 12.0 | +0.0 | 0.0 | 96.7 | 11.0 | +0.0 | 0.0 | 178.7 |
| COMBAT PIVOT | 1.3 | +0.0 | 232.3 | 113.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| COVER ONCE | 7.3 | -351.9 | 0.0 | 109.7 | 8.3 | -568.0 | 0.0 | 236.7 |
| DEFENSIVE FLOOR | - | - | - | - | 0.3 | +0.2 | 15.0 | 0.0 |
| DENIED BY THE FIGHT | 0.3 | -0.4 | 0.0 | 0.0 | 0.3 | -1.5 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 8.0 | +61.7 | 0.0 | 0.0 | 9.7 | -60.2 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.7 | -9.3 | 123.7 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 1.0 | +26.1 | 57.7 | 45.7 | - | - | - | - |
| EXACT ROUND | 2.7 | +12.3 | 146.0 | 164.7 | 2.7 | +27.7 | 259.7 | 199.7 |
| FALL BACK GOOD ORDER | 4.0 | +13.8 | 327.7 | 0.0 | 4.0 | +2.0 | 381.3 | 232.3 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | 17.0 | +176.9 | 0.0 | 165.3 | 7.3 | +106.5 | 0.0 | 188.3 |
| FEATURE BUFFS | 1.3 | +36.7 | 0.0 | 0.0 | 1.0 | +16.0 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +0.2 | 57.7 | 0.0 | 0.7 | +35.3 | 0.0 | 199.7 |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 70.7 | +3643.1 | 407.7 | 878.7 | 110.0 | +3971.5 | 967.7 | 1208.3 |
| FLANK NOT WEIGHED | 11.0 | +0.0 | 0.0 | 143.0 | 9.0 | +0.0 | 0.0 | 169.7 |
| FOLLOW UP WEIGHED | 0.7 | +53.6 | 0.0 | 0.0 | 1.7 | +391.8 | 0.0 | 199.7 |
| FOOT FIRST | - | - | - | - | 49.7 | +0.0 | 0.0 | 520.7 |
| FOUR ROUNDS | 5.3 | +324.4 | 407.7 | 210.3 | 5.7 | +530.7 | 678.3 | 232.3 |
| FREED FROM HIS FIGHT | 13.7 | +0.0 | 0.0 | 312.7 | 6.3 | +0.0 | 0.0 | 312.7 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.7 | -2.7 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.3 | +27.6 | 0.0 | 0.0 |
| GIVES UP | 0.7 | -19.2 | 66.0 | 45.7 | 0.3 | -3.9 | 0.0 | 0.0 |
| GOAL ROUTE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| GOAL WALK | 7.0 | +409.1 | 0.0 | 356.0 | 11.3 | +701.5 | 0.0 | 0.0 |
| GROUND FLIERS | - | - | - | - | 0.3 | +13.8 | 0.0 | 0.0 |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 35.7 |
| HE REFORMS ONCE FREED | 8.3 | +0.0 | 0.0 | 93.3 | 4.0 | +0.0 | 0.0 | 197.3 |
| HIS CHARGE BY HIS RUN | 13.0 | +0.0 | 0.0 | 356.0 | 3.7 | +0.0 | 0.0 | 32.7 |
| HIS CHARGE DENIED | 0.3 | +0.4 | 0.0 | 0.0 | 1.3 | +25.3 | 210.3 | 32.7 |
| HIS CHARGE LIST | 3.3 | +0.0 | 0.0 | 10.0 | 8.0 | +0.0 | 0.0 | 65.3 |
| HIS LEGAL MOVES | 6.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 5.3 | -33.6 | 0.0 | 129.7 | 0.3 | -4.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 11.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 20.7 | +0.0 | 0.0 | 421.7 |
| HIS RANDOM MOVER COMES | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 43.3 | +968.5 | 0.0 | 531.7 | 20.3 | +430.8 | 0.0 | 410.7 |
| HIS SHOTS BY HIS RUN | 45.7 | +428.4 | 0.0 | 611.7 | 10.7 | +240.1 | 0.0 | 207.3 |
| HIS TURN DENIED | 0.3 | +2.4 | 0.0 | 45.7 | - | - | - | - |
| HOLD ODDS | 24.0 | +0.0 | 0.0 | 91.3 | 18.0 | +0.0 | 0.0 | 65.3 |
| HOLDER ASSIGNMENT | 12.7 | +1246.7 | 0.0 | 45.7 | 12.7 | +1273.7 | 0.0 | 65.3 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.3 | -151.2 | 407.7 | 210.3 | 4.3 | -211.3 | 442.0 | 199.7 |
| IDLE COST | 9.7 | -172.1 | 0.0 | 38.3 | 3.3 | -86.5 | 0.0 | 132.0 |
| JOINT CHARGE NOW | 0.7 | +21.4 | 0.0 | 0.0 | 1.0 | +214.0 | 30.0 | 32.7 |
| JOINT ON THE TABLE | - | - | - | - | 0.3 | +212.6 | 0.0 | 32.7 |
| KEEP FALLS | - | - | - | - | 0.3 | +2.1 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +26.9 | 0.0 | 0.0 | 1.7 | +56.0 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 5.7 | +0.0 | 483.0 | 223.7 | 9.7 | +0.0 | 510.0 | 295.7 |
| LONG SHOT | - | - | - | - | 0.3 | +0.4 | 15.0 | 0.0 |
| LOST AFTER ESCAPE | 1.3 | +1.0 | 167.7 | 0.0 | 1.3 | -0.8 | 289.7 | 199.7 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.3 | -5.4 | 0.0 | 0.0 |
| MANOEUVRE | 3.0 | +4.1 | 0.0 | 45.7 | 1.0 | +22.9 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | -40.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.7 | +26.1 | 0.0 | 0.0 | 1.7 | +65.1 | 0.0 | 36.3 |
| MEETS IN TIME | 4.0 | +291.4 | 0.0 | 0.0 | 4.7 | +488.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.0 | +61.6 | 0.0 | 0.0 | - | - | - | - |
| MISSILES NEXT TURN | 1.0 | +32.5 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 2.7 | +0.0 | 0.0 | 13.3 | 4.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 7.3 | +436.1 | 0.0 | 0.0 | 5.7 | +450.9 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 7.0 | +288.6 | 0.0 | 45.7 | 7.3 | +379.3 | 0.0 | 136.7 |
| NEAREST TO GOAL | - | - | - | - | 3.3 | +0.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 6.3 | +418.5 | 0.0 | 0.0 | 5.0 | +461.5 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 4.7 | -325.7 | 398.7 | 210.3 | 4.7 | -411.9 | 608.3 | 199.7 |
| NO LATE CUT | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 3.3 | -113.5 | 101.7 | 0.0 | 6.0 | -292.4 | 56.7 | 0.0 |
| ONE FIGHT FORMULA | 6.0 | -111.9 | 0.0 | 0.0 | 6.0 | -167.3 | 0.0 | 36.3 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +1.5 | 15.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 6.3 | -17.8 | 0.0 | 45.7 | 5.3 | -65.4 | 0.0 | 32.7 |
| ONE PROMISE A TARGET | 0.3 | -9.3 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 1.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 1.0 | +69.6 | 80.0 | 164.7 | 0.3 | +25.0 | 13.3 | 0.0 |
| OVERRUNS AWAY | 1.0 | +33.8 | 44.7 | 45.7 | 0.7 | +122.3 | 23.3 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -34.9 | 0.0 | 0.0 | 0.3 | -14.3 | 0.0 | 0.0 |
| PLAN RESULT | 35.7 | +370.8 | 292.0 | 1211.7 | 51.0 | +650.2 | 196.3 | 879.0 |
| PROMISE BY ITS OWN SUM | 7.0 | -64.8 | 0.0 | 0.0 | 13.0 | -383.6 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 3.0 | +70.7 | 0.0 | 113.3 | - | - | - | - |
| REAL GROUND | 1.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 2.0 | +47.7 | 0.0 | 0.0 |
| REDIRECT COUNTER | 7.0 | +163.5 | 0.0 | 23.3 | 3.3 | +331.1 | 0.0 | 18.0 |
| REDIRECT FOR A FRIEND IN REACH | 2.7 | +0.0 | 0.0 | 23.3 | 4.7 | +83.7 | 0.0 | 18.0 |
| REDIRECT WEIGHED | 0.3 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 0.7 | -0.3 | 0.0 | 0.0 | 3.0 | -116.3 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +6.7 | 0.0 | 0.0 |
| RISK BY ARC | 3.7 | +323.0 | 369.3 | 210.3 | 4.3 | +66.7 | 523.3 | 232.3 |
| RISK ON THE WAY | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 1.3 | -11.4 | 115.7 | 164.7 | 0.7 | -3.2 | 91.3 | 0.0 |
| RUN DOWN | 3.7 | -39.9 | 362.3 | 210.3 | 2.3 | -13.6 | 355.3 | 0.0 |
| SAME CHARGE LATER | - | - | - | - | 0.3 | -8.8 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 2.3 | -149.4 | 0.0 | 10.0 | 0.7 | -38.0 | 0.0 | 0.0 |
| SEARCH SPOT | - | - | - | - | 1.0 | +4.7 | 0.0 | 32.7 |
| SECOND LOOK | 1.3 | +31.1 | 170.7 | 164.7 | 1.3 | +61.5 | 180.0 | 0.0 |
| SET CREDITED ONCE | 0.7 | -2.0 | 0.0 | 13.3 | 3.0 | -96.9 | 0.0 | 18.0 |
| SET UP BY THE SET | 1.0 | +7.7 | 0.0 | 13.3 | 3.7 | +102.6 | 0.0 | 18.0 |
| SHOOTERS ON THE TABLE | 1.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 2.3 | +32.0 | 10.0 | 0.0 |
| SHOT RISK POINTS | 31.0 | -285.5 | 0.0 | 442.7 | 8.7 | +33.9 | 0.0 | 76.7 |
| SHOTS AFTER THE MOVES | - | - | - | - | 3.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 1.0 | +11.8 | 0.0 | 0.0 | 15.0 | +173.8 | 0.0 | 71.3 |
| SPELL WORTH | 2.0 | +43.2 | 0.0 | 0.0 | - | - | - | - |
| SPELLS IN THE FIGHT | 0.3 | +0.3 | 0.0 | 0.0 | 0.7 | -15.2 | 0.0 | 199.7 |
| SPOT AS THE GAME MOVES | 8.3 | +0.0 | 0.0 | 243.0 | 10.0 | +0.0 | 0.0 | 105.0 |
| STAND AND SHOOT | 0.7 | -4.5 | 35.7 | 45.7 | - | - | - | - |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| STANDS STILL | 22.3 | +0.0 | 0.0 | 182.3 | 45.3 | +0.0 | 289.3 | 306.0 |
| STAY WORTH | 1.3 | -17.4 | 0.0 | 0.0 | 17.0 | +87.8 | 259.3 | 35.7 |
| STUCK PIVOT | 1.0 | +0.0 | 0.0 | 56.7 | - | - | - | - |
| SUPPORT ADDS | 6.0 | +361.9 | 0.0 | 34.3 | 11.0 | +544.1 | 0.0 | 72.7 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 10.0 | 0.0 |
| SUPPORT WORKED OUT | 6.0 | +361.9 | 0.0 | 34.3 | 11.0 | +544.1 | 0.0 | 72.7 |
| SURE REACH TOGETHER | 0.3 | +8.7 | 0.0 | 0.0 | 0.7 | +0.5 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 4.0 | +0.0 | 0.0 | 119.7 | 6.0 | +0.0 | 0.0 | 38.3 |
| THE ROW KEEPS ITS WAY | 2.0 | +0.0 | 0.0 | 10.0 | 2.7 | +0.0 | 0.0 | 32.7 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 10.0 | 1.7 | +0.0 | 0.0 | 32.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 31.7 | +0.0 | 0.0 | 272.0 | 53.3 | +0.0 | 0.0 | 488.0 |
| TIED UP BY THE SUM | 2.0 | +287.6 | 179.7 | 164.7 | 2.0 | +376.5 | 237.3 | 0.0 |
| TIME ON OUR SIDE | 16.7 | +143.7 | 0.0 | 68.3 | 76.7 | +446.6 | 219.3 | 433.7 |
| WAITS AGAIN | 2.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -0.8 | 113.3 | 0.0 |
| WHO FIGHTS | 0.3 | -0.5 | 35.7 | 0.0 | 0.7 | -1.1 | 30.0 | 0.0 |
| WHO GETS IN | - | - | - | - | 0.3 | +212.6 | 0.0 | 32.7 |
| WHO HITS BACK | 0.7 | +158.8 | 0.0 | 0.0 | 0.3 | +11.5 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +4.8 | 56.7 | 0.0 |
| WHOLE FIGHT DANGER | 2.0 | -142.6 | 0.0 | 56.7 | 3.3 | -526.9 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p48

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 146 | 146 | 108 | 36.00 | +284 | +2.6 |
| HOLDER ASSIGNMENT | 76 | 76 | 73 | 24.33 | +4224 | +57.9 |
| TIME ON OUR SIDE | 280 | 246 | 50 | 16.67 | +41 | +0.8 |
| LEGAL CHARGES ONLY | 46 | 46 | 46 | 15.33 | +0 | +0.0 |
| DEPLOY BY FIGURES | 53 | 53 | 30 | 10.00 | +239 | +8.0 |
| HIS SHOTS BY HIS RUN | 169 | 164 | 29 | 9.67 | +129 | +4.5 |
| OFF BEST | 28 | 28 | 28 | 9.33 | -1218 | -43.5 |
| HIS SHOT LIST | 191 | 186 | 22 | 7.33 | +172 | +7.8 |
| THE TABLE AGAIN | 36 | 36 | 22 | 7.33 | +0 | +0.0 |
| MOVE ORDER | 21 | 21 | 21 | 7.00 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 34 | 32 | 21 | 7.00 | +1188 | +56.6 |
| SUPPORT ADDS | 51 | 51 | 21 | 7.00 | +698 | +33.2 |
| SUPPORT WORKED OUT | 51 | 51 | 21 | 7.00 | +698 | +33.2 |
| MOVE TO CHARGE COMPUTED | 39 | 32 | 20 | 6.67 | +1127 | +56.4 |
| REDIRECT FOR A FRIEND IN REACH | 22 | 22 | 20 | 6.67 | +66 | +3.3 |
| FIVE ACTION | 542 | 518 | 19 | 6.33 | +1116 | +58.7 |
| PROMISE BY ITS OWN SUM | 60 | 60 | 18 | 6.00 | -1345 | -74.7 |
| SHOT RISK POINTS | 119 | 118 | 17 | 5.67 | +213 | +12.5 |
| FOUR ROUNDS | 33 | 27 | 15 | 5.00 | +542 | +36.2 |
| MEETS IN TIME | 26 | 26 | 15 | 5.00 | +895 | +59.6 |
| CHALLENGE BY POINTS | 9 | 9 | 9 | 3.00 | +367 | +40.8 |
| LANE BY FIGURES | 9 | 9 | 9 | 3.00 | +249 | +27.7 |
| SECOND LOOK | 8 | 8 | 8 | 2.67 | +277 | +34.7 |
| TIED UP BY THE SUM | 12 | 8 | 8 | 2.67 | +311 | +38.9 |
| COVER ONCE | 47 | 29 | 7 | 2.33 | +134 | +19.2 |
| FALLS SHORT | 73 | 58 | 7 | 2.33 | +17 | +2.4 |
| FOLLOW UP WEIGHED | 7 | 7 | 7 | 2.33 | +1336 | +190.9 |
| GOAL WALK | 55 | 55 | 7 | 2.33 | +105 | +14.9 |
| HARD STAY DROPPED | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| REDIRECT COUNTER | 31 | 28 | 7 | 2.33 | +523 | +74.7 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CHARGE NOW FIRST | 19 | 19 | 6 | 2.00 | -237 | -39.5 |
| RANDOM MOVE BY FIGURES | 9 | 9 | 6 | 2.00 | +212 | +35.4 |
| COMBAT PIVOT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | +706 | +141.2 |
| WHOLE FIGHT DANGER | 16 | 16 | 5 | 1.67 | +321 | +64.2 |
| CHAFF IN THE MOVE | 10 | 10 | 4 | 1.33 | +0 | +0.0 |
| RISK BY ARC | 24 | 18 | 4 | 1.33 | +70 | +17.6 |
| SHOOTS FROM THE BEST SPOT | 7 | 7 | 4 | 1.33 | +2 | +0.6 |
| STAY WORTH | 55 | 43 | 4 | 1.33 | +11 | +2.7 |
| CHARGE LOSSES | 63 | 62 | 3 | 1.00 | +41 | +13.6 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| IDLE COST | 39 | 24 | 3 | 1.00 | +52 | +17.2 |
| MANOEUVRE | 12 | 12 | 3 | 1.00 | +81 | +27.0 |
| MAX FOR POSITIONING | 10 | 9 | 3 | 1.00 | +11 | +3.7 |
| OVERRUNS AWAY | 5 | 4 | 3 | 1.00 | +125 | +41.8 |
| REDIRECT BY WHAT IT STOPS | 6 | 6 | 3 | 1.00 | +44 | +14.7 |
| SEARCH SPOT | 3 | 3 | 3 | 1.00 | +14 | +4.6 |
| STUCK PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 30 | 3 | 3 | 1.00 | +0 | +0.0 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +354 | +118.0 |
| ASSAILMENT BY POINTS | 2 | 2 | 2 | 0.67 | +11 | +5.4 |
| BEST PRIZE | 2 | 2 | 2 | 0.67 | -33 | -16.6 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | -9 | -4.7 |
| FALL BACK GOOD ORDER | 24 | 19 | 2 | 0.67 | +4 | +2.0 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.67 | -148 | -73.8 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +20 | +10.1 |
| SET UP BY THE SET | 14 | 14 | 2 | 0.67 | +169 | +84.3 |
| SHOTS IN THE MOVE | 48 | 39 | 2 | 0.67 | +32 | +15.8 |
| SURE REACH TOGETHER | 3 | 3 | 2 | 0.67 | +7 | +3.6 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +98 | +97.5 |
| EDGE GIVE GROUND | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 16 | 14 | 1 | 0.33 | +0 | +0.2 |
| FEATURE BUFFS | 7 | 7 | 1 | 0.33 | +19 | +19.1 |
| FIGHT TO THE END | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +83 | +82.8 |
| GOAL ROUTE | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HONEST WORTH | 26 | 21 | 1 | 0.33 | +18 | +18.0 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.33 | +638 | +637.8 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +6 | +6.3 |
| MISSILES NEXT TURN | 3 | 1 | 1 | 0.33 | +76 | +76.2 |
| NEARER NOT NEEDED | 43 | 42 | 1 | 0.33 | +8 | +8.3 |
| NO DOUBLE ROUNDS | 28 | 23 | 1 | 0.33 | +4 | +3.7 |
| ONE JOINT FIGURE | 1 | 1 | 1 | 0.33 | +1 | +0.7 |
| ONE OBJECTIVE FORMULA | 35 | 33 | 1 | 0.33 | +6 | +5.9 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -28 | -28.0 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | -18 | -18.2 |
| REFUSING RETIRES | 2 | 2 | 1 | 0.33 | -13 | -13.3 |
| WHO GETS IN | 1 | 1 | 1 | 0.33 | +638 | +637.8 |
| BACKUP TARGETS | 2 | 1 | 0 | 0.00 | - | - |
| CAST JOB | 2 | 2 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 2 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 69 | 65 | 0 | 0.00 | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 1 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 60 | not checked | - | - | - | - |
| FOOT FIRST | 149 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 60 | 56 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 37 | 35 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 50 | 49 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 5 | 5 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 34 | 34 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 31 | 30 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 17 | 17 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 48 | 45 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 62 | 57 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 4 | 4 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HOLD ODDS | 126 | 126 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 20 | 20 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 8 | 6 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 8 | 8 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 3 | 2 | 0 | 0.00 | - | - |
| NEAREST TO GOAL | 10 | 10 | 0 | 0.00 | - | - |
| NO LATE CUT | 8 | 8 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| ONE FIGHT FORMULA | 36 | 17 | 0 | 0.00 | - | - |
| ONE ROUTE | 8 | 8 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP | 4 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 260 | trace | - | - | - | - |
| REAL GROUND | 8 | 8 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 11 | 9 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 4 | 4 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 6 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 18 | 13 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 9 | 9 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 11 | 11 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 20 | not checked | - | - | - | - |
| SHOTS AFTER THE MOVES | 9 | 9 | 0 | 0.00 | - | - |
| SPELL WORTH | 6 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 55 | 54 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 2 | 2 | 0 | 0.00 | - | - |
| STANDS STILL | 203 | 200 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 11 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 14 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 9 | not checked | - | - | - | - |
| THE TABLE BINDS | 255 | not checked | - | - | - | - |
| WAITS AGAIN | 16 | 12 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | not checked | - | - | - | - |
| WHO FIGHTS | 3 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | not checked | - | - | - | - |

### Off best figure: gs3-83c8646-p48

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| ARMY TABLE | rule | 3.67 | 5.67 | 46.1 |
| JOB FIRST | gate | 2.67 | 5.33 | 45.8 |
| PROMISE BY ITS OWN SUM | rule | 1.33 | 4.67 | 74.7 |
| HOLDER ASSIGNMENT | rule | 1.00 | 2.33 | 20.2 |
| CHARGE NOW FIRST | rule | 1.33 | 0.67 | 39.5 |
| BEST PRIZE | rule | 0.33 | 0.33 | 16.6 |
| PIVOT GUARDS FLANK | rule | 0.33 | 0.33 | 73.8 |
| RULE SWITCHED OFF | gate | 0.67 | - | 44.7 |
| AFTERMATH BAND | gate | - | 0.33 | 2.1 |
| CHAFF PASSED | rule | - | 0.33 | 9.4 |
| NO REASON | gate | - | 0.33 | 27.2 |
| ONE PROMISE A TARGET | rule | 0.33 | - | 28.0 |
| REDIRECT WEIGHED | rule | 0.33 | - | 18.2 |
| REFUSING RETIRES | rule | - | 0.33 | 13.3 |

### Plans: gs3-83c8646-p48

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.7 | 55% | 319 | 241 | 76% |
| Mine | move | 30.7 | 92% | 1247 | 0 | 0% |
| Mine | shoot | 0.3 | 100% | 28 | 130 | 464% |
| Mine | support | 1.0 | 67% | 0 | 0 | - |
| Opponent | charge | 5.0 | 87% | 603 | 624 | 104% |
| Opponent | move | 41.0 | 95% | 1678 | 0 | 0% |
| Opponent | shoot | 3.3 | 50% | 201 | 26 | 13% |
| Opponent | support | 1.7 | 100% | 59 | 0 | 0% |

### Battle groups: gs3-83c8646-p48

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 7.0 | 14% | 33% | 0% | - | 0% | 0% | 0% | 67% | 33% |
| Opponent | REDIRECT COUNTER | 3.3 | 50% | 60% | 20% | 0% | 0% | 0% | 50% | 50% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p48

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 7 | 61 (7) | 0 | 61 | 49 | 71% | 4.5 | 0 (3) | 100 (2) | 90 (2) | 61 (7) | - |
| Mine | Character | 6 | 72 (6) | 72 | 0 | 17 | 0% | 2.8 | - | 105 (3) | 42 (3) | 61 (5) | 120 (1) |
| Mine | Clean-up | 1 | 76 (1) | 0 | 76 | 0 | 100% | - | - | 76 (1) | - | - | 76 (1) |
| Mine | Fast Hammer | 6 | 41 (6) | 12 | 29 | 52 | 17% | 4.6 | - | 63 (3) | 19 (3) | 16 (4) | 99 (2) |
| Mine | Hammer | 6 | 33 (6) | 0 | 33 | 74 | 17% | 3.4 | - | 45 (5) | 0 (1) | 48 (4) | 0 (2) |
| Mine | Holder | 3 | 0 (3) | 0 | 0 | 0 | 67% | 6.0 | 0 (1) | 0 (1) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Chaff | 5 | 321 (5) | 40 | 281 | 15 | 40% | 4.0 | 0 (2) | 796 (1) | 28 (2) | 379 (4) | 0 (1) |
| Opponent | Character | 7 | 58 (7) | 58 | 0 | 41 | 0% | 1.7 | 75 (2) | 67 (3) | - | 68 (2) | 72 (3) |
| Opponent | Clean-up | 6 | 52 (6) | 9 | 42 | 49 | 17% | 2.6 | 102 (2) | 0 (1) | 36 (3) | 55 (4) | 44 (2) |
| Opponent | Fast Hammer | 4 | 25 (4) | 16 | 9 | 44 | 0% | 1.2 | 29 (2) | 20 (2) | - | 19 (3) | 56 (1) |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Hammer | 9 | 0 (9) | 0 | 0 | 29 | 67% | 4.3 | - | 0 (6) | 0 (3) | 0 (7) | 0 (2) |
| Opponent | Holder | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | 0 (1) | - | - | - | 0 (1) |
| Opponent | Shooter | 3 | 128 (3) | 0 | 128 | 0 | 0% | 1.0 | 0 (1) | 150 (2) | - | 0 (1) | 150 (2) |

### Charged fights: gs3-83c8646-p48

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 1 | 626 | 0 | 2.0 | 1.5 | 0 | 0 | +0 | 0 of 2 | 2 of 2 | +0 | +0 |
| Mine | Warriors of Chaos | 2 | 0 | 344 | 3.0 | 1.0 | 114 | 0 | +114 | 1 of 6 | 4 of 6 | - | +114 |
| **Mine** | all armies | 3 | 209 | 229 | 2.7 | 1.1 | 86 | 0 | +86 | 1 of 8 | 6 of 8 | +0 | +98 |
| Opponent | Warriors of Chaos | 1 | 0 | 869 | 4.0 | 1.0 | 217 | 152 | +65 | 2 of 4 | 3 of 4 | - | +65 |
| Opponent | Wood Elf Realms | 2 | 15 | 546 | 5.0 | 1.1 | 109 | 12 | +98 | 4 of 10 | 9 of 10 | +45 | +103 |
| **Opponent** | all armies | 3 | 10 | 653 | 4.7 | 1.1 | 140 | 52 | +88 | 6 of 14 | 12 of 14 | +45 | +92 |

### Effective charges: gs3-83c8646-p48

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 2 | 0 | 0 | 0 | 0 | 2 (net +0) | 0 | 0 | 0% (0 of 2) |
| Mine | Warriors of Chaos | 6 | 0 | 0 | 1 (net +0) | 1 (net +0) | 1 (net +0) | 2 (net +289) | 1 | 20% (1 of 5) |
| Opponent | Warriors of Chaos | 4 | 1 (net -608) | 0 | 0 | 1 (net +494) | 0 | 1 (net +205) | 1 | 0% (0 of 3) |
| Opponent | Wood Elf Realms | 10 | 1 (net +0) | 0 | 2 (net +22) | 0 | 2 (net +31) | 2 (net +250) | 3 | 29% (2 of 7) |

### Charged fights, damage counted: gs3-83c8646-p48

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 365 | 173 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 76-89% | 1 | 205 | 285 | +0 | 48 | 51 | -4 | -1.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 365 | 198 | +289 | 289 | 0 | +289 | +79.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 492 | 72 | +0 | 42 | 0 | +42 | +8.6 |
| Mine | No odds | 1 | 489 | 109 | +109 | 109 | 0 | +109 | +22.3 |
| Mine | All fights | 8 | 408 | 147 | +86 | 108 | 6 | +101 | +24.8 |
| Opponent | Long shot (under 50%) | 2 | 298 | 496 | -304 | 94 | 470 | -377 | -126.2 |
| Opponent | Effective (55-75%) | 2 | 321 | 272 | +22 | 22 | 0 | +22 | +7.0 |
| Opponent | 76-89% | 1 | 479 | 494 | +494 | 494 | 0 | +494 | +103.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 492 | 235 | +235 | 251 | 0 | +251 | +50.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 500 | 88 | +31 | 116 | 58 | +58 | +11.6 |
| Opponent | No odds | 4 | 446 | 135 | +135 | 135 | 10 | +124 | +27.9 |
| Opponent | All fights | 14 | 427 | 247 | +88 | 161 | 78 | +82 | +19.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p48 | move | 25 | 3 (12%) | 3 (12%) | 9 (36%) | 13 (52%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2634 |
| Charmed Shield | Opponent | L2634, L3234 |

# Doctrine scorecard: gs3-83c8646-p61

### Scorecard: gs3-83c8646-p61

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 3 | 5 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0106 | 4 | 1 | Opponent | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 1189 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | - | 1 | 6 | 0 | 0 | 0 | 170 |
| L0206 | 2 | 1 | Opponent | - | - | 4 | 2 | 1 | 0 | 0 | 0 | 801 |
| **Average** | | | Mine | 0% | 3.0 | 5.0 | 0.3 | 3.3 | 0.0 | 0.0 | 0.0 | 56.7 |
| **Average** | | | Opponent | 0% | 0.0 | 3.0 | 2.0 | 0.7 | 0.0 | 0.0 | 0.0 | 663.3 |

### KPIs: gs3-83c8646-p61

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 10) | 69% (11 of 16) | 42% (11 of 26) |
| Winner chose to follow up after the loser gave ground |  | 0% (0 of 1); on the table 0% | - | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 50% (1 of 2); on the table 50% | 0% (0 of 1); on the table 0% | 33% (1 of 3); on the table 33% |
| Magic missiles tried each own turn | 50%+ | 38% (34 of 90) | - | 38% (34 of 90) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 47% (34 of 73) | - | 47% (34 of 73) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 100% (6 of 6) | - | 100% (6 of 6) |
| Points that never fought | lower | 49% (2768 of 5699) | 77% (4613 of 6000) | 63% (7381 of 11699) |
|   infantry points that never fought | lower | 59% (1328 of 2239) | 95% (2011 of 2111) | 77% (3339 of 4350) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 62% (10 of 16) | 60% (15 of 25) | 61% (25 of 41) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 4.0 uses a game | 0.0 uses a game | 100% (4 of 4); 2.0 uses a game |
| Bound items with another spell used |  | 50% (1 of 2); 1.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (4 of 4); 1.3 uses a game | 0.0 uses a game | 100% (4 of 4); 0.7 uses a game |
|   their share of the points of units over 100 pts | lower | 59% (2293 of 3916) | 56% (2475 of 4382) | 57% (4768 of 8298) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 7.0 (38%) | - | 7.0 (38%) |
| MARCHED: its unit marched | 5.3 (29%) | - | 5.3 (29%) |
| IN COMBAT: engaged in combat | 3.3 (18%) | - | 3.3 (18%) |
| FLEEING: fleeing | 0.7 (4%) | - | 0.7 (4%) |
| GONE: slain | 1.7 (9%) | - | 1.7 (9%) |
| STUPIDITY: Stupidity | 0.7 (4%) | - | 0.7 (4%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 0.7 | 6.7 | 11.3 | 0.0 | 1.0 |
| not cast | 1.7 | 3.3 | 3.3 | 18.7 | 2.0 | 27.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.3 (70%) | 0.0 (0%) | 7.0 (38%) | 1.7 (83%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 5.3 (29%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (20%) | 2.0 (60%) | 3.3 (18%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.3 (10%) | 0.3 (10%) | 0.7 (4%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.3 (10%) | 1.7 (9%) | 0.0 (0%) | 2.7 (10%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (4%) | 0.3 (17%) | 1.3 (5%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (100%) | 0.0 (0%) | 0.7 (20%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 22.3 (83%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 7.7 a game | 0.0 a game | 3.8 a game |
| stood (cast and not dispelled) | 65% (15 of 23) | - | 65% (15 of 23) |
| the unit moved after it | 67% (10 of 15) | - | 67% (10 of 15) |
| it charged on its next turn | 0% (0 of 15) | - | 0% (0 of 15) |
| the enemy charged it first | 27% (4 of 15) | - | 27% (4 of 15) |
| it fought by the end of its next turn | 20% (3 of 15) | - | 20% (3 of 15) |
| it moved out of a charge the enemy had planned (not charged first) | 7% (1 of 15) | - | 7% (1 of 15) |
| none of these (no charge, no fight, no charge escaped) | 67% (10 of 15) | - | 67% (10 of 15) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 50% (9 of 18) | 62% (121 of 196) | 61% (130 of 214) |
|   cavalry | - | 46% (11 of 24) | 46% (11 of 24) |
|   character | - | 50% (11 of 22) | 50% (11 of 22) |
|   chariot | - | 83% (5 of 6) | 83% (5 of 6) |
|   infantry | 50% (9 of 18) | 60% (40 of 67) | 58% (49 of 85) |
|   monster | - | 92% (11 of 12) | 92% (11 of 12) |
|   war machine | - | 66% (43 of 65) | 66% (43 of 65) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (56%) | 1.7 (7%) | 3.3 (12%) |
| CHARGED: it charged | 0.0 (0%) | 1.0 (4%) | 1.0 (4%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (1%) | 0.3 (1%) |
| NO TARGET IN RANGE | 0.3 (11%) | 10.0 (40%) | 10.3 (37%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 2.3 (9%) | 2.3 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (33%) | 5.3 (21%) | 6.3 (23%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.3 (1%) | 0.3 (1%) |
| OTHER BAR | 0.0 (0%) | 4.0 (16%) | 4.0 (14%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.7 | 0.7 | 88% | 1.7 pts | 10 pts |
| character | 3.7 | 5.0 | 64% | 28.2 pts | 103 pts |
| chariot | 1.7 | 0.3 | 80% | 2.2 pts | 4 pts |
| infantry | 23.3 | 11.7 | 70% | 4.9 pts | 115 pts |
| monster | 3.7 | 1.7 | 64% | 4.5 pts | 16 pts |
| war machine | 14.3 | 16.0 | 56% | 13.8 pts | 198 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.7 | 2.7 | 1.7 |
| Charges that made contact a game | 0.3 | 1.3 | 0.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.10 declared, 0.05 contact (20 units) | 0.30 declared, 0.15 contact (27 units) | 0.21 declared, 0.11 contact (47 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Character in a unit | 67% (2 of 3) | 100% (4 of 4) | - | 86% (6 of 7) |
| Character on its own | 100% (3 of 3) | 50% (1 of 2) | 50% (1 of 2) | 71% (5 of 7) |
| Infantry | 43% (3 of 7) | 43% (3 of 7) | - | 43% (6 of 14) |
| Monster | 40% (2 of 5) | - | - | 40% (2 of 5) |
| War Machines | 75% (6 of 8) | - | - | 75% (6 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 3 | 50% (1 of 2); on the table 50% | 38% (34 of 90) | 49% | 62% (10 of 16) | 100% (4 of 4); 4.0 uses a game | 50% (1 of 2); 1.0 uses a game | 100% (4 of 4); 1.3 uses a game |
| Dwarfen Mountain Holds | 2 | - | - | 86% | 65% (13 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 0% (0 of 1); on the table 0% | - | 58% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p61, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 25% (1) | 0% (0) | 20% (1) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p61

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 0.7 |
| Strategy | Charge objectives carried out (made contact) | 0% (0 of 1) | 14% (1 of 7) |
| Strategy | Shoot objectives carried out (shot that target) | 0% (0 of 10) | 38% (32 of 84) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 0% (0 of 1) | - |
| Strategy | Joined characters whose unit fought | 40% (4 of 10) | 0% (0 of 8) |
| Strategy | Lone characters that fought | 88% (7 of 8) | 100% (2 of 2) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 3.3 | 0.7 |
| Movement | Points that never moved of their own | 56.7 | 663.3 |
| Movement | Fights charged into per game | 0.3 | 1.3 |
| Movement | Charges with odds: long shots (under 50%) | - | 3 of 3, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | - | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | - | 0 of 3 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | - | 0 of 3 |
| Shooting | Shots by shooting units (incl. breath weapons) | 3.0 | 27.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 56% (5 of 9) | 53% (43 of 81) |
| Shooting | Points destroyed by shooting units | 24.0 | 336.0 |
| Shooting | War machine shots | - | 14.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | - | 67% (29 of 43) |
| Shooting | Points destroyed by war machines | 0.0 | 17.3 |
| Magic | Magic missiles cast | 4.3 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 54% (7 of 13) | - |
| Magic | Wounds caused by magic missiles | 9.3 | - |
| Magic | Wounds caused by other spells | 1.3 | - |
| Magic | Points destroyed by magic (all spells) | 20.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.3 / 0.0 / 0.7 / 0.0 | 4.0 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 93.3 | 75.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +148 | +110 |
| Combat | Net per 100 charger points, damage counted | +17.6 | +46.1 |
| Combat | First round won (charged fights) | 100% | 0% |
| Combat | Net points per charged fight | +220 | +56 |
| Combat | Net points per supported fight / lone fight | - / +220 | - / +56 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 1 | 3 of 4 |
| Game | Points lost | 497.3 | 271.0 |
| Game | VP from objectives | 586.7 | 620.0 |
| Game | Lone holders (player turns) | 3.0 | 0.0 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -491 VP
- The side that went first won 0 of 3 games with a winner
- Points traded per game (both sides' losses): 768
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p61

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +208.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 23.0 | +110.9 | 0.0 | 370.0 | 15.3 | +173.6 | 0.0 | 88.0 |
| BACKUP TARGETS | 0.3 | +2.5 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | - | - | - | - | 0.3 | -0.2 | 0.0 | 0.0 |
| BOMBING RUN | - | - | - | - | 0.3 | +3.0 | 0.0 | 0.0 |
| CANNON PLAN MISSED | - | - | - | - | 1.7 | +0.0 | 311.3 | 0.0 |
| CANNON PLANNED TARGET | - | - | - | - | 15.7 | +509.0 | 622.0 | 150.0 |
| CANNON SIGHT KEPT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 1.3 | +14.3 | 0.0 | 178.3 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 4.0 | +255.1 | 96.0 | 181.3 | - | - | - | - |
| CASTS AFTER FRIENDS | 5.0 | +0.0 | 0.0 | 73.3 | - | - | - | - |
| CATCH FLIERS | 0.3 | +7.4 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.3 | +5.2 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 1.7 | +0.0 | 0.0 | 24.0 |
| CHARACTER GUNS | - | - | - | - | 7.0 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 20.7 | -1592.0 | 0.0 | 75.0 | 12.0 | -246.9 | 0.0 | 184.0 |
| CHARGE NOW FIRST | - | - | - | - | 2.7 | +0.0 | 142.7 | 20.0 |
| CLOSES ON WHAT IT BEATS | 9.7 | +0.0 | 0.0 | 213.0 | 7.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 5.7 | +1127.8 | 254.7 | 146.7 | - | - | - | - |
| COVER ONCE | 4.7 | -264.3 | 0.0 | 39.0 | 3.0 | -108.4 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -5.1 | 21.7 | 0.0 |
| DEPLOY BY FIGURES | 6.7 | +87.5 | 0.0 | 0.0 | 12.3 | -197.3 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.7 | -374.1 | 0.0 | 0.0 |
| EXACT ROUND | 0.3 | +6.0 | 0.0 | 0.0 | 0.7 | +8.8 | 40.0 | 0.0 |
| FALL BACK GOOD ORDER | - | - | - | - | 1.7 | +0.0 | 112.3 | 20.0 |
| FALLS SHORT | 16.0 | +397.8 | 0.0 | 535.7 | 11.7 | +80.7 | 0.0 | 24.0 |
| FEATURE BUFFS | 14.3 | +455.7 | 0.0 | 271.0 | 1.0 | +4.0 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.7 | +8.7 | 0.0 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 0.7 | +0.0 | 25.7 | 0.0 |
| FIVE ACTION | 69.0 | +6273.5 | 96.0 | 1264.3 | 143.3 | +8413.0 | 2221.7 | 642.0 |
| FLANK NOT WEIGHED | 4.7 | +0.0 | 0.0 | 98.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 0.3 | +8.7 | 0.0 | 0.0 | 2.7 | +655.9 | 182.0 | 20.0 |
| FREED FROM HIS FIGHT | - | - | - | - | 1.3 | +0.0 | 0.0 | 70.0 |
| FRIEND SHOOTS FIRST | 0.7 | -8.0 | 0.0 | 0.0 | 2.0 | -74.7 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.3 | -1.3 | 90.7 | 20.0 |
| GOAL ON TIME | 0.7 | +51.9 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 14.0 | +2408.8 | 0.0 | 102.3 | 0.3 | +12.3 | 0.0 | 0.0 |
| GUN FIGURES | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| GUN MASK | - | - | - | - | 1.0 | +69.2 | 0.0 | 0.0 |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 90.7 | 7.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 12.7 | +0.0 | 0.0 | 31.7 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | 0.3 | +15.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 10.3 | +0.0 | 0.0 | 332.7 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 5.7 | -67.1 | 0.0 | 162.0 | 5.3 | -171.6 | 0.0 | 40.0 |
| HIS ONE QUARTER | 2.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 3.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 10.7 | +0.0 | 0.0 | 60.0 |
| HIS RANDOM MOVER COMES | - | - | - | - | 1.7 | +0.0 | 0.0 | 60.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 56.0 | +2105.3 | 0.0 | 883.0 | 56.7 | +1972.4 | 0.0 | 282.0 |
| HIS SHOTS BY HIS RUN | 45.3 | +1387.0 | 0.0 | 883.0 | 40.7 | +795.4 | 0.0 | 232.0 |
| HIS TURN DENIED | - | - | - | - | 1.0 | +18.8 | 112.3 | 20.0 |
| HOLD ODDS | 34.0 | +0.0 | 0.0 | 621.0 | 14.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 12.0 | +1308.1 | 0.0 | 191.3 | 9.0 | +1134.0 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.3 | -2.4 | 0.0 | 0.0 | 2.0 | -124.1 | 91.3 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 1.3 | +163.5 | 0.0 | 0.0 |
| IDLE COST | 14.3 | -89.9 | 0.0 | 270.0 | 3.0 | -58.9 | 0.0 | 0.0 |
| JOINT CHARGE NOW | - | - | - | - | 0.3 | -8.5 | 25.7 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 3.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +18.2 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 5.0 | +0.0 | 48.0 | 150.0 | 4.0 | +0.0 | 43.3 | 72.0 |
| LONE WIZARD KEPT IN | 2.7 | +247.6 | 0.0 | 0.0 | 0.7 | +60.4 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.3 | -0.6 | 0.0 | 0.0 | 1.3 | +1.6 | 51.3 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 1.0 | +47.7 | 0.0 | 24.0 |
| MANOEUVRE | 0.7 | +5.0 | 0.0 | 0.0 | 1.7 | -13.6 | 0.0 | 0.0 |
| MARCH BY THE SUM | 1.7 | +98.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.0 | +79.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.3 | -176.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.7 | +22.1 | 0.0 | 45.3 | 1.3 | +48.0 | 0.0 | 24.0 |
| MEETS IN TIME | 3.0 | +105.1 | 0.0 | 0.0 | 7.7 | +68.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 7.3 | +303.4 | 0.0 | 340.3 | - | - | - | - |
| MISSILES NEXT TURN | 9.0 | +279.3 | 0.0 | 235.3 | - | - | - | - |
| MISSILES ON ONE TARGET | 2.0 | -69.3 | 0.0 | 90.7 | - | - | - | - |
| MODEL FACING | - | - | - | - | 3.7 | +575.9 | 0.0 | 40.0 |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.3 | +9.5 | 0.0 | 73.3 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 3.3 | -190.9 | 0.0 | 63.3 | - | - | - | - |
| MOVE SPELL SPOT | 2.0 | +0.0 | 0.0 | 181.3 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 3.3 | +221.9 | 0.0 | 17.3 | 5.7 | +429.2 | 0.0 | 20.0 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 5.0 | +205.2 | 0.0 | 90.7 | 10.3 | +445.8 | 0.0 | 0.0 |
| NEAREST TO GOAL | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 2.3 | +158.1 | 0.0 | 17.3 | 4.0 | +115.2 | 51.3 | 20.0 |
| NO DOUBLE ROUNDS | - | - | - | - | 2.7 | -42.7 | 182.0 | 20.0 |
| NO LATE CUT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 5.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 4.3 | -185.2 | 0.0 | 44.0 | 6.7 | -266.2 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.0 | -22.3 | 0.0 | 28.3 | 5.3 | -109.8 | 0.0 | 40.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | -5.3 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 7.3 | +72.2 | 0.0 | 141.3 | 3.7 | -152.6 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.7 | -12.8 | 0.0 | 0.0 | 0.3 | -200.9 | 0.0 | 0.0 |
| ONE ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | - | - | - | - | 1.3 | +21.9 | 362.7 | 0.0 |
| OVERRUNS AWAY | 0.3 | +9.5 | 0.0 | 0.0 | 1.7 | +54.8 | 91.3 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -12.6 | 0.0 | 0.0 |
| PLAN RESULT | 30.7 | +61.8 | 24.0 | 510.7 | 62.3 | +1637.9 | 1246.7 | 475.3 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 1.7 | +0.0 | 0.0 | 0.0 | 5.3 | -26.9 | 0.0 | 20.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.3 | -0.5 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | - | - | - | - | 0.3 | -0.8 | 0.0 | 0.0 |
| QUARTER ODDS | 6.3 | +1300.7 | 0.0 | 0.0 | 16.0 | +839.9 | 0.0 | 216.7 |
| RANDOM MOVE BY FIGURES | 2.0 | +99.5 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.7 | +60.8 | 0.0 | 73.7 | 2.0 | +58.1 | 0.0 | 24.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.0 | +0.0 | 0.0 | 117.7 | 1.3 | +0.0 | 0.0 | 24.0 |
| REFORMS TO MEET IT | 1.3 | -11.1 | 0.0 | 0.0 | 1.7 | -90.9 | 0.0 | 20.0 |
| RESERVE FALL BACK | 0.3 | +2.7 | 0.0 | 0.0 | 1.0 | +7.5 | 0.0 | 0.0 |
| RESERVE MOVE SPELL | 1.0 | +9.9 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 0.3 | -17.3 | 0.0 | 0.0 | 2.7 | -72.4 | 182.0 | 20.0 |
| RISK ON THE WAY | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.7 | -25.1 | 73.0 | 0.0 |
| RUN DOWN | - | - | - | - | 1.7 | -20.3 | 73.0 | 0.0 |
| SAME CHARGE LATER | - | - | - | - | 0.3 | -33.9 | 0.0 | 20.0 |
| SCOUT SPOT | 0.7 | +0.4 | 0.0 | 0.0 | 0.7 | -0.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.3 | -53.5 | 0.0 | 18.3 | - | - | - | - |
| SEARCH SPOT | 0.3 | +19.9 | 0.0 | 0.0 | 1.3 | +62.5 | 0.0 | 20.0 |
| SET CREDITED ONCE | 0.7 | -1.9 | 0.0 | 0.0 | 2.0 | -255.5 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.3 | +13.4 | 0.0 | 0.0 | 6.3 | +106.9 | 51.3 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 1.0 | +47.7 | 0.0 | 24.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 1.7 | +4.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 3.0 | +0.0 | 0.0 | 217.3 | 28.3 | +0.0 | 0.0 | 150.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +54.1 | 0.0 | 0.0 | 1.0 | +41.2 | 51.3 | 20.0 |
| SHORT GUN FORWARD | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -298.8 | 90.7 | 20.0 |
| SHOT RISK POINTS | 39.0 | +734.9 | 0.0 | 604.7 | 43.0 | +245.2 | 0.0 | 302.0 |
| SHOTS AFTER THE MOVES | 0.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 3.7 | +73.3 | 0.0 | 65.0 | 46.0 | +1814.4 | 0.0 | 194.0 |
| SPELL SETS UP CHARGE | 0.7 | +314.7 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 1.0 | +6.1 | 0.0 | 0.0 | - | - | - | - |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | -8.1 | 90.7 | 20.0 |
| SPOT AS THE GAME MOVES | 6.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | 0.3 | -1.1 | 0.0 | 0.0 | 0.3 | -1.6 | 21.7 | 0.0 |
| STANDS FOR A REASON | 2.7 | +0.0 | 0.0 | 362.7 | 6.0 | +0.0 | 51.3 | 48.0 |
| STANDS STILL | 18.3 | +0.0 | 96.0 | 780.3 | 101.0 | +0.0 | 2039.7 | 438.0 |
| STAY WORTH | 4.7 | +75.2 | 48.0 | 43.3 | 76.0 | +911.3 | 1468.3 | 532.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.7 | +48.0 | 122.3 | 20.0 |
| SUPPORT ADDS | 3.7 | +328.9 | 0.0 | 84.0 | 0.7 | +1.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 3.7 | +328.9 | 0.0 | 84.0 | 0.7 | +1.0 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.7 | +26.0 | 0.0 | 24.0 |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 40.0 |
| THE ROW IN ITS ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.3 | +0.0 | 0.0 | 27.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 2.0 | +0.0 | 0.0 | 27.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 5.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 32.0 | +0.0 | 0.0 | 641.3 | 66.0 | +0.0 | 0.0 | 276.0 |
| TIED UP BY THE SUM | - | - | - | - | 1.3 | +78.9 | 91.3 | 0.0 |
| TIME ON OUR SIDE | 6.3 | +154.4 | 0.0 | 124.0 | 57.0 | +476.1 | 28.3 | 102.0 |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 21.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | - | - | - | - | 0.3 | +6.1 | 90.7 | 20.0 |
| WHO HITS BACK | 0.3 | +288.7 | 0.0 | 90.7 | - | - | - | - |
| WHOLE FIGHT DANGER | 4.7 | -1082.2 | 0.0 | 31.7 | 1.3 | -41.4 | 0.0 | 40.0 |
| WOUNDS ON THE RANKS | 8.0 | +590.0 | 0.0 | 0.0 | 2.0 | +12.3 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p61

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 115 | 115 | 81 | 27.00 | +756 | +9.3 |
| HIS SHOT LIST | 338 | 333 | 78 | 26.00 | +962 | +12.3 |
| HIS SHOTS BY HIS RUN | 258 | 253 | 72 | 24.00 | +605 | +8.4 |
| HOLDER ASSIGNMENT | 63 | 63 | 61 | 20.33 | +3177 | +52.1 |
| SHOT RISK POINTS | 246 | 239 | 61 | 20.33 | +2548 | +41.8 |
| DEPLOY BY FIGURES | 57 | 57 | 34 | 11.33 | +500 | +14.7 |
| OFF BEST | 33 | 33 | 33 | 11.00 | -1354 | -41.0 |
| TIME ON OUR SIDE | 190 | 182 | 31 | 10.33 | +115 | +3.7 |
| LEGAL CHARGES ONLY | 27 | 27 | 27 | 9.00 | +0 | +0.0 |
| HARD STAY DROPPED | 24 | 24 | 24 | 8.00 | +0 | +0.0 |
| FIVE ACTION | 637 | 630 | 23 | 7.67 | +1085 | +47.2 |
| GOAL WALK | 43 | 43 | 23 | 7.67 | +3980 | +173.0 |
| THE TABLE AGAIN | 35 | 35 | 19 | 6.33 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 27 | 25 | 15 | 5.00 | +460 | +30.7 |
| REDIRECT FOR A FRIEND IN REACH | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| MEETS IN TIME | 32 | 32 | 12 | 4.00 | +122 | +10.1 |
| MODEL FACING | 11 | 11 | 11 | 3.67 | +1728 | +157.1 |
| QUARTER ODDS | 67 | 67 | 11 | 3.67 | +861 | +78.3 |
| LONE WIZARD KEPT IN | 10 | 10 | 10 | 3.33 | +924 | +92.4 |
| CANNON PLANNED TARGET | 47 | 47 | 9 | 3.00 | -1 | -0.1 |
| NEXT CHARGE BY LIST | 19 | 19 | 9 | 3.00 | +205 | +22.8 |
| SET UP BY THE SET | 23 | 23 | 9 | 3.00 | +517 | +57.5 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| CASTING BLOCK | 12 | 12 | 7 | 2.33 | +155 | +22.1 |
| STAY WORTH | 242 | 230 | 7 | 2.33 | +134 | +19.1 |
| MOVE ORDER | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 21 | 21 | 6 | 2.00 | -81 | -13.4 |
| RANDOM MOVE BY FIGURES | 6 | 6 | 6 | 2.00 | +298 | +49.7 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 30 | 30 | 6 | 2.00 | +579 | +96.4 |
| CASTER AWAY FROM SCREEN | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHAFF PASSED | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 8 | 8 | 5 | 1.67 | -595 | -119.0 |
| MARCH BY THE SUM | 5 | 5 | 5 | 1.67 | +295 | +59.1 |
| SHOOTERS IN TWO RANKS | 5 | 5 | 5 | 1.67 | +12 | +2.4 |
| SHOOTS FROM THE BEST SPOT | 7 | 7 | 5 | 1.67 | +52 | +10.3 |
| CHARGE LOSSES | 98 | 96 | 4 | 1.33 | +1166 | +291.6 |
| FOUR ROUNDS | 9 | 9 | 4 | 1.33 | +138 | +34.4 |
| HIS MOVE AND SHOT | 33 | 33 | 4 | 1.33 | +91 | +22.7 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| IDLE COST | 52 | 37 | 4 | 1.33 | +42 | +10.5 |
| MISSILES IN THE MOVE | 22 | 16 | 4 | 1.33 | +95 | +23.8 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +31 | +7.7 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 149 | 129 | 4 | 1.33 | +204 | +51.1 |
| SUPPORT ADDS | 13 | 13 | 4 | 1.33 | +43 | +10.8 |
| SUPPORT WORKED OUT | 13 | 13 | 4 | 1.33 | +43 | +10.8 |
| TIED UP BY THE SUM | 4 | 4 | 4 | 1.33 | +128 | +31.9 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| ONE PROMISE A TARGET | 3 | 3 | 3 | 1.00 | -641 | -213.7 |
| OVERRUNS AWAY | 6 | 6 | 3 | 1.00 | +36 | +12.0 |
| RESERVE MOVE SPELL | 3 | 3 | 3 | 1.00 | +30 | +9.9 |
| FALLS SHORT | 83 | 66 | 2 | 0.67 | +4 | +1.9 |
| FEATURE BUFFS | 46 | 46 | 2 | 0.67 | +48 | +24.1 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| GOAL ON TIME | 2 | 2 | 2 | 0.67 | -44 | -21.9 |
| HUNT IN PAIRS | 4 | 4 | 2 | 0.67 | +198 | +99.2 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +55 | +27.4 |
| MAX FOR POSITIONING | 9 | 8 | 2 | 0.67 | +1 | +0.7 |
| REDIRECT COUNTER | 11 | 9 | 2 | 0.67 | +69 | +34.4 |
| SEARCH SPOT | 5 | 5 | 2 | 0.67 | +252 | +126.1 |
| SHOTS AFTER THE MOVES | 16 | 16 | 2 | 0.67 | +0 | +0.0 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +144 | +71.9 |
| SURE REACH TOGETHER | 2 | 2 | 2 | 0.67 | +38 | +19.1 |
| WHOLE FIGHT DANGER | 18 | 18 | 2 | 0.67 | +7 | +3.3 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +624 | +624.0 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -1 | -0.7 |
| BOMBING RUN | 1 | 1 | 1 | 0.33 | +9 | +9.0 |
| CAST JOB | 4 | 4 | 1 | 0.33 | +5 | +4.6 |
| DENIED BY THE FIGHT | 2 | 2 | 1 | 0.33 | +1 | +0.8 |
| FIGHT TO THE END | 2 | 2 | 1 | 0.33 | +1 | +0.8 |
| GUN MASK | 3 | 3 | 1 | 0.33 | +197 | +197.0 |
| JOINT CHARGE NOW | 1 | 1 | 1 | 0.33 | -26 | -25.5 |
| MANOEUVRE | 7 | 7 | 1 | 0.33 | +15 | +15.0 |
| MARCH CHECK | 3 | 3 | 1 | 0.33 | +47 | +47.2 |
| MISSILES NEXT TURN | 27 | 19 | 1 | 0.33 | +18 | +18.1 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| ONE OBJECTIVE FORMULA | 33 | 21 | 1 | 0.33 | +69 | +69.2 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -38 | -37.9 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -2 | -2.5 |
| RISK BY ARC | 9 | 9 | 1 | 0.33 | +1 | +0.7 |
| ROUNDS AFTER TERROR | 5 | 5 | 1 | 0.33 | +47 | +47.0 |
| SAME CHARGE LATER | 1 | 1 | 1 | 0.33 | +5 | +4.7 |
| THE ROW IN ITS ORDER | 10 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +855 | +854.7 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 5 | 5 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 15 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAFF IN THE MOVE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 21 | 21 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 50 | 49 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 17 | not checked | - | - | - | - |
| COVER ONCE | 23 | 17 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| EXACT ROUND | 3 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 5 | 5 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 17 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 8 | 8 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 3 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 52 | 52 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 43 | 43 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 12 | 12 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 20 | 20 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 21 | 21 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 32 | 31 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 5 | 4 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 3 | 3 | 0 | 0.00 | - | - |
| HOLD ODDS | 145 | 145 | 0 | 0.00 | - | - |
| HONEST WORTH | 7 | 7 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 23 | 23 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 3 | 3 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 5 | 5 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 3 | not checked | - | - | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 6 | not checked | - | - | - | - |
| MOVE SPELL IN RANGE | 1 | 1 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 10 | trace | - | - | - | - |
| MOVE SPELL SPOT | 6 | not checked | - | - | - | - |
| NEARER NOT NEEDED | 46 | 45 | 0 | 0.00 | - | - |
| NEAREST TO GOAL | 6 | 6 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 8 | 8 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 35 | 35 | 0 | 0.00 | - | - |
| ONE FIGHT FORMULA | 25 | 19 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS A LANE | 4 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 279 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 3 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 9 | 8 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 5 | 5 | 0 | 0.00 | - | - |
| RUN DOWN | 5 | 5 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 1 | 1 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 8 | 8 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 3 | 3 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 94 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 2 | not checked | - | - | - | - |
| SPELL WORTH | 3 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 30 | 29 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 26 | 24 | 0 | 0.00 | - | - |
| STANDS STILL | 358 | 356 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 10 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 8 | not checked | - | - | - | - |
| THE TABLE BINDS | 294 | not checked | - | - | - | - |
| WAITS AGAIN | 7 | 7 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p61

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.00 | 6.67 | 41.4 |
| ARMY TABLE | rule | 3.67 | 2.00 | 44.9 |
| HOLDER ASSIGNMENT | rule | 1.67 | 1.00 | 20.6 |
| PROMISE BY ITS OWN SUM | rule | - | 2.00 | 13.4 |
| CHARGE NOW FIRST | rule | - | 1.67 | 119.0 |
| ONE PROMISE A TARGET | rule | 0.67 | 0.33 | 213.7 |
| GOAL ON TIME | rule | 0.67 | - | 21.9 |
| BEST PRIZE | rule | - | 0.33 | 0.7 |
| CANNON PLANNED TARGET | rule | - | 0.33 | 0.8 |
| JOINT CHARGE NOW | rule | - | 0.33 | 25.5 |
| NO REASON | gate | 0.33 | - | 29.1 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 37.9 |
| PROMISE SHOT AWAY | rule | - | 0.33 | 2.5 |

### Plans: gs3-83c8646-p61

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | move | 28.0 | 93% | 2760 | 0 | 0% |
| Mine | shoot | 2.3 | 43% | 350 | 62 | 18% |
| Mine | support | 0.3 | 0% | 0 | 0 | - |
| Opponent | charge | 2.7 | 62% | 402 | 99 | 25% |
| Opponent | move | 37.0 | 96% | 1534 | 0 | 0% |
| Opponent | shoot | 22.7 | 82% | 1618 | 1539 | 95% |

### Battle groups: gs3-83c8646-p61

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.7 | 20% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 2.0 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p61

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 4 | 0 (4) | 0 | 0 | 62 | 75% | 3.0 | 0 (2) | - | 0 (2) | 0 (3) | 0 (1) |
| Mine | Character | 15 | 1 (15) | 1 | 0 | 13 | 13% | 3.2 | - | 0 (8) | 8 (2) | 4 (6) | 0 (4) |
| Mine | Clean-up | 3 | 0 (3) | 0 | 0 | 33 | 100% | - | 0 (1) | 0 (2) | - | 0 (3) | - |
| Mine | Fast Hammer | 2 | 0 (2) | 0 | 0 | 100 | 100% | - | 0 (2) | - | - | 0 (1) | 0 (1) |
| Mine | Hammer | 6 | 47 (6) | 14 | 33 | 16 | 33% | 3.5 | 35 (1) | 39 (3) | 65 (2) | 66 (4) | 16 (2) |
| Mine | Holder | 5 | 24 (5) | 0 | 24 | 21 | 60% | 3.5 | 0 (3) | 117 (1) | 0 (1) | 0 (1) | 30 (4) |
| Mine | Shooter | 2 | 209 (2) | 55 | 154 | 100 | 0% | 1.0 | - | 308 (1) | 111 (1) | 209 (2) | - |
| Mine | Wizard | 3 | 14 (3) | 14 | 0 | 78 | 0% | 2.7 | - | - | 0 (1) | 0 (1) | - |
| Opponent | Chaff | 2 | 278 (2) | 0 | 278 | 50 | 0% | 1.5 | 556 (1) | 0 (1) | - | 278 (2) | - |
| Opponent | Character | 8 | 30 (8) | 30 | 0 | 0 | 38% | 2.2 | 74 (1) | 27 (6) | 0 (1) | 48 (4) | 22 (4) |
| Opponent | Clean-up | 6 | 0 (6) | 0 | 0 | 17 | 17% | 2.6 | 0 (1) | 0 (5) | - | 0 (5) | 0 (1) |
| Opponent | Fast Hammer | 4 | 25 (4) | 25 | 0 | 0 | 50% | 1.5 | 0 (1) | 33 (1) | 29 (2) | 31 (3) | 0 (1) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 0 | 33% | 4.5 | 0 (1) | 0 (1) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Holder | 1 | 76 (1) | 76 | 0 | 0 | 0% | 2.0 | - | - | 76 (1) | 76 (1) | - |
| Opponent | Shooter | 10 | 62 (10) | 27 | 35 | 14 | 0% | 2.2 | 87 (2) | 60 (8) | - | 85 (8) | 0 (2) |
| Opponent | War machine | 12 | 36 (12) | 36 | 0 | 27 | 17% | 1.7 | 38 (10) | - | 23 (2) | 0 (2) | 44 (10) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (2) | - | - | 0 (2) |

### Charged fights: gs3-83c8646-p61

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 44 | 73 | 0.3 | 1.0 | 220 | 0 | +220 | 0 of 1 | 1 of 1 | - | +220 |
| Opponent | Dwarfen Mountain Holds | 2 | 502 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 2 | 0 of 2 | - | +0 |
| Opponent | Tomb Kings of Khemri | 1 | 55 | 225 | 2.0 | 1.0 | 112 | 0 | +112 | 2 of 2 | 0 of 2 | - | +112 |
| **Opponent** | all armies | 3 | 353 | 75 | 1.3 | 1.0 | 56 | 0 | +56 | 3 of 4 | 0 of 4 | - | +56 |

### Effective charges: gs3-83c8646-p61

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Dwarfen Mountain Holds | 2 | 2 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |

### Charged fights, damage counted: gs3-83c8646-p61

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | No odds | 1 | 836 | 50 | +220 | 220 | 72 | +148 | +17.6 |
| Mine | All fights | 1 | 836 | 50 | +220 | 220 | 72 | +148 | +17.6 |
| Opponent | Long shot (under 50%) | 3 | 174 | 255 | +0 | 52 | 26 | +26 | +15.0 |
| Opponent | No odds | 1 | 431 | 322 | +225 | 386 | 25 | +361 | +83.8 |
| Opponent | All fights | 4 | 238 | 272 | +56 | 135 | 26 | +110 | +46.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p61 | move | 20 | 2 (10%) | 0 (0%) | 3 (15%) | 15 (75%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122 |
| Ring of Doom | Mine | L0206 |

# Doctrine scorecard: gs3-83c8646-p73

### Scorecard: gs3-83c8646-p73

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | 4 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0110 | 2 | 1 | Opponent | - | - | - | 0 | 1 | 1 | 0 | 0 | 300 |
| L0126 | 6 | 1 | Mine | no | 9 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0126 | 6 | 1 | Opponent | no | 8 | 3 | 1 | 4 | 0 | 0 | 0 | 60 |
| L0210 | 6 | 1 | Mine | no | 4 | 4 | 2 | 4 | 0 | 0 | 0 | 170 |
| L0210 | 6 | 1 | Opponent | no | 8 | 5 | 1 | 0 | 0 | 0 | 0 | 165 |
| **Average** | | | Mine | 0% | 6.5 | 4.0 | 1.0 | 2.7 | 0.0 | 0.0 | 0.0 | 56.7 |
| **Average** | | | Opponent | 0% | 8.0 | 4.0 | 0.7 | 1.7 | 0.3 | 0.0 | 0.0 | 175.0 |

### KPIs: gs3-83c8646-p73

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 11) | 13% (2 of 15) | 8% (2 of 26) |
| Winner chose to follow up after the loser gave ground |  | - | - | - |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | - | 0% (0 of 1); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 0% (0 of 1); on the table 0% | - | 0% (0 of 1); on the table 0% |
| Magic missiles tried each own turn | 50%+ | 40% (36 of 90) | 43% (26 of 60) | 41% (62 of 150) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 41% (36 of 88) | 46% (26 of 57) | 43% (62 of 145) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 83% (5 of 6) | - | 83% (5 of 6) |
| Points that never fought | lower | 96% (5448 of 5699) | 91% (5467 of 5998) | 93% (10915 of 11697) |
|   infantry points that never fought | lower | 96% (2158 of 2239) | 100% (819 of 819) | 97% (2977 of 3058) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 50% (8 of 16) | 68% (17 of 25) | 61% (25 of 41) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 5.0 uses a game | 100% (4 of 4); 5.0 uses a game | 100% (8 of 8); 5.0 uses a game |
| Bound items with another spell used |  | 0% (0 of 2); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 4); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (4 of 4); 1.3 uses a game | 50% (1 of 2); 0.3 uses a game | 83% (5 of 6); 0.8 uses a game |
|   their share of the points of units over 100 pts | lower | 42% (1646 of 3916) | 64% (3731 of 5793) | 55% (5377 of 9709) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 10.3 (57%) | 4.3 (38%) | 14.7 (50%) |
| MARCHED: its unit marched | 2.7 (15%) | 5.7 (50%) | 8.3 (28%) |
| CHARGED: its unit charged | 1.3 (7%) | 0.0 (0%) | 1.3 (5%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (6%) | 0.7 (2%) |
| REAR RANK: in a rear rank | 2.0 (11%) | 0.0 (0%) | 2.0 (7%) |
| GONE: slain | 0.7 (4%) | 0.3 (3%) | 1.0 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 1.0 (6%) | 0.3 (3%) | 1.3 (5%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 10.0 | 4.3 | 9.0 | 20.7 | 1.7 | 0.7 |
| not cast | 2.0 | 3.7 | 9.0 | 29.3 | 4.3 | 31.3 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.0 (82%) | 1.7 (19%) | 14.7 (50%) | 0.7 (15%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 8.3 (28%) | 0.7 (15%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (5%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.7 (7%) | 0.7 (2%) | 0.0 (0%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (0%) | 2.0 (22%) | 2.0 (7%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.3 (17%) | 0.0 (0%) | 0.3 (4%) | 1.0 (3%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 1.3 (5%) | 3.0 (69%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (83%) | 0.7 (18%) | 4.0 (44%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 31.3 (100%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 8.0 a game | 1.0 a game | 4.5 a game |
| stood (cast and not dispelled) | 71% (17 of 24) | 33% (1 of 3) | 67% (18 of 27) |
| the unit moved after it | 71% (12 of 17) | 100% (1 of 1) | 72% (13 of 18) |
| it charged on its next turn | 0% (0 of 17) | 0% (0 of 1) | 0% (0 of 18) |
| the enemy charged it first | 0% (0 of 17) | 0% (0 of 1) | 0% (0 of 18) |
| it fought by the end of its next turn | 0% (0 of 17) | 0% (0 of 1) | 0% (0 of 18) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 17) | 0% (0 of 1) | 0% (0 of 18) |
| none of these (no charge, no fight, no charge escaped) | 100% (17 of 17) | 100% (1 of 1) | 100% (18 of 18) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 60% (12 of 20) | 79% (22 of 28) | 71% (34 of 48) |
|   chariot | - | 100% (10 of 10) | 100% (10 of 10) |
|   infantry | 60% (12 of 20) | - | 60% (12 of 20) |
|   war machine | - | 67% (12 of 18) | 67% (12 of 18) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (100%) | 0.0 (0%) | 2.7 (57%) |
| MOVED: a war machine that moved | 0.0 (0%) | 1.0 (50%) | 1.0 (21%) |
| OTHER BAR | 0.0 (0%) | 1.0 (50%) | 1.0 (21%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| chariot | 3.3 | 0.7 | 80% | 3.9 pts | 13 pts |
| infantry | 4.0 | 0.7 | 83% | 7.5 pts | 30 pts |
| war machine | 5.3 | 1.7 | 81% | 6.0 pts | 32 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.3 | 1.0 | 1.2 |
| Charges that made contact a game | 0.3 | 0.7 | 0.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.29 declared, 0.29 contact (7 units) | 0.29 declared, 0.29 contact (7 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 0.00 contact (1 units) | 1.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.20 declared, 0.05 contact (20 units) | 0.00 declared, 0.00 contact (15 units) | 0.11 declared, 0.03 contact (35 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | - | - | 50% (2 of 4) |
| Character in a unit | 80% (4 of 5) | 67% (4 of 6) | - | 73% (8 of 11) |
| Character on its own | 100% (1 of 1) | 100% (4 of 4) | 50% (2 of 4) | 78% (7 of 9) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 0% (0 of 2) | 0% (0 of 5) | 0% (0 of 1) | 0% (0 of 8) |
| Monster | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Monstrous | - | 100% (1 of 1) | - | 100% (1 of 1) |
| War Machines | 75% (3 of 4) | - | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 3 | 0% (0 of 1); on the table 0% | 40% (36 of 90) | 96% | 50% (8 of 16) | 100% (4 of 4); 5.0 uses a game | 0% (0 of 2); 0.0 uses a game | 100% (4 of 4); 1.3 uses a game |
| Grand Cathay | 2 | - | 43% (23 of 54) | 87% | 70% (14 of 20) | 100% (4 of 4); 7.5 uses a game | 0% (0 of 2); 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Vampire Counts | 1 | - | 50% (3 of 6) | 100% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p73, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (2) | 0% (0) | 67% (2) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.00 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.00 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p73

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 0% (0 of 2) | 33% (1 of 3) |
| Strategy | Shoot objectives carried out (shot that target) | 0% (0 of 12) | 39% (12 of 31) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 2) | 20% (1 of 5) |
| Strategy | Joined characters whose unit fought | 0% (0 of 15) | 0% (0 of 2) |
| Strategy | Lone characters that fought | 33% (1 of 3) | 12% (1 of 8) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.7 | 1.7 |
| Movement | Points that never moved of their own | 56.7 | 175.0 |
| Movement | Fights charged into per game | 0.3 | 0.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 1 | 0 of 2 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 1, net +162 | 0 of 2 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 1 | 2 of 2, net +42 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 1 | 0 of 2 |
| Shooting | Shots by shooting units (incl. breath weapons) | 4.0 | 3.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 67% (8 of 12) | 30% (3 of 10) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | - | 4.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | - | 15% (2 of 13) |
| Shooting | Points destroyed by war machines | 0.0 | 28.3 |
| Magic | Magic missiles cast | 9.7 | 7.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 41% (12 of 29) | 27% (6 of 22) |
| Magic | Wounds caused by magic missiles | 19.7 | 14.3 |
| Magic | Wounds caused by other spells | - | 0.7 |
| Magic | Points destroyed by magic (all spells) | 227.3 | 55.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 4.0 / 0.7 / 0.0 / 0.0 | 2.7 / 1.7 / 0.3 / 0.7 |
| Combat | Points destroyed in combat | 0.0 | 28.3 |
| Combat | Points run down | 0.0 | 21.7 |
| Combat | Net points per charged fight, damage counted | +150 | +57 |
| Combat | Net per 100 charger points, damage counted | +185.7 | +15.4 |
| Combat | First round won (charged fights) | 100% | 100% |
| Combat | Net points per charged fight | +162 | +42 |
| Combat | Net points per supported fight / lone fight | - / +162 | - / +42 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 1 | 0 of 2 |
| Game | Points lost | 209.0 | 436.3 |
| Game | VP from objectives | 986.7 | 526.7 |
| Game | Lone holders (player turns) | 6.5 | 8.0 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +690 VP
- The side that went first won 0 of 3 games with a winner
- Points traded per game (both sides' losses): 645
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p73

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 12.7 | +458.5 | 0.0 | 129.7 | 11.0 | +142.5 | 0.0 | 90.0 |
| ARTILLERY RE-ROLL WEIGHED | - | - | - | - | 3.3 | +0.0 | 0.0 | 110.0 |
| CANNON PLANNED TARGET | - | - | - | - | 4.0 | +125.6 | 119.7 | 220.0 |
| CANNON SIGHT KEPT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CAST JOB | - | - | - | - | 8.7 | +75.0 | 56.7 | 244.7 |
| CASTER AWAY FROM SCREEN | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 5.3 | +641.8 | 469.7 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 5.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 1.7 | +19.8 | 0.0 | 10.0 | 1.3 | +8.1 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +3.3 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 14.7 | -466.0 | 0.0 | 141.0 | 21.7 | -581.1 | 0.0 | 90.0 |
| CHARGE NOW FIRST | - | - | - | - | 0.7 | +0.0 | 50.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 9.0 | +0.0 | 0.0 | 141.7 | 12.3 | +0.0 | 0.0 | 352.7 |
| CONVEYANCE SEARCH | 6.7 | +622.5 | 0.0 | 0.0 | 0.3 | +10.4 | 0.0 | 0.0 |
| COVER ONCE | 3.7 | -300.7 | 0.0 | 0.0 | 12.7 | -517.8 | 0.0 | 200.7 |
| DEPLOY BY FIGURES | 6.0 | +68.6 | 0.0 | 0.0 | 7.3 | -110.4 | 0.0 | 13.3 |
| EXACT ROUND | 0.7 | +1.5 | 108.0 | 10.0 | 0.7 | +4.8 | 56.7 | 0.0 |
| FALL BACK GOOD ORDER | 0.3 | +0.0 | 54.0 | 0.0 | 0.3 | +0.0 | 28.3 | 0.0 |
| FALLS SHORT | 11.3 | +255.4 | 0.0 | 85.0 | 15.7 | +161.9 | 0.0 | 255.0 |
| FEATURE BUFFS | 16.3 | +517.6 | 0.0 | 0.0 | 2.7 | +120.1 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +0.8 | 108.0 | 10.0 | - | - | - | - |
| FIVE ACTION | 73.0 | +7790.4 | 722.3 | 472.7 | 91.0 | +3175.7 | 374.3 | 1610.7 |
| FLANK NOT WEIGHED | 4.7 | +0.0 | 0.0 | 113.3 | 8.3 | +0.0 | 0.0 | 180.7 |
| FOUR ROUNDS | 0.7 | +19.7 | 108.0 | 10.0 | 1.0 | +32.8 | 78.3 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 1.3 | -29.2 | 0.0 | 0.0 |
| GOAL ROUTE | 0.3 | +18.9 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 14.7 | +2018.8 | 0.0 | 69.3 | 8.0 | +455.9 | 0.0 | 0.0 |
| GUN MASK | - | - | - | - | 1.0 | +3.6 | 0.0 | 0.0 |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 45.0 |
| HIS CHARGE BY HIS RUN | 6.3 | +0.0 | 0.0 | 71.7 | 14.3 | +0.0 | 0.0 | 90.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +31.4 | 28.3 | 0.0 |
| HIS CHARGE LIST | 14.0 | +0.0 | 0.0 | 226.7 | 7.7 | +0.0 | 0.0 | 73.3 |
| HIS LEGAL MOVES | 3.7 | +0.0 | 0.0 | 43.3 | 8.0 | +0.0 | 0.0 | 136.7 |
| HIS MOVE AND SHOT | 14.0 | -203.2 | 0.0 | 258.0 | 4.0 | -127.9 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 3.7 | +0.0 | 0.0 | 43.3 | 14.7 | +0.0 | 0.0 | 210.0 |
| HIS RANDOM MOVE | - | - | - | - | 6.3 | +0.0 | 0.0 | 108.0 |
| HIS RANDOM MOVER COMES | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 48.3 | +1807.4 | 0.0 | 419.3 | 36.0 | +1959.2 | 0.0 | 699.3 |
| HIS SHOTS BY HIS RUN | 41.3 | +427.5 | 0.0 | 462.7 | 42.7 | +1394.2 | 0.0 | 701.3 |
| HIS TURN DENIED | 0.3 | +2.3 | 54.0 | 0.0 | - | - | - | - |
| HOLD ODDS | 44.3 | +0.0 | 0.0 | 43.3 | 26.7 | +0.0 | 0.0 | 108.0 |
| HOLDER ASSIGNMENT | 16.7 | +1826.3 | 0.0 | 21.7 | 15.3 | +1382.5 | 0.0 | 54.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HONEST WORTH | 0.3 | -0.4 | 54.0 | 10.0 | 1.0 | -40.4 | 78.3 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 1.3 | +29.9 | 0.0 | 136.7 |
| IDLE COST | 12.0 | -103.8 | 0.0 | 176.3 | 11.0 | -212.9 | 0.0 | 268.3 |
| JOINT CHARGE NOW | 0.3 | -0.0 | 54.0 | 10.0 | - | - | - | - |
| JOINT KNOWS CHALLENGE | 0.3 | -3.8 | 54.0 | 10.0 | - | - | - | - |
| KEEP FALLS | 0.3 | +3.6 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 2.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 2.0 | +53.2 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 11.7 | +0.0 | 286.7 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 2.7 | +270.0 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 0.3 | -1.5 | 54.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 0.7 | +1.2 | 108.0 | 10.0 | 0.7 | +0.6 | 50.0 | 0.0 |
| MANOEUVRE | 0.3 | +0.0 | 0.0 | 0.0 | 2.7 | -13.5 | 0.0 | 54.0 |
| MARCH BY THE SUM | 0.3 | +42.1 | 0.0 | 0.0 | 2.7 | +197.3 | 0.0 | 0.0 |
| MARCH CHECK | 1.7 | +71.5 | 0.0 | 0.0 | 2.0 | +240.1 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +16.3 | 0.0 | 0.0 | 1.3 | +74.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.7 | +86.2 | 0.0 | 0.0 | 2.3 | -102.1 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.7 | +50.7 | 0.0 | 28.3 | 6.0 | +75.9 | 0.0 | 136.7 |
| MEETS IN TIME | 2.7 | +200.3 | 0.0 | 0.0 | 3.7 | +336.1 | 0.0 | 13.3 |
| MISSILES IN THE MOVE | 9.3 | +632.2 | 0.0 | 0.0 | 12.7 | +143.4 | 0.0 | 244.7 |
| MISSILES NEXT TURN | 9.3 | +433.4 | 0.0 | 0.0 | 16.3 | +120.7 | 0.0 | 298.7 |
| MISSILES ON ONE TARGET | 1.7 | -95.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 0.7 | +0.0 | 28.3 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 3.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 0.7 | +98.4 | 0.0 | 56.7 | 9.3 | +347.3 | 0.0 | 210.0 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 8.0 | +370.2 | 0.0 | 0.0 | 7.0 | +277.4 | 0.0 | 108.0 |
| NEAREST TO GOAL | 3.7 | +0.0 | 0.0 | 34.7 | - | - | - | - |
| NEXT CHARGE BY LIST | - | - | - | - | 7.3 | +291.9 | 0.0 | 210.0 |
| NO DOUBLE ROUNDS | 0.7 | -20.0 | 108.0 | 10.0 | 1.0 | -16.5 | 78.3 | 0.0 |
| NO LATE CUT | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.7 | -0.8 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 2.7 | -181.9 | 0.0 | 21.7 | 2.3 | -38.7 | 0.0 | 105.0 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 6.0 | +25.5 | 17.3 | 55.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.3 | -34.1 | 0.0 | 56.7 | 6.7 | -124.6 | 0.0 | 68.3 |
| ONE OBJECTIVE FORMULA | 10.0 | +157.7 | 0.0 | 21.7 | 7.7 | -77.8 | 0.0 | 54.0 |
| ONE PROMISE A TARGET | - | - | - | - | 2.0 | -66.9 | 0.0 | 73.3 |
| ONE ROUTE | 1.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.3 | +1.3 | 54.0 | 0.0 | 0.7 | +14.2 | 50.0 | 0.0 |
| OWN CAST FIRST | - | - | - | - | 0.7 | -3.4 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -6.2 | 0.0 | 0.0 |
| PLAN RESULT | 33.7 | +400.2 | 99.0 | 268.0 | 40.0 | +263.9 | 74.0 | 792.0 |
| PROMISE BELOW ZERO | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 1.3 | -32.2 | 0.0 | 0.0 | 12.7 | -252.2 | 0.0 | 310.0 |
| PROMISE IN STEPS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.7 | -3.0 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 2.0 | +54.7 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | 1.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 1.3 | +26.9 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 3.3 | +242.4 | 0.0 | 123.3 | 1.3 | +69.3 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 4.3 | +44.3 | 0.0 | 20.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | - | - | - | - | 0.7 | -0.3 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 54.0 |
| RESERVE FALL BACK | - | - | - | - | 0.7 | +11.6 | 0.0 | 0.0 |
| RESERVE MOVE SPELL | 0.3 | +15.5 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 0.7 | +1.4 | 108.0 | 10.0 | 0.7 | -19.3 | 50.0 | 0.0 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.3 | +1.5 | 21.7 | 0.0 |
| RUN DOWN | 0.7 | -4.3 | 108.0 | 10.0 | 1.0 | -3.1 | 78.3 | 0.0 |
| SCOUT SPOT | 0.7 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | 1.7 | +7.7 | 0.0 | 10.0 | 0.7 | -66.7 | 0.0 | 0.0 |
| SEARCH SPOT | - | - | - | - | 1.0 | +5.5 | 0.0 | 0.0 |
| SET UP BY THE SET | - | - | - | - | 0.7 | +1.4 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.3 | +85.8 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 3.3 | +0.0 | 0.0 | 0.0 | 11.0 | +0.0 | 0.0 | 387.3 |
| SHOOTS FROM THE BEST SPOT | 0.3 | +34.0 | 0.0 | 0.0 | 1.3 | +6.9 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.7 | -3.7 | 56.7 | 55.0 |
| SHOT RISK POINTS | 38.7 | +183.7 | 0.0 | 419.3 | 36.0 | -130.1 | 0.0 | 728.0 |
| SHOTS AFTER THE MOVES | 0.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 3.7 | +48.0 | 0.0 | 21.7 | 9.3 | +285.1 | 0.0 | 420.0 |
| SPELL SETS UP CHARGE | 0.3 | +85.8 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 3.0 | +29.9 | 0.0 | 0.0 | 4.0 | +37.4 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | +0.4 | 28.3 | 0.0 |
| SPOT AS THE GAME MOVES | 6.7 | +0.0 | 0.0 | 85.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -4.7 | 21.7 | 0.0 |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 226.7 |
| STANDS STILL | 21.0 | +0.0 | 614.3 | 56.7 | 38.3 | +0.0 | 296.0 | 1158.0 |
| STAY WORTH | 6.0 | +59.9 | 396.0 | 0.0 | 15.3 | +150.0 | 267.7 | 273.0 |
| SUPPORT ADDS | 1.7 | +6.1 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 1.7 | +6.1 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.7 | +0.0 | 0.0 | 28.3 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 4.0 | +0.0 | 0.0 | 28.3 | 3.0 | +0.0 | 0.0 | 54.0 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 34.7 | +0.0 | 0.0 | 226.3 | 43.3 | +0.0 | 0.0 | 695.3 |
| TIED UP BY THE SUM | - | - | - | - | 0.7 | +93.0 | 50.0 | 0.0 |
| TIME ON OUR SIDE | 22.3 | +457.1 | 0.0 | 21.7 | 31.7 | +378.5 | 0.0 | 405.0 |
| WAITS AGAIN | - | - | - | - | 3.3 | +0.0 | 0.0 | 244.7 |
| WAR ENGINE JOBS | - | - | - | - | 1.7 | +0.0 | 0.0 | 90.0 |
| WHO FIGHTS | 0.3 | +2.1 | 54.0 | 10.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 2.0 | -127.7 | 0.0 | 43.3 | 2.0 | -146.5 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | 0.3 | +0.0 | 54.0 | 10.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 3.7 | +89.5 | 0.0 | 0.0 | 0.7 | +8.2 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p73

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 96 | 96 | 92 | 30.67 | +5858 | +63.7 |
| HIS SHOT LIST | 253 | 242 | 68 | 22.67 | +1430 | +21.0 |
| HIS SHOTS BY HIS RUN | 252 | 237 | 50 | 16.67 | +776 | +15.5 |
| SHOT RISK POINTS | 224 | 209 | 44 | 14.67 | +1497 | +34.0 |
| ARMY TABLE | 71 | 71 | 43 | 14.33 | +1292 | +30.1 |
| GOAL WALK | 68 | 68 | 36 | 12.00 | +2873 | +79.8 |
| LEGAL CHARGES ONLY | 35 | 35 | 35 | 11.67 | +0 | +0.0 |
| DEPLOY BY FIGURES | 40 | 40 | 25 | 8.33 | +250 | +10.0 |
| CAST JOB | 26 | 26 | 23 | 7.67 | +49 | +2.1 |
| THE TABLE AGAIN | 36 | 36 | 22 | 7.33 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 42 | 42 | 21 | 7.00 | -853 | -40.6 |
| OGRE LOADER SECOND SHOT | 18 | 18 | 18 | 6.00 | +76 | +4.2 |
| FIVE ACTION | 492 | 476 | 16 | 5.33 | +327 | +20.5 |
| TIME ON OUR SIDE | 162 | 137 | 16 | 5.33 | +79 | +4.9 |
| OFF BEST | 15 | 15 | 15 | 5.00 | -661 | -44.1 |
| CASTING BLOCK | 16 | 16 | 14 | 4.67 | +581 | +41.5 |
| MOVE TO CHARGE COMPUTED | 30 | 22 | 14 | 4.67 | +211 | +15.1 |
| NEXT CHARGE BY LIST | 22 | 16 | 11 | 3.67 | +152 | +13.8 |
| ARTILLERY RE-ROLL WEIGHED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| CHARGE LOSSES | 109 | 103 | 10 | 3.33 | +374 | +37.4 |
| MAX FOR POSITIONING | 23 | 21 | 10 | 3.33 | +57 | +5.7 |
| REDIRECT FOR A FRIEND IN REACH | 14 | 14 | 10 | 3.33 | +0 | +0.0 |
| HARD STAY DROPPED | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| MARCH BY THE SUM | 9 | 9 | 9 | 3.00 | +718 | +79.8 |
| MARCH CHECK | 11 | 11 | 9 | 3.00 | +240 | +26.6 |
| MEETS IN TIME | 19 | 19 | 9 | 3.00 | +555 | +61.7 |
| FALLS SHORT | 81 | 61 | 8 | 2.67 | +49 | +6.1 |
| FEATURE BUFFS | 57 | 57 | 8 | 2.67 | +217 | +27.1 |
| LONE WIZARD KEPT IN | 8 | 8 | 8 | 2.67 | +810 | +101.2 |
| COVER ONCE | 49 | 40 | 7 | 2.33 | +51 | +7.3 |
| IDLE COST | 69 | 46 | 6 | 2.00 | +66 | +10.9 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +160 | +26.6 |
| ONE PROMISE A TARGET | 6 | 6 | 6 | 2.00 | -201 | -33.4 |
| STAY WORTH | 64 | 63 | 6 | 2.00 | +128 | +21.3 |
| CASTER AWAY FROM SCREEN | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| MARCH OF THE TABLE | 5 | 5 | 5 | 1.67 | -271 | -54.2 |
| ONE OBJECTIVE FORMULA | 53 | 44 | 5 | 1.67 | +199 | +39.8 |
| RANDOM MOVE BY FIGURES | 6 | 6 | 5 | 1.67 | +164 | +32.8 |
| MOVE ORDER | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 39 | 36 | 4 | 1.33 | +18 | +4.5 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHAFF IN THE MOVE | 9 | 9 | 3 | 1.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SEARCH SPOT | 3 | 3 | 3 | 1.00 | +16 | +5.5 |
| SHOOTS FROM THE BEST SPOT | 5 | 5 | 3 | 1.00 | +17 | +5.7 |
| WOUNDS ON THE RANKS | 13 | 13 | 3 | 1.00 | +8 | +2.5 |
| CANNON SIGHT KEPT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FOUR ROUNDS | 5 | 5 | 2 | 0.67 | +7 | +3.5 |
| HUNT IN PAIRS | 4 | 3 | 2 | 0.67 | +22 | +10.8 |
| KEEP FALLS | 2 | 2 | 2 | 0.67 | +42 | +20.8 |
| OWN CAST FIRST | 2 | 2 | 2 | 0.67 | -10 | -5.1 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +35 | +17.4 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 11 | 2 | 2 | 0.67 | +0 | +0.0 |
| TIED UP BY THE SUM | 2 | 2 | 2 | 0.67 | +120 | +60.2 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +10 | +9.9 |
| CHARGE NOW FIRST | 2 | 2 | 1 | 0.33 | -6 | -5.6 |
| EXACT ROUND | 4 | 4 | 1 | 0.33 | +0 | +0.0 |
| FIGHT TO THE END | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| GOAL ROUTE | 1 | 1 | 1 | 0.33 | +57 | +56.7 |
| HIS MOVE AND SHOT | 54 | 54 | 1 | 0.33 | +0 | +0.0 |
| JOINT CHARGE NOW | 1 | 1 | 1 | 0.33 | -0 | -0.1 |
| LOST AFTER ESCAPE | 4 | 4 | 1 | 0.33 | +0 | +0.0 |
| MISSILES IN THE MOVE | 66 | 49 | 1 | 0.33 | +5 | +4.6 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| NEARER NOT NEEDED | 45 | 38 | 1 | 0.33 | +52 | +52.2 |
| ONE FIGHT FORMULA | 30 | 18 | 1 | 0.33 | +7 | +6.8 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -19 | -18.7 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -10 | -9.6 |
| RESERVE MOVE SPELL | 1 | 1 | 1 | 0.33 | +46 | +46.4 |
| SET UP BY THE SET | 2 | 2 | 1 | 0.33 | +15 | +15.0 |
| WHO FIGHTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| CANNON PLANNED TARGET | 12 | 12 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 16 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 64 | 61 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 21 | not checked | - | - | - | - |
| FALL BACK GOOD ORDER | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 39 | not checked | - | - | - | - |
| FRIEND SHOOTS FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GUN MASK | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 62 | 58 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 65 | 65 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 35 | 30 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 55 | 46 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 19 | 17 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 2 | 2 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HOLD ODDS | 213 | 212 | 0 | 0.00 | - | - |
| HONEST WORTH | 4 | 4 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 19 | 18 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| MANOEUVRE | 9 | 9 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 9 | 9 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 11 | 10 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 77 | 53 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 5 | not checked | - | - | - | - |
| MOVE SPELL SPOT | 10 | not checked | - | - | - | - |
| NEAREST TO GOAL | 11 | 11 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 5 | 5 | 0 | 0.00 | - | - |
| NO LATE CUT | 6 | 6 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE ROUTE | 11 | 10 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 221 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 11 | 10 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 4 | 4 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 14 | 10 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 2 | not checked | - | - | - | - |
| RISK BY ARC | 4 | 4 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 3 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 5 | 5 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 7 | 7 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 43 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 10 | 10 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 21 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 35 | 34 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 16 | 16 | 0 | 0.00 | - | - |
| STANDS STILL | 178 | 171 | 0 | 0.00 | - | - |
| SUPPORT ADDS | 5 | 5 | 0 | 0.00 | - | - |
| SUPPORT WORKED OUT | 5 | 5 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 21 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 9 | not checked | - | - | - | - |
| THE TABLE BINDS | 234 | not checked | - | - | - | - |
| WAITS AGAIN | 10 | 8 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 5 | 5 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 12 | 12 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p73

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 0.67 | 6.33 | 40.6 |
| JOB FIRST | gate | 2.67 | 2.00 | 46.6 |
| ARMY TABLE | rule | 0.67 | 1.00 | 7.8 |
| MARCH OF THE TABLE | rule | 0.33 | 1.33 | 54.2 |
| HOLDER ASSIGNMENT | rule | 1.33 | - | 33.1 |
| ONE PROMISE A TARGET | rule | - | 1.33 | 50.3 |
| DEPLOY BY FIGURES | rule | 0.33 | 0.33 | 1.9 |
| OWN CAST FIRST | rule | - | 0.67 | 5.1 |
| CHARGE NOW FIRST | rule | - | 0.33 | 5.6 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 18.7 |
| REFUSING RETIRES | rule | - | 0.33 | 9.6 |
| RULE SWITCHED OFF | gate | - | 0.33 | 8.4 |

### Plans: gs3-83c8646-p73

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.7 | 50% | 24 | 54 | 228% |
| Mine | move | 29.0 | 94% | 2722 | 0 | 0% |
| Mine | shoot | 3.0 | 100% | 680 | 346 | 51% |
| Mine | support | 1.0 | 100% | 29 | 0 | 0% |
| Opponent | charge | 0.7 | 100% | 61 | 50 | 81% |
| Opponent | move | 31.0 | 96% | 1294 | 0 | 0% |
| Opponent | shoot | 8.3 | 60% | 218 | 214 | 98% |

### Battle groups: gs3-83c8646-p73

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.3 | 20% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 1.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p73

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 3 | 0 (3) | 0 | 0 | 21 | 100% | - | 0 (1) | 0 (1) | 0 (1) | 0 (3) | - |
| Mine | Character | 18 | 23 (18) | 23 | 0 | 11 | 22% | 2.4 | 8 (3) | 20 (13) | - | 25 (7) | 11 (9) |
| Mine | Clean-up | 3 | 0 (3) | 0 | 0 | 33 | 100% | - | 0 (2) | 0 (1) | - | 0 (2) | 0 (1) |
| Mine | Fast Hammer | 2 | 0 (2) | 0 | 0 | 100 | 50% | 5.0 | - | 0 (2) | - | 0 (2) | - |
| Mine | Hammer | 7 | 116 (7) | 7 | 109 | 0 | 86% | 4.0 | 104 (1) | 143 (4) | 0 (2) | 99 (5) | 152 (2) |
| Mine | Holder | 3 | 76 (3) | 0 | 76 | 0 | 100% | - | - | 0 (1) | 214 (1) | 214 (1) | 0 (1) |
| Mine | Shooter | 4 | 46 (4) | 0 | 46 | 25 | 0% | 2.0 | 0 (2) | 46 (1) | 138 (1) | 46 (4) | - |
| Opponent | Chaff | 4 | 263 (4) | 0 | 263 | 20 | 100% | - | 171 (2) | 600 (1) | 0 (1) | 0 (2) | 450 (2) |
| Opponent | Character | 10 | 10 (10) | 10 | 0 | 7 | 20% | 1.6 | 0 (1) | 5 (4) | 16 (5) | 3 (8) | 36 (2) |
| Opponent | Clean-up | 3 | 41 (3) | 0 | 41 | 23 | 67% | 2.0 | 93 (1) | 58 (1) | 8 (1) | 41 (3) | - |
| Opponent | Fast Hammer | 6 | 31 (6) | 0 | 31 | 46 | 17% | 1.6 | - | 38 (5) | 0 (1) | 31 (6) | - |
| Opponent | Hammer | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Holder | 1 | 53 (1) | 0 | 53 | 0 | 100% | - | - | - | 53 (1) | 53 (1) | - |
| Opponent | War machine | 4 | 13 (4) | 13 | 0 | 75 | 0% | 2.0 | 0 (1) | 17 (3) | - | - | 13 (4) |

### Charged fights: gs3-83c8646-p73

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 227 | 54 | 0.3 | 1.0 | 162 | 0 | +162 | 0 of 1 | 1 of 1 | - | +162 |
| Opponent | Grand Cathay | 2 | 126 | 42 | 1.0 | 1.0 | 42 | 0 | +42 | 0 of 2 | 2 of 2 | - | +42 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 84 | 28 | 0.7 | 1.0 | 42 | 0 | +42 | 0 of 2 | 2 of 2 | - | +42 |

### Effective charges: gs3-83c8646-p73

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 0 | 0 | 1 (net +162) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | Grand Cathay | 2 | 0 | 0 | 0 | 0 | 2 (net +42) | 0 | 0 | 0% (0 of 2) |

### Charged fights, damage counted: gs3-83c8646-p73

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 81 | 162 | +162 | 162 | 12 | +150 | +185.7 |
| Mine | All fights | 1 | 81 | 162 | +162 | 162 | 12 | +150 | +185.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 369 | 85 | +42 | 57 | 0 | +57 | +15.4 |
| Opponent | All fights | 2 | 369 | 85 | +42 | 57 | 0 | +57 | +15.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p73 | move | 20 | 3 (15%) | 2 (10%) | 0 (0%) | 17 (85%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126 |
| Charmed Shield | Opponent | L0126 |
| Ring of Doom | Mine | L0210 |
| Ring of Jet | Opponent | L0110, L0210 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |

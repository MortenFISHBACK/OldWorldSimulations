# Doctrine scorecard: gs3-83c8646-p60

### Scorecard: gs3-83c8646-p60

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2531 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 211 |
| L2531 | 5 | 1 | Opponent | yes | - | 1 | 2 | 3 | 0 | 0 | 0 | 170 |
| L2730 | 6 | 1 | Mine | no | 0 | 5 | 6 | 2 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 2 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 0 | 3 | 2 | 2 | 1 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Opponent | no | 2 | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 0.0 | 4.0 | 2.7 | 1.7 | 0.3 | 0.0 | 0.0 | 70.3 |
| **Average** | | | Opponent | 33% | 2.0 | 1.7 | 2.3 | 3.0 | 0.0 | 0.0 | 0.0 | 56.7 |

### KPIs: gs3-83c8646-p60

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 17) | 0% (0 of 16) | 0% (0 of 33) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 75% (6 of 8); on the table 88% | 78% (7 of 9); on the table 89% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | 0% (0 of 2); on the table 0% | 33% (1 of 3); on the table 33% |
| Winner chose to follow up or pursue (all three) |  | 100% (2 of 2); on the table 100% | 64% (7 of 11); on the table 73% | 69% (9 of 13); on the table 77% |
| Magic missiles tried each own turn | 50%+ | 50% (3 of 6) | 33% (2 of 6) | 42% (5 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 100% (3 of 3) | 33% (2 of 6) | 56% (5 of 9) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 50% (2 of 4) | 58% (7 of 12) | 56% (9 of 16) |
| Points that never fought | lower | 41% (2439 of 5998) | 53% (3182 of 5998) | 47% (5621 of 11996) |
|   infantry points that never fought | lower | 63% (565 of 902) | 69% (738 of 1072) | 66% (1303 of 1974) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 68% (13 of 19) | 65% (17 of 26) | 67% (30 of 45) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (1 of 1); 0.7 uses a game | 100% (1 of 1); 0.3 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 63% (3168 of 5038) | 62% (3321 of 5360) | 62% (6489 of 10398) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (100%) | 1.3 (57%) |
| GONE: slain | 1.0 (100%) | 0.0 (0%) | 1.0 (43%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 2.3 | 1.7 | 1.0 | 1.7 | 0.3 | 1.3 |
| not cast | 3.7 | 0.0 | 3.0 | 2.3 | 1.7 | 22.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | - | 0.7 (22%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | - | 0.0 (0%) | 1.3 (57%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | - | 1.0 (33%) | 1.0 (43%) | 1.0 (60%) | 2.0 (9%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| STUPIDITY: Stupidity | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (6%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.7 (40%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.7 (100%) | - | 1.3 (44%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.7 (82%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 0.0 a game | 0.5 a game |
| stood (cast and not dispelled) | 100% (3 of 3) | - | 100% (3 of 3) |
| the unit moved after it | 100% (3 of 3) | - | 100% (3 of 3) |
| it charged on its next turn | 0% (0 of 3) | - | 0% (0 of 3) |
| the enemy charged it first | 0% (0 of 3) | - | 0% (0 of 3) |
| it fought by the end of its next turn | 0% (0 of 3) | - | 0% (0 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 3) | - | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | 100% (3 of 3) | - | 100% (3 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 33% (3 of 9) | 60% (21 of 35) | 55% (24 of 44) |
|   cavalry | 60% (3 of 5) | 73% (8 of 11) | 69% (11 of 16) |
|   character | 0% (0 of 4) | 38% (6 of 16) | 30% (6 of 20) |
|   infantry | - | 88% (7 of 8) | 88% (7 of 8) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.3 (17%) | 1.0 (21%) | 1.3 (20%) |
| CHARGED: it charged | 0.7 (33%) | 2.0 (43%) | 2.7 (40%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (7%) | 0.3 (5%) |
| NO TARGET IN RANGE | 0.7 (33%) | 0.3 (7%) | 1.0 (15%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (17%) | 1.0 (21%) | 1.3 (20%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.3 | 2.0 | 79% | 3.9 pts | 25 pts |
| character | 2.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 4.3 | 0.7 | 85% | 6.4 pts | 28 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.0 | 3.7 | 3.8 |
| Charges that made contact a game | 2.7 | 2.7 | 2.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | - | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.40 declared, 0.40 contact (5 units) | 0.00 declared, 0.00 contact (1 units) | 0.33 declared, 0.33 contact (6 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.45 declared, 0.27 contact (22 units) | 0.46 declared, 0.33 contact (24 units) | 0.46 declared, 0.30 contact (46 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 57% (4 of 7) | 100% (5 of 5) | 0% (0 of 1) | 69% (9 of 13) |
| Character in a unit | 100% (6 of 6) | 100% (1 of 1) | 100% (1 of 1) | 100% (8 of 8) |
| Character on its own | 0% (0 of 1) | 50% (1 of 2) | 43% (3 of 7) | 40% (4 of 10) |
| Infantry | 57% (4 of 7) | 0% (0 of 1) | - | 50% (4 of 8) |
| Monster | 67% (2 of 3) | 100% (1 of 1) | - | 75% (3 of 4) |
| Monstrous | 100% (2 of 2) | - | - | 100% (2 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vampire Counts | 2 | 100% (1 of 1); on the table 100% | 50% (3 of 6) | 45% | 83% (10 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 3 | 75% (6 of 8); on the table 88% | 33% (2 of 6) | 53% | 68% (17 of 25) | 100% (1 of 1); 0.7 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Wood Elf Realms | 1 | 50% (2 of 4); on the table 50% | - | 33% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p60, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 57% (4) | 100% (6) | 77% (10) |
| ...free all their last turn and able to turn (per game) | 0.67 | 1.67 | 2.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.67 | 0.33 | 1.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 1.33 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.33 | 0.67 | 1.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p60

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 58% (7 of 12) | 73% (8 of 11) |
| Strategy | Shoot objectives carried out (shot that target) | - | 22% (2 of 9) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | - |
| Strategy | Joined characters whose unit fought | 25% (1 of 4) | 0% (0 of 5) |
| Strategy | Lone characters that fought | 78% (7 of 9) | 100% (5 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.7 | 3.0 |
| Movement | Points that never moved of their own | 70.3 | 56.7 |
| Movement | Fights charged into per game | 2.7 | 2.7 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 8, net +0 | 1 of 8, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 8, net +26 | 1 of 8, net +254 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 8, net +45 | 0 of 8 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 8, net +0 | 5 of 8, net +150 |
| Shooting | Shots by shooting units (incl. breath weapons) | 1.7 | 7.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 20% (1 of 5) | 65% (15 of 23) |
| Shooting | Points destroyed by shooting units | 9.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.7 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 2) | 100% (1 of 1) |
| Magic | Wounds caused by other spells | 0.7 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.0 / 1.3 / 0.3 | 0.0 / 1.3 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 44.7 | 299.3 |
| Combat | Points run down | 0.0 | 124.3 |
| Combat | Net points per charged fight, damage counted | +40 | +152 |
| Combat | Net per 100 charger points, damage counted | +19.4 | +43.1 |
| Combat | First round won (charged fights) | 88% | 88% |
| Combat | Net points per charged fight | +23 | +149 |
| Combat | Net points per supported fight / lone fight | - / +23 | - / +149 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 8 | 1 of 8 |
| Game | Points lost | 542.7 | 172.3 |
| Game | VP from objectives | 440.0 | 610.0 |
| Game | Lone holders (player turns) | 0.0 | 2.0 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -553 VP
- The side that went first won 0 of 3 games with a winner
- Points traded per game (both sides' losses): 715
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p60

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +7.1 | 0.0 | 0.0 | 0.7 | +53.8 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | 0.3 | +35.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 25.3 | +333.4 | 0.0 | 540.7 | 20.3 | +241.1 | 0.0 | 107.0 |
| ASSAILMENT BY POINTS | 0.7 | +0.6 | 0.0 | 98.7 | - | - | - | - |
| BACKUP TARGETS | 0.7 | +2.8 | 0.0 | 0.0 | 0.3 | +1.0 | 0.0 | 0.0 |
| CAST JOB | - | - | - | - | 2.3 | +29.5 | 49.0 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 70.3 | - | - | - | - |
| CASTS FROM BEHIND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.7 | +19.5 | 0.0 | 0.0 | 0.3 | +11.1 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 0.3 | -0.1 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 1.0 | +16.4 | 0.0 | 153.0 | 1.7 | +41.3 | 0.0 | 35.7 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -3.9 | 0.0 | 0.0 |
| CHARGE LOSSES | 18.3 | -811.6 | 0.0 | 877.3 | 8.0 | -314.1 | 0.0 | 237.3 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 121.7 | 0.0 | 3.7 | +0.0 | 491.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 20.7 | +0.0 | 0.0 | 98.0 | 15.3 | +0.0 | 0.0 | 32.7 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONTINUE AHEAD WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 1.0 | +17.3 | 0.0 | 70.3 | - | - | - | - |
| COVER ONCE | 9.0 | -477.6 | 0.0 | 277.3 | 8.3 | -449.5 | 0.0 | 86.0 |
| DEFENSIVE FLOOR | - | - | - | - | 0.3 | +3.2 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 7.0 | +107.4 | 0.0 | 15.0 | 7.3 | -37.6 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -27.3 | 124.3 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +54.6 | 84.7 | 0.0 |
| EXACT ROUND | 2.3 | +28.4 | 98.0 | 15.0 | 2.0 | +32.4 | 156.3 | 0.0 |
| FACES THE THREAT | 0.3 | +0.0 | 0.0 | 70.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 4.0 | +0.5 | 196.0 | 15.0 | 3.3 | +0.0 | 349.0 | 0.0 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | 27.7 | +357.6 | 0.0 | 652.0 | - | - | - | - |
| FEATURE BUFFS | 0.7 | +6.9 | 0.0 | 0.0 | 1.7 | +18.4 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +20.0 | 0.0 | 0.0 | 1.0 | +31.7 | 0.0 | 0.0 |
| FIVE ACTION | 87.7 | +4485.0 | 196.0 | 1481.0 | 90.7 | +5380.8 | 693.0 | 392.0 |
| FLANK NOT WEIGHED | 9.7 | +0.0 | 0.0 | 209.3 | 7.0 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.3 | +36.0 | 0.0 | 0.0 | 1.7 | +194.3 | 0.0 | 0.0 |
| FOOT FIRST | 32.0 | +0.0 | 0.0 | 761.0 | - | - | - | - |
| FOUR ROUNDS | 4.0 | +95.0 | 196.0 | 15.0 | 3.7 | +323.3 | 417.3 | 0.0 |
| FREED FROM HIS FIGHT | 2.7 | +0.0 | 0.0 | 385.3 | 7.7 | +0.0 | 0.0 | 32.7 |
| GIVES UP | - | - | - | - | 0.3 | -0.4 | 0.0 | 0.0 |
| GOAL ON TIME | 0.3 | +63.4 | 0.0 | 0.0 | - | - | - | - |
| GOAL ROUTE | 0.7 | +52.2 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 8.3 | +796.7 | 0.0 | 0.0 | 15.3 | +1022.1 | 0.0 | 0.0 |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 70.3 | 2.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.0 | +0.0 | 0.0 | 385.3 | 2.0 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 13.0 | +0.0 | 0.0 | 832.0 | 6.7 | +0.0 | 0.0 | 237.3 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +2.5 | 0.0 | 0.0 |
| HIS CHARGE LIST | 4.3 | +0.0 | 0.0 | 248.7 | 13.3 | +0.0 | 0.0 | 169.3 |
| HIS LEGAL MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 71.3 |
| HIS MOVE AND SHOT | 1.3 | -9.1 | 0.0 | 0.0 | 0.7 | -42.6 | 0.0 | 0.0 |
| HIS ONE QUARTER | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 9.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 71.3 |
| HIS RANDOM MOVE | 16.7 | +0.0 | 0.0 | 582.0 | 10.7 | +0.0 | 0.0 | 133.7 |
| HIS RANDOM MOVER COMES | 5.3 | +0.0 | 0.0 | 95.3 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 46.0 | +524.3 | 0.0 | 1143.7 | 12.0 | +337.0 | 0.0 | 0.0 |
| HIS SHOTS BY HIS RUN | 37.3 | +246.2 | 0.0 | 1068.7 | 11.7 | +206.5 | 0.0 | 106.7 |
| HIS TURN DENIED | 0.3 | +17.5 | 35.7 | 0.0 | - | - | - | - |
| HOLD ODDS | 18.0 | +0.0 | 0.0 | 497.3 | 21.7 | +0.0 | 0.0 | 210.7 |
| HOLDER ASSIGNMENT | 10.3 | +976.7 | 0.0 | 248.7 | 12.3 | +1364.3 | 0.0 | 121.7 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.7 | -98.5 | 163.3 | 0.0 | 3.7 | -106.9 | 417.3 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +45.3 | 0.0 | 0.0 |
| IDLE COST | 19.7 | -277.8 | 0.0 | 258.0 | - | - | - | - |
| JOINT CHARGE NOW | 1.0 | +31.6 | 65.3 | 0.0 | 0.7 | -97.6 | 124.3 | 0.0 |
| KEEP FALLS | - | - | - | - | 0.3 | +6.2 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.0 | +42.8 | 0.0 | 0.0 | 0.7 | +13.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.7 | +0.0 | 0.0 | 79.0 | 7.7 | +0.0 | 247.0 | 175.0 |
| LONG SHOT | - | - | - | - | 0.3 | -1.6 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 2.7 | +25.9 | 98.0 | 15.0 | 2.0 | -0.3 | 276.0 | 0.0 |
| LOST CHARGE | - | - | - | - | 0.3 | -2.7 | 84.7 | 0.0 |
| MANOEUVRE | 1.3 | -41.2 | 0.0 | 124.3 | 1.0 | -0.3 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.7 | +7.8 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 1.0 | +6.1 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.7 | +30.7 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | +34.1 | 0.0 | 70.3 | 1.0 | -14.5 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.7 | +111.6 | 0.0 | 25.0 | 3.0 | +115.4 | 0.0 | 9.0 |
| MEETS IN TIME | 3.7 | +311.9 | 0.0 | 0.0 | 3.3 | +260.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 0.7 | +1.6 | 0.0 | 70.3 | 2.0 | +39.6 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 1.0 | +1.7 | 0.0 | 140.7 | 3.0 | +31.9 | 0.0 | 0.0 |
| MOVE ORDER | 2.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 9.0 | 35.7 |
| MOVE TO CHARGE COMPUTED | 9.7 | +524.9 | 0.0 | 0.0 | 3.3 | +257.6 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 7.3 | +319.1 | 0.0 | 124.3 | 7.7 | +367.3 | 0.0 | 65.3 |
| NEAREST TO GOAL | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 6.7 | +388.2 | 0.0 | 0.0 | 2.7 | +212.6 | 226.7 | 0.0 |
| NO DOUBLE ROUNDS | 2.7 | -85.9 | 163.3 | 15.0 | 3.0 | -109.4 | 293.0 | 0.0 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 2.0 | -0.6 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 6.7 | -152.5 | 0.0 | 85.3 | 5.0 | -219.8 | 0.0 | 53.3 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 6.7 | -123.1 | 0.0 | 0.0 | 2.7 | -75.5 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 0.3 | +1.8 | 32.7 | 0.0 | 0.7 | +42.0 | 124.3 | 0.0 |
| ONE OBJECTIVE FORMULA | 4.7 | +25.4 | 0.0 | 248.7 | 5.3 | +118.3 | 0.0 | 89.0 |
| ONE PROMISE A TARGET | 1.3 | -20.7 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +10.3 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 1.0 | +3.2 | 89.0 | 0.0 | 0.3 | +1.5 | 84.7 | 0.0 |
| PATHS CROSS | 1.0 | +38.6 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -11.0 | 0.0 | 0.0 | 0.3 | -0.4 | 0.0 | 0.0 |
| PLAN RESULT | 46.0 | +285.2 | 65.3 | 983.0 | 44.3 | +418.6 | 238.3 | 335.7 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 13.0 | -275.1 | 0.0 | 0.0 | 8.0 | -261.9 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -5.0 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 5.3 | +541.5 | 0.0 | 95.3 | 7.7 | +1158.4 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 1.3 | +8.4 | 0.0 | 113.3 | 4.0 | +97.0 | 0.0 | 0.0 |
| REAL GROUND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.3 | +0.4 | 0.0 | 0.0 |
| REDIRECT COUNTER | 4.7 | +192.0 | 0.0 | 40.0 | 1.3 | -8.6 | 0.0 | 9.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.0 | +0.0 | 0.0 | 15.0 | 2.3 | +11.1 | 0.0 | 18.0 |
| REDIRECT WEIGHED | 0.3 | +14.9 | 0.0 | 0.0 | 0.3 | +11.1 | 68.3 | 0.0 |
| REFORMS TO MEET IT | 1.7 | -20.7 | 0.0 | 0.0 | 0.7 | -29.7 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.3 | +5.6 | 0.0 | 0.0 |
| RISK BY ARC | 3.3 | +173.6 | 196.0 | 15.0 | 3.3 | +129.7 | 349.0 | 0.0 |
| ROUNDS AFTER TERROR | 1.3 | -27.6 | 118.7 | 0.0 | 0.3 | -27.2 | 124.3 | 0.0 |
| RUN DOWN | 4.0 | -32.3 | 196.0 | 15.0 | 1.7 | -13.2 | 261.0 | 0.0 |
| SAME CHARGE LATER | - | - | - | - | 0.3 | -13.2 | 56.7 | 0.0 |
| SCREEN BY WHAT IT SAVES | 2.3 | -133.3 | 0.0 | 30.0 | 0.7 | -15.3 | 0.0 | 18.0 |
| SEARCH SPOT | 1.0 | +38.9 | 0.0 | 0.0 | 0.3 | +4.0 | 0.0 | 0.0 |
| SET CREDITED ONCE | 3.7 | -87.7 | 0.0 | 84.7 | 1.3 | -26.7 | 0.0 | 9.0 |
| SET UP BY THE SET | 5.0 | +77.7 | 0.0 | 84.7 | 1.3 | +26.3 | 0.0 | 9.0 |
| SET UP TOGETHER | - | - | - | - | 0.3 | +19.8 | 0.0 | 35.7 |
| SHOOTER COUNTED ONCE | 0.3 | -0.8 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 2.0 | +0.0 | 0.0 | 155.7 | 3.7 | +0.0 | 0.0 | 9.0 |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 1.0 | +5.0 | 0.0 | 0.0 |
| SHOT RISK POINTS | 20.0 | -129.7 | 0.0 | 298.0 | 10.3 | -17.7 | 0.0 | 0.0 |
| SHOTS AFTER THE MOVES | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 1.7 | +57.2 | 0.0 | 0.0 | 6.7 | +61.8 | 0.0 | 89.0 |
| SPELL WORTH | 2.0 | +4.3 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 12.3 | +0.0 | 0.0 | 309.3 | 10.0 | +0.0 | 0.0 | 74.3 |
| STAND AND SHOOT | 0.3 | -3.6 | 35.7 | 0.0 | - | - | - | - |
| STANDS STILL | 15.7 | +0.0 | 0.0 | 412.0 | 41.3 | +0.0 | 275.7 | 74.3 |
| STAY WORTH | 1.3 | +14.7 | 0.0 | 0.0 | 8.3 | +77.4 | 275.7 | 35.7 |
| STRIKE BY THE ODDS | 0.3 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| STUBBORN BY POINTS | - | - | - | - | 0.3 | +2.5 | 0.0 | 0.0 |
| STUCK PIVOT | 1.0 | +0.0 | 0.0 | 113.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | 4.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 14.0 | +1848.4 | 0.0 | 451.3 | 8.7 | +304.3 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 14.0 | +1848.4 | 0.0 | 451.3 | 8.7 | +304.3 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +0.7 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | -0.7 | 0.0 | 32.7 |
| THE DEARER SUM KEEPS ITS PLAN | 2.3 | +0.0 | 0.0 | 22.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -5.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 5.7 | +0.0 | 0.0 | 153.0 | 7.7 | +0.0 | 0.0 | 41.7 |
| THE ROW KEEPS ITS WAY | 4.3 | +0.0 | 0.0 | 22.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 45.3 | +0.0 | 0.0 | 832.0 | 43.7 | +0.0 | 0.0 | 205.0 |
| TIED UP BY THE SUM | 0.7 | +110.1 | 89.0 | 0.0 | 1.3 | +262.7 | 125.0 | 0.0 |
| TIME ON OUR SIDE | - | - | - | - | 67.0 | +648.5 | 0.0 | 303.0 |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 1.3 | -30.3 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | - | - | - | - | 0.3 | -0.8 | 0.0 | 0.0 |
| WHO HITS BACK | 0.7 | +152.7 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | 0.7 | -1.0 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 6.3 | -648.1 | 0.0 | 736.0 | 4.3 | -262.8 | 0.0 | 237.3 |
| WHOLE FIGHT GAIN | 0.7 | +7.9 | 32.7 | 0.0 | 0.7 | +110.0 | 124.3 | 0.0 |
| WOUNDS ON THE RANKS | 2.7 | +2.7 | 0.0 | 0.0 | - | - | - | - |

### Rule changes: gs3-83c8646-p60

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 137 | 137 | 87 | 29.00 | +1427 | +16.4 |
| HOLDER ASSIGNMENT | 68 | 68 | 63 | 21.00 | +4041 | +64.2 |
| FIVE ACTION | 535 | 509 | 42 | 14.00 | +2518 | +60.0 |
| LEGAL CHARGES ONLY | 40 | 40 | 40 | 13.33 | +0 | +0.0 |
| OFF BEST | 35 | 35 | 35 | 11.67 | -1117 | -31.9 |
| THE TABLE AGAIN | 36 | 36 | 31 | 10.33 | +0 | +0.0 |
| TIME ON OUR SIDE | 201 | 168 | 27 | 9.00 | +15 | +0.6 |
| PROMISE BY ITS OWN SUM | 63 | 63 | 25 | 8.33 | -1611 | -64.4 |
| DEPLOY BY FIGURES | 43 | 43 | 24 | 8.00 | +122 | +5.1 |
| GOAL WALK | 71 | 70 | 23 | 7.67 | +1492 | +64.9 |
| MOVE TO CHARGE COMPUTED | 39 | 31 | 22 | 7.33 | +374 | +17.0 |
| HIS SHOT LIST | 174 | 155 | 21 | 7.00 | +62 | +2.9 |
| SUPPORT ADDS | 68 | 64 | 20 | 6.67 | +668 | +33.4 |
| SUPPORT WORKED OUT | 68 | 64 | 20 | 6.67 | +668 | +33.4 |
| HIS SHOTS BY HIS RUN | 147 | 130 | 15 | 5.00 | +11 | +0.7 |
| NEXT CHARGE BY LIST | 28 | 25 | 15 | 5.00 | +235 | +15.7 |
| REDIRECT FOR A FRIEND IN REACH | 16 | 16 | 15 | 5.00 | +0 | +0.0 |
| MOVE ORDER | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| FOUR ROUNDS | 23 | 23 | 13 | 4.33 | +418 | +32.2 |
| MEETS IN TIME | 21 | 21 | 13 | 4.33 | +865 | +66.5 |
| IDLE COST | 59 | 42 | 11 | 3.67 | +64 | +5.9 |
| RISK BY ARC | 20 | 20 | 10 | 3.33 | +276 | +27.6 |
| SHOT RISK POINTS | 91 | 79 | 10 | 3.33 | +163 | +16.3 |
| RANDOM MOVE BY FIGURES | 16 | 16 | 9 | 3.00 | +316 | +35.1 |
| CHALLENGE BY POINTS | 8 | 8 | 8 | 2.67 | +173 | +21.7 |
| FALLS SHORT | 83 | 70 | 8 | 2.67 | +4 | +0.5 |
| HARD STAY DROPPED | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 32 | 31 | 8 | 2.67 | +56 | +7.1 |
| MAX FOR POSITIONING | 20 | 17 | 7 | 2.33 | +10 | +1.4 |
| QUARTER ODDS | 39 | 36 | 7 | 2.33 | +574 | +82.0 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CHARGE NOW FIRST | 14 | 14 | 6 | 2.00 | -178 | -29.7 |
| FOLLOW UP WEIGHED | 6 | 6 | 6 | 2.00 | +691 | +115.2 |
| HOLDS AMBUSHERS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| REDIRECT COUNTER | 18 | 17 | 6 | 2.00 | +130 | +21.6 |
| TIED UP BY THE SUM | 6 | 6 | 6 | 2.00 | +284 | +47.3 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | -198 | -39.6 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +170 | +33.9 |
| SHOTS IN THE MOVE | 25 | 20 | 5 | 1.67 | +131 | +26.2 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHARGE LOSSES | 79 | 72 | 4 | 1.33 | +773 | +193.2 |
| COVER ONCE | 52 | 39 | 4 | 1.33 | +1 | +0.2 |
| ONE OBJECTIVE FORMULA | 30 | 28 | 4 | 1.33 | +196 | +48.9 |
| ONE PROMISE A TARGET | 4 | 4 | 4 | 1.33 | -62 | -15.5 |
| PATHS CROSS | 4 | 4 | 4 | 1.33 | +116 | +29.0 |
| SET UP BY THE SET | 19 | 18 | 4 | 1.33 | +157 | +39.3 |
| STUCK PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 1.00 | +183 | +60.9 |
| CAST JOB | 7 | 7 | 3 | 1.00 | +20 | +6.8 |
| CHAFF IN THE MOVE | 6 | 5 | 3 | 1.00 | +1 | +0.2 |
| EXACT ROUND | 13 | 13 | 3 | 1.00 | +35 | +11.7 |
| FACES THE THREAT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +18 | +6.2 |
| SEARCH SPOT | 4 | 4 | 3 | 1.00 | +129 | +42.9 |
| THE ROW IN ITS ORDER | 40 | 3 | 3 | 1.00 | +0 | +0.0 |
| ASSAILMENT BY POINTS | 2 | 2 | 2 | 0.67 | +2 | +0.8 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| GOAL ROUTE | 2 | 2 | 2 | 0.67 | +6 | +3.0 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -92 | -46.0 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.67 | -34 | -17.1 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +78 | +39.0 |
| SHOOTS FROM THE BEST SPOT | 3 | 3 | 2 | 0.67 | +0 | +0.0 |
| STAY WORTH | 29 | 24 | 2 | 0.67 | +51 | +25.4 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +399 | +199.7 |
| WHOLE FIGHT GAIN | 4 | 4 | 2 | 0.67 | +104 | +52.2 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +105 | +104.9 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -0 | -0.2 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +76 | +75.5 |
| FIGHT TO THE END | 5 | 5 | 1 | 0.33 | +10 | +9.8 |
| GOAL ON TIME | 1 | 1 | 1 | 0.33 | -2 | -1.6 |
| HONEST WORTH | 22 | 22 | 1 | 0.33 | +14 | +13.6 |
| HUNT IN PAIRS | 2 | 1 | 1 | 0.33 | +30 | +29.5 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +26 | +26.0 |
| LOST AFTER ESCAPE | 14 | 14 | 1 | 0.33 | +10 | +9.8 |
| MANOEUVRE | 7 | 7 | 1 | 0.33 | +7 | +6.8 |
| NO DOUBLE ROUNDS | 17 | 17 | 1 | 0.33 | +25 | +25.2 |
| ONE FIGHT FORMULA | 28 | 14 | 1 | 0.33 | +4 | +3.5 |
| ONE JOINT FIGURE | 3 | 3 | 1 | 0.33 | +83 | +83.0 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +26 | +26.3 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +17 | +16.6 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +1 | +0.7 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +8 | +7.6 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | -2 | -2.0 |
| BACKUP TARGETS | 3 | not checked | - | - | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 108 | 106 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 22 | 22 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 7 | 7 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 50 | not checked | - | - | - | - |
| FOOT FIRST | 96 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 31 | 30 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 12 | 11 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 59 | 56 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 53 | 51 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 23 | 20 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 6 | 4 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 6 | 6 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 42 | 36 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 82 | 74 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 16 | 13 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HOLD ODDS | 119 | 119 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 8 | 8 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 8 | 5 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 12 | 5 | 0 | 0.00 | - | - |
| NEARER NOT NEEDED | 45 | 41 | 0 | 0.00 | - | - |
| NEAREST TO GOAL | 5 | 5 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 6 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 4 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 271 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 7 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 5 | 5 | 0 | 0.00 | - | - |
| RUN DOWN | 17 | 17 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 9 | 9 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 15 | 14 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 17 | not checked | - | - | - | - |
| SHOTS AFTER THE MOVES | 3 | 3 | 0 | 0.00 | - | - |
| SPELL WORTH | 6 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 67 | 59 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS STILL | 171 | 165 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 12 | 9 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 1 | not checked | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 10 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 17 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 10 | not checked | - | - | - | - |
| THE TABLE BINDS | 267 | not checked | - | - | - | - |
| WAITS AGAIN | 9 | 4 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 4 | 4 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 8 | 8 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p60

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.00 | 4.67 | 28.3 |
| PROMISE BY ITS OWN SUM | rule | 5.00 | 3.33 | 64.4 |
| ARMY TABLE | rule | 1.67 | 1.33 | 88.7 |
| CHARGE NOW FIRST | rule | - | 2.00 | 29.7 |
| NO REASON | gate | 1.33 | - | 69.8 |
| JOINT CHARGE NOW | rule | 0.33 | 0.67 | 98.0 |
| MARCH OF THE TABLE | rule | - | 0.67 | 46.0 |
| ONE PROMISE A TARGET | rule | 0.67 | - | 58.6 |
| PIVOT GUARDS FLANK | rule | 0.33 | 0.33 | 17.1 |
| AFTERMATH BAND | gate | - | 0.33 | 4.2 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.33 | - | 11.9 |
| GOAL ON TIME | rule | 0.33 | - | 1.6 |
| SWIFTSTRIDE BY POINTS | rule | - | 0.33 | 2.0 |

### Plans: gs3-83c8646-p60

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.0 | 89% | 156 | 285 | 182% |
| Mine | join | 4.0 | 92% | 138 | 0 | 0% |
| Mine | move | 38.0 | 96% | 2292 | 0 | 0% |
| Mine | support | 1.0 | 67% | 0 | 0 | - |
| Opponent | charge | 3.3 | 70% | 325 | 351 | 108% |
| Opponent | join | 2.3 | 100% | 198 | 0 | 0% |
| Opponent | move | 36.3 | 97% | 1715 | 0 | 0% |
| Opponent | shoot | 1.7 | 60% | 170 | 68 | 40% |
| Opponent | support | 0.7 | 50% | 11 | 0 | 0% |

### Battle groups: gs3-83c8646-p60

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.7 | 21% | 33% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 1.3 | 50% | 50% | 0% | - | 50% | 0% | 0% | 50% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p60

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 121 (9) | 19 | 103 | 44 | 56% | 4.0 | 38 (4) | 222 (3) | 178 (2) | 189 (6) | 0 (3) |
| Mine | Character | 9 | 12 (9) | 12 | 0 | 0 | 33% | 3.8 | 0 (2) | 21 (6) | 0 (1) | 9 (6) | 23 (3) |
| Mine | Clean-up | 1 | 170 (1) | 22 | 148 | 0 | 0% | 2.0 | - | - | 170 (1) | 170 (1) | - |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast Hammer | 6 | 10 (6) | 6 | 4 | 14 | 50% | 4.3 | - | 5 (4) | 25 (2) | 7 (3) | 16 (3) |
| Mine | Hammer | 2 | 18 (2) | 0 | 18 | 110 | 50% | 2.0 | - | 18 (2) | - | 0 (1) | 28 (1) |
| Mine | Holder | 1 | 32 (1) | 32 | 0 | 0 | 0% | 2.0 | 32 (1) | - | - | 32 (1) | - |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 73 | 50% | 2.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 54 | 0% | 3.5 | 0 (2) | 0 (1) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | Chaff | 3 | 145 (3) | 0 | 145 | 44 | 33% | 3.5 | 0 (1) | 257 (1) | 0 (1) | 145 (3) | - |
| Opponent | Character | 10 | 42 (10) | 42 | 0 | 0 | 40% | 2.3 | 34 (3) | 50 (6) | 22 (1) | 50 (6) | 31 (4) |
| Opponent | Clean-up | 2 | 0 (2) | 0 | 0 | 0 | 50% | 4.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 5 | 27 (5) | 0 | 27 | 22 | 60% | 2.5 | 40 (2) | 0 (1) | 31 (2) | 41 (2) | 21 (3) |
| Opponent | Fragile | 2 | 0 (2) | 0 | 0 | 0 | 50% | 1.0 | 0 (1) | - | 0 (1) | 0 (2) | - |
| Opponent | Hammer | 6 | 73 (6) | 54 | 18 | 0 | 17% | 5.2 | - | 94 (4) | 0 (2) | 102 (3) | 39 (3) |
| Opponent | Holder | 6 | 38 (6) | 0 | 38 | 15 | 67% | 2.0 | 24 (2) | 84 (2) | 0 (1) | 0 (1) | 54 (4) |
| Opponent | Shooter | 1 | 56 (1) | 0 | 56 | 100 | 0% | 2.0 | - | - | 56 (1) | 56 (1) | - |

### Charged fights: gs3-83c8646-p60

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 2 | 0 | 49 | 2.5 | 1.0 | 20 | 9 | +11 | 1 of 5 | 4 of 5 | - | +11 |
| Mine | Warriors of Chaos | 1 | 27 | 134 | 3.0 | 1.0 | 45 | 0 | +45 | 0 of 3 | 3 of 3 | - | +45 |
| **Mine** | all armies | 3 | 9 | 77 | 2.7 | 1.0 | 29 | 6 | +23 | 1 of 8 | 7 of 8 | - | +23 |
| Opponent | Warriors of Chaos | 2 | 0 | 223 | 1.5 | 1.0 | 149 | 0 | +149 | 1 of 3 | 3 of 3 | - | +149 |
| Opponent | Wood Elf Realms | 1 | 0 | 748 | 5.0 | 1.0 | 150 | 0 | +150 | 0 of 5 | 4 of 5 | - | +150 |
| **Opponent** | all armies | 3 | 0 | 398 | 2.7 | 1.0 | 149 | 0 | +149 | 1 of 8 | 7 of 8 | - | +149 |

### Effective charges: gs3-83c8646-p60

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 5 | 1 (net +0) | 0 | 2 (net +26) | 0 | 0 | 2 (net +0) | 0 | 40% (2 of 5) |
| Mine | Warriors of Chaos | 3 | 0 | 0 | 0 | 0 | 3 (net +45) | 0 | 0 | 0% (0 of 3) |
| Opponent | Warriors of Chaos | 3 | 0 | 0 | 1 (net +254) | 1 (net +192) | 0 | 1 (net +0) | 0 | 33% (1 of 3) |
| Opponent | Wood Elf Realms | 5 | 1 (net +0) | 0 | 0 | 0 | 0 | 4 (net +187) | 0 | 0% (0 of 5) |

### Charged fights, damage counted: gs3-83c8646-p60

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 50 | 70 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 2 | 45 | 98 | +26 | 49 | 22 | +26 | +58.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 260 | 326 | +0 | 43 | 0 | +43 | +16.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 327 | 75 | +45 | 60 | 0 | +60 | +18.3 |
| Mine | All fights | 8 | 205 | 143 | +23 | 46 | 6 | +40 | +19.4 |
| Opponent | Long shot (under 50%) | 1 | 109 | 122 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Effective (55-75%) | 1 | 116 | 254 | +254 | 254 | 0 | +254 | +219.0 |
| Opponent | 76-89% | 1 | 116 | 45 | +192 | 192 | 0 | +192 | +165.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 496 | 187 | +150 | 165 | 11 | +154 | +31.0 |
| Opponent | All fights | 8 | 352 | 170 | +149 | 159 | 7 | +152 | +43.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p60 | move | 19 | 2 (11%) | 1 (5%) | 4 (21%) | 13 (68%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2531, L2730 |
| Charmed Shield | Opponent | L2934 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Ring of Doom | Opponent | L2531 |

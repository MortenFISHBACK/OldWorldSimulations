# Doctrine scorecard: gs3-83c8646-p28

### Scorecard: gs3-83c8646-p28

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0533 | 5 | 1 | Mine | yes | - | - | 0 | 3 | 0 | 0 | 0 | 1261 |
| L0533 | 5 | 1 | Opponent | no | - | - | 0 | 8 | 0 | 0 | 0 | 19 |
| L0620 | 2 | 1 | Mine | - | - | - | 0 | 3 | 0 | 0 | 0 | 508 |
| L0620 | 2 | 1 | Opponent | - | - | - | 0 | 8 | 0 | 0 | 0 | 275 |
| L0709 | 1 | 1 | Mine | yes | 1 | 3 | 2 | 2 | 1 | 0 | 0 | 375 |
| L0709 | 1 | 1 | Opponent | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 375 |
| **Average** | | | Mine | 100% | 1.0 | 3.0 | 0.7 | 2.7 | 0.3 | 0.0 | 0.0 | 714.7 |
| **Average** | | | Opponent | 0% | 0.0 | - | 0.0 | 5.7 | 0.0 | 0.0 | 0.0 | 223.0 |

### KPIs: gs3-83c8646-p28

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 55% (6 of 11) | 0% (0 of 9) | 30% (6 of 20) |
| Winner chose to follow up after the loser gave ground |  | - | - | - |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Magic missiles tried each own turn | 50%+ | - | 46% (11 of 24) | 46% (11 of 24) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 55% (11 of 20) | 55% (11 of 20) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 75% (9 of 12) | 75% (9 of 12) |
| Points that never fought | lower | 88% (4477 of 5106) | 86% (5177 of 5998) | 87% (9654 of 11104) |
|   infantry points that never fought | lower | 100% (1380 of 1380) | 88% (1900 of 2154) | 93% (3280 of 3534) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 86% (19 of 22) | 90% (26 of 29) | 88% (45 of 51) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Bound items with another spell used |  | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 82% (3169 of 3848) | 94% (5099 of 5432) | 89% (8268 of 9280) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 2.3 (54%) | 2.3 (54%) |
| MARCHED: its unit marched | - | 0.7 (15%) | 0.7 (15%) |
| GONE: slain | - | 1.3 (31%) | 1.3 (31%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 6.0 | 2.0 | 3.7 | 1.7 | 0.0 |
| not cast | 2.0 | 2.0 | 4.3 | 0.3 | 12.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (33%) | 2.3 (54%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.7 (15%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (33%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 1.3 (31%) | 0.0 (0%) | 0.0 (0%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (17%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (6%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (100%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (83%) | 0.7 (33%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 10.7 (89%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.7 a game | 1.3 a game | 1.0 a game |
| stood (cast and not dispelled) | 100% (2 of 2) | 25% (1 of 4) | 50% (3 of 6) |
| the unit moved after it | 0% (0 of 2) | 0% (0 of 1) | 0% (0 of 3) |
| it charged on its next turn | 50% (1 of 2) | 0% (0 of 1) | 33% (1 of 3) |
| the enemy charged it first | 0% (0 of 2) | 0% (0 of 1) | 0% (0 of 3) |
| it fought by the end of its next turn | 0% (0 of 2) | 0% (0 of 1) | 0% (0 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 2) | 0% (0 of 1) | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | 50% (1 of 2) | 100% (1 of 1) | 67% (2 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 74% (99 of 133) | 59% (59 of 100) | 68% (158 of 233) |
|   cavalry | 75% (6 of 8) | 0% (0 of 8) | 38% (6 of 16) |
|   character | 95% (20 of 21) | 100% (10 of 10) | 97% (30 of 31) |
|   chariot | - | 100% (2 of 2) | 100% (2 of 2) |
|   infantry | 59% (19 of 32) | 50% (27 of 54) | 53% (46 of 86) |
|   monster | 100% (6 of 6) | 33% (2 of 6) | 67% (8 of 12) |
|   war machine | 73% (48 of 66) | 90% (18 of 20) | 77% (66 of 86) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (15%) | 3.0 (22%) | 4.7 (19%) |
| CHARGED: it charged | 0.3 (3%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET IN RANGE | 2.3 (21%) | 2.3 (17%) | 4.7 (19%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 6.3 (56%) | 5.3 (39%) | 11.7 (47%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 2.7 (20%) | 3.0 (12%) |
| OTHER BAR | 0.3 (3%) | 0.3 (2%) | 0.7 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.0 | 0.3 | 83% | 5.4 pts | 11 pts |
| character | 10.7 | 3.3 | 72% | 5.3 pts | 57 pts |
| chariot | 0.7 | 0.3 | 50% | 14.9 pts | 10 pts |
| infantry | 25.3 | 6.7 | 76% | 5.6 pts | 142 pts |
| monster | 3.3 | 0.3 | 90% | 2.2 pts | 7 pts |
| war machine | 25.3 | 17.3 | 67% | 14.4 pts | 364 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.7 | 0.0 | 0.8 |
| Charges that made contact a game | 1.3 | 0.0 | 0.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, units carrying another wizard (or one alone) | 2.00 declared, 2.00 contact (1 units) | - | 2.00 declared, 2.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.17 declared, 0.11 contact (18 units) | 0.00 declared, 0.00 contact (27 units) | 0.07 declared, 0.04 contact (45 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 60% (3 of 5) | 100% (1 of 1) | - | 67% (4 of 6) |
| Character in a unit | 100% (8 of 8) | 100% (2 of 2) | 100% (1 of 1) | 100% (11 of 11) |
| Character on its own | 100% (2 of 2) | - | 50% (1 of 2) | 75% (3 of 4) |
| Chariot | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Infantry | 80% (8 of 10) | 100% (7 of 7) | - | 88% (15 of 17) |
| Monster | 100% (1 of 1) | 100% (2 of 2) | - | 100% (3 of 3) |
| Monstrous | 100% (1 of 1) | 100% (1 of 1) | - | 100% (2 of 2) |
| War Machines | 86% (6 of 7) | - | - | 86% (6 of 7) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dwarfen Mountain Holds | 2 | - | - | 98% | 100% (17 of 17) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 2 | 100% (1 of 1); on the table 100% | 50% (6 of 12) | 57% | 65% (11 of 17) | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | - | 83% (5 of 6) | 97% | 100% (7 of 7) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Wood Elf Realms | 1 | - | 0% (0 of 6) | 100% | 100% (10 of 10) | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p28, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | - | 100% (1) | 100% (1) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p28

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.3 | 0.7 |
| Strategy | Charge objectives carried out (made contact) | 40% (2 of 5) | - |
| Strategy | Shoot objectives carried out (shot that target) | 64% (55 of 86) | 61% (20 of 33) |
| Strategy | Joined characters whose unit fought | 0% (0 of 8) | 14% (1 of 7) |
| Strategy | Lone characters that fought | 33% (1 of 3) | 20% (1 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.7 | 5.7 |
| Movement | Points that never moved of their own | 714.7 | 223.0 |
| Movement | Fights charged into per game | 1.3 | 0.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 3, net +60 | - |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 3, net +65 | - |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 3 | - |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 3 | - |
| Shooting | Shots by shooting units (incl. breath weapons) | 18.3 | 16.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 62% (34 of 55) | 18% (9 of 50) |
| Shooting | Points destroyed by shooting units | 0.0 | 79.3 |
| Shooting | War machine shots | 16.0 | 9.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 31% (15 of 48) | 11% (3 of 27) |
| Shooting | Points destroyed by war machines | 82.7 | 0.0 |
| Magic | Magic missiles cast | - | 1.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 0% (0 of 5) |
| Magic | Wounds caused by magic missiles | - | 0.7 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 3.7 / 0.0 / 0.0 / 1.7 |
| Combat | Points destroyed in combat | 171.7 | 0.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +95 | - |
| Combat | Net per 100 charger points, damage counted | +37.6 | - |
| Combat | First round won (charged fights) | 75% | - |
| Combat | Net points per charged fight | +160 | - |
| Combat | Net points per supported fight / lone fight | - / +160 | - / - |
| Combat | Charged fights on a top-3 enemy unit | 1 of 4 | - |
| Game | Points lost | 181.3 | 515.3 |
| Game | VP from objectives | 350.0 | 683.3 |
| Game | Lone holders (player turns) | 1.0 | 0.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -67 VP
- The side that went first won 2 of 2 games with a winner
- Points traded per game (both sides' losses): 697
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p28

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 9.7 | +213.1 | 0.0 | 0.0 | 19.0 | +390.9 | 0.0 | 91.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 41.7 |
| BEST PRIZE | 0.3 | +19.8 | 41.7 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 1.0 | +0.0 | 106.7 | 0.0 | 0.3 | +0.0 | 0.0 | 41.7 |
| CANNON PLANNED TARGET | 18.3 | +258.0 | 755.7 | 166.7 | 4.0 | +300.7 | 0.0 | 83.3 |
| CANNON SIGHT KEPT | 3.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CAST JOB | - | - | - | - | 2.0 | +20.0 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | - | - | - | - | 1.3 | +16.8 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 0.7 | +3.2 | 0.0 | 0.0 |
| CHARACTER GUNS | 6.7 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 18.3 | -561.7 | 0.0 | 0.0 | 21.0 | -682.1 | 0.0 | 296.0 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 130.0 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 14.0 | +0.0 | 0.0 | 158.7 | 6.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.7 | +66.9 | 0.0 | 0.0 | 1.0 | +38.0 | 0.0 | 0.0 |
| COVER ONCE | 1.7 | -31.0 | 0.0 | 0.0 | 10.0 | -835.9 | 0.0 | 88.3 |
| DEFENSIVE ARMY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 11.0 | -163.1 | 0.0 | 0.0 | 8.0 | -10.1 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 3.3 | +404.9 | 0.0 | 393.3 |
| EXACT ROUND | 1.7 | -5.5 | 151.7 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.0 | +0.0 | 151.7 | 0.0 | - | - | - | - |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | 5.7 | +67.1 | 0.0 | 0.0 | 21.0 | +267.0 | 0.0 | 134.3 |
| FEATURE BUFFS | - | - | - | - | 2.0 | +4.5 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 135.0 | +4480.9 | 2642.7 | 650.7 | 93.3 | +5336.4 | 317.3 | 851.3 |
| FLANK NOT WEIGHED | 1.3 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 88.3 |
| FOUR ROUNDS | 1.7 | +118.8 | 151.7 | 0.0 | - | - | - | - |
| FREED FROM HIS FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.3 | -11.4 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| GOAL WALK | 9.3 | +1187.2 | 0.0 | 0.0 | 8.7 | +411.5 | 0.0 | 0.0 |
| GUN FIGURES | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +16.0 | 0.0 | 21.7 |
| GUN MASK | 2.3 | +36.3 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 7.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 4.7 | +0.0 | 0.0 | 0.0 | 12.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE LIST | 1.3 | +0.0 | 0.0 | 0.0 | 11.7 | +0.0 | 0.0 | 21.7 |
| HIS LEGAL MOVES | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 6.0 | -71.2 | 0.0 | 0.0 | 0.7 | -2.9 | 0.0 | 0.0 |
| HIS ONE QUARTER | 4.0 | +0.0 | 0.0 | 79.3 | 2.3 | +0.0 | 0.0 | 157.3 |
| HIS OWN BEST MOVE | 5.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 11.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 54.7 | +3053.1 | 0.0 | 158.7 | 61.3 | +4426.9 | 0.0 | 486.3 |
| HIS SHOTS BY HIS RUN | 36.0 | +989.4 | 0.0 | 158.7 | 41.3 | +912.1 | 0.0 | 373.7 |
| HIS TURN DENIED | 1.3 | +75.1 | 130.0 | 0.0 | - | - | - | - |
| HOLD ODDS | 6.0 | +0.0 | 0.0 | 0.0 | 17.0 | +0.0 | 0.0 | 138.7 |
| HOLDER ASSIGNMENT | 5.0 | +518.1 | 0.0 | 0.0 | 9.0 | +1106.9 | 0.0 | 69.3 |
| HONEST WORTH | 1.7 | -38.1 | 151.7 | 0.0 | - | - | - | - |
| IDLE COST | 6.3 | -79.1 | 0.0 | 0.0 | 13.3 | -186.5 | 0.0 | 49.7 |
| KEEPS SCOUTS OR AMBUSH | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 3.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +18.9 | 0.0 | 0.0 | - | - | - | - |
| LATE ONLY FROM HERE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | - | - | - | - | 1.0 | +89.6 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.0 | -18.0 | 21.7 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 0.7 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 2.0 | -16.6 | 0.0 | 0.0 | 4.3 | -30.8 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.7 | +32.5 | 0.0 | 69.3 |
| MARCH CHECK | - | - | - | - | 2.0 | +79.1 | 0.0 | 69.3 |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +41.1 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 0.7 | -23.2 | 0.0 | 69.3 |
| MARCH WHEELS ONLY | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.0 | +2.3 | 0.0 | 0.0 | - | - | - | - |
| MEETS IN TIME | 5.3 | +70.8 | 0.0 | 0.0 | 3.0 | +88.2 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | - | - | - | - | 5.0 | +56.6 | 0.0 | 0.0 |
| MISSILES NEXT TURN | - | - | - | - | 6.3 | +72.9 | 0.0 | 69.3 |
| MODEL FACING | 1.3 | +272.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.7 | +20.7 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.7 | -33.6 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 5.0 | +146.2 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 8.0 | +379.6 | 0.0 | 0.0 | 11.3 | +455.1 | 0.0 | 0.0 |
| NEAREST TO GOAL | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 2.7 | +75.8 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 1.7 | -87.7 | 151.7 | 0.0 | - | - | - | - |
| NO LATE CUT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.7 | -0.7 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 4.0 | -156.2 | 0.0 | 41.7 | 1.0 | -6.2 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.0 | -64.4 | 0.0 | 0.0 | - | - | - | - |
| ONE JOINT FIGURE | 0.7 | -36.8 | 0.0 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 0.3 | +10.0 | 0.0 | 0.0 | 5.7 | +103.6 | 0.0 | 69.3 |
| ONE PROMISE A TARGET | 0.3 | -11.4 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.7 | +112.1 | 130.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 59.3 | +979.4 | 596.3 | 325.3 | 42.0 | +862.4 | 0.0 | 689.0 |
| PROMISE BY ITS OWN SUM | 6.3 | -47.5 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | - | - | - | - | 0.7 | -0.1 | 0.0 | 0.0 |
| QUARTER ODDS | 24.0 | +1329.7 | 1221.3 | 317.3 | 14.7 | +2003.2 | 317.3 | 226.7 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.0 | +166.9 | 0.0 | 0.0 |
| REAL GROUND | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT WEIGHED | 0.3 | +19.8 | 41.7 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.0 | -163.4 | 130.0 | 0.0 | - | - | - | - |
| RISK ON THE WAY | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | 0.3 | -7.1 | 41.7 | 0.0 | - | - | - | - |
| RUN DOWN | 0.7 | -0.2 | 63.3 | 0.0 | - | - | - | - |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -58.7 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +15.8 | 0.0 | 0.0 | 0.7 | +5.1 | 0.0 | 88.3 |
| SET CREDITED ONCE | 1.7 | -50.1 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 1.7 | +35.7 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.7 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| SET-UP MISSED | 0.3 | +29.5 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 1.3 | +2.7 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 28.7 | +0.0 | 0.0 | 166.7 | 11.3 | +0.0 | 0.0 | 193.3 |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 2.7 | +38.5 | 0.0 | 176.7 |
| SHORT GUN FORWARD | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 0.3 | -10.8 | 88.3 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 39.0 | +129.1 | 0.0 | 0.0 | 31.7 | +77.2 | 0.0 | 473.7 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 35.3 | +812.1 | 0.0 | 166.7 | 20.3 | +921.7 | 0.0 | 126.7 |
| SPELL WORTH | - | - | - | - | 6.0 | +147.3 | 43.3 | 0.0 |
| SPELLS IN THE FIGHT | 0.7 | +5.4 | 130.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 7.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 6.3 |
| STAND AND SHOOT | 0.3 | -5.1 | 21.7 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | - | - | - | - | 8.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 98.7 | +0.0 | 2491.0 | 333.3 | 40.7 | +0.0 | 317.3 | 408.3 |
| STAY WORTH | 74.3 | +713.0 | 1269.7 | 500.0 | 17.3 | +90.2 | 0.0 | 148.0 |
| STRIKE BY THE ODDS | 0.7 | +1.6 | 20.0 | 0.0 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | - | - | - | - | 1.7 | +38.8 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | - | - | - | - | 1.7 | +38.8 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 1.3 | +75.0 | 0.0 | 0.0 | - | - | - | - |
| SWIFTSTRIDE BY POINTS | 0.3 | +1.7 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 69.3 |
| THE ROW IN ITS ORDER | 3.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 34.7 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.3 | +0.0 | 0.0 | 79.3 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 79.3 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 57.0 | +0.0 | 0.0 | 325.3 | 44.0 | +0.0 | 0.0 | 425.7 |
| TIED UP BY THE SUM | 0.3 | +36.4 | 41.7 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 53.0 | +398.9 | 151.3 | 0.0 | 11.0 | +128.1 | 0.0 | 88.3 |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WALKS ON ITS ROUTE | 0.3 | -0.9 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.7 | +5.6 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 2.3 | -48.2 | 0.0 | 0.0 | 0.7 | -42.7 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 5.3 | +122.4 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p28

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 348 | 342 | 90 | 30.00 | +1386 | +15.4 |
| ARMY TABLE | 86 | 86 | 69 | 23.00 | +1447 | +21.0 |
| HIS SHOTS BY HIS RUN | 232 | 230 | 69 | 23.00 | +1035 | +15.0 |
| SHOT RISK POINTS | 212 | 208 | 44 | 14.67 | +1345 | +30.6 |
| DEPLOY BY FIGURES | 57 | 57 | 39 | 13.00 | +626 | +16.0 |
| HOLDER ASSIGNMENT | 42 | 42 | 39 | 13.00 | +3137 | +80.4 |
| HARD STAY DROPPED | 29 | 29 | 29 | 9.67 | +0 | +0.0 |
| GOAL WALK | 54 | 54 | 19 | 6.33 | +1962 | +103.3 |
| TIME ON OUR SIDE | 192 | 183 | 19 | 6.33 | +39 | +2.0 |
| OFF BEST | 15 | 15 | 15 | 5.00 | -487 | -32.5 |
| THE TABLE AGAIN | 36 | 36 | 15 | 5.00 | +0 | +0.0 |
| CANNON SIGHT KEPT | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| IDLE COST | 59 | 43 | 12 | 4.00 | +115 | +9.6 |
| FIVE ACTION | 685 | 679 | 10 | 3.33 | +163 | +16.3 |
| EVASIVE BY THE ODDS | 10 | 10 | 9 | 3.00 | +1200 | +133.4 |
| MEETS IN TIME | 25 | 25 | 9 | 3.00 | +196 | +21.7 |
| QUARTER ODDS | 116 | 116 | 9 | 3.00 | +1287 | +143.0 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 9 | 3.00 | +501 | +55.6 |
| STAY WORTH | 275 | 261 | 9 | 3.00 | +103 | +11.4 |
| MOVE TO CHARGE COMPUTED | 15 | 12 | 8 | 2.67 | +93 | +11.6 |
| CHARGE LOSSES | 118 | 116 | 6 | 2.00 | +199 | +33.2 |
| MOVE ORDER | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CANNON PLANNED TARGET | 67 | 67 | 5 | 1.67 | -104 | -20.9 |
| PROMISE BY ITS OWN SUM | 19 | 19 | 5 | 1.67 | -143 | -28.5 |
| SHOOTERS IN TWO RANKS | 5 | 5 | 5 | 1.67 | +10 | +2.0 |
| SHOTS IN THE MOVE | 167 | 139 | 5 | 1.67 | +95 | +19.0 |
| FOUR ROUNDS | 5 | 5 | 4 | 1.33 | +87 | +21.8 |
| MARCH CHECK | 6 | 6 | 4 | 1.33 | +95 | +23.6 |
| MODEL FACING | 4 | 4 | 4 | 1.33 | +816 | +204.0 |
| NEXT CHARGE BY LIST | 8 | 8 | 4 | 1.33 | +48 | +12.0 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 8 | 8 | 4 | 1.33 | +64 | +16.1 |
| SHOTS AFTER THE MOVES | 28 | 28 | 4 | 1.33 | +0 | +0.0 |
| CAST JOB | 6 | 6 | 3 | 1.00 | +0 | +0.1 |
| HIS TURN DENIED | 4 | 4 | 3 | 1.00 | +110 | +36.7 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +269 | +89.6 |
| SEARCH SPOT | 4 | 4 | 3 | 1.00 | +63 | +20.9 |
| SHORT GUN FORWARD | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 16 | 15 | 3 | 1.00 | +14 | +4.7 |
| CASTING BLOCK | 4 | 4 | 2 | 0.67 | +5 | +2.6 |
| CHAFF IN THE MOVE | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| COVER ONCE | 35 | 29 | 2 | 0.67 | +14 | +7.1 |
| GUN MASK | 7 | 7 | 2 | 0.67 | +19 | +9.3 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +98 | +48.9 |
| NEARER NOT NEEDED | 58 | 58 | 2 | 0.67 | +37 | +18.3 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -0 | -0.1 |
| SET UP BY THE SET | 8 | 8 | 2 | 0.67 | +81 | +40.6 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +5 | +2.4 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -0 | -0.2 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 4 | 4 | 1 | 0.33 | -4 | -4.5 |
| FALLS SHORT | 80 | 65 | 1 | 0.33 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +2 | +1.8 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| LANE BY FIGURES | 1 | 1 | 1 | 0.33 | +57 | +56.6 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -124 | -123.5 |
| ONE OBJECTIVE FORMULA | 18 | 15 | 1 | 0.33 | +160 | +159.6 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -34 | -34.3 |
| OVERRUNS AWAY | 2 | 2 | 1 | 0.33 | +60 | +59.6 |
| REDIRECT FOR A FRIEND IN REACH | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +59 | +59.3 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SURE REACH TOGETHER | 4 | 3 | 1 | 0.33 | +20 | +20.2 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +5 | +5.1 |
| THE ROW IN ITS ORDER | 17 | 1 | 1 | 0.33 | +0 | +0.0 |
| TIED UP BY THE SUM | 1 | 1 | 1 | 0.33 | +86 | +86.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -3 | -2.7 |
| WHO FIGHTS | 2 | 2 | 1 | 0.33 | +4 | +4.5 |
| CANNON PLAN MISSED | 4 | 4 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CHARACTER GUNS | 43 | 41 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 61 | 61 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 5 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| EXACT ROUND | 5 | 5 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 3 | 3 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 6 | 6 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 28 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 9 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 50 | 49 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 39 | 38 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 8 | 6 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 20 | 19 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 19 | 19 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 19 | 16 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 35 | 32 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 2 | 2 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 69 | 69 | 0 | 0.00 | - | - |
| HONEST WORTH | 5 | 5 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 12 | 12 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 3 | 3 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MANOEUVRE | 19 | 19 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 7 | 7 | 0 | 0.00 | - | - |
| MAX FOR POSITIONING | 3 | 2 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 15 | 9 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 19 | 12 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 2 | 1 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 2 | trace | - | - | - | - |
| NEAREST TO GOAL | 3 | 3 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 5 | 5 | 0 | 0.00 | - | - |
| NO LATE CUT | 5 | 5 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 5 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 7 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 12 | 11 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 2 | 2 | 0 | 0.00 | - | - |
| ONE ROUTE | 7 | 7 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 304 | trace | - | - | - | - |
| REAL GROUND | 7 | 7 | 0 | 0.00 | - | - |
| RISK BY ARC | 3 | 3 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 3 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 5 | 5 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 2 | 0 | 0.00 | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 120 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 18 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 36 | 26 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 24 | 24 | 0 | 0.00 | - | - |
| STANDS STILL | 418 | 416 | 0 | 0.00 | - | - |
| SUPPORT ADDS | 5 | 5 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| SUPPORT WORKED OUT | 5 | 5 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 14 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 11 | not checked | - | - | - | - |
| THE TABLE BINDS | 303 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 9 | 9 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p28

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.67 | 1.00 | 17.1 |
| ARMY TABLE | rule | 0.67 | 3.00 | 53.4 |
| PROMISE BY ITS OWN SUM | rule | 1.67 | - | 28.5 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.33 | 2.2 |
| CANNON PLANNED TARGET | rule | - | 0.33 | 106.0 |
| CHARGE NOW FIRST | rule | 0.33 | - | 4.5 |
| MARCH OF THE TABLE | rule | - | 0.33 | 123.5 |
| ONE PROMISE A TARGET | rule | 0.33 | - | 34.3 |
| RULE SWITCHED OFF | gate | 0.33 | - | 247.3 |
| WALKS ON ITS ROUTE | rule | 0.33 | - | 2.7 |

### Plans: gs3-83c8646-p28

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 50% | 111 | 141 | 127% |
| Mine | join | 2.3 | 100% | 80 | 0 | 0% |
| Mine | move | 32.7 | 98% | 1033 | 0 | 0% |
| Mine | shoot | 23.0 | 61% | 704 | 839 | 119% |
| Opponent | move | 32.3 | 95% | 1524 | 0 | 0% |
| Opponent | shoot | 9.7 | 66% | 442 | 863 | 195% |

### Deployment: positions vs output by unit type: gs3-83c8646-p28

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Character | 11 | 32 (11) | 32 | 0 | 0 | 36% | 2.3 | 104 (2) | 0 (9) | - | 40 (8) | 0 (3) |
| Mine | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 4 | 21 (4) | 8 | 12 | 33 | 75% | 5.0 | 0 (1) | 32 (1) | 30 (2) | 28 (3) | 0 (1) |
| Mine | Hammer | 5 | 0 (5) | 0 | 0 | 0 | 60% | 4.0 | 0 (1) | 0 (4) | - | 0 (3) | 0 (2) |
| Mine | Shooter | 5 | 9 (5) | 9 | 0 | 0 | 0% | 1.4 | 26 (2) | 0 (3) | - | 9 (5) | - |
| Mine | War machine | 11 | 17 (11) | 17 | 0 | 0 | 18% | 1.1 | 11 (6) | 26 (5) | - | 10 (2) | 19 (9) |
| Opponent | Chaff | 2 | 0 (2) | 0 | 0 | 100 | 100% | - | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Character | 8 | 0 (8) | 0 | 0 | 11 | 38% | 1.8 | 0 (4) | 0 (2) | 0 (1) | 0 (4) | 0 (3) |
| Opponent | Clean-up | 4 | 0 (4) | 0 | 0 | 0 | 75% | 5.0 | - | 0 (3) | 0 (1) | 0 (2) | 0 (2) |
| Opponent | Fast Hammer | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Hammer | 6 | 0 (6) | 0 | 0 | 20 | 67% | 1.0 | 0 (3) | 0 (3) | - | 0 (4) | 0 (2) |
| Opponent | Holder | 5 | 191 (5) | 0 | 191 | 0 | 80% | 1.0 | 0 (2) | 308 (2) | 202 (1) | 247 (4) | 0 (1) |
| Opponent | Shooter | 7 | 28 (7) | 28 | 0 | 68 | 29% | 2.2 | 0 (1) | 0 (2) | 70 (4) | 63 (3) | 0 (4) |
| Opponent | War machine | 3 | 75 (3) | 75 | 0 | 67 | 0% | 1.0 | - | - | 75 (3) | - | 75 (3) |
| Opponent | Wizard | 4 | 0 (4) | 0 | 0 | 30 | 25% | 2.0 | 0 (1) | 0 (1) | - | - | 0 (2) |

### Charged fights: gs3-83c8646-p28

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 2 | 94 | 32 | 0.5 | 1.0 | 65 | 0 | +65 | 0 of 1 | 1 of 1 | - | +65 |
| Mine | Empire of Man | 1 | 60 | 575 | 3.0 | 1.0 | 192 | 0 | +192 | 1 of 3 | 2 of 3 | - | +192 |
| **Mine** | all armies | 3 | 83 | 213 | 1.3 | 1.0 | 160 | 0 | +160 | 1 of 4 | 3 of 4 | - | +160 |
| Opponent | Empire of Man | 1 | 238 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 79 | 0 | 0.0 | - | - | - | - | - | - | - | - |

### Effective charges: gs3-83c8646-p28

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 1 | 0 | 0 | 1 (net +65) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Mine | Empire of Man | 3 | 1 (net +60) | 0 | 0 | 1 (net +390) | 0 | 0 | 1 | 0% (0 of 2) |

### Charged fights, damage counted: gs3-83c8646-p28

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 189 | 189 | +60 | 86 | 94 | -8 | -4.5 |
| Mine | Effective (55-75%) | 1 | 60 | 65 | +65 | 65 | 0 | +65 | +108.3 |
| Mine | 76-89% | 1 | 380 | 265 | +390 | 390 | 0 | +390 | +102.6 |
| Mine | No odds | 1 | 380 | 125 | +125 | 125 | 193 | -68 | -17.8 |
| Mine | All fights | 4 | 252 | 161 | +160 | 167 | 72 | +95 | +37.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p28 | move | 9 | 0 (0%) | 0 (0%) | 2 (22%) | 7 (78%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Horn of the Wild Hunt | Opponent | L0533 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Opponent | L0533 |
| Twice-Blessed Armour | Mine | L0709 |
| Witch Hunter's Ward | Mine | L0709 |

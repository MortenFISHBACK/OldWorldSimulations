# Doctrine scorecard: gs3-83c8646-p77

### Scorecard: gs3-83c8646-p77

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0725 | 5 | 1 | Mine | no | - | - | 0 | 3 | 0 | 0 | 0 | 452 |
| L0725 | 5 | 1 | Opponent | no | - | 5 | 1 | 5 | 0 | 0 | 0 | 50 |
| L0815 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 450 |
| L0815 | 5 | 1 | Opponent | yes | - | - | 0 | 3 | 1 | 0 | 0 | 115 |
| L0831 | 3 | 1 | Mine | no | 1 | 2 | 1 | 1 | 0 | 0 | 0 | 255 |
| L0831 | 3 | 1 | Opponent | no | 1 | 3 | 2 | 3 | 1 | 0 | 0 | 170 |
| **Average** | | | Mine | 0% | 1.0 | 2.0 | 0.3 | 2.0 | 0.0 | 0.0 | 0.0 | 385.7 |
| **Average** | | | Opponent | 33% | 1.0 | 4.0 | 1.0 | 3.7 | 0.7 | 0.0 | 0.0 | 111.7 |

### KPIs: gs3-83c8646-p77

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 64% (9 of 14) | 0% (0 of 12) | 35% (9 of 26) |
| Winner chose to follow up after the loser gave ground |  | 100% (3 of 3); on the table 100% | 100% (6 of 6); on the table 100% | 100% (9 of 9); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 100% (4 of 4); on the table 100% | 100% (6 of 6); on the table 100% | 100% (10 of 10); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 83% (5 of 6) | 39% (7 of 18) | 50% (12 of 24) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 83% (5 of 6) | 44% (7 of 16) | 55% (12 of 22) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 67% (8 of 12) | 67% (8 of 12) |
| Points that never fought | lower | 77% (4615 of 5999) | 83% (4973 of 5999) | 80% (9588 of 11998) |
|   infantry points that never fought | lower | 62% (597 of 968) | 82% (674 of 821) | 71% (1271 of 1789) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 67% (20 of 30) | 80% (20 of 25) | 73% (40 of 55) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 67% (2 of 3); 1.7 uses a game | 67% (2 of 3); 0.8 uses a game |
| Bound items with another spell used |  | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 67% (2 of 3); 0.7 uses a game | 0.0 uses a game | 67% (2 of 3); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 62% (3317 of 5378) | 83% (4593 of 5548) | 72% (7910 of 10926) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.0 (27%) | 1.0 (25%) |
| MARCHED: its unit marched | 0.3 (100%) | 2.0 (55%) | 2.3 (58%) |
| GONE: slain | 0.0 (0%) | 0.7 (18%) | 0.7 (17%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- |
| tried | 0.7 | 5.3 | 4.0 | 0.3 |
| not cast | 5.3 | 4.7 | 4.0 | 15.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (7%) | 1.0 (25%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 2.3 (58%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| GONE: slain | 0.7 (12%) | 0.7 (14%) | 0.7 (17%) | 1.3 (9%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.7 (14%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.7 (88%) | 3.0 (64%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.0 (83%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 4.0 a game | 2.7 a game |
| stood (cast and not dispelled) | 75% (3 of 4) | 67% (4 of 6) | 70% (7 of 10) |
| the unit moved after it | 0% (0 of 3) | 75% (3 of 4) | 43% (3 of 7) |
| it charged on its next turn | 0% (0 of 3) | 0% (0 of 4) | 0% (0 of 7) |
| the enemy charged it first | 33% (1 of 3) | 0% (0 of 4) | 14% (1 of 7) |
| it fought by the end of its next turn | 0% (0 of 3) | 0% (0 of 4) | 0% (0 of 7) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 3) | 0% (0 of 4) | 0% (0 of 7) |
| none of these (no charge, no fight, no charge escaped) | 67% (2 of 3) | 100% (4 of 4) | 86% (6 of 7) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 71% (70 of 99) | 53% (10 of 19) | 68% (80 of 118) |
|   cavalry | 64% (14 of 22) | - | 64% (14 of 22) |
|   character | - | 0% (0 of 7) | 0% (0 of 7) |
|   chariot | 75% (6 of 8) | - | 75% (6 of 8) |
|   infantry | 42% (5 of 12) | 83% (10 of 12) | 62% (15 of 24) |
|   war machine | 79% (45 of 57) | - | 79% (45 of 57) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (21%) | 2.0 (67%) | 4.0 (32%) |
| FLEEING: it fled or was fleeing | 0.3 (3%) | 0.0 (0%) | 0.3 (3%) |
| IN COMBAT: it fought this turn or the last | 1.0 (10%) | 0.0 (0%) | 1.0 (8%) |
| MOVED: a war machine that moved | 2.0 (21%) | 0.0 (0%) | 2.0 (16%) |
| NO TARGET IN RANGE | 1.0 (10%) | 0.7 (22%) | 1.7 (13%) |
| ONLY IN COMBAT: the only targets were in combat | 1.7 (17%) | 0.0 (0%) | 1.7 (13%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (14%) | 0.3 (11%) | 1.7 (13%) |
| OTHER BAR | 0.3 (3%) | 0.0 (0%) | 0.3 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 8.7 | 3.3 | 62% | 11.5 pts | 100 pts |
| chariot | 2.0 | 1.0 | 67% | 4.6 pts | 9 pts |
| infantry | 6.7 | 1.3 | 80% | 7.3 pts | 48 pts |
| war machine | 15.0 | 12.3 | 64% | 30.7 pts | 460 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.3 | 1.3 | 0.8 |
| Charges that made contact a game | 0.3 | 0.7 | 0.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (3 units) | 0.00 declared, 0.00 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.05 declared, 0.05 contact (21 units) | 0.19 declared, 0.10 contact (21 units) | 0.12 declared, 0.07 contact (42 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 75% (6 of 8) | 67% (4 of 6) | 100% (1 of 1) | 73% (11 of 15) |
| Character in a unit | 100% (5 of 5) | - | - | 100% (5 of 5) |
| Character on its own | 83% (5 of 6) | 100% (1 of 1) | 60% (3 of 5) | 75% (9 of 12) |
| Chariot | 100% (1 of 1) | 50% (1 of 2) | - | 67% (2 of 3) |
| Infantry | 60% (3 of 5) | - | 50% (1 of 2) | 57% (4 of 7) |
| Monster | 100% (2 of 2) | - | - | 100% (2 of 2) |
| War Machines | 64% (7 of 11) | - | - | 64% (7 of 11) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 3 | 100% (4 of 4); on the table 100% | 83% (5 of 6) | 77% | 67% (20 of 30) | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| High Elf Realms | 1 | - | 0% (0 of 6) | 100% | 86% (6 of 7) | 50% (1 of 2); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (3 of 3); on the table 100% | 67% (4 of 6) | 93% | 100% (6 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (3 of 3); on the table 100% | 50% (3 of 6) | 56% | 67% (8 of 12) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p77, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 0% (0) | 0% (0) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: gs3-83c8646-p77

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.0 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | - | 50% (1 of 2) |
| Strategy | Shoot objectives carried out (shot that target) | 44% (28 of 64) | 50% (5 of 10) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 29% (2 of 7) | 0% (0 of 1) |
| Strategy | Lone characters that fought | 14% (1 of 7) | 18% (2 of 11) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 2.0 | 3.7 |
| Movement | Points that never moved of their own | 385.7 | 111.7 |
| Movement | Fights charged into per game | 0.3 | 0.7 |
| Movement | Charges with odds: long shots (under 50%) | - | 0 of 1 |
| Movement | Charges with odds: sweet spot (55-75%) | - | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | - | 0 of 1 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | - | 0 of 1 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.7 | 4.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 58% (15 of 26) | 31% (4 of 13) |
| Shooting | Points destroyed by shooting units | 106.7 | 41.7 |
| Shooting | War machine shots | 15.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 56% (25 of 45) | - |
| Shooting | Points destroyed by war machines | 307.7 | 0.0 |
| Magic | Magic missiles cast | 1.7 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 20% (1 of 5) | 75% (3 of 4) |
| Magic | Wounds caused by magic missiles | 8.0 | 3.0 |
| Magic | Points destroyed by magic (all spells) | 116.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 0.3 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 122.3 | 122.3 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | -163 | +25 |
| Combat | Net per 100 charger points, damage counted | -61.6 | +18.8 |
| Combat | First round won (charged fights) | 100% | 50% |
| Combat | Net points per charged fight | -14 | -7 |
| Combat | Net points per supported fight / lone fight | - / -14 | - / -7 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 1 | 2 of 2 |
| Game | Points lost | 343.7 | 603.0 |
| Game | VP from objectives | 456.7 | 623.3 |
| Game | Lone holders (player turns) | 1.0 | 1.0 |

- Mine won / drew / lost: 0 / 3 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +149 VP
- Points traded per game (both sides' losses): 947
- Games not ended: 0; findings 2, warnings 0

### Opponent rules: gs3-83c8646-p77

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 11.0 | +88.9 | 0.0 | 0.0 | 17.3 | -32.5 | 0.0 | 156.0 |
| ARTILLERY RE-ROLL WEIGHED | 6.0 | +0.0 | 0.0 | 41.7 | - | - | - | - |
| ASSAILMENT BY POINTS | 0.3 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | +1.3 | 0.0 | 38.7 |
| CANNON PLAN MISSED | 1.7 | +0.0 | 334.7 | 41.7 | - | - | - | - |
| CANNON PLANNED TARGET | 14.7 | +342.5 | 1464.0 | 291.7 | - | - | - | - |
| CANNON SIGHT KEPT | 2.3 | +0.0 | 0.0 | 41.7 | - | - | - | - |
| CAST JOB | 1.7 | +87.4 | 0.0 | 0.0 | 2.3 | +21.1 | 109.3 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.7 | +8.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +6.4 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 10.7 | -978.7 | 0.0 | 0.0 | 13.3 | -752.3 | 0.0 | 772.7 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 83.7 | 88.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 6.7 | +0.0 | 0.0 | 0.0 | 10.7 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 88.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 1.3 | +160.2 | 0.0 | 0.0 | 2.0 | +130.8 | 0.0 | 0.0 |
| COVER ONCE | 9.7 | -499.0 | 0.0 | 54.7 | 3.7 | -316.6 | 0.0 | 380.0 |
| DEPLOY BY FIGURES | 8.0 | -93.7 | 0.0 | 41.7 | 6.3 | +53.2 | 0.0 | 38.3 |
| EXACT ROUND | 0.3 | +15.6 | 83.7 | 88.3 | 0.7 | -6.6 | 0.0 | 38.7 |
| FALL BACK GOOD ORDER | 0.3 | +1.9 | 83.7 | 88.3 | 1.0 | +4.7 | 0.0 | 38.7 |
| FALLBACK BY WORTH | 0.7 | +33.3 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | - | - | - | - | 17.0 | +266.9 | 0.0 | 584.3 |
| FEATURE BUFFS | 0.7 | +27.8 | 0.0 | 0.0 | 1.0 | +33.7 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.7 | +20.7 | 0.0 | 38.7 |
| FIRE IN ORDER | 0.7 | +0.0 | 20.0 | 41.7 | - | - | - | - |
| FIVE ACTION | 99.7 | +4718.8 | 4502.0 | 890.3 | 72.3 | +5067.0 | 411.3 | 1165.3 |
| FLANK NOT WEIGHED | 4.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 401.0 |
| FOLLOW UP WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +328.4 | 0.0 | 38.7 |
| FOOT FIRST | 17.0 | +0.0 | 0.0 | 41.7 | - | - | - | - |
| FOUR ROUNDS | 0.3 | +79.4 | 83.7 | 88.3 | 1.0 | +161.5 | 0.0 | 38.7 |
| FREED FROM HIS FIGHT | 4.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -6.1 | 140.7 | 0.0 | 0.7 | -22.3 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 1.0 | +22.8 | 0.0 | 88.3 | - | - | - | - |
| GOAL ROUTE | 1.3 | +69.2 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 9.3 | +908.0 | 0.0 | 0.0 | 10.7 | +1783.8 | 0.0 | 0.0 |
| GUN FIGURES | 2.0 | +22.5 | 199.0 | 0.0 | - | - | - | - |
| GUN MASK | 2.0 | +47.4 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 8.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 772.7 |
| HIS CHARGE LIST | 3.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 169.3 |
| HIS LEGAL MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 246.7 |
| HIS MOVE AND SHOT | 2.3 | -22.5 | 0.0 | 0.0 | 3.0 | -51.5 | 0.0 | 167.3 |
| HIS ONE QUARTER | 2.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 77.3 |
| HIS OWN BEST MOVE | 3.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 246.7 |
| HIS RANDOM MOVE | 7.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 4.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 18.7 | +352.3 | 0.0 | 0.0 | 54.3 | +4850.4 | 0.0 | 728.7 |
| HIS SHOTS BY HIS RUN | 13.3 | +135.2 | 0.0 | 0.0 | 42.3 | +2009.1 | 0.0 | 957.3 |
| HOLD ODDS | 5.3 | +0.0 | 0.0 | 0.0 | 11.3 | +0.0 | 0.0 | 334.7 |
| HOLDER ASSIGNMENT | 3.7 | +252.6 | 0.0 | 0.0 | 6.3 | +633.3 | 0.0 | 167.3 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.3 | -2.5 | 83.7 | 88.3 | 0.7 | -12.8 | 0.0 | 38.7 |
| IDLE COST | - | - | - | - | 14.3 | -204.4 | 0.0 | 212.7 |
| KEPT FROM ITS LAST STOP | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +11.1 | 0.0 | 0.0 | 0.7 | +44.3 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.3 | +0.0 | 475.3 | 265.0 | 3.7 | +0.0 | 176.7 | 116.0 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.7 | +45.1 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 0.3 | +0.0 | 83.7 | 88.3 | 0.3 | +0.3 | 0.0 | 0.0 |
| MANOEUVRE | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | -38.6 | 0.0 | 83.7 |
| MARCH AT ESCAPER | 0.3 | +5.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | - | - | - | - | 0.3 | +88.9 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +7.9 | 0.0 | 0.0 | 0.3 | +7.1 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +40.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | -58.3 | 0.0 | 0.0 | 1.7 | +37.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.3 | +18.0 | 0.0 | 0.0 | 1.0 | +7.5 | 0.0 | 38.7 |
| MEETS IN TIME | 4.3 | +75.1 | 0.0 | 41.7 | 3.0 | +38.3 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.7 | +108.4 | 0.0 | 0.0 | 4.3 | +33.0 | 0.0 | 70.3 |
| MISSILES NEXT TURN | 1.7 | +71.8 | 0.0 | 0.0 | 7.3 | +41.3 | 0.0 | 70.3 |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 83.7 | 38.7 |
| MOVE SPELL IN RANGE | 2.0 | +49.8 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.7 | -9.5 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 4.7 | +372.7 | 0.0 | 0.0 | 3.0 | +235.5 | 0.0 | 246.7 |
| MOVES UNITS SPELL | - | - | - | - | 0.3 | +2.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 10.0 | +382.3 | 0.0 | 109.3 | 8.0 | +359.8 | 0.0 | 0.0 |
| NEAREST TO GOAL | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 4.7 | +521.0 | 140.7 | 0.0 | 1.3 | +125.0 | 0.0 | 77.3 |
| NO DOUBLE ROUNDS | 0.3 | -32.0 | 83.7 | 88.3 | 1.0 | -58.4 | 0.0 | 38.7 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 70.3 |
| NOT WORTH A CAST | 1.7 | -1.3 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 5.7 | -227.8 | 83.7 | 171.7 | 1.0 | -49.4 | 0.0 | 38.7 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.0 | -59.4 | 0.0 | 0.0 | 3.0 | -110.3 | 0.0 | 406.0 |
| ONE OBJECTIVE FORMULA | 2.7 | -89.8 | 0.0 | 0.0 | 3.7 | +90.4 | 0.0 | 167.3 |
| ONE PROMISE A TARGET | 1.3 | -108.6 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.3 | +2.4 | 0.0 | 0.0 |
| PATHS CROSS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PLAN RESULT | 44.7 | +2190.6 | 1542.0 | 494.3 | 36.3 | +184.6 | 41.7 | 911.7 |
| PROMISE BELOW ZERO | - | - | - | - | 0.7 | +0.0 | 0.0 | 15.0 |
| PROMISE BY ITS OWN SUM | 9.0 | -517.2 | 0.0 | 0.0 | 5.0 | -110.4 | 0.0 | 169.3 |
| PROMISE KNOWS THE FIGHT | 3.3 | -4.9 | 140.7 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| QUARTER ODDS | 28.3 | +1640.5 | 2260.7 | 166.7 | 18.0 | +2161.6 | 0.0 | 77.3 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.0 | +86.4 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.7 | +6.7 | 0.0 | 0.0 | 3.3 | +640.0 | 0.0 | 15.0 |
| REDIRECT FOR A FRIEND IN REACH | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.3 | -2.8 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 0.3 | -1.8 | 83.7 | 88.3 | 0.7 | -44.7 | 0.0 | 38.7 |
| ROUNDS AFTER TERROR | 0.3 | -15.9 | 83.7 | 88.3 | - | - | - | - |
| RUN DOWN | 0.3 | -10.3 | 83.7 | 88.3 | 0.7 | -10.7 | 0.0 | 38.7 |
| SAME CHARGE LATER | 0.3 | -9.7 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.0 | -42.2 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +4.0 | 0.0 | 0.0 | 0.7 | +20.3 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +119.7 | 83.7 | 88.3 | 0.3 | +15.8 | 0.0 | 38.7 |
| SELF MOVE SPELL | - | - | - | - | 2.0 | +569.6 | 0.0 | 0.0 |
| SET CREDITED ONCE | 1.0 | -28.1 | 0.0 | 0.0 | 0.7 | -45.8 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.3 | +41.2 | 0.0 | 0.0 | 1.3 | +38.5 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 1.7 | +17.6 | 0.0 | 77.3 |
| SET-UP MISSED | 0.7 | +103.5 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +0.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 23.0 | +0.0 | 0.0 | 401.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +9.3 | 140.7 | 0.0 | 0.7 | +82.7 | 109.3 | 0.0 |
| SHORT GUN FORWARD | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 12.7 | -11.1 | 0.0 | 0.0 | 34.3 | +1490.9 | 0.0 | 917.3 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 25.3 | +1411.4 | 0.0 | 401.0 | 4.0 | +193.5 | 0.0 | 199.0 |
| SPELL WORTH | 0.3 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | -22.9 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 53.7 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -2.8 | 0.0 | 38.7 |
| STANDS FOR A REASON | - | - | - | - | 3.7 | +0.0 | 109.3 | 481.7 |
| STANDS STILL | 69.7 | +0.0 | 4418.3 | 802.0 | 21.0 | +0.0 | 411.3 | 475.3 |
| STAY WORTH | 48.0 | -126.3 | 1889.7 | 664.0 | 8.3 | +174.0 | 302.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 3.7 | +80.4 | 0.0 | 0.0 | 1.0 | +147.1 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 83.7 | 88.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 3.7 | +80.4 | 0.0 | 0.0 | 1.0 | +147.1 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.7 | +2.4 | 0.0 | 38.7 |
| THE DEARER SUM KEEPS ITS PLAN | 2.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 4.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 48.0 | +0.0 | 0.0 | 401.0 | 35.7 | +0.0 | 0.0 | 563.3 |
| TIME ON OUR SIDE | 39.0 | +457.0 | 0.0 | 109.3 | - | - | - | - |
| TWO OR MORE ARRIVE | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.3 | -6.7 | 83.7 | 88.3 | 0.3 | +12.1 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 5.0 | -891.5 | 0.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 2.7 | +20.2 | 0.0 | 0.0 | 2.7 | +88.1 | 0.0 | 334.7 |

### Rule changes: gs3-83c8646-p77

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 85 | 85 | 62 | 20.67 | +604 | +9.7 |
| HIS SHOTS BY HIS RUN | 167 | 160 | 33 | 11.00 | +673 | +20.4 |
| HIS SHOT LIST | 219 | 214 | 31 | 10.33 | +1143 | +36.9 |
| HOLDER ASSIGNMENT | 30 | 30 | 28 | 9.33 | +1885 | +67.3 |
| TIME ON OUR SIDE | 117 | 104 | 28 | 9.33 | +73 | +2.6 |
| LEGAL CHARGES ONLY | 27 | 27 | 27 | 9.00 | +0 | +0.0 |
| DEPLOY BY FIGURES | 43 | 43 | 26 | 8.67 | +348 | +13.4 |
| SHOT RISK POINTS | 141 | 134 | 24 | 8.00 | +1602 | +66.8 |
| FIVE ACTION | 516 | 505 | 20 | 6.67 | +2386 | +119.3 |
| OFF BEST | 20 | 20 | 20 | 6.67 | -832 | -41.6 |
| PROMISE BY ITS OWN SUM | 42 | 42 | 19 | 6.33 | -1883 | -99.1 |
| THE TABLE AGAIN | 36 | 36 | 19 | 6.33 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| GOAL WALK | 60 | 60 | 15 | 5.00 | +2270 | +151.3 |
| MOVE ORDER | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| STAY WORTH | 169 | 159 | 12 | 4.00 | +159 | +13.2 |
| QUARTER ODDS | 139 | 136 | 11 | 3.67 | +611 | +55.5 |
| MOVE TO CHARGE COMPUTED | 23 | 18 | 10 | 3.33 | +359 | +35.9 |
| CAST JOB | 12 | 12 | 9 | 3.00 | +81 | +9.0 |
| CHARGE LOSSES | 72 | 66 | 8 | 2.67 | +987 | +123.4 |
| MEETS IN TIME | 22 | 22 | 8 | 2.67 | +93 | +11.6 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 8 | 2.67 | +259 | +32.4 |
| CANNON SIGHT KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 6 | 6 | 6 | 2.00 | +985 | +164.2 |
| HARD STAY DROPPED | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SHOTS IN THE MOVE | 88 | 69 | 6 | 2.00 | +321 | +53.5 |
| SUPPORT ADDS | 14 | 14 | 6 | 2.00 | +151 | +25.2 |
| SUPPORT WORKED OUT | 14 | 14 | 6 | 2.00 | +151 | +25.2 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| COVER ONCE | 40 | 29 | 5 | 1.67 | +16 | +3.2 |
| NEXT CHARGE BY LIST | 18 | 15 | 5 | 1.67 | +286 | +57.1 |
| CHAFF PASSED | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| GOAL ROUTE | 4 | 4 | 4 | 1.33 | +208 | +51.9 |
| ONE PROMISE A TARGET | 4 | 4 | 4 | 1.33 | -326 | -81.4 |
| SET UP BY THE SET | 8 | 8 | 4 | 1.33 | +125 | +31.1 |
| SHOOTS FROM THE BEST SPOT | 4 | 4 | 4 | 1.33 | +13 | +3.2 |
| FEATURE BUFFS | 5 | 5 | 3 | 1.00 | +34 | +11.2 |
| FRIENDS SHOTS CHECKED | 3 | 3 | 3 | 1.00 | +68 | +22.8 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| IDLE COST | 43 | 30 | 3 | 1.00 | +10 | +3.2 |
| LANE BY FIGURES | 3 | 3 | 3 | 1.00 | +166 | +55.5 |
| NEARER NOT NEEDED | 54 | 50 | 3 | 1.00 | +31 | +10.3 |
| REDIRECT FOR A FRIEND IN REACH | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FOUR ROUNDS | 4 | 2 | 2 | 0.67 | +138 | +69.0 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +135 | +67.7 |
| MAX FOR POSITIONING | 7 | 7 | 2 | 0.67 | +0 | +0.0 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| PROMISE KNOWS THE FIGHT | 13 | 9 | 2 | 0.67 | -15 | -7.4 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SEARCH SPOT | 4 | 4 | 2 | 0.67 | +73 | +36.5 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +406 | +203.2 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +2 | +1.0 |
| SHORT GUN FORWARD | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 24 | 2 | 2 | 0.67 | +0 | +0.0 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +4 | +4.0 |
| CANNON PLANNED TARGET | 44 | 44 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +19 | +19.2 |
| CHARGE NOW FIRST | 2 | 2 | 1 | 0.33 | -5 | -4.9 |
| FALLBACK BY WORTH | 2 | 2 | 1 | 0.33 | +100 | +100.0 |
| FALLS SHORT | 51 | 43 | 1 | 0.33 | +43 | +42.7 |
| FIGHT TO THE END | 2 | 1 | 1 | 0.33 | +27 | +27.0 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +267 | +266.7 |
| MARCH CHECK | 2 | 1 | 1 | 0.33 | +2 | +1.7 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -120 | -120.0 |
| MISSILES NEXT TURN | 27 | 15 | 1 | 0.33 | +3 | +3.4 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| NO DOUBLE ROUNDS | 4 | 2 | 1 | 0.33 | +27 | +27.0 |
| ONE OBJECTIVE FORMULA | 19 | 16 | 1 | 0.33 | +48 | +48.2 |
| REDIRECT COUNTER | 12 | 10 | 1 | 0.33 | +5 | +5.2 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -1 | -1.3 |
| SHOTS AFTER THE MOVES | 21 | 21 | 1 | 0.33 | +0 | +0.0 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SUPPORT NARROWED | 2 | 2 | 1 | 0.33 | -55 | -55.0 |
| WOUNDS ON THE RANKS | 16 | 16 | 1 | 0.33 | +28 | +28.0 |
| BLOWS WHERE AIMED | 1 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 5 | 5 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 10 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 52 | 52 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 10 | not checked | - | - | - | - |
| EXACT ROUND | 3 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 4 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 27 | not checked | - | - | - | - |
| FOOT FIRST | 51 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 19 | 17 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GUN FIGURES | 6 | not checked | - | - | - | - |
| GUN MASK | 6 | 6 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 7 | 5 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 39 | 35 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 19 | 19 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 19 | 19 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 16 | 15 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 22 | 21 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 23 | 23 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 23 | 23 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 13 | 13 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 50 | 50 | 0 | 0.00 | - | - |
| HONEST WORTH | 3 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 8 | 8 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LOST AFTER ESCAPE | 2 | 1 | 0 | 0.00 | - | - |
| MANOEUVRE | 9 | 9 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 6 | 6 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 18 | 7 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 6 | 1 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 2 | trace | - | - | - | - |
| MOVE SPELL SPOT | 2 | not checked | - | - | - | - |
| NEAREST TO GOAL | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 5 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 18 | 7 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 243 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 4 | 3 | 0 | 0.00 | - | - |
| RISK BY ARC | 3 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | not checked | - | - | - | - |
| RUN DOWN | 3 | 1 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 5 | 5 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 5 | 2 | 0 | 0.00 | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 84 | not checked | - | - | - | - |
| SPELL WORTH | 1 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 39 | 37 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | not checked | - | - | - | - |
| STANDS FOR A REASON | 11 | 11 | 0 | 0.00 | - | - |
| STANDS STILL | 272 | 270 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 13 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 10 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 5 | not checked | - | - | - | - |
| THE TABLE BINDS | 251 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 1 | not checked | - | - | - | - |
| WAITS AGAIN | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 15 | 13 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p77

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 4.67 | 1.67 | 99.1 |
| JOB FIRST | gate | 5.33 | 0.67 | 41.3 |
| ARMY TABLE | rule | 1.33 | 3.00 | 71.9 |
| ONE PROMISE A TARGET | rule | 1.33 | - | 81.4 |
| PROMISE KNOWS THE FIGHT | rule | 0.67 | - | 7.4 |
| CHARGE NOW FIRST | rule | - | 0.33 | 4.9 |
| MARCH OF THE TABLE | rule | 0.33 | - | 120.0 |
| NO REASON | gate | 0.33 | - | 10.1 |
| REFUSING RETIRES | rule | 0.33 | - | 1.3 |
| RULE SWITCHED OFF | gate | - | 0.33 | 79.0 |
| SUPPORT NARROWED | rule | - | 0.33 | 55.0 |

### Plans: gs3-83c8646-p77

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.3 | 100% | 143 | 67 | 47% |
| Mine | join | 2.0 | 100% | 27 | 0 | 0% |
| Mine | move | 23.3 | 99% | 1074 | 0 | 0% |
| Mine | shoot | 19.0 | 63% | 922 | 2124 | 230% |
| Opponent | charge | 1.0 | 67% | 62 | 7 | 11% |
| Opponent | join | 2.7 | 88% | 129 | 0 | 0% |
| Opponent | move | 29.3 | 93% | 1809 | 0 | 0% |
| Opponent | shoot | 2.7 | 50% | 154 | 178 | 116% |
| Opponent | support | 0.7 | 100% | 0 | 0 | - |

### Battle groups: gs3-83c8646-p77

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.7 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 3.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p77

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | Character | 12 | 24 (12) | 24 | 0 | 7 | 75% | 3.0 | 0 (8) | 54 (3) | - | 48 (6) | 0 (5) |
| Mine | Fast Hammer | 5 | 0 (5) | 0 | 0 | 0 | 60% | 1.5 | 0 (4) | 0 (1) | - | 0 (2) | 0 (3) |
| Mine | Hammer | 4 | 22 (4) | 20 | 2 | 21 | 25% | 2.3 | 39 (2) | 5 (2) | - | 28 (3) | 8 (1) |
| Mine | Shooter | 5 | 39 (5) | 26 | 13 | 24 | 0% | 2.0 | 40 (4) | 37 (1) | - | 25 (4) | 72 (1) |
| Mine | War machine | 11 | 84 (11) | 84 | 0 | 36 | 0% | 1.3 | 102 (9) | 0 (2) | - | 182 (5) | 0 (6) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 5.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Chaff | 4 | 0 (4) | 0 | 0 | 18 | 100% | - | 0 (3) | 0 (1) | - | 0 (3) | 0 (1) |
| Opponent | Character | 9 | 16 (9) | 16 | 0 | 38 | 44% | 2.2 | 0 (5) | 35 (4) | - | 17 (6) | 14 (3) |
| Opponent | Clean-up | 2 | 0 (2) | 0 | 0 | 63 | 50% | 2.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 5 | 7 (5) | 0 | 7 | 28 | 80% | 2.0 | 0 (3) | 28 (2) | - | 0 (4) | 45 (1) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 0 | 33% | 4.5 | 0 (2) | 0 (1) | - | 0 (2) | 0 (1) |
| Opponent | Holder | 3 | 7 (3) | 0 | 7 | 35 | 100% | - | - | 11 (2) | 0 (1) | 0 (1) | 11 (2) |
| Opponent | Shooter | 2 | 41 (2) | 41 | 0 | 0 | 0% | 1.5 | 99 (1) | 0 (1) | - | 99 (1) | 0 (1) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 43 | 0% | 3.0 | 0 (2) | 0 (1) | - | 0 (1) | 0 (2) |

### Charged fights: gs3-83c8646-p77

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 3 | 531 | 84 | 0.3 | 1.0 | 251 | 265 | -14 | 1 of 1 | 1 of 1 | - | -14 |
| Opponent | High Elf Realms | 1 | 125 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Vampire Counts | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Warriors of Chaos | 1 | 0 | 102 | 1.0 | 1.0 | 102 | 116 | -14 | 1 of 1 | 1 of 1 | - | -14 |
| **Opponent** | all armies | 3 | 42 | 34 | 0.7 | 1.0 | 51 | 58 | -7 | 2 of 2 | 1 of 2 | - | -7 |

### Effective charges: gs3-83c8646-p77

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Vampire Counts | 1 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: gs3-83c8646-p77

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | No odds | 1 | 265 | 201 | -14 | 316 | 479 | -163 | -61.6 |
| Mine | All fights | 1 | 265 | 201 | -14 | 316 | 479 | -163 | -61.6 |
| Opponent | 50-54% | 1 | 147 | 189 | +0 | 295 | 260 | +35 | +24.1 |
| Opponent | No odds | 1 | 116 | 202 | -14 | 325 | 311 | +14 | +12.1 |
| Opponent | All fights | 2 | 132 | 196 | -7 | 310 | 286 | +25 | +18.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p77 | move | 11 | 1 (9%) | 1 (9%) | 0 (0%) | 10 (91%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0725 |
| Invocation of Nehek | Opponent | L0725 |
| Ring of Doom | Opponent | L0815, L0831 |
| Twice-Blessed Armour | Mine | L0725 |
| Witch Hunter's Ward | Mine | L0725, L0815, L0831 |

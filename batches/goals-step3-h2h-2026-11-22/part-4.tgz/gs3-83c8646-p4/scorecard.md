# Doctrine scorecard: gs3-83c8646-p4

### Scorecard: gs3-83c8646-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0524 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 285 |
| L0524 | 2 | 1 | Opponent | - | - | - | 1 | 5 | 1 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 4 | - | 0 | 4 | 0 | 0 | 0 | 550 |
| L0612 | 6 | 1 | Opponent | no | 6 | 6 | 1 | 0 | 0 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 696 |
| L0628 | 4 | 1 | Opponent | no | 8 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 2.0 | - | 0.0 | 3.0 | 0.0 | 0.0 | 0.0 | 510.3 |
| **Average** | | | Opponent | 0% | 7.0 | 6.0 | 0.7 | 2.3 | 0.3 | 0.0 | 0.0 | 110.0 |

### KPIs: gs3-83c8646-p4

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 100% (15 of 15) | 0% (0 of 14) | 52% (15 of 29) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | - | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 100% (2 of 2); on the table 100% | - | 100% (2 of 2); on the table 100% |
| Magic missiles tried each own turn | 50%+ | - | 30% (9 of 30) | 30% (9 of 30) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 47% (9 of 19) | 47% (9 of 19) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 79% (4742 of 6000) | 87% (5236 of 5998) | 83% (9978 of 11998) |
|   infantry points that never fought | lower | 81% (1810 of 2232) | 100% (694 of 694) | 86% (2504 of 2926) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (15 of 27) | 70% (16 of 23) | 62% (31 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 67% (2 of 3); 2.0 uses a game | 67% (2 of 3); 1.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 51% (2163 of 4232) | 76% (4421 of 5787) | 66% (6584 of 10019) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.7 (24%) | 1.7 (24%) |
| MARCHED: its unit marched | - | 1.3 (19%) | 1.3 (19%) |
| IN COMBAT: engaged in combat | - | 0.3 (5%) | 0.3 (5%) |
| REAR RANK: in a rear rank | - | 0.3 (5%) | 0.3 (5%) |
| GONE: slain | - | 3.3 (48%) | 3.3 (48%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 5.3 | 0.0 | 3.0 | 0.7 | 0.3 |
| not cast | 2.7 | 4.0 | 7.0 | 3.3 | 23.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (50%) | 1.7 (24%) | 0.7 (20%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.3 (19%) | 0.7 (20%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.3 (5%) | 0.0 (0%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (0%) | 0.3 (5%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.7 (25%) | 2.0 (50%) | 3.3 (48%) | 2.0 (60%) | 4.0 (17%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (75%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 19.3 (82%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 67% (141 of 210) | 89% (8 of 9) | 68% (149 of 219) |
|   cavalry | 37% (7 of 19) | 50% (1 of 2) | 38% (8 of 21) |
|   character | 86% (24 of 28) | - | 86% (24 of 28) |
|   infantry | 56% (32 of 57) | - | 56% (32 of 57) |
|   monster | 75% (9 of 12) | - | 75% (9 of 12) |
|   war machine | 73% (69 of 94) | 100% (7 of 7) | 75% (76 of 101) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.3 (19%) | 0.3 (100%) | 4.7 (20%) |
| NO TARGET IN RANGE | 9.7 (42%) | 0.0 (0%) | 9.7 (41%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 7.0 (30%) | 0.0 (0%) | 7.0 (30%) |
| SHELTERED: the target was sheltered | 1.7 (7%) | 0.0 (0%) | 1.7 (7%) |
| OTHER BAR | 0.3 (1%) | 0.0 (0%) | 0.3 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.7 | 1.3 | 62% | 16.0 pts | 43 pts |
| character | 9.0 | 6.3 | 56% | 8.9 pts | 80 pts |
| infantry | 21.7 | 5.3 | 80% | 3.2 pts | 69 pts |
| monster | 3.3 | 0.3 | 90% | 1.4 pts | 5 pts |
| war machine | 25.3 | 16.0 | 71% | 25.8 pts | 653 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.0 | 2.0 | 1.0 |
| Charges that made contact a game | 0.0 | 1.3 | 0.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.33 declared, 0.33 contact (3 units) | 0.33 declared, 0.33 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.50 declared, 0.50 contact (2 units) | 0.50 declared, 0.50 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.00 declared, 0.00 contact (21 units) | 0.33 declared, 0.17 contact (12 units) | 0.12 declared, 0.06 contact (33 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 25% (1 of 4) | 100% (1 of 1) | 50% (1 of 2) | 43% (3 of 7) |
| Character in a unit | 62% (5 of 8) | 75% (3 of 4) | 100% (1 of 1) | 69% (9 of 13) |
| Character on its own | - | 100% (3 of 3) | 100% (2 of 2) | 100% (5 of 5) |
| Infantry | 29% (2 of 7) | 50% (3 of 6) | - | 38% (5 of 13) |
| Monster | 100% (2 of 2) | - | - | 100% (2 of 2) |
| War Machines | 70% (7 of 10) | - | - | 70% (7 of 10) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dwarfen Mountain Holds | 3 | 100% (2 of 2); on the table 100% | - | 79% | 56% (15 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 22% (4 of 18) | 64% | 67% (6 of 9) | 67% (2 of 3); 6.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 1 | - | 0% (0 of 6) | 97% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | - | 83% (5 of 6) | 100% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p4, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | - | - | - |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: gs3-83c8646-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | - | 67% (4 of 6) |
| Strategy | Shoot objectives carried out (shot that target) | 63% (59 of 93) | 42% (5 of 12) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 42% (5 of 12) | 0% (0 of 6) |
| Strategy | Lone characters that fought | 0% (0 of 1) | 50% (3 of 6) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 3.0 | 2.3 |
| Movement | Points that never moved of their own | 510.3 | 110.0 |
| Movement | Fights charged into per game | 0.0 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | - | 0 of 2 |
| Movement | Charges with odds: sweet spot (55-75%) | - | 1 of 2, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | - | 0 of 2 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | - | 1 of 2, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 25.7 | 0.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 36% (28 of 77) | 0% (0 of 1) |
| Shooting | Points destroyed by shooting units | 124.3 | 0.0 |
| Shooting | War machine shots | 23.0 | 2.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 68% (47 of 69) | 0% (0 of 7) |
| Shooting | Points destroyed by war machines | 355.3 | 40.0 |
| Magic | Magic missiles cast | - | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 0% (0 of 4) |
| Magic | Wounds caused by magic missiles | - | 1.0 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 20.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 3.7 / 0.0 / 0.0 / 0.7 |
| Combat | Points destroyed in combat | 16.7 | 0.0 |
| Combat | Points run down | 0.0 | 21.7 |
| Combat | Net points per charged fight, damage counted | - | -24 |
| Combat | Net per 100 charger points, damage counted | - | -9.3 |
| Combat | First round won (charged fights) | - | 33% |
| Combat | Net points per charged fight | - | -17 |
| Combat | Net points per supported fight / lone fight | - / - | +0 / -25 |
| Combat | Charged fights on a top-3 enemy unit | - | 2 of 3 |
| Game | Points lost | 145.0 | 606.3 |
| Game | VP from objectives | 773.3 | 576.7 |
| Game | Lone holders (player turns) | 2.0 | 7.0 |

- Mine won / drew / lost: 3 / 0 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +702 VP
- The side that went first won 3 of 3 games with a winner
- Points traded per game (both sides' losses): 751
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 6.0 | +126.0 | 0.0 | 0.0 | 8.0 | +111.2 | 0.0 | 341.3 |
| ARTILLERY RE-ROLL WEIGHED | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.3 | +3.1 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 1.0 | +0.0 | 193.7 | 31.7 | - | - | - | - |
| CANNON PLANNED TARGET | 19.7 | +333.4 | 1625.0 | 95.0 | 2.3 | +128.7 | 40.0 | 165.0 |
| CANNON SIGHT KEPT | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 55.0 |
| CAST JOB | - | - | - | - | 2.7 | +5.8 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | - | - | - | - | 0.3 | +3.3 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.0 | +3.4 | 0.0 | 13.7 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 31.7 | - | - | - | - |
| CHALLENGE BY POINTS | 0.7 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 4.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 9.0 | -142.7 | 0.0 | 63.3 | 24.0 | -1137.3 | 0.0 | 628.0 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 37.0 | 0.0 | 0.7 | +0.0 | 53.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 8.7 | +0.0 | 0.0 | 86.7 | 8.3 | +0.0 | 0.0 | 33.3 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| COVER ONCE | 11.7 | -591.3 | 0.0 | 31.7 | 2.0 | -104.6 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -16.0 | 31.7 | 0.0 |
| DEPLOY BY FIGURES | 13.3 | -169.6 | 0.0 | 0.0 | 4.3 | +35.7 | 0.0 | 55.0 |
| EXACT ROUND | - | - | - | - | 1.0 | -2.3 | 53.3 | 0.0 |
| FALL BACK GOOD ORDER | - | - | - | - | 1.3 | +0.0 | 31.7 | 16.7 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | - | - | - | - | 21.0 | +297.9 | 0.0 | 572.7 |
| FEATURE BUFFS | 0.7 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 138.0 | +5445.5 | 4785.0 | 580.0 | 59.7 | +2150.7 | 53.3 | 1339.3 |
| FLANK NOT WEIGHED | 3.0 | +0.0 | 0.0 | 21.7 | 2.7 | +0.0 | 0.0 | 37.0 |
| FOLLOW UP WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FOOT FIRST | - | - | - | - | 13.7 | +0.0 | 0.0 | 198.3 |
| FOUR ROUNDS | - | - | - | - | 2.0 | +94.8 | 53.3 | 16.7 |
| FREED FROM HIS FIGHT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 5.3 | -201.2 | 37.0 | 0.0 | - | - | - | - |
| GOAL WALK | 3.7 | +298.6 | 0.0 | 0.0 | 2.0 | +121.2 | 0.0 | 0.0 |
| GUN FIGURES | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| GUN MASK | 1.3 | +8.9 | 0.0 | 0.0 | 1.3 | +77.8 | 0.0 | 0.0 |
| HARD STAY DROPPED | 4.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 126.3 |
| HIS CHARGE BY HIS RUN | 4.0 | +0.0 | 0.0 | 63.3 | 10.3 | +0.0 | 0.0 | 375.3 |
| HIS CHARGE LIST | 12.0 | +0.0 | 0.0 | 106.7 | 6.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.3 | -7.1 | 0.0 | 0.0 | 5.0 | -13.1 | 0.0 | 172.0 |
| HIS ONE QUARTER | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS OWN BEST MOVE | 6.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 34.3 | +980.2 | 0.0 | 240.0 | 40.3 | +2937.6 | 0.0 | 852.0 |
| HIS SHOTS BY HIS RUN | 28.0 | +369.3 | 0.0 | 0.0 | 38.3 | +862.6 | 0.0 | 695.3 |
| HIS TURN DENIED | - | - | - | - | 1.0 | +38.2 | 31.7 | 16.7 |
| HOLD ODDS | 10.7 | +0.0 | 0.0 | 0.0 | 12.0 | +0.0 | 0.0 | 74.0 |
| HOLDER ASSIGNMENT | 10.0 | +986.3 | 0.0 | 0.0 | 8.3 | +1098.5 | 0.0 | 37.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | - | - | - | - | 1.7 | -53.4 | 53.3 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 3.3 | +328.2 | 0.0 | 72.3 |
| IDLE COST | - | - | - | - | 13.7 | -325.6 | 0.0 | 459.3 |
| JOINT CHARGE NOW | - | - | - | - | 0.7 | -38.6 | 0.0 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +42.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 0.3 | +0.0 | 13.7 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | - | - | - | - | 1.0 | -19.3 | 0.0 | 0.0 |
| MANOEUVRE | 2.0 | -26.2 | 0.0 | 21.7 | 3.0 | -5.6 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 1.0 | +65.3 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 0.7 | -7.7 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 0.3 | +1.4 | 0.0 | 0.0 | 2.3 | +39.5 | 0.0 | 72.3 |
| MEETS IN TIME | 9.3 | +185.0 | 0.0 | 0.0 | 2.3 | +331.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | - | - | - | - | 5.3 | +20.6 | 0.0 | 0.0 |
| MISSILES NEXT TURN | - | - | - | - | 8.3 | +28.1 | 0.0 | 283.0 |
| MODEL FACING | 3.0 | +1289.7 | 0.0 | 20.0 | - | - | - | - |
| MOVE ORDER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 5.7 | +219.6 | 0.0 | 0.0 | 1.7 | +80.7 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.3 | +294.6 | 0.0 | 0.0 | 5.7 | +278.7 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 3.3 | +131.6 | 37.0 | 0.0 | 1.0 | +35.8 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | - | - | - | - | 1.0 | -16.9 | 53.3 | 0.0 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.3 | +13.3 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 5.7 | -209.0 | 0.0 | 31.7 | 4.3 | -77.9 | 0.0 | 147.3 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 2.0 | +8.6 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.0 | -26.0 | 0.0 | 0.0 | 1.0 | -16.7 | 0.0 | 72.3 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | +57.7 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 5.0 | +17.7 | 0.0 | 0.0 | 3.3 | -123.6 | 0.0 | 37.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| PATHS CROSS | 0.3 | +1.2 | 0.0 | 0.0 | 0.3 | +2.7 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.7 | -21.4 | 0.0 | 0.0 |
| PLAN RESULT | 59.7 | +2140.9 | 1261.3 | 230.0 | 28.3 | +66.8 | 21.7 | 1102.7 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 3.7 | -24.4 | 0.0 | 0.0 | 5.0 | -44.9 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.7 | +0.0 | 37.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 3.0 | -106.8 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 17.3 | +978.5 | 0.0 | 0.0 | 2.3 | +929.8 | 0.0 | 0.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.3 | +4.7 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.7 | +43.8 | 0.0 | 43.3 | 0.7 | +31.0 | 0.0 | 13.7 |
| REDIRECT FOR A FRIEND IN REACH | 0.3 | +0.0 | 0.0 | 21.7 | 0.7 | +0.0 | 0.0 | 20.0 |
| REFORMS TO MEET IT | 3.0 | -27.1 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | 0.3 | +43.3 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | - | - | - | - | 0.7 | +58.1 | 53.3 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.7 | -4.1 | 31.7 | 16.7 |
| RUN DOWN | - | - | - | - | 1.3 | -5.1 | 21.7 | 0.0 |
| SAME CHARGE LATER | 0.3 | -6.6 | 37.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.3 | -49.7 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +14.2 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.3 | -0.7 | 0.0 | 0.0 | 4.7 | -245.0 | 0.0 | 144.7 |
| SET UP BY THE SET | 2.0 | -0.2 | 144.7 | 0.0 | 5.3 | +322.9 | 0.0 | 144.7 |
| SHOOTERS IN TWO RANKS | 2.0 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 31.3 | +0.0 | 0.0 | 95.0 | 4.0 | +0.0 | 0.0 | 165.0 |
| SHOOTS FROM THE BEST SPOT | 5.0 | +185.7 | 37.0 | 0.0 | 0.7 | +1.3 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -13.3 | 0.0 | 55.0 |
| SHOT RISK POINTS | 23.0 | +750.4 | 0.0 | 240.0 | 26.0 | -670.9 | 0.0 | 633.3 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 39.3 | +1383.6 | 0.0 | 83.3 | 2.7 | +132.2 | 0.0 | 202.0 |
| SPELL WORTH | - | - | - | - | 5.3 | +116.2 | 156.7 | 156.7 |
| SPOT AS THE GAME MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 146.3 |
| STAND AND SHOOT | - | - | - | - | 0.7 | -8.7 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 108.0 | +0.0 | 4785.0 | 456.7 | 12.3 | +0.0 | 0.0 | 622.7 |
| STAY WORTH | 73.3 | +225.9 | 3604.0 | 198.3 | 8.3 | +74.0 | 0.0 | 330.0 |
| SUPPORT ADDS | 2.0 | +102.4 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 2.0 | +102.4 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.0 | +0.0 | 0.0 | 21.7 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 58.7 | +0.0 | 0.0 | 178.3 | 29.3 | +0.0 | 0.0 | 661.3 |
| TIED UP BY THE SUM | - | - | - | - | 0.3 | +22.0 | 31.7 | 0.0 |
| TIME ON OUR SIDE | 55.0 | +624.3 | 107.3 | 126.7 | - | - | - | - |
| WAITS AGAIN | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WALKS ON ITS ROUTE | 0.3 | -14.5 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | - | - | - | - | 1.0 | +6.6 | 53.3 | 0.0 |
| WHOLE FIGHT DANGER | 2.0 | -78.4 | 0.0 | 63.3 | 3.7 | -295.2 | 0.0 | 375.3 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.7 | +129.4 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 2.7 | +21.1 | 0.0 | 0.0 | 6.7 | +547.3 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 224 | 222 | 73 | 24.33 | +1518 | +20.8 |
| HIS SHOTS BY HIS RUN | 199 | 194 | 52 | 17.33 | +445 | +8.6 |
| HOLDER ASSIGNMENT | 55 | 55 | 51 | 17.00 | +3742 | +73.4 |
| ARMY TABLE | 42 | 42 | 33 | 11.00 | +595 | +18.0 |
| DEPLOY BY FIGURES | 53 | 53 | 32 | 10.67 | +329 | +10.3 |
| OFF BEST | 30 | 30 | 30 | 10.00 | -861 | -28.7 |
| TIME ON OUR SIDE | 165 | 156 | 26 | 8.67 | +74 | +2.8 |
| FIVE ACTION | 593 | 586 | 22 | 7.33 | +296 | +13.4 |
| SHOT RISK POINTS | 147 | 144 | 22 | 7.33 | +783 | +35.6 |
| MOVE TO CHARGE COMPUTED | 22 | 19 | 17 | 5.67 | +146 | +8.6 |
| SHOOTS FROM THE BEST SPOT | 17 | 17 | 17 | 5.67 | +204 | +12.0 |
| HARD STAY DROPPED | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| MEETS IN TIME | 35 | 35 | 14 | 4.67 | +462 | +33.0 |
| COVER ONCE | 41 | 39 | 13 | 4.33 | +58 | +4.4 |
| CHARGE LOSSES | 99 | 98 | 12 | 4.00 | +438 | +36.5 |
| NEXT CHARGE BY LIST | 13 | 13 | 11 | 3.67 | +136 | +12.4 |
| THE TABLE AGAIN | 36 | 36 | 11 | 3.67 | +0 | +0.0 |
| CANNON SIGHT KEPT | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| IDLE COST | 41 | 33 | 10 | 3.33 | +349 | +34.9 |
| ARTILLERY RE-ROLL WEIGHED | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| GOAL WALK | 17 | 17 | 9 | 3.00 | +868 | +96.4 |
| MODEL FACING | 9 | 9 | 9 | 3.00 | +3869 | +429.9 |
| CANNON PLANNED TARGET | 66 | 66 | 7 | 2.33 | -8 | -1.2 |
| PROMISE BY ITS OWN SUM | 26 | 26 | 7 | 2.33 | -208 | -29.7 |
| SET UP BY THE SET | 22 | 22 | 7 | 2.33 | +188 | +26.9 |
| WOUNDS ON THE RANKS | 28 | 28 | 7 | 2.33 | +74 | +10.6 |
| OGRE LOADER SECOND SHOT | 6 | 6 | 6 | 2.00 | +26 | +4.3 |
| SHOOTERS IN TWO RANKS | 6 | 6 | 6 | 2.00 | +12 | +2.0 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 24 | 24 | 6 | 2.00 | +0 | +0.0 |
| SHOTS IN THE MOVE | 126 | 108 | 6 | 2.00 | +149 | +24.9 |
| STAY WORTH | 245 | 230 | 6 | 2.00 | +66 | +10.9 |
| FALLS SHORT | 63 | 57 | 4 | 1.33 | +70 | +17.4 |
| GUN MASK | 8 | 8 | 4 | 1.33 | +141 | +35.2 |
| PROMISE READS THE TABLE | 9 | 9 | 4 | 1.33 | -23 | -5.8 |
| QUARTER ODDS | 59 | 59 | 4 | 1.33 | +205 | +51.2 |
| SUPPORT ADDS | 6 | 4 | 4 | 1.33 | +143 | +35.8 |
| SUPPORT WORKED OUT | 6 | 4 | 4 | 1.33 | +143 | +35.8 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CAST JOB | 8 | 8 | 3 | 1.00 | +2 | +0.7 |
| HUNT IN PAIRS | 10 | 9 | 3 | 1.00 | +243 | +81.1 |
| REDIRECT FOR A FRIEND IN REACH | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +10 | +5.1 |
| FOUR ROUNDS | 6 | 6 | 2 | 0.67 | +102 | +51.2 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | -116 | -57.9 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +128 | +64.0 |
| LEGAL CHARGES ONLY | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MARCH CHECK | 3 | 3 | 2 | 0.67 | +36 | +17.8 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +12 | +5.8 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.67 | -64 | -32.0 |
| RISK BY ARC | 2 | 2 | 2 | 0.67 | +110 | +55.1 |
| WHOLE FIGHT GAIN | 2 | 2 | 2 | 0.67 | +158 | +79.2 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 3 | 3 | 1 | 0.33 | -14 | -13.9 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS TURN DENIED | 3 | 3 | 1 | 0.33 | +78 | +78.1 |
| MAX FOR POSITIONING | 8 | 6 | 1 | 0.33 | +18 | +17.7 |
| MOVE ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| NEARER NOT NEEDED | 36 | 33 | 1 | 0.33 | +23 | +23.2 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.33 | +28 | +28.2 |
| ONE JOINT FIGURE | 2 | 2 | 1 | 0.33 | +38 | +37.9 |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +130 | +130.1 |
| SAME CHARGE LATER | 1 | 1 | 1 | 0.33 | +4 | +4.1 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +42 | +42.5 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -44 | -43.5 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 3 | 3 | 0 | 0.00 | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAFF IN THE MOVE | 3 | 3 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 14 | 14 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 51 | 51 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| EXACT ROUND | 3 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 4 | 4 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 17 | not checked | - | - | - | - |
| FOOT FIRST | 41 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 16 | 16 | 0 | 0.00 | - | - |
| GUN FIGURES | 4 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 43 | 42 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 56 | 56 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 21 | 21 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 22 | 22 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 4 | 4 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 34 | 33 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 68 | 68 | 0 | 0.00 | - | - |
| HONEST WORTH | 5 | 5 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 6 | 6 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 3 | 3 | 0 | 0.00 | - | - |
| MANOEUVRE | 15 | 15 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 16 | 12 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 25 | 18 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 3 | 3 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 6 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 18 | 17 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 25 | 22 | 0 | 0.00 | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 264 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 9 | 8 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 1 | 1 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 15 | 15 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 106 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 16 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 27 | 20 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 6 | 6 | 0 | 0.00 | - | - |
| STANDS STILL | 361 | 357 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 6 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 10 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 16 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 8 | not checked | - | - | - | - |
| THE TABLE BINDS | 264 | not checked | - | - | - | - |
| TIED UP BY THE SUM | 1 | 1 | 0 | 0.00 | - | - |
| WAITS AGAIN | 8 | 8 | 0 | 0.00 | - | - |
| WHO FIGHTS | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 17 | 17 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.33 | 4.33 | 29.5 |
| PROMISE BY ITS OWN SUM | rule | 1.67 | 0.67 | 29.7 |
| HOLDER ASSIGNMENT | rule | 0.67 | 0.67 | 9.8 |
| JOINT CHARGE NOW | rule | - | 0.67 | 57.9 |
| PIVOT GUARDS FLANK | rule | - | 0.67 | 32.0 |
| PROMISE READS THE TABLE | rule | 0.67 | - | 25.8 |
| ARMY TABLE | rule | - | 0.33 | 8.9 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 8.5 |
| CHARGE NOW FIRST | rule | - | 0.33 | 13.9 |
| DEPLOY BY FIGURES | rule | 0.33 | - | 6.9 |
| RULE SWITCHED OFF | gate | 0.33 | - | 6.0 |
| WALKS ON ITS ROUTE | rule | 0.33 | - | 43.5 |

### Plans: gs3-83c8646-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | join | 1.3 | 100% | 46 | 0 | 0% |
| Mine | move | 32.0 | 96% | 898 | 0 | 0% |
| Mine | shoot | 26.3 | 66% | 1095 | 2141 | 195% |
| Opponent | charge | 1.0 | 33% | 82 | 32 | 39% |
| Opponent | join | 1.0 | 100% | 54 | 0 | 0% |
| Opponent | move | 22.7 | 90% | 686 | 0 | 0% |
| Opponent | shoot | 3.3 | 40% | 231 | 35 | 15% |
| Opponent | support | 0.3 | 100% | 15 | 0 | 0% |

### Battle groups: gs3-83c8646-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.7 | 100% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 0.7 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Character | 13 | 17 (13) | 17 | 0 | 0 | 23% | 3.1 | 31 (6) | 0 (6) | 0 (1) | 19 (11) | 0 (2) |
| Mine | Clean-up | 4 | 0 (4) | 0 | 0 | 0 | 75% | 1.0 | 0 (1) | 0 (1) | 0 (2) | 0 (4) | - |
| Mine | Fast | 3 | 0 (3) | 0 | 0 | 27 | 33% | 1.0 | - | 0 (1) | 0 (2) | 0 (3) | - |
| Mine | Hammer | 4 | 88 (4) | 2 | 87 | 0 | 50% | 2.0 | 4 (1) | 147 (3) | - | 88 (4) | - |
| Mine | Shooter | 8 | 84 (8) | 3 | 80 | 0 | 0% | 2.4 | 164 (1) | 118 (4) | 9 (3) | 78 (6) | 98 (2) |
| Mine | War machine | 17 | 69 (17) | 69 | 0 | 18 | 12% | 1.6 | 0 (4) | 62 (9) | 155 (4) | 31 (3) | 79 (14) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 63 | 100% | - | 0 (2) | - | 0 (1) | 0 (3) | - |
| Opponent | Character | 10 | 0 (10) | 0 | 0 | 46 | 60% | 3.0 | 0 (3) | 0 (5) | 0 (2) | 0 (9) | 0 (1) |
| Opponent | Clean-up | 1 | 99 (1) | 99 | 0 | 100 | 100% | - | - | 99 (1) | - | 99 (1) | - |
| Opponent | Fast Hammer | 3 | 23 (3) | 0 | 23 | 0 | 100% | - | 0 (1) | 76 (1) | 0 (1) | 32 (2) | 0 (1) |
| Opponent | Holder | 6 | 94 (6) | 6 | 88 | 10 | 50% | 2.0 | 35 (1) | 129 (4) | - | 149 (4) | 0 (1) |
| Opponent | War machine | 2 | 36 (2) | 36 | 0 | 100 | 0% | 1.0 | - | 73 (1) | 0 (1) | - | 36 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 2.0 | 0 (1) | 0 (1) | - | 0 (2) | - |

### Charged fights: gs3-83c8646-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 3 | 480 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 180 | 0 | 2.0 | 1.5 | 0 | 0 | +0 | 1 of 2 | 1 of 2 | +0 | +0 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 50 | -50 | 1 of 1 | 0 of 1 | - | -50 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 60 | 0 | 1.0 | 1.3 | 0 | 17 | -17 | 2 of 3 | 1 of 3 | +0 | -25 |

### Effective charges: gs3-83c8646-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Grand Cathay | 2 | 0 | 0 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 50% (1 of 2) |

### Charged fights, damage counted: gs3-83c8646-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Effective (55-75%) | 1 | 173 | 105 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 539 | 183 | +0 | 13 | 34 | -21 | -3.9 |
| Opponent | No odds | 1 | 50 | 239 | -50 | 0 | 50 | -50 | -100.0 |
| Opponent | All fights | 3 | 254 | 176 | -17 | 4 | 28 | -24 | -9.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p4 | move | 13 | 0 (0%) | 0 (0%) | 1 (8%) | 12 (92%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0524 |
| Clockwork Compass | Opponent | L0612 |
| Invocation of Nehek | Opponent | L0524 |
| Ring of Doom | Opponent | L0612 |
| Ring of Jet | Opponent | L0612 |

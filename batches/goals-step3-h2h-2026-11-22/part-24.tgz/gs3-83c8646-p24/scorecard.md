# Doctrine scorecard: gs3-83c8646-p24

### Scorecard: gs3-83c8646-p24

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2535 | 3 | 1 | Mine | no | 0 | 4 | 2 | 3 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 1 | 3 | 1 | 3 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | yes | - | - | 1 | 5 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 2 | 3 | 5 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 6 | 4 | 2 | 3 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 5 | 2 | 2 | 3 | 0 | 0 | 0 | 19 |
| **Average** | | | Mine | 67% | 3.0 | 4.0 | 1.7 | 3.7 | 0.0 | 0.0 | 0.0 | 0.0 |
| **Average** | | | Opponent | 33% | 3.0 | 2.3 | 2.0 | 3.7 | 0.0 | 0.0 | 0.0 | 6.3 |

### KPIs: gs3-83c8646-p24

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 15) | 38% (6 of 16) | 19% (6 of 31) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | 100% (5 of 5); on the table 100% | 100% (7 of 7); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 50% (2 of 4); on the table 100% | - | 50% (2 of 4); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 67% (4 of 6); on the table 100% | 100% (6 of 6); on the table 100% | 83% (10 of 12); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 50% (12 of 24) | 39% (7 of 18) | 45% (19 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 50% (12 of 24) | 41% (7 of 17) | 46% (19 of 41) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 61% (3669 of 5999) | 46% (2747 of 6000) | 53% (6416 of 11999) |
|   infantry points that never fought | lower | 50% (390 of 780) | 68% (1304 of 1918) | 63% (1694 of 2698) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 78% (14 of 18) | 76% (26 of 34) | 77% (40 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 50% (2 of 4); 2.0 uses a game | 50% (2 of 4); 1.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 78% (3755 of 4808) | 71% (4208 of 5962) | 74% (7963 of 10770) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.0 (75%) | 2.0 (55%) | 5.0 (65%) |
| MARCHED: its unit marched | 0.7 (17%) | 1.0 (27%) | 1.7 (22%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.3 (9%) | 0.3 (4%) |
| STUPIDITY: Stupidity | 0.3 (8%) | 0.0 (0%) | 0.3 (4%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (9%) | 0.3 (4%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 2.0 | 4.3 | 6.3 | 2.3 | 0.3 |
| not cast | 3.7 | 0.7 | 1.7 | 7.7 | 3.7 | 23.7 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (50%) | 0.0 (0%) | 5.0 (65%) | 2.7 (73%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (22%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.3 (9%) | 0.3 (50%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.3 (1%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 1.0 (27%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.3 (91%) | 0.0 (0%) | 1.7 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 22.7 (96%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.7 a game | 3.7 a game | 2.2 a game |
| stood (cast and not dispelled) | 50% (1 of 2) | 45% (5 of 11) | 46% (6 of 13) |
| the unit moved after it | 100% (1 of 1) | 40% (2 of 5) | 50% (3 of 6) |
| it charged on its next turn | 0% (0 of 1) | 0% (0 of 5) | 0% (0 of 6) |
| the enemy charged it first | 0% (0 of 1) | 20% (1 of 5) | 17% (1 of 6) |
| it fought by the end of its next turn | 0% (0 of 1) | 0% (0 of 5) | 0% (0 of 6) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 1) | 0% (0 of 5) | 0% (0 of 6) |
| none of these (no charge, no fight, no charge escaped) | 100% (1 of 1) | 80% (4 of 5) | 83% (5 of 6) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 0% (0 of 2) | 65% (61 of 94) | 64% (61 of 96) |
|   cavalry | - | 68% (28 of 41) | 68% (28 of 41) |
|   character | 0% (0 of 2) | 54% (7 of 13) | 47% (7 of 15) |
|   infantry | - | 65% (26 of 40) | 65% (26 of 40) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.0 (0%) | 5.0 (45%) | 5.0 (43%) |
| CHARGED: it charged | 0.0 (0%) | 2.7 (24%) | 2.7 (23%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 1.3 (12%) | 1.3 (11%) |
| NO TARGET IN RANGE | 0.3 (50%) | 0.7 (6%) | 1.0 (9%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (50%) | 0.0 (0%) | 0.3 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 1.3 (12%) | 1.3 (11%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 12.3 | 1.3 | 95% | 0.8 pts | 9 pts |
| character | 3.0 | 0.7 | 78% | 3.1 pts | 9 pts |
| infantry | 11.0 | 3.7 | 73% | 15.4 pts | 170 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 3.0 | 3.3 |
| Charges that made contact a game | 3.7 | 1.7 | 2.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (4 units) | - | 0.00 declared, 0.00 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.50 declared, 0.50 contact (2 units) | - | 0.50 declared, 0.50 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.45 declared, 0.45 contact (22 units) | 0.29 declared, 0.16 contact (31 units) | 0.36 declared, 0.28 contact (53 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 73% (8 of 11) | 50% (1 of 2) | 100% (1 of 1) | 71% (10 of 14) |
| Character in a unit | 100% (4 of 4) | 100% (5 of 5) | 0% (0 of 1) | 90% (9 of 10) |
| Character on its own | 100% (1 of 1) | 100% (1 of 1) | 60% (3 of 5) | 71% (5 of 7) |
| Infantry | 67% (8 of 12) | 67% (2 of 3) | - | 67% (10 of 15) |
| Monster | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Monstrous | 100% (5 of 5) | - | - | 100% (5 of 5) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vampire Counts | 2 | 67% (4 of 6); on the table 100% | 50% (12 of 24) | 67% | 83% (10 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | - | - | 50% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Wood Elf Realms | 3 | 100% (6 of 6); on the table 100% | 39% (7 of 18) | 46% | 76% (26 of 34) | 50% (2 of 4); 2.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p24, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 0% (0) | 0% (0) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.67 | 0.00 | 0.67 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: gs3-83c8646-p24

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 0.7 |
| Strategy | Charge objectives carried out (made contact) | 90% (9 of 10) | 50% (3 of 6) |
| Strategy | Shoot objectives carried out (shot that target) | 0% (0 of 3) | 57% (4 of 7) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | - |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 100% (2 of 2) |
| Strategy | Joined characters whose unit fought | 17% (1 of 6) | 60% (3 of 5) |
| Strategy | Lone characters that fought | 38% (3 of 8) | 100% (3 of 3) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 3.7 | 3.7 |
| Movement | Points that never moved of their own | 0.0 | 6.3 |
| Movement | Fights charged into per game | 3.3 | 1.7 |
| Movement | Charges with odds: long shots (under 50%) | 4 of 9, net -84 | 1 of 3, net -599 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 9 | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 9 | 0 of 3 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 9, net +85 | 1 of 3, net +186 |
| Shooting | Shots by shooting units (incl. breath weapons) | 1.3 | 21.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 4) | 68% (43 of 63) |
| Shooting | Points destroyed by shooting units | 0.0 | 32.7 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 2.3 | 2.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 43% (3 of 7) | 83% (5 of 6) |
| Magic | Wounds caused by magic missiles | - | 5.3 |
| Magic | Wounds caused by other spells | - | 0.7 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.0 / 0.7 / 0.0 / 0.3 | 2.0 / 0.7 / 0.3 / 1.0 |
| Combat | Points destroyed in combat | 72.7 | 213.7 |
| Combat | Points run down | 246.3 | 0.0 |
| Combat | Net points per charged fight, damage counted | +44 | -67 |
| Combat | Net per 100 charger points, damage counted | +24.5 | -24.6 |
| Combat | First round won (charged fights) | 40% | 80% |
| Combat | Net points per charged fight | +48 | -79 |
| Combat | Net points per supported fight / lone fight | +432 / +5 | - / -79 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 10 | 1 of 5 |
| Game | Points lost | 305.7 | 471.7 |
| Game | VP from objectives | 583.3 | 760.0 |
| Game | Lone holders (player turns) | 3.0 | 3.0 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) +23 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 777
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p24

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 31.7 | +590.4 | 0.0 | 293.0 | 48.3 | +294.6 | 0.0 | 194.0 |
| ASSAILMENT BY POINTS | - | - | - | - | 0.3 | +7.8 | 0.0 | 91.3 |
| BACKUP TARGETS | 0.7 | +2.4 | 0.0 | 0.0 | 0.7 | +1.5 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.3 | +10.1 | 0.0 | 95.0 | - | - | - | - |
| CARRIES OUT SET-UP | - | - | - | - | 0.3 | +0.0 | 32.7 | 0.0 |
| CAST JOB | 2.7 | +10.5 | 140.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 6.3 | +185.0 | 0.0 | 15.0 | 0.7 | +52.3 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 1.3 | -0.4 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.7 | +0.5 | 0.0 | 0.0 |
| CHARACTER GUNS | - | - | - | - | 4.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 24.7 | -810.8 | 0.0 | 320.7 | 9.3 | -331.1 | 0.0 | 135.3 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 126.7 | 95.0 | 1.7 | +0.0 | 72.7 | 199.7 |
| CLOSES ON WHAT IT BEATS | 15.0 | +0.0 | 0.0 | 40.0 | 5.7 | +0.0 | 0.0 | 42.0 |
| CONVEYANCE SEARCH | 0.7 | +6.7 | 0.0 | 0.0 | 2.3 | +202.6 | 0.0 | 0.0 |
| COVER ONCE | 10.0 | -710.7 | 0.0 | 206.3 | 17.3 | -658.2 | 0.0 | 176.0 |
| DENIED BY THE FIGHT | 1.0 | -15.0 | 137.3 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 7.0 | +35.9 | 0.0 | 0.0 | 10.0 | -110.5 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -45.8 | 0.0 | 199.7 |
| EXACT ROUND | 2.7 | +13.1 | 232.0 | 95.0 | 1.7 | +17.3 | 102.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.0 | +7.9 | 137.3 | 16.7 | 1.7 | +0.0 | 57.7 | 199.7 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 26.0 | +321.8 | 0.0 | 157.0 | - | - | - | - |
| FEATURE BUFFS | 1.3 | +15.6 | 0.0 | 0.0 | 2.7 | +24.9 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +12.8 | 46.7 | 0.0 | 0.7 | +13.1 | 25.0 | 0.0 |
| FIVE ACTION | 91.7 | +5781.6 | 372.0 | 912.0 | 103.0 | +8486.7 | 372.3 | 586.3 |
| FLANK NOT WEIGHED | 10.0 | +0.0 | 0.0 | 182.0 | 9.3 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.7 | +82.8 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FOOT FIRST | - | - | - | - | 26.0 | +0.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 3.3 | +344.7 | 232.0 | 111.7 | 2.7 | +336.1 | 149.7 | 199.7 |
| FREED FROM HIS FIGHT | 1.0 | +0.0 | 0.0 | 94.7 | 2.3 | +0.0 | 0.0 | 84.0 |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.3 | -1.5 | 0.0 | 0.0 |
| GOAL WALK | 5.0 | +309.9 | 0.0 | 0.0 | 25.7 | +1900.6 | 0.0 | 84.0 |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 62.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 15.7 | +0.0 | 0.0 | 225.7 | 8.0 | +0.0 | 0.0 | 135.3 |
| HIS CHARGE DENIED | 0.3 | +10.0 | 0.0 | 16.7 | 0.7 | +1.0 | 30.0 | 0.0 |
| HIS CHARGE LIST | 7.7 | +0.0 | 0.0 | 157.0 | 19.0 | +0.0 | 0.0 | 198.7 |
| HIS LEGAL MOVES | 6.7 | +0.0 | 0.0 | 0.0 | 10.3 | +0.0 | 0.0 | 224.0 |
| HIS MOVE AND SHOT | 10.0 | -89.9 | 0.0 | 157.7 | 2.3 | -34.6 | 0.0 | 93.3 |
| HIS ONE QUARTER | 10.0 | +0.0 | 0.0 | 124.0 | 9.0 | +0.0 | 0.0 | 52.7 |
| HIS OWN BEST MOVE | 14.0 | +0.0 | 0.0 | 0.0 | 11.7 | +0.0 | 0.0 | 293.3 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 73.0 | +1947.6 | 0.0 | 646.3 | 32.0 | +124.1 | 0.0 | 147.3 |
| HIS SHOTS BY HIS RUN | 67.0 | +890.7 | 0.0 | 705.0 | 24.3 | +244.8 | 0.0 | 198.7 |
| HIS TURN DENIED | 1.7 | +71.6 | 232.0 | 0.0 | - | - | - | - |
| HOLD ODDS | 15.3 | +0.0 | 0.0 | 65.3 | 18.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 9.0 | +642.3 | 0.0 | 32.7 | 11.7 | +845.9 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HONEST WORTH | 2.7 | -73.9 | 232.0 | 0.0 | 2.7 | -142.0 | 149.7 | 199.7 |
| HORN WORTH | - | - | - | - | 0.3 | +5.4 | 0.0 | 0.0 |
| IDLE COST | 21.0 | -249.8 | 0.0 | 144.3 | - | - | - | - |
| JOINT CHARGE NOW | 0.7 | +45.9 | 105.3 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 0.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +4.5 | 0.0 | 0.0 | 0.7 | +50.8 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.3 | +0.0 | 72.7 | 0.0 | 14.0 | +0.0 | 513.3 | 271.3 |
| LOST AFTER ESCAPE | 2.7 | +15.1 | 232.0 | 0.0 | 1.7 | +0.1 | 119.7 | 199.7 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.7 | -29.8 | 0.0 | 0.0 |
| MANOEUVRE | 2.7 | +4.3 | 0.0 | 0.0 | 0.3 | +14.7 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +1.3 | 0.0 | 0.0 | 1.0 | +60.0 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 2.0 | +83.4 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.7 | +29.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | -51.5 | 0.0 | 0.0 | 1.7 | +266.9 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.7 | +30.2 | 0.0 | 87.0 | 3.0 | +69.0 | 0.0 | 0.0 |
| MEETS IN TIME | 4.0 | +174.0 | 0.0 | 0.0 | 5.7 | +191.1 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.7 | +17.1 | 0.0 | 0.0 | 5.3 | +163.1 | 0.0 | 52.7 |
| MISSILES NEXT TURN | 6.0 | +14.6 | 0.0 | 0.0 | 6.7 | +140.7 | 0.0 | 52.7 |
| MOVE ORDER | 3.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 34.7 | 42.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 2.3 | -95.5 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 13.0 | +1662.6 | 0.0 | 62.0 | 4.3 | +258.9 | 0.0 | 69.3 |
| NEARER NOT NEEDED | 9.3 | +361.9 | 0.0 | 32.7 | 8.7 | +452.8 | 0.0 | 46.7 |
| NEAREST TO GOAL | - | - | - | - | 3.7 | +0.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 9.7 | +1155.6 | 0.0 | 62.0 | 1.7 | +184.3 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 3.0 | -236.7 | 232.0 | 95.0 | 2.0 | -77.6 | 134.7 | 0.0 |
| NO LATE CUT | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT WORTH A CAST | - | - | - | - | 1.7 | -3.3 | 0.0 | 0.0 |
| OFF BEST | 6.3 | -237.5 | 0.0 | 156.7 | 7.0 | -211.7 | 15.0 | 42.0 |
| ONE CHECK AFTER THE LAST CHANGE | 1.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.7 | -125.0 | 0.0 | 25.0 | 6.3 | -106.2 | 0.0 | 87.3 |
| ONE OBJECTIVE FORMULA | 4.7 | -97.0 | 0.0 | 32.7 | 4.7 | +115.9 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 1.0 | -11.8 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +5.4 | 15.0 | 0.0 |
| OVERRUNS AWAY | 1.0 | +7.6 | 84.7 | 0.0 | 0.3 | +0.5 | 15.0 | 0.0 |
| PATHS CROSS | 2.0 | +4.5 | 0.0 | 0.0 | 0.7 | +40.7 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -18.0 | 0.0 | 0.0 | 0.3 | -11.8 | 0.0 | 0.0 |
| PLAN RESULT | 48.3 | +168.5 | 38.0 | 611.3 | 46.3 | +178.6 | 95.0 | 754.7 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 13.3 | -603.1 | 0.0 | 62.0 | 9.3 | -222.7 | 0.0 | 111.3 |
| PROMISE KNOWS THE FIGHT | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | -4.7 | 0.0 | 0.0 |
| QUARTER ODDS | 25.3 | +2876.7 | 239.3 | 264.7 | 28.7 | +3293.0 | 127.3 | 105.3 |
| REAL GROUND | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 2.0 | +33.1 | 0.0 | 0.0 |
| REDIRECT COUNTER | 4.3 | +458.8 | 0.0 | 80.0 | 1.0 | +65.6 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 5.0 | +0.0 | 0.0 | 15.0 | 2.7 | +120.9 | 0.0 | 0.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.3 | -91.8 | 0.0 | 0.0 | 1.0 | -14.5 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +8.0 | 0.0 | 0.0 | 1.0 | +232.9 | 0.0 | 0.0 |
| RISK BY ARC | 2.7 | +4.3 | 232.0 | 111.7 | 1.3 | +32.6 | 40.0 | 199.7 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 1.0 | -28.0 | 132.7 | 0.0 | 0.3 | -12.5 | 32.7 | 0.0 |
| RUN DOWN | 2.7 | -53.4 | 232.0 | 0.0 | 0.3 | -2.4 | 32.7 | 0.0 |
| SAFER THAN THE JOB | 0.7 | +16.4 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | 3.0 | +5.8 | 0.0 | 15.0 | - | - | - | - |
| SEARCH SPOT | 1.3 | +40.6 | 0.0 | 0.0 | 0.7 | +59.6 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.7 | +22.3 | 40.0 | 0.0 |
| SET CREDITED ONCE | 2.3 | -60.4 | 0.0 | 30.0 | 0.3 | -9.3 | 0.0 | 0.0 |
| SET UP BY THE SET | 4.7 | +150.7 | 0.0 | 62.7 | 0.3 | +0.4 | 0.0 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.7 | +68.6 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.3 | +53.6 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.7 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +0.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 3.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 1.0 | +59.4 | 32.7 | 0.0 |
| SHOT OR CHARGE | 0.3 | -0.2 | 46.7 | 0.0 | 0.3 | -7.7 | 0.0 | 0.0 |
| SHOT RISK POINTS | 58.0 | -451.8 | 0.0 | 469.0 | 3.7 | -44.0 | 0.0 | 93.3 |
| SHOTS AFTER THE MOVES | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 0.7 | +20.5 | 0.0 | 0.0 | 19.3 | +324.4 | 0.0 | 141.3 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.7 | +68.6 | 0.0 | 0.0 |
| SPELL WORTH | 2.0 | +2.9 | 0.0 | 0.0 | 2.0 | +6.4 | 91.3 | 91.3 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | -2.0 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 13.7 | +0.0 | 0.0 | 252.0 | 8.0 | +0.0 | 0.0 | 76.7 |
| STAND AND SHOOT | 0.3 | -1.4 | 0.0 | 16.7 | - | - | - | - |
| STANDS STILL | 18.0 | +0.0 | 140.0 | 62.0 | 33.3 | +0.0 | 222.7 | 0.0 |
| STAY WORTH | 1.3 | +1.9 | 140.0 | 0.0 | 16.0 | +102.4 | 190.0 | 46.7 |
| STRIKE BY THE ODDS | 0.3 | +1.6 | 52.7 | 0.0 | - | - | - | - |
| STUPIDITY NEXT TURN | 4.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 6.3 | +299.4 | 0.0 | 121.3 | 4.0 | +275.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 6.3 | +299.4 | 0.0 | 121.3 | 4.0 | +275.0 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | -0.9 | 0.0 | 42.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.3 | +0.0 | 95.0 | 0.0 | 6.0 | +0.0 | 0.0 | 34.7 |
| THE ROW KEEPS ITS WAY | 6.3 | +0.0 | 0.0 | 119.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 4.0 | +0.0 | 0.0 | 94.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 50.7 | +0.0 | 0.0 | 392.7 | 51.0 | +0.0 | 0.0 | 176.0 |
| TIED UP BY THE SUM | 0.3 | +34.3 | 38.0 | 0.0 | 1.0 | +126.5 | 47.7 | 0.0 |
| TIME ON OUR SIDE | - | - | - | - | 50.3 | +570.2 | 0.0 | 123.3 |
| WAITS AGAIN | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -4.0 | 0.0 | 0.0 |
| WHO FIGHTS | - | - | - | - | 0.7 | -2.6 | 77.0 | 0.0 |
| WHO HITS BACK | 0.3 | +10.1 | 0.0 | 0.0 | 0.3 | +30.8 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 3.0 | -202.2 | 0.0 | 130.7 | 4.3 | -232.7 | 0.0 | 42.0 |
| WOUNDS ON THE RANKS | 6.0 | +65.5 | 0.0 | 0.0 | 0.7 | +9.5 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p24

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 240 | 240 | 144 | 48.00 | +2365 | +16.4 |
| HOLDER ASSIGNMENT | 62 | 62 | 55 | 18.33 | +3007 | +54.7 |
| LEGAL CHARGES ONLY | 49 | 49 | 49 | 16.33 | +0 | +0.0 |
| OFF BEST | 40 | 40 | 40 | 13.33 | -1347 | -33.7 |
| FIVE ACTION | 584 | 557 | 36 | 12.00 | +2882 | +80.1 |
| QUARTER ODDS | 162 | 150 | 36 | 12.00 | +3258 | +90.5 |
| DEPLOY BY FIGURES | 51 | 51 | 35 | 11.67 | +412 | +11.8 |
| HIS SHOT LIST | 315 | 302 | 34 | 11.33 | +500 | +14.7 |
| HIS SHOTS BY HIS RUN | 274 | 257 | 30 | 10.00 | +418 | +13.9 |
| MOVE TO CHARGE COMPUTED | 52 | 44 | 27 | 9.00 | +2336 | +86.5 |
| MOVE ORDER | 23 | 23 | 23 | 7.67 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 68 | 68 | 22 | 7.33 | -2477 | -112.6 |
| GOAL WALK | 92 | 91 | 21 | 7.00 | +1142 | +54.4 |
| NEXT CHARGE BY LIST | 34 | 34 | 21 | 7.00 | +1747 | +83.2 |
| REDIRECT FOR A FRIEND IN REACH | 23 | 23 | 21 | 7.00 | +14 | +0.6 |
| THE TABLE AGAIN | 36 | 36 | 17 | 5.67 | +0 | +0.0 |
| SHOT RISK POINTS | 185 | 174 | 15 | 5.00 | +406 | +27.1 |
| TIME ON OUR SIDE | 151 | 120 | 13 | 4.33 | +69 | +5.3 |
| FOUR ROUNDS | 18 | 16 | 12 | 4.00 | +621 | +51.7 |
| ADVANCE LANE KEPT | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| IDLE COST | 63 | 47 | 11 | 3.67 | +57 | +5.2 |
| COVER ONCE | 82 | 55 | 10 | 3.33 | +186 | +18.6 |
| HARD STAY DROPPED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 21 | 18 | 9 | 3.00 | +26 | +2.9 |
| MEETS IN TIME | 29 | 29 | 9 | 3.00 | +409 | +45.5 |
| PATHS CROSS | 8 | 8 | 8 | 2.67 | +135 | +16.9 |
| SET UP BY THE SET | 15 | 15 | 8 | 2.67 | +609 | +76.1 |
| CHARGE LOSSES | 102 | 95 | 7 | 2.33 | +997 | +142.5 |
| SUPPORT ADDS | 31 | 27 | 7 | 2.33 | +66 | +9.4 |
| SUPPORT WORKED OUT | 31 | 27 | 7 | 2.33 | +66 | +9.4 |
| WHOLE FIGHT DANGER | 22 | 21 | 6 | 2.00 | +149 | +24.8 |
| CAST JOB | 8 | 8 | 5 | 1.67 | +3 | +0.5 |
| SEARCH SPOT | 6 | 6 | 5 | 1.67 | +301 | +60.1 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHAFF PASSED | 4 | 4 | 4 | 1.33 | -1 | -0.3 |
| MARCH BY THE SUM | 4 | 4 | 4 | 1.33 | +184 | +46.0 |
| NEARER NOT NEEDED | 54 | 53 | 4 | 1.33 | +158 | +39.6 |
| REDIRECT COUNTER | 16 | 15 | 4 | 1.33 | +206 | +51.6 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +723 | +180.7 |
| SCREEN BY WHAT IT SAVES | 9 | 9 | 4 | 1.33 | +19 | +4.6 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +248 | +82.8 |
| LANE BY FIGURES | 3 | 3 | 3 | 1.00 | +166 | +55.2 |
| MANOEUVRE | 9 | 9 | 3 | 1.00 | +57 | +19.0 |
| ONE PROMISE A TARGET | 3 | 3 | 3 | 1.00 | -36 | -11.8 |
| RISK BY ARC | 12 | 11 | 3 | 1.00 | +94 | +31.4 |
| SHOOTS FROM THE BEST SPOT | 3 | 3 | 3 | 1.00 | +46 | +15.3 |
| STAY WORTH | 52 | 43 | 3 | 1.00 | +17 | +5.7 |
| THE ROW IN ITS ORDER | 28 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +2 | +0.8 |
| CHARGE NOW FIRST | 9 | 9 | 2 | 0.67 | -419 | -209.6 |
| FALLS SHORT | 78 | 67 | 2 | 0.67 | +29 | +14.6 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +138 | +68.8 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -89 | -44.6 |
| MAX FOR POSITIONING | 17 | 15 | 2 | 0.67 | +0 | +0.0 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.67 | -90 | -44.8 |
| PROMISE KNOWS THE FIGHT | 9 | 4 | 2 | 0.67 | -14 | -7.0 |
| REDIRECT BY WHAT IT STOPS | 6 | 6 | 2 | 0.67 | +14 | +6.8 |
| SAFER THAN THE JOB | 2 | 2 | 2 | 0.67 | +49 | +24.6 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +67 | +33.5 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +2 | +1.0 |
| TIED UP BY THE SUM | 4 | 3 | 2 | 0.67 | +83 | +41.3 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +60 | +30.2 |
| WOUNDS ON THE RANKS | 20 | 20 | 2 | 0.67 | +43 | +21.6 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +23 | +23.3 |
| BLOWS WHERE AIMED | 1 | 1 | 1 | 0.33 | +25 | +24.9 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 13 | 11 | 1 | 0.33 | +0 | +0.0 |
| FEATURE BUFFS | 12 | 12 | 1 | 0.33 | +7 | +6.7 |
| FIGHT TO THE END | 4 | 3 | 1 | 0.33 | +26 | +25.8 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | -5 | -4.6 |
| HIS TURN DENIED | 5 | 5 | 1 | 0.33 | +30 | +29.8 |
| HORN WORTH | 1 | 1 | 1 | 0.33 | +16 | +16.1 |
| LOST AFTER ESCAPE | 13 | 12 | 1 | 0.33 | +0 | +0.0 |
| MARCH CHECK | 6 | 6 | 1 | 0.33 | +11 | +10.8 |
| ONE OBJECTIVE FORMULA | 28 | 22 | 1 | 0.33 | +22 | +22.3 |
| OVERRUNS AWAY | 4 | 4 | 1 | 0.33 | +0 | +0.0 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| REFORMS TO MEET IT | 7 | 7 | 1 | 0.33 | +12 | +11.6 |
| SHOTS IN THE MOVE | 60 | 45 | 1 | 0.33 | +65 | +64.9 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +5 | +4.9 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | -3 | -2.7 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -12 | -12.1 |
| BACKUP TARGETS | 4 | 2 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 8 | trace | - | - | - | - |
| CHARACTER GUNS | 13 | 13 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 62 | 58 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 9 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 11 | 10 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 58 | not checked | - | - | - | - |
| FOOT FIRST | 78 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 10 | 8 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 5 | 5 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 71 | 67 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 3 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 80 | 78 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 51 | 47 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 37 | 35 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 57 | 46 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 77 | 70 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 102 | 102 | 0 | 0.00 | - | - |
| HONEST WORTH | 16 | 14 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 13 | 13 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 1 | 1 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 6 | 6 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 5 | 5 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 27 | 16 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 38 | 26 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 7 | trace | - | - | - | - |
| NEAREST TO GOAL | 11 | 11 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 15 | 14 | 0 | 0.00 | - | - |
| NO LATE CUT | 6 | 6 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 5 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 8 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 36 | 15 | 0 | 0.00 | - | - |
| ONE ROUTE | 5 | 5 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP | 1 | not checked | - | - | - | - |
| PLAN RESULT | 284 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 5 | 5 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 9 | 9 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 8 | 8 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 2 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 20 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 6 | 6 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 2 | not checked | - | - | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 65 | 59 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS STILL | 154 | 149 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 14 | 11 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 10 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 22 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 15 | not checked | - | - | - | - |
| THE TABLE BINDS | 305 | not checked | - | - | - | - |
| WAITS AGAIN | 10 | 10 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p24

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.67 | 4.67 | 34.0 |
| PROMISE BY ITS OWN SUM | rule | 4.00 | 3.33 | 112.6 |
| ARMY TABLE | rule | 1.67 | 5.33 | 107.6 |
| HOLDER ASSIGNMENT | rule | 0.67 | 1.67 | 14.3 |
| NO REASON | gate | - | 1.33 | 54.5 |
| CHARGE NOW FIRST | rule | - | 0.67 | 209.6 |
| MARCH OF THE TABLE | rule | 0.67 | - | 44.6 |
| ONE PROMISE A TARGET | rule | 0.67 | - | 50.8 |
| PIVOT GUARDS FLANK | rule | 0.33 | 0.33 | 44.8 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.67 | 7.0 |
| RULE SWITCHED OFF | gate | 0.67 | - | 27.4 |
| AFTERMATH BAND | gate | - | 0.33 | 4.6 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.33 | 14.5 |
| CHAFF PASSED | rule | - | 0.33 | 0.7 |
| FIGHT ORDER BAND | gate | - | 0.33 | 1.2 |
| FRIENDS SHOTS CHECKED | rule | - | 0.33 | 4.6 |
| JOINT CHARGE NOW | rule | 0.33 | - | 99.9 |
| PATHS CROSS | rule | 0.33 | - | 15.7 |
| SWIFTSTRIDE BY POINTS | rule | - | 0.33 | 2.7 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 12.1 |

### Plans: gs3-83c8646-p24

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 71% | 248 | 122 | 49% |
| Mine | join | 6.3 | 100% | 294 | 0 | 0% |
| Mine | move | 38.0 | 96% | 1869 | 0 | 0% |
| Mine | shoot | 0.3 | 100% | 91 | 47 | 51% |
| Mine | support | 1.3 | 100% | 47 | 0 | 0% |
| Opponent | charge | 2.3 | 57% | 415 | 88 | 21% |
| Opponent | move | 40.7 | 97% | 2803 | 0 | 0% |
| Opponent | shoot | 2.0 | 50% | 168 | 91 | 54% |
| Opponent | support | 1.3 | 100% | 85 | 0 | 0% |

### Battle groups: gs3-83c8646-p24

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.3 | 38% | 40% | 0% | - | 20% | 0% | 0% | 80% | 0% |
| Opponent | REDIRECT COUNTER | 1.0 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p24

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 64 (9) | 0 | 64 | 21 | 67% | 3.0 | 82 (7) | 0 (1) | 0 (1) | 72 (8) | 0 (1) |
| Mine | Character | 10 | 4 (10) | 4 | 0 | 2 | 50% | 3.2 | 0 (6) | 8 (4) | - | 0 (4) | 7 (6) |
| Mine | Clean-up | 1 | 94 (1) | 94 | 0 | 0 | 0% | 2.0 | 94 (1) | - | - | 94 (1) | - |
| Mine | Fast Hammer | 8 | 8 (8) | 0 | 8 | 37 | 62% | 3.7 | 0 (2) | 0 (4) | 39 (2) | 0 (1) | 11 (7) |
| Mine | Hammer | 2 | 306 (2) | 231 | 75 | 0 | 0% | 4.0 | 139 (1) | 503 (1) | - | 139 (1) | 503 (1) |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 25% | 1.3 | 0 (3) | - | 0 (1) | 0 (2) | 0 (2) |
| Opponent | Chaff | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (2) | - | - | 0 (2) | - |
| Opponent | Character | 7 | 22 (7) | 22 | 0 | 37 | 0% | 1.3 | 37 (4) | 0 (1) | 0 (1) | 0 (2) | 34 (4) |
| Opponent | Clean-up | 2 | 41 (2) | 0 | 41 | 0 | 50% | 1.0 | 83 (1) | 0 (1) | - | 83 (1) | 0 (1) |
| Opponent | Fast Hammer | 5 | 27 (5) | 18 | 9 | 58 | 0% | 1.2 | 19 (2) | 52 (2) | 0 (1) | 19 (2) | 34 (3) |
| Opponent | Hammer | 11 | 0 (11) | 0 | 0 | 0 | 73% | 3.7 | 0 (3) | 0 (6) | 0 (2) | 0 (2) | 0 (9) |
| Opponent | Shooter | 8 | 62 (8) | 8 | 54 | 22 | 0% | 1.4 | 86 (2) | 74 (5) | 0 (1) | 66 (3) | 60 (5) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 4.0 | - | - | 0 (1) | - | 0 (1) |

### Charged fights: gs3-83c8646-p24

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 2 | 0 | 406 | 4.0 | 1.1 | 102 | 6 | +95 | 2 of 8 | 4 of 8 | +432 | +47 |
| Mine | Warriors of Chaos | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 142 | -142 | 0 of 2 | 0 of 2 | - | -142 |
| **Mine** | all armies | 3 | 0 | 271 | 3.3 | 1.1 | 81 | 34 | +48 | 2 of 10 | 4 of 10 | +432 | +5 |
| Opponent | Wood Elf Realms | 3 | 33 | 102 | 1.7 | 1.0 | 61 | 141 | -79 | 1 of 5 | 4 of 5 | - | -79 |

### Effective charges: gs3-83c8646-p24

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 8 | 3 (net -17) | 0 | 0 | 2 (net +279) | 0 | 3 (net +85) | 0 | 0% (0 of 8) |
| Mine | Warriors of Chaos | 2 | 1 (net -285) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Wood Elf Realms | 5 | 1 (net -599) | 0 | 0 | 1 (net +45) | 0 | 1 (net +186) | 2 | 0% (0 of 3) |

### Charged fights, damage counted: gs3-83c8646-p24

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 4 | 109 | 187 | -84 | 0 | 84 | -84 | -77.0 |
| Mine | 76-89% | 2 | 328 | 142 | +279 | 279 | 32 | +247 | +75.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 183 | 126 | +85 | 106 | 0 | +106 | +57.8 |
| Mine | No odds | 1 | 173 | 224 | +0 | 95 | 127 | -32 | -18.4 |
| Mine | All fights | 10 | 181 | 164 | +48 | 97 | 53 | +44 | +24.5 |
| Opponent | Long shot (under 50%) | 1 | 499 | 348 | -599 | 0 | 632 | -632 | -126.7 |
| Opponent | 76-89% | 1 | 126 | 45 | +45 | 54 | 0 | +54 | +42.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 499 | 186 | +186 | 186 | 0 | +186 | +37.3 |
| Opponent | No odds | 2 | 115 | 72 | -14 | 82 | 52 | +30 | +25.7 |
| Opponent | All fights | 5 | 271 | 145 | -79 | 81 | 147 | -67 | -24.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p24 | move | 27 | 3 (11%) | 2 (7%) | 3 (11%) | 21 (78%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2535, L2735 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2535, L2735 |
| Ring of Doom | Opponent | L3033 |

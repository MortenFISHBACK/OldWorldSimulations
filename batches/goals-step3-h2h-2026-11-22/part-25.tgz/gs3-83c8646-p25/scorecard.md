# Doctrine scorecard: gs3-83c8646-p25

### Scorecard: gs3-83c8646-p25

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L0110 | 2 | 1 | Opponent | - | - | 5 | 1 | 1 | 0 | 0 | 0 | 165 |
| L0126 | 6 | 1 | Mine | no | 4 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0126 | 6 | 1 | Opponent | no | 6 | 2 | 6 | 3 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 4 | - | 0 | 5 | 2 | 0 | 0 | 811 |
| L0210 | 6 | 1 | Opponent | no | 18 | 4 | 1 | 0 | 0 | 0 | 0 | 165 |
| **Average** | | | Mine | 0% | 4.0 | - | 0.0 | 4.0 | 0.7 | 0.0 | 0.0 | 270.3 |
| **Average** | | | Opponent | 0% | 12.0 | 3.7 | 2.7 | 1.3 | 0.0 | 0.0 | 0.0 | 110.0 |

### KPIs: gs3-83c8646-p25

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 5) | 0% (0 of 15) | 0% (0 of 20) |
| Winner chose to follow up after the loser gave ground |  | 0% (0 of 1); on the table 100% | - | 0% (0 of 1); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 91% (10 of 11); on the table 91% | 91% (10 of 11); on the table 91% |
| Winner chose to follow up or pursue (all three) |  | 0% (0 of 1); on the table 100% | 91% (10 of 11); on the table 91% | 83% (10 of 12); on the table 92% |
| Magic missiles tried each own turn | 50%+ | 52% (47 of 90) | 52% (31 of 60) | 52% (78 of 150) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 54% (47 of 87) | 57% (31 of 54) | 55% (78 of 141) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 100% (6 of 6) | - | 100% (6 of 6) |
| Points that never fought | lower | 74% (4205 of 5699) | 67% (4012 of 5998) | 70% (8217 of 11697) |
|   infantry points that never fought | lower | 78% (1756 of 2239) | 79% (648 of 819) | 79% (2404 of 3058) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 44% (7 of 16) | 60% (15 of 25) | 54% (22 of 41) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 4.7 uses a game | 100% (4 of 4); 6.0 uses a game | 100% (8 of 8); 5.3 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 0.7 uses a game | 0% (0 of 2); 0.0 uses a game | 50% (2 of 4); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (4 of 4); 1.3 uses a game | 50% (1 of 2); 0.3 uses a game | 83% (5 of 6); 0.8 uses a game |
|   their share of the points of units over 100 pts | lower | 37% (1457 of 3916) | 55% (3196 of 5793) | 48% (4653 of 9709) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 6.0 (42%) | 3.3 (34%) | 9.3 (39%) |
| MARCHED: its unit marched | 3.3 (23%) | 3.7 (38%) | 7.0 (29%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.7 (7%) | 0.7 (3%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 2.0 (21%) | 2.0 (8%) |
| REAR RANK: in a rear rank | 4.0 (28%) | 0.0 (0%) | 4.0 (17%) |
| GONE: slain | 1.0 (7%) | 0.0 (0%) | 1.0 (4%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 10.0 | 4.3 | 9.7 | 26.0 | 0.7 | 1.0 |
| not cast | 2.0 | 3.7 | 8.3 | 24.0 | 5.3 | 31.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.0 (82%) | 0.3 (4%) | 9.3 (39%) | 2.7 (50%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 7.0 (29%) | 0.7 (12%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 2.0 (8%) | 1.0 (19%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (0%) | 3.0 (36%) | 4.0 (17%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (3%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (4%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (19%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (100%) | 0.7 (18%) | 4.7 (56%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 28.3 (91%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 9.0 a game | 1.3 a game | 5.2 a game |
| stood (cast and not dispelled) | 74% (20 of 27) | 50% (2 of 4) | 71% (22 of 31) |
| the unit moved after it | 75% (15 of 20) | 100% (2 of 2) | 77% (17 of 22) |
| it charged on its next turn | 0% (0 of 20) | 0% (0 of 2) | 0% (0 of 22) |
| the enemy charged it first | 0% (0 of 20) | 0% (0 of 2) | 0% (0 of 22) |
| it fought by the end of its next turn | 0% (0 of 20) | 0% (0 of 2) | 0% (0 of 22) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 20) | 0% (0 of 2) | 0% (0 of 22) |
| none of these (no charge, no fight, no charge escaped) | 100% (20 of 20) | 100% (2 of 2) | 100% (22 of 22) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 69% (11 of 16) | 71% (20 of 28) | 70% (31 of 44) |
|   chariot | - | 78% (7 of 9) | 78% (7 of 9) |
|   infantry | 69% (11 of 16) | - | 69% (11 of 16) |
|   war machine | - | 68% (13 of 19) | 68% (13 of 19) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.3 (80%) | 0.3 (12%) | 1.7 (38%) |
| CHARGED: it charged | 0.0 (0%) | 0.3 (12%) | 0.3 (8%) |
| FLEEING: it fled or was fleeing | 0.3 (20%) | 0.0 (0%) | 0.3 (8%) |
| MOVED: a war machine that moved | 0.0 (0%) | 1.0 (38%) | 1.0 (23%) |
| OTHER BAR | 0.0 (0%) | 1.0 (38%) | 1.0 (23%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| chariot | 2.3 | 0.7 | 71% | 6.1 pts | 14 pts |
| infantry | 4.3 | 0.7 | 85% | 3.6 pts | 16 pts |
| war machine | 5.0 | 1.0 | 93% | 5.7 pts | 28 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.0 | 4.3 | 2.2 |
| Charges that made contact a game | 0.0 | 3.3 | 1.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.71 declared, 0.57 contact (7 units) | 0.71 declared, 0.57 contact (7 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 3.00 declared, 1.00 contact (1 units) | 3.00 declared, 1.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.00 declared, 0.00 contact (20 units) | 0.33 declared, 0.33 contact (15 units) | 0.14 declared, 0.14 contact (35 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 25% (1 of 4) | - | - | 25% (1 of 4) |
| Character in a unit | 100% (3 of 3) | 50% (2 of 4) | - | 71% (5 of 7) |
| Character on its own | 67% (2 of 3) | 33% (2 of 6) | 50% (2 of 4) | 46% (6 of 13) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 0% (0 of 2) | 20% (1 of 5) | 0% (0 of 1) | 12% (1 of 8) |
| Monster | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Monstrous | - | 100% (1 of 1) | - | 100% (1 of 1) |
| War Machines | 100% (4 of 4) | - | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 3 | 0% (0 of 1); on the table 100% | 52% (47 of 90) | 74% | 44% (7 of 16) | 100% (4 of 4); 4.7 uses a game | 100% (2 of 2); 0.7 uses a game | 100% (4 of 4); 1.3 uses a game |
| Grand Cathay | 2 | 100% (9 of 9); on the table 100% | 52% (28 of 54) | 66% | 60% (12 of 20) | 100% (4 of 4); 9.0 uses a game | 0% (0 of 2); 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Vampire Counts | 1 | 50% (1 of 2); on the table 50% | 50% (3 of 6) | 70% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p25, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (2) | - | 50% (2) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.00 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p25

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | - | 31% (4 of 13) |
| Strategy | Shoot objectives carried out (shot that target) | 0% (0 of 13) | 35% (12 of 34) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (3 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 1) | 20% (1 of 5) |
| Strategy | Joined characters whose unit fought | 0% (0 of 12) | 0% (0 of 1) |
| Strategy | Lone characters that fought | 67% (4 of 6) | 44% (4 of 9) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 4.0 | 1.3 |
| Movement | Points that never moved of their own | 270.3 | 110.0 |
| Movement | Fights charged into per game | 0.0 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | - | 0 of 7 |
| Movement | Charges with odds: sweet spot (55-75%) | - | 2 of 7, net +40 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | - | 1 of 7, net +65 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | - | 1 of 7, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 3.7 | 2.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 36% (4 of 11) | 57% (4 of 7) |
| Shooting | Points destroyed by shooting units | 45.0 | 0.0 |
| Shooting | War machine shots | - | 4.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | - | 31% (4 of 13) |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 11.3 | 8.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 29% (10 of 34) | 16% (4 of 25) |
| Magic | Wounds caused by magic missiles | 21.7 | 15.7 |
| Magic | Wounds caused by other spells | - | 3.7 |
| Magic | Points destroyed by magic (all spells) | 207.7 | 120.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 5.0 / 0.3 / 0.0 / 0.0 | 2.7 / 1.7 / 1.0 / 0.7 |
| Combat | Points destroyed in combat | 45.0 | 145.7 |
| Combat | Points run down | 0.0 | 73.3 |
| Combat | Net points per charged fight, damage counted | - | +124 |
| Combat | Net per 100 charger points, damage counted | - | +35.7 |
| Combat | First round won (charged fights) | - | 71% |
| Combat | Net points per charged fight | - | +80 |
| Combat | Net points per supported fight / lone fight | - / - | +176 / +42 |
| Combat | Charged fights on a top-3 enemy unit | - | 2 of 7 |
| Game | Points lost | 446.7 | 409.7 |
| Game | VP from objectives | 646.7 | 723.3 |
| Game | Lone holders (player turns) | 4.0 | 12.0 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -226 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 856
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p25

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +11.4 | 0.0 | 0.0 | - | - | - | - |
| ALREADY CARRIED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 16.3 | +369.3 | 0.0 | 158.3 | 8.0 | +192.6 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | - | - | - | - | 3.7 | +0.0 | 0.0 | 165.0 |
| CANNON PLANNED TARGET | - | - | - | - | 4.3 | +79.8 | 0.0 | 275.0 |
| CANNON SIGHT KEPT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.3 | -5.5 | 56.7 | 0.0 |
| CAST JOB | 0.7 | +3.1 | 0.0 | 0.0 | 10.3 | +153.2 | 336.7 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 6.7 | +922.5 | 711.3 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 5.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.3 | +8.7 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.7 | +13.8 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 1.0 | +45.8 | 0.0 | 107.3 | 0.7 | +37.7 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -1.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 13.7 | -566.2 | 0.0 | 226.0 | 17.0 | -571.6 | 0.0 | 401.3 |
| CHARGE NOW FIRST | - | - | - | - | 2.0 | +0.0 | 43.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 10.7 | +0.0 | 0.0 | 150.0 | 10.3 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 6.0 | +758.4 | 0.0 | 0.0 | 0.3 | +7.5 | 0.0 | 0.0 |
| COVER ONCE | 6.3 | -630.8 | 0.0 | 43.3 | 14.3 | -452.3 | 0.0 | 255.0 |
| DEPLOY BY FIGURES | 6.0 | +68.6 | 0.0 | 0.0 | 7.3 | -110.4 | 0.0 | 0.0 |
| EXACT ROUND | - | - | - | - | 2.0 | -0.2 | 207.3 | 45.0 |
| FALL BACK GOOD ORDER | - | - | - | - | 1.7 | +0.0 | 107.3 | 0.0 |
| FALLS SHORT | 13.3 | +395.1 | 0.0 | 50.0 | 15.3 | -28.2 | 0.0 | 0.0 |
| FEATURE BUFFS | 14.3 | +639.8 | 0.0 | 78.3 | 4.3 | +205.6 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 1.7 | +28.9 | 21.7 | 0.0 |
| FIVE ACTION | 65.0 | +8559.4 | 711.3 | 462.7 | 97.0 | +3632.9 | 823.7 | 1107.7 |
| FLANK NOT WEIGHED | 6.0 | +0.0 | 0.0 | 17.3 | 6.0 | +0.0 | 0.0 | 45.0 |
| FOLLOW UP WEIGHED | - | - | - | - | 0.3 | +9.6 | 0.0 | 0.0 |
| FOOT FIRST | - | - | - | - | 28.0 | +0.0 | 0.0 | 386.3 |
| FOUR ROUNDS | - | - | - | - | 4.3 | +212.1 | 443.7 | 45.0 |
| FREED FROM HIS FIGHT | 0.7 | +0.0 | 0.0 | 56.7 | - | - | - | - |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -5.6 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 2.0 | -11.1 | 0.0 | 0.0 |
| GOAL WALK | 15.0 | +2213.0 | 0.0 | 126.0 | 7.3 | +413.1 | 0.0 | 0.0 |
| GUN MASK | - | - | - | - | 1.3 | +6.1 | 0.0 | 0.0 |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 0.7 | +0.0 | 0.0 | 56.7 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 9.3 | +0.0 | 0.0 | 208.7 | 10.7 | +0.0 | 0.0 | 401.3 |
| HIS CHARGE LIST | 9.7 | +0.0 | 0.0 | 136.7 | 11.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 1.7 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 11.0 | -121.0 | 0.0 | 239.3 | 6.3 | -160.6 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 1.7 | +0.0 | 0.0 | 0.0 | 11.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVER COMES | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 36.7 | +1624.3 | 0.0 | 339.3 | 40.7 | +2724.0 | 0.0 | 512.7 |
| HIS SHOTS BY HIS RUN | 33.3 | +321.6 | 0.0 | 332.7 | 45.0 | +2104.3 | 0.0 | 512.7 |
| HIS TURN DENIED | - | - | - | - | 2.0 | +50.0 | 365.3 | 45.0 |
| HOLD ODDS | 35.7 | +0.0 | 0.0 | 215.0 | 28.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 14.0 | +1662.9 | 0.0 | 68.3 | 17.7 | +1589.5 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HONEST WORTH | - | - | - | - | 2.7 | -94.0 | 121.7 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 2.0 | +179.4 | 0.0 | 0.0 |
| IDLE COST | 13.0 | -101.0 | 0.0 | 84.7 | 9.0 | -177.4 | 0.0 | 0.0 |
| JOINT CHARGE NOW | - | - | - | - | 1.7 | +379.0 | 322.0 | 45.0 |
| KEEP FALLS | - | - | - | - | 0.3 | +3.8 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 3.3 | +0.0 | 0.0 | 21.7 | 4.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 2.0 | +53.2 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 13.3 | +0.0 | 367.0 | 399.7 | - | - | - | - |
| LONE WIZARD KEPT IN | 2.7 | +270.0 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | - | - | - | - | 3.0 | -8.1 | 400.3 | 45.0 |
| MANOEUVRE | 0.3 | +0.0 | 0.0 | 0.0 | 2.7 | -4.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +2.4 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +42.5 | 0.0 | 0.0 | 2.0 | +56.4 | 0.0 | 0.0 |
| MARCH CHECK | 1.0 | +44.5 | 0.0 | 0.0 | 3.0 | +262.2 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +17.6 | 0.0 | 0.0 | 1.3 | +19.2 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.7 | -7.0 | 0.0 | 0.0 | 3.0 | +8.0 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.0 | +165.2 | 0.0 | 0.0 | 6.0 | +44.0 | 0.0 | 55.7 |
| MEETS IN TIME | 2.7 | +200.3 | 0.0 | 0.0 | 3.7 | +336.1 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 9.0 | +825.7 | 0.0 | 0.0 | 13.7 | +170.8 | 0.0 | 111.3 |
| MISSILES NEXT TURN | 9.3 | +449.6 | 0.0 | 0.0 | 16.3 | +133.7 | 0.0 | 55.7 |
| MISSILES ON ONE TARGET | 2.7 | -149.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 1.0 | +0.0 | 85.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 1.0 | -25.2 | 0.0 | 146.7 | - | - | - | - |
| MOVE SPELL SPOT | 3.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 0.7 | +77.6 | 0.0 | 0.0 | 4.7 | +236.3 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 6.7 | +300.7 | 0.0 | 0.0 | 8.3 | +337.1 | 0.0 | 0.0 |
| NEAREST TO GOAL | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 0.7 | +77.6 | 0.0 | 0.0 | 2.7 | +144.7 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | - | - | - | - | 2.7 | -58.7 | 229.0 | 45.0 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.7 | -1.1 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 2.7 | -85.9 | 0.0 | 56.3 | 5.7 | -250.1 | 0.0 | 110.7 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 6.0 | +22.8 | 0.0 | 165.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.3 | -55.9 | 0.0 | 0.0 | 5.7 | -130.2 | 0.0 | 55.7 |
| ONE JOINT FIGURE | - | - | - | - | 1.7 | +911.3 | 322.0 | 45.0 |
| ONE OBJECTIVE FORMULA | 9.7 | +303.6 | 0.0 | 46.7 | 9.0 | -302.6 | 0.0 | 0.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 1.3 | +38.1 | 180.0 | 0.0 | 1.0 | +17.1 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 1.3 | +97.9 | 43.3 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.7 | +13.6 | 43.3 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -10.6 | 0.0 | 45.0 |
| PLAN RESULT | 30.7 | +221.2 | 210.7 | 505.7 | 43.3 | +547.3 | 707.0 | 678.3 |
| PROMISE BELOW ZERO | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 1.0 | +0.0 | 0.0 | 0.0 | 6.0 | -87.7 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 1.7 | -9.2 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | - | - | - | - | 0.7 | -1.4 | 0.0 | 0.0 |
| PURSUES BIG PREY | - | - | - | - | 0.3 | +58.1 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 2.0 | +99.7 | 0.0 | 113.3 | - | - | - | - |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 3.7 | +167.7 | 0.0 | 18.3 | 0.3 | +17.9 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.3 | +0.0 | 0.0 | 18.3 | 2.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -11.9 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 107.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 1.3 | +21.8 | 0.0 | 0.0 |
| RESERVE MOVE SPELL | 1.0 | +29.1 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | - | - | - | - | 4.0 | -85.6 | 387.0 | 45.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.7 | -42.8 | 65.0 | 0.0 |
| RUN DOWN | - | - | - | - | 2.0 | -10.4 | 150.7 | 0.0 |
| SCOUT SPOT | 0.7 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | 3.0 | -62.7 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 1.0 | +10.0 | 0.0 | 21.7 | - | - | - | - |
| SET CREDITED ONCE | 0.7 | -9.3 | 0.0 | 21.7 | 3.3 | -879.0 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.7 | +4.7 | 0.0 | 21.7 | 4.0 | +715.2 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.3 | +65.2 | 0.0 | 0.0 | 0.3 | +14.3 | 0.0 | 0.0 |
| SET-UP MISSED | 0.3 | +24.1 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 4.3 | +0.0 | 0.0 | 0.0 | 10.7 | +0.0 | 0.0 | 275.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +56.6 | 0.0 | 0.0 | 2.7 | +45.5 | 43.3 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.7 | -23.3 | 56.7 | 0.0 |
| SHOT RISK POINTS | 32.3 | +276.9 | 0.0 | 341.3 | 38.7 | +677.0 | 0.0 | 422.7 |
| SHOTS AFTER THE MOVES | - | - | - | - | 3.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 2.7 | +57.2 | 0.0 | 43.3 | 8.3 | +247.1 | 0.0 | 420.0 |
| SPELL SETS UP CHARGE | 0.7 | +114.1 | 0.0 | 0.0 | 0.3 | +14.3 | 0.0 | 0.0 |
| SPELL WORTH | 2.7 | +20.7 | 0.0 | 0.0 | 4.0 | +42.1 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | +4.1 | 56.7 | 0.0 |
| SPOT AS THE GAME MOVES | 8.3 | +0.0 | 0.0 | 314.0 | 7.0 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | - | - | - | - | 1.7 | -6.9 | 65.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 2.7 | +0.0 | 36.7 | 0.0 |
| STANDS STILL | 11.7 | +0.0 | 711.3 | 56.7 | 41.0 | +0.0 | 380.0 | 660.0 |
| STAY WORTH | 4.3 | +23.2 | 291.3 | 43.3 | 15.3 | +147.7 | 143.3 | 330.0 |
| STRIKE BY THE ODDS | 0.3 | +1.5 | 45.0 | 107.3 | 0.7 | +38.7 | 107.3 | 90.0 |
| SUPPORT ADDS | 4.7 | +265.6 | 0.0 | 105.0 | - | - | - | - |
| SUPPORT WORKED OUT | 4.7 | +265.6 | 0.0 | 105.0 | - | - | - | - |
| SURE REACH TOGETHER | 0.3 | +1.8 | 0.0 | 28.3 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.0 | +0.0 | 0.0 | 28.3 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 3.3 | +0.0 | 0.0 | 28.3 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 31.0 | +0.0 | 0.0 | 174.7 | 44.0 | +0.0 | 0.0 | 476.3 |
| TIED UP BY THE SUM | - | - | - | - | 1.0 | +116.8 | 43.3 | 0.0 |
| TIME ON OUR SIDE | 9.3 | +299.7 | 0.0 | 61.7 | 34.3 | +478.6 | 86.7 | 312.7 |
| WAITS AGAIN | - | - | - | - | 4.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | - | - | - | - | 0.7 | +56.5 | 107.3 | 45.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +38.2 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 3.0 | -213.2 | 0.0 | 34.7 | 2.3 | -102.6 | 0.0 | 180.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 1.3 | +110.3 | 214.7 | 0.0 |
| WOUNDS ON THE RANKS | 3.0 | +83.8 | 0.0 | 0.0 | 1.3 | +12.9 | 0.0 | 111.3 |

### Rule changes: gs3-83c8646-p25

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 95 | 95 | 91 | 30.33 | +6709 | +73.7 |
| HIS SHOTS BY HIS RUN | 235 | 233 | 60 | 20.00 | +750 | +12.5 |
| HIS SHOT LIST | 232 | 231 | 57 | 19.00 | +1356 | +23.8 |
| SHOT RISK POINTS | 213 | 210 | 54 | 18.00 | +1819 | +33.7 |
| ARMY TABLE | 73 | 73 | 48 | 16.00 | +1348 | +28.1 |
| LEGAL CHARGES ONLY | 40 | 40 | 40 | 13.33 | +0 | +0.0 |
| GOAL WALK | 67 | 66 | 31 | 10.33 | +2974 | +95.9 |
| DEPLOY BY FIGURES | 40 | 40 | 25 | 8.33 | +250 | +10.0 |
| OFF BEST | 25 | 25 | 25 | 8.33 | -1008 | -40.3 |
| THE TABLE AGAIN | 36 | 36 | 22 | 7.33 | +0 | +0.0 |
| CAST JOB | 33 | 33 | 20 | 6.67 | +69 | +3.4 |
| CASTING BLOCK | 20 | 20 | 19 | 6.33 | +768 | +40.4 |
| OGRE LOADER SECOND SHOT | 18 | 18 | 18 | 6.00 | +68 | +3.8 |
| FIVE ACTION | 486 | 481 | 17 | 5.67 | +1104 | +64.9 |
| REDIRECT FOR A FRIEND IN REACH | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| IDLE COST | 66 | 51 | 12 | 4.00 | +163 | +13.5 |
| TIME ON OUR SIDE | 131 | 106 | 12 | 4.00 | +142 | +11.9 |
| ARTILLERY RE-ROLL WEIGHED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| COVER ONCE | 62 | 47 | 11 | 3.67 | +120 | +10.9 |
| CHARGE LOSSES | 92 | 90 | 9 | 3.00 | +244 | +27.1 |
| MEETS IN TIME | 19 | 19 | 9 | 3.00 | +555 | +61.7 |
| STAY WORTH | 59 | 58 | 9 | 3.00 | +50 | +5.5 |
| LONE WIZARD KEPT IN | 8 | 8 | 8 | 2.67 | +810 | +101.2 |
| MARCH BY THE SUM | 8 | 8 | 8 | 2.67 | +297 | +37.1 |
| MARCH CHECK | 12 | 11 | 8 | 2.67 | +140 | +17.5 |
| MISSILES IN THE MOVE | 68 | 50 | 8 | 2.67 | +281 | +35.1 |
| MOVE TO CHARGE COMPUTED | 16 | 14 | 8 | 2.67 | +177 | +22.1 |
| MOVE ORDER | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| SET UP BY THE SET | 14 | 14 | 7 | 2.33 | +950 | +135.6 |
| FALLS SHORT | 86 | 61 | 6 | 2.00 | +3 | +0.5 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +160 | +26.6 |
| MAX FOR POSITIONING | 30 | 26 | 6 | 2.00 | +45 | +7.5 |
| RANDOM MOVE BY FIGURES | 6 | 6 | 6 | 2.00 | +299 | +49.9 |
| CASTER AWAY FROM SCREEN | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 5 | 5 | 5 | 1.67 | +250 | +50.0 |
| FEATURE BUFFS | 56 | 56 | 5 | 1.67 | +76 | +15.3 |
| HARD STAY DROPPED | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | +1137 | +227.3 |
| MARCH OF THE TABLE | 5 | 5 | 5 | 1.67 | -111 | -22.1 |
| PROMISE BY ITS OWN SUM | 21 | 21 | 5 | 1.67 | -263 | -52.6 |
| HIS MOVE AND SHOT | 52 | 52 | 4 | 1.33 | +58 | +14.5 |
| NEXT CHARGE BY LIST | 10 | 8 | 4 | 1.33 | +25 | +6.2 |
| ONE JOINT FIGURE | 5 | 5 | 4 | 1.33 | +852 | +213.1 |
| ONE OBJECTIVE FORMULA | 56 | 42 | 4 | 1.33 | +175 | +43.8 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +65 | +16.3 |
| SHOOTS FROM THE BEST SPOT | 12 | 12 | 4 | 1.33 | +68 | +17.0 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| OPENS UP | 4 | 4 | 3 | 1.00 | +64 | +21.4 |
| RESERVE MOVE SPELL | 3 | 3 | 3 | 1.00 | +87 | +29.1 |
| SUPPORT ADDS | 14 | 14 | 3 | 1.00 | +50 | +16.7 |
| SUPPORT WORKED OUT | 14 | 14 | 3 | 1.00 | +50 | +16.7 |
| TIED UP BY THE SUM | 3 | 3 | 3 | 1.00 | +64 | +21.4 |
| CANNON SIGHT KEPT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 5 | 5 | 2 | 0.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 6 | 6 | 2 | 0.67 | -26 | -12.8 |
| FOUR ROUNDS | 13 | 12 | 2 | 0.67 | +78 | +39.0 |
| HUNT IN PAIRS | 6 | 4 | 2 | 0.67 | +128 | +63.9 |
| MANOEUVRE | 9 | 9 | 2 | 0.67 | +4 | +1.8 |
| OPENS A LANE | 7 | 6 | 2 | 0.67 | +19 | +9.4 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -4 | -2.2 |
| REDIRECT COUNTER | 12 | 7 | 2 | 0.67 | +33 | +16.6 |
| RISK BY ARC | 12 | 12 | 2 | 0.67 | +74 | +37.0 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SEARCH SPOT | 3 | 3 | 2 | 0.67 | +30 | +15.0 |
| SET CREDITED ONCE | 12 | 12 | 2 | 0.67 | +119 | +59.3 |
| SHOTS IN THE MOVE | 33 | 27 | 2 | 0.67 | +73 | +36.6 |
| STRIKE BY THE ODDS | 3 | 3 | 2 | 0.67 | +49 | +24.4 |
| THE ROW IN ITS ORDER | 12 | 2 | 2 | 0.67 | +0 | +0.0 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +34 | +34.1 |
| CANNON PLANNED TARGET | 13 | 13 | 1 | 0.33 | +0 | +0.0 |
| CARRIES OUT SET-UP | 1 | 1 | 1 | 0.33 | -17 | -16.6 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +29 | +28.8 |
| HIS TURN DENIED | 6 | 6 | 1 | 0.33 | +58 | +57.5 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +47 | +47.3 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| OVERRUNS AWAY | 2 | 2 | 1 | 0.33 | +21 | +21.0 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -32 | -31.8 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.33 | +174 | +174.2 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +101 | +100.8 |
| REFUSING RETIRES | 4 | 4 | 1 | 0.33 | -0 | -0.4 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 2 | 2 | 1 | 0.33 | +104 | +103.5 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +42 | +42.5 |
| WHOLE FIGHT GAIN | 4 | 4 | 1 | 0.33 | +58 | +57.5 |
| WOUNDS ON THE RANKS | 13 | 13 | 1 | 0.33 | +2 | +2.1 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| CASTS AFTER FRIENDS | 17 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 63 | 61 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 19 | not checked | - | - | - | - |
| EXACT ROUND | 6 | 5 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 5 | 5 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 5 | 5 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 36 | not checked | - | - | - | - |
| FOOT FIRST | 84 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 6 | 6 | 0 | 0.00 | - | - |
| GUN MASK | 4 | 4 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 60 | 58 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 63 | 63 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 26 | 23 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 38 | 35 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 18 | 18 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 3 | 3 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 192 | 191 | 0 | 0.00 | - | - |
| HONEST WORTH | 8 | 7 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 22 | 21 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 9 | 8 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 11 | 11 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 10 | 9 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 77 | 50 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 8 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 3 | trace | - | - | - | - |
| MOVE SPELL SPOT | 12 | not checked | - | - | - | - |
| NEARER NOT NEEDED | 45 | 35 | 0 | 0.00 | - | - |
| NEAREST TO GOAL | 2 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 8 | 7 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 27 | 15 | 0 | 0.00 | - | - |
| ONE ROUTE | 10 | 9 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 222 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 5 | 5 | 0 | 0.00 | - | - |
| REAL GROUND | 10 | 9 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 5 | 5 | 0 | 0.00 | - | - |
| RUN DOWN | 6 | 6 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 9 | 9 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 2 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 45 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 1 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 10 | 10 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 3 | not checked | - | - | - | - |
| SPELL WORTH | 20 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 46 | 44 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 5 | 5 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 158 | 158 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 19 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 11 | not checked | - | - | - | - |
| THE TABLE BINDS | 225 | not checked | - | - | - | - |
| WAITS AGAIN | 13 | 13 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 16 | 16 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p25

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.67 | 5.33 | 41.7 |
| ARMY TABLE | rule | 1.33 | 0.33 | 28.3 |
| HOLDER ASSIGNMENT | rule | 1.33 | 0.33 | 36.3 |
| MARCH OF THE TABLE | rule | 0.33 | 1.33 | 22.1 |
| PROMISE BY ITS OWN SUM | rule | - | 1.67 | 52.6 |
| CHARGE NOW FIRST | rule | - | 0.67 | 12.8 |
| DEPLOY BY FIGURES | rule | 0.33 | 0.33 | 1.9 |
| PROMISE SHOT AWAY | rule | - | 0.67 | 2.2 |
| CARRIES OUT SET-UP | rule | - | 0.33 | 16.6 |
| NO REASON | gate | - | 0.33 | 8.4 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 31.8 |
| SET UP BY THE SET | rule | - | 0.33 | 13.0 |

### Plans: gs3-83c8646-p25

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | move | 25.3 | 91% | 2692 | 0 | 0% |
| Mine | shoot | 4.0 | 58% | 1031 | 221 | 21% |
| Mine | support | 1.3 | 75% | 18 | 0 | 0% |
| Opponent | charge | 3.7 | 64% | 479 | 364 | 76% |
| Opponent | move | 30.0 | 99% | 1556 | 0 | 0% |
| Opponent | shoot | 9.7 | 45% | 376 | 183 | 49% |

### Battle groups: gs3-83c8646-p25

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.7 | 27% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p25

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 3 | 0 (3) | 0 | 0 | 39 | 100% | - | 0 (1) | 0 (1) | 0 (1) | 0 (3) | - |
| Mine | Character | 18 | 26 (18) | 26 | 0 | 15 | 28% | 1.7 | 8 (5) | 38 (11) | - | 20 (12) | 55 (4) |
| Mine | Clean-up | 3 | 0 (3) | 0 | 0 | 33 | 100% | - | 0 (2) | 0 (1) | - | 0 (2) | 0 (1) |
| Mine | Fast Hammer | 2 | 0 (2) | 0 | 0 | 50 | 50% | 5.0 | - | 0 (2) | - | 0 (2) | - |
| Mine | Hammer | 7 | 62 (7) | 0 | 62 | 32 | 57% | 4.7 | 76 (1) | 71 (4) | 0 (2) | 45 (5) | 98 (2) |
| Mine | Holder | 3 | 25 (3) | 0 | 25 | 0 | 100% | - | 0 (1) | 0 (1) | 71 (1) | 37 (2) | 0 (1) |
| Mine | Shooter | 4 | 113 (4) | 52 | 62 | 75 | 0% | 1.5 | 181 (2) | 92 (1) | 0 (1) | 113 (4) | - |
| Opponent | Chaff | 4 | 263 (4) | 0 | 263 | 0 | 100% | - | 171 (2) | 600 (1) | 0 (1) | 0 (2) | 450 (2) |
| Opponent | Character | 10 | 30 (10) | 30 | 0 | 4 | 20% | 1.5 | 0 (1) | 5 (3) | 55 (5) | 19 (7) | 71 (2) |
| Opponent | Clean-up | 3 | 80 (3) | 0 | 80 | 0 | 67% | 2.0 | 204 (1) | 58 (1) | 34 (1) | 80 (3) | - |
| Opponent | Fast Hammer | 6 | 70 (6) | 10 | 61 | 50 | 0% | 2.3 | - | 87 (5) | 0 (1) | 70 (6) | - |
| Opponent | Hammer | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Holder | 1 | 88 (1) | 0 | 88 | 100 | 0% | 4.0 | - | - | 88 (1) | 88 (1) | - |
| Opponent | War machine | 4 | 0 (4) | 0 | 0 | 75 | 0% | 2.0 | 0 (1) | 0 (3) | - | - | 0 (4) |

### Charged fights: gs3-83c8646-p25

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 253 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 2 | 154 | 369 | 2.0 | 1.8 | 184 | 76 | +108 | 2 of 4 | 3 of 4 | +176 | +40 |
| Opponent | Vampire Counts | 1 | 55 | 130 | 3.0 | 1.0 | 43 | 0 | +43 | 0 of 3 | 2 of 3 | - | +43 |
| **Opponent** | all armies | 3 | 121 | 289 | 2.3 | 1.4 | 124 | 44 | +80 | 2 of 7 | 5 of 7 | +176 | +42 |

### Effective charges: gs3-83c8646-p25

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Grand Cathay | 4 | 0 | 0 | 2 (net +40) | 1 (net +351) | 0 | 1 (net +0) | 0 | 50% (2 of 4) |
| Opponent | Vampire Counts | 3 | 0 | 0 | 0 | 2 (net +32) | 1 (net +65) | 0 | 0 | 0% (0 of 3) |

### Charged fights, damage counted: gs3-83c8646-p25

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Effective (55-75%) | 2 | 266 | 126 | +40 | 110 | 0 | +110 | +41.4 |
| Opponent | 76-89% | 3 | 298 | 134 | +139 | 286 | 145 | +141 | +47.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 505 | 272 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 500 | 65 | +65 | 226 | 0 | +226 | +45.2 |
| Opponent | All fights | 7 | 347 | 141 | +80 | 186 | 62 | +124 | +35.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p25 | move | 15 | 2 (13%) | 2 (13%) | 1 (7%) | 12 (80%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126 |
| Charmed Shield | Opponent | L0126 |
| Ring of Doom | Mine | L0210 |
| Ring of Jet | Opponent | L0110, L0210 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |

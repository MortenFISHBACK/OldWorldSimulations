# Doctrine scorecard: gs3-83c8646-p18

### Scorecard: gs3-83c8646-p18

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0918 | 6 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 250 |
| L0918 | 6 | 1 | Opponent | no | 9 | - | 2 | 1 | 0 | 0 | 0 | 0 |
| L0934 | 4 | 1 | Mine | no | 0 | 5 | 0 | 1 | 0 | 0 | 0 | 745 |
| L0934 | 4 | 1 | Opponent | no | 4 | 3 | 4 | 5 | 0 | 0 | 0 | 0 |
| L1026 | 6 | 1 | Mine | no | 9 | 3 | 2 | 0 | 0 | 0 | 0 | 165 |
| L1026 | 6 | 1 | Opponent | no | 1 | 5 | 1 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 3.0 | 4.0 | 0.7 | 0.7 | 0.0 | 0.0 | 0.0 | 386.7 |
| **Average** | | | Opponent | 0% | 4.7 | 4.0 | 2.3 | 2.3 | 0.0 | 0.0 | 0.0 | 0.0 |

### KPIs: gs3-83c8646-p18

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 46% (6 of 13) | 0% (0 of 13) | 23% (6 of 26) |
| Winner chose to follow up after the loser gave ground |  | 100% (5 of 5); on the table 100% | 100% (4 of 4); on the table 100% | 100% (9 of 9); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | 100% (3 of 3); on the table 100% | 100% (4 of 4); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (6 of 6); on the table 100% | 100% (7 of 7); on the table 100% | 100% (13 of 13); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 25% (12 of 48) | 25% (3 of 12) | 25% (15 of 60) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 31% (12 of 39) | 25% (3 of 12) | 29% (15 of 51) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 49% (2957 of 5997) | 63% (3772 of 5998) | 56% (6729 of 11995) |
|   infantry points that never fought | lower | 46% (730 of 1591) | 58% (670 of 1147) | 51% (1400 of 2738) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 68% (23 of 34) | 60% (12 of 20) | 65% (35 of 54) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 1.7 uses a game | 100% (1 of 1); 1.3 uses a game | 100% (3 of 3); 1.5 uses a game |
| Bound items with another spell used |  | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 63% (3543 of 5667) | 51% (2626 of 5186) | 57% (6169 of 10853) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 6.0 (50%) | 0.0 (0%) | 6.0 (40%) |
| MARCHED: its unit marched | 2.0 (17%) | 0.7 (22%) | 2.7 (18%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.3 (11%) | 0.3 (2%) |
| IN COMBAT: engaged in combat | 3.0 (25%) | 0.0 (0%) | 3.0 (20%) |
| REAR RANK: in a rear rank | 1.0 (8%) | 0.7 (22%) | 1.7 (11%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 1.3 (44%) | 1.3 (9%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 1.0 | 5.0 | 0.3 | 1.3 |
| not cast | 2.0 | 5.0 | 15.0 | 3.7 | 14.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (40%) | 6.0 (40%) | 2.0 (55%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 2.7 (18%) | 0.7 (18%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (7%) | 3.0 (20%) | 1.0 (27%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (100%) | 2.0 (40%) | 1.7 (11%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.7 (13%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 1.3 (9%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.0 (95%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 59% (74 of 126) | 65% (54 of 83) | 61% (128 of 209) |
|   cavalry | - | 64% (7 of 11) | 64% (7 of 11) |
|   character | 100% (3 of 3) | 61% (11 of 18) | 67% (14 of 21) |
|   chariot | 76% (13 of 17) | 83% (10 of 12) | 79% (23 of 29) |
|   infantry | 47% (27 of 57) | 60% (18 of 30) | 52% (45 of 87) |
|   monster | 17% (1 of 6) | 67% (8 of 12) | 50% (9 of 18) |
|   war machine | 70% (30 of 43) | - | 70% (30 of 43) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 5.0 (29%) | 3.7 (38%) | 8.7 (32%) |
| CHARGED: it charged | 0.0 (0%) | 0.7 (7%) | 0.7 (2%) |
| IN COMBAT: it fought this turn or the last | 1.3 (8%) | 0.0 (0%) | 1.3 (5%) |
| MOVED: a war machine that moved | 1.7 (10%) | 0.0 (0%) | 1.7 (6%) |
| NO TARGET IN RANGE | 3.7 (21%) | 2.3 (24%) | 6.0 (22%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (2%) | 0.0 (0%) | 0.3 (1%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 4.0 (23%) | 2.3 (24%) | 6.3 (23%) |
| SHELTERED: the target was sheltered | 1.3 (8%) | 0.7 (7%) | 2.0 (7%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.7 | 0.3 | 93% | 0.6 pts | 3 pts |
| character | 4.7 | 1.0 | 79% | 1.8 pts | 8 pts |
| chariot | 7.7 | 4.3 | 70% | 7.6 pts | 58 pts |
| infantry | 17.3 | 4.7 | 77% | 5.6 pts | 98 pts |
| monster | 3.3 | 0.3 | 90% | 1.3 pts | 4 pts |
| war machine | 10.0 | 6.3 | 77% | 12.1 pts | 121 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.3 | 3.7 | 2.5 |
| Charges that made contact a game | 1.3 | 3.0 | 2.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 1.00 contact (3 units) | 1.00 declared, 0.00 contact (1 units) | 1.00 declared, 0.75 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 1.00 contact (1 units) | 1.00 declared, 1.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.05 declared, 0.05 contact (19 units) | 0.29 declared, 0.26 contact (31 units) | 0.20 declared, 0.18 contact (50 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | - | - | 50% (2 of 4) |
| Character in a unit | 75% (3 of 4) | 100% (1 of 1) | - | 80% (4 of 5) |
| Character on its own | 100% (1 of 1) | 33% (1 of 3) | 20% (1 of 5) | 33% (3 of 9) |
| Chariot | 100% (3 of 3) | 50% (1 of 2) | - | 80% (4 of 5) |
| Infantry | 45% (5 of 11) | 100% (2 of 2) | 0% (0 of 1) | 50% (7 of 14) |
| Monster | 100% (1 of 1) | 100% (1 of 1) | - | 100% (2 of 2) |
| Monstrous | 50% (1 of 2) | 80% (4 of 5) | - | 71% (5 of 7) |
| War Machines | 100% (8 of 8) | - | - | 100% (8 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 2 | 100% (2 of 2); on the table 100% | 17% (4 of 24) | 58% | 75% (18 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | 100% (4 of 4); on the table 100% | 33% (8 of 24) | 31% | 50% (5 of 10) | 100% (2 of 2); 5.0 uses a game | 0% (0 of 1); 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Ogre Kingdoms | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 92% | 100% (7 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (4 of 4); on the table 100% | 50% (3 of 6) | 32% | 20% (1 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (2 of 2); on the table 100% | - | 64% | 50% (4 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p18, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 80% (4) | 67% (2) | 75% (6) |
| ...free all their last turn and able to turn (per game) | 1.00 | 0.67 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 1.00 | 0.67 | 1.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p18

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 100% (3 of 3) | 67% (6 of 9) |
| Strategy | Shoot objectives carried out (shot that target) | 34% (19 of 56) | 63% (19 of 30) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 33% (1 of 3) | - |
| Strategy | Joined characters whose unit fought | 25% (2 of 8) | 0% (0 of 1) |
| Strategy | Lone characters that fought | 83% (5 of 6) | 40% (2 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.7 | 2.3 |
| Movement | Points that never moved of their own | 386.7 | 0.0 |
| Movement | Fights charged into per game | 1.3 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 3 | 1 of 6, net +221 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 3 | 0 of 6 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 3, net +30 | 1 of 6, net +297 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 3, net +109 | 3 of 6, net +152 |
| Shooting | Shots by shooting units (incl. breath weapons) | 15.0 | 18.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 22% (10 of 45) | 48% (26 of 54) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 10.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 73% (22 of 30) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 3.0 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 11% (1 of 9) | 0% (0 of 2) |
| Magic | Wounds caused by magic missiles | 4.3 | 3.0 |
| Magic | Wounds caused by other spells | 2.0 | - |
| Magic | Points destroyed by magic (all spells) | 26.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 1.0 / 1.0 / 0.3 | 1.7 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 51.3 | 45.0 |
| Combat | Points run down | 0.0 | 245.7 |
| Combat | Net points per charged fight, damage counted | +57 | +197 |
| Combat | Net per 100 charger points, damage counted | +19.5 | +80.3 |
| Combat | First round won (charged fights) | 100% | 78% |
| Combat | Net points per charged fight | +57 | +162 |
| Combat | Net points per supported fight / lone fight | - / +57 | - / +162 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 4 | 1 of 9 |
| Game | Points lost | 547.3 | 149.7 |
| Game | VP from objectives | 373.3 | 746.7 |
| Game | Lone holders (player turns) | 3.0 | 4.7 |

- Mine won / drew / lost: 0 / 0 / 3 of 3 ended games (of 3); mean margin (Mine - Opponent) -883 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 697
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p18

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 11.0 | +190.6 | 0.0 | 225.0 | 25.7 | +359.6 | 0.0 | 72.7 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +8.7 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 4.7 | +0.0 | 0.0 | 41.7 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 0.3 | +2.7 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.3 | -21.3 | 79.7 | 0.0 |
| CANNON PLANNED TARGET | 9.3 | +139.2 | 11.3 | 125.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 6.0 | +104.3 | 58.3 | 267.3 | 1.3 | +6.4 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.0 | +34.3 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +10.6 | 0.0 | 75.7 | - | - | - | - |
| CHARACTER GUNS | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 18.7 | -586.8 | 0.0 | 648.0 | 21.7 | -711.9 | 0.0 | 145.3 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 76.3 | 0.0 | 0.7 | +0.0 | 45.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 11.0 | +0.0 | 0.0 | 73.7 | 14.7 | +0.0 | 0.0 | 22.7 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 10.7 | -453.2 | 0.0 | 325.3 | 4.3 | -351.8 | 0.0 | 0.0 |
| DEFENSIVE ARMY | 1.3 | +0.0 | 0.0 | 69.3 | - | - | - | - |
| DENIED BY THE FIGHT | - | - | - | - | 1.3 | -10.3 | 79.7 | 0.0 |
| DEPLOY BY FIGURES | 9.0 | -55.1 | 0.0 | 0.0 | 9.0 | +40.5 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 1.0 | +377.9 | 34.7 | 0.0 |
| EXACT ROUND | 1.3 | +4.6 | 91.3 | 0.0 | 1.7 | +38.5 | 162.3 | 0.0 |
| FALL BACK GOOD ORDER | 1.0 | +0.0 | 71.3 | 0.0 | 2.0 | +3.6 | 155.3 | 0.0 |
| FALLS SHORT | - | - | - | - | 35.0 | +417.0 | 0.0 | 35.0 |
| FIGHT TO THE END | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 101.3 | +4152.4 | 302.7 | 1476.0 | 116.3 | +5469.8 | 866.7 | 377.0 |
| FLANK NOT WEIGHED | 6.0 | +0.0 | 0.0 | 299.3 | 7.0 | +0.0 | 0.0 | 104.0 |
| FOLLOW UP WEIGHED | 0.7 | +35.0 | 0.0 | 0.0 | 1.3 | +162.8 | 0.0 | 0.0 |
| FOOT FIRST | - | - | - | - | 29.7 | +0.0 | 0.0 | 164.0 |
| FOUR ROUNDS | 1.3 | +74.9 | 91.3 | 0.0 | 3.0 | +157.5 | 337.0 | 0.0 |
| FREED FROM HIS FIGHT | 2.7 | +0.0 | 0.0 | 243.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.3 | -1.5 | 0.0 | 0.0 | 0.3 | -0.4 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.3 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | - | - | - | - | 0.3 | -7.6 | 73.7 | 0.0 |
| GOAL WALK | 10.0 | +542.3 | 0.0 | 0.0 | 23.0 | +2240.2 | 0.0 | 0.0 |
| GUN FIGURES | 2.7 | +23.7 | 36.3 | 0.0 | 1.0 | +7.7 | 0.0 | 0.0 |
| GUN MASK | 2.7 | +175.1 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 2.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 1.0 | +0.0 | 0.0 | 108.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 11.3 | +0.0 | 0.0 | 496.7 | 8.7 | +0.0 | 0.0 | 145.3 |
| HIS CHARGE DENIED | 0.3 | +1.4 | 15.0 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 4.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 1.7 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.7 | -19.5 | 0.0 | 237.3 | 15.3 | -104.2 | 0.0 | 84.0 |
| HIS ONE QUARTER | 0.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 2.3 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 39.3 | +1055.4 | 0.0 | 302.7 | 86.0 | +5622.2 | 0.0 | 305.7 |
| HIS SHOTS BY HIS RUN | 37.0 | +668.8 | 0.0 | 738.0 | 62.0 | +1437.3 | 0.0 | 234.3 |
| HIS TURN DENIED | - | - | - | - | 2.3 | +71.0 | 187.7 | 0.0 |
| HOLD ODDS | 17.7 | +0.0 | 0.0 | 255.3 | 21.0 | +0.0 | 0.0 | 40.0 |
| HOLDER ASSIGNMENT | 12.3 | +1133.2 | 0.0 | 181.7 | 15.3 | +1367.1 | 0.0 | 20.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -48.1 | 91.3 | 0.0 | 3.0 | -127.4 | 337.0 | 0.0 |
| IDLE COST | - | - | - | - | 25.3 | -334.2 | 0.0 | 47.7 |
| JOINT CHARGE NOW | - | - | - | - | 0.7 | +18.9 | 108.0 | 0.0 |
| KEEP FALLS | 0.3 | +2.3 | 0.0 | 73.7 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 6.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.7 | +15.4 | 0.0 | 0.0 | 1.3 | +93.2 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 1.0 | +0.0 | 20.0 | 73.7 | 5.3 | +0.0 | 131.7 | 216.3 |
| LONE WIZARD KEPT IN | 1.3 | +43.3 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.3 | +4.1 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.3 | -0.1 | 20.0 | 0.0 | 1.7 | +12.8 | 226.7 | 0.0 |
| MAKE SURE TOGETHER | 0.7 | +0.9 | 0.0 | 0.0 | 0.7 | +7.4 | 0.0 | 0.0 |
| MANOEUVRE | 2.0 | -7.2 | 0.0 | 75.7 | 2.0 | +2.0 | 0.0 | 36.3 |
| MARCH AT ESCAPER | 0.3 | +3.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.3 | +17.4 | 0.0 | 0.0 | 0.3 | +17.4 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | +0.1 | 0.0 | 0.0 | 0.3 | +8.9 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 4.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.3 | +9.4 | 0.0 | 54.0 | 2.3 | +15.4 | 0.0 | 0.0 |
| MEETS IN TIME | 3.7 | +414.2 | 0.0 | 0.0 | 3.7 | +549.1 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 10.0 | +134.3 | 0.0 | 187.7 | 2.3 | +33.5 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 12.0 | +105.7 | 0.0 | 133.7 | 3.3 | +27.8 | 0.0 | 0.0 |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 35.7 | 35.7 |
| MOVE TO CHARGE COMPUTED | 2.3 | +119.5 | 0.0 | 0.0 | 4.0 | +92.0 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.7 | +267.8 | 0.0 | 75.7 | 5.3 | +248.6 | 0.0 | 20.0 |
| NEAREST TO GOAL | - | - | - | - | 4.3 | +0.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 2.3 | +118.1 | 0.0 | 0.0 | 3.0 | +62.5 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.7 | -16.5 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.3 | -47.8 | 91.3 | 0.0 | 2.7 | -93.9 | 283.0 | 0.0 |
| NO LATE CUT | 4.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 7.7 | -177.5 | 0.0 | 159.0 | 4.3 | -111.5 | 0.0 | 71.3 |
| OGRE LOADER SECOND SHOT | 3.0 | +8.1 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.7 | -71.5 | 0.0 | 45.0 | 5.7 | -150.6 | 0.0 | 35.7 |
| ONE OBJECTIVE FORMULA | 4.0 | -5.3 | 0.0 | 181.7 | 5.0 | -4.2 | 0.0 | 20.0 |
| ONE ROUTE | 4.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 1.3 | +12.8 | 153.3 | 0.0 |
| PATHS CROSS | 0.3 | +0.3 | 0.0 | 0.0 | 0.3 | -1.2 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -1.4 | 0.0 | 0.0 |
| PLAN RESULT | 44.3 | +522.9 | 89.7 | 1001.7 | 52.3 | +436.1 | 354.7 | 279.3 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 6.0 | -111.0 | 0.0 | 0.0 | 8.3 | -244.8 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.3 | -0.4 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | - | - | - | - | 0.7 | -0.3 | 0.0 | 0.0 |
| QUARTER ODDS | 9.3 | +727.7 | 143.3 | 312.0 | 15.3 | +1113.0 | 34.7 | 144.0 |
| REAL GROUND | 4.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | +9.2 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 3.0 | +168.5 | 0.0 | 20.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 7.3 | +23.9 | 0.0 | 22.7 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | -21.3 | 79.7 | 0.0 |
| REFORMS TO MEET IT | 1.0 | -21.1 | 0.0 | 0.0 | 0.7 | -6.4 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 1.7 | +64.7 | 0.0 | 0.0 |
| RISK BY ARC | 1.3 | +69.0 | 91.3 | 0.0 | 2.0 | -108.7 | 229.0 | 0.0 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 1.3 | -28.8 | 228.7 | 0.0 |
| RUN DOWN | - | - | - | - | 2.7 | -22.7 | 337.0 | 0.0 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +7.2 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.7 | -166.7 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SECOND LOOK | 0.3 | +14.3 | 20.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 1.0 | -1.0 | 0.0 | 45.0 | 3.3 | -106.6 | 0.0 | 15.0 |
| SET UP BY THE SET | 1.7 | -13.7 | 0.0 | 45.0 | 4.3 | +20.5 | 0.0 | 15.0 |
| SET UP TOGETHER | 0.7 | +0.9 | 0.0 | 0.0 | 0.7 | +7.4 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 18.3 | +0.0 | 0.0 | 369.0 | 9.7 | +0.0 | 0.0 | 35.7 |
| SHOOTS FROM THE BEST SPOT | 4.3 | +21.1 | 36.3 | 0.0 | 4.0 | +51.0 | 0.0 | 71.3 |
| SHOT RISK POINTS | 20.7 | -307.2 | 0.0 | 388.7 | 50.3 | -448.3 | 0.0 | 265.7 |
| SHOTS AFTER THE MOVES | 5.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 26.7 | +901.7 | 0.0 | 325.3 | 18.7 | +381.3 | 0.0 | 0.0 |
| SPELL WORTH | - | - | - | - | 4.0 | +50.0 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 4.7 | +0.0 | 0.0 | 0.0 | 10.7 | +0.0 | 0.0 | 66.3 |
| STAND AND SHOOT | - | - | - | - | 1.0 | -2.9 | 75.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 13.7 | +0.0 | 75.7 | 0.0 |
| STANDS STILL | 55.3 | +0.0 | 211.3 | 738.0 | 38.0 | +0.0 | 529.7 | 159.0 |
| STAY WORTH | 45.0 | +272.6 | 139.3 | 531.0 | 29.7 | +331.3 | 529.7 | 35.7 |
| STUBBORN BY POINTS | 0.3 | +2.7 | 0.0 | 0.0 | - | - | - | - |
| SURE REACH TOGETHER | 0.3 | +0.8 | 0.0 | 0.0 | 0.3 | +1.4 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 35.7 |
| THE ROW KEEPS ITS WAY | 3.7 | +0.0 | 0.0 | 75.7 | 4.0 | +0.0 | 0.0 | 11.3 |
| THE STEP BACK IS MADE | 2.7 | +0.0 | 0.0 | 75.7 | 2.7 | +0.0 | 0.0 | 11.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 44.3 | +0.0 | 0.0 | 684.0 | 56.7 | +0.0 | 0.0 | 175.3 |
| TIED UP BY THE SUM | 0.7 | +92.2 | 56.3 | 0.0 | 0.7 | +132.3 | 120.7 | 0.0 |
| TIME ON OUR SIDE | 48.7 | +644.6 | 0.0 | 650.0 | - | - | - | - |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -3.3 | 0.0 | 0.0 |
| WAR ENGINE JOBS | - | - | - | - | 4.0 | +0.0 | 454.0 | 0.0 |
| WEAPON BY POINTS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | - | - | - | - | 0.3 | -1.0 | 0.0 | 0.0 |
| WHO HITS BACK | 0.3 | +3.5 | 0.0 | 0.0 | 0.3 | +11.0 | 0.0 | 11.3 |
| WHOLE FIGHT DANGER | 2.3 | -174.9 | 0.0 | 259.3 | 0.3 | -0.7 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 2.0 | +10.8 | 0.0 | 0.0 | - | - | - | - |

### Rule changes: gs3-83c8646-p18

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 376 | 366 | 154 | 51.33 | +2812 | +18.3 |
| ARMY TABLE | 110 | 110 | 83 | 27.67 | +1146 | +13.8 |
| HOLDER ASSIGNMENT | 83 | 83 | 77 | 25.67 | +4035 | +52.4 |
| HIS SHOTS BY HIS RUN | 297 | 290 | 66 | 22.00 | +737 | +11.2 |
| SHOT RISK POINTS | 213 | 210 | 51 | 17.00 | +735 | +14.4 |
| GOAL WALK | 99 | 98 | 41 | 13.67 | +2431 | +59.3 |
| OFF BEST | 36 | 36 | 36 | 12.00 | -867 | -24.1 |
| DEPLOY BY FIGURES | 54 | 54 | 32 | 10.67 | +492 | +15.4 |
| HARD STAY DROPPED | 24 | 24 | 24 | 8.00 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 21 | 7.00 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 22 | 22 | 20 | 6.67 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| STAY WORTH | 224 | 195 | 19 | 6.33 | +130 | +6.8 |
| MEETS IN TIME | 22 | 22 | 18 | 6.00 | +1382 | +76.8 |
| PROMISE BY ITS OWN SUM | 43 | 43 | 18 | 6.00 | -1067 | -59.3 |
| TIME ON OUR SIDE | 146 | 111 | 15 | 5.00 | +111 | +7.4 |
| ARTILLERY RE-ROLL WEIGHED | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| CAST JOB | 22 | 22 | 14 | 4.67 | +43 | +3.0 |
| MOVE ORDER | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| QUARTER ODDS | 74 | 72 | 13 | 4.33 | +685 | +52.7 |
| FALLS SHORT | 105 | 88 | 11 | 3.67 | +103 | +9.4 |
| FIVE ACTION | 653 | 636 | 11 | 3.67 | +392 | +35.6 |
| CHARGE LOSSES | 121 | 118 | 10 | 3.33 | +416 | +41.6 |
| IDLE COST | 76 | 48 | 9 | 3.00 | +35 | +3.9 |
| OGRE LOADER SECOND SHOT | 9 | 9 | 9 | 3.00 | +24 | +2.7 |
| SHOOTS FROM THE BEST SPOT | 25 | 25 | 8 | 2.67 | +5 | +0.7 |
| FOUR ROUNDS | 13 | 12 | 7 | 2.33 | +237 | +33.9 |
| FOLLOW UP WEIGHED | 6 | 6 | 6 | 2.00 | +593 | +98.9 |
| GUN MASK | 8 | 8 | 6 | 2.00 | +289 | +48.1 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +326 | +54.3 |
| MOVE TO CHARGE COMPUTED | 19 | 16 | 6 | 2.00 | +167 | +27.8 |
| MISSILES IN THE MOVE | 37 | 27 | 5 | 1.67 | +52 | +10.3 |
| NEXT CHARGE BY LIST | 16 | 15 | 5 | 1.67 | +175 | +35.0 |
| RESERVE FALL BACK | 5 | 5 | 5 | 1.67 | +194 | +38.8 |
| SCOUT WAITS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| ADVANCE LANE KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +130 | +32.5 |
| TIED UP BY THE SUM | 4 | 4 | 4 | 1.33 | +130 | +32.5 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| COVER ONCE | 45 | 29 | 3 | 1.00 | +74 | +24.6 |
| HIS MOVE AND SHOT | 60 | 57 | 3 | 1.00 | +6 | +1.9 |
| MAX FOR POSITIONING | 14 | 13 | 3 | 1.00 | +0 | +0.0 |
| SET UP BY THE SET | 18 | 18 | 3 | 1.00 | -0 | -0.1 |
| SHOTS IN THE MOVE | 136 | 105 | 3 | 1.00 | +9 | +3.0 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 8 | 8 | 2 | 0.67 | -33 | -16.4 |
| HIS TURN DENIED | 7 | 7 | 2 | 0.67 | +44 | +22.2 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +57 | +28.3 |
| MISSILES NEXT TURN | 46 | 31 | 2 | 0.67 | +10 | +5.1 |
| ONE OBJECTIVE FORMULA | 27 | 24 | 2 | 0.67 | +71 | +35.6 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | -3 | -1.4 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -1 | -0.5 |
| RISK BY ARC | 10 | 9 | 2 | 0.67 | +37 | +18.3 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| SHOTS AFTER THE MOVES | 26 | 26 | 2 | 0.67 | +0 | +0.0 |
| WEAPON BY POINTS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +38 | +19.0 |
| WHOLE FIGHT DANGER | 8 | 8 | 2 | 0.67 | +37 | +18.5 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -64 | -63.8 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +32 | +31.9 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 9 | 8 | 1 | 0.33 | +5 | +4.7 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| HOLDS AMBUSHERS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +48 | +48.0 |
| LONG SHOT | 1 | 1 | 1 | 0.33 | +4 | +4.5 |
| MANOEUVRE | 12 | 12 | 1 | 0.33 | +6 | +5.9 |
| MARCH CHECK | 2 | 2 | 1 | 0.33 | +33 | +32.6 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -1 | -1.3 |
| NEARER NOT NEEDED | 33 | 30 | 1 | 0.33 | +71 | +71.1 |
| ONE FIGHT FORMULA | 31 | 16 | 1 | 0.33 | +10 | +9.6 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -4 | -4.1 |
| REDIRECT COUNTER | 9 | 8 | 1 | 0.33 | +49 | +48.9 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | -2 | -2.1 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +43 | +42.8 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +8 | +8.1 |
| SURE REACH TOGETHER | 2 | 2 | 1 | 0.33 | +3 | +3.1 |
| THE ROW IN ITS ORDER | 20 | 1 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -10 | -9.9 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLANNED TARGET | 28 | 28 | 0 | 0.00 | - | - |
| CHAFF IN THE MOVE | 3 | 3 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 6 | 6 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 77 | 77 | 0 | 0.00 | - | - |
| DEFENSIVE ARMY | 4 | 4 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| EVASIVE BY THE ODDS | 3 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 9 | 9 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 39 | not checked | - | - | - | - |
| FOOT FIRST | 89 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 20 | 20 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 11 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 11 | 11 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 60 | 59 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 20 | 19 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 22 | 19 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 14 | 12 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 31 | 27 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 116 | 116 | 0 | 0.00 | - | - |
| HONEST WORTH | 13 | 12 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 31 | 31 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 4 | 4 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 6 | 5 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 4 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 19 | 19 | 0 | 0.00 | - | - |
| NEAREST TO GOAL | 13 | 13 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 2 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 12 | 11 | 0 | 0.00 | - | - |
| NO LATE CUT | 16 | 16 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE ROUTE | 19 | 19 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 4 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 290 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 19 | 19 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 5 | 4 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 8 | 8 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 5 | 5 | 0 | 0.00 | - | - |
| SEARCH SPOT | 1 | 1 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 13 | 13 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 4 | 3 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 84 | not checked | - | - | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 46 | 41 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 41 | 38 | 0 | 0.00 | - | - |
| STANDS STILL | 280 | 268 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 15 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 23 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 16 | not checked | - | - | - | - |
| THE TABLE BINDS | 303 | not checked | - | - | - | - |
| WAITS AGAIN | 6 | 4 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 12 | 12 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 6 | 6 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p18

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 7.67 | 4.33 | 24.1 |
| PROMISE BY ITS OWN SUM | rule | 2.67 | 3.33 | 59.3 |
| ARMY TABLE | rule | 1.00 | 2.00 | 47.0 |
| HOLDER ASSIGNMENT | rule | 1.33 | 1.00 | 33.4 |
| CHARGE NOW FIRST | rule | 0.33 | 0.33 | 16.4 |
| BEST PRIZE | rule | - | 0.33 | 63.8 |
| JOINT CHARGE NOW | rule | - | 0.33 | 22.8 |
| MARCH OF THE TABLE | rule | 0.33 | - | 1.3 |
| PATHS CROSS | rule | - | 0.33 | 3.7 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 4.1 |
| REDIRECT WEIGHED | rule | - | 0.33 | 2.1 |
| SET UP BY THE SET | rule | - | 0.33 | 12.7 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 9.9 |

### Plans: gs3-83c8646-p18

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 100% | 57 | 67 | 118% |
| Mine | move | 27.7 | 96% | 1151 | 0 | 0% |
| Mine | shoot | 15.7 | 49% | 748 | 456 | 61% |
| Opponent | charge | 1.3 | 75% | 50 | 168 | 333% |
| Opponent | move | 41.7 | 97% | 1980 | 0 | 0% |
| Opponent | shoot | 8.0 | 54% | 440 | 268 | 61% |
| Opponent | support | 1.3 | 100% | 12 | 0 | 0% |

### Battle groups: gs3-83c8646-p18

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 3.0 | 22% | 100% | 0% | - | 50% | 0% | 0% | 50% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p18

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 12 | 10 (12) | 10 | 0 | 16 | 50% | 2.3 | 11 (5) | 12 (5) | 0 (1) | 8 (6) | 13 (5) |
| Mine | Clean-up | 2 | 83 (2) | 0 | 83 | 128 | 0% | 5.5 | - | - | 83 (2) | 83 (2) | - |
| Mine | Fast Hammer | 3 | 13 (3) | 0 | 13 | 64 | 33% | 2.0 | 0 (1) | 20 (2) | - | 18 (2) | 0 (1) |
| Mine | Hammer | 7 | 8 (7) | 8 | 0 | 29 | 29% | 2.0 | 0 (1) | 19 (3) | 0 (3) | 2 (5) | 22 (2) |
| Mine | Shooter | 6 | 82 (6) | 0 | 82 | 17 | 0% | 2.0 | 0 (1) | 188 (2) | 38 (3) | 98 (5) | 0 (1) |
| Mine | War machine | 8 | 0 (8) | 0 | 0 | 23 | 0% | 1.1 | 0 (1) | 0 (4) | 0 (3) | - | 0 (8) |
| Mine | Wizard | 2 | 28 (2) | 28 | 0 | 0 | 50% | 2.0 | - | 28 (2) | - | 28 (2) | - |
| Opponent | Chaff | 11 | 136 (11) | 0 | 136 | 48 | 36% | 3.3 | 165 (3) | 117 (1) | 129 (7) | 136 (11) | - |
| Opponent | Character | 6 | 41 (6) | 41 | 0 | 0 | 0% | 1.5 | 30 (2) | 102 (2) | 0 (2) | 74 (2) | 19 (4) |
| Opponent | Clean-up | 4 | 27 (4) | 0 | 27 | 24 | 50% | 1.0 | - | 56 (2) | 0 (2) | 36 (3) | 0 (1) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | 0 (1) | - | - | 0 (1) | - |
| Opponent | Hammer | 10 | 17 (10) | 17 | 0 | 6 | 30% | 2.6 | 18 (4) | 24 (4) | 0 (2) | 50 (2) | 7 (8) |
| Opponent | Holder | 1 | 76 (1) | 0 | 76 | 0 | 0% | 5.0 | - | 76 (1) | - | - | 76 (1) |
| Opponent | Shooter | 1 | 150 (1) | 0 | 150 | 0 | 0% | 1.0 | - | 150 (1) | - | 150 (1) | - |

### Charged fights: gs3-83c8646-p18

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 17 | 54 | 0.5 | 1.0 | 109 | 0 | +109 | 0 of 1 | 1 of 1 | - | +109 |
| Mine | Grand Cathay | 1 | 45 | 120 | 3.0 | 1.0 | 40 | 0 | +40 | 0 of 3 | 3 of 3 | - | +40 |
| **Mine** | all armies | 3 | 26 | 76 | 1.3 | 1.0 | 57 | 0 | +57 | 0 of 4 | 4 of 4 | - | +57 |
| Opponent | Ogre Kingdoms | 1 | 0 | 0 | 3.0 | 1.0 | 0 | 11 | -11 | 0 of 3 | 1 of 3 | - | -11 |
| Opponent | Vampire Counts | 1 | 0 | 518 | 2.0 | 1.0 | 259 | 0 | +259 | 0 of 2 | 2 of 2 | - | +259 |
| Opponent | Wood Elf Realms | 1 | 0 | 972 | 4.0 | 1.0 | 243 | 0 | +243 | 1 of 4 | 4 of 4 | - | +243 |
| **Opponent** | all armies | 3 | 0 | 497 | 3.0 | 1.0 | 166 | 4 | +162 | 1 of 9 | 7 of 9 | - | +162 |

### Effective charges: gs3-83c8646-p18

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +109) | 0 | 0% (0 of 1) |
| Mine | Grand Cathay | 3 | 0 | 0 | 0 | 0 | 2 (net +30) | 0 | 1 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 3 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 2 | 0% (0 of 1) |
| Opponent | Vampire Counts | 2 | 1 (net +221) | 0 | 0 | 0 | 1 (net +297) | 0 | 0 | 0% (0 of 2) |
| Opponent | Wood Elf Realms | 4 | 0 | 0 | 0 | 0 | 0 | 3 (net +152) | 1 | 0% (0 of 3) |

### Charged fights, damage counted: gs3-83c8646-p18

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 265 | 109 | +109 | 109 | 0 | +109 | +41.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 352 | 52 | +30 | 30 | 0 | +30 | +8.5 |
| Mine | No odds | 1 | 205 | 60 | +60 | 60 | 0 | +60 | +29.3 |
| Mine | All fights | 4 | 293 | 68 | +57 | 57 | 0 | +57 | +19.5 |
| Opponent | Long shot (under 50%) | 1 | 329 | 171 | +221 | 516 | 14 | +501 | +152.3 |
| Opponent | 50-54% | 1 | 90 | 104 | +0 | 16 | 18 | -2 | -2.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 239 | 145 | +152 | 173 | 0 | +173 | +72.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 500 | 135 | +297 | 297 | 28 | +270 | +53.9 |
| Opponent | No odds | 3 | 189 | 168 | +161 | 219 | 58 | +161 | +84.9 |
| Opponent | All fights | 9 | 245 | 150 | +162 | 223 | 26 | +197 | +80.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p18 | move | 22 | 7 (32%) | 6 (27%) | 3 (14%) | 12 (55%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0934, L1026 |
| Fistful of Laurels | Opponent | L0918 |
| Ring of Jet | Mine | L1026 |
| Twice-Blessed Armour | Mine | L1026 |

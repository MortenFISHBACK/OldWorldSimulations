# Doctrine scorecard: gs3-83c8646-p41

### Scorecard: gs3-83c8646-p41

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0729 | 3 | 1 | Mine | yes | 11 | 6 | 0 | 0 | 0 | 0 | 0 | 388 |
| L0729 | 3 | 1 | Opponent | no | 5 | 5 | 2 | 1 | 0 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 81 |
| L0819 | 3 | 1 | Opponent | no | 4 | 4 | 0 | 2 | 0 | 0 | 0 | 255 |
| L0835 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 471 |
| L0835 | 1 | 1 | Opponent | no | 0 | 5 | 1 | 5 | 0 | 0 | 0 | 140 |
| **Average** | | | Mine | 33% | 4.3 | 6.0 | 0.0 | 0.7 | 0.0 | 0.0 | 0.0 | 313.3 |
| **Average** | | | Opponent | 0% | 3.0 | 4.7 | 1.0 | 2.7 | 0.0 | 0.0 | 0.0 | 188.3 |

### KPIs: gs3-83c8646-p41

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 100% (16 of 16) | 0% (0 of 11) | 59% (16 of 27) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | - | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 100% (2 of 2); on the table 100% | 100% (2 of 2); on the table 100% | 100% (4 of 4); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (4 of 4); on the table 100% | 100% (2 of 2); on the table 100% | 100% (6 of 6); on the table 100% |
| Magic missiles tried each own turn | 50%+ | - | 33% (4 of 12) | 33% (4 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 33% (4 of 12) | 33% (4 of 12) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 33% (2 of 6) | 33% (2 of 6) |
| Points that never fought | lower | 65% (3902 of 5999) | 73% (4355 of 5999) | 69% (8257 of 11998) |
|   infantry points that never fought | lower | 58% (561 of 968) | 95% (1070 of 1130) | 78% (1631 of 2098) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 73% (22 of 30) | 63% (17 of 27) | 68% (39 of 57) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Bound items with another spell used |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 3); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 4); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 75% (4011 of 5378) | 60% (3431 of 5714) | 67% (7442 of 11092) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 2.7 (100%) | 2.7 (100%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.3 | 0.0 | 2.7 | 1.3 | 0.3 |
| not cast | 4.7 | 2.0 | 3.3 | 2.7 | 19.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (33%) | 0.0 (0%) | 2.7 (100%) | 0.0 (0%) |
| OFF THE TABLE: off the table or not arrived | 1.3 (29%) | 1.3 (67%) | 1.3 (40%) | 0.0 (0%) | 3.0 (15%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.3 (71%) | 0.0 (0%) | 2.0 (60%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.3 (83%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.0 a game | 0.7 a game | 1.3 a game |
| stood (cast and not dispelled) | 67% (4 of 6) | 50% (1 of 2) | 62% (5 of 8) |
| the unit moved after it | 0% (0 of 4) | 0% (0 of 1) | 0% (0 of 5) |
| it charged on its next turn | 0% (0 of 4) | 0% (0 of 1) | 0% (0 of 5) |
| the enemy charged it first | 0% (0 of 4) | 0% (0 of 1) | 0% (0 of 5) |
| it fought by the end of its next turn | 0% (0 of 4) | 0% (0 of 1) | 0% (0 of 5) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 4) | 0% (0 of 1) | 0% (0 of 5) |
| none of these (no charge, no fight, no charge escaped) | 100% (4 of 4) | 100% (1 of 1) | 100% (5 of 5) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 67% (68 of 102) | 70% (23 of 33) | 67% (91 of 135) |
|   cavalry | 71% (15 of 21) | 62% (8 of 13) | 68% (23 of 34) |
|   character | - | 38% (3 of 8) | 38% (3 of 8) |
|   chariot | 92% (11 of 12) | - | 92% (11 of 12) |
|   infantry | 50% (6 of 12) | 100% (12 of 12) | 75% (18 of 24) |
|   war machine | 63% (36 of 57) | - | 63% (36 of 57) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.3 (29%) | 1.3 (40%) | 4.7 (32%) |
| CHARGED: it charged | 0.0 (0%) | 0.7 (20%) | 0.7 (5%) |
| MOVED: a war machine that moved | 2.7 (24%) | 0.0 (0%) | 2.7 (18%) |
| NO TARGET IN RANGE | 1.3 (12%) | 1.0 (30%) | 2.3 (16%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (15%) | 0.3 (10%) | 2.0 (14%) |
| SHELTERED: the target was sheltered | 2.0 (18%) | 0.0 (0%) | 2.0 (14%) |
| OTHER BAR | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 12.3 | 6.3 | 65% | 7.8 pts | 96 pts |
| character | 1.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 3.7 | 2.3 | 45% | 12.4 pts | 45 pts |
| infantry | 6.0 | 2.0 | 78% | 7.1 pts | 42 pts |
| war machine | 12.0 | 15.0 | 56% | 20.7 pts | 248 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.3 | 2.0 | 1.2 |
| Charges that made contact a game | 0.3 | 2.0 | 1.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 1.00 declared, 1.00 contact (1 units) | 0.50 declared, 0.50 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.05 declared, 0.05 contact (22 units) | 0.20 declared, 0.20 contact (25 units) | 0.13 declared, 0.13 contact (47 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (4 of 8) | 50% (3 of 6) | - | 50% (7 of 14) |
| Character in a unit | 100% (6 of 6) | 100% (1 of 1) | - | 100% (7 of 7) |
| Character on its own | 100% (3 of 3) | 100% (1 of 1) | 60% (3 of 5) | 78% (7 of 9) |
| Chariot | - | 50% (1 of 2) | - | 50% (1 of 2) |
| Infantry | 50% (3 of 6) | 0% (0 of 1) | 100% (2 of 2) | 56% (5 of 9) |
| Monster | 0% (0 of 1) | - | - | 0% (0 of 1) |
| Monstrous | 100% (2 of 2) | 50% (1 of 2) | - | 75% (3 of 4) |
| War Machines | 82% (9 of 11) | - | - | 82% (9 of 11) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 3 | 100% (4 of 4); on the table 100% | - | 65% | 73% (22 of 30) | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 0% (0 of 3); 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (1 of 1); on the table 100% | 33% (4 of 12) | 94% | 88% (7 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (1 of 1); on the table 100% | - | 48% | 29% (2 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | - | 75% | 67% (8 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p41, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 33% (2) | 100% (1) | 43% (3) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.33 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.33 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p41

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | 100% (1 of 1) | 100% (4 of 4) |
| Strategy | Shoot objectives carried out (shot that target) | 57% (31 of 54) | 64% (7 of 11) |
| Strategy | Joined characters whose unit fought | 20% (1 of 5) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 33% (3 of 9) | 40% (2 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.7 | 2.7 |
| Movement | Points that never moved of their own | 313.3 | 188.3 |
| Movement | Fights charged into per game | 0.3 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 1 | 0 of 4 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 1, net +0 | 1 of 4, net +125 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 1 | 0 of 4 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 1 | 3 of 4, net +142 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.7 | 9.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 34% (11 of 32) | 44% (12 of 27) |
| Shooting | Points destroyed by shooting units | 158.3 | 15.0 |
| Shooting | War machine shots | 12.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 39% (14 of 36) | - |
| Shooting | Points destroyed by war machines | 54.0 | 0.0 |
| Magic | Magic missiles cast | - | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 0% (0 of 2) |
| Magic | Wounds caused by magic missiles | - | 0.3 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.0 / 0.0 / 0.0 | 0.7 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 0.0 | 358.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | -33 | +86 |
| Combat | Net per 100 charger points, damage counted | -17.3 | +40.6 |
| Combat | First round won (charged fights) | 100% | 67% |
| Combat | Net points per charged fight | +0 | +137 |
| Combat | Net points per supported fight / lone fight | - / +0 | - / +137 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 1 | 2 of 6 |
| Game | Points lost | 550.3 | 441.3 |
| Game | VP from objectives | 923.3 | 756.7 |
| Game | Lone holders (player turns) | 4.3 | 3.0 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -14 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 992
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p41

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 14.3 | +82.2 | 0.0 | 126.0 | 21.3 | +501.8 | 0.0 | 225.3 |
| ARTILLERY RE-ROLL WEIGHED | 4.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.3 | +0.0 | 85.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 11.3 | +110.4 | 648.3 | 85.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | - | - | - | - | 1.3 | +9.1 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 91.3 |
| CHAFF PASSED | 0.3 | -0.1 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.3 | +0.2 | 0.0 | 20.0 |
| CHARGE LOSSES | 10.0 | -744.0 | 0.0 | 584.0 | 21.3 | -946.3 | 0.0 | 846.3 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 36.7 | 0.0 | 0.3 | +0.0 | 36.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 5.3 | +0.0 | 0.0 | 0.0 | 13.0 | +0.0 | 0.0 | 193.3 |
| CONVEYANCE SEARCH | 2.0 | +218.1 | 0.0 | 0.0 | 0.7 | +81.8 | 41.7 | 182.7 |
| COVER ONCE | 8.0 | -353.0 | 0.0 | 41.7 | 9.0 | -1310.7 | 0.0 | 75.7 |
| DENIED BY THE FIGHT | 0.3 | -0.8 | 0.0 | 0.0 | 0.3 | -0.2 | 93.7 | 0.0 |
| DEPLOY BY FIGURES | 8.7 | -169.2 | 0.0 | 43.3 | 8.3 | -1.0 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -30.8 | 0.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.7 | +2.0 | 53.7 | 20.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 2.0 | +87.6 | 54.7 | 125.3 |
| EXACT ROUND | 0.3 | -7.6 | 0.0 | 0.0 | 1.0 | +14.7 | 142.3 | 20.0 |
| FALL BACK GOOD ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +22.8 | 105.7 | 20.0 |
| FALLS SHORT | - | - | - | - | 22.0 | +225.8 | 0.0 | 559.3 |
| FEATURE BUFFS | 0.7 | +4.1 | 0.0 | 109.3 | - | - | - | - |
| FIGHT TO THE END | - | - | - | - | 0.3 | +2.1 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 100.3 | +4982.7 | 2342.3 | 965.3 | 84.3 | +5315.4 | 293.3 | 1236.7 |
| FLANK NOT WEIGHED | 4.0 | +0.0 | 0.0 | 226.3 | 8.0 | +0.0 | 0.0 | 52.3 |
| FOCUS FIRE | - | - | - | - | 0.3 | +3.7 | 15.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FOOT FIRST | - | - | - | - | 33.0 | +0.0 | 0.0 | 596.0 |
| FOUR ROUNDS | 0.3 | +5.8 | 0.0 | 0.0 | 1.7 | +172.9 | 184.0 | 20.0 |
| FREED FROM HIS FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.3 | +3.3 | 0.0 | 96.0 | - | - | - | - |
| GIVES UP | - | - | - | - | 0.3 | -2.5 | 0.0 | 0.0 |
| GOAL WALK | 8.3 | +508.5 | 0.0 | 0.0 | 16.3 | +1249.8 | 0.0 | 101.7 |
| GROUND FLIERS | 0.3 | +9.4 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 3.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| GUN MASK | 7.7 | +143.5 | 0.0 | 109.3 | - | - | - | - |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 85.0 |
| HIS CHARGE BY HIS RUN | 6.7 | +0.0 | 0.0 | 348.7 | 11.0 | +0.0 | 0.0 | 299.0 |
| HIS CHARGE DENIED | 0.3 | +1.6 | 0.0 | 0.0 | 0.3 | +6.9 | 93.7 | 0.0 |
| HIS CHARGE LIST | 0.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 83.3 |
| HIS LEGAL MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.0 | -13.6 | 0.0 | 192.0 | 2.7 | -58.6 | 0.0 | 169.0 |
| HIS ONE QUARTER | 2.7 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 4.0 | +0.0 | 0.0 | 93.7 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 11.7 | +0.0 | 0.0 | 318.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.0 | +0.0 | 0.0 | 318.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 21.3 | +265.4 | 0.0 | 468.3 | 72.0 | +4449.0 | 0.0 | 1047.7 |
| HIS SHOTS BY HIS RUN | 16.3 | +179.2 | 0.0 | 604.3 | 49.3 | +1851.6 | 0.0 | 1114.3 |
| HIS TURN DENIED | - | - | - | - | 0.3 | +16.2 | 41.7 | 0.0 |
| HOLD ODDS | 17.0 | +0.0 | 0.0 | 292.0 | 14.7 | +0.0 | 0.0 | 243.7 |
| HOLDER ASSIGNMENT | 13.0 | +1056.8 | 0.0 | 91.3 | 10.3 | +892.2 | 0.0 | 131.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | - | - | - | - | 1.7 | -79.9 | 184.0 | 20.0 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +27.3 | 0.0 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.3 | +61.4 | 41.7 | 0.0 |
| IDLE COST | - | - | - | - | 14.3 | -248.3 | 0.0 | 117.3 |
| KEPT FROM ITS LAST STOP | 4.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 1.3 | +65.2 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 3.3 | +0.0 | 0.0 | 96.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.7 | +36.3 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 0.3 | +0.2 | 0.0 | 0.0 | 1.3 | -3.3 | 147.3 | 20.0 |
| MAKE SURE TOGETHER | 0.3 | +2.2 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 2.0 | +4.3 | 0.0 | 48.7 | 3.3 | -21.9 | 0.0 | 85.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 1.7 | +49.5 | 0.0 | 93.7 | 1.7 | +71.6 | 0.0 | 0.0 |
| MEETS IN TIME | 3.3 | +278.5 | 0.0 | 0.0 | 4.0 | +266.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | - | - | - | - | 2.0 | +35.5 | 0.0 | 105.3 |
| MISSILES NEXT TURN | - | - | - | - | 2.0 | +17.6 | 0.0 | 105.3 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 83.3 | 90.7 |
| MOVE SPELL IN RANGE | 1.7 | +30.5 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 2.0 | -55.4 | 189.7 | 0.0 | 0.3 | -6.1 | 0.0 | 91.3 |
| MOVE TO CHARGE COMPUTED | 0.3 | +15.9 | 0.0 | 93.7 | 4.0 | +403.3 | 0.0 | 0.0 |
| MOVES UNITS SPELL | - | - | - | - | 0.3 | +1.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 11.3 | +534.5 | 0.0 | 187.3 | 7.3 | +328.8 | 0.0 | 121.7 |
| NEAREST TO GOAL | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 0.3 | +15.9 | 0.0 | 93.7 | 3.3 | +158.9 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.7 | -11.4 | 18.3 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 0.3 | -12.9 | 0.0 | 0.0 | 1.7 | -86.6 | 184.0 | 20.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 3.3 | -2.4 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 5.3 | -142.2 | 0.0 | 41.7 | 3.7 | -111.0 | 0.0 | 42.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.0 | -86.7 | 0.0 | 93.7 | 7.7 | -214.4 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 4.3 | -87.2 | 0.0 | 91.3 | 4.7 | -52.7 | 0.0 | 76.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.7 | +14.7 | 130.3 | 0.0 |
| PLAN RESULT | 44.0 | +908.5 | 580.0 | 878.7 | 38.7 | +103.3 | 0.0 | 591.0 |
| PROMISE BY ITS OWN SUM | 1.7 | -24.0 | 0.0 | 0.0 | 4.7 | -71.4 | 0.0 | 0.0 |
| QUARTER ODDS | 24.0 | +2049.7 | 344.0 | 187.3 | 22.0 | +2732.8 | 172.0 | 236.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 2.0 | +6.5 | 0.0 | 0.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 0.3 | +9.9 | 0.0 | 12.0 | 1.3 | +40.9 | 0.0 | 18.3 |
| REDIRECT FOR A FRIEND IN REACH | 0.3 | +0.0 | 0.0 | 12.0 | 1.0 | +0.0 | 0.0 | 55.0 |
| REFORMS TO MEET IT | 0.3 | -0.4 | 0.0 | 93.7 | 1.3 | -16.8 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 12.0 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +33.8 | 0.0 | 38.0 |
| RISK BY ARC | - | - | - | - | 1.7 | -10.7 | 184.0 | 20.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.3 | -8.8 | 0.0 | 0.0 |
| RUN DOWN | 0.3 | -2.2 | 0.0 | 0.0 | 1.7 | -10.1 | 184.0 | 20.0 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +9.3 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +2.3 | 0.0 | 0.0 |
| SELF MOVE SPELL | - | - | - | - | 2.0 | -4.2 | 0.0 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 3.3 | -198.4 | 0.0 | 83.3 |
| SET UP BY THE SET | - | - | - | - | 4.0 | +133.4 | 0.0 | 83.3 |
| SET UP TOGETHER | 1.3 | +20.0 | 0.0 | 0.0 | 0.7 | +9.4 | 0.0 | 41.7 |
| SET-UP ANY TARGET | 1.0 | +139.1 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 18.0 | +0.0 | 0.0 | 85.0 | 4.0 | +0.0 | 0.0 | 42.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +55.6 | 152.0 | 0.0 | 0.3 | +5.3 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 6.7 | -152.6 | 0.0 | 109.3 | 33.3 | -815.0 | 0.0 | 938.0 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 27.0 | +1000.4 | 0.0 | 181.3 | 8.7 | +192.2 | 0.0 | 181.3 |
| SPELL SETS UP CHARGE | 1.0 | +139.1 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 2.7 | +16.7 | 0.0 | 0.0 | 0.7 | +3.7 | 182.7 | 182.7 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | -2.2 | 93.7 | 0.0 |
| SPOT AS THE GAME MOVES | 1.7 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 114.3 |
| STANDS FOR A REASON | - | - | - | - | 3.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 62.0 | +0.0 | 2342.3 | 277.3 | 30.0 | +0.0 | 109.3 | 390.0 |
| STAY WORTH | 51.0 | +160.6 | 2038.3 | 309.7 | 13.7 | +190.6 | 109.3 | 307.3 |
| STOPS | - | - | - | - | 0.3 | +11.1 | 41.7 | 0.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +0.2 | 96.0 | 0.0 |
| SUPPORT ADDS | 4.0 | +409.9 | 0.0 | 0.0 | 2.3 | +259.3 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 4.0 | +409.9 | 0.0 | 0.0 | 2.3 | +259.3 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +9.7 | 0.0 | 0.0 | - | - | - | - |
| SWIFTSTRIDE BY POINTS | 0.3 | -7.1 | 0.0 | 62.7 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 3.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 18.3 |
| THE ROW IN ITS ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 43.7 | +0.0 | 0.0 | 441.0 | 38.3 | +0.0 | 0.0 | 556.7 |
| TIED UP BY THE SUM | - | - | - | - | 0.3 | +23.9 | 36.7 | 0.0 |
| TIME ON OUR SIDE | 38.0 | +495.2 | 0.0 | 412.3 | - | - | - | - |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 93.7 | 3.7 | +0.0 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 4.0 | -583.1 | 0.0 | 474.7 | - | - | - | - |
| WOUNDS ON THE RANKS | 2.0 | +17.5 | 0.0 | 192.0 | 2.3 | +177.1 | 0.0 | 52.7 |

### Rule changes: gs3-83c8646-p41

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 280 | 272 | 75 | 25.00 | +1781 | +23.7 |
| ARMY TABLE | 107 | 107 | 65 | 21.67 | +1395 | +21.5 |
| HOLDER ASSIGNMENT | 70 | 70 | 63 | 21.00 | +4182 | +66.4 |
| HIS SHOTS BY HIS RUN | 197 | 195 | 61 | 20.33 | +1559 | +25.6 |
| OFF BEST | 27 | 27 | 27 | 9.00 | -760 | -28.1 |
| DEPLOY BY FIGURES | 51 | 51 | 24 | 8.00 | +302 | +12.6 |
| GOAL WALK | 74 | 74 | 24 | 8.00 | +1596 | +66.5 |
| SHOT RISK POINTS | 120 | 120 | 24 | 8.00 | +1365 | +56.9 |
| TIME ON OUR SIDE | 114 | 104 | 22 | 7.33 | +63 | +2.8 |
| THE TABLE AGAIN | 36 | 36 | 17 | 5.67 | +0 | +0.0 |
| QUARTER ODDS | 138 | 135 | 14 | 4.67 | +867 | +61.9 |
| ARTILLERY RE-ROLL WEIGHED | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| FIVE ACTION | 554 | 545 | 12 | 4.00 | +1196 | +99.7 |
| HARD STAY DROPPED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| CHARGE LOSSES | 94 | 94 | 10 | 3.33 | +291 | +29.1 |
| MEETS IN TIME | 22 | 22 | 9 | 3.00 | +621 | +69.0 |
| STAY WORTH | 194 | 176 | 9 | 3.00 | +172 | +19.1 |
| SUPPORT ADDS | 19 | 17 | 8 | 2.67 | +633 | +79.1 |
| SUPPORT WORKED OUT | 19 | 17 | 8 | 2.67 | +633 | +79.1 |
| SET UP BY THE SET | 12 | 12 | 7 | 2.33 | +400 | +57.1 |
| MOVE ORDER | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 23 | 23 | 6 | 2.00 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 12 | 12 | 6 | 2.00 | +12 | +2.1 |
| WOUNDS ON THE RANKS | 13 | 13 | 6 | 2.00 | +263 | +43.8 |
| IDLE COST | 43 | 28 | 5 | 1.67 | +29 | +5.8 |
| PROMISE BY ITS OWN SUM | 19 | 19 | 5 | 1.67 | -286 | -57.3 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +196 | +48.9 |
| NEXT CHARGE BY LIST | 11 | 10 | 4 | 1.33 | +202 | +50.6 |
| REDIRECT FOR A FRIEND IN REACH | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 5 | 5 | 4 | 1.33 | +10 | +2.6 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SEARCH SPOT | 4 | 4 | 3 | 1.00 | +28 | +9.3 |
| SHOTS IN THE MOVE | 107 | 78 | 3 | 1.00 | +94 | +31.3 |
| CANNON PLANNED TARGET | 34 | 34 | 2 | 0.67 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | -0 | -0.1 |
| CHARGE NOW FIRST | 3 | 3 | 2 | 0.67 | -48 | -24.2 |
| COVER ONCE | 51 | 30 | 2 | 0.67 | +4 | +1.9 |
| EVASIVE BY THE ODDS | 6 | 6 | 2 | 0.67 | +49 | +24.3 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +109 | +54.5 |
| MOVE TO CHARGE COMPUTED | 13 | 10 | 2 | 0.67 | +83 | +41.5 |
| NEARER NOT NEEDED | 56 | 56 | 2 | 0.67 | +48 | +23.8 |
| RANDOM MOVE BY FIGURES | 6 | 6 | 2 | 0.67 | +19 | +9.7 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHORT GUN FORWARD | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 15 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +1 | +0.7 |
| FALLS SHORT | 66 | 64 | 1 | 0.33 | +4 | +3.5 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +11 | +11.0 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +10 | +10.0 |
| HOLDS AMBUSHERS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| MANOEUVRE | 16 | 16 | 1 | 0.33 | +13 | +12.8 |
| MAX FOR POSITIONING | 10 | 9 | 1 | 0.33 | +5 | +4.6 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| ONE OBJECTIVE FORMULA | 27 | 20 | 1 | 0.33 | +40 | +40.1 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -0 | -0.5 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +101 | +101.3 |
| RISK BY ARC | 5 | 4 | 1 | 0.33 | +14 | +14.0 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +7 | +7.0 |
| SET UP TOGETHER | 6 | 5 | 1 | 0.33 | +20 | +19.7 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +1 | +0.6 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | -21 | -21.2 |
| TIED UP BY THE SUM | 1 | 1 | 1 | 0.33 | +52 | +51.7 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CASTING BLOCK | 4 | 4 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 4 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 55 | 53 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 8 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 2 | 2 | 0 | 0.00 | - | - |
| EXACT ROUND | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 4 | 3 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 36 | not checked | - | - | - | - |
| FOOT FIRST | 99 | not checked | - | - | - | - |
| FOUR ROUNDS | 6 | 5 | 0 | 0.00 | - | - |
| FREED FROM HIS FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 1 | not checked | - | - | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 9 | not checked | - | - | - | - |
| GUN MASK | 23 | 23 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 53 | 53 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 13 | 13 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 15 | 15 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 14 | 14 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 32 | 30 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 20 | 19 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 35 | 35 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 6 | 6 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HOLD ODDS | 95 | 95 | 0 | 0.00 | - | - |
| HONEST WORTH | 5 | 4 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 2 | 0 | 0.00 | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| KEPT FROM ITS LAST STOP | 15 | 15 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 5 | 4 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 6 | 4 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 6 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 5 | 3 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 7 | trace | - | - | - | - |
| NEAREST TO GOAL | 6 | 6 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 6 | 5 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 10 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 35 | 24 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 248 | trace | - | - | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 5 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 5 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | not checked | - | - | - | - |
| RUN DOWN | 6 | 5 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 10 | 10 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 3 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 66 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 3 | not checked | - | - | - | - |
| SPELL WORTH | 10 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 29 | 27 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 11 | 11 | 0 | 0.00 | - | - |
| STANDS STILL | 276 | 272 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 12 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 18 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 9 | not checked | - | - | - | - |
| THE TABLE BINDS | 246 | not checked | - | - | - | - |
| WAITS AGAIN | 15 | 11 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p41

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.33 | 2.33 | 25.8 |
| ARMY TABLE | rule | 3.00 | 1.00 | 42.9 |
| PROMISE BY ITS OWN SUM | rule | 0.67 | 1.00 | 57.3 |
| HOLDER ASSIGNMENT | rule | 1.00 | 0.33 | 35.7 |
| NO REASON | gate | - | 1.00 | 54.1 |
| CHARGE NOW FIRST | rule | 0.67 | - | 24.2 |
| AFTERMATH BAND | gate | - | 0.33 | 4.0 |
| SWIFTSTRIDE BY POINTS | rule | 0.33 | - | 21.2 |

### Plans: gs3-83c8646-p41

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | join | 0.3 | 100% | 4 | 0 | 0% |
| Mine | move | 27.7 | 93% | 1299 | 0 | 0% |
| Mine | shoot | 16.0 | 69% | 764 | 908 | 119% |
| Opponent | charge | 1.0 | 67% | 97 | 49 | 50% |
| Opponent | move | 35.0 | 93% | 1883 | 0 | 0% |
| Opponent | shoot | 2.7 | 12% | 256 | 55 | 21% |

### Packages: hunt the guns, gs3-83c8646-p41

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Opponent | 0.3 | 1 | 1 | - | - | - | - | - | - | - | 142 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 60 |
| Warriors of Chaos | 1.0 | 1 | 1 | - | - | - | - | - | - | - | 0 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 365 |

### Battle groups: gs3-83c8646-p41

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 100% | 100% | 0% | - | 100% | 0% | 0% | 0% | 0% |
| Opponent | REDIRECT COUNTER | 1.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p41

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 50% | 4.0 | - | - | 0 (2) | - | 0 (2) |
| Mine | Character | 12 | 0 (12) | 0 | 0 | 53 | 67% | 4.2 | 0 (7) | 0 (3) | 0 (1) | 0 (5) | 0 (6) |
| Mine | Clean-up | 2 | 69 (2) | 0 | 69 | 114 | 0% | 5.0 | 69 (2) | - | - | 218 (1) | 0 (1) |
| Mine | Fast Hammer | 4 | 68 (4) | 7 | 61 | 24 | 0% | 3.2 | 91 (2) | 46 (2) | - | 46 (2) | 91 (2) |
| Mine | Hammer | 4 | 8 (4) | 8 | 0 | 0 | 25% | 2.3 | - | 19 (2) | 0 (2) | 19 (2) | 0 (2) |
| Mine | Shooter | 4 | 136 (4) | 11 | 124 | 34 | 0% | 1.5 | - | 145 (2) | 117 (2) | 91 (1) | 159 (3) |
| Mine | War machine | 11 | 30 (11) | 30 | 0 | 27 | 0% | 1.4 | 0 (4) | 47 (7) | - | 92 (3) | 6 (8) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 3.5 | - | - | 0 (2) | - | 0 (2) |
| Opponent | Chaff | 3 | 64 (3) | 0 | 64 | 79 | 67% | 2.0 | 64 (3) | - | - | 64 (3) | - |
| Opponent | Character | 6 | 28 (6) | 28 | 0 | 0 | 50% | 3.3 | 17 (5) | - | 77 (1) | 32 (2) | 25 (4) |
| Opponent | Clean-up | 5 | 48 (5) | 0 | 48 | 60 | 60% | 1.5 | 94 (2) | 28 (2) | 0 (1) | 46 (4) | 53 (1) |
| Opponent | Fast Hammer | 4 | 12 (4) | 12 | 0 | 17 | 25% | 4.0 | 0 (1) | 30 (2) | 0 (1) | 0 (1) | 15 (3) |
| Opponent | Hammer | 8 | 85 (8) | 49 | 36 | 31 | 75% | 4.0 | 44 (3) | 138 (4) | 0 (1) | 119 (5) | 51 (3) |
| Opponent | Holder | 1 | 147 (1) | 147 | 0 | 0 | 0% | 4.0 | - | - | 147 (1) | 147 (1) | - |
| Opponent | Shooter | 2 | 78 (2) | 18 | 60 | 0 | 0% | 1.0 | - | 136 (1) | 32 (1) | 78 (2) | - |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 42 | 0% | 3.7 | 0 (2) | - | - | - | 0 (2) |

### Charged fights: gs3-83c8646-p41

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 3 | 212 | 0 | 0.3 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 36 | 2.0 | 1.0 | 18 | 0 | +18 | 1 of 2 | 1 of 2 | - | +18 |
| Opponent | Warriors of Chaos | 1 | 0 | 516 | 3.0 | 1.0 | 172 | 0 | +172 | 0 of 3 | 3 of 3 | - | +172 |
| Opponent | Wood Elf Realms | 1 | 45 | 270 | 1.0 | 1.0 | 270 | 0 | +270 | 1 of 1 | 0 of 1 | - | +270 |
| **Opponent** | all armies | 3 | 15 | 274 | 2.0 | 1.0 | 137 | 0 | +137 | 2 of 6 | 4 of 6 | - | +137 |

### Effective charges: gs3-83c8646-p41

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 1 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +36) | 1 | 0% (0 of 1) |
| Opponent | Warriors of Chaos | 3 | 0 | 0 | 1 (net +125) | 0 | 0 | 2 (net +196) | 0 | 33% (1 of 3) |

### Charged fights, damage counted: gs3-83c8646-p41

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 189 | 205 | +0 | 51 | 84 | -33 | -17.3 |
| Mine | All fights | 1 | 189 | 205 | +0 | 51 | 84 | -33 | -17.3 |
| Opponent | Effective (55-75%) | 1 | 85 | 125 | +125 | 125 | 0 | +125 | +147.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 210 | 109 | +142 | 142 | 13 | +129 | +61.4 |
| Opponent | No odds | 2 | 277 | 318 | +135 | 148 | 147 | +2 | +0.5 |
| Opponent | All fights | 6 | 212 | 181 | +137 | 141 | 56 | +86 | +40.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p41 | move | 24 | 2 (8%) | 2 (8%) | 0 (0%) | 22 (92%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Elixir of Power | Opponent | L0819 |
| Twice-Blessed Armour | Mine | L0729 |
| Witch Hunter's Ward | Mine | L0729, L0819, L0835 |

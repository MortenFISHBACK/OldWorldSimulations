# Doctrine scorecard: gs3-83c8646-p22

### Scorecard: gs3-83c8646-p22

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1827 | 3 | 1 | Mine | no | 4 | 6 | 1 | 3 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Opponent | no | 4 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 1 | 1 | 4 | 1 | 1 | 0 | 0 | 255 |
| L1927 | 1 | 1 | Opponent | no | 3 | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 1 | 3 | 2 | 0 | 0 | 210 |
| L2029 | 1 | 1 | Opponent | no | 4 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 1.7 | 3.5 | 2.0 | 2.3 | 1.0 | 0.0 | 0.0 | 155.0 |
| **Average** | | | Opponent | 0% | 3.7 | 2.0 | 3.7 | 2.7 | 0.0 | 0.0 | 0.0 | 0.0 |

### KPIs: gs3-83c8646-p22

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 13) | 0% (0 of 15) | 0% (0 of 28) |
| Winner chose to follow up after the loser gave ground |  | 100% (6 of 6); on the table 100% | 100% (3 of 3); on the table 100% | 100% (9 of 9); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (3 of 3); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 50% (2 of 4); on the table 75% | 50% (2 of 4); on the table 75% |
| Winner chose to follow up or pursue (all three) |  | 100% (6 of 6); on the table 100% | 80% (8 of 10); on the table 90% | 88% (14 of 16); on the table 94% |
| Magic missiles tried each own turn | 50%+ | 8% (2 of 24) | 33% (4 of 12) | 17% (6 of 36) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 15% (2 of 13) | 36% (4 of 11) | 25% (6 of 24) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 88% (7 of 8) | 50% (3 of 6) | 71% (10 of 14) |
| Points that never fought | lower | 37% (2236 of 5999) | 44% (2617 of 5999) | 40% (4853 of 11998) |
|   infantry points that never fought | lower | 64% (631 of 993) | 85% (673 of 793) | 73% (1304 of 1786) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 64% (14 of 22) | 58% (11 of 19) | 61% (25 of 41) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.7 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (1 of 2); 0.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 65% (3343 of 5151) | 53% (2614 of 4976) | 59% (5957 of 10127) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (9%) | 2.3 (88%) | 3.0 (30%) |
| MARCHED: its unit marched | 1.0 (14%) | 0.0 (0%) | 1.0 (10%) |
| IN COMBAT: engaged in combat | 2.0 (27%) | 0.3 (12%) | 2.3 (23%) |
| REAR RANK: in a rear rank | 0.7 (9%) | 0.0 (0%) | 0.7 (7%) |
| FLEEING: fleeing | 0.3 (5%) | 0.0 (0%) | 0.3 (3%) |
| GONE: slain | 1.3 (18%) | 0.0 (0%) | 1.3 (13%) |
| NOT OFFERED: not in the cast list | 1.3 (18%) | 0.0 (0%) | 1.3 (13%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 2.3 | 2.3 | 2.0 | 0.7 | 3.7 |
| not cast | 9.7 | 7.7 | 10.0 | 3.3 | 28.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 3.0 (30%) | 2.0 (60%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.0 (10%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (4%) | 2.3 (23%) | 0.0 (0%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (21%) | 2.0 (26%) | 0.7 (7%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.3 (3%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.7 (17%) | 1.0 (13%) | 1.3 (13%) | 0.0 (0%) | 2.7 (9%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.7 (9%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (40%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 1.3 (13%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 5.7 (59%) | 4.3 (57%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 22.0 (78%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 1.3 a game | 1.2 a game |
| stood (cast and not dispelled) | 33% (1 of 3) | 25% (1 of 4) | 29% (2 of 7) |
| the unit moved after it | 100% (1 of 1) | 100% (1 of 1) | 100% (2 of 2) |
| it charged on its next turn | 0% (0 of 1) | 100% (1 of 1) | 50% (1 of 2) |
| the enemy charged it first | 0% (0 of 1) | 0% (0 of 1) | 0% (0 of 2) |
| it fought by the end of its next turn | 0% (0 of 1) | 0% (0 of 1) | 0% (0 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 1) | 0% (0 of 1) | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | 100% (1 of 1) | 0% (0 of 1) | 50% (1 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 68% (44 of 65) | 33% (2 of 6) | 65% (46 of 71) |
|   cavalry | - | 100% (2 of 2) | 100% (2 of 2) |
|   character | 83% (5 of 6) | 0% (0 of 4) | 50% (5 of 10) |
|   chariot | 92% (11 of 12) | - | 92% (11 of 12) |
|   infantry | 53% (18 of 34) | - | 53% (18 of 34) |
|   monster | 77% (10 of 13) | - | 77% (10 of 13) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (29%) | 0.0 (0%) | 2.0 (24%) |
| CHARGED: it charged | 0.7 (10%) | 0.7 (50%) | 1.3 (16%) |
| IN COMBAT: it fought this turn or the last | 1.0 (14%) | 0.0 (0%) | 1.0 (12%) |
| NO TARGET IN RANGE | 1.3 (19%) | 0.3 (25%) | 1.7 (20%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (10%) | 0.3 (25%) | 1.0 (12%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (14%) | 0.0 (0%) | 1.0 (12%) |
| OTHER BAR | 0.3 (5%) | 0.0 (0%) | 0.3 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 0.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| character | 2.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 4.0 | 2.7 | 67% | 23.4 pts | 93 pts |
| infantry | 6.0 | 3.3 | 50% | 16.4 pts | 98 pts |
| monster | 3.3 | 0.7 | 90% | 0.6 pts | 2 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 7.3 | 5.5 |
| Charges that made contact a game | 2.0 | 5.0 | 3.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.50 declared, 0.50 contact (2 units) | 0.33 declared, 0.33 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.39 declared, 0.21 contact (28 units) | 0.81 declared, 0.54 contact (26 units) | 0.59 declared, 0.37 contact (54 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 75% (3 of 4) | 67% (2 of 3) | 50% (1 of 2) | 67% (6 of 9) |
| Character in a unit | 67% (4 of 6) | 0% (0 of 1) | - | 57% (4 of 7) |
| Character on its own | 100% (2 of 2) | 100% (2 of 2) | 67% (4 of 6) | 80% (8 of 10) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 75% (3 of 4) | 0% (0 of 1) | - | 60% (3 of 5) |
| Monster | 0% (0 of 1) | 67% (2 of 3) | - | 50% (2 of 4) |
| Monstrous | - | 25% (1 of 4) | - | 25% (1 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ogre Kingdoms | 1 | 100% (3 of 3); on the table 100% | 0% (0 of 6) | 42% | 29% (2 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (3 of 3); on the table 100% | 0% (0 of 12) | 16% | 75% (6 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | - | 33% (2 of 6) | 54% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 2 | 88% (7 of 8); on the table 100% | 33% (4 of 12) | 42% | 67% (8 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 50% (1 of 2); on the table 50% | - | 46% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p22, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 67% (4) | 33% (2) | 50% (6) |
| ...free all their last turn and able to turn (per game) | 1.33 | 0.33 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 1.33 | 0.33 | 1.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.33 | 0.33 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p22

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.7 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 50% (2 of 4) | 41% (9 of 22) |
| Strategy | Shoot objectives carried out (shot that target) | 12% (2 of 17) | - |
| Strategy | Support requests answered (helper made contact too) | - | 75% (3 of 4) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Joined characters whose unit fought | 80% (4 of 5) | 25% (1 of 4) |
| Strategy | Lone characters that fought | 60% (3 of 5) | 60% (6 of 10) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.3 | 2.7 |
| Movement | Points that never moved of their own | 155.0 | 0.0 |
| Movement | Fights charged into per game | 2.0 | 4.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 2, net -210 | 1 of 11, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | 2 of 11, net -30 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 2, net +436 | 0 of 11 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 2 | 4 of 11, net +59 |
| Shooting | Shots by shooting units (incl. breath weapons) | 15.3 | 1.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 41% (19 of 46) | 0% (0 of 4) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 20.0 | 0.0 |
| Magic | Magic missiles cast | 0.7 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 2) | 0% (0 of 4) |
| Magic | Wounds caused by magic missiles | 1.3 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.0 / 1.7 / 0.0 | 0.7 / 0.0 / 0.7 / 0.3 |
| Combat | Points destroyed in combat | 306.0 | 508.3 |
| Combat | Points run down | 0.0 | 36.7 |
| Combat | Net points per charged fight, damage counted | -11 | +84 |
| Combat | Net per 100 charger points, damage counted | -6.2 | +40.1 |
| Combat | First round won (charged fights) | 33% | 50% |
| Combat | Net points per charged fight | -14 | +67 |
| Combat | Net points per supported fight / lone fight | - / -14 | +109 / +53 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 6 | 6 of 12 |
| Game | Points lost | 715.0 | 351.0 |
| Game | VP from objectives | 553.3 | 966.7 |
| Game | Lone holders (player turns) | 1.7 | 3.7 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -898 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 1066
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p22

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +31.7 | 0.0 | 0.0 |
| ARMY TABLE | 31.3 | +36.7 | 0.0 | 94.3 | 15.3 | +387.4 | 0.0 | 0.0 |
| ASSAILMENT BY POINTS | 0.3 | +0.4 | 0.0 | 108.7 | 1.0 | +12.8 | 0.0 | 63.3 |
| CASTER AWAY FROM SCREEN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 0.7 | +40.7 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 63.3 |
| CASTS FROM BEHIND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.7 | +46.3 | 0.0 | 0.0 | 2.0 | +130.6 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | -4.2 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 1.3 | +6.7 | 0.0 | 0.0 | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -21.1 | 180.0 | 0.0 |
| CHAMPION TAKES THE CHALLENGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 8.3 | -891.1 | 0.0 | 438.3 | 11.3 | -401.3 | 0.0 | 186.0 |
| CHARGE NOW FIRST | - | - | - | - | 2.0 | +0.0 | 258.3 | 62.0 |
| CLOSES ON WHAT IT BEATS | 9.0 | +0.0 | 0.0 | 360.0 | 22.7 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 1.0 | +0.0 | 62.0 | 186.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.7 | +51.2 | 0.0 | 0.0 | 1.3 | +11.2 | 63.3 | 63.3 |
| COVER ONCE | 10.7 | -841.9 | 0.0 | 0.0 | 3.3 | -132.1 | 0.0 | 124.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -1.4 | 180.0 | 62.0 |
| DEPLOY BY FIGURES | 8.0 | -112.9 | 0.0 | 0.0 | 7.0 | +58.5 | 0.0 | 62.0 |
| EDGE GIVE GROUND | 0.3 | +11.8 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 0.3 | +0.6 | 0.0 | 0.0 | 3.0 | +22.8 | 91.7 | 242.7 |
| FALL BACK GOOD ORDER | - | - | - | - | 5.7 | +16.6 | 451.7 | 259.3 |
| FALLS SHORT | - | - | - | - | 18.0 | +134.5 | 0.0 | 62.0 |
| FEATURE BUFFS | 2.3 | +41.8 | 0.0 | 0.0 | 0.7 | +0.7 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 2.3 | +37.0 | 78.3 | 115.3 |
| FIVE ACTION | 85.3 | +7319.3 | 130.0 | 959.0 | 96.7 | +8262.2 | 631.7 | 837.3 |
| FLANK NOT WEIGHED | 11.7 | +0.0 | 0.0 | 180.0 | 3.7 | +0.0 | 0.0 | 25.0 |
| FOLLOW UP WEIGHED | 0.7 | +45.5 | 0.0 | 0.0 | 1.0 | +172.0 | 0.0 | 62.0 |
| FOOT FIRST | - | - | - | - | 35.0 | +0.0 | 0.0 | 310.0 |
| FOUR ROUNDS | 1.7 | +13.3 | 45.0 | 0.0 | 7.3 | +295.4 | 451.7 | 322.7 |
| FREED FROM HIS FIGHT | 3.3 | +0.0 | 0.0 | 85.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.7 | -46.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -1.2 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 13.7 | +1575.4 | 0.0 | 85.0 | 8.0 | +1149.5 | 0.0 | 0.0 |
| GUN FIGURES | 6.0 | +0.1 | 0.0 | 21.7 | - | - | - | - |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HE REFORMS ONCE FREED | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | - | - | - | - | 0.7 | +0.0 | 0.0 | 20.0 |
| HIS CHARGE BY HIS RUN | 6.0 | +0.0 | 0.0 | 438.3 | 5.3 | +0.0 | 0.0 | 186.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.7 | +57.0 | 0.0 | 62.0 |
| HIS CHARGE LIST | 8.0 | +0.0 | 0.0 | 11.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 4.0 | +0.0 | 0.0 | 116.7 | 5.7 | +0.0 | 0.0 | 124.0 |
| HIS MOVE AND SHOT | 2.0 | -13.4 | 0.0 | 0.0 | 8.0 | -110.6 | 0.0 | 0.0 |
| HIS ONE QUARTER | 3.0 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 125.3 |
| HIS OWN BEST MOVE | 4.7 | +0.0 | 0.0 | 116.7 | 11.3 | +0.0 | 0.0 | 124.0 |
| HIS RANDOM MOVE | 14.3 | +0.0 | 0.0 | 426.7 | 5.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVER COMES | 2.7 | +0.0 | 0.0 | 360.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 12.3 | +141.8 | 0.0 | 46.0 | 36.0 | +669.6 | 0.0 | 328.7 |
| HIS SHOTS BY HIS RUN | 13.7 | +103.8 | 0.0 | 478.0 | 36.7 | +747.3 | 0.0 | 326.0 |
| HIS TURN DENIED | - | - | - | - | 1.3 | +25.1 | 360.0 | 33.3 |
| HOLD ODDS | 21.7 | +0.0 | 0.0 | 103.3 | 12.7 | +0.0 | 0.0 | 40.0 |
| HOLDER ASSIGNMENT | 12.7 | +987.4 | 0.0 | 103.3 | 8.0 | +970.5 | 0.0 | 40.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -12.0 | 45.0 | 0.0 | 6.0 | -114.7 | 451.7 | 259.3 |
| IDLE COST | - | - | - | - | 21.0 | -258.6 | 0.0 | 90.0 |
| JOINT CHARGE NOW | - | - | - | - | 2.7 | +453.5 | 0.0 | 145.3 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.3 | -16.3 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 2.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +9.3 | 0.0 | 0.0 | 1.3 | +47.7 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 3.7 | +0.0 | 144.0 | 224.3 | 3.3 | +0.0 | 280.0 | 20.0 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 20.0 |
| LONE WIZARD KEPT IN | 0.3 | +7.9 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 0.3 | +2.3 | 25.0 | 0.0 | 1.0 | +1.0 | 0.0 | 100.0 |
| LOST AFTER ESCAPE | 0.3 | -0.2 | 0.0 | 0.0 | 3.3 | +11.8 | 271.7 | 180.7 |
| MANOEUVRE | 2.7 | +64.5 | 0.0 | 13.3 | 1.7 | +18.3 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.3 | +241.7 | 0.0 | 13.3 | 1.3 | +6.0 | 0.0 | 25.0 |
| MEETS IN TIME | 5.0 | +381.2 | 0.0 | 0.0 | 3.3 | +411.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.7 | +134.2 | 0.0 | 180.0 | 1.7 | +3.8 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 3.3 | +61.6 | 0.0 | 180.0 | 2.7 | +3.6 | 0.0 | 63.3 |
| MOVE ORDER | 3.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.3 | -2.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 3.0 | +45.0 | 0.0 | 139.3 | 15.0 | +1578.6 | 0.0 | 273.0 |
| MOVES UNITS SPELL | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 11.0 | +543.2 | 0.0 | 25.0 | 4.0 | +161.5 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 2.7 | +35.8 | 0.0 | 22.7 | 9.0 | +1069.7 | 0.0 | 186.0 |
| NEXT OBJECTIVE NEARER | 1.7 | -38.9 | 0.0 | 11.7 | - | - | - | - |
| NO DOUBLE ROUNDS | 1.3 | -2.3 | 45.0 | 0.0 | 5.0 | -311.2 | 451.7 | 226.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.7 | -0.5 | 0.0 | 0.0 | 2.0 | -0.7 | 0.0 | 0.0 |
| OFF BEST | 4.0 | -136.6 | 0.0 | 23.0 | 3.0 | -119.9 | 0.0 | 0.0 |
| ONE CHALLENGE TEST | - | - | - | - | 0.3 | -21.1 | 180.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 62.0 |
| ONE FIGHT FORMULA | 1.7 | -8.0 | 0.0 | 11.3 | 7.7 | -170.3 | 0.0 | 149.0 |
| ONE JOINT FIGURE | - | - | - | - | 1.0 | -35.7 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 5.3 | +37.7 | 0.0 | 13.3 | 3.0 | +116.0 | 0.0 | 20.0 |
| ONE PROMISE A TARGET | - | - | - | - | 1.3 | -12.8 | 0.0 | 124.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.3 | +11.6 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.3 | +3.2 | 25.0 | 0.0 | 1.3 | +15.1 | 180.0 | 62.0 |
| PERIAPT WORTH | 0.3 | +18.1 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.3 | -9.2 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 40.7 | +274.3 | 70.0 | 1036.3 | 47.3 | +423.4 | 180.0 | 558.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 11.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 3.0 | -9.2 | 0.0 | 116.7 | 13.0 | -415.4 | 0.0 | 87.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | -0.6 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -0.5 | 0.0 | 0.0 | 0.3 | -46.6 | 0.0 | 0.0 |
| QUARTER ODDS | 20.0 | +1954.8 | 40.0 | 23.3 | 29.7 | +3551.4 | 373.3 | 534.7 |
| RANDOM MOVE BY FIGURES | 2.7 | +85.5 | 0.0 | 70.0 | 2.0 | +23.0 | 0.0 | 0.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 1.0 | +94.4 | 0.0 | 0.0 |
| REDIRECT COUNTER | 4.0 | +162.8 | 0.0 | 24.7 | 3.0 | +257.0 | 0.0 | 25.0 |
| REDIRECT FOR A FRIEND IN REACH | 6.7 | +0.0 | 0.0 | 84.3 | 4.3 | +153.4 | 0.0 | 25.0 |
| REFORMS TO MEET IT | 2.0 | -70.0 | 0.0 | 22.7 | 4.3 | -139.7 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| RISK BY ARC | 0.7 | -4.0 | 25.0 | 0.0 | 6.3 | +21.0 | 373.3 | 322.7 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 3.0 | -33.7 | 78.3 | 95.3 |
| RUN DOWN | 0.3 | -2.6 | 0.0 | 0.0 | 4.0 | -46.4 | 271.7 | 226.0 |
| SAFER THAN THE JOB | - | - | - | - | 0.3 | +3.9 | 0.0 | 0.0 |
| SCOUT SPOT | 0.7 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -68.4 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +3.2 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SELF MOVE SPELL | 1.0 | -2.1 | 0.0 | 217.3 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 1.0 | -76.3 | 0.0 | 62.0 |
| SET UP BY THE SET | 2.0 | +67.3 | 25.0 | 22.7 | 3.7 | +137.7 | 0.0 | 62.0 |
| SHOOTERS ON THE TABLE | 4.3 | +0.0 | 0.0 | 13.3 | 1.7 | +0.0 | 0.0 | 40.0 |
| SHOOTS FROM THE BEST SPOT | 5.7 | +376.9 | 20.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 0.7 | -8.5 | 45.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 5.7 | -12.4 | 0.0 | 25.0 | 25.3 | -181.4 | 0.0 | 248.0 |
| SHOTS AFTER THE MOVES | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 12.0 | +235.6 | 0.0 | 35.0 | 0.7 | +2.3 | 0.0 | 0.0 |
| SPELL WORTH | 1.0 | +23.2 | 180.0 | 180.0 | 0.7 | +5.4 | 40.0 | 40.0 |
| SPOT AS THE GAME MOVES | 12.7 | +0.0 | 0.0 | 375.0 | 11.3 | +0.0 | 0.0 | 149.0 |
| STAND AND SHOOT | - | - | - | - | 1.3 | -4.6 | 13.3 | 103.3 |
| STANDS FOR A REASON | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 28.3 | +0.0 | 85.0 | 214.0 | 19.3 | +0.0 | 180.0 | 166.7 |
| STAY WORTH | 7.7 | +40.5 | 0.0 | 21.7 | 0.7 | +1.5 | 0.0 | 0.0 |
| STRIKE BY THE ODDS | 2.0 | +11.3 | 0.0 | 0.0 | 1.0 | +1.3 | 0.0 | 62.0 |
| STUCK PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 3.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 19.3 | +1697.4 | 0.0 | 95.0 | 4.7 | +297.4 | 0.0 | 62.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 19.3 | +1697.4 | 0.0 | 95.0 | 4.7 | +297.4 | 0.0 | 62.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +0.4 | 0.0 | 25.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.7 | -46.6 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 8.3 | +0.0 | 0.0 | 180.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.3 | +0.0 | 0.0 | 21.7 | 4.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 2.7 | +0.0 | 0.0 | 35.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 38.3 | +0.0 | 0.0 | 238.0 | 46.0 | +0.0 | 0.0 | 297.3 |
| TIED UP BY THE SUM | - | - | - | - | 1.3 | +133.0 | 78.3 | 62.0 |
| TIME ON OUR SIDE | 36.3 | +403.2 | 0.0 | 142.7 | - | - | - | - |
| WAITS AGAIN | 2.3 | +0.0 | 0.0 | 139.3 | 2.0 | +0.0 | 0.0 | 25.0 |
| WAR ENGINE JOBS | 3.3 | +0.0 | 65.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | - | - | - | - | 1.3 | -154.1 | 0.0 | 0.0 |
| WHO FIGHTS | 0.3 | -1.4 | 0.0 | 0.0 | 0.3 | -2.6 | 13.3 | 20.0 |
| WHO HITS BACK | 0.3 | +4.6 | 0.0 | 0.0 | 1.0 | +32.0 | 0.0 | 25.0 |
| WHOLE FIGHT | - | - | - | - | 0.7 | +2.5 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 6.3 | -854.8 | 0.0 | 438.3 | 0.3 | -10.4 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 0.3 | +2.6 | 0.0 | 0.0 | 0.7 | +20.5 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p22

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 140 | 140 | 85 | 28.33 | +597 | +7.0 |
| HOLDER ASSIGNMENT | 62 | 62 | 56 | 18.67 | +3439 | +61.4 |
| FIVE ACTION | 546 | 543 | 40 | 13.33 | +3181 | +79.5 |
| REDIRECT FOR A FRIEND IN REACH | 33 | 33 | 33 | 11.00 | +267 | +8.1 |
| SUPPORT ADDS | 72 | 71 | 33 | 11.00 | +1761 | +53.4 |
| SUPPORT WORKED OUT | 72 | 71 | 33 | 11.00 | +1761 | +53.4 |
| MOVE TO CHARGE COMPUTED | 54 | 52 | 28 | 9.33 | +988 | +35.3 |
| DEPLOY BY FIGURES | 45 | 45 | 26 | 8.67 | +294 | +11.3 |
| THE TABLE AGAIN | 36 | 36 | 26 | 8.67 | +0 | +0.0 |
| HIS SHOT LIST | 145 | 143 | 23 | 7.67 | +214 | +9.3 |
| HIS SHOTS BY HIS RUN | 151 | 151 | 21 | 7.00 | +416 | +19.8 |
| LEGAL CHARGES ONLY | 21 | 21 | 21 | 7.00 | +0 | +0.0 |
| OFF BEST | 21 | 21 | 21 | 7.00 | -770 | -36.6 |
| NEXT CHARGE BY LIST | 35 | 35 | 17 | 5.67 | +998 | +58.7 |
| PROMISE BY ITS OWN SUM | 48 | 48 | 17 | 5.67 | -1274 | -74.9 |
| GOAL WALK | 65 | 65 | 16 | 5.33 | +1698 | +106.2 |
| QUARTER ODDS | 149 | 148 | 16 | 5.33 | +820 | +51.2 |
| MOVE ORDER | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| IDLE COST | 63 | 46 | 13 | 4.33 | +74 | +5.7 |
| RANDOM MOVE BY FIGURES | 14 | 14 | 10 | 3.33 | +325 | +32.5 |
| SHOOTS FROM THE BEST SPOT | 17 | 17 | 10 | 3.33 | +77 | +7.7 |
| STRIKE BY THE ODDS | 9 | 9 | 9 | 3.00 | +38 | +4.2 |
| JOINT CHARGE NOW | 8 | 8 | 8 | 2.67 | +1361 | +170.1 |
| MAX FOR POSITIONING | 17 | 16 | 8 | 2.67 | +1 | +0.1 |
| FOUR ROUNDS | 27 | 27 | 7 | 2.33 | +307 | +43.9 |
| MEETS IN TIME | 25 | 25 | 7 | 2.33 | +441 | +63.0 |
| RISK BY ARC | 21 | 21 | 7 | 2.33 | +94 | +13.5 |
| TIME ON OUR SIDE | 109 | 88 | 7 | 2.33 | +34 | +4.9 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +653 | +130.6 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +171 | +34.2 |
| MANOEUVRE | 13 | 13 | 5 | 1.67 | +294 | +58.8 |
| ADVANCE LANE KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| ASSAILMENT BY POINTS | 4 | 4 | 4 | 1.33 | +39 | +9.8 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +20 | +5.1 |
| CHARGE LOSSES | 59 | 59 | 4 | 1.33 | +288 | +71.9 |
| COMBAT PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| HARD STAY DROPPED | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| NEARER NOT NEEDED | 45 | 40 | 4 | 1.33 | +131 | +32.8 |
| ONE PROMISE A TARGET | 4 | 4 | 4 | 1.33 | -38 | -9.6 |
| SET UP BY THE SET | 17 | 17 | 4 | 1.33 | +22 | +5.4 |
| SHOT RISK POINTS | 93 | 92 | 4 | 1.33 | +80 | +19.9 |
| WHO HITS BACK | 4 | 4 | 4 | 1.33 | +63 | +15.6 |
| WHOLE FIGHT DANGER | 20 | 20 | 4 | 1.33 | +386 | +96.5 |
| EXACT ROUND | 10 | 10 | 3 | 1.00 | +50 | +16.5 |
| REDIRECT COUNTER | 21 | 18 | 3 | 1.00 | +150 | +50.1 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 41 | 3 | 3 | 1.00 | +0 | +0.0 |
| TIED UP BY THE SUM | 4 | 4 | 3 | 1.00 | +173 | +57.6 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CASTING BLOCK | 2 | 2 | 2 | 0.67 | +54 | +27.0 |
| CHAFF IN THE MOVE | 8 | 8 | 2 | 0.67 | +0 | +0.0 |
| COVER ONCE | 42 | 20 | 2 | 0.67 | +54 | +27.2 |
| REDIRECT BY WHAT IT STOPS | 3 | 3 | 2 | 0.67 | +267 | +133.4 |
| REFUSING RETIRES | 4 | 4 | 2 | 0.67 | -35 | -17.5 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 3 | 3 | 2 | 0.67 | +42 | +20.8 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +95 | +95.1 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -13 | -12.7 |
| CHARGE NOW FIRST | 6 | 6 | 1 | 0.33 | -21 | -20.6 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +27 | +26.8 |
| FALL BACK GOOD ORDER | 17 | 17 | 1 | 0.33 | +0 | +0.0 |
| FIGHT TO THE END | 7 | 7 | 1 | 0.33 | +16 | +16.3 |
| HIS TURN DENIED | 4 | 4 | 1 | 0.33 | +6 | +6.3 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +24 | +23.8 |
| LONG SHOT | 4 | 4 | 1 | 0.33 | +0 | +0.0 |
| LOST AFTER ESCAPE | 11 | 11 | 1 | 0.33 | +0 | +0.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| NO DOUBLE ROUNDS | 19 | 19 | 1 | 0.33 | +4 | +4.0 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +4 | +4.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +54 | +54.4 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -28 | -27.5 |
| PROMISE KNOWS THE FIGHT | 2 | 2 | 1 | 0.33 | -2 | -1.8 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.33 | +12 | +11.7 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +10 | +9.7 |
| SHOTS IN THE MOVE | 38 | 24 | 1 | 0.33 | +3 | +2.9 |
| STAY WORTH | 25 | 21 | 1 | 0.33 | +1 | +0.9 |
| SUPPORT NARROWED | 3 | 3 | 1 | 0.33 | -33 | -33.4 |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 95 | 94 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 6 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| FALLS SHORT | 54 | 43 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 9 | 9 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 46 | not checked | - | - | - | - |
| FOOT FIRST | 105 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 16 | 16 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 18 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 6 | 6 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 34 | 34 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 26 | 26 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 29 | 29 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 30 | 30 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 33 | 32 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 48 | 47 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 60 | 60 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 11 | 11 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 103 | 103 | 0 | 0.00 | - | - |
| HONEST WORTH | 21 | 21 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 11 | 11 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 13 | 8 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 18 | 12 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 1 | trace | - | - | - | - |
| NEXT OBJECTIVE NEARER | 5 | 4 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 8 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 28 | 11 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 3 | 3 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 25 | 16 | 0 | 0.00 | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | not checked | - | - | - | - |
| OVERRUNS AWAY | 5 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 264 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 19 | 19 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 9 | 9 | 0 | 0.00 | - | - |
| RUN DOWN | 13 | 13 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 3 | not checked | - | - | - | - |
| SET CREDITED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 18 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 6 | 6 | 0 | 0.00 | - | - |
| SPELL WORTH | 5 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 72 | 61 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 2 | 2 | 0 | 0.00 | - | - |
| STANDS STILL | 143 | 143 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 9 | 9 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 10 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 3 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 20 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 20 | not checked | - | - | - | - |
| THE TABLE BINDS | 253 | not checked | - | - | - | - |
| WAITS AGAIN | 13 | 13 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 10 | 10 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 4 | 4 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p22

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| ARMY TABLE | rule | 6.33 | 0.67 | 96.5 |
| JOB FIRST | gate | 3.67 | 2.67 | 39.8 |
| PROMISE BY ITS OWN SUM | rule | 0.33 | 5.33 | 74.9 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.33 | 33.6 |
| ONE PROMISE A TARGET | rule | - | 0.67 | 37.6 |
| REFUSING RETIRES | rule | - | 0.67 | 17.5 |
| SET UP BY THE SET | rule | - | 0.67 | 12.9 |
| CHAFF PASSED | rule | 0.33 | - | 12.7 |
| CHARGE NOW FIRST | rule | - | 0.33 | 20.6 |
| FIGHT ORDER BAND | gate | - | 0.33 | 1.2 |
| JOINT CHARGE NOW | rule | - | 0.33 | 112.5 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 27.5 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | - | 1.8 |
| RULE SWITCHED OFF | gate | 0.33 | - | 11.7 |
| SUPPORT NARROWED | rule | - | 0.33 | 33.4 |

### Plans: gs3-83c8646-p22

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 33% | 61 | 25 | 41% |
| Mine | move | 34.7 | 88% | 2618 | 0 | 0% |
| Mine | shoot | 5.0 | 60% | 526 | 249 | 47% |
| Opponent | charge | 5.3 | 44% | 1086 | 423 | 39% |
| Opponent | join | 2.3 | 86% | 94 | 0 | 0% |
| Opponent | move | 38.7 | 98% | 2627 | 0 | 0% |
| Opponent | support | 1.0 | 100% | 91 | 0 | 0% |

### Battle groups: gs3-83c8646-p22

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.0 | 33% | 75% | 25% | 100% | 33% | 0% | 0% | 33% | 33% |
| Opponent | REDIRECT COUNTER | 3.0 | 33% | 67% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p22

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 7 | 116 (7) | 18 | 99 | 22 | 43% | 3.2 | 81 (6) | 375 (1) | - | 81 (6) | 375 (1) |
| Mine | Character | 7 | 12 (7) | 12 | 0 | 61 | 14% | 1.2 | 0 (1) | 26 (4) | 0 (1) | 30 (3) | 3 (3) |
| Mine | Clean-up | 2 | 26 (2) | 0 | 26 | 0 | 50% | 6.0 | 26 (2) | - | - | 0 (1) | 30 (1) |
| Mine | Fast Hammer | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Hammer | 10 | 38 (10) | 33 | 4 | 38 | 20% | 2.0 | 0 (2) | 68 (5) | 10 (3) | 12 (4) | 52 (6) |
| Mine | Holder | 3 | 43 (3) | 0 | 43 | 8 | 100% | - | 0 (1) | 79 (2) | - | 43 (3) | - |
| Mine | Shooter | 3 | 0 (3) | 0 | 0 | 33 | 0% | 1.3 | 0 (1) | 0 (2) | - | 0 (2) | 0 (1) |
| Mine | Wizard | 3 | 0 (3) | 0 | 0 | 68 | 0% | 1.7 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 9 | 65 (9) | 7 | 59 | 38 | 56% | 4.8 | 0 (4) | 233 (2) | 64 (3) | 117 (4) | 38 (5) |
| Opponent | Character | 10 | 32 (10) | 32 | 0 | 2 | 40% | 2.5 | 50 (4) | 15 (5) | 43 (1) | 60 (5) | 0 (5) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 8 | 59 (8) | 55 | 5 | 29 | 12% | 4.0 | 0 (2) | 83 (4) | 88 (2) | 98 (5) | 0 (3) |
| Opponent | Hammer | 2 | 86 (2) | 13 | 73 | 0 | 50% | 5.0 | - | 86 (2) | - | 38 (1) | 111 (1) |
| Opponent | Holder | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Wizard | 4 | 0 (4) | 0 | 0 | 50 | 25% | 1.3 | 0 (1) | 0 (1) | 0 (2) | - | 0 (4) |

### Charged fights: gs3-83c8646-p22

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 1 | 60 | 436 | 2.0 | 1.0 | 218 | 17 | +201 | 0 of 2 | 1 of 2 | - | +201 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 186 | 3.0 | 1.0 | 62 | 153 | -91 | 1 of 3 | 1 of 3 | - | -91 |
| Mine | Skaven | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 210 | -210 | 1 of 1 | 0 of 1 | - | -210 |
| **Mine** | all armies | 3 | 20 | 207 | 2.0 | 1.0 | 104 | 117 | -14 | 2 of 6 | 2 of 6 | - | -14 |
| Opponent | Vampire Counts | 2 | 0 | 280 | 4.5 | 1.3 | 62 | 33 | +29 | 4 of 9 | 3 of 9 | +109 | -10 |
| Opponent | Warriors of Chaos | 1 | 0 | 540 | 3.0 | 1.0 | 180 | 0 | +180 | 2 of 3 | 3 of 3 | - | +180 |
| **Opponent** | all armies | 3 | 0 | 367 | 4.0 | 1.2 | 92 | 25 | +67 | 6 of 12 | 6 of 12 | +109 | +53 |

### Effective charges: gs3-83c8646-p22

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 2 | 0 | 0 | 0 | 0 | 1 (net +436) | 0 | 1 | 0% (0 of 1) |
| Mine | Skaven | 1 | 1 (net -210) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Vampire Counts | 9 | 1 (net +0) | 1 (net -186) | 2 (net -30) | 2 (net +163) | 0 | 2 (net +118) | 1 | 25% (2 of 8) |
| Opponent | Warriors of Chaos | 3 | 0 | 0 | 0 | 1 (net +540) | 0 | 2 (net +0) | 0 | 0% (0 of 3) |

### Charged fights, damage counted: gs3-83c8646-p22

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 0 | 494 | -210 | 0 | 210 | -210 | - |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 234 | 60 | +436 | 436 | 0 | +436 | +186.3 |
| Mine | No odds | 4 | 197 | 230 | -77 | 51 | 124 | -72 | -36.8 |
| Mine | All fights | 6 | 170 | 245 | -14 | 107 | 117 | -11 | -6.2 |
| Opponent | Long shot (under 50%) | 1 | 376 | 234 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 50-54% | 1 | 186 | 251 | -186 | 42 | 186 | -144 | -77.5 |
| Opponent | Effective (55-75%) | 2 | 245 | 192 | -30 | 2 | 30 | -28 | -11.4 |
| Opponent | 76-89% | 3 | 117 | 279 | +289 | 355 | 16 | +339 | +291.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 268 | 276 | +59 | 83 | 22 | +61 | +22.8 |
| Opponent | No odds | 1 | 50 | 297 | -50 | 0 | 50 | -50 | -100.0 |
| Opponent | All fights | 12 | 210 | 259 | +67 | 120 | 36 | +84 | +40.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p22 | move | 21 | 2 (10%) | 2 (10%) | 3 (14%) | 16 (76%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1827, L1927 |
| Elixir of Power | Mine | L1927 |
| Fistful of Laurels | Mine | L1827 |
| Invocation of Nehek | Opponent | L1827, L1927 |
| Periapt of Soul Exchange | Mine | L2029 |

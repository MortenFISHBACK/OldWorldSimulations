# Doctrine scorecard: gs3-83c8646-p15

### Scorecard: gs3-83c8646-p15

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0409 | 1 | 1 | Mine | no | 4 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 4 | - | 0 | 1 | 0 | 0 | 0 | 295 |
| L0425 | 5 | 1 | Mine | yes | - | 1 | 3 | 4 | 0 | 0 | 0 | 65 |
| L0425 | 5 | 1 | Opponent | no | - | 2 | 3 | 3 | 2 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 285 |
| L0512 | 2 | 1 | Opponent | - | - | 3 | 1 | 1 | 0 | 0 | 0 | 165 |
| **Average** | | | Mine | 50% | 4.0 | 1.0 | 1.0 | 3.0 | 0.0 | 0.0 | 0.0 | 116.7 |
| **Average** | | | Opponent | 0% | 4.0 | 2.5 | 1.3 | 1.7 | 0.7 | 0.0 | 0.0 | 153.3 |

### KPIs: gs3-83c8646-p15

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 17% (2 of 12) | 0% (0 of 11) | 9% (2 of 23) |
| Winner chose to follow up after the loser gave ground |  | 100% (4 of 4); on the table 100% | - | 100% (4 of 4); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 100% (5 of 5); on the table 100% | - | 100% (5 of 5); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 58% (7 of 12) | 44% (16 of 36) | 48% (23 of 48) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 70% (7 of 10) | 50% (16 of 32) | 55% (23 of 42) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 74% (4439 of 5998) | 73% (4403 of 5998) | 74% (8842 of 11996) |
|   infantry points that never fought | lower | 83% (1185 of 1424) | 88% (1040 of 1187) | 85% (2225 of 2611) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 65% (15 of 23) | 67% (18 of 27) | 66% (33 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (3 of 3); 3.0 uses a game | 100% (3 of 3); 1.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 59% (3002 of 5120) | 64% (3503 of 5442) | 62% (6505 of 10562) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 5.0 (75%) | 5.0 (60%) |
| MARCHED: its unit marched | 1.0 (60%) | 0.3 (5%) | 1.3 (16%) |
| IN COMBAT: engaged in combat | 0.7 (40%) | 0.3 (5%) | 1.0 (12%) |
| GONE: slain | 0.0 (0%) | 1.0 (15%) | 1.0 (12%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.3 | 1.3 | 1.3 | 7.7 | 1.3 | 0.3 |
| not cast | 4.7 | 4.7 | 4.7 | 8.3 | 0.7 | 19.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.3 (17%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 4.7 (100%) | 2.0 (43%) | 5.0 (60%) | 0.3 (50%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (16%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 1.0 (21%) | 0.0 (0%) | 1.3 (29%) | 1.0 (12%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (50%) | 0.0 (0%) |
| GONE: slain | 1.3 (29%) | 0.0 (0%) | 0.3 (7%) | 1.0 (12%) | 0.0 (0%) | 4.3 (22%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (50%) | 0.0 (0%) | 1.0 (21%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.0 (61%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.7 a game | 0.7 a game | 0.7 a game |
| stood (cast and not dispelled) | 50% (1 of 2) | 0% (0 of 2) | 25% (1 of 4) |
| the unit moved after it | 100% (1 of 1) | - | 100% (1 of 1) |
| it charged on its next turn | 0% (0 of 1) | - | 0% (0 of 1) |
| the enemy charged it first | 0% (0 of 1) | - | 0% (0 of 1) |
| it fought by the end of its next turn | 0% (0 of 1) | - | 0% (0 of 1) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 1) | - | 0% (0 of 1) |
| none of these (no charge, no fight, no charge escaped) | 100% (1 of 1) | - | 100% (1 of 1) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 59% (48 of 82) | 57% (36 of 63) | 58% (84 of 145) |
|   cavalry | 43% (3 of 7) | - | 43% (3 of 7) |
|   character | 73% (11 of 15) | 100% (1 of 1) | 75% (12 of 16) |
|   chariot | 25% (6 of 24) | 100% (6 of 6) | 40% (12 of 30) |
|   infantry | 58% (7 of 12) | 41% (12 of 29) | 46% (19 of 41) |
|   monster | - | 80% (4 of 5) | 80% (4 of 5) |
|   war machine | 88% (21 of 24) | 59% (13 of 22) | 74% (34 of 46) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.0 (35%) | 2.0 (22%) | 6.0 (30%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.7 (7%) | 0.7 (3%) |
| NO TARGET IN RANGE | 4.0 (35%) | 2.7 (30%) | 6.7 (33%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.7 (24%) | 1.3 (15%) | 4.0 (20%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 1.7 (19%) | 1.7 (8%) |
| OTHER BAR | 0.7 (6%) | 0.7 (7%) | 1.3 (7%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 1.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| character | 4.0 | 2.3 | 67% | 18.1 pts | 72 pts |
| chariot | 4.0 | 6.7 | 42% | 23.6 pts | 94 pts |
| infantry | 8.7 | 2.3 | 73% | 10.0 pts | 86 pts |
| monster | 2.7 | 1.0 | 75% | 9.7 pts | 26 pts |
| war machine | 11.3 | 6.0 | 74% | 20.1 pts | 228 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.3 | 1.7 | 1.5 |
| Charges that made contact a game | 1.3 | 1.3 | 1.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.50 contact (2 units) | 0.33 declared, 0.33 contact (3 units) | 0.40 declared, 0.40 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.50 declared, 0.00 contact (2 units) | 0.50 declared, 0.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.13 declared, 0.13 contact (23 units) | 0.18 declared, 0.18 contact (17 units) | 0.15 declared, 0.15 contact (40 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | 100% (2 of 2) | - | 67% (4 of 6) |
| Character in a unit | 75% (3 of 4) | 100% (1 of 1) | - | 80% (4 of 5) |
| Character on its own | 100% (3 of 3) | 67% (4 of 6) | 0% (0 of 4) | 54% (7 of 13) |
| Chariot | - | 80% (4 of 5) | - | 80% (4 of 5) |
| Infantry | 42% (5 of 12) | 100% (3 of 3) | - | 53% (8 of 15) |
| Monstrous | - | 100% (1 of 1) | - | 100% (1 of 1) |
| War Machines | 100% (5 of 5) | - | - | 100% (5 of 5) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 2 | 100% (4 of 4); on the table 100% | 58% (7 of 12) | 80% | 56% (9 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Dwarfen Mountain Holds | 1 | 100% (1 of 1); on the table 100% | - | 63% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | - | 33% (4 of 12) | 100% | 67% (8 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 44% (8 of 18) | 72% | 56% (5 of 9) | 100% (3 of 3); 9.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Vampire Counts | 1 | - | 67% (4 of 6) | 48% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p15, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 75% (3) | 33% (1) | 57% (4) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.33 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.67 | 0.00 | 0.67 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p15

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 100% (4 of 4) | 60% (3 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 38% (13 of 34) | 53% (16 of 30) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 0% (0 of 2) |
| Strategy | Joined characters whose unit fought | 50% (2 of 4) | 0% (0 of 5) |
| Strategy | Lone characters that fought | 29% (2 of 7) | 56% (5 of 9) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 3.0 | 1.7 |
| Movement | Points that never moved of their own | 116.7 | 153.3 |
| Movement | Fights charged into per game | 1.3 | 1.3 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 4, net +0 | 0 of 3 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 4 | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 4, net +45 | 0 of 3 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 4 | 2 of 3, net -86 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.0 | 7.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 59% (16 of 27) | 43% (10 of 23) |
| Shooting | Points destroyed by shooting units | 193.7 | 0.0 |
| Shooting | War machine shots | 7.0 | 4.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 57% (12 of 21) | 23% (3 of 13) |
| Shooting | Points destroyed by war machines | 127.3 | 0.0 |
| Magic | Magic missiles cast | 1.7 | 3.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 60% (3 of 5) | 60% (6 of 10) |
| Magic | Wounds caused by magic missiles | 7.7 | 3.0 |
| Magic | Points destroyed by magic (all spells) | 75.7 | 62.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.0 / 0.0 / 0.0 | 1.0 / 0.7 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 349.0 | 31.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +182 | -143 |
| Combat | Net per 100 charger points, damage counted | +48.7 | -76.7 |
| Combat | First round won (charged fights) | 100% | 75% |
| Combat | Net points per charged fight | +182 | -56 |
| Combat | Net points per supported fight / lone fight | - / +182 | - / -56 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 4 | 3 of 4 |
| Game | Points lost | 162.7 | 858.0 |
| Game | VP from objectives | 780.0 | 520.0 |
| Game | Lone holders (player turns) | 4.0 | 4.0 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +1022 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 1021
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: gs3-83c8646-p15

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +22.5 | 0.0 | 0.0 |
| ARMY TABLE | 19.7 | -36.7 | 0.0 | 37.3 | 20.3 | +187.8 | 0.0 | 525.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 55.0 |
| BACKUP TARGETS | - | - | - | - | 0.3 | +0.7 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.3 | +0.0 | 55.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 6.7 | +32.1 | 905.7 | 63.3 | 3.3 | +0.0 | 0.0 | 55.0 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 2.0 | +77.2 | 249.3 | 0.0 | 6.3 | +54.6 | 0.0 | 56.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.7 | +7.0 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 1.3 | +22.8 | 0.0 | 0.0 | 0.3 | +1.2 | 0.0 | 0.0 |
| CHARACTER GUNS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 18.0 | -491.1 | 0.0 | 0.0 | 14.3 | -859.0 | 0.0 | 636.7 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 232.3 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 8.7 | +0.0 | 0.0 | 74.7 | 4.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.7 | +59.5 | 0.0 | 0.0 | 0.3 | +66.2 | 0.0 | 0.0 |
| COVER ONCE | 1.7 | -170.0 | 0.0 | 0.0 | 2.3 | -202.1 | 0.0 | 49.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -0.5 | 0.0 | 144.7 |
| DEPLOY BY FIGURES | 8.7 | +61.0 | 0.0 | 0.0 | 6.3 | +5.3 | 0.0 | 70.0 |
| DUEL STOPS AT THE KILL | 0.3 | -80.5 | 0.0 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | 0.7 | +26.6 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 0.3 | -39.7 | 0.0 | 0.0 | 0.7 | +2.4 | 31.7 | 0.0 |
| FACES THE THREAT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.3 | +0.0 | 147.7 | 0.0 | 1.3 | +0.4 | 37.3 | 161.3 |
| FALLS SHORT | 7.0 | +117.1 | 0.0 | 0.0 | 15.7 | +178.2 | 0.0 | 401.3 |
| FIGHT TO THE END | 0.7 | +25.6 | 0.0 | 0.0 | 1.0 | +46.2 | 0.0 | 161.3 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 100.0 | +6632.1 | 2463.0 | 264.7 | 90.3 | +4036.1 | 117.7 | 1684.0 |
| FLANK NOT WEIGHED | 5.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 198.7 |
| FOLLOW UP WEIGHED | 1.7 | +549.8 | 0.0 | 0.0 | - | - | - | - |
| FOOT FIRST | - | - | - | - | 15.7 | +0.0 | 0.0 | 385.7 |
| FOUR ROUNDS | 1.3 | +558.2 | 147.7 | 0.0 | 1.7 | +238.6 | 69.0 | 161.3 |
| FREED FROM HIS FIGHT | - | - | - | - | 2.7 | +0.0 | 0.0 | 98.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.3 | -0.0 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.7 | -7.8 | 37.3 | 144.7 |
| GOAL WALK | 13.3 | +1135.4 | 0.0 | 0.0 | 5.3 | +205.5 | 0.0 | 0.0 |
| GUN FIGURES | 1.3 | +0.0 | 124.7 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| GUN MASK | 2.0 | +5.6 | 0.0 | 0.0 | 3.7 | +39.8 | 0.0 | 151.3 |
| HARD STAY DROPPED | 2.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 84.7 |
| HE REFORMS ONCE FREED | - | - | - | - | 3.3 | +0.0 | 0.0 | 98.0 |
| HIS CHARGE BY HIS RUN | 3.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 492.0 |
| HIS CHARGE LIST | 4.7 | +0.0 | 0.0 | 37.3 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 56.0 |
| HIS MOVE AND SHOT | 4.7 | -39.3 | 0.0 | 0.0 | 1.0 | -6.3 | 0.0 | 0.0 |
| HIS ONE QUARTER | 4.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 151.3 |
| HIS OWN BEST MOVE | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 56.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 50.0 | +4474.0 | 0.0 | 0.0 | 45.7 | +2728.6 | 0.0 | 1182.0 |
| HIS SHOTS BY HIS RUN | 34.7 | +684.4 | 0.0 | 0.0 | 31.3 | +734.8 | 0.0 | 1106.7 |
| HIS TURN DENIED | - | - | - | - | 0.3 | +8.6 | 0.0 | 144.7 |
| HOLD ODDS | 16.0 | +0.0 | 0.0 | 0.0 | 15.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 9.7 | +974.8 | 0.0 | 0.0 | 9.3 | +940.9 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -129.3 | 147.7 | 0.0 | 1.7 | -83.7 | 69.0 | 161.3 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +85.1 | 0.0 | 144.7 |
| IDLE COST | 5.3 | -104.7 | 0.0 | 0.0 | 11.3 | -174.8 | 0.0 | 304.3 |
| KEPT FROM ITS LAST STOP | 2.0 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +64.9 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 2.7 | +0.0 | 308.0 | 0.0 | 1.3 | +0.0 | 0.0 | 182.7 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.7 | +30.1 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.7 | -0.2 | 132.7 | 0.0 | 0.7 | +0.5 | 0.0 | 144.7 |
| MAKE SURE TOGETHER | 0.3 | +9.7 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 1.3 | +17.2 | 0.0 | 0.0 | 2.3 | +9.8 | 0.0 | 56.0 |
| MARCH BY THE SUM | 0.3 | +6.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.3 | +21.3 | 0.0 | 0.0 | 3.7 | +286.1 | 0.0 | 200.7 |
| MARCH OF THE TABLE | 0.3 | +72.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | +9.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 2.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.7 | +44.9 | 0.0 | 0.0 | 2.0 | +22.4 | 0.0 | 144.7 |
| MEETS IN TIME | 5.3 | +153.6 | 0.0 | 0.0 | 2.3 | +33.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.0 | +74.3 | 0.0 | 0.0 | 9.7 | +94.2 | 0.0 | 256.7 |
| MISSILES NEXT TURN | 2.7 | +48.8 | 0.0 | 0.0 | 10.7 | +79.0 | 0.0 | 256.7 |
| MOVE ORDER | 2.3 | +0.0 | 0.0 | 37.7 | 1.0 | +0.0 | 0.0 | 15.0 |
| MOVE SPELL IN RANGE | 2.7 | +110.8 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 1.3 | -103.6 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 1.7 | +346.5 | 0.0 | 0.0 | 4.0 | +302.2 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 9.0 | +383.0 | 0.0 | 37.3 | 8.0 | +307.8 | 0.0 | 112.0 |
| NEAREST TO GOAL | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 0.7 | +29.8 | 0.0 | 0.0 | 1.7 | +128.1 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 1.0 | -46.1 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.3 | -73.4 | 147.7 | 0.0 | 0.7 | -14.8 | 69.0 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 3.3 | -100.5 | 0.0 | 31.7 | 4.3 | -147.6 | 0.0 | 75.7 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 55.0 |
| ONE CHALLENGE TEST | 0.3 | +22.6 | 132.7 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 2.7 | -59.4 | 0.0 | 0.0 | 3.0 | -36.0 | 0.0 | 72.3 |
| ONE OBJECTIVE FORMULA | 3.0 | +133.3 | 0.0 | 0.0 | 3.0 | -107.2 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.7 | +8.5 | 0.0 | 0.0 |
| ONE ROUTE | 2.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +13.4 | 15.0 | 0.0 | 0.3 | +3.1 | 37.3 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.3 | +15.2 | 0.0 | 0.0 |
| PATHS CROSS | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | -2.2 | 0.0 | 0.0 |
| PLAN RESULT | 44.0 | +976.2 | 672.0 | 201.7 | 40.7 | +337.1 | 0.0 | 1106.3 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 5.3 | -414.4 | 0.0 | 0.0 | 4.3 | -114.8 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.7 | -52.1 | 0.0 | 0.0 |
| QUARTER ODDS | 17.3 | +1588.0 | 729.3 | 0.0 | 19.0 | +1027.7 | 0.0 | 633.3 |
| REAL GROUND | 2.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.7 | +39.7 | 0.0 | 0.0 | 1.7 | +166.3 | 0.0 | 40.0 |
| REDIRECT FOR A FRIEND IN REACH | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 1.3 | -32.6 | 0.0 | 0.0 | 0.3 | -21.1 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| RISK BY ARC | 1.3 | +73.5 | 147.7 | 0.0 | 1.7 | -68.3 | 69.0 | 161.3 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.7 | -11.5 | 69.0 | 0.0 |
| RUN DOWN | - | - | - | - | 0.7 | -4.9 | 37.3 | 0.0 |
| SCOUT SPOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +41.8 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 0.3 | -27.3 | 0.0 | 0.0 |
| SET UP BY THE SET | - | - | - | - | 0.7 | +27.7 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.3 | +9.7 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 13.7 | +0.0 | 0.0 | 63.3 | 9.7 | +0.0 | 0.0 | 55.0 |
| SHOOTS FROM THE BEST SPOT | 4.7 | +209.9 | 182.7 | 0.0 | 1.7 | +6.3 | 48.7 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -0.2 | 0.0 | 16.7 |
| SHOT RISK POINTS | 27.3 | -50.8 | 0.0 | 0.0 | 19.7 | +100.2 | 0.0 | 918.0 |
| SHOTS AFTER THE MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 11.3 | +303.4 | 0.0 | 132.3 | 15.0 | +376.8 | 0.0 | 240.7 |
| SPELL WORTH | 0.7 | +6.2 | 0.0 | 0.0 | 1.0 | +25.2 | 289.3 | 289.3 |
| SPOT AS THE GAME MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 208.3 |
| STAND AND SHOOT | - | - | - | - | 0.7 | -7.6 | 37.3 | 144.7 |
| STANDS FOR A REASON | - | - | - | - | 3.0 | +0.0 | 48.7 | 0.0 |
| STANDS STILL | 52.7 | +0.0 | 2315.3 | 190.0 | 37.7 | +0.0 | 48.7 | 952.0 |
| STAY WORTH | 20.3 | -8.7 | 1200.0 | 31.7 | 25.7 | +61.8 | 0.0 | 331.0 |
| STRIKE BY THE ODDS | 0.3 | -22.7 | 0.0 | 0.0 | - | - | - | - |
| STUBBORN BY POINTS | 0.3 | +56.8 | 0.0 | 0.0 | - | - | - | - |
| STUPIDITY NEXT TURN | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 5.3 | +689.3 | 0.0 | 0.0 | 7.0 | +998.4 | 0.0 | 50.0 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 0.0 | 16.7 |
| SUPPORT WORKED OUT | 5.3 | +689.3 | 0.0 | 0.0 | 7.0 | +998.4 | 0.0 | 50.0 |
| SURE REACH TOGETHER | 0.7 | +0.6 | 0.0 | 0.0 | 1.3 | +32.3 | 0.0 | 56.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | -4.1 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 3.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.7 | -94.4 | 0.0 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 5.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 25.0 | 75.7 |
| THE ROW KEEPS ITS WAY | 5.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 2.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 56.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 49.3 | +0.0 | 0.0 | 138.3 | 41.7 | +0.0 | 0.0 | 651.3 |
| TIED UP BY THE SUM | 0.3 | +29.1 | 15.0 | 0.0 | 0.7 | +72.1 | 69.0 | 0.0 |
| TIME ON OUR SIDE | 35.7 | +405.7 | 256.7 | 99.3 | 19.0 | +180.7 | 0.0 | 0.0 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | - | - | - | - | 1.3 | +56.8 | 0.0 | 33.3 |
| WHO HITS BACK | 0.7 | +91.0 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | - | - | - | - | 0.7 | +9.9 | 0.0 | 16.7 |
| WHOLE FIGHT DANGER | 1.3 | -128.4 | 0.0 | 0.0 | 3.3 | -540.2 | 0.0 | 242.7 |
| WOUNDS ON THE RANKS | 4.0 | +37.7 | 0.0 | 0.0 | - | - | - | - |

### Rule changes: gs3-83c8646-p15

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 120 | 120 | 83 | 27.67 | +211 | +2.5 |
| HIS SHOT LIST | 287 | 278 | 74 | 24.67 | +1926 | +26.0 |
| HOLDER ASSIGNMENT | 57 | 57 | 55 | 18.33 | +3830 | +69.6 |
| HIS SHOTS BY HIS RUN | 198 | 195 | 50 | 16.67 | +571 | +11.4 |
| TIME ON OUR SIDE | 164 | 150 | 26 | 8.67 | +69 | +2.6 |
| OFF BEST | 23 | 23 | 23 | 7.67 | -744 | -32.4 |
| DEPLOY BY FIGURES | 45 | 45 | 22 | 7.33 | +460 | +20.9 |
| SHOT RISK POINTS | 141 | 137 | 22 | 7.33 | +385 | +17.5 |
| SUPPORT ADDS | 37 | 37 | 20 | 6.67 | +833 | +41.6 |
| SUPPORT WORKED OUT | 37 | 37 | 20 | 6.67 | +833 | +41.6 |
| GOAL WALK | 56 | 56 | 17 | 5.67 | +643 | +37.8 |
| THE TABLE AGAIN | 36 | 36 | 17 | 5.67 | +0 | +0.0 |
| CAST JOB | 25 | 25 | 16 | 5.33 | +213 | +13.3 |
| STAY WORTH | 138 | 125 | 15 | 5.00 | +168 | +11.2 |
| FIVE ACTION | 571 | 560 | 13 | 4.33 | +450 | +34.6 |
| ARTILLERY RE-ROLL WEIGHED | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| HARD STAY DROPPED | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| MARCH CHECK | 12 | 12 | 12 | 4.00 | +297 | +24.7 |
| PROMISE BY ITS OWN SUM | 29 | 29 | 12 | 4.00 | -1588 | -132.3 |
| MEETS IN TIME | 23 | 23 | 10 | 3.33 | +383 | +38.3 |
| MOVE ORDER | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 19 | 19 | 10 | 3.33 | +170 | +17.0 |
| FOUR ROUNDS | 9 | 9 | 7 | 2.33 | +1225 | +175.0 |
| IDLE COST | 50 | 34 | 7 | 2.33 | +24 | +3.5 |
| MOVE TO CHARGE COMPUTED | 17 | 12 | 6 | 2.00 | +83 | +13.9 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 5 | 5 | 5 | 1.67 | +72 | +14.3 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +1649 | +329.9 |
| QUARTER ODDS | 109 | 106 | 5 | 1.67 | +198 | +39.6 |
| CANNON SIGHT KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +195 | +48.6 |
| MANOEUVRE | 11 | 11 | 4 | 1.33 | +83 | +20.7 |
| MISSILES IN THE MOVE | 35 | 27 | 4 | 1.33 | +87 | +21.7 |
| PATHS CROSS | 4 | 4 | 4 | 1.33 | -7 | -1.7 |
| WHAT THE JOINER ADDS | 4 | 4 | 4 | 1.33 | +182 | +45.4 |
| COVER ONCE | 12 | 8 | 3 | 1.00 | +195 | +65.1 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +6 | +2.0 |
| SHOTS AFTER THE MOVES | 17 | 17 | 3 | 1.00 | +0 | +0.0 |
| SHOTS IN THE MOVE | 79 | 58 | 3 | 1.00 | +105 | +35.1 |
| TIED UP BY THE SUM | 3 | 3 | 3 | 1.00 | +167 | +55.7 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHARGE LOSSES | 97 | 95 | 2 | 0.67 | +16 | +8.0 |
| CHARGE NOW FIRST | 5 | 5 | 2 | 0.67 | -104 | -52.2 |
| EVASIVE BY THE ODDS | 2 | 2 | 2 | 0.67 | +80 | +39.8 |
| FACES THE THREAT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| GUN MASK | 17 | 16 | 2 | 0.67 | +75 | +37.6 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HUNT IN PAIRS | 2 | 2 | 2 | 0.67 | +232 | +115.8 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +90 | +45.1 |
| NEXT CHARGE BY LIST | 7 | 7 | 2 | 0.67 | +69 | +34.5 |
| OGRE LOADER SECOND SHOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| ONE FIGHT FORMULA | 17 | 9 | 2 | 0.67 | +27 | +13.5 |
| ONE OBJECTIVE FORMULA | 18 | 14 | 2 | 0.67 | +33 | +16.6 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | +26 | +12.8 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SEARCH SPOT | 2 | 2 | 2 | 0.67 | +126 | +62.8 |
| SURE REACH TOGETHER | 6 | 6 | 2 | 0.67 | +4 | +2.0 |
| THE ROW IN ITS ORDER | 27 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +190 | +94.9 |
| WHOLE FIGHT DANGER | 14 | 14 | 2 | 0.67 | +564 | +281.9 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +68 | +67.6 |
| CANNON PLANNED TARGET | 30 | 30 | 1 | 0.33 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALLS SHORT | 68 | 60 | 1 | 0.33 | +0 | +0.0 |
| FIGHT TO THE END | 5 | 5 | 1 | 0.33 | +31 | +31.3 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +20 | +19.7 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -217 | -216.8 |
| MAX FOR POSITIONING | 11 | 11 | 1 | 0.33 | +11 | +11.0 |
| NEARER NOT NEEDED | 51 | 48 | 1 | 0.33 | +50 | +50.5 |
| OPENS UP | 2 | 2 | 1 | 0.33 | +6 | +6.2 |
| OVERRUNS AWAY | 1 | 1 | 1 | 0.33 | +31 | +31.3 |
| REDIRECT COUNTER | 7 | 5 | 1 | 0.33 | +20 | +19.9 |
| REDIRECT FOR A FRIEND IN REACH | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| RISK BY ARC | 9 | 9 | 1 | 0.33 | +80 | +80.1 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +170 | +170.5 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -17 | -17.1 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | -12 | -12.3 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CHAFF IN THE MOVE | 2 | 2 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 2 | 2 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 39 | 39 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 3 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 8 | 8 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 27 | not checked | - | - | - | - |
| FOOT FIRST | 47 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 8 | 8 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 9 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 10 | 10 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 29 | 28 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 28 | 26 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 5 | 3 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 17 | 17 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 18 | 16 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 6 | 3 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HOLD ODDS | 94 | 94 | 0 | 0.00 | - | - |
| HONEST WORTH | 9 | 9 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 28 | 28 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 4 | 4 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 15 | 15 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 40 | 34 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 8 | 7 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 4 | trace | - | - | - | - |
| MOVE SPELL SPOT | 1 | not checked | - | - | - | - |
| NEAREST TO GOAL | 2 | 2 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 3 | 3 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 6 | 6 | 0 | 0.00 | - | - |
| NO LATE CUT | 7 | 7 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE ROUTE | 15 | 15 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 254 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 8 | 6 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 15 | 15 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 5 | 2 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 3 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SET UP BY THE SET | 2 | 2 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 70 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 5 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 32 | 30 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 9 | 9 | 0 | 0.00 | - | - |
| STANDS STILL | 271 | 269 | 0 | 0.00 | - | - |
| STRIKE BY THE ODDS | 1 | 1 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 3 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 17 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 24 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 16 | not checked | - | - | - | - |
| THE TABLE BINDS | 273 | not checked | - | - | - | - |
| WAITS AGAIN | 3 | 1 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 4 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 12 | 12 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p15

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.33 | 3.67 | 31.1 |
| ARMY TABLE | rule | 4.67 | 1.00 | 81.7 |
| PROMISE BY ITS OWN SUM | rule | 2.33 | 1.67 | 132.3 |
| HOLDER ASSIGNMENT | rule | 0.33 | 1.00 | 12.7 |
| CHARGE NOW FIRST | rule | 0.67 | - | 52.2 |
| NO REASON | gate | - | 0.67 | 45.5 |
| MARCH OF THE TABLE | rule | 0.33 | - | 216.8 |
| PATHS CROSS | rule | - | 0.33 | 6.7 |
| SUPPORT NARROWED | rule | - | 0.33 | 17.1 |
| SWIFTSTRIDE BY POINTS | rule | 0.33 | - | 12.3 |

### Plans: gs3-83c8646-p15

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 75% | 505 | 173 | 34% |
| Mine | join | 1.3 | 75% | 46 | 0 | 0% |
| Mine | move | 32.7 | 99% | 2057 | 0 | 0% |
| Mine | shoot | 8.7 | 58% | 259 | 803 | 310% |
| Opponent | charge | 1.7 | 80% | 160 | 126 | 78% |
| Opponent | join | 1.0 | 100% | 51 | 0 | 0% |
| Opponent | move | 29.7 | 96% | 1563 | 0 | 0% |
| Opponent | shoot | 8.3 | 52% | 178 | 212 | 119% |

### Battle groups: gs3-83c8646-p15

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.7 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 1.7 | 20% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p15

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Character | 11 | 66 (11) | 66 | 0 | 7 | 27% | 2.4 | 14 (8) | 255 (3) | - | 78 (8) | 34 (3) |
| Mine | Clean-up | 6 | 74 (6) | 0 | 74 | 0 | 83% | 5.0 | 0 (3) | 148 (2) | 200 (1) | 91 (5) | 0 (1) |
| Mine | Fast Hammer | 1 | 0 (1) | 0 | 0 | 100 | 0% | 1.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Hammer | 6 | 11 (6) | 11 | 0 | 0 | 50% | 3.0 | 0 (2) | 15 (4) | - | 0 (5) | 47 (1) |
| Mine | Holder | 2 | 76 (2) | 0 | 76 | 0 | 100% | - | 151 (1) | 0 (1) | - | 76 (2) | - |
| Mine | Shooter | 2 | 0 (2) | 0 | 0 | 0 | 0% | 2.0 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Mine | War machine | 5 | 80 (5) | 80 | 0 | 40 | 0% | 1.2 | 201 (2) | 0 (1) | 0 (2) | - | 80 (5) |
| Opponent | Chaff | 4 | 0 (4) | 0 | 0 | 47 | 50% | 3.5 | 0 (4) | - | - | 0 (3) | 0 (1) |
| Opponent | Character | 9 | 26 (9) | 12 | 14 | 55 | 33% | 3.5 | 19 (2) | 36 (5) | 0 (1) | 34 (5) | 0 (3) |
| Opponent | Clean-up | 2 | 7 (2) | 0 | 7 | 57 | 100% | - | 16 (1) | 0 (1) | - | 16 (1) | 0 (1) |
| Opponent | Fast Hammer | 1 | 0 (1) | 0 | 0 | 114 | 0% | 2.0 | 0 (1) | - | - | - | 0 (1) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 32 | 33% | 1.5 | - | 0 (3) | - | 0 (2) | 0 (1) |
| Opponent | Holder | 3 | 59 (3) | 21 | 37 | 31 | 0% | 3.3 | - | 54 (2) | - | 103 (1) | 0 (1) |
| Opponent | Shooter | 3 | 58 (3) | 0 | 58 | 0 | 0% | 1.0 | - | 87 (1) | 43 (2) | 58 (2) | 58 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | War machine | 5 | 0 (5) | 0 | 0 | 47 | 20% | 1.0 | - | - | 0 (5) | - | 0 (5) |
| Opponent | Wizard | 5 | 9 (5) | 9 | 0 | 27 | 20% | 3.0 | 0 (3) | 17 (2) | - | 17 (2) | 0 (3) |

### Charged fights: gs3-83c8646-p15

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 187 | 364 | 2.0 | 1.0 | 182 | 0 | +182 | 3 of 4 | 4 of 4 | - | +182 |
| Mine | Dwarfen Mountain Holds | 1 | 816 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 397 | 243 | 1.3 | 1.0 | 182 | 0 | +182 | 3 of 4 | 4 of 4 | - | +182 |
| Opponent | Empire of Man | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 186 | 95 | 2.0 | 1.0 | 48 | 0 | +48 | 1 of 2 | 1 of 2 | - | +48 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 159 | -159 | 2 of 2 | 2 of 2 | - | -159 |
| **Opponent** | all armies | 3 | 62 | 32 | 1.3 | 1.0 | 24 | 80 | -56 | 3 of 4 | 3 of 4 | - | -56 |

### Effective charges: gs3-83c8646-p15

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 4 | 2 (net +0) | 0 | 0 | 1 (net +684) | 1 (net +45) | 0 | 0 | 0% (0 of 4) |
| Opponent | Grand Cathay | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +95) | 1 | 0% (0 of 1) |
| Opponent | Vampire Counts | 2 | 0 | 1 (net -50) | 0 | 0 | 0 | 1 (net -268) | 0 | 0% (0 of 2) |

### Charged fights, damage counted: gs3-83c8646-p15

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 410 | 348 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 76-89% | 1 | 339 | 348 | +684 | 684 | 0 | +684 | +201.8 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 339 | 45 | +45 | 45 | 0 | +45 | +13.3 |
| Mine | All fights | 4 | 374 | 272 | +182 | 182 | 0 | +182 | +48.7 |
| Opponent | 50-54% | 1 | 50 | 480 | -50 | 44 | 148 | -104 | -207.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 182 | 217 | -86 | 48 | 156 | -108 | -59.5 |
| Opponent | No odds | 1 | 334 | 239 | +0 | 227 | 481 | -253 | -75.9 |
| Opponent | All fights | 4 | 187 | 288 | -56 | 92 | 235 | -143 | -76.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p15 | move | 14 | 2 (14%) | 2 (14%) | 2 (14%) | 10 (71%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0425 |
| Clockwork Compass | Opponent | L0512 |
| Invocation of Nehek | Opponent | L0425 |
| Ring of Doom | Opponent | L0512 |
| Ring of Jet | Opponent | L0512 |

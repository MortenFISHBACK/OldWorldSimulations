# Doctrine scorecard: gs3-83c8646-p74

### Scorecard: gs3-83c8646-p74

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0226 | 4 | 1 | Mine | no | 0 | 4 | 1 | 4 | 0 | 0 | 0 | 52 |
| L0226 | 4 | 1 | Opponent | no | 0 | 3 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | no | - | - | 0 | 3 | 0 | 0 | 0 | 675 |
| L0311 | 5 | 1 | Opponent | no | - | 3 | 2 | 1 | 1 | 0 | 0 | 330 |
| L0327 | 3 | 1 | Mine | no | 3 | 4 | 1 | 1 | 0 | 0 | 0 | 480 |
| L0327 | 3 | 1 | Opponent | no | 5 | 2 | 3 | 6 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 1.5 | 4.0 | 0.7 | 2.7 | 0.0 | 0.0 | 0.0 | 402.3 |
| **Average** | | | Opponent | 0% | 2.5 | 2.7 | 1.7 | 3.0 | 0.7 | 0.0 | 0.0 | 110.0 |

### KPIs: gs3-83c8646-p74

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 56% (9 of 16) | 0% (0 of 16) | 28% (9 of 32) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 50% (15 of 30) | 26% (11 of 42) | 36% (26 of 72) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 56% (15 of 27) | 37% (11 of 30) | 46% (26 of 57) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 50% (3 of 6) | - | 50% (3 of 6) |
| Points that never fought | lower | 69% (4092 of 5897) | 60% (3586 of 5999) | 65% (7678 of 11896) |
|   infantry points that never fought | lower | 78% (1123 of 1437) | 93% (859 of 919) | 84% (1982 of 2356) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 64% (14 of 22) | 68% (13 of 19) | 66% (27 of 41) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 1.7 uses a game | 50% (1 of 2); 1.7 uses a game | 75% (3 of 4); 1.7 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (2 of 4); 0.7 uses a game | 0% (0 of 1); 0.0 uses a game | 40% (2 of 5); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 67% (3011 of 4484) | 57% (2911 of 5148) | 61% (5922 of 9632) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.7 (53%) | 2.0 (19%) | 4.7 (30%) |
| MARCHED: its unit marched | 1.3 (27%) | 3.0 (29%) | 4.3 (28%) |
| CHARGED: its unit charged | 0.0 (0%) | 1.3 (13%) | 1.3 (9%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 1.3 (13%) | 1.3 (9%) |
| GONE: slain | 0.0 (0%) | 2.7 (26%) | 2.7 (17%) |
| OFF THE TABLE: off the table or not arrived | 1.0 (20%) | 0.0 (0%) | 1.0 (7%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.7 | 1.7 | 2.3 | 8.7 | 1.0 | 0.7 |
| not cast | 4.3 | 0.3 | 3.7 | 15.3 | 1.0 | 23.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (100%) | 1.0 (27%) | 4.7 (30%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.3 (28%) | 0.3 (33%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (9%) | 0.3 (33%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (9%) | 0.3 (33%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.7 (17%) | 0.0 (0%) | 2.7 (11%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (7%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.3 (100%) | 0.0 (0%) | 2.7 (73%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 20.0 (86%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.3 a game | 0.0 a game | 1.2 a game |
| stood (cast and not dispelled) | 43% (3 of 7) | - | 43% (3 of 7) |
| the unit moved after it | 67% (2 of 3) | - | 67% (2 of 3) |
| it charged on its next turn | 0% (0 of 3) | - | 0% (0 of 3) |
| the enemy charged it first | 0% (0 of 3) | - | 0% (0 of 3) |
| it fought by the end of its next turn | 0% (0 of 3) | - | 0% (0 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 3) | - | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | 100% (3 of 3) | - | 100% (3 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 86% (43 of 50) | 95% (18 of 19) | 88% (61 of 69) |
|   chariot | 74% (14 of 19) | 100% (6 of 6) | 80% (20 of 25) |
|   infantry | - | 100% (6 of 6) | 100% (6 of 6) |
|   war machine | 94% (29 of 31) | 86% (6 of 7) | 92% (35 of 38) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.0 (43%) | 0.0 (0%) | 1.0 (38%) |
| CHARGED: it charged | 0.3 (14%) | 0.0 (0%) | 0.3 (12%) |
| IN COMBAT: it fought this turn or the last | 0.3 (14%) | 0.0 (0%) | 0.3 (12%) |
| MOVED: a war machine that moved | 0.3 (14%) | 0.0 (0%) | 0.3 (12%) |
| NO TARGET IN RANGE | 0.3 (14%) | 0.0 (0%) | 0.3 (12%) |
| OTHER BAR | 0.0 (0%) | 0.3 (100%) | 0.3 (12%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| chariot | 6.7 | 9.0 | 45% | 38.0 pts | 254 pts |
| infantry | 4.0 | 0.3 | 92% | 3.7 pts | 15 pts |
| war machine | 12.0 | 13.0 | 69% | 41.5 pts | 497 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.0 | 4.3 | 2.7 |
| Charges that made contact a game | 1.0 | 2.3 | 1.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (4 units) | 1.20 declared, 0.60 contact (5 units) | 0.67 declared, 0.33 contact (9 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 3.00 declared, 2.00 contact (1 units) | 3.00 declared, 2.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.15 declared, 0.15 contact (20 units) | 0.20 declared, 0.10 contact (20 units) | 0.17 declared, 0.12 contact (40 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 100% (2 of 2) | - | 100% (2 of 2) | 100% (4 of 4) |
| Character in a unit | 86% (6 of 7) | 100% (2 of 2) | - | 89% (8 of 9) |
| Character on its own | - | 0% (0 of 1) | 0% (0 of 4) | 0% (0 of 5) |
| Chariot | 100% (1 of 1) | 75% (3 of 4) | - | 80% (4 of 5) |
| Infantry | 100% (1 of 1) | 67% (2 of 3) | 100% (1 of 1) | 80% (4 of 5) |
| Monster | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Monstrous | - | 100% (1 of 1) | - | 100% (1 of 1) |
| War Machines | 50% (4 of 8) | 50% (1 of 2) | - | 50% (5 of 10) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1 | - | 33% (2 of 6) | 78% | 83% (5 of 6) | 100% (2 of 2); 5.0 uses a game | 0.0 uses a game | 50% (1 of 2); 1.0 uses a game |
| Chaos Dwarfs | 2 | 100% (1 of 1); on the table 100% | 54% (13 of 24) | 65% | 56% (9 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Grand Cathay | 1 | - | 25% (6 of 24) | 82% | 62% (5 of 8) | 50% (1 of 2); 5.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Vampire Counts | 2 | - | 28% (5 of 18) | 49% | 73% (8 of 11) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p74, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (3) | 33% (1) | 44% (4) |
| ...free all their last turn and able to turn (per game) | 1.00 | 0.00 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.00 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: gs3-83c8646-p74

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 67% (2 of 3) | 36% (4 of 11) |
| Strategy | Shoot objectives carried out (shot that target) | 49% (24 of 49) | 50% (7 of 14) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 33% (1 of 3) |
| Strategy | Joined characters whose unit fought | 14% (1 of 7) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 0% (0 of 5) | 75% (6 of 8) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.7 | 3.0 |
| Movement | Points that never moved of their own | 402.3 | 110.0 |
| Movement | Fights charged into per game | 1.0 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 3, net -30 | 0 of 3 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 3 | 1 of 3, net +310 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 3, net +60 | 2 of 3, net +98 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 3, net +40 | 0 of 3 |
| Shooting | Shots by shooting units (incl. breath weapons) | 4.7 | 4.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 36% (5 of 14) | 50% (6 of 12) |
| Shooting | Points destroyed by shooting units | 20.0 | 0.0 |
| Shooting | War machine shots | 10.0 | 2.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (13 of 30) | 83% (5 of 6) |
| Shooting | Points destroyed by war machines | 172.7 | 206.7 |
| Magic | Magic missiles cast | 2.3 | 3.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 71% (5 of 7) | 11% (1 of 9) |
| Magic | Wounds caused by magic missiles | 2.0 | 3.3 |
| Magic | Points destroyed by magic (all spells) | 62.0 | 76.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 1.3 / 1.0 / 0.0 / 0.3 |
| Combat | Points destroyed in combat | 81.7 | 280.0 |
| Combat | Points run down | 0.0 | 27.0 |
| Combat | Net points per charged fight, damage counted | +18 | +131 |
| Combat | Net per 100 charger points, damage counted | +13.4 | +38.1 |
| Combat | First round won (charged fights) | 67% | 71% |
| Combat | Net points per charged fight | +23 | +114 |
| Combat | Net points per supported fight / lone fight | - / +23 | - / +114 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 3 | 3 of 7 |
| Game | Points lost | 727.0 | 336.3 |
| Game | VP from objectives | 493.3 | 670.0 |
| Game | Lone holders (player turns) | 1.5 | 2.5 |

- Mine won / drew / lost: 0 / 1 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -576 VP
- The side that went first won 2 of 2 games with a winner
- Points traded per game (both sides' losses): 1063
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p74

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 11.0 | +238.2 | 0.0 | 291.7 | 15.0 | +262.8 | 0.0 | 68.3 |
| ARTILLERY RE-ROLL WEIGHED | 5.0 | +0.0 | 0.0 | 113.3 | 0.3 | +0.0 | 0.0 | 55.0 |
| BACKUP TARGETS | - | - | - | - | 0.7 | +0.8 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.3 | -38.3 | 36.7 | 0.0 |
| CANNON PLANNED TARGET | 9.7 | +56.8 | 766.3 | 300.0 | 2.0 | +244.3 | 283.3 | 55.0 |
| CANNON SIGHT KEPT | 3.0 | +0.0 | 0.0 | 76.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 6.0 | +70.2 | 66.7 | 0.0 | 3.0 | +90.7 | 463.3 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 2.7 | +82.4 | 60.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.7 | +1.7 | 0.0 | 0.0 | 0.7 | +10.6 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.7 | +28.6 | 0.0 | 33.3 |
| CHARGE LOSSES | 8.0 | -138.6 | 0.0 | 206.7 | 16.3 | -473.1 | 0.0 | 222.0 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 33.3 | 0.0 | 2.3 | +0.0 | 368.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 11.0 | +0.0 | 0.0 | 55.3 | 14.3 | +0.0 | 0.0 | 95.0 |
| CONVEYANCE SEARCH | 1.3 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 15.3 | -741.0 | 0.0 | 318.3 | 2.3 | -70.9 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 10.0 | +28.6 | 0.0 | 76.7 | 7.0 | +82.9 | 0.0 | 55.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -1.7 | 31.7 | 0.0 |
| ENGINEER BY LORE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 0.7 | +5.0 | 33.3 | 0.0 | 3.0 | +8.1 | 253.3 | 0.0 |
| FALL BACK GOOD ORDER | 0.7 | +0.0 | 33.3 | 0.0 | 2.7 | +0.0 | 153.3 | 33.3 |
| FALLS SHORT | - | - | - | - | 21.7 | +193.6 | 0.0 | 262.0 |
| FEATURE BUFFS | 5.7 | +67.6 | 0.0 | 82.3 | 1.3 | +45.1 | 0.0 | 30.0 |
| FIGHT TO THE END | - | - | - | - | 0.7 | -10.8 | 135.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 103.3 | 0.0 |
| FIVE ACTION | 89.0 | +4109.6 | 2033.3 | 1750.7 | 86.3 | +6698.3 | 2268.7 | 878.0 |
| FLANK NOT WEIGHED | 10.7 | +0.0 | 0.0 | 425.3 | 3.3 | +0.0 | 0.0 | 77.7 |
| FOLLOW UP WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.0 | +25.3 | 33.3 | 10.0 | 4.3 | +115.7 | 312.0 | 33.3 |
| FREED FROM HIS FIGHT | 2.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 16.7 |
| FRIEND SHOOTS FIRST | 0.7 | -4.3 | 0.0 | 0.0 | 0.7 | -114.0 | 153.3 | 0.0 |
| GIVES UP ITS SCREEN | 0.3 | -11.0 | 0.0 | 10.0 | - | - | - | - |
| GOAL WALK | 10.0 | +800.9 | 0.0 | 148.3 | 8.0 | +397.7 | 0.0 | 25.0 |
| GUN FIGURES | 2.7 | +51.8 | 236.7 | 103.3 | - | - | - | - |
| HARD STAY DROPPED | 4.3 | +0.0 | 0.0 | 103.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 16.7 |
| HIS CHARGE BY HIS RUN | 4.0 | +0.0 | 0.0 | 206.7 | 4.7 | +0.0 | 0.0 | 172.0 |
| HIS CHARGE LIST | 6.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.0 | -26.9 | 0.0 | 0.0 | 3.3 | -66.4 | 0.0 | 16.7 |
| HIS ONE QUARTER | 3.3 | +0.0 | 0.0 | 206.7 | 8.3 | +0.0 | 0.0 | 33.3 |
| HIS OWN BEST MOVE | 3.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 9.7 | +0.0 | 0.0 | 113.3 |
| HIS RANDOM MOVER COMES | - | - | - | - | 1.3 | +0.0 | 0.0 | 56.7 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 22.7 | +266.0 | 0.0 | 206.7 | 48.3 | +1881.9 | 0.0 | 429.3 |
| HIS SHOTS BY HIS RUN | 21.3 | +212.0 | 0.0 | 394.0 | 38.3 | +651.3 | 0.0 | 584.0 |
| HIS TURN DENIED | - | - | - | - | 0.7 | +61.5 | 140.0 | 0.0 |
| HOLD ODDS | 20.0 | +0.0 | 0.0 | 311.3 | 13.3 | +0.0 | 0.0 | 30.0 |
| HOLDER ASSIGNMENT | 7.3 | +801.0 | 0.0 | 73.3 | 9.0 | +941.7 | 0.0 | 15.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.7 | -13.7 | 33.3 | 0.0 | 3.7 | -180.0 | 312.0 | 0.0 |
| IDLE COST | - | - | - | - | 16.3 | -234.2 | 0.0 | 229.7 |
| JOINT CHARGE NOW | - | - | - | - | 0.7 | -1.4 | 0.0 | 0.0 |
| KEEP FALLS | 0.3 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 3.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 1.3 | +40.9 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 40.0 |
| LONE WIZARD KEPT IN | 0.7 | +44.0 | 0.0 | 0.0 | 0.3 | +31.7 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | - | - | - | - | 1.3 | +7.4 | 68.3 | 0.0 |
| MANOEUVRE | 0.3 | +12.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.7 | +2.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.7 | +17.4 | 0.0 | 0.0 | 1.0 | +81.3 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +6.4 | 0.0 | 0.0 | 0.3 | +69.2 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.7 | +62.9 | 0.0 | 77.7 |
| MARCH OVER CASTS | 1.3 | -49.3 | 0.0 | 0.0 | 1.3 | -65.7 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.0 | +3.9 | 0.0 | 0.0 | 3.3 | +76.9 | 0.0 | 155.3 |
| MEETS IN TIME | 4.3 | +186.0 | 0.0 | 0.0 | 3.0 | +268.1 | 0.0 | 55.0 |
| MISSILES IN THE MOVE | 7.3 | +139.4 | 0.0 | 27.0 | 4.3 | +80.9 | 0.0 | 77.7 |
| MISSILES NEXT TURN | 7.7 | +80.0 | 0.0 | 55.3 | 6.7 | +75.2 | 0.0 | 155.3 |
| MISSILES ON ONE TARGET | 0.3 | -3.3 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 20.0 |
| MOVE SPELL SPOT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.7 | +276.3 | 0.0 | 206.7 | 6.0 | +359.8 | 0.0 | 155.3 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 4.0 | +165.7 | 0.0 | 31.7 | 5.3 | +244.5 | 0.0 | 20.0 |
| NEAREST TO GOAL | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 1.3 | +133.9 | 0.0 | 206.7 | 4.0 | +321.8 | 153.3 | 0.0 |
| NO DOUBLE ROUNDS | 0.3 | -10.7 | 20.0 | 0.0 | 3.7 | -65.2 | 312.0 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT WORTH A CAST | - | - | - | - | 0.3 | -0.0 | 0.0 | 0.0 |
| OFF BEST | 2.7 | -87.8 | 0.0 | 36.7 | 4.7 | -220.4 | 0.0 | 13.3 |
| OGRE LOADER SECOND SHOT | 0.3 | +0.7 | 77.7 | 0.0 | 0.3 | +10.0 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.7 | +0.0 | 0.0 | 13.3 |
| ONE FIGHT FORMULA | 3.0 | -26.0 | 0.0 | 103.3 | 5.3 | -134.6 | 0.0 | 106.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +46.2 | 0.0 | 16.7 |
| ONE OBJECTIVE FORMULA | 1.3 | -56.7 | 0.0 | 41.7 | 4.0 | +82.3 | 0.0 | 15.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | +5.9 | 0.0 | 0.0 |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | - | - | - | - | 2.0 | +7.7 | 460.0 | 77.7 |
| OPENS UP | - | - | - | - | 1.7 | +34.7 | 116.7 | 0.0 |
| OVERRUNS AWAY | 0.7 | +0.9 | 33.3 | 0.0 | 1.7 | +111.1 | 116.7 | 0.0 |
| PIVOT GUARDS FLANK | 0.7 | -19.3 | 0.0 | 0.0 | 0.7 | -2.1 | 0.0 | 77.7 |
| PLAN RESULT | 39.7 | +936.4 | 412.3 | 1137.0 | 40.7 | +870.8 | 511.7 | 460.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 4.0 | -49.1 | 0.0 | 0.0 | 9.3 | -255.5 | 0.0 | 155.3 |
| PROMISE HOLDS THE SPOT | - | - | - | - | 0.3 | +5.6 | 0.0 | 13.3 |
| PROMISE KNOWS THE FIGHT | 1.7 | -5.5 | 0.0 | 103.3 | - | - | - | - |
| PROMISE SHOT AWAY | - | - | - | - | 0.3 | -17.4 | 76.7 | 0.0 |
| QUARTER ODDS | 22.0 | +2043.7 | 224.0 | 383.3 | 22.3 | +3294.1 | 966.7 | 66.7 |
| RANDOM MOVE BY FIGURES | 2.0 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.7 | +3.7 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 2.7 | -19.6 | 0.0 | 83.7 | 1.3 | +31.5 | 0.0 | 13.3 |
| REDIRECT FOR A FRIEND IN REACH | 3.0 | +10.7 | 0.0 | 93.7 | 1.3 | +0.0 | 0.0 | 48.3 |
| REDIRECT WEIGHED | - | - | - | - | 1.3 | -38.3 | 36.7 | 0.0 |
| REFORMS TO MEET IT | 1.3 | -36.9 | 0.0 | 206.7 | - | - | - | - |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 1.3 | +38.0 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | 0.3 | +46.4 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 0.7 | +14.0 | 33.3 | 0.0 | 3.3 | -149.0 | 275.3 | 16.7 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 2.3 | -37.1 | 125.0 | 33.3 |
| RUN DOWN | - | - | - | - | 2.3 | -7.7 | 125.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -24.8 | 0.0 | 0.0 |
| SEARCH SPOT | 1.3 | +12.1 | 0.0 | 131.7 | 0.7 | +31.7 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +4.9 | 0.0 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 2.3 | -50.2 | 0.0 | 46.7 |
| SET UP BY THE SET | 2.3 | +120.1 | 0.0 | 0.0 | 3.7 | +49.6 | 181.7 | 46.7 |
| SHOOTERS ON THE TABLE | 17.3 | +0.0 | 0.0 | 403.3 | 6.0 | +0.0 | 0.0 | 55.0 |
| SHOOTS FROM THE BEST SPOT | 4.0 | +93.1 | 40.0 | 206.7 | - | - | - | - |
| SHOT OR CHARGE | 0.3 | -1.5 | 20.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 10.0 | -115.9 | 0.0 | 206.7 | 27.7 | -232.8 | 0.0 | 479.3 |
| SHOTS AFTER THE MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 14.3 | +560.6 | 0.0 | 506.7 | 6.3 | +498.8 | 0.0 | 55.0 |
| SPELL WORTH | - | - | - | - | 3.7 | +21.5 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 6.3 | +0.0 | 0.0 | 366.7 | 6.7 | +0.0 | 0.0 | 63.3 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -4.1 | 103.3 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 2.0 | +0.0 | 360.0 | 0.0 |
| STANDS STILL | 58.3 | +0.0 | 2000.0 | 1033.3 | 23.7 | +0.0 | 1956.7 | 126.7 |
| STAY WORTH | 22.7 | -235.0 | 480.7 | 650.0 | 13.3 | +532.4 | 1646.7 | 165.0 |
| STUCK PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| STUPIDITY NEXT TURN | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.0 | +112.3 | 0.0 | 20.0 | 0.7 | +39.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 2.0 | +112.3 | 0.0 | 20.0 | 0.7 | +39.0 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | +0.0 | 0.0 | 16.7 |
| THE ROW IN ITS ORDER | 5.0 | +0.0 | 28.3 | 158.7 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 13.3 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 13.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 42.7 | +0.0 | 0.0 | 870.3 | 42.3 | +0.0 | 0.0 | 442.3 |
| TIED UP BY THE SUM | 0.7 | +48.0 | 33.3 | 0.0 | 2.3 | +303.6 | 172.0 | 0.0 |
| TIME ON OUR SIDE | 46.0 | +463.4 | 100.0 | 485.3 | - | - | - | - |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 155.3 |
| WAR ENGINE JOBS | 2.7 | +0.0 | 310.7 | 206.7 | 1.3 | +0.0 | 360.0 | 0.0 |
| WHO HITS BACK | 0.3 | +56.1 | 0.0 | 0.0 | 0.7 | +44.4 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 0.7 | -26.7 | 0.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 2.0 | +23.4 | 0.0 | 0.0 | 4.7 | +113.4 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p74

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 78 | 78 | 63 | 21.00 | +1338 | +21.2 |
| HOLDER ASSIGNMENT | 49 | 49 | 47 | 15.67 | +3227 | +68.7 |
| HIS SHOT LIST | 213 | 206 | 46 | 15.33 | +985 | +21.4 |
| DEPLOY BY FIGURES | 51 | 51 | 31 | 10.33 | +306 | +9.9 |
| FIVE ACTION | 526 | 515 | 28 | 9.33 | +2586 | +92.3 |
| HIS SHOTS BY HIS RUN | 179 | 172 | 24 | 8.00 | +408 | +17.0 |
| OFF BEST | 22 | 22 | 22 | 7.33 | -925 | -42.0 |
| QUARTER ODDS | 133 | 131 | 22 | 7.33 | +2592 | +117.8 |
| GOAL WALK | 54 | 53 | 18 | 6.00 | +943 | +52.4 |
| THE TABLE AGAIN | 36 | 36 | 17 | 5.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 138 | 115 | 17 | 5.67 | +47 | +2.8 |
| ARTILLERY RE-ROLL WEIGHED | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| HARD STAY DROPPED | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 26 | 20 | 15 | 5.00 | +864 | +57.6 |
| PROMISE BY ITS OWN SUM | 40 | 40 | 14 | 4.67 | -914 | -65.3 |
| REDIRECT FOR A FRIEND IN REACH | 13 | 13 | 13 | 4.33 | +20 | +1.6 |
| MEETS IN TIME | 22 | 22 | 11 | 3.67 | +245 | +22.3 |
| CANNON SIGHT KEPT | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| IDLE COST | 49 | 34 | 10 | 3.33 | +101 | +10.1 |
| NEXT CHARGE BY LIST | 16 | 15 | 9 | 3.00 | +565 | +62.8 |
| SET UP BY THE SET | 18 | 18 | 8 | 2.67 | +462 | +57.8 |
| CAST JOB | 27 | 27 | 7 | 2.33 | +60 | +8.5 |
| COVER ONCE | 53 | 33 | 7 | 2.33 | +149 | +21.3 |
| MOVE ORDER | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| TIED UP BY THE SUM | 9 | 8 | 7 | 2.33 | +185 | +26.5 |
| CASTING BLOCK | 8 | 8 | 6 | 2.00 | +36 | +6.0 |
| FOUR ROUNDS | 16 | 15 | 6 | 2.00 | +76 | +12.6 |
| SHOOTS FROM THE BEST SPOT | 12 | 12 | 6 | 2.00 | +45 | +7.5 |
| SHOT RISK POINTS | 113 | 109 | 6 | 2.00 | +302 | +50.2 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| MARCH BY THE SUM | 5 | 5 | 5 | 1.67 | +296 | +59.2 |
| MISSILES IN THE MOVE | 35 | 17 | 5 | 1.67 | +108 | +21.5 |
| PROMISE KNOWS THE FIGHT | 5 | 5 | 5 | 1.67 | -16 | -3.3 |
| SEARCH SPOT | 6 | 6 | 5 | 1.67 | +132 | +26.3 |
| FIRE IN ORDER | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +123 | +30.7 |
| PIVOT GUARDS FLANK | 4 | 4 | 4 | 1.33 | -64 | -16.1 |
| REDIRECT WEIGHED | 4 | 4 | 4 | 1.33 | +557 | +139.2 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +114 | +28.5 |
| SHOTS AFTER THE MOVES | 18 | 18 | 4 | 1.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 9 | 9 | 3 | 1.00 | -82 | -27.4 |
| LEGAL CHARGES ONLY | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +227 | +75.7 |
| RANDOM MOVE BY FIGURES | 6 | 6 | 3 | 1.00 | +5 | +1.8 |
| STAY WORTH | 108 | 98 | 3 | 1.00 | +19 | +6.4 |
| THE ROW IN ITS ORDER | 21 | 3 | 3 | 1.00 | +0 | +0.0 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +243 | +80.9 |
| WOUNDS ON THE RANKS | 20 | 19 | 3 | 1.00 | +57 | +19.1 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 4 | 4 | 2 | 0.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +86 | +43.0 |
| CHARGE LOSSES | 73 | 69 | 2 | 0.67 | +6 | +3.2 |
| FALLS SHORT | 65 | 58 | 2 | 0.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | -4 | -2.1 |
| MARCH CHECK | 2 | 2 | 2 | 0.67 | +102 | +51.2 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -189 | -94.4 |
| MAX FOR POSITIONING | 13 | 12 | 2 | 0.67 | +0 | +0.0 |
| MISSILES NEXT TURN | 43 | 23 | 2 | 0.67 | +1 | +0.6 |
| OGRE LOADER SECOND SHOT | 2 | 2 | 2 | 0.67 | +32 | +16.1 |
| OVERRUNS AWAY | 7 | 7 | 2 | 0.67 | +93 | +46.4 |
| REDIRECT COUNTER | 12 | 6 | 2 | 0.67 | +44 | +21.9 |
| SHOTS IN THE MOVE | 62 | 44 | 2 | 0.67 | +186 | +92.8 |
| SUPPORT ADDS | 8 | 8 | 2 | 0.67 | +4 | +1.8 |
| SUPPORT WORKED OUT | 8 | 8 | 2 | 0.67 | +4 | +1.8 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -115 | -114.9 |
| CANNON PLANNED TARGET | 35 | 35 | 1 | 0.33 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 11 | 10 | 1 | 0.33 | +6 | +5.5 |
| FEATURE BUFFS | 21 | 19 | 1 | 0.33 | +1 | +1.3 |
| HIS TURN DENIED | 2 | 2 | 1 | 0.33 | +21 | +20.7 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +21 | +21.0 |
| LOST AFTER ESCAPE | 4 | 4 | 1 | 0.33 | +5 | +5.0 |
| MANOEUVRE | 7 | 7 | 1 | 0.33 | +36 | +35.9 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| ONE JOINT FIGURE | 1 | 1 | 1 | 0.33 | +23 | +23.4 |
| ONE OBJECTIVE FORMULA | 16 | 9 | 1 | 0.33 | +46 | +45.9 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | +18 | +17.6 |
| OPENS UP | 5 | 4 | 1 | 0.33 | +6 | +5.5 |
| PROMISE HOLDS THE SPOT | 1 | 1 | 1 | 0.33 | +17 | +16.9 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -52 | -52.2 |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 1 | 0.33 | +5 | +4.9 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +139 | +139.3 |
| RISK BY ARC | 12 | 11 | 1 | 0.33 | +34 | +34.4 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +15 | +14.6 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| BACKUP TARGETS | 2 | not checked | - | - | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 76 | 76 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 4 | not checked | - | - | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 10 | 9 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 42 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 12 | 12 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 8 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 6 | 6 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 26 | 25 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 26 | 26 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 18 | 17 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 22 | 20 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 35 | 34 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 26 | 25 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 29 | 28 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 4 | 4 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 100 | 96 | 0 | 0.00 | - | - |
| HONEST WORTH | 13 | 12 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 16 | 16 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 8 | 8 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 8 | 8 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 1 | not checked | - | - | - | - |
| MOVE SPELL SPOT | 3 | not checked | - | - | - | - |
| NEARER NOT NEEDED | 28 | 27 | 0 | 0.00 | - | - |
| NEAREST TO GOAL | 2 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 12 | 11 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 25 | 5 | 0 | 0.00 | - | - |
| ONE ROUTE | 8 | 8 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS A LANE | 6 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 241 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 8 | 8 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 4 | 2 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 2 | 2 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 7 | 7 | 0 | 0.00 | - | - |
| RUN DOWN | 7 | 6 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 7 | 7 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 70 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 11 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 39 | 33 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 6 | 6 | 0 | 0.00 | - | - |
| STANDS STILL | 246 | 243 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 6 | 4 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 24 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 13 | not checked | - | - | - | - |
| THE TABLE BINDS | 255 | not checked | - | - | - | - |
| WAITS AGAIN | 12 | 9 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 12 | 12 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p74

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.33 | 4.00 | 44.8 |
| PROMISE BY ITS OWN SUM | rule | 1.33 | 3.33 | 65.3 |
| ARMY TABLE | rule | 1.33 | 1.67 | 34.4 |
| PIVOT GUARDS FLANK | rule | 0.67 | 0.67 | 16.1 |
| CHARGE NOW FIRST | rule | 0.33 | 0.67 | 27.4 |
| DEPLOY BY FIGURES | rule | 0.67 | 0.33 | 6.0 |
| PROMISE KNOWS THE FIGHT | rule | 1.00 | - | 5.1 |
| MARCH OF THE TABLE | rule | - | 0.67 | 94.4 |
| RULE SWITCHED OFF | gate | - | 0.67 | 28.7 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.33 | - | 16.5 |
| BEST PRIZE | rule | - | 0.33 | 114.9 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 12.0 |
| JOINT CHARGE NOW | rule | - | 0.33 | 24.9 |
| PROMISE SHOT AWAY | rule | - | 0.33 | 52.2 |

### Plans: gs3-83c8646-p74

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.7 | 100% | 31 | 33 | 107% |
| Mine | move | 24.7 | 89% | 1592 | 0 | 0% |
| Mine | shoot | 14.0 | 71% | 267 | 903 | 339% |
| Mine | support | 0.3 | 100% | 5 | 0 | 0% |
| Opponent | charge | 3.0 | 78% | 283 | 256 | 90% |
| Opponent | join | 1.3 | 75% | 50 | 0 | 0% |
| Opponent | move | 31.7 | 94% | 1520 | 0 | 0% |
| Opponent | shoot | 4.3 | 77% | 688 | 615 | 89% |
| Opponent | support | 0.3 | 100% | 0 | 0 | - |

### Battle groups: gs3-83c8646-p74

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.7 | 38% | 67% | 0% | - | 0% | 0% | 0% | 33% | 67% |
| Opponent | REDIRECT COUNTER | 1.3 | 25% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p74

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 100 | 0% | 6.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Character | 8 | 21 (8) | 21 | 0 | 0 | 38% | 3.2 | 18 (7) | 42 (1) | - | 21 (2) | 21 (6) |
| Mine | Clean-up | 4 | 24 (4) | 0 | 24 | 26 | 100% | - | 32 (3) | 0 (1) | - | 48 (2) | 0 (2) |
| Mine | Fast Hammer | 5 | 12 (5) | 12 | 0 | 52 | 40% | 3.3 | 0 (1) | 38 (2) | 0 (2) | 12 (5) | - |
| Mine | Hammer | 9 | 19 (9) | 9 | 10 | 42 | 22% | 2.4 | 0 (3) | 32 (5) | 0 (1) | 22 (6) | 13 (3) |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | War machine | 8 | 44 (8) | 44 | 0 | 67 | 0% | 1.0 | 44 (6) | 45 (2) | - | 68 (5) | 9 (3) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 22 | 50% | 1.5 | 0 (4) | - | - | 0 (2) | 0 (2) |
| Opponent | Chaff | 8 | 115 (8) | 0 | 115 | 60 | 62% | 3.7 | 100 (3) | 153 (4) | 0 (1) | 132 (7) | 0 (1) |
| Opponent | Character | 8 | 45 (8) | 45 | 0 | 4 | 25% | 3.7 | 24 (3) | 68 (5) | - | 17 (1) | 53 (7) |
| Opponent | Clean-up | 5 | 0 (5) | 0 | 0 | 18 | 80% | 1.0 | 0 (2) | 0 (1) | 0 (2) | 0 (2) | 0 (3) |
| Opponent | Fast Hammer | 2 | 0 (2) | 0 | 0 | 0 | 50% | 1.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Hammer | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Shooter | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | War machine | 2 | 188 (2) | 188 | 0 | 50 | 0% | 1.0 | 376 (1) | 0 (1) | - | - | 188 (2) |
| Opponent | Wizard | 4 | 40 (4) | 40 | 0 | 51 | 50% | 2.5 | 44 (3) | 0 (1) | - | 44 (3) | 0 (1) |

### Charged fights: gs3-83c8646-p74

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 0 | 40 | 2.0 | 1.0 | 20 | 15 | +5 | 1 of 2 | 1 of 2 | - | +5 |
| Mine | Chaos Dwarfs | 2 | 382 | 30 | 0.5 | 1.0 | 60 | 0 | +60 | 0 of 1 | 1 of 1 | - | +60 |
| **Mine** | all armies | 3 | 255 | 33 | 1.0 | 1.0 | 33 | 10 | +23 | 1 of 3 | 2 of 3 | - | +23 |
| Opponent | Grand Cathay | 1 | 850 | 305 | 1.0 | 1.0 | 305 | 0 | +305 | 0 of 1 | 1 of 1 | - | +305 |
| Opponent | Vampire Counts | 2 | 0 | 295 | 3.0 | 1.0 | 98 | 17 | +82 | 3 of 6 | 4 of 6 | - | +82 |
| **Opponent** | all armies | 3 | 283 | 298 | 2.3 | 1.0 | 128 | 14 | +114 | 3 of 7 | 5 of 7 | - | +114 |

### Effective charges: gs3-83c8646-p74

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 1 (net -30) | 0 | 0 | 0 | 0 | 1 (net +40) | 0 | 0% (0 of 2) |
| Mine | Chaos Dwarfs | 1 | 0 | 0 | 0 | 0 | 1 (net +60) | 0 | 0 | 0% (0 of 1) |
| Opponent | Vampire Counts | 6 | 0 | 0 | 1 (net +310) | 0 | 2 (net +98) | 0 | 3 | 33% (1 of 3) |

### Charged fights, damage counted: gs3-83c8646-p74

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 30 | 500 | -30 | 0 | 30 | -30 | -100.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 52 | 40 | +40 | 40 | 17 | +23 | +43.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 310 | 60 | +60 | 60 | 0 | +60 | +19.4 |
| Mine | All fights | 3 | 131 | 200 | +23 | 33 | 16 | +18 | +13.4 |
| Opponent | Effective (55-75%) | 1 | 471 | 310 | +310 | 310 | 93 | +217 | +46.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 486 | 98 | +98 | 98 | 0 | +98 | +20.1 |
| Opponent | No odds | 4 | 242 | 206 | +72 | 169 | 42 | +127 | +52.3 |
| Opponent | All fights | 7 | 344 | 190 | +114 | 169 | 37 | +131 | +38.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p74 | move | 18 | 5 (28%) | 3 (17%) | 3 (17%) | 10 (56%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0226, L0327 |
| Elixir of Power | Opponent | L0311 |
| Invocation of Nehek | Opponent | L0327 |
| Ring of Doom | Mine | L0226 |
| Ring of Doom | Opponent | L0311 |
| Ring of Jet | Opponent | L0311 |

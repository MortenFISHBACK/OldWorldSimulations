# Doctrine scorecard: gs3-83c8646-p1

### Scorecard: gs3-83c8646-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 2 | 5 | 1 | 0 | 0 | 0 | 0 | 55 |
| L0102 | 6 | 1 | Opponent | no | 5 | 2 | 1 | 5 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Mine | no | 3 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 0 | 6 | 0 | 5 | 1 | 0 | 0 | 228 |
| L0135 | 3 | 1 | Mine | no | 7 | - | 0 | 1 | 0 | 0 | 0 | 55 |
| L0135 | 3 | 1 | Opponent | no | 3 | 2 | 2 | 5 | 0 | 0 | 0 | 224 |
| **Average** | | | Mine | 0% | 4.0 | 5.0 | 0.3 | 1.0 | 0.0 | 0.0 | 0.0 | 36.7 |
| **Average** | | | Opponent | 0% | 2.7 | 3.3 | 1.0 | 5.0 | 0.3 | 0.0 | 0.0 | 150.7 |

### KPIs: gs3-83c8646-p1

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 6) | 0% (0 of 13) | 0% (0 of 19) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | 67% (2 of 3); on the table 67% | 75% (3 of 4); on the table 75% |
| Winner chose to follow up or pursue (all three) |  | 100% (3 of 3); on the table 100% | 67% (2 of 3); on the table 67% | 83% (5 of 6); on the table 83% |
| Magic missiles tried each own turn | 50%+ | 30% (27 of 90) | 17% (4 of 24) | 27% (31 of 114) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 33% (27 of 81) | 17% (4 of 24) | 30% (31 of 105) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 80% (4 of 5) | 80% (4 of 5) |
| Points that never fought | lower | 54% (3054 of 5700) | 80% (4748 of 5899) | 67% (7802 of 11599) |
|   infantry points that never fought | lower | 55% (1497 of 2703) | 100% (1219 of 1219) | 69% (2716 of 3922) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 47% (7 of 15) | 68% (17 of 25) | 60% (24 of 40) |
| Bound items with a magic missile used (at least once a game) |  | 100% (3 of 3); 3.7 uses a game | 75% (3 of 4); 3.7 uses a game | 86% (6 of 7); 3.7 uses a game |
| Bound items with another spell used |  | 100% (3 of 3); 1.3 uses a game | 0.0 uses a game | 100% (3 of 3); 0.7 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (3 of 3); 1.0 uses a game | 50% (1 of 2); 0.3 uses a game | 80% (4 of 5); 0.7 uses a game |
|   their share of the points of units over 100 pts | lower | 48% (1962 of 4077) | 67% (3289 of 4883) | 59% (5251 of 8960) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 12.3 (59%) | 5.7 (85%) | 18.0 (65%) |
| MARCHED: its unit marched | 2.3 (11%) | 1.0 (15%) | 3.3 (12%) |
| CHARGED: its unit charged | 0.7 (3%) | 0.0 (0%) | 0.7 (2%) |
| IN COMBAT: engaged in combat | 3.0 (14%) | 0.0 (0%) | 3.0 (11%) |
| STUPIDITY: Stupidity | 2.0 (10%) | 0.0 (0%) | 2.0 (7%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.7 (3%) | 0.0 (0%) | 0.7 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 10.7 | 2.7 | 7.3 | 10.3 | 3.3 |
| not cast | 7.3 | 7.3 | 8.7 | 27.7 | 40.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.7 (50%) | 2.3 (27%) | 18.0 (65%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.3 (12%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.7 (9%) | 1.0 (14%) | 1.7 (19%) | 3.0 (11%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| STUPIDITY: Stupidity | 1.0 (14%) | 0.0 (0%) | 2.0 (23%) | 2.0 (7%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (2%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 5.7 (77%) | 2.7 (36%) | 2.7 (31%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 39.0 (96%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 7.0 a game | 1.7 a game | 4.3 a game |
| stood (cast and not dispelled) | 71% (15 of 21) | 80% (4 of 5) | 73% (19 of 26) |
| the unit moved after it | 80% (12 of 15) | 25% (1 of 4) | 68% (13 of 19) |
| it charged on its next turn | 0% (0 of 15) | 0% (0 of 4) | 0% (0 of 19) |
| the enemy charged it first | 7% (1 of 15) | 0% (0 of 4) | 5% (1 of 19) |
| it fought by the end of its next turn | 7% (1 of 15) | 0% (0 of 4) | 5% (1 of 19) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 15) | 0% (0 of 4) | 0% (0 of 19) |
| none of these (no charge, no fight, no charge escaped) | 87% (13 of 15) | 100% (4 of 4) | 89% (17 of 19) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 32% (9 of 28) | 48% (22 of 46) | 42% (31 of 74) |
|   cavalry | - | 75% (9 of 12) | 75% (9 of 12) |
|   character | - | 38% (3 of 8) | 38% (3 of 8) |
|   chariot | - | 50% (1 of 2) | 50% (1 of 2) |
|   infantry | 32% (9 of 28) | 32% (6 of 19) | 32% (15 of 47) |
|   monster | - | 60% (3 of 5) | 60% (3 of 5) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (42%) | 1.3 (17%) | 4.0 (28%) |
| CHARGED: it charged | 0.0 (0%) | 0.3 (4%) | 0.3 (2%) |
| FLEEING: it fled or was fleeing | 0.3 (5%) | 0.0 (0%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.3 (5%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 2.0 (32%) | 5.3 (67%) | 7.3 (51%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (4%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (16%) | 0.7 (8%) | 1.7 (12%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.7 | 2.0 | 64% | 3.2 pts | 15 pts |
| character | 1.0 | 0.7 | 33% | 4.4 pts | 4 pts |
| chariot | 0.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 5.0 | 1.7 | 73% | 3.0 pts | 15 pts |
| monster | 1.0 | 0.3 | 67% | 2.7 pts | 3 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.3 | 2.3 | 1.3 |
| Charges that made contact a game | 0.0 | 2.0 | 1.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.07 declared, 0.00 contact (15 units) | 0.22 declared, 0.19 contact (32 units) | 0.17 declared, 0.13 contact (47 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (2 of 3) | - | - | 67% (2 of 3) |
| Character in a unit | 40% (2 of 5) | 80% (8 of 10) | - | 67% (10 of 15) |
| Character on its own | - | 100% (1 of 1) | 100% (1 of 1) | 100% (2 of 2) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 80% (4 of 5) | 14% (1 of 7) | - | 42% (5 of 12) |
| Monster | 0% (0 of 1) | 100% (1 of 1) | - | 50% (1 of 2) |
| Monstrous | 50% (1 of 2) | 50% (1 of 2) | - | 50% (2 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 80% (4 of 5); on the table 80% | 27% (29 of 108) | 62% | 48% (10 of 21) | 100% (5 of 5); 4.5 uses a game | 100% (3 of 3); 1.0 uses a game | 80% (4 of 5); 1.0 uses a game |
| Ogre Kingdoms | 1 | - | - | 65% | 71% (5 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (1 of 1); on the table 100% | 33% (2 of 6) | 90% | 75% (9 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p1, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (2) | - | 50% (2) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.00 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: gs3-83c8646-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.0 | 1.7 |
| Strategy | Charge objectives carried out (made contact) | - | 33% (2 of 6) |
| Strategy | Shoot objectives carried out (shot that target) | 5% (1 of 19) | 25% (4 of 16) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 2) | 60% (3 of 5) |
| Strategy | Joined characters whose unit fought | 47% (8 of 17) | 14% (1 of 7) |
| Strategy | Lone characters that fought | 100% (1 of 1) | 0% (0 of 3) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.0 | 5.0 |
| Movement | Points that never moved of their own | 36.7 | 150.7 |
| Movement | Fights charged into per game | 0.0 | 1.7 |
| Movement | Charges with odds: long shots (under 50%) | - | 0 of 5 |
| Movement | Charges with odds: sweet spot (55-75%) | - | 1 of 5, net -102 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | - | 0 of 5 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | - | 3 of 5, net +90 |
| Shooting | Shots by shooting units (incl. breath weapons) | 3.0 | 7.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (4 of 9) | 64% (14 of 22) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 5.7 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 12% (2 of 17) | 0% (0 of 3) |
| Magic | Wounds caused by magic missiles | 20.0 | 9.0 |
| Magic | Wounds caused by other spells | 0.7 | - |
| Magic | Points destroyed by magic (all spells) | 344.7 | 40.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 6.0 / 0.7 / 2.3 / 0.0 | 2.7 / 1.7 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 30.0 | 50.0 |
| Combat | Points run down | 0.0 | 21.7 |
| Combat | Net points per charged fight, damage counted | - | +44 |
| Combat | Net per 100 charger points, damage counted | - | +29.1 |
| Combat | First round won (charged fights) | - | 40% |
| Combat | Net points per charged fight | - | +16 |
| Combat | Net points per supported fight / lone fight | - / - | -90 / +42 |
| Combat | Charged fights on a top-3 enemy unit | - | 3 of 5 |
| Game | Points lost | 151.7 | 634.3 |
| Game | VP from objectives | 853.3 | 616.7 |
| Game | Lone holders (player turns) | 4.0 | 2.7 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +739 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 786
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 98.3 |
| ARMY TABLE | 5.3 | +118.2 | 0.0 | 120.0 | 16.7 | +66.9 | 0.0 | 152.0 |
| ASSAILMENT BY POINTS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | - | - | - | - | 1.3 | +13.8 | 36.7 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 7.0 | +513.2 | 500.7 | 0.0 | 1.3 | +36.2 | 43.3 | 0.0 |
| CASTS AFTER FRIENDS | 4.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | - | - | - | - | 0.3 | +72.6 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.3 | +36.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +7.9 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 14.3 | -233.1 | 0.0 | 108.3 | 10.7 | -509.3 | 0.0 | 531.3 |
| CHARGE NOW FIRST | - | - | - | - | 0.3 | +0.0 | 18.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 5.0 | +0.0 | 0.0 | 36.7 | 15.0 | +0.0 | 0.0 | 206.7 |
| CONVEYANCE SEARCH | 5.7 | +705.7 | 0.0 | 0.0 | 1.7 | +38.0 | 0.0 | 0.0 |
| COVER ONCE | 1.0 | -16.6 | 0.0 | 0.0 | 3.7 | -120.6 | 0.0 | 83.7 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -3.5 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 5.0 | +41.5 | 0.0 | 0.0 | 10.0 | -145.9 | 0.0 | 211.3 |
| EVASIVE BY THE ODDS | - | - | - | - | 1.0 | +9.6 | 21.7 | 0.0 |
| EXACT ROUND | - | - | - | - | 1.3 | +56.1 | 36.7 | 34.0 |
| FALL BACK GOOD ORDER | - | - | - | - | 1.7 | +0.0 | 18.3 | 34.0 |
| FALLS SHORT | - | - | - | - | 17.7 | +227.9 | 0.0 | 503.3 |
| FEATURE BUFFS | 12.0 | +496.0 | 0.0 | 200.0 | 1.3 | +50.3 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.3 | +5.0 | 0.0 | 34.0 |
| FIVE ACTION | 47.7 | +7197.5 | 584.0 | 335.0 | 90.0 | +3528.9 | 153.3 | 1570.7 |
| FLANK NOT WEIGHED | 0.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| FOOT FIRST | - | - | - | - | 10.0 | +0.0 | 0.0 | 117.3 |
| FOUR ROUNDS | - | - | - | - | 2.0 | +51.3 | 36.7 | 34.0 |
| GOAL WALK | 5.3 | +638.3 | 0.0 | 0.0 | - | - | - | - |
| GROUND FLIERS | - | - | - | - | 0.3 | +6.1 | 0.0 | 0.0 |
| GUN FIGURES | - | - | - | - | 0.3 | +0.0 | 0.0 | 61.7 |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 152.0 |
| HIS CHARGE BY HIS RUN | 4.3 | +0.0 | 0.0 | 65.0 | 5.3 | +0.0 | 0.0 | 250.7 |
| HIS CHARGE LIST | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.3 | +0.0 | 0.0 | 21.7 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.7 | -42.5 | 0.0 | 73.3 | 6.3 | -205.1 | 0.0 | 56.0 |
| HIS ONE QUARTER | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 90.0 |
| HIS OWN BEST MOVE | 3.3 | +0.0 | 0.0 | 21.7 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 6.7 | +0.0 | 0.0 | 86.7 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.0 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 23.0 | +345.1 | 0.0 | 160.0 | 49.7 | +2341.3 | 0.0 | 586.0 |
| HIS SHOTS BY HIS RUN | 24.3 | +111.1 | 0.0 | 298.3 | 35.7 | +606.2 | 0.0 | 587.3 |
| HIS TURN DENIED | - | - | - | - | 0.3 | +34.9 | 0.0 | 0.0 |
| HOLD ODDS | 31.0 | +0.0 | 0.0 | 331.7 | 14.0 | +0.0 | 0.0 | 56.0 |
| HOLDER ASSIGNMENT | 15.3 | +1728.8 | 0.0 | 101.7 | 10.3 | +1074.9 | 0.0 | 66.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | - | - | - | - | 1.3 | -24.3 | 36.7 | 34.0 |
| IDLE COST | - | - | - | - | 28.0 | -311.3 | 0.0 | 695.3 |
| KEPT FROM ITS LAST STOP | 2.0 | +0.0 | 0.0 | 36.7 | 1.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 8.0 | +0.0 | 0.0 | 248.3 | - | - | - | - |
| LONE WIZARD KEPT IN | 3.0 | +270.0 | 0.0 | 0.0 | 0.7 | +87.5 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 1.0 | +1.8 | 18.3 | 34.0 |
| LOST AFTER ESCAPE | - | - | - | - | 1.3 | +4.5 | 0.0 | 34.0 |
| MANOEUVRE | 1.0 | +10.7 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 1.3 | +129.1 | 0.0 | 0.0 | 0.3 | +2.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +17.4 | 0.0 | 0.0 | 1.7 | +89.5 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +98.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | -51.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.7 | +28.3 | 0.0 | 18.3 | 0.7 | +5.6 | 0.0 | 0.0 |
| MEETS IN TIME | 1.7 | +224.8 | 0.0 | 0.0 | 7.7 | +309.7 | 0.0 | 211.3 |
| MISSILES IN THE MOVE | 7.7 | +474.6 | 0.0 | 0.0 | 7.0 | +102.9 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 8.0 | +335.7 | 0.0 | 0.0 | 6.3 | +59.1 | 0.0 | 0.0 |
| MISSILES ON ONE TARGET | 1.7 | -77.8 | 0.0 | 0.0 | 0.7 | -4.1 | 0.0 | 0.0 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 83.7 |
| MOVE SPELL OUT OF RANGE | 2.0 | -173.4 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 0.3 | +54.5 | 0.0 | 0.0 | 1.7 | +64.6 | 0.0 | 0.0 |
| MOVES UNITS SPELL | - | - | - | - | 0.3 | +18.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.7 | +262.9 | 0.0 | 21.7 | 3.0 | +141.5 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 0.3 | +54.5 | 0.0 | 0.0 | 1.3 | +60.9 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | - | - | - | - | 1.7 | -63.2 | 36.7 | 34.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 3.0 | -5.1 | 0.0 | 0.0 | 1.0 | -1.5 | 0.0 | 0.0 |
| OFF BEST | 0.7 | -4.5 | 0.0 | 21.7 | 1.7 | -11.5 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 3.3 | -78.9 | 0.0 | 36.7 | 1.7 | -21.9 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 7.3 | +131.9 | 0.0 | 61.7 | 4.0 | +9.5 | 0.0 | 28.0 |
| ONE ROUTE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 0.7 | +1.1 | 83.3 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | - | - | - | - | 0.7 | +22.8 | 36.7 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +17.6 | 0.0 | 0.0 |
| PLAN RESULT | 21.3 | +261.9 | 113.3 | 181.7 | 41.3 | +118.9 | 21.7 | 630.3 |
| PROMISE BY ITS OWN SUM | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| QUARTER ODDS | 9.3 | +1732.7 | 0.0 | 0.0 | 12.7 | +1779.3 | 36.7 | 90.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 1.7 | +41.3 | 0.0 | 0.0 |
| REAL GROUND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.3 | +8.7 | 0.0 | 18.3 | 4.0 | +0.7 | 0.0 | 28.0 |
| REDIRECT FOR A FRIEND IN REACH | 1.3 | +0.0 | 0.0 | 73.3 | 5.3 | +0.0 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +9.9 | 0.0 | 0.0 |
| RESERVE MOVE SPELL | 1.7 | +83.1 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | - | - | - | - | 1.0 | -25.0 | 36.7 | 34.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.3 | -1.2 | 0.0 | 0.0 |
| RUN DOWN | - | - | - | - | 1.3 | -10.1 | 36.7 | 0.0 |
| SCOUT SPOT | 1.0 | +1.2 | 0.0 | 0.0 | 0.7 | +2.1 | 0.0 | 0.0 |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | -139.2 | 0.0 | 0.0 |
| SEARCH SPOT | 1.0 | +38.5 | 0.0 | 0.0 | 0.7 | -1.3 | 0.0 | 78.0 |
| SET-UP ANY TARGET | 0.3 | +9.8 | 0.0 | 0.0 | 0.3 | +45.9 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.7 | -1.3 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 36.7 |
| SHOOTERS ON THE TABLE | 5.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 156.0 |
| SHOOTS FROM THE BEST SPOT | 5.0 | +184.9 | 83.3 | 0.0 | 3.0 | +47.4 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.7 | -2.6 | 18.3 | 0.0 |
| SHOT RISK POINTS | 17.7 | -255.1 | 0.0 | 215.0 | 51.0 | +269.3 | 0.0 | 647.3 |
| SHOTS AFTER THE MOVES | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 3.3 | +50.9 | 0.0 | 43.3 | 8.3 | +62.0 | 0.0 | 537.0 |
| SPELL SETS UP CHARGE | 0.3 | +9.8 | 0.0 | 0.0 | 0.3 | +45.9 | 0.0 | 0.0 |
| SPELL WORTH | 1.7 | +3.7 | 0.0 | 0.0 | 3.0 | +24.7 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 5.0 | +0.0 | 0.0 | 98.3 | 4.7 | +0.0 | 0.0 | 141.7 |
| STANDS FOR A REASON | - | - | - | - | 10.7 | +0.0 | 0.0 | 627.3 |
| STANDS STILL | 19.3 | +0.0 | 584.0 | 55.0 | 26.3 | +0.0 | 116.7 | 783.3 |
| STAY WORTH | 9.3 | +148.9 | 417.3 | 65.0 | 13.0 | +79.2 | 116.7 | 849.0 |
| STRIKE BY THE ODDS | - | - | - | - | 1.3 | +18.0 | 63.3 | 64.0 |
| STUBBORN BY POINTS | - | - | - | - | 0.3 | +9.9 | 0.0 | 34.0 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.7 | +0.3 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | - | - | - | - | 3.3 | +0.0 | 0.0 | 113.7 |
| THE ROW KEEPS ITS WAY | 0.7 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 55.0 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 22.3 | +0.0 | 0.0 | 156.7 | 43.7 | +0.0 | 0.0 | 753.3 |
| TIED UP BY THE SUM | - | - | - | - | 0.3 | +7.8 | 18.3 | 0.0 |
| TIME ON OUR SIDE | 22.3 | +580.7 | 0.0 | 211.7 | 4.0 | +39.6 | 0.0 | 0.0 |
| WAITS AGAIN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -7.9 | 0.0 | 0.0 |
| WHO FIGHTS | - | - | - | - | 0.7 | -79.7 | 0.0 | 34.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +4.5 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.0 | -35.9 | 0.0 | 43.3 | - | - | - | - |
| WOUNDS ON THE RANKS | 8.0 | +171.9 | 0.0 | 0.0 | 1.3 | +61.7 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 77 | 77 | 69 | 23.00 | +3954 | +57.3 |
| HIS SHOT LIST | 218 | 218 | 62 | 20.67 | +619 | +10.0 |
| ARMY TABLE | 66 | 66 | 51 | 17.00 | +558 | +10.9 |
| HIS SHOTS BY HIS RUN | 180 | 180 | 47 | 15.67 | +349 | +7.4 |
| SHOT RISK POINTS | 206 | 206 | 38 | 12.67 | +260 | +6.8 |
| DEPLOY BY FIGURES | 45 | 45 | 30 | 10.00 | +432 | +14.4 |
| CASTING BLOCK | 25 | 25 | 25 | 8.33 | +540 | +21.6 |
| LEGAL CHARGES ONLY | 24 | 24 | 24 | 8.00 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 20 | 6.67 | +0 | +0.0 |
| IDLE COST | 84 | 67 | 15 | 5.00 | +92 | +6.1 |
| MEETS IN TIME | 28 | 28 | 14 | 4.67 | +257 | +18.3 |
| TIME ON OUR SIDE | 79 | 67 | 13 | 4.33 | +252 | +19.4 |
| GOAL WALK | 16 | 16 | 11 | 3.67 | +1396 | +126.9 |
| HARD STAY DROPPED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 11 | 11 | 11 | 3.67 | +1073 | +97.5 |
| SHOOTS FROM THE BEST SPOT | 24 | 24 | 11 | 3.67 | +208 | +18.9 |
| WOUNDS ON THE RANKS | 28 | 28 | 10 | 3.33 | +153 | +15.3 |
| STAY WORTH | 67 | 54 | 9 | 3.00 | +85 | +9.4 |
| CASTER AWAY FROM SCREEN | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| FEATURE BUFFS | 40 | 40 | 8 | 2.67 | +40 | +5.0 |
| MOVE ORDER | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| OFF BEST | 7 | 7 | 7 | 2.33 | -48 | -6.9 |
| QUARTER ODDS | 66 | 66 | 6 | 2.00 | +861 | +143.5 |
| SCOUT WAITS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| FALLS SHORT | 53 | 41 | 5 | 1.67 | +89 | +17.9 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| MARCH BY THE SUM | 5 | 5 | 5 | 1.67 | +393 | +78.7 |
| MARCH CHECK | 6 | 6 | 5 | 1.67 | +188 | +37.6 |
| MAX FOR POSITIONING | 7 | 7 | 5 | 1.67 | +9 | +1.8 |
| MISSILES IN THE MOVE | 44 | 30 | 5 | 1.67 | +292 | +58.4 |
| REDIRECT COUNTER | 13 | 9 | 5 | 1.67 | +62 | +12.4 |
| RESERVE MOVE SPELL | 5 | 5 | 5 | 1.67 | +250 | +49.9 |
| CHAFF IN THE MOVE | 4 | 4 | 4 | 1.33 | +51 | +12.7 |
| FIVE ACTION | 413 | 413 | 4 | 1.33 | +99 | +24.8 |
| ONE OBJECTIVE FORMULA | 34 | 19 | 4 | 1.33 | +128 | +31.9 |
| RANDOM MOVE BY FIGURES | 5 | 5 | 4 | 1.33 | +124 | +31.0 |
| SEARCH SPOT | 5 | 5 | 4 | 1.33 | +121 | +30.3 |
| STRIKE BY THE ODDS | 4 | 4 | 4 | 1.33 | +54 | +13.5 |
| CHARGE LOSSES | 75 | 75 | 3 | 1.00 | +32 | +10.7 |
| COVER ONCE | 14 | 8 | 3 | 1.00 | +17 | +5.8 |
| MISSILES NEXT TURN | 43 | 30 | 3 | 1.00 | +9 | +3.1 |
| MOVE TO CHARGE COMPUTED | 6 | 6 | 3 | 1.00 | +158 | +52.6 |
| NEXT CHARGE BY LIST | 5 | 5 | 3 | 1.00 | +158 | +52.6 |
| CAST JOB | 4 | 4 | 2 | 0.67 | +0 | +0.0 |
| NEARER NOT NEEDED | 26 | 23 | 2 | 0.67 | +63 | +31.5 |
| SWIFTSTRIDE BY POINTS | 2 | 2 | 2 | 0.67 | +1 | +0.4 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.1 |
| CATCH ODDS | 1 | 1 | 1 | 0.33 | -199 | -199.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +24 | +23.6 |
| EVASIVE BY THE ODDS | 3 | 3 | 1 | 0.33 | +4 | +4.1 |
| EXACT ROUND | 4 | 4 | 1 | 0.33 | +75 | +75.0 |
| FOUR ROUNDS | 6 | 6 | 1 | 0.33 | +15 | +15.1 |
| LANE BY FIGURES | 1 | 1 | 1 | 0.33 | +2 | +1.7 |
| LONG SHOT | 3 | 3 | 1 | 0.33 | +12 | +12.0 |
| MANOEUVRE | 5 | 5 | 1 | 0.33 | +32 | +32.1 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -295 | -294.6 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| ONE FIGHT FORMULA | 15 | 11 | 1 | 0.33 | +2 | +2.3 |
| OVERRUNS AWAY | 2 | 2 | 1 | 0.33 | +32 | +32.3 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +53 | +52.8 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | +0 | +0.5 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +30 | +29.6 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SHOTS IN THE MOVE | 35 | 23 | 1 | 0.33 | +9 | +8.6 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +30 | +29.6 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 10 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 6 | 6 | 1 | 0.33 | +14 | +13.5 |
| CASTS AFTER FRIENDS | 18 | trace | - | - | - | - |
| CHARGE NOW FIRST | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 60 | 60 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 22 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 5 | 5 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 14 | not checked | - | - | - | - |
| FOOT FIRST | 30 | not checked | - | - | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 1 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 29 | 29 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 12 | 12 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 25 | 25 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 33 | 33 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 10 | 10 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 25 | 25 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 20 | 20 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 6 | 6 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HOLD ODDS | 135 | 135 | 0 | 0.00 | - | - |
| HONEST WORTH | 4 | 4 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 11 | 11 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 4 | 4 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 1 | 1 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 7 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 6 | trace | - | - | - | - |
| MOVE SPELL SPOT | 6 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 5 | 5 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 12 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE ROUTE | 1 | 1 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS A LANE | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 188 | trace | - | - | - | - |
| PROMISE BY ITS OWN SUM | 4 | 4 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 1 | 1 | 0 | 0.00 | - | - |
| RISK BY ARC | 3 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 4 | 4 | 0 | 0.00 | - | - |
| SCOUT SPOT | 5 | 5 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 2 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 32 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 8 | 8 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 2 | not checked | - | - | - | - |
| SPELL WORTH | 14 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 29 | 29 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 32 | 32 | 0 | 0.00 | - | - |
| STANDS STILL | 137 | 137 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 25 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 14 | not checked | - | - | - | - |
| THE TABLE BINDS | 198 | not checked | - | - | - | - |
| TIED UP BY THE SUM | 1 | 1 | 0 | 0.00 | - | - |
| WAITS AGAIN | 2 | 2 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 0.67 | 1.67 | 6.9 |
| HOLDER ASSIGNMENT | rule | 0.67 | 1.00 | 7.2 |
| ARMY TABLE | rule | 0.67 | - | 49.3 |
| CATCH ODDS | rule | - | 0.33 | 199.0 |
| MARCH OF THE TABLE | rule | 0.33 | - | 294.6 |

### Plans: gs3-83c8646-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | move | 16.3 | 86% | 1892 | 0 | 0% |
| Mine | shoot | 5.0 | 47% | 1053 | 262 | 25% |
| Opponent | charge | 1.0 | 67% | 17 | 42 | 248% |
| Opponent | move | 35.0 | 90% | 1035 | 0 | 0% |
| Opponent | shoot | 4.7 | 50% | 267 | 77 | 29% |
| Opponent | support | 0.7 | 100% | 9 | 0 | 0% |

### Battle groups: gs3-83c8646-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 4.0 | 8% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 3 | 0 (3) | 0 | 0 | 100 | 33% | 2.0 | 0 (1) | 0 (1) | 0 (1) | 0 (2) | 0 (1) |
| Mine | Character | 18 | 35 (18) | 35 | 0 | 3 | 22% | 1.9 | 76 (3) | 36 (11) | 0 (3) | 56 (11) | 0 (6) |
| Mine | Hammer | 6 | 48 (6) | 4 | 44 | 0 | 50% | 5.0 | 75 (1) | 53 (4) | 0 (1) | 48 (4) | 47 (2) |
| Mine | Holder | 3 | 65 (3) | 0 | 65 | 0 | 100% | - | - | 97 (2) | - | 195 (1) | 0 (1) |
| Mine | Shooter | 6 | 69 (6) | 0 | 69 | 50 | 17% | 2.2 | - | 83 (5) | 0 (1) | 92 (4) | 23 (2) |
| Opponent | Chaff | 6 | 94 (6) | 0 | 94 | 27 | 83% | 3.0 | 0 (3) | 343 (2) | 0 (1) | 94 (6) | - |
| Opponent | Character | 8 | 6 (8) | 6 | 0 | 11 | 25% | 1.3 | 0 (4) | 13 (4) | - | 6 (4) | 6 (4) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 7 | 34 (7) | 9 | 25 | 0 | 57% | 2.0 | 95 (1) | 0 (3) | 25 (3) | 29 (3) | 36 (4) |
| Opponent | Hammer | 13 | 20 (13) | 10 | 11 | 54 | 38% | 2.5 | - | 29 (8) | 0 (5) | 16 (3) | 22 (10) |
| Opponent | Holder | 1 | 179 (1) | 0 | 179 | 100 | 100% | - | - | 179 (1) | - | - | 179 (1) |
| Opponent | Shooter | 3 | 74 (3) | 0 | 74 | 62 | 67% | 1.0 | 193 (1) | 0 (2) | - | 193 (1) | 0 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (2) | - | 0 (2) | - |

### Charged fights: gs3-83c8646-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 345 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Beastmen Brayherds | 1 | 65 | 150 | 2.0 | 1.0 | 75 | 0 | +75 | 1 of 2 | 1 of 2 | - | +75 |
| Opponent | Ogre Kingdoms | 1 | 55 | 0 | 1.0 | 2.0 | 0 | 90 | -90 | 1 of 1 | 0 of 1 | -90 | - |
| Opponent | Wood Elf Realms | 1 | 0 | 120 | 2.0 | 1.0 | 60 | 51 | +9 | 1 of 2 | 1 of 2 | - | +9 |
| **Opponent** | all armies | 3 | 40 | 90 | 1.7 | 1.2 | 54 | 38 | +16 | 3 of 5 | 2 of 5 | -90 | +42 |

### Effective charges: gs3-83c8646-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Beastmen Brayherds | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +75) | 0 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 1 | 0 | 0 | 0 | 1 (net -90) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Wood Elf Realms | 2 | 0 | 0 | 1 (net -102) | 0 | 0 | 1 (net +120) | 0 | 50% (1 of 2) |

### Charged fights, damage counted: gs3-83c8646-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Effective (55-75%) | 1 | 102 | 322 | -102 | 32 | 143 | -111 | -108.6 |
| Opponent | 76-89% | 1 | 387 | 322 | -90 | 136 | 189 | -53 | -13.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 91 | 144 | +90 | 152 | 24 | +128 | +141.6 |
| Opponent | All fights | 5 | 152 | 215 | +16 | 125 | 81 | +44 | +29.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p1 | move | 5 | 1 (20%) | 1 (20%) | 1 (20%) | 3 (60%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135 |
| Fistful of Laurels | Opponent | L0118 |
| Ring of Doom | Opponent | L0102 |

# Doctrine scorecard: gs3-83c8646-p33

### Scorecard: gs3-83c8646-p33

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1535 | 5 | 1 | Mine | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 3 | 1 | 3 | 0 | 0 | 0 | 609 |
| L1633 | 1 | 1 | Mine | yes | 7 | 2 | 4 | 1 | 0 | 0 | 0 | 307 |
| L1633 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 4 | 0 | 0 | 0 | 368 |
| L1731 | 3 | 1 | Mine | yes | 7 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Opponent | no | 0 | - | 1 | 1 | 1 | 0 | 0 | 340 |
| **Average** | | | Mine | 100% | 7.0 | 2.0 | 4.3 | 1.0 | 0.0 | 0.0 | 0.0 | 102.3 |
| **Average** | | | Opponent | 33% | 0.0 | 2.5 | 1.3 | 2.7 | 0.3 | 0.0 | 0.0 | 439.0 |

### KPIs: gs3-83c8646-p33

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 16) | 12% (2 of 16) | 6% (2 of 32) |
| Winner chose to follow up after the loser gave ground |  | 88% (7 of 8); on the table 88% | 100% (3 of 3); on the table 100% | 91% (10 of 11); on the table 91% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (2 of 2); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | 25% (1 of 4); on the table 50% | 50% (1 of 2); on the table 50% | 33% (2 of 6); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 67% (8 of 12); on the table 75% | 86% (6 of 7); on the table 86% | 74% (14 of 19); on the table 79% |
| Magic missiles tried each own turn | 50%+ | 67% (8 of 12) | 33% (2 of 6) | 56% (10 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 73% (8 of 11) | 40% (2 of 5) | 62% (10 of 16) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 38% (3 of 8) | 38% (3 of 8) |
| Points that never fought | lower | 40% (2408 of 6000) | 39% (2323 of 6000) | 39% (4731 of 12000) |
|   infantry points that never fought | lower | 61% (807 of 1332) | 47% (715 of 1529) | 53% (1522 of 2861) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 60% (12 of 20) | 79% (27 of 34) | 72% (39 of 54) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.3 uses a game | 100% (4 of 4); 2.7 uses a game | 100% (6 of 6); 2.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 64% (3285 of 5135) | 82% (4862 of 5962) | 73% (8147 of 11097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (75%) | 0.0 (0%) | 1.0 (38%) |
| MARCHED: its unit marched | 0.0 (0%) | 1.0 (75%) | 1.0 (38%) |
| IN COMBAT: engaged in combat | 0.3 (25%) | 0.0 (0%) | 0.3 (12%) |
| GONE: slain | 0.0 (0%) | 0.3 (25%) | 0.3 (12%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.0 | 0.3 | 3.7 | 3.3 | 0.3 | 0.0 |
| not cast | 3.0 | 1.7 | 2.3 | 2.7 | 1.7 | 12.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.7 (100%) | 0.3 (14%) | 1.0 (38%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (38%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.3 (14%) | 0.3 (12%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 1.3 (57%) | 0.3 (12%) | 1.3 (80%) | 3.0 (25%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.7 (22%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (20%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (78%) | 0.0 (0%) | 0.3 (14%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 8.7 (72%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.0 a game | 1.7 a game | 1.8 a game |
| stood (cast and not dispelled) | - | 40% (2 of 5) | 40% (2 of 5) |
| the unit moved after it | - | 0% (0 of 2) | 0% (0 of 2) |
| it charged on its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| the enemy charged it first | - | 0% (0 of 2) | 0% (0 of 2) |
| it fought by the end of its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 2) | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (2 of 2) | 100% (2 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (51 of 84) | 66% (41 of 62) | 63% (92 of 146) |
|   cavalry | 75% (6 of 8) | 56% (14 of 25) | 61% (20 of 33) |
|   character | 62% (5 of 8) | 77% (10 of 13) | 71% (15 of 21) |
|   chariot | 0% (0 of 5) | - | 0% (0 of 5) |
|   infantry | 68% (25 of 37) | 71% (17 of 24) | 69% (42 of 61) |
|   monster | 35% (6 of 17) | - | 35% (6 of 17) |
|   war machine | 100% (9 of 9) | - | 100% (9 of 9) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (15%) | 2.0 (29%) | 3.7 (20%) |
| CHARGED: it charged | 1.3 (12%) | 1.0 (14%) | 2.3 (13%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.7 (10%) | 0.7 (4%) |
| IN COMBAT: it fought this turn or the last | 1.3 (12%) | 1.0 (14%) | 2.3 (13%) |
| NO TARGET IN RANGE | 5.7 (52%) | 0.0 (0%) | 5.7 (31%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (6%) | 1.0 (14%) | 1.7 (9%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (3%) | 1.3 (19%) | 1.7 (9%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.7 | 3.0 | 74% | 9.3 pts | 71 pts |
| character | 6.0 | 0.7 | 89% | 1.8 pts | 11 pts |
| infantry | 21.3 | 8.7 | 77% | 9.9 pts | 211 pts |
| monster | 2.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 3.0 | 2.3 | 67% | 14.5 pts | 43 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.3 | 2.3 | 3.3 |
| Charges that made contact a game | 3.7 | 2.0 | 2.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.50 contact (2 units) | 0.00 declared, 0.00 contact (1 units) | 0.33 declared, 0.33 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | - | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.57 declared, 0.48 contact (21 units) | 0.29 declared, 0.25 contact (24 units) | 0.42 declared, 0.36 contact (45 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 88% (7 of 8) | 100% (1 of 1) | 100% (1 of 1) | 90% (9 of 10) |
| Character in a unit | 100% (4 of 4) | 100% (1 of 1) | 100% (2 of 2) | 100% (7 of 7) |
| Character on its own | 67% (2 of 3) | 0% (0 of 3) | 83% (5 of 6) | 58% (7 of 12) |
| Chariot | 100% (1 of 1) | - | - | 100% (1 of 1) |
| Infantry | 73% (8 of 11) | 40% (2 of 5) | - | 62% (10 of 16) |
| Monster | 80% (4 of 5) | - | - | 80% (4 of 5) |
| Monstrous | 33% (1 of 3) | - | - | 33% (1 of 3) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 1 | 50% (1 of 2); on the table 50% | 50% (3 of 6) | 61% | 71% (5 of 7) | 100% (2 of 2); 7.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 60% (3 of 5); on the table 80% | - | 39% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | 80% (4 of 5); on the table 80% | 83% (5 of 6) | 21% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 0% (0 of 1); on the table 0% | 33% (2 of 6) | 29% | 100% (12 of 12) | 100% (1 of 1); 5.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 2 | 100% (6 of 6); on the table 100% | - | 44% | 68% (15 of 22) | 100% (3 of 3); 1.5 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p33, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (2) | 20% (1) | 33% (3) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: gs3-83c8646-p33

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.0 | 2.3 |
| Strategy | Charge objectives carried out (made contact) | 73% (8 of 11) | 100% (2 of 2) |
| Strategy | Shoot objectives carried out (shot that target) | 73% (11 of 15) | 10% (1 of 10) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 0% (0 of 1) | 57% (4 of 7) |
| Strategy | Lone characters that fought | 88% (7 of 8) | 50% (2 of 4) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 1.0 | 2.7 |
| Movement | Points that never moved of their own | 102.3 | 439.0 |
| Movement | Fights charged into per game | 3.7 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 10, net +0 | 0 of 2 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 10 | 0 of 2 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 10, net +0 | 0 of 2 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 of 10, net +78 | 0 of 2 |
| Shooting | Shots by shooting units (incl. breath weapons) | 16.0 | 13.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 8% (4 of 48) | 49% (20 of 41) |
| Shooting | Points destroyed by shooting units | 38.0 | 53.3 |
| Shooting | War machine shots | 3.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 22% (2 of 9) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.7 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 20% (1 of 5) | - |
| Magic | Wounds caused by magic missiles | 1.3 | - |
| Magic | Points destroyed by magic (all spells) | 65.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 0.0 / 0.0 / 0.0 | 2.3 / 0.3 / 0.0 / 0.3 |
| Combat | Points destroyed in combat | 409.0 | 123.7 |
| Combat | Points run down | 78.7 | 88.0 |
| Combat | Net points per charged fight, damage counted | +114 | +75 |
| Combat | Net per 100 charger points, damage counted | +36.3 | +84.1 |
| Combat | First round won (charged fights) | 73% | 67% |
| Combat | Net points per charged fight | +101 | +75 |
| Combat | Net points per supported fight / lone fight | - / +101 | - / +75 |
| Combat | Charged fights on a top-3 enemy unit | 4 of 11 | 0 of 6 |
| Game | Points lost | 248.3 | 557.3 |
| Game | VP from objectives | 750.0 | 313.3 |
| Game | Lone holders (player turns) | 7.0 | 0.0 |

- Mine won / drew / lost: 3 / 0 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +800 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 806
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: gs3-83c8646-p33

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +27.0 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH WITH FRIENDS | 0.7 | +24.9 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 22.0 | +364.6 | 0.0 | 40.0 | 33.3 | +502.4 | 0.0 | 179.7 |
| BACKUP TARGETS | 0.7 | +5.9 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | 0.3 | -2.9 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 2.7 | +0.5 | 0.0 | 33.3 | - | - | - | - |
| CANNON SIGHT KEPT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.3 | +0.0 | 40.0 | 0.0 | - | - | - | - |
| CAST JOB | 0.3 | +10.6 | 199.7 | 0.0 | 2.3 | +21.8 | 88.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.0 | +10.7 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +6.6 | 0.0 | 0.0 | 0.3 | +11.9 | 0.0 | 0.0 |
| CHARACTER GUNS | - | - | - | - | 6.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 21.0 | -770.7 | 0.0 | 76.7 | 20.7 | -845.8 | 0.0 | 309.7 |
| CHARGE NOW FIRST | 2.7 | +0.0 | 118.7 | 38.3 | 1.0 | +0.0 | 38.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 13.7 | +0.0 | 0.0 | 26.7 | 10.7 | +0.0 | 0.0 | 65.0 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 1.7 | +52.1 | 0.0 | 78.0 |
| COVER ONCE | 11.3 | -779.1 | 0.0 | 146.3 | 9.0 | -535.5 | 0.0 | 170.0 |
| DENIED BY THE FIGHT | 0.7 | -10.0 | 0.0 | 38.3 | - | - | - | - |
| DEPLOY BY FIGURES | 7.3 | -10.9 | 0.0 | 0.0 | 8.0 | -64.1 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.7 | -7.0 | 0.0 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.3 | +56.6 | 0.0 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | - | - | - | - | 0.3 | +11.2 | 0.0 | 0.0 |
| EXACT ROUND | 2.3 | +37.0 | 118.7 | 38.3 | 0.3 | +1.8 | 38.3 | 0.0 |
| FALL BACK GOOD ORDER | 3.0 | +17.1 | 78.7 | 38.3 | 0.7 | +1.0 | 38.3 | 0.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 6.0 | +80.1 | 0.0 | 26.7 | 15.7 | +193.4 | 0.0 | 103.0 |
| FEATURE BUFFS | 1.3 | +10.5 | 0.0 | 0.0 | 0.3 | +8.3 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.0 | +15.5 | 0.0 | 0.0 | 0.3 | +10.7 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 87.3 | +7458.9 | 600.3 | 491.0 | 87.3 | +5081.0 | 166.3 | 633.3 |
| FLANK NOT WEIGHED | 7.3 | +0.0 | 0.0 | 166.3 | 8.3 | +0.0 | 0.0 | 65.0 |
| FOLLOW UP WEIGHED | 2.3 | +396.3 | 0.0 | 38.3 | 0.3 | +47.5 | 0.0 | 0.0 |
| FOOT FIRST | - | - | - | - | 12.3 | +0.0 | 0.0 | 38.0 |
| FOUR ROUNDS | 4.3 | +375.3 | 118.7 | 38.3 | 0.7 | +50.3 | 38.3 | 0.0 |
| FREED FROM HIS FIGHT | 3.7 | +0.0 | 0.0 | 80.0 | 16.7 | +0.0 | 0.0 | 0.0 |
| FRIEND CHARGES FIRST | 0.3 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 1.3 | -3.2 | 0.0 | 0.0 | 1.0 | -7.4 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -12.0 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 10.3 | +2061.1 | 0.0 | 0.0 | 4.3 | +297.9 | 0.0 | 34.7 |
| HARD STAY DROPPED | 3.0 | +0.0 | 0.0 | 20.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.3 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 12.7 | +0.0 | 0.0 | 76.7 | 15.0 | +0.0 | 0.0 | 275.0 |
| HIS CHARGE LIST | 0.7 | +0.0 | 0.0 | 0.0 | 12.0 | +0.0 | 0.0 | 34.7 |
| HIS LEGAL MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 6.3 | -132.9 | 0.0 | 53.3 | 4.0 | -46.8 | 0.0 | 65.0 |
| HIS ONE QUARTER | 6.7 | +0.0 | 0.0 | 176.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 9.3 | +0.0 | 0.0 | 76.7 | 5.3 | +0.0 | 0.0 | 164.7 |
| HIS RANDOM MOVE | 10.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 40.3 | +1916.1 | 0.0 | 386.0 | 54.3 | +2423.6 | 0.0 | 369.0 |
| HIS SHOTS BY HIS RUN | 43.0 | +969.1 | 0.0 | 386.0 | 48.7 | +1250.0 | 0.0 | 435.7 |
| HIS TURN DENIED | 1.0 | +55.9 | 0.0 | 38.3 | - | - | - | - |
| HOLD ODDS | 19.7 | +0.0 | 0.0 | 229.3 | 7.0 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 11.0 | +712.7 | 0.0 | 114.7 | 5.3 | +452.2 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.3 | -156.3 | 118.7 | 38.3 | 0.7 | -15.9 | 38.3 | 0.0 |
| HORN WORTH | - | - | - | - | 0.3 | +6.9 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.7 | +2.7 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | 1.3 | -30.7 | 0.0 | 0.0 | 12.3 | -113.2 | 0.0 | 38.0 |
| JOINT CHARGE NOW | - | - | - | - | 0.3 | +6.3 | 0.0 | 0.0 |
| JOINT ON THE TABLE | - | - | - | - | 0.3 | +6.3 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 3.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.7 | +70.6 | 0.0 | 0.0 | 0.3 | +6.0 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 16.0 | +0.0 | 956.3 | 205.3 | 7.7 | +0.0 | 311.3 | 315.7 |
| LONE WIZARD KEPT IN | 0.3 | +16.9 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.3 | +0.4 | 38.3 | 0.0 |
| LOST AFTER ESCAPE | 3.7 | +3.6 | 118.7 | 0.0 | 0.3 | +0.1 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 1.0 | +16.7 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 2.7 | -39.7 | 0.0 | 20.0 | 4.3 | -16.3 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +82.1 | 0.0 | 0.0 | 0.3 | +52.9 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 0.3 | +20.5 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +15.5 | 0.0 | 65.0 |
| MARCH OVER CASTS | 0.3 | +4.7 | 0.0 | 0.0 | 1.0 | +1.0 | 0.0 | 130.0 |
| MAX FOR POSITIONING | 2.0 | +31.5 | 0.0 | 0.0 | 4.3 | +110.5 | 0.0 | 130.0 |
| MEETS IN TIME | 3.7 | +154.4 | 0.0 | 0.0 | 4.3 | +198.7 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 4.0 | +82.0 | 0.0 | 0.0 | 5.7 | +66.3 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 5.0 | +50.3 | 0.0 | 0.0 | 7.0 | +61.2 | 0.0 | 130.0 |
| MOVE ORDER | 2.0 | +0.0 | 0.0 | 26.7 | 2.3 | +0.0 | 65.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 1.0 | -38.1 | 0.0 | 78.0 |
| MOVE TO CHARGE COMPUTED | 8.3 | +397.2 | 0.0 | 76.7 | 4.7 | +388.0 | 0.0 | 164.7 |
| MOVES UNITS SPELL | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 6.3 | +280.7 | 0.0 | 0.0 | 6.7 | +293.0 | 0.0 | 0.0 |
| NEAREST TO GOAL | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 6.7 | +323.1 | 0.0 | 76.7 | 2.7 | +203.5 | 0.0 | 130.0 |
| NO DOUBLE ROUNDS | 4.0 | -261.1 | 40.0 | 38.3 | 0.7 | -14.5 | 38.3 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | -2.7 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.1 | 0.0 | 0.0 | 0.3 | -0.3 | 0.0 | 0.0 |
| OFF BEST | 6.7 | -223.3 | 0.0 | 0.0 | 7.3 | -158.9 | 0.0 | 105.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 6.3 | -113.5 | 0.0 | 38.3 | 5.3 | -75.1 | 0.0 | 130.0 |
| ONE OBJECTIVE FORMULA | 5.0 | -2.6 | 0.0 | 114.7 | 2.0 | +26.7 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 1.7 | -28.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | - | - | - | - | 0.7 | +0.5 | 40.0 | 0.0 |
| OPENS UP | 0.7 | +39.1 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 2.0 | +55.9 | 118.7 | 38.3 | 0.3 | +0.7 | 38.3 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +4.9 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -6.9 | 0.0 | 0.0 | 0.3 | -4.9 | 0.0 | 0.0 |
| PLAN RESULT | 39.0 | +548.8 | 183.7 | 444.7 | 41.3 | +174.9 | 58.7 | 490.7 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 65.0 |
| PROMISE BY ITS OWN SUM | 9.7 | -163.2 | 0.0 | 0.0 | 6.3 | -228.2 | 0.0 | 34.7 |
| PROMISE IN STEPS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.7 | -0.7 | 0.0 | 0.0 | 1.0 | -7.4 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.7 | -0.5 | 130.0 | 0.0 | 0.7 | -0.3 | 0.0 | 0.0 |
| QUARTER ODDS | 24.7 | +3105.1 | 318.3 | 216.0 | 26.3 | +2936.0 | 166.3 | 210.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 2.7 | +21.7 | 0.0 | 113.3 |
| REDIRECT COUNTER | 1.3 | +12.9 | 0.0 | 26.7 | 0.7 | +54.8 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -41.0 | 0.0 | 0.0 | 1.0 | -34.0 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 1.3 | +46.7 | 0.0 | 0.0 | 0.3 | +15.0 | 0.0 | 0.0 |
| RISK BY ARC | 3.7 | -75.1 | 118.7 | 38.3 | 0.7 | -6.0 | 38.3 | 0.0 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | 1.7 | -45.3 | 78.7 | 0.0 | - | - | - | - |
| RUN DOWN | 3.7 | -76.3 | 118.7 | 38.3 | 0.7 | -0.9 | 38.3 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -14.5 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | -8.8 | 0.0 | 0.0 | 0.3 | +37.0 | 0.0 | 38.0 |
| SECOND LOOK | 0.7 | +21.9 | 40.0 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | 2.0 | +473.5 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 2.3 | -41.0 | 0.0 | 26.7 | 0.7 | -49.3 | 0.0 | 0.0 |
| SET UP BY THE SET | 5.0 | -76.3 | 0.0 | 26.7 | 1.0 | +49.9 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.0 | +16.7 | 0.0 | 0.0 | - | - | - | - |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +44.8 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.7 | -0.2 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 1.0 | +2.0 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 4.3 | +0.0 | 0.0 | 33.3 | 4.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.7 | +44.9 | 76.0 | 0.0 | 0.7 | +7.0 | 0.0 | 0.0 |
| SHOT RISK POINTS | 29.0 | +49.4 | 0.0 | 210.0 | 34.7 | -172.9 | 0.0 | 255.7 |
| SHOTS AFTER THE MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 14.7 | +404.5 | 0.0 | 33.3 | 14.0 | +283.5 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +44.8 | 0.0 | 0.0 |
| SPELL WORTH | 1.3 | +8.2 | 0.0 | 0.0 | 3.7 | +19.3 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 4.3 | +0.0 | 0.0 | 26.7 | 8.0 | +0.0 | 0.0 | 177.7 |
| STAND AND SHOOT | 0.7 | -28.7 | 0.0 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | - | - | - | - | 5.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 24.3 | +0.0 | 481.7 | 106.7 | 32.0 | +0.0 | 128.0 | 228.0 |
| STAY WORTH | 15.3 | +339.0 | 275.7 | 100.0 | 9.0 | +73.9 | 0.0 | 0.0 |
| STUBBORN BY POINTS | 0.3 | +7.4 | 0.0 | 0.0 | - | - | - | - |
| STUPIDITY NEXT TURN | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 4.3 | +118.0 | 0.0 | 40.0 | 9.7 | +862.4 | 0.0 | 114.7 |
| SUPPORT NARROWED | 0.7 | +0.0 | 0.0 | 38.3 | 1.0 | +0.0 | 38.3 | 0.0 |
| SUPPORT WORKED OUT | 4.3 | +118.0 | 0.0 | 40.0 | 9.7 | +862.4 | 0.0 | 114.7 |
| SURE REACH TOGETHER | 0.3 | +2.4 | 0.0 | 0.0 | 1.0 | +4.4 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 65.0 |
| THE ROW IN ITS ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 38.0 |
| THE ROW KEEPS ITS WAY | 2.3 | +0.0 | 0.0 | 20.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 20.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 40.7 | +0.0 | 0.0 | 226.3 | 43.0 | +0.0 | 0.0 | 242.7 |
| TIED UP BY THE SUM | 2.0 | +240.7 | 78.7 | 38.3 | - | - | - | - |
| TIME ON OUR SIDE | 29.7 | +359.5 | 0.0 | 98.3 | 17.3 | +175.7 | 0.0 | 69.3 |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 65.0 |
| WHAT THE JOINER ADDS | 0.7 | -82.2 | 157.3 | 0.0 | 0.7 | -13.5 | 76.7 | 0.0 |
| WHO FIGHTS | 1.0 | -3.8 | 40.0 | 0.0 | 0.3 | -3.1 | 0.0 | 0.0 |
| WHO GETS IN | - | - | - | - | 0.3 | +6.3 | 0.0 | 0.0 |
| WHO HITS BACK | 0.3 | +86.4 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | 0.3 | +50.2 | 78.7 | 0.0 | 0.3 | +3.8 | 38.3 | 0.0 |
| WHOLE FIGHT DANGER | 3.0 | -304.8 | 0.0 | 0.0 | 4.3 | -258.7 | 0.0 | 210.0 |
| WOUNDED STAYS OUT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 2.7 | +22.7 | 0.0 | 0.0 | 1.7 | +72.7 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p33

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 166 | 166 | 97 | 32.33 | +2198 | +22.7 |
| HIS SHOT LIST | 284 | 273 | 80 | 26.67 | +1661 | +20.8 |
| LEGAL CHARGES ONLY | 71 | 71 | 71 | 23.67 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 275 | 265 | 56 | 18.67 | +602 | +10.7 |
| HOLDER ASSIGNMENT | 49 | 49 | 45 | 15.00 | +2460 | +54.7 |
| OFF BEST | 42 | 42 | 42 | 14.00 | -1147 | -27.3 |
| FIVE ACTION | 524 | 500 | 32 | 10.67 | +1169 | +36.5 |
| DEPLOY BY FIGURES | 46 | 46 | 31 | 10.33 | +301 | +9.7 |
| SHOT RISK POINTS | 191 | 180 | 25 | 8.33 | +1083 | +43.3 |
| MOVE TO CHARGE COMPUTED | 39 | 32 | 23 | 7.67 | +811 | +35.3 |
| QUARTER ODDS | 153 | 144 | 23 | 7.67 | +1887 | +82.1 |
| THE TABLE AGAIN | 36 | 36 | 23 | 7.67 | +0 | +0.0 |
| GOAL WALK | 44 | 44 | 22 | 7.33 | +2603 | +118.3 |
| PROMISE BY ITS OWN SUM | 48 | 48 | 19 | 6.33 | -1174 | -61.8 |
| TIME ON OUR SIDE | 141 | 118 | 19 | 6.33 | +65 | +3.4 |
| NEXT CHARGE BY LIST | 28 | 23 | 15 | 5.00 | +385 | +25.7 |
| HARD STAY DROPPED | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| MOVE ORDER | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| FOUR ROUNDS | 15 | 15 | 9 | 3.00 | +398 | +44.3 |
| MEETS IN TIME | 24 | 24 | 9 | 3.00 | +788 | +87.5 |
| FOLLOW UP WEIGHED | 8 | 8 | 8 | 2.67 | +1331 | +166.4 |
| SUPPORT ADDS | 42 | 38 | 8 | 2.67 | +424 | +53.0 |
| SUPPORT WORKED OUT | 42 | 38 | 8 | 2.67 | +424 | +53.0 |
| CHARGE LOSSES | 125 | 121 | 7 | 2.33 | +297 | +42.4 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +230 | +38.3 |
| SHOOTS FROM THE BEST SPOT | 7 | 7 | 6 | 2.00 | +27 | +4.5 |
| COVER ONCE | 61 | 34 | 5 | 1.67 | +95 | +19.0 |
| ONE PROMISE A TARGET | 5 | 5 | 5 | 1.67 | -84 | -16.8 |
| RESERVE FALL BACK | 5 | 5 | 5 | 1.67 | +185 | +37.0 |
| TIED UP BY THE SUM | 6 | 6 | 5 | 1.67 | +265 | +53.0 |
| CAST JOB | 8 | 8 | 4 | 1.33 | +2 | +0.6 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| PROMISE SHOT AWAY | 4 | 4 | 4 | 1.33 | -2 | -0.6 |
| SET UP BY THE SET | 18 | 18 | 4 | 1.33 | -10 | -2.4 |
| SHOOTERS IN TWO RANKS | 4 | 4 | 4 | 1.33 | +7 | +1.8 |
| WHOLE FIGHT DANGER | 22 | 22 | 4 | 1.33 | +191 | +47.8 |
| CHARGE NOW FIRST | 11 | 11 | 3 | 1.00 | -55 | -18.2 |
| IDLE COST | 41 | 28 | 3 | 1.00 | +1 | +0.4 |
| RANDOM MOVE BY FIGURES | 8 | 8 | 3 | 1.00 | +65 | +21.7 |
| SHOTS IN THE MOVE | 86 | 58 | 3 | 1.00 | +69 | +22.9 |
| STAY WORTH | 73 | 61 | 3 | 1.00 | +16 | +5.4 |
| AFTERMATH WITH FRIENDS | 2 | 2 | 2 | 0.67 | +74 | +37.2 |
| CHAFF IN THE MOVE | 3 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +56 | +27.8 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +405 | +202.6 |
| MAX FOR POSITIONING | 19 | 16 | 2 | 0.67 | +34 | +17.2 |
| MISSILES IN THE MOVE | 29 | 17 | 2 | 0.67 | +13 | +6.6 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.67 | -36 | -17.8 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +66 | +32.9 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +81 | +80.9 |
| CANNON PLANNED TARGET | 8 | 8 | 1 | 0.33 | +0 | +0.0 |
| CANNON SIGHT KEPT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 8 | 8 | 1 | 0.33 | +13 | +12.7 |
| FALL BACK GOOD ORDER | 11 | 11 | 1 | 0.33 | +29 | +29.0 |
| FALLS SHORT | 65 | 51 | 1 | 0.33 | +8 | +8.2 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS MOVE AND SHOT | 31 | 31 | 1 | 0.33 | +20 | +20.0 |
| HIS TURN DENIED | 3 | 3 | 1 | 0.33 | +61 | +61.0 |
| HORN WORTH | 1 | 1 | 1 | 0.33 | +21 | +20.6 |
| JOINT CHARGE NOW | 1 | 1 | 1 | 0.33 | +19 | +18.9 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.33 | +19 | +18.9 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +51 | +50.6 |
| LOST AFTER ESCAPE | 12 | 12 | 1 | 0.33 | +15 | +14.8 |
| MANOEUVRE | 21 | 21 | 1 | 0.33 | +36 | +36.2 |
| MARCH CHECK | 1 | 1 | 1 | 0.33 | +38 | +37.7 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -46 | -46.5 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| NEARER NOT NEEDED | 39 | 38 | 1 | 0.33 | +21 | +21.3 |
| ONE FIGHT FORMULA | 35 | 16 | 1 | 0.33 | +20 | +19.7 |
| OPENS A LANE | 2 | 2 | 1 | 0.33 | +0 | +0.1 |
| OPENS UP | 2 | 2 | 1 | 0.33 | +24 | +24.2 |
| OVERRUNS AWAY | 7 | 7 | 1 | 0.33 | +83 | +83.1 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +15 | +14.7 |
| REDIRECT COUNTER | 6 | 6 | 1 | 0.33 | +0 | +0.0 |
| RISK BY ARC | 13 | 13 | 1 | 0.33 | +13 | +12.7 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +111 | +110.9 |
| SHOTS AFTER THE MOVES | 14 | 14 | 1 | 0.33 | +0 | +0.0 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +22 | +22.3 |
| SURE REACH TOGETHER | 4 | 2 | 1 | 0.33 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 14 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO GETS IN | 1 | 1 | 1 | 0.33 | +19 | +18.9 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +136 | +135.8 |
| WHOLE FIGHT | 2 | 2 | 1 | 0.33 | +83 | +83.1 |
| BACKUP TARGETS | 2 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 7 | trace | - | - | - | - |
| CHARACTER GUNS | 20 | 18 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 73 | 67 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 5 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| EVASIVE BY THE ODDS | 1 | 1 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 5 | 5 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 47 | not checked | - | - | - | - |
| FOOT FIRST | 37 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 61 | 55 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 7 | 7 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 27 | 27 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 83 | 80 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 38 | 38 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 18 | 16 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 33 | 30 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 44 | 37 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 31 | 29 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 6 | 6 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 80 | 80 | 0 | 0.00 | - | - |
| HONEST WORTH | 15 | 15 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 14 | 14 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 3 | 3 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 3 | not checked | - | - | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 36 | 23 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 3 | trace | - | - | - | - |
| NEAREST TO GOAL | 2 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 14 | 14 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 21 | 14 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 241 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 4 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 5 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 5 | 5 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 2 | 2 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 5 | 5 | 0 | 0.00 | - | - |
| RUN DOWN | 13 | 13 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 9 | 9 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 3 | 3 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 26 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 15 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 37 | 33 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 15 | 15 | 0 | 0.00 | - | - |
| STANDS STILL | 169 | 164 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 5 | 5 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 5 | 5 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 19 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 13 | not checked | - | - | - | - |
| THE TABLE BINDS | 251 | not checked | - | - | - | - |
| WAITS AGAIN | 16 | 12 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 4 | 4 | 0 | 0.00 | - | - |
| WHO FIGHTS | 4 | 4 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 13 | 13 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p33

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 6.33 | 5.67 | 25.8 |
| PROMISE BY ITS OWN SUM | rule | 3.33 | 3.00 | 61.8 |
| ARMY TABLE | rule | 1.00 | 1.67 | 33.6 |
| ONE PROMISE A TARGET | rule | 1.67 | - | 16.8 |
| NO REASON | gate | - | 1.33 | 33.8 |
| CHARGE NOW FIRST | rule | 1.00 | - | 18.2 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.33 | 25.8 |
| PIVOT GUARDS FLANK | rule | 0.33 | 0.33 | 17.8 |
| PROMISE SHOT AWAY | rule | 0.67 | - | 0.6 |
| SET UP BY THE SET | rule | 0.67 | - | 74.8 |
| MARCH OF THE TABLE | rule | - | 0.33 | 46.5 |
| RULE SWITCHED OFF | gate | 0.33 | - | 73.8 |
| TURN GATE | gate | - | 0.33 | 8.0 |

### Plans: gs3-83c8646-p33

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.3 | 40% | 504 | 225 | 45% |
| Mine | move | 31.0 | 98% | 2340 | 0 | 0% |
| Mine | shoot | 4.7 | 50% | 272 | 323 | 119% |
| Opponent | charge | 0.7 | 100% | 58 | 66 | 113% |
| Opponent | join | 1.7 | 100% | 97 | 0 | 0% |
| Opponent | move | 35.7 | 96% | 1538 | 0 | 0% |
| Opponent | shoot | 3.0 | 56% | 117 | 109 | 93% |
| Opponent | support | 0.3 | 100% | 0 | 0 | - |

### Battle groups: gs3-83c8646-p33

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.3 | 25% | 100% | 100% | 0% | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 0.7 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p33

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 94 (2) | 0 | 94 | 50 | 0% | 2.0 | 188 (1) | 0 (1) | - | 0 (1) | 188 (1) |
| Mine | Character | 8 | 47 (8) | 47 | 0 | 0 | 0% | 3.0 | 30 (4) | 60 (4) | - | 66 (6) | 0 (2) |
| Mine | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 3 | 0 (3) | 0 | 0 | 15 | 33% | 4.5 | 0 (3) | - | - | 0 (3) | - |
| Mine | Hammer | 4 | 13 (4) | 0 | 13 | 29 | 25% | 4.3 | 21 (3) | - | 0 (1) | 0 (3) | 56 (1) |
| Mine | Shooter | 7 | 112 (7) | 38 | 73 | 20 | 0% | 1.9 | 175 (3) | 18 (3) | 171 (1) | 175 (3) | 61 (4) |
| Mine | Support | 4 | 58 (4) | 58 | 0 | 0 | 0% | 3.0 | - | - | 58 (4) | 0 (1) | 101 (3) |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 50 | 0% | 1.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | - | 0 (1) | 0 (1) | - |
| Opponent | Chaff | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (2) | - | - | 0 (1) | 0 (1) |
| Opponent | Character | 10 | 2 (10) | 2 | 0 | 41 | 20% | 2.2 | 0 (5) | 0 (3) | 0 (1) | 0 (4) | 0 (5) |
| Opponent | Fast Hammer | 5 | 6 (5) | 6 | 0 | 15 | 0% | 2.0 | 0 (2) | 10 (3) | - | 8 (4) | 0 (1) |
| Opponent | Hammer | 10 | 21 (10) | 21 | 0 | 12 | 50% | 3.4 | 0 (6) | 93 (3) | 0 (1) | 38 (6) | 0 (4) |
| Opponent | Holder | 3 | 0 (3) | 0 | 0 | 29 | 33% | 5.0 | - | - | 0 (3) | 0 (1) | 0 (2) |
| Opponent | Shooter | 5 | 31 (5) | 20 | 11 | 43 | 0% | 1.4 | 43 (2) | 0 (2) | 48 (1) | 45 (3) | 0 (2) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | - | 0 (1) | - | 0 (1) |

### Charged fights: gs3-83c8646-p33

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 1 | 114 | 599 | 3.0 | 1.0 | 200 | 0 | +200 | 1 of 3 | 2 of 3 | - | +200 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 470 | 4.0 | 1.0 | 118 | 20 | +98 | 2 of 4 | 3 of 4 | - | +98 |
| Mine | Lizardmen | 1 | 195 | 120 | 4.0 | 1.0 | 30 | 0 | +30 | 1 of 4 | 3 of 4 | - | +30 |
| **Mine** | all armies | 3 | 103 | 396 | 3.7 | 1.0 | 108 | 7 | +101 | 4 of 11 | 8 of 11 | - | +101 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| Opponent | Wood Elf Realms | 2 | 80 | 278 | 2.5 | 1.0 | 111 | 21 | +90 | 0 of 5 | 4 of 5 | - | +90 |
| **Opponent** | all armies | 3 | 53 | 185 | 2.0 | 1.0 | 92 | 17 | +75 | 0 of 6 | 4 of 6 | - | +75 |

### Effective charges: gs3-83c8646-p33

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 3 | 0 | 1 (net +599) | 0 | 0 | 1 (net +0) | 1 (net +0) | 0 | 0% (0 of 3) |
| Mine | Kingdom of Bretonnia | 4 | 0 | 0 | 0 | 0 | 0 | 4 (net +98) | 0 | 0% (0 of 4) |
| Mine | Lizardmen | 4 | 1 (net +0) | 0 | 0 | 2 (net +0) | 0 | 0 | 1 | 0% (0 of 3) |
| Opponent | Wood Elf Realms | 5 | 0 | 1 (net +115) | 0 | 1 (net +176) | 0 | 0 | 3 | 0% (0 of 2) |

### Charged fights, damage counted: gs3-83c8646-p33

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 399 | 201 | +0 | 157 | 228 | -71 | -17.8 |
| Mine | 50-54% | 1 | 497 | 499 | +599 | 599 | 0 | +599 | +120.5 |
| Mine | 76-89% | 2 | 295 | 157 | +0 | 78 | 58 | +21 | +7.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 263 | 186 | +78 | 108 | 16 | +92 | +35.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 497 | 110 | +0 | 156 | 55 | +100 | +20.2 |
| Mine | No odds | 1 | 141 | 120 | +120 | 120 | 0 | +120 | +85.1 |
| Mine | All fights | 11 | 313 | 197 | +101 | 157 | 44 | +114 | +36.3 |
| Opponent | 50-54% | 1 | 102 | 115 | +115 | 115 | 0 | +115 | +112.7 |
| Opponent | 76-89% | 1 | 102 | 176 | +176 | 176 | 0 | +176 | +172.5 |
| Opponent | No odds | 4 | 83 | 186 | +40 | 66 | 26 | +40 | +48.2 |
| Opponent | All fights | 6 | 89 | 172 | +75 | 92 | 17 | +75 | +84.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p33 | move | 26 | 7 (27%) | 7 (27%) | 3 (12%) | 16 (62%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Horn of the Wild Hunt | Opponent | L1633 |
| Ring of Doom | Mine | L1535 |
| Ring of Doom | Opponent | L1633, L1731 |

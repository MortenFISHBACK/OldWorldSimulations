# Doctrine scorecard: gs3-83c8646-p29

### Scorecard: gs3-83c8646-p29

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0725 | 5 | 1 | Mine | yes | - | 3 | 3 | 3 | 0 | 0 | 0 | 327 |
| L0725 | 5 | 1 | Opponent | no | - | - | 2 | 4 | 0 | 0 | 0 | 50 |
| L0815 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 668 |
| L0815 | 5 | 1 | Opponent | yes | - | 5 | 0 | 3 | 1 | 0 | 0 | 115 |
| L0831 | 3 | 1 | Mine | no | 0 | 5 | 2 | 1 | 1 | 0 | 0 | 589 |
| L0831 | 3 | 1 | Opponent | no | 6 | 5 | 1 | 2 | 2 | 0 | 0 | 170 |
| **Average** | | | Mine | 33% | 0.0 | 4.0 | 1.7 | 2.0 | 0.3 | 0.0 | 0.0 | 528.0 |
| **Average** | | | Opponent | 33% | 6.0 | 5.0 | 1.0 | 3.0 | 1.0 | 0.0 | 0.0 | 111.7 |

### KPIs: gs3-83c8646-p29

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 69% (11 of 16) | 0% (0 of 14) | 37% (11 of 30) |
| Winner chose to follow up after the loser gave ground |  | 75% (3 of 4); on the table 100% | 100% (2 of 2); on the table 100% | 83% (5 of 6); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 50% (1 of 2); on the table 50% | 50% (1 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 75% (3 of 4); on the table 100% | 75% (3 of 4); on the table 75% | 75% (6 of 8); on the table 88% |
| Magic missiles tried each own turn | 50%+ | 67% (4 of 6) | 33% (6 of 18) | 42% (10 of 24) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 100% (4 of 4) | 35% (6 of 17) | 48% (10 of 21) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 55% (6 of 11) | 55% (6 of 11) |
| Points that never fought | lower | 66% (3970 of 5999) | 61% (3637 of 5999) | 63% (7607 of 11998) |
|   infantry points that never fought | lower | 62% (597 of 968) | 92% (753 of 821) | 75% (1350 of 1789) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 73% (22 of 30) | 72% (18 of 25) | 73% (40 of 55) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (3 of 3); 2.3 uses a game | 100% (3 of 3); 1.2 uses a game |
| Bound items with another spell used |  | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 33% (1 of 3); 0.3 uses a game | 0.0 uses a game | 33% (1 of 3); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 73% (3933 of 5378) | 70% (3899 of 5548) | 72% (7832 of 10926) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.7 (42%) | 1.7 (36%) |
| MARCHED: its unit marched | 0.0 (0%) | 2.0 (50%) | 2.0 (43%) |
| IN COMBAT: engaged in combat | 0.7 (100%) | 0.0 (0%) | 0.7 (14%) |
| GONE: slain | 0.0 (0%) | 0.3 (8%) | 0.3 (7%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- |
| tried | 0.7 | 5.7 | 3.3 | 2.3 |
| not cast | 5.3 | 4.3 | 4.7 | 13.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (8%) | 1.7 (36%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 2.0 (43%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (15%) | 0.7 (14%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.3 (7%) | 0.3 (2%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 1.0 (23%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 5.3 (100%) | 2.3 (54%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.7 (93%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 4.7 a game | 2.8 a game |
| stood (cast and not dispelled) | 33% (1 of 3) | 75% (6 of 8) | 64% (7 of 11) |
| the unit moved after it | 0% (0 of 1) | 100% (6 of 6) | 86% (6 of 7) |
| it charged on its next turn | 100% (1 of 1) | 0% (0 of 6) | 14% (1 of 7) |
| the enemy charged it first | 0% (0 of 1) | 0% (0 of 6) | 0% (0 of 7) |
| it fought by the end of its next turn | 0% (0 of 1) | 0% (0 of 6) | 0% (0 of 7) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 1) | 0% (0 of 6) | 0% (0 of 7) |
| none of these (no charge, no fight, no charge escaped) | 0% (0 of 1) | 100% (6 of 6) | 86% (6 of 7) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 79% (81 of 102) | 52% (11 of 21) | 75% (92 of 123) |
|   cavalry | 89% (17 of 19) | - | 89% (17 of 19) |
|   character | - | 11% (1 of 9) | 11% (1 of 9) |
|   chariot | 91% (10 of 11) | - | 91% (10 of 11) |
|   infantry | 42% (5 of 12) | 83% (10 of 12) | 62% (15 of 24) |
|   war machine | 82% (49 of 60) | - | 82% (49 of 60) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.7 (10%) | 2.0 (60%) | 2.7 (26%) |
| CHARGED: it charged | 0.0 (0%) | 0.3 (10%) | 0.3 (3%) |
| IN COMBAT: it fought this turn or the last | 0.3 (5%) | 0.0 (0%) | 0.3 (3%) |
| MOVED: a war machine that moved | 1.7 (24%) | 0.0 (0%) | 1.7 (16%) |
| NO TARGET IN RANGE | 2.3 (33%) | 0.7 (20%) | 3.0 (29%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (19%) | 0.3 (10%) | 1.7 (16%) |
| SHELTERED: the target was sheltered | 0.7 (10%) | 0.0 (0%) | 0.7 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 11.3 | 2.0 | 82% | 5.9 pts | 66 pts |
| character | 0.3 | 1.0 | 0% | 130.0 pts | 43 pts |
| chariot | 3.3 | 0.3 | 90% | 0.9 pts | 3 pts |
| infantry | 6.7 | 2.0 | 70% | 10.5 pts | 70 pts |
| war machine | 16.3 | 15.3 | 49% | 24.4 pts | 399 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.7 | 1.7 | 1.7 |
| Charges that made contact a game | 1.0 | 0.7 | 0.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 1.00 contact (1 units) | 0.00 declared, 0.00 contact (3 units) | 0.25 declared, 0.25 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.20 declared, 0.10 contact (20 units) | 0.26 declared, 0.11 contact (19 units) | 0.23 declared, 0.10 contact (39 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 62% (5 of 8) | 67% (4 of 6) | 100% (1 of 1) | 67% (10 of 15) |
| Character in a unit | 100% (5 of 5) | - | 100% (1 of 1) | 100% (6 of 6) |
| Character on its own | 83% (5 of 6) | 100% (1 of 1) | 25% (1 of 4) | 64% (7 of 11) |
| Chariot | 100% (1 of 1) | 100% (2 of 2) | - | 100% (3 of 3) |
| Infantry | 80% (4 of 5) | - | 100% (2 of 2) | 86% (6 of 7) |
| Monster | 50% (1 of 2) | - | - | 50% (1 of 2) |
| War Machines | 64% (7 of 11) | - | - | 64% (7 of 11) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 3 | 75% (3 of 4); on the table 100% | 67% (4 of 6) | 66% | 73% (22 of 30) | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| High Elf Realms | 1 | 100% (2 of 2); on the table 100% | 17% (1 of 6) | 75% | 57% (4 of 7) | 100% (2 of 2); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | - | 33% (2 of 6) | 71% | 100% (6 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 50% (1 of 2); on the table 50% | 50% (3 of 6) | 36% | 67% (8 of 12) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p29, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 50% (1) | 33% (1) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.33 | 0.33 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: gs3-83c8646-p29

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.0 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 40% (2 of 5) | 40% (2 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 48% (32 of 66) | 55% (6 of 11) |
| Strategy | Joined characters whose unit fought | 0% (0 of 6) | 100% (3 of 3) |
| Strategy | Lone characters that fought | 50% (4 of 8) | 33% (3 of 9) |
| Movement | Charges halted short of contact | 0.0 | 0.7 |
| Movement | Idle units | 2.0 | 3.0 |
| Movement | Points that never moved of their own | 528.0 | 111.7 |
| Movement | Fights charged into per game | 1.0 | 0.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 3 | 0 of 2 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 3 | 1 of 2, net +252 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 3 | 0 of 2 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 3, net +34 | 1 of 2, net +265 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.0 | 4.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 67% (22 of 33) | 43% (6 of 14) |
| Shooting | Points destroyed by shooting units | 171.7 | 41.7 |
| Shooting | War machine shots | 16.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (22 of 49) | - |
| Shooting | Points destroyed by war machines | 120.0 | 0.0 |
| Magic | Magic missiles cast | 1.0 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (1 of 3) | 50% (1 of 2) |
| Magic | Wounds caused by magic missiles | 5.7 | 2.7 |
| Magic | Points destroyed by magic (all spells) | 101.3 | 43.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.3 / 0.0 / 1.3 / 0.0 | 0.0 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 112.0 | 88.3 |
| Combat | Points run down | 0.0 | 376.7 |
| Combat | Net points per charged fight, damage counted | +102 | +201 |
| Combat | Net per 100 charger points, damage counted | +36.9 | +65.7 |
| Combat | First round won (charged fights) | 67% | 100% |
| Combat | Net points per charged fight | +112 | +258 |
| Combat | Net points per supported fight / lone fight | - / +112 | - / +258 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 3 | 2 of 2 |
| Game | Points lost | 579.7 | 471.7 |
| Game | VP from objectives | 410.0 | 860.0 |
| Game | Lone holders (player turns) | 0.0 | 6.0 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -585 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 1051
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: gs3-83c8646-p29

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +25.6 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 8.3 | -69.6 | 0.0 | 0.0 | 20.3 | +343.0 | 0.0 | 76.7 |
| ARTILLERY RE-ROLL WEIGHED | 7.0 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| ASSAILMENT BY POINTS | 1.0 | +4.3 | 0.0 | 56.7 | - | - | - | - |
| BEST OVERALL | - | - | - | - | 0.3 | +7.5 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.7 | +0.0 | 58.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 16.3 | +352.6 | 553.0 | 211.7 | - | - | - | - |
| CANNON SIGHT KEPT | 2.3 | +0.0 | 0.0 | 41.7 | - | - | - | - |
| CAST JOB | 1.3 | +93.1 | 0.0 | 0.0 | 2.3 | +10.2 | 84.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 3.7 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.3 | +2.5 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 2.0 | +109.5 | 0.0 | 68.0 |
| CHAFF PASSED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LIST READ AGAIN | - | - | - | - | 0.3 | +26.5 | 0.0 | 0.0 |
| CHARGE LOSSES | 10.0 | -510.8 | 0.0 | 344.7 | 15.3 | -876.5 | 0.0 | 136.0 |
| CHARGE NOW FIRST | 3.3 | +0.0 | 130.0 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 5.7 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 176.7 | 0.7 | +0.0 | 0.0 | 56.7 |
| CONVEYANCE SEARCH | 1.0 | +28.8 | 0.0 | 0.0 | 2.3 | +97.7 | 0.0 | 0.0 |
| COVER ONCE | 9.7 | -634.6 | 0.0 | 84.0 | 3.7 | -579.7 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 8.0 | -93.7 | 0.0 | 41.7 | 6.3 | +53.2 | 0.0 | 38.3 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -7.5 | 84.0 | 38.7 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +1.0 | 0.0 | 38.7 |
| EXACT ROUND | 1.3 | +41.1 | 22.7 | 0.0 | 1.0 | +6.2 | 88.3 | 38.7 |
| FALL BACK GOOD ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.4 | 84.0 | 77.3 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 19.0 | +254.1 | 0.0 | 197.7 |
| FEATURE BUFFS | - | - | - | - | 0.7 | +0.3 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.3 | +2.0 | 84.0 | 38.7 |
| FIRE IN ORDER | 0.3 | +0.0 | 20.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 103.7 | +4747.3 | 1387.3 | 877.3 | 71.3 | +5696.6 | 423.0 | 489.3 |
| FLANK NOT WEIGHED | 3.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 96.0 |
| FOLLOW UP WEIGHED | 0.7 | +234.1 | 0.0 | 140.3 | 0.7 | +86.5 | 0.0 | 0.0 |
| FOOT FIRST | - | - | - | - | 17.3 | +0.0 | 0.0 | 47.7 |
| FOUR ROUNDS | 1.7 | +461.4 | 22.7 | 0.0 | 2.0 | +202.5 | 172.3 | 77.3 |
| FREED FROM HIS FIGHT | 2.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.7 | -13.1 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.3 | +36.2 | 0.0 | 140.3 | - | - | - | - |
| GIVES UP | - | - | - | - | 0.3 | -0.6 | 0.0 | 0.0 |
| GOAL ROUTE | - | - | - | - | 0.7 | +52.7 | 0.0 | 0.0 |
| GOAL WALK | 7.7 | +740.4 | 0.0 | 0.0 | 10.0 | +1736.9 | 0.0 | 0.0 |
| GUN FIGURES | 2.3 | +0.0 | 0.0 | 88.3 | - | - | - | - |
| GUN MASK | 2.0 | +45.8 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 130.0 |
| HE REFORMS ONCE FREED | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 8.7 | +0.0 | 0.0 | 344.7 | 6.7 | +0.0 | 0.0 | 116.0 |
| HIS CHARGE LIST | 5.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 169.3 |
| HIS LEGAL MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 169.3 |
| HIS MOVE AND SHOT | 2.0 | -21.8 | 0.0 | 0.0 | 1.0 | -4.8 | 0.0 | 96.0 |
| HIS ONE QUARTER | 3.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 56.7 |
| HIS OWN BEST MOVE | 2.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 169.3 |
| HIS RANDOM MOVE | 7.7 | +0.0 | 0.0 | 168.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 21.0 | +297.8 | 0.0 | 176.7 | 51.7 | +4265.0 | 0.0 | 412.0 |
| HIS SHOTS BY HIS RUN | 12.0 | +110.1 | 0.0 | 344.7 | 44.3 | +1830.6 | 0.0 | 242.7 |
| HOLD ODDS | 6.7 | +0.0 | 0.0 | 168.0 | 10.0 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 4.7 | +319.4 | 0.0 | 84.0 | 6.0 | +472.0 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -14.8 | 22.7 | 0.0 | 2.0 | -54.7 | 172.3 | 77.3 |
| HUNT THE GUNS | - | - | - | - | 0.3 | +58.2 | 0.0 | 38.7 |
| IDLE COST | - | - | - | - | 16.0 | -215.4 | 0.0 | 158.0 |
| KEEP FALLS | 0.3 | +1.7 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 0.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +11.1 | 0.0 | 0.0 | 0.7 | +44.3 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.7 | +0.0 | 56.7 | 228.7 | 1.7 | +0.0 | 88.3 | 0.0 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.7 | +14.9 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.7 | +45.1 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 1.3 | +8.7 | 22.7 | 0.0 | 1.3 | +0.7 | 84.0 | 38.7 |
| MANOEUVRE | 1.3 | -0.6 | 0.0 | 0.0 | 4.0 | -64.9 | 0.0 | 22.7 |
| MARCH BY THE SUM | - | - | - | - | 0.7 | +42.9 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 0.3 | +7.1 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.7 | +1.8 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 1.3 | -57.1 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 1.7 | +40.9 | 0.0 | 0.0 | 1.3 | +113.7 | 0.0 | 65.0 |
| MEETS IN TIME | 4.3 | +75.1 | 0.0 | 41.7 | 3.0 | +38.3 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.3 | +90.3 | 0.0 | 0.0 | 4.7 | +55.6 | 0.0 | 130.0 |
| MISSILES NEXT TURN | 1.3 | +57.5 | 0.0 | 0.0 | 7.7 | +44.9 | 0.0 | 130.0 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 25.0 | 0.0 |
| MOVE SPELL IN RANGE | 1.3 | +29.8 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.7 | -9.5 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.0 | +211.1 | 0.0 | 0.0 | 2.0 | +150.4 | 0.0 | 169.3 |
| MOVES UNITS SPELL | - | - | - | - | 0.3 | +2.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 9.7 | +389.7 | 0.0 | 138.7 | 8.3 | +389.5 | 0.0 | 0.0 |
| NEAREST TO GOAL | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 2.0 | +223.1 | 0.0 | 0.0 | 1.7 | +139.0 | 0.0 | 169.3 |
| NO DOUBLE ROUNDS | 1.7 | -149.9 | 22.7 | 0.0 | 1.3 | -87.2 | 172.3 | 77.3 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO RALLY LEFT | - | - | - | - | 0.3 | +151.7 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.7 | -1.3 | 0.0 | 0.0 | 0.3 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 9.0 | -409.3 | 0.0 | 167.3 | 2.3 | -141.2 | 0.0 | 130.0 |
| ONE CHALLENGE TEST | 0.3 | +39.9 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.3 | -46.9 | 0.0 | 0.0 | 2.7 | -80.0 | 0.0 | 132.7 |
| ONE OBJECTIVE FORMULA | 2.3 | +22.6 | 0.0 | 84.0 | 3.7 | +97.3 | 0.0 | 0.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.3 | +6.1 | 0.0 | 0.0 |
| PATHS CROSS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +3.2 | 0.0 | 0.0 |
| PLAN RESULT | 46.7 | +938.7 | 304.7 | 764.3 | 39.0 | +259.7 | 260.0 | 520.7 |
| PROMISE BELOW ZERO | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 4.0 | -174.0 | 0.0 | 0.0 | 2.7 | -11.5 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.7 | -41.1 | 96.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 23.3 | +1437.1 | 232.0 | 256.7 | 16.7 | +2445.1 | 256.3 | 134.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.7 | +42.5 | 0.0 | 56.7 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 1.3 | +87.2 | 0.0 | 45.3 |
| REDIRECT COUNTER | 0.7 | +10.4 | 0.0 | 0.0 | 2.0 | +244.7 | 0.0 | 22.7 |
| REDIRECT FOR A FRIEND IN REACH | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | +54.9 | 0.0 | 45.3 |
| REFORMS TO MEET IT | 0.7 | -2.0 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RISK BY ARC | 1.3 | +16.9 | 22.7 | 0.0 | 1.7 | -173.9 | 172.3 | 77.3 |
| ROUNDS AFTER TERROR | 0.7 | -28.2 | 0.0 | 0.0 | - | - | - | - |
| RUN DOWN | 0.7 | -49.0 | 0.0 | 0.0 | 1.0 | -4.1 | 84.0 | 77.3 |
| SAFER THAN THE JOB | - | - | - | - | 0.3 | +7.5 | 0.0 | 0.0 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.0 | -84.4 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +8.9 | 0.0 | 0.0 |
| SELF MOVE SPELL | - | - | - | - | 2.0 | +619.7 | 0.0 | 0.0 |
| SET CREDITED ONCE | 1.0 | -39.8 | 0.0 | 0.0 | 0.7 | -15.2 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.7 | +58.3 | 0.0 | 0.0 | 0.7 | +15.2 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.7 | +46.0 | 0.0 | 0.0 | - | - | - | - |
| SET-UP MISSED | 0.3 | +47.7 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +0.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 22.7 | +0.0 | 0.0 | 266.3 | 6.3 | +0.0 | 0.0 | 130.0 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +8.7 | 0.0 | 0.0 | 0.7 | +4.7 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 13.3 | -154.4 | 0.0 | 344.7 | 30.3 | +458.1 | 0.0 | 106.7 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 28.0 | +1340.3 | 0.0 | 438.7 | 4.3 | +203.1 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.7 | +46.0 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 0.3 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| SPELLS IN THE FIGHT | 0.3 | +25.2 | 0.0 | 0.0 | 0.3 | -1.7 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 25.0 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -3.6 | 84.0 | 38.7 |
| STANDS FOR A REASON | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 77.3 | +0.0 | 1364.7 | 532.7 | 20.7 | +0.0 | 250.7 | 56.7 |
| STAY WORTH | 53.3 | -130.0 | 790.7 | 753.0 | 10.0 | +230.9 | 250.7 | 0.0 |
| STOPS | - | - | - | - | 0.3 | +8.0 | 0.0 | 38.7 |
| STRIKE BY THE ODDS | 0.7 | +106.8 | 0.0 | 0.0 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 1.3 | +15.2 | 0.0 | 0.0 | 5.3 | +763.1 | 0.0 | 0.0 |
| SUPPORT NARROWED | 1.3 | +0.0 | 130.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 1.3 | +15.2 | 0.0 | 0.0 | 5.3 | +763.1 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +4.3 | 0.0 | 54.7 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 84.0 | 4.7 | +0.0 | 0.0 | 20.0 |
| THE STEP BACK IS MADE | 1.7 | +0.0 | 0.0 | 84.0 | 2.7 | +0.0 | 0.0 | 20.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 48.3 | +0.0 | 0.0 | 438.7 | 36.3 | +0.0 | 0.0 | 307.7 |
| TIED UP BY THE SUM | 0.3 | +16.8 | 0.0 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 45.7 | +496.6 | 0.0 | 138.7 | - | - | - | - |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -59.1 | 0.0 | 0.0 |
| WHO FIGHTS | 1.0 | +19.8 | 0.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.3 | +27.0 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | - | - | - | - | 0.3 | +24.4 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.0 | -321.1 | 0.0 | 0.0 | 1.3 | -97.5 | 0.0 | 96.0 |
| WOUNDS ON THE RANKS | 2.7 | +31.1 | 0.0 | 168.0 | 3.0 | +252.5 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p29

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 86 | 86 | 67 | 22.33 | +219 | +3.3 |
| HIS SHOT LIST | 218 | 214 | 41 | 13.67 | +1284 | +31.3 |
| OFF BEST | 34 | 34 | 34 | 11.33 | -1652 | -48.6 |
| HOLDER ASSIGNMENT | 32 | 32 | 30 | 10.00 | +1874 | +62.5 |
| TIME ON OUR SIDE | 137 | 126 | 29 | 9.67 | +0 | +0.0 |
| DEPLOY BY FIGURES | 43 | 43 | 26 | 8.67 | +348 | +13.4 |
| ARTILLERY RE-ROLL WEIGHED | 21 | 21 | 21 | 7.00 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 169 | 166 | 21 | 7.00 | +506 | +24.1 |
| FIVE ACTION | 525 | 518 | 18 | 6.00 | +2509 | +139.4 |
| LEGAL CHARGES ONLY | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| SHOT RISK POINTS | 131 | 128 | 15 | 5.00 | +757 | +50.5 |
| THE TABLE AGAIN | 36 | 36 | 15 | 5.00 | +0 | +0.0 |
| GOAL WALK | 53 | 53 | 14 | 4.67 | +2104 | +150.3 |
| STAY WORTH | 190 | 174 | 14 | 4.67 | +277 | +19.8 |
| QUARTER ODDS | 120 | 117 | 12 | 4.00 | +1386 | +115.5 |
| CAST JOB | 11 | 11 | 11 | 3.67 | +144 | +13.1 |
| HARD STAY DROPPED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| MOVE ORDER | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| MEETS IN TIME | 22 | 22 | 8 | 2.67 | +93 | +11.6 |
| CANNON SIGHT KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| FOUR ROUNDS | 11 | 11 | 7 | 2.33 | +345 | +49.2 |
| REDIRECT FOR A FRIEND IN REACH | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 11 | 11 | 6 | 2.00 | +128 | +21.3 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHARGE LOSSES | 76 | 73 | 5 | 1.67 | +193 | +38.5 |
| CHARGE NOW FIRST | 10 | 10 | 5 | 1.67 | -41 | -8.1 |
| MOVE TO CHARGE COMPUTED | 12 | 8 | 5 | 1.67 | +236 | +47.1 |
| NEXT CHARGE BY LIST | 11 | 10 | 5 | 1.67 | +236 | +47.1 |
| PROMISE BY ITS OWN SUM | 20 | 20 | 5 | 1.67 | -556 | -111.3 |
| SHOTS AFTER THE MOVES | 24 | 24 | 5 | 1.67 | +0 | +0.0 |
| CANNON PLANNED TARGET | 49 | 49 | 4 | 1.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 6 | 6 | 4 | 1.33 | +0 | +0.0 |
| COMBAT PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +962 | +240.5 |
| REDIRECT BY WHAT IT STOPS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SUPPORT ADDS | 20 | 20 | 4 | 1.33 | +491 | +122.8 |
| SUPPORT WORKED OUT | 20 | 20 | 4 | 1.33 | +491 | +122.8 |
| ASSAILMENT BY POINTS | 3 | 3 | 3 | 1.00 | +13 | +4.3 |
| COVER ONCE | 40 | 29 | 3 | 1.00 | +11 | +3.8 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| LANE BY FIGURES | 3 | 3 | 3 | 1.00 | +166 | +55.5 |
| SET UP BY THE SET | 7 | 7 | 3 | 1.00 | +154 | +51.4 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| EXACT ROUND | 7 | 7 | 2 | 0.67 | +36 | +17.9 |
| FALLS SHORT | 57 | 48 | 2 | 0.67 | +0 | +0.0 |
| GOAL ROUTE | 2 | 2 | 2 | 0.67 | +158 | +79.0 |
| HIS MOVE AND SHOT | 9 | 8 | 2 | 0.67 | +46 | +23.2 |
| IDLE COST | 48 | 32 | 2 | 0.67 | +4 | +2.0 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +135 | +67.7 |
| MANOEUVRE | 16 | 16 | 2 | 0.67 | +33 | +16.4 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +129 | +64.3 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -5 | -2.7 |
| MAX FOR POSITIONING | 9 | 8 | 2 | 0.67 | +0 | +0.0 |
| MISSILES IN THE MOVE | 18 | 7 | 2 | 0.67 | +33 | +16.6 |
| ONE OBJECTIVE FORMULA | 18 | 16 | 2 | 0.67 | +74 | +37.1 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +10 | +4.8 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -123 | -61.7 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +2 | +1.0 |
| SHORT GUN FORWARD | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 15 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 10 | 10 | 2 | 0.67 | +6 | +2.9 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +77 | +76.8 |
| BEST OVERALL | 1 | 1 | 1 | 0.33 | +22 | +22.4 |
| BLOCKED CHARGE SKIPPED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +12 | +11.9 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +80 | +79.6 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +109 | +108.6 |
| GUN MASK | 6 | 6 | 1 | 0.33 | +24 | +24.4 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +7 | +6.7 |
| LOST AFTER ESCAPE | 8 | 8 | 1 | 0.33 | +1 | +1.2 |
| MARCH CHECK | 1 | 1 | 1 | 0.33 | +6 | +5.9 |
| MISSILES NEXT TURN | 27 | 13 | 1 | 0.33 | +0 | +0.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.33 | +249 | +248.6 |
| ONE CHALLENGE TEST | 1 | 1 | 1 | 0.33 | +58 | +58.5 |
| OVERRUNS AWAY | 1 | 1 | 1 | 0.33 | +1 | +1.2 |
| REDIRECT COUNTER | 8 | 7 | 1 | 0.33 | +0 | +0.0 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.33 | +22 | +22.4 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +27 | +26.8 |
| SHOTS IN THE MOVE | 97 | 71 | 1 | 0.33 | +4 | +4.0 |
| SPELLS IN THE FIGHT | 2 | 2 | 1 | 0.33 | +58 | +58.5 |
| STRIKE BY THE ODDS | 2 | 2 | 1 | 0.33 | +35 | +34.6 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +13 | +12.9 |
| WHO FIGHTS | 3 | 3 | 1 | 0.33 | +35 | +34.6 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +23 | +22.9 |
| WHOLE FIGHT | 1 | 1 | 1 | 0.33 | +1 | +1.2 |
| WOUNDS ON THE RANKS | 17 | 16 | 1 | 0.33 | +10 | +10.0 |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 11 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 39 | 39 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 10 | not checked | - | - | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 9 | 9 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 26 | not checked | - | - | - | - |
| FOOT FIRST | 52 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 7 | 7 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 7 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 5 | 5 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 46 | 44 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 21 | 21 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 15 | 12 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 25 | 24 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 17 | 14 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 23 | 23 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 10 | 10 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 50 | 50 | 0 | 0.00 | - | - |
| HONEST WORTH | 9 | 9 | 0 | 0.00 | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| KEPT FROM ITS LAST STOP | 10 | 10 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 2 | not checked | - | - | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 4 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 2 | trace | - | - | - | - |
| NEARER NOT NEEDED | 54 | 53 | 0 | 0.00 | - | - |
| NEAREST TO GOAL | 5 | 5 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 9 | 9 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 6 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 18 | 8 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 257 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 1 | not checked | - | - | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 2 | 1 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK BY ARC | 9 | 9 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 5 | 5 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 5 | 5 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 2 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 87 | not checked | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 2 | not checked | - | - | - | - |
| SPELL WORTH | 1 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 24 | 24 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 294 | 293 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 1 | not checked | - | - | - | - |
| SUPPORT NARROWED | 4 | 4 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 17 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 13 | not checked | - | - | - | - |
| THE TABLE BINDS | 254 | not checked | - | - | - | - |
| TIED UP BY THE SUM | 1 | 1 | 0 | 0.00 | - | - |
| WAITS AGAIN | 4 | 2 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p29

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 9.00 | 1.67 | 44.4 |
| ARMY TABLE | rule | 0.67 | 3.00 | 96.4 |
| CHARGE NOW FIRST | rule | 1.67 | - | 8.1 |
| PROMISE BY ITS OWN SUM | rule | 1.33 | 0.33 | 111.3 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.67 | 115.6 |
| PROMISE SHOT AWAY | rule | 0.67 | - | 61.7 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 14.3 |
| MARCH OF THE TABLE | rule | - | 0.33 | 5.4 |

### Plans: gs3-83c8646-p29

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 33% | 353 | 15 | 4% |
| Mine | join | 1.3 | 100% | 18 | 0 | 0% |
| Mine | move | 25.3 | 99% | 986 | 0 | 0% |
| Mine | shoot | 19.0 | 67% | 848 | 924 | 109% |
| Opponent | charge | 1.3 | 50% | 101 | 138 | 137% |
| Opponent | join | 4.0 | 92% | 179 | 0 | 0% |
| Opponent | move | 29.0 | 95% | 2131 | 0 | 0% |
| Opponent | shoot | 3.0 | 89% | 175 | 121 | 69% |
| Opponent | support | 1.7 | 80% | 55 | 0 | 0% |

### Packages: hunt the guns, gs3-83c8646-p29

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Opponent | 0.3 | 1 | 1 | - | - | - | - | - | - | - | 272 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 115 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 75 |
| Warriors of Chaos | 1.0 | 1 | 1 | - | - | - | - | - | - | - | 625 |

### Battle groups: gs3-83c8646-p29

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.7 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 2.0 | 33% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p29

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | Character | 12 | 39 (12) | 39 | 0 | 25 | 75% | 3.3 | 0 (8) | 119 (2) | - | 78 (6) | 0 (4) |
| Mine | Fast Hammer | 5 | 7 (5) | 7 | 0 | 0 | 60% | 3.5 | 9 (4) | 0 (1) | - | 0 (2) | 11 (3) |
| Mine | Hammer | 4 | 0 (4) | 0 | 0 | 54 | 25% | 2.0 | 0 (2) | 0 (2) | - | 0 (3) | 0 (1) |
| Mine | Shooter | 5 | 13 (5) | 9 | 4 | 61 | 0% | 2.0 | 6 (4) | 37 (1) | - | 12 (4) | 15 (1) |
| Mine | War machine | 11 | 58 (11) | 58 | 0 | 27 | 0% | 1.3 | 64 (9) | 30 (2) | - | 88 (5) | 32 (6) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 50 | 0% | 5.0 | 0 (1) | - | - | 0 (1) | - |
| Opponent | Chaff | 4 | 0 (4) | 0 | 0 | 56 | 75% | 6.0 | 0 (3) | 0 (1) | - | 0 (3) | 0 (1) |
| Opponent | Character | 9 | 32 (9) | 32 | 0 | 19 | 22% | 4.4 | 12 (4) | 59 (4) | - | 12 (4) | 55 (4) |
| Opponent | Clean-up | 2 | 0 (2) | 0 | 0 | 63 | 100% | - | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 5 | 28 (5) | 0 | 28 | 9 | 40% | 4.3 | 0 (3) | 114 (2) | - | 0 (4) | 179 (1) |
| Opponent | Hammer | 3 | 170 (3) | 170 | 0 | 37 | 0% | 4.7 | 228 (2) | 0 (1) | - | 228 (2) | 0 (1) |
| Opponent | Holder | 3 | 29 (3) | 0 | 29 | 35 | 100% | - | - | 45 (2) | 0 (1) | 0 (1) | 45 (2) |
| Opponent | Shooter | 2 | 41 (2) | 41 | 0 | 0 | 0% | 1.5 | 99 (1) | 0 (1) | - | 99 (1) | 0 (1) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 40 | 0% | 3.0 | 0 (2) | 0 (1) | - | 0 (1) | 0 (2) |

### Charged fights: gs3-83c8646-p29

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 3 | 393 | 112 | 1.0 | 1.0 | 112 | 0 | +112 | 2 of 3 | 2 of 3 | - | +112 |
| Opponent | High Elf Realms | 1 | 255 | 265 | 1.0 | 1.0 | 265 | 0 | +265 | 1 of 1 | 1 of 1 | - | +265 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Warriors of Chaos | 1 | 0 | 252 | 1.0 | 1.0 | 252 | 0 | +252 | 1 of 1 | 1 of 1 | - | +252 |
| **Opponent** | all armies | 3 | 85 | 172 | 0.7 | 1.0 | 258 | 0 | +258 | 2 of 2 | 2 of 2 | - | +258 |

### Effective charges: gs3-83c8646-p29

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 3 | 0 | 1 (net +268) | 0 | 0 | 0 | 2 (net +34) | 0 | 0% (0 of 3) |
| Opponent | High Elf Realms | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +265) | 0 | 0% (0 of 1) |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 1 (net +252) | 0 | 0 | 0 | 0 | 100% (1 of 1) |

### Charged fights, damage counted: gs3-83c8646-p29

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 50-54% | 1 | 380 | 348 | +268 | 331 | 109 | +223 | +58.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 227 | 134 | +34 | 90 | 48 | +42 | +18.6 |
| Mine | All fights | 3 | 278 | 206 | +112 | 170 | 68 | +102 | +36.9 |
| Opponent | Effective (55-75%) | 1 | 116 | 202 | +252 | 252 | 77 | +175 | +150.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 497 | 265 | +265 | 310 | 82 | +228 | +45.8 |
| Opponent | All fights | 2 | 306 | 234 | +258 | 281 | 80 | +201 | +65.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p29 | move | 10 | 1 (10%) | 1 (10%) | 1 (10%) | 8 (80%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0725 |
| Invocation of Nehek | Opponent | L0725 |
| Ring of Doom | Opponent | L0815, L0831 |
| Twice-Blessed Armour | Mine | L0725 |
| Witch Hunter's Ward | Mine | L0725, L0815, L0831 |

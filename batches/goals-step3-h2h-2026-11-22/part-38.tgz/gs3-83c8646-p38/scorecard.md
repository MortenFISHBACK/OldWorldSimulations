# Doctrine scorecard: gs3-83c8646-p38

### Scorecard: gs3-83c8646-p38

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0230 | 2 | 1 | Mine | - | - | 2 | 4 | 3 | 0 | 0 | 0 | 170 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Opponent | no | 4 | 2 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | - | 0 | 3 | 0 | 0 | 0 | 590 |
| L0332 | 2 | 1 | Opponent | - | - | 3 | 4 | 8 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 2.0 | 2.0 | 1.3 | 2.3 | 0.0 | 0.0 | 0.0 | 253.3 |
| **Average** | | | Opponent | 0% | 4.0 | 2.3 | 1.7 | 4.0 | 0.0 | 0.0 | 0.0 | 0.0 |

### KPIs: gs3-83c8646-p38

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 53% (8 of 15) | 0% (0 of 16) | 26% (8 of 31) |
| Winner chose to follow up after the loser gave ground |  | - | 100% (5 of 5); on the table 100% | 100% (5 of 5); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 67% (2 of 3); on the table 67% | 100% (1 of 1); on the table 100% | 75% (3 of 4); on the table 75% |
| Winner chose to follow up or pursue (all three) |  | 75% (3 of 4); on the table 75% | 100% (6 of 6); on the table 100% | 90% (9 of 10); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 43% (13 of 30) | - | 43% (13 of 30) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 43% (13 of 30) | - | 43% (13 of 30) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 0% (0 of 5) | 42% (5 of 12) | 29% (5 of 17) |
| Points that never fought | lower | 68% (4016 of 5897) | 66% (3956 of 5999) | 67% (7972 of 11896) |
|   infantry points that never fought | lower | 100% (1437 of 1437) | 53% (365 of 688) | 85% (1802 of 2125) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 77% (17 of 22) | 52% (11 of 21) | 65% (28 of 43) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 3.3 uses a game | 100% (2 of 2); 3.0 uses a game | 100% (4 of 4); 3.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (4 of 4); 1.3 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (5 of 5); 0.8 uses a game |
|   their share of the points of units over 100 pts | lower | 76% (3406 of 4484) | 50% (2750 of 5470) | 62% (6156 of 9954) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.7 (65%) | - | 3.7 (65%) |
| MARCHED: its unit marched | 1.0 (18%) | - | 1.0 (18%) |
| STUPIDITY: Stupidity | 1.0 (18%) | - | 1.0 (18%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 0.0 | 3.0 | 7.0 | 4.3 | 0.0 |
| not cast | 2.0 | 0.7 | 1.0 | 5.7 | 8.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.7 (65%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (18%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.3 (33%) | 1.0 (18%) | 0.7 (8%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.7 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (100%) | 0.0 (0%) | 0.7 (67%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 7.3 (92%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 5.0 a game | 2.0 a game | 3.5 a game |
| stood (cast and not dispelled) | 80% (12 of 15) | - | 80% (12 of 15) |
| the unit moved after it | 67% (8 of 12) | - | 67% (8 of 12) |
| it charged on its next turn | 0% (0 of 12) | - | 0% (0 of 12) |
| the enemy charged it first | 17% (2 of 12) | - | 17% (2 of 12) |
| it fought by the end of its next turn | 8% (1 of 12) | - | 8% (1 of 12) |
| it moved out of a charge the enemy had planned (not charged first) | 8% (1 of 12) | - | 8% (1 of 12) |
| none of these (no charge, no fight, no charge escaped) | 75% (9 of 12) | - | 75% (9 of 12) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (41 of 63) | 27% (10 of 37) | 51% (51 of 100) |
|   character | - | 24% (5 of 21) | 24% (5 of 21) |
|   chariot | 59% (10 of 17) | 25% (1 of 4) | 52% (11 of 21) |
|   infantry | - | 33% (4 of 12) | 33% (4 of 12) |
|   war machine | 67% (31 of 46) | - | 67% (31 of 46) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.7 (9%) | 2.3 (26%) | 3.0 (18%) |
| CHARGED: it charged | 0.0 (0%) | 2.7 (30%) | 2.7 (16%) |
| IN COMBAT: it fought this turn or the last | 1.3 (18%) | 0.0 (0%) | 1.3 (8%) |
| MOVED: a war machine that moved | 1.3 (18%) | 0.0 (0%) | 1.3 (8%) |
| NO TARGET IN RANGE | 0.3 (5%) | 1.7 (19%) | 2.0 (12%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.7 (7%) | 0.7 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 3.7 (50%) | 1.7 (19%) | 5.3 (33%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| character | 3.3 | 0.3 | 90% | 4.2 pts | 14 pts |
| chariot | 3.7 | 2.7 | 55% | 25.7 pts | 94 pts |
| infantry | 2.3 | 2.0 | 57% | 3.7 pts | 9 pts |
| war machine | 10.3 | 10.0 | 68% | 35.9 pts | 371 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 3.7 | 3.3 |
| Charges that made contact a game | 2.0 | 2.7 | 2.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | - | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (4 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.45 declared, 0.30 contact (20 units) | 0.48 declared, 0.35 contact (23 units) | 0.47 declared, 0.33 contact (43 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 40% (2 of 5) | - | 100% (1 of 1) | 50% (3 of 6) |
| Character in a unit | 100% (3 of 3) | 100% (4 of 4) | - | 100% (7 of 7) |
| Character on its own | 100% (1 of 1) | - | 40% (2 of 5) | 50% (3 of 6) |
| Chariot | 100% (1 of 1) | 100% (4 of 4) | - | 100% (5 of 5) |
| Infantry | 0% (0 of 3) | 33% (1 of 3) | - | 17% (1 of 6) |
| Monster | 67% (2 of 3) | 0% (0 of 1) | - | 50% (2 of 4) |
| Monstrous | 100% (1 of 1) | - | - | 100% (1 of 1) |
| War Machines | 67% (4 of 6) | 100% (2 of 2) | - | 75% (6 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1 | 75% (3 of 4); on the table 75% | 50% (9 of 18) | 74% | 83% (5 of 6) | 100% (2 of 2); 10.0 uses a game | 0.0 uses a game | 100% (2 of 2); 2.0 uses a game |
| Chaos Dwarfs | 2 | - | 33% (4 of 12) | 65% | 75% (12 of 16) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| High Elf Realms | 1 | 100% (4 of 4); on the table 100% | - | 75% | 43% (3 of 7) | 100% (2 of 2); 9.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | 100% (2 of 2); on the table 100% | - | 61% | 57% (8 of 14) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.5 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p38, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 43% (3) | 67% (2) | 50% (5) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.33 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.33 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p38

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 2.3 |
| Strategy | Charge objectives carried out (made contact) | 62% (5 of 8) | 40% (4 of 10) |
| Strategy | Shoot objectives carried out (shot that target) | 63% (26 of 41) | 25% (1 of 4) |
| Strategy | Support requests answered (helper made contact too) | 50% (1 of 2) | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 0% (0 of 6) | 0% (0 of 2) |
| Strategy | Lone characters that fought | 17% (1 of 6) | 60% (3 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.3 | 4.0 |
| Movement | Points that never moved of their own | 253.3 | 0.0 |
| Movement | Fights charged into per game | 1.7 | 2.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 4 | 0 of 6 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 4 | 0 of 6 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 4 | 2 of 6, net +112 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 4, net +65 | 3 of 6, net +180 |
| Shooting | Shots by shooting units (incl. breath weapons) | 3.3 | 6.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 70% (7 of 10) | 53% (10 of 19) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 10.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 29% (9 of 31) | - |
| Shooting | Points destroyed by war machines | 48.3 | 0.0 |
| Magic | Magic missiles cast | 1.3 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 50% (2 of 4) | - |
| Magic | Wounds caused by magic missiles | 3.3 | 1.0 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 28.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 0.0 / 1.7 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 56.0 | 479.0 |
| Combat | Points run down | 26.7 | 194.3 |
| Combat | Net points per charged fight, damage counted | +79 | +169 |
| Combat | Net per 100 charger points, damage counted | +96.5 | +41.3 |
| Combat | First round won (charged fights) | 100% | 88% |
| Combat | Net points per charged fight | +74 | +184 |
| Combat | Net points per supported fight / lone fight | +80 / +72 | - / +184 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 5 | 3 of 8 |
| Game | Points lost | 713.7 | 188.7 |
| Game | VP from objectives | 453.3 | 690.0 |
| Game | Lone holders (player turns) | 2.0 | 4.0 |

- Mine won / drew / lost: 0 / 1 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -807 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 902
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: gs3-83c8646-p38

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +19.8 | 0.0 | 17.3 | - | - | - | - |
| ARMY TABLE | 8.3 | +21.6 | 0.0 | 17.3 | 21.3 | +709.1 | 0.0 | 296.0 |
| ARTILLERY RE-ROLL WEIGHED | 5.3 | +0.0 | 0.0 | 93.3 | - | - | - | - |
| CANNON PLAN MISSED | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 9.0 | +42.4 | 50.0 | 170.0 | - | - | - | - |
| CANNON SIGHT KEPT | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 3.3 | +146.1 | 0.0 | 0.0 | 0.7 | +1.6 | 103.3 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 1.0 | +109.5 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 3.3 | +0.0 | 0.0 | 28.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 0.7 | +25.3 | 0.0 | 0.0 |
| CHAFF PASSED | 1.0 | -5.8 | 0.0 | 0.0 | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -0.5 | 28.3 | 0.0 |
| CHARGE LOSSES | 6.0 | -686.9 | 0.0 | 544.7 | 16.0 | -655.4 | 0.0 | 246.0 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 146.3 | 28.3 | 3.0 | +0.0 | 540.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.7 | +0.0 | 0.0 | 364.0 | 11.7 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 206.7 | - | - | - | - |
| CONVEYANCE SEARCH | 4.0 | +135.5 | 89.0 | 56.7 | - | - | - | - |
| COVER ONCE | 3.3 | -183.3 | 0.0 | 30.3 | 6.3 | -207.2 | 0.0 | 90.3 |
| DEPLOY BY FIGURES | 10.0 | -94.4 | 0.0 | 0.0 | 7.0 | +28.2 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.7 | -97.1 | 151.7 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +10.6 | 57.7 | 0.0 | - | - | - | - |
| ENGINEER BY LORE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 3.0 | +10.1 | 232.3 | 45.7 | 2.3 | +25.6 | 386.7 | 0.0 |
| FALL BACK GOOD ORDER | 2.7 | +0.9 | 205.7 | 45.7 | 2.0 | +51.3 | 362.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 22.3 | +295.6 | 0.0 | 121.0 |
| FEATURE BUFFS | 4.7 | +157.4 | 0.0 | 60.7 | 3.0 | +54.6 | 0.0 | 23.3 |
| FIGHT TO THE END | 1.0 | +1.3 | 113.7 | 17.3 | 1.0 | -0.9 | 237.0 | 0.0 |
| FIRE IN ORDER | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 90.3 | +2278.3 | 332.3 | 1415.7 | 80.0 | +5559.9 | 1005.3 | 688.0 |
| FLANK NOT WEIGHED | 4.7 | +0.0 | 0.0 | 178.0 | 7.0 | +0.0 | 0.0 | 149.7 |
| FOCUS FIRE | 0.3 | +4.8 | 0.0 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | - | - | - | - | 1.0 | +232.3 | 0.0 | 0.0 |
| FOOT FIRST | - | - | - | - | 24.0 | +0.0 | 0.0 | 240.7 |
| FOUR ROUNDS | 3.0 | +62.9 | 232.3 | 45.7 | 3.3 | +279.4 | 568.7 | 0.0 |
| FREED FROM HIS FIGHT | 2.7 | +0.0 | 0.0 | 63.3 | 3.0 | +0.0 | 0.0 | 204.0 |
| FRIEND SHOOTS FIRST | 1.0 | -43.4 | 0.0 | 0.0 | - | - | - | - |
| GOAL ROUTE | - | - | - | - | 0.7 | +40.9 | 0.0 | 0.0 |
| GOAL WALK | 3.7 | +210.5 | 0.0 | 206.7 | 12.7 | +1136.0 | 0.0 | 0.0 |
| GROUND FLIERS | 0.7 | +11.7 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 5.3 | +0.0 | 0.0 | 544.7 | 11.0 | +0.0 | 0.0 | 246.0 |
| HIS CHARGE LIST | 6.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 1.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 100.0 |
| HIS MOVE AND SHOT | 2.7 | -60.7 | 0.0 | 124.0 | 3.7 | -77.5 | 0.0 | 65.3 |
| HIS ONE QUARTER | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 4.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 100.0 |
| HIS RANDOM MOVE | 6.7 | +0.0 | 0.0 | 760.0 | 12.3 | +0.0 | 0.0 | 458.7 |
| HIS RANDOM MOVER COMES | 1.3 | +0.0 | 0.0 | 121.3 | 3.0 | +0.0 | 0.0 | 280.7 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 26.0 | +539.6 | 0.0 | 670.0 | 53.7 | +3467.1 | 0.0 | 601.3 |
| HIS SHOTS BY HIS RUN | 17.3 | +135.2 | 0.0 | 969.3 | 37.7 | +739.1 | 0.0 | 253.7 |
| HIS TURN DENIED | - | - | - | - | 1.3 | +79.7 | 330.0 | 0.0 |
| HOLD ODDS | 18.7 | +0.0 | 0.0 | 424.7 | 21.0 | +0.0 | 0.0 | 100.0 |
| HOLDER ASSIGNMENT | 7.7 | +805.3 | 0.0 | 182.0 | 11.0 | +1277.1 | 0.0 | 50.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.3 | -9.5 | 173.0 | 28.3 | 3.0 | -143.6 | 538.3 | 0.0 |
| IDLE COST | - | - | - | - | 17.3 | -301.2 | 0.0 | 261.3 |
| JOINT CHARGE NOW | 1.7 | -6.7 | 86.0 | 45.7 | 1.0 | +34.5 | 182.0 | 0.0 |
| JOINT LOOK BACK | 0.3 | +0.0 | 32.7 | 17.3 | - | - | - | - |
| KEEP FALLS | 0.3 | +4.5 | 0.0 | 73.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 1.0 | +49.3 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.7 | +0.0 | 0.0 | 526.7 | 1.0 | +0.0 | 224.0 | 23.3 |
| LONE WIZARD KEPT IN | 0.7 | +17.5 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 2.0 | +3.7 | 167.0 | 17.3 | 1.0 | +1.4 | 164.0 | 0.0 |
| LOST CHARGE | 0.3 | -0.9 | 32.7 | 17.3 | - | - | - | - |
| MANOEUVRE | 0.7 | -17.0 | 0.0 | 31.7 | 1.7 | +1.2 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.3 | +9.6 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +50.0 | 0.0 | 0.0 | 0.3 | +6.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 0.3 | -45.3 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.0 | +11.9 | 0.0 | 0.0 | 2.0 | +15.9 | 0.0 | 23.3 |
| MEETS IN TIME | 4.3 | +78.0 | 0.0 | 0.0 | 1.3 | +99.3 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 5.0 | +176.1 | 0.0 | 0.0 | 3.3 | +22.3 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 5.0 | +82.4 | 0.0 | 0.0 | 3.3 | +23.1 | 0.0 | 0.0 |
| MISSILES ON ONE TARGET | 0.3 | -9.3 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 3.7 | +60.4 | 0.0 | 28.3 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 1.3 | -19.0 | 121.3 | 56.7 | - | - | - | - |
| MOVE SPELL SPOT | 2.7 | +0.0 | 0.0 | 30.3 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 9.0 | +373.6 | 0.0 | 0.0 | 4.0 | +369.2 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | 0.3 | +2.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.0 | +224.8 | 0.0 | 335.0 | 6.0 | +275.6 | 0.0 | 56.0 |
| NEXT CHARGE BY LIST | 5.3 | +233.4 | 0.0 | 0.0 | 3.3 | +224.3 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 3.0 | -38.0 | 232.3 | 45.7 | 2.7 | -171.8 | 447.3 | 0.0 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 2.7 | -83.9 | 0.0 | 0.0 | 2.0 | -36.6 | 0.0 | 0.0 |
| OGRE LOADER SECOND SHOT | 0.7 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.0 | -27.1 | 0.0 | 0.0 | 6.7 | -165.8 | 0.0 | 96.0 |
| ONE JOINT FIGURE | 0.3 | +1.8 | 32.7 | 17.3 | 0.3 | -6.0 | 121.3 | 0.0 |
| ONE OBJECTIVE FORMULA | 4.0 | -17.8 | 0.0 | 151.7 | 5.3 | +123.3 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 1.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.7 | +37.5 | 30.3 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 1.3 | +54.0 | 135.3 | 0.0 |
| PATHS CROSS | 0.3 | +14.2 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | - | - | - | - | 0.7 | -3.9 | 0.0 | 0.0 |
| PLAN RESULT | 41.0 | +256.0 | 125.3 | 1118.0 | 38.3 | +646.6 | 338.3 | 350.7 |
| PROMISE BY ITS OWN SUM | 6.7 | -95.7 | 0.0 | 0.0 | 8.3 | -423.4 | 0.0 | 76.7 |
| PROMISE IN STEPS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 4.3 | -95.4 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 0.3 | -8.6 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 9.3 | +317.0 | 0.0 | 0.0 | 5.0 | +1103.2 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 1.7 | +0.0 | 0.0 | 0.0 | 4.0 | +5.5 | 0.0 | 0.0 |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.3 | +114.5 | 0.0 | 0.0 | 2.0 | +42.8 | 0.0 | 50.0 |
| REDIRECT FOR A FRIEND IN REACH | 4.0 | +0.0 | 0.0 | 28.3 | 1.0 | +0.0 | 0.0 | 53.3 |
| REDIRECT WEIGHED | 1.0 | +5.7 | 0.0 | 45.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 3.0 | -46.7 | 0.0 | 0.0 | 0.3 | -2.1 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.7 | +59.5 | 0.0 | 0.0 |
| RISK BY ARC | 2.3 | +78.3 | 179.0 | 45.7 | 3.0 | -137.5 | 540.3 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.7 | -9.0 | 303.3 | 0.0 |
| RUN DOWN | 3.0 | -29.2 | 232.3 | 45.7 | 1.0 | -5.6 | 137.3 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.7 | -149.7 | 0.0 | 0.0 | 2.3 | -57.7 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +0.3 | 0.0 | 0.0 | 1.3 | +8.3 | 0.0 | 32.7 |
| SELF MOVE SPELL | - | - | - | - | 2.0 | +535.2 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.3 | +4.0 | 0.0 | 0.0 | 0.3 | -1.5 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.7 | +112.0 | 0.0 | 0.0 | - | - | - | - |
| SET-UP MISSED | 0.3 | +104.5 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +0.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 14.0 | +0.0 | 0.0 | 170.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.3 | +45.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 0.3 | -18.4 | 0.0 | 28.3 | 0.3 | -7.4 | 103.3 | 0.0 |
| SHOT RISK POINTS | 15.3 | -91.1 | 0.0 | 124.0 | 28.3 | -309.6 | 0.0 | 534.7 |
| SHOTS AFTER THE MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 15.3 | +394.4 | 0.0 | 246.7 | 6.0 | +102.4 | 0.0 | 38.3 |
| SPELL SETS UP CHARGE | 0.7 | +112.0 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 7.0 | +0.0 | 0.0 | 149.7 | 9.0 | +0.0 | 0.0 | 103.7 |
| STANDS FOR A REASON | - | - | - | - | 2.3 | +0.0 | 63.3 | 76.7 |
| STANDS STILL | 53.7 | +0.0 | 100.0 | 675.3 | 16.3 | +0.0 | 436.7 | 0.0 |
| STAY WORTH | 25.3 | -715.7 | 80.0 | 370.0 | 8.7 | +44.8 | 436.7 | 76.7 |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.3 | +123.8 | 0.0 | 0.0 | 3.7 | +378.2 | 0.0 | 23.3 |
| SUPPORT WORKED OUT | 2.3 | +123.8 | 0.0 | 0.0 | 3.7 | +378.2 | 0.0 | 23.3 |
| SURE REACH TOGETHER | 0.7 | +2.7 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 1.0 | -63.7 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.3 | +0.0 | 0.0 | 121.3 | 6.0 | +0.0 | 0.0 | 38.3 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 30.3 | 5.0 | +0.0 | 0.0 | 117.7 |
| THE STEP BACK IS MADE | 1.7 | +0.0 | 0.0 | 30.3 | 3.3 | +0.0 | 0.0 | 66.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 36.7 | +0.0 | 0.0 | 608.3 | 37.3 | +0.0 | 0.0 | 344.0 |
| TIED UP BY THE SUM | 1.7 | +43.5 | 88.7 | 28.3 | 1.3 | +141.0 | 151.7 | 0.0 |
| TIME ON OUR SIDE | 43.7 | +505.9 | 0.0 | 679.7 | - | - | - | - |
| WAITS AGAIN | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 1.3 | -8.3 | 149.7 | 17.3 | 0.3 | +4.3 | 28.3 | 0.0 |
| WHO HITS BACK | 0.3 | +12.9 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 3.3 | -614.9 | 0.0 | 481.3 | 2.7 | -88.2 | 0.0 | 180.7 |
| WHOLE FIGHT GAIN | 0.7 | +11.3 | 59.3 | 17.3 | 0.3 | +16.1 | 121.3 | 0.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 3.0 | +121.2 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p38

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 89 | 89 | 56 | 18.67 | +1476 | +26.4 |
| HOLDER ASSIGNMENT | 56 | 56 | 55 | 18.33 | +3692 | +67.1 |
| HIS SHOT LIST | 239 | 235 | 41 | 13.67 | +981 | +23.9 |
| DEPLOY BY FIGURES | 51 | 51 | 35 | 11.67 | +435 | +12.4 |
| HIS SHOTS BY HIS RUN | 165 | 161 | 34 | 11.33 | +313 | +9.2 |
| FIVE ACTION | 511 | 503 | 27 | 9.00 | +458 | +17.0 |
| MOVE TO CHARGE COMPUTED | 39 | 36 | 25 | 8.33 | +392 | +15.7 |
| TIME ON OUR SIDE | 131 | 117 | 25 | 8.33 | +19 | +0.8 |
| THE TABLE AGAIN | 36 | 36 | 22 | 7.33 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 45 | 45 | 21 | 7.00 | -1557 | -74.2 |
| ARTILLERY RE-ROLL WEIGHED | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| GOAL WALK | 49 | 49 | 15 | 5.00 | +720 | +48.0 |
| REDIRECT FOR A FRIEND IN REACH | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| OFF BEST | 14 | 14 | 14 | 4.67 | -361 | -25.8 |
| NEXT CHARGE BY LIST | 26 | 24 | 13 | 4.33 | +253 | +19.5 |
| SHOT RISK POINTS | 131 | 131 | 13 | 4.33 | +76 | +5.9 |
| LEGAL CHARGES ONLY | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| PROMISE KNOWS THE FIGHT | 13 | 13 | 11 | 3.67 | -286 | -26.0 |
| MOVE ORDER | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| MEETS IN TIME | 17 | 17 | 9 | 3.00 | +159 | +17.7 |
| SUPPORT ADDS | 18 | 18 | 9 | 3.00 | +339 | +37.7 |
| SUPPORT WORKED OUT | 18 | 18 | 9 | 3.00 | +339 | +37.7 |
| WHOLE FIGHT DANGER | 18 | 18 | 9 | 3.00 | +194 | +21.5 |
| FOUR ROUNDS | 19 | 18 | 8 | 2.67 | +400 | +50.0 |
| JOINT CHARGE NOW | 8 | 8 | 8 | 2.67 | +84 | +10.4 |
| CANNON PLANNED TARGET | 27 | 27 | 7 | 2.33 | +11 | +1.6 |
| CANNON SIGHT KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| STAY WORTH | 102 | 94 | 7 | 2.33 | +46 | +6.6 |
| TIED UP BY THE SUM | 9 | 9 | 7 | 2.33 | +140 | +20.0 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| HARD STAY DROPPED | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CHARGE NOW FIRST | 14 | 14 | 5 | 1.67 | -317 | -63.3 |
| RANDOM MOVE BY FIGURES | 17 | 17 | 5 | 1.67 | +17 | +3.3 |
| SEARCH SPOT | 5 | 5 | 5 | 1.67 | +26 | +5.2 |
| SHOOTS FROM THE BEST SPOT | 7 | 7 | 5 | 1.67 | +62 | +12.4 |
| CAST JOB | 12 | 12 | 4 | 1.33 | +4 | +0.9 |
| MISSILES IN THE MOVE | 25 | 15 | 4 | 1.33 | +68 | +16.9 |
| ONE PROMISE A TARGET | 4 | 4 | 4 | 1.33 | +4 | +1.1 |
| REDIRECT WEIGHED | 4 | 4 | 4 | 1.33 | +68 | +17.1 |
| RISK BY ARC | 16 | 15 | 4 | 1.33 | +31 | +7.8 |
| CASTER AWAY FROM SCREEN | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CASTING BLOCK | 3 | 3 | 3 | 1.00 | +171 | +56.9 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | -18 | -5.8 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +697 | +232.3 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| LANE BY FIGURES | 3 | 3 | 3 | 1.00 | +148 | +49.3 |
| ONE OBJECTIVE FORMULA | 28 | 22 | 3 | 1.00 | +60 | +20.1 |
| QUARTER ODDS | 43 | 43 | 3 | 1.00 | +259 | +86.3 |
| SHOTS IN THE MOVE | 64 | 47 | 3 | 1.00 | +134 | +44.6 |
| CHARGE LOSSES | 66 | 66 | 2 | 0.67 | +60 | +30.0 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| COVER ONCE | 29 | 17 | 2 | 0.67 | +0 | +0.0 |
| EXACT ROUND | 16 | 15 | 2 | 0.67 | +6 | +2.9 |
| FALLS SHORT | 67 | 49 | 2 | 0.67 | +53 | +26.3 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| GOAL ROUTE | 2 | 2 | 2 | 0.67 | +123 | +61.3 |
| IDLE COST | 52 | 36 | 2 | 0.67 | +69 | +34.6 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +53 | +26.3 |
| MARCH CHECK | 2 | 2 | 2 | 0.67 | +39 | +19.5 |
| MOVES UNITS SPELL | 2 | 2 | 2 | 0.67 | +62 | +31.2 |
| OGRE LOADER SECOND SHOT | 2 | 2 | 2 | 0.67 | +3 | +1.7 |
| OPENS UP | 2 | 2 | 2 | 0.67 | +83 | +41.6 |
| OVERRUNS AWAY | 4 | 4 | 2 | 0.67 | +32 | +16.2 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.67 | -12 | -5.8 |
| REDIRECT COUNTER | 13 | 9 | 2 | 0.67 | +66 | +32.8 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +178 | +89.2 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +2 | +1.0 |
| SHOTS AFTER THE MOVES | 10 | 10 | 2 | 0.67 | +0 | +0.0 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| WAR ENGINE JOBS | 5 | 5 | 2 | 0.67 | -148 | -74.0 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +60 | +59.5 |
| CHAFF IN THE MOVE | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| FALL BACK GOOD ORDER | 14 | 13 | 1 | 0.33 | +80 | +80.4 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +14 | +14.3 |
| HIS TURN DENIED | 4 | 4 | 1 | 0.33 | +2 | +1.5 |
| JOINT LOOK BACK | 1 | 1 | 1 | 0.33 | +0 | +0.1 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +17 | +17.3 |
| MANOEUVRE | 7 | 7 | 1 | 0.33 | +7 | +7.2 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +29 | +29.0 |
| MAX FOR POSITIONING | 9 | 9 | 1 | 0.33 | +7 | +7.2 |
| NEARER NOT NEEDED | 33 | 32 | 1 | 0.33 | +3 | +3.0 |
| NO DOUBLE ROUNDS | 17 | 16 | 1 | 0.33 | +23 | +23.3 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +42 | +42.5 |
| SET UP BY THE SET | 2 | 2 | 1 | 0.33 | -21 | -20.9 |
| THE ROW IN ITS ORDER | 25 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +39 | +38.6 |
| CANNON PLAN MISSED | 3 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 13 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 58 | 58 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 12 | not checked | - | - | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 23 | 23 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 6 | 5 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 35 | not checked | - | - | - | - |
| FOOT FIRST | 72 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 17 | 17 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 3 | 3 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| GUN FIGURES | 4 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 10 | 10 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 49 | 49 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 25 | 24 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 13 | 13 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 19 | 19 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 6 | 6 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 30 | 28 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 57 | 57 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 13 | 13 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 119 | 119 | 0 | 0.00 | - | - |
| HONEST WORTH | 16 | 16 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 8 | 8 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 9 | 8 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | not checked | - | - | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 3 | 3 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 25 | 16 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 1 | not checked | - | - | - | - |
| MOVE SPELL IN RANGE | 11 | 11 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 4 | trace | - | - | - | - |
| MOVE SPELL SPOT | 8 | not checked | - | - | - | - |
| NO LATE CUT | 1 | 1 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 5 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 35 | 20 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 2 | 1 | 0 | 0.00 | - | - |
| ONE ROUTE | 3 | 3 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 238 | trace | - | - | - | - |
| PROMISE IN STEPS | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 3 | 3 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 10 | 9 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 5 | 5 | 0 | 0.00 | - | - |
| RUN DOWN | 12 | 11 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 9 | 9 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 2 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 49 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 2 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 48 | 41 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 7 | 7 | 0 | 0.00 | - | - |
| STANDS STILL | 210 | 207 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE PROMISE ADDS | 3 | 3 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 20 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 15 | not checked | - | - | - | - |
| THE TABLE BINDS | 222 | not checked | - | - | - | - |
| WAITS AGAIN | 9 | 9 | 0 | 0.00 | - | - |
| WHO FIGHTS | 5 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 3 | 2 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 9 | 9 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p38

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 3.33 | 3.67 | 74.2 |
| JOB FIRST | gate | 2.67 | 2.00 | 25.8 |
| ARMY TABLE | rule | 1.00 | 3.33 | 31.5 |
| PROMISE KNOWS THE FIGHT | rule | 3.00 | - | 31.7 |
| CHARGE NOW FIRST | rule | 0.33 | 1.33 | 63.3 |
| CHAFF PASSED | rule | 1.00 | - | 5.8 |
| JOINT CHARGE NOW | rule | 1.00 | - | 31.7 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.33 | 11.4 |
| ONE PROMISE A TARGET | rule | 0.67 | - | 2.2 |
| PIVOT GUARDS FLANK | rule | - | 0.67 | 5.8 |
| WAR ENGINE JOBS | rule | 0.67 | - | 74.0 |
| SET UP BY THE SET | rule | - | 0.33 | 20.9 |

### Plans: gs3-83c8646-p38

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 43% | 148 | 118 | 80% |
| Mine | move | 27.7 | 95% | 973 | 0 | 0% |
| Mine | shoot | 11.0 | 52% | 361 | 138 | 38% |
| Opponent | charge | 3.0 | 78% | 512 | 421 | 82% |
| Opponent | move | 33.0 | 95% | 1900 | 0 | 0% |
| Opponent | shoot | 1.3 | 100% | 65 | 226 | 348% |
| Opponent | support | 1.0 | 100% | 7 | 0 | 0% |

### Battle groups: gs3-83c8646-p38

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 2.0 | 33% | 0% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p38

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Character | 6 | 0 (6) | 0 | 0 | 23 | 67% | 1.5 | 0 (1) | 0 (1) | 0 (3) | - | 0 (5) |
| Mine | Clean-up | 7 | 167 (7) | 15 | 152 | 45 | 57% | 4.7 | 161 (2) | 200 (4) | 0 (1) | 260 (5) | 0 (2) |
| Mine | Fast Hammer | 2 | 189 (2) | 189 | 0 | 50 | 0% | 3.0 | - | - | 189 (2) | 319 (1) | 59 (1) |
| Mine | Hammer | 9 | 8 (9) | 1 | 7 | 54 | 33% | 1.3 | 6 (4) | 11 (4) | 0 (1) | 10 (5) | 5 (4) |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | War machine | 8 | 12 (8) | 12 | 0 | 31 | 0% | 2.1 | 19 (4) | 5 (4) | - | - | 12 (8) |
| Mine | Wizard | 6 | 0 (6) | 0 | 0 | 15 | 17% | 3.8 | 0 (2) | 0 (2) | 0 (2) | - | 0 (6) |
| Opponent | Chaff | 3 | 40 (3) | 40 | 0 | 77 | 67% | 3.0 | 0 (1) | 74 (1) | 0 (1) | 40 (3) | - |
| Opponent | Character | 7 | 68 (7) | 68 | 0 | 0 | 29% | 1.4 | 0 (1) | 98 (5) | 0 (1) | 43 (5) | 117 (2) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Opponent | Fast Hammer | 9 | 37 (9) | 10 | 27 | 13 | 44% | 2.6 | 39 (4) | 37 (5) | - | 70 (5) | 9 (4) |
| Opponent | Hammer | 4 | 35 (4) | 0 | 35 | 30 | 75% | 2.0 | - | 35 (4) | - | 49 (3) | 0 (1) |
| Opponent | Holder | 2 | 46 (2) | 0 | 46 | 37 | 50% | 6.0 | - | 46 (2) | - | 72 (1) | 0 (1) |
| Opponent | Shooter | 2 | 119 (2) | 0 | 119 | 0 | 0% | 1.0 | 119 (2) | - | - | 238 (1) | 34 (1) |

### Charged fights: gs3-83c8646-p38

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 0 | 421 | 5.0 | 1.2 | 84 | 10 | +74 | 0 of 5 | 5 of 5 | +80 | +72 |
| Mine | Chaos Dwarfs | 2 | 72 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 48 | 140 | 1.7 | 1.2 | 84 | 10 | +74 | 0 of 5 | 5 of 5 | +80 | +72 |
| Opponent | High Elf Realms | 1 | 0 | 620 | 2.0 | 1.0 | 310 | 0 | +310 | 2 of 2 | 2 of 2 | - | +310 |
| Opponent | Warriors of Chaos | 2 | 42 | 428 | 3.0 | 1.0 | 143 | 0 | +143 | 1 of 6 | 5 of 6 | - | +143 |
| **Opponent** | all armies | 3 | 28 | 492 | 2.7 | 1.0 | 184 | 0 | +184 | 3 of 8 | 7 of 8 | - | +184 |

### Effective charges: gs3-83c8646-p38

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 0 | 0 | 0 | 1 (net +173) | 0 | 3 (net +65) | 1 | 0% (0 of 4) |
| Opponent | High Elf Realms | 2 | 0 | 0 | 0 | 1 (net +310) | 0 | 1 (net +310) | 0 | 0% (0 of 2) |
| Opponent | Warriors of Chaos | 6 | 0 | 0 | 0 | 0 | 2 (net +112) | 2 (net +115) | 2 | 0% (0 of 4) |

### Charged fights, damage counted: gs3-83c8646-p38

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 1 | 85 | 173 | +173 | 173 | 21 | +152 | +178.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 91 | 83 | +65 | 83 | 17 | +65 | +71.5 |
| Mine | No odds | 1 | 52 | 173 | +0 | 49 | 0 | +49 | +94.2 |
| Mine | All fights | 5 | 82 | 119 | +74 | 94 | 15 | +79 | +96.5 |
| Opponent | 76-89% | 1 | 497 | 310 | +310 | 340 | 0 | +340 | +68.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 378 | 208 | +180 | 208 | 75 | +133 | +35.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 489 | 112 | +112 | 112 | 0 | +112 | +23.0 |
| Opponent | No odds | 2 | 331 | 240 | +200 | 200 | 8 | +193 | +58.3 |
| Opponent | All fights | 8 | 409 | 205 | +184 | 199 | 30 | +169 | +41.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p38 | move | 22 | 6 (27%) | 2 (9%) | 3 (14%) | 13 (59%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Ring of Doom | Mine | L0230 |
| Ring of Doom | Opponent | L0315 |

# Doctrine scorecard: gs3-83c8646-p5

### Scorecard: gs3-83c8646-p5

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0717 | 3 | 1 | Mine | no | 0 | 4 | 5 | 0 | 0 | 0 | 0 | 497 |
| L0717 | 3 | 1 | Opponent | yes | 5 | - | 0 | 1 | 1 | 0 | 0 | 141 |
| L0733 | 1 | 1 | Mine | no | 11 | 3 | 0 | 1 | 0 | 0 | 0 | 372 |
| L0733 | 1 | 1 | Opponent | no | 0 | 4 | 1 | 5 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 10 | 3 | 1 | 1 | 0 | 0 | 0 | 551 |
| L0823 | 1 | 1 | Opponent | no | 0 | 1 | 2 | 3 | 1 | 0 | 0 | 195 |
| **Average** | | | Mine | 0% | 7.0 | 3.3 | 2.0 | 0.7 | 0.0 | 0.0 | 0.0 | 473.3 |
| **Average** | | | Opponent | 33% | 1.7 | 2.5 | 1.0 | 3.0 | 0.7 | 0.0 | 0.0 | 112.0 |

### KPIs: gs3-83c8646-p5

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 69% (11 of 16) | 0% (0 of 14) | 37% (11 of 30) |
| Winner chose to follow up after the loser gave ground |  | 100% (3 of 3); on the table 100% | 100% (1 of 1); on the table 100% | 100% (4 of 4); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 50% (1 of 2); on the table 50% | 50% (1 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 100% (3 of 3); on the table 100% | 67% (2 of 3); on the table 67% | 83% (5 of 6); on the table 83% |
| Magic missiles tried each own turn | 50%+ | 42% (5 of 12) | 8% (1 of 12) | 25% (6 of 24) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 62% (5 of 8) | 12% (1 of 8) | 38% (6 of 16) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 56% (3338 of 5998) | 64% (3849 of 6000) | 60% (7187 of 11998) |
|   infantry points that never fought | lower | 48% (344 of 715) | 64% (909 of 1418) | 59% (1253 of 2133) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 57% (17 of 30) | 68% (15 of 22) | 62% (32 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (2 of 2); 2.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Bound items with another spell used |  | 50% (1 of 2); 0.7 uses a game | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 3); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 4); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 51% (2771 of 5389) | 70% (3529 of 5023) | 61% (6300 of 10412) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (55%) | 2.0 (33%) |
| MARCHED: its unit marched | 1.0 (43%) | 0.3 (9%) | 1.3 (22%) |
| IN COMBAT: engaged in combat | 0.3 (14%) | 0.0 (0%) | 0.3 (6%) |
| GONE: slain | 1.0 (43%) | 1.3 (36%) | 2.3 (39%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.0 | 0.7 | 2.0 | 0.3 | 0.0 |
| not cast | 5.0 | 1.3 | 6.0 | 1.7 | 12.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (25%) | 2.0 (33%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.3 (22%) | 0.3 (20%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.3 (6%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 2.7 (53%) | 1.0 (75%) | 2.3 (39%) | 1.3 (80%) | 4.3 (36%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (47%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 7.7 (64%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 76% (73 of 96) | 73% (72 of 98) | 75% (145 of 194) |
|   cavalry | 67% (8 of 12) | 67% (10 of 15) | 67% (18 of 27) |
|   character | - | 60% (9 of 15) | 60% (9 of 15) |
|   chariot | 50% (2 of 4) | - | 50% (2 of 4) |
|   infantry | 67% (16 of 24) | 83% (49 of 59) | 78% (65 of 83) |
|   monster | - | 44% (4 of 9) | 44% (4 of 9) |
|   war machine | 84% (47 of 56) | - | 84% (47 of 56) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (22%) | 0.7 (8%) | 2.3 (14%) |
| CHARGED: it charged | 0.0 (0%) | 2.0 (23%) | 2.0 (12%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 1.7 (19%) | 1.7 (10%) |
| MOVED: a war machine that moved | 0.3 (4%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 1.7 (22%) | 2.3 (27%) | 4.0 (24%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (9%) | 0.0 (0%) | 0.7 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (17%) | 2.0 (23%) | 3.3 (20%) |
| SHELTERED: the target was sheltered | 1.3 (17%) | 0.0 (0%) | 1.3 (8%) |
| OTHER BAR | 0.7 (9%) | 0.0 (0%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 8.3 | 4.0 | 68% | 8.3 pts | 69 pts |
| character | 3.0 | 1.0 | 67% | 10.7 pts | 32 pts |
| chariot | 0.7 | 1.0 | 50% | 73.3 pts | 49 pts |
| infantry | 31.3 | 12.0 | 71% | 8.6 pts | 270 pts |
| monster | 1.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 15.7 | 17.3 | 49% | 36.6 pts | 574 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.3 | 2.7 | 2.5 |
| Charges that made contact a game | 2.0 | 2.0 | 2.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.50 contact (2 units) | - | 0.50 declared, 0.50 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.26 declared, 0.22 contact (23 units) | 0.28 declared, 0.21 contact (29 units) | 0.27 declared, 0.21 contact (52 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 56% (5 of 9) | 0% (0 of 3) | - | 42% (5 of 12) |
| Character in a unit | 83% (5 of 6) | - | 100% (1 of 1) | 86% (6 of 7) |
| Character on its own | 67% (2 of 3) | 100% (1 of 1) | 67% (4 of 6) | 70% (7 of 10) |
| Chariot | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Infantry | 0% (0 of 2) | 33% (1 of 3) | 0% (0 of 1) | 17% (1 of 6) |
| Monster | 80% (4 of 5) | - | - | 80% (4 of 5) |
| Monstrous | 100% (1 of 1) | - | - | 100% (1 of 1) |
| War Machines | 70% (7 of 10) | - | - | 70% (7 of 10) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 3 | 100% (3 of 3); on the table 100% | 42% (5 of 12) | 56% | 57% (17 of 30) | 0.0 uses a game | 50% (1 of 2); 0.7 uses a game | 0% (0 of 3); 0.0 uses a game |
| Lizardmen | 1 | 0% (0 of 1); on the table 0% | - | 60% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 69% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (1 of 1); on the table 100% | 17% (1 of 6) | 64% | 70% (7 of 10) | 100% (2 of 2); 6.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p5, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (3) | 67% (2) | 56% (5) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.67 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.67 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: gs3-83c8646-p5

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.3 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 50% (3 of 6) | 60% (3 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 32% (20 of 62) | 79% (11 of 14) |
| Strategy | Hexes on a unit its side charged or shot that turn | 100% (2 of 2) | - |
| Strategy | Joined characters whose unit fought | 50% (2 of 4) | 25% (1 of 4) |
| Strategy | Lone characters that fought | 44% (4 of 9) | 17% (1 of 6) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 0.7 | 3.0 |
| Movement | Points that never moved of their own | 473.3 | 112.0 |
| Movement | Fights charged into per game | 2.0 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 5 | 1 of 3, net -110 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 5 | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 5, net -380 | 1 of 3, net +175 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 5, net -9 | 1 of 3, net +265 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.7 | 25.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 19% (5 of 26) | 51% (39 of 76) |
| Shooting | Points destroyed by shooting units | 94.7 | 15.0 |
| Shooting | War machine shots | 15.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 55% (26 of 47) | - |
| Shooting | Points destroyed by war machines | 363.3 | 0.0 |
| Magic | Magic missiles cast | 1.0 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 3) | 0% (0 of 1) |
| Magic | Wounds caused by magic missiles | 2.7 | 2.7 |
| Magic | Points destroyed by magic (all spells) | 36.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.7 / 0.0 / 0.0 | 2.0 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 154.3 | 394.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | -55 | +103 |
| Combat | Net per 100 charger points, damage counted | -26.6 | +45.1 |
| Combat | First round won (charged fights) | 50% | 83% |
| Combat | Net points per charged fight | -37 | +105 |
| Combat | Net points per supported fight / lone fight | - / -37 | - / +105 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 6 | 4 of 6 |
| Game | Points lost | 494.7 | 615.0 |
| Game | VP from objectives | 966.7 | 1003.3 |
| Game | Lone holders (player turns) | 7.0 | 1.7 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -0 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1110
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p5

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 36.0 |
| ARMY TABLE | 15.7 | +164.1 | 0.0 | 73.3 | 27.3 | +378.6 | 0.0 | 136.0 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +0.7 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 7.0 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 47.0 | 41.7 | - | - | - | - |
| CANNON PLANNED TARGET | 15.0 | +368.9 | 1554.0 | 170.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 1.0 | +70.0 | 72.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 2.3 | +98.7 | 0.0 | 19.0 |
| CHARACTER GUNS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 20.3 | -902.4 | 0.0 | 73.3 | 27.3 | -1620.2 | 0.0 | 746.3 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 89.3 | 163.3 | 0.7 | +0.0 | 0.0 | 65.0 |
| CLOSES ON WHAT IT BEATS | 6.0 | +0.0 | 0.0 | 0.0 | 15.3 | +0.0 | 0.0 | 337.7 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 12.3 | -668.6 | 0.0 | 163.3 | 9.7 | -862.9 | 0.0 | 61.7 |
| DENIED BY THE FIGHT | 0.7 | -76.9 | 27.7 | 36.7 | - | - | - | - |
| DEPLOY BY FIGURES | 8.7 | -71.5 | 0.0 | 0.0 | 8.7 | +28.7 | 0.0 | 101.0 |
| EXACT ROUND | 1.7 | +35.2 | 89.3 | 163.3 | 1.7 | +32.9 | 58.3 | 65.0 |
| FALL BACK GOOD ORDER | 2.3 | +6.1 | 89.3 | 163.3 | 1.7 | +0.1 | 58.3 | 65.0 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | - | - | - | - | 19.0 | +268.0 | 0.0 | 383.3 |
| FIGHT TO THE END | 0.7 | +2.1 | 0.0 | 36.7 | 1.0 | +23.8 | 0.0 | 65.0 |
| FIRE IN ORDER | 1.3 | +0.0 | 58.3 | 0.0 | - | - | - | - |
| FIVE ACTION | 109.7 | +7375.1 | 3456.3 | 830.0 | 88.3 | +5657.6 | 118.3 | 1137.7 |
| FLANK NOT WEIGHED | 8.0 | +0.0 | 0.0 | 45.0 | 5.7 | +0.0 | 0.0 | 139.7 |
| FOLLOW UP WEIGHED | 0.7 | +30.0 | 0.0 | 0.0 | 0.3 | +72.4 | 0.0 | 0.0 |
| FOOT FIRST | - | - | - | - | 9.7 | +0.0 | 0.0 | 23.3 |
| FOUR ROUNDS | 2.3 | +59.9 | 89.3 | 163.3 | 1.7 | +194.0 | 58.3 | 65.0 |
| FREED FROM HIS FIGHT | 3.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -38.1 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 1.0 | -59.2 | 0.0 | 0.0 | - | - | - | - |
| GOAL ROUTE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| GOAL WALK | 6.7 | +485.9 | 0.0 | 0.0 | 19.0 | +1413.0 | 0.0 | 72.0 |
| GUN FIGURES | 1.0 | +0.0 | 180.0 | 0.0 | - | - | - | - |
| GUN MASK | 2.7 | +173.8 | 0.0 | 73.3 | - | - | - | - |
| HARD STAY DROPPED | 2.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 18.0 | +0.0 | 0.0 | 73.3 | 16.3 | +0.0 | 0.0 | 557.7 |
| HIS CHARGE DENIED | 0.3 | +17.0 | 0.0 | 126.7 | - | - | - | - |
| HIS CHARGE LIST | 1.3 | +0.0 | 0.0 | 0.0 | 10.0 | +0.0 | 0.0 | 78.0 |
| HIS LEGAL MOVES | 11.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 6.3 | -116.2 | 0.0 | 73.3 | 6.0 | -94.8 | 0.0 | 27.7 |
| HIS ONE QUARTER | 2.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 12.7 |
| HIS OWN BEST MOVE | 13.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 43.3 | +1687.0 | 0.0 | 0.0 | 62.3 | +3218.9 | 0.0 | 803.3 |
| HIS SHOTS BY HIS RUN | 41.3 | +1081.8 | 0.0 | 73.3 | 45.3 | +1417.3 | 0.0 | 759.0 |
| HIS TURN DENIED | 1.3 | +90.7 | 89.3 | 36.7 | 0.7 | +12.9 | 0.0 | 0.0 |
| HOLD ODDS | 22.0 | +0.0 | 0.0 | 0.0 | 22.0 | +0.0 | 0.0 | 99.7 |
| HOLDER ASSIGNMENT | 15.0 | +1448.5 | 0.0 | 0.0 | 16.0 | +1334.3 | 0.0 | 99.7 |
| HOLDS AMBUSHERS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.3 | -53.7 | 89.3 | 163.3 | 1.7 | -60.5 | 58.3 | 65.0 |
| HORN WORTH | - | - | - | - | 0.3 | +6.1 | 0.0 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 1.0 | +21.4 | 0.0 | 61.7 |
| IDLE COST | - | - | - | - | 13.7 | -210.7 | 0.0 | 201.3 |
| KEPT FROM ITS LAST STOP | 5.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +17.2 | 0.0 | 0.0 | 1.3 | +85.6 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 5.7 | +0.0 | 0.0 | 402.3 | 15.7 | +0.0 | 265.0 | 93.3 |
| LONE CHARACTER SAFE SPOT | 0.7 | +0.0 | 0.0 | 15.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 0.3 | +19.8 | 0.0 | 0.0 | 0.3 | +37.5 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +33.3 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 1.3 | -0.1 | 27.7 | 36.7 | 0.3 | +0.1 | 0.0 | 65.0 |
| MAKE SURE TOGETHER | 1.7 | +44.6 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 1.0 | +0.0 | 0.0 | 0.0 | 1.7 | -22.3 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +4.3 | 0.0 | 36.0 |
| MARCH BY THE SUM | 0.3 | +12.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | - | - | - | - | 0.3 | +6.0 | 0.0 | 36.0 |
| MARCH OF THE TABLE | 0.3 | +3.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | +131.9 | 0.0 | 0.0 | 0.3 | +9.9 | 0.0 | 36.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 3.0 | +125.9 | 0.0 | 126.7 | 1.7 | +52.3 | 0.0 | 61.7 |
| MEETS IN TIME | 4.3 | +404.6 | 0.0 | 0.0 | 4.0 | +319.6 | 0.0 | 36.0 |
| MISSILES IN THE MOVE | 1.7 | +99.3 | 0.0 | 126.7 | 2.0 | +17.8 | 0.0 | 78.0 |
| MISSILES NEXT TURN | 2.3 | +66.9 | 0.0 | 126.7 | 3.7 | +31.8 | 0.0 | 114.0 |
| MOVE ORDER | 1.7 | +0.0 | 0.0 | 30.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 5.3 | +509.8 | 0.0 | 0.0 | 3.7 | +176.3 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 9.0 | +374.9 | 0.0 | 0.0 | 10.3 | +521.7 | 0.0 | 0.0 |
| NEAREST TO GOAL | - | - | - | - | 4.3 | +0.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 4.3 | +308.7 | 0.0 | 0.0 | 1.7 | +99.6 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.7 | -1.9 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.3 | -36.2 | 89.3 | 163.3 | 1.7 | -110.9 | 58.3 | 65.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT WORTH A CAST | 2.3 | -1.0 | 0.0 | 28.3 | - | - | - | - |
| OFF BEST | 7.0 | -243.5 | 0.0 | 80.0 | 6.3 | -186.4 | 0.0 | 12.7 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 4.7 | -101.7 | 0.0 | 126.7 | 4.3 | -91.5 | 0.0 | 180.0 |
| ONE OBJECTIVE FORMULA | 4.7 | +7.5 | 0.0 | 0.0 | 7.7 | -64.3 | 0.0 | 63.7 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +12.3 | 0.0 | 126.7 | 0.3 | +20.6 | 15.0 | 0.0 |
| OVERRUNS AWAY | 1.0 | +16.6 | 61.7 | 126.7 | 0.3 | +45.2 | 15.0 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +12.6 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -13.1 | 0.0 | 0.0 |
| PLAN RESULT | 50.3 | +2135.3 | 180.0 | 724.7 | 40.0 | +170.1 | 118.3 | 721.3 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 180.0 |
| PROMISE BY ITS OWN SUM | 4.3 | -3.9 | 0.0 | 0.0 | 7.0 | -112.9 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 1.0 | -59.3 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | - | - | - | - | 1.0 | -5.2 | 0.0 | 0.0 |
| QUARTER ODDS | 30.7 | +2682.7 | 46.7 | 246.7 | 21.3 | +2115.7 | 88.3 | 59.3 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 2.0 | +55.4 | 0.0 | 12.7 |
| REDIRECT COUNTER | - | - | - | - | 1.0 | -22.0 | 0.0 | 6.3 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 4.0 | +47.5 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.7 | -19.1 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.3 | +124.6 | 89.3 | 163.3 | 1.3 | -113.3 | 15.0 | 65.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.0 | -19.6 | 58.3 | 65.0 |
| RUN DOWN | 1.3 | -5.7 | 27.7 | 163.3 | 0.7 | -1.6 | 43.3 | 65.0 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +1.8 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.3 | -37.2 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +35.3 | 0.0 | 126.7 | 0.3 | +0.2 | 0.0 | 27.7 |
| SECOND LOOK | 0.3 | +30.4 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.7 | -3.6 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 2.0 | -15.7 | 0.0 | 0.0 | 2.0 | +31.8 | 0.0 | 0.0 |
| SET UP TOGETHER | 2.0 | +50.4 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +3.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 24.0 | +0.0 | 0.0 | 341.7 | 5.3 | +0.0 | 0.0 | 27.7 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +94.2 | 156.0 | 253.3 | - | - | - | - |
| SHORT GUN FORWARD | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 1.0 | -115.3 | 123.3 | 0.0 | 0.3 | -0.7 | 0.0 | 65.0 |
| SHOT RISK POINTS | 29.0 | -177.6 | 0.0 | 73.3 | 38.3 | +100.4 | 0.0 | 853.3 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 25.7 | +904.8 | 0.0 | 170.0 | 21.7 | +340.1 | 0.0 | 269.3 |
| SPELL WORTH | 0.3 | +3.1 | 28.3 | 28.3 | 2.7 | +32.1 | 78.0 | 156.0 |
| SPELLS IN THE FIGHT | 0.7 | +3.8 | 61.7 | 126.7 | - | - | - | - |
| SPOT AS THE GAME MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 42.3 |
| STAND AND SHOOT | 1.3 | -11.5 | 27.7 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | - | - | - | - | 5.0 | +0.0 | 0.0 | 360.0 |
| STANDS STILL | 65.3 | +0.0 | 3367.0 | 593.3 | 21.3 | +0.0 | 60.0 | 74.3 |
| STAY WORTH | 55.3 | +46.6 | 3164.3 | 380.0 | 15.0 | +76.4 | 0.0 | 36.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.7 | +21.2 | 28.3 | 130.0 |
| STUBBORN BY POINTS | - | - | - | - | 0.3 | +8.4 | 0.0 | 0.0 |
| SUPPORT ADDS | 3.0 | +86.2 | 0.0 | 0.0 | 6.0 | +530.3 | 0.0 | 89.3 |
| SUPPORT WORKED OUT | 3.0 | +86.2 | 0.0 | 0.0 | 6.0 | +530.3 | 0.0 | 89.3 |
| SURE REACH TOGETHER | 0.3 | +1.5 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 36.0 |
| THE ROW IN ITS ORDER | 3.0 | +0.0 | 0.0 | 126.7 | 4.0 | +0.0 | 65.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 58.3 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 58.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 52.3 | +0.0 | 0.0 | 378.3 | 41.7 | +0.0 | 0.0 | 536.3 |
| TIED UP BY THE SUM | 1.0 | +73.4 | 27.7 | 163.3 | 0.3 | +35.9 | 15.0 | 0.0 |
| TIME ON OUR SIDE | 41.3 | +452.3 | 0.0 | 156.7 | - | - | - | - |
| WAITS AGAIN | 3.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | 0.3 | -0.8 | 0.0 | 36.7 | 0.3 | +26.2 | 0.0 | 65.0 |
| WHO HITS BACK | 0.7 | +15.7 | 0.0 | 36.7 | 0.7 | +83.2 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 1.7 | -241.3 | 0.0 | 0.0 | 3.7 | -539.3 | 0.0 | 123.3 |
| WOUNDS ON THE RANKS | 9.0 | +217.4 | 0.0 | 0.0 | 4.3 | +131.7 | 0.0 | 72.0 |

### Rule changes: gs3-83c8646-p5

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 129 | 129 | 96 | 32.00 | +1701 | +17.7 |
| HIS SHOT LIST | 317 | 309 | 82 | 27.33 | +1754 | +21.4 |
| HOLDER ASSIGNMENT | 93 | 93 | 82 | 27.33 | +5210 | +63.5 |
| LEGAL CHARGES ONLY | 64 | 64 | 64 | 21.33 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 260 | 252 | 55 | 18.33 | +998 | +18.2 |
| OFF BEST | 40 | 40 | 40 | 13.33 | -1290 | -32.2 |
| DEPLOY BY FIGURES | 52 | 52 | 33 | 11.00 | +478 | +14.5 |
| FIVE ACTION | 594 | 584 | 28 | 9.33 | +1341 | +47.9 |
| SHOT RISK POINTS | 202 | 196 | 24 | 8.00 | +495 | +20.6 |
| QUARTER ODDS | 156 | 153 | 23 | 7.67 | +1009 | +43.9 |
| GOAL WALK | 77 | 77 | 22 | 7.33 | +727 | +33.0 |
| THE TABLE AGAIN | 36 | 36 | 22 | 7.33 | +0 | +0.0 |
| TIME ON OUR SIDE | 124 | 104 | 22 | 7.33 | +104 | +4.7 |
| ARTILLERY RE-ROLL WEIGHED | 21 | 21 | 21 | 7.00 | +0 | +0.0 |
| CHARGE LOSSES | 143 | 139 | 14 | 4.67 | +789 | +56.4 |
| MOVE ORDER | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 27 | 22 | 13 | 4.33 | +885 | +68.0 |
| REDIRECT FOR A FRIEND IN REACH | 12 | 12 | 12 | 4.00 | +128 | +10.7 |
| HARD STAY DROPPED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 18 | 16 | 11 | 3.67 | +508 | +46.2 |
| MEETS IN TIME | 25 | 25 | 9 | 3.00 | +266 | +29.5 |
| PROMISE BY ITS OWN SUM | 34 | 34 | 9 | 3.00 | -350 | -38.9 |
| STAY WORTH | 211 | 184 | 9 | 3.00 | +14 | +1.6 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| COVER ONCE | 66 | 39 | 6 | 2.00 | +105 | +17.6 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 7 | 6 | 5 | 1.67 | +128 | +25.7 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +308 | +61.7 |
| SET UP BY THE SET | 12 | 12 | 5 | 1.67 | +219 | +43.9 |
| SUPPORT ADDS | 27 | 26 | 5 | 1.67 | +178 | +35.6 |
| SUPPORT WORKED OUT | 27 | 26 | 5 | 1.67 | +178 | +35.6 |
| FIRE IN ORDER | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 28 | 28 | 4 | 1.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 142 | 95 | 4 | 1.33 | +29 | +7.2 |
| THE ROW IN ITS ORDER | 21 | 4 | 4 | 1.33 | +0 | +0.0 |
| WHO HITS BACK | 4 | 4 | 4 | 1.33 | +229 | +57.2 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +307 | +102.5 |
| FOUR ROUNDS | 12 | 12 | 3 | 1.00 | +228 | +75.9 |
| MAX FOR POSITIONING | 14 | 13 | 3 | 1.00 | +52 | +17.3 |
| MISSILES IN THE MOVE | 11 | 7 | 3 | 1.00 | +171 | +56.9 |
| PROMISE SHOT AWAY | 3 | 3 | 3 | 1.00 | -16 | -5.2 |
| WHOLE FIGHT DANGER | 16 | 16 | 3 | 1.00 | +141 | +46.9 |
| WOUNDS ON THE RANKS | 40 | 40 | 3 | 1.00 | +74 | +24.7 |
| IDLE COST | 41 | 20 | 2 | 0.67 | +11 | +5.6 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +172 | +86.0 |
| ONE OBJECTIVE FORMULA | 37 | 29 | 2 | 0.67 | +103 | +51.3 |
| OPENS UP | 2 | 2 | 2 | 0.67 | +33 | +16.5 |
| OVERRUNS AWAY | 4 | 4 | 2 | 0.67 | +33 | +16.5 |
| SEARCH SPOT | 2 | 2 | 2 | 0.67 | +107 | +53.3 |
| SET UP TOGETHER | 6 | 4 | 2 | 0.67 | +16 | +8.2 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +9 | +4.5 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +64 | +31.8 |
| TIED UP BY THE SUM | 4 | 4 | 2 | 0.67 | +57 | +28.7 |
| CANNON PLANNED TARGET | 45 | 45 | 1 | 0.33 | +0 | +0.0 |
| CAST JOB | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| GOAL ROUTE | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS CHARGE DENIED | 1 | 1 | 1 | 0.33 | +11 | +11.4 |
| HOLDS AMBUSHERS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HORN WORTH | 1 | 1 | 1 | 0.33 | +18 | +18.2 |
| HUNT IN PAIRS | 3 | 1 | 1 | 0.33 | +5 | +4.9 |
| LONG SHOT | 1 | 1 | 1 | 0.33 | +39 | +38.7 |
| MANOEUVRE | 8 | 8 | 1 | 0.33 | +0 | +0.0 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +37 | +37.0 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -11 | -11.4 |
| ONE FIGHT FORMULA | 27 | 18 | 1 | 0.33 | +0 | +0.0 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | +2 | +1.7 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +38 | +37.7 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -39 | -39.3 |
| PROMISE READS THE TABLE | 3 | 3 | 1 | 0.33 | +6 | +5.6 |
| REDIRECT BY WHAT IT STOPS | 6 | 6 | 1 | 0.33 | +0 | +0.0 |
| REDIRECT COUNTER | 3 | 1 | 1 | 0.33 | +6 | +5.8 |
| RISK BY ARC | 11 | 11 | 1 | 0.33 | +33 | +33.4 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +91 | +91.2 |
| SHOOTS FROM THE BEST SPOT | 2 | 2 | 1 | 0.33 | +32 | +32.1 |
| SHORT GUN FORWARD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +25 | +25.3 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +2 | +1.8 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 18 | 16 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 6 | 6 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 64 | 61 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| EXACT ROUND | 10 | 10 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 12 | 12 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FALLS SHORT | 57 | 52 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 5 | 5 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 41 | not checked | - | - | - | - |
| FOOT FIRST | 29 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 20 | 20 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 3 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 3 | not checked | - | - | - | - |
| GUN MASK | 8 | 8 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 14 | 14 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 103 | 99 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 34 | 32 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 44 | 43 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 37 | 37 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 18 | 15 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 52 | 50 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 6 | 6 | 0 | 0.00 | - | - |
| HOLD ODDS | 132 | 132 | 0 | 0.00 | - | - |
| HONEST WORTH | 12 | 12 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 22 | 22 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 2 | not checked | - | - | - | - |
| LOST AFTER ESCAPE | 5 | 5 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 5 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH CHECK | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 18 | 13 | 0 | 0.00 | - | - |
| NEARER NOT NEEDED | 58 | 56 | 0 | 0.00 | - | - |
| NEAREST TO GOAL | 13 | 13 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 12 | 12 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 7 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 271 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 7 | 4 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 5 | 4 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 6 | 6 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 1 | 1 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 88 | not checked | - | - | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL WORTH | 9 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 25 | 25 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 15 | 15 | 0 | 0.00 | - | - |
| STANDS STILL | 260 | 257 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 10 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 14 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 9 | not checked | - | - | - | - |
| THE TABLE BINDS | 282 | not checked | - | - | - | - |
| WAITS AGAIN | 17 | 15 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p5

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 6.67 | 6.00 | 32.2 |
| ARMY TABLE | rule | 2.33 | 3.67 | 28.5 |
| PROMISE BY ITS OWN SUM | rule | 0.33 | 2.67 | 38.9 |
| HOLDER ASSIGNMENT | rule | 0.33 | 2.00 | 20.3 |
| PROMISE SHOT AWAY | rule | - | 1.00 | 5.2 |
| MARCH OF THE TABLE | rule | 0.33 | - | 11.4 |
| NO REASON | gate | - | 0.33 | 4.4 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 39.3 |
| RULE SWITCHED OFF | gate | 0.33 | - | 63.0 |

### Plans: gs3-83c8646-p5

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.0 | 50% | 335 | 112 | 33% |
| Mine | join | 2.3 | 71% | 23 | 0 | 0% |
| Mine | move | 29.0 | 99% | 1912 | 0 | 0% |
| Mine | shoot | 17.0 | 69% | 928 | 2023 | 218% |
| Opponent | charge | 1.3 | 50% | 204 | 33 | 16% |
| Opponent | move | 34.3 | 93% | 2114 | 0 | 0% |
| Opponent | shoot | 3.3 | 80% | 191 | 137 | 72% |
| Opponent | support | 1.0 | 100% | 51 | 0 | 0% |

### Battle groups: gs3-83c8646-p5

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 1.0 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p5

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | Character | 12 | 18 (12) | 18 | 0 | 25 | 50% | 3.3 | 31 (7) | 0 (2) | 10 (3) | 29 (7) | 0 (5) |
| Mine | Clean-up | 1 | 82 (1) | 0 | 82 | 100 | 0% | 6.0 | - | 82 (1) | - | 82 (1) | - |
| Mine | Fast Hammer | 8 | 71 (8) | 18 | 53 | 19 | 25% | 4.2 | 87 (4) | 17 (3) | 126 (1) | 117 (4) | 20 (4) |
| Mine | Hammer | 2 | 42 (2) | 23 | 19 | 42 | 0% | 1.5 | - | 0 (1) | 72 (1) | 42 (2) | - |
| Mine | Shooter | 5 | 140 (5) | 19 | 121 | 0 | 0% | 2.0 | 78 (2) | 262 (1) | 71 (2) | 173 (3) | 71 (2) |
| Mine | War machine | 10 | 86 (10) | 86 | 0 | 20 | 0% | 1.4 | 76 (8) | 126 (2) | - | 0 (1) | 96 (9) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | - | - | - | - | - |
| Opponent | Chaff | 4 | 35 (4) | 0 | 35 | 11 | 50% | 1.0 | 0 (3) | 91 (1) | - | 35 (4) | - |
| Opponent | Character | 9 | 16 (9) | 16 | 0 | 34 | 44% | 1.4 | 0 (1) | 34 (5) | 0 (3) | 27 (5) | 0 (4) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 28 | 100% | - | 0 (2) | 0 (1) | - | 0 (1) | 0 (2) |
| Opponent | Fast Hammer | 5 | 83 (5) | 83 | 0 | 87 | 40% | 2.7 | 44 (1) | 197 (2) | 0 (2) | 17 (3) | 197 (2) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 0 | 0% | 5.0 | 0 (3) | - | - | - | 0 (3) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 30 | 67% | 1.0 | - | 0 (1) | 0 (2) | - | 0 (3) |
| Opponent | Holder | 3 | 164 (3) | 23 | 141 | 0 | 0% | 2.0 | 300 (1) | 102 (2) | - | 262 (2) | 0 (1) |
| Opponent | Shooter | 7 | 145 (7) | 22 | 123 | 8 | 0% | 1.1 | 96 (2) | 129 (3) | 211 (2) | 140 (3) | 149 (4) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | - | 0 (1) | - | 0 (1) |

### Charged fights: gs3-83c8646-p5

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 3 | 494 | 89 | 2.0 | 1.0 | 45 | 82 | -37 | 1 of 6 | 3 of 6 | - | -37 |
| Opponent | Lizardmen | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 1 | 45 | 525 | 3.0 | 1.0 | 175 | 65 | +110 | 2 of 3 | 2 of 3 | - | +110 |
| Opponent | Wood Elf Realms | 1 | 0 | 299 | 3.0 | 1.0 | 100 | 0 | +100 | 2 of 3 | 3 of 3 | - | +100 |
| **Opponent** | all armies | 3 | 15 | 275 | 2.0 | 1.0 | 137 | 32 | +105 | 4 of 6 | 5 of 6 | - | +105 |

### Effective charges: gs3-83c8646-p5

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 6 | 0 | 0 | 0 | 1 (net +185) | 1 (net -380) | 3 (net -9) | 1 | 0% (0 of 5) |
| Opponent | Tomb Kings of Khemri | 3 | 1 (net -110) | 0 | 0 | 0 | 1 (net +175) | 1 (net +265) | 0 | 0% (0 of 3) |

### Charged fights, damage counted: gs3-83c8646-p5

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 1 | 181 | 185 | +185 | 185 | 0 | +185 | +102.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 163 | 114 | -9 | 28 | 68 | -40 | -24.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 380 | 104 | -380 | 73 | 380 | -307 | -80.9 |
| Mine | No odds | 1 | 181 | 135 | +0 | 13 | 98 | -85 | -46.9 |
| Mine | All fights | 6 | 205 | 128 | -37 | 59 | 113 | -55 | -26.6 |
| Opponent | Long shot (under 50%) | 1 | 195 | 371 | -110 | 118 | 195 | -77 | -39.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 431 | 265 | +265 | 449 | 206 | +244 | +56.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 431 | 45 | +175 | 236 | 0 | +236 | +54.9 |
| Opponent | No odds | 3 | 104 | 163 | +100 | 100 | 28 | +72 | +68.9 |
| Opponent | All fights | 6 | 228 | 195 | +105 | 184 | 81 | +103 | +45.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p5 | move | 23 | 2 (9%) | 2 (9%) | 2 (9%) | 19 (83%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Horn of the Wild Hunt | Opponent | L0733 |
| Ring of Doom | Opponent | L0733 |
| Twice-Blessed Armour | Mine | L0717, L0733 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |

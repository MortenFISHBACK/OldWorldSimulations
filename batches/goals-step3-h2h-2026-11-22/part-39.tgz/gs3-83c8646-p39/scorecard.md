# Doctrine scorecard: gs3-83c8646-p39

### Scorecard: gs3-83c8646-p39

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0417 | 3 | 1 | Mine | no | 3 | 3 | 4 | 2 | 0 | 0 | 0 | 124 |
| L0417 | 3 | 1 | Opponent | yes | 4 | 1 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Mine | - | - | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 5 | 0 | 4 | 0 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 453 |
| L0520 | 4 | 1 | Opponent | no | 8 | - | 0 | 7 | 2 | 0 | 0 | 550 |
| **Average** | | | Mine | 0% | 1.5 | 3.0 | 2.0 | 1.7 | 0.0 | 0.0 | 0.0 | 192.3 |
| **Average** | | | Opponent | 50% | 6.0 | 3.0 | 1.0 | 3.7 | 0.7 | 0.0 | 0.0 | 183.3 |

### KPIs: gs3-83c8646-p39

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 29% (4 of 14) | 0% (0 of 16) | 13% (4 of 30) |
| Winner chose to follow up after the loser gave ground |  | 100% (3 of 3); on the table 100% | - | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (5 of 5); on the table 100% | - | 100% (5 of 5); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 42% (5 of 12) | 58% (7 of 12) | 50% (12 of 24) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 50% (5 of 10) | 58% (7 of 12) | 55% (12 of 22) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 57% (4 of 7) | 57% (4 of 7) |
| Points that never fought | lower | 59% (3528 of 5998) | 63% (3791 of 5997) | 61% (7319 of 11995) |
|   infantry points that never fought | lower | 72% (1026 of 1424) | 83% (1387 of 1662) | 78% (2413 of 3086) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% (14 of 23) | 77% (17 of 22) | 69% (31 of 45) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 100% (2 of 2); 0.7 uses a game | 100% (2 of 2); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 55% (2806 of 5120) | 75% (3728 of 4957) | 65% (6534 of 10077) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (43%) | 1.3 (80%) | 2.3 (58%) |
| MARCHED: its unit marched | 0.7 (29%) | 0.3 (20%) | 1.0 (25%) |
| IN COMBAT: engaged in combat | 0.7 (29%) | 0.0 (0%) | 0.7 (17%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.7 | 0.3 | 4.0 | 1.3 | 0.0 |
| not cast | 1.3 | 1.7 | 4.0 | 4.7 | 12.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.0 (60%) | 2.3 (58%) | 1.3 (29%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.0 (25%) | 2.0 (43%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (40%) | 0.7 (17%) | 0.7 (14%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (14%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.3 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.0 (100%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.3 a game | 0.0 a game | 0.2 a game |
| stood (cast and not dispelled) | 100% (1 of 1) | - | 100% (1 of 1) |
| the unit moved after it | 0% (0 of 1) | - | 0% (0 of 1) |
| it charged on its next turn | 0% (0 of 1) | - | 0% (0 of 1) |
| the enemy charged it first | 0% (0 of 1) | - | 0% (0 of 1) |
| it fought by the end of its next turn | 0% (0 of 1) | - | 0% (0 of 1) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 1) | - | 0% (0 of 1) |
| none of these (no charge, no fight, no charge escaped) | 100% (1 of 1) | - | 100% (1 of 1) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 76% (75 of 99) | 73% (48 of 66) | 75% (123 of 165) |
|   cavalry | 44% (4 of 9) | 83% (10 of 12) | 67% (14 of 21) |
|   character | 72% (18 of 25) | 67% (6 of 9) | 71% (24 of 34) |
|   chariot | 65% (15 of 23) | - | 65% (15 of 23) |
|   infantry | 83% (10 of 12) | 86% (31 of 36) | 85% (41 of 48) |
|   monster | - | 11% (1 of 9) | 11% (1 of 9) |
|   war machine | 93% (28 of 30) | - | 93% (28 of 30) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (25%) | 0.0 (0%) | 2.0 (14%) |
| CHARGED: it charged | 0.3 (4%) | 0.3 (6%) | 0.7 (5%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.3 (6%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.7 (11%) | 0.7 (5%) |
| NO TARGET IN RANGE | 4.7 (58%) | 4.0 (67%) | 8.7 (62%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (4%) | 0.0 (0%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (4%) | 0.7 (11%) | 1.0 (7%) |
| OTHER BAR | 0.3 (4%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 8.3 | 0.7 | 92% | 2.9 pts | 24 pts |
| character | 8.0 | 6.0 | 58% | 6.6 pts | 53 pts |
| chariot | 5.0 | 4.3 | 53% | 14.5 pts | 72 pts |
| infantry | 24.0 | 8.7 | 75% | 10.9 pts | 261 pts |
| monster | 0.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 9.3 | 12.3 | 50% | 49.5 pts | 462 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.3 | 2.0 | 2.2 |
| Charges that made contact a game | 2.3 | 1.0 | 1.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 1.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) | 0.50 declared, 0.50 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.23 declared, 0.23 contact (22 units) | 0.19 declared, 0.10 contact (31 units) | 0.21 declared, 0.15 contact (53 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 100% (4 of 4) | - | - | 100% (4 of 4) |
| Character in a unit | 67% (2 of 3) | 100% (1 of 1) | - | 75% (3 of 4) |
| Character on its own | 100% (3 of 3) | 50% (1 of 2) | 71% (5 of 7) | 75% (9 of 12) |
| Chariot | - | 50% (2 of 4) | - | 50% (2 of 4) |
| Infantry | 58% (7 of 12) | 0% (0 of 2) | - | 50% (7 of 14) |
| Monster | 100% (3 of 3) | 50% (1 of 2) | - | 80% (4 of 5) |
| Monstrous | 100% (2 of 2) | - | - | 100% (2 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 2 | 100% (5 of 5); on the table 100% | 42% (5 of 12) | 43% | 62% (10 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Dwarfen Mountain Holds | 1 | - | - | 91% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Lizardmen | 1 | - | 83% (5 of 6) | 55% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Skaven | 1 | - | 33% (2 of 6) | 89% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Wood Elf Realms | 1 | - | - | 45% | 88% (7 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p39, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 67% (2) | 100% (4) | 86% (6) |
| ...free all their last turn and able to turn (per game) | 0.33 | 1.33 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 1.00 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p39

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.0 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 50% (4 of 8) | 67% (2 of 3) |
| Strategy | Shoot objectives carried out (shot that target) | 24% (10 of 42) | 33% (2 of 6) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | - |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 5) | 0% (0 of 1) |
| Strategy | Lone characters that fought | 67% (4 of 6) | 43% (3 of 7) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.7 | 3.7 |
| Movement | Points that never moved of their own | 192.3 | 183.3 |
| Movement | Fights charged into per game | 2.3 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 6 | 1 of 2, net -109 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 6, net +0 | 0 of 2 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 6 | 0 of 2 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 of 6, net +90 | 1 of 2, net +422 |
| Shooting | Shots by shooting units (incl. breath weapons) | 16.0 | 18.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 25% (12 of 48) | 69% (37 of 54) |
| Shooting | Points destroyed by shooting units | 109.7 | 0.0 |
| Shooting | War machine shots | 9.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 71% (20 of 28) | - |
| Shooting | Points destroyed by war machines | 91.7 | 0.0 |
| Magic | Magic missiles cast | 0.7 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 50% (1 of 2) | 0% (0 of 4) |
| Magic | Wounds caused by magic missiles | 1.3 | 0.3 |
| Magic | Points destroyed by magic (all spells) | 47.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.0 / 0.0 / 0.3 | 2.0 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 191.3 | 201.3 |
| Combat | Points run down | 53.3 | 0.0 |
| Combat | Net points per charged fight, damage counted | +68 | +166 |
| Combat | Net per 100 charger points, damage counted | +19.9 | +66.6 |
| Combat | First round won (charged fights) | 100% | 67% |
| Combat | Net points per charged fight | +89 | +104 |
| Combat | Net points per supported fight / lone fight | - / +89 | - / +104 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 7 | 3 of 3 |
| Game | Points lost | 238.7 | 627.0 |
| Game | VP from objectives | 483.3 | 693.3 |
| Game | Lone holders (player turns) | 1.5 | 6.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +138 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 866
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p39

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 16.0 | +278.9 | 0.0 | 396.7 | 35.3 | +554.1 | 0.0 | 195.7 |
| ARTILLERY RE-ROLL WEIGHED | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 0.3 | +0.4 | 0.0 | 0.0 |
| BEST PRIZE | 0.3 | -7.1 | 58.3 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 140.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 9.0 | +155.4 | 558.3 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | - | - | - | - | 1.7 | +20.2 | 86.7 | 0.0 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.0 | +20.4 | 0.0 | 43.3 | 0.7 | +17.4 | 0.0 | 18.0 |
| CHAFF PASSED | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +1.8 | 0.0 | 0.0 | 0.3 | +24.4 | 0.0 | 38.3 |
| CHARACTER GUNS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 18.3 | -522.0 | 0.0 | 284.7 | 21.0 | -614.4 | 0.0 | 246.7 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 150.0 | 0.0 | 0.3 | +0.0 | 103.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 6.7 | +0.0 | 0.0 | 0.0 | 15.7 | +0.0 | 0.0 | 200.7 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.3 | +4.1 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 9.3 | -394.2 | 0.0 | 103.3 | 6.3 | -296.5 | 0.0 | 36.3 |
| DENIED BY THE FIGHT | 0.3 | -0.2 | 53.3 | 0.0 | 0.3 | -1.7 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 8.7 | -48.8 | 0.0 | 0.0 | 9.0 | -54.3 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -4.6 | 0.0 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | 1.0 | +25.5 | 53.3 | 37.3 | 1.0 | +14.9 | 103.3 | 0.0 |
| EXACT ROUND | 1.0 | -1.9 | 36.3 | 0.0 | 0.7 | -0.6 | 103.3 | 0.0 |
| FALL BACK GOOD ORDER | 2.3 | +15.0 | 186.3 | 0.0 | 0.7 | +0.0 | 103.3 | 0.0 |
| FALLS SHORT | - | - | - | - | 21.7 | +166.0 | 0.0 | 140.0 |
| FIGHT TO THE END | 0.3 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 101.0 | +6407.7 | 1732.0 | 954.7 | 95.3 | +4638.8 | 190.0 | 821.7 |
| FLANK NOT WEIGHED | 9.7 | +0.0 | 0.0 | 185.7 | 6.3 | +0.0 | 0.0 | 153.0 |
| FOLLOW UP WEIGHED | 0.7 | +102.3 | 0.0 | 0.0 | - | - | - | - |
| FOOT FIRST | - | - | - | - | 20.7 | +0.0 | 0.0 | 107.7 |
| FOUR ROUNDS | 2.7 | +160.2 | 186.3 | 0.0 | 1.0 | +84.7 | 103.3 | 0.0 |
| FREED FROM HIS FIGHT | 4.3 | +0.0 | 0.0 | 112.0 | 6.0 | +0.0 | 0.0 | 189.3 |
| FRIEND SHOOTS FIRST | - | - | - | - | 1.3 | -0.9 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.3 | +5.2 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | - | - | - | - | 0.3 | -0.3 | 0.0 | 0.0 |
| GOAL ROUTE | - | - | - | - | 0.3 | +13.7 | 0.0 | 0.0 |
| GOAL WALK | 12.0 | +1056.5 | 0.0 | 0.0 | 5.7 | +302.8 | 0.0 | 0.0 |
| GROUND FLIERS | - | - | - | - | 0.3 | +11.1 | 0.0 | 0.0 |
| GUN FIGURES | 4.0 | +3.7 | 159.0 | 206.7 | - | - | - | - |
| GUN MASK | 2.0 | +43.5 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 4.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 3.0 | +0.0 | 0.0 | 37.3 | 7.0 | +0.0 | 0.0 | 306.0 |
| HIS CHARGE BY HIS RUN | 14.3 | +0.0 | 0.0 | 284.7 | 12.0 | +0.0 | 0.0 | 176.7 |
| HIS CHARGE DENIED | 0.3 | +4.1 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 1.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 163.7 |
| HIS LEGAL MOVES | 7.7 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 5.7 | -36.7 | 0.0 | 206.7 | 7.0 | -132.2 | 0.0 | 0.0 |
| HIS ONE QUARTER | 6.7 | +0.0 | 0.0 | 78.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 10.3 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 5.3 | +0.0 | 0.0 | 242.7 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.7 | +0.0 | 0.0 | 164.7 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 44.3 | +1134.5 | 0.0 | 752.7 | 60.0 | +2347.7 | 0.0 | 715.0 |
| HIS SHOTS BY HIS RUN | 43.0 | +454.3 | 0.0 | 500.0 | 46.0 | +1042.4 | 0.0 | 555.0 |
| HIS TURN DENIED | 0.7 | +28.8 | 53.3 | 0.0 | 0.3 | +10.7 | 0.0 | 0.0 |
| HOLD ODDS | 10.3 | +0.0 | 0.0 | 0.0 | 15.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 7.7 | +887.5 | 0.0 | 0.0 | 10.0 | +785.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.7 | -81.7 | 186.3 | 0.0 | 1.0 | -23.3 | 103.3 | 0.0 |
| IDLE COST | - | - | - | - | 24.7 | -389.3 | 0.0 | 276.7 |
| JOINT CHARGE NOW | 0.7 | +22.6 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.0 | +43.0 | 0.0 | 0.0 | 1.0 | +36.6 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 1.7 | +0.0 | 38.3 | 0.0 | 9.7 | +0.0 | 74.7 | 53.3 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.3 | +31.7 | 0.0 | 0.0 |
| LONG SHOT | 0.7 | +12.3 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 1.7 | +4.3 | 53.3 | 0.0 | 0.7 | +0.0 | 103.3 | 0.0 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.7 | -50.1 | 0.0 | 18.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.3 | +0.4 | 0.0 | 0.0 |
| MANOEUVRE | 1.3 | -4.1 | 0.0 | 0.0 | 1.0 | +0.3 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +12.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.3 | +13.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH ODDS | 0.3 | +16.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +0.8 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.7 | -11.5 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 0.3 | +4.6 | 0.0 | 0.0 | 2.0 | +8.6 | 0.0 | 0.0 |
| MEETS IN TIME | 5.0 | +152.8 | 0.0 | 0.0 | 4.7 | +143.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.3 | +51.5 | 0.0 | 0.0 | 2.7 | +13.4 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 2.7 | +56.8 | 0.0 | 0.0 | 3.0 | +12.4 | 0.0 | 0.0 |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.7 | +21.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 1.0 | -69.7 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 4.3 | +264.3 | 0.0 | 0.0 | 5.3 | +278.8 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.0 | +252.8 | 0.0 | 37.3 | 3.3 | +108.8 | 0.0 | 53.3 |
| NEXT CHARGE BY LIST | 1.7 | +135.8 | 0.0 | 0.0 | 4.7 | +276.1 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.7 | -66.7 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.7 | -138.7 | 186.3 | 0.0 | 0.7 | -84.4 | 103.3 | 0.0 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 4.7 | -64.7 | 0.0 | 0.0 | 4.7 | -247.4 | 0.0 | 9.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.0 | -50.4 | 0.0 | 37.3 | 6.0 | -133.5 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 3.0 | -14.0 | 0.0 | 0.0 | 3.7 | -25.7 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.7 | -43.6 | 0.0 | 0.0 |
| ONE ROUTE | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +14.6 | 0.0 | 0.0 | 0.3 | +1.9 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.7 | +19.5 | 0.0 | 0.0 | - | - | - | - |
| PERIAPT WORTH | - | - | - | - | 0.3 | +33.1 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -3.3 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 45.3 | +694.1 | 693.0 | 477.3 | 45.0 | +132.2 | 59.0 | 937.7 |
| PROMISE BY ITS OWN SUM | 8.7 | -166.7 | 0.0 | 0.0 | 8.0 | -268.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.3 | -0.3 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 1.0 | -0.4 | 0.0 | 0.0 |
| QUARTER ODDS | 20.0 | +1734.2 | 980.0 | 78.0 | 15.3 | +2690.1 | 0.0 | 70.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 2.3 | +42.3 | 0.0 | 140.0 |
| REAL GROUND | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.7 | +22.8 | 0.0 | 43.3 | 1.3 | +44.1 | 0.0 | 18.0 |
| REDIRECT FOR A FRIEND IN REACH | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 18.0 |
| REFORMS TO MEET IT | 0.3 | -1.1 | 0.0 | 0.0 | 2.0 | -27.1 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.7 | +5.7 | 0.0 | 0.0 | 0.3 | +9.2 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.3 | +1.8 | 0.0 | 0.0 |
| RISK BY ARC | 2.3 | -23.4 | 133.0 | 0.0 | 0.7 | -13.6 | 103.3 | 0.0 |
| RISK ON THE WAY | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 1.0 | -8.1 | 91.7 | 0.0 | 0.3 | -9.9 | 0.0 | 0.0 |
| RUN DOWN | 1.7 | -23.3 | 53.3 | 0.0 | 0.3 | -3.8 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -14.3 | 0.0 | 18.0 |
| SEARCH SPOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SET CREDITED ONCE | 1.3 | -33.5 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 1.3 | +33.5 | 0.0 | 0.0 | 2.3 | +34.4 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.3 | +0.4 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | 0.3 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 14.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 9.0 |
| SHOOTS FROM THE BEST SPOT | 2.3 | +82.4 | 0.0 | 0.0 | 1.3 | +11.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -16.8 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 26.0 | -473.4 | 0.0 | 446.0 | 32.3 | -27.3 | 0.0 | 642.3 |
| SHOTS AFTER THE MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 17.7 | +909.7 | 0.0 | 281.3 | 12.3 | +207.2 | 0.0 | 53.3 |
| SPELL WORTH | 0.7 | +5.4 | 0.0 | 0.0 | 2.0 | +28.4 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 4.7 | +0.0 | 0.0 | 142.3 | 9.3 | +0.0 | 0.0 | 123.3 |
| STAND AND SHOOT | 1.3 | -12.6 | 58.3 | 0.0 | 0.7 | -5.6 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 8.0 | +0.0 | 86.7 | 0.0 |
| STANDS STILL | 55.0 | +0.0 | 1545.7 | 408.7 | 22.3 | +0.0 | 86.7 | 156.7 |
| STAY WORTH | 36.0 | +939.9 | 1125.7 | 178.0 | 11.7 | +62.9 | 86.7 | 53.3 |
| STUPIDITY NEXT TURN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 4.0 | +360.6 | 0.0 | 74.7 | 0.7 | +3.6 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 4.0 | +360.6 | 0.0 | 74.7 | 0.7 | +3.6 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 9.0 |
| THE ROW IN ITS ORDER | 3.0 | +0.0 | 0.0 | 103.3 | 5.3 | +0.0 | 0.0 | 58.3 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 116.3 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 49.0 | +0.0 | 0.0 | 477.3 | 44.3 | +0.0 | 0.0 | 339.0 |
| TIED UP BY THE SUM | 1.3 | +219.2 | 150.0 | 0.0 | 0.3 | +39.7 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 55.3 | +625.3 | 0.0 | 553.7 | - | - | - | - |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -25.5 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.3 | -1.3 | 0.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.7 | +33.8 | 0.0 | 0.0 | 0.3 | +8.7 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 1.3 | -22.0 | 0.0 | 78.0 | 1.3 | -59.9 | 0.0 | 70.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 3.7 | +61.7 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p39

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 154 | 154 | 120 | 40.00 | +1452 | +12.1 |
| HIS SHOT LIST | 313 | 305 | 78 | 26.00 | +907 | +11.6 |
| HIS SHOTS BY HIS RUN | 267 | 260 | 59 | 19.67 | +362 | +6.1 |
| HOLDER ASSIGNMENT | 53 | 53 | 48 | 16.00 | +3238 | +67.5 |
| SHOT RISK POINTS | 175 | 171 | 39 | 13.00 | +935 | +24.0 |
| LEGAL CHARGES ONLY | 34 | 34 | 34 | 11.33 | +0 | +0.0 |
| TIME ON OUR SIDE | 166 | 139 | 29 | 9.67 | +141 | +4.9 |
| DEPLOY BY FIGURES | 53 | 53 | 28 | 9.33 | +385 | +13.7 |
| OFF BEST | 28 | 28 | 28 | 9.33 | -936 | -33.4 |
| IDLE COST | 74 | 59 | 21 | 7.00 | +209 | +10.0 |
| GOAL WALK | 53 | 53 | 18 | 6.00 | +803 | +44.6 |
| THE TABLE AGAIN | 36 | 36 | 18 | 6.00 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 50 | 50 | 17 | 5.67 | -1304 | -76.7 |
| HARD STAY DROPPED | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| MOVE ORDER | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 29 | 27 | 16 | 5.33 | +612 | +38.2 |
| COVER ONCE | 47 | 32 | 13 | 4.33 | +278 | +21.4 |
| MEETS IN TIME | 29 | 29 | 13 | 4.33 | +307 | +23.6 |
| FIVE ACTION | 589 | 577 | 12 | 4.00 | +252 | +21.0 |
| QUARTER ODDS | 106 | 106 | 11 | 3.67 | +1184 | +107.6 |
| NEXT CHARGE BY LIST | 19 | 19 | 10 | 3.33 | +526 | +52.6 |
| SHOTS IN THE MOVE | 90 | 62 | 10 | 3.33 | +274 | +27.4 |
| FOUR ROUNDS | 11 | 11 | 9 | 3.00 | +348 | +38.7 |
| REDIRECT FOR A FRIEND IN REACH | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| CANNON PLANNED TARGET | 27 | 27 | 7 | 2.33 | -225 | -32.1 |
| CHARGE LOSSES | 118 | 116 | 7 | 2.33 | +372 | +53.1 |
| SET UP BY THE SET | 11 | 11 | 7 | 2.33 | +61 | +8.7 |
| SHOOTS FROM THE BEST SPOT | 11 | 11 | 7 | 2.33 | +56 | +8.0 |
| SUPPORT ADDS | 14 | 14 | 7 | 2.33 | +210 | +30.0 |
| SUPPORT WORKED OUT | 14 | 14 | 7 | 2.33 | +210 | +30.0 |
| ARTILLERY RE-ROLL WEIGHED | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| FALLS SHORT | 65 | 53 | 6 | 2.00 | +12 | +2.0 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +239 | +39.8 |
| EVASIVE BY THE ODDS | 6 | 6 | 5 | 1.67 | +77 | +15.3 |
| STAY WORTH | 143 | 122 | 5 | 1.67 | +12 | +2.5 |
| TIED UP BY THE SUM | 5 | 5 | 5 | 1.67 | +124 | +24.7 |
| ADVANCE LANE KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CANNON SIGHT KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 7 | 7 | 4 | 1.33 | +127 | +31.7 |
| WOUNDS ON THE RANKS | 11 | 11 | 4 | 1.33 | +38 | +9.6 |
| MANOEUVRE | 7 | 7 | 3 | 1.00 | +3 | +1.1 |
| MAX FOR POSITIONING | 7 | 7 | 3 | 1.00 | +1 | +0.3 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +45 | +15.0 |
| RISK BY ARC | 9 | 9 | 3 | 1.00 | +44 | +14.6 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +8 | +2.7 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +55 | +18.4 |
| CHAFF IN THE MOVE | 5 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +79 | +39.4 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +307 | +153.6 |
| GUN MASK | 6 | 6 | 2 | 0.67 | +38 | +19.2 |
| HONEST WORTH | 11 | 11 | 2 | 0.67 | +22 | +10.9 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +68 | +33.9 |
| MISSILES IN THE MOVE | 15 | 10 | 2 | 0.67 | +2 | +1.0 |
| NEARER NOT NEEDED | 28 | 27 | 2 | 0.67 | +102 | +51.0 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -131 | -65.5 |
| OPENS UP | 2 | 2 | 2 | 0.67 | +30 | +15.0 |
| SHOTS AFTER THE MOVES | 16 | 16 | 2 | 0.67 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 25 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 8 | 8 | 2 | 0.67 | +112 | +56.0 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -21 | -21.4 |
| CAST JOB | 5 | 5 | 1 | 0.33 | +10 | +10.2 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -0 | -0.5 |
| CHARGE NOW FIRST | 6 | 6 | 1 | 0.33 | -9 | -8.8 |
| EXACT ROUND | 5 | 5 | 1 | 0.33 | +2 | +2.1 |
| FALL BACK GOOD ORDER | 9 | 9 | 1 | 0.33 | +9 | +9.2 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +16 | +15.6 |
| GOAL ROUTE | 1 | 1 | 1 | 0.33 | +41 | +41.0 |
| HIS TURN DENIED | 3 | 3 | 1 | 0.33 | +1 | +1.1 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +95 | +95.0 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +38 | +38.4 |
| MARCH ODDS | 1 | 1 | 1 | 0.33 | -34 | -33.8 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -2 | -2.3 |
| ONE FIGHT FORMULA | 27 | 14 | 1 | 0.33 | +1 | +0.8 |
| OVERRUNS AWAY | 2 | 2 | 1 | 0.33 | +26 | +25.6 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +99 | +99.4 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -10 | -10.0 |
| PROMISE KNOWS THE FIGHT | 1 | 1 | 1 | 0.33 | -1 | -1.0 |
| PROMISE READS THE TABLE | 3 | 3 | 1 | 0.33 | +16 | +16.2 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +5 | +5.4 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -77 | -76.6 |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CHARACTER GUNS | 2 | 2 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 67 | 67 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 1 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 48 | not checked | - | - | - | - |
| FOOT FIRST | 62 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 31 | 31 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 12 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 30 | 30 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 79 | 78 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 16 | 16 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 38 | 37 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 38 | 37 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 23 | 23 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 52 | 49 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 16 | 16 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 8 | 8 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 78 | 78 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 13 | 13 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 7 | 7 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH CHECK | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 9 | 9 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 17 | 11 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 2 | 1 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 3 | trace | - | - | - | - |
| NEXT OBJECTIVE NEARER | 2 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 10 | 10 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 20 | 15 | 0 | 0.00 | - | - |
| ONE ROUTE | 9 | 9 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 271 | trace | - | - | - | - |
| REAL GROUND | 9 | 9 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 9 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 7 | 6 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 2 | 2 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 7 | 7 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 6 | 6 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SEARCH SPOT | 1 | 1 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 53 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 8 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 42 | 37 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 6 | 6 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 24 | 19 | 0 | 0.00 | - | - |
| STANDS STILL | 232 | 223 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 1 | 1 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 25 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 1 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 14 | not checked | - | - | - | - |
| THE TABLE BINDS | 280 | not checked | - | - | - | - |
| WAR ENGINE JOBS | 3 | 3 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p39

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.67 | 4.00 | 31.9 |
| PROMISE BY ITS OWN SUM | rule | 3.67 | 2.00 | 76.7 |
| ARMY TABLE | rule | 1.33 | 4.00 | 38.2 |
| CANNON PLANNED TARGET | rule | 1.00 | - | 79.7 |
| NO REASON | gate | - | 0.67 | 52.9 |
| ONE PROMISE A TARGET | rule | - | 0.67 | 65.5 |
| BEST PRIZE | rule | 0.33 | - | 21.4 |
| CHARGE NOW FIRST | rule | 0.33 | - | 8.8 |
| HOLDER ASSIGNMENT | rule | - | 0.33 | 30.2 |
| MARCH ODDS | rule | 0.33 | - | 33.8 |
| MARCH OF THE TABLE | rule | - | 0.33 | 2.3 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 10.0 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.33 | 1.0 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 76.6 |

### Plans: gs3-83c8646-p39

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 57% | 226 | 183 | 81% |
| Mine | join | 0.7 | 100% | 23 | 0 | 0% |
| Mine | move | 30.7 | 96% | 1816 | 0 | 0% |
| Mine | shoot | 11.7 | 57% | 757 | 511 | 67% |
| Opponent | charge | 0.7 | 50% | 70 | 103 | 147% |
| Opponent | move | 41.7 | 92% | 1542 | 0 | 0% |
| Opponent | shoot | 2.0 | 33% | 122 | 29 | 24% |
| Opponent | support | 0.7 | 0% | 0 | 0 | - |

### Battle groups: gs3-83c8646-p39

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.7 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 1.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p39

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | - | 0 (1) | 0 (1) | - |
| Mine | Character | 11 | 38 (11) | 38 | 0 | 5 | 18% | 2.7 | 46 (5) | 20 (4) | 60 (2) | 39 (8) | 37 (3) |
| Mine | Clean-up | 3 | 0 (3) | 0 | 0 | 0 | 67% | 4.0 | 0 (3) | - | - | 0 (1) | 0 (2) |
| Mine | Fast Hammer | 1 | 0 (1) | 0 | 0 | 100 | 0% | 1.0 | - | - | 0 (1) | - | 0 (1) |
| Mine | Hammer | 10 | 34 (10) | 11 | 22 | 15 | 40% | 2.3 | 37 (3) | 32 (6) | 35 (1) | 40 (9) | 0 (1) |
| Mine | Holder | 2 | 144 (2) | 0 | 144 | 0 | 0% | 5.0 | - | 144 (2) | - | 288 (1) | 0 (1) |
| Mine | Shooter | 1 | 0 (1) | 0 | 0 | 100 | 0% | 1.0 | - | - | 0 (1) | 0 (1) | - |
| Mine | War machine | 5 | 58 (5) | 58 | 0 | 0 | 0% | 1.0 | 17 (4) | 221 (1) | - | - | 58 (5) |
| Opponent | Chaff | 2 | 0 (2) | 0 | 0 | 100 | 100% | - | 0 (1) | - | 0 (1) | 0 (2) | - |
| Opponent | Character | 7 | 16 (7) | 16 | 0 | 13 | 29% | 1.8 | 0 (3) | 0 (1) | 42 (2) | 0 (3) | 32 (3) |
| Opponent | Clean-up | 6 | 4 (6) | 0 | 4 | 14 | 50% | 4.3 | 7 (3) | 0 (3) | - | 7 (4) | 0 (2) |
| Opponent | Fragile | 5 | 0 (5) | 0 | 0 | 36 | 60% | 3.0 | 0 (1) | 0 (4) | - | 0 (2) | 0 (3) |
| Opponent | Hammer | 6 | 19 (6) | 19 | 0 | 81 | 50% | 3.0 | 0 (2) | 36 (3) | 0 (1) | 25 (5) | 0 (1) |
| Opponent | Holder | 3 | 90 (3) | 0 | 90 | 43 | 67% | 1.0 | - | 132 (2) | 0 (1) | 132 (2) | 0 (1) |
| Opponent | Shooter | 9 | 82 (9) | 0 | 82 | 39 | 33% | 1.3 | 78 (3) | 144 (4) | 0 (2) | 116 (4) | 67 (5) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |

### Charged fights: gs3-83c8646-p39

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 98 | 312 | 3.5 | 1.0 | 89 | 0 | +89 | 2 of 7 | 7 of 7 | - | +89 |
| Mine | Dwarfen Mountain Holds | 1 | 550 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 248 | 208 | 2.3 | 1.0 | 89 | 0 | +89 | 2 of 7 | 7 of 7 | - | +89 |
| Opponent | Lizardmen | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Wood Elf Realms | 1 | 0 | 422 | 2.0 | 1.0 | 211 | 54 | +156 | 2 of 2 | 1 of 2 | - | +156 |
| **Opponent** | all armies | 3 | 0 | 141 | 1.0 | 1.0 | 141 | 36 | +104 | 3 of 3 | 2 of 3 | - | +104 |

### Effective charges: gs3-83c8646-p39

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 7 | 0 | 0 | 1 (net +0) | 0 | 0 | 5 (net +90) | 1 | 17% (1 of 6) |
| Opponent | Wood Elf Realms | 2 | 1 (net -109) | 0 | 0 | 0 | 0 | 1 (net +422) | 0 | 0% (0 of 2) |

### Charged fights, damage counted: gs3-83c8646-p39

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 339 | 405 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 318 | 133 | +90 | 103 | 42 | +61 | +19.1 |
| Mine | No odds | 1 | 480 | 175 | +175 | 175 | 0 | +175 | +36.5 |
| Mine | All fights | 7 | 344 | 178 | +89 | 98 | 30 | +68 | +19.9 |
| Opponent | Long shot (under 50%) | 1 | 109 | 310 | -109 | 0 | 164 | -164 | -150.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 500 | 310 | +422 | 480 | 56 | +424 | +84.9 |
| Opponent | No odds | 1 | 141 | 339 | +0 | 285 | 47 | +238 | +169.0 |
| Opponent | All fights | 3 | 250 | 320 | +104 | 255 | 89 | +166 | +66.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p39 | move | 18 | 2 (11%) | 2 (11%) | 0 (0%) | 16 (89%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0434 |
| Periapt of Soul Exchange | Opponent | L0520 |

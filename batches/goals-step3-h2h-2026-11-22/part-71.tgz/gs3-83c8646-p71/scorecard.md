# Doctrine scorecard: gs3-83c8646-p71

### Scorecard: gs3-83c8646-p71

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2131 | 1 | 1 | Mine | yes | 0 | 6 | 1 | 1 | 0 | 0 | 0 | 500 |
| L2131 | 1 | 1 | Opponent | no | 0 | 4 | 2 | 1 | 0 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L2235 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L2429 | 5 | 1 | Mine | yes | - | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 1 | 4 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 100% | 0.0 | 6.0 | 0.5 | 2.5 | 0.0 | 0.0 | 0.0 | 250.0 |
| **Average** | | | Opponent | 50% | 0.0 | 3.5 | 1.5 | 2.5 | 0.0 | 0.0 | 0.0 | 85.0 |

### KPIs: gs3-83c8646-p71

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 11) | 0% (0 of 12) | 0% (0 of 23) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | 100% (2 of 2); on the table 100% | 100% (4 of 4); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 100% (2 of 2); on the table 100% | 100% (2 of 2); on the table 100% | 100% (4 of 4); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 33% (4 of 12) | 0% (0 of 2) | 29% (4 of 14) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 33% (4 of 12) | - | 33% (4 of 12) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 80% (8 of 10) | 57% (8 of 14) | 67% (16 of 24) |
| Points that never fought | lower | 51% (2036 of 3997) | 58% (2335 of 3999) | 55% (4371 of 7996) |
|   infantry points that never fought | lower | 48% (607 of 1268) | 100% (681 of 681) | 66% (1288 of 1949) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 75% (12 of 16) | 58% (11 of 19) | 66% (23 of 35) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.3 uses a game | 100% (2 of 2); 1.7 uses a game | 100% (3 of 3); 1.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 75% (2590 of 3464) | 62% (2410 of 3884) | 68% (5000 of 7348) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (50%) | - | 1.3 (50%) |
| MARCHED: its unit marched | 1.0 (38%) | - | 1.0 (38%) |
| CHARGED: its unit charged | 0.3 (12%) | - | 0.3 (12%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 1.3 | 0.3 | 1.3 | 1.7 |
| not cast | 2.7 | 4.0 | 0.3 | 2.7 | 19.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 4.0 (100%) | 0.0 (0%) | 1.3 (50%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (38%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (12%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (11%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.7 (100%) | 0.0 (0%) | 0.3 (100%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.3 (86%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 0.3 a game | 0.2 a game |
| stood (cast and not dispelled) | - | 0% (0 of 1) | 0% (0 of 1) |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 80% (12 of 15) | 22% (2 of 9) | 58% (14 of 24) |
|   cavalry | - | 50% (2 of 4) | 50% (2 of 4) |
|   character | - | 0% (0 of 5) | 0% (0 of 5) |
|   chariot | 80% (4 of 5) | - | 80% (4 of 5) |
|   infantry | 80% (8 of 10) | - | 80% (8 of 10) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.3 (33%) | 0.3 (14%) | 0.7 (20%) |
| CHARGED: it charged | 0.0 (0%) | 0.3 (14%) | 0.3 (10%) |
| IN COMBAT: it fought this turn or the last | 0.3 (33%) | 0.0 (0%) | 0.3 (10%) |
| NO TARGET IN RANGE | 0.3 (33%) | 1.0 (43%) | 1.3 (40%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (14%) | 0.3 (10%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 0.3 (14%) | 0.3 (10%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 0.7 | 0.3 | 50% | 2.6 pts | 2 pts |
| chariot | 1.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 2.7 | 0.7 | 75% | 7.1 pts | 19 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.7 | 2.7 | 1.7 |
| Charges that made contact a game | 0.3 | 2.0 | 1.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.00 contact (2 units) | - | 0.50 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.04 declared, 0.04 contact (27 units) | 0.32 declared, 0.24 contact (25 units) | 0.17 declared, 0.13 contact (52 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 33% (1 of 3) | 100% (4 of 4) | - | 71% (5 of 7) |
| Character in a unit | 100% (1 of 1) | 100% (1 of 1) | 100% (1 of 1) | 100% (3 of 3) |
| Character on its own | 67% (4 of 6) | - | 50% (2 of 4) | 60% (6 of 10) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 40% (2 of 5) | 100% (4 of 4) | - | 67% (6 of 9) |
| Monster | 33% (1 of 3) | 0% (0 of 1) | - | 25% (1 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Skaven | 1 | 100% (1 of 1); on the table 100% | 33% (2 of 6) | 19% | 56% (5 of 9) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 1 | 100% (1 of 1); on the table 100% | 33% (2 of 6) | 83% | 100% (7 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | 100% (2 of 2); on the table 100% | - | 58% | 58% (11 of 19) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p71, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 25% (1) | 0% (0) | 20% (1) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.00 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.00 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.67 | 1.00 |

### Quality by phase: gs3-83c8646-p71

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 50% (1 of 2) | 71% (5 of 7) |
| Strategy | Shoot objectives carried out (shot that target) | 60% (3 of 5) | 0% (0 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 1) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 2) | 0% (0 of 1) |
| Strategy | Lone characters that fought | 80% (4 of 5) | 50% (3 of 6) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.5 | 2.5 |
| Movement | Points that never moved of their own | 250.0 | 85.0 |
| Movement | Fights charged into per game | 0.5 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 1, net +0 | 1 of 3, net +92 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 1 | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 1 | 1 of 3, net +60 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 1 | 0 of 3 |
| Shooting | Shots by shooting units (incl. breath weapons) | 4.0 | 1.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 12) | 0% (0 of 3) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.3 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 100% (1 of 1) | - |
| Magic | Wounds caused by magic missiles | - | 1.3 |
| Magic | Wounds caused by other spells | 1.0 | 0.3 |
| Magic | Points destroyed by magic (all spells) | 56.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 3.3 / 0.3 / 1.3 / 0.0 | 0.0 / 0.7 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 65.0 | 116.7 |
| Combat | Points run down | 0.0 | 37.3 |
| Combat | Net points per charged fight, damage counted | +67 | +106 |
| Combat | Net per 100 charger points, damage counted | +28.6 | +48.8 |
| Combat | First round won (charged fights) | 0% | 100% |
| Combat | Net points per charged fight | +0 | +102 |
| Combat | Net points per supported fight / lone fight | - / +0 | - / +102 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 1 | 0 of 4 |
| Game | Points lost | 566.0 | 182.5 |
| Game | VP from objectives | 565.0 | 630.0 |
| Game | Lone holders (player turns) | 0.0 | 0.0 |

- Mine won / drew / lost: 0 / 1 / 1 of 2 ended games (of 3); mean margin (Mine - Opponent) -386 VP
- The side that went first won 1 of 1 games with a winner
- Points traded per game (both sides' losses): 748
- Games not ended: 1 (L2235-1); findings 1, warnings 0

### Opponent rules: gs3-83c8646-p71

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 27.3 | -169.2 | 0.0 | 140.0 | 24.0 | +583.8 | 0.0 | 56.7 |
| BACKUP TARGETS | - | - | - | - | 0.3 | +1.7 | 0.0 | 0.0 |
| CAST JOB | 0.7 | +2.1 | 0.0 | 0.0 | 1.3 | +10.9 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.0 | +41.1 | 0.0 | 40.0 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 0.3 | -2.2 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -1.0 | 37.3 | 0.0 |
| CHARACTER GUNS | 3.3 | +0.0 | 0.0 | 148.0 | - | - | - | - |
| CHARGE LOSSES | 9.0 | -724.2 | 0.0 | 239.7 | 16.7 | -748.1 | 0.0 | 56.7 |
| CHARGE NOW FIRST | - | - | - | - | 1.7 | +0.0 | 90.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 10.0 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 48.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 0.3 | +27.6 | 0.0 | 0.0 |
| COVER ONCE | 9.3 | -689.3 | 0.0 | 95.7 | 8.3 | -412.3 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | 0.3 | -1.2 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 7.7 | +9.0 | 0.0 | 0.0 | 7.7 | +16.7 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -13.8 | 30.7 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 0.7 | +195.0 | 0.0 | 0.0 |
| EXACT ROUND | 0.3 | -2.3 | 0.0 | 0.0 | 1.0 | +9.0 | 70.0 | 0.0 |
| FALL BACK GOOD ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +11.7 | 138.0 | 0.0 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 65.0 |
| FALLS SHORT | 9.3 | +114.7 | 0.0 | 20.0 | 11.7 | +144.5 | 0.0 | 65.0 |
| FEATURE BUFFS | 1.3 | +1.9 | 0.0 | 0.0 | 1.3 | +3.2 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.3 | -0.1 | 30.7 | 0.0 |
| FIVE ACTION | 70.7 | +3883.8 | 0.0 | 430.0 | 73.7 | +4706.1 | 158.0 | 113.3 |
| FLANK NOT WEIGHED | 9.0 | +0.0 | 0.0 | 138.7 | 7.3 | +0.0 | 0.0 | 65.0 |
| FOLLOW UP WEIGHED | 0.3 | +52.3 | 0.0 | 74.0 | 1.0 | +107.3 | 0.0 | 0.0 |
| FOOT FIRST | 13.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 0.7 | +74.7 | 0.0 | 0.0 | 2.7 | +96.1 | 158.0 | 0.0 |
| FREED FROM HIS FIGHT | 5.0 | +0.0 | 0.0 | 74.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -12.7 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | - | - | - | - | 0.7 | -18.8 | 30.7 | 0.0 |
| GOAL WALK | 5.3 | +255.5 | 0.0 | 0.0 | 14.0 | +1597.6 | 0.0 | 0.0 |
| GUN FIGURES | 2.0 | +3.7 | 56.7 | 21.7 | - | - | - | - |
| HARD STAY DROPPED | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 8.3 | +0.0 | 0.0 | 239.7 | 6.3 | +0.0 | 0.0 | 56.7 |
| HIS CHARGE DENIED | 0.3 | +12.7 | 0.0 | 0.0 | 0.3 | +31.2 | 0.0 | 0.0 |
| HIS CHARGE LIST | 6.0 | +0.0 | 0.0 | 0.0 | 9.3 | +0.0 | 0.0 | 56.7 |
| HIS LEGAL MOVES | - | - | - | - | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 1.3 | -6.9 | 0.0 | 188.0 | 4.7 | -86.2 | 0.0 | 0.0 |
| HIS ONE QUARTER | 4.7 | +0.0 | 0.0 | 222.7 | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 4.7 | +0.0 | 0.0 | 40.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 28.0 | +0.0 | 0.0 | 328.0 | 11.3 | +0.0 | 0.0 | 56.7 |
| HIS RANDOM MOVER COMES | 7.3 | +0.0 | 0.0 | 91.7 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 4.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 13.7 | +218.8 | 0.0 | 0.0 | 32.3 | +761.2 | 0.0 | 113.3 |
| HIS SHOTS BY HIS RUN | 12.0 | +103.1 | 0.0 | 188.0 | 27.3 | +298.5 | 0.0 | 113.3 |
| HIS TURN DENIED | - | - | - | - | 0.7 | +23.2 | 0.0 | 0.0 |
| HOLD ODDS | 16.0 | +0.0 | 0.0 | 222.7 | 11.0 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 10.0 | +637.7 | 0.0 | 111.3 | 6.3 | +429.1 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.7 | -32.2 | 0.0 | 0.0 | 2.7 | -58.6 | 158.0 | 0.0 |
| IDLE COST | 4.3 | -81.9 | 0.0 | 0.0 | 8.7 | -104.2 | 0.0 | 65.0 |
| KEPT FROM ITS LAST STOP | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +16.4 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 68.0 | 0.0 |
| LONE WIZARD KEPT IN | 1.0 | +52.2 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 0.3 | +8.7 | 0.0 | 0.0 | 1.3 | +0.3 | 116.3 | 0.0 |
| LURE BY WHAT IT DRAWS | 0.7 | -39.3 | 0.0 | 40.0 | - | - | - | - |
| MANOEUVRE | 1.0 | +0.0 | 0.0 | 13.7 | 1.3 | +7.7 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +12.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.3 | +17.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | -21.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.0 | +2.7 | 0.0 | 13.7 | 1.3 | +14.9 | 0.0 | 0.0 |
| MEETS IN TIME | 5.3 | +188.6 | 0.0 | 0.0 | 3.7 | +115.9 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.7 | +25.1 | 0.0 | 74.0 | 1.7 | +14.2 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 4.7 | +28.1 | 0.0 | 74.0 | 2.0 | +11.4 | 0.0 | 0.0 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 8.0 | +584.1 | 0.0 | 40.0 | 5.0 | +422.8 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 7.7 | +299.9 | 0.0 | 20.0 | 5.3 | +218.0 | 0.0 | 0.0 |
| NEAREST TO GOAL | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 6.0 | +488.4 | 0.0 | 0.0 | 5.0 | +422.8 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 1.0 | -1.6 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 0.3 | -7.4 | 0.0 | 0.0 | 2.0 | -48.0 | 136.3 | 0.0 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 4.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.3 | +1.9 | 0.0 | 37.3 | - | - | - | - |
| NO SECOND RUN | 4.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | -11.9 | 0.0 | 0.0 | 0.7 | +18.1 | 0.0 | 130.0 |
| NOT WORTH A CAST | 2.7 | -1.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 4.7 | -153.0 | 0.0 | 21.7 | 3.3 | -79.7 | 0.0 | 0.0 |
| ONE CHALLENGE TEST | - | - | - | - | 0.3 | -1.0 | 37.3 | 0.0 |
| ONE FIGHT FORMULA | 3.3 | -30.5 | 0.0 | 0.0 | 4.0 | -178.2 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 5.7 | -3.0 | 0.0 | 111.3 | 2.3 | +3.3 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.7 | -10.3 | 0.0 | 0.0 | 0.3 | +34.2 | 0.0 | 0.0 |
| ONE ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 4.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.7 | +7.9 | 85.7 | 0.0 |
| OWN CAST FIRST | 0.7 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| PATHS CROSS | 0.3 | +4.4 | 0.0 | 0.0 | 0.7 | +1.2 | 0.0 | 0.0 |
| PERIAPT WORTH | 0.3 | +40.5 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.3 | -3.9 | 0.0 | 0.0 | 0.3 | -2.7 | 0.0 | 0.0 |
| PLAN RESULT | 32.3 | +0.0 | 65.0 | 509.0 | 32.7 | +100.7 | 30.7 | 243.3 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 8.7 | -254.7 | 0.0 | 40.0 | 8.0 | -264.2 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 15.7 | +1064.6 | 0.0 | 250.0 | 17.7 | +2072.3 | 89.7 | 56.7 |
| RANDOM MOVE BY FIGURES | 3.3 | +124.9 | 0.0 | 96.7 | 4.7 | +53.4 | 0.0 | 113.3 |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.7 | +33.2 | 0.0 | 27.3 | - | - | - | - |
| REDIRECT COUNTER | 1.3 | +98.7 | 0.0 | 13.7 | 1.0 | +32.9 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 2.0 | +0.0 | 0.0 | 40.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.3 | -64.6 | 0.0 | 0.0 | 1.0 | -25.4 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.7 | +10.5 | 0.0 | 0.0 | 0.3 | +5.8 | 0.0 | 0.0 |
| RISK BY ARC | 0.3 | -4.5 | 0.0 | 0.0 | 2.3 | +44.5 | 138.0 | 0.0 |
| RUN DOWN | 0.7 | -10.6 | 0.0 | 0.0 | 1.0 | -5.1 | 116.3 | 0.0 |
| SCOUT SPOT | 0.7 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +28.7 | 48.3 | 0.0 |
| SET CREDITED ONCE | 2.7 | -62.3 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 2.7 | +54.1 | 0.0 | 0.0 | - | - | - | - |
| SET UP TOGETHER | - | - | - | - | 0.7 | +2.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +1.3 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 1.7 | +0.0 | 0.0 | 13.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.7 | +64.0 | 0.0 | 0.0 | 0.7 | +5.2 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -2.6 | 0.0 | 0.0 |
| SHOT RISK POINTS | 6.0 | -56.0 | 0.0 | 188.0 | 18.3 | -245.9 | 0.0 | 56.7 |
| SHOTS AFTER THE MOVES | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOTS IN THE MOVE | 6.7 | +139.4 | 0.0 | 95.7 | 4.0 | +44.1 | 0.0 | 0.0 |
| SPELL WORTH | 3.3 | +51.7 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 7.0 | +0.0 | 0.0 | 90.0 | 10.3 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | - | - | - | - | 0.7 | -7.5 | 21.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 24.3 | +0.0 | 0.0 | 75.7 | 26.3 | +0.0 | 0.0 | 113.3 |
| STAY WORTH | 4.7 | +7.4 | 0.0 | 0.0 | 4.3 | +19.6 | 0.0 | 0.0 |
| STUBBORN BY POINTS | 0.3 | +26.3 | 56.7 | 0.0 | - | - | - | - |
| STUCK PIVOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 8.0 | +1285.4 | 0.0 | 0.0 | 6.7 | +210.7 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 8.0 | +1285.4 | 0.0 | 0.0 | 6.7 | +210.7 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.7 | +0.9 | 0.0 | 65.0 |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 4.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 4.3 | +0.0 | 0.0 | 133.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 4.0 | +0.0 | 0.0 | 133.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 4.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 35.3 | +0.0 | 0.0 | 180.3 | 33.7 | +0.0 | 0.0 | 130.0 |
| TIED UP BY THE SUM | - | - | - | - | 1.3 | +78.4 | 41.7 | 0.0 |
| TIME ON OUR SIDE | 23.3 | +215.7 | 0.0 | 21.7 | 17.7 | +184.9 | 0.0 | 0.0 |
| WAITS AGAIN | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | 0.3 | -2.4 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.3 | +3.3 | 0.0 | 0.0 | 0.7 | +5.7 | 0.0 | 0.0 |
| WHO HITS BACK | 0.3 | +13.8 | 0.0 | 0.0 | 0.3 | +4.1 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 5.3 | -666.1 | 0.0 | 91.7 | 3.0 | -427.0 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 1.3 | +3.7 | 0.0 | 148.0 | 1.3 | +53.6 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p71

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 154 | 154 | 105 | 35.00 | +2680 | +25.5 |
| HOLDER ASSIGNMENT | 49 | 49 | 45 | 15.00 | +2968 | +65.9 |
| OFF BEST | 24 | 24 | 24 | 8.00 | -698 | -29.1 |
| PROMISE BY ITS OWN SUM | 50 | 50 | 24 | 8.00 | -1557 | -64.9 |
| DEPLOY BY FIGURES | 46 | 46 | 23 | 7.67 | +275 | +12.0 |
| HIS SHOTS BY HIS RUN | 118 | 105 | 21 | 7.00 | +169 | +8.0 |
| THE TABLE AGAIN | 27 | 27 | 21 | 7.00 | +0 | +0.0 |
| HIS SHOT LIST | 138 | 122 | 20 | 6.67 | +176 | +8.8 |
| FIVE ACTION | 433 | 406 | 19 | 6.33 | +1858 | +97.8 |
| LEGAL CHARGES ONLY | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 24 | 24 | 16 | 5.33 | +535 | +33.4 |
| TIME ON OUR SIDE | 123 | 111 | 14 | 4.67 | +30 | +2.1 |
| ADVANCE LANE KEPT | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 39 | 27 | 13 | 4.33 | +884 | +68.0 |
| QUARTER ODDS | 100 | 96 | 12 | 4.00 | +643 | +53.6 |
| MEETS IN TIME | 27 | 27 | 11 | 3.67 | +349 | +31.8 |
| NEXT CHARGE BY LIST | 33 | 25 | 11 | 3.67 | +884 | +80.3 |
| REDIRECT FOR A FRIEND IN REACH | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| SUPPORT ADDS | 44 | 43 | 9 | 3.00 | +275 | +30.6 |
| SUPPORT WORKED OUT | 44 | 43 | 9 | 3.00 | +275 | +30.6 |
| COVER ONCE | 53 | 38 | 7 | 2.33 | +94 | +13.5 |
| HOLDS AMBUSHERS | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| MOVE ORDER | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 7 | 7 | 7 | 2.33 | +37 | +5.3 |
| GOAL WALK | 58 | 53 | 6 | 2.00 | +453 | +75.4 |
| HARD STAY DROPPED | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 25 | 24 | 6 | 2.00 | +518 | +86.3 |
| SHOT RISK POINTS | 73 | 64 | 5 | 1.67 | +82 | +16.4 |
| CHARGE LOSSES | 77 | 70 | 4 | 1.33 | +310 | +77.6 |
| COMBAT PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +479 | +119.7 |
| FOUR ROUNDS | 10 | 10 | 4 | 1.33 | +180 | +45.1 |
| SET UP BY THE SET | 8 | 6 | 4 | 1.33 | +9 | +2.3 |
| STUCK PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| IDLE COST | 39 | 22 | 3 | 1.00 | +12 | +4.0 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +157 | +52.2 |
| ONE PROMISE A TARGET | 3 | 3 | 3 | 1.00 | +71 | +23.8 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +17 | +5.6 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +49 | +16.4 |
| CAST JOB | 6 | 6 | 2 | 0.67 | +10 | +4.8 |
| CHAFF IN THE MOVE | 3 | 3 | 2 | 0.67 | +0 | +0.0 |
| FALLS SHORT | 63 | 53 | 2 | 0.67 | +12 | +6.2 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +51 | +25.7 |
| MISSILES IN THE MOVE | 13 | 10 | 2 | 0.67 | +7 | +3.5 |
| NEARER NOT NEEDED | 39 | 35 | 2 | 0.67 | +32 | +15.8 |
| ONE OBJECTIVE FORMULA | 24 | 17 | 2 | 0.67 | +73 | +36.7 |
| OWN CAST FIRST | 2 | 2 | 2 | 0.67 | -1 | -0.6 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.67 | -20 | -9.9 |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 2 | 0.67 | +29 | +14.3 |
| RISK BY ARC | 8 | 8 | 2 | 0.67 | +72 | +36.2 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +5 | +2.5 |
| SHOTS IN THE MOVE | 32 | 26 | 2 | 0.67 | +19 | +9.4 |
| THE ROW IN ITS ORDER | 28 | 2 | 2 | 0.67 | +0 | +0.0 |
| TIED UP BY THE SUM | 4 | 4 | 2 | 0.67 | +42 | +20.8 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +11 | +5.3 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -7 | -6.7 |
| CHARGE NOW FIRST | 5 | 5 | 1 | 0.33 | -101 | -101.4 |
| EVASIVE BY THE ODDS | 2 | 2 | 1 | 0.33 | +582 | +582.1 |
| MANOEUVRE | 7 | 7 | 1 | 0.33 | +32 | +32.3 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +36 | +36.2 |
| MARCH CHECK | 1 | 1 | 1 | 0.33 | +41 | +41.0 |
| MAX FOR POSITIONING | 7 | 7 | 1 | 0.33 | +2 | +1.7 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.33 | +2 | +2.2 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +122 | +121.5 |
| REDIRECT COUNTER | 7 | 6 | 1 | 0.33 | +42 | +41.5 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +56 | +56.2 |
| REFUSING RETIRES | 2 | 2 | 1 | 0.33 | -4 | -4.4 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +86 | +86.1 |
| STAY WORTH | 27 | 26 | 1 | 0.33 | +4 | +4.1 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +79 | +79.0 |
| SURE REACH TOGETHER | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -7 | -7.2 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 10 | 10 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 54 | 50 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 1 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 7 | 7 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 2 | 2 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 8 | 8 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 49 | not checked | - | - | - | - |
| FOOT FIRST | 40 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 17 | 17 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | not checked | - | - | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 6 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 44 | 42 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 46 | 46 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 15 | 13 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 18 | 16 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 25 | 25 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 29 | 23 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 118 | 116 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 29 | 28 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 26 | 26 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HOLD ODDS | 81 | 81 | 0 | 0.00 | - | - |
| HONEST WORTH | 10 | 10 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 13 | 13 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 5 | 5 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 20 | 17 | 0 | 0.00 | - | - |
| NEAREST TO GOAL | 1 | 1 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 3 | 3 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 7 | 7 | 0 | 0.00 | - | - |
| NO LATE CUT | 5 | 5 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 27 | 27 | 0 | 0.00 | - | - |
| NO SECOND RUN | 27 | 27 | 0 | 0.00 | - | - |
| NOT TURNED | 3 | 3 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 8 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE FIGHT FORMULA | 22 | 10 | 0 | 0.00 | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 27 | 27 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 195 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 4 | not checked | - | - | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 7 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 5 | 5 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SEARCH SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 8 | 6 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 9 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 3 | 3 | 0 | 0.00 | - | - |
| SPELL WORTH | 10 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 52 | 48 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 3 | 1 | 0 | 0.00 | - | - |
| STANDS STILL | 152 | 142 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 16 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 15 | not checked | - | - | - | - |
| THE TABLE BINDS | 207 | not checked | - | - | - | - |
| WAITS AGAIN | 3 | 3 | 0 | 0.00 | - | - |
| WHO FIGHTS | 3 | 3 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 8 | 8 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p71

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 4.00 | 4.00 | 64.9 |
| ARMY TABLE | rule | 5.00 | 1.67 | 45.1 |
| JOB FIRST | gate | 3.00 | 3.00 | 31.8 |
| HOLDER ASSIGNMENT | rule | 0.67 | 0.33 | 8.4 |
| NO REASON | gate | 1.00 | - | 28.8 |
| ONE PROMISE A TARGET | rule | 0.67 | - | 15.6 |
| PIVOT GUARDS FLANK | rule | 0.33 | 0.33 | 9.9 |
| AFTERMATH BAND | gate | 0.33 | - | 1.8 |
| CHAFF PASSED | rule | - | 0.33 | 6.7 |
| CHARGE NOW FIRST | rule | - | 0.33 | 101.4 |
| OWN CAST FIRST | rule | 0.33 | - | 0.6 |
| REFUSING RETIRES | rule | - | 0.33 | 4.4 |
| RULE SWITCHED OFF | gate | - | 0.33 | 1.7 |
| TURN GATE | gate | 0.33 | - | 35.5 |
| WALKS ON ITS ROUTE | rule | 0.33 | - | 7.2 |
| WHO HITS BACK | rule | 0.33 | - | 1.8 |

### Plans: gs3-83c8646-p71

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | join | 2.3 | 100% | 125 | 0 | 0% |
| Mine | move | 28.0 | 96% | 1504 | 0 | 0% |
| Mine | shoot | 1.3 | 0% | 80 | 0 | 0% |
| Mine | support | 0.7 | 50% | 21 | 0 | 0% |
| Opponent | charge | 1.7 | 80% | 321 | 101 | 31% |
| Opponent | join | 0.7 | 50% | 20 | 0 | 0% |
| Opponent | move | 29.3 | 99% | 1662 | 0 | 0% |
| Opponent | shoot | 1.0 | 0% | 53 | 0 | 0% |

### Battle groups: gs3-83c8646-p71

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.3 | 25% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 1.0 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p71

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Chaff | 3 | 0 (3) | 0 | 0 | 34 | 67% | 3.0 | 0 (2) | 0 (1) | - | 0 (2) | 0 (1) |
| Mine | Character | 7 | 10 (7) | 10 | 0 | 18 | 14% | 4.3 | 0 (3) | 35 (2) | - | 39 (1) | 0 (4) |
| Mine | Clean-up | 2 | 0 (2) | 0 | 0 | 58 | 50% | 6.0 | - | 0 (1) | 0 (1) | 0 (1) | 0 (1) |
| Mine | Fast Hammer | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | Hammer | 3 | 39 (3) | 39 | 0 | 58 | 0% | 1.7 | - | 55 (2) | 0 (1) | 39 (3) | - |
| Mine | Holder | 6 | 41 (6) | 0 | 41 | 31 | 50% | 5.7 | 76 (2) | 14 (3) | 73 (1) | 41 (6) | - |
| Mine | Shooter | 2 | 0 (2) | 0 | 0 | 50 | 0% | 1.5 | - | 0 (1) | 0 (1) | 0 (2) | - |
| Opponent | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Character | 7 | 20 (7) | 20 | 0 | 11 | 57% | 3.0 | 11 (4) | 76 (2) | 0 (1) | 32 (5) | 7 (2) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 3 | 0 (3) | 0 | 0 | 0 | 67% | 6.0 | 0 (2) | - | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Hammer | 5 | 70 (5) | 70 | 0 | 18 | 20% | 2.5 | 86 (4) | 0 (1) | - | 131 (3) | 0 (2) |
| Opponent | Holder | 4 | 65 (4) | 23 | 43 | 0 | 50% | 5.5 | 125 (1) | 46 (3) | - | - | 65 (4) |

### Charged fights: gs3-83c8646-p71

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 1 | 170 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Vampire Counts | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| **Mine** | all armies | 2 | 85 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| Opponent | Warriors of Chaos | 2 | 0 | 204 | 2.0 | 1.0 | 102 | 0 | +102 | 0 of 4 | 4 of 4 | - | +102 |

### Effective charges: gs3-83c8646-p71

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Warriors of Chaos | 4 | 1 (net +92) | 0 | 0 | 1 (net +112) | 1 (net +60) | 0 | 1 | 0% (0 of 3) |

### Charged fights, damage counted: gs3-83c8646-p71

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 235 | 205 | +0 | 102 | 35 | +67 | +28.6 |
| Mine | All fights | 1 | 235 | 205 | +0 | 102 | 35 | +67 | +28.6 |
| Opponent | Long shot (under 50%) | 1 | 116 | 92 | +92 | 92 | 0 | +92 | +79.3 |
| Opponent | 76-89% | 1 | 144 | 112 | +112 | 112 | 0 | +112 | +77.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 494 | 60 | +60 | 60 | 0 | +60 | +12.1 |
| Opponent | No odds | 1 | 116 | 145 | +145 | 232 | 72 | +160 | +138.4 |
| Opponent | All fights | 4 | 218 | 102 | +102 | 124 | 18 | +106 | +48.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p71 | move | 13 | 3 (23%) | 3 (23%) | 0 (0%) | 10 (77%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2429 |
| Invocation of Nehek | Mine | L2429 |
| Periapt of Soul Exchange | Mine | L2131 |
| Ring of Doom | Opponent | L2131 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |

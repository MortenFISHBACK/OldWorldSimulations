# Doctrine scorecard: gs3-83c8646-p21

### Scorecard: gs3-83c8646-p21

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1531 | 1 | 1 | Mine | no | 0 | 3 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 1 | 5 | 0 | 2 | 1 | 0 | 0 | 170 |
| L1629 | 3 | 1 | Mine | no | 7 | 2 | 2 | 0 | 0 | 0 | 0 | 200 |
| L1629 | 3 | 1 | Opponent | no | 2 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Mine | yes | - | 3 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 3.5 | 2.7 | 3.3 | 0.7 | 0.0 | 0.0 | 0.0 | 66.7 |
| **Average** | | | Opponent | 33% | 1.5 | 3.3 | 2.0 | 2.0 | 0.3 | 0.0 | 0.0 | 56.7 |

### KPIs: gs3-83c8646-p21

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 16) | 0% (0 of 16) | 0% (0 of 32) |
| Winner chose to follow up after the loser gave ground |  | 60% (6 of 10); on the table 70% | 100% (1 of 1); on the table 100% | 64% (7 of 11); on the table 73% |
| Winner chose to pursue after the loser fell back in good order |  | - | 50% (1 of 2); on the table 50% | 50% (1 of 2); on the table 50% |
| Winner chose to pursue after the loser fled |  | 25% (1 of 4); on the table 50% | - | 25% (1 of 4); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 50% (7 of 14); on the table 64% | 67% (2 of 3); on the table 67% | 53% (9 of 17); on the table 65% |
| Magic missiles tried each own turn | 50%+ | - | 42% (5 of 12) | 42% (5 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 42% (5 of 12) | 42% (5 of 12) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 54% (7 of 13) | 54% (7 of 13) |
| Points that never fought | lower | 48% (2892 of 6000) | 51% (3051 of 5999) | 50% (5943 of 11999) |
|   infantry points that never fought | lower | 85% (1134 of 1332) | 79% (673 of 855) | 83% (1807 of 2187) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 45% (9 of 20) | 76% (19 of 25) | 62% (28 of 45) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.7 uses a game | 100% (1 of 1); 1.3 uses a game | 100% (3 of 3); 2.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 37% (1919 of 5135) | 80% (4340 of 5430) | 59% (6259 of 10565) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.7 (71%) | 1.7 (71%) |
| MARCHED: its unit marched | - | 0.7 (29%) | 0.7 (29%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 2.3 | 1.3 | 0.0 | 1.7 | 0.3 |
| not cast | 7.7 | 0.7 | 2.0 | 2.3 | 19.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (71%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (29%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 1.3 (17%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.7 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 6.3 (83%) | 0.0 (0%) | 2.0 (100%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 19.3 (98%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 58% (57 of 98) | 14% (1 of 7) | 55% (58 of 105) |
|   cavalry | 82% (9 of 11) | 33% (1 of 3) | 71% (10 of 14) |
|   character | 27% (3 of 11) | 0% (0 of 4) | 20% (3 of 15) |
|   chariot | 17% (1 of 6) | - | 17% (1 of 6) |
|   infantry | 69% (27 of 39) | - | 69% (27 of 39) |
|   monster | 26% (5 of 19) | - | 26% (5 of 19) |
|   war machine | 100% (12 of 12) | - | 100% (12 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (20%) | 0.0 (0%) | 2.7 (17%) |
| CHARGED: it charged | 2.3 (17%) | 0.0 (0%) | 2.3 (15%) |
| IN COMBAT: it fought this turn or the last | 2.0 (15%) | 0.0 (0%) | 2.0 (13%) |
| NO TARGET IN RANGE | 2.7 (20%) | 2.0 (100%) | 4.7 (30%) |
| ONLY IN COMBAT: the only targets were in combat | 1.3 (10%) | 0.0 (0%) | 1.3 (9%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.7 (20%) | 0.0 (0%) | 2.7 (17%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.7 | 0.7 | 82% | 13.3 pts | 49 pts |
| character | 1.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 0.3 | 0.3 | 0% | 65.0 pts | 22 pts |
| infantry | 16.3 | 1.3 | 94% | 1.6 pts | 26 pts |
| monster | 1.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 4.0 | 2.3 | 75% | 19.4 pts | 78 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.7 | 5.3 | 5.5 |
| Charges that made contact a game | 4.7 | 3.0 | 3.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 0.33 contact (3 units) | 1.00 declared, 0.33 contact (3 units) | 1.00 declared, 0.33 contact (6 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.67 declared, 0.62 contact (21 units) | 0.65 declared, 0.40 contact (20 units) | 0.66 declared, 0.51 contact (41 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 60% (3 of 5) | 67% (2 of 3) | 100% (2 of 2) | 70% (7 of 10) |
| Character in a unit | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Character on its own | 60% (3 of 5) | 0% (0 of 2) | 56% (5 of 9) | 50% (8 of 16) |
| Chariot | 100% (1 of 1) | - | - | 100% (1 of 1) |
| Infantry | 71% (5 of 7) | 0% (0 of 3) | - | 50% (5 of 10) |
| Monster | 83% (5 of 6) | - | - | 83% (5 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 1 | 0% (0 of 3); on the table 67% | - | 63% | 71% (5 of 7) | 100% (2 of 2); 8.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 50% (1 of 2); on the table 50% | - | 50% | 17% (1 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | 67% (6 of 9); on the table 67% | - | 32% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (2 of 2); on the table 100% | 17% (1 of 6) | 68% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | 0% (0 of 1); on the table 0% | 67% (4 of 6) | 42% | 74% (14 of 19) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p21, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 44% (4) | 36% (4) |
| ...free all their last turn and able to turn (per game) | 0.00 | 1.33 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 1.00 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.67 | 0.67 |

### Quality by phase: gs3-83c8646-p21

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 4.3 |
| Strategy | Charge objectives carried out (made contact) | 67% (8 of 12) | 38% (6 of 16) |
| Strategy | Shoot objectives carried out (shot that target) | 39% (9 of 23) | 0% (0 of 2) |
| Strategy | Support requests answered (helper made contact too) | 100% (2 of 2) | 75% (3 of 4) |
| Strategy | Joined characters whose unit fought | 0% (0 of 1) | 0% (0 of 2) |
| Strategy | Lone characters that fought | 88% (7 of 8) | 73% (8 of 11) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 0.7 | 2.0 |
| Movement | Points that never moved of their own | 66.7 | 56.7 |
| Movement | Fights charged into per game | 3.7 | 2.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 7 | 3 of 8, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 7 | 1 of 8, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 4 of 7, net +52 | 0 of 8 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 7, net +356 | 3 of 8, net +69 |
| Shooting | Shots by shooting units (incl. breath weapons) | 16.7 | 0.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 38% (19 of 50) | 100% (1 of 1) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 4.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 58% (7 of 12) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | - | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 50% (1 of 2) |
| Magic | Wounds caused by magic missiles | 1.7 | 0.7 |
| Magic | Wounds caused by other spells | - | 0.7 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 1.0 / 0.0 / 0.0 | 0.7 / 0.0 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 322.7 | 100.3 |
| Combat | Points run down | 68.3 | 0.0 |
| Combat | Net points per charged fight, damage counted | +132 | +7 |
| Combat | Net per 100 charger points, damage counted | +33.3 | +4.5 |
| Combat | First round won (charged fights) | 100% | 62% |
| Combat | Net points per charged fight | +120 | +26 |
| Combat | Net points per supported fight / lone fight | +4 / +146 | +126 / +11 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 11 | 0 of 8 |
| Game | Points lost | 271.0 | 630.0 |
| Game | VP from objectives | 663.3 | 603.3 |
| Game | Lone holders (player turns) | 3.5 | 1.5 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +395 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 901
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: gs3-83c8646-p21

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 1.0 | +14.9 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH WITH FRIENDS | 0.3 | +20.2 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 23.7 | -6.6 | 0.0 | 142.3 | 14.7 | +202.8 | 0.0 | 751.7 |
| BACKUP TARGETS | 0.3 | +0.3 | 0.0 | 0.0 | 1.0 | +14.5 | 0.0 | 38.7 |
| BEST PRIZE | - | - | - | - | 0.3 | -17.5 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.7 | -11.1 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 4.0 | +33.9 | 0.0 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 1.3 | +3.7 | 211.3 | 0.0 | 1.0 | +3.4 | 42.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.3 | +34.8 | 0.0 | 0.0 | 1.3 | +6.0 | 0.0 | 0.0 |
| CHAFF PASSED | 0.7 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | - | - | - | - | 1.0 | +20.2 | 0.0 | 135.3 |
| CHARGE LIST READ AGAIN | 0.3 | +89.8 | 0.0 | 0.0 | 0.3 | +45.8 | 26.7 | 0.0 |
| CHARGE LOSSES | 9.3 | -403.5 | 0.0 | 572.7 | 19.7 | -802.9 | 0.0 | 295.3 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 301.7 | 0.0 | 2.0 | +0.0 | 142.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 8.7 | +0.0 | 0.0 | 58.3 | 13.7 | +0.0 | 0.0 | 424.7 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| COVER ONCE | 9.3 | -568.8 | 0.0 | 58.3 | 9.0 | -737.9 | 0.0 | 81.3 |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -0.4 | 58.3 | 0.0 |
| DEPLOY BY FIGURES | 7.3 | -26.0 | 0.0 | 0.0 | 6.3 | +63.8 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -9.9 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 3.0 | +25.6 | 148.3 | 0.0 | 3.7 | +6.5 | 255.0 | 0.0 |
| FALL BACK GOOD ORDER | 3.3 | +2.8 | 149.7 | 0.0 | 4.3 | +11.9 | 323.7 | 0.0 |
| FALLS SHORT | - | - | - | - | 17.7 | +234.2 | 0.0 | 302.7 |
| FEATURE BUFFS | 2.0 | +131.1 | 0.0 | 0.0 | 2.3 | +217.6 | 0.0 | 0.0 |
| FIGHT LIFT | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 1.3 | +3.9 | 149.7 | 0.0 | 1.7 | +14.0 | 58.3 | 0.0 |
| FIRE AND FLEE | 0.3 | +2.0 | 0.0 | 26.7 | - | - | - | - |
| FIVE ACTION | 91.7 | +7674.6 | 775.0 | 914.0 | 81.3 | +5036.2 | 407.7 | 1372.0 |
| FLANK NOT WEIGHED | 5.7 | +0.0 | 0.0 | 142.3 | 9.7 | +0.0 | 0.0 | 177.3 |
| FOLLOW UP WEIGHED | 1.0 | +117.8 | 0.0 | 0.0 | 0.3 | +57.3 | 0.0 | 0.0 |
| FOOT FIRST | - | - | - | - | 21.0 | +0.0 | 0.0 | 359.7 |
| FOUR ROUNDS | 5.0 | +316.7 | 340.3 | 0.0 | 5.3 | +274.0 | 365.7 | 0.0 |
| FREED FROM HIS FIGHT | 2.3 | +0.0 | 0.0 | 346.3 | 4.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -1.4 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.3 | +7.9 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 1.0 | -10.3 | 0.0 | 0.0 | 0.7 | -12.6 | 26.7 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.3 | -8.4 | 26.7 | 0.0 |
| GOAL ON TIME | - | - | - | - | 0.7 | +90.4 | 0.0 | 0.0 |
| GOAL WALK | 10.3 | +764.4 | 0.0 | 576.0 | 8.7 | +650.8 | 0.0 | 0.0 |
| GUN MASK | 1.3 | +6.1 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HE REFORMS ONCE FREED | 1.0 | +0.0 | 0.0 | 58.3 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 7.3 | +0.0 | 0.0 | 200.7 | 12.0 | +0.0 | 0.0 | 295.3 |
| HIS CHARGE LIST | 2.0 | +0.0 | 0.0 | 0.0 | 10.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 5.0 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | - | - | - | - | 6.0 | -73.1 | 0.0 | 38.7 |
| HIS ONE QUARTER | 5.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 38.7 |
| HIS OWN BEST MOVE | 8.0 | +0.0 | 0.0 | 0.0 | 10.3 | +0.0 | 0.0 | 68.7 |
| HIS RANDOM MOVE | 8.3 | +0.0 | 0.0 | 168.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.7 | +0.0 | 0.0 | 372.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 5.0 | +106.7 | 0.0 | 84.0 | 42.3 | +1353.1 | 0.0 | 1285.3 |
| HIS SHOTS BY HIS RUN | 5.3 | +32.2 | 0.0 | 84.0 | 42.3 | +1029.0 | 0.0 | 683.3 |
| HIS TURN DENIED | - | - | - | - | 2.0 | +11.1 | 170.0 | 0.0 |
| HOLD ODDS | 15.0 | +0.0 | 0.0 | 0.0 | 16.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 9.0 | +861.2 | 0.0 | 0.0 | 7.7 | +913.0 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.3 | -175.6 | 340.3 | 0.0 | 5.0 | -131.2 | 339.0 | 0.0 |
| HUNT DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HUNT RESULT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HUNT THE GUNS | 0.3 | +87.3 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | - | - | - | - | 17.7 | -226.0 | 0.0 | 481.0 |
| JOINT CHARGE NOW | 1.7 | +22.8 | 107.7 | 0.0 | 2.7 | +17.1 | 207.0 | 0.0 |
| JOINT ON THE TABLE | 0.3 | +95.6 | 0.0 | 0.0 | 0.3 | +31.3 | 26.7 | 0.0 |
| KEPT FROM ITS LAST STOP | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +91.8 | 0.0 | 0.0 | 1.0 | +8.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 15.7 | +0.0 | 195.3 | 53.3 | 7.0 | +0.0 | 58.3 | 142.0 |
| LONE WIZARD KEPT IN | 0.3 | +5.0 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.3 | +14.1 | 26.7 | 0.0 |
| LOST AFTER ESCAPE | 3.0 | +1.5 | 188.3 | 0.0 | 3.7 | +15.6 | 254.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.7 | +2.4 | 0.0 | 0.0 |
| MANOEUVRE | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | -3.8 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +29.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | +155.1 | 0.0 | 0.0 | 0.7 | +17.9 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.7 | +34.8 | 0.0 | 0.0 | 2.7 | +27.9 | 0.0 | 43.3 |
| MEETS IN TIME | 3.7 | +211.0 | 0.0 | 0.0 | 3.3 | +109.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.0 | +37.3 | 0.0 | 0.0 | 3.3 | +32.7 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 3.3 | +33.3 | 0.0 | 0.0 | 3.7 | +37.6 | 0.0 | 0.0 |
| MOVE ORDER | 3.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 69.0 |
| MOVE TO CHARGE COMPUTED | 12.3 | +1411.4 | 0.0 | 0.0 | 10.0 | +692.0 | 0.0 | 68.7 |
| MOVES UNITS SPELL | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 7.0 | +326.7 | 0.0 | 0.0 | 3.7 | +139.0 | 0.0 | 69.0 |
| NEAREST TO GOAL | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 7.7 | +935.4 | 0.0 | 0.0 | 5.7 | +416.5 | 0.0 | 30.0 |
| NO DOUBLE ROUNDS | 3.7 | -135.3 | 340.3 | 0.0 | 4.0 | -117.5 | 365.7 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.3 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.3 | -1.6 | 0.0 | 0.0 | 1.0 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 8.0 | -349.0 | 0.0 | 0.0 | 2.0 | -59.7 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 7.0 | -163.3 | 0.0 | 0.0 | 5.3 | -91.1 | 0.0 | 53.7 |
| ONE JOINT FIGURE | 0.3 | +78.1 | 67.0 | 0.0 | 0.7 | -3.1 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 4.3 | +31.0 | 0.0 | 0.0 | 4.3 | +122.4 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 1.7 | -281.5 | 0.0 | 0.0 | 1.3 | -56.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +10.3 | 38.7 | 0.0 | 0.7 | +33.4 | 26.7 | 0.0 |
| OVERRUNS AWAY | 0.7 | +5.2 | 67.0 | 0.0 | 1.3 | +11.3 | 95.3 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.7 | +10.8 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.7 | -9.5 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 41.3 | +528.3 | 392.3 | 500.0 | 43.0 | +246.2 | 245.7 | 763.3 |
| PROMISE BY ITS OWN SUM | 14.0 | -801.9 | 0.0 | 0.0 | 11.0 | -210.7 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 3.0 | +0.0 | 0.0 | 0.0 | 2.3 | -1.4 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.7 | -1.3 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 27.0 | +3369.3 | 116.0 | 116.7 | 21.7 | +2282.5 | 354.3 | 77.3 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.3 | +92.1 | 0.0 | 113.3 |
| REDIRECT BY WHAT IT STOPS | 0.3 | -5.9 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 1.7 | +128.4 | 0.0 | 0.0 | 1.7 | +141.9 | 0.0 | 43.3 |
| REDIRECT FOR A FRIEND IN REACH | 1.3 | +12.5 | 0.0 | 26.7 | 2.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | -17.5 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 2.7 | -74.3 | 0.0 | 0.0 | 1.7 | -83.2 | 0.0 | 38.7 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 0.3 | +12.8 | 0.0 | 0.0 | - | - | - | - |
| RESTRAINS TO SHOOT | 0.3 | +5.8 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 3.3 | +64.7 | 233.3 | 0.0 | 5.3 | +166.2 | 365.7 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 1.0 | -29.3 | 146.3 | 0.0 | 1.3 | -28.2 | 0.0 | 0.0 |
| RUN DOWN | 2.7 | -105.5 | 283.7 | 0.0 | 4.0 | -30.2 | 307.3 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | -131.7 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +2.6 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SECOND LOOK | 0.7 | +49.8 | 0.0 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | 2.0 | -1.0 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 1.3 | -35.6 | 0.0 | 0.0 | 0.3 | -3.6 | 0.0 | 0.0 |
| SET UP BY THE SET | 4.0 | +4.7 | 40.7 | 26.7 | 1.3 | +5.9 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.7 | +2.4 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 1.0 | +2.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 9.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 3.0 | +29.5 | 30.0 | 0.0 | 0.3 | +1.3 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -0.2 | 0.0 | 0.0 | 0.3 | -0.8 | 42.0 | 0.0 |
| SHOT RISK POINTS | 6.7 | -43.1 | 0.0 | 84.0 | 28.7 | +106.6 | 0.0 | 145.7 |
| SHOTS AFTER THE MOVES | 4.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOTS IN THE MOVE | 15.7 | +314.9 | 0.0 | 127.0 | - | - | - | - |
| SPELL WORTH | 0.7 | +21.8 | 0.0 | 0.0 | 1.7 | +2.3 | 40.0 | 40.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | +14.7 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 11.3 | +0.0 | 0.0 | 242.7 |
| STAND AND SHOOT | - | - | - | - | 1.7 | -7.4 | 106.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 33.7 | +0.0 | 434.7 | 58.3 | 17.7 | +0.0 | 42.0 | 278.0 |
| STAY WORTH | 17.3 | -120.2 | 327.3 | 0.0 | 0.3 | +0.2 | 42.0 | 0.0 |
| STOPS | 0.3 | +3.6 | 0.0 | 0.0 | - | - | - | - |
| STRIKE BY THE ODDS | - | - | - | - | 0.7 | +0.1 | 0.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 56.7 |
| STUPIDITY NEXT TURN | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.7 | +63.8 | 0.0 | 0.0 | 1.7 | +48.8 | 0.0 | 0.0 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 42.0 | 0.0 |
| SUPPORT WORKED OUT | 2.7 | +63.8 | 0.0 | 0.0 | 1.7 | +48.8 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +0.8 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | -0.5 | 0.0 | 26.7 | 0.3 | +1.2 | 0.0 | 67.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 40.7 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 109.0 |
| THE STEP BACK IS MADE | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 42.7 | +0.0 | 0.0 | 457.0 | 38.0 | +0.0 | 0.0 | 629.3 |
| TIED UP BY THE SUM | 2.3 | +221.3 | 234.7 | 0.0 | 1.0 | +60.2 | 110.7 | 0.0 |
| TIME ON OUR SIDE | 39.7 | +508.0 | 0.0 | 356.7 | - | - | - | - |
| WAITS AGAIN | 3.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 30.0 |
| WEAPON BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 67.0 |
| WHAT THE JOINER ADDS | 0.7 | +17.4 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 2.0 | -1.2 | 28.3 | 0.0 | 1.3 | +17.6 | 111.7 | 0.0 |
| WHO GETS IN | - | - | - | - | 0.3 | -37.6 | 58.3 | 0.0 |
| WHO HITS BACK | 0.3 | +36.8 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | 0.3 | -23.2 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 6.0 | -330.4 | 0.0 | 572.7 | 2.7 | -398.3 | 0.0 | 81.3 |
| WHOLE FIGHT GAIN | 0.7 | +73.3 | 67.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | - | - | - | - | 3.7 | +44.6 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p21

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 115 | 115 | 72 | 24.00 | +948 | +13.2 |
| LEGAL CHARGES ONLY | 68 | 68 | 68 | 22.67 | +0 | +0.0 |
| FIVE ACTION | 519 | 500 | 53 | 17.67 | +1950 | +36.8 |
| HOLDER ASSIGNMENT | 50 | 50 | 47 | 15.67 | +3465 | +73.7 |
| MOVE TO CHARGE COMPUTED | 67 | 59 | 37 | 12.33 | +957 | +25.9 |
| HIS SHOT LIST | 142 | 138 | 32 | 10.67 | +828 | +25.9 |
| PROMISE BY ITS OWN SUM | 75 | 75 | 31 | 10.33 | -3038 | -98.0 |
| OFF BEST | 30 | 30 | 30 | 10.00 | -1226 | -40.9 |
| THE TABLE AGAIN | 36 | 36 | 29 | 9.67 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 143 | 136 | 26 | 8.67 | +287 | +11.0 |
| DEPLOY BY FIGURES | 41 | 41 | 25 | 8.33 | +230 | +9.2 |
| MOVE ORDER | 22 | 22 | 22 | 7.33 | +0 | +0.0 |
| QUARTER ODDS | 146 | 143 | 22 | 7.33 | +1660 | +75.4 |
| NEXT CHARGE BY LIST | 40 | 37 | 19 | 6.33 | +751 | +39.5 |
| SHOT RISK POINTS | 106 | 98 | 15 | 5.00 | +400 | +26.7 |
| FOUR ROUNDS | 31 | 29 | 13 | 4.33 | +462 | +35.5 |
| JOINT CHARGE NOW | 13 | 13 | 13 | 4.33 | +119 | +9.2 |
| REDIRECT FOR A FRIEND IN REACH | 12 | 12 | 12 | 4.00 | +25 | +2.1 |
| GOAL WALK | 57 | 57 | 10 | 3.33 | +710 | +71.0 |
| CHARGE LOSSES | 87 | 82 | 9 | 3.00 | +858 | +95.3 |
| ONE PROMISE A TARGET | 9 | 9 | 9 | 3.00 | -1012 | -112.5 |
| RISK BY ARC | 26 | 24 | 9 | 3.00 | +180 | +20.0 |
| COVER ONCE | 55 | 38 | 8 | 2.67 | +146 | +18.3 |
| MEETS IN TIME | 21 | 21 | 8 | 2.67 | +429 | +53.6 |
| TIED UP BY THE SUM | 10 | 10 | 8 | 2.67 | +144 | +18.0 |
| TIME ON OUR SIDE | 119 | 101 | 8 | 2.67 | +2 | +0.2 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| IDLE COST | 53 | 43 | 7 | 2.33 | +63 | +9.0 |
| LANE BY FIGURES | 7 | 7 | 7 | 2.33 | +300 | +42.8 |
| RANDOM MOVE BY FIGURES | 13 | 13 | 7 | 2.33 | +276 | +39.5 |
| HOLDS AMBUSHERS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CHAFF IN THE MOVE | 5 | 5 | 5 | 1.67 | +17 | +3.3 |
| PROMISE KNOWS THE FIGHT | 16 | 15 | 5 | 1.67 | -4 | -0.9 |
| WHOLE FIGHT DANGER | 26 | 25 | 5 | 1.67 | +680 | +136.0 |
| EXACT ROUND | 20 | 18 | 4 | 1.33 | +6 | +1.6 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +525 | +131.3 |
| HARD STAY DROPPED | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SET UP BY THE SET | 16 | 15 | 4 | 1.33 | +234 | +58.5 |
| SHOTS AFTER THE MOVES | 13 | 13 | 4 | 1.33 | +0 | +0.0 |
| SUPPORT ADDS | 13 | 13 | 4 | 1.33 | +136 | +34.0 |
| SUPPORT WORKED OUT | 13 | 13 | 4 | 1.33 | +136 | +34.0 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 1.00 | +45 | +14.9 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +61 | +20.2 |
| REDIRECT COUNTER | 10 | 10 | 3 | 1.00 | +126 | +42.0 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +6 | +2.0 |
| CANNON PLANNED TARGET | 12 | 12 | 2 | 0.67 | -4 | -1.8 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | -1 | -0.3 |
| CHARGE LIST READ AGAIN | 2 | 2 | 2 | 0.67 | +407 | +203.5 |
| CHARGE NOW FIRST | 12 | 12 | 2 | 0.67 | -43 | -21.4 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FALLS SHORT | 53 | 43 | 2 | 0.67 | +9 | +4.5 |
| GOAL ON TIME | 2 | 2 | 2 | 0.67 | -124 | -62.1 |
| JOINT ON THE TABLE | 2 | 2 | 2 | 0.67 | +381 | +190.3 |
| MARCH CHECK | 2 | 2 | 2 | 0.67 | +27 | +13.5 |
| MAX FOR POSITIONING | 13 | 12 | 2 | 0.67 | +0 | +0.0 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +32 | +16.1 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.67 | -29 | -14.3 |
| PROMISE READS THE TABLE | 2 | 2 | 2 | 0.67 | +12 | +5.9 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +150 | +74.8 |
| SHOTS IN THE MOVE | 47 | 30 | 2 | 0.67 | +47 | +23.7 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +0 | +0.1 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 2 | 2 | 2 | 0.67 | +2 | +1.2 |
| WHO FIGHTS | 10 | 10 | 2 | 0.67 | +4 | +2.1 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +61 | +60.7 |
| BACKUP TARGETS | 4 | 2 | 1 | 0.33 | +3 | +2.6 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -53 | -52.6 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 23 | 22 | 1 | 0.33 | +1 | +1.4 |
| FEATURE BUFFS | 13 | 13 | 1 | 0.33 | +133 | +132.6 |
| FIGHT TO THE END | 9 | 8 | 1 | 0.33 | +3 | +2.8 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.33 | +6 | +6.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +24 | +23.8 |
| HIS TURN DENIED | 6 | 6 | 1 | 0.33 | +17 | +16.7 |
| HONEST WORTH | 28 | 27 | 1 | 0.33 | +1 | +0.9 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +15 | +15.0 |
| MANOEUVRE | 8 | 8 | 1 | 0.33 | +72 | +72.2 |
| MISSILES IN THE MOVE | 19 | 11 | 1 | 0.33 | +2 | +1.7 |
| MISSILES NEXT TURN | 21 | 15 | 1 | 0.33 | +0 | +0.3 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| NEARER NOT NEEDED | 32 | 32 | 1 | 0.33 | +31 | +30.8 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.33 | +2 | +1.7 |
| ONE FIGHT FORMULA | 37 | 22 | 1 | 0.33 | +0 | +0.0 |
| ONE JOINT FIGURE | 3 | 3 | 1 | 0.33 | +136 | +136.2 |
| ONE OBJECTIVE FORMULA | 26 | 14 | 1 | 0.33 | +117 | +116.7 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +98 | +97.6 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +38 | +38.4 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +17 | +17.4 |
| SEARCH SPOT | 3 | 3 | 1 | 0.33 | +9 | +8.9 |
| SHOOTS FROM THE BEST SPOT | 10 | 10 | 1 | 0.33 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 20 | 1 | 1 | 0.33 | +0 | +0.0 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO GETS IN | 1 | 1 | 1 | 0.33 | -113 | -112.8 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +74 | +74.4 |
| WHOLE FIGHT GAIN | 2 | 2 | 1 | 0.33 | +113 | +113.3 |
| BLOWS WHERE AIMED | 2 | 2 | 0 | 0.00 | - | - |
| CAST JOB | 7 | 7 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 67 | 67 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 46 | not checked | - | - | - | - |
| FOOT FIRST | 63 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 20 | 20 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 5 | 3 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GUN MASK | 4 | 4 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 12 | 12 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 58 | 53 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 38 | 38 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 37 | 33 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 18 | 18 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 32 | 29 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 55 | 50 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 25 | 22 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 8 | 8 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 94 | 94 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| KEPT FROM ITS LAST STOP | 8 | 8 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 20 | 18 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| NEAREST TO GOAL | 8 | 8 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 23 | 22 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 7 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP | 3 | 3 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 6 | 6 | 0 | 0.00 | - | - |
| PLAN RESULT | 253 | trace | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 13 | 11 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 7 | 7 | 0 | 0.00 | - | - |
| RUN DOWN | 20 | 19 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 5 | 5 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 34 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 7 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 51 | 45 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 5 | 5 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 4 | 4 | 0 | 0.00 | - | - |
| STANDS STILL | 154 | 149 | 0 | 0.00 | - | - |
| STAY WORTH | 53 | 44 | 0 | 0.00 | - | - |
| STOPS | 1 | not checked | - | - | - | - |
| STUPIDITY NEXT TURN | 7 | 7 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 11 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 4 | not checked | - | - | - | - |
| THE TABLE BINDS | 242 | not checked | - | - | - | - |
| WAITS AGAIN | 16 | 14 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | not checked | - | - | - | - |
| WHOLE FIGHT | 1 | not checked | - | - | - | - |
| WOUNDS ON THE RANKS | 11 | 11 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p21

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 6.33 | 4.00 | 98.0 |
| JOB FIRST | gate | 5.33 | 1.67 | 34.9 |
| ARMY TABLE | rule | 2.67 | 1.33 | 95.5 |
| ONE PROMISE A TARGET | rule | 1.67 | 1.33 | 112.5 |
| RULE SWITCHED OFF | gate | 2.33 | - | 68.0 |
| JOINT CHARGE NOW | rule | 1.00 | 1.00 | 81.6 |
| PROMISE KNOWS THE FIGHT | rule | - | 1.00 | 1.4 |
| CHARGE NOW FIRST | rule | 0.33 | 0.33 | 21.4 |
| GOAL ON TIME | rule | - | 0.67 | 62.1 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.33 | 3.9 |
| PIVOT GUARDS FLANK | rule | 0.67 | - | 14.3 |
| AFTERMATH BAND | gate | 0.33 | - | 3.8 |
| BEST PRIZE | rule | - | 0.33 | 52.6 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 3.6 |
| CHAFF PASSED | rule | 0.33 | - | 0.6 |
| NO REASON | gate | - | 0.33 | 12.7 |
| SWIFTSTRIDE BY POINTS | rule | 0.33 | - | 1.3 |
| WHO GETS IN | rule | - | 0.33 | 112.8 |

### Plans: gs3-83c8646-p21

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.3 | 60% | 353 | 264 | 75% |
| Mine | move | 32.0 | 96% | 1973 | 0 | 0% |
| Mine | shoot | 5.7 | 41% | 559 | 265 | 47% |
| Mine | support | 0.3 | 100% | 13 | 0 | 0% |
| Opponent | charge | 4.0 | 50% | 532 | 204 | 38% |
| Opponent | join | 2.7 | 100% | 63 | 0 | 0% |
| Opponent | move | 35.3 | 93% | 1607 | 0 | 0% |
| Opponent | shoot | 0.3 | 100% | 42 | 42 | 100% |
| Opponent | support | 0.7 | 100% | 0 | 0 | - |

### Packages: hunt the guns, gs3-83c8646-p21

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.3 | 1 | 0 | 0% | 0% | 0% | - | 262 | 0 | 0% | 0 |
| Opponent | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 1.0 | 1 | 0 | 0% | 0% | 0% | - | 262 | 0 | 0% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: gs3-83c8646-p21

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.7 | 40% | 50% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 1.7 | 40% | 100% | 0% | - | 0% | 0% | 50% | 50% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p21

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | 0 (3) | - | - | 0 (3) | - |
| Mine | Chaff | 2 | 188 (2) | 0 | 188 | 50 | 0% | 1.5 | 375 (1) | 0 (1) | - | 375 (1) | 0 (1) |
| Mine | Character | 8 | 46 (8) | 46 | 0 | 0 | 0% | 2.6 | 16 (4) | 94 (3) | 55 (1) | 42 (5) | 58 (3) |
| Mine | Clean-up | 1 | 126 (1) | 0 | 126 | 0 | 100% | - | 126 (1) | - | - | 126 (1) | - |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 4 | 0 (4) | 0 | 0 | 46 | 25% | 3.0 | 0 (3) | 0 (1) | - | 0 (3) | 0 (1) |
| Mine | Hammer | 3 | 8 (3) | 4 | 4 | 26 | 33% | 2.0 | 16 (1) | 6 (2) | - | 16 (1) | 6 (2) |
| Mine | Shooter | 6 | 13 (6) | 0 | 13 | 19 | 0% | 2.0 | 0 (3) | 32 (3) | - | 27 (3) | 0 (3) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 0% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | - | - | 0 (1) | 0 (1) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 3.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 5 | 30 (5) | 30 | 0 | 17 | 40% | 4.0 | 0 (2) | 48 (3) | - | 0 (1) | 36 (4) |
| Opponent | Character | 10 | 2 (10) | 2 | 0 | 48 | 40% | 4.3 | 0 (4) | 6 (4) | 0 (1) | 5 (6) | 0 (3) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 6 | 15 (6) | 13 | 2 | 30 | 33% | 3.5 | 23 (3) | 5 (3) | - | 26 (4) | 0 (2) |
| Opponent | Hammer | 5 | 25 (5) | 0 | 25 | 18 | 40% | 2.0 | 39 (3) | 0 (2) | - | 31 (4) | 0 (1) |
| Opponent | Holder | 4 | 34 (4) | 15 | 18 | 17 | 50% | 4.0 | 37 (2) | 29 (2) | - | 74 (1) | 17 (3) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 13 | 0% | 3.3 | 0 (1) | 0 (1) | 0 (1) | 0 (1) | 0 (2) |

### Charged fights: gs3-83c8646-p21

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 1 | 0 | 809 | 3.0 | 1.0 | 270 | 0 | +270 | 2 of 3 | 3 of 3 | - | +270 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 582 | 4.0 | 1.2 | 146 | 0 | +146 | 0 of 4 | 4 of 4 | +122 | +153 |
| Mine | Lizardmen | 1 | 0 | 105 | 4.0 | 1.5 | 26 | 44 | -18 | 0 of 4 | 4 of 4 | -115 | +15 |
| **Mine** | all armies | 3 | 0 | 499 | 3.7 | 1.3 | 136 | 16 | +120 | 2 of 11 | 11 of 11 | +4 | +146 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 5.0 | 1.0 | 0 | 0 | +0 | 0 of 5 | 2 of 5 | - | +0 |
| Opponent | Warriors of Chaos | 2 | 0 | 103 | 1.5 | 1.3 | 69 | 0 | +69 | 0 of 3 | 3 of 3 | +126 | +40 |
| **Opponent** | all armies | 3 | 0 | 69 | 2.7 | 1.1 | 26 | 0 | +26 | 0 of 8 | 5 of 8 | +126 | +11 |

### Effective charges: gs3-83c8646-p21

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 3 | 0 | 0 | 0 | 0 | 1 (net +116) | 1 (net +693) | 1 | 0% (0 of 2) |
| Mine | Kingdom of Bretonnia | 4 | 0 | 0 | 0 | 0 | 2 (net +104) | 2 (net +188) | 0 | 0% (0 of 4) |
| Mine | Lizardmen | 4 | 0 | 0 | 0 | 0 | 1 (net -115) | 0 | 3 | 0% (0 of 1) |
| Opponent | Vampire Counts | 5 | 3 (net +0) | 0 | 0 | 1 (net +0) | 0 | 1 (net +0) | 0 | 0% (0 of 5) |
| Opponent | Warriors of Chaos | 3 | 0 | 0 | 1 (net +0) | 0 | 0 | 2 (net +103) | 0 | 33% (1 of 3) |

### Charged fights, damage counted: gs3-83c8646-p21

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 381 | 192 | +356 | 356 | 0 | +356 | +93.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 600 | 96 | +52 | 107 | 44 | +64 | +10.6 |
| Mine | No odds | 4 | 200 | 119 | +11 | 36 | 4 | +31 | +15.7 |
| Mine | All fights | 11 | 395 | 130 | +120 | 149 | 17 | +132 | +33.3 |
| Opponent | Long shot (under 50%) | 3 | 95 | 106 | +0 | 8 | 0 | +8 | +8.4 |
| Opponent | Effective (55-75%) | 1 | 365 | 275 | +0 | 0 | 158 | -158 | -43.4 |
| Opponent | 76-89% | 1 | 186 | 175 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 159 | 127 | +69 | 69 | 4 | +65 | +40.8 |
| Opponent | All fights | 8 | 164 | 144 | +26 | 29 | 21 | +7 | +4.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p21 | move | 33 | 10 (30%) | 8 (24%) | 3 (9%) | 20 (61%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1727 |
| Invocation of Nehek | Opponent | L1727 |
| Ring of Doom | Mine | L1531 |
| Ring of Doom | Opponent | L1531 |

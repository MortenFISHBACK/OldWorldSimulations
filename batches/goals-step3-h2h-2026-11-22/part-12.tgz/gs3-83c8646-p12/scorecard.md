# Doctrine scorecard: gs3-83c8646-p12

### Scorecard: gs3-83c8646-p12

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2531 | 5 | 1 | Mine | no | - | 5 | 2 | 3 | 0 | 0 | 0 | 211 |
| L2531 | 5 | 1 | Opponent | yes | - | 1 | 1 | 2 | 1 | 0 | 0 | 170 |
| L2730 | 6 | 1 | Mine | no | 3 | 2 | 7 | 1 | 0 | 0 | 0 | 60 |
| L2730 | 6 | 1 | Opponent | no | 2 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L2934 | 6 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| **Average** | | | Mine | 0% | 3.0 | 3.5 | 4.5 | 2.0 | 0.0 | 0.0 | 0.0 | 135.5 |
| **Average** | | | Opponent | 50% | 2.0 | 1.5 | 2.0 | 1.5 | 0.5 | 0.0 | 0.0 | 85.0 |

### KPIs: gs3-83c8646-p12

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 13) | 0% (0 of 12) | 0% (0 of 25) |
| Winner chose to follow up after the loser gave ground |  | 83% (5 of 6); on the table 83% | 100% (5 of 5); on the table 100% | 91% (10 of 11); on the table 91% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 86% (6 of 7); on the table 86% | 100% (5 of 5); on the table 100% | 92% (11 of 12); on the table 92% |
| Magic missiles tried each own turn | 50%+ | 50% (3 of 6) | 33% (2 of 6) | 42% (5 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 100% (3 of 3) | 33% (2 of 6) | 56% (5 of 9) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 0% (0 of 2) | 67% (6 of 9) | 55% (6 of 11) |
| Points that never fought | lower | 18% (720 of 3999) | 23% (909 of 4000) | 20% (1629 of 7999) |
|   infantry points that never fought | lower | 68% (310 of 457) | 57% (316 of 559) | 62% (626 of 1016) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 58% (7 of 12) | 72% (13 of 18) | 67% (20 of 30) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (1 of 1); 0.7 uses a game | 100% (1 of 1); 0.3 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 50% (1592 of 3154) | 64% (2324 of 3654) | 58% (3916 of 6808) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (100%) | 1.3 (57%) |
| GONE: slain | 1.0 (100%) | 0.0 (0%) | 1.0 (43%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.0 | 2.0 | 1.7 | 1.7 | 0.3 | 0.7 |
| not cast | 3.0 | 0.0 | 2.3 | 2.3 | 1.7 | 20.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | - | 0.3 (14%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | - | 0.0 (0%) | 1.3 (57%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | - | 1.0 (43%) | 1.0 (43%) | 1.0 (60%) | 3.3 (16%) |
| STUPIDITY: Stupidity | 0.3 (11%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.7 (40%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.7 (89%) | - | 1.0 (43%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.3 (80%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.7 a game | 0.0 a game | 0.8 a game |
| stood (cast and not dispelled) | 80% (4 of 5) | - | 80% (4 of 5) |
| the unit moved after it | 100% (4 of 4) | - | 100% (4 of 4) |
| it charged on its next turn | 0% (0 of 4) | - | 0% (0 of 4) |
| the enemy charged it first | 0% (0 of 4) | - | 0% (0 of 4) |
| it fought by the end of its next turn | 0% (0 of 4) | - | 0% (0 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 4) | - | 0% (0 of 4) |
| none of these (no charge, no fight, no charge escaped) | 100% (4 of 4) | - | 100% (4 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | - | 0% (0 of 5) | 0% (0 of 5) |
|   character | - | 0% (0 of 5) | 0% (0 of 5) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| CHARGED: it charged | - | 1.3 (80%) | 1.3 (80%) |
| NO TARGET IN RANGE | - | 0.3 (20%) | 0.3 (20%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 3.3 | 3.2 |
| Charges that made contact a game | 2.7 | 3.0 | 2.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | - | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.67 declared, 0.67 contact (3 units) | 0.00 declared, 0.00 contact (1 units) | 0.50 declared, 0.50 contact (4 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.29 declared, 0.25 contact (24 units) | 0.40 declared, 0.36 contact (25 units) | 0.35 declared, 0.31 contact (49 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 80% (4 of 5) | 67% (2 of 3) | 0% (0 of 1) | 67% (6 of 9) |
| Character in a unit | 80% (4 of 5) | 100% (1 of 1) | 0% (0 of 1) | 71% (5 of 7) |
| Character on its own | 50% (1 of 2) | 100% (2 of 2) | 33% (1 of 3) | 57% (4 of 7) |
| Infantry | 75% (3 of 4) | - | - | 75% (3 of 4) |
| Monster | 50% (1 of 2) | 100% (1 of 1) | - | 67% (2 of 3) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vampire Counts | 2 | 86% (6 of 7); on the table 86% | 50% (3 of 6) | 18% | 58% (7 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | 100% (5 of 5); on the table 100% | 33% (2 of 6) | 23% | 72% (13 of 18) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p12, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 33% (2) | 75% (6) | 57% (8) |
| ...free all their last turn and able to turn (per game) | 0.33 | 1.33 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.33 | 0.67 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.67 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.33 | 0.00 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: gs3-83c8646-p12

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 71% (5 of 7) | 75% (6 of 8) |
| Strategy | Shoot objectives carried out (shot that target) | - | 33% (1 of 3) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 40% (2 of 5) | 100% (4 of 4) |
| Strategy | Lone characters that fought | 100% (6 of 6) | 75% (3 of 4) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 2.0 | 1.5 |
| Movement | Points that never moved of their own | 135.5 | 85.0 |
| Movement | Fights charged into per game | 4.0 | 3.5 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 7, net -290 | 2 of 6, net -33 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 7, net +0 | 1 of 6, net +254 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 7 | 2 of 6, net +60 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 7, net +0 | 0 of 6 |
| Shooting | Shots by shooting units (incl. breath weapons) | - | 0.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | - | 100% (1 of 1) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.7 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 2) | - |
| Magic | Wounds caused by other spells | 1.0 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.3 / 0.0 / 0.7 / 0.3 | 0.0 / 1.7 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 56.7 | 446.3 |
| Combat | Points run down | 32.7 | 0.0 |
| Combat | Net points per charged fight, damage counted | -12 | +59 |
| Combat | Net per 100 charger points, damage counted | -6.5 | +19.9 |
| Combat | First round won (charged fights) | 62% | 57% |
| Combat | Net points per charged fight | -72 | +74 |
| Combat | Net points per supported fight / lone fight | - / -72 | -66 / +97 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 8 | 3 of 7 |
| Game | Points lost | 746.5 | 192.0 |
| Game | VP from objectives | 430.0 | 870.0 |
| Game | Lone holders (player turns) | 3.0 | 2.0 |

- Mine won / drew / lost: 0 / 1 / 1 of 2 ended games (of 3); mean margin (Mine - Opponent) -907 VP
- The side that went first won 0 of 1 games with a winner
- Points traded per game (both sides' losses): 938
- Games not ended: 1 (L2934-1); findings 2, warnings 0

### Opponent rules: gs3-83c8646-p12

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +35.3 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 23.0 | +182.2 | 0.0 | 217.7 | 15.7 | +259.2 | 0.0 | 0.0 |
| ASSAILMENT BY POINTS | 0.7 | +2.0 | 0.0 | 263.7 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 0.3 | +3.0 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -24.5 | 0.0 | 38.7 |
| CAST JOB | - | - | - | - | 1.3 | +9.3 | 49.0 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.3 | +0.0 | 0.0 | 70.3 | - | - | - | - |
| CASTS FROM BEHIND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.7 | +12.3 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +2.4 | 0.0 | 84.7 | 1.0 | +6.7 | 0.0 | 38.7 |
| CHARGE LOSSES | 11.7 | -493.0 | 0.0 | 84.7 | 4.7 | -104.6 | 0.0 | 122.0 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 62.0 | 0.0 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 32.7 | 193.3 | 1.7 | +0.0 | 40.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 13.7 | +0.0 | 0.0 | 158.0 | 4.7 | +0.0 | 0.0 | 32.7 |
| COMBAT PIVOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 1.7 | +47.4 | 0.0 | 70.3 | - | - | - | - |
| COVER ONCE | 8.0 | -656.4 | 0.0 | 294.7 | 6.0 | -348.8 | 0.0 | 65.3 |
| DEPLOY BY FIGURES | 7.0 | +107.4 | 0.0 | 15.0 | 7.3 | -37.6 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -123.2 | 0.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +54.6 | 84.7 | 0.0 |
| EXACT ROUND | 2.0 | +16.9 | 71.3 | 16.7 | 2.7 | +2.1 | 201.7 | 38.7 |
| FACES THE THREAT | 0.3 | +0.0 | 0.0 | 70.3 | - | - | - | - |
| FALL BACK GOOD ORDER | 3.0 | +7.2 | 71.3 | 210.0 | 3.0 | +0.0 | 139.7 | 38.7 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | 22.0 | +304.2 | 0.0 | 435.3 | - | - | - | - |
| FEATURE BUFFS | - | - | - | - | 1.3 | +15.9 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.0 | +26.5 | 0.0 | 0.0 | 0.3 | +3.1 | 0.0 | 0.0 |
| FIVE ACTION | 64.3 | +4126.4 | 71.3 | 927.3 | 65.3 | +4726.6 | 250.7 | 282.7 |
| FLANK NOT WEIGHED | 6.0 | +0.0 | 0.0 | 210.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 1.3 | +326.7 | 0.0 | 0.0 | 1.0 | +96.2 | 0.0 | 38.7 |
| FOOT FIRST | - | - | - | - | 18.3 | +0.0 | 0.0 | 65.3 |
| FOUR ROUNDS | 3.0 | +338.6 | 71.3 | 210.0 | 3.3 | +326.2 | 201.7 | 38.7 |
| FREED FROM HIS FIGHT | 2.7 | +0.0 | 0.0 | 386.7 | 6.0 | +0.0 | 0.0 | 0.0 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -9.8 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -2.7 | 0.0 | 0.0 | - | - | - | - |
| GOAL ROUTE | - | - | - | - | 0.3 | +3.2 | 0.0 | 0.0 |
| GOAL WALK | 7.7 | +603.7 | 0.0 | 0.0 | 14.0 | +948.9 | 0.0 | 0.0 |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 70.3 | 2.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 5.0 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 6.0 | +0.0 | 0.0 | 84.7 | 3.7 | +0.0 | 0.0 | 122.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +6.1 | 15.0 | 0.0 |
| HIS CHARGE LIST | 2.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 1.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 1.3 | -11.3 | 0.0 | 0.0 | - | - | - | - |
| HIS ONE QUARTER | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 3.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 13.7 | +0.0 | 0.0 | 687.3 | 5.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVER COMES | 4.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 4.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 26.7 | +351.2 | 0.0 | 602.7 | 5.3 | +79.9 | 0.0 | 0.0 |
| HIS SHOTS BY HIS RUN | 27.7 | +174.8 | 0.0 | 488.0 | 6.7 | +34.7 | 0.0 | 56.7 |
| HOLD ODDS | 10.0 | +0.0 | 0.0 | 0.0 | 19.0 | +0.0 | 0.0 | 130.7 |
| HOLDER ASSIGNMENT | 6.7 | +629.6 | 0.0 | 0.0 | 10.7 | +1092.2 | 0.0 | 65.3 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.0 | -135.2 | 71.3 | 210.0 | 3.3 | -113.9 | 201.7 | 38.7 |
| IDLE COST | 12.0 | -186.9 | 0.0 | 204.7 | - | - | - | - |
| JOINT CHARGE NOW | 0.3 | +1.1 | 0.0 | 0.0 | 0.7 | +88.4 | 0.0 | 38.7 |
| KEEP FALLS | - | - | - | - | 0.3 | +6.2 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.0 | +42.8 | 0.0 | 0.0 | 0.7 | +13.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.3 | +0.0 | 95.3 | 365.0 | 3.3 | +0.0 | 235.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.3 | +0.2 | 62.0 | 0.0 |
| LOST AFTER ESCAPE | 2.7 | +27.4 | 38.7 | 210.0 | 1.0 | -9.0 | 15.0 | 0.0 |
| LOST CHARGE | - | - | - | - | 0.3 | -2.7 | 84.7 | 0.0 |
| LURE BY WHAT IT DRAWS | 0.7 | -126.1 | 0.0 | 50.0 | - | - | - | - |
| MANOEUVRE | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.7 | +7.8 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 1.3 | +28.9 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.7 | +30.7 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | +34.1 | 0.0 | 70.3 | 1.3 | -75.0 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.0 | +282.4 | 0.0 | 225.0 | 1.0 | +7.7 | 0.0 | 0.0 |
| MEETS IN TIME | 3.7 | +311.9 | 0.0 | 0.0 | 3.3 | +260.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 0.7 | +1.6 | 0.0 | 70.3 | 2.0 | +33.9 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 1.0 | +1.7 | 0.0 | 140.7 | 3.3 | +32.5 | 0.0 | 0.0 |
| MOVE ORDER | 2.0 | +0.0 | 0.0 | 193.3 | 2.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 4.7 | +262.0 | 0.0 | 386.7 | 5.0 | +634.1 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.7 | +262.8 | 0.0 | 0.0 | 6.3 | +253.7 | 0.0 | 32.7 |
| NEAREST TO GOAL | - | - | - | - | 3.3 | +0.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 4.0 | +214.3 | 0.0 | 0.0 | 2.7 | +360.5 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.0 | -82.2 | 32.7 | 193.3 | 2.0 | -89.9 | 124.7 | 38.7 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 4.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 4.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT WORTH A CAST | 0.7 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 4.3 | -91.5 | 32.7 | 25.0 | 3.3 | -186.4 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.7 | -49.9 | 0.0 | 225.0 | 2.3 | -40.2 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 0.3 | +1.5 | 0.0 | 0.0 | 0.3 | +8.2 | 0.0 | 38.7 |
| ONE OBJECTIVE FORMULA | 2.7 | -4.8 | 0.0 | 0.0 | 5.0 | -10.2 | 0.0 | 65.3 |
| ONE PROMISE A TARGET | 0.7 | -39.1 | 0.0 | 0.0 | 0.3 | -95.3 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 4.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 1.0 | +59.6 | 40.0 | 0.0 |
| OVERRUNS AWAY | 0.3 | +3.4 | 38.7 | 16.7 | 0.3 | +1.5 | 84.7 | 0.0 |
| PATHS CROSS | 0.7 | +18.6 | 0.0 | 0.0 | 0.3 | +25.1 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -0.4 | 0.0 | 0.0 |
| PLAN RESULT | 32.3 | +64.8 | 38.7 | 844.0 | 28.7 | +240.5 | 146.7 | 256.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 32.7 |
| PROMISE BY ITS OWN SUM | 7.0 | -175.6 | 0.0 | 386.7 | 8.3 | -500.7 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| QUARTER ODDS | 3.7 | +461.1 | 0.0 | 193.3 | 7.7 | +1025.0 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.7 | +0.0 | 0.0 | 0.0 | 3.0 | +78.3 | 0.0 | 113.3 |
| REAL GROUND | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | -9.1 | 0.0 | 0.0 |
| REDIRECT COUNTER | 5.0 | +139.6 | 0.0 | 55.0 | 1.3 | +81.3 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 0.7 | +0.0 | 0.0 | 15.0 | 1.3 | +5.1 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.3 | -84.6 | 0.0 | 0.0 | 1.7 | -37.2 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 16.7 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +10.7 | 0.0 | 0.0 |
| RISK BY ARC | 2.3 | +102.2 | 71.3 | 210.0 | 3.3 | +186.1 | 201.7 | 38.7 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 1.7 | -22.1 | 38.7 | 210.0 | - | - | - | - |
| RUN DOWN | 3.0 | -37.6 | 71.3 | 210.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | 2.0 | -110.3 | 0.0 | 30.0 | - | - | - | - |
| SEARCH SPOT | 0.7 | +31.0 | 0.0 | 0.0 | 0.7 | +33.8 | 0.0 | 0.0 |
| SECOND LOOK | 0.7 | +20.1 | 32.7 | 0.0 | 0.7 | +90.4 | 62.0 | 0.0 |
| SET CREDITED ONCE | 1.0 | -18.5 | 0.0 | 116.3 | 0.3 | -0.5 | 0.0 | 32.7 |
| SET UP BY THE SET | 3.0 | -27.5 | 0.0 | 116.3 | 1.3 | -5.6 | 0.0 | 32.7 |
| SET-UP ANY TARGET | 0.3 | +46.8 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 1.0 | +0.0 | 0.0 | 155.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 0.7 | +18.5 | 0.0 | 0.0 |
| SHOT RISK POINTS | 11.0 | -58.8 | 0.0 | 118.0 | 3.7 | -3.8 | 0.0 | 56.7 |
| SHOTS AFTER THE MOVES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | - | - | - | - | 3.0 | +25.8 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.3 | +46.8 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 3.0 | +15.0 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 7.3 | +0.0 | 0.0 | 621.7 | 7.3 | +0.0 | 0.0 | 32.7 |
| STANDS STILL | 9.0 | +0.0 | 0.0 | 33.3 | 24.7 | +0.0 | 49.0 | 146.0 |
| STAY WORTH | - | - | - | - | 4.3 | +30.6 | 49.0 | 0.0 |
| STUCK PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | 2.7 | +0.0 | 0.0 | 386.7 | - | - | - | - |
| SUPPORT ADDS | 15.0 | +2392.5 | 0.0 | 589.3 | 4.3 | +189.8 | 0.0 | 0.0 |
| SUPPORT NARROWED | 1.0 | +0.0 | 38.7 | 210.0 | 0.3 | +0.0 | 62.0 | 0.0 |
| SUPPORT WORKED OUT | 15.0 | +2392.5 | 0.0 | 589.3 | 4.3 | +189.8 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.7 | +0.0 | 0.0 | 84.7 | 4.7 | +0.0 | 0.0 | 32.7 |
| THE ROW KEEPS ITS WAY | 4.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 32.7 |
| THE STEP BACK IS MADE | 2.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 32.7 |
| THE TABLE AGAIN | 4.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 33.0 | +0.0 | 0.0 | 514.3 | 30.3 | +0.0 | 0.0 | 65.3 |
| TIED UP BY THE SUM | 0.7 | +46.6 | 32.7 | 0.0 | 1.3 | +196.4 | 40.0 | 0.0 |
| TIME ON OUR SIDE | - | - | - | - | 43.0 | +484.0 | 0.0 | 65.3 |
| WAITS AGAIN | 2.7 | +0.0 | 0.0 | 403.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 0.0 | 50.0 | - | - | - | - |
| WHAT THE JOINER ADDS | 0.7 | +10.7 | 77.3 | 33.3 | 0.7 | +27.9 | 124.0 | 0.0 |
| WHO FIGHTS | 0.7 | +17.1 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | 0.3 | +13.4 | 38.7 | 16.7 | 0.3 | -33.7 | 62.0 | 0.0 |
| WHOLE FIGHT DANGER | 4.0 | -408.3 | 0.0 | 0.0 | 2.3 | -94.3 | 0.0 | 65.3 |
| WOUNDS ON THE RANKS | 2.0 | +0.9 | 0.0 | 0.0 | - | - | - | - |

### Rule changes: gs3-83c8646-p12

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 116 | 116 | 75 | 25.00 | +1269 | +16.9 |
| HOLDER ASSIGNMENT | 52 | 52 | 47 | 15.67 | +2644 | +56.3 |
| GOAL WALK | 65 | 65 | 27 | 9.00 | +1703 | +63.1 |
| DEPLOY BY FIGURES | 43 | 43 | 24 | 8.00 | +122 | +5.1 |
| FIVE ACTION | 389 | 368 | 24 | 8.00 | +1057 | +44.0 |
| LEGAL CHARGES ONLY | 23 | 23 | 23 | 7.67 | +0 | +0.0 |
| OFF BEST | 23 | 23 | 23 | 7.67 | -833 | -36.2 |
| THE TABLE AGAIN | 28 | 28 | 22 | 7.33 | +0 | +0.0 |
| SUPPORT ADDS | 58 | 54 | 21 | 7.00 | +784 | +37.3 |
| SUPPORT WORKED OUT | 58 | 54 | 21 | 7.00 | +784 | +37.3 |
| HIS SHOT LIST | 96 | 88 | 19 | 6.33 | +153 | +8.1 |
| PROMISE BY ITS OWN SUM | 46 | 46 | 18 | 6.00 | -2029 | -112.7 |
| TIME ON OUR SIDE | 129 | 96 | 15 | 5.00 | +37 | +2.5 |
| MEETS IN TIME | 21 | 21 | 13 | 4.33 | +865 | +66.5 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 103 | 96 | 11 | 3.67 | +23 | +2.1 |
| FOUR ROUNDS | 19 | 16 | 10 | 3.33 | +485 | +48.5 |
| IDLE COST | 36 | 25 | 9 | 3.00 | +85 | +9.4 |
| MOVE TO CHARGE COMPUTED | 29 | 18 | 9 | 3.00 | +501 | +55.7 |
| NEXT CHARGE BY LIST | 20 | 16 | 9 | 3.00 | +520 | +57.8 |
| RISK BY ARC | 17 | 14 | 9 | 3.00 | +262 | +29.1 |
| HARD STAY DROPPED | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 7 | 7 | 7 | 2.33 | +1268 | +181.2 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| FALLS SHORT | 66 | 55 | 6 | 2.00 | +4 | +0.6 |
| HOLDS AMBUSHERS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 11 | 11 | 6 | 2.00 | +235 | +39.2 |
| COVER ONCE | 42 | 30 | 5 | 1.67 | +55 | +11.0 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +170 | +33.9 |
| MAX FOR POSITIONING | 18 | 17 | 5 | 1.67 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 6 | 6 | 5 | 1.67 | +1 | +0.1 |
| TIED UP BY THE SUM | 6 | 5 | 5 | 1.67 | +150 | +29.9 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +28 | +6.9 |
| CHARGE NOW FIRST | 10 | 10 | 4 | 1.33 | -329 | -82.3 |
| MARCH BY THE SUM | 4 | 4 | 4 | 1.33 | +87 | +21.7 |
| SECOND LOOK | 4 | 4 | 4 | 1.33 | +332 | +82.9 |
| SET UP BY THE SET | 13 | 13 | 4 | 1.33 | +178 | +44.4 |
| SUPPORT NARROWED | 4 | 4 | 4 | 1.33 | -489 | -122.2 |
| CAST JOB | 4 | 4 | 3 | 1.00 | +14 | +4.8 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| EXACT ROUND | 14 | 12 | 3 | 1.00 | +22 | +7.4 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | +268 | +89.5 |
| ONE FIGHT FORMULA | 18 | 12 | 3 | 1.00 | +4 | +1.2 |
| ONE PROMISE A TARGET | 3 | 3 | 3 | 1.00 | -403 | -134.4 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +131 | +43.8 |
| QUARTER ODDS | 34 | 34 | 3 | 1.00 | +596 | +198.5 |
| SEARCH SPOT | 4 | 4 | 3 | 1.00 | +194 | +64.8 |
| ASSAILMENT BY POINTS | 2 | 2 | 2 | 0.67 | +6 | +3.0 |
| CHAFF IN THE MOVE | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -92 | -46.0 |
| REDIRECT COUNTER | 19 | 17 | 2 | 0.67 | +32 | +16.1 |
| SHOOTS FROM THE BEST SPOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHOT RISK POINTS | 44 | 40 | 2 | 0.67 | +11 | +5.5 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| WAR ENGINE JOBS | 2 | 2 | 2 | 0.67 | -18 | -8.9 |
| WHAT THE JOINER ADDS | 4 | 2 | 2 | 0.67 | +41 | +20.3 |
| WHOLE FIGHT DANGER | 19 | 19 | 2 | 0.67 | +16 | +8.2 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +106 | +105.8 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE LOSSES | 49 | 45 | 1 | 0.33 | +42 | +41.5 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -201 | -201.4 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +58 | +57.7 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FIGHT TO THE END | 4 | 3 | 1 | 0.33 | +16 | +15.9 |
| GOAL ROUTE | 1 | 1 | 1 | 0.33 | +10 | +9.6 |
| HONEST WORTH | 19 | 16 | 1 | 0.33 | +2 | +2.5 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +26 | +26.0 |
| MANOEUVRE | 5 | 5 | 1 | 0.33 | +2 | +1.7 |
| NO DOUBLE ROUNDS | 12 | 10 | 1 | 0.33 | +29 | +28.7 |
| OPENS UP | 3 | 3 | 1 | 0.33 | +2 | +1.8 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -1 | -1.3 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +32 | +32.2 |
| SHOTS IN THE MOVE | 9 | 7 | 1 | 0.33 | +5 | +4.6 |
| STAY WORTH | 13 | 11 | 1 | 0.33 | +51 | +50.9 |
| THE ROW IN ITS ORDER | 22 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT | 2 | 1 | 1 | 0.33 | +20 | +20.3 |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 4 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 55 | 55 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 5 | not checked | - | - | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 18 | 16 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 34 | not checked | - | - | - | - |
| FOOT FIRST | 55 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 26 | 20 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 15 | 11 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 29 | 26 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 19 | 19 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 11 | 11 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 4 | 4 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 8 | 8 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 21 | 18 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 57 | 51 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 13 | 13 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 27 | 27 | 0 | 0.00 | - | - |
| HOLD ODDS | 87 | 87 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 12 | 12 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | not checked | - | - | - | - |
| LOST AFTER ESCAPE | 11 | 10 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 8 | 3 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 13 | 5 | 0 | 0.00 | - | - |
| NEARER NOT NEEDED | 39 | 34 | 0 | 0.00 | - | - |
| NEAREST TO GOAL | 10 | 10 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 28 | 28 | 0 | 0.00 | - | - |
| NO SECOND RUN | 28 | 28 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 2 | 1 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 23 | 18 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 28 | 28 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 183 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 6 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 9 | 7 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 2 | 2 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 5 | 5 | 0 | 0.00 | - | - |
| RUN DOWN | 9 | 7 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 7 | not checked | - | - | - | - |
| SHOTS AFTER THE MOVES | 1 | 1 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 9 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 44 | 39 | 0 | 0.00 | - | - |
| STANDS STILL | 101 | 95 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 8 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 6 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 17 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 11 | not checked | - | - | - | - |
| THE TABLE BINDS | 190 | not checked | - | - | - | - |
| WAITS AGAIN | 12 | 8 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 6 | 6 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p12

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.00 | 2.67 | 37.0 |
| PROMISE BY ITS OWN SUM | rule | 2.33 | 3.67 | 112.7 |
| ARMY TABLE | rule | 2.33 | 1.33 | 63.8 |
| CHARGE NOW FIRST | rule | 0.67 | 0.67 | 82.3 |
| SUPPORT NARROWED | rule | 1.00 | 0.33 | 122.2 |
| ONE PROMISE A TARGET | rule | 0.67 | 0.33 | 134.4 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.33 | 53.1 |
| MARCH OF THE TABLE | rule | - | 0.67 | 46.0 |
| WAR ENGINE JOBS | rule | 0.67 | - | 8.9 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.33 | 10.1 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 201.4 |
| FALLBACK | gate | - | 0.33 | 5.6 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 1.3 |
| RULE SWITCHED OFF | gate | 0.33 | - | 77.1 |

### Plans: gs3-83c8646-p12

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 43% | 336 | 65 | 19% |
| Mine | join | 3.3 | 90% | 126 | 0 | 0% |
| Mine | move | 25.3 | 99% | 1816 | 0 | 0% |
| Mine | support | 1.3 | 50% | 0 | 0 | - |
| Opponent | charge | 2.7 | 62% | 368 | 192 | 52% |
| Opponent | join | 1.3 | 100% | 133 | 0 | 0% |
| Opponent | move | 23.7 | 97% | 1417 | 0 | 0% |
| Opponent | shoot | 1.0 | 33% | 74 | 49 | 66% |

### Battle groups: gs3-83c8646-p12

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 5.0 | 20% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 1.3 | 50% | 50% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p12

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 8 | 54 (8) | 0 | 54 | 33 | 62% | 2.3 | 0 (4) | 114 (2) | 111 (2) | 88 (5) | 0 (3) |
| Mine | Character | 7 | 16 (7) | 16 | 0 | 45 | 0% | 4.1 | 18 (2) | 14 (4) | 0 (1) | 18 (5) | 0 (2) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast Hammer | 4 | 36 (4) | 14 | 22 | 17 | 0% | 4.2 | - | 33 (3) | 53 (1) | 33 (3) | 53 (1) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 73 | 50% | 2.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 39 | 25% | 1.7 | 0 (2) | 0 (1) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | Chaff | 1 | 171 (1) | 0 | 171 | 0 | 0% | 5.0 | - | 171 (1) | - | 171 (1) | - |
| Opponent | Character | 8 | 62 (8) | 62 | 0 | 6 | 12% | 3.7 | 99 (2) | 54 (5) | 0 (1) | 50 (5) | 83 (3) |
| Opponent | Fast Hammer | 5 | 61 (5) | 0 | 61 | 11 | 20% | 3.2 | 70 (2) | 0 (1) | 86 (2) | 111 (2) | 36 (3) |
| Opponent | Hammer | 4 | 68 (4) | 63 | 5 | 27 | 0% | 4.5 | - | 68 (4) | - | 62 (2) | 75 (2) |
| Opponent | Holder | 4 | 0 (4) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | 0 (1) | 0 (1) | 0 (2) |

### Charged fights: gs3-83c8646-p12

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 2 | 0 | 0 | 4.0 | 1.0 | 0 | 72 | -72 | 3 of 8 | 5 of 8 | - | -72 |
| Opponent | Warriors of Chaos | 2 | 0 | 401 | 3.5 | 1.1 | 115 | 41 | +74 | 3 of 7 | 4 of 7 | -66 | +97 |

### Effective charges: gs3-83c8646-p12

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 8 | 2 (net -290) | 0 | 1 (net +0) | 1 (net +0) | 0 | 3 (net +0) | 1 | 14% (1 of 7) |
| Opponent | Warriors of Chaos | 7 | 2 (net -33) | 0 | 1 (net +254) | 1 (net +22) | 2 (net +60) | 0 | 1 | 17% (1 of 6) |

### Charged fights, damage counted: gs3-83c8646-p12

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 265 | 150 | -290 | 62 | 290 | -228 | -86.2 |
| Mine | Effective (55-75%) | 1 | 186 | 285 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 76-89% | 1 | 50 | 116 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 95 | 216 | +0 | 98 | 0 | +98 | +103.3 |
| Mine | No odds | 1 | 471 | 510 | +0 | 62 | 0 | +62 | +13.2 |
| Mine | All fights | 8 | 190 | 232 | -72 | 60 | 72 | -12 | -6.5 |
| Opponent | Long shot (under 50%) | 2 | 356 | 364 | -33 | 57 | 130 | -73 | -20.5 |
| Opponent | Effective (55-75%) | 1 | 116 | 254 | +254 | 254 | 0 | +254 | +219.0 |
| Opponent | 76-89% | 1 | 116 | 45 | +22 | 192 | 170 | +22 | +19.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 479 | 60 | +60 | 60 | 0 | +60 | +12.5 |
| Opponent | No odds | 1 | 173 | 186 | +186 | 186 | 23 | +163 | +94.2 |
| Opponent | All fights | 7 | 296 | 190 | +74 | 124 | 65 | +59 | +19.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p12 | move | 12 | 2 (17%) | 2 (17%) | 3 (25%) | 7 (58%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2531, L2730 |
| Charmed Shield | Opponent | L2934 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Ring of Doom | Opponent | L2531 |

# Doctrine scorecard: gs3-83c8646-p96

### Scorecard: gs3-83c8646-p96

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2634 | 6 | 1 | Mine | no | 4 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 2 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Mine | - | - | 2 | 3 | 3 | 0 | 0 | 0 | 292 |
| L2930 | 2 | 1 | Opponent | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 0 | 3 | 2 | 4 | 1 | 0 | 0 | 170 |
| L3234 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 2.0 | 2.3 | 2.0 | 2.7 | 0.3 | 0.0 | 0.0 | 154.0 |
| **Average** | | | Opponent | 0% | 1.0 | 2.0 | 3.3 | 2.7 | 0.0 | 0.0 | 0.0 | 0.0 |

### KPIs: gs3-83c8646-p96

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 16) | 0% (0 of 15) | 0% (0 of 31) |
| Winner chose to follow up after the loser gave ground |  | 100% (5 of 5); on the table 100% | 83% (5 of 6); on the table 83% | 91% (10 of 11); on the table 91% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | 50% (2 of 4); on the table 75% | 60% (3 of 5); on the table 80% |
| Winner chose to pursue after the loser fled |  | 20% (1 of 5); on the table 40% | 100% (1 of 1); on the table 100% | 33% (2 of 6); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 64% (7 of 11); on the table 73% | 73% (8 of 11); on the table 82% | 68% (15 of 22); on the table 77% |
| Magic missiles tried each own turn | 50%+ | 0% (0 of 6) | - | 0% (0 of 6) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 0% (0 of 2) | - | 0% (0 of 2) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 50% (9 of 18) | - | 50% (9 of 18) |
| Points that never fought | lower | 36% (2158 of 5998) | 26% (1551 of 5996) | 31% (3709 of 11994) |
|   infantry points that never fought | lower | 88% (865 of 985) | 41% (550 of 1349) | 61% (1415 of 2334) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 45% (9 of 20) | 41% (9 of 22) | 43% (18 of 42) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game | 100% (3 of 3); 0.5 uses a game |
|   their share of the points of units over 100 pts | lower | 41% (2300 of 5555) | 32% (1603 of 5066) | 37% (3903 of 10621) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.7 (33%) | - | 0.7 (33%) |
| IN COMBAT: engaged in combat | 0.3 (17%) | - | 0.3 (17%) |
| GONE: slain | 1.0 (50%) | - | 1.0 (50%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Assailments |
| --- | --- | --- | --- | --- |
| tried | 1.0 | 1.7 | 0.0 | 2.7 |
| not cast | 1.0 | 0.0 | 2.0 | 9.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | - | 0.0 (0%) | 0.3 (4%) |
| MARCHED: its unit marched | 0.0 (0%) | - | 0.7 (33%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | - | 0.3 (17%) | 0.0 (0%) |
| GONE: slain | 1.0 (100%) | - | 1.0 (50%) | 1.7 (18%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | - | 0.0 (0%) | 7.3 (79%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 15% (2 of 13) | 65% (43 of 66) | 57% (45 of 79) |
|   cavalry | 100% (2 of 2) | 83% (19 of 23) | 84% (21 of 25) |
|   character | 0% (0 of 11) | 40% (10 of 25) | 28% (10 of 36) |
|   infantry | - | 78% (14 of 18) | 78% (14 of 18) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.0 (0%) | 2.7 (35%) | 2.7 (24%) |
| CHARGED: it charged | 2.0 (55%) | 3.3 (43%) | 5.3 (47%) |
| NO TARGET IN RANGE | 1.3 (36%) | 1.0 (13%) | 2.3 (21%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (4%) | 0.3 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (9%) | 0.3 (4%) | 0.7 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 13.3 | 0.7 | 95% | 0.4 pts | 5 pts |
| character | 3.3 | 1.3 | 60% | 9.0 pts | 30 pts |
| infantry | 8.0 | 0.0 | 100% | 0.0 pts | 0 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 6.0 | 5.7 | 5.8 |
| Charges that made contact a game | 3.7 | 2.7 | 3.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | - | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, units carrying another wizard (or one alone) | 2.50 declared, 2.00 contact (2 units) | 0.00 declared, 0.00 contact (1 units) | 1.67 declared, 1.33 contact (3 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.54 declared, 0.29 contact (24 units) | 0.53 declared, 0.25 contact (32 units) | 0.54 declared, 0.27 contact (56 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 38% (3 of 8) | 100% (2 of 2) | - | 50% (5 of 10) |
| Character in a unit | - | 0% (0 of 2) | - | 0% (0 of 2) |
| Character on its own | - | - | 27% (3 of 11) | 27% (3 of 11) |
| Infantry | 50% (3 of 6) | 0% (0 of 1) | 0% (0 of 1) | 38% (3 of 8) |
| Monster | 25% (1 of 4) | 100% (1 of 1) | - | 40% (2 of 5) |
| Monstrous | 80% (4 of 5) | 100% (1 of 1) | - | 83% (5 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vampire Counts | 1 | 100% (5 of 5); on the table 100% | 0% (0 of 6) | 20% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 3 | 44% (4 of 9); on the table 67% | - | 40% | 38% (8 of 21) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |
| Wood Elf Realms | 2 | 75% (6 of 8); on the table 75% | - | 23% | 50% (8 of 16) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p96, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 43% (3) | 56% (5) | 50% (8) |
| ...free all their last turn and able to turn (per game) | 0.67 | 1.67 | 2.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 1.00 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p96

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 1.7 |
| Strategy | Charge objectives carried out (made contact) | 56% (9 of 16) | 50% (6 of 12) |
| Strategy | Shoot objectives carried out (shot that target) | 0% (0 of 1) | 0% (0 of 2) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | - | 100% (2 of 2) |
| Strategy | Lone characters that fought | 83% (5 of 6) | 100% (5 of 5) |
| Movement | Charges halted short of contact | 0.3 | 0.7 |
| Movement | Idle units | 2.7 | 2.7 |
| Movement | Points that never moved of their own | 154.0 | 0.0 |
| Movement | Fights charged into per game | 3.3 | 2.7 |
| Movement | Charges with odds: long shots (under 50%) | 3 of 10, net -52 | 1 of 8, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 10, net -494 | 2 of 8, net +92 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 5 of 10, net +86 | 1 of 8, net +60 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 10 | 3 of 8, net +341 |
| Shooting | Shots by shooting units (incl. breath weapons) | 2.3 | 16.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 57% (4 of 7) | 73% (35 of 48) |
| Shooting | Points destroyed by shooting units | 9.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Wounds caused by other spells | 1.7 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.3 / 0.0 / 1.0 / 0.0 | 0.0 / 1.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 149.3 | 773.7 |
| Combat | Points run down | 63.0 | 78.3 |
| Combat | Net points per charged fight, damage counted | +35 | +233 |
| Combat | Net per 100 charger points, damage counted | +9.3 | +68.2 |
| Combat | First round won (charged fights) | 60% | 88% |
| Combat | Net points per charged fight | -11 | +233 |
| Combat | Net points per supported fight / lone fight | +160 / -30 | - / +233 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 10 | 2 of 8 |
| Game | Points lost | 925.7 | 404.7 |
| Game | VP from objectives | 496.7 | 433.3 |
| Game | Lone holders (player turns) | 2.0 | 1.0 |

- Mine won / drew / lost: 0 / 1 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -491 VP
- The side that went first won 2 of 2 games with a winner
- Points traded per game (both sides' losses): 1330
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p96

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH IN POINTS | - | - | - | - | 0.3 | +16.3 | 0.0 | 36.3 |
| AFTERMATH WITH FRIENDS | 0.3 | -1.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 10.7 | -16.6 | 0.0 | 46.7 | 36.7 | -872.4 | 0.0 | 532.7 |
| ASSAILMENT BY POINTS | 0.3 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 0.7 | +5.3 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.3 | +0.0 | 163.0 | 0.0 |
| CHAFF IN THE MOVE | 0.7 | +40.0 | 0.0 | 40.0 | 3.3 | +77.7 | 0.0 | 100.7 |
| CHAFF PASSED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 1.0 | +50.1 | 0.0 | 341.0 | 1.0 | +30.5 | 0.0 | 103.0 |
| CHAMPION KNOWS CHALLENGE | 0.3 | -7.5 | 0.0 | 68.3 | - | - | - | - |
| CHARGE LIST READ AGAIN | 0.3 | +40.3 | 53.3 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 17.3 | -772.9 | 0.0 | 136.7 | 10.3 | -342.7 | 0.0 | 545.0 |
| CHARGE NOT DECLARED | 0.3 | +0.0 | 9.0 | 0.0 | - | - | - | - |
| CHARGE NOW FIRST | 3.7 | +0.0 | 179.3 | 301.3 | 2.3 | +0.0 | 438.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 10.7 | +0.0 | 0.0 | 43.3 | 12.3 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 199.7 | - | - | - | - |
| COVER ONCE | 6.7 | -399.7 | 0.0 | 46.3 | 6.3 | -137.1 | 0.0 | 243.3 |
| DEFENSIVE FLOOR | - | - | - | - | 0.3 | +0.2 | 15.0 | 0.0 |
| DENIED BY THE FIGHT | 0.3 | -0.4 | 0.0 | 20.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.0 | +61.7 | 0.0 | 0.0 | 9.7 | -60.2 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +6.7 | 36.3 | 0.0 | 0.3 | +63.2 | 0.0 | 0.0 |
| EXACT ROUND | 2.7 | +12.5 | 184.3 | 68.3 | 3.0 | +89.8 | 454.0 | 0.0 |
| FALL BACK GOOD ORDER | 4.0 | +15.6 | 179.3 | 321.3 | 3.0 | +0.0 | 484.7 | 0.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 9.0 |
| FALLS SHORT | 14.7 | +164.2 | 0.0 | 244.3 | 9.3 | +104.9 | 0.0 | 65.3 |
| FEATURE BUFFS | 0.7 | +5.7 | 0.0 | 0.0 | 3.0 | +50.0 | 0.0 | 160.0 |
| FIGHT TO THE END | 0.7 | +3.4 | 53.3 | 0.0 | 1.0 | -1.9 | 246.0 | 0.0 |
| FIVE ACTION | 62.0 | +2581.8 | 334.0 | 1022.0 | 103.3 | +4388.0 | 707.7 | 1174.7 |
| FLANK NOT WEIGHED | 10.3 | +0.0 | 0.0 | 252.7 | 8.7 | +0.0 | 0.0 | 168.3 |
| FOLLOW UP WEIGHED | 0.3 | +183.2 | 0.0 | 0.0 | 0.7 | +112.4 | 0.0 | 0.0 |
| FOOT FIRST | 23.3 | +0.0 | 0.0 | 309.0 | - | - | - | - |
| FOUR ROUNDS | 6.0 | +559.8 | 287.3 | 321.3 | 5.0 | +417.7 | 707.7 | 0.0 |
| FREED FROM HIS FIGHT | 4.7 | +0.0 | 0.0 | 108.0 | 13.7 | +0.0 | 0.0 | 203.3 |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.3 | +79.5 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -4.7 | 9.0 | 0.0 | 0.3 | -5.4 | 10.0 | 0.0 |
| GOAL WALK | 4.7 | +322.9 | 0.0 | 136.7 | 13.7 | +730.5 | 0.0 | 60.7 |
| HARD STAY DROPPED | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 3.0 | +0.0 | 0.0 | 40.0 | 11.7 | +0.0 | 0.0 | 203.3 |
| HIS CHARGE BY HIS RUN | 12.0 | +0.0 | 0.0 | 136.7 | 3.0 | +0.0 | 0.0 | 220.7 |
| HIS CHARGE DENIED | 0.3 | +76.1 | 0.0 | 20.0 | - | - | - | - |
| HIS CHARGE LIST | 3.7 | +0.0 | 0.0 | 0.0 | 9.3 | +0.0 | 0.0 | 114.0 |
| HIS LEGAL MOVES | 8.7 | +0.0 | 0.0 | 30.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.7 | -37.7 | 0.0 | 0.0 | 1.0 | -4.1 | 0.0 | 36.3 |
| HIS OWN BEST MOVE | 11.0 | +0.0 | 0.0 | 30.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 31.7 | +0.0 | 0.0 | 629.3 |
| HIS RANDOM MOVER COMES | - | - | - | - | 9.0 | +0.0 | 0.0 | 216.7 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 37.7 | +789.1 | 0.0 | 564.0 | 25.0 | +496.2 | 0.0 | 563.0 |
| HIS SHOTS BY HIS RUN | 38.0 | +385.7 | 0.0 | 599.3 | 10.0 | +110.2 | 0.0 | 143.0 |
| HIS TURN DENIED | 0.3 | +1.4 | 0.0 | 0.0 | 0.3 | +3.1 | 163.0 | 0.0 |
| HOLD ODDS | 16.7 | +0.0 | 0.0 | 40.0 | 22.7 | +0.0 | 0.0 | 586.7 |
| HOLDER ASSIGNMENT | 9.3 | +1050.9 | 0.0 | 20.0 | 12.0 | +1292.4 | 0.0 | 213.3 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.7 | -182.1 | 287.3 | 233.0 | 4.3 | -143.3 | 529.7 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 1.7 | +100.6 | 0.0 | 0.0 |
| IDLE COST | 10.7 | -178.6 | 0.0 | 211.3 | 4.7 | -126.4 | 0.0 | 0.0 |
| JOIN BY POINTS | - | - | - | - | 0.3 | +8.2 | 0.0 | 0.0 |
| JOINT CHARGE NOW | 1.7 | -1.2 | 62.3 | 68.3 | 1.0 | +1.7 | 40.0 | 0.0 |
| JOINT ON THE TABLE | - | - | - | - | 0.3 | +0.3 | 10.0 | 0.0 |
| KEEP FALLS | - | - | - | - | 0.7 | +15.6 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 40.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +26.9 | 0.0 | 0.0 | 1.7 | +56.0 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 40.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 2.3 | +0.0 | 36.3 | 261.3 | 12.7 | +0.0 | 587.0 | 548.7 |
| LONG SHOT | 0.3 | +2.9 | 9.0 | 0.0 | 0.3 | +0.4 | 15.0 | 0.0 |
| LOST AFTER ESCAPE | 2.3 | +0.9 | 89.7 | 233.0 | 1.3 | +5.2 | 477.3 | 0.0 |
| LURE BY WHAT IT DRAWS | 0.7 | -39.9 | 0.0 | 40.0 | 2.0 | -151.8 | 0.0 | 82.7 |
| MANOEUVRE | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +6.3 | 0.0 | 63.0 |
| MARCH AT ESCAPER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | +37.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.7 | +33.7 | 0.0 | 10.0 | 2.7 | +106.4 | 0.0 | 9.0 |
| MEETS IN TIME | 4.0 | +291.4 | 0.0 | 0.0 | 4.7 | +488.4 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 0.7 | +2.3 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 3.0 | +0.0 | 30.0 | 10.0 | 2.3 | +0.0 | 53.3 | 53.3 |
| MOVE TO CHARGE COMPUTED | 8.3 | +695.1 | 0.0 | 0.0 | 7.7 | +634.7 | 0.0 | 60.7 |
| NEARER NOT NEEDED | 5.7 | +263.9 | 0.0 | 60.7 | 6.3 | +343.4 | 0.0 | 32.7 |
| NEAREST TO GOAL | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 6.0 | +605.4 | 0.0 | 0.0 | 2.7 | +368.3 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 5.0 | -345.2 | 211.7 | 321.3 | 4.3 | -298.9 | 687.7 | 0.0 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 3.3 | -159.7 | 9.0 | 0.0 | 8.3 | -343.5 | 20.0 | 77.3 |
| ONE CHALLENGE TEST | 0.3 | -7.5 | 0.0 | 68.3 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 7.7 | -144.5 | 0.0 | 61.3 | 5.3 | -135.4 | 0.0 | 66.7 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +1.5 | 15.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 4.0 | -128.0 | 0.0 | 0.0 | 5.7 | -49.0 | 0.0 | 160.0 |
| ONE PROMISE A TARGET | 1.3 | -77.5 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.7 | +31.0 | 23.3 | 0.0 | 1.0 | +93.4 | 40.0 | 0.0 |
| OVERRUNS AWAY | 1.0 | +7.7 | 54.3 | 0.0 | 0.7 | +19.2 | 20.0 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PLAN RESULT | 33.7 | +308.4 | 72.7 | 1427.7 | 49.3 | +462.7 | 309.3 | 660.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 163.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 10.0 | -182.4 | 0.0 | 0.0 | 19.3 | -716.4 | 0.0 | 60.7 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 3.3 | +0.0 | 0.0 | 60.7 |
| RANDOM MOVE BY FIGURES | 6.0 | +106.2 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 1.3 | +53.8 | 0.0 | 36.0 |
| REDIRECT COUNTER | 4.3 | +213.1 | 0.0 | 70.0 | 4.3 | -143.3 | 0.0 | 36.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.0 | +0.0 | 0.0 | 73.3 | 3.3 | +82.3 | 0.0 | 77.3 |
| REDIRECT WEIGHED | 0.3 | +0.0 | 0.0 | 68.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 3.0 | -48.1 | 0.0 | 0.0 | 1.3 | -35.8 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 68.3 | - | - | - | - |
| RESERVE FALL BACK | 0.3 | +8.7 | 0.0 | 0.0 | 0.7 | +1.9 | 0.0 | 35.7 |
| RISK BY ARC | 4.7 | +47.4 | 197.3 | 321.3 | 4.0 | +18.0 | 609.3 | 0.0 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | 0.7 | -6.1 | 106.7 | 0.0 | 0.3 | -12.1 | 40.7 | 0.0 |
| RUN DOWN | 5.0 | -26.9 | 251.0 | 301.3 | 1.7 | -13.8 | 175.3 | 0.0 |
| SAME CHARGE LATER | 0.3 | -9.7 | 0.0 | 0.0 | 0.3 | -2.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 2.0 | -152.7 | 0.0 | 0.0 | 0.7 | -12.1 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +2.4 | 0.0 | 0.0 | 1.3 | +42.5 | 0.0 | 0.0 |
| SECOND LOOK | 0.7 | +4.5 | 9.0 | 0.0 | 1.0 | +39.0 | 60.7 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 2.3 | -57.5 | 0.0 | 71.3 |
| SET UP BY THE SET | 0.7 | +4.9 | 0.0 | 0.0 | 2.7 | +92.9 | 0.0 | 71.3 |
| SET UP TOGETHER | - | - | - | - | 0.7 | +3.5 | 0.0 | 35.7 |
| SHOOTERS ON THE TABLE | 1.0 | +0.0 | 0.0 | 20.0 | 2.7 | +0.0 | 0.0 | 50.3 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +21.4 | 46.7 | 0.0 | 0.3 | +1.6 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -10.7 | 23.3 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 23.0 | -215.6 | 0.0 | 584.3 | 6.0 | +77.4 | 0.0 | 180.3 |
| SHOTS AFTER THE MOVES | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 2.0 | +51.5 | 0.0 | 0.0 | 14.3 | +99.1 | 0.0 | 162.0 |
| SPELL WORTH | 1.0 | +22.6 | 199.7 | 199.7 | - | - | - | - |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | -5.0 | 199.7 | 0.0 |
| SPOT AS THE GAME MOVES | 7.0 | +0.0 | 0.0 | 446.0 | 15.0 | +0.0 | 0.0 | 222.7 |
| STAND AND SHOOT | 0.7 | -7.0 | 53.3 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| STANDS STILL | 14.7 | +0.0 | 46.7 | 81.3 | 29.0 | +0.0 | 0.0 | 152.0 |
| STAY WORTH | 1.7 | +8.7 | 0.0 | 0.0 | 13.3 | +56.8 | 0.0 | 233.0 |
| STUBBORN BY POINTS | - | - | - | - | 0.7 | +12.9 | 0.0 | 0.0 |
| STUCK PIVOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 2.7 | +167.0 | 0.0 | 20.0 | 8.0 | +495.9 | 0.0 | 65.3 |
| SUPPORT NARROWED | 0.7 | +0.0 | 62.3 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 2.7 | +167.0 | 0.0 | 20.0 | 8.0 | +495.9 | 0.0 | 65.3 |
| SWIFTSTRIDE BY POINTS | 0.7 | +19.1 | 0.0 | 211.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 4.7 | +0.0 | 0.0 | 20.0 | 8.0 | +0.0 | 0.0 | 55.0 |
| THE ROW KEEPS ITS WAY | 3.3 | +0.0 | 0.0 | 10.0 | 3.0 | +0.0 | 0.0 | 55.0 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 10.0 | 3.0 | +0.0 | 0.0 | 87.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 25.3 | +0.0 | 0.0 | 370.3 | 50.3 | +0.0 | 0.0 | 637.7 |
| TIED UP BY THE SUM | 2.3 | +353.2 | 135.0 | 68.3 | 1.7 | +282.8 | 139.0 | 0.0 |
| TIME ON OUR SIDE | 10.0 | +135.9 | 0.0 | 200.3 | 65.0 | +446.7 | 0.0 | 655.3 |
| WAITS AGAIN | 1.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | 0.3 | -0.1 | 9.0 | 0.0 | 0.7 | -1.1 | 30.0 | 0.0 |
| WHO GETS IN | 0.3 | -2.5 | 0.0 | 0.0 | 0.3 | +0.3 | 10.0 | 0.0 |
| WHO HITS BACK | 0.7 | +64.0 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 2.3 | -513.5 | 0.0 | 0.0 | 7.3 | -317.9 | 0.0 | 295.3 |
| WOUNDED STAYS OUT | - | - | - | - | 0.3 | +0.0 | 20.0 | 0.0 |

### Rule changes: gs3-83c8646-p96

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 142 | 142 | 102 | 34.00 | -1835 | -18.0 |
| HOLDER ASSIGNMENT | 64 | 64 | 61 | 20.33 | +4025 | +66.0 |
| LEGAL CHARGES ONLY | 45 | 45 | 45 | 15.00 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 88 | 88 | 42 | 14.00 | -2696 | -64.2 |
| TIME ON OUR SIDE | 225 | 182 | 37 | 12.33 | +27 | +0.7 |
| OFF BEST | 35 | 35 | 35 | 11.67 | -1510 | -43.1 |
| FIVE ACTION | 496 | 461 | 31 | 10.33 | +2033 | +65.6 |
| DEPLOY BY FIGURES | 53 | 53 | 30 | 10.00 | +239 | +8.0 |
| HIS SHOT LIST | 188 | 177 | 28 | 9.33 | +223 | +8.0 |
| THE TABLE AGAIN | 36 | 36 | 26 | 8.67 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 144 | 136 | 24 | 8.00 | +82 | +3.4 |
| MOVE TO CHARGE COMPUTED | 48 | 35 | 22 | 7.33 | +543 | +24.7 |
| FOUR ROUNDS | 33 | 29 | 20 | 6.67 | +1031 | +51.5 |
| REDIRECT FOR A FRIEND IN REACH | 19 | 19 | 19 | 6.33 | +223 | +11.7 |
| MOVE ORDER | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| MEETS IN TIME | 26 | 26 | 15 | 5.00 | +895 | +59.6 |
| NEXT CHARGE BY LIST | 26 | 23 | 13 | 4.33 | +459 | +35.3 |
| GOAL WALK | 55 | 55 | 12 | 4.00 | +261 | +21.8 |
| CHARGE LOSSES | 83 | 77 | 9 | 3.00 | +1041 | +115.7 |
| LANE BY FIGURES | 9 | 9 | 9 | 3.00 | +249 | +27.7 |
| RANDOM MOVE BY FIGURES | 18 | 18 | 9 | 3.00 | +319 | +35.4 |
| TIED UP BY THE SUM | 12 | 9 | 9 | 3.00 | +187 | +20.7 |
| JOINT CHARGE NOW | 8 | 8 | 8 | 2.67 | +1 | +0.2 |
| SHOT RISK POINTS | 87 | 81 | 8 | 2.67 | +83 | +10.4 |
| SUPPORT ADDS | 32 | 31 | 7 | 2.33 | +31 | +4.4 |
| SUPPORT WORKED OUT | 32 | 31 | 7 | 2.33 | +31 | +4.4 |
| WHOLE FIGHT DANGER | 29 | 29 | 7 | 2.33 | +344 | +49.1 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CHAFF IN THE MOVE | 12 | 11 | 6 | 2.00 | +0 | +0.0 |
| CHALLENGE BY POINTS | 6 | 6 | 6 | 2.00 | +242 | +40.3 |
| IDLE COST | 46 | 36 | 6 | 2.00 | +63 | +10.5 |
| CHARGE NOW FIRST | 18 | 18 | 5 | 1.67 | -234 | -46.8 |
| REDIRECT COUNTER | 26 | 16 | 5 | 1.67 | +199 | +39.8 |
| SECOND LOOK | 5 | 5 | 5 | 1.67 | +131 | +26.1 |
| SET UP BY THE SET | 10 | 8 | 5 | 1.67 | +64 | +12.8 |
| SHOTS IN THE MOVE | 49 | 35 | 5 | 1.67 | +21 | +4.3 |
| COVER ONCE | 39 | 29 | 4 | 1.33 | +137 | +34.2 |
| EXACT ROUND | 17 | 14 | 4 | 1.33 | +95 | +23.8 |
| HARD STAY DROPPED | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| ONE PROMISE A TARGET | 4 | 4 | 4 | 1.33 | -232 | -58.1 |
| RISK BY ARC | 26 | 22 | 4 | 1.33 | +16 | +4.0 |
| FALLS SHORT | 72 | 60 | 3 | 1.00 | +22 | +7.4 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +887 | +295.6 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MANOEUVRE | 7 | 7 | 3 | 1.00 | +19 | +6.3 |
| REDIRECT WEIGHED | 3 | 3 | 3 | 1.00 | +190 | +63.3 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +32 | +10.6 |
| SEARCH SPOT | 6 | 6 | 3 | 1.00 | +195 | +64.9 |
| SHOOTS FROM THE BEST SPOT | 3 | 3 | 3 | 1.00 | +24 | +8.2 |
| THE ROW IN ITS ORDER | 38 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HUNT IN PAIRS | 5 | 4 | 2 | 0.67 | +48 | +24.1 |
| KEEP FALLS | 2 | 2 | 2 | 0.67 | +73 | +36.3 |
| OPENS UP | 5 | 4 | 2 | 0.67 | +37 | +18.4 |
| STUBBORN BY POINTS | 2 | 2 | 2 | 0.67 | +39 | +19.3 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 2 | 2 | 2 | 0.67 | +57 | +28.7 |
| WHO GETS IN | 2 | 2 | 2 | 0.67 | -6 | -3.2 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +143 | +71.5 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +49 | +48.8 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | -3 | -3.0 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +3 | +3.4 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +121 | +121.0 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -17 | -17.3 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 2 | 2 | 1 | 0.33 | +8 | +8.0 |
| FALL BACK GOOD ORDER | 21 | 18 | 1 | 0.33 | +11 | +10.7 |
| FIGHT TO THE END | 5 | 5 | 1 | 0.33 | +2 | +1.5 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +238 | +238.5 |
| HIS CHARGE DENIED | 1 | 1 | 1 | 0.33 | +162 | +162.1 |
| JOIN BY POINTS | 1 | 1 | 1 | 0.33 | +25 | +24.7 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.33 | +1 | +0.9 |
| MAX FOR POSITIONING | 13 | 12 | 1 | 0.33 | +5 | +5.1 |
| NEARER NOT NEEDED | 36 | 34 | 1 | 0.33 | +19 | +18.6 |
| ONE JOINT FIGURE | 1 | 1 | 1 | 0.33 | +1 | +0.7 |
| ONE OBJECTIVE FORMULA | 29 | 27 | 1 | 0.33 | +0 | +0.0 |
| OVERRUNS AWAY | 5 | 4 | 1 | 0.33 | +0 | +0.0 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -5 | -4.7 |
| SUPPORT NARROWED | 2 | 2 | 1 | 0.33 | -11 | -11.4 |
| BACKUP TARGETS | 2 | 1 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 69 | 68 | 0 | 0.00 | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 11 | 11 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 57 | not checked | - | - | - | - |
| FOOT FIRST | 70 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 55 | 51 | 0 | 0.00 | - | - |
| GIVES UP | 2 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 44 | 40 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 45 | 42 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 39 | 37 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 37 | 29 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 17 | 16 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 46 | 38 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 95 | 83 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 27 | 25 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HOLD ODDS | 118 | 118 | 0 | 0.00 | - | - |
| HONEST WORTH | 27 | 23 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 16 | 16 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 11 | 11 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 8 | 8 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 3 | 3 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 2 | 2 | 0 | 0.00 | - | - |
| NEAREST TO GOAL | 3 | 3 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 28 | 24 | 0 | 0.00 | - | - |
| NO LATE CUT | 8 | 8 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 39 | 20 | 0 | 0.00 | - | - |
| ONE ROUTE | 3 | 3 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 249 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 10 | 4 | 0 | 0.00 | - | - |
| REAL GROUND | 3 | 3 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 13 | 13 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 20 | 16 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 8 | 8 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 7 | 5 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 11 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 4 | 4 | 0 | 0.00 | - | - |
| SPELL WORTH | 3 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 66 | 65 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 3 | 3 | 0 | 0.00 | - | - |
| STANDS STILL | 131 | 129 | 0 | 0.00 | - | - |
| STAY WORTH | 45 | 34 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 19 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 13 | not checked | - | - | - | - |
| THE TABLE BINDS | 227 | not checked | - | - | - | - |
| WAITS AGAIN | 13 | 10 | 0 | 0.00 | - | - |
| WHO FIGHTS | 3 | 2 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p96

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 3.67 | 10.33 | 64.2 |
| ARMY TABLE | rule | 2.00 | 6.67 | 110.5 |
| JOB FIRST | gate | 1.67 | 6.67 | 47.4 |
| CHARGE NOW FIRST | rule | 0.67 | 1.00 | 46.8 |
| HOLDER ASSIGNMENT | rule | 0.33 | 1.33 | 5.8 |
| ONE PROMISE A TARGET | rule | 1.33 | - | 58.1 |
| AFTERMATH BAND | gate | 0.67 | 0.33 | 3.3 |
| JOINT CHARGE NOW | rule | 1.00 | - | 54.7 |
| RULE SWITCHED OFF | gate | - | 1.00 | 34.5 |
| NO REASON | gate | 0.67 | - | 66.2 |
| AFTERMATH WITH FRIENDS | rule | 0.33 | - | 3.0 |
| CHARGE NOT DECLARED | rule | 0.33 | - | 17.3 |
| FALLBACK | gate | - | 0.33 | 78.2 |
| FIGHT ORDER BAND | gate | 0.33 | - | 0.6 |
| REFUSING RETIRES | rule | 0.33 | - | 4.7 |
| SUPPORT NARROWED | rule | 0.33 | - | 11.4 |
| SWIFTSTRIDE BY POINTS | rule | 0.33 | - | 8.3 |
| WHO GETS IN | rule | 0.33 | - | 7.3 |

### Plans: gs3-83c8646-p96

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 5.0 | 40% | 492 | 308 | 63% |
| Mine | move | 27.3 | 93% | 944 | 0 | 0% |
| Mine | support | 1.3 | 75% | 0 | 0 | - |
| Opponent | charge | 4.3 | 77% | 555 | 463 | 83% |
| Opponent | move | 43.0 | 95% | 1740 | 0 | 0% |
| Opponent | shoot | 0.3 | 0% | 1 | 0 | 0% |
| Opponent | support | 1.7 | 60% | 41 | 0 | 0% |

### Battle groups: gs3-83c8646-p96

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.3 | 31% | 50% | 25% | 0% | 0% | 0% | 33% | 67% | 0% |
| Opponent | REDIRECT COUNTER | 4.3 | 15% | 0% | 0% | - | 0% | 0% | 0% | 50% | 50% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p96

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 7 | 71 (7) | 0 | 71 | 100 | 57% | 3.7 | 0 (3) | 233 (2) | 0 (2) | 71 (7) | - |
| Mine | Character | 6 | 19 (6) | 19 | 0 | 56 | 0% | 3.0 | - | 13 (3) | 24 (3) | 23 (5) | 0 (1) |
| Mine | Clean-up | 1 | 42 (1) | 0 | 42 | 0 | 100% | - | - | 42 (1) | - | - | 42 (1) |
| Mine | Fast Hammer | 6 | 53 (6) | 18 | 36 | 44 | 50% | 2.3 | - | 104 (3) | 6 (3) | 25 (4) | 120 (2) |
| Mine | Hammer | 6 | 91 (6) | 26 | 65 | 27 | 50% | 3.7 | - | 124 (5) | 0 (1) | 134 (4) | 0 (2) |
| Mine | Holder | 3 | 0 (3) | 0 | 0 | 75 | 33% | 4.0 | - | - | 0 (3) | 0 (2) | 0 (1) |
| Opponent | Chaff | 5 | 190 (5) | 78 | 112 | 70 | 60% | 3.5 | 257 (2) | 286 (1) | 0 (2) | 225 (4) | 0 (1) |
| Opponent | Character | 7 | 85 (7) | 85 | 0 | 0 | 0% | 2.0 | 76 (2) | 90 (5) | - | 76 (4) | 95 (3) |
| Opponent | Clean-up | 6 | 21 (6) | 7 | 14 | 32 | 33% | 2.5 | 44 (2) | 0 (1) | 13 (3) | 31 (4) | 0 (2) |
| Opponent | Fast Hammer | 4 | 48 (4) | 5 | 43 | 0 | 0% | 1.5 | 15 (2) | 90 (2) | - | 16 (3) | 224 (1) |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 0% | 1.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Hammer | 9 | 10 (9) | 0 | 10 | 52 | 44% | 3.4 | - | 15 (6) | 0 (3) | 0 (7) | 38 (2) |
| Opponent | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Shooter | 3 | 56 (3) | 0 | 56 | 85 | 0% | 1.0 | 0 (1) | 66 (2) | - | 0 (1) | 66 (2) |

### Charged fights: gs3-83c8646-p96

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 1 | 0 | 469 | 5.0 | 1.2 | 94 | 12 | +82 | 2 of 5 | 4 of 5 | +160 | +62 |
| Mine | Warriors of Chaos | 2 | 14 | 90 | 2.5 | 1.0 | 36 | 140 | -104 | 1 of 5 | 2 of 5 | - | -104 |
| **Mine** | all armies | 3 | 9 | 216 | 3.3 | 1.1 | 65 | 76 | -11 | 3 of 10 | 6 of 10 | +160 | -30 |
| Opponent | Warriors of Chaos | 1 | 0 | 205 | 1.0 | 1.0 | 205 | 0 | +205 | 0 of 1 | 1 of 1 | - | +205 |
| Opponent | Wood Elf Realms | 2 | 0 | 830 | 3.5 | 1.0 | 237 | 0 | +237 | 2 of 7 | 6 of 7 | - | +237 |
| **Opponent** | all armies | 3 | 0 | 622 | 2.7 | 1.0 | 233 | 0 | +233 | 2 of 8 | 7 of 8 | - | +233 |

### Effective charges: gs3-83c8646-p96

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 5 | 2 (net +24) | 0 | 0 | 0 | 3 (net +120) | 0 | 0 | 0% (0 of 5) |
| Mine | Warriors of Chaos | 5 | 1 (net -205) | 0 | 1 (net -494) | 1 (net +109) | 2 (net +35) | 0 | 0 | 20% (1 of 5) |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +205) | 0 | 0% (0 of 1) |
| Opponent | Wood Elf Realms | 7 | 1 (net +0) | 0 | 2 (net +92) | 1 (net +599) | 1 (net +60) | 2 (net +409) | 0 | 29% (2 of 7) |

### Charged fights, damage counted: gs3-83c8646-p96

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 3 | 125 | 442 | -52 | 36 | 98 | -61 | -48.9 |
| Mine | Effective (55-75%) | 1 | 494 | 717 | -494 | 250 | 494 | -244 | -49.5 |
| Mine | 76-89% | 1 | 489 | 500 | +109 | 442 | 28 | +414 | +84.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 493 | 108 | +86 | 86 | 12 | +74 | +14.9 |
| Mine | All fights | 10 | 382 | 308 | -11 | 123 | 88 | +35 | +9.3 |
| Opponent | Long shot (under 50%) | 1 | 109 | 110 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Effective (55-75%) | 2 | 71 | 92 | +92 | 92 | 4 | +88 | +123.2 |
| Opponent | 76-89% | 1 | 499 | 499 | +599 | 599 | 0 | +599 | +120.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 493 | 341 | +341 | 341 | 18 | +323 | +65.6 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 499 | 60 | +60 | 117 | 0 | +117 | +23.5 |
| Opponent | All fights | 8 | 341 | 234 | +233 | 240 | 8 | +233 | +68.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p96 | move | 33 | 5 (15%) | 3 (9%) | 7 (21%) | 21 (64%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2634 |
| Charmed Shield | Opponent | L2634, L3234 |

# Doctrine scorecard: gs3-83c8646-p7

### Scorecard: gs3-83c8646-p7

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1114 | 4 | 1 | Mine | no | 0 | 4 | 1 | 0 | 0 | 0 | 0 | 165 |
| L1114 | 4 | 1 | Opponent | no | 0 | 4 | 3 | 3 | 0 | 0 | 0 | 0 |
| L1131 | 3 | 1 | Mine | no | 0 | 4 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1131 | 3 | 1 | Opponent | no | 0 | 3 | 1 | 5 | 2 | 0 | 0 | 0 |
| L1224 | 6 | 1 | Mine | no | 8 | 2 | 3 | 0 | 1 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 1 | 4 | 1 | 2 | 1 | 0 | 0 | 470 |
| **Average** | | | Mine | 0% | 2.7 | 3.3 | 2.0 | 0.0 | 0.3 | 0.0 | 0.0 | 275.0 |
| **Average** | | | Opponent | 0% | 0.3 | 3.7 | 1.7 | 3.3 | 1.0 | 0.0 | 0.0 | 156.7 |

### KPIs: gs3-83c8646-p7

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 69% (11 of 16) | 0% (0 of 15) | 35% (11 of 31) |
| Winner chose to follow up after the loser gave ground |  | 80% (4 of 5); on the table 80% | 100% (1 of 1); on the table 100% | 83% (5 of 6); on the table 83% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 80% (4 of 5); on the table 80% | 100% (2 of 2); on the table 100% | 86% (6 of 7); on the table 86% |
| Magic missiles tried each own turn | 50%+ | 48% (32 of 66) | 22% (4 of 18) | 43% (36 of 84) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 56% (32 of 57) | 31% (4 of 13) | 51% (36 of 70) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 67% (8 of 12) | 67% (8 of 12) |
| Points that never fought | lower | 63% (3762 of 5998) | 71% (4247 of 5998) | 67% (8009 of 11996) |
|   infantry points that never fought | lower | 100% (730 of 730) | 74% (676 of 913) | 86% (1406 of 1643) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 44% (11 of 25) | 89% (25 of 28) | 68% (36 of 53) |
| Bound items with a magic missile used (at least once a game) |  | 86% (6 of 7); 4.7 uses a game | 100% (1 of 1); 1.0 uses a game | 88% (7 of 8); 2.8 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 33% (2 of 6); 0.7 uses a game | 33% (2 of 6); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 33% (1 of 3); 0.3 uses a game | 0.0 uses a game | 33% (1 of 3); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 36% (2028 of 5614) | 91% (5299 of 5828) | 64% (7327 of 11442) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.3 (21%) | 1.7 (36%) | 4.0 (25%) |
| MARCHED: its unit marched | 3.7 (32%) | 1.3 (29%) | 5.0 (31%) |
| CHARGED: its unit charged | 2.3 (21%) | 0.0 (0%) | 2.3 (15%) |
| IN COMBAT: engaged in combat | 3.0 (26%) | 0.3 (7%) | 3.3 (21%) |
| GONE: slain | 0.0 (0%) | 1.3 (29%) | 1.3 (8%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.0 | 4.7 | 2.3 | 12.0 | 4.0 | 3.0 |
| not cast | 1.0 | 7.3 | 1.7 | 16.0 | 4.0 | 33.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 6.3 (86%) | 0.0 (0%) | 4.0 (25%) | 1.0 (25%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 5.0 (31%) | 0.7 (17%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (15%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (9%) | 0.7 (40%) | 3.3 (21%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.3 (33%) | 0.3 (5%) | 0.3 (20%) | 1.3 (8%) | 0.0 (0%) | 1.0 (3%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (33%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (58%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.3 (33%) | 0.0 (0%) | 0.7 (40%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 31.3 (95%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 2.3 a game | 1.2 a game |
| stood (cast and not dispelled) | - | 57% (4 of 7) | 57% (4 of 7) |
| the unit moved after it | - | 0% (0 of 4) | 0% (0 of 4) |
| it charged on its next turn | - | 0% (0 of 4) | 0% (0 of 4) |
| the enemy charged it first | - | 25% (1 of 4) | 25% (1 of 4) |
| it fought by the end of its next turn | - | 25% (1 of 4) | 25% (1 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 4) | 0% (0 of 4) |
| none of these (no charge, no fight, no charge escaped) | - | 75% (3 of 4) | 75% (3 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 68% (47 of 69) | 43% (10 of 23) | 62% (57 of 92) |
|   cavalry | 0% (0 of 12) | 67% (4 of 6) | 22% (4 of 18) |
|   character | - | 0% (0 of 10) | 0% (0 of 10) |
|   chariot | 58% (7 of 12) | - | 58% (7 of 12) |
|   infantry | 100% (12 of 12) | 86% (6 of 7) | 95% (18 of 19) |
|   war machine | 85% (28 of 33) | - | 85% (28 of 33) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (23%) | 0.3 (8%) | 2.0 (17%) |
| CHARGED: it charged | 0.3 (5%) | 0.7 (15%) | 1.0 (9%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (8%) | 0.3 (3%) |
| MOVED: a war machine that moved | 0.3 (5%) | 0.0 (0%) | 0.3 (3%) |
| FREE: none of these - no target in range or sight, or held its fire | 4.0 (55%) | 0.0 (0%) | 4.0 (34%) |
| NO TARGET IN RANGE | 0.0 (0%) | 1.7 (38%) | 1.7 (14%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 1.0 (23%) | 1.0 (9%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (5%) | 0.3 (8%) | 0.7 (6%) |
| SHELTERED: the target was sheltered | 0.3 (5%) | 0.0 (0%) | 0.3 (3%) |
| OTHER BAR | 0.3 (5%) | 0.0 (0%) | 0.3 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 2.3 | 0.3 | 86% | 6.8 pts | 16 pts |
| infantry | 12.7 | 1.0 | 92% | 4.5 pts | 57 pts |
| war machine | 10.3 | 6.7 | 61% | 21.5 pts | 223 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 2.0 | 2.8 |
| Charges that made contact a game | 2.3 | 1.3 | 1.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.29 declared, 0.71 contact (7 units) | 0.00 declared, 0.00 contact (3 units) | 0.90 declared, 0.50 contact (10 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.20 declared, 0.20 contact (10 units) | 0.29 declared, 0.19 contact (21 units) | 0.26 declared, 0.19 contact (31 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 73% (8 of 11) | 50% (1 of 2) | 0% (0 of 2) | 60% (9 of 15) |
| Character in a unit | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Character on its own | 100% (5 of 5) | 67% (4 of 6) | 57% (4 of 7) | 72% (13 of 18) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 67% (4 of 6) | 50% (1 of 2) | - | 62% (5 of 8) |
| Monster | 100% (2 of 2) | - | - | 100% (2 of 2) |
| War Machines | 67% (4 of 6) | - | - | 67% (4 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 3 | 80% (4 of 5); on the table 80% | 48% (32 of 66) | 63% | 44% (11 of 25) | 86% (6 of 7); 4.7 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| High Elf Realms | 1 | - | 17% (1 of 6) | 52% | 89% (8 of 9) | 0.0 uses a game | 33% (2 of 6); 2.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (1 of 1); on the table 100% | 33% (2 of 6) | 70% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (1 of 1); on the table 100% | 17% (1 of 6) | 90% | 92% (11 of 12) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p7, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 25% (1) | 25% (1) | 25% (2) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 1.33 | 1.33 |

### Quality by phase: gs3-83c8646-p7

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 4.3 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 67% (6 of 9) | 75% (3 of 4) |
| Strategy | Shoot objectives carried out (shot that target) | 35% (18 of 51) | 25% (1 of 4) |
| Strategy | Hexes on a unit its side charged or shot that turn | 50% (1 of 2) | 100% (2 of 2) |
| Strategy | Joined characters whose unit fought | 25% (1 of 4) | - |
| Strategy | Lone characters that fought | 62% (5 of 8) | 18% (2 of 11) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.0 | 3.3 |
| Movement | Points that never moved of their own | 275.0 | 156.7 |
| Movement | Fights charged into per game | 2.3 | 1.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 7 | 0 of 3 |
| Movement | Charges with odds: sweet spot (55-75%) | 3 of 7, net +50 | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 7, net +60 | 0 of 3 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 7, net +0 | 1 of 3, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 6.3 | 4.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 58% (11 of 19) | 92% (11 of 12) |
| Shooting | Points destroyed by shooting units | 47.7 | 0.0 |
| Shooting | War machine shots | 9.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 38% (11 of 29) | - |
| Shooting | Points destroyed by war machines | 79.7 | 0.0 |
| Magic | Magic missiles cast | 8.0 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 21% (5 of 24) | 100% (2 of 2) |
| Magic | Wounds caused by magic missiles | 12.0 | 0.3 |
| Magic | Wounds caused by other spells | 2.3 | 0.7 |
| Magic | Points destroyed by magic (all spells) | 373.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 0.7 / 1.3 / 1.7 | 1.7 / 0.7 / 0.7 / 0.0 |
| Combat | Points destroyed in combat | 56.7 | 0.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +102 | -71 |
| Combat | Net per 100 charger points, damage counted | +35.5 | -22.1 |
| Combat | First round won (charged fights) | 71% | 0% |
| Combat | Net points per charged fight | +39 | +0 |
| Combat | Net points per supported fight / lone fight | - / +39 | - / +0 |
| Combat | Charged fights on a top-3 enemy unit | 4 of 7 | 4 of 4 |
| Game | Points lost | 127.3 | 650.3 |
| Game | VP from objectives | 810.0 | 490.0 |
| Game | Lone holders (player turns) | 2.7 | 0.3 |

- Mine won / drew / lost: 3 / 0 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +884 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 778
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: gs3-83c8646-p7

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +87.1 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 9.7 | +163.7 | 0.0 | 0.0 | 32.0 | -199.9 | 0.0 | 614.7 |
| ARTILLERY RE-ROLL WEIGHED | 4.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 0.3 | +0.8 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.3 | +0.0 | 38.7 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 9.3 | +340.0 | 451.7 | 110.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 5.0 | +151.5 | 367.0 | 0.0 | 1.0 | +2.8 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.3 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 1.0 | +50.2 | 0.0 | 60.0 |
| CHALLENGE BY POINTS | 0.3 | +5.6 | 0.0 | 0.0 | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -47.7 | 0.0 | 0.0 |
| CHARGE LOSSES | 11.0 | -700.3 | 0.0 | 0.0 | 28.7 | -1061.3 | 0.0 | 493.3 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 176.7 | 72.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| CHARGER SLAIN LOST | - | - | - | - | 0.3 | -6.5 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.3 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 113.3 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 313.3 |
| CONVEYANCE SEARCH | - | - | - | - | 2.3 | +315.5 | 0.0 | 0.0 |
| COVER ONCE | 11.0 | -824.0 | 0.0 | 0.0 | 10.7 | -784.1 | 0.0 | 72.0 |
| DEPLOY BY FIGURES | 6.0 | +5.5 | 0.0 | 0.0 | 6.7 | +127.1 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.7 | -82.7 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +14.8 | 50.3 | 0.0 | - | - | - | - |
| EXACT ROUND | 2.3 | +22.9 | 285.7 | 0.0 | 0.3 | +11.2 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.7 | +2.2 | 265.7 | 0.0 | 1.3 | +25.7 | 72.3 | 53.7 |
| FALLS SHORT | - | - | - | - | 20.7 | +281.6 | 0.0 | 237.0 |
| FIGHT TO THE END | 1.3 | +64.0 | 156.7 | 72.3 | 0.7 | +11.2 | 72.3 | 53.7 |
| FIVE ACTION | 87.0 | +6719.0 | 2206.3 | 292.3 | 81.0 | +4242.8 | 72.3 | 1357.0 |
| FLANK NOT WEIGHED | 3.7 | +0.0 | 0.0 | 0.0 | 8.3 | +0.0 | 0.0 | 118.3 |
| FOLLOW UP WEIGHED | 1.3 | +287.5 | 0.0 | 0.0 | 0.7 | +137.8 | 0.0 | 0.0 |
| FOOT FIRST | - | - | - | - | 15.7 | +0.0 | 0.0 | 316.0 |
| FOUR ROUNDS | 3.7 | +450.7 | 285.7 | 72.3 | 1.7 | +296.3 | 72.3 | 53.7 |
| FREED FROM HIS FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 113.3 |
| FRIEND SHOOTS FIRST | 4.3 | -207.8 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 1.0 | -11.4 | 38.7 | 0.0 | 0.3 | -0.4 | 72.3 | 53.7 |
| GOAL WALK | 0.7 | +76.9 | 0.0 | 0.0 | 11.0 | +1407.6 | 0.0 | 158.0 |
| GUN MASK | 1.3 | +44.2 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 38.7 |
| HE REFORMS ONCE FREED | - | - | - | - | 5.0 | +0.0 | 0.0 | 56.7 |
| HIS CHARGE BY HIS RUN | 10.3 | +0.0 | 0.0 | 0.0 | 20.3 | +0.0 | 0.0 | 398.0 |
| HIS CHARGE DENIED | 0.3 | +22.3 | 38.7 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 2.7 | +0.0 | 0.0 | 0.0 | 9.7 | +0.0 | 0.0 | 216.7 |
| HIS LEGAL MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 38.7 |
| HIS MOVE AND SHOT | 1.3 | -3.8 | 0.0 | 0.0 | 17.3 | -254.6 | 0.0 | 380.7 |
| HIS ONE QUARTER | 4.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 113.3 |
| HIS OWN BEST MOVE | 7.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 38.7 |
| HIS RANDOM MOVE | 14.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 15.7 | +140.9 | 0.0 | 0.0 | 69.0 | +4615.1 | 0.0 | 1134.7 |
| HIS SHOTS BY HIS RUN | 19.0 | +281.4 | 0.0 | 0.0 | 58.0 | +1787.6 | 0.0 | 887.0 |
| HIS TURN DENIED | 0.3 | +0.9 | 0.0 | 72.3 | - | - | - | - |
| HOLD ODDS | 12.0 | +0.0 | 0.0 | 0.0 | 14.7 | +0.0 | 0.0 | 180.7 |
| HOLDER ASSIGNMENT | 10.0 | +1051.6 | 0.0 | 0.0 | 10.0 | +859.3 | 0.0 | 90.3 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.7 | -147.0 | 285.7 | 72.3 | 1.0 | -59.6 | 72.3 | 53.7 |
| HUNT DROPPED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 2.0 | +57.3 | 0.0 | 0.0 | 0.7 | +27.9 | 0.0 | 0.0 |
| HUNT RESULT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.3 | +132.6 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 17.3 | -293.3 | 0.0 | 305.3 |
| JOINT CHARGE NOW | 0.3 | -80.8 | 0.0 | 72.3 | 1.0 | -273.8 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.3 | -6.4 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.0 | +5.5 | 0.0 | 0.0 | 0.7 | +40.1 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 1.3 | +0.0 | 286.7 | 0.0 | 5.3 | +0.0 | 72.3 | 790.7 |
| LONE WIZARD KEPT IN | 0.7 | +41.6 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 2.3 | -3.8 | 207.0 | 72.3 | 1.7 | +6.9 | 72.3 | 53.7 |
| LOST CHARGE | 0.3 | -3.0 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 0.7 | +5.2 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +1.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 2.0 | +60.3 | 0.0 | 0.0 | 0.3 | +56.9 | 0.0 | 0.0 |
| MARCH CHECK | 2.0 | +108.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.7 | +34.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 2.3 | +37.1 | 0.0 | 0.0 | 1.3 | +184.7 | 0.0 | 65.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 9.0 | +178.6 | 0.0 | 0.0 | 4.3 | +119.0 | 0.0 | 85.0 |
| MEETS IN TIME | 3.7 | +420.3 | 0.0 | 0.0 | 3.7 | +347.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 12.3 | +332.9 | 0.0 | 0.0 | 2.7 | +13.0 | 0.0 | 65.0 |
| MISSILES NEXT TURN | 16.3 | +302.7 | 0.0 | 0.0 | 5.3 | +22.3 | 0.0 | 130.0 |
| MISSILES ON ONE TARGET | 0.3 | -12.3 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | - | - | - | - | 3.7 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 10.3 | +914.5 | 0.0 | 0.0 | 4.3 | +253.1 | 0.0 | 38.7 |
| NEARER NOT NEEDED | 4.7 | +201.8 | 0.0 | 0.0 | 7.3 | +271.1 | 0.0 | 73.7 |
| NEAREST TO GOAL | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 4.3 | +499.9 | 0.0 | 0.0 | 3.0 | +220.4 | 0.0 | 38.7 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -10.0 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 3.7 | -159.3 | 285.7 | 72.3 | 1.0 | -96.8 | 0.0 | 0.0 |
| NO LATE CUT | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 1.3 | -1.2 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 6.3 | -314.3 | 0.0 | 0.0 | 8.0 | -372.6 | 72.3 | 186.0 |
| OGRE LOADER SECOND SHOT | 6.3 | +94.7 | 56.7 | 0.0 | - | - | - | - |
| ONE CHALLENGE TEST | 0.3 | -1.2 | 50.3 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 7.3 | -153.4 | 0.0 | 0.0 | 6.7 | -196.8 | 0.0 | 103.7 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | +31.9 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 4.3 | -23.9 | 0.0 | 0.0 | 3.0 | -143.9 | 0.0 | 70.3 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +9.1 | 20.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | - | - | - | - | 0.7 | +11.2 | 72.3 | 53.7 |
| OWN CAST FIRST | 0.3 | -8.4 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.7 | -7.1 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 38.0 | +1109.8 | 891.3 | 199.7 | 40.7 | +137.6 | 0.0 | 1018.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 14.3 | -350.5 | 0.0 | 0.0 | 7.3 | -125.2 | 0.0 | 0.0 |
| PROMISE IN STEPS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 0.7 | -11.7 | 0.0 | 0.0 | 2.7 | -0.7 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 2.0 | -101.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | 2.7 | -46.0 | 390.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 19.7 | +1980.8 | 636.3 | 0.0 | 14.3 | +1519.5 | 0.0 | 296.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.0 | +107.4 | 0.0 | 113.3 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | +13.7 | 0.0 | 40.0 |
| REDIRECT COUNTER | - | - | - | - | 1.7 | +243.5 | 0.0 | 40.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 4.3 | -113.9 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RISK BY ARC | 3.3 | +215.2 | 265.7 | 72.3 | 1.3 | -103.7 | 72.3 | 53.7 |
| RISK ON THE WAY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.7 | -41.1 | 0.0 | 0.0 |
| RUN DOWN | 2.0 | -16.1 | 89.0 | 0.0 | 1.7 | -93.0 | 72.3 | 53.7 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | +24.6 | 0.0 | 40.0 |
| SEARCH SPOT | - | - | - | - | 0.3 | +1.8 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +5.6 | 0.0 | 0.0 | 0.3 | +2.2 | 72.3 | 53.7 |
| SET CREDITED ONCE | 1.3 | -54.1 | 0.0 | 0.0 | 1.7 | -73.3 | 0.0 | 53.3 |
| SET UP BY THE SET | 3.3 | +93.4 | 38.7 | 0.0 | 2.7 | +59.7 | 0.0 | 53.3 |
| SHOOTERS ON THE TABLE | 17.0 | +0.0 | 0.0 | 110.0 | 3.7 | +0.0 | 0.0 | 143.7 |
| SHOOTS FROM THE BEST SPOT | 6.0 | +225.0 | 217.7 | 0.0 | 1.3 | +129.4 | 0.0 | 130.0 |
| SHOT REPLANNED | 0.3 | +0.0 | 38.7 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 9.3 | -44.3 | 0.0 | 0.0 | 46.3 | +522.3 | 0.0 | 1043.3 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.7 | +761.6 | 0.0 | 110.0 | 3.7 | +82.7 | 0.0 | 41.0 |
| SPELL WORTH | 1.3 | +19.1 | 0.0 | 0.0 | 1.7 | +43.9 | 313.3 | 313.3 |
| SPELLS IN THE FIGHT | 0.7 | -19.2 | 50.3 | 72.3 | - | - | - | - |
| SPOT AS THE GAME MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 187.7 |
| STAND AND SHOOT | 0.7 | -12.5 | 0.0 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 43.3 | +0.0 | 1920.7 | 220.0 | 21.3 | +0.0 | 0.0 | 268.7 |
| STAY WORTH | 34.0 | -194.9 | 1134.3 | 330.0 | 2.0 | +9.4 | 0.0 | 41.0 |
| STOPS | - | - | - | - | 0.3 | +0.7 | 0.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 56.7 |
| SUPPORT ADDS | 4.3 | +374.0 | 0.0 | 0.0 | 10.0 | +1187.9 | 0.0 | 180.7 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 4.3 | +374.0 | 0.0 | 0.0 | 10.0 | +1187.9 | 0.0 | 180.7 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +11.4 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 110.0 |
| THE ROW KEEPS ITS WAY | 2.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 53.7 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 40.3 | +0.0 | 0.0 | 110.0 | 41.0 | +0.0 | 0.0 | 673.7 |
| TIED UP BY THE SUM | 1.0 | +109.5 | 20.0 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 31.3 | +542.7 | 0.0 | 0.0 | - | - | - | - |
| WAITS AGAIN | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -32.2 | 144.7 | 107.3 |
| WHO FIGHTS | 0.3 | -2.2 | 50.3 | 0.0 | - | - | - | - |
| WHOLE FIGHT | - | - | - | - | 0.3 | +10.6 | 72.3 | 53.7 |
| WHOLE FIGHT DANGER | 4.0 | -641.8 | 0.0 | 0.0 | 1.0 | -112.3 | 0.0 | 130.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 1.0 | +331.2 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 2.7 | +5.5 | 0.0 | 0.0 | - | - | - | - |

### Rule changes: gs3-83c8646-p7

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 125 | 125 | 84 | 28.00 | +508 | +6.1 |
| HIS SHOT LIST | 254 | 233 | 64 | 21.33 | +1943 | +30.4 |
| HOLDER ASSIGNMENT | 60 | 60 | 54 | 18.00 | +3133 | +58.0 |
| FIVE ACTION | 504 | 480 | 53 | 17.67 | +3919 | +73.9 |
| OFF BEST | 43 | 43 | 43 | 14.33 | -2061 | -47.9 |
| HIS SHOTS BY HIS RUN | 231 | 218 | 39 | 13.00 | +399 | +10.2 |
| MOVE TO CHARGE COMPUTED | 44 | 33 | 26 | 8.67 | +896 | +34.5 |
| PROMISE BY ITS OWN SUM | 65 | 65 | 25 | 8.33 | -1428 | -57.1 |
| THE TABLE AGAIN | 36 | 36 | 24 | 8.00 | +0 | +0.0 |
| QUARTER ODDS | 102 | 98 | 22 | 7.33 | +2410 | +109.5 |
| SHOT RISK POINTS | 167 | 155 | 22 | 7.33 | +1157 | +52.6 |
| LEGAL CHARGES ONLY | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| OGRE LOADER SECOND SHOT | 19 | 19 | 19 | 6.33 | +284 | +15.0 |
| DEPLOY BY FIGURES | 38 | 38 | 18 | 6.00 | +443 | +24.6 |
| SHOOTS FROM THE BEST SPOT | 22 | 22 | 17 | 5.67 | +87 | +5.1 |
| NEXT CHARGE BY LIST | 22 | 21 | 14 | 4.67 | +752 | +53.7 |
| SUPPORT ADDS | 43 | 43 | 14 | 4.67 | +832 | +59.4 |
| SUPPORT WORKED OUT | 43 | 43 | 14 | 4.67 | +832 | +59.4 |
| ARTILLERY RE-ROLL WEIGHED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| MEETS IN TIME | 22 | 22 | 12 | 4.00 | +535 | +44.6 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| CAST JOB | 18 | 18 | 10 | 3.33 | +125 | +12.5 |
| GOAL WALK | 35 | 35 | 10 | 3.33 | +1495 | +149.5 |
| HARD STAY DROPPED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| COVER ONCE | 65 | 45 | 9 | 3.00 | +198 | +22.0 |
| FOUR ROUNDS | 16 | 14 | 9 | 3.00 | +549 | +61.0 |
| MISSILES IN THE MOVE | 45 | 29 | 9 | 3.00 | +72 | +8.0 |
| TIME ON OUR SIDE | 94 | 74 | 9 | 3.00 | +84 | +9.3 |
| PROMISE SHOT AWAY | 8 | 8 | 8 | 2.67 | -138 | -17.2 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 8 | 2.67 | +322 | +40.2 |
| CHARGE LOSSES | 119 | 110 | 7 | 2.33 | +433 | +61.9 |
| MARCH BY THE SUM | 7 | 7 | 7 | 2.33 | +352 | +50.2 |
| MAX FOR POSITIONING | 40 | 37 | 7 | 2.33 | +29 | +4.2 |
| RISK BY ARC | 14 | 12 | 7 | 2.33 | +305 | +43.6 |
| SET UP BY THE SET | 18 | 17 | 7 | 2.33 | +263 | +37.6 |
| WHOLE FIGHT DANGER | 15 | 15 | 7 | 2.33 | +1604 | +229.2 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 6 | 6 | 6 | 2.00 | +1276 | +212.6 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +137 | +27.3 |
| STAY WORTH | 108 | 93 | 5 | 1.67 | +55 | +10.9 |
| IDLE COST | 52 | 35 | 4 | 1.33 | +32 | +8.0 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | -1064 | -265.9 |
| PROMISE KNOWS THE FIGHT | 10 | 6 | 4 | 1.33 | -37 | -9.3 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| EXACT ROUND | 8 | 8 | 3 | 1.00 | +44 | +14.5 |
| FALLS SHORT | 62 | 49 | 3 | 1.00 | +8 | +2.8 |
| STUCK PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHAFF IN THE MOVE | 3 | 3 | 2 | 0.67 | +0 | +0.0 |
| FIGHT TO THE END | 6 | 4 | 2 | 0.67 | +61 | +30.6 |
| HONEST WORTH | 14 | 12 | 2 | 0.67 | +27 | +13.7 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +125 | +62.4 |
| MARCH CHECK | 6 | 6 | 2 | 0.67 | +43 | +21.6 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -104 | -52.1 |
| NEARER NOT NEEDED | 36 | 34 | 2 | 0.67 | +68 | +34.0 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.67 | -21 | -10.7 |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +24 | +11.9 |
| TIED UP BY THE SUM | 3 | 3 | 2 | 0.67 | +51 | +25.6 |
| WHOLE FIGHT GAIN | 3 | 3 | 2 | 0.67 | +229 | +114.3 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +261 | +261.3 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +17 | +16.9 |
| CHARGE NOW FIRST | 9 | 9 | 1 | 0.33 | -19 | -19.4 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +28 | +28.2 |
| GUN MASK | 4 | 4 | 1 | 0.33 | +4 | +4.0 |
| HIS CHARGE DENIED | 1 | 1 | 1 | 0.33 | +5 | +5.4 |
| HIS MOVE AND SHOT | 56 | 54 | 1 | 0.33 | +7 | +6.7 |
| HUNT IN PAIRS | 8 | 5 | 1 | 0.33 | +0 | +0.0 |
| MANOEUVRE | 5 | 5 | 1 | 0.33 | +16 | +15.5 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| OWN CAST FIRST | 1 | 1 | 1 | 0.33 | -25 | -25.1 |
| REDIRECT FOR A FRIEND IN REACH | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +22 | +22.3 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -35 | -34.6 |
| SEARCH SPOT | 1 | 1 | 1 | 0.33 | +5 | +5.3 |
| SHOT REPLANNED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 19 | 19 | 1 | 0.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 61 | 36 | 1 | 0.33 | +20 | +19.6 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLANNED TARGET | 28 | 28 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 4 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 44 | 44 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 7 | not checked | - | - | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 12 | 10 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 36 | not checked | - | - | - | - |
| FOOT FIRST | 47 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 18 | 14 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 13 | 13 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 15 | 11 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 92 | 83 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 37 | 36 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 22 | 19 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 22 | 20 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 36 | 29 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 43 | 43 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 4 | 4 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HOLD ODDS | 80 | 80 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 14 | 14 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 3 | 3 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 12 | 10 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 11 | 11 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 5 | 5 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 65 | 42 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 1 | not checked | - | - | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NEAREST TO GOAL | 5 | 5 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 14 | 13 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 4 | 4 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 42 | 28 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 2 | 2 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 22 | 14 | 0 | 0.00 | - | - |
| ONE ROUTE | 5 | 5 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 2 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 236 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 6 | 6 | 0 | 0.00 | - | - |
| REAL GROUND | 5 | 5 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 5 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 13 | 12 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 11 | 9 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 9 | 8 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 62 | not checked | - | - | - | - |
| SPELL WORTH | 9 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 41 | 34 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 18 | 18 | 0 | 0.00 | - | - |
| STANDS STILL | 194 | 190 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 21 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 20 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 14 | not checked | - | - | - | - |
| THE TABLE BINDS | 244 | not checked | - | - | - | - |
| WAITS AGAIN | 10 | 9 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 1 | 1 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | not checked | - | - | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | not checked | - | - | - | - |
| WOUNDS ON THE RANKS | 8 | 8 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p7

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 6.00 | 5.67 | 50.1 |
| PROMISE BY ITS OWN SUM | rule | 6.33 | 2.00 | 57.1 |
| ARMY TABLE | rule | 1.00 | 6.67 | 69.1 |
| PROMISE SHOT AWAY | rule | 2.67 | - | 17.2 |
| NO REASON | gate | - | 1.67 | 34.6 |
| JOINT CHARGE NOW | rule | 0.33 | 1.00 | 265.9 |
| PROMISE KNOWS THE FIGHT | rule | 0.67 | 0.67 | 9.3 |
| FALLBACK | gate | - | 0.67 | 63.3 |
| MARCH OF THE TABLE | rule | 0.67 | - | 52.1 |
| PIVOT GUARDS FLANK | rule | 0.67 | - | 10.7 |
| CHARGE NOW FIRST | rule | 0.33 | - | 19.4 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 43.4 |
| OWN CAST FIRST | rule | 0.33 | - | 25.1 |
| REFUSING RETIRES | rule | - | 0.33 | 34.6 |
| RULE SWITCHED OFF | gate | 0.33 | - | 7.8 |

### Plans: gs3-83c8646-p7

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.7 | 38% | 354 | 211 | 59% |
| Mine | move | 21.3 | 100% | 1398 | 0 | 0% |
| Mine | shoot | 14.0 | 50% | 934 | 899 | 96% |
| Opponent | charge | 1.3 | 25% | 179 | 120 | 67% |
| Opponent | join | 2.3 | 100% | 123 | 0 | 0% |
| Opponent | move | 35.0 | 92% | 1955 | 0 | 0% |
| Opponent | shoot | 1.3 | 25% | 23 | 18 | 76% |
| Opponent | support | 0.7 | 50% | 41 | 0 | 0% |

### Packages: hunt the guns, gs3-83c8646-p7

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Opponent | 0.3 | 1 | 0 | 0% | 0% | 0% | - | 398 | 0 | 0% | 80 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 123 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 1.0 | 1 | 0 | 0% | 0% | 0% | - | 398 | 0 | 0% | 116 |

### Battle groups: gs3-83c8646-p7

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 1.7 | 40% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p7

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 9 | 46 (9) | 46 | 0 | 10 | 22% | 2.3 | 46 (2) | 46 (7) | - | 11 (5) | 79 (4) |
| Mine | Clean-up | 2 | 41 (2) | 0 | 41 | 0 | 0% | 3.5 | 0 (1) | 77 (1) | - | 41 (2) | - |
| Mine | Fast Hammer | 4 | 50 (4) | 14 | 35 | 0 | 25% | 2.7 | 48 (2) | 50 (2) | - | 63 (3) | 25 (1) |
| Mine | Holder | 1 | 140 (1) | 0 | 140 | 0 | 0% | 1.0 | 140 (1) | - | - | 140 (1) | - |
| Mine | Shooter | 4 | 62 (4) | 0 | 62 | 0 | 25% | 2.7 | 11 (2) | 111 (2) | - | 46 (2) | 70 (2) |
| Mine | War machine | 6 | 24 (6) | 24 | 0 | 17 | 0% | 1.0 | 35 (2) | 37 (2) | 0 (2) | 0 (1) | 29 (5) |
| Mine | Wizard | 3 | 52 (3) | 52 | 0 | 0 | 0% | 1.7 | 0 (2) | 99 (1) | - | 52 (3) | - |
| Opponent | Chaff | 2 | 225 (2) | 0 | 225 | 100 | 0% | 4.0 | - | 450 (1) | 0 (1) | 225 (2) | - |
| Opponent | Character | 10 | 0 (10) | 0 | 0 | 31 | 70% | 2.0 | 0 (3) | 0 (5) | 0 (2) | 0 (5) | 0 (5) |
| Opponent | Fast Hammer | 9 | 31 (9) | 0 | 31 | 46 | 56% | 4.2 | 0 (2) | 39 (7) | - | 14 (5) | 55 (4) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 37 | 67% | 3.0 | 0 (2) | 0 (1) | - | 0 (2) | 0 (1) |
| Opponent | Holder | 5 | 14 (5) | 0 | 14 | 0 | 100% | - | 0 (2) | 0 (2) | 59 (1) | 27 (2) | 0 (3) |
| Opponent | Shooter | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | - | 0 (1) | - | 0 (1) |

### Charged fights: gs3-83c8646-p7

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 3 | 500 | 90 | 2.3 | 1.0 | 39 | 0 | +39 | 4 of 7 | 5 of 7 | - | +39 |
| Opponent | High Elf Realms | 1 | 0 | 0 | 3.0 | 1.0 | 0 | 0 | +0 | 3 of 3 | 0 of 3 | - | +0 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 0 | 0 | 1.3 | 1.0 | 0 | 0 | +0 | 4 of 4 | 0 of 4 | - | +0 |

### Effective charges: gs3-83c8646-p7

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 7 | 0 | 0 | 3 (net +50) | 0 | 2 (net +60) | 2 (net +0) | 0 | 43% (3 of 7) |
| Opponent | High Elf Realms | 3 | 0 | 1 (net +0) | 0 | 1 (net +0) | 0 | 1 (net +0) | 0 | 0% (0 of 3) |

### Charged fights, damage counted: gs3-83c8646-p7

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 3 | 261 | 364 | +50 | 168 | 16 | +152 | +58.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 260 | 189 | +0 | 70 | 0 | +70 | +26.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 356 | 60 | +60 | 60 | 0 | +60 | +16.8 |
| Mine | All fights | 7 | 288 | 227 | +39 | 109 | 7 | +102 | +35.5 |
| Opponent | 50-54% | 1 | 143 | 358 | +0 | 24 | 72 | -48 | -33.3 |
| Opponent | 76-89% | 1 | 489 | 358 | +0 | 9 | 0 | +9 | +1.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 489 | 358 | +0 | 0 | 244 | -244 | -50.0 |
| Opponent | No odds | 1 | 161 | 217 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | All fights | 4 | 320 | 323 | +0 | 8 | 79 | -71 | -22.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p7 | move | 28 | 4 (14%) | 3 (11%) | 3 (11%) | 21 (75%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1224 |
| Clockwork Compass | Mine | L1224 |
| Elixir of Power | Mine | L1114, L1131 |
| Invocation of Nehek | Opponent | L1224 |
| Opal Amulet | Opponent | L1114 |
| Ring of Doom | Mine | L1114, L1131, L1224 |
| Ring of Doom | Opponent | L1131 |
| Ring of Jet | Mine | L1114, L1131, L1224 |

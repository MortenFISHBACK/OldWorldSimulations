# Doctrine scorecard: gs3-83c8646-p49

### Scorecard: gs3-83c8646-p49

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 2 | 5 | 1 | 0 | 0 | 0 | 0 | 55 |
| L0102 | 6 | 1 | Opponent | no | 5 | 2 | 1 | 5 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Mine | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 0 | - | 1 | 3 | 0 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Mine | no | 7 | - | 0 | 1 | 0 | 0 | 0 | 55 |
| L0135 | 3 | 1 | Opponent | no | 3 | 2 | 2 | 5 | 0 | 0 | 0 | 224 |
| **Average** | | | Mine | 0% | 3.7 | 5.0 | 0.3 | 1.0 | 0.0 | 0.0 | 0.0 | 36.7 |
| **Average** | | | Opponent | 0% | 2.7 | 2.0 | 1.3 | 4.3 | 0.0 | 0.0 | 0.0 | 74.7 |

### KPIs: gs3-83c8646-p49

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 6) | 0% (0 of 13) | 0% (0 of 19) |
| Winner chose to follow up after the loser gave ground |  | - | - | - |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | 80% (4 of 5); on the table 80% | 83% (5 of 6); on the table 83% |
| Winner chose to follow up or pursue (all three) |  | 100% (2 of 2); on the table 100% | 80% (4 of 5); on the table 80% | 86% (6 of 7); on the table 86% |
| Magic missiles tried each own turn | 50%+ | 27% (24 of 90) | 17% (4 of 24) | 25% (28 of 114) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 29% (24 of 84) | 17% (4 of 24) | 26% (28 of 108) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 80% (4 of 5) | 80% (4 of 5) |
| Points that never fought | lower | 67% (3801 of 5700) | 91% (5372 of 5899) | 79% (9173 of 11599) |
|   infantry points that never fought | lower | 65% (1764 of 2703) | 100% (1219 of 1219) | 76% (2983 of 3922) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 67% (10 of 15) | 72% (18 of 25) | 70% (28 of 40) |
| Bound items with a magic missile used (at least once a game) |  | 100% (3 of 3); 4.0 uses a game | 50% (2 of 4); 2.3 uses a game | 71% (5 of 7); 3.2 uses a game |
| Bound items with another spell used |  | 100% (3 of 3); 1.3 uses a game | 0.0 uses a game | 100% (3 of 3); 0.7 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (3 of 3); 1.0 uses a game | 50% (1 of 2); 0.3 uses a game | 80% (4 of 5); 0.7 uses a game |
|   their share of the points of units over 100 pts | lower | 65% (2669 of 4077) | 74% (3594 of 4883) | 70% (6263 of 8960) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 15.0 (68%) | 5.7 (85%) | 20.7 (72%) |
| MARCHED: its unit marched | 1.7 (8%) | 1.0 (15%) | 2.7 (9%) |
| CHARGED: its unit charged | 0.7 (3%) | 0.0 (0%) | 0.7 (2%) |
| IN COMBAT: engaged in combat | 2.0 (9%) | 0.0 (0%) | 2.0 (7%) |
| STUPIDITY: Stupidity | 2.0 (9%) | 0.0 (0%) | 2.0 (7%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.7 (3%) | 0.0 (0%) | 0.7 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 9.7 | 2.0 | 8.3 | 9.3 | 1.7 |
| not cast | 8.3 | 8.0 | 7.7 | 28.7 | 42.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 4.7 (58%) | 2.0 (26%) | 20.7 (72%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.7 (9%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (4%) | 0.7 (8%) | 1.0 (13%) | 2.0 (7%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| STUPIDITY: Stupidity | 1.0 (12%) | 0.0 (0%) | 2.0 (26%) | 2.0 (7%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (2%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 7.0 (84%) | 2.7 (33%) | 2.7 (35%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 41.0 (97%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 7.3 a game | 2.3 a game | 4.8 a game |
| stood (cast and not dispelled) | 68% (15 of 22) | 57% (4 of 7) | 66% (19 of 29) |
| the unit moved after it | 80% (12 of 15) | 25% (1 of 4) | 68% (13 of 19) |
| it charged on its next turn | 0% (0 of 15) | 0% (0 of 4) | 0% (0 of 19) |
| the enemy charged it first | 7% (1 of 15) | 0% (0 of 4) | 5% (1 of 19) |
| it fought by the end of its next turn | 7% (1 of 15) | 0% (0 of 4) | 5% (1 of 19) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 15) | 0% (0 of 4) | 0% (0 of 19) |
| none of these (no charge, no fight, no charge escaped) | 87% (13 of 15) | 100% (4 of 4) | 89% (17 of 19) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 39% (11 of 28) | 50% (36 of 72) | 47% (47 of 100) |
|   cavalry | - | 75% (9 of 12) | 75% (9 of 12) |
|   character | - | 58% (7 of 12) | 58% (7 of 12) |
|   chariot | - | 50% (6 of 12) | 50% (6 of 12) |
|   infantry | 39% (11 of 28) | 21% (5 of 24) | 31% (16 of 52) |
|   monster | - | 75% (9 of 12) | 75% (9 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (29%) | 2.7 (22%) | 4.3 (25%) |
| CHARGED: it charged | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| FLEEING: it fled or was fleeing | 0.3 (6%) | 0.0 (0%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.3 (6%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 1.7 (29%) | 6.7 (56%) | 8.3 (47%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (24%) | 0.7 (6%) | 2.0 (11%) |
| SHELTERED: the target was sheltered | 0.3 (6%) | 0.7 (6%) | 1.0 (6%) |
| OTHER BAR | 0.0 (0%) | 1.0 (8%) | 1.0 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.7 | 2.0 | 64% | 3.2 pts | 15 pts |
| character | 2.3 | 3.3 | 29% | 11.1 pts | 26 pts |
| chariot | 2.0 | 2.3 | 83% | 9.4 pts | 19 pts |
| infantry | 5.3 | 1.7 | 75% | 2.8 pts | 15 pts |
| monster | 3.0 | 3.7 | 33% | 9.8 pts | 30 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.3 | 2.7 | 1.5 |
| Charges that made contact a game | 0.0 | 2.0 | 1.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.07 declared, 0.00 contact (15 units) | 0.25 declared, 0.19 contact (32 units) | 0.19 declared, 0.13 contact (47 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (2 of 3) | - | - | 67% (2 of 3) |
| Character in a unit | 60% (3 of 5) | 100% (10 of 10) | - | 87% (13 of 15) |
| Character on its own | - | 100% (1 of 1) | 100% (1 of 1) | 100% (2 of 2) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 80% (4 of 5) | 29% (2 of 7) | - | 50% (6 of 12) |
| Monster | 0% (0 of 1) | 100% (1 of 1) | - | 50% (1 of 2) |
| Monstrous | 50% (1 of 2) | 50% (1 of 2) | - | 50% (2 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 75% (3 of 4); on the table 75% | 24% (26 of 108) | 72% | 62% (13 of 21) | 100% (5 of 5); 4.8 uses a game | 100% (3 of 3); 1.0 uses a game | 80% (4 of 5); 1.0 uses a game |
| Ogre Kingdoms | 1 | 100% (2 of 2); on the table 100% | - | 97% | 86% (6 of 7) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (1 of 1); on the table 100% | 33% (2 of 6) | 90% | 75% (9 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p49, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 67% (2) | - | 67% (2) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.00 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: gs3-83c8646-p49

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.0 | 1.7 |
| Strategy | Charge objectives carried out (made contact) | - | 50% (3 of 6) |
| Strategy | Shoot objectives carried out (shot that target) | 8% (2 of 24) | 19% (4 of 21) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 3) | 50% (1 of 2) |
| Strategy | Joined characters whose unit fought | 29% (5 of 17) | 0% (0 of 7) |
| Strategy | Lone characters that fought | 100% (1 of 1) | 0% (0 of 3) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.0 | 4.3 |
| Movement | Points that never moved of their own | 36.7 | 74.7 |
| Movement | Fights charged into per game | 0.0 | 1.7 |
| Movement | Charges with odds: long shots (under 50%) | - | 1 of 5, net +55 |
| Movement | Charges with odds: sweet spot (55-75%) | - | 1 of 5, net -102 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | - | 0 of 5 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | - | 3 of 5, net +90 |
| Shooting | Shots by shooting units (incl. breath weapons) | 3.7 | 12.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (5 of 11) | 78% (28 of 36) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 5.3 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 12% (2 of 16) | 0% (0 of 3) |
| Magic | Wounds caused by magic missiles | 22.7 | 6.0 |
| Magic | Points destroyed by magic (all spells) | 121.3 | 21.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 6.3 / 1.0 / 1.3 / 0.0 | 1.3 / 0.7 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 0.0 | 50.0 |
| Combat | Points run down | 0.0 | 21.7 |
| Combat | Net points per charged fight, damage counted | - | +64 |
| Combat | Net per 100 charger points, damage counted | - | +72.6 |
| Combat | First round won (charged fights) | - | 60% |
| Combat | Net points per charged fight | - | +45 |
| Combat | Net points per supported fight / lone fight | - / - | +55 / +42 |
| Combat | Charged fights on a top-3 enemy unit | - | 2 of 5 |
| Game | Points lost | 151.7 | 230.0 |
| Game | VP from objectives | 823.3 | 670.0 |
| Game | Lone holders (player turns) | 3.7 | 2.7 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +274 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 382
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p49

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 36.7 |
| ARMY TABLE | 4.7 | -15.7 | 0.0 | 101.7 | 16.0 | +25.5 | 0.0 | 0.0 |
| CAST JOB | - | - | - | - | 2.0 | +15.1 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 9.0 | +1130.1 | 333.3 | 0.0 | 1.3 | +36.2 | 43.3 | 0.0 |
| CASTS AFTER FRIENDS | 4.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 2.0 | +56.1 | 0.0 | 0.0 |
| CHARGE LOSSES | 11.7 | -210.6 | 0.0 | 108.3 | 11.7 | -451.7 | 0.0 | 166.7 |
| CHARGE NOW FIRST | - | - | - | - | 0.3 | +0.0 | 18.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 3.0 | +0.0 | 0.0 | 18.3 | 15.3 | +0.0 | 0.0 | 83.3 |
| CONVEYANCE SEARCH | 6.3 | +818.9 | 0.0 | 0.0 | 2.3 | +57.5 | 0.0 | 0.0 |
| COVER ONCE | 1.7 | -27.2 | 0.0 | 0.0 | 3.3 | -118.1 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 5.0 | +41.5 | 0.0 | 0.0 | 10.0 | -145.9 | 0.0 | 74.7 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +1.9 | 18.3 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 1.0 | +9.6 | 21.7 | 0.0 |
| EXACT ROUND | - | - | - | - | 1.7 | +56.6 | 55.0 | 34.0 |
| FALL BACK GOOD ORDER | - | - | - | - | 1.7 | +0.0 | 36.7 | 34.0 |
| FALLS SHORT | 3.0 | +100.1 | 0.0 | 18.3 | 16.0 | +220.0 | 0.0 | 28.0 |
| FEATURE BUFFS | 10.7 | +513.3 | 0.0 | 200.0 | 1.3 | +50.3 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.7 | +5.1 | 18.3 | 34.0 |
| FIVE ACTION | 47.7 | +8444.5 | 416.7 | 335.0 | 105.7 | +4004.7 | 135.0 | 256.7 |
| FLANK NOT WEIGHED | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| FOUR ROUNDS | - | - | - | - | 2.0 | +33.1 | 55.0 | 34.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.7 | -2.4 | 0.0 | 0.0 |
| GOAL ROUTE | 0.7 | +67.2 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 4.7 | +589.6 | 0.0 | 0.0 | - | - | - | - |
| GROUND FLIERS | - | - | - | - | 0.3 | +6.1 | 0.0 | 0.0 |
| GUN FIGURES | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 4.0 | +0.0 | 0.0 | 65.0 | 5.3 | +0.0 | 0.0 | 83.3 |
| HIS CHARGE LIST | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 1.3 | +0.0 | 0.0 | 21.7 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.3 | -37.3 | 0.0 | 73.3 | 5.3 | -210.6 | 0.0 | 56.0 |
| HIS ONE QUARTER | 2.0 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 1.3 | +0.0 | 0.0 | 21.7 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 6.7 | +0.0 | 0.0 | 86.7 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.0 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 22.3 | +352.4 | 0.0 | 178.3 | 52.0 | +2924.8 | 0.0 | 83.3 |
| HIS SHOTS BY HIS RUN | 25.7 | +177.9 | 0.0 | 280.0 | 45.0 | +1074.0 | 0.0 | 222.7 |
| HOLD ODDS | 27.0 | +0.0 | 0.0 | 295.0 | 14.3 | +0.0 | 0.0 | 56.0 |
| HOLDER ASSIGNMENT | 15.0 | +1730.9 | 0.0 | 83.3 | 10.7 | +1074.9 | 0.0 | 66.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | - | - | - | - | 1.7 | -25.0 | 55.0 | 34.0 |
| IDLE COST | 0.7 | -3.9 | 0.0 | 0.0 | 24.7 | -273.1 | 0.0 | 83.3 |
| KEPT FROM ITS LAST STOP | 2.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 7.3 | +0.0 | 0.0 | 266.7 | - | - | - | - |
| LONE WIZARD KEPT IN | 3.0 | +270.0 | 0.0 | 0.0 | 0.7 | +87.5 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.7 | +5.4 | 18.3 | 34.0 |
| LOST AFTER ESCAPE | - | - | - | - | 1.3 | +0.8 | 18.3 | 34.0 |
| MANOEUVRE | 0.7 | +10.7 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.7 | +97.9 | 0.0 | 0.0 | 0.3 | +2.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +26.1 | 0.0 | 0.0 | 1.7 | +89.5 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.7 | -56.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.0 | +8.8 | 0.0 | 18.3 | 0.3 | +0.5 | 0.0 | 0.0 |
| MEETS IN TIME | 1.7 | +224.8 | 0.0 | 0.0 | 7.7 | +309.7 | 0.0 | 74.7 |
| MISSILES IN THE MOVE | 8.0 | +792.0 | 0.0 | 0.0 | 7.3 | +104.5 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 8.0 | +459.3 | 0.0 | 0.0 | 6.3 | +56.2 | 0.0 | 0.0 |
| MISSILES ON ONE TARGET | 1.7 | -77.8 | 0.0 | 0.0 | 0.7 | -4.1 | 0.0 | 0.0 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 2.0 | -168.0 | 0.0 | 0.0 | 1.0 | -2.8 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | - | - | - | - | 2.3 | +237.2 | 0.0 | 0.0 |
| MOVES UNITS SPELL | - | - | - | - | 0.3 | +18.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.7 | +262.9 | 0.0 | 21.7 | 3.0 | +141.5 | 0.0 | 0.0 |
| NEAREST TO GOAL | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | - | - | - | - | 1.3 | +60.9 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | - | - | - | - | 1.7 | -37.4 | 55.0 | 34.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 3.0 | -5.1 | 0.0 | 0.0 | 2.3 | -2.8 | 0.0 | 0.0 |
| OFF BEST | 0.7 | -4.5 | 0.0 | 21.7 | 1.3 | -11.1 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 2.0 | -29.1 | 0.0 | 36.7 | 2.0 | -34.2 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | -2.7 | 18.3 | 0.0 |
| ONE OBJECTIVE FORMULA | 7.0 | +126.4 | 0.0 | 61.7 | 4.3 | +9.5 | 0.0 | 28.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | -12.2 | 0.0 | 0.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 0.7 | +1.1 | 83.3 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | - | - | - | - | 1.0 | +24.7 | 55.0 | 0.0 |
| PLAN RESULT | 21.0 | +227.4 | 83.3 | 181.7 | 47.3 | +164.6 | 21.7 | 249.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.7 | -2.4 | 0.0 | 0.0 |
| QUARTER ODDS | 10.7 | +1921.9 | 0.0 | 0.0 | 23.7 | +2266.8 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 1.7 | +41.3 | 0.0 | 0.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.3 | +13.4 | 0.0 | 18.3 | 2.7 | +7.2 | 0.0 | 28.0 |
| REDIRECT FOR A FRIEND IN REACH | 1.3 | +0.0 | 0.0 | 73.3 | 3.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +9.9 | 0.0 | 0.0 |
| RESERVE MOVE SPELL | 1.7 | +167.1 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | - | - | - | - | 1.3 | -23.4 | 55.0 | 34.0 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 0.3 | -1.2 | 0.0 | 0.0 |
| RUN DOWN | - | - | - | - | 1.3 | -2.1 | 55.0 | 0.0 |
| SCOUT SPOT | 1.0 | +1.2 | 0.0 | 0.0 | 0.7 | +2.1 | 0.0 | 0.0 |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.0 | -170.4 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +37.4 | 0.0 | 0.0 | 0.7 | -1.3 | 0.0 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 1.7 | -82.3 | 0.0 | 0.0 |
| SET UP BY THE SET | - | - | - | - | 1.7 | +59.0 | 0.0 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +45.9 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.3 | +125.3 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.7 | -1.3 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 36.7 |
| SHOOTERS ON THE TABLE | 7.0 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 5.7 | +234.2 | 83.3 | 0.0 | 2.7 | +47.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.7 | -2.6 | 18.3 | 34.0 |
| SHOT RISK POINTS | 16.0 | -252.2 | 0.0 | 178.3 | 57.0 | +617.8 | 0.0 | 222.7 |
| SHOTS AFTER THE MOVES | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 4.3 | +78.1 | 0.0 | 43.3 | 13.7 | +125.1 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +45.9 | 0.0 | 0.0 |
| SPELL WORTH | 2.3 | +14.1 | 0.0 | 0.0 | 1.7 | +7.7 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 4.0 | +0.0 | 0.0 | 98.3 | 4.3 | +0.0 | 0.0 | 28.0 |
| STANDS FOR A REASON | - | - | - | - | 10.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 20.7 | +0.0 | 416.7 | 55.0 | 39.0 | +0.0 | 80.0 | 0.0 |
| STAY WORTH | 10.7 | +308.4 | 250.0 | 65.0 | 19.0 | +92.7 | 80.0 | 0.0 |
| STRIKE BY THE ODDS | - | - | - | - | 1.0 | +9.4 | 63.3 | 34.0 |
| STUBBORN BY POINTS | - | - | - | - | 0.3 | +9.9 | 0.0 | 34.0 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 1.0 | +87.5 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 1.0 | +87.5 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 0.7 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 41.7 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 22.0 | +0.0 | 0.0 | 156.7 | 51.3 | +0.0 | 0.0 | 111.3 |
| TIED UP BY THE SUM | - | - | - | - | 0.3 | +7.8 | 18.3 | 0.0 |
| TIME ON OUR SIDE | 16.3 | +475.8 | 0.0 | 193.3 | 19.0 | +146.0 | 0.0 | 0.0 |
| WAITS AGAIN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -7.9 | 0.0 | 0.0 |
| WHO FIGHTS | - | - | - | - | 1.0 | -81.3 | 18.3 | 34.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +4.5 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.0 | -35.9 | 0.0 | 43.3 | - | - | - | - |
| WOUNDS ON THE RANKS | 6.0 | +141.0 | 0.0 | 0.0 | 1.3 | +61.7 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p49

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 223 | 223 | 75 | 25.00 | +1246 | +16.6 |
| HOLDER ASSIGNMENT | 77 | 77 | 69 | 23.00 | +3566 | +51.7 |
| HIS SHOTS BY HIS RUN | 212 | 212 | 59 | 19.67 | +333 | +5.6 |
| ARMY TABLE | 62 | 62 | 49 | 16.33 | +194 | +4.0 |
| SHOT RISK POINTS | 219 | 219 | 48 | 16.00 | +723 | +15.1 |
| DEPLOY BY FIGURES | 45 | 45 | 30 | 10.00 | +432 | +14.4 |
| CASTING BLOCK | 31 | 31 | 25 | 8.33 | +881 | +35.2 |
| LEGAL CHARGES ONLY | 22 | 22 | 22 | 7.33 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 20 | 6.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 106 | 93 | 20 | 6.67 | +267 | +13.4 |
| HARD STAY DROPPED | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| STAY WORTH | 89 | 74 | 16 | 5.33 | +123 | +7.7 |
| MEETS IN TIME | 28 | 28 | 14 | 4.67 | +257 | +18.3 |
| REDIRECT FOR A FRIEND IN REACH | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| IDLE COST | 76 | 63 | 12 | 4.00 | +82 | +6.8 |
| LONE WIZARD KEPT IN | 11 | 11 | 11 | 3.67 | +1073 | +97.5 |
| SHOOTS FROM THE BEST SPOT | 25 | 25 | 10 | 3.33 | +220 | +22.0 |
| FEATURE BUFFS | 36 | 36 | 9 | 3.00 | +50 | +5.6 |
| QUARTER ODDS | 103 | 103 | 9 | 3.00 | +1081 | +120.1 |
| WOUNDS ON THE RANKS | 22 | 22 | 9 | 3.00 | +142 | +15.7 |
| CASTER AWAY FROM SCREEN | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| MISSILES IN THE MOVE | 46 | 32 | 8 | 2.67 | +554 | +69.2 |
| FIVE ACTION | 460 | 460 | 7 | 2.33 | +506 | +72.3 |
| GOAL WALK | 14 | 14 | 7 | 2.33 | +1312 | +187.5 |
| CAST JOB | 6 | 6 | 6 | 2.00 | +7 | +1.1 |
| CHAFF IN THE MOVE | 6 | 6 | 6 | 2.00 | +51 | +8.5 |
| MARCH CHECK | 7 | 7 | 6 | 2.00 | +212 | +35.3 |
| MOVE ORDER | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 7 | 7 | 6 | 2.00 | +497 | +82.8 |
| OFF BEST | 6 | 6 | 6 | 2.00 | -47 | -7.8 |
| SCOUT WAITS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHARGE LOSSES | 70 | 70 | 5 | 1.67 | +434 | +86.8 |
| FALLS SHORT | 57 | 47 | 5 | 1.67 | +108 | +21.5 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| RESERVE MOVE SPELL | 5 | 5 | 5 | 1.67 | +501 | +100.2 |
| MISSILES NEXT TURN | 43 | 32 | 4 | 1.33 | +25 | +6.3 |
| NEXT CHARGE BY LIST | 4 | 4 | 4 | 1.33 | +115 | +28.7 |
| RANDOM MOVE BY FIGURES | 5 | 5 | 4 | 1.33 | +124 | +31.0 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +300 | +99.9 |
| MAX FOR POSITIONING | 4 | 4 | 3 | 1.00 | +5 | +1.8 |
| ONE OBJECTIVE FORMULA | 34 | 21 | 3 | 1.00 | +99 | +33.0 |
| REDIRECT COUNTER | 9 | 7 | 3 | 1.00 | +47 | +15.6 |
| SEARCH SPOT | 4 | 4 | 3 | 1.00 | +118 | +39.3 |
| STRIKE BY THE ODDS | 3 | 3 | 3 | 1.00 | +28 | +9.4 |
| COVER ONCE | 15 | 9 | 2 | 0.67 | +7 | +3.4 |
| EXACT ROUND | 5 | 5 | 2 | 0.67 | +76 | +38.1 |
| FOUR ROUNDS | 6 | 6 | 2 | 0.67 | +16 | +7.9 |
| GOAL ROUTE | 2 | 2 | 2 | 0.67 | +5 | +2.6 |
| NEARER NOT NEEDED | 26 | 23 | 2 | 0.67 | +63 | +31.5 |
| OVERRUNS AWAY | 3 | 3 | 2 | 0.67 | +34 | +16.8 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +1 | +1.3 |
| EVASIVE BY THE ODDS | 3 | 3 | 1 | 0.33 | +4 | +4.1 |
| FIGHT TO THE END | 2 | 2 | 1 | 0.33 | +14 | +14.5 |
| HIS MOVE AND SHOT | 29 | 29 | 1 | 0.33 | +0 | +0.0 |
| LANE BY FIGURES | 1 | 1 | 1 | 0.33 | +2 | +1.7 |
| LONG SHOT | 2 | 2 | 1 | 0.33 | +12 | +12.0 |
| MANOEUVRE | 5 | 5 | 1 | 0.33 | +32 | +32.1 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -37 | -36.6 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +30 | +29.6 |
| RISK BY ARC | 4 | 4 | 1 | 0.33 | +1 | +1.3 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +30 | +29.6 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SUPPORT ADDS | 3 | 3 | 1 | 0.33 | +39 | +38.9 |
| SUPPORT WORKED OUT | 3 | 3 | 1 | 0.33 | +39 | +38.9 |
| THE ROW IN ITS ORDER | 6 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 6 | 6 | 1 | 0.33 | +14 | +13.5 |
| CASTS AFTER FRIENDS | 18 | trace | - | - | - | - |
| CHARGE NOW FIRST | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 55 | 55 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 26 | not checked | - | - | - | - |
| FALL BACK GOOD ORDER | 5 | 5 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 9 | not checked | - | - | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 6 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 28 | 28 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 12 | 12 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 19 | 19 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 28 | 28 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 19 | 19 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 20 | 20 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 6 | 6 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 124 | 124 | 0 | 0.00 | - | - |
| HONEST WORTH | 5 | 5 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 15 | 15 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 4 | 4 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 7 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 9 | trace | - | - | - | - |
| MOVE SPELL SPOT | 6 | not checked | - | - | - | - |
| NEAREST TO GOAL | 2 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 5 | 5 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 16 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 12 | 8 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS A LANE | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 205 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE BY ITS OWN SUM | 6 | 6 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 4 | 4 | 0 | 0.00 | - | - |
| SCOUT SPOT | 5 | 5 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 5 | 5 | 0 | 0.00 | - | - |
| SET UP BY THE SET | 5 | 5 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 44 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 12 | 12 | 0 | 0.00 | - | - |
| SHOTS IN THE MOVE | 54 | 36 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 25 | 25 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 30 | 30 | 0 | 0.00 | - | - |
| STANDS STILL | 179 | 179 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 23 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 13 | not checked | - | - | - | - |
| THE TABLE BINDS | 220 | not checked | - | - | - | - |
| TIED UP BY THE SUM | 1 | 1 | 0 | 0.00 | - | - |
| WAITS AGAIN | 2 | 2 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p49

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | rule | 1.33 | 1.00 | 5.7 |
| JOB FIRST | gate | 0.67 | 1.33 | 7.8 |
| ARMY TABLE | rule | 0.67 | - | 245.1 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 36.6 |

### Plans: gs3-83c8646-p49

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | move | 14.7 | 84% | 1818 | 0 | 0% |
| Mine | shoot | 6.3 | 37% | 1551 | 227 | 15% |
| Opponent | charge | 1.3 | 75% | 17 | 60 | 351% |
| Opponent | move | 40.0 | 96% | 1263 | 0 | 0% |
| Opponent | shoot | 5.0 | 53% | 218 | 104 | 48% |
| Opponent | support | 1.0 | 100% | 9 | 0 | 0% |

### Battle groups: gs3-83c8646-p49

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 100% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 2.7 | 12% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p49

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 3 | 0 (3) | 0 | 0 | 100 | 0% | 2.3 | 0 (1) | 0 (1) | 0 (1) | 0 (2) | 0 (1) |
| Mine | Character | 18 | 12 (18) | 12 | 0 | 3 | 33% | 1.7 | 76 (3) | 0 (11) | 0 (3) | 20 (11) | 0 (6) |
| Mine | Hammer | 6 | 39 (6) | 0 | 39 | 0 | 67% | 4.5 | 75 (1) | 40 (4) | 0 (1) | 35 (4) | 47 (2) |
| Mine | Holder | 3 | 26 (3) | 0 | 26 | 0 | 100% | - | - | 39 (2) | - | - | 39 (2) |
| Mine | Shooter | 6 | 92 (6) | 0 | 92 | 50 | 0% | 2.8 | - | 111 (5) | 0 (1) | 127 (4) | 23 (2) |
| Opponent | Chaff | 6 | 33 (6) | 22 | 12 | 12 | 67% | 3.0 | 38 (3) | 43 (2) | 0 (1) | 33 (6) | - |
| Opponent | Character | 8 | 3 (8) | 3 | 0 | 0 | 25% | 1.3 | 0 (4) | 7 (4) | - | 6 (4) | 0 (4) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 7 | 34 (7) | 9 | 25 | 0 | 57% | 2.0 | 95 (1) | 0 (3) | 25 (3) | 29 (3) | 36 (4) |
| Opponent | Hammer | 13 | 32 (13) | 10 | 23 | 16 | 38% | 2.1 | - | 46 (8) | 0 (5) | 16 (3) | 38 (10) |
| Opponent | Holder | 1 | 179 (1) | 0 | 179 | 100 | 100% | - | - | 179 (1) | - | - | 179 (1) |
| Opponent | Shooter | 3 | 74 (3) | 0 | 74 | 62 | 67% | 1.0 | 193 (1) | 0 (2) | - | 193 (1) | 0 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (2) | - | 0 (2) | - |

### Charged fights: gs3-83c8646-p49

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 121 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Beastmen Brayherds | 1 | 65 | 150 | 2.0 | 1.0 | 75 | 0 | +75 | 1 of 2 | 1 of 2 | - | +75 |
| Opponent | Ogre Kingdoms | 1 | 0 | 55 | 1.0 | 2.0 | 55 | 0 | +55 | 0 of 1 | 1 of 1 | +55 | - |
| Opponent | Wood Elf Realms | 1 | 0 | 120 | 2.0 | 1.0 | 60 | 51 | +9 | 1 of 2 | 1 of 2 | - | +9 |
| **Opponent** | all armies | 3 | 22 | 108 | 1.7 | 1.2 | 65 | 20 | +45 | 2 of 5 | 3 of 5 | +55 | +42 |

### Effective charges: gs3-83c8646-p49

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Beastmen Brayherds | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +75) | 0 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 1 | 1 (net +55) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Wood Elf Realms | 2 | 0 | 0 | 1 (net -102) | 0 | 0 | 1 (net +120) | 0 | 50% (1 of 2) |

### Charged fights, damage counted: gs3-83c8646-p49

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Long shot (under 50%) | 1 | 68 | 55 | +55 | 55 | 8 | +46 | +68.4 |
| Opponent | Effective (55-75%) | 1 | 102 | 322 | -102 | 32 | 143 | -111 | -108.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 91 | 144 | +90 | 152 | 24 | +128 | +141.6 |
| Opponent | All fights | 5 | 88 | 162 | +45 | 109 | 44 | +64 | +72.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p49 | move | 5 | 1 (20%) | 1 (20%) | 1 (20%) | 3 (60%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135 |
| Fistful of Laurels | Opponent | L0118 |
| Ring of Doom | Opponent | L0102 |

# Doctrine scorecard: gs3-83c8646-p62

### Scorecard: gs3-83c8646-p62

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0222 | 6 | 1 | Mine | no | 1 | 2 | 2 | 3 | 1 | 0 | 0 | 0 |
| L0222 | 6 | 1 | Opponent | yes | 1 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | yes | 10 | - | 0 | 2 | 0 | 0 | 0 | 360 |
| L0307 | 1 | 1 | Opponent | no | 8 | 5 | 1 | 2 | 1 | 0 | 0 | 125 |
| L0323 | 5 | 1 | Mine | yes | - | 4 | 1 | 2 | 1 | 0 | 0 | 535 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 4 | 2 | 0 | 0 | 0 | 60 |
| **Average** | | | Mine | 67% | 5.5 | 3.0 | 1.0 | 2.3 | 0.7 | 0.0 | 0.0 | 298.3 |
| **Average** | | | Opponent | 67% | 4.5 | 3.0 | 3.3 | 1.7 | 0.3 | 0.0 | 0.0 | 61.7 |

### KPIs: gs3-83c8646-p62

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 60% (9 of 15) | 0% (0 of 16) | 29% (9 of 31) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | 100% (3 of 3); on the table 100% | 100% (5 of 5); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (2 of 2); on the table 100% | 100% (5 of 5); on the table 100% | 100% (7 of 7); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 50% (18 of 36) | 50% (3 of 6) | 50% (21 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 51% (18 of 35) | 75% (3 of 4) | 54% (21 of 39) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (2 of 3) | - | 67% (2 of 3) |
| Points that never fought | lower | 56% (3309 of 5897) | 72% (4304 of 5999) | 64% (7613 of 11896) |
|   infantry points that never fought | lower | 54% (770 of 1437) | 94% (883 of 938) | 70% (1653 of 2375) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 64% (14 of 22) | 45% (9 of 20) | 55% (23 of 42) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 75% (3 of 4); 1.0 uses a game | 0% (0 of 1); 0.0 uses a game | 60% (3 of 5); 0.5 uses a game |
|   their share of the points of units over 100 pts | lower | 55% (2488 of 4484) | 40% (1874 of 4648) | 48% (4362 of 9132) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.7 (61%) | 0.0 (0%) | 3.7 (52%) |
| MARCHED: its unit marched | 2.0 (33%) | 0.3 (33%) | 2.3 (33%) |
| FLEEING: fleeing | 0.3 (6%) | 0.0 (0%) | 0.3 (5%) |
| GONE: slain | 0.0 (0%) | 0.7 (67%) | 0.7 (10%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 6.0 | 1.3 | 7.0 | 0.3 | 0.3 |
| not cast | 0.0 | 2.7 | 7.0 | 1.7 | 7.7 |
| NO TARGET: no enemy in range, sight and arc it may target | - | 0.0 (0%) | 3.7 (52%) | 0.3 (20%) | 0.0 (0%) |
| MARCHED: its unit marched | - | 0.0 (0%) | 2.3 (33%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | - | 0.0 (0%) | 0.3 (5%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | - | 0.0 (0%) | 0.7 (10%) | 0.7 (40%) | 1.3 (17%) |
| OTHER BAR: another bar (miscast, baggage ...) | - | 0.0 (0%) | 0.0 (0%) | 0.7 (40%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | - | 2.7 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 6.3 (83%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.0 a game | 0.7 a game |
| stood (cast and not dispelled) | 50% (2 of 4) | - | 50% (2 of 4) |
| the unit moved after it | 50% (1 of 2) | - | 50% (1 of 2) |
| it charged on its next turn | 0% (0 of 2) | - | 0% (0 of 2) |
| the enemy charged it first | 0% (0 of 2) | - | 0% (0 of 2) |
| it fought by the end of its next turn | 0% (0 of 2) | - | 0% (0 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 2) | - | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | 100% (2 of 2) | - | 100% (2 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 84% (52 of 62) | 67% (72 of 108) | 73% (124 of 170) |
|   cavalry | - | 93% (13 of 14) | 93% (13 of 14) |
|   character | - | 0% (0 of 15) | 0% (0 of 15) |
|   chariot | 71% (17 of 24) | 67% (4 of 6) | 70% (21 of 30) |
|   infantry | - | 75% (46 of 61) | 75% (46 of 61) |
|   war machine | 92% (35 of 38) | 75% (9 of 12) | 88% (44 of 50) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.3 (40%) | 1.7 (14%) | 3.0 (20%) |
| CHARGED: it charged | 0.3 (10%) | 2.0 (17%) | 2.3 (15%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.7 (6%) | 0.7 (4%) |
| MOVED: a war machine that moved | 1.0 (30%) | 1.0 (8%) | 2.0 (13%) |
| NO TARGET IN RANGE | 0.3 (10%) | 5.7 (47%) | 6.0 (39%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (10%) | 0.3 (3%) | 0.7 (4%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.3 | 0.7 | 94% | 1.4 pts | 8 pts |
| chariot | 7.0 | 10.3 | 29% | 43.7 pts | 306 pts |
| infantry | 18.7 | 3.3 | 84% | 5.0 pts | 93 pts |
| war machine | 15.0 | 13.7 | 76% | 31.3 pts | 469 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.0 | 6.3 | 3.7 |
| Charges that made contact a game | 1.0 | 3.0 | 2.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (4 units) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.15 declared, 0.15 contact (20 units) | 0.63 declared, 0.30 contact (30 units) | 0.44 declared, 0.24 contact (50 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (2 of 3) | 0% (0 of 1) | - | 50% (2 of 4) |
| Character in a unit | 67% (2 of 3) | 50% (1 of 2) | - | 60% (3 of 5) |
| Character on its own | 100% (3 of 3) | - | 40% (2 of 5) | 62% (5 of 8) |
| Chariot | - | 25% (1 of 4) | - | 25% (1 of 4) |
| Infantry | 0% (0 of 2) | 33% (1 of 3) | - | 20% (1 of 5) |
| Monster | 40% (2 of 5) | - | - | 40% (2 of 5) |
| War Machines | 78% (7 of 9) | 100% (2 of 2) | - | 82% (9 of 11) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1 | 100% (2 of 2); on the table 100% | 50% (6 of 12) | 15% | 50% (3 of 6) | 100% (2 of 2); 6.0 uses a game | 0.0 uses a game | 50% (1 of 2); 1.0 uses a game |
| Chaos Dwarfs | 2 | - | 50% (12 of 24) | 76% | 69% (11 of 16) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Empire of Man | 1 | 100% (1 of 1); on the table 100% | 50% (3 of 6) | 91% | 70% (7 of 10) | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 2 | 100% (4 of 4); on the table 100% | - | 62% | 20% (2 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p62, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 67% (6) | 100% (1) | 70% (7) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.33 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.67 | 0.00 | 0.67 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.33 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p62

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 100% (3 of 3) | 33% (5 of 15) |
| Strategy | Shoot objectives carried out (shot that target) | 56% (31 of 55) | 59% (20 of 34) |
| Strategy | Joined characters whose unit fought | 83% (5 of 6) | 0% (0 of 3) |
| Strategy | Lone characters that fought | 17% (1 of 6) | 25% (2 of 8) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 2.3 | 1.7 |
| Movement | Points that never moved of their own | 298.3 | 61.7 |
| Movement | Fights charged into per game | 1.0 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 3 | 1 of 8, net -122 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 3 | 1 of 8, net +230 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 3, net +66 | 1 of 8, net +52 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 3, net +72 | 4 of 8, net +96 |
| Shooting | Shots by shooting units (incl. breath weapons) | 5.7 | 23.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 53% (9 of 17) | 41% (29 of 71) |
| Shooting | Points destroyed by shooting units | 266.0 | 36.7 |
| Shooting | War machine shots | 11.7 | 3.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 26% (9 of 35) | 67% (6 of 9) |
| Shooting | Points destroyed by war machines | 41.7 | 36.7 |
| Magic | Magic missiles cast | 3.0 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 67% (6 of 9) | 50% (1 of 2) |
| Magic | Wounds caused by magic missiles | 7.7 | 0.3 |
| Magic | Points destroyed by magic (all spells) | 24.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.3 / 0.0 | 5.3 / 0.0 / 0.0 / 0.3 |
| Combat | Points destroyed in combat | 86.7 | 210.0 |
| Combat | Points run down | 0.0 | 58.7 |
| Combat | Net points per charged fight, damage counted | +24 | +118 |
| Combat | Net per 100 charger points, damage counted | +17.0 | +48.6 |
| Combat | First round won (charged fights) | 100% | 78% |
| Combat | Net points per charged fight | +46 | +91 |
| Combat | Net points per supported fight / lone fight | - / +46 | - / +91 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 3 | 2 of 9 |
| Game | Points lost | 490.3 | 401.7 |
| Game | VP from objectives | 400.0 | 876.7 |
| Game | Lone holders (player turns) | 5.5 | 4.5 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -639 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 892
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p62

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 15.0 | +66.0 | 0.0 | 83.7 | 27.7 | +304.5 | 0.0 | 124.0 |
| ARTILLERY RE-ROLL WEIGHED | 3.7 | +0.0 | 0.0 | 46.7 | - | - | - | - |
| BLOCKED CHARGE SKIPPED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.7 | +0.0 | 150.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 10.7 | +125.6 | 313.3 | 233.3 | 3.0 | +96.4 | 36.7 | 0.0 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 41.7 |
| CAST JOB | 6.0 | +66.3 | 317.3 | 0.0 | 0.7 | +9.1 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 1.3 | +66.5 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CATCH FLIERS | 0.3 | +9.4 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.0 | +4.7 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +49.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LIST READ AGAIN | - | - | - | - | 0.3 | +94.6 | 0.0 | 0.0 |
| CHARGE LOSSES | 17.3 | -860.6 | 0.0 | 412.0 | 25.3 | -1026.9 | 0.0 | 578.7 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 70.7 | 17.3 | 3.0 | +0.0 | 206.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.3 | +0.0 | 0.0 | 170.7 | 15.7 | +0.0 | 0.0 | 96.7 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 56.7 | - | - | - | - |
| CONVEYANCE SEARCH | 1.0 | +216.2 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 13.0 | -737.4 | 0.0 | 255.7 | 4.3 | -75.2 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -4.3 | 28.3 | 0.0 |
| DEPLOY BY FIGURES | 9.0 | -61.4 | 0.0 | 0.0 | 7.3 | -45.6 | 0.0 | 41.7 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -77.1 | 0.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.7 | +26.9 | 153.3 | 0.0 |
| ENGINEER BY LORE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 1.0 | +7.3 | 46.0 | 34.7 | 4.7 | +37.3 | 418.3 | 0.0 |
| FALL BACK GOOD ORDER | 1.0 | +0.0 | 46.0 | 34.7 | 3.0 | +9.6 | 230.7 | 0.0 |
| FALLS SHORT | 10.0 | +201.7 | 0.0 | 173.3 | 15.3 | +138.0 | 0.0 | 170.7 |
| FEATURE BUFFS | 5.0 | +100.0 | 0.0 | 154.0 | 4.0 | +116.9 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +0.1 | 0.0 | 17.3 | - | - | - | - |
| FIVE ACTION | 94.7 | +3146.9 | 1775.3 | 1422.7 | 109.7 | +8605.0 | 1077.3 | 884.7 |
| FLANK NOT WEIGHED | 14.3 | +0.0 | 0.0 | 226.7 | 3.7 | +0.0 | 0.0 | 116.0 |
| FOLLOW UP WEIGHED | - | - | - | - | 0.7 | +166.2 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.0 | +8.8 | 46.0 | 34.7 | 6.7 | +483.2 | 446.7 | 40.7 |
| FREED FROM HIS FIGHT | 3.7 | +0.0 | 0.0 | 119.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 1.3 | -63.1 | 0.0 | 0.0 | 1.7 | -7.2 | 0.0 | 22.0 |
| GIVES UP | - | - | - | - | 0.7 | -11.4 | 31.7 | 0.0 |
| GOAL ON TIME | 0.7 | +114.2 | 0.0 | 0.0 | - | - | - | - |
| GOAL ROUTE | 1.0 | +25.9 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 12.3 | +758.0 | 0.0 | 0.0 | 17.7 | +2200.6 | 0.0 | 93.3 |
| GUN FIGURES | 3.0 | +52.6 | 58.7 | 0.0 | - | - | - | - |
| GUN MASK | - | - | - | - | 0.7 | -22.2 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 3.7 | +0.0 | 0.0 | 119.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 14.0 | +0.0 | 0.0 | 412.0 | 7.0 | +0.0 | 0.0 | 278.7 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +14.6 | 28.3 | 0.0 |
| HIS CHARGE LIST | 6.0 | +0.0 | 0.0 | 123.3 | - | - | - | - |
| HIS LEGAL MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 206.7 |
| HIS MOVE AND SHOT | 3.3 | -16.0 | 0.0 | 27.0 | 9.0 | -279.5 | 0.0 | 94.0 |
| HIS ONE QUARTER | 4.0 | +0.0 | 0.0 | 153.3 | 3.3 | +0.0 | 0.0 | 36.7 |
| HIS OWN BEST MOVE | 5.7 | +0.0 | 0.0 | 0.0 | 10.3 | +0.0 | 0.0 | 206.7 |
| HIS RANDOM MOVE | - | - | - | - | 7.3 | +0.0 | 0.0 | 72.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 47.0 | +883.8 | 0.0 | 691.3 | 56.3 | +1838.9 | 0.0 | 716.7 |
| HIS SHOTS BY HIS RUN | 51.3 | +608.6 | 0.0 | 904.0 | 52.0 | +1059.0 | 0.0 | 779.3 |
| HIS TURN DENIED | 0.7 | +3.0 | 24.0 | 34.7 | 0.3 | +3.7 | 0.0 | 0.0 |
| HOLD ODDS | 15.7 | +0.0 | 0.0 | 308.0 | 26.0 | +0.0 | 0.0 | 254.7 |
| HOLDER ASSIGNMENT | 7.7 | +707.3 | 0.0 | 87.7 | 16.7 | +1491.0 | 0.0 | 127.3 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -17.1 | 46.0 | 34.7 | 6.0 | -161.6 | 446.7 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 1.3 | +37.1 | 0.0 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.3 | +39.4 | 0.0 | 0.0 |
| IDLE COST | 6.7 | -38.8 | 0.0 | 80.0 | 14.7 | -205.9 | 0.0 | 217.3 |
| JOINT CHARGE NOW | - | - | - | - | 0.3 | +4.8 | 0.0 | 0.0 |
| KEEP FALLS | 0.3 | +6.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | - | - | - | - | 5.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 1.3 | +45.8 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 1.7 | +0.0 | 0.0 | 45.3 | 8.7 | +0.0 | 145.3 | 140.0 |
| LONE WIZARD KEPT IN | 0.7 | +17.5 | 0.0 | 0.0 | 1.0 | +78.3 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.3 | -1.1 | 0.0 | 17.3 | 2.3 | -2.4 | 232.7 | 0.0 |
| MANOEUVRE | 3.3 | -4.8 | 0.0 | 30.3 | 1.7 | +6.2 | 0.0 | 102.7 |
| MARCH AT ESCAPER | 0.7 | +3.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 1.0 | +61.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.7 | +28.4 | 0.0 | 27.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.3 | +8.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | -58.2 | 0.0 | 0.0 | 0.3 | +83.5 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.0 | +145.6 | 0.0 | 110.7 | 2.3 | +38.3 | 0.0 | 0.0 |
| MEETS IN TIME | 3.3 | +203.8 | 0.0 | 0.0 | 1.7 | +142.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 7.0 | +164.6 | 0.0 | 54.0 | 1.0 | +25.7 | 0.0 | 126.7 |
| MISSILES NEXT TURN | 7.7 | +105.7 | 0.0 | 54.0 | 1.3 | +32.7 | 0.0 | 126.7 |
| MISSILES ON ONE TARGET | 1.0 | -30.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 0.7 | +0.0 | 28.3 | 0.0 | 2.3 | +0.0 | 48.0 | 0.0 |
| MOVE SPELL SPOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 8.0 | +465.5 | 0.0 | 83.7 | 10.7 | +873.5 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 4.0 | +205.5 | 0.0 | 0.0 | 11.3 | +515.1 | 0.0 | 24.0 |
| NEAREST TO GOAL | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 4.0 | +189.4 | 0.0 | 0.0 | 5.0 | +427.7 | 113.3 | 0.0 |
| NO DOUBLE ROUNDS | 0.7 | -9.0 | 24.0 | 34.7 | 6.0 | -217.3 | 429.3 | 40.7 |
| NO LATE CUT | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 5.3 | -387.9 | 0.0 | 121.0 | 6.7 | -265.0 | 59.7 | 46.0 |
| OGRE LOADER SECOND SHOT | 3.0 | +1.7 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 6.0 | -60.9 | 0.0 | 55.3 | 11.3 | -257.9 | 0.0 | 167.3 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +76.1 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 5.3 | +28.0 | 0.0 | 87.7 | 5.0 | +102.2 | 0.0 | 127.3 |
| ONE PROMISE A TARGET | - | - | - | - | 0.7 | -42.7 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 1.3 | +40.9 | 79.3 | 0.0 |
| OVERRUNS AWAY | 0.7 | +82.0 | 46.0 | 17.3 | 0.3 | +7.5 | 30.3 | 0.0 |
| OWN CAST FIRST | 0.3 | -0.5 | 0.0 | 27.0 | - | - | - | - |
| PATHS CROSS | - | - | - | - | 0.7 | +21.7 | 0.0 | 0.0 |
| PLAN RESULT | 42.7 | +731.8 | 820.7 | 796.3 | 49.3 | +717.9 | 271.0 | 706.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 11.7 | -405.1 | 0.0 | 118.3 | 13.3 | -500.5 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | - | - | - | - | 0.7 | -0.3 | 0.0 | 22.0 |
| PROMISE SHOT AWAY | 2.0 | -1.5 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 16.7 | +922.0 | 1129.3 | 400.0 | 19.0 | +2462.9 | 153.3 | 73.3 |
| RANDOM MOVE BY FIGURES | 1.0 | +0.0 | 0.0 | 113.3 | - | - | - | - |
| REAL GROUND | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 3.3 | +241.7 | 0.0 | 83.7 | 1.3 | +28.9 | 0.0 | 46.0 |
| REDIRECT FOR A FRIEND IN REACH | 4.0 | +0.0 | 0.0 | 139.7 | 5.3 | +0.0 | 0.0 | 173.3 |
| REDIRECT WEIGHED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.0 | -3.9 | 0.0 | 27.0 | 3.3 | -64.6 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 3.0 | +76.0 | 0.0 | 44.0 |
| RISK BY ARC | 1.0 | -78.4 | 46.0 | 34.7 | 4.7 | +112.1 | 324.7 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 3.0 | -66.4 | 153.0 | 0.0 |
| RUN DOWN | - | - | - | - | 4.3 | -8.6 | 333.3 | 0.0 |
| SAME CHARGE LATER | 0.3 | -1.1 | 0.0 | 27.0 | 0.3 | -5.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 2.0 | +1.8 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.7 | -149.3 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 0.7 | +21.9 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 1.3 | +36.4 | 77.0 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 1.0 | -5.3 | 0.0 | 44.0 |
| SET UP BY THE SET | 1.7 | -40.4 | 0.0 | 0.0 | 1.3 | -7.6 | 0.0 | 44.0 |
| SET UP TOGETHER | - | - | - | - | 0.3 | +3.8 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.3 | +16.3 | 0.0 | 0.0 | - | - | - | - |
| SET-UP MISSED | 0.7 | +59.1 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 17.3 | +0.0 | 0.0 | 233.3 | 13.3 | +0.0 | 0.0 | 40.7 |
| SHOOTS FROM THE BEST SPOT | 3.3 | +295.8 | 253.3 | 0.0 | 1.7 | +9.5 | 113.3 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 1.3 | -14.8 | 141.7 | 0.0 |
| SHOT RISK POINTS | 27.7 | -286.8 | 0.0 | 303.0 | 38.3 | -396.2 | 0.0 | 714.7 |
| SHOTS AFTER THE MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 18.7 | +843.2 | 0.0 | 356.7 | 27.3 | +498.0 | 0.0 | 132.7 |
| SPELL SETS UP CHARGE | 0.3 | +16.3 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 9.0 | +0.0 | 0.0 | 136.7 | 4.0 | +0.0 | 0.0 | 45.3 |
| STAND AND SHOOT | 0.3 | -1.5 | 0.0 | 17.3 | - | - | - | - |
| STANDS FOR A REASON | - | - | - | - | 6.7 | +0.0 | 0.0 | 44.0 |
| STANDS STILL | 52.7 | +0.0 | 1729.3 | 938.3 | 41.3 | +0.0 | 630.7 | 320.7 |
| STAY WORTH | 34.3 | -417.4 | 1038.7 | 486.7 | 40.7 | +431.4 | 390.0 | 24.0 |
| STOPS | - | - | - | - | 0.3 | +0.5 | 0.0 | 0.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.7 | +9.3 | 0.0 | 40.7 |
| STUBBORN BY POINTS | 0.3 | +5.8 | 0.0 | 76.7 | - | - | - | - |
| STUCK PIVOT | 0.7 | +0.0 | 0.0 | 113.3 | - | - | - | - |
| SUPPORT ADDS | 12.0 | +469.5 | 0.0 | 236.7 | 3.7 | +116.4 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 24.0 | 17.3 | 0.3 | +0.0 | 30.3 | 0.0 |
| SUPPORT WORKED OUT | 12.0 | +469.5 | 0.0 | 236.7 | 3.7 | +116.4 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 2.0 | +8.8 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 5.3 | +0.0 | 0.0 | 45.3 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 23.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 43.7 | +0.0 | 0.0 | 514.0 | 50.7 | +0.0 | 0.0 | 422.0 |
| TIED UP BY THE SUM | 0.7 | +31.5 | 46.0 | 17.3 | 3.3 | +272.6 | 236.7 | 0.0 |
| TIME ON OUR SIDE | 22.7 | +289.1 | 0.0 | 122.7 | 18.7 | +234.3 | 28.3 | 170.0 |
| WAITS AGAIN | 3.0 | +0.0 | 0.0 | 54.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 4.3 | +0.0 | 734.0 | 0.0 | - | - | - | - |
| WEAPON BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -1.5 | 34.7 | 0.0 |
| WHO FIGHTS | - | - | - | - | 0.3 | -16.2 | 0.0 | 0.0 |
| WHO HITS BACK | 0.3 | +77.5 | 0.0 | 0.0 | 0.7 | +4.7 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | -0.1 | 17.3 | 0.0 |
| WHOLE FIGHT DANGER | 5.0 | -626.1 | 0.0 | 338.0 | 0.3 | -34.8 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +20.7 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 4.3 | +76.8 | 0.0 | 0.0 | 4.3 | +218.7 | 0.0 | 158.7 |

### Rule changes: gs3-83c8646-p62

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 128 | 128 | 93 | 31.00 | +1474 | +15.9 |
| HOLDER ASSIGNMENT | 73 | 73 | 69 | 23.00 | +4173 | +60.5 |
| HIS SHOTS BY HIS RUN | 310 | 292 | 62 | 20.67 | +474 | +7.6 |
| HIS SHOT LIST | 310 | 291 | 55 | 18.33 | +972 | +17.7 |
| OFF BEST | 36 | 36 | 36 | 12.00 | -1960 | -54.4 |
| PROMISE BY ITS OWN SUM | 75 | 75 | 35 | 11.67 | -2717 | -77.6 |
| DEPLOY BY FIGURES | 49 | 49 | 32 | 10.67 | +405 | +12.6 |
| LEGAL CHARGES ONLY | 31 | 31 | 31 | 10.33 | +0 | +0.0 |
| FIVE ACTION | 613 | 584 | 30 | 10.00 | +1630 | +54.4 |
| MOVE TO CHARGE COMPUTED | 56 | 44 | 28 | 9.33 | +994 | +35.5 |
| REDIRECT FOR A FRIEND IN REACH | 28 | 28 | 28 | 9.33 | +0 | +0.0 |
| GOAL WALK | 90 | 89 | 21 | 7.00 | +1502 | +71.5 |
| THE TABLE AGAIN | 36 | 36 | 20 | 6.67 | +0 | +0.0 |
| SHOT RISK POINTS | 198 | 183 | 19 | 6.33 | +746 | +39.3 |
| TIME ON OUR SIDE | 124 | 105 | 19 | 6.33 | +46 | +2.4 |
| NEXT CHARGE BY LIST | 27 | 27 | 18 | 6.00 | +630 | +35.0 |
| QUARTER ODDS | 107 | 105 | 14 | 4.67 | +1553 | +110.9 |
| CHARGE LOSSES | 128 | 121 | 12 | 4.00 | +978 | +81.5 |
| ARTILLERY RE-ROLL WEIGHED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| FOUR ROUNDS | 23 | 20 | 11 | 3.67 | +705 | +64.1 |
| COVER ONCE | 52 | 32 | 10 | 3.33 | +70 | +7.0 |
| SUPPORT ADDS | 47 | 38 | 10 | 3.33 | +129 | +12.9 |
| SUPPORT WORKED OUT | 47 | 38 | 10 | 3.33 | +129 | +12.9 |
| FALLS SHORT | 76 | 53 | 9 | 3.00 | +254 | +28.2 |
| HARD STAY DROPPED | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| MOVE ORDER | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| OGRE LOADER SECOND SHOT | 9 | 9 | 9 | 3.00 | +5 | +0.6 |
| RESERVE FALL BACK | 9 | 9 | 9 | 3.00 | +228 | +25.3 |
| MAX FOR POSITIONING | 22 | 21 | 7 | 2.33 | +8 | +1.1 |
| REDIRECT COUNTER | 14 | 11 | 7 | 2.33 | +247 | +35.3 |
| SHOOTS FROM THE BEST SPOT | 15 | 15 | 7 | 2.33 | +136 | +19.4 |
| TIED UP BY THE SUM | 12 | 9 | 7 | 2.33 | +192 | +27.5 |
| CANNON PLANNED TARGET | 41 | 41 | 6 | 2.00 | +0 | +0.0 |
| CANNON SIGHT KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| MEETS IN TIME | 15 | 15 | 6 | 2.00 | +516 | +86.1 |
| PROMISE SHOT AWAY | 6 | 6 | 6 | 2.00 | -5 | -0.8 |
| SCOUT WAITS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| STAY WORTH | 225 | 202 | 6 | 2.00 | +77 | +12.9 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 12 | 12 | 5 | 1.67 | -250 | -50.1 |
| LONE WIZARD KEPT IN | 5 | 5 | 5 | 1.67 | +288 | +57.5 |
| MISSILES IN THE MOVE | 24 | 14 | 5 | 1.67 | +95 | +19.1 |
| RISK BY ARC | 17 | 15 | 5 | 1.67 | +95 | +19.0 |
| SET UP BY THE SET | 9 | 9 | 5 | 1.67 | +13 | +2.5 |
| SHOTS AFTER THE MOVES | 28 | 28 | 5 | 1.67 | +0 | +0.0 |
| CASTING BLOCK | 4 | 4 | 4 | 1.33 | +24 | +6.0 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +137 | +34.3 |
| SECOND LOOK | 4 | 4 | 4 | 1.33 | +109 | +27.3 |
| SHOTS IN THE MOVE | 138 | 98 | 4 | 1.33 | +126 | +31.5 |
| GOAL ROUTE | 3 | 3 | 3 | 1.00 | +78 | +25.9 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| IDLE COST | 64 | 39 | 3 | 1.00 | +18 | +6.0 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +184 | +61.2 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +131 | +43.7 |
| WHOLE FIGHT DANGER | 16 | 16 | 3 | 1.00 | +154 | +51.4 |
| WOUNDS ON THE RANKS | 26 | 26 | 3 | 1.00 | +66 | +21.9 |
| CAST JOB | 20 | 20 | 2 | 0.67 | +25 | +12.7 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 3 | 3 | 2 | 0.67 | +1 | +0.6 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +499 | +249.3 |
| GOAL ON TIME | 2 | 2 | 2 | 0.67 | -1 | -0.4 |
| MANOEUVRE | 15 | 15 | 2 | 0.67 | +48 | +23.9 |
| NEARER NOT NEEDED | 46 | 45 | 2 | 0.67 | +96 | +48.2 |
| NO DOUBLE ROUNDS | 20 | 17 | 2 | 0.67 | +28 | +14.2 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -128 | -64.0 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +65 | +32.6 |
| RANDOM MOVE BY FIGURES | 3 | 3 | 2 | 0.67 | +0 | +0.0 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +105 | +52.5 |
| SEARCH SPOT | 3 | 3 | 2 | 0.67 | +66 | +32.9 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +28 | +13.9 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SURE REACH TOGETHER | 6 | 6 | 2 | 0.67 | +3 | +1.5 |
| BLOCKED CHARGE SKIPPED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +147 | +146.8 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +284 | +283.7 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 2 | 2 | 1 | 0.33 | +51 | +50.9 |
| EXACT ROUND | 17 | 14 | 1 | 0.33 | +1 | +1.2 |
| FEATURE BUFFS | 27 | 26 | 1 | 0.33 | +32 | +31.7 |
| HIS CHARGE DENIED | 1 | 1 | 1 | 0.33 | +18 | +18.4 |
| HONEST WORTH | 21 | 18 | 1 | 0.33 | +5 | +5.2 |
| JOINT CHARGE NOW | 1 | 1 | 1 | 0.33 | +14 | +14.4 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +34 | +33.8 |
| MARCH CHECK | 2 | 1 | 1 | 0.33 | +3 | +3.3 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -24 | -24.4 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| ONE FIGHT FORMULA | 52 | 30 | 1 | 0.33 | +0 | +0.0 |
| ONE JOINT FIGURE | 1 | 1 | 1 | 0.33 | +152 | +151.7 |
| ONE OBJECTIVE FORMULA | 31 | 23 | 1 | 0.33 | +23 | +23.3 |
| OVERRUNS AWAY | 3 | 3 | 1 | 0.33 | +83 | +82.9 |
| OWN CAST FIRST | 1 | 1 | 1 | 0.33 | -2 | -1.6 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +4 | +4.0 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +17 | +17.4 |
| THE ROW IN ITS ORDER | 23 | 1 | 1 | 0.33 | +0 | +0.0 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 69 | 68 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 12 | 10 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 54 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 15 | 15 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 9 | 9 | 0 | 0.00 | - | - |
| GIVES UP | 2 | not checked | - | - | - | - |
| GUN FIGURES | 9 | not checked | - | - | - | - |
| GUN MASK | 2 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 15 | 15 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 63 | 57 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 18 | 16 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 29 | 28 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 37 | 37 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 22 | 20 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 48 | 41 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 22 | 22 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 3 | 2 | 0 | 0.00 | - | - |
| HOLD ODDS | 125 | 125 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 4 | 1 | 0 | 0.00 | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| KEPT FROM ITS LAST STOP | 15 | 15 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 8 | 7 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 5 | 5 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 27 | 20 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 3 | not checked | - | - | - | - |
| MOVE SPELL SPOT | 2 | not checked | - | - | - | - |
| NEAREST TO GOAL | 2 | 2 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE ROUTE | 5 | 5 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP | 4 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 276 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 2 | not checked | - | - | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 5 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 13 | 10 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 9 | 7 | 0 | 0.00 | - | - |
| RUN DOWN | 13 | 11 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 92 | not checked | - | - | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 39 | 28 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 20 | 20 | 0 | 0.00 | - | - |
| STANDS STILL | 282 | 273 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 4 | not checked | - | - | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 5 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 5 | not checked | - | - | - | - |
| THE TABLE BINDS | 283 | not checked | - | - | - | - |
| WAITS AGAIN | 19 | 17 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 13 | 13 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p62

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 5.67 | 6.00 | 77.6 |
| JOB FIRST | gate | 5.33 | 5.67 | 55.6 |
| ARMY TABLE | rule | 2.00 | 2.67 | 61.2 |
| PROMISE SHOT AWAY | rule | 2.00 | - | 0.8 |
| CHARGE NOW FIRST | rule | 0.67 | 1.00 | 50.1 |
| HOLDER ASSIGNMENT | rule | - | 1.33 | 62.8 |
| RULE SWITCHED OFF | gate | - | 1.00 | 41.1 |
| ONE PROMISE A TARGET | rule | - | 0.67 | 64.0 |
| MARCH OF THE TABLE | rule | 0.33 | - | 24.4 |
| OWN CAST FIRST | rule | 0.33 | - | 1.6 |

### Plans: gs3-83c8646-p62

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 67% | 26 | 46 | 179% |
| Mine | move | 25.7 | 91% | 1255 | 0 | 0% |
| Mine | shoot | 15.7 | 47% | 582 | 686 | 118% |
| Mine | support | 0.3 | 100% | 0 | 0 | 0% |
| Opponent | charge | 5.0 | 67% | 647 | 346 | 53% |
| Opponent | move | 34.3 | 94% | 2564 | 0 | 0% |
| Opponent | shoot | 10.0 | 53% | 557 | 372 | 67% |

### Packages: hunt the guns, gs3-83c8646-p62

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 37 |
| Opponent | 0.3 | 1 | 1 | - | - | - | - | - | - | - | 42 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 55 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 125 |
| Tomb Kings of Khemri | 0.5 | 1 | 1 | - | - | - | - | - | - | - | 0 |

### Battle groups: gs3-83c8646-p62

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.3 | 40% | 75% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 1.3 | 50% | 100% | 50% | 0% | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p62

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Character | 7 | 18 (7) | 18 | 0 | 20 | 29% | 3.6 | - | 0 (1) | 22 (5) | 20 (6) | - |
| Mine | Clean-up | 4 | 0 (4) | 0 | 0 | 50 | 100% | - | 0 (1) | 0 (3) | - | 0 (3) | 0 (1) |
| Mine | Fast Hammer | 5 | 22 (5) | 22 | 0 | 74 | 20% | 3.8 | - | 46 (3) | 0 (2) | 26 (4) | 0 (1) |
| Mine | Hammer | 9 | 61 (9) | 36 | 25 | 10 | 11% | 2.9 | 0 (1) | 69 (4) | 73 (4) | 83 (7) | 0 (2) |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | War machine | 8 | 11 (8) | 11 | 0 | 50 | 0% | 1.0 | 0 (2) | 20 (5) | 0 (1) | 0 (3) | 17 (5) |
| Mine | Wizard | 5 | 0 (5) | 0 | 0 | 0 | 20% | 3.5 | 0 (1) | 0 (2) | 0 (2) | 0 (2) | 0 (3) |
| Opponent | Chaff | 5 | 32 (5) | 23 | 9 | 95 | 0% | 1.0 | 112 (1) | 11 (4) | - | 32 (5) | - |
| Opponent | Character | 8 | 21 (8) | 21 | 0 | 15 | 38% | 2.8 | 24 (3) | 24 (3) | 14 (2) | 27 (6) | 0 (2) |
| Opponent | Clean-up | 4 | 55 (4) | 0 | 55 | 86 | 100% | - | 0 (2) | 0 (1) | 113 (1) | 65 (3) | 0 (1) |
| Opponent | Fast Hammer | 6 | 44 (6) | 44 | 0 | 0 | 50% | 4.3 | 40 (3) | 49 (3) | - | 96 (2) | 19 (4) |
| Opponent | Holder | 9 | 77 (9) | 0 | 77 | 0 | 11% | 1.8 | 0 (2) | 80 (4) | 118 (3) | 170 (4) | 0 (5) |
| Opponent | Shooter | 2 | 82 (2) | 31 | 51 | 0 | 0% | 1.5 | 59 (1) | 106 (1) | - | 59 (1) | 106 (1) |
| Opponent | War machine | 3 | 29 (3) | 29 | 0 | 33 | 33% | 1.0 | 29 (3) | - | - | 0 (2) | 88 (1) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 0% | 1.0 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |

### Charged fights: gs3-83c8646-p62

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 72 | 72 | 2.0 | 1.0 | 36 | 0 | +36 | 0 of 2 | 2 of 2 | - | +36 |
| Mine | Chaos Dwarfs | 2 | 462 | 33 | 0.5 | 1.0 | 66 | 0 | +66 | 0 of 1 | 1 of 1 | - | +66 |
| **Mine** | all armies | 3 | 332 | 46 | 1.0 | 1.0 | 46 | 0 | +46 | 0 of 3 | 3 of 3 | - | +46 |
| Opponent | Empire of Man | 1 | 110 | 230 | 1.0 | 1.0 | 230 | 0 | +230 | 0 of 1 | 1 of 1 | - | +230 |
| Opponent | Tomb Kings of Khemri | 2 | 55 | 356 | 4.0 | 1.0 | 89 | 15 | +74 | 2 of 8 | 6 of 8 | - | +74 |
| **Opponent** | all armies | 3 | 73 | 314 | 3.0 | 1.0 | 105 | 14 | +91 | 2 of 9 | 7 of 9 | - | +91 |

### Effective charges: gs3-83c8646-p62

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 0 | 0 | 0 | 1 (net +0) | 0 | 1 (net +72) | 0 | 0% (0 of 2) |
| Mine | Chaos Dwarfs | 1 | 0 | 0 | 0 | 0 | 1 (net +66) | 0 | 0 | 0% (0 of 1) |
| Opponent | Empire of Man | 1 | 0 | 0 | 1 (net +230) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | Tomb Kings of Khemri | 8 | 1 (net -122) | 0 | 0 | 1 (net +222) | 1 (net +52) | 4 (net +96) | 1 | 0% (0 of 7) |

### Charged fights, damage counted: gs3-83c8646-p62

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 1 | 52 | 55 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 52 | 72 | +72 | 72 | 0 | +72 | +138.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 310 | 66 | +66 | 87 | 89 | -1 | -0.5 |
| Mine | All fights | 3 | 138 | 64 | +46 | 53 | 30 | +24 | +17.0 |
| Opponent | Long shot (under 50%) | 1 | 72 | 272 | -122 | 0 | 122 | -122 | -169.4 |
| Opponent | Effective (55-75%) | 1 | 189 | 230 | +230 | 230 | 21 | +209 | +110.6 |
| Opponent | 76-89% | 1 | 411 | 170 | +222 | 222 | 0 | +222 | +54.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 280 | 162 | +96 | 162 | 0 | +162 | +57.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 195 | 52 | +52 | 52 | 0 | +52 | +26.7 |
| Opponent | No odds | 1 | 195 | 52 | +52 | 52 | 0 | +52 | +26.7 |
| Opponent | All fights | 9 | 242 | 158 | +91 | 134 | 16 | +118 | +48.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p62 | move | 28 | 4 (14%) | 2 (7%) | 6 (21%) | 18 (64%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Ring of Doom | Mine | L0222 |
| Twice-Blessed Armour | Opponent | L0307 |
| Witch Hunter's Ward | Opponent | L0307 |

# Doctrine scorecard: gs3-83c8646-p47

### Scorecard: gs3-83c8646-p47

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2227 | 1 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L2227 | 1 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L2331 | 3 | 1 | Mine | yes | 1 | 2 | 3 | 1 | 0 | 0 | 0 | 70 |
| L2331 | 3 | 1 | Opponent | no | 0 | 2 | 1 | 0 | 2 | 0 | 0 | 876 |
| L2527 | 1 | 1 | Mine | no | 2 | 5 | 3 | 1 | 1 | 0 | 0 | 236 |
| L2527 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 50% | 1.5 | 3.5 | 3.0 | 1.0 | 0.5 | 0.0 | 0.0 | 153.0 |
| **Average** | | | Opponent | 0% | 0.0 | 2.0 | 3.0 | 1.0 | 1.0 | 0.0 | 0.0 | 438.0 |

### KPIs: gs3-83c8646-p47

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 12) | 0% (0 of 10) | 0% (0 of 22) |
| Winner chose to follow up after the loser gave ground |  | 75% (3 of 4); on the table 75% | 100% (5 of 5); on the table 100% | 89% (8 of 9); on the table 89% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 33% (1 of 3); on the table 67% | - | 33% (1 of 3); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 57% (4 of 7); on the table 71% | 100% (5 of 5); on the table 100% | 75% (9 of 12); on the table 83% |
| Magic missiles tried each own turn | 50%+ | 0% (0 of 7) | 58% (11 of 19) | 42% (11 of 26) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 0% (0 of 5) | 90% (9 of 10) | 60% (9 of 15) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 45% (5 of 11) | 45% (5 of 11) |
| Points that never fought | lower | 8% (202 of 2451) | 16% (642 of 4000) | 13% (844 of 6451) |
|   infantry points that never fought | lower | 25% (132 of 524) | 56% (230 of 410) | 39% (362 of 934) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 14% (1 of 7) | 50% (9 of 18) | 40% (10 of 25) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 8% (147 of 1847) | 45% (1581 of 3546) | 32% (1728 of 5393) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.7 (71%) | 0.3 (17%) | 2.0 (46%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (17%) | 0.3 (8%) |
| GONE: slain | 0.7 (29%) | 1.3 (67%) | 2.0 (46%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- |
| tried | 5.0 | 3.7 | 0.3 | 1.0 |
| not cast | 6.7 | 4.3 | 1.7 | 18.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (46%) | 1.0 (60%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (8%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.0 (15%) | 2.0 (46%) | 0.7 (40%) | 2.7 (15%) |
| OFF THE TABLE: off the table or not arrived | 1.0 (15%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.3 (5%) | 0.0 (0%) | 0.0 (0%) | 2.0 (11%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.3 (65%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.0 (72%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 56% (19 of 34) | - | 56% (19 of 34) |
|   cavalry | 100% (6 of 6) | - | 100% (6 of 6) |
|   character | 0% (0 of 11) | - | 0% (0 of 11) |
|   infantry | 76% (13 of 17) | - | 76% (13 of 17) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| CHARGED: it charged | 1.3 (27%) | - | 1.3 (27%) |
| NO TARGET IN RANGE | 2.3 (47%) | - | 2.3 (47%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (27%) | - | 1.3 (27%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.0 | 0.7 | 67% | 17.3 pts | 35 pts |
| infantry | 4.7 | 2.0 | 71% | 20.3 pts | 95 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.7 | 4.7 | 4.7 |
| Charges that made contact a game | 4.0 | 3.7 | 3.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (5 units) | 0.00 declared, 0.00 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 3.00 declared, 3.00 contact (1 units) | 3.00 declared, 3.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.56 declared, 0.48 contact (25 units) | 0.50 declared, 0.36 contact (22 units) | 0.53 declared, 0.43 contact (47 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | 50% (1 of 2) | 0% (0 of 1) | 43% (3 of 7) |
| Character in a unit | 0% (0 of 1) | - | - | 0% (0 of 1) |
| Character on its own | 60% (3 of 5) | - | 25% (1 of 4) | 44% (4 of 9) |
| Infantry | 75% (3 of 4) | - | - | 75% (3 of 4) |
| Monster | 0% (0 of 4) | - | - | 0% (0 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Tomb Kings of Khemri | 1 | 40% (2 of 5); on the table 60% | - | 10% | 0% (0 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 2 | 100% (5 of 5); on the table 100% | 44% (7 of 16) | 17% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (2 of 2); on the table 100% | 33% (2 of 6) | 12% | 58% (7 of 12) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p47, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 83% (5) | 45% (5) | 59% (10) |
| ...free all their last turn and able to turn (per game) | 1.00 | 1.33 | 2.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.67 | 0.33 | 1.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 1.00 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.67 | 0.67 |

### Quality by phase: gs3-83c8646-p47

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 5.3 |
| Strategy | Charge objectives carried out (made contact) | 44% (7 of 16) | 70% (7 of 10) |
| Strategy | Shoot objectives carried out (shot that target) | 55% (6 of 11) | 0% (0 of 2) |
| Strategy | Support requests answered (helper made contact too) | 50% (1 of 2) | 100% (1 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | - | 50% (1 of 2) |
| Strategy | Lone characters that fought | 100% (4 of 4) | 78% (7 of 9) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.0 | 1.0 |
| Movement | Points that never moved of their own | 153.0 | 438.0 |
| Movement | Fights charged into per game | 5.0 | 3.5 |
| Movement | Charges with odds: long shots (under 50%) | 3 of 9, net -14 | 2 of 6, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 9, net +98 | 2 of 6, net +11 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 9, net +359 | 1 of 6, net +401 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 9, net +260 | 1 of 6, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 6.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 30% (6 of 20) | - |
| Shooting | Points destroyed by shooting units | 103.7 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | - | 2.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 25% (2 of 8) |
| Magic | Wounds caused by magic missiles | - | 3.0 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.7 / 0.0 / 0.0 / 0.0 | 2.0 / 0.0 / 0.3 / 0.3 |
| Combat | Points destroyed in combat | 342.7 | 214.3 |
| Combat | Points run down | 48.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +144 | +49 |
| Combat | Net per 100 charger points, damage counted | +42.8 | +20.7 |
| Combat | First round won (charged fights) | 70% | 86% |
| Combat | Net points per charged fight | +155 | +68 |
| Combat | Net points per supported fight / lone fight | +98 / +179 | +401 / +12 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 10 | 6 of 7 |
| Game | Points lost | 899.0 | 1220.5 |
| Game | VP from objectives | 925.0 | 595.0 |
| Game | Lone holders (player turns) | 1.5 | 0.0 |

- Mine won / drew / lost: 1 / 0 / 1 of 2 ended games (of 3); mean margin (Mine - Opponent) +602 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 2120
- Games not ended: 1 (L2227-1); findings 1, warnings 0

### Opponent rules: gs3-83c8646-p47

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.3 | +164.5 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | 0.3 | +28.4 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 19.0 | +94.5 | 0.0 | 106.7 | 11.3 | -138.4 | 0.0 | 409.0 |
| ASSAILMENT BY POINTS | 0.3 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 0.3 | +0.2 | 0.0 | 38.7 |
| BLOWS WHERE AIMED | 0.3 | -4.3 | 48.0 | 0.0 | 0.3 | -8.0 | 0.0 | 0.0 |
| CAST JOB | - | - | - | - | 0.7 | +6.2 | 169.3 | 40.0 |
| CASTS FROM BEHIND | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF PASSED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.7 | +50.3 | 0.0 | 0.0 | 1.0 | +42.2 | 0.0 | 48.0 |
| CHARGE LOSSES | 3.3 | -609.0 | 0.0 | 0.0 | 10.7 | -575.4 | 0.0 | 840.0 |
| CHARGE NOT DECLARED | 0.3 | +0.0 | 0.0 | 16.7 | - | - | - | - |
| CHARGE NOW FIRST | 3.0 | +0.0 | 301.3 | 16.7 | 2.3 | +0.0 | 66.0 | 103.7 |
| CLOSES ON WHAT IT BEATS | 10.7 | +0.0 | 0.0 | 42.0 | 9.7 | +0.0 | 0.0 | 56.7 |
| COMBAT PIVOT | 0.7 | +0.0 | 40.0 | 0.0 | 0.3 | +0.0 | 0.0 | 25.0 |
| COVER ONCE | 4.7 | -256.5 | 0.0 | 0.0 | 4.0 | -229.1 | 0.0 | 185.7 |
| DEPLOY BY FIGURES | 7.7 | +43.2 | 0.0 | 0.0 | 6.0 | +17.1 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.7 | -64.4 | 20.0 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 1.0 | +5.3 | 38.7 | 0.0 | 0.3 | +22.2 | 84.7 | 0.0 |
| EXACT ROUND | 3.7 | +57.6 | 398.7 | 101.3 | 3.0 | +27.8 | 150.7 | 120.3 |
| FALL BACK GOOD ORDER | 3.0 | +8.0 | 330.3 | 150.3 | 1.7 | +0.0 | 0.0 | 16.7 |
| FALLS SHORT | - | - | - | - | 15.3 | +199.7 | 0.0 | 424.3 |
| FEATURE BUFFS | 1.0 | +3.5 | 0.0 | 0.0 | 1.3 | +17.2 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.3 | +14.9 | 98.0 | 16.7 | 0.7 | +62.6 | 0.0 | 0.0 |
| FIVE ACTION | 80.3 | +7570.1 | 1016.0 | 767.7 | 60.0 | +3058.7 | 342.0 | 1444.3 |
| FLANK NOT WEIGHED | 6.7 | +0.0 | 0.0 | 129.7 | 6.7 | +0.0 | 0.0 | 322.0 |
| FOLLOW UP WEIGHED | 0.3 | +209.0 | 0.0 | 0.0 | 1.3 | +555.3 | 0.0 | 0.0 |
| FOOT FIRST | - | - | - | - | 12.0 | +0.0 | 0.0 | 53.3 |
| FOUR ROUNDS | 5.7 | +537.3 | 550.3 | 167.0 | 3.7 | +228.7 | 150.7 | 120.3 |
| FREED FROM HIS FIGHT | 1.0 | +0.0 | 0.0 | 124.7 | 5.7 | +0.0 | 0.0 | 192.0 |
| FRIEND CHARGES FIRST | 0.3 | -22.8 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.3 | -2.5 | 0.0 | 0.0 | 0.7 | -0.1 | 0.0 | 0.0 |
| GIVES UP | 0.7 | -3.9 | 83.7 | 0.0 | - | - | - | - |
| GOAL WALK | 9.3 | +1255.0 | 0.0 | 0.0 | 6.3 | +547.2 | 0.0 | 83.7 |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 1.0 | +0.0 | 0.0 | 124.7 | 5.3 | +0.0 | 0.0 | 192.0 |
| HIS CHARGE BY HIS RUN | 3.0 | +0.0 | 0.0 | 0.0 | 9.7 | +0.0 | 0.0 | 801.3 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +13.5 | 0.0 | 38.7 |
| HIS CHARGE LIST | 1.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 157.3 |
| HIS LEGAL MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 62.0 |
| HIS MOVE AND SHOT | - | - | - | - | 1.0 | -1.8 | 0.0 | 0.0 |
| HIS ONE QUARTER | 5.0 | +0.0 | 0.0 | 174.7 | 2.0 | +0.0 | 0.0 | 77.3 |
| HIS OWN BEST MOVE | 9.3 | +0.0 | 0.0 | 0.0 | 8.7 | +0.0 | 0.0 | 255.3 |
| HIS RANDOM MOVE | 12.3 | +0.0 | 0.0 | 128.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 3.0 | +0.0 | 0.0 | 66.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 4.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 5.3 | +30.3 | 0.0 | 84.7 | 26.0 | +236.2 | 0.0 | 1038.7 |
| HIS SHOTS BY HIS RUN | 8.3 | +32.3 | 0.0 | 44.0 | 18.0 | +150.5 | 0.0 | 972.0 |
| HIS TURN DENIED | 0.3 | +0.4 | 38.7 | 0.0 | 1.7 | +7.4 | 44.0 | 0.0 |
| HOLD ODDS | 15.3 | +0.0 | 0.0 | 168.0 | 10.7 | +0.0 | 0.0 | 316.0 |
| HOLDER ASSIGNMENT | 11.0 | +835.0 | 0.0 | 106.0 | 7.0 | +598.7 | 0.0 | 226.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.7 | -243.6 | 410.0 | 150.3 | 3.0 | -113.0 | 66.0 | 81.7 |
| IDLE COST | - | - | - | - | 13.7 | -120.1 | 0.0 | 303.3 |
| JOINT CHARGE NOW | 2.0 | +102.6 | 305.7 | 33.3 | 2.0 | -57.4 | 66.0 | 81.7 |
| KEPT FROM ITS LAST STOP | 3.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 158.0 |
| LANE BY FIGURES | 1.3 | +38.9 | 0.0 | 0.0 | 0.7 | +32.2 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 7.7 | +0.0 | 103.7 | 157.0 | 3.3 | +0.0 | 133.7 | 110.0 |
| LONE WIZARD KEPT IN | 1.0 | +45.9 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 0.3 | +1.1 | 0.0 | 0.0 | 0.3 | +1.6 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.3 | +5.8 | 126.7 | 0.0 | 0.7 | -0.1 | 22.0 | 103.7 |
| MANOEUVRE | 1.0 | -1.9 | 0.0 | 0.0 | 0.3 | +2.7 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +0.0 | 0.0 | 38.7 |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +0.3 | 0.0 | 38.7 |
| MARCH OVER CASTS | - | - | - | - | 0.3 | -11.0 | 0.0 | 38.7 |
| MARCH WHEELS ONLY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 1.7 | +30.6 | 0.0 | 0.0 | 1.3 | +26.6 | 0.0 | 0.0 |
| MEETS IN TIME | 4.3 | +306.2 | 0.0 | 0.0 | 4.0 | +274.1 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.3 | +3.2 | 0.0 | 0.0 | 3.7 | +43.0 | 0.0 | 123.7 |
| MISSILES NEXT TURN | 2.0 | +3.1 | 0.0 | 0.0 | 3.7 | +13.6 | 0.0 | 123.7 |
| MOVE ORDER | 1.7 | +0.0 | 20.0 | 0.0 | 0.7 | +0.0 | 48.0 | 38.7 |
| MOVE TO CHARGE COMPUTED | 8.0 | +796.0 | 0.0 | 0.0 | 9.3 | +517.9 | 0.0 | 255.3 |
| NEARER NOT NEEDED | 11.3 | +340.2 | 0.0 | 61.7 | 6.3 | +244.1 | 0.0 | 227.7 |
| NEAREST TO GOAL | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 4.7 | +558.3 | 0.0 | 0.0 | 5.7 | +310.9 | 0.0 | 216.7 |
| NO DOUBLE ROUNDS | 4.3 | -176.2 | 530.3 | 101.3 | 3.3 | -51.8 | 150.7 | 120.3 |
| NO LATE CUT | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 4.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 4.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.7 | +0.0 | 0.0 | 77.3 |
| NOT WORTH A CAST | - | - | - | - | 1.7 | -0.3 | 0.0 | 0.0 |
| OFF BEST | 2.3 | -52.7 | 56.7 | 106.7 | 4.3 | -175.6 | 0.0 | 261.0 |
| ONE CHALLENGE TEST | - | - | - | - | 0.3 | +54.2 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 1.0 | +0.0 | 0.0 | 38.7 |
| ONE FIGHT FORMULA | 5.7 | -155.3 | 0.0 | 61.7 | 3.3 | -51.0 | 0.0 | 100.7 |
| ONE JOINT FIGURE | 0.3 | +3.8 | 56.7 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 4.3 | -45.5 | 0.0 | 64.0 | 2.3 | +9.6 | 0.0 | 130.0 |
| ONE ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 4.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 0.7 | +3.3 | 130.0 | 123.3 | - | - | - | - |
| OPENS UP | 0.3 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | - | - | - | - | 1.0 | +7.2 | 22.0 | 38.7 |
| PLAN RESULT | 36.7 | +550.7 | 394.7 | 683.3 | 29.0 | +244.3 | 148.0 | 1026.3 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 16.7 | 0.3 | +0.0 | 0.0 | 38.7 |
| PROMISE BY ITS OWN SUM | 10.3 | -300.2 | 0.0 | 0.0 | 9.0 | -247.7 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 3.0 | -4.6 | 0.0 | 100.7 |
| PROMISE READS THE TABLE | 0.3 | -2.5 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 17.0 | +1968.8 | 194.0 | 348.3 | 10.3 | +1305.9 | 254.0 | 330.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.7 | +20.3 | 0.0 | 113.3 |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 4.3 | +207.0 | 0.0 | 69.0 | 2.3 | +151.1 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 4.7 | +0.0 | 0.0 | 89.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 2.7 | -195.1 | 0.0 | 0.0 | 1.3 | -24.7 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 1.0 | +36.3 | 0.0 | 22.0 | 0.3 | +10.4 | 0.0 | 0.0 |
| RISK BY ARC | 3.3 | +148.1 | 226.7 | 118.0 | 2.3 | +6.7 | 66.0 | 120.3 |
| RISK ON THE WAY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | 2.0 | -51.1 | 302.0 | 0.0 | - | - | - | - |
| RUN DOWN | 2.3 | -50.1 | 342.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 1.3 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | - | - | - | - | 1.0 | +1.7 | 0.0 | 48.0 |
| SECOND LOOK | 0.3 | +6.7 | 56.7 | 0.0 | 0.3 | +25.7 | 0.0 | 0.0 |
| SET CREDITED ONCE | 1.3 | -88.9 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 2.7 | +84.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.7 | +3.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 3.0 | +0.0 | 0.0 | 61.7 | 0.7 | +0.0 | 0.0 | 20.0 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +13.7 | 38.7 | 0.0 | 0.3 | +0.9 | 22.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -9.0 | 38.7 | 0.0 | 0.3 | -0.9 | 22.0 | 0.0 |
| SHOT RISK POINTS | 3.0 | +6.6 | 0.0 | 0.0 | 13.0 | +12.7 | 0.0 | 507.0 |
| SHOTS AFTER THE MOVES | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOTS IN THE MOVE | 9.7 | +113.9 | 0.0 | 125.7 | - | - | - | - |
| SPELL WORTH | - | - | - | - | 2.0 | +1.6 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | +0.3 | 25.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 249.3 |
| STAND AND SHOOT | - | - | - | - | 1.0 | -3.1 | 66.0 | 65.0 |
| STANDS FOR A REASON | - | - | - | - | 1.0 | +0.0 | 0.0 | 65.0 |
| STANDS STILL | 33.3 | +0.0 | 465.7 | 218.3 | 7.7 | +0.0 | 191.3 | 130.0 |
| STAY WORTH | 6.0 | +12.4 | 154.7 | 20.0 | - | - | - | - |
| STRIKE BY THE ODDS | 0.3 | +1.7 | 0.0 | 49.0 | - | - | - | - |
| STUPIDITY NEXT TURN | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 9.3 | +2217.7 | 0.0 | 22.0 | 0.7 | +24.7 | 0.0 | 96.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 83.7 | 0.0 | 1.0 | +0.0 | 44.0 | 38.7 |
| SUPPORT WORKED OUT | 9.3 | +2217.7 | 0.0 | 22.0 | 0.7 | +24.7 | 0.0 | 96.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +2.2 | 0.0 | 48.0 |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -72.2 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.0 | +0.0 | 0.0 | 84.7 | 2.3 | +0.0 | 0.0 | 110.0 |
| THE ROW KEEPS ITS WAY | 0.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 4.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 38.3 | +0.0 | 0.0 | 300.3 | 28.0 | +0.0 | 0.0 | 663.3 |
| TIED UP BY THE SUM | 1.7 | +174.6 | 154.7 | 16.7 | 1.7 | +107.4 | 66.0 | 65.0 |
| TIME ON OUR SIDE | 47.7 | +410.2 | 0.0 | 200.7 | - | - | - | - |
| WHAT THE JOINER ADDS | 0.7 | +0.5 | 0.0 | 33.3 | 0.7 | -17.9 | 0.0 | 0.0 |
| WHO FIGHTS | 1.3 | -14.4 | 162.3 | 0.0 | 0.7 | +1.2 | 22.0 | 65.0 |
| WHO GETS IN | 0.3 | -10.2 | 25.0 | 16.7 | - | - | - | - |
| WHO HITS BACK | - | - | - | - | 1.0 | +38.9 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.3 | +0.0 | 0.0 | 16.7 | 0.3 | -29.8 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.3 | -598.1 | 0.0 | 0.0 | 2.7 | -473.4 | 0.0 | 371.7 |
| WHOLE FIGHT GAIN | 0.3 | +7.3 | 56.7 | 0.0 | 0.7 | +12.6 | 0.0 | 16.7 |
| WOUNDS ON THE RANKS | 0.7 | +2.3 | 0.0 | 0.0 | 1.0 | +1.1 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p47

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 91 | 91 | 67 | 22.33 | +430 | +6.4 |
| HOLDER ASSIGNMENT | 54 | 54 | 49 | 16.33 | +2885 | +58.9 |
| FIVE ACTION | 421 | 407 | 34 | 11.33 | +2220 | +65.3 |
| LEGAL CHARGES ONLY | 33 | 33 | 33 | 11.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 52 | 41 | 27 | 9.00 | +956 | +35.4 |
| PROMISE BY ITS OWN SUM | 58 | 58 | 27 | 9.00 | -1644 | -60.9 |
| THE TABLE AGAIN | 27 | 27 | 23 | 7.67 | +0 | +0.0 |
| DEPLOY BY FIGURES | 41 | 41 | 22 | 7.33 | +162 | +7.4 |
| OFF BEST | 20 | 20 | 20 | 6.67 | -685 | -34.3 |
| REDIRECT FOR A FRIEND IN REACH | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| TIME ON OUR SIDE | 143 | 121 | 17 | 5.67 | +57 | +3.4 |
| HIS SHOT LIST | 94 | 93 | 16 | 5.33 | +62 | +3.9 |
| NEXT CHARGE BY LIST | 31 | 27 | 16 | 5.33 | +891 | +55.7 |
| MEETS IN TIME | 25 | 25 | 15 | 5.00 | +710 | +47.3 |
| JOINT CHARGE NOW | 12 | 12 | 12 | 4.00 | +135 | +11.3 |
| SUPPORT ADDS | 30 | 30 | 12 | 4.00 | +1850 | +154.2 |
| SUPPORT WORKED OUT | 30 | 30 | 12 | 4.00 | +1850 | +154.2 |
| GOAL WALK | 47 | 46 | 10 | 3.33 | +1202 | +120.2 |
| IDLE COST | 41 | 23 | 10 | 3.33 | +34 | +3.4 |
| QUARTER ODDS | 82 | 80 | 10 | 3.33 | +984 | +98.4 |
| HIS SHOTS BY HIS RUN | 79 | 70 | 9 | 3.00 | +94 | +10.5 |
| FOUR ROUNDS | 28 | 26 | 8 | 2.67 | +623 | +77.8 |
| TIED UP BY THE SUM | 10 | 8 | 8 | 2.67 | +134 | +16.8 |
| HOLDS AMBUSHERS | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| MOVE ORDER | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| CASTS FROM BEHIND | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| HARD STAY DROPPED | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +213 | +35.6 |
| RISK BY ARC | 17 | 16 | 6 | 2.00 | +244 | +40.6 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 5 | 5 | 5 | 1.67 | +277 | +55.4 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +2293 | +458.6 |
| RANDOM MOVE BY FIGURES | 11 | 11 | 5 | 1.67 | +61 | +12.2 |
| SHOT RISK POINTS | 48 | 46 | 5 | 1.67 | +68 | +13.7 |
| CHARGE NOW FIRST | 16 | 16 | 4 | 1.33 | -365 | -91.1 |
| MAX FOR POSITIONING | 9 | 8 | 4 | 1.33 | +6 | +1.6 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +140 | +35.1 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SET UP BY THE SET | 8 | 8 | 4 | 1.33 | +172 | +42.9 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +138 | +45.9 |
| PROMISE KNOWS THE FIGHT | 10 | 9 | 3 | 1.00 | -14 | -4.6 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +58 | +19.4 |
| CAST JOB | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| COVER ONCE | 26 | 12 | 2 | 0.67 | +30 | +14.8 |
| MANOEUVRE | 4 | 4 | 2 | 0.67 | +17 | +8.4 |
| NEARER NOT NEEDED | 53 | 48 | 2 | 0.67 | +70 | +34.9 |
| REDIRECT COUNTER | 20 | 15 | 2 | 0.67 | +85 | +42.5 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +97 | +48.6 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +9 | +4.5 |
| WHOLE FIGHT DANGER | 15 | 15 | 2 | 0.67 | +28 | +14.1 |
| WHOLE FIGHT GAIN | 3 | 3 | 2 | 0.67 | +29 | +14.4 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +493 | +493.3 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +85 | +85.1 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +2 | +2.2 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -224 | -223.6 |
| EDGE GIVE GROUND | 4 | 4 | 1 | 0.33 | +42 | +42.1 |
| EXACT ROUND | 20 | 19 | 1 | 0.33 | +3 | +3.3 |
| FIGHT TO THE END | 6 | 6 | 1 | 0.33 | +3 | +3.3 |
| HONEST WORTH | 23 | 21 | 1 | 0.33 | +3 | +2.9 |
| LONG SHOT | 2 | 2 | 1 | 0.33 | +3 | +2.9 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -1 | -1.1 |
| MISSILES IN THE MOVE | 18 | 10 | 1 | 0.33 | +48 | +48.0 |
| NO DOUBLE ROUNDS | 23 | 22 | 1 | 0.33 | +3 | +2.9 |
| ONE OBJECTIVE FORMULA | 20 | 13 | 1 | 0.33 | +33 | +33.3 |
| REFUSING RETIRES | 4 | 4 | 1 | 0.33 | -0 | -0.3 |
| SEARCH SPOT | 3 | 3 | 1 | 0.33 | +5 | +5.0 |
| SHOOTS FROM THE BEST SPOT | 4 | 4 | 1 | 0.33 | +0 | +0.0 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +5 | +5.2 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +7 | +6.7 |
| WHO GETS IN | 1 | 1 | 1 | 0.33 | -30 | -30.5 |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 2 | 2 | 0 | 0.00 | - | - |
| CHARGE LOSSES | 42 | 40 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 61 | 61 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 14 | 13 | 0 | 0.00 | - | - |
| FALLS SHORT | 46 | 32 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 7 | 7 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 40 | not checked | - | - | - | - |
| FOOT FIRST | 36 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 20 | 20 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 3 | 3 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 19 | 19 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 38 | 36 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 18 | 18 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 24 | 21 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 3 | 3 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 21 | 19 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 54 | 44 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 37 | 34 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 9 | 9 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 27 | 27 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 6 | 6 | 0 | 0.00 | - | - |
| HOLD ODDS | 78 | 78 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 15 | 15 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 6 | 6 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 1 | 1 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 17 | 9 | 0 | 0.00 | - | - |
| NEAREST TO GOAL | 5 | 5 | 0 | 0.00 | - | - |
| NO LATE CUT | 8 | 8 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 27 | 27 | 0 | 0.00 | - | - |
| NO SECOND RUN | 27 | 27 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 5 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 27 | 8 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE ROUTE | 1 | 1 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 27 | 27 | 0 | 0.00 | - | - |
| OPENS A LANE | 2 | 2 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 3 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 197 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 12 | 9 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 4 | 4 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 6 | 6 | 0 | 0.00 | - | - |
| RUN DOWN | 7 | 7 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 11 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 6 | 6 | 0 | 0.00 | - | - |
| SHOTS IN THE MOVE | 29 | 25 | 0 | 0.00 | - | - |
| SPELL WORTH | 6 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 26 | 25 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 3 | 3 | 0 | 0.00 | - | - |
| STANDS STILL | 123 | 122 | 0 | 0.00 | - | - |
| STAY WORTH | 18 | 17 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 5 | 5 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 4 | 4 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 3 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE ROW IN ITS ORDER | 13 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 12 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 10 | not checked | - | - | - | - |
| THE TABLE BINDS | 199 | not checked | - | - | - | - |
| WHAT THE JOINER ADDS | 4 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 6 | 6 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 2 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 5 | 5 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p47

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 4.33 | 4.67 | 60.9 |
| JOB FIRST | gate | 2.00 | 3.67 | 34.4 |
| ARMY TABLE | rule | 2.00 | 0.67 | 78.0 |
| JOINT CHARGE NOW | rule | 1.00 | 1.67 | 37.4 |
| CHARGE NOW FIRST | rule | 1.00 | 0.33 | 91.1 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.67 | 21.8 |
| DEPLOY BY FIGURES | rule | 0.67 | - | 3.1 |
| AFTERMATH BAND | gate | - | 0.33 | 1.3 |
| CHARGE NOT DECLARED | rule | 0.33 | - | 223.6 |
| MARCH OF THE TABLE | rule | - | 0.33 | 1.1 |
| NO REASON | gate | - | 0.33 | 88.6 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.33 | 13.5 |
| RULE SWITCHED OFF | gate | 0.33 | - | 10.4 |
| WHO GETS IN | rule | 0.33 | - | 30.5 |

### Plans: gs3-83c8646-p47

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 4.7 | 64% | 710 | 408 | 57% |
| Mine | join | 1.3 | 100% | 47 | 0 | 0% |
| Mine | move | 28.7 | 94% | 2459 | 0 | 0% |
| Mine | shoot | 2.0 | 50% | 80 | 142 | 178% |
| Opponent | charge | 2.3 | 86% | 329 | 222 | 68% |
| Opponent | join | 1.0 | 100% | 75 | 0 | 0% |
| Opponent | move | 25.0 | 89% | 903 | 0 | 0% |
| Opponent | shoot | 0.7 | 50% | 37 | 22 | 59% |

### Battle groups: gs3-83c8646-p47

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.3 | 15% | 0% | 0% | - | 0% | 0% | 50% | 50% | 0% |
| Opponent | REDIRECT COUNTER | 2.3 | 29% | 50% | 50% | 0% | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p47

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 182 (2) | 0 | 182 | 100 | 0% | 1.0 | - | 182 (2) | - | - | 182 (2) |
| Mine | Character | 3 | 140 (3) | 140 | 0 | 5 | 0% | 2.7 | 235 (1) | 54 (2) | - | 211 (2) | 60 (1) |
| Mine | Clean-up | 1 | 30 (1) | 30 | 0 | 100 | 0% | 5.0 | - | - | 30 (1) | 30 (1) | - |
| Mine | Fast | 2 | 17 (2) | 17 | 0 | 0 | 50% | 5.0 | 17 (2) | - | - | 17 (2) | - |
| Mine | Fast Hammer | 2 | 90 (2) | 90 | 0 | 0 | 0% | 3.5 | 62 (1) | 119 (1) | - | - | 90 (2) |
| Mine | Hammer | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Holder | 3 | 78 (3) | 0 | 78 | 31 | 0% | 2.7 | 114 (2) | 0 (1) | - | 125 (2) | 0 (1) |
| Mine | Shooter | 1 | 168 (1) | 168 | 0 | 100 | 0% | 1.0 | - | 168 (1) | - | - | 168 (1) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 100 | 0% | 1.0 | - | - | - | - | - |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 4 | 353 (4) | 53 | 300 | 56 | 25% | 5.3 | 424 (2) | 299 (2) | - | 271 (3) | 600 (1) |
| Opponent | Character | 8 | 70 (8) | 70 | 0 | 65 | 25% | 3.5 | 0 (2) | 95 (3) | 32 (3) | 102 (6) | 9 (2) |
| Opponent | Fast Hammer | 4 | 34 (4) | 34 | 0 | 46 | 25% | 4.3 | - | 0 (1) | 44 (3) | 13 (2) | 66 (2) |
| Opponent | Hammer | 3 | 88 (3) | 88 | 0 | 63 | 33% | 4.5 | 88 (3) | - | - | 88 (3) | - |
| Opponent | Holder | 3 | 7 (3) | 0 | 7 | 100 | 0% | 4.0 | - | 10 (2) | 0 (1) | - | 7 (3) |
| Opponent | Wizard | 3 | 4 (3) | 4 | 0 | 87 | 0% | 2.0 | 5 (2) | 0 (1) | - | 7 (2) | 0 (1) |

### Charged fights: gs3-83c8646-p47

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Tomb Kings of Khemri | 1 | 311 | 1437 | 5.0 | 1.4 | 287 | 13 | +274 | 1 of 5 | 4 of 5 | +52 | +422 |
| Mine | Vampire Counts | 1 | 0 | 325 | 5.0 | 1.2 | 65 | 29 | +36 | 2 of 5 | 3 of 5 | +190 | -3 |
| **Mine** | all armies | 2 | 156 | 881 | 5.0 | 1.3 | 176 | 21 | +155 | 3 of 10 | 7 of 10 | +98 | +179 |
| Opponent | Vampire Counts | 1 | 0 | 304 | 5.0 | 1.0 | 61 | 0 | +61 | 5 of 5 | 5 of 5 | - | +61 |
| Opponent | Warriors of Chaos | 1 | 0 | 401 | 2.0 | 1.5 | 200 | 116 | +84 | 1 of 2 | 1 of 2 | +401 | -232 |
| **Opponent** | all armies | 2 | 0 | 352 | 3.5 | 1.1 | 101 | 33 | +68 | 6 of 7 | 6 of 7 | +401 | +12 |

### Effective charges: gs3-83c8646-p47

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Tomb Kings of Khemri | 5 | 1 (net +104) | 0 | 1 (net +120) | 0 | 2 (net +444) | 1 (net +260) | 0 | 20% (1 of 5) |
| Mine | Vampire Counts | 5 | 2 (net -74) | 0 | 1 (net +75) | 0 | 1 (net +190) | 0 | 1 | 25% (1 of 4) |
| Opponent | Vampire Counts | 5 | 2 (net +0) | 0 | 1 (net +254) | 0 | 0 | 1 (net +0) | 1 | 25% (1 of 4) |
| Opponent | Warriors of Chaos | 2 | 0 | 0 | 1 (net -232) | 0 | 1 (net +401) | 0 | 0 | 50% (1 of 2) |

### Charged fights, damage counted: gs3-83c8646-p47

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 3 | 236 | 340 | -14 | 67 | 79 | -12 | -4.9 |
| Mine | Effective (55-75%) | 2 | 224 | 98 | +98 | 98 | 32 | +65 | +29.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 431 | 144 | +260 | 260 | 48 | +212 | +49.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 438 | 140 | +359 | 359 | 0 | +359 | +81.9 |
| Mine | No odds | 1 | 471 | 60 | +60 | 60 | 0 | +60 | +12.7 |
| Mine | All fights | 10 | 337 | 184 | +155 | 179 | 35 | +144 | +42.8 |
| Opponent | Long shot (under 50%) | 2 | 260 | 220 | +0 | 0 | 3 | -3 | -1.2 |
| Opponent | Effective (55-75%) | 2 | 151 | 224 | +11 | 143 | 116 | +27 | +18.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 45 | 60 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 311 | 66 | +401 | 401 | 158 | +243 | +78.0 |
| Opponent | No odds | 1 | 471 | 190 | +50 | 50 | 0 | +50 | +10.6 |
| Opponent | All fights | 7 | 236 | 172 | +68 | 105 | 57 | +49 | +20.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p47 | move | 19 | 5 (26%) | 5 (26%) | 3 (16%) | 11 (58%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2527 |
| Charmed Shield | Opponent | L2227, L2527 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L2227, L2527 |
| Ring of Doom | Opponent | L2331 |

# Doctrine scorecard: gs3-83c8646-p51

### Scorecard: gs3-83c8646-p51

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0405 | 3 | 1 | Mine | no | 2 | 3 | 4 | 3 | 0 | 0 | 0 | 139 |
| L0405 | 3 | 1 | Opponent | no | 0 | 4 | 2 | 1 | 0 | 0 | 0 | 668 |
| L0421 | 1 | 1 | Mine | no | 9 | 3 | 1 | 0 | 0 | 0 | 0 | 139 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 0 | 6 | 1 | 0 | 0 | 210 |
| L0508 | 4 | 1 | Mine | no | 7 | - | 0 | 2 | 0 | 0 | 0 | 380 |
| L0508 | 4 | 1 | Opponent | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 560 |
| **Average** | | | Mine | 0% | 6.0 | 3.0 | 1.7 | 1.7 | 0.0 | 0.0 | 0.0 | 219.3 |
| **Average** | | | Opponent | 0% | 0.0 | 4.0 | 0.7 | 3.3 | 0.3 | 0.0 | 0.0 | 479.3 |

### KPIs: gs3-83c8646-p51

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 10) | 67% (4 of 6) | 25% (4 of 16) |
| Winner chose to follow up after the loser gave ground |  | 100% (3 of 3); on the table 100% | 100% (2 of 2); on the table 100% | 100% (5 of 5); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fled |  | - | 33% (1 of 3); on the table 33% | 33% (1 of 3); on the table 33% |
| Winner chose to follow up or pursue (all three) |  | 100% (3 of 3); on the table 100% | 50% (3 of 6); on the table 50% | 67% (6 of 9); on the table 67% |
| Magic missiles tried each own turn | 50%+ | 33% (4 of 12) | 33% (2 of 6) | 33% (6 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 33% (4 of 12) | 50% (2 of 4) | 38% (6 of 16) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 50% (6 of 12) | 50% (6 of 12) |
| Points that never fought | lower | 82% (4899 of 5998) | 81% (4837 of 5999) | 81% (9736 of 11997) |
|   infantry points that never fought | lower | 78% (1115 of 1424) | 83% (1414 of 1703) | 81% (2529 of 3127) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 65% (15 of 23) | 65% (17 of 26) | 65% (32 of 49) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game | 100% (1 of 1); 0.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 68% (3461 of 5120) | 54% (2517 of 4677) | 61% (5978 of 9797) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (50%) | 0.3 (25%) | 1.7 (42%) |
| MARCHED: its unit marched | 1.3 (50%) | 0.3 (25%) | 1.7 (42%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (25%) | 0.3 (8%) |
| GONE: slain | 0.0 (0%) | 0.3 (25%) | 0.3 (8%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.3 | 1.0 | 2.0 | 1.7 | 0.7 |
| not cast | 2.7 | 3.0 | 4.0 | 2.3 | 11.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.7 (89%) | 1.7 (42%) | 0.3 (14%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.7 (42%) | 1.3 (57%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.3 (8%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.3 (12%) | 0.0 (0%) | 0.3 (8%) | 0.0 (0%) | 1.0 (9%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (29%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (88%) | 0.3 (11%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 10.0 (88%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 0.0 a game | 0.5 a game |
| stood (cast and not dispelled) | 33% (1 of 3) | - | 33% (1 of 3) |
| the unit moved after it | 0% (0 of 1) | - | 0% (0 of 1) |
| it charged on its next turn | 0% (0 of 1) | - | 0% (0 of 1) |
| the enemy charged it first | 0% (0 of 1) | - | 0% (0 of 1) |
| it fought by the end of its next turn | 0% (0 of 1) | - | 0% (0 of 1) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 1) | - | 0% (0 of 1) |
| none of these (no charge, no fight, no charge escaped) | 100% (1 of 1) | - | 100% (1 of 1) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 60% (48 of 80) | 71% (74 of 104) | 66% (122 of 184) |
|   cavalry | 64% (7 of 11) | 0% (0 of 7) | 39% (7 of 18) |
|   character | 50% (5 of 10) | 83% (19 of 23) | 73% (24 of 33) |
|   chariot | 57% (12 of 21) | 54% (7 of 13) | 56% (19 of 34) |
|   infantry | 17% (2 of 12) | 59% (13 of 22) | 44% (15 of 34) |
|   war machine | 85% (22 of 26) | 90% (35 of 39) | 88% (57 of 65) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (22%) | 1.7 (17%) | 4.0 (19%) |
| CHARGED: it charged | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| NO TARGET IN RANGE | 4.7 (44%) | 3.0 (30%) | 7.7 (37%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 1.0 (10%) | 1.3 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 3.3 (31%) | 2.3 (23%) | 5.7 (27%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 1.0 (10%) | 1.0 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.3 | 0.7 | 71% | 1.3 pts | 3 pts |
| character | 8.3 | 3.0 | 80% | 9.6 pts | 80 pts |
| chariot | 6.3 | 8.3 | 53% | 15.0 pts | 95 pts |
| infantry | 8.7 | 4.3 | 62% | 15.7 pts | 136 pts |
| war machine | 19.0 | 20.0 | 60% | 22.9 pts | 436 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.3 | 0.7 | 1.0 |
| Charges that made contact a game | 1.0 | 0.3 | 0.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.18 declared, 0.14 contact (22 units) | 0.09 declared, 0.05 contact (22 units) | 0.14 declared, 0.09 contact (44 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 0% (0 of 3) | 100% (1 of 1) | - | 25% (1 of 4) |
| Character in a unit | 100% (9 of 9) | 50% (1 of 2) | - | 91% (10 of 11) |
| Character on its own | 100% (3 of 3) | 50% (1 of 2) | 67% (2 of 3) | 75% (6 of 8) |
| Chariot | 50% (1 of 2) | 80% (4 of 5) | - | 71% (5 of 7) |
| Infantry | 75% (6 of 8) | 20% (1 of 5) | 0% (0 of 1) | 50% (7 of 14) |
| Monster | - | 0% (0 of 1) | - | 0% (0 of 1) |
| War Machines | 75% (3 of 4) | - | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 2 | 100% (3 of 3); on the table 100% | 33% (4 of 12) | 73% | 62% (10 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Dwarfen Mountain Holds | 2 | 100% (1 of 1); on the table 100% | - | 87% | 71% (10 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | - | - | 100% | 70% (7 of 10) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 40% (2 of 5); on the table 40% | 33% (2 of 6) | 67% | 56% (5 of 9) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p51, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | - | 100% (1) | 100% (1) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: gs3-83c8646-p51

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 25% (1 of 4) | 0% (0 of 1) |
| Strategy | Shoot objectives carried out (shot that target) | 59% (19 of 32) | 60% (26 of 43) |
| Strategy | Joined characters whose unit fought | 0% (0 of 5) | 0% (0 of 8) |
| Strategy | Lone characters that fought | 33% (2 of 6) | 43% (3 of 7) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.7 | 3.3 |
| Movement | Points that never moved of their own | 219.3 | 479.3 |
| Movement | Fights charged into per game | 1.0 | 0.3 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 2, net +0 | - |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | - |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 2 | - |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 2, net +0 | - |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.7 | 13.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 58% (15 of 26) | 78% (32 of 41) |
| Shooting | Points destroyed by shooting units | 247.3 | 149.7 |
| Shooting | War machine shots | 7.3 | 11.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 23% (5 of 22) | 46% (16 of 35) |
| Shooting | Points destroyed by war machines | 176.0 | 21.7 |
| Magic | Magic missiles cast | 0.3 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 100% (1 of 1) | 50% (1 of 2) |
| Magic | Wounds caused by magic missiles | - | 0.3 |
| Magic | Wounds caused by other spells | - | 1.3 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 1.3 | 1.3 / 0.0 / 0.7 / 0.0 |
| Combat | Points destroyed in combat | 142.3 | 21.7 |
| Combat | Points run down | 61.7 | 37.3 |
| Combat | Net points per charged fight, damage counted | +235 | +378 |
| Combat | Net per 100 charger points, damage counted | +69.5 | +755.4 |
| Combat | First round won (charged fights) | 33% | 100% |
| Combat | Net points per charged fight | +204 | +112 |
| Combat | Net points per supported fight / lone fight | - / +204 | - / +112 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 3 | 0 of 1 |
| Game | Points lost | 397.0 | 703.0 |
| Game | VP from objectives | 843.3 | 800.0 |
| Game | Lone holders (player turns) | 6.0 | 0.0 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +302 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 1100
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p51

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 11.7 | +218.7 | 0.0 | 136.0 | 9.7 | -38.4 | 0.0 | 261.7 |
| ARTILLERY RE-ROLL WEIGHED | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 43.3 |
| ASSAILMENT BY POINTS | - | - | - | - | 0.7 | +3.8 | 0.0 | 180.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | +2.2 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 1.7 | +0.0 | 233.3 | 31.7 | 1.0 | +0.0 | 228.3 | 0.0 |
| CANNON PLANNED TARGET | 6.7 | +26.8 | 565.3 | 95.0 | 11.7 | +137.4 | 685.3 | 126.7 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.3 | +8.2 | 0.0 | 12.0 |
| CHARACTER GUNS | 3.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 22.0 | -951.5 | 0.0 | 281.3 | 8.7 | -604.3 | 0.0 | 388.7 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 8.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.7 | +12.1 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 2.7 | -63.8 | 0.0 | 31.7 | 2.3 | -115.8 | 0.0 | 127.0 |
| DENIED BY THE FIGHT | 0.3 | -0.7 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.7 | +40.3 | 0.0 | 0.0 | 9.0 | -53.5 | 0.0 | 135.0 |
| DUEL STOPS AT THE KILL | 0.7 | -101.4 | 96.3 | 0.0 | - | - | - | - |
| EXACT ROUND | 0.7 | +19.3 | 61.7 | 0.0 | 0.3 | -1.6 | 37.3 | 0.0 |
| FALL BACK GOOD ORDER | 1.0 | +7.9 | 96.3 | 0.0 | 0.3 | +0.0 | 37.3 | 0.0 |
| FALLS SHORT | 7.7 | +120.6 | 0.0 | 130.0 | 10.7 | +134.3 | 0.0 | 52.3 |
| FEATURE BUFFS | 0.3 | +6.2 | 0.0 | 0.0 | 1.3 | +9.5 | 0.0 | 61.3 |
| FIRE IN ORDER | 1.7 | +0.0 | 41.7 | 31.7 | 0.7 | +0.0 | 46.3 | 0.0 |
| FIVE ACTION | 92.7 | +6672.2 | 2278.0 | 964.0 | 91.3 | +3148.0 | 1511.3 | 1161.0 |
| FLANK NOT WEIGHED | 2.7 | +0.0 | 0.0 | 125.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.7 | +7.8 | 0.0 | 0.0 | 0.3 | +88.3 | 0.0 | 0.0 |
| FOOT FIRST | 21.7 | +0.0 | 0.0 | 312.0 | - | - | - | - |
| FOUR ROUNDS | 1.3 | +225.6 | 158.0 | 0.0 | 0.7 | +77.8 | 37.3 | 0.0 |
| FREED FROM HIS FIGHT | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 1.0 | -19.9 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.3 | +8.3 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -9.9 | 96.3 | 0.0 | - | - | - | - |
| GOAL ON TIME | 0.3 | +40.6 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 13.0 | +1616.3 | 0.0 | 43.3 | 3.0 | +87.8 | 0.0 | 0.0 |
| GUN FIGURES | 2.3 | +93.2 | 210.7 | 0.0 | 3.3 | +0.9 | 0.0 | 21.7 |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 7.0 | +0.0 | 0.0 | 281.3 | 6.0 | +0.0 | 0.0 | 254.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +16.1 | 0.0 | 0.0 |
| HIS CHARGE LIST | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 192.7 |
| HIS LEGAL MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 1.7 | -9.7 | 0.0 | 0.0 | 3.7 | -57.7 | 0.0 | 0.0 |
| HIS ONE QUARTER | 3.3 | +0.0 | 0.0 | 206.7 | 10.0 | +0.0 | 0.0 | 192.7 |
| HIS OWN BEST MOVE | 5.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 6.7 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS RANDOM MOVER COMES | 4.3 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 49.0 | +3235.6 | 0.0 | 524.0 | 35.7 | +1233.0 | 0.0 | 499.3 |
| HIS SHOTS BY HIS RUN | 33.3 | +714.3 | 0.0 | 386.0 | 24.3 | +517.8 | 0.0 | 412.7 |
| HOLD ODDS | 15.0 | +0.0 | 0.0 | 74.7 | 16.7 | +0.0 | 0.0 | 122.7 |
| HOLDER ASSIGNMENT | 9.7 | +919.5 | 0.0 | 74.7 | 9.3 | +722.3 | 0.0 | 98.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -104.2 | 158.0 | 0.0 | 0.3 | -1.8 | 37.3 | 0.0 |
| HUNT IN PAIRS | 0.3 | +7.9 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | 7.0 | -115.0 | 0.0 | 68.0 | 8.3 | -103.8 | 0.0 | 33.7 |
| KEPT FROM ITS LAST STOP | 3.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +36.6 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 96.3 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.7 | +63.4 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.7 | -13.4 | 37.3 | 0.0 |
| LOST AFTER ESCAPE | 0.7 | -1.1 | 96.3 | 0.0 | 0.3 | +4.0 | 37.3 | 0.0 |
| MANOEUVRE | 2.3 | +164.4 | 0.0 | 103.3 | 2.3 | +3.1 | 0.0 | 30.7 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.3 | +5.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.0 | -39.5 | 0.0 | 0.0 | 0.3 | +61.3 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.7 | +69.0 | 0.0 | 0.0 | - | - | - | - |
| MEETS IN TIME | 2.7 | +300.6 | 0.0 | 0.0 | 3.7 | +178.8 | 0.0 | 41.7 |
| MISSILES IN THE MOVE | 2.0 | +28.0 | 0.0 | 0.0 | 2.0 | +16.5 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 3.3 | +32.0 | 0.0 | 0.0 | 2.7 | +40.6 | 0.0 | 180.0 |
| MOVE ORDER | 1.0 | +0.0 | 103.3 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 3.0 | +107.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 2.3 | -120.4 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 4.0 | +316.7 | 0.0 | 0.0 | 0.7 | +34.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.3 | +247.5 | 0.0 | 37.3 | 6.0 | +265.0 | 0.0 | 30.7 |
| NEAREST TO GOAL | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 2.7 | +229.3 | 0.0 | 0.0 | 0.7 | +34.4 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.0 | -40.2 | 158.0 | 0.0 | 0.7 | -83.1 | 37.3 | 0.0 |
| NO LATE CUT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 0.3 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 4.7 | -351.7 | 0.0 | 31.7 | 4.7 | -112.6 | 37.3 | 41.7 |
| ONE FIGHT FORMULA | 3.7 | -120.1 | 0.0 | 0.0 | 0.7 | -6.0 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 1.7 | -6.8 | 0.0 | 37.3 | 4.3 | -43.5 | 0.0 | 30.7 |
| ONE ROUTE | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +19.8 | 61.7 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.3 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| PATHS CROSS | - | - | - | - | 0.3 | +2.2 | 0.0 | 0.0 |
| PERIAPT WORTH | - | - | - | - | 0.3 | +18.0 | 0.0 | 0.0 |
| PLAN RESULT | 41.3 | +1057.1 | 911.3 | 726.0 | 43.3 | +742.6 | 239.3 | 738.7 |
| PROMISE BY ITS OWN SUM | 8.0 | -532.5 | 0.0 | 0.0 | 2.3 | -61.1 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.3 | -5.6 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 0.3 | -1.1 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 24.0 | +2129.5 | 732.7 | 270.0 | 26.0 | +2126.5 | 967.3 | 636.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.0 | +14.3 | 0.0 | 48.3 |
| REAL GROUND | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.7 | +18.5 | 0.0 | 21.7 | 0.7 | +2.9 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 0.3 | +0.0 | 0.0 | 21.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -35.2 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 0.7 | +6.2 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 0.7 | +2.8 | 96.3 | 0.0 | 0.3 | -4.3 | 0.0 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.7 | -14.4 | 96.3 | 0.0 | - | - | - | - |
| RUN DOWN | 0.7 | -2.6 | 96.3 | 0.0 | 0.7 | -28.4 | 37.3 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | -166.9 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SECOND LOOK | - | - | - | - | 0.3 | +4.7 | 37.3 | 0.0 |
| SET CREDITED ONCE | 1.3 | -93.1 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 1.3 | +142.9 | 0.0 | 0.0 | - | - | - | - |
| SET-UP ANY TARGET | 0.3 | +16.2 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | 0.7 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 10.3 | +0.0 | 0.0 | 198.3 | 13.3 | +0.0 | 0.0 | 306.7 |
| SHOOTS FROM THE BEST SPOT | 4.3 | +430.6 | 360.0 | 206.7 | 1.3 | +7.3 | 0.0 | 360.0 |
| SHORT GUN FORWARD | - | - | - | - | 0.3 | +0.0 | 0.0 | 45.0 |
| SHOT OR CHARGE | 0.3 | -14.5 | 0.0 | 0.0 | 0.7 | -8.1 | 0.0 | 0.0 |
| SHOT RISK POINTS | 33.0 | +963.9 | 0.0 | 356.7 | 20.3 | +187.2 | 0.0 | 306.7 |
| SHOTS AFTER THE MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.7 | +847.4 | 0.0 | 370.7 | 20.3 | +562.5 | 0.0 | 148.3 |
| SPELL SETS UP CHARGE | 0.3 | +16.2 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | - | - | - | - | 3.3 | +74.3 | 360.0 | 360.0 |
| SPOT AS THE GAME MOVES | 4.3 | +0.0 | 0.0 | 140.7 | 3.7 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | 0.3 | -0.5 | 96.3 | 0.0 | 0.3 | -2.2 | 37.3 | 0.0 |
| STANDS FOR A REASON | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 46.7 | +0.0 | 2120.0 | 596.0 | 55.0 | +0.0 | 1474.0 | 857.7 |
| STAY WORTH | 28.3 | +569.9 | 1324.0 | 428.3 | 37.0 | -18.3 | 854.0 | 565.3 |
| STUCK PIVOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 48.3 |
| SUPPORT ADDS | - | - | - | - | 1.0 | +25.2 | 0.0 | 30.7 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 37.3 | 0.0 |
| SUPPORT WORKED OUT | - | - | - | - | 1.0 | +25.2 | 0.0 | 30.7 |
| SWIFTSTRIDE BY POINTS | 0.3 | +7.8 | 0.0 | 37.3 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.3 | +0.0 | 0.0 | 103.3 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 3.0 | +0.0 | 0.0 | 21.7 | 4.3 | +0.0 | 0.0 | 43.3 |
| THE STEP BACK IS MADE | 2.7 | +0.0 | 0.0 | 21.7 | 3.3 | +0.0 | 0.0 | 21.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 43.3 | +0.0 | 0.0 | 450.3 | 41.7 | +0.0 | 0.0 | 392.7 |
| TIME ON OUR SIDE | 24.0 | +329.1 | 269.3 | 190.0 | 17.0 | +186.6 | 0.0 | 67.3 |
| WAITS AGAIN | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -20.0 | 0.0 | 67.3 |
| WAR ENGINE JOBS | 2.0 | +0.0 | 360.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | - | - | - | - | 0.3 | +9.4 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 4.0 | -130.9 | 0.0 | 74.7 | 2.7 | -464.9 | 0.0 | 192.7 |
| WOUNDS ON THE RANKS | 2.7 | +185.7 | 0.0 | 0.0 | 2.0 | +23.5 | 0.0 | 134.7 |

### Rule changes: gs3-83c8646-p51

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 254 | 239 | 64 | 21.33 | +621 | +9.7 |
| HOLDER ASSIGNMENT | 57 | 57 | 53 | 17.67 | +2653 | +50.1 |
| HIS SHOTS BY HIS RUN | 173 | 162 | 51 | 17.00 | +542 | +10.6 |
| ARMY TABLE | 64 | 64 | 41 | 13.67 | +597 | +14.6 |
| DEPLOY BY FIGURES | 53 | 53 | 38 | 12.67 | +613 | +16.1 |
| SHOT RISK POINTS | 160 | 150 | 38 | 12.67 | +568 | +14.9 |
| OFF BEST | 28 | 28 | 28 | 9.33 | -1393 | -49.7 |
| GOAL WALK | 48 | 41 | 22 | 7.33 | +2547 | +115.8 |
| TIME ON OUR SIDE | 123 | 107 | 15 | 5.00 | +7 | +0.5 |
| MOVE TO CHARGE COMPUTED | 14 | 13 | 13 | 4.33 | +582 | +44.8 |
| THE TABLE AGAIN | 36 | 36 | 13 | 4.33 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 31 | 31 | 12 | 4.00 | -1780 | -148.4 |
| FIVE ACTION | 552 | 535 | 11 | 3.67 | +537 | +48.8 |
| CANNON PLANNED TARGET | 55 | 55 | 10 | 3.33 | -83 | -8.3 |
| IDLE COST | 46 | 38 | 10 | 3.33 | +61 | +6.1 |
| NEXT CHARGE BY LIST | 10 | 10 | 10 | 3.33 | +512 | +51.2 |
| SHOOTS FROM THE BEST SPOT | 17 | 17 | 10 | 3.33 | +630 | +63.0 |
| ADVANCE LANE KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 20 | 20 | 8 | 2.67 | +525 | +65.7 |
| FIRE IN ORDER | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| MOVE ORDER | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| HARD STAY DROPPED | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| QUARTER ODDS | 150 | 148 | 6 | 2.00 | +316 | +52.6 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 6 | 2.00 | +43 | +7.1 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| MEETS IN TIME | 19 | 19 | 5 | 1.67 | +199 | +39.8 |
| REDIRECT FOR A FRIEND IN REACH | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| SHOTS IN THE MOVE | 111 | 75 | 5 | 1.67 | +85 | +17.0 |
| FOUR ROUNDS | 6 | 5 | 4 | 1.33 | +191 | +47.8 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +110 | +27.4 |
| LEGAL CHARGES ONLY | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 4 | 4 | 4 | 1.33 | +8 | +2.0 |
| STAY WORTH | 196 | 169 | 4 | 1.33 | +114 | +28.5 |
| CHAFF IN THE MOVE | 4 | 4 | 3 | 1.00 | +1 | +0.5 |
| CHARGE LOSSES | 92 | 82 | 3 | 1.00 | +17 | +5.5 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FALLS SHORT | 55 | 50 | 3 | 1.00 | +54 | +18.1 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +288 | +96.1 |
| MANOEUVRE | 14 | 14 | 3 | 1.00 | +503 | +167.5 |
| STUCK PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| ASSAILMENT BY POINTS | 2 | 2 | 2 | 0.67 | +12 | +5.8 |
| COVER ONCE | 15 | 11 | 2 | 0.67 | +62 | +31.1 |
| HIS MOVE AND SHOT | 16 | 14 | 2 | 0.67 | +3 | +1.4 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +190 | +95.2 |
| MAX FOR POSITIONING | 8 | 7 | 2 | 0.67 | +4 | +1.8 |
| NEARER NOT NEEDED | 34 | 32 | 2 | 0.67 | +126 | +63.0 |
| PROMISE KNOWS THE FIGHT | 4 | 4 | 2 | 0.67 | -17 | -8.5 |
| REDIRECT COUNTER | 4 | 3 | 2 | 0.67 | +69 | +34.3 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +19 | +9.3 |
| SET CREDITED ONCE | 4 | 4 | 2 | 0.67 | +5 | +2.3 |
| SET UP BY THE SET | 4 | 4 | 2 | 0.67 | +61 | +30.5 |
| WAR ENGINE JOBS | 6 | 6 | 2 | 0.67 | -231 | -115.5 |
| CHARGE NOW FIRST | 2 | 2 | 1 | 0.33 | -148 | -148.1 |
| FEATURE BUFFS | 5 | 5 | 1 | 0.33 | +15 | +14.7 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +25 | +24.8 |
| GOAL ON TIME | 1 | 1 | 1 | 0.33 | -9 | -8.9 |
| HIS CHARGE DENIED | 1 | 1 | 1 | 0.33 | +30 | +29.9 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +0 | +0.2 |
| ONE OBJECTIVE FORMULA | 18 | 12 | 1 | 0.33 | +28 | +28.1 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +7 | +6.7 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +54 | +54.0 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +14 | +14.1 |
| SHORT GUN FORWARD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +23 | +23.4 |
| THE ROW IN ITS ORDER | 15 | 1 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -60 | -60.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | -4 | -4.5 |
| WOUNDS ON THE RANKS | 14 | 14 | 1 | 0.33 | +13 | +12.9 |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 8 | 8 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 24 | 22 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 42 | 42 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 2 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| EXACT ROUND | 3 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 4 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 14 | not checked | - | - | - | - |
| FOOT FIRST | 65 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 12 | 10 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 3 | 3 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 17 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 6 | 6 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 39 | 37 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 7 | 7 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 11 | 11 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 40 | 40 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 18 | 18 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 20 | 20 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 13 | 13 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 95 | 93 | 0 | 0.00 | - | - |
| HONEST WORTH | 5 | 4 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 13 | 11 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 3 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH CHECK | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 9 | 7 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 12 | 5 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 18 | 10 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 9 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 7 | trace | - | - | - | - |
| NEAREST TO GOAL | 6 | 5 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 5 | 4 | 0 | 0.00 | - | - |
| NO LATE CUT | 5 | 5 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 13 | 6 | 0 | 0.00 | - | - |
| ONE ROUTE | 9 | 7 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 254 | trace | - | - | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 9 | 7 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 2 | 2 | 0 | 0.00 | - | - |
| RISK BY ARC | 3 | 3 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 4 | 3 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SEARCH SPOT | 1 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 71 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 24 | 24 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 10 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 24 | 16 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 10 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 305 | 301 | 0 | 0.00 | - | - |
| SUPPORT ADDS | 3 | 3 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| SUPPORT WORKED OUT | 3 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 4 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 22 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 18 | not checked | - | - | - | - |
| THE TABLE BINDS | 255 | not checked | - | - | - | - |
| WAITS AGAIN | 5 | 5 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p51

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.33 | 4.00 | 48.0 |
| PROMISE BY ITS OWN SUM | rule | 3.33 | 0.67 | 148.4 |
| ARMY TABLE | rule | 1.67 | 0.33 | 44.1 |
| CANNON PLANNED TARGET | rule | - | 1.67 | 16.7 |
| NO REASON | gate | 1.33 | - | 80.8 |
| PROMISE KNOWS THE FIGHT | rule | 0.67 | - | 8.5 |
| WAR ENGINE JOBS | rule | 0.67 | - | 115.5 |
| AFTERMATH BAND | gate | - | 0.33 | 4.5 |
| CHARGE NOW FIRST | rule | 0.33 | - | 148.1 |
| GOAL ON TIME | rule | 0.33 | - | 8.9 |
| RULE SWITCHED OFF | gate | - | 0.33 | 9.2 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 60.0 |
| WHO HITS BACK | rule | - | 0.33 | 4.5 |

### Plans: gs3-83c8646-p51

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 33% | 169 | 252 | 149% |
| Mine | join | 0.3 | 100% | 11 | 0 | 0% |
| Mine | move | 30.3 | 95% | 1966 | 0 | 0% |
| Mine | shoot | 9.3 | 57% | 720 | 822 | 114% |
| Opponent | charge | 0.7 | 50% | 27 | 37 | 138% |
| Opponent | join | 1.3 | 100% | 46 | 0 | 0% |
| Opponent | move | 28.3 | 94% | 909 | 0 | 0% |
| Opponent | shoot | 12.3 | 65% | 406 | 705 | 174% |
| Opponent | support | 0.7 | 100% | 0 | 0 | - |

### Battle groups: gs3-83c8646-p51

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.7 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 0.7 | 50% | 100% | 100% | 0% | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p51

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | 0 (1) | - | 0 (1) | 0 (2) | - |
| Mine | Character | 11 | 32 (11) | 32 | 0 | 0 | 18% | 2.6 | 19 (5) | 68 (4) | 0 (2) | 15 (7) | 50 (4) |
| Mine | Clean-up | 3 | 99 (3) | 0 | 99 | 0 | 33% | 4.5 | 99 (3) | - | - | 150 (2) | 0 (1) |
| Mine | Hammer | 8 | 44 (8) | 29 | 15 | 37 | 12% | 2.1 | 0 (2) | 53 (6) | - | 90 (5) | 0 (3) |
| Mine | Holder | 4 | 82 (4) | 0 | 82 | 49 | 75% | 2.0 | 0 (1) | 108 (3) | - | 237 (1) | 24 (3) |
| Mine | Shooter | 1 | 27 (1) | 0 | 27 | 0 | 0% | 1.0 | 27 (1) | - | - | - | 27 (1) |
| Mine | War machine | 5 | 111 (5) | 111 | 0 | 40 | 0% | 1.0 | 111 (5) | - | - | 278 (2) | 0 (3) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 23 | 100% | - | 0 (1) | 0 (1) | 0 (1) | 0 (1) | 0 (2) |
| Opponent | Character | 14 | 16 (14) | 16 | 0 | 49 | 43% | 2.8 | 21 (10) | 0 (3) | - | 20 (9) | 0 (4) |
| Opponent | Clean-up | 4 | 113 (4) | 16 | 96 | 0 | 75% | 5.0 | - | 113 (4) | - | 113 (4) | - |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Hammer | 6 | 85 (6) | 58 | 27 | 35 | 17% | 2.4 | 163 (2) | 0 (1) | 55 (3) | 85 (6) | - |
| Opponent | Holder | 3 | 0 (3) | 0 | 0 | 29 | 100% | - | - | 0 (2) | 0 (1) | 0 (1) | 0 (2) |
| Opponent | Shooter | 4 | 12 (4) | 0 | 12 | 54 | 50% | 2.0 | - | 20 (3) | 0 (1) | 12 (4) | - |
| Opponent | War machine | 9 | 7 (9) | 7 | 0 | 52 | 11% | 1.0 | 7 (9) | - | - | 0 (1) | 8 (8) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | 0 (1) | - |

### Charged fights: gs3-83c8646-p51

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 270 | 306 | 1.5 | 1.0 | 204 | 0 | +204 | 2 of 3 | 1 of 3 | - | +204 |
| Mine | Dwarfen Mountain Holds | 1 | 730 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 423 | 204 | 1.0 | 1.0 | 204 | 0 | +204 | 2 of 3 | 1 of 3 | - | +204 |
| Opponent | Dwarfen Mountain Holds | 1 | 449 | 112 | 1.0 | 1.0 | 112 | 0 | +112 | 0 of 1 | 1 of 1 | - | +112 |
| Opponent | Empire of Man | 1 | 65 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 171 | 37 | 0.3 | 1.0 | 112 | 0 | +112 | 0 of 1 | 1 of 1 | - | +112 |

### Effective charges: gs3-83c8646-p51

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 3 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +0) | 1 | 0% (0 of 2) |

### Charged fights, damage counted: gs3-83c8646-p51

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 339 | 239 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 339 | 440 | +0 | 385 | 291 | +94 | +27.9 |
| Mine | No odds | 1 | 339 | 138 | +612 | 612 | 0 | +612 | +180.5 |
| Mine | All fights | 3 | 339 | 272 | +204 | 332 | 97 | +235 | +69.5 |
| Opponent | No odds | 1 | 50 | 112 | +112 | 378 | 0 | +378 | +755.4 |
| Opponent | All fights | 1 | 50 | 112 | +112 | 378 | 0 | +378 | +755.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p51 | move | 12 | 4 (33%) | 3 (25%) | 0 (0%) | 8 (67%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Periapt of Soul Exchange | Opponent | L0421 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421 |
| Witch Hunter's Ward | Opponent | L0508 |

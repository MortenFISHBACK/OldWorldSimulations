# Doctrine scorecard: gs3-83c8646-p8

### Scorecard: gs3-83c8646-p8

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1319 | 5 | 1 | Mine | yes | - | 3 | 3 | 2 | 0 | 0 | 0 | 140 |
| L1319 | 5 | 1 | Opponent | yes | - | 2 | 4 | 5 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 1 | 4 | 1 | 1 | 0 | 0 | 0 | 540 |
| L1335 | 3 | 1 | Opponent | no | 2 | 3 | 5 | 2 | 0 | 0 | 0 | 110 |
| L1431 | 3 | 1 | Mine | no | 5 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 0 | - | 2 | 1 | 1 | 0 | 0 | 170 |
| **Average** | | | Mine | 33% | 3.0 | 3.0 | 2.3 | 1.7 | 0.0 | 0.0 | 0.0 | 226.7 |
| **Average** | | | Opponent | 33% | 1.0 | 2.5 | 3.7 | 2.7 | 0.3 | 0.0 | 0.0 | 93.3 |

### KPIs: gs3-83c8646-p8

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 19% (3 of 16) | 0% (0 of 14) | 10% (3 of 30) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 100% (5 of 5); on the table 100% | 100% (6 of 6); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | 50% (2 of 4); on the table 50% | 100% (1 of 1); on the table 100% | 60% (3 of 5); on the table 60% |
| Winner chose to follow up or pursue (all three) |  | 67% (4 of 6); on the table 67% | 100% (7 of 7); on the table 100% | 85% (11 of 13); on the table 85% |
| Magic missiles tried each own turn | 50%+ | 22% (4 of 18) | 42% (10 of 24) | 33% (14 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 33% (4 of 12) | 56% (10 of 18) | 47% (14 of 30) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 56% (5 of 9) | 56% (5 of 9) |
| Points that never fought | lower | 30% (1781 of 6000) | 31% (1866 of 6000) | 30% (3647 of 12000) |
|   infantry points that never fought | lower | 39% (516 of 1315) | 35% (325 of 921) | 38% (841 of 2236) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 52% (13 of 25) | 81% (26 of 32) | 68% (39 of 57) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.3 uses a game | 50% (1 of 2); 1.3 uses a game | 75% (3 of 4); 1.8 uses a game |
| Bound items with another spell used |  | 30% (3 of 10); 1.7 uses a game | 0.0 uses a game | 30% (3 of 10); 0.8 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 46% (2625 of 5720) | 77% (4466 of 5830) | 61% (7091 of 11550) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.7 (36%) | 1.3 (29%) | 3.0 (32%) |
| MARCHED: its unit marched | 1.0 (21%) | 1.0 (21%) | 2.0 (21%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.3 (7%) | 0.3 (4%) |
| IN COMBAT: engaged in combat | 1.0 (21%) | 0.3 (7%) | 1.3 (14%) |
| GONE: slain | 0.0 (0%) | 1.7 (36%) | 1.7 (18%) |
| OFF THE TABLE: off the table or not arrived | 1.0 (21%) | 0.0 (0%) | 1.0 (11%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.0 | 0.7 | 2.7 | 4.7 | 0.3 | 4.0 |
| not cast | 3.0 | 3.3 | 3.3 | 9.3 | 1.7 | 20.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.0 (90%) | 0.0 (0%) | 3.0 (32%) | 0.3 (20%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (21%) | 0.3 (20%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (10%) | 0.3 (10%) | 1.3 (14%) | 0.7 (40%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (5%) |
| GONE: slain | 1.3 (44%) | 0.0 (0%) | 0.0 (0%) | 1.7 (18%) | 0.0 (0%) | 0.0 (0%) |
| OFF THE TABLE: off the table or not arrived | 0.7 (22%) | 0.0 (0%) | 0.7 (20%) | 1.0 (11%) | 0.3 (20%) | 2.0 (10%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.0 (33%) | 0.0 (0%) | 2.3 (70%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.3 (82%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.7 a game | 0.0 a game | 1.3 a game |
| stood (cast and not dispelled) | 62% (5 of 8) | - | 62% (5 of 8) |
| the unit moved after it | 20% (1 of 5) | - | 20% (1 of 5) |
| it charged on its next turn | 0% (0 of 5) | - | 0% (0 of 5) |
| the enemy charged it first | 40% (2 of 5) | - | 40% (2 of 5) |
| it fought by the end of its next turn | 20% (1 of 5) | - | 20% (1 of 5) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 5) | - | 0% (0 of 5) |
| none of these (no charge, no fight, no charge escaped) | 60% (3 of 5) | - | 60% (3 of 5) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 68% (66 of 97) | 70% (21 of 30) | 69% (87 of 127) |
|   cavalry | 25% (3 of 12) | 75% (12 of 16) | 54% (15 of 28) |
|   character | 45% (14 of 31) | 0% (0 of 4) | 40% (14 of 35) |
|   infantry | 83% (25 of 30) | 90% (9 of 10) | 85% (34 of 40) |
|   war machine | 100% (24 of 24) | - | 100% (24 of 24) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (23%) | 1.3 (44%) | 3.7 (28%) |
| CHARGED: it charged | 2.3 (23%) | 1.3 (44%) | 3.7 (28%) |
| FLEEING: it fled or was fleeing | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 3.7 (35%) | 0.3 (11%) | 4.0 (30%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (6%) | 0.0 (0%) | 0.7 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (6%) | 0.0 (0%) | 0.7 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.3 | 1.0 | 86% | 3.4 pts | 25 pts |
| character | 7.7 | 1.3 | 87% | 5.6 pts | 43 pts |
| infantry | 18.3 | 6.7 | 73% | 11.6 pts | 212 pts |
| war machine | 8.0 | 1.3 | 88% | 2.7 pts | 22 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.3 | 4.3 | 4.3 |
| Charges that made contact a game | 3.7 | 3.7 | 3.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.67 contact (3 units) | 0.00 declared, 0.00 contact (1 units) | 0.75 declared, 0.50 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.45 declared, 0.41 contact (22 units) | 0.57 declared, 0.48 contact (23 units) | 0.51 declared, 0.44 contact (45 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 60% (9 of 15) | 50% (1 of 2) | - | 59% (10 of 17) |
| Character in a unit | 0% (0 of 1) | 100% (2 of 2) | - | 67% (2 of 3) |
| Character on its own | 83% (5 of 6) | 50% (2 of 4) | 43% (3 of 7) | 59% (10 of 17) |
| Infantry | 83% (10 of 12) | 50% (1 of 2) | - | 79% (11 of 14) |
| Monster | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Monstrous | 100% (2 of 2) | 100% (2 of 2) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 3 | 67% (4 of 6); on the table 67% | 22% (4 of 18) | 30% | 52% (13 of 25) | 100% (2 of 2); 2.3 uses a game | 30% (3 of 10); 1.7 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (2 of 2); on the table 100% | 50% (6 of 12) | 33% | 75% (6 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (2 of 2); on the table 100% | 67% (4 of 6) | 30% | 83% (10 of 12) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (3 of 3); on the table 100% | 0% (0 of 6) | 30% | 83% (10 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p8, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 67% (4) | 57% (4) | 62% (8) |
| ...free all their last turn and able to turn (per game) | 1.00 | 0.67 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.67 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: gs3-83c8646-p8

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 4.0 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 70% (7 of 10) | 20% (2 of 10) |
| Strategy | Shoot objectives carried out (shot that target) | 67% (24 of 36) | 15% (2 of 13) |
| Strategy | Support requests answered (helper made contact too) | 50% (1 of 2) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 100% (2 of 2) |
| Strategy | Joined characters whose unit fought | - | 100% (3 of 3) |
| Strategy | Lone characters that fought | 100% (8 of 8) | 78% (7 of 9) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.7 | 2.7 |
| Movement | Points that never moved of their own | 226.7 | 93.3 |
| Movement | Fights charged into per game | 3.0 | 3.3 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 5, net +0 | 2 of 5, net -118 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 5, net +0 | 2 of 5, net +76 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 5, net +0 | 0 of 5 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 5, net +0 | 1 of 5, net +551 |
| Shooting | Shots by shooting units (incl. breath weapons) | 14.7 | 7.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (20 of 44) | 70% (16 of 23) |
| Shooting | Points destroyed by shooting units | 103.7 | 0.0 |
| Shooting | War machine shots | 8.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (11 of 24) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.7 | 1.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 50% (1 of 2) | 40% (2 of 5) |
| Magic | Wounds caused by magic missiles | 4.3 | 0.3 |
| Magic | Wounds caused by other spells | 4.7 | 0.7 |
| Magic | Points destroyed by magic (all spells) | 176.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.3 / 0.0 / 1.7 / 0.0 | 1.7 / 0.7 / 1.0 / 0.0 |
| Combat | Points destroyed in combat | 329.0 | 197.7 |
| Combat | Points run down | 0.0 | 59.0 |
| Combat | Net points per charged fight, damage counted | +45 | +46 |
| Combat | Net per 100 charger points, damage counted | +10.7 | +14.5 |
| Combat | First round won (charged fights) | 78% | 70% |
| Combat | Net points per charged fight | +70 | +38 |
| Combat | Net points per supported fight / lone fight | +85 / +66 | +0 / +42 |
| Combat | Charged fights on a top-3 enemy unit | 4 of 9 | 6 of 10 |
| Game | Points lost | 407.0 | 978.7 |
| Game | VP from objectives | 683.3 | 570.0 |
| Game | Lone holders (player turns) | 3.0 | 1.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +557 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 1386
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p8

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 29.7 | +379.1 | 0.0 | 485.3 | 26.7 | +247.6 | 0.0 | 467.7 |
| ASSAILMENT BY POINTS | 1.0 | +5.8 | 0.0 | 133.3 | 0.7 | +3.4 | 0.0 | 0.0 |
| BOUND ASSAILMENT | 0.3 | +0.0 | 0.0 | 50.3 | - | - | - | - |
| CANNON PLANNED TARGET | 8.0 | +111.4 | 482.3 | 0.0 | - | - | - | - |
| CAST JOB | 1.0 | +8.9 | 0.0 | 0.0 | 2.3 | +44.1 | 0.0 | 130.0 |
| CASTING BLOCK | - | - | - | - | 0.7 | +3.5 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.7 | +0.0 | 0.0 | 266.7 | - | - | - | - |
| CHALLENGE BY POINTS | 1.0 | +76.3 | 0.0 | 109.3 | 0.3 | +5.0 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | 0.3 | -8.0 | 65.0 | 0.0 | 0.3 | +10.9 | 0.0 | 0.0 |
| CHARGE LOSSES | 15.3 | -682.4 | 0.0 | 662.0 | 18.3 | -1211.5 | 0.0 | 483.7 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 290.3 | 0.0 | 2.0 | +0.0 | 317.0 | 246.7 |
| CLOSES ON WHAT IT BEATS | 7.7 | +0.0 | 0.0 | 428.0 | 6.0 | +0.0 | 0.0 | 41.7 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 1.7 | +169.1 | 266.7 | 266.7 | - | - | - | - |
| COVER ONCE | 7.7 | -468.7 | 0.0 | 183.7 | 5.3 | -370.3 | 0.0 | 186.0 |
| DEFENSIVE FLOOR | 0.3 | +5.7 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 7.3 | -21.6 | 0.0 | 0.0 | 7.7 | +43.4 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -48.9 | 0.0 | 147.3 | - | - | - | - |
| EDGE GIVE GROUND | 0.7 | +97.6 | 115.0 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | - | - | - | - | 3.7 | +81.6 | 118.0 | 83.3 |
| EXACT ROUND | 1.7 | +5.3 | 205.3 | 0.0 | 2.7 | +30.1 | 183.7 | 233.3 |
| FALL BACK GOOD ORDER | 2.3 | +0.0 | 205.3 | 147.3 | 2.0 | +0.6 | 133.3 | 233.3 |
| FALLS SHORT | - | - | - | - | 20.7 | +254.0 | 0.0 | 454.0 |
| FEATURE BUFFS | 0.7 | +9.7 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +23.6 | 0.0 | 147.3 | 1.0 | +16.0 | 0.0 | 116.7 |
| FIRE IN ORDER | 0.3 | +0.0 | 116.7 | 0.0 | - | - | - | - |
| FIVE ACTION | 102.3 | +5745.5 | 1733.7 | 1412.7 | 73.3 | +4718.6 | 752.0 | 1819.7 |
| FLANK NOT WEIGHED | 6.0 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 400.3 |
| FOLLOW UP WEIGHED | 1.0 | +255.1 | 0.0 | 0.0 | 0.7 | +129.2 | 0.0 | 56.7 |
| FOOT FIRST | - | - | - | - | 21.7 | +0.0 | 0.0 | 176.3 |
| FOUR ROUNDS | 4.0 | +437.7 | 377.0 | 147.3 | 3.3 | +297.3 | 317.0 | 233.3 |
| FREED FROM HIS FIGHT | 1.3 | +0.0 | 0.0 | 133.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 1.7 | -8.7 | 0.0 | 0.0 | 0.7 | -0.6 | 0.0 | 41.7 |
| FRIENDS SHOTS CHECKED | 0.3 | +17.6 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.3 | -17.9 | 0.0 | 147.3 | - | - | - | - |
| GOAL ON TIME | - | - | - | - | 0.7 | +39.7 | 0.0 | 0.0 |
| GOAL ROUTE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| GOAL WALK | 6.3 | +277.1 | 0.0 | 100.7 | 8.3 | +432.9 | 0.0 | 41.7 |
| GUN MASK | 0.7 | -6.5 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 4.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 106.7 |
| HE REFORMS ONCE FREED | 1.3 | +0.0 | 0.0 | 133.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 8.7 | +0.0 | 0.0 | 367.3 | 12.0 | +0.0 | 0.0 | 349.7 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +7.2 | 0.0 | 0.0 |
| HIS CHARGE LIST | 1.3 | +0.0 | 0.0 | 118.0 | 4.0 | +0.0 | 0.0 | 36.7 |
| HIS LEGAL MOVES | 4.7 | +0.0 | 0.0 | 428.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 1.3 | -31.1 | 0.0 | 0.0 | 2.0 | -12.9 | 0.0 | 56.7 |
| HIS ONE QUARTER | 4.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 230.0 |
| HIS OWN BEST MOVE | 6.7 | +0.0 | 0.0 | 428.0 | 6.3 | +0.0 | 0.0 | 77.3 |
| HIS RANDOM MOVE | 9.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 40.7 | +1221.5 | 0.0 | 752.0 | 40.7 | +1029.6 | 0.0 | 824.3 |
| HIS SHOTS BY HIS RUN | 41.0 | +947.9 | 0.0 | 1014.0 | 50.7 | +1214.7 | 0.0 | 1188.3 |
| HIS TURN DENIED | 1.3 | +27.5 | 166.7 | 147.3 | 0.3 | +35.0 | 0.0 | 0.0 |
| HOLD ODDS | 14.0 | +0.0 | 0.0 | 100.7 | 8.7 | +0.0 | 0.0 | 120.0 |
| HOLDER ASSIGNMENT | 8.3 | +656.2 | 0.0 | 50.3 | 7.3 | +532.9 | 0.0 | 80.0 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.0 | -128.8 | 273.3 | 147.3 | 2.7 | -80.1 | 266.7 | 233.3 |
| IDLE COST | - | - | - | - | 11.0 | -149.5 | 0.0 | 294.7 |
| JOINT CHARGE NOW | 1.3 | +21.8 | 130.0 | 0.0 | 0.7 | +275.4 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 2.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 80.0 |
| LANE BY FIGURES | 1.3 | +97.5 | 0.0 | 0.0 | 0.3 | +7.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.7 | +0.0 | 250.7 | 50.3 | 2.3 | +0.0 | 0.0 | 182.7 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.3 | +0.0 | 67.0 | 0.0 |
| LONG SHOT | 0.3 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 2.3 | +14.7 | 103.7 | 147.3 | 1.3 | -9.1 | 50.3 | 0.0 |
| MANOEUVRE | 1.7 | +1.9 | 0.0 | 0.0 | 1.3 | +7.2 | 0.0 | 67.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +3.2 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.7 | +30.8 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 1.0 | +29.9 | 0.0 | 65.0 |
| MARCH OF THE TABLE | 0.3 | +77.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | +15.3 | 0.0 | 133.3 | 1.0 | +20.7 | 0.0 | 65.0 |
| MARCH WHEELS ONLY | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 40.0 |
| MAX FOR POSITIONING | 1.0 | +2.7 | 0.0 | 0.0 | 2.7 | +130.4 | 0.0 | 83.3 |
| MEETS IN TIME | 3.3 | +197.2 | 0.0 | 0.0 | 4.3 | +88.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 4.7 | +76.7 | 0.0 | 0.0 | 5.7 | +135.4 | 0.0 | 142.3 |
| MISSILES NEXT TURN | 7.0 | +55.7 | 0.0 | 266.7 | 6.3 | +102.6 | 0.0 | 168.7 |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 48.0 | 65.0 |
| MOVE SPELL SPOT | 1.7 | +0.0 | 0.0 | 266.7 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 6.0 | +587.6 | 0.0 | 100.7 | 4.7 | +490.7 | 0.0 | 77.3 |
| MOVES UNITS SPELL | - | - | - | - | 0.3 | +1.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.7 | +285.1 | 0.0 | 100.7 | 6.0 | +254.1 | 0.0 | 134.0 |
| NEAREST TO GOAL | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 3.3 | +198.0 | 0.0 | 50.3 | 2.3 | +202.2 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.7 | -95.7 | 329.0 | 0.0 | 2.3 | -174.2 | 317.0 | 233.3 |
| NO LATE CUT | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 65.0 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 8.7 | -190.0 | 123.7 | 168.3 | 3.3 | -122.5 | 0.0 | 119.0 |
| ONE CHALLENGE TEST | 0.3 | +0.7 | 38.7 | 0.0 | 0.3 | +10.9 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 125.3 |
| ONE FIGHT FORMULA | 5.7 | -123.2 | 0.0 | 280.7 | 3.7 | -77.3 | 0.0 | 103.7 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +6.4 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 4.0 | -34.4 | 0.0 | 50.3 | 1.0 | +93.3 | 0.0 | 0.0 |
| ONE ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 40.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +14.2 | 0.0 | 0.0 |
| OVERRUNS AWAY | 1.0 | +30.4 | 36.7 | 0.0 | 1.0 | +8.2 | 133.3 | 233.3 |
| PLAN RESULT | 45.3 | +767.1 | 571.3 | 880.7 | 38.0 | +364.9 | 841.3 | 1300.3 |
| PROMISE BY ITS OWN SUM | 9.3 | -351.7 | 0.0 | 50.3 | 5.7 | -101.7 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | - | - | - | - | 0.3 | -111.1 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.3 | -1.1 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 28.7 | +2639.8 | 889.3 | 236.0 | 16.7 | +2147.0 | 218.7 | 625.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.0 | +5.9 | 0.0 | 226.7 |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 40.0 |
| REDIRECT COUNTER | - | - | - | - | 1.0 | +85.0 | 0.0 | 18.3 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.3 | +0.0 | 0.0 | 18.3 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +4.0 | 59.0 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -15.7 | 0.0 | 0.0 | 0.3 | -14.3 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 50.3 | 0.3 | +0.0 | 0.0 | 38.7 |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +23.9 | 0.0 | 38.0 |
| RISK BY ARC | 3.0 | -45.3 | 233.7 | 147.3 | 2.0 | -21.1 | 317.0 | 233.3 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | 1.0 | -33.4 | 115.0 | 147.3 | 0.7 | -11.1 | 133.3 | 116.7 |
| RUN DOWN | 3.3 | -114.1 | 320.3 | 0.0 | 2.7 | -7.5 | 317.0 | 233.3 |
| SEARCH SPOT | 1.7 | +24.5 | 0.0 | 192.3 | 0.3 | +41.4 | 0.0 | 0.0 |
| SECOND LOOK | 0.7 | +35.5 | 123.7 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | - | - | - | - | 2.0 | -4.2 | 0.0 | 0.0 |
| SET CREDITED ONCE | 1.7 | -50.5 | 0.0 | 0.0 | 0.3 | -8.3 | 0.0 | 41.7 |
| SET UP BY THE SET | 3.3 | +3.5 | 0.0 | 147.3 | 0.7 | +8.3 | 0.0 | 41.7 |
| SET-UP ANY TARGET | 0.3 | +21.2 | 133.3 | 133.3 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 11.3 | +0.0 | 0.0 | 59.0 | 5.0 | +0.0 | 0.0 | 140.3 |
| SHOOTS FROM THE BEST SPOT | 3.0 | +64.1 | 197.0 | 118.0 | 1.7 | +16.0 | 168.3 | 38.7 |
| SHOT OR CHARGE | 0.3 | -0.1 | 0.0 | 0.0 | 0.7 | -17.0 | 133.3 | 0.0 |
| SHOT RISK POINTS | 25.3 | -305.6 | 0.0 | 795.3 | 26.7 | -100.9 | 0.0 | 652.3 |
| SHOTS AFTER THE MOVES | 4.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 21.3 | +562.5 | 0.0 | 251.3 | 6.3 | +161.4 | 0.0 | 36.7 |
| SPELL SETS UP CHARGE | 0.3 | +21.2 | 133.3 | 133.3 | - | - | - | - |
| SPELL WORTH | 3.0 | +91.7 | 266.7 | 266.7 | 2.0 | +21.5 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 1.0 | +12.6 | 168.7 | 0.0 | 0.3 | -6.5 | 50.3 | 0.0 |
| SPOT AS THE GAME MOVES | 3.3 | +0.0 | 0.0 | 183.7 | 8.3 | +0.0 | 0.0 | 347.0 |
| STAND AND SHOOT | - | - | - | - | 1.3 | -4.4 | 266.7 | 116.7 |
| STANDS FOR A REASON | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 53.3 | +0.0 | 1356.7 | 236.0 | 24.0 | +0.0 | 435.0 | 532.0 |
| STAY WORTH | 32.0 | +40.7 | 1094.7 | 192.3 | 10.0 | +67.5 | 266.7 | 0.0 |
| STRIKE BY THE ODDS | 0.7 | +11.6 | 52.0 | 147.3 | 1.0 | +23.6 | 0.0 | 56.7 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 4.0 | +236.0 | 0.0 | 0.0 | 6.3 | +1043.0 | 0.0 | 36.7 |
| SUPPORT NARROWED | - | - | - | - | 1.0 | +0.0 | 50.3 | 116.7 |
| SUPPORT WORKED OUT | 4.0 | +236.0 | 0.0 | 0.0 | 6.3 | +1043.0 | 0.0 | 36.7 |
| SURE REACH TOGETHER | 0.3 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| SWIFTSTRIDE BY POINTS | 0.7 | +7.7 | 0.0 | 183.7 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -111.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 86.7 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 67.0 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 134.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 49.0 | +0.0 | 0.0 | 632.7 | 33.3 | +0.0 | 0.0 | 731.0 |
| TIED UP BY THE SUM | 1.0 | +139.5 | 158.3 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 50.3 | +549.6 | 67.0 | 648.0 | - | - | - | - |
| WAITS AGAIN | 2.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 0.3 | +10.6 | 0.0 | 0.0 | 0.7 | -3.4 | 0.0 | 0.0 |
| WHO FIGHTS | 0.7 | +0.9 | 103.7 | 0.0 | 0.3 | -5.2 | 50.3 | 0.0 |
| WHO HITS BACK | 0.3 | +49.7 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | 0.3 | -4.1 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 1.7 | -144.1 | 0.0 | 266.7 | 2.7 | -822.8 | 0.0 | 134.0 |
| WHOLE FIGHT GAIN | 0.3 | +25.4 | 65.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | - | - | - | - | 4.7 | +130.7 | 0.0 | 268.0 |

### Rule changes: gs3-83c8646-p8

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 169 | 169 | 122 | 40.67 | +2309 | +18.9 |
| HIS SHOTS BY HIS RUN | 275 | 260 | 74 | 24.67 | +925 | +12.5 |
| HIS SHOT LIST | 244 | 231 | 59 | 19.67 | +1085 | +18.4 |
| HOLDER ASSIGNMENT | 47 | 47 | 40 | 13.33 | +2103 | +52.6 |
| OFF BEST | 36 | 36 | 36 | 12.00 | -938 | -26.1 |
| THE TABLE AGAIN | 36 | 36 | 29 | 9.67 | +0 | +0.0 |
| FIVE ACTION | 527 | 506 | 27 | 9.00 | +1714 | +63.5 |
| DEPLOY BY FIGURES | 45 | 45 | 26 | 8.67 | +294 | +11.3 |
| HARD STAY DROPPED | 26 | 26 | 26 | 8.67 | +0 | +0.0 |
| QUARTER ODDS | 136 | 131 | 26 | 8.67 | +1956 | +75.2 |
| SHOT RISK POINTS | 156 | 151 | 24 | 8.00 | +553 | +23.1 |
| MOVE TO CHARGE COMPUTED | 32 | 27 | 21 | 7.00 | +882 | +42.0 |
| TIME ON OUR SIDE | 151 | 133 | 18 | 6.00 | +73 | +4.1 |
| LEGAL CHARGES ONLY | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| GOAL WALK | 44 | 44 | 14 | 4.67 | +502 | +35.9 |
| PROMISE BY ITS OWN SUM | 45 | 45 | 13 | 4.33 | -1360 | -104.6 |
| ADVANCE LANE KEPT | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| CHARGE LOSSES | 101 | 96 | 11 | 3.67 | +1215 | +110.4 |
| COVER ONCE | 39 | 24 | 11 | 3.67 | +228 | +20.8 |
| FOUR ROUNDS | 22 | 20 | 10 | 3.33 | +754 | +75.4 |
| NEXT CHARGE BY LIST | 17 | 15 | 9 | 3.00 | +562 | +62.4 |
| SHOOTS FROM THE BEST SPOT | 14 | 14 | 9 | 3.00 | +86 | +9.5 |
| MEETS IN TIME | 23 | 23 | 8 | 2.67 | +188 | +23.5 |
| CAST JOB | 10 | 10 | 7 | 2.33 | +49 | +7.0 |
| JOINT CHARGE NOW | 6 | 6 | 6 | 2.00 | +891 | +148.6 |
| STAY WORTH | 126 | 110 | 6 | 2.00 | +25 | +4.1 |
| SUPPORT ADDS | 31 | 29 | 6 | 2.00 | +442 | +73.7 |
| SUPPORT WORKED OUT | 31 | 29 | 6 | 2.00 | +442 | +73.7 |
| ASSAILMENT BY POINTS | 5 | 5 | 5 | 1.67 | +28 | +5.6 |
| EVASIVE BY THE ODDS | 11 | 11 | 5 | 1.67 | +183 | +36.6 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +1153 | +230.6 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +314 | +62.7 |
| MOVE ORDER | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 9 | 9 | 5 | 1.67 | +18 | +3.5 |
| SHOTS IN THE MOVE | 83 | 60 | 5 | 1.67 | +119 | +23.8 |
| STRIKE BY THE ODDS | 5 | 5 | 5 | 1.67 | +106 | +21.1 |
| CANNON PLANNED TARGET | 24 | 24 | 4 | 1.33 | +18 | +4.4 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +244 | +61.0 |
| FALLS SHORT | 62 | 54 | 4 | 1.33 | +52 | +13.1 |
| IDLE COST | 33 | 22 | 4 | 1.33 | +23 | +5.8 |
| MAX FOR POSITIONING | 11 | 11 | 4 | 1.33 | +7 | +1.7 |
| MISSILES IN THE MOVE | 31 | 22 | 4 | 1.33 | +50 | +12.6 |
| REDIRECT FOR A FRIEND IN REACH | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SEARCH SPOT | 6 | 6 | 4 | 1.33 | +208 | +51.9 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MANOEUVRE | 9 | 9 | 3 | 1.00 | +27 | +9.1 |
| NEARER NOT NEEDED | 38 | 36 | 3 | 1.00 | +82 | +27.3 |
| SET UP BY THE SET | 12 | 12 | 3 | 1.00 | +333 | +111.0 |
| WHOLE FIGHT DANGER | 13 | 12 | 3 | 1.00 | +285 | +95.1 |
| EXACT ROUND | 13 | 13 | 2 | 0.67 | +5 | +2.3 |
| GOAL ON TIME | 2 | 2 | 2 | 0.67 | -62 | -30.8 |
| GOAL ROUTE | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HONEST WORTH | 17 | 15 | 2 | 0.67 | +13 | +6.3 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +92 | +46.2 |
| NO DOUBLE ROUNDS | 15 | 13 | 2 | 0.67 | +20 | +10.0 |
| REDIRECT COUNTER | 3 | 3 | 2 | 0.67 | +18 | +9.0 |
| REFUSING RETIRES | 2 | 2 | 2 | 0.67 | -38 | -19.1 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +106 | +53.2 |
| SWIFTSTRIDE BY POINTS | 2 | 2 | 2 | 0.67 | +23 | +11.5 |
| THE ROW IN ITS ORDER | 17 | 2 | 2 | 0.67 | +0 | +0.0 |
| TIED UP BY THE SUM | 3 | 2 | 2 | 0.67 | +123 | +61.5 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.33 | +0 | +0.1 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 2 | 1 | 1 | 0.33 | +0 | +0.1 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +53 | +52.7 |
| HIS TURN DENIED | 5 | 5 | 1 | 0.33 | +78 | +78.4 |
| MARCH CHECK | 3 | 3 | 1 | 0.33 | +50 | +50.5 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -233 | -233.3 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +4 | +3.5 |
| OVERRUNS AWAY | 6 | 6 | 1 | 0.33 | +38 | +37.5 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -3 | -3.4 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +19 | +18.9 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +72 | +71.8 |
| RISK BY ARC | 15 | 14 | 1 | 0.33 | +1 | +1.1 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SHOTS AFTER THE MOVES | 18 | 18 | 1 | 0.33 | +0 | +0.0 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +122 | +122.0 |
| WHOLE FIGHT GAIN | 1 | 1 | 1 | 0.33 | +52 | +52.5 |
| WOUNDS ON THE RANKS | 14 | 14 | 1 | 0.33 | +24 | +23.7 |
| CASTING BLOCK | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 5 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 12 | 12 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 41 | 40 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 5 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 13 | 13 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 3 | 3 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 5 | 5 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 39 | not checked | - | - | - | - |
| FOOT FIRST | 65 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 8 | 8 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 7 | 7 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN MASK | 2 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 7 | 7 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 62 | 58 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 16 | 12 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 23 | 20 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 10 | 10 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 28 | 27 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 39 | 35 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 28 | 26 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 68 | 67 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 16 | 15 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 11 | 11 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 40 | 29 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 5 | not checked | - | - | - | - |
| NEAREST TO GOAL | 3 | 3 | 0 | 0.00 | - | - |
| NO LATE CUT | 7 | 6 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 2 | 2 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 5 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 28 | 19 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 15 | 8 | 0 | 0.00 | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 250 | trace | - | - | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 3 | 3 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 5 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 18 | 17 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 6 | 6 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 49 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 15 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 35 | 34 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 7 | 7 | 0 | 0.00 | - | - |
| STANDS STILL | 232 | 223 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 3 | 3 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 15 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 11 | not checked | - | - | - | - |
| THE TABLE BINDS | 247 | not checked | - | - | - | - |
| WAITS AGAIN | 12 | 12 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 3 | 3 | 0 | 0.00 | - | - |
| WHO FIGHTS | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p8

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 6.67 | 2.33 | 26.2 |
| ARMY TABLE | rule | 1.67 | 3.67 | 73.9 |
| PROMISE BY ITS OWN SUM | rule | 3.33 | 1.00 | 104.6 |
| RULE SWITCHED OFF | gate | 1.33 | - | 15.8 |
| HOLDER ASSIGNMENT | rule | - | 1.00 | 90.3 |
| CANNON PLANNED TARGET | rule | 0.67 | - | 3.5 |
| GOAL ON TIME | rule | - | 0.67 | 30.8 |
| REFUSING RETIRES | rule | 0.33 | 0.33 | 19.1 |
| AFTERMATH BAND | gate | 0.33 | - | 1.0 |
| DEPLOY BY FIGURES | rule | - | 0.33 | 6.7 |
| FALLBACK | gate | - | 0.33 | 33.2 |
| FIGHT ORDER BAND | gate | 0.33 | - | 0.6 |
| JOINT CHARGE NOW | rule | 0.33 | - | 80.4 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.33 | 1.3 |
| MARCH OF THE TABLE | rule | 0.33 | - | 233.3 |
| NO REASON | gate | - | 0.33 | 132.1 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 3.4 |
| SET UP BY THE SET | rule | 0.33 | - | 11.6 |

### Plans: gs3-83c8646-p8

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 43% | 412 | 247 | 60% |
| Mine | move | 33.3 | 98% | 1515 | 0 | 0% |
| Mine | shoot | 9.7 | 41% | 460 | 520 | 113% |
| Opponent | charge | 2.3 | 43% | 263 | 299 | 114% |
| Opponent | join | 1.7 | 100% | 63 | 0 | 0% |
| Opponent | move | 30.0 | 90% | 2165 | 0 | 0% |
| Opponent | shoot | 4.0 | 33% | 212 | 66 | 31% |

### Battle groups: gs3-83c8646-p8

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 1.0 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p8

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 8 | 83 (8) | 83 | 0 | 28 | 0% | 2.6 | 91 (6) | 56 (2) | - | 99 (2) | 78 (6) |
| Mine | Clean-up | 3 | 85 (3) | 0 | 85 | 0 | 67% | 1.0 | 134 (2) | 0 (1) | - | 134 (2) | 0 (1) |
| Mine | Fast Hammer | 7 | 24 (7) | 13 | 11 | 29 | 57% | 4.3 | 0 (3) | 58 (3) | 0 (1) | 0 (2) | 34 (5) |
| Mine | Holder | 2 | 65 (2) | 0 | 65 | 0 | 0% | 4.5 | 65 (2) | - | - | 65 (2) | - |
| Mine | Shooter | 5 | 51 (5) | 51 | 0 | 21 | 0% | 1.4 | 63 (4) | 0 (1) | - | 63 (4) | 0 (1) |
| Mine | War machine | 4 | 0 (4) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | 0 (2) | - | 0 (2) | 0 (2) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 32 | 100% | - | 0 (3) | - | - | 0 (3) | - |
| Opponent | Character | 9 | 55 (9) | 55 | 0 | 63 | 11% | 2.6 | 65 (3) | 99 (4) | - | 52 (3) | 87 (4) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 0 | 33% | 2.5 | - | 0 (3) | - | 0 (1) | 0 (2) |
| Opponent | Fast Hammer | 3 | 68 (3) | 21 | 47 | 29 | 0% | 2.3 | 209 (1) | 27 (2) | - | 43 (1) | 92 (2) |
| Opponent | Hammer | 8 | 0 (8) | 0 | 0 | 53 | 38% | 4.0 | 0 (4) | 0 (2) | 0 (2) | 0 (5) | 0 (3) |
| Opponent | Holder | 3 | 7 (3) | 0 | 7 | 65 | 67% | 5.0 | 7 (3) | - | - | 0 (1) | 11 (2) |
| Opponent | Shooter | 3 | 0 (3) | 0 | 0 | 62 | 0% | 1.0 | - | 0 (2) | 0 (1) | - | 0 (3) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 61 | 33% | 1.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |

### Charged fights: gs3-83c8646-p8

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 3 | 280 | 358 | 3.0 | 1.2 | 119 | 49 | +70 | 4 of 9 | 7 of 9 | +85 | +66 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 0 | 3.0 | 1.0 | 0 | 0 | +0 | 2 of 3 | 2 of 3 | - | +0 |
| Opponent | Warriors of Chaos | 1 | 0 | 151 | 2.0 | 1.0 | 76 | 132 | -56 | 1 of 2 | 1 of 2 | - | -56 |
| Opponent | Wood Elf Realms | 1 | 0 | 728 | 5.0 | 1.2 | 146 | 47 | +99 | 3 of 5 | 4 of 5 | +0 | +123 |
| **Opponent** | all armies | 3 | 0 | 293 | 3.3 | 1.1 | 88 | 50 | +38 | 6 of 10 | 7 of 10 | +0 | +42 |

### Effective charges: gs3-83c8646-p8

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 9 | 1 (net +0) | 1 (net +116) | 1 (net +0) | 0 | 1 (net +0) | 1 (net +0) | 4 | 20% (1 of 5) |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 2 | 100% (1 of 1) |
| Opponent | Warriors of Chaos | 2 | 0 | 0 | 1 (net +151) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Opponent | Wood Elf Realms | 5 | 2 (net -118) | 0 | 0 | 0 | 0 | 1 (net +551) | 2 | 0% (0 of 3) |

### Charged fights, damage counted: gs3-83c8646-p8

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 400 | 343 | +0 | 79 | 324 | -244 | -61.1 |
| Mine | 50-54% | 1 | 151 | 116 | +116 | 116 | 0 | +116 | +76.8 |
| Mine | Effective (55-75%) | 1 | 230 | 350 | +0 | 0 | 61 | -61 | -26.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 247 | 110 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 477 | 102 | +0 | 51 | 101 | -50 | -10.4 |
| Mine | No odds | 4 | 577 | 221 | +129 | 272 | 110 | +162 | +28.0 |
| Mine | All fights | 9 | 424 | 212 | +70 | 148 | 103 | +45 | +10.7 |
| Opponent | Long shot (under 50%) | 2 | 192 | 294 | -118 | 86 | 218 | -132 | -68.7 |
| Opponent | Effective (55-75%) | 2 | 233 | 199 | +76 | 76 | 8 | +68 | +29.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 499 | 400 | +551 | 551 | 0 | +551 | +110.4 |
| Opponent | No odds | 5 | 364 | 278 | -17 | 60 | 53 | +8 | +2.1 |
| Opponent | All fights | 10 | 317 | 278 | +38 | 118 | 72 | +46 | +14.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p8 | move | 19 | 8 (42%) | 7 (37%) | 4 (21%) | 7 (37%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Elixir of Power | Opponent | L1319 |
| Opal Amulet | Mine | L1431 |
| Ring of Doom | Opponent | L1431 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |

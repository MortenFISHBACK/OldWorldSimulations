# Doctrine scorecard: gs3-83c8646-p55

### Scorecard: gs3-83c8646-p55

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1114 | 4 | 1 | Mine | no | 4 | 2 | 1 | 0 | 0 | 0 | 0 | 165 |
| L1114 | 4 | 1 | Opponent | no | 1 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1131 | 3 | 1 | Mine | no | 0 | - | 2 | 0 | 1 | 0 | 0 | 526 |
| L1131 | 3 | 1 | Opponent | no | 0 | - | 0 | 1 | 2 | 0 | 0 | 0 |
| L1224 | 6 | 1 | Mine | no | 16 | 3 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 6.7 | 2.5 | 1.7 | 0.0 | 0.3 | 0.0 | 0.0 | 340.3 |
| **Average** | | | Opponent | 0% | 0.3 | 2.5 | 1.7 | 1.0 | 0.7 | 0.0 | 0.0 | 0.0 |

### KPIs: gs3-83c8646-p55

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 44% (7 of 16) | 0% (0 of 16) | 22% (7 of 32) |
| Winner chose to follow up after the loser gave ground |  | 80% (4 of 5); on the table 80% | 100% (4 of 4); on the table 100% | 89% (8 of 9); on the table 89% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | 0% (0 of 3); on the table 33% | 0% (0 of 4); on the table 25% |
| Winner chose to follow up or pursue (all three) |  | 67% (4 of 6); on the table 67% | 57% (4 of 7); on the table 71% | 62% (8 of 13); on the table 69% |
| Magic missiles tried each own turn | 50%+ | 39% (26 of 66) | 22% (4 of 18) | 36% (30 of 84) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 54% (26 of 48) | 36% (4 of 11) | 51% (30 of 59) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 58% (7 of 12) | 58% (7 of 12) |
| Points that never fought | lower | 42% (2494 of 5998) | 39% (2351 of 5998) | 40% (4845 of 11996) |
|   infantry points that never fought | lower | 100% (730 of 730) | 61% (558 of 913) | 78% (1288 of 1643) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 52% (13 of 25) | 68% (19 of 28) | 60% (32 of 53) |
| Bound items with a magic missile used (at least once a game) |  | 100% (7 of 7); 7.3 uses a game | 100% (1 of 1); 1.3 uses a game | 100% (8 of 8); 4.3 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 50% (3 of 6); 1.0 uses a game | 50% (3 of 6); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 33% (1 of 3); 0.3 uses a game | 0.0 uses a game | 33% (1 of 3); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 48% (2688 of 5614) | 64% (3731 of 5828) | 56% (6419 of 11442) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.7 (28%) | 1.3 (29%) | 5.0 (28%) |
| MARCHED: its unit marched | 3.7 (28%) | 1.0 (21%) | 4.7 (26%) |
| IN COMBAT: engaged in combat | 5.3 (40%) | 1.3 (29%) | 6.7 (37%) |
| GONE: slain | 0.7 (5%) | 1.0 (21%) | 1.7 (9%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.0 | 5.0 | 2.3 | 10.0 | 2.3 | 5.3 |
| not cast | 1.0 | 7.0 | 1.7 | 18.0 | 5.7 | 30.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 5.3 (76%) | 0.0 (0%) | 5.0 (28%) | 0.7 (12%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.7 (26%) | 1.0 (18%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 1.0 (14%) | 1.3 (80%) | 6.7 (37%) | 1.3 (24%) | 0.0 (0%) |
| GONE: slain | 0.7 (67%) | 0.0 (0%) | 0.0 (0%) | 1.7 (9%) | 0.0 (0%) | 1.0 (3%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.7 (10%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.7 (47%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.3 (33%) | 0.0 (0%) | 0.3 (20%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 28.3 (92%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 2.3 a game | 1.2 a game |
| stood (cast and not dispelled) | - | 71% (5 of 7) | 71% (5 of 7) |
| the unit moved after it | - | 0% (0 of 5) | 0% (0 of 5) |
| it charged on its next turn | - | 0% (0 of 5) | 0% (0 of 5) |
| the enemy charged it first | - | 0% (0 of 5) | 0% (0 of 5) |
| it fought by the end of its next turn | - | 0% (0 of 5) | 0% (0 of 5) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 5) | 0% (0 of 5) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (5 of 5) | 100% (5 of 5) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 68% (45 of 66) | 41% (9 of 22) | 61% (54 of 88) |
|   cavalry | 0% (0 of 12) | 83% (5 of 6) | 28% (5 of 18) |
|   character | - | 0% (0 of 10) | 0% (0 of 10) |
|   chariot | 67% (8 of 12) | - | 67% (8 of 12) |
|   infantry | 92% (11 of 12) | 67% (4 of 6) | 83% (15 of 18) |
|   war machine | 87% (26 of 30) | - | 87% (26 of 30) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (33%) | 0.7 (15%) | 3.0 (26%) |
| CHARGED: it charged | 0.0 (0%) | 1.0 (23%) | 1.0 (9%) |
| FLEEING: it fled or was fleeing | 0.3 (5%) | 0.0 (0%) | 0.3 (3%) |
| IN COMBAT: it fought this turn or the last | 0.3 (5%) | 0.0 (0%) | 0.3 (3%) |
| MOVED: a war machine that moved | 0.3 (5%) | 0.0 (0%) | 0.3 (3%) |
| FREE: none of these - no target in range or sight, or held its fire | 3.3 (48%) | 0.0 (0%) | 3.3 (29%) |
| NO TARGET IN RANGE | 0.0 (0%) | 2.7 (62%) | 2.7 (24%) |
| SHELTERED: the target was sheltered | 0.3 (5%) | 0.0 (0%) | 0.3 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 2.7 | 0.7 | 75% | 8.6 pts | 23 pts |
| infantry | 10.0 | 1.7 | 83% | 7.8 pts | 78 pts |
| war machine | 9.3 | 11.0 | 50% | 32.2 pts | 301 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.0 | 2.3 | 2.2 |
| Charges that made contact a game | 2.0 | 2.3 | 2.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.86 declared, 0.86 contact (7 units) | 0.67 declared, 0.67 contact (3 units) | 0.80 declared, 0.80 contact (10 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.00 declared, 0.00 contact (10 units) | 0.25 declared, 0.25 contact (20 units) | 0.17 declared, 0.17 contact (30 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 55% (6 of 11) | 50% (1 of 2) | 50% (1 of 2) | 53% (8 of 15) |
| Character in a unit | 100% (1 of 1) | 100% (1 of 1) | - | 100% (2 of 2) |
| Character on its own | 100% (6 of 6) | 60% (3 of 5) | 29% (2 of 7) | 61% (11 of 18) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 67% (4 of 6) | 100% (2 of 2) | - | 75% (6 of 8) |
| Monster | 0% (0 of 2) | - | - | 0% (0 of 2) |
| War Machines | 67% (4 of 6) | - | - | 67% (4 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 3 | 67% (4 of 6); on the table 67% | 39% (26 of 66) | 42% | 52% (13 of 25) | 100% (7 of 7); 7.3 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| High Elf Realms | 1 | 100% (1 of 1); on the table 100% | 33% (2 of 6) | 23% | 56% (5 of 9) | 0.0 uses a game | 50% (3 of 6); 3.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (3 of 3); on the table 100% | 17% (1 of 6) | 25% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 0% (0 of 3); on the table 33% | 17% (1 of 6) | 70% | 75% (9 of 12) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p55, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 43% (3) | 60% (3) | 50% (6) |
| ...free all their last turn and able to turn (per game) | 0.33 | 1.00 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.33 | 0.33 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: gs3-83c8646-p55

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 4.3 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 100% (5 of 5) | 80% (4 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 34% (19 of 56) | 40% (2 of 5) |
| Strategy | Hexes on a unit its side charged or shot that turn | 83% (5 of 6) | - |
| Strategy | Joined characters whose unit fought | 33% (1 of 3) | 100% (1 of 1) |
| Strategy | Lone characters that fought | 78% (7 of 9) | 30% (3 of 10) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.0 | 1.0 |
| Movement | Points that never moved of their own | 340.3 | 0.0 |
| Movement | Fights charged into per game | 2.0 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 5, net +0 | 2 of 5, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 5, net +60 | 0 of 5 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 5 | 1 of 5, net +165 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 5, net +0 | 1 of 5, net +165 |
| Shooting | Shots by shooting units (incl. breath weapons) | 6.3 | 3.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 42% (8 of 19) | 82% (9 of 11) |
| Shooting | Points destroyed by shooting units | 38.7 | 0.0 |
| Shooting | War machine shots | 8.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 35% (9 of 26) | - |
| Shooting | Points destroyed by war machines | 144.7 | 0.0 |
| Magic | Magic missiles cast | 5.3 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 31% (5 of 16) | 75% (3 of 4) |
| Magic | Wounds caused by magic missiles | 13.3 | 1.3 |
| Magic | Wounds caused by other spells | 2.7 | 0.7 |
| Magic | Points destroyed by magic (all spells) | 134.7 | 144.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 2.0 / 2.3 / 1.0 | 1.7 / 0.0 / 2.0 / 0.0 |
| Combat | Points destroyed in combat | 47.7 | 246.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +130 | +62 |
| Combat | Net per 100 charger points, damage counted | +38.0 | +19.8 |
| Combat | First round won (charged fights) | 100% | 43% |
| Combat | Net points per charged fight | +64 | +47 |
| Combat | Net points per supported fight / lone fight | - / +64 | - / +47 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 6 | 5 of 7 |
| Game | Points lost | 516.0 | 489.7 |
| Game | VP from objectives | 800.0 | 553.3 |
| Game | Lone holders (player turns) | 6.7 | 0.3 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +254 VP
- The side that went first won 2 of 2 games with a winner
- Points traded per game (both sides' losses): 1006
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p55

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +173.5 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 8.7 | +458.2 | 0.0 | 136.0 | 29.7 | -3.3 | 0.0 | 325.0 |
| ARTILLERY RE-ROLL WEIGHED | 6.0 | +0.0 | 0.0 | 165.0 | - | - | - | - |
| ASSAILMENT BY POINTS | 0.3 | +3.5 | 0.0 | 0.0 | 0.7 | +5.2 | 0.0 | 0.0 |
| BACKUP TARGETS | - | - | - | - | 0.3 | +0.8 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.3 | +0.0 | 38.7 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 8.7 | +367.2 | 379.0 | 220.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 5.0 | +156.6 | 197.3 | 0.0 | 0.7 | +2.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 0.3 | +1.1 | 0.0 | 20.0 |
| CHALLENGE BY POINTS | 0.3 | +3.7 | 0.0 | 0.0 | 1.3 | +51.2 | 0.0 | 139.0 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -6.7 | 0.0 | 0.0 |
| CHARGE LOSSES | 11.0 | -526.3 | 0.0 | 272.0 | 31.3 | -1183.0 | 0.0 | 652.3 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 245.0 | 0.0 | 0.7 | +0.0 | 55.0 | 38.7 |
| CLOSES ON WHAT IT BEATS | 5.3 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | - | - | - | - | 2.3 | +271.1 | 0.0 | 0.0 |
| COVER ONCE | 10.0 | -747.1 | 0.0 | 0.0 | 7.0 | -371.6 | 0.0 | 193.3 |
| DEPLOY BY FIGURES | 6.0 | +5.5 | 0.0 | 0.0 | 6.7 | +127.1 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -21.9 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +18.6 | 41.0 | 0.0 | 0.3 | +2.4 | 55.0 | 0.0 |
| EXACT ROUND | 0.3 | +4.5 | 0.0 | 0.0 | 1.3 | +3.1 | 254.7 | 0.0 |
| FALL BACK GOOD ORDER | 1.7 | +7.1 | 87.7 | 0.0 | 1.0 | +30.8 | 0.0 | 0.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 38.7 |
| FALLS SHORT | - | - | - | - | 25.0 | +139.4 | 0.0 | 658.0 |
| FIGHT TO THE END | 1.0 | +9.1 | 87.7 | 0.0 | 0.7 | +24.4 | 144.7 | 0.0 |
| FIVE ACTION | 84.0 | +6859.1 | 1438.7 | 932.0 | 78.0 | +3765.1 | 254.7 | 1190.3 |
| FLANK NOT WEIGHED | 7.0 | +0.0 | 0.0 | 136.0 | 6.3 | +0.0 | 0.0 | 218.3 |
| FOLLOW UP WEIGHED | 1.3 | +148.1 | 0.0 | 0.0 | 1.3 | +269.5 | 0.0 | 0.0 |
| FOOT FIRST | 21.3 | +0.0 | 0.0 | 330.0 | - | - | - | - |
| FOUR ROUNDS | 2.0 | +224.2 | 128.7 | 0.0 | 2.0 | +284.5 | 254.7 | 0.0 |
| FREED FROM HIS FIGHT | 2.7 | +0.0 | 0.0 | 0.0 | 9.7 | +0.0 | 0.0 | 302.0 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -3.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 3.3 | -56.4 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 1.0 | +78.6 | 0.0 | 0.0 | 9.7 | +1327.3 | 0.0 | 38.7 |
| GUN MASK | 4.3 | +152.2 | 0.0 | 272.0 | - | - | - | - |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 77.3 |
| HE REFORMS ONCE FREED | 0.7 | +0.0 | 0.0 | 0.0 | 8.7 | +0.0 | 0.0 | 251.7 |
| HELPER UNSEEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 9.3 | +0.0 | 0.0 | 272.0 | 18.0 | +0.0 | 0.0 | 482.7 |
| HIS CHARGE LIST | 1.7 | +0.0 | 0.0 | 110.0 | 9.7 | +0.0 | 0.0 | 236.7 |
| HIS LEGAL MOVES | 5.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 38.7 |
| HIS MOVE AND SHOT | 1.0 | -2.4 | 0.0 | 0.0 | 16.0 | -297.7 | 0.0 | 239.0 |
| HIS ONE QUARTER | 4.3 | +0.0 | 0.0 | 356.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 7.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 38.7 |
| HIS RANDOM MOVE | 14.3 | +0.0 | 0.0 | 272.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 1.0 | +0.0 | 0.0 | 272.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 12.7 | +161.1 | 0.0 | 220.0 | 66.7 | +4505.9 | 0.0 | 981.7 |
| HIS SHOTS BY HIS RUN | 16.3 | +246.3 | 0.0 | 110.0 | 57.0 | +1539.6 | 0.0 | 901.0 |
| HIS TURN DENIED | - | - | - | - | 0.3 | +4.7 | 55.0 | 0.0 |
| HOLD ODDS | 13.3 | +0.0 | 0.0 | 0.0 | 15.0 | +0.0 | 0.0 | 100.7 |
| HOLDER ASSIGNMENT | 10.7 | +1169.3 | 0.0 | 0.0 | 9.7 | +927.3 | 0.0 | 50.3 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.0 | -71.0 | 128.7 | 0.0 | 2.0 | -135.2 | 254.7 | 0.0 |
| IDLE COST | - | - | - | - | 19.7 | -367.5 | 0.0 | 295.3 |
| KEEP FALLS | 0.3 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.0 | +5.5 | 0.0 | 0.0 | 0.7 | +40.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 7.0 | +0.0 | 285.7 | 425.3 | 4.7 | +0.0 | 289.3 | 227.7 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.3 | +2.8 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.7 | +41.6 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.3 | +3.5 | 144.7 | 0.0 |
| LOST AFTER ESCAPE | 1.7 | +1.0 | 87.7 | 0.0 | 1.7 | +3.7 | 199.7 | 0.0 |
| MANOEUVRE | - | - | - | - | 2.3 | +3.4 | 0.0 | 47.7 |
| MARCH AT ESCAPER | 0.3 | +11.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 1.3 | +23.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.3 | +79.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 2.3 | +235.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 3.3 | +43.9 | 0.0 | 0.0 | 1.0 | +199.0 | 0.0 | 65.0 |
| MARCH WHEELS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 8.0 | +131.4 | 0.0 | 0.0 | 1.7 | +9.6 | 0.0 | 65.0 |
| MEETS IN TIME | 3.7 | +420.3 | 0.0 | 0.0 | 3.7 | +347.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 13.3 | +337.3 | 0.0 | 0.0 | 3.3 | +14.6 | 0.0 | 65.0 |
| MISSILES NEXT TURN | 16.7 | +272.9 | 0.0 | 0.0 | 5.0 | +21.1 | 0.0 | 130.0 |
| MISSILES ON ONE TARGET | 0.3 | -8.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 8.0 | +924.2 | 0.0 | 0.0 | 6.7 | +845.1 | 0.0 | 38.7 |
| NEARER NOT NEEDED | 5.7 | +245.7 | 0.0 | 0.0 | 6.0 | +191.7 | 0.0 | 60.0 |
| NEXT CHARGE BY LIST | 4.0 | +552.1 | 0.0 | 0.0 | 6.0 | +584.3 | 0.0 | 38.7 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 1.3 | -15.6 | 0.0 | 100.7 |
| NO DOUBLE ROUNDS | 1.3 | -71.5 | 128.7 | 0.0 | 1.7 | -40.0 | 110.0 | 0.0 |
| NO LATE CUT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 6.0 | -325.0 | 41.0 | 165.0 | 5.7 | -368.6 | 0.0 | 162.3 |
| OGRE LOADER SECOND SHOT | 8.3 | +139.2 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 9.0 | -197.4 | 0.0 | 0.0 | 6.3 | -203.3 | 0.0 | 231.3 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +13.0 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 5.0 | +55.5 | 0.0 | 0.0 | 5.3 | -146.8 | 0.0 | 50.3 |
| ONE ROUTE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 0.7 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.3 | +5.4 | 41.0 | 0.0 | 1.3 | +33.7 | 199.7 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +0.5 | 0.0 | 38.7 |
| PLAN RESULT | 36.3 | +1259.0 | 536.0 | 801.7 | 39.7 | +222.1 | 0.0 | 846.3 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 47.7 |
| PROMISE BY ITS OWN SUM | 12.3 | -523.0 | 0.0 | 0.0 | 9.3 | -549.3 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 2.3 | -21.3 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 3.0 | -37.4 | 0.0 | 0.0 | 0.7 | -7.0 | 0.0 | 20.0 |
| QUARTER ODDS | 16.3 | +2101.8 | 0.0 | 492.0 | 13.0 | +1383.6 | 55.0 | 0.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.0 | +72.1 | 0.0 | 0.0 |
| REAL GROUND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 1.3 | +92.1 | 0.0 | 20.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 4.0 | -128.6 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| RISK BY ARC | 1.3 | +55.6 | 128.7 | 0.0 | 1.7 | -140.4 | 199.7 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.3 | -49.9 | 110.0 | 0.0 |
| RUN DOWN | 1.3 | -11.6 | 128.7 | 0.0 | 2.0 | -63.6 | 254.7 | 0.0 |
| SAFER THAN THE JOB | - | - | - | - | 0.3 | +3.1 | 0.0 | 0.0 |
| SAME CHARGE LATER | 0.7 | -34.6 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.0 | +5.6 | 0.0 | 20.0 |
| SEARCH SPOT | 0.7 | +5.2 | 0.0 | 0.0 | 0.3 | +48.6 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +7.7 | 41.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 1.0 | -21.6 | 0.0 | 0.0 | 4.0 | -208.7 | 0.0 | 86.7 |
| SET UP BY THE SET | 1.0 | +36.4 | 0.0 | 0.0 | 6.7 | +172.1 | 0.0 | 86.7 |
| SET-UP MISSED | - | - | - | - | 0.3 | +80.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 17.7 | +0.0 | 0.0 | 220.0 | 2.7 | +0.0 | 0.0 | 142.3 |
| SHOOTS FROM THE BEST SPOT | 7.3 | +201.0 | 130.0 | 0.0 | 1.0 | +116.1 | 0.0 | 130.0 |
| SHOT REPLANNED | 0.3 | +0.0 | 38.7 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 9.3 | -90.4 | 0.0 | 110.0 | 46.7 | +582.5 | 0.0 | 809.3 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 15.7 | +756.0 | 0.0 | 330.0 | 3.0 | +71.4 | 0.0 | 82.0 |
| SPELL WORTH | 1.0 | +11.4 | 144.7 | 144.7 | 2.0 | +55.5 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | +5.7 | 0.0 | 0.0 | 0.3 | -19.7 | 144.7 | 0.0 |
| SPOT AS THE GAME MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 9.7 | +0.0 | 0.0 | 183.7 |
| STAND AND SHOOT | 0.3 | -0.8 | 41.0 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | - | - | - | - | 4.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 42.7 | +0.0 | 1310.0 | 660.0 | 17.0 | +0.0 | 0.0 | 210.0 |
| STAY WORTH | 32.7 | -284.4 | 838.0 | 550.0 | 3.3 | -23.6 | 0.0 | 0.0 |
| STRIKE BY THE ODDS | 0.3 | +0.4 | 0.0 | 136.0 | 0.3 | +8.0 | 136.0 | 0.0 |
| STUBBORN BY POINTS | 0.3 | +0.1 | 0.0 | 55.0 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 3.3 | +282.6 | 0.0 | 0.0 | 1.7 | +347.9 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 41.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 3.3 | +282.6 | 0.0 | 0.0 | 1.7 | +347.9 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 1.0 | +2.7 | 0.0 | 65.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 38.7 |
| THE PROMISE ADDS | - | - | - | - | 1.0 | -50.7 | 0.0 | 20.0 |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 59.7 |
| THE ROW KEEPS ITS WAY | 2.3 | +0.0 | 0.0 | 136.0 | 3.7 | +0.0 | 0.0 | 40.0 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 40.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 39.7 | +0.0 | 0.0 | 356.0 | 38.7 | +0.0 | 0.0 | 657.3 |
| TIED UP BY THE SUM | 0.3 | +38.6 | 41.0 | 0.0 | 0.3 | +17.3 | 55.0 | 0.0 |
| TIME ON OUR SIDE | 31.3 | +547.0 | 0.0 | 0.0 | - | - | - | - |
| WAITS AGAIN | 3.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -95.8 | 289.3 | 0.0 |
| WHO FIGHTS | 0.3 | -0.4 | 40.0 | 0.0 | 1.0 | +12.2 | 199.7 | 0.0 |
| WHO HITS BACK | 0.7 | +252.1 | 0.0 | 144.7 | 1.0 | +88.3 | 0.0 | 47.7 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +43.2 | 144.7 | 0.0 |
| WHOLE FIGHT DANGER | 2.0 | -398.5 | 0.0 | 272.0 | 1.0 | -110.6 | 0.0 | 171.0 |
| WOUNDS ON THE RANKS | 5.3 | +44.9 | 0.0 | 0.0 | - | - | - | - |

### Rule changes: gs3-83c8646-p55

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 115 | 115 | 87 | 29.00 | +1937 | +22.3 |
| HIS SHOT LIST | 238 | 230 | 64 | 21.33 | +2104 | +32.9 |
| HOLDER ASSIGNMENT | 61 | 61 | 55 | 18.33 | +4102 | +74.6 |
| FIVE ACTION | 486 | 474 | 41 | 13.67 | +3473 | +84.7 |
| LEGAL CHARGES ONLY | 35 | 35 | 35 | 11.67 | +0 | +0.0 |
| OFF BEST | 35 | 35 | 35 | 11.67 | -2081 | -59.5 |
| MOVE TO CHARGE COMPUTED | 44 | 40 | 33 | 11.00 | +2255 | +68.3 |
| HIS SHOTS BY HIS RUN | 220 | 215 | 30 | 10.00 | +513 | +17.1 |
| OGRE LOADER SECOND SHOT | 25 | 25 | 25 | 8.33 | +418 | +16.7 |
| PROMISE BY ITS OWN SUM | 65 | 65 | 24 | 8.00 | -3217 | -134.1 |
| SHOT RISK POINTS | 168 | 162 | 24 | 8.00 | +938 | +39.1 |
| QUARTER ODDS | 88 | 88 | 23 | 7.67 | +1798 | +78.2 |
| THE TABLE AGAIN | 36 | 36 | 23 | 7.67 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 30 | 28 | 20 | 6.67 | +1583 | +79.2 |
| ARTILLERY RE-ROLL WEIGHED | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| DEPLOY BY FIGURES | 38 | 38 | 18 | 6.00 | +443 | +24.6 |
| HARD STAY DROPPED | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 94 | 78 | 14 | 4.67 | +61 | +4.4 |
| CHARGE LOSSES | 127 | 126 | 13 | 4.33 | +1255 | +96.6 |
| MEETS IN TIME | 22 | 22 | 12 | 4.00 | +535 | +44.6 |
| SHOOTS FROM THE BEST SPOT | 25 | 25 | 11 | 3.67 | +181 | +16.4 |
| CAST JOB | 17 | 17 | 10 | 3.33 | +164 | +16.4 |
| COVER ONCE | 51 | 31 | 10 | 3.33 | +184 | +18.4 |
| FOUR ROUNDS | 12 | 11 | 9 | 3.00 | +619 | +68.7 |
| FOLLOW UP WEIGHED | 8 | 8 | 8 | 2.67 | +1253 | +156.6 |
| GOAL WALK | 32 | 32 | 8 | 2.67 | +1689 | +211.2 |
| MOVE ORDER | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| MARCH OF THE TABLE | 7 | 7 | 7 | 2.33 | -705 | -100.7 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 7 | 2.33 | +216 | +30.9 |
| SET UP BY THE SET | 23 | 22 | 7 | 2.33 | +190 | +27.2 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 19 | 19 | 6 | 2.00 | +0 | +0.0 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 5 | 5 | 5 | 1.67 | +165 | +33.0 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| IDLE COST | 59 | 38 | 5 | 1.67 | +21 | +4.2 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +137 | +27.3 |
| ONE OBJECTIVE FORMULA | 31 | 23 | 5 | 1.67 | +332 | +66.3 |
| WHO HITS BACK | 5 | 5 | 5 | 1.67 | +572 | +114.3 |
| MARCH BY THE SUM | 4 | 4 | 4 | 1.33 | +69 | +17.3 |
| MISSILES IN THE MOVE | 50 | 29 | 4 | 1.33 | +123 | +30.6 |
| PROMISE KNOWS THE FIGHT | 14 | 11 | 4 | 1.33 | -64 | -16.0 |
| SUPPORT ADDS | 15 | 15 | 4 | 1.33 | +140 | +34.9 |
| SUPPORT WORKED OUT | 15 | 15 | 4 | 1.33 | +140 | +34.9 |
| WHOLE FIGHT DANGER | 9 | 9 | 4 | 1.33 | +745 | +186.3 |
| ASSAILMENT BY POINTS | 3 | 3 | 3 | 1.00 | +26 | +8.7 |
| FALLS SHORT | 75 | 65 | 3 | 1.00 | +21 | +7.1 |
| MARCH CHECK | 4 | 4 | 3 | 1.00 | +60 | +20.0 |
| MAX FOR POSITIONING | 29 | 25 | 3 | 1.00 | +5 | +1.8 |
| SEARCH SPOT | 3 | 3 | 3 | 1.00 | +161 | +53.8 |
| CANNON PLANNED TARGET | 26 | 26 | 2 | 0.67 | -129 | -64.4 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +125 | +62.4 |
| NEARER NOT NEEDED | 35 | 34 | 2 | 0.67 | +37 | +18.6 |
| OVERRUNS AWAY | 5 | 4 | 2 | 0.67 | +62 | +30.9 |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 2 | 0.67 | +0 | +0.0 |
| SHOTS IN THE MOVE | 56 | 37 | 2 | 0.67 | +70 | +35.1 |
| STAY WORTH | 108 | 95 | 2 | 0.67 | +62 | +31.1 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +25 | +12.6 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 19 | 2 | 2 | 0.67 | +0 | +0.0 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +520 | +520.4 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 9 | 9 | 1 | 0.33 | -19 | -19.2 |
| FALL BACK GOOD ORDER | 8 | 8 | 1 | 0.33 | +0 | +0.5 |
| FALLBACK BY WORTH | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| GUN MASK | 13 | 12 | 1 | 0.33 | +18 | +17.6 |
| HONEST WORTH | 12 | 11 | 1 | 0.33 | +97 | +96.6 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +3 | +2.8 |
| MANOEUVRE | 7 | 7 | 1 | 0.33 | +24 | +23.6 |
| MISSILES NEXT TURN | 65 | 42 | 1 | 0.33 | +0 | +0.0 |
| NEXT OBJECTIVE NEARER | 4 | 4 | 1 | 0.33 | +43 | +42.8 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +2 | +1.6 |
| PROMISE READS THE TABLE | 11 | 11 | 1 | 0.33 | -5 | -4.9 |
| REDIRECT FOR A FRIEND IN REACH | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.33 | +9 | +9.2 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +23 | +22.9 |
| SHOT REPLANNED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.4 |
| WHOLE FIGHT | 1 | 1 | 1 | 0.33 | +38 | +38.1 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 5 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 38 | 34 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 7 | not checked | - | - | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 2 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 5 | 5 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 5 | 5 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 40 | not checked | - | - | - | - |
| FOOT FIRST | 64 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 37 | 35 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 10 | 10 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 28 | 27 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 82 | 81 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 34 | 34 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 23 | 21 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 51 | 51 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 21 | 21 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 32 | 29 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 43 | 42 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 3 | 3 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HOLD ODDS | 85 | 85 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 9 | 9 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 10 | 10 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 13 | 13 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 1 | not checked | - | - | - | - |
| MOVE SPELL SPOT | 5 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 9 | 8 | 0 | 0.00 | - | - |
| NO LATE CUT | 1 | 1 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 46 | 23 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS A LANE | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 228 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 12 | 12 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 2 | 2 | 0 | 0.00 | - | - |
| RISK BY ARC | 9 | 8 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 10 | 9 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 15 | 14 | 0 | 0.00 | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 61 | not checked | - | - | - | - |
| SPELL WORTH | 9 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 46 | 37 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | not checked | - | - | - | - |
| STANDS FOR A REASON | 14 | 14 | 0 | 0.00 | - | - |
| STANDS STILL | 179 | 178 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 3 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 12 | not checked | - | - | - | - |
| THE PROMISE ADDS | 3 | 2 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 18 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 11 | not checked | - | - | - | - |
| THE TABLE BINDS | 235 | not checked | - | - | - | - |
| TIED UP BY THE SUM | 2 | 1 | 0 | 0.00 | - | - |
| WAITS AGAIN | 10 | 10 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 2 | 2 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 4 | 4 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 16 | 16 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p55

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.67 | 4.67 | 60.9 |
| PROMISE BY ITS OWN SUM | rule | 5.67 | 2.33 | 134.1 |
| ARMY TABLE | rule | 1.00 | 5.00 | 74.3 |
| MARCH OF THE TABLE | rule | 2.33 | - | 100.7 |
| PROMISE KNOWS THE FIGHT | rule | 1.33 | - | 16.0 |
| CANNON PLANNED TARGET | rule | 0.67 | - | 64.4 |
| CHARGE NOW FIRST | rule | 0.33 | - | 19.2 |
| FALLBACK | gate | - | 0.33 | 93.9 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 13.2 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.33 | 24.2 |
| NO REASON | gate | 0.33 | - | 37.4 |
| PROMISE READS THE TABLE | rule | - | 0.33 | 4.9 |
| RULE SWITCHED OFF | gate | - | 0.33 | 37.4 |
| SET UP BY THE SET | rule | - | 0.33 | 5.1 |

### Plans: gs3-83c8646-p55

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 100% | 122 | 195 | 159% |
| Mine | move | 20.0 | 98% | 1760 | 0 | 0% |
| Mine | shoot | 15.0 | 60% | 919 | 1064 | 116% |
| Opponent | charge | 1.7 | 60% | 199 | 222 | 111% |
| Opponent | join | 2.7 | 88% | 137 | 0 | 0% |
| Opponent | move | 34.0 | 91% | 1683 | 0 | 0% |
| Opponent | shoot | 1.0 | 0% | 0 | 0 | - |
| Opponent | support | 0.3 | 100% | 31 | 0 | 0% |

### Battle groups: gs3-83c8646-p55

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 1.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p55

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 9 | 30 (9) | 30 | 0 | 33 | 0% | 2.3 | 44 (2) | 28 (7) | - | 44 (5) | 17 (4) |
| Mine | Clean-up | 2 | 90 (2) | 0 | 90 | 0 | 0% | 2.0 | 0 (1) | 170 (1) | - | 90 (2) | - |
| Mine | Fast Hammer | 4 | 29 (4) | 11 | 18 | 40 | 0% | 3.2 | 39 (2) | 25 (2) | - | 45 (3) | 0 (1) |
| Mine | Holder | 1 | 175 (1) | 0 | 175 | 0 | 0% | 1.0 | 175 (1) | - | - | 175 (1) | - |
| Mine | Shooter | 4 | 73 (4) | 0 | 73 | 0 | 0% | 2.2 | 48 (3) | 186 (1) | - | 73 (4) | - |
| Mine | War machine | 6 | 44 (6) | 44 | 0 | 67 | 0% | 1.0 | 94 (2) | 0 (2) | 37 (2) | 0 (1) | 53 (5) |
| Mine | Wizard | 3 | 17 (3) | 17 | 0 | 0 | 0% | 1.7 | 0 (2) | 33 (1) | - | 17 (3) | - |
| Opponent | Chaff | 2 | 275 (2) | 0 | 275 | 50 | 100% | - | - | 550 (1) | 0 (1) | 275 (2) | - |
| Opponent | Character | 10 | 22 (10) | 22 | 0 | 17 | 60% | 3.0 | 16 (3) | 35 (5) | 0 (2) | 0 (5) | 48 (5) |
| Opponent | Fast Hammer | 9 | 42 (9) | 11 | 31 | 44 | 22% | 3.1 | 30 (2) | 45 (7) | - | 14 (5) | 80 (4) |
| Opponent | Hammer | 3 | 191 (3) | 191 | 0 | 0 | 33% | 5.0 | 185 (2) | 201 (1) | - | 185 (2) | 201 (1) |
| Opponent | Holder | 5 | 0 (5) | 0 | 0 | 14 | 40% | 5.0 | 0 (3) | 0 (1) | 0 (1) | 0 (2) | 0 (3) |
| Opponent | Shooter | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | - | 0 (1) | - | 0 (1) |

### Charged fights: gs3-83c8646-p55

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 3 | 318 | 129 | 2.0 | 1.0 | 64 | 0 | +64 | 2 of 6 | 6 of 6 | - | +64 |
| Opponent | High Elf Realms | 1 | 0 | 165 | 4.0 | 1.0 | 41 | 0 | +41 | 3 of 4 | 1 of 4 | - | +41 |
| Opponent | Vampire Counts | 1 | 434 | 165 | 3.0 | 1.0 | 55 | 0 | +55 | 2 of 3 | 2 of 3 | - | +55 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 145 | 110 | 2.3 | 1.0 | 47 | 0 | +47 | 5 of 7 | 3 of 7 | - | +47 |

### Effective charges: gs3-83c8646-p55

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 6 | 1 (net +0) | 0 | 2 (net +60) | 1 (net +143) | 0 | 1 (net +0) | 1 | 40% (2 of 5) |
| Opponent | High Elf Realms | 4 | 1 (net +0) | 0 | 0 | 0 | 1 (net +165) | 0 | 2 | 0% (0 of 2) |
| Opponent | Vampire Counts | 3 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 1 (net +165) | 0 | 0% (0 of 3) |

### Charged fights, damage counted: gs3-83c8646-p55

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 379 | 343 | +0 | 49 | 0 | +49 | +12.9 |
| Mine | Effective (55-75%) | 2 | 352 | 295 | +60 | 113 | 0 | +113 | +32.0 |
| Mine | 76-89% | 1 | 233 | 143 | +143 | 350 | 39 | +311 | +133.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 369 | 144 | +0 | 72 | 0 | +72 | +19.5 |
| Mine | No odds | 1 | 369 | 123 | +123 | 123 | 0 | +123 | +33.3 |
| Mine | All fights | 6 | 342 | 224 | +64 | 136 | 6 | +130 | +38.0 |
| Opponent | Long shot (under 50%) | 2 | 330 | 288 | +0 | 119 | 0 | +119 | +36.1 |
| Opponent | 76-89% | 1 | 235 | 334 | +0 | 0 | 24 | -24 | -10.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 161 | 165 | +165 | 165 | 0 | +165 | +102.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 500 | 165 | +165 | 165 | 188 | -22 | -4.5 |
| Opponent | No odds | 2 | 316 | 364 | +0 | 53 | 15 | +38 | +11.9 |
| Opponent | All fights | 7 | 313 | 281 | +47 | 96 | 34 | +62 | +19.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p55 | move | 35 | 3 (9%) | 3 (9%) | 4 (11%) | 28 (80%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1224 |
| Clockwork Compass | Mine | L1224 |
| Elixir of Power | Mine | L1114, L1131 |
| Invocation of Nehek | Opponent | L1224 |
| Opal Amulet | Opponent | L1114 |
| Ring of Doom | Mine | L1114, L1131, L1224 |
| Ring of Doom | Opponent | L1131 |
| Ring of Jet | Mine | L1114, L1131, L1224 |

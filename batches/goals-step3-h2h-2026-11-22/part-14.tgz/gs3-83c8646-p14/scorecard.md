# Doctrine scorecard: gs3-83c8646-p14

### Scorecard: gs3-83c8646-p14

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0222 | 6 | 1 | Mine | no | 0 | 2 | 5 | 4 | 1 | 0 | 0 | 0 |
| L0222 | 6 | 1 | Opponent | no | 2 | 2 | 5 | 1 | 0 | 0 | 0 | 72 |
| L0307 | 1 | 1 | Mine | yes | 5 | - | 1 | 1 | 0 | 0 | 0 | 590 |
| L0307 | 1 | 1 | Opponent | no | 6 | 5 | 2 | 1 | 1 | 0 | 0 | 375 |
| L0323 | 5 | 1 | Mine | no | - | 2 | 2 | 3 | 0 | 0 | 0 | 220 |
| L0323 | 5 | 1 | Opponent | yes | - | 4 | 1 | 3 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 2.5 | 2.0 | 2.7 | 2.7 | 0.3 | 0.0 | 0.0 | 270.0 |
| **Average** | | | Opponent | 33% | 4.0 | 3.7 | 2.7 | 1.7 | 0.7 | 0.0 | 0.0 | 149.0 |

### KPIs: gs3-83c8646-p14

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 31% (4 of 13) | 6% (1 of 16) | 17% (5 of 29) |
| Winner chose to follow up after the loser gave ground |  | 100% (9 of 9); on the table 100% | 100% (3 of 3); on the table 100% | 100% (12 of 12); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 0% (0 of 1); on the table 100% | 0% (0 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (9 of 9); on the table 100% | 75% (3 of 4); on the table 100% | 92% (12 of 13); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 39% (14 of 36) | 67% (4 of 6) | 43% (18 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 52% (14 of 27) | 80% (4 of 5) | 56% (18 of 32) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 75% (3 of 4) | - | 75% (3 of 4) |
| Points that never fought | lower | 55% (3252 of 5897) | 48% (2907 of 5999) | 52% (6159 of 11896) |
|   infantry points that never fought | lower | 59% (851 of 1437) | 88% (828 of 938) | 71% (1679 of 2375) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 50% (11 of 22) | 55% (11 of 20) | 52% (22 of 42) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 75% (3 of 4); 1.0 uses a game | 0% (0 of 1); 0.0 uses a game | 60% (3 of 5); 0.5 uses a game |
|   their share of the points of units over 100 pts | lower | 42% (1872 of 4484) | 51% (2360 of 4648) | 46% (4232 of 9132) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.7 (36%) | 0.0 (0%) | 2.7 (33%) |
| MARCHED: its unit marched | 1.7 (23%) | 0.3 (50%) | 2.0 (25%) |
| IN COMBAT: engaged in combat | 1.3 (18%) | 0.0 (0%) | 1.3 (17%) |
| GONE: slain | 1.7 (23%) | 0.3 (50%) | 2.0 (25%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 6.0 | 1.3 | 6.0 | 0.3 | 0.7 |
| not cast | 0.0 | 2.7 | 8.0 | 1.7 | 7.3 |
| NOT CHOSEN: could have been cast at a target | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (18%) |
| NO TARGET: no enemy in range, sight and arc it may target | - | 0.0 (0%) | 2.7 (33%) | 0.3 (20%) | 0.0 (0%) |
| MARCHED: its unit marched | - | 0.0 (0%) | 2.0 (25%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | - | 1.3 (50%) | 1.3 (17%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | - | 0.0 (0%) | 2.0 (25%) | 0.3 (20%) | 0.7 (9%) |
| OTHER BAR: another bar (miscast, baggage ...) | - | 0.0 (0%) | 0.0 (0%) | 1.0 (60%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | - | 1.3 (50%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 5.3 (73%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.0 a game | 0.7 a game |
| stood (cast and not dispelled) | 50% (2 of 4) | - | 50% (2 of 4) |
| the unit moved after it | 50% (1 of 2) | - | 50% (1 of 2) |
| it charged on its next turn | 0% (0 of 2) | - | 0% (0 of 2) |
| the enemy charged it first | 50% (1 of 2) | - | 50% (1 of 2) |
| it fought by the end of its next turn | 0% (0 of 2) | - | 0% (0 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 2) | - | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | 50% (1 of 2) | - | 50% (1 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 80% (44 of 55) | 64% (64 of 100) | 70% (108 of 155) |
|   cavalry | - | 93% (13 of 14) | 93% (13 of 14) |
|   character | - | 0% (0 of 15) | 0% (0 of 15) |
|   chariot | 74% (17 of 23) | 100% (2 of 2) | 76% (19 of 25) |
|   infantry | - | 67% (39 of 58) | 67% (39 of 58) |
|   war machine | 84% (27 of 32) | 91% (10 of 11) | 86% (37 of 43) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.3 (9%) | 1.3 (11%) | 1.7 (11%) |
| CHARGED: it charged | 0.7 (18%) | 1.7 (14%) | 2.3 (15%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.7 (18%) | 1.3 (11%) | 2.0 (13%) |
| MOVED: a war machine that moved | 1.0 (27%) | 0.0 (0%) | 1.0 (6%) |
| NO TARGET IN RANGE | 0.3 (9%) | 4.7 (39%) | 5.0 (32%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (9%) | 1.3 (11%) | 1.7 (11%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 1.0 (8%) | 1.0 (6%) |
| OTHER BAR | 0.3 (9%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.3 | 0.7 | 88% | 3.6 pts | 19 pts |
| chariot | 6.7 | 7.3 | 40% | 36.4 pts | 243 pts |
| infantry | 15.3 | 6.7 | 67% | 10.0 pts | 154 pts |
| war machine | 13.0 | 15.3 | 72% | 41.7 pts | 543 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 4.0 | 3.5 |
| Charges that made contact a game | 2.0 | 3.3 | 2.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (4 units) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.45 declared, 0.30 contact (20 units) | 0.40 declared, 0.33 contact (30 units) | 0.42 declared, 0.32 contact (50 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 100% (3 of 3) | 0% (0 of 1) | - | 75% (3 of 4) |
| Character in a unit | 50% (2 of 4) | 50% (1 of 2) | - | 50% (3 of 6) |
| Character on its own | 0% (0 of 2) | - | 40% (2 of 5) | 29% (2 of 7) |
| Chariot | - | 0% (0 of 4) | - | 0% (0 of 4) |
| Infantry | 0% (0 of 2) | 33% (1 of 3) | - | 20% (1 of 5) |
| Monster | 100% (5 of 5) | - | - | 100% (5 of 5) |
| War Machines | 67% (6 of 9) | 100% (2 of 2) | - | 73% (8 of 11) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1 | 100% (6 of 6); on the table 100% | 50% (6 of 12) | 26% | 33% (2 of 6) | 100% (2 of 2); 6.0 uses a game | 0.0 uses a game | 100% (2 of 2); 2.0 uses a game |
| Chaos Dwarfs | 2 | 100% (3 of 3); on the table 100% | 33% (8 of 24) | 69% | 56% (9 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Empire of Man | 1 | 100% (1 of 1); on the table 100% | 67% (4 of 6) | 60% | 50% (5 of 10) | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 2 | 67% (2 of 3); on the table 100% | - | 43% | 60% (6 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p14, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 29% (2) | 33% (1) | 30% (3) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p14

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 38% (3 of 8) | 50% (6 of 12) |
| Strategy | Shoot objectives carried out (shot that target) | 58% (25 of 43) | 68% (30 of 44) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | 33% (1 of 3) |
| Strategy | Joined characters whose unit fought | 86% (6 of 7) | 0% (0 of 3) |
| Strategy | Lone characters that fought | 20% (1 of 5) | 75% (6 of 8) |
| Movement | Charges halted short of contact | 0.0 | 0.7 |
| Movement | Idle units | 2.7 | 1.7 |
| Movement | Points that never moved of their own | 270.0 | 149.0 |
| Movement | Fights charged into per game | 2.0 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 4, net +0 | 1 of 6, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 4 | 1 of 6, net +310 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 4 | 0 of 6 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 4, net +41 | 4 of 6, net +91 |
| Shooting | Shots by shooting units (incl. breath weapons) | 5.7 | 19.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 59% (10 of 17) | 24% (14 of 59) |
| Shooting | Points destroyed by shooting units | 228.0 | 140.0 |
| Shooting | War machine shots | 9.3 | 3.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 32% (9 of 28) | 60% (6 of 10) |
| Shooting | Points destroyed by war machines | 65.0 | 36.7 |
| Magic | Magic missiles cast | 2.3 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 14% (1 of 7) | 67% (2 of 3) |
| Magic | Wounds caused by magic missiles | 5.0 | 1.3 |
| Magic | Wounds caused by other spells | 0.3 | - |
| Magic | Points destroyed by magic (all spells) | 71.3 | 28.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.3 / 0.0 | 5.7 / 0.0 / 0.0 / 0.3 |
| Combat | Points destroyed in combat | 486.3 | 205.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +108 | +3 |
| Combat | Net per 100 charger points, damage counted | +61.9 | +1.1 |
| Combat | First round won (charged fights) | 83% | 56% |
| Combat | Net points per charged fight | +102 | -3 |
| Combat | Net points per supported fight / lone fight | - / +102 | +0 / -4 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 6 | 5 of 9 |
| Game | Points lost | 564.3 | 859.0 |
| Game | VP from objectives | 480.0 | 636.7 |
| Game | Lone holders (player turns) | 2.5 | 4.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +129 VP
- The side that went first won 2 of 2 games with a winner
- Points traded per game (both sides' losses): 1423
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: gs3-83c8646-p14

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 12.7 | +103.1 | 0.0 | 56.7 | 17.3 | +410.1 | 0.0 | 419.3 |
| ARTILLERY RE-ROLL WEIGHED | 5.0 | +0.0 | 0.0 | 226.7 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 0.7 | +2.9 | 0.0 | 65.0 |
| CANNON PLAN MISSED | 0.3 | +0.0 | 23.3 | 36.7 | - | - | - | - |
| CANNON PLANNED TARGET | 8.3 | +20.8 | 238.3 | 430.0 | 3.3 | +63.6 | 36.7 | 41.7 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 41.7 |
| CARRIES OUT SET-UP | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 4.7 | +68.7 | 263.0 | 113.3 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.3 | +24.2 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.7 | -0.6 | 65.0 | 36.7 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +0.8 | 0.0 | 28.3 | - | - | - | - |
| CHARGE LOSSES | 21.0 | -1403.2 | 0.0 | 174.0 | 21.7 | -919.5 | 0.0 | 718.7 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 242.0 | 0.0 | 2.7 | +0.0 | 141.7 | 314.0 |
| CLOSES ON WHAT IT BEATS | 9.7 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 46.7 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.7 | +169.7 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 12.7 | -591.2 | 0.0 | 67.0 | 4.3 | -111.4 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 9.0 | -61.4 | 0.0 | 0.0 | 7.3 | -45.6 | 0.0 | 65.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -16.6 | 0.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +11.2 | 36.7 | 0.0 |
| ENGINEER BY LORE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 2.3 | +6.6 | 131.3 | 17.3 | 2.7 | +20.0 | 178.3 | 208.7 |
| FALL BACK GOOD ORDER | 0.7 | +0.0 | 24.0 | 0.0 | 3.3 | +0.0 | 178.3 | 314.0 |
| FALLS SHORT | 7.0 | +150.2 | 0.0 | 56.7 | 14.3 | +166.8 | 0.0 | 123.3 |
| FEATURE BUFFS | 4.3 | +61.4 | 0.0 | 0.0 | 3.7 | +95.1 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +0.0 | 0.0 | 17.3 | 0.7 | +142.2 | 0.0 | 170.3 |
| FIVE ACTION | 91.7 | +3656.9 | 1544.0 | 1391.3 | 100.0 | +8187.3 | 1046.3 | 1636.3 |
| FLANK NOT WEIGHED | 11.7 | +0.0 | 0.0 | 58.7 | 4.0 | +0.0 | 0.0 | 103.3 |
| FOLLOW UP WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +309.3 | 0.0 | 0.0 |
| FOOT FIRST | - | - | - | - | 32.0 | +0.0 | 0.0 | 227.7 |
| FOUR ROUNDS | 3.0 | +88.4 | 301.7 | 17.3 | 4.7 | +548.3 | 178.3 | 379.0 |
| FREED FROM HIS FIGHT | 3.3 | +0.0 | 0.0 | 89.0 | 4.3 | +0.0 | 0.0 | 130.0 |
| FRIEND SHOOTS FIRST | 0.3 | -0.1 | 0.0 | 0.0 | 2.7 | -36.1 | 0.0 | 130.0 |
| FRIENDS SHOTS CHECKED | 0.7 | +6.8 | 0.0 | 103.3 | - | - | - | - |
| GIVES UP | 0.3 | -0.5 | 0.0 | 17.3 | 0.7 | -2.7 | 36.7 | 0.0 |
| GOAL ROUTE | - | - | - | - | 0.7 | +24.3 | 0.0 | 0.0 |
| GOAL WALK | 12.0 | +735.3 | 0.0 | 0.0 | 16.0 | +2167.1 | 0.0 | 176.7 |
| GUN FIGURES | 3.3 | +100.1 | 315.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 1.3 | +0.0 | 0.0 | 60.7 | 4.0 | +0.0 | 0.0 | 130.0 |
| HELPER UNSEEN | 0.7 | +0.0 | 170.3 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 17.7 | +0.0 | 0.0 | 174.0 | 7.3 | +0.0 | 0.0 | 418.7 |
| HIS CHARGE DENIED | 0.7 | +64.3 | 65.0 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 12.7 | +0.0 | 0.0 | 117.3 | 1.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 178.0 |
| HIS MOVE AND SHOT | 3.7 | -29.2 | 0.0 | 0.0 | 2.7 | -378.8 | 0.0 | 275.3 |
| HIS ONE QUARTER | 3.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 173.3 |
| HIS OWN BEST MOVE | 8.0 | +0.0 | 0.0 | 89.0 | 9.3 | +0.0 | 0.0 | 308.0 |
| HIS RANDOM MOVE | - | - | - | - | 9.7 | +0.0 | 0.0 | 72.0 |
| HIS RANDOM MOVER COMES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 48.7 | +1325.3 | 0.0 | 344.0 | 47.0 | +1739.1 | 0.0 | 659.3 |
| HIS SHOTS BY HIS RUN | 50.0 | +658.4 | 0.0 | 400.7 | 46.7 | +1000.3 | 0.0 | 1174.0 |
| HIS TURN DENIED | 0.7 | +10.1 | 24.0 | 17.3 | 1.0 | +18.0 | 36.7 | 170.3 |
| HOLD ODDS | 16.7 | +0.0 | 0.0 | 0.0 | 25.0 | +0.0 | 0.0 | 250.7 |
| HOLDER ASSIGNMENT | 7.7 | +700.7 | 0.0 | 0.0 | 14.7 | +1042.1 | 0.0 | 125.3 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.0 | -17.0 | 131.3 | 17.3 | 2.7 | -96.3 | 121.7 | 379.0 |
| IDLE COST | 7.3 | -46.5 | 0.0 | 56.7 | 12.7 | -196.2 | 0.0 | 176.7 |
| JOINT CHARGE NOW | 0.7 | +26.3 | 0.0 | 0.0 | 2.0 | +8.5 | 56.7 | 0.0 |
| KEEP FALLS | 0.7 | +7.3 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | - | - | - | - | 6.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 1.3 | +45.8 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.7 | +0.0 | 188.7 | 149.0 | 14.3 | +0.0 | 503.7 | 206.3 |
| LONE WIZARD KEPT IN | 0.7 | +17.5 | 0.0 | 0.0 | 1.0 | +78.3 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 1.0 | -1.3 | 42.3 | 17.3 | 2.0 | +0.0 | 0.0 | 170.3 |
| LOST CHARGE | - | - | - | - | 0.7 | -5.4 | 36.7 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 2.0 | +31.8 | 0.0 | 150.7 |
| MANOEUVRE | 2.0 | -10.4 | 0.0 | 0.0 | 1.3 | -32.4 | 0.0 | 23.3 |
| MARCH AT ESCAPER | 1.7 | +9.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.7 | +13.1 | 0.0 | 0.0 | 0.3 | +91.1 | 0.0 | 126.7 |
| MARCH CHECK | 0.7 | +25.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 1.0 | +5.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.3 | -36.4 | 0.0 | 0.0 | 0.7 | +5.5 | 0.0 | 126.7 |
| MARCH WHEELS ONLY | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.7 | +83.5 | 0.0 | 87.0 | 3.7 | +83.1 | 0.0 | 174.7 |
| MEETS IN TIME | 3.3 | +203.8 | 0.0 | 0.0 | 1.7 | +142.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 5.0 | +102.2 | 0.0 | 56.7 | 1.3 | +26.6 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 7.3 | +79.0 | 0.0 | 85.0 | 1.7 | +39.9 | 0.0 | 126.7 |
| MISSILES ON ONE TARGET | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 1.0 | +0.0 | 56.7 | 0.0 | 1.7 | +0.0 | 46.0 | 0.0 |
| MOVE SPELL SPOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 8.7 | +428.1 | 0.0 | 117.3 | 10.3 | +925.7 | 0.0 | 260.0 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 5.0 | +243.8 | 0.0 | 0.0 | 10.7 | +453.6 | 0.0 | 24.0 |
| NEAREST TO GOAL | - | - | - | - | 3.0 | +0.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 4.7 | +174.9 | 0.0 | 28.3 | 8.3 | +787.8 | 0.0 | 260.0 |
| NO DOUBLE ROUNDS | 2.3 | -69.4 | 131.3 | 17.3 | 4.0 | -125.7 | 178.3 | 379.0 |
| NO LATE CUT | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 5.7 | -84.5 | 0.0 | 141.7 | 6.0 | -206.5 | 0.0 | 41.7 |
| OGRE LOADER SECOND SHOT | 3.0 | +2.3 | 0.0 | 153.3 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 79.3 |
| ONE FIGHT FORMULA | 7.0 | -42.2 | 0.0 | 58.7 | 8.7 | -236.2 | 0.0 | 280.7 |
| ONE JOINT FIGURE | - | - | - | - | 1.0 | +15.8 | 56.7 | 0.0 |
| ONE OBJECTIVE FORMULA | 4.7 | +13.3 | 0.0 | 0.0 | 6.0 | +6.8 | 0.0 | 125.3 |
| ONE PROMISE A TARGET | 0.7 | -5.7 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.7 | +26.5 | 0.0 | 0.0 |
| OVERRUNS AWAY | 1.0 | +3.2 | 235.3 | 0.0 | 0.3 | +3.8 | 0.0 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.7 | +7.2 | 0.0 | 0.0 |
| PLAN RESULT | 42.7 | +870.0 | 778.3 | 782.0 | 45.0 | +715.9 | 595.3 | 1547.3 |
| PROMISE BELOW ZERO | 0.7 | +0.0 | 0.0 | 28.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 10.7 | -272.4 | 0.0 | 174.0 | 10.7 | -215.7 | 0.0 | 0.0 |
| PROMISE IN STEPS | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 2.7 | -62.2 | 0.0 | 28.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.7 | -53.0 | 0.0 | 0.0 | 1.0 | -6.4 | 0.0 | 23.3 |
| QUARTER ODDS | 15.7 | +1275.2 | 458.7 | 117.3 | 16.7 | +2056.7 | 186.3 | 383.3 |
| RANDOM MOVE BY FIGURES | 1.3 | +0.4 | 0.0 | 113.3 | - | - | - | - |
| REAL GROUND | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 3.3 | +120.6 | 0.0 | 56.7 | 3.3 | +119.1 | 0.0 | 116.0 |
| REDIRECT FOR A FRIEND IN REACH | 2.3 | +0.0 | 0.0 | 85.0 | 5.0 | +0.0 | 0.0 | 116.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.7 | +34.2 | 103.3 | 0.0 |
| REFORMS TO MEET IT | 1.3 | -0.6 | 0.0 | 28.3 | 1.7 | -230.2 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 2.3 | +47.8 | 0.0 | 24.0 |
| RESERVE MOVE SPELL | 0.3 | +6.9 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.3 | +29.2 | 301.7 | 17.3 | 2.3 | +72.5 | 178.3 | 314.0 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.7 | -12.8 | 0.0 | 170.3 |
| RUN DOWN | 0.3 | -6.1 | 0.0 | 0.0 | 2.0 | -6.5 | 36.7 | 235.3 |
| SCOUT SPOT | - | - | - | - | 2.0 | +1.8 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 1.3 | -172.0 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 1.0 | +23.7 | 0.0 | 0.0 | 0.7 | +7.4 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +0.8 | 18.3 | 0.0 | 0.7 | +182.4 | 0.0 | 170.3 |
| SET CREDITED ONCE | 0.7 | -21.9 | 0.0 | 0.0 | 2.3 | -203.0 | 0.0 | 47.3 |
| SET UP BY THE SET | 1.7 | -3.5 | 0.0 | 0.0 | 4.7 | +197.2 | 0.0 | 47.3 |
| SET UP TOGETHER | - | - | - | - | 2.3 | +32.1 | 0.0 | 150.7 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 15.3 | +0.0 | 0.0 | 486.7 | 13.7 | +0.0 | 0.0 | 41.7 |
| SHOOTS FROM THE BEST SPOT | 3.3 | +115.5 | 46.7 | 0.0 | 1.3 | +12.4 | 56.7 | 0.0 |
| SHOT OR CHARGE | 0.3 | -2.5 | 65.0 | 0.0 | 1.7 | -23.8 | 56.7 | 0.0 |
| SHOT RISK POINTS | 26.0 | -204.9 | 0.0 | 230.7 | 30.3 | -217.4 | 0.0 | 904.0 |
| SHOTS AFTER THE MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.3 | +649.7 | 0.0 | 430.0 | 23.3 | +454.7 | 0.0 | 157.7 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | +1.8 | 28.3 | 0.0 |
| SPOT AS THE GAME MOVES | 8.3 | +0.0 | 0.0 | 132.7 | 5.0 | +0.0 | 0.0 | 88.3 |
| STAND AND SHOOT | 1.0 | -2.4 | 42.3 | 0.0 | 0.3 | -2.6 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 4.3 | +0.0 | 0.0 | 22.0 |
| STANDS STILL | 45.3 | +0.0 | 1242.3 | 1115.0 | 37.7 | +0.0 | 868.0 | 176.7 |
| STAY WORTH | 31.0 | -386.0 | 723.3 | 1106.7 | 39.7 | +431.1 | 637.3 | 125.0 |
| STRIKE BY THE ODDS | - | - | - | - | 2.0 | +67.5 | 0.0 | 208.7 |
| STUBBORN BY POINTS | 0.3 | +40.1 | 0.0 | 0.0 | - | - | - | - |
| STUCK PIVOT | 1.0 | +0.0 | 0.0 | 113.3 | - | - | - | - |
| SUPPORT ADDS | 10.0 | +648.0 | 0.0 | 174.0 | 3.7 | +86.4 | 0.0 | 48.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 18.3 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 10.0 | +648.0 | 0.0 | 174.0 | 3.7 | +86.4 | 0.0 | 48.0 |
| SURE REACH TOGETHER | 0.7 | +0.9 | 0.0 | 0.0 | 1.7 | +5.3 | 0.0 | 23.3 |
| SWIFTSTRIDE BY POINTS | 0.3 | +0.3 | 0.0 | 10.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | - | - | - | - | 3.7 | +0.0 | 0.0 | 87.0 |
| THE PROMISE ADDS | 1.0 | -64.0 | 0.0 | 0.0 | 1.0 | -46.3 | 0.0 | 23.3 |
| THE PROMISED MOVE | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 4.3 | +0.0 | 0.0 | 58.7 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 102.7 |
| THE ROW READS HIS LAST RUN | 0.3 | +0.0 | 0.0 | 28.3 | - | - | - | - |
| THE STEP BACK IS MADE | 2.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 46.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 42.3 | +0.0 | 0.0 | 630.3 | 47.3 | +0.0 | 0.0 | 628.7 |
| TIED UP BY THE SUM | 0.7 | +44.7 | 89.0 | 0.0 | 1.3 | +108.4 | 121.7 | 143.7 |
| TIME ON OUR SIDE | 21.0 | +291.1 | 0.0 | 85.0 | 15.7 | +187.6 | 0.0 | 315.0 |
| WAITS AGAIN | 4.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | 0.3 | +8.3 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 2.0 | +0.0 | 44.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | 0.7 | -2.4 | 340.7 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.7 | +1.6 | 24.0 | 0.0 | 1.0 | -4.9 | 0.0 | 0.0 |
| WHO HITS BACK | 0.3 | +110.0 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | 0.3 | +7.3 | 170.3 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 4.3 | -1186.6 | 0.0 | 113.3 | 1.0 | -42.0 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 1.0 | +45.9 | 56.7 | 0.0 |
| WOUNDS ON THE RANKS | 3.0 | +43.1 | 0.0 | 0.0 | 3.3 | +254.8 | 0.0 | 158.7 |

### Rule changes: gs3-83c8646-p14

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 287 | 270 | 78 | 26.00 | +1198 | +15.4 |
| ARMY TABLE | 90 | 90 | 69 | 23.00 | +1338 | +19.4 |
| HOLDER ASSIGNMENT | 67 | 67 | 63 | 21.00 | +3162 | +50.2 |
| LEGAL CHARGES ONLY | 51 | 51 | 51 | 17.00 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 290 | 278 | 49 | 16.33 | +398 | +8.1 |
| OFF BEST | 35 | 35 | 35 | 11.67 | -873 | -24.9 |
| MOVE TO CHARGE COMPUTED | 57 | 52 | 34 | 11.33 | +1208 | +35.5 |
| FIVE ACTION | 575 | 555 | 33 | 11.00 | +1308 | +39.6 |
| DEPLOY BY FIGURES | 49 | 49 | 32 | 10.67 | +405 | +12.6 |
| PROMISE BY ITS OWN SUM | 64 | 64 | 26 | 8.67 | -1464 | -56.3 |
| THE TABLE AGAIN | 36 | 36 | 25 | 8.33 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 39 | 38 | 23 | 7.67 | +1029 | +44.8 |
| GOAL WALK | 84 | 82 | 22 | 7.33 | +1333 | +60.6 |
| REDIRECT FOR A FRIEND IN REACH | 22 | 22 | 22 | 7.33 | +0 | +0.0 |
| SUPPORT ADDS | 41 | 37 | 19 | 6.33 | +591 | +31.1 |
| SUPPORT WORKED OUT | 41 | 37 | 19 | 6.33 | +591 | +31.1 |
| ARTILLERY RE-ROLL WEIGHED | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| TIME ON OUR SIDE | 110 | 84 | 15 | 5.00 | +107 | +7.1 |
| STAY WORTH | 212 | 191 | 12 | 4.00 | +95 | +7.9 |
| HARD STAY DROPPED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| QUARTER ODDS | 97 | 97 | 11 | 3.67 | +710 | +64.6 |
| COVER ONCE | 51 | 38 | 9 | 3.00 | +544 | +60.5 |
| FOUR ROUNDS | 23 | 21 | 9 | 3.00 | +656 | +72.9 |
| OGRE LOADER SECOND SHOT | 9 | 9 | 9 | 3.00 | +7 | +0.8 |
| SHOT RISK POINTS | 169 | 161 | 9 | 3.00 | +159 | +17.7 |
| CANNON PLANNED TARGET | 35 | 35 | 8 | 2.67 | -4 | -0.5 |
| JOINT CHARGE NOW | 8 | 8 | 8 | 2.67 | +104 | +13.0 |
| MOVE ORDER | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| MAX FOR POSITIONING | 28 | 22 | 7 | 2.33 | +11 | +1.5 |
| RESERVE FALL BACK | 7 | 7 | 7 | 2.33 | +143 | +20.5 |
| SET UP BY THE SET | 19 | 19 | 7 | 2.33 | +654 | +93.4 |
| SHOOTS FROM THE BEST SPOT | 14 | 14 | 7 | 2.33 | +24 | +3.4 |
| CANNON SIGHT KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| MEETS IN TIME | 15 | 15 | 6 | 2.00 | +516 | +86.1 |
| SCOUT WAITS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| STRIKE BY THE ODDS | 6 | 6 | 6 | 2.00 | +203 | +33.8 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| FEATURE BUFFS | 24 | 24 | 5 | 1.67 | +14 | +2.9 |
| LONE WIZARD KEPT IN | 5 | 5 | 5 | 1.67 | +288 | +57.5 |
| PROMISE KNOWS THE FIGHT | 12 | 10 | 5 | 1.67 | -186 | -37.3 |
| SHOTS AFTER THE MOVES | 26 | 26 | 5 | 1.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 4 | 4 | 4 | 1.33 | +1 | +0.1 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +928 | +232.0 |
| IDLE COST | 60 | 35 | 4 | 1.33 | +25 | +6.3 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +137 | +34.3 |
| REDIRECT COUNTER | 20 | 16 | 4 | 1.33 | +71 | +17.8 |
| RISK BY ARC | 14 | 13 | 4 | 1.33 | +73 | +18.1 |
| SEARCH SPOT | 5 | 5 | 4 | 1.33 | +94 | +23.4 |
| SHOTS IN THE MOVE | 119 | 88 | 4 | 1.33 | +125 | +31.2 |
| CHARGE NOW FIRST | 13 | 13 | 3 | 1.00 | -172 | -57.5 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +313 | +104.2 |
| MARCH OF THE TABLE | 3 | 3 | 3 | 1.00 | -15 | -5.1 |
| RANDOM MOVE BY FIGURES | 4 | 4 | 3 | 1.00 | +1 | +0.4 |
| SECOND LOOK | 3 | 3 | 3 | 1.00 | +549 | +183.1 |
| STUCK PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| TIED UP BY THE SUM | 6 | 5 | 3 | 1.00 | +109 | +36.5 |
| CAST JOB | 14 | 14 | 2 | 0.67 | +0 | +0.1 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | -2 | -0.9 |
| FALLS SHORT | 64 | 50 | 2 | 0.67 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.67 | +20 | +10.2 |
| GOAL ROUTE | 2 | 2 | 2 | 0.67 | +73 | +36.4 |
| HIS TURN DENIED | 5 | 5 | 2 | 0.67 | +27 | +13.6 |
| HONEST WORTH | 14 | 12 | 2 | 0.67 | +122 | +61.0 |
| KEEP FALLS | 2 | 2 | 2 | 0.67 | +114 | +57.2 |
| MISSILES IN THE MOVE | 19 | 12 | 2 | 0.67 | +38 | +19.1 |
| NEARER NOT NEEDED | 47 | 45 | 2 | 0.67 | +90 | +45.1 |
| ONE OBJECTIVE FORMULA | 32 | 25 | 2 | 0.67 | +82 | +41.1 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -17 | -8.5 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +22 | +10.9 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +235 | +117.4 |
| SUPPORT NARROWED | 2 | 2 | 2 | 0.67 | -30 | -14.8 |
| WHOLE FIGHT DANGER | 16 | 16 | 2 | 0.67 | +92 | +46.2 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +2 | +2.5 |
| CHARGE LOSSES | 128 | 124 | 1 | 0.33 | +134 | +134.4 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 15 | 13 | 1 | 0.33 | +4 | +4.3 |
| FIGHT TO THE END | 3 | 3 | 1 | 0.33 | +415 | +415.4 |
| HIS CHARGE DENIED | 2 | 2 | 1 | 0.33 | +115 | +114.7 |
| MANOEUVRE | 10 | 10 | 1 | 0.33 | +3 | +2.9 |
| MARCH CHECK | 2 | 1 | 1 | 0.33 | +24 | +24.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| NO DOUBLE ROUNDS | 19 | 17 | 1 | 0.33 | +30 | +29.7 |
| ONE FIGHT FORMULA | 47 | 31 | 1 | 0.33 | +0 | +0.5 |
| ONE JOINT FIGURE | 3 | 3 | 1 | 0.33 | +66 | +66.3 |
| OPENS UP | 2 | 1 | 1 | 0.33 | +31 | +30.7 |
| RESERVE MOVE SPELL | 1 | 1 | 1 | 0.33 | +22 | +21.8 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +4 | +4.0 |
| SPELLS IN THE FIGHT | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +120 | +120.4 |
| SURE REACH TOGETHER | 7 | 5 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +1 | +0.8 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +144 | +144.3 |
| WHOLE FIGHT | 1 | 1 | 1 | 0.33 | +13 | +12.9 |
| WHOLE FIGHT GAIN | 3 | 3 | 1 | 0.33 | +53 | +53.0 |
| BACKUP TARGETS | 2 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 48 | 48 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 2 | not checked | - | - | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 12 | 11 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 47 | not checked | - | - | - | - |
| FOOT FIRST | 96 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 23 | 20 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 9 | 9 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 10 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 16 | 12 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 75 | 72 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 43 | 41 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 25 | 22 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 19 | 19 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 17 | 17 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 52 | 47 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 29 | 25 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 1 | 1 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 125 | 125 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 20 | 20 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 9 | 8 | 0 | 0.00 | - | - |
| LOST CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 6 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 5 | trace | - | - | - | - |
| MARCH OVER CASTS | 6 | 6 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 7 | 7 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 27 | 15 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 1 | not checked | - | - | - | - |
| MOVE SPELL SPOT | 2 | not checked | - | - | - | - |
| NEAREST TO GOAL | 9 | 8 | 0 | 0.00 | - | - |
| NO LATE CUT | 6 | 6 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE ROUTE | 7 | 7 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 4 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 263 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 4 | 4 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 5 | 5 | 0 | 0.00 | - | - |
| REAL GROUND | 7 | 7 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 9 | 9 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 7 | 6 | 0 | 0.00 | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 9 | 9 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 7 | 4 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 87 | not checked | - | - | - | - |
| SHOT OR CHARGE | 6 | 5 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 40 | 32 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 13 | 13 | 0 | 0.00 | - | - |
| STANDS STILL | 249 | 241 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 11 | not checked | - | - | - | - |
| THE PROMISE ADDS | 6 | 5 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 3 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 19 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 17 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 1 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 11 | not checked | - | - | - | - |
| THE TABLE BINDS | 269 | not checked | - | - | - | - |
| WAITS AGAIN | 19 | 17 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 1 | 1 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 6 | 6 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 5 | 5 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 19 | 19 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p14

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.67 | 6.00 | 26.5 |
| PROMISE BY ITS OWN SUM | rule | 5.33 | 3.33 | 56.3 |
| ARMY TABLE | rule | 1.33 | 3.00 | 43.8 |
| HOLDER ASSIGNMENT | rule | - | 1.33 | 6.9 |
| PROMISE KNOWS THE FIGHT | rule | 1.33 | - | 46.6 |
| CHARGE NOW FIRST | rule | - | 1.00 | 57.5 |
| JOINT CHARGE NOW | rule | - | 1.00 | 75.7 |
| MARCH OF THE TABLE | rule | 1.00 | - | 5.1 |
| CHAFF PASSED | rule | 0.67 | - | 0.9 |
| ONE PROMISE A TARGET | rule | 0.67 | - | 8.5 |
| SUPPORT NARROWED | rule | 0.33 | 0.33 | 14.8 |
| AFTERMATH BAND | gate | 0.33 | - | 1.8 |
| CANNON PLANNED TARGET | rule | - | 0.33 | 4.0 |
| FIGHT ORDER BAND | gate | 0.33 | - | 1.2 |
| RULE SWITCHED OFF | gate | 0.33 | - | 23.4 |

### Plans: gs3-83c8646-p14

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 86% | 234 | 297 | 127% |
| Mine | move | 26.7 | 96% | 1202 | 0 | 0% |
| Mine | shoot | 13.0 | 49% | 637 | 573 | 90% |
| Mine | support | 0.7 | 50% | 0 | 0 | 0% |
| Opponent | charge | 3.7 | 45% | 606 | 287 | 47% |
| Opponent | move | 30.0 | 90% | 2546 | 0 | 0% |
| Opponent | shoot | 11.3 | 68% | 685 | 429 | 63% |

### Battle groups: gs3-83c8646-p14

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.3 | 10% | 100% | 0% | - | 100% | 0% | 0% | 0% | 0% |
| Opponent | REDIRECT COUNTER | 3.3 | 20% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p14

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Character | 7 | 78 (7) | 78 | 0 | 0 | 29% | 2.6 | 0 (1) | 0 (1) | 96 (5) | 88 (6) | 0 (1) |
| Mine | Clean-up | 4 | 32 (4) | 0 | 32 | 24 | 100% | - | 132 (1) | 0 (3) | - | 43 (3) | 0 (1) |
| Mine | Fast Hammer | 5 | 39 (5) | 39 | 0 | 68 | 60% | 3.0 | - | 81 (3) | 0 (2) | 26 (4) | 106 (1) |
| Mine | Hammer | 9 | 66 (9) | 55 | 11 | 20 | 11% | 2.6 | 0 (1) | 45 (4) | 112 (4) | 86 (7) | 11 (2) |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | War machine | 8 | 17 (8) | 17 | 0 | 59 | 0% | 1.0 | 0 (2) | 32 (5) | 0 (1) | 0 (3) | 27 (5) |
| Mine | Wizard | 5 | 16 (5) | 16 | 0 | 39 | 40% | 3.3 | 0 (1) | 41 (2) | 0 (2) | 0 (2) | 27 (3) |
| Opponent | Chaff | 5 | 9 (5) | 0 | 9 | 81 | 0% | 1.0 | 0 (1) | 11 (4) | - | 9 (5) | - |
| Opponent | Character | 8 | 31 (8) | 31 | 0 | 54 | 12% | 3.9 | 34 (3) | 21 (3) | 42 (2) | 38 (6) | 0 (2) |
| Opponent | Clean-up | 4 | 31 (4) | 0 | 31 | 77 | 75% | 6.0 | 0 (2) | 0 (1) | 63 (1) | 36 (3) | 0 (1) |
| Opponent | Fast Hammer | 6 | 0 (6) | 0 | 0 | 34 | 33% | 4.5 | 0 (3) | 0 (3) | - | 0 (2) | 0 (4) |
| Opponent | Holder | 9 | 120 (9) | 33 | 87 | 9 | 0% | 2.7 | 0 (3) | 232 (4) | 68 (2) | 266 (4) | 0 (5) |
| Opponent | Shooter | 2 | 113 (2) | 79 | 34 | 0 | 0% | 2.0 | 59 (1) | 171 (1) | - | 59 (1) | 171 (1) |
| Opponent | War machine | 3 | 29 (3) | 29 | 0 | 67 | 33% | 1.0 | 29 (3) | - | - | 0 (2) | 88 (1) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 0% | 1.0 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |

### Charged fights: gs3-83c8646-p14

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 144 | 558 | 4.0 | 1.0 | 140 | 13 | +126 | 1 of 4 | 4 of 4 | - | +126 |
| Mine | Chaos Dwarfs | 2 | 474 | 98 | 1.0 | 1.0 | 98 | 46 | +52 | 2 of 2 | 1 of 2 | - | +52 |
| **Mine** | all armies | 3 | 364 | 251 | 2.0 | 1.0 | 126 | 24 | +102 | 3 of 6 | 5 of 6 | - | +102 |
| Opponent | Empire of Man | 1 | 335 | 195 | 4.0 | 1.2 | 49 | 0 | +49 | 2 of 4 | 3 of 4 | +0 | +65 |
| Opponent | Tomb Kings of Khemri | 2 | 140 | 240 | 2.5 | 1.0 | 96 | 141 | -45 | 3 of 5 | 2 of 5 | - | -45 |
| **Opponent** | all armies | 3 | 205 | 225 | 3.0 | 1.1 | 75 | 78 | -3 | 5 of 9 | 5 of 9 | +0 | -4 |

### Effective charges: gs3-83c8646-p14

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 0 | 0 | 0 | 0 | 0 | 2 (net +10) | 2 | 0% (0 of 2) |
| Mine | Chaos Dwarfs | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +104) | 0 | 0% (0 of 2) |
| Opponent | Empire of Man | 4 | 1 (net +0) | 0 | 0 | 0 | 0 | 3 (net +65) | 0 | 0% (0 of 4) |
| Opponent | Tomb Kings of Khemri | 5 | 0 | 0 | 1 (net +310) | 0 | 0 | 1 (net +170) | 3 | 50% (1 of 2) |

### Charged fights, damage counted: gs3-83c8646-p14

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 310 | 431 | +0 | 0 | 44 | -44 | -14.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 138 | 107 | +41 | 134 | 67 | +67 | +48.8 |
| Mine | No odds | 2 | 162 | 243 | +243 | 246 | 0 | +246 | +151.5 |
| Mine | All fights | 6 | 175 | 206 | +102 | 149 | 41 | +108 | +61.9 |
| Opponent | Long shot (under 50%) | 1 | 110 | 314 | +0 | 26 | 44 | -18 | -16.2 |
| Opponent | Effective (55-75%) | 1 | 440 | 310 | +310 | 310 | 98 | +212 | +48.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 282 | 170 | +91 | 129 | 0 | +129 | +45.7 |
| Opponent | No odds | 3 | 339 | 238 | -235 | 9 | 235 | -227 | -66.9 |
| Opponent | All fights | 9 | 299 | 224 | -3 | 97 | 94 | +3 | +1.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p14 | move | 33 | 8 (24%) | 6 (18%) | 2 (6%) | 23 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Ring of Doom | Mine | L0222 |
| Twice-Blessed Armour | Opponent | L0307 |
| Witch Hunter's Ward | Opponent | L0307 |

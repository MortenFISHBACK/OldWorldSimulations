# Doctrine scorecard: gs3-83c8646-p83

### Scorecard: gs3-83c8646-p83

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2223 | 3 | 1 | Mine | no | 5 | 2 | 8 | 0 | 1 | 0 | 0 | 127 |
| L2223 | 3 | 1 | Opponent | yes | 0 | 3 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 5 | 1 | 1 | 0 | 0 | 72 |
| L2327 | 5 | 1 | Opponent | yes | - | 1 | 4 | 4 | 0 | 0 | 0 | 133 |
| L2433 | 3 | 1 | Mine | no | 8 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 6.5 | 2.3 | 5.7 | 0.7 | 0.7 | 0.0 | 0.0 | 66.3 |
| **Average** | | | Opponent | 67% | 0.0 | 2.0 | 4.3 | 2.7 | 0.0 | 0.0 | 0.0 | 44.3 |

### KPIs: gs3-83c8646-p83

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 17) | 33% (6 of 18) | 17% (6 of 35) |
| Winner chose to follow up after the loser gave ground |  | 100% (8 of 8); on the table 100% | 88% (7 of 8); on the table 88% | 94% (15 of 16); on the table 94% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | - | 0% (0 of 1); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 89% (8 of 9); on the table 89% | 88% (7 of 8); on the table 88% | 88% (15 of 17); on the table 88% |
| Magic missiles tried each own turn | 50%+ | 17% (1 of 6) | - | 17% (1 of 6) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 17% (1 of 6) | - | 17% (1 of 6) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 38% (1780 of 4626) | 29% (1716 of 6000) | 33% (3496 of 10626) |
|   infantry points that never fought | lower | 56% (522 of 932) | 47% (567 of 1219) | 51% (1089 of 2151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 62% (8 of 13) | 67% (14 of 21) | 65% (22 of 34) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (2 of 2); 2.7 uses a game | 100% (2 of 2); 1.3 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 51% (1874 of 3685) | 52% (2599 of 4954) | 52% (4473 of 8639) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (80%) | - | 1.3 (80%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.3 (20%) | - | 0.3 (20%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 14.0 | 0.3 | 2.7 | 0.3 | 1.0 | 0.3 |
| not cast | 4.0 | 1.7 | 1.3 | 1.7 | 1.0 | 23.7 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.7 (100%) | 0.3 (25%) | 1.3 (80%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.3 (8%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (7%) |
| OFF THE TABLE: off the table or not arrived | 0.7 (17%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (100%) | 1.7 (7%) |
| STUPIDITY: Stupidity | 0.3 (8%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (20%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.7 (67%) | 0.0 (0%) | 1.0 (75%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 20.0 (85%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 1.3 a game | 1.3 a game |
| stood (cast and not dispelled) | 100% (4 of 4) | 25% (1 of 4) | 62% (5 of 8) |
| the unit moved after it | 50% (2 of 4) | 100% (1 of 1) | 60% (3 of 5) |
| it charged on its next turn | 0% (0 of 4) | 0% (0 of 1) | 0% (0 of 5) |
| the enemy charged it first | 0% (0 of 4) | 0% (0 of 1) | 0% (0 of 5) |
| it fought by the end of its next turn | 0% (0 of 4) | 0% (0 of 1) | 0% (0 of 5) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 4) | 0% (0 of 1) | 0% (0 of 5) |
| none of these (no charge, no fight, no charge escaped) | 100% (4 of 4) | 100% (1 of 1) | 100% (5 of 5) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 54% (30 of 56) | 54% (37 of 68) | 54% (67 of 124) |
|   cavalry | 80% (8 of 10) | 54% (7 of 13) | 65% (15 of 23) |
|   character | 0% (0 of 15) | 22% (4 of 18) | 12% (4 of 33) |
|   chariot | 40% (2 of 5) | - | 40% (2 of 5) |
|   infantry | 77% (20 of 26) | 70% (26 of 37) | 73% (46 of 63) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.0 (0%) | 1.0 (10%) | 1.0 (5%) |
| CHARGED: it charged | 3.0 (35%) | 3.0 (29%) | 6.0 (32%) |
| IN COMBAT: it fought this turn or the last | 1.3 (15%) | 3.0 (29%) | 4.3 (23%) |
| NO TARGET IN RANGE | 1.7 (19%) | 2.0 (19%) | 3.7 (19%) |
| ONLY IN COMBAT: the only targets were in combat | 1.3 (15%) | 0.7 (6%) | 2.0 (11%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (15%) | 0.7 (6%) | 2.0 (11%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 8.3 | 1.3 | 88% | 0.7 pts | 6 pts |
| character | 1.3 | 0.3 | 75% | 8.1 pts | 11 pts |
| chariot | 0.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 29.0 | 9.0 | 82% | 8.0 pts | 231 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.7 | 7.3 | 6.0 |
| Charges that made contact a game | 3.3 | 6.7 | 5.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | - | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.75 declared, 0.75 contact (4 units) | 0.60 declared, 0.60 contact (5 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.70 declared, 0.50 contact (20 units) | 0.70 declared, 0.63 contact (27 units) | 0.70 declared, 0.57 contact (47 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 60% (3 of 5) | 100% (1 of 1) | 100% (1 of 1) | 71% (5 of 7) |
| Character in a unit | 100% (2 of 2) | - | 0% (0 of 1) | 67% (2 of 3) |
| Character on its own | 100% (3 of 3) | 50% (1 of 2) | 14% (1 of 7) | 42% (5 of 12) |
| Infantry | 100% (2 of 2) | 60% (3 of 5) | - | 71% (5 of 7) |
| Monster | 100% (4 of 4) | - | - | 100% (4 of 4) |
| Monstrous | 100% (1 of 1) | - | - | 100% (1 of 1) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Tomb Kings of Khemri | 3 | 100% (6 of 6); on the table 100% | - | 24% | 64% (7 of 11) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 2 | 86% (6 of 7); on the table 86% | 17% (1 of 6) | 42% | 54% (7 of 13) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 75% (3 of 4); on the table 75% | - | 35% | 80% (8 of 10) | 100% (2 of 2); 8.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p83, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 56% (5) | 80% (4) | 64% (9) |
| ...free all their last turn and able to turn (per game) | 1.33 | 1.33 | 2.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 1.00 | 1.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.33 | 0.67 |

### Quality by phase: gs3-83c8646-p83

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 67% (12 of 18) | 86% (12 of 14) |
| Strategy | Shoot objectives carried out (shot that target) | 47% (8 of 17) | 70% (7 of 10) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 1) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 2) | 40% (2 of 5) |
| Strategy | Lone characters that fought | 71% (5 of 7) | 75% (6 of 8) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 0.7 | 2.7 |
| Movement | Points that never moved of their own | 66.3 | 44.3 |
| Movement | Fights charged into per game | 4.3 | 5.0 |
| Movement | Charges with odds: long shots (under 50%) | 3 of 11, net +201 | 1 of 12, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 11 | 3 of 12, net +87 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 5 of 11, net +78 | 3 of 12, net +43 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 11, net +221 | 3 of 12, net +65 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.3 | 19.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 56% (19 of 34) | 24% (14 of 58) |
| Shooting | Points destroyed by shooting units | 80.0 | 24.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Wounds caused by magic missiles | 0.7 | - |
| Magic | Wounds caused by other spells | - | 0.3 |
| Magic | Points destroyed by magic (all spells) | 6.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 5.7 / 0.3 / 0.0 / 0.0 | 4.0 / 0.0 / 0.3 / 1.0 |
| Combat | Points destroyed in combat | 614.0 | 304.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +142 | +62 |
| Combat | Net per 100 charger points, damage counted | +48.5 | +28.5 |
| Combat | First round won (charged fights) | 92% | 87% |
| Combat | Net points per charged fight | +132 | +57 |
| Combat | Net points per supported fight / lone fight | - / +132 | +128 / +46 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 13 | 4 of 15 |
| Game | Points lost | 483.3 | 764.3 |
| Game | VP from objectives | 650.0 | 500.0 |
| Game | Lone holders (player turns) | 6.5 | 0.0 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +510 VP
- The side that went first won 2 of 2 games with a winner
- Points traded per game (both sides' losses): 1248
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: gs3-83c8646-p83

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +38.4 | 0.0 | 65.0 | - | - | - | - |
| ARMY TABLE | 18.3 | +142.6 | 0.0 | 237.3 | 27.0 | -420.8 | 0.0 | 367.3 |
| ASSAILMENT BY POINTS | - | - | - | - | 0.3 | +1.6 | 0.0 | 63.3 |
| BACKUP TARGETS | 0.7 | +0.8 | 0.0 | 65.0 | 0.7 | +2.8 | 0.0 | 65.0 |
| BLOWS WHERE AIMED | 0.3 | -102.1 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 0.7 | +35.9 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.3 | +19.3 | 0.0 | 20.0 | 2.0 | +282.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +15.7 | 0.0 | 16.7 | 0.7 | +26.3 | 0.0 | 16.7 |
| CHARACTER GUNS | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 16.7 | -436.0 | 0.0 | 260.0 | 18.0 | -692.2 | 0.0 | 431.7 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 150.7 | 65.0 | 1.3 | +0.0 | 65.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 12.3 | +0.0 | 0.0 | 63.3 | 8.7 | +0.0 | 0.0 | 46.7 |
| COMBAT PIVOT | 1.0 | +0.0 | 0.0 | 65.0 | 1.0 | +0.0 | 18.3 | 65.0 |
| CONTINUE AHEAD WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 1.3 | +55.9 | 0.0 | 0.0 | 1.0 | +69.0 | 77.7 | 0.0 |
| COVER ONCE | 8.3 | -314.7 | 0.0 | 222.0 | 6.0 | -347.3 | 0.0 | 233.3 |
| DEFENSIVE ARMY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 7.0 | +1.1 | 0.0 | 65.0 | 7.7 | -34.6 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -34.3 | 143.3 | 0.0 | 0.3 | -17.3 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +8.0 | 0.0 | 0.0 | 0.7 | +30.8 | 0.0 | 0.0 |
| EXACT ROUND | 4.7 | -40.3 | 291.3 | 65.0 | 3.3 | -21.7 | 191.7 | 16.7 |
| FALL BACK GOOD ORDER | 4.0 | +0.0 | 294.0 | 81.7 | 2.7 | +0.0 | 101.7 | 16.7 |
| FALLS SHORT | 9.0 | +73.8 | 0.0 | 127.3 | 10.7 | +118.2 | 0.0 | 129.0 |
| FEATURE BUFFS | - | - | - | - | 0.3 | +2.1 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.7 | +125.7 | 0.0 | 16.7 | 1.3 | +62.4 | 130.0 | 0.0 |
| FIVE ACTION | 84.3 | +6484.5 | 1309.7 | 1240.3 | 85.3 | +4774.6 | 384.7 | 1102.7 |
| FLANK NOT WEIGHED | 6.7 | +0.0 | 0.0 | 153.3 | 8.7 | +0.0 | 0.0 | 278.7 |
| FOLLOW UP WEIGHED | 2.3 | +433.8 | 0.0 | 65.0 | 1.0 | +270.1 | 0.0 | 78.7 |
| FOOT FIRST | 33.7 | +0.0 | 0.0 | 295.7 | - | - | - | - |
| FOUR ROUNDS | 6.3 | +664.1 | 454.7 | 81.7 | 4.7 | +300.6 | 231.7 | 16.7 |
| FREED FROM HIS FIGHT | 2.7 | +0.0 | 0.0 | 23.3 | 7.3 | +0.0 | 0.0 | 211.0 |
| GIVES UP | 1.3 | -33.3 | 143.3 | 0.0 | 0.7 | -2.8 | 20.0 | 0.0 |
| GOAL WALK | 7.7 | +770.7 | 0.0 | 130.0 | 7.7 | +483.6 | 0.0 | 65.0 |
| HARD STAY DROPPED | 4.0 | +0.0 | 0.0 | 82.3 | 1.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 124.0 |
| HIS CHARGE BY HIS RUN | 9.7 | +0.0 | 0.0 | 260.0 | 12.7 | +0.0 | 0.0 | 320.0 |
| HIS CHARGE DENIED | 0.7 | +39.9 | 62.0 | 0.0 | 1.3 | +39.9 | 130.0 | 16.7 |
| HIS CHARGE LIST | 4.0 | +0.0 | 0.0 | 43.3 | 8.3 | +0.0 | 0.0 | 235.0 |
| HIS LEGAL MOVES | 5.7 | +0.0 | 0.0 | 299.3 | 4.7 | +0.0 | 0.0 | 130.0 |
| HIS MOVE AND SHOT | 3.3 | -19.4 | 0.0 | 0.0 | 5.3 | -38.6 | 0.0 | 239.0 |
| HIS ONE QUARTER | 6.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 10.3 | +0.0 | 0.0 | 536.7 | 8.0 | +0.0 | 0.0 | 192.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 31.0 | +793.4 | 0.0 | 558.7 | 37.3 | +596.1 | 0.0 | 716.7 |
| HIS SHOTS BY HIS RUN | 33.3 | +655.7 | 0.0 | 583.3 | 33.0 | +182.9 | 0.0 | 784.7 |
| HIS TURN DENIED | 0.7 | +25.7 | 0.0 | 16.7 | 1.7 | +8.0 | 38.3 | 0.0 |
| HOLD ODDS | 14.3 | +0.0 | 0.0 | 84.0 | 12.7 | +0.0 | 0.0 | 220.0 |
| HOLDER ASSIGNMENT | 9.0 | +568.2 | 0.0 | 62.0 | 8.3 | +509.1 | 0.0 | 140.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 6.3 | -287.2 | 454.7 | 81.7 | 4.3 | -164.2 | 231.7 | 16.7 |
| HORN WORTH | - | - | - | - | 0.3 | +1.2 | 0.0 | 0.0 |
| HUNT IN PAIRS | 1.7 | +60.5 | 0.0 | 65.0 | - | - | - | - |
| IDLE COST | 4.0 | -75.8 | 0.0 | 0.0 | 9.3 | -117.8 | 0.0 | 103.3 |
| JOINT CHARGE NOW | 0.3 | -32.7 | 143.3 | 0.0 | 1.0 | -14.8 | 105.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 160.0 |
| LANE BY FIGURES | 1.0 | +25.1 | 0.0 | 0.0 | - | - | - | - |
| LATE ONLY FROM HERE | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 24.7 | +0.0 | 933.7 | 1469.0 | 13.0 | +0.0 | 429.3 | 968.7 |
| LONE WIZARD KEPT IN | 1.0 | +19.6 | 0.0 | 0.0 | 0.3 | +7.5 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +0.2 | 0.0 | 16.7 | - | - | - | - |
| LOST AFTER ESCAPE | 1.0 | +0.3 | 0.0 | 16.7 | - | - | - | - |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MANOEUVRE | 0.7 | +1.0 | 0.0 | 0.0 | 1.3 | +0.3 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 1.0 | +52.9 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +32.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | -17.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.7 | +78.0 | 0.0 | 130.0 | 1.3 | +12.8 | 0.0 | 0.0 |
| MEETS IN TIME | 3.7 | +86.8 | 0.0 | 65.0 | 4.0 | +290.1 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 0.3 | +17.9 | 0.0 | 0.0 | 3.0 | +21.3 | 0.0 | 36.0 |
| MISSILES NEXT TURN | 1.7 | +30.1 | 0.0 | 0.0 | 2.7 | +23.6 | 0.0 | 36.0 |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 65.0 | 85.3 |
| MOVE SPELL SPOT | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 8.0 | +686.9 | 0.0 | 474.7 | 7.0 | +407.9 | 0.0 | 254.0 |
| NEARER NOT NEEDED | 14.3 | +647.6 | 0.0 | 102.3 | 5.7 | +169.7 | 0.0 | 42.0 |
| NEAREST TO GOAL | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 5.3 | +455.9 | 0.0 | 421.0 | 5.7 | +350.2 | 0.0 | 254.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -0.1 | 0.0 | 20.0 |
| NO DOUBLE ROUNDS | 5.0 | -109.0 | 311.3 | 81.7 | 3.7 | -108.0 | 166.7 | 0.0 |
| NO LATE CUT | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 72.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +28.6 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 1.3 | -1.3 | 0.0 | 0.0 |
| OFF BEST | 3.0 | -86.4 | 0.0 | 0.0 | 4.7 | -74.7 | 0.0 | 43.3 |
| ONE FIGHT FORMULA | 5.3 | -88.3 | 0.0 | 302.3 | 4.7 | -89.9 | 0.0 | 127.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | +14.1 | 65.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 5.7 | -110.0 | 0.0 | 62.0 | 2.7 | -74.3 | 0.0 | 40.0 |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 2.0 | +131.9 | 65.3 | 0.0 | 0.7 | +22.4 | 43.3 | 0.0 |
| OVERRUNS AWAY | 1.0 | +110.7 | 142.0 | 0.0 | 1.0 | +4.0 | 43.3 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -3.7 | 0.0 | 0.0 |
| PLAN RESULT | 40.7 | +697.0 | 267.0 | 666.3 | 43.3 | +569.8 | 109.0 | 1026.7 |
| PROMISE BELOW ZERO | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 65.0 |
| PROMISE BY ITS OWN SUM | 12.0 | -394.6 | 0.0 | 53.7 | 8.7 | -112.4 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.0 | +0.0 | 0.0 | 53.7 | 1.0 | +0.0 | 0.0 | 62.0 |
| PROMISE READS THE TABLE | 0.3 | -3.4 | 0.0 | 0.0 | 0.3 | -14.2 | 0.0 | 0.0 |
| QUARTER ODDS | 18.0 | +2950.7 | 93.7 | 48.0 | 23.0 | +2158.0 | 40.0 | 170.0 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.3 | +38.7 | 0.0 | 20.0 | 0.3 | -5.3 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.7 | +49.2 | 0.0 | 64.0 | 4.7 | -1.5 | 0.0 | 65.3 |
| REDIRECT FOR A FRIEND IN REACH | 2.3 | +49.5 | 0.0 | 86.0 | 2.7 | +0.0 | 0.0 | 28.3 |
| REFORMS TO MEET IT | 3.0 | -40.8 | 0.0 | 130.0 | 1.7 | -43.2 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 16.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 1.3 | +58.9 | 0.0 | 0.0 | 0.7 | -2.0 | 0.0 | 44.0 |
| RISK BY ARC | 5.0 | -138.9 | 311.3 | 81.7 | 3.0 | -39.7 | 191.7 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.3 | -3.1 | 0.0 | 16.7 | - | - | - | - |
| RUN DOWN | 1.3 | -1.1 | 142.0 | 16.7 | - | - | - | - |
| SCOUT SPOT | 1.3 | +0.5 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -27.7 | 0.0 | 0.0 |
| SEARCH SPOT | - | - | - | - | 0.7 | -0.9 | 0.0 | 20.0 |
| SECOND LOOK | 0.3 | +18.1 | 22.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 1.0 | -8.0 | 0.0 | 40.0 | 5.0 | -282.4 | 0.0 | 0.0 |
| SET UP BY THE SET | 2.0 | +166.0 | 0.0 | 40.0 | 6.3 | +67.2 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.3 | +108.5 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.3 | +1.3 | 0.0 | 0.0 | 0.3 | +1.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 5.3 | +0.0 | 0.0 | 80.3 | 3.7 | +0.0 | 0.0 | 62.0 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +19.9 | 0.0 | 0.0 | 1.0 | +9.7 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.7 | -9.0 | 0.0 | 0.0 |
| SHOT RISK POINTS | 24.7 | -211.4 | 0.0 | 650.7 | 23.7 | -111.5 | 0.0 | 595.7 |
| SHOTS AFTER THE MOVES | 2.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.0 | +117.4 | 0.0 | 184.3 | 10.3 | +127.4 | 0.0 | 162.0 |
| SPELL SETS UP CHARGE | 0.3 | +108.5 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 4.0 | +53.9 | 0.0 | 0.0 | 3.3 | +10.8 | 0.0 | 78.0 |
| SPELLS IN THE FIGHT | 0.3 | -0.9 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 6.3 | +0.0 | 0.0 | 138.7 | 9.7 | +0.0 | 0.0 | 349.0 |
| STAND AND SHOOT | 1.7 | -3.0 | 84.0 | 65.0 | 1.0 | -2.2 | 40.0 | 0.0 |
| STANDS FOR A REASON | 0.7 | +0.0 | 130.0 | 44.0 | 0.7 | +0.0 | 0.0 | 44.0 |
| STANDS STILL | 32.0 | +0.0 | 855.0 | 295.3 | 23.3 | +0.0 | 153.0 | 206.0 |
| STAY WORTH | 11.3 | +0.8 | 275.0 | 62.0 | 9.7 | +125.8 | 88.0 | 102.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 8.3 | +479.1 | 0.0 | 153.3 | 5.7 | +440.4 | 0.0 | 63.3 |
| SUPPORT NARROWED | 0.3 | +0.0 | 63.3 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 8.3 | +479.1 | 0.0 | 153.3 | 5.7 | +440.4 | 0.0 | 63.3 |
| SURE REACH TOGETHER | 0.7 | +6.0 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.7 | -5.7 | 0.0 | 53.7 | 0.3 | -14.2 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 65.0 | 65.0 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 23.3 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 77.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 37.7 | +0.0 | 0.0 | 537.3 | 41.3 | +0.0 | 0.0 | 535.3 |
| TIED UP BY THE SUM | 3.0 | +317.8 | 170.7 | 65.0 | 1.7 | +215.0 | 108.3 | 0.0 |
| TIME ON OUR SIDE | 31.0 | +254.6 | 0.0 | 538.7 | 19.7 | +194.9 | 0.0 | 338.0 |
| WAITS AGAIN | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| WEAPON BY POINTS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.3 | +0.6 | 0.0 | 0.0 | 1.3 | +8.8 | 0.0 | 0.0 |
| WHO HITS BACK | 1.3 | +181.3 | 0.0 | 65.0 | 0.3 | +58.6 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.0 | -175.9 | 0.0 | 0.0 | 4.3 | -509.8 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | 0.3 | +32.7 | 143.3 | 0.0 | 0.3 | +4.1 | 65.0 | 0.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 2.7 | +9.3 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p83

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| LEGAL CHARGES ONLY | 113 | 113 | 113 | 37.67 | +0 | +0.0 |
| ARMY TABLE | 136 | 136 | 88 | 29.33 | -188 | -2.1 |
| HOLDER ASSIGNMENT | 52 | 52 | 46 | 15.33 | +1662 | +36.1 |
| FIVE ACTION | 509 | 493 | 40 | 13.33 | +2143 | +53.6 |
| THE TABLE AGAIN | 36 | 36 | 25 | 8.33 | +0 | +0.0 |
| OFF BEST | 23 | 23 | 23 | 7.67 | -484 | -21.0 |
| PROMISE BY ITS OWN SUM | 62 | 62 | 22 | 7.33 | -1521 | -69.1 |
| SUPPORT ADDS | 42 | 41 | 22 | 7.33 | +636 | +28.9 |
| SUPPORT WORKED OUT | 42 | 41 | 22 | 7.33 | +636 | +28.9 |
| QUARTER ODDS | 123 | 122 | 21 | 7.00 | +1844 | +87.8 |
| GOAL WALK | 46 | 45 | 19 | 6.33 | +1015 | +53.4 |
| FOUR ROUNDS | 33 | 33 | 18 | 6.00 | +1111 | +61.7 |
| HARD STAY DROPPED | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| DEPLOY BY FIGURES | 44 | 44 | 16 | 5.33 | +134 | +8.4 |
| HIS SHOTS BY HIS RUN | 199 | 189 | 16 | 5.33 | +132 | +8.3 |
| TIME ON OUR SIDE | 152 | 130 | 16 | 5.33 | +66 | +4.2 |
| HIS SHOT LIST | 205 | 195 | 15 | 5.00 | +155 | +10.3 |
| REDIRECT FOR A FRIEND IN REACH | 15 | 15 | 14 | 4.67 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 45 | 37 | 13 | 4.33 | +504 | +38.8 |
| TIED UP BY THE SUM | 14 | 14 | 11 | 3.67 | +538 | +48.9 |
| FOLLOW UP WEIGHED | 10 | 10 | 10 | 3.33 | +2112 | +211.2 |
| MEETS IN TIME | 23 | 23 | 9 | 3.00 | +517 | +57.5 |
| CHARGE LOSSES | 104 | 98 | 8 | 2.67 | +627 | +78.4 |
| SHOT RISK POINTS | 145 | 137 | 8 | 2.67 | +74 | +9.2 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| COMBAT PIVOT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| IDLE COST | 40 | 21 | 6 | 2.00 | +22 | +3.7 |
| MOVE ORDER | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 33 | 28 | 6 | 2.00 | +360 | +59.9 |
| RESERVE FALL BACK | 6 | 6 | 6 | 2.00 | +171 | +28.4 |
| SCOUT WAITS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| STAY WORTH | 63 | 56 | 6 | 2.00 | +55 | +9.1 |
| NEARER NOT NEEDED | 60 | 57 | 5 | 1.67 | +129 | +25.7 |
| SHOOTS FROM THE BEST SPOT | 6 | 6 | 5 | 1.67 | +30 | +6.0 |
| WHO HITS BACK | 5 | 5 | 5 | 1.67 | +442 | +88.4 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | -142 | -35.6 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +81 | +20.3 |
| OPENS UP | 8 | 8 | 4 | 1.33 | +48 | +11.9 |
| REDIRECT COUNTER | 22 | 15 | 4 | 1.33 | +103 | +25.8 |
| RISK BY ARC | 24 | 24 | 4 | 1.33 | +201 | +50.3 |
| SET UP BY THE SET | 25 | 25 | 4 | 1.33 | +287 | +71.8 |
| WHOLE FIGHT DANGER | 19 | 19 | 4 | 1.33 | +250 | +62.5 |
| CASTS FROM BEHIND | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +126 | +42.0 |
| CHARGE NOW FIRST | 10 | 10 | 3 | 1.00 | -153 | -51.0 |
| COVER ONCE | 43 | 27 | 3 | 1.00 | +5 | +1.6 |
| LANE BY FIGURES | 3 | 3 | 3 | 1.00 | +75 | +25.1 |
| MARCH CHECK | 3 | 3 | 3 | 1.00 | +48 | +16.0 |
| FALLS SHORT | 59 | 47 | 2 | 0.67 | +21 | +10.4 |
| FIGHT TO THE END | 9 | 9 | 2 | 0.67 | +99 | +49.6 |
| HONEST WORTH | 32 | 32 | 2 | 0.67 | +44 | +21.9 |
| MANOEUVRE | 6 | 6 | 2 | 0.67 | +8 | +4.0 |
| MAX FOR POSITIONING | 15 | 13 | 2 | 0.67 | +3 | +1.6 |
| NO DOUBLE ROUNDS | 26 | 26 | 2 | 0.67 | +15 | +7.3 |
| REFUSING RETIRES | 6 | 6 | 2 | 0.67 | +85 | +42.3 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +9 | +4.5 |
| THE ROW IN ITS ORDER | 10 | 2 | 2 | 0.67 | +0 | +0.0 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +115 | +115.3 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +5 | +4.7 |
| CAST JOB | 2 | 2 | 1 | 0.33 | +21 | +21.0 |
| CHAFF IN THE MOVE | 7 | 4 | 1 | 0.33 | +0 | +0.0 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 3 | 3 | 1 | 0.33 | +2 | +1.7 |
| EXACT ROUND | 24 | 24 | 1 | 0.33 | +1 | +0.8 |
| HIS CHARGE DENIED | 6 | 6 | 1 | 0.33 | +20 | +20.5 |
| HIS MOVE AND SHOT | 26 | 25 | 1 | 0.33 | +6 | +6.3 |
| HIS TURN DENIED | 7 | 7 | 1 | 0.33 | +2 | +1.7 |
| HORN WORTH | 1 | 1 | 1 | 0.33 | +4 | +3.6 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -98 | -98.4 |
| ONE OBJECTIVE FORMULA | 25 | 18 | 1 | 0.33 | +5 | +4.7 |
| OVERRUNS AWAY | 6 | 6 | 1 | 0.33 | +82 | +82.4 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -11 | -11.1 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +5 | +5.0 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +54 | +54.2 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| BACKUP TARGETS | 4 | 4 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 5 | trace | - | - | - | - |
| CHARACTER GUNS | 8 | 8 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 63 | 62 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 7 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 20 | 20 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 46 | not checked | - | - | - | - |
| FOOT FIRST | 101 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 30 | 29 | 0 | 0.00 | - | - |
| GIVES UP | 6 | 6 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 18 | 18 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 67 | 65 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 37 | 35 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 31 | 30 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 30 | 30 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 55 | 49 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 81 | 81 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 5 | 2 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 24 | 24 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 3 | 3 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 3 | 3 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 10 | 10 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 10 | 6 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 13 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NEAREST TO GOAL | 2 | 2 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO LATE CUT | 12 | 12 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 30 | 10 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 2 | 2 | 0 | 0.00 | - | - |
| ONE ROUTE | 10 | 10 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 252 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 6 | 4 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 10 | 10 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 14 | 12 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 4 | 4 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 4 | 4 | 0 | 0.00 | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 18 | 18 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 27 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 14 | 14 | 0 | 0.00 | - | - |
| SHOTS IN THE MOVE | 79 | 62 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 22 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 48 | 42 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 8 | 8 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 4 | 4 | 0 | 0.00 | - | - |
| STANDS STILL | 166 | 159 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 3 | 1 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 3 | not checked | - | - | - | - |
| THE PROMISE ADDS | 3 | 2 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 15 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 15 | not checked | - | - | - | - |
| THE TABLE BINDS | 237 | not checked | - | - | - | - |
| WAITS AGAIN | 9 | 7 | 0 | 0.00 | - | - |
| WHO FIGHTS | 5 | 5 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 2 | 2 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 8 | 8 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p83

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.00 | 4.33 | 21.9 |
| PROMISE BY ITS OWN SUM | rule | 5.00 | 2.33 | 69.1 |
| ARMY TABLE | rule | 1.33 | 5.67 | 86.7 |
| CHARGE NOW FIRST | rule | 1.00 | - | 51.0 |
| JOINT CHARGE NOW | rule | 0.33 | 0.67 | 51.7 |
| HOLDER ASSIGNMENT | rule | - | 0.67 | 21.0 |
| MARCH OF THE TABLE | rule | 0.33 | - | 98.4 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 11.1 |
| REFUSING RETIRES | rule | - | 0.33 | 12.2 |
| RESERVE FALL BACK | rule | - | 0.33 | 14.5 |
| RULE SWITCHED OFF | gate | - | 0.33 | 1.0 |

### Plans: gs3-83c8646-p83

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 5.0 | 60% | 715 | 254 | 36% |
| Mine | join | 0.7 | 100% | 41 | 0 | 0% |
| Mine | move | 29.7 | 92% | 1788 | 0 | 0% |
| Mine | shoot | 5.0 | 67% | 163 | 442 | 272% |
| Mine | support | 0.3 | 0% | 49 | 0 | 0% |
| Opponent | charge | 4.0 | 92% | 353 | 384 | 109% |
| Opponent | join | 2.3 | 86% | 94 | 0 | 0% |
| Opponent | move | 33.0 | 93% | 1716 | 0 | 0% |
| Opponent | shoot | 3.0 | 67% | 172 | 185 | 108% |
| Opponent | support | 1.0 | 100% | 59 | 0 | 0% |

### Battle groups: gs3-83c8646-p83

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.7 | 25% | 100% | 50% | 0% | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 4.7 | 21% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p83

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 5 | 94 (5) | 20 | 74 | 61 | 0% | 1.2 | 232 (2) | - | 0 (3) | 232 (2) | 0 (3) |
| Mine | Character | 7 | 72 (7) | 72 | 0 | 2 | 14% | 2.5 | 19 (4) | 171 (3) | - | 27 (3) | 108 (4) |
| Mine | Clean-up | 4 | 41 (4) | 0 | 41 | 12 | 50% | 4.0 | 0 (2) | 55 (2) | - | 87 (2) | 0 (2) |
| Mine | Fast Hammer | 4 | 0 (4) | 0 | 0 | 62 | 25% | 1.3 | 0 (1) | 0 (2) | 0 (1) | 0 (2) | 0 (2) |
| Mine | Holder | 4 | 18 (4) | 18 | 0 | 47 | 0% | 1.8 | 0 (1) | 34 (2) | 0 (1) | 0 (1) | 24 (3) |
| Mine | Shooter | 1 | 0 (1) | 0 | 0 | 0 | 0% | 3.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | - | - | 0 (2) | - |
| Opponent | Chaff | 8 | 31 (8) | 16 | 15 | 48 | 62% | 1.3 | 53 (3) | 0 (2) | 40 (3) | 53 (3) | 21 (5) |
| Opponent | Character | 10 | 33 (10) | 33 | 0 | 28 | 10% | 2.0 | 37 (4) | 20 (4) | 62 (1) | 31 (7) | 45 (2) |
| Opponent | Fast Hammer | 9 | 27 (9) | 27 | 0 | 79 | 11% | 2.6 | 33 (3) | 35 (4) | 0 (2) | 33 (3) | 23 (6) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 0 | 33% | 2.0 | 0 (2) | 0 (1) | - | 0 (2) | 0 (1) |
| Opponent | Holder | 1 | 333 (1) | 0 | 333 | 0 | 0% | 1.0 | 333 (1) | - | - | - | 333 (1) |
| Opponent | Shooter | 4 | 59 (4) | 11 | 48 | 63 | 0% | 1.0 | 76 (1) | 125 (2) | 0 (1) | 101 (2) | 11 (2) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | 0 (1) | - | 0 (2) | 0 (1) |

### Charged fights: gs3-83c8646-p83

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Tomb Kings of Khemri | 2 | 120 | 678 | 4.0 | 1.0 | 170 | 0 | +170 | 1 of 8 | 8 of 8 | - | +170 |
| Mine | Vampire Counts | 1 | 19 | 426 | 5.0 | 1.0 | 85 | 12 | +73 | 2 of 5 | 4 of 5 | - | +73 |
| **Mine** | all armies | 3 | 86 | 594 | 4.3 | 1.0 | 137 | 5 | +132 | 3 of 13 | 12 of 13 | - | +132 |
| Opponent | Tomb Kings of Khemri | 1 | 72 | 55 | 5.0 | 1.0 | 11 | 0 | +11 | 1 of 5 | 5 of 5 | - | +11 |
| Opponent | Vampire Counts | 1 | 0 | 586 | 6.0 | 1.3 | 98 | 0 | +98 | 3 of 6 | 4 of 6 | +128 | +83 |
| Opponent | Wood Elf Realms | 1 | 0 | 211 | 4.0 | 1.0 | 53 | 0 | +53 | 0 of 4 | 4 of 4 | - | +53 |
| **Opponent** | all armies | 3 | 24 | 284 | 5.0 | 1.1 | 57 | 0 | +57 | 4 of 15 | 13 of 15 | +128 | +46 |

### Effective charges: gs3-83c8646-p83

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Tomb Kings of Khemri | 8 | 1 (net +663) | 0 | 0 | 0 | 5 (net +78) | 1 (net +236) | 1 | 0% (0 of 7) |
| Mine | Vampire Counts | 5 | 2 (net -30) | 0 | 0 | 0 | 0 | 2 (net +213) | 1 | 0% (0 of 4) |
| Opponent | Tomb Kings of Khemri | 5 | 0 | 0 | 0 | 2 (net +28) | 1 (net +0) | 2 (net +0) | 0 | 0% (0 of 5) |
| Opponent | Vampire Counts | 6 | 1 (net +0) | 0 | 2 (net +130) | 0 | 2 (net +65) | 1 (net +195) | 0 | 33% (2 of 6) |
| Opponent | Wood Elf Realms | 4 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 3 | 100% (1 of 1) |

### Charged fights, damage counted: gs3-83c8646-p83

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 3 | 183 | 240 | +201 | 247 | 23 | +224 | +122.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 337 | 204 | +221 | 221 | 0 | +221 | +65.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 376 | 66 | +78 | 89 | 0 | +89 | +23.7 |
| Mine | No odds | 2 | 178 | 145 | +33 | 43 | 12 | +31 | +17.5 |
| Mine | All fights | 13 | 292 | 150 | +132 | 149 | 7 | +142 | +48.5 |
| Opponent | Long shot (under 50%) | 1 | 50 | 431 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Effective (55-75%) | 3 | 77 | 165 | +87 | 134 | 8 | +126 | +164.3 |
| Opponent | 76-89% | 2 | 70 | 58 | +28 | 28 | 18 | +10 | +14.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 341 | 152 | +65 | 65 | 4 | +61 | +18.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 523 | 63 | +43 | 43 | 0 | +43 | +8.3 |
| Opponent | No odds | 3 | 79 | 90 | +70 | 70 | 0 | +70 | +89.4 |
| Opponent | All fights | 15 | 216 | 131 | +57 | 66 | 5 | +62 | +28.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p83 | move | 26 | 4 (15%) | 3 (12%) | 4 (15%) | 18 (69%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2433 |
| Charmed Shield | Opponent | L2327 |
| Horn of the Wild Hunt | Opponent | L2433 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L2327 |
| Ring of Doom | Opponent | L2433 |

# Doctrine scorecard: gs3-83c8646-p70

### Scorecard: gs3-83c8646-p70

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1827 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1827 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1927 | 1 | 1 | Mine | no | 2 | 1 | 7 | 1 | 1 | 0 | 0 | 255 |
| L1927 | 1 | 1 | Opponent | no | 2 | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 2 | 1 | 1 | 0 | 0 | 420 |
| L2029 | 1 | 1 | Opponent | no | 8 | 2 | 3 | 1 | 0 | 0 | 0 | 170 |
| **Average** | | | Mine | 0% | 1.0 | 1.0 | 4.5 | 1.0 | 1.0 | 0.0 | 0.0 | 337.5 |
| **Average** | | | Opponent | 0% | 5.0 | 2.0 | 2.5 | 2.5 | 0.0 | 0.0 | 0.0 | 85.0 |

### KPIs: gs3-83c8646-p70

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 10) | 0% (0 of 11) | 0% (0 of 21) |
| Winner chose to follow up after the loser gave ground |  | 50% (2 of 4); on the table 100% | 100% (4 of 4); on the table 100% | 75% (6 of 8); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 50% (1 of 2); on the table 50% | 33% (1 of 3); on the table 33% | 40% (2 of 5); on the table 40% |
| Winner chose to pursue after the loser fled |  | - | 80% (4 of 5); on the table 80% | 80% (4 of 5); on the table 80% |
| Winner chose to follow up or pursue (all three) |  | 50% (3 of 6); on the table 83% | 75% (9 of 12); on the table 75% | 67% (12 of 18); on the table 78% |
| Magic missiles tried each own turn | 50%+ | 0% (0 of 21) | 30% (3 of 10) | 10% (3 of 31) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 0% (0 of 9) | 30% (3 of 10) | 16% (3 of 19) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 71% (5 of 7) | 50% (2 of 4) | 64% (7 of 11) |
| Points that never fought | lower | 19% (772 of 3999) | 24% (944 of 3999) | 21% (1716 of 7998) |
|   infantry points that never fought | lower | 39% (322 of 836) | 100% (619 of 619) | 65% (941 of 1455) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 40% (6 of 15) | 38% (5 of 13) | 39% (11 of 28) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (1 of 2); 0.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 43% (1489 of 3466) | 24% (836 of 3430) | 34% (2325 of 6896) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.7 (24%) | 2.3 (100%) | 4.0 (43%) |
| MARCHED: its unit marched | 0.3 (5%) | 0.0 (0%) | 0.3 (4%) |
| IN COMBAT: engaged in combat | 1.7 (24%) | 0.0 (0%) | 1.7 (18%) |
| GONE: slain | 2.3 (33%) | 0.0 (0%) | 2.3 (25%) |
| NOT OFFERED: not in the cast list | 1.0 (14%) | 0.0 (0%) | 1.0 (11%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.0 | 2.3 | 1.0 | 1.0 | 3.0 |
| not cast | 7.3 | 6.0 | 9.3 | 2.3 | 23.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (6%) | 4.0 (43%) | 1.0 (43%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 1.7 (18%) | 0.0 (0%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 1.0 (14%) | 1.0 (17%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.3 (18%) | 1.0 (17%) | 2.3 (25%) | 0.0 (0%) | 5.3 (23%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.7 (11%) | 0.0 (0%) | 0.7 (29%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (6%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (29%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 1.0 (11%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 5.0 (68%) | 3.0 (50%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.3 (67%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 1.3 a game | 1.2 a game |
| stood (cast and not dispelled) | 33% (1 of 3) | 25% (1 of 4) | 29% (2 of 7) |
| the unit moved after it | 100% (1 of 1) | 100% (1 of 1) | 100% (2 of 2) |
| it charged on its next turn | 0% (0 of 1) | 0% (0 of 1) | 0% (0 of 2) |
| the enemy charged it first | 0% (0 of 1) | 100% (1 of 1) | 50% (1 of 2) |
| it fought by the end of its next turn | 0% (0 of 1) | 100% (1 of 1) | 50% (1 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 1) | 0% (0 of 1) | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | 100% (1 of 1) | 0% (0 of 1) | 50% (1 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 76% (13 of 17) | 43% (3 of 7) | 67% (16 of 24) |
|   cavalry | - | 100% (3 of 3) | 100% (3 of 3) |
|   character | - | 0% (0 of 4) | 0% (0 of 4) |
|   infantry | 76% (13 of 17) | - | 76% (13 of 17) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| CHARGED: it charged | 0.0 (0%) | 1.0 (75%) | 1.0 (38%) |
| NO TARGET IN RANGE | 0.3 (25%) | 0.3 (25%) | 0.7 (25%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (50%) | 0.0 (0%) | 0.7 (25%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (25%) | 0.0 (0%) | 0.3 (12%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 1.3 | 1.0 | 50% | 2.4 pts | 3 pts |
| infantry | 4.7 | 2.3 | 64% | 18.7 pts | 87 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.3 | 5.3 | 4.8 |
| Charges that made contact a game | 3.3 | 4.3 | 3.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (3 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.46 declared, 0.36 contact (28 units) | 0.64 declared, 0.52 contact (25 units) | 0.55 declared, 0.43 contact (53 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (1 of 2) | 33% (1 of 3) | 0% (0 of 1) | 33% (2 of 6) |
| Character in a unit | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Character on its own | 25% (1 of 4) | 0% (0 of 1) | 20% (1 of 5) | 20% (2 of 10) |
| Infantry | 75% (3 of 4) | 0% (0 of 1) | - | 60% (3 of 5) |
| Monster | 0% (0 of 1) | 50% (1 of 2) | - | 33% (1 of 3) |
| Monstrous | - | 50% (1 of 2) | - | 50% (1 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Orc & Goblin Tribes | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 12) | 13% | 12% (1 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 25% (1 of 4); on the table 75% | 0% (0 of 6) | 26% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 1 | 78% (7 of 9); on the table 78% | 0% (0 of 6) | 25% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 67% (2 of 3); on the table 67% | - | 22% | 29% (2 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p70, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 62% (5) | 25% (2) | 44% (7) |
| ...free all their last turn and able to turn (per game) | 1.67 | 0.00 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 1.67 | 0.00 | 1.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.33 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.33 | 0.33 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p70

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.7 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 60% (3 of 5) | 62% (10 of 16) |
| Strategy | Shoot objectives carried out (shot that target) | 29% (2 of 7) | 0% (0 of 1) |
| Strategy | Support requests answered (helper made contact too) | - | 67% (2 of 3) |
| Strategy | Joined characters whose unit fought | - | 33% (1 of 3) |
| Strategy | Lone characters that fought | 88% (7 of 8) | 100% (5 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.0 | 2.5 |
| Movement | Points that never moved of their own | 337.5 | 85.0 |
| Movement | Fights charged into per game | 3.0 | 4.0 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 2, net +0 | 1 of 7, net +437 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | 2 of 7, net +55 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 2 | 0 of 7 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 2 | 3 of 7, net +503 |
| Shooting | Shots by shooting units (incl. breath weapons) | 4.3 | 1.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 54% (7 of 13) | 0% (0 of 5) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | - | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 0% (0 of 2) |
| Magic | Wounds caused by magic missiles | 1.3 | - |
| Magic | Wounds caused by other spells | - | 1.3 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.0 / 1.3 / 0.0 | 1.0 / 0.0 / 0.7 / 0.3 |
| Combat | Points destroyed in combat | 277.3 | 436.7 |
| Combat | Points run down | 0.0 | 450.0 |
| Combat | Net points per charged fight, damage counted | -28 | +321 |
| Combat | Net per 100 charger points, damage counted | -19.7 | +110.1 |
| Combat | First round won (charged fights) | 50% | 88% |
| Combat | Net points per charged fight | -32 | +326 |
| Combat | Net points per supported fight / lone fight | - / -32 | +379 / +308 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 6 | 5 of 8 |
| Game | Points lost | 1819.5 | 366.0 |
| Game | VP from objectives | 355.0 | 935.0 |
| Game | Lone holders (player turns) | 1.0 | 5.0 |

- Mine won / drew / lost: 0 / 0 / 2 of 2 ended games (of 3); mean margin (Mine - Opponent) -2184 VP
- The side that went first won 2 of 2 games with a winner
- Points traded per game (both sides' losses): 2186
- Games not ended: 1 (L1827-1); findings 2, warnings 0

### Opponent rules: gs3-83c8646-p70

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +47.0 | 0.0 | 64.0 | 0.3 | +52.5 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 1.3 | +48.8 | 0.0 | 0.0 |
| ARMY TABLE | 21.7 | +255.7 | 0.0 | 106.7 | 14.3 | +203.9 | 0.0 | 30.0 |
| ASSAILMENT BY POINTS | 0.3 | +0.5 | 0.0 | 108.7 | 1.0 | +10.0 | 0.0 | 380.7 |
| BACKUP TARGETS | - | - | - | - | 0.3 | +0.5 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 0.7 | +20.3 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 0.7 | +15.4 | 0.0 | 0.0 |
| CHAFF PASSED | 0.7 | -8.5 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.7 | +76.8 | 0.0 | 0.0 | 0.3 | +0.2 | 0.0 | 0.0 |
| CHARGE LOSSES | 4.3 | -727.9 | 0.0 | 360.0 | 10.3 | -273.7 | 0.0 | 124.0 |
| CHARGE NOT DECLARED | 0.3 | +0.0 | 0.0 | 36.7 | - | - | - | - |
| CHARGE NOW FIRST | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 381.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 6.3 | +0.0 | 0.0 | 198.3 | 15.7 | +0.0 | 0.0 | 15.0 |
| COMBAT PIVOT | - | - | - | - | 1.3 | +0.0 | 85.0 | 190.3 |
| CONVEYANCE SEARCH | 0.7 | +36.8 | 0.0 | 0.0 | 1.3 | +71.3 | 0.0 | 0.0 |
| COVER ONCE | 6.3 | -473.9 | 0.0 | 191.7 | 2.3 | -86.6 | 0.0 | 62.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -0.3 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 8.0 | -112.9 | 0.0 | 0.0 | 7.0 | +58.5 | 0.0 | 62.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +33.4 | 70.0 | 0.0 |
| EXACT ROUND | 1.7 | +1.3 | 0.0 | 36.7 | 2.0 | -3.6 | 0.0 | 0.0 |
| FACES THE THREAT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 3.3 | +5.6 | 311.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 18.0 | +164.5 | 0.0 | 62.0 |
| FEATURE BUFFS | 2.0 | +21.0 | 0.0 | 41.7 | - | - | - | - |
| FIGHT TO THE END | 1.0 | +6.4 | 0.0 | 0.0 | 2.3 | +79.3 | 131.0 | 0.0 |
| FIVE ACTION | 57.0 | +3756.8 | 0.0 | 966.7 | 79.0 | +7167.5 | 679.7 | 574.7 |
| FLANK NOT WEIGHED | 7.7 | +0.0 | 0.0 | 201.7 | 3.0 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.3 | +329.0 | 0.0 | 131.0 | 0.3 | +56.1 | 0.0 | 0.0 |
| FOOT FIRST | 1.7 | +0.0 | 0.0 | 103.3 | - | - | - | - |
| FOUR ROUNDS | 2.0 | +127.6 | 0.0 | 36.7 | 5.3 | +565.6 | 679.7 | 15.0 |
| FREED FROM HIS FIGHT | 6.0 | +0.0 | 0.0 | 43.3 | 1.0 | +0.0 | 0.0 | 15.0 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.7 | -25.0 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -2.7 | 0.0 | 0.0 | - | - | - | - |
| GOAL ON TIME | 0.7 | +125.5 | 0.0 | 0.0 | - | - | - | - |
| GOAL ROUTE | 0.7 | +31.8 | 0.0 | 85.0 | - | - | - | - |
| GOAL WALK | 14.0 | +1536.9 | 0.0 | 85.0 | 8.0 | +1137.2 | 0.0 | 20.0 |
| GUN FIGURES | 5.0 | +0.0 | 0.0 | 21.7 | - | - | - | - |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HE REFORMS ONCE FREED | 3.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 15.0 |
| HIS CHARGE BY HIS RUN | 3.3 | +0.0 | 0.0 | 360.0 | 2.0 | +0.0 | 0.0 | 124.0 |
| HIS CHARGE LIST | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.0 | +0.0 | 0.0 | 116.7 | 6.3 | +0.0 | 0.0 | 124.0 |
| HIS MOVE AND SHOT | - | - | - | - | 6.0 | -59.6 | 0.0 | 0.0 |
| HIS ONE QUARTER | 0.3 | +0.0 | 0.0 | 21.7 | 1.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 3.7 | +0.0 | 0.0 | 116.7 | 9.3 | +0.0 | 0.0 | 504.7 |
| HIS RANDOM MOVE | 5.3 | +0.0 | 0.0 | 23.3 | 7.7 | +0.0 | 0.0 | 20.0 |
| HIS RANDOM MOVER COMES | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 20.0 |
| HIS RUN AFTER OUR TURN | 5.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 12.0 | +134.3 | 0.0 | 183.3 | 28.7 | +624.5 | 0.0 | 15.0 |
| HIS SHOTS BY HIS RUN | 8.0 | +67.4 | 0.0 | 360.0 | 27.7 | +545.2 | 0.0 | 124.0 |
| HIS TURN DENIED | - | - | - | - | 1.0 | +16.3 | 0.0 | 0.0 |
| HOLD ODDS | 11.7 | +0.0 | 0.0 | 156.7 | 12.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 7.3 | +731.5 | 0.0 | 85.0 | 8.3 | +945.8 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -5.7 | 0.0 | 36.7 | 4.0 | -105.4 | 417.7 | 0.0 |
| IDLE COST | - | - | - | - | 19.3 | -239.7 | 0.0 | 225.3 |
| JOINT CHARGE NOW | - | - | - | - | 1.7 | +333.1 | 262.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 2.3 | +0.0 | 0.0 | 55.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +9.3 | 0.0 | 0.0 | 1.3 | +47.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.0 | +0.0 | 190.3 | 623.0 | 2.3 | +0.0 | 316.7 | 380.7 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.3 | +7.9 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 0.7 | -2.9 | 0.0 | 36.7 | - | - | - | - |
| LOST AFTER ESCAPE | 1.0 | -0.2 | 0.0 | 0.0 | 2.3 | +4.3 | 201.0 | 0.0 |
| MANOEUVRE | 2.0 | +47.9 | 0.0 | 0.0 | 0.7 | +1.7 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | - | - | - | - | 0.3 | +0.5 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 0.3 | +22.5 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.0 | +57.3 | 0.0 | 0.0 | 2.3 | +31.5 | 0.0 | 0.0 |
| MEETS IN TIME | 5.0 | +381.2 | 0.0 | 0.0 | 3.3 | +411.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.0 | +78.4 | 0.0 | 180.0 | 0.7 | +1.1 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 2.7 | +46.6 | 0.0 | 180.0 | 2.7 | +2.4 | 0.0 | 0.0 |
| MOVE ORDER | 2.3 | +0.0 | 0.0 | 21.7 | 3.0 | +0.0 | 10.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.7 | -5.0 | 0.0 | 31.7 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 4.3 | +322.3 | 0.0 | 116.7 | 11.0 | +1696.4 | 0.0 | 504.7 |
| MOVES UNITS SPELL | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 7.3 | +328.5 | 0.0 | 11.7 | 4.7 | +186.8 | 0.0 | 0.0 |
| NEAREST TO GOAL | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 3.3 | +220.9 | 0.0 | 0.0 | 5.7 | +1267.0 | 0.0 | 504.7 |
| NO DOUBLE ROUNDS | 1.0 | -29.1 | 0.0 | 0.0 | 3.3 | -260.5 | 381.0 | 0.0 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 18.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 4.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 4.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | 2.0 | -0.6 | 0.0 | 0.0 |
| OFF BEST | 3.0 | -134.8 | 0.0 | 18.3 | 3.0 | -68.1 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 1.3 | -9.4 | 0.0 | 0.0 | 6.7 | -192.4 | 0.0 | 252.3 |
| ONE JOINT FIGURE | - | - | - | - | 1.0 | -101.4 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 1.3 | +45.9 | 0.0 | 11.7 | 2.7 | -16.8 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.7 | -14.7 | 0.0 | 0.0 | 1.3 | -78.2 | 0.0 | 124.0 |
| ONE ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 4.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +11.6 | 0.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 1.7 | +41.5 | 180.0 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +8.0 | 0.0 | 0.0 |
| PERIAPT WORTH | 0.3 | +40.6 | 0.0 | 180.0 | - | - | - | - |
| PLAN RESULT | 27.0 | +35.9 | 0.0 | 1339.0 | 37.7 | +719.8 | 602.3 | 230.3 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 5.7 | -84.5 | 0.0 | 116.7 | 11.7 | -418.4 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.3 | -2.5 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| QUARTER ODDS | 6.7 | +638.4 | 0.0 | 113.3 | 16.7 | +2371.0 | 216.7 | 0.0 |
| RANDOM MOVE BY FIGURES | 2.3 | +142.9 | 0.0 | 210.0 | 1.3 | +34.3 | 0.0 | 0.0 |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.3 | +12.4 | 0.0 | 15.0 |
| REDIRECT COUNTER | 3.0 | +80.7 | 0.0 | 0.0 | 3.7 | +153.0 | 0.0 | 25.0 |
| REDIRECT FOR A FRIEND IN REACH | 5.0 | +0.0 | 0.0 | 91.7 | 2.0 | +15.7 | 0.0 | 30.0 |
| REFORMS TO MEET IT | 2.0 | -127.5 | 0.0 | 0.0 | 1.7 | -130.2 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 36.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| RISK BY ARC | 1.7 | +60.9 | 0.0 | 36.7 | 5.0 | -9.1 | 643.0 | 15.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 2.7 | -61.1 | 167.7 | 0.0 |
| RUN DOWN | 0.3 | -1.4 | 0.0 | 0.0 | 2.0 | -74.0 | 131.0 | 0.0 |
| SAFER THAN THE JOB | - | - | - | - | 0.3 | +3.9 | 0.0 | 0.0 |
| SCOUT SPOT | 0.7 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -68.4 | 0.0 | 0.0 |
| SEARCH SPOT | - | - | - | - | 0.3 | +7.7 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +14.4 | 0.0 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | 1.0 | -2.0 | 0.0 | 108.7 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 3.3 | -72.6 | 0.0 | 0.0 |
| SET UP BY THE SET | 2.0 | +50.9 | 0.0 | 0.0 | 3.7 | +73.1 | 0.0 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +7.5 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 1.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 3.0 | +182.6 | 0.0 | 0.0 | 0.7 | +28.9 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -5.3 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 1.7 | +10.7 | 0.0 | 0.0 | 21.3 | -44.8 | 0.0 | 124.0 |
| SHOTS AFTER THE MOVES | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 8.0 | +184.9 | 0.0 | 21.7 | 1.3 | +10.7 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +7.5 | 0.0 | 0.0 |
| SPELL WORTH | 1.3 | +73.4 | 360.0 | 360.0 | 1.3 | +11.4 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | -3.6 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 7.7 | +0.0 | 0.0 | 296.0 | 8.3 | +0.0 | 0.0 | 200.3 |
| STAND AND SHOOT | 0.3 | -0.5 | 0.0 | 0.0 | 0.7 | -7.7 | 0.0 | 0.0 |
| STANDS STILL | 14.0 | +0.0 | 0.0 | 163.3 | 15.7 | +0.0 | 0.0 | 0.0 |
| STAY WORTH | 4.0 | +21.2 | 0.0 | 21.7 | 0.7 | +3.7 | 0.0 | 0.0 |
| STRIKE BY THE ODDS | 0.3 | +3.9 | 0.0 | 0.0 | 0.7 | +3.0 | 0.0 | 62.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 1.3 | +0.0 | 0.0 | 380.7 |
| SUPPORT ADDS | 7.0 | +827.6 | 0.0 | 0.0 | 6.7 | +449.5 | 0.0 | 20.0 |
| SUPPORT NARROWED | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 7.0 | +827.6 | 0.0 | 0.0 | 6.7 | +449.5 | 0.0 | 20.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +0.8 | 0.0 | 15.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +3.8 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.0 | +0.0 | 0.0 | 21.7 | 3.0 | +0.0 | 0.0 | 10.0 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 4.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 24.0 | +0.0 | 0.0 | 231.7 | 39.3 | +0.0 | 0.0 | 287.3 |
| TIED UP BY THE SUM | - | - | - | - | 1.0 | +108.5 | 70.0 | 0.0 |
| TIME ON OUR SIDE | 29.3 | +341.6 | 0.0 | 570.0 | - | - | - | - |
| WAITS AGAIN | 2.7 | +0.0 | 0.0 | 116.7 | 2.7 | +0.0 | 0.0 | 380.7 |
| WALKS ON ITS ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | 0.7 | +57.2 | 0.0 | 0.0 | 0.7 | -4.5 | 73.3 | 0.0 |
| WHO FIGHTS | 0.3 | -11.9 | 0.0 | 0.0 | 0.3 | +0.5 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +8.0 | 36.7 | 0.0 |
| WHOLE FIGHT DANGER | 4.3 | -727.1 | 0.0 | 360.0 | 0.7 | -29.5 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +13.2 | 131.0 | 0.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 3.0 | +36.5 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p70

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 108 | 108 | 69 | 23.00 | +1479 | +21.4 |
| HOLDER ASSIGNMENT | 47 | 47 | 41 | 13.67 | +2903 | +70.8 |
| FIVE ACTION | 408 | 396 | 34 | 11.33 | +2120 | +62.4 |
| DEPLOY BY FIGURES | 45 | 45 | 26 | 8.67 | +294 | +11.3 |
| MOVE TO CHARGE COMPUTED | 46 | 40 | 26 | 8.67 | +1698 | +65.3 |
| SUPPORT ADDS | 41 | 41 | 24 | 8.00 | +1251 | +52.1 |
| SUPPORT WORKED OUT | 41 | 41 | 24 | 8.00 | +1251 | +52.1 |
| HIS SHOT LIST | 122 | 117 | 22 | 7.33 | +168 | +7.6 |
| THE TABLE AGAIN | 28 | 28 | 22 | 7.33 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 52 | 52 | 21 | 7.00 | -1509 | -71.8 |
| REDIRECT FOR A FRIEND IN REACH | 21 | 21 | 21 | 7.00 | +43 | +2.0 |
| LEGAL CHARGES ONLY | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| GOAL WALK | 66 | 65 | 18 | 6.00 | +1680 | +93.4 |
| NEXT CHARGE BY LIST | 27 | 27 | 18 | 6.00 | +1476 | +82.0 |
| OFF BEST | 18 | 18 | 18 | 6.00 | -609 | -33.8 |
| MOVE ORDER | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| FOUR ROUNDS | 22 | 21 | 12 | 4.00 | +560 | +46.7 |
| IDLE COST | 58 | 42 | 12 | 4.00 | +42 | +3.5 |
| HIS SHOTS BY HIS RUN | 107 | 105 | 11 | 3.67 | +57 | +5.2 |
| SHOOTS FROM THE BEST SPOT | 11 | 11 | 11 | 3.67 | +113 | +10.3 |
| MEETS IN TIME | 25 | 25 | 7 | 2.33 | +441 | +63.0 |
| RANDOM MOVE BY FIGURES | 11 | 11 | 7 | 2.33 | +532 | +75.9 |
| ONE PROMISE A TARGET | 6 | 6 | 6 | 2.00 | -279 | -46.5 |
| QUARTER ODDS | 70 | 69 | 6 | 2.00 | +848 | +141.3 |
| RISK BY ARC | 20 | 19 | 6 | 2.00 | +134 | +22.3 |
| TIME ON OUR SIDE | 88 | 70 | 6 | 2.00 | +57 | +9.5 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | +999 | +199.9 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +171 | +34.2 |
| SHOT RISK POINTS | 69 | 68 | 5 | 1.67 | +46 | +9.2 |
| ADVANCE LANE KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| AFTERMATH WITH FRIENDS | 4 | 4 | 4 | 1.33 | +146 | +36.6 |
| ASSAILMENT BY POINTS | 4 | 4 | 4 | 1.33 | +32 | +7.9 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| COMBAT PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +231 | +77.0 |
| CHARGE NOW FIRST | 9 | 9 | 3 | 1.00 | -322 | -107.3 |
| FIGHT TO THE END | 10 | 9 | 3 | 1.00 | +63 | +21.1 |
| MANOEUVRE | 8 | 8 | 3 | 1.00 | +149 | +49.5 |
| OVERRUNS AWAY | 5 | 5 | 3 | 1.00 | +19 | +6.4 |
| REDIRECT COUNTER | 20 | 17 | 3 | 1.00 | +72 | +24.1 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| STRIKE BY THE ODDS | 3 | 3 | 3 | 1.00 | +21 | +6.9 |
| TIED UP BY THE SUM | 3 | 3 | 3 | 1.00 | +112 | +37.2 |
| WHOLE FIGHT DANGER | 15 | 15 | 3 | 1.00 | +76 | +25.3 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +299 | +149.4 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CASTING BLOCK | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | -25 | -12.7 |
| CHARGE LOSSES | 44 | 44 | 2 | 0.67 | +27 | +13.4 |
| EXACT ROUND | 11 | 10 | 2 | 0.67 | +9 | +4.6 |
| FALLS SHORT | 54 | 43 | 2 | 0.67 | +12 | +6.2 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +1155 | +577.5 |
| GOAL ON TIME | 2 | 2 | 2 | 0.67 | -1 | -0.3 |
| GOAL ROUTE | 2 | 2 | 2 | 0.67 | +95 | +47.6 |
| MAX FOR POSITIONING | 10 | 9 | 2 | 0.67 | +23 | +11.4 |
| NEARER NOT NEEDED | 36 | 34 | 2 | 0.67 | +29 | +14.7 |
| PROMISE KNOWS THE FIGHT | 10 | 7 | 2 | 0.67 | -8 | -3.8 |
| SET CREDITED ONCE | 10 | 10 | 2 | 0.67 | +2 | +1.1 |
| SHOTS IN THE MOVE | 28 | 19 | 2 | 0.67 | +160 | +79.8 |
| THE ROW IN ITS ORDER | 18 | 2 | 2 | 0.67 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 9 | 9 | 2 | 0.67 | +49 | +24.5 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -30 | -29.5 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HARD STAY DROPPED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS TURN DENIED | 3 | 3 | 1 | 0.33 | +10 | +10.4 |
| HONEST WORTH | 15 | 15 | 1 | 0.33 | +19 | +19.2 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +24 | +23.8 |
| MARCH CHECK | 1 | 1 | 1 | 0.33 | +2 | +1.5 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| NO DOUBLE ROUNDS | 13 | 13 | 1 | 0.33 | +4 | +4.0 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +4 | +4.0 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +24 | +24.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +122 | +121.9 |
| REFUSING RETIRES | 4 | 4 | 1 | 0.33 | -16 | -15.8 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.33 | +12 | +11.7 |
| SEARCH SPOT | 1 | 1 | 1 | 0.33 | +23 | +23.1 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +43 | +43.0 |
| SET UP BY THE SET | 17 | 17 | 1 | 0.33 | +7 | +7.2 |
| SUPPORT NARROWED | 3 | 3 | 1 | 0.33 | -7 | -6.8 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +11 | +11.3 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT | 2 | 1 | 1 | 0.33 | +11 | +11.2 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 66 | 66 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 6 | not checked | - | - | - | - |
| COVER ONCE | 26 | 15 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 13 | 12 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 6 | 6 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 32 | not checked | - | - | - | - |
| FOOT FIRST | 5 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 21 | 15 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 1 | not checked | - | - | - | - |
| GUN FIGURES | 15 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 13 | 7 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 16 | 16 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 9 | 8 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 28 | 28 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 18 | 18 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 6 | 6 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 39 | 37 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 39 | 37 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 10 | 10 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 30 | 30 | 0 | 0.00 | - | - |
| HOLD ODDS | 73 | 72 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 13 | 12 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LONG SHOT | 2 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 10 | 10 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 3 | 2 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 8 | 5 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 16 | 11 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 2 | trace | - | - | - | - |
| NEAREST TO GOAL | 4 | 4 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 29 | 29 | 0 | 0.00 | - | - |
| NO SECOND RUN | 28 | 28 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 7 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 24 | 12 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 3 | 3 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 12 | 8 | 0 | 0.00 | - | - |
| ONE ROUTE | 3 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 29 | 29 | 0 | 0.00 | - | - |
| PLAN RESULT | 194 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 3 | 2 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 11 | 11 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 8 | 8 | 0 | 0.00 | - | - |
| RUN DOWN | 7 | 7 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 3 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 11 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 4 | 4 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 8 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 48 | 44 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS STILL | 89 | 87 | 0 | 0.00 | - | - |
| STAY WORTH | 14 | 12 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 4 | 4 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 20 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 17 | not checked | - | - | - | - |
| THE TABLE BINDS | 190 | not checked | - | - | - | - |
| WAITS AGAIN | 16 | 16 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 2 | 2 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 4 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p70

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| ARMY TABLE | rule | 5.00 | 2.00 | 57.7 |
| PROMISE BY ITS OWN SUM | rule | 2.33 | 4.67 | 71.8 |
| JOB FIRST | gate | 2.33 | 3.00 | 30.4 |
| ONE PROMISE A TARGET | rule | 0.33 | 1.33 | 59.8 |
| CHARGE NOW FIRST | rule | - | 1.00 | 107.3 |
| CHAFF PASSED | rule | 0.67 | - | 12.7 |
| HOLDER ASSIGNMENT | rule | - | 0.67 | 30.5 |
| NO REASON | gate | 0.67 | - | 60.8 |
| PROMISE KNOWS THE FIGHT | rule | 0.67 | - | 3.8 |
| CHARGE NOT DECLARED | rule | 0.33 | - | 29.5 |
| JOINT CHARGE NOW | rule | - | 0.33 | 42.7 |
| REFUSING RETIRES | rule | - | 0.33 | 15.8 |
| SUPPORT NARROWED | rule | 0.33 | - | 6.8 |

### Plans: gs3-83c8646-p70

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.7 | 0% | 27 | 18 | 65% |
| Mine | move | 25.0 | 89% | 1767 | 0 | 0% |
| Mine | shoot | 1.3 | 25% | 141 | 18 | 13% |
| Opponent | charge | 5.0 | 53% | 1155 | 720 | 62% |
| Opponent | join | 2.7 | 100% | 100 | 0 | 0% |
| Opponent | move | 29.3 | 98% | 2122 | 0 | 0% |
| Opponent | support | 0.7 | 100% | 16 | 0 | 0% |

### Battle groups: gs3-83c8646-p70

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.0 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 3.7 | 27% | 100% | 0% | - | 67% | 0% | 0% | 33% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p70

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 100 | 0% | 3.0 | 0 (2) | - | - | 0 (2) | - |
| Mine | Character | 5 | 62 (5) | 62 | 0 | 116 | 20% | 1.2 | 0 (1) | - | 163 (1) | 163 (1) | 0 (1) |
| Mine | Clean-up | 2 | 0 (2) | 0 | 0 | 84 | 0% | 4.5 | 0 (2) | - | - | 0 (1) | 0 (1) |
| Mine | Fast Hammer | 1 | 3 (1) | 3 | 0 | 115 | 0% | 1.0 | - | 3 (1) | - | 3 (1) | - |
| Mine | Hammer | 5 | 15 (5) | 3 | 12 | 105 | 20% | 3.0 | 7 (2) | 41 (2) | 0 (1) | 20 (4) | 0 (1) |
| Mine | Holder | 3 | 57 (3) | 0 | 57 | 54 | 33% | 3.5 | 0 (1) | 106 (2) | - | 57 (3) | - |
| Mine | Shooter | 3 | 0 (3) | 0 | 0 | 33 | 0% | 1.3 | 0 (1) | 0 (2) | - | 0 (2) | 0 (1) |
| Mine | Wizard | 3 | 4 (3) | 4 | 0 | 121 | 0% | 1.3 | - | - | - | - | - |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 28 | 60% | 2.5 | 0 (3) | 0 (1) | 0 (1) | 0 (2) | 0 (3) |
| Opponent | Character | 6 | 170 (6) | 170 | 0 | 37 | 0% | 3.0 | 305 (2) | 58 (3) | 152 (1) | 205 (5) | 58 (1) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 5 | 25 (5) | 19 | 5 | 16 | 0% | 2.8 | - | 23 (3) | 28 (2) | 25 (5) | - |
| Opponent | Hammer | 2 | 128 (2) | 55 | 73 | 0 | 50% | 3.0 | - | 128 (2) | - | 160 (1) | 111 (1) |
| Opponent | Holder | 1 | 0 (1) | 0 | 0 | 0 | 0% | 4.0 | - | - | 0 (1) | 0 (1) | - |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 1.0 | 0 (1) | - | 0 (1) | - | 0 (2) |

### Charged fights: gs3-83c8646-p70

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Orc & Goblin Tribes | 1 | 0 | 757 | 4.0 | 1.0 | 189 | 238 | -48 | 1 of 4 | 2 of 4 | - | -48 |
| Mine | Skaven | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 1 of 2 | 1 of 2 | - | +0 |
| **Mine** | all armies | 2 | 0 | 378 | 3.0 | 1.0 | 126 | 158 | -32 | 2 of 6 | 3 of 6 | - | -32 |
| Opponent | Vampire Counts | 1 | 0 | 1350 | 5.0 | 1.4 | 270 | 9 | +261 | 3 of 5 | 4 of 5 | +379 | +182 |
| Opponent | Warriors of Chaos | 1 | 0 | 1299 | 3.0 | 1.0 | 433 | 0 | +433 | 2 of 3 | 3 of 3 | - | +433 |
| **Opponent** | all armies | 2 | 0 | 1324 | 4.0 | 1.2 | 331 | 6 | +326 | 5 of 8 | 7 of 8 | +379 | +308 |

### Effective charges: gs3-83c8646-p70

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 2 | 2 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Vampire Counts | 5 | 1 (net +437) | 0 | 2 (net +55) | 1 (net +0) | 0 | 1 (net +758) | 0 | 40% (2 of 5) |
| Opponent | Warriors of Chaos | 3 | 0 | 0 | 0 | 0 | 0 | 2 (net +375) | 1 | 0% (0 of 2) |

### Charged fights, damage counted: gs3-83c8646-p70

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 19 | 290 | +0 | 17 | 3 | +14 | +72.8 |
| Mine | No odds | 4 | 201 | 257 | -48 | 189 | 238 | -48 | -24.0 |
| Mine | All fights | 6 | 140 | 268 | -32 | 132 | 159 | -28 | -19.7 |
| Opponent | Long shot (under 50%) | 1 | 45 | 343 | +437 | 482 | 45 | +437 | +971.1 |
| Opponent | Effective (55-75%) | 2 | 118 | 148 | +55 | 55 | 0 | +55 | +46.6 |
| Opponent | 76-89% | 1 | 430 | 343 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 473 | 331 | +503 | 503 | 11 | +492 | +104.0 |
| Opponent | No odds | 1 | 205 | 192 | +549 | 549 | 0 | +549 | +267.8 |
| Opponent | All fights | 8 | 292 | 271 | +326 | 331 | 10 | +321 | +110.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p70 | move | 20 | 5 (25%) | 4 (20%) | 3 (15%) | 12 (60%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1827, L1927 |
| Elixir of Power | Mine | L1927 |
| Fistful of Laurels | Mine | L1827 |
| Invocation of Nehek | Opponent | L1827, L1927 |
| Periapt of Soul Exchange | Mine | L2029 |

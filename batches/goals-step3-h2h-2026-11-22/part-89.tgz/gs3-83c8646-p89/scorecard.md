# Doctrine scorecard: gs3-83c8646-p89

### Scorecard: gs3-83c8646-p89

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0729 | 3 | 1 | Mine | no | 9 | 2 | 3 | 0 | 0 | 0 | 0 | 295 |
| L0729 | 3 | 1 | Opponent | no | 1 | 6 | 0 | 1 | 0 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | no | 0 | 4 | 2 | 1 | 0 | 0 | 0 | 471 |
| L0819 | 3 | 1 | Opponent | no | 6 | 4 | 2 | 1 | 0 | 0 | 0 | 255 |
| L0835 | 1 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 673 |
| L0835 | 1 | 1 | Opponent | no | 0 | - | 0 | 5 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 3.0 | 3.0 | 1.7 | 1.0 | 0.0 | 0.0 | 0.0 | 479.7 |
| **Average** | | | Opponent | 0% | 2.3 | 5.0 | 0.7 | 2.3 | 0.0 | 0.0 | 0.0 | 141.7 |

### KPIs: gs3-83c8646-p89

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 100% (14 of 14) | 0% (0 of 12) | 54% (14 of 26) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 100% (3 of 3); on the table 100% | 100% (4 of 4); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | 100% (1 of 1); on the table 100% | 50% (1 of 2); on the table 50% |
| Winner chose to pursue after the loser fled |  | 100% (4 of 4); on the table 100% | 50% (1 of 2); on the table 100% | 83% (5 of 6); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 83% (5 of 6); on the table 83% | 83% (5 of 6); on the table 100% | 83% (10 of 12); on the table 92% |
| Magic missiles tried each own turn | 50%+ | - | 25% (3 of 12) | 25% (3 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 30% (3 of 10) | 30% (3 of 10) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 40% (2 of 5) | 40% (2 of 5) |
| Points that never fought | lower | 68% (4109 of 5999) | 64% (3817 of 5999) | 66% (7926 of 11998) |
|   infantry points that never fought | lower | 96% (932 of 968) | 84% (948 of 1130) | 90% (1880 of 2098) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 70% (21 of 30) | 74% (20 of 27) | 72% (41 of 57) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Bound items with another spell used |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 33% (1 of 3); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 65% (3518 of 5378) | 79% (4500 of 5714) | 72% (8018 of 11092) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.0 (33%) | 1.0 (33%) |
| MARCHED: its unit marched | - | 0.7 (22%) | 0.7 (22%) |
| CHARGED: its unit charged | - | 0.7 (22%) | 0.7 (22%) |
| IN COMBAT: engaged in combat | - | 0.7 (22%) | 0.7 (22%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 2.7 | 0.0 | 1.7 | 1.0 | 1.3 |
| not cast | 5.3 | 2.0 | 4.3 | 3.0 | 18.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (33%) | 0.0 (0%) | 1.0 (33%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (22%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (22%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.7 (15%) | 0.7 (22%) | 0.0 (0%) |
| OFF THE TABLE: off the table or not arrived | 1.3 (25%) | 1.3 (67%) | 1.3 (31%) | 0.0 (0%) | 3.0 (16%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.0 (75%) | 0.0 (0%) | 2.3 (54%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.3 (78%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 0.7 a game | 0.8 a game |
| stood (cast and not dispelled) | 33% (1 of 3) | 50% (1 of 2) | 40% (2 of 5) |
| the unit moved after it | 0% (0 of 1) | 0% (0 of 1) | 0% (0 of 2) |
| it charged on its next turn | 100% (1 of 1) | 0% (0 of 1) | 50% (1 of 2) |
| the enemy charged it first | 0% (0 of 1) | 0% (0 of 1) | 0% (0 of 2) |
| it fought by the end of its next turn | 0% (0 of 1) | 0% (0 of 1) | 0% (0 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 1) | 0% (0 of 1) | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | 0% (0 of 1) | 100% (1 of 1) | 50% (1 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 70% (76 of 109) | 63% (22 of 35) | 68% (98 of 144) |
|   cavalry | 72% (18 of 25) | 69% (11 of 16) | 71% (29 of 41) |
|   character | - | 29% (2 of 7) | 29% (2 of 7) |
|   chariot | 82% (9 of 11) | - | 82% (9 of 11) |
|   infantry | 75% (9 of 12) | 75% (9 of 12) | 75% (18 of 24) |
|   war machine | 66% (40 of 61) | - | 66% (40 of 61) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (21%) | 1.3 (31%) | 3.7 (24%) |
| FLEEING: it fled or was fleeing | 0.7 (6%) | 0.7 (15%) | 1.3 (9%) |
| IN COMBAT: it fought this turn or the last | 0.7 (6%) | 0.0 (0%) | 0.7 (4%) |
| MOVED: a war machine that moved | 1.3 (12%) | 0.0 (0%) | 1.3 (9%) |
| NO TARGET IN RANGE | 0.7 (6%) | 1.7 (38%) | 2.3 (15%) |
| ONLY IN COMBAT: the only targets were in combat | 1.3 (12%) | 0.0 (0%) | 1.3 (9%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.3 (21%) | 0.7 (15%) | 3.0 (20%) |
| SHELTERED: the target was sheltered | 1.3 (12%) | 0.0 (0%) | 1.3 (9%) |
| OTHER BAR | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 14.7 | 3.0 | 82% | 3.5 pts | 51 pts |
| character | 0.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 3.0 | 1.3 | 67% | 8.0 pts | 24 pts |
| infantry | 6.0 | 2.3 | 72% | 5.8 pts | 35 pts |
| war machine | 13.3 | 14.3 | 45% | 21.6 pts | 288 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 2.0 | 2.8 |
| Charges that made contact a game | 2.7 | 1.3 | 2.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | 3.00 declared, 2.00 contact (1 units) | - | 3.00 declared, 2.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.36 declared, 0.27 contact (22 units) | 0.23 declared, 0.15 contact (26 units) | 0.29 declared, 0.21 contact (48 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (4 of 8) | 50% (3 of 6) | - | 50% (7 of 14) |
| Character in a unit | 100% (8 of 8) | 100% (1 of 1) | - | 100% (9 of 9) |
| Character on its own | 100% (1 of 1) | 100% (1 of 1) | 80% (4 of 5) | 86% (6 of 7) |
| Chariot | - | 50% (1 of 2) | - | 50% (1 of 2) |
| Infantry | 50% (3 of 6) | 0% (0 of 1) | 100% (2 of 2) | 56% (5 of 9) |
| Monster | 0% (0 of 1) | - | - | 0% (0 of 1) |
| Monstrous | 100% (2 of 2) | 50% (1 of 2) | - | 75% (3 of 4) |
| War Machines | 91% (10 of 11) | - | - | 91% (10 of 11) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 3 | 83% (5 of 6); on the table 83% | - | 68% | 70% (21 of 30) | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 33% (1 of 3); 0.3 uses a game |
| Orc & Goblin Tribes | 1 | 80% (4 of 5); on the table 100% | 25% (3 of 12) | 30% | 88% (7 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (1 of 1); on the table 100% | - | 61% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | - | 100% | 75% (9 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p89, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (1) | 100% (4) | 83% (5) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.67 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.67 | 1.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.67 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p89

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | 60% (6 of 10) | 67% (2 of 3) |
| Strategy | Shoot objectives carried out (shot that target) | 55% (35 of 64) | 55% (6 of 11) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 2) | - |
| Strategy | Joined characters whose unit fought | 14% (1 of 7) | 100% (4 of 4) |
| Strategy | Lone characters that fought | 29% (2 of 7) | 0% (0 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.0 | 2.3 |
| Movement | Points that never moved of their own | 479.7 | 141.7 |
| Movement | Fights charged into per game | 2.7 | 1.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 6 | 0 of 2 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 6, net +0 | 1 of 2, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 6 | 0 of 2 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 6, net +68 | 1 of 2, net +36 |
| Shooting | Shots by shooting units (incl. breath weapons) | 12.3 | 7.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 22% (8 of 37) | 55% (12 of 22) |
| Shooting | Points destroyed by shooting units | 98.0 | 15.0 |
| Shooting | War machine shots | 13.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 30% (12 of 40) | - |
| Shooting | Points destroyed by war machines | 34.0 | 0.0 |
| Magic | Magic missiles cast | - | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 0% (0 of 1) |
| Magic | Wounds caused by magic missiles | - | 0.3 |
| Magic | Wounds caused by other spells | 2.0 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.0 / 0.7 / 0.0 | 0.7 / 0.0 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 0.0 | 36.7 |
| Combat | Points run down | 68.3 | 0.0 |
| Combat | Net points per charged fight, damage counted | +48 | -32 |
| Combat | Net per 100 charger points, damage counted | +18.7 | -31.7 |
| Combat | First round won (charged fights) | 88% | 75% |
| Combat | Net points per charged fight | +41 | +9 |
| Combat | Net points per supported fight / lone fight | - / +41 | - / +9 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 8 | 2 of 4 |
| Game | Points lost | 107.0 | 801.0 |
| Game | VP from objectives | 973.3 | 616.7 |
| Game | Lone holders (player turns) | 3.0 | 2.3 |

- Mine won / drew / lost: 3 / 0 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +1115 VP
- The side that went first won 0 of 3 games with a winner
- Points traded per game (both sides' losses): 908
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p89

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH WITH FRIENDS | 0.3 | +6.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 9.0 | -85.8 | 0.0 | 0.0 | 23.3 | +388.9 | 0.0 | 419.7 |
| ARTILLERY RE-ROLL WEIGHED | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ASSAILMENT BY POINTS | - | - | - | - | 1.0 | +4.5 | 0.0 | 0.0 |
| BACKUP TARGETS | - | - | - | - | 0.3 | +0.6 | 0.0 | 199.7 |
| BEST PRIZE | 0.7 | -21.1 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 38.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 12.7 | +174.8 | 773.7 | 43.3 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| CARRIES OUT SET-UP | 0.7 | -16.8 | 0.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | - | - | - | - | 1.7 | +41.1 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 91.3 |
| CATCH FLIERS | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 0.3 | +13.4 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.7 | +22.7 | 0.0 | 68.3 |
| CHARGE LOSSES | 7.3 | -339.2 | 0.0 | 0.0 | 24.3 | -960.0 | 0.0 | 1124.7 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 12.0 | 0.0 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 68.3 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 9.7 | +0.0 | 0.0 | 0.0 | 12.7 | +0.0 | 0.0 | 275.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 1.0 | +53.9 | 0.0 | 0.0 | 0.7 | +81.8 | 0.0 | 182.7 |
| COVER ONCE | 5.7 | -325.9 | 0.0 | 0.0 | 6.7 | -556.0 | 0.0 | 541.7 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -1.0 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 8.7 | -169.2 | 0.0 | 43.3 | 8.3 | -1.0 | 0.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +1.3 | 12.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 3.0 | +160.6 | 0.0 | 283.0 |
| EXACT ROUND | 3.0 | +135.1 | 81.3 | 0.0 | 0.7 | -26.4 | 12.0 | 0.0 |
| FALL BACK GOOD ORDER | 3.0 | +21.0 | 109.0 | 0.0 | 1.0 | +0.5 | 12.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 20.3 | +182.7 | 0.0 | 684.0 |
| FIGHT TO THE END | 1.7 | +3.4 | 68.3 | 0.0 | - | - | - | - |
| FIRE IN ORDER | 1.0 | +0.0 | 85.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 101.7 | +6471.7 | 2356.0 | 110.7 | 82.0 | +4135.9 | 12.0 | 2534.0 |
| FLANK NOT WEIGHED | 3.7 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 582.3 |
| FOCUS FIRE | - | - | - | - | 0.3 | +3.7 | 15.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +83.8 | 0.0 | 0.0 |
| FOOT FIRST | 18.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 3.7 | +323.0 | 149.7 | 0.0 | 1.0 | +43.1 | 12.0 | 0.0 |
| FREED FROM HIS FIGHT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.7 | +27.9 | 0.0 | 0.0 | - | - | - | - |
| GOAL ROUTE | 0.7 | +4.2 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 6.7 | +248.9 | 0.0 | 0.0 | 19.3 | +1621.2 | 0.0 | 273.3 |
| GUN FIGURES | 3.0 | +33.1 | 34.0 | 0.0 | - | - | - | - |
| GUN MASK | 7.0 | +137.0 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 199.7 |
| HE REFORMS ONCE FREED | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 4.7 | +0.0 | 0.0 | 0.0 | 10.0 | +0.0 | 0.0 | 738.7 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +16.7 | 0.0 | 0.0 |
| HIS CHARGE LIST | 1.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 124.0 |
| HIS LEGAL MOVES | 1.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 1.7 | -7.8 | 0.0 | 0.0 | 3.0 | -40.6 | 0.0 | 68.0 |
| HIS ONE QUARTER | 4.3 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 68.0 |
| HIS OWN BEST MOVE | 3.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 7.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 16.0 | +322.2 | 0.0 | 0.0 | 69.7 | +4189.7 | 0.0 | 1513.7 |
| HIS SHOTS BY HIS RUN | 11.7 | +93.1 | 0.0 | 0.0 | 51.0 | +1523.6 | 0.0 | 1667.0 |
| HIS TURN DENIED | 0.3 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| HOLD ODDS | 11.3 | +0.0 | 0.0 | 0.0 | 14.0 | +0.0 | 0.0 | 288.3 |
| HOLDER ASSIGNMENT | 12.0 | +1166.4 | 0.0 | 0.0 | 9.7 | +889.7 | 0.0 | 153.3 |
| HOLDS AMBUSHERS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.0 | -89.4 | 81.3 | 0.0 | 1.0 | -23.0 | 12.0 | 0.0 |
| IDLE COST | - | - | - | - | 16.3 | -276.2 | 0.0 | 384.7 |
| JOINT CHARGE NOW | 1.0 | +20.5 | 81.3 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | - | - | - | - | 1.3 | +65.2 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.0 | +0.0 | 162.7 | 73.3 | - | - | - | - |
| LONE WIZARD KEPT IN | 0.7 | +36.3 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.3 | +7.3 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 3.0 | +3.7 | 149.7 | 0.0 | 1.0 | +4.0 | 12.0 | 0.0 |
| MAKE SURE TOGETHER | 0.7 | +11.1 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 1.7 | +0.0 | 0.0 | 12.0 | 3.0 | -6.7 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 0.3 | +24.1 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 1.0 | +16.9 | 0.0 | 0.0 | 0.7 | +10.2 | 0.0 | 0.0 |
| MEETS IN TIME | 3.3 | +278.5 | 0.0 | 0.0 | 4.0 | +266.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | - | - | - | - | 1.3 | +26.4 | 0.0 | 105.3 |
| MISSILES NEXT TURN | - | - | - | - | 1.7 | +16.3 | 0.0 | 105.3 |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 90.7 |
| MOVE SPELL IN RANGE | 1.0 | +33.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 1.0 | -25.8 | 0.0 | 0.0 | 0.3 | -6.1 | 0.0 | 91.3 |
| MOVE TO CHARGE COMPUTED | 3.0 | +136.1 | 0.0 | 0.0 | 0.7 | +15.3 | 0.0 | 0.0 |
| MOVES UNITS SPELL | - | - | - | - | 0.3 | +1.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 11.0 | +469.7 | 0.0 | 0.0 | 7.0 | +310.7 | 0.0 | 18.3 |
| NEAREST TO GOAL | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 3.0 | +136.1 | 0.0 | 0.0 | 0.7 | +15.3 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.7 | -20.0 | 18.3 | 0.0 | 0.7 | -20.5 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 3.3 | -154.5 | 149.7 | 0.0 | 1.0 | -46.3 | 12.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 4.0 | -3.1 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 4.7 | -90.3 | 0.0 | 0.0 | 1.7 | -68.4 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 1.3 | +0.0 | 0.0 | 81.3 |
| ONE FIGHT FORMULA | 4.0 | -71.3 | 0.0 | 0.0 | 4.7 | -103.7 | 0.0 | 467.7 |
| ONE OBJECTIVE FORMULA | 3.7 | -0.3 | 0.0 | 0.0 | 3.7 | -22.6 | 0.0 | 76.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.7 | +29.7 | 0.0 | 0.0 | 0.3 | +5.3 | 0.0 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +15.4 | 0.0 | 0.0 |
| PLAN RESULT | 45.0 | +1254.2 | 633.0 | 60.7 | 38.0 | +102.8 | 0.0 | 1377.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 2.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| QUARTER ODDS | 27.7 | +2933.6 | 353.3 | 0.0 | 19.7 | +1895.4 | 0.0 | 176.7 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 1.7 | +27.5 | 0.0 | 0.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 0.3 | +9.9 | 0.0 | 12.0 | 1.3 | +305.8 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 0.3 | +0.0 | 0.0 | 12.0 | 2.3 | +0.0 | 0.0 | 18.3 |
| REDIRECT WEIGHED | 0.7 | -13.4 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 1.0 | -87.4 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 12.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +33.8 | 0.0 | 38.0 |
| RISK BY ARC | 3.0 | +73.1 | 68.3 | 0.0 | 1.0 | -10.3 | 12.0 | 0.0 |
| ROUNDS AFTER TERROR | 1.0 | -29.3 | 40.7 | 0.0 | - | - | - | - |
| RUN DOWN | 3.3 | -26.3 | 149.7 | 0.0 | 1.0 | -17.2 | 12.0 | 0.0 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | - | - | - | - | 1.0 | +8.1 | 0.0 | 0.0 |
| SELF MOVE SPELL | - | - | - | - | 2.0 | -4.2 | 0.0 | 0.0 |
| SET CREDITED ONCE | 1.3 | -24.9 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 2.7 | -2.4 | 68.3 | 0.0 | 1.0 | -3.1 | 0.0 | 399.3 |
| SET UP TOGETHER | 1.3 | +17.9 | 0.0 | 0.0 | 0.7 | +9.4 | 0.0 | 41.7 |
| SET-UP ANY TARGET | 0.7 | +95.4 | 0.0 | 0.0 | - | - | - | - |
| SET-UP MISSED | 0.3 | +23.1 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 21.0 | +0.0 | 0.0 | 43.3 | 3.7 | +0.0 | 0.0 | 399.3 |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 0.7 | +4.2 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 1.7 | -22.2 | 0.0 | 0.0 | 0.3 | -3.4 | 0.0 | 0.0 |
| SHOT RISK POINTS | 6.3 | -75.9 | 0.0 | 0.0 | 33.3 | -514.0 | 0.0 | 917.3 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 26.3 | +1044.8 | 0.0 | 43.3 | 7.3 | +141.8 | 0.0 | 381.0 |
| SPELL SETS UP CHARGE | 0.7 | +95.4 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 2.0 | +12.9 | 0.0 | 0.0 | 0.7 | +3.7 | 182.7 | 182.7 |
| SPELLS IN THE FIGHT | 1.3 | +26.5 | 81.3 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 274.3 |
| STAND AND SHOOT | 0.3 | -2.2 | 0.0 | 0.0 | 0.3 | -11.1 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 3.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 69.7 | +0.0 | 2206.3 | 110.7 | 25.3 | +0.0 | 0.0 | 934.7 |
| STAY WORTH | 58.3 | +89.8 | 1987.0 | 130.0 | 12.3 | +196.3 | 0.0 | 1179.7 |
| STRIKE BY THE ODDS | 0.7 | +140.8 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 2.0 | +140.5 | 0.0 | 0.0 | 2.0 | +85.8 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 2.0 | +140.5 | 0.0 | 0.0 | 2.0 | +85.8 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +0.3 | 0.0 | 0.0 | 0.3 | +0.5 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 18.3 |
| THE ROW IN ITS ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 68.3 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 43.0 | +0.0 | 0.0 | 55.3 | 38.0 | +0.0 | 0.0 | 1133.0 |
| TIED UP BY THE SUM | 1.3 | +121.8 | 0.0 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 35.0 | +445.0 | 0.0 | 36.0 | - | - | - | - |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -12.5 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 0.3 | -4.8 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 1.0 | +144.6 | 40.7 | 0.0 | 0.3 | -1.5 | 0.0 | 0.0 |
| WHO HITS BACK | 0.3 | +89.0 | 0.0 | 0.0 | 0.3 | +27.3 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.3 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 1.3 | -221.3 | 0.0 | 0.0 | 2.3 | -158.2 | 0.0 | 262.3 |
| WOUNDS ON THE RANKS | 0.7 | +7.7 | 0.0 | 0.0 | 0.7 | +30.3 | 0.0 | 52.7 |

### Rule changes: gs3-83c8646-p89

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 97 | 97 | 70 | 23.33 | +1232 | +17.6 |
| HIS SHOT LIST | 257 | 256 | 64 | 21.33 | +1027 | +16.1 |
| HOLDER ASSIGNMENT | 65 | 65 | 58 | 19.33 | +4344 | +74.9 |
| HIS SHOTS BY HIS RUN | 188 | 187 | 47 | 15.67 | +1125 | +23.9 |
| DEPLOY BY FIGURES | 51 | 51 | 24 | 8.00 | +302 | +12.6 |
| SHOT RISK POINTS | 119 | 118 | 22 | 7.33 | +1061 | +48.2 |
| TIME ON OUR SIDE | 105 | 95 | 22 | 7.33 | +71 | +3.2 |
| OFF BEST | 19 | 19 | 19 | 6.33 | -476 | -25.1 |
| THE TABLE AGAIN | 36 | 36 | 18 | 6.00 | +0 | +0.0 |
| GOAL WALK | 78 | 77 | 17 | 5.67 | +956 | +56.2 |
| HARD STAY DROPPED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| STAY WORTH | 212 | 193 | 13 | 4.33 | +241 | +18.6 |
| FIVE ACTION | 551 | 546 | 12 | 4.00 | +1155 | +96.2 |
| LEGAL CHARGES ONLY | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| QUARTER ODDS | 142 | 139 | 11 | 3.67 | +721 | +65.5 |
| CHARGE LOSSES | 95 | 94 | 10 | 3.33 | +783 | +78.3 |
| FOUR ROUNDS | 14 | 13 | 9 | 3.00 | +427 | +47.4 |
| MEETS IN TIME | 22 | 22 | 9 | 3.00 | +621 | +69.0 |
| MOVE ORDER | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| IDLE COST | 49 | 32 | 8 | 2.67 | +56 | +7.0 |
| REDIRECT FOR A FRIEND IN REACH | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 22 | 22 | 7 | 2.33 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 11 | 11 | 6 | 2.00 | +230 | +38.4 |
| COVER ONCE | 37 | 23 | 5 | 1.67 | +61 | +12.3 |
| CANNON PLANNED TARGET | 38 | 38 | 4 | 1.33 | +0 | +0.0 |
| EVASIVE BY THE ODDS | 9 | 9 | 4 | 1.33 | +150 | +37.6 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +196 | +48.9 |
| SHOTS IN THE MOVE | 101 | 76 | 4 | 1.33 | +89 | +22.2 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| ASSAILMENT BY POINTS | 3 | 3 | 3 | 1.00 | +13 | +4.5 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CASTING BLOCK | 5 | 5 | 3 | 1.00 | +82 | +27.2 |
| FIRE IN ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | +62 | +20.5 |
| RISK BY ARC | 12 | 11 | 3 | 1.00 | +23 | +7.6 |
| SEARCH SPOT | 3 | 3 | 3 | 1.00 | +24 | +8.1 |
| SET UP BY THE SET | 11 | 10 | 3 | 1.00 | +43 | +14.4 |
| BEST PRIZE | 2 | 2 | 2 | 0.67 | -63 | -31.6 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +68 | +34.1 |
| CHARGE NOW FIRST | 7 | 7 | 2 | 0.67 | -21 | -10.5 |
| EXACT ROUND | 11 | 10 | 2 | 0.67 | +269 | +134.5 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +251 | +125.7 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.67 | +84 | +41.8 |
| GOAL ROUTE | 2 | 2 | 2 | 0.67 | +13 | +6.3 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +109 | +54.5 |
| NEARER NOT NEEDED | 54 | 52 | 2 | 0.67 | +47 | +23.6 |
| RANDOM MOVE BY FIGURES | 5 | 5 | 2 | 0.67 | +82 | +41.2 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +472 | +236.2 |
| REFUSING RETIRES | 3 | 3 | 2 | 0.67 | -38 | -19.2 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHORT GUN FORWARD | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SPELLS IN THE FIGHT | 4 | 3 | 2 | 0.67 | +21 | +10.6 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +249 | +124.7 |
| SUPPORT ADDS | 12 | 11 | 2 | 0.67 | +113 | +56.5 |
| SUPPORT WORKED OUT | 12 | 11 | 2 | 0.67 | +113 | +56.5 |
| SWIFTSTRIDE BY POINTS | 2 | 2 | 2 | 0.67 | +2 | +1.2 |
| THE ROW IN ITS ORDER | 14 | 2 | 2 | 0.67 | +0 | +0.0 |
| TIED UP BY THE SUM | 4 | 4 | 2 | 0.67 | +47 | +23.4 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +320 | +159.9 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +18 | +18.0 |
| CARRIES OUT SET-UP | 2 | 2 | 1 | 0.33 | -50 | -50.5 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -28 | -28.0 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 12 | 11 | 1 | 0.33 | +2 | +2.1 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +11 | +11.0 |
| GUN MASK | 21 | 21 | 1 | 0.33 | +39 | +38.9 |
| HIS CHARGE DENIED | 1 | 1 | 1 | 0.33 | +50 | +49.8 |
| HOLDS AMBUSHERS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| MARCH CHECK | 1 | 1 | 1 | 0.33 | +13 | +13.4 |
| MOVE TO CHARGE COMPUTED | 11 | 10 | 1 | 0.33 | +8 | +7.6 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| NEXT CHARGE BY LIST | 11 | 10 | 1 | 0.33 | +8 | +7.6 |
| ONE OBJECTIVE FORMULA | 22 | 18 | 1 | 0.33 | +40 | +40.1 |
| OVERRUNS AWAY | 3 | 3 | 1 | 0.33 | +21 | +21.4 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +46 | +46.3 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +101 | +101.3 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -38 | -37.5 |
| WHO FIGHTS | 4 | 4 | 1 | 0.33 | +248 | +247.6 |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAFF IN THE MOVE | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 67 | 63 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 5 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| FALLS SHORT | 61 | 57 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 5 | 5 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 32 | not checked | - | - | - | - |
| FOOT FIRST | 54 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 5 | 4 | 0 | 0.00 | - | - |
| GUN FIGURES | 9 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 5 | 4 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 44 | 44 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 22 | 22 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 13 | 13 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 14 | 14 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 35 | 33 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 21 | 21 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 22 | 20 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 5 | 5 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HOLD ODDS | 76 | 76 | 0 | 0.00 | - | - |
| HONEST WORTH | 12 | 12 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 6 | 6 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 12 | 11 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MANOEUVRE | 14 | 14 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MAX FOR POSITIONING | 5 | 5 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 5 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 3 | 1 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 4 | trace | - | - | - | - |
| NEAREST TO GOAL | 2 | 2 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 4 | 4 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 13 | 12 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 12 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 26 | 19 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 249 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE BY ITS OWN SUM | 11 | 11 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 5 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 3 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 13 | 12 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 4 | 3 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 6 | 2 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 2 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 74 | not checked | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 6 | 6 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 2 | not checked | - | - | - | - |
| SPELL WORTH | 8 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 28 | 26 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 9 | 9 | 0 | 0.00 | - | - |
| STANDS STILL | 285 | 285 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 10 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 19 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 12 | not checked | - | - | - | - |
| THE TABLE BINDS | 243 | not checked | - | - | - | - |
| WAITS AGAIN | 5 | 5 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 4 | 3 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p89

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.00 | 1.67 | 27.6 |
| ARMY TABLE | rule | 1.33 | 1.67 | 69.6 |
| HOLDER ASSIGNMENT | rule | 1.00 | 0.33 | 32.6 |
| BEST PRIZE | rule | 0.67 | - | 31.6 |
| CHARGE NOW FIRST | rule | 0.67 | - | 10.5 |
| CARRIES OUT SET-UP | rule | 0.33 | - | 50.5 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 28.0 |
| FIGHT ORDER BAND | gate | 0.33 | - | 0.6 |
| JOINT CHARGE NOW | rule | 0.33 | - | 36.6 |
| NO REASON | gate | 0.33 | - | 6.5 |
| REFUSING RETIRES | rule | - | 0.33 | 38.0 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 37.5 |

### Plans: gs3-83c8646-p89

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.0 | 33% | 411 | 186 | 45% |
| Mine | join | 0.3 | 100% | 0 | 0 | - |
| Mine | move | 23.0 | 97% | 1232 | 0 | 0% |
| Mine | shoot | 18.7 | 71% | 1005 | 1069 | 106% |
| Opponent | charge | 0.7 | 100% | 20 | 39 | 201% |
| Opponent | move | 34.3 | 91% | 1696 | 0 | 0% |
| Opponent | shoot | 3.0 | 33% | 173 | 64 | 37% |

### Battle groups: gs3-83c8646-p89

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 100% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 1.3 | 50% | 50% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p89

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 50% | 4.0 | - | - | 0 (2) | - | 0 (2) |
| Mine | Character | 12 | 22 (12) | 22 | 0 | 3 | 75% | 3.3 | 33 (8) | 0 (2) | 0 (2) | 53 (5) | 0 (7) |
| Mine | Clean-up | 2 | 112 (2) | 0 | 112 | 32 | 0% | 4.5 | 112 (2) | - | - | 55 (1) | 139 (1) |
| Mine | Fast Hammer | 4 | 76 (4) | 7 | 69 | 0 | 0% | 2.2 | 98 (2) | 54 (2) | - | 54 (2) | 98 (2) |
| Mine | Hammer | 4 | 8 (4) | 8 | 0 | 0 | 50% | 1.0 | - | 19 (2) | 0 (2) | 19 (2) | 0 (2) |
| Mine | Shooter | 4 | 205 (4) | 124 | 81 | 0 | 0% | 1.2 | - | 256 (2) | 97 (2) | 457 (1) | 75 (3) |
| Mine | War machine | 11 | 17 (11) | 17 | 0 | 9 | 0% | 1.5 | 0 (4) | 26 (7) | - | 61 (3) | 0 (8) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 2.0 | - | - | 0 (2) | - | 0 (2) |
| Opponent | Chaff | 3 | 129 (3) | 0 | 129 | 39 | 33% | 4.0 | 129 (3) | - | - | 129 (3) | - |
| Opponent | Character | 6 | 0 (6) | 0 | 0 | 55 | 50% | 4.0 | 0 (5) | - | 0 (1) | 0 (2) | 0 (4) |
| Opponent | Clean-up | 5 | 42 (5) | 0 | 42 | 60 | 40% | 2.0 | 80 (2) | 28 (2) | 0 (1) | 40 (4) | 53 (1) |
| Opponent | Fast Hammer | 4 | 0 (4) | 0 | 0 | 40 | 0% | 2.8 | 0 (1) | 0 (2) | 0 (1) | 0 (1) | 0 (3) |
| Opponent | Hammer | 8 | 38 (8) | 10 | 28 | 27 | 62% | 3.7 | 44 (3) | 47 (4) | 0 (1) | 41 (5) | 34 (3) |
| Opponent | Holder | 1 | 0 (1) | 0 | 0 | 0 | 0% | 3.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Shooter | 2 | 54 (2) | 18 | 36 | 0 | 0% | 1.0 | - | 82 (1) | 32 (1) | 54 (2) | - |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 42 | 0% | 2.3 | 0 (2) | - | - | - | 0 (2) |

### Charged fights: gs3-83c8646-p89

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 3 | 132 | 109 | 2.7 | 1.0 | 41 | 0 | +41 | 1 of 8 | 7 of 8 | - | +41 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 36 | 4.0 | 1.0 | 9 | 0 | +9 | 2 of 4 | 3 of 4 | - | +9 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Wood Elf Realms | 1 | 45 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 15 | 12 | 1.3 | 1.0 | 9 | 0 | +9 | 2 of 4 | 3 of 4 | - | +9 |

### Effective charges: gs3-83c8646-p89

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 8 | 0 | 0 | 2 (net +0) | 1 (net +0) | 0 | 3 (net +68) | 2 | 33% (2 of 6) |
| Opponent | Orc & Goblin Tribes | 4 | 0 | 0 | 1 (net +0) | 0 | 0 | 1 (net +36) | 2 | 50% (1 of 2) |

### Charged fights, damage counted: gs3-83c8646-p89

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 2 | 227 | 274 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 76-89% | 1 | 181 | 122 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 214 | 175 | +68 | 122 | 27 | +95 | +44.3 |
| Mine | No odds | 2 | 380 | 205 | +61 | 134 | 87 | +48 | +12.6 |
| Mine | All fights | 8 | 255 | 201 | +41 | 79 | 32 | +48 | +18.7 |
| Opponent | Effective (55-75%) | 1 | 235 | 164 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 60 | 36 | +36 | 36 | 0 | +36 | +60.0 |
| Opponent | No odds | 2 | 55 | 265 | +0 | 40 | 122 | -82 | -149.4 |
| Opponent | All fights | 4 | 101 | 182 | +9 | 29 | 61 | -32 | -31.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p89 | move | 17 | 6 (35%) | 4 (24%) | 1 (6%) | 10 (59%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Elixir of Power | Opponent | L0819 |
| Twice-Blessed Armour | Mine | L0729 |
| Witch Hunter's Ward | Mine | L0729, L0819, L0835 |

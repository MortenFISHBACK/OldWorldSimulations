# Doctrine scorecard: gs3-83c8646-p44

### Scorecard: gs3-83c8646-p44

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1331 | 5 | 1 | Mine | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 291 |
| L1331 | 5 | 1 | Opponent | yes | - | 4 | 2 | 4 | 1 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Mine | yes | - | 3 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | no | - | 2 | 2 | 2 | 0 | 0 | 0 | 186 |
| L1523 | 5 | 1 | Mine | yes | - | 4 | 2 | 2 | 0 | 0 | 0 | 60 |
| L1523 | 5 | 1 | Opponent | yes | - | - | 1 | 3 | 1 | 0 | 0 | 185 |
| **Average** | | | Mine | 100% | - | 3.0 | 3.0 | 2.0 | 0.0 | 0.0 | 0.0 | 117.0 |
| **Average** | | | Opponent | 67% | - | 3.0 | 1.7 | 3.0 | 0.7 | 0.0 | 0.0 | 123.7 |

### KPIs: gs3-83c8646-p44

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 13) | 0% (0 of 14) | 0% (0 of 27) |
| Winner chose to follow up after the loser gave ground |  | 100% (4 of 4); on the table 100% | 75% (3 of 4); on the table 75% | 88% (7 of 8); on the table 88% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (2 of 2); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (5 of 5); on the table 100% | 83% (5 of 6); on the table 83% | 91% (10 of 11); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 33% (2 of 6) | 42% (5 of 12) | 39% (7 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 33% (2 of 6) | 45% (5 of 11) | 41% (7 of 17) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 78% (7 of 9) | 78% (7 of 9) |
| Points that never fought | lower | 58% (3461 of 6000) | 49% (2945 of 6000) | 53% (6406 of 12000) |
|   infantry points that never fought | lower | 85% (886 of 1048) | 63% (497 of 787) | 75% (1383 of 1835) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 67% (16 of 24) | 83% (19 of 23) | 74% (35 of 47) |
| Bound items with a magic missile used (at least once a game) |  | 100% (3 of 3); 3.3 uses a game | 0% (0 of 1); 0.0 uses a game | 75% (3 of 4); 1.7 uses a game |
| Bound items with another spell used |  | 38% (3 of 8); 2.0 uses a game | 0.0 uses a game | 38% (3 of 8); 1.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 63% (3680 of 5800) | 75% (3734 of 4992) | 69% (7414 of 10792) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (50%) | 1.3 (57%) | 2.0 (55%) |
| MARCHED: its unit marched | 0.7 (50%) | 0.0 (0%) | 0.7 (18%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.3 (14%) | 0.3 (9%) |
| GONE: slain | 0.0 (0%) | 0.3 (14%) | 0.3 (9%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.3 (14%) | 0.3 (9%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 5.7 | 4.3 | 3.7 | 2.3 | 3.7 |
| not cast | 4.3 | 1.7 | 2.3 | 3.7 | 24.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.7 (100%) | 0.3 (14%) | 2.0 (55%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (18%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (9%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 1.0 (43%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| GONE: slain | 0.3 (8%) | 0.0 (0%) | 0.0 (0%) | 0.3 (9%) | 0.7 (3%) |
| STUPIDITY: Stupidity | 0.7 (15%) | 0.0 (0%) | 0.0 (0%) | 0.3 (9%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.3 (77%) | 0.0 (0%) | 1.0 (43%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 22.3 (92%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 3.7 a game | 0.0 a game | 1.8 a game |
| stood (cast and not dispelled) | 60% (3 of 5) | - | 60% (3 of 5) |
| the unit moved after it | 100% (3 of 3) | - | 100% (3 of 3) |
| it charged on its next turn | 0% (0 of 3) | - | 0% (0 of 3) |
| the enemy charged it first | 0% (0 of 3) | - | 0% (0 of 3) |
| it fought by the end of its next turn | 0% (0 of 3) | - | 0% (0 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 3) | - | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | 100% (3 of 3) | - | 100% (3 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 68% (59 of 87) | 59% (24 of 41) | 65% (83 of 128) |
|   cavalry | 80% (4 of 5) | 100% (7 of 7) | 92% (11 of 12) |
|   character | 26% (9 of 34) | 0% (0 of 11) | 20% (9 of 45) |
|   chariot | 83% (5 of 6) | - | 83% (5 of 6) |
|   infantry | 97% (29 of 30) | 74% (17 of 23) | 87% (46 of 53) |
|   war machine | 100% (12 of 12) | - | 100% (12 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (29%) | 0.0 (0%) | 2.7 (18%) |
| CHARGED: it charged | 2.3 (25%) | 0.0 (0%) | 2.3 (16%) |
| NO TARGET IN RANGE | 3.0 (32%) | 5.3 (94%) | 8.3 (56%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (4%) | 0.3 (6%) | 0.7 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (11%) | 0.0 (0%) | 1.0 (7%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.3 | 1.3 | 81% | 4.9 pts | 26 pts |
| character | 4.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 1.7 | 1.0 | 80% | 19.5 pts | 32 pts |
| infantry | 25.3 | 13.0 | 67% | 9.6 pts | 244 pts |
| war machine | 4.0 | 3.0 | 42% | 25.3 pts | 101 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.0 | 2.0 | 3.0 |
| Charges that made contact a game | 3.3 | 0.7 | 2.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.50 declared, 1.50 contact (2 units) | 1.00 declared, 0.00 contact (1 units) | 1.33 declared, 1.00 contact (3 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.41 declared, 0.32 contact (22 units) | 0.21 declared, 0.08 contact (24 units) | 0.30 declared, 0.20 contact (46 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 69% (9 of 13) | 100% (1 of 1) | 100% (2 of 2) | 75% (12 of 16) |
| Character in a unit | 100% (1 of 1) | - | - | 100% (1 of 1) |
| Character on its own | 100% (5 of 5) | 50% (1 of 2) | 56% (5 of 9) | 69% (11 of 16) |
| Chariot | 100% (1 of 1) | - | - | 100% (1 of 1) |
| Infantry | 75% (6 of 8) | 100% (1 of 1) | - | 78% (7 of 9) |
| Monster | 75% (3 of 4) | - | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 3 | 100% (5 of 5); on the table 100% | 33% (2 of 6) | 58% | 67% (16 of 24) | 100% (3 of 3); 3.3 uses a game | 38% (3 of 8); 2.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | - | - | 72% | 80% (4 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (2 of 2); on the table 100% | 50% (3 of 6) | 47% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 75% (3 of 4); on the table 75% | 33% (2 of 6) | 29% | 92% (11 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p44, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | - | 25% (2) | 25% (2) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.67 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.67 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.67 | 0.67 |

### Quality by phase: gs3-83c8646-p44

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 4.7 |
| Strategy | Charge objectives carried out (made contact) | 67% (8 of 12) | 0% (0 of 6) |
| Strategy | Shoot objectives carried out (shot that target) | 52% (14 of 27) | 78% (7 of 9) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | 100% (1 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 80% (4 of 5) | - |
| Strategy | Joined characters whose unit fought | - | 0% (0 of 2) |
| Strategy | Lone characters that fought | 57% (4 of 7) | 67% (8 of 12) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.0 | 3.0 |
| Movement | Points that never moved of their own | 117.0 | 123.7 |
| Movement | Fights charged into per game | 3.3 | 0.3 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 10, net +0 | 0 of 1 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 10, net -50 | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 10, net +105 | 1 of 1, net +0 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 10, net +57 | 0 of 1 |
| Shooting | Shots by shooting units (incl. breath weapons) | 16.7 | 8.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 26% (13 of 50) | 23% (6 of 26) |
| Shooting | Points destroyed by shooting units | 127.7 | 20.0 |
| Shooting | War machine shots | 4.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 33% (4 of 12) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.7 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 50% (1 of 2) | 33% (1 of 3) |
| Magic | Wounds caused by magic missiles | 2.3 | - |
| Magic | Wounds caused by other spells | 6.7 | - |
| Magic | Points destroyed by magic (all spells) | 172.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 2.3 / 2.7 / 0.0 | 2.7 / 0.0 / 0.7 / 0.0 |
| Combat | Points destroyed in combat | 183.3 | 116.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +23 | +101 |
| Combat | Net per 100 charger points, damage counted | +6.8 | +19.9 |
| Combat | First round won (charged fights) | 90% | 100% |
| Combat | Net points per charged fight | +20 | +0 |
| Combat | Net points per supported fight / lone fight | - / +20 | +0 / - |
| Combat | Charged fights on a top-3 enemy unit | 2 of 10 | 0 of 1 |
| Game | Points lost | 218.7 | 531.3 |
| Game | VP from objectives | 516.7 | 550.0 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +291 VP
- The side that went first won 2 of 2 games with a winner
- Points traded per game (both sides' losses): 750
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: gs3-83c8646-p44

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.3 | +263.2 | 0.0 | 67.0 |
| ARMY TABLE | 32.3 | +725.1 | 0.0 | 287.0 | 26.0 | +632.6 | 0.0 | 205.7 |
| ASSAILMENT BY POINTS | 0.3 | +3.6 | 0.0 | 0.0 | 0.3 | +1.3 | 0.0 | 63.3 |
| BACKUP TARGETS | - | - | - | - | 1.0 | +1.2 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.3 | -175.1 | 0.0 | 67.0 |
| CANNON PLAN MISSED | 1.0 | +0.0 | 116.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 3.7 | +137.4 | 335.0 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 0.7 | +1.4 | 0.0 | 0.0 | 0.7 | +3.7 | 0.0 | 40.0 |
| CASTS AFTER FRIENDS | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.0 | +30.8 | 0.0 | 59.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.3 | +1.8 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | 0.3 | -5.3 | 38.7 | 50.3 | - | - | - | - |
| CHARGE LOSSES | 8.7 | -319.9 | 0.0 | 82.0 | 16.7 | -626.1 | 0.0 | 167.3 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 41.0 | 0.0 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 110.3 | 66.3 | 0.3 | +0.0 | 41.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 11.3 | +0.0 | 0.0 | 0.0 | 8.7 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 23.3 |
| CONVEYANCE SEARCH | 1.3 | +93.1 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 7.3 | -341.2 | 0.0 | 123.0 | 8.3 | -556.3 | 0.0 | 58.7 |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -7.6 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 7.3 | -40.0 | 0.0 | 20.0 | 6.3 | +17.3 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.7 | -16.2 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +3.4 | 18.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 3.0 | +3.1 | 247.0 | 116.7 | 1.0 | +43.3 | 107.3 | 90.3 |
| FALL BACK GOOD ORDER | 2.0 | +0.0 | 181.0 | 116.7 | 1.3 | +4.0 | 107.3 | 23.3 |
| FALLS SHORT | 8.0 | +110.1 | 0.0 | 0.0 | 12.3 | +161.3 | 0.0 | 110.0 |
| FEATURE BUFFS | 0.3 | +1.4 | 0.0 | 0.0 | 1.3 | +4.9 | 0.0 | 88.0 |
| FIGHT LIFT | 0.3 | +1.8 | 66.3 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.3 | +15.0 | 0.0 | 0.0 | - | - | - | - |
| FIRE IN ORDER | 1.0 | +0.0 | 67.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 90.7 | +7308.2 | 1351.3 | 444.7 | 92.0 | +4771.2 | 188.3 | 663.7 |
| FLANK NOT WEIGHED | 1.7 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 84.7 |
| FOLLOW UP WEIGHED | 1.0 | +301.4 | 0.0 | 0.0 | 1.0 | +74.6 | 0.0 | 0.0 |
| FOOT FIRST | - | - | - | - | 25.0 | +0.0 | 0.0 | 146.0 |
| FOUR ROUNDS | 4.0 | +441.8 | 334.0 | 116.7 | 2.0 | +431.5 | 148.3 | 90.3 |
| FREED FROM HIS FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 34.7 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -7.9 | 0.0 | 0.0 |
| GIVES UP | 1.0 | -7.2 | 125.0 | 0.0 | - | - | - | - |
| GOAL WALK | 13.7 | +1096.5 | 0.0 | 0.0 | 3.3 | +424.6 | 0.0 | 0.0 |
| GUN FIGURES | 1.3 | +28.2 | 180.3 | 0.0 | - | - | - | - |
| GUN MASK | 0.7 | +56.1 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 3.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 62.0 |
| HE REFORMS ONCE FREED | 0.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 34.7 |
| HIS CHARGE BY HIS RUN | 3.7 | +0.0 | 0.0 | 82.0 | 9.3 | +0.0 | 0.0 | 90.0 |
| HIS CHARGE DENIED | 1.0 | +14.4 | 133.3 | 66.3 | - | - | - | - |
| HIS CHARGE LIST | 1.7 | +0.0 | 0.0 | 41.0 | 12.3 | +0.0 | 0.0 | 165.0 |
| HIS LEGAL MOVES | 8.0 | +0.0 | 0.0 | 164.0 | 4.3 | +0.0 | 0.0 | 62.0 |
| HIS MOVE AND SHOT | 0.3 | -18.3 | 0.0 | 0.0 | 5.0 | -205.3 | 0.0 | 44.0 |
| HIS ONE QUARTER | 7.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 38.7 |
| HIS OWN BEST MOVE | 9.3 | +0.0 | 0.0 | 164.0 | 5.3 | +0.0 | 0.0 | 62.0 |
| HIS RANDOM MOVE | 9.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 27.7 | +592.3 | 0.0 | 246.0 | 58.0 | +1597.4 | 0.0 | 423.3 |
| HIS SHOTS BY HIS RUN | 18.3 | +173.2 | 0.0 | 0.0 | 55.0 | +1143.1 | 0.0 | 533.3 |
| HIS TURN DENIED | 1.0 | +8.9 | 42.0 | 0.0 | 1.0 | +13.9 | 0.0 | 67.0 |
| HOLD ODDS | 8.3 | +0.0 | 0.0 | 0.0 | 10.3 | +0.0 | 0.0 | 220.0 |
| HOLDER ASSIGNMENT | 4.3 | +389.3 | 0.0 | 50.3 | 4.7 | +333.2 | 0.0 | 66.0 |
| HOLDS AMBUSHERS | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.0 | -120.5 | 334.0 | 116.7 | 1.0 | -55.0 | 41.0 | 0.0 |
| IDLE COST | 3.0 | -79.6 | 0.0 | 0.0 | 10.3 | -83.0 | 0.0 | 15.0 |
| JOINT CHARGE NOW | 0.3 | +23.5 | 62.0 | 0.0 | 1.0 | -16.4 | 66.3 | 23.3 |
| JOINT ON THE TABLE | 0.3 | +23.5 | 62.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +36.8 | 0.0 | 0.0 | 0.7 | +13.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.0 | +0.0 | 20.0 | 189.3 | 5.7 | +0.0 | 86.3 | 233.3 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.3 | +23.9 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 2.7 | -0.3 | 191.3 | 66.3 | 1.0 | +1.6 | 66.3 | 23.3 |
| MAKE SURE TOGETHER | 0.3 | +6.0 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 1.0 | -14.6 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +52.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.3 | +10.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.3 | +16.6 | 0.0 | 0.0 | 0.3 | +18.2 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.7 | +7.9 | 0.0 | 0.0 | 0.3 | +8.1 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 0.7 | +9.3 | 0.0 | 0.0 | 0.7 | +10.4 | 0.0 | 38.7 |
| MEETS IN TIME | 2.7 | -24.5 | 0.0 | 20.0 | 3.0 | -46.8 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 5.0 | +79.8 | 0.0 | 0.0 | 2.3 | +32.2 | 0.0 | 20.0 |
| MISSILES NEXT TURN | 6.3 | +43.0 | 0.0 | 0.0 | 3.0 | +33.2 | 0.0 | 20.0 |
| MOVE ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 22.0 | 0.0 |
| MOVE SPELL SPOT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 4.0 | +221.0 | 0.0 | 82.0 | 5.3 | +428.0 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 8.7 | +332.6 | 0.0 | 41.0 | 9.0 | +267.3 | 0.0 | 62.0 |
| NEAREST TO GOAL | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 2.3 | +140.3 | 0.0 | 0.0 | 3.7 | +256.8 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -1.0 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 3.3 | -115.8 | 294.0 | 116.7 | 1.3 | -42.1 | 148.3 | 90.3 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.7 | +1.7 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 2.7 | -76.3 | 0.0 | 41.0 | 4.7 | -143.7 | 0.0 | 22.0 |
| ONE CHALLENGE TEST | 0.3 | -0.3 | 48.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 4.3 | -159.4 | 0.0 | 41.0 | 4.7 | -57.4 | 0.0 | 103.3 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +7.6 | 66.3 | 23.3 |
| ONE OBJECTIVE FORMULA | 2.3 | +133.3 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 66.0 |
| ONE ROUTE | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.7 | +28.9 | 37.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.3 | +1.8 | 62.0 | 0.0 | 0.3 | +9.3 | 41.0 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +1.7 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -4.9 | 0.0 | 0.0 |
| PLAN RESULT | 40.7 | +819.3 | 231.7 | 356.3 | 44.7 | +139.0 | 86.3 | 742.7 |
| PROMISE BELOW ZERO | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 6.7 | -66.5 | 0.0 | 41.0 | 9.3 | -384.5 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -31.6 | 0.0 | 0.0 | 0.3 | -6.4 | 0.0 | 15.0 |
| PROMISE SHOT AWAY | 0.3 | -0.5 | 48.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 25.0 | +3089.3 | 370.0 | 66.3 | 29.0 | +2551.5 | 66.3 | 210.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.0 | +32.6 | 0.0 | 56.7 |
| REAL GROUND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 2.0 | +114.9 | 0.0 | 59.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.7 | +0.0 | 0.0 | 62.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 2.0 | -63.8 | 0.0 | 82.0 | 0.7 | -33.5 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 50.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.7 | +4.2 | 0.0 | 18.0 |
| RISK BY ARC | 3.3 | +150.0 | 268.0 | 116.7 | 1.3 | -35.6 | 148.3 | 90.3 |
| RISK ON THE WAY | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.3 | -6.4 | 48.0 | 0.0 | 0.3 | -1.8 | 41.0 | 0.0 |
| RUN DOWN | 1.3 | -34.8 | 153.7 | 50.3 | 1.7 | -7.1 | 148.3 | 23.3 |
| SCOUT SPOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +5.0 | 0.0 | 0.0 | 0.3 | +0.5 | 0.0 | 0.0 |
| SELF MOVE SPELL | 2.0 | +279.8 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 2.3 | -130.0 | 0.0 | 96.0 |
| SET UP BY THE SET | 0.3 | +4.4 | 0.0 | 0.0 | 3.0 | +87.6 | 0.0 | 96.0 |
| SET UP TOGETHER | 0.3 | +6.0 | 0.0 | 0.0 | - | - | - | - |
| SET-UP ANY TARGET | 0.7 | +64.1 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.7 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 9.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 20.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +144.5 | 0.0 | 0.0 | 0.3 | +9.4 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.7 | -12.5 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 11.7 | -114.3 | 0.0 | 0.0 | 38.3 | -161.0 | 0.0 | 329.3 |
| SHOTS AFTER THE MOVES | 4.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 19.7 | +640.5 | 0.0 | 123.0 | 6.7 | +89.6 | 0.0 | 88.0 |
| SPELL SETS UP CHARGE | 0.7 | +64.1 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 2.0 | +20.4 | 66.3 | 0.0 | 1.3 | +14.7 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 1.3 | +29.3 | 138.7 | 50.3 | 0.3 | -2.6 | 41.0 | 0.0 |
| SPOT AS THE GAME MOVES | 5.0 | +0.0 | 0.0 | 41.0 | 7.7 | +0.0 | 0.0 | 82.7 |
| STAND AND SHOOT | 0.3 | -0.2 | 22.0 | 0.0 | 1.0 | -14.0 | 41.0 | 0.0 |
| STANDS FOR A REASON | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 38.3 | +0.0 | 1017.3 | 82.0 | 43.0 | +0.0 | 40.0 | 135.3 |
| STAY WORTH | 29.3 | +41.5 | 780.0 | 82.0 | 7.3 | +49.5 | 0.0 | 44.0 |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 56.7 |
| SUPPORT ADDS | 4.7 | +152.2 | 0.0 | 0.0 | 6.3 | +685.3 | 0.0 | 124.0 |
| SUPPORT NARROWED | 0.7 | +0.0 | 23.3 | 66.3 | - | - | - | - |
| SUPPORT WORKED OUT | 4.7 | +152.2 | 0.0 | 0.0 | 6.3 | +685.3 | 0.0 | 124.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.7 | +1.1 | 0.0 | 38.7 |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 22.0 |
| THE PROMISE ADDS | 0.7 | -39.6 | 0.0 | 0.0 | 0.3 | -11.1 | 0.0 | 15.0 |
| THE ROW IN ITS ORDER | 2.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 18.0 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 0.3 | +0.0 | 0.0 | 38.7 |
| THE STEP BACK IS MADE | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 18.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 42.7 | +0.0 | 0.0 | 164.0 | 45.7 | +0.0 | 0.0 | 258.3 |
| TIED UP BY THE SUM | 1.3 | +140.3 | 105.0 | 0.0 | 0.7 | +167.6 | 41.0 | 67.0 |
| TIME ON OUR SIDE | 29.0 | +355.2 | 0.0 | 246.0 | 32.7 | +218.2 | 0.0 | 88.0 |
| WHO FIGHTS | 1.3 | +0.2 | 172.0 | 116.7 | 0.3 | -2.3 | 66.3 | 23.3 |
| WHO GETS IN | 0.3 | +23.5 | 62.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.3 | +5.0 | 0.0 | 66.3 | - | - | - | - |
| WHOLE FIGHT DANGER | 2.3 | -164.5 | 0.0 | 82.0 | 0.7 | -26.1 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +0.8 | 66.3 | 23.3 |
| WOUNDED STAYS OUT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 2.7 | +40.2 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p44

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 175 | 175 | 126 | 42.00 | +3262 | +25.9 |
| HIS SHOT LIST | 257 | 240 | 54 | 18.00 | +979 | +18.1 |
| HIS SHOTS BY HIS RUN | 220 | 203 | 39 | 13.00 | +347 | +8.9 |
| QUARTER ODDS | 162 | 153 | 31 | 10.33 | +2826 | +91.1 |
| FIVE ACTION | 548 | 529 | 29 | 9.67 | +1714 | +59.1 |
| HOLDER ASSIGNMENT | 27 | 27 | 27 | 9.00 | +1943 | +72.0 |
| THE TABLE AGAIN | 36 | 36 | 26 | 8.67 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 23 | 23 | 23 | 7.67 | +0 | +0.0 |
| DEPLOY BY FIGURES | 41 | 41 | 22 | 7.33 | +143 | +6.5 |
| OFF BEST | 22 | 22 | 22 | 7.33 | -660 | -30.0 |
| PROMISE BY ITS OWN SUM | 48 | 48 | 20 | 6.67 | -1353 | -67.7 |
| HARD STAY DROPPED | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| TIME ON OUR SIDE | 185 | 167 | 16 | 5.33 | +54 | +3.4 |
| FOUR ROUNDS | 18 | 18 | 12 | 4.00 | +825 | +68.7 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 28 | 25 | 11 | 3.67 | +531 | +48.2 |
| ADVANCE LANE KEPT | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 18 | 18 | 9 | 3.00 | +650 | +72.3 |
| GOAL WALK | 51 | 51 | 8 | 2.67 | +473 | +59.1 |
| MEETS IN TIME | 17 | 17 | 8 | 2.67 | +22 | +2.7 |
| SHOT RISK POINTS | 150 | 144 | 8 | 2.67 | +324 | +40.6 |
| SUPPORT ADDS | 33 | 33 | 8 | 2.67 | +648 | +81.0 |
| SUPPORT WORKED OUT | 33 | 33 | 8 | 2.67 | +648 | +81.0 |
| RANDOM MOVE BY FIGURES | 9 | 9 | 7 | 2.33 | +98 | +14.0 |
| SET UP BY THE SET | 10 | 10 | 7 | 2.33 | +215 | +30.8 |
| STAY WORTH | 110 | 104 | 7 | 2.33 | +43 | +6.2 |
| CHARGE LOSSES | 76 | 73 | 6 | 2.00 | +394 | +65.7 |
| COVER ONCE | 47 | 38 | 6 | 2.00 | +19 | +3.1 |
| FIRE IN ORDER | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 6 | 6 | 6 | 2.00 | +1128 | +188.0 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +149 | +24.9 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CAST JOB | 4 | 4 | 4 | 1.33 | +1 | +0.2 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | +21 | +5.3 |
| SHOOTS FROM THE BEST SPOT | 5 | 5 | 4 | 1.33 | +319 | +79.8 |
| TIED UP BY THE SUM | 6 | 6 | 4 | 1.33 | +154 | +38.6 |
| CHARGE NOW FIRST | 8 | 8 | 3 | 1.00 | -155 | -51.5 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| IDLE COST | 40 | 31 | 3 | 1.00 | +13 | +4.2 |
| NEARER NOT NEEDED | 53 | 50 | 3 | 1.00 | +57 | +18.9 |
| RISK BY ARC | 14 | 14 | 3 | 1.00 | +97 | +32.4 |
| SHOTS IN THE MOVE | 79 | 61 | 3 | 1.00 | +172 | +57.2 |
| ASSAILMENT BY POINTS | 2 | 2 | 2 | 0.67 | +15 | +7.5 |
| CANNON SIGHT KEPT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FALLS SHORT | 61 | 59 | 2 | 0.67 | +37 | +18.7 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +158 | +79.2 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -104 | -52.2 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +12 | +6.2 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SEARCH SPOT | 2 | 2 | 2 | 0.67 | +16 | +8.1 |
| SET CREDITED ONCE | 7 | 7 | 2 | 0.67 | +58 | +29.1 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +2 | +1.0 |
| SHOTS AFTER THE MOVES | 18 | 18 | 2 | 0.67 | +0 | +0.0 |
| SPELLS IN THE FIGHT | 5 | 5 | 2 | 0.67 | +66 | +32.8 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +790 | +789.6 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -525 | -525.3 |
| CANNON PLANNED TARGET | 11 | 11 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +6 | +5.5 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -2 | -1.6 |
| EXACT ROUND | 12 | 12 | 1 | 0.33 | +2 | +1.6 |
| GUN MASK | 2 | 2 | 1 | 0.33 | +59 | +59.4 |
| HIS CHARGE DENIED | 3 | 3 | 1 | 0.33 | +14 | +13.7 |
| HIS TURN DENIED | 6 | 6 | 1 | 0.33 | +15 | +15.1 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.33 | +70 | +70.5 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +72 | +71.6 |
| MAX FOR POSITIONING | 4 | 4 | 1 | 0.33 | +0 | +0.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| ONE OBJECTIVE FORMULA | 15 | 9 | 1 | 0.33 | +38 | +37.8 |
| OPENS UP | 2 | 2 | 1 | 0.33 | +14 | +14.5 |
| OVERRUNS AWAY | 2 | 2 | 1 | 0.33 | +2 | +1.6 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +5 | +5.0 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -15 | -14.7 |
| PROMISE READS THE TABLE | 2 | 2 | 1 | 0.33 | -17 | -17.3 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -2 | -1.6 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +84 | +84.0 |
| SHOT OR CHARGE | 2 | 2 | 1 | 0.33 | +12 | +12.5 |
| SUPPORT NARROWED | 2 | 2 | 1 | 0.33 | -57 | -57.4 |
| THE ROW IN ITS ORDER | 13 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 5 | 5 | 1 | 0.33 | +2 | +2.3 |
| WHO GETS IN | 1 | 1 | 1 | 0.33 | +70 | +70.5 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +15 | +15.1 |
| BACKUP TARGETS | 3 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 3 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 8 | trace | - | - | - | - |
| CHAFF IN THE MOVE | 3 | 3 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 60 | 60 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 4 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 10 | 10 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 5 | 5 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 29 | not checked | - | - | - | - |
| FOOT FIRST | 75 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 25 | 25 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 4 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 18 | 18 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 39 | 37 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 42 | 40 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 37 | 34 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 16 | 16 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 37 | 34 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 44 | 41 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 27 | 27 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 56 | 56 | 0 | 0.00 | - | - |
| HONEST WORTH | 15 | 15 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 9 | 9 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 11 | 11 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MANOEUVRE | 6 | 6 | 0 | 0.00 | - | - |
| MARCH CHECK | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 22 | 17 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 28 | 24 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 3 | not checked | - | - | - | - |
| NEAREST TO GOAL | 2 | 2 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 14 | 14 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 27 | 15 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 256 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 4 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 6 | 6 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 8 | 8 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 2 | 2 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 4 | 4 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 9 | 9 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET UP TOGETHER | 1 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 2 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 39 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 2 | not checked | - | - | - | - |
| SPELL WORTH | 10 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 38 | 34 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 9 | 9 | 0 | 0.00 | - | - |
| STANDS STILL | 244 | 233 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 2 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE PROMISE ADDS | 3 | 3 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 15 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 1 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 12 | not checked | - | - | - | - |
| THE TABLE BINDS | 265 | not checked | - | - | - | - |
| WHOLE FIGHT DANGER | 9 | 9 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 8 | 8 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p44

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 2.67 | 4.00 | 67.7 |
| JOB FIRST | gate | 2.67 | 3.67 | 30.3 |
| ARMY TABLE | rule | 4.33 | 1.67 | 74.7 |
| CHARGE NOW FIRST | rule | 1.00 | - | 51.5 |
| NO REASON | gate | - | 1.00 | 27.9 |
| JOINT CHARGE NOW | rule | - | 0.67 | 32.1 |
| MARCH OF THE TABLE | rule | 0.33 | 0.33 | 52.2 |
| BEST PRIZE | rule | - | 0.33 | 525.3 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 1.6 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 2.1 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 14.7 |
| PROMISE READS THE TABLE | rule | - | 0.33 | 17.3 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 1.6 |
| SUPPORT NARROWED | rule | 0.33 | - | 57.4 |

### Plans: gs3-83c8646-p44

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.3 | 80% | 571 | 252 | 44% |
| Mine | move | 29.7 | 98% | 2133 | 0 | 0% |
| Mine | shoot | 7.7 | 83% | 263 | 567 | 216% |
| Opponent | charge | 1.3 | 75% | 79 | 101 | 128% |
| Opponent | join | 2.7 | 100% | 78 | 0 | 0% |
| Opponent | move | 38.3 | 93% | 1708 | 0 | 0% |
| Opponent | shoot | 2.3 | 57% | 109 | 38 | 35% |

### Battle groups: gs3-83c8646-p44

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 2.0 | 67% | 50% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p44

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 7 | 24 (7) | 24 | 0 | 0 | 14% | 2.2 | 32 (5) | 0 (2) | - | 29 (6) | 0 (1) |
| Mine | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 11 | 10 (11) | 10 | 0 | 32 | 36% | 3.0 | 12 (8) | 0 (3) | - | 11 (6) | 8 (5) |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Shooter | 5 | 43 (5) | 43 | 0 | 0 | 0% | 1.0 | 22 (2) | 56 (3) | - | 55 (4) | 0 (1) |
| Mine | War machine | 2 | 226 (2) | 226 | 0 | 0 | 0% | 1.0 | 226 (2) | - | - | 226 (2) | - |
| Opponent | Chaff | 6 | 0 (6) | 0 | 0 | 80 | 17% | 3.2 | 0 (3) | 0 (3) | - | 0 (4) | 0 (2) |
| Opponent | Character | 10 | 14 (10) | 14 | 0 | 7 | 40% | 3.8 | 17 (8) | 0 (2) | - | 9 (8) | 23 (2) |
| Opponent | Clean-up | 2 | 0 (2) | 0 | 0 | 50 | 50% | 5.0 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Opponent | Fast Hammer | 6 | 9 (6) | 9 | 0 | 29 | 67% | 4.0 | 11 (5) | 0 (1) | - | 0 (4) | 33 (2) |
| Opponent | Hammer | 3 | 33 (3) | 33 | 0 | 63 | 33% | 2.0 | 44 (2) | 0 (1) | - | 33 (3) | - |
| Opponent | Holder | 4 | 0 (4) | 0 | 0 | 30 | 100% | - | 0 (2) | 0 (1) | - | 0 (3) | - |
| Opponent | Shooter | 3 | 20 (3) | 20 | 0 | 0 | 0% | 1.3 | 0 (1) | 24 (2) | - | 50 (2) | 0 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 100 | 0% | 6.0 | - | - | 0 (1) | - | 0 (1) |
| Opponent | Wizard | 4 | 0 (4) | 0 | 0 | 36 | 25% | 2.7 | 0 (1) | 0 (2) | - | - | 0 (3) |

### Charged fights: gs3-83c8646-p44

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 3 | 300 | 183 | 3.3 | 1.0 | 55 | 35 | +20 | 2 of 10 | 9 of 10 | - | +20 |
| Opponent | Tomb Kings of Khemri | 1 | 60 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Vampire Counts | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 1.0 | 2.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | +0 | - |
| **Opponent** | all armies | 3 | 20 | 0 | 0.3 | 2.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | +0 | - |

### Effective charges: gs3-83c8646-p44

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 10 | 1 (net +0) | 0 | 2 (net -50) | 2 (net -64) | 3 (net +105) | 2 (net +57) | 0 | 20% (2 of 10) |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: gs3-83c8646-p44

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 247 | 201 | +0 | 89 | 165 | -75 | -30.5 |
| Mine | Effective (55-75%) | 2 | 326 | 151 | -50 | 170 | 176 | -5 | -1.7 |
| Mine | 76-89% | 2 | 344 | 270 | -64 | 209 | 226 | -17 | -5.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 147 | 57 | +57 | 57 | 39 | +18 | +12.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 499 | 57 | +105 | 105 | 0 | +105 | +21.1 |
| Mine | All fights | 10 | 338 | 133 | +20 | 128 | 105 | +23 | +6.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 508 | 162 | +0 | 101 | 0 | +101 | +19.9 |
| Opponent | All fights | 1 | 508 | 162 | +0 | 101 | 0 | +101 | +19.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p44 | move | 17 | 3 (18%) | 2 (12%) | 1 (6%) | 13 (76%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1427 |
| Invocation of Nehek | Opponent | L1427 |
| Opal Amulet | Mine | L1427 |
| Ring of Doom | Mine | L1523 |
| Ring of Doom | Opponent | L1331 |
| Standard of the Fell Warrior | Mine | L1331 |

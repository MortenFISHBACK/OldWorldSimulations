# Doctrine scorecard: gs3-83c8646-p32

### Scorecard: gs3-83c8646-p32

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1327 | 1 | 1 | Mine | no | 6 | 2 | 4 | 0 | 0 | 0 | 0 | 70 |
| L1327 | 1 | 1 | Opponent | no | 4 | 2 | 3 | 2 | 1 | 0 | 0 | 509 |
| L1422 | 6 | 1 | Mine | no | 2 | 3 | 3 | 1 | 0 | 0 | 0 | 177 |
| L1422 | 6 | 1 | Opponent | no | 1 | 3 | 0 | 0 | 0 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Mine | no | 0 | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Opponent | no | 4 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 2.7 | 2.0 | 3.3 | 0.7 | 0.0 | 0.0 | 0.0 | 82.3 |
| **Average** | | | Opponent | 0% | 3.0 | 2.7 | 2.0 | 1.0 | 0.3 | 0.0 | 0.0 | 169.7 |

### KPIs: gs3-83c8646-p32

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 6% (1 of 16) | 0% (0 of 13) | 3% (1 of 29) |
| Winner chose to follow up after the loser gave ground |  | 71% (5 of 7); on the table 71% | 80% (4 of 5); on the table 80% | 75% (9 of 12); on the table 75% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (3 of 3); on the table 100% | 80% (4 of 5); on the table 80% | 88% (7 of 8); on the table 88% |
| Winner chose to pursue after the loser fled |  | 50% (1 of 2); on the table 50% | 0% (0 of 2); on the table 0% | 25% (1 of 4); on the table 25% |
| Winner chose to follow up or pursue (all three) |  | 75% (9 of 12); on the table 75% | 67% (8 of 12); on the table 67% | 71% (17 of 24); on the table 71% |
| Magic missiles tried each own turn | 50%+ | 39% (7 of 18) | 8% (1 of 12) | 27% (8 of 30) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 50% (7 of 14) | 17% (1 of 6) | 40% (8 of 20) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 21% (1280 of 6000) | 22% (1299 of 6000) | 21% (2579 of 12000) |
|   infantry points that never fought | lower | 44% (464 of 1048) | 56% (357 of 641) | 49% (821 of 1689) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 29% (7 of 24) | 63% (12 of 19) | 44% (19 of 43) |
| Bound items with a magic missile used (at least once a game) |  | 100% (3 of 3); 3.3 uses a game | 0.0 uses a game | 100% (3 of 3); 1.7 uses a game |
| Bound items with another spell used |  | 50% (4 of 8); 1.7 uses a game | 0.0 uses a game | 50% (4 of 8); 0.8 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 25% (1445 of 5800) | 53% (2530 of 4778) | 38% (3975 of 10578) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (27%) | 0.0 (0%) | 1.0 (14%) |
| MARCHED: its unit marched | 1.3 (36%) | 0.0 (0%) | 1.3 (18%) |
| IN COMBAT: engaged in combat | 1.3 (36%) | 0.0 (0%) | 1.3 (18%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 1.7 (45%) | 1.7 (23%) |
| GONE: slain | 0.0 (0%) | 2.0 (55%) | 2.0 (27%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 1.7 | 3.3 | 2.7 | 0.3 | 1.3 |
| not cast | 3.7 | 0.3 | 6.7 | 7.3 | 3.7 | 34.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (100%) | 0.0 (0%) | 1.0 (14%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (18%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (9%) | 0.0 (0%) | 0.7 (10%) | 1.3 (18%) | 0.0 (0%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (0%) | 1.7 (25%) | 1.7 (23%) | 1.3 (36%) | 0.0 (0%) |
| GONE: slain | 0.7 (18%) | 0.0 (0%) | 2.0 (30%) | 2.0 (27%) | 2.3 (64%) | 6.0 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (9%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| STUPIDITY: Stupidity | 0.3 (9%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (55%) | 0.0 (0%) | 2.3 (35%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 26.3 (76%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 3.3 a game | 0.0 a game | 1.7 a game |
| stood (cast and not dispelled) | 88% (7 of 8) | - | 88% (7 of 8) |
| the unit moved after it | 57% (4 of 7) | - | 57% (4 of 7) |
| it charged on its next turn | 14% (1 of 7) | - | 14% (1 of 7) |
| the enemy charged it first | 0% (0 of 7) | - | 0% (0 of 7) |
| it fought by the end of its next turn | 0% (0 of 7) | - | 0% (0 of 7) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 7) | - | 0% (0 of 7) |
| none of these (no charge, no fight, no charge escaped) | 86% (6 of 7) | - | 86% (6 of 7) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (52 of 83) | 75% (39 of 52) | 67% (91 of 135) |
|   cavalry | 89% (8 of 9) | 100% (12 of 12) | 95% (20 of 21) |
|   character | 31% (9 of 29) | 0% (0 of 8) | 24% (9 of 37) |
|   chariot | 50% (3 of 6) | 83% (5 of 6) | 67% (8 of 12) |
|   infantry | 78% (21 of 27) | 85% (22 of 26) | 81% (43 of 53) |
|   war machine | 92% (11 of 12) | - | 92% (11 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.3 (13%) | 0.0 (0%) | 1.3 (9%) |
| CHARGED: it charged | 3.7 (35%) | 1.3 (31%) | 5.0 (34%) |
| IN COMBAT: it fought this turn or the last | 1.3 (13%) | 0.0 (0%) | 1.3 (9%) |
| MOVED: a war machine that moved | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 1.0 (10%) | 2.3 (54%) | 3.3 (23%) |
| ONLY IN COMBAT: the only targets were in combat | 1.0 (10%) | 0.0 (0%) | 1.0 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (16%) | 0.7 (15%) | 2.3 (16%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 13.3 | 0.7 | 95% | 2.4 pts | 32 pts |
| character | 5.3 | 1.3 | 81% | 0.8 pts | 4 pts |
| chariot | 2.7 | 0.7 | 88% | 3.9 pts | 10 pts |
| infantry | 22.0 | 6.7 | 80% | 9.4 pts | 206 pts |
| war machine | 3.7 | 1.0 | 73% | 2.2 pts | 8 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.7 | 4.3 | 5.0 |
| Charges that made contact a game | 5.3 | 3.0 | 4.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 1.00 contact (3 units) | 0.00 declared, 0.00 contact (1 units) | 0.75 declared, 0.75 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.50 declared, 1.50 contact (2 units) | 1.50 declared, 1.50 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.64 declared, 0.59 contact (22 units) | 0.38 declared, 0.23 contact (26 units) | 0.50 declared, 0.40 contact (48 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 36% (4 of 11) | 0% (0 of 1) | 50% (1 of 2) | 36% (5 of 14) |
| Character in a unit | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Character on its own | 67% (2 of 3) | 67% (2 of 3) | 22% (2 of 9) | 40% (6 of 15) |
| Chariot | 0% (0 of 1) | - | - | 0% (0 of 1) |
| Infantry | 67% (4 of 6) | 0% (0 of 1) | - | 57% (4 of 7) |
| Monster | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Monstrous | - | 0% (0 of 2) | - | 0% (0 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 3 | 75% (9 of 12); on the table 75% | 39% (7 of 18) | 21% | 29% (7 of 24) | 100% (3 of 3); 3.3 uses a game | 50% (4 of 8); 1.7 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 6) | 3% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 33% (1 of 3); on the table 33% | - | 43% | 80% (4 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 71% (5 of 7); on the table 71% | 17% (1 of 6) | 20% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p32, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (1) | 33% (4) | 36% (5) |
| ...free all their last turn and able to turn (per game) | 0.33 | 1.33 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 1.00 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p32

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 94% (15 of 16) | 33% (3 of 9) |
| Strategy | Shoot objectives carried out (shot that target) | 43% (9 of 21) | 55% (6 of 11) |
| Strategy | Support requests answered (helper made contact too) | 67% (2 of 3) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 50% (1 of 2) | - |
| Strategy | Joined characters whose unit fought | - | 50% (2 of 4) |
| Strategy | Lone characters that fought | 100% (7 of 7) | 82% (9 of 11) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.7 | 1.0 |
| Movement | Points that never moved of their own | 82.3 | 169.7 |
| Movement | Fights charged into per game | 4.7 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 13, net +0 | 2 of 7, net -28 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 13 | 1 of 7, net +498 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 4 of 13, net +56 | 0 of 7 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 7 of 13, net +212 | 2 of 7, net +238 |
| Shooting | Shots by shooting units (incl. breath weapons) | 16.0 | 14.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (22 of 48) | 77% (33 of 43) |
| Shooting | Points destroyed by shooting units | 0.0 | 41.0 |
| Shooting | War machine shots | 3.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 36% (4 of 11) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.3 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 4) | 100% (1 of 1) |
| Magic | Wounds caused by magic missiles | 8.0 | - |
| Magic | Wounds caused by other spells | 1.3 | - |
| Magic | Points destroyed by magic (all spells) | 160.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.7 / 1.0 / 0.0 | 1.7 / 0.0 / 0.0 / 0.3 |
| Combat | Points destroyed in combat | 696.3 | 284.0 |
| Combat | Points run down | 0.0 | 199.0 |
| Combat | Net points per charged fight, damage counted | +124 | +127 |
| Combat | Net per 100 charger points, damage counted | +31.7 | +34.8 |
| Combat | First round won (charged fights) | 86% | 89% |
| Combat | Net points per charged fight | +122 | +102 |
| Combat | Net points per supported fight / lone fight | +60 / +132 | - / +102 |
| Combat | Charged fights on a top-3 enemy unit | 7 of 14 | 6 of 9 |
| Game | Points lost | 548.7 | 896.7 |
| Game | VP from objectives | 983.3 | 506.7 |
| Game | Lone holders (player turns) | 2.7 | 3.0 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +817 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1445
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p32

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.7 | +107.4 | 0.0 | 115.7 | 0.3 | +48.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +24.1 | 0.0 | 143.3 |
| ARMY TABLE | 23.3 | +449.8 | 0.0 | 159.0 | 15.0 | +196.9 | 0.0 | 138.3 |
| BACKUP TARGETS | 0.3 | +1.8 | 0.0 | 41.0 | - | - | - | - |
| BOUND ASSAILMENT | 1.0 | +0.1 | 0.0 | 91.3 | - | - | - | - |
| CANNON PLANNED TARGET | 3.7 | +20.0 | 83.0 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.3 | -19.7 | 63.3 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | 0.3 | +2.7 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 0.3 | +5.7 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 2.0 | +213.3 | 0.0 | 209.3 | 1.3 | +53.4 | 0.0 | 77.7 |
| CHAMPION KNOWS CHALLENGE | 1.0 | -43.2 | 163.3 | 100.7 | - | - | - | - |
| CHARGE LOSSES | 12.0 | -203.4 | 0.0 | 264.0 | 15.3 | -814.5 | 0.0 | 391.7 |
| CHARGE NOW FIRST | 2.7 | +0.0 | 434.7 | 50.3 | 2.3 | +0.0 | 225.0 | 18.3 |
| CLOSES ON WHAT IT BEATS | 11.7 | +0.0 | 0.0 | 0.0 | 11.7 | +0.0 | 0.0 | 148.3 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 199.0 | 0.3 | +0.0 | 50.3 | 0.0 |
| CONVEYANCE SEARCH | 2.3 | +156.0 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 7.7 | -576.5 | 0.0 | 100.0 | 6.3 | -498.1 | 0.0 | 353.7 |
| DEPLOY BY FIGURES | 7.0 | -17.9 | 0.0 | 0.0 | 7.0 | +76.9 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -136.6 | 0.0 | 199.0 | 0.3 | -25.9 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 1.0 | +187.9 | 20.0 | 199.0 | - | - | - | - |
| EXACT ROUND | 3.0 | +19.0 | 351.3 | 0.0 | 2.3 | +6.9 | 281.7 | 18.3 |
| FALL BACK GOOD ORDER | 3.3 | +0.0 | 433.3 | 415.3 | 2.7 | +12.3 | 340.7 | 18.3 |
| FALLS SHORT | 6.7 | +75.8 | 0.0 | 141.0 | 9.7 | +140.4 | 0.0 | 476.0 |
| FEATURE BUFFS | 1.3 | +21.6 | 0.0 | 0.0 | 1.3 | +53.7 | 0.0 | 156.7 |
| FIGHT TO THE END | 1.0 | +34.7 | 85.0 | 166.0 | 0.3 | +11.5 | 0.0 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 0.7 | +0.0 | 41.0 | 18.3 |
| FIVE ACTION | 84.3 | +8666.0 | 1255.7 | 1080.0 | 73.0 | +3132.0 | 450.0 | 1015.7 |
| FLANK NOT WEIGHED | 6.7 | +0.0 | 0.0 | 50.3 | 7.7 | +0.0 | 0.0 | 223.3 |
| FOLLOW UP WEIGHED | 1.0 | +307.3 | 0.0 | 115.7 | 0.7 | +154.4 | 0.0 | 0.0 |
| FOOT FIRST | - | - | - | - | 25.3 | +0.0 | 0.0 | 456.3 |
| FOUR ROUNDS | 5.7 | +794.9 | 698.0 | 415.3 | 4.0 | +416.8 | 450.0 | 18.3 |
| FREED FROM HIS FIGHT | 7.0 | +0.0 | 0.0 | 82.0 | 6.0 | +0.0 | 0.0 | 255.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 2.0 | -2.8 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.3 | +15.7 | 0.0 | 50.3 | - | - | - | - |
| GIVES UP | 1.0 | -22.8 | 0.0 | 365.0 | 0.7 | -7.6 | 115.7 | 0.0 |
| GOAL ON TIME | - | - | - | - | 0.3 | +34.8 | 0.0 | 0.0 |
| GOAL WALK | 11.0 | +695.8 | 0.0 | 0.0 | 8.7 | +699.6 | 0.0 | 170.0 |
| GUN MASK | 1.7 | +140.9 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 62.0 |
| HE REFORMS ONCE FREED | 6.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 255.0 |
| HIS CHARGE BY HIS RUN | 7.0 | +0.0 | 0.0 | 264.0 | 10.0 | +0.0 | 0.0 | 391.7 |
| HIS CHARGE LIST | 6.7 | +0.0 | 0.0 | 241.7 | 10.3 | +0.0 | 0.0 | 131.7 |
| HIS LEGAL MOVES | 4.0 | +0.0 | 0.0 | 123.0 | 3.0 | +0.0 | 0.0 | 156.7 |
| HIS MOVE AND SHOT | 2.3 | -13.9 | 0.0 | 0.0 | 7.0 | -66.3 | 0.0 | 161.7 |
| HIS ONE QUARTER | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 80.0 |
| HIS OWN BEST MOVE | 8.3 | +0.0 | 0.0 | 123.0 | 6.7 | +0.0 | 0.0 | 286.7 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 31.7 | +560.2 | 0.0 | 546.7 | 41.0 | +1046.7 | 0.0 | 771.7 |
| HIS SHOTS BY HIS RUN | 25.7 | +269.8 | 0.0 | 546.7 | 43.3 | +569.9 | 0.0 | 960.7 |
| HIS TURN DENIED | 0.3 | +1.3 | 18.3 | 0.0 | - | - | - | - |
| HOLD ODDS | 21.3 | +0.0 | 0.0 | 328.0 | 18.3 | +0.0 | 0.0 | 523.3 |
| HOLDER ASSIGNMENT | 14.3 | +1371.1 | 0.0 | 214.3 | 11.3 | +996.7 | 0.0 | 183.3 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 5.0 | -244.2 | 698.0 | 365.0 | 3.0 | -166.2 | 399.7 | 0.0 |
| IDLE COST | 6.3 | -142.1 | 0.0 | 50.3 | 8.0 | -91.6 | 0.0 | 131.7 |
| JOINT CHARGE NOW | 1.7 | +90.6 | 78.3 | 365.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +42.4 | 0.0 | 0.0 | 1.3 | +32.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.7 | +0.0 | 180.0 | 753.3 | 6.3 | +0.0 | 257.3 | 420.7 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.7 | +22.2 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.7 | +1.7 | 183.3 | 166.0 | 2.0 | +2.1 | 109.3 | 18.3 |
| MAKE SURE TOGETHER | - | - | - | - | 0.3 | +2.2 | 0.0 | 0.0 |
| MANOEUVRE | 0.3 | -0.7 | 0.0 | 0.0 | 1.7 | +53.9 | 0.0 | 80.0 |
| MARCH BY THE SUM | 0.7 | +64.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.3 | +6.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH ODDS | 0.3 | +2.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.7 | +67.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | -4.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 3.3 | +53.2 | 0.0 | 0.0 | 0.7 | +16.7 | 0.0 | 65.0 |
| MEETS IN TIME | 4.0 | +361.7 | 0.0 | 0.0 | 4.3 | +352.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 6.3 | +176.5 | 0.0 | 0.0 | 1.0 | +5.1 | 0.0 | 63.3 |
| MISSILES NEXT TURN | 7.3 | +129.8 | 0.0 | 0.0 | 1.7 | +5.5 | 0.0 | 63.3 |
| MOVE ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 8.3 | +823.9 | 0.0 | 0.0 | 7.3 | +356.4 | 0.0 | 148.3 |
| MOVES UNITS SPELL | 0.3 | +2.4 | 0.0 | 0.0 | 0.3 | +1.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.3 | +257.7 | 0.0 | 82.0 | 8.7 | +304.9 | 0.0 | 140.3 |
| NEAREST TO GOAL | - | - | - | - | 3.7 | +0.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 5.7 | +617.7 | 0.0 | 0.0 | 5.0 | +218.6 | 0.0 | 83.3 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -0.3 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 4.7 | -243.9 | 659.7 | 299.7 | 3.7 | -263.0 | 334.3 | 18.3 |
| NO LATE CUT | 1.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.7 | -0.3 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 4.0 | -118.3 | 0.0 | 41.0 | 4.7 | -96.2 | 50.3 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 18.0 |
| ONE FIGHT FORMULA | 6.3 | -230.0 | 0.0 | 41.0 | 4.0 | -94.0 | 0.0 | 83.3 |
| ONE JOINT FIGURE | 0.7 | +329.5 | 0.0 | 199.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 6.7 | +127.0 | 0.0 | 123.0 | 4.7 | +17.1 | 0.0 | 105.0 |
| ONE PROMISE A TARGET | 1.0 | -55.7 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 1.0 | +35.8 | 36.3 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.7 | +42.3 | 18.3 | 199.0 | 0.3 | +2.1 | 0.0 | 0.0 |
| PATHS CROSS | 0.7 | +10.1 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.7 | -11.7 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 39.3 | +1073.7 | 731.3 | 1230.7 | 36.0 | +486.7 | 384.7 | 955.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 10.7 | -258.7 | 0.0 | 0.0 | 6.7 | -142.7 | 0.0 | 83.3 |
| PROMISE IN STEPS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.7 | -1.2 | 0.0 | 0.0 |
| QUARTER ODDS | 16.3 | +2261.5 | 140.0 | 0.0 | 4.7 | +898.3 | 0.0 | 80.0 |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | +46.1 | 0.0 | 36.0 |
| REDIRECT COUNTER | - | - | - | - | 3.0 | +101.6 | 0.0 | 43.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 5.0 | +0.0 | 0.0 | 53.3 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 2.0 | -51.0 | 0.0 | 0.0 | 1.7 | -50.5 | 0.0 | 0.0 |
| REFUSING RETIRES | 2.0 | +0.0 | 0.0 | 480.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 1.3 | +23.6 | 0.0 | 0.0 |
| RISK BY ARC | 5.0 | +33.9 | 658.0 | 415.3 | 3.3 | -1.5 | 349.3 | 18.3 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 1.0 | -54.6 | 163.3 | 199.0 | 2.0 | -35.2 | 281.7 | 0.0 |
| RUN DOWN | 1.3 | -18.1 | 183.3 | 199.0 | 4.0 | -21.8 | 450.0 | 18.3 |
| SCOUT SPOT | - | - | - | - | 0.7 | +0.5 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +31.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +11.5 | 25.0 | 0.0 | 0.7 | +22.6 | 100.7 | 0.0 |
| SELF MOVE SPELL | 2.0 | +38.7 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.7 | -11.0 | 0.0 | 0.0 | 1.3 | -14.1 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.7 | +0.4 | 0.0 | 0.0 | 2.3 | +98.6 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.3 | +2.2 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.7 | +105.8 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.7 | +0.7 | 0.0 | 0.0 | 0.3 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 6.7 | +0.0 | 0.0 | 59.0 | 3.7 | +0.0 | 0.0 | 81.3 |
| SHOOTS FROM THE BEST SPOT | 2.7 | +40.8 | 161.7 | 0.0 | 3.3 | +15.8 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.7 | -69.6 | 143.3 | 0.0 | 0.3 | -0.7 | 0.0 | 0.0 |
| SHOT RISK POINTS | 17.7 | -149.6 | 0.0 | 305.7 | 30.7 | -353.2 | 0.0 | 530.7 |
| SHOTS AFTER THE MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 18.0 | +352.5 | 0.0 | 282.0 | 12.0 | +132.2 | 0.0 | 18.3 |
| SPELL SETS UP CHARGE | 1.0 | +246.0 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 1.3 | +14.2 | 0.0 | 0.0 | 3.0 | +21.3 | 20.0 | 20.0 |
| SPELLS IN THE FIGHT | 0.7 | +14.3 | 168.3 | 50.3 | 1.0 | -11.5 | 50.3 | 18.3 |
| SPOT AS THE GAME MOVES | 8.7 | +0.0 | 0.0 | 59.0 | 7.7 | +0.0 | 0.0 | 323.3 |
| STAND AND SHOOT | 0.3 | -2.2 | 18.3 | 0.0 | 0.7 | -4.5 | 59.0 | 0.0 |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 26.0 | +0.0 | 557.7 | 159.0 | 14.0 | +0.0 | 0.0 | 382.3 |
| STAY WORTH | 21.0 | +187.3 | 379.3 | 141.0 | 8.3 | +34.3 | 0.0 | 18.3 |
| STRIKE BY THE ODDS | 1.0 | +7.2 | 143.3 | 216.3 | 0.3 | +3.9 | 50.3 | 0.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 1.3 | +109.0 | 0.0 | 0.0 | 2.7 | +65.2 | 0.0 | 65.0 |
| SUPPORT WORKED OUT | 1.3 | +109.0 | 0.0 | 0.0 | 2.7 | +65.2 | 0.0 | 65.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +4.0 | 0.0 | 50.3 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -4.7 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 3.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.7 | +0.0 | 0.0 | 50.3 | 4.0 | +0.0 | 0.0 | 45.0 |
| THE STEP BACK IS MADE | 1.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 45.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 39.0 | +0.0 | 0.0 | 332.3 | 35.3 | +0.0 | 0.0 | 580.0 |
| TIED UP BY THE SUM | 2.7 | +329.8 | 288.0 | 0.0 | 1.3 | +215.7 | 168.3 | 0.0 |
| TIME ON OUR SIDE | 21.0 | +310.8 | 0.0 | 141.0 | 24.7 | +252.4 | 0.0 | 101.7 |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 82.0 | 1.0 | +0.0 | 0.0 | 65.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -26.9 | 231.3 | 0.0 |
| WHO FIGHTS | 0.3 | -7.4 | 0.0 | 0.0 | 0.7 | +28.9 | 0.0 | 18.3 |
| WHO HITS BACK | 0.3 | +34.1 | 0.0 | 0.0 | 0.3 | +38.6 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +11.1 | 115.7 | 0.0 |
| WHOLE FIGHT DANGER | 0.3 | -31.0 | 0.0 | 59.0 | 4.3 | -606.8 | 0.0 | 326.7 |
| WOUNDS ON THE RANKS | - | - | - | - | 3.3 | +190.8 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p32

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 115 | 115 | 97 | 32.33 | +1781 | +18.4 |
| HOLDER ASSIGNMENT | 77 | 77 | 73 | 24.33 | +4645 | +63.6 |
| HIS SHOT LIST | 218 | 210 | 42 | 14.00 | +453 | +10.8 |
| LEGAL CHARGES ONLY | 36 | 36 | 36 | 12.00 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 30 | 10.00 | +0 | +0.0 |
| FIVE ACTION | 472 | 457 | 27 | 9.00 | +2240 | +83.0 |
| OFF BEST | 26 | 26 | 26 | 8.67 | -643 | -24.7 |
| FOUR ROUNDS | 29 | 27 | 22 | 7.33 | +2063 | +93.8 |
| DEPLOY BY FIGURES | 42 | 42 | 20 | 6.67 | +223 | +11.2 |
| HIS SHOTS BY HIS RUN | 207 | 200 | 20 | 6.67 | +335 | +16.8 |
| MOVE TO CHARGE COMPUTED | 47 | 39 | 19 | 6.33 | +1563 | +82.3 |
| PROMISE BY ITS OWN SUM | 52 | 52 | 17 | 5.67 | -1204 | -70.8 |
| NEXT CHARGE BY LIST | 32 | 30 | 15 | 5.00 | +1447 | +96.4 |
| REDIRECT FOR A FRIEND IN REACH | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| GOAL WALK | 59 | 57 | 14 | 4.67 | +584 | +41.8 |
| TIME ON OUR SIDE | 137 | 115 | 12 | 4.00 | +70 | +5.8 |
| MEETS IN TIME | 25 | 25 | 11 | 3.67 | +575 | +52.3 |
| CHALLENGE BY POINTS | 10 | 10 | 10 | 3.33 | +800 | +80.0 |
| SHOT RISK POINTS | 145 | 138 | 10 | 3.33 | +521 | +52.1 |
| TIED UP BY THE SUM | 12 | 10 | 10 | 3.33 | +360 | +36.0 |
| CHARGE LOSSES | 82 | 77 | 9 | 3.00 | +983 | +109.3 |
| IDLE COST | 43 | 33 | 8 | 2.67 | +36 | +4.5 |
| LANE BY FIGURES | 8 | 8 | 8 | 2.67 | +225 | +28.2 |
| MOVE ORDER | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| QUARTER ODDS | 63 | 58 | 8 | 2.67 | +931 | +116.4 |
| COVER ONCE | 42 | 29 | 5 | 1.67 | +58 | +11.6 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +1385 | +277.0 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | +272 | +54.4 |
| SET UP BY THE SET | 12 | 12 | 5 | 1.67 | +180 | +35.9 |
| SHOOTS FROM THE BEST SPOT | 18 | 18 | 5 | 1.67 | +4 | +0.7 |
| CHARGE NOW FIRST | 15 | 15 | 4 | 1.33 | -87 | -21.8 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +71 | +17.7 |
| SHOTS IN THE MOVE | 90 | 72 | 4 | 1.33 | +61 | +15.2 |
| STRIKE BY THE ODDS | 4 | 4 | 4 | 1.33 | +33 | +8.3 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 1.00 | +467 | +155.5 |
| BOUND ASSAILMENT | 3 | 3 | 3 | 1.00 | +0 | +0.1 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FALLS SHORT | 49 | 39 | 3 | 1.00 | +75 | +25.0 |
| HARD STAY DROPPED | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| ONE PROMISE A TARGET | 3 | 3 | 3 | 1.00 | -167 | -55.7 |
| REFUSING RETIRES | 7 | 7 | 3 | 1.00 | +147 | +48.9 |
| SECOND LOOK | 3 | 3 | 3 | 1.00 | +102 | +34.1 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +6 | +2.0 |
| SUPPORT ADDS | 12 | 12 | 3 | 1.00 | +326 | +108.7 |
| SUPPORT WORKED OUT | 12 | 12 | 3 | 1.00 | +326 | +108.7 |
| WHOLE FIGHT DANGER | 14 | 14 | 3 | 1.00 | +184 | +61.4 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +67 | +33.4 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +193 | +96.4 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -202 | -100.8 |
| MAX FOR POSITIONING | 12 | 9 | 2 | 0.67 | +4 | +1.9 |
| MISSILES IN THE MOVE | 22 | 14 | 2 | 0.67 | +5 | +2.6 |
| MOVES UNITS SPELL | 2 | 2 | 2 | 0.67 | +12 | +5.8 |
| NEARER NOT NEEDED | 45 | 38 | 2 | 0.67 | +62 | +31.1 |
| ONE JOINT FIGURE | 2 | 2 | 2 | 0.67 | +479 | +239.7 |
| ONE OBJECTIVE FORMULA | 34 | 26 | 2 | 0.67 | +115 | +57.4 |
| OPENS UP | 3 | 3 | 2 | 0.67 | +17 | +8.3 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +30 | +15.2 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.67 | -35 | -17.5 |
| RISK BY ARC | 25 | 24 | 2 | 0.67 | +28 | +13.8 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| STAY WORTH | 88 | 80 | 2 | 0.67 | +48 | +23.8 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +127 | +63.3 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +72 | +72.4 |
| CANNON PLANNED TARGET | 11 | 11 | 1 | 0.33 | +0 | +0.0 |
| CARRIES OUT SET-UP | 1 | 1 | 1 | 0.33 | -59 | -59.2 |
| CATCH ODDS | 1 | 1 | 1 | 0.33 | -4 | -3.9 |
| EDGE GIVE GROUND | 3 | 3 | 1 | 0.33 | +96 | +96.0 |
| EXACT ROUND | 16 | 15 | 1 | 0.33 | +1 | +1.2 |
| FIGHT TO THE END | 4 | 4 | 1 | 0.33 | +16 | +16.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +47 | +47.2 |
| GOAL ON TIME | 1 | 1 | 1 | 0.33 | -90 | -89.7 |
| MANOEUVRE | 6 | 6 | 1 | 0.33 | +164 | +164.2 |
| MARCH CHECK | 1 | 1 | 1 | 0.33 | +4 | +3.9 |
| MARCH ODDS | 1 | 1 | 1 | 0.33 | -2 | -2.3 |
| MISSILES NEXT TURN | 27 | 19 | 1 | 0.33 | +32 | +31.9 |
| ONE FIGHT FORMULA | 31 | 19 | 1 | 0.33 | +4 | +3.8 |
| OVERRUNS AWAY | 3 | 3 | 1 | 0.33 | +57 | +56.8 |
| REDIRECT COUNTER | 9 | 9 | 1 | 0.33 | +28 | +27.7 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +30 | +30.3 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +93 | +93.0 |
| SPELLS IN THE FIGHT | 5 | 5 | 1 | 0.33 | +1 | +1.2 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +12 | +11.9 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 8 | trace | - | - | - | - |
| CHAFF IN THE MOVE | 1 | 1 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 3 | 3 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 70 | 70 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 7 | not checked | - | - | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 18 | 18 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 8 | 8 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 43 | not checked | - | - | - | - |
| FOOT FIRST | 76 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 39 | 38 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 6 | 6 | 0 | 0.00 | - | - |
| GIVES UP | 5 | 5 | 0 | 0.00 | - | - |
| GUN MASK | 5 | 5 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 28 | 27 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 51 | 49 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 51 | 47 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 21 | 19 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 28 | 25 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 8 | 6 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 45 | 38 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HOLD ODDS | 119 | 119 | 0 | 0.00 | - | - |
| HONEST WORTH | 24 | 22 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 10 | 10 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 11 | 11 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 1 | 1 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 7 | not checked | - | - | - | - |
| NEAREST TO GOAL | 11 | 11 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 25 | 23 | 0 | 0.00 | - | - |
| NO LATE CUT | 8 | 8 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE ROUTE | 1 | 1 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 226 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 4 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 1 | 1 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 11 | 10 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 3 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 9 | 8 | 0 | 0.00 | - | - |
| RUN DOWN | 16 | 15 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 6 | 6 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 2 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 31 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 12 | 12 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 3 | not checked | - | - | - | - |
| SPELL WORTH | 13 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 49 | 43 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 4 | 4 | 0 | 0.00 | - | - |
| STANDS STILL | 120 | 120 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 11 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 16 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 20 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 14 | not checked | - | - | - | - |
| THE TABLE BINDS | 223 | not checked | - | - | - | - |
| WAITS AGAIN | 9 | 9 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 10 | 10 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p32

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.00 | 4.00 | 27.2 |
| ARMY TABLE | rule | 2.33 | 3.33 | 28.6 |
| PROMISE BY ITS OWN SUM | rule | 3.67 | 2.00 | 70.8 |
| HOLDER ASSIGNMENT | rule | 1.00 | 2.33 | 13.1 |
| CHARGE NOW FIRST | rule | 1.00 | 0.33 | 21.8 |
| ONE PROMISE A TARGET | rule | 1.00 | - | 55.7 |
| FIGHT ORDER BAND | gate | 0.67 | - | 0.7 |
| MARCH OF THE TABLE | rule | 0.67 | - | 100.8 |
| NO REASON | gate | - | 0.67 | 25.9 |
| PIVOT GUARDS FLANK | rule | 0.67 | - | 17.5 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.33 | - | 18.1 |
| CARRIES OUT SET-UP | rule | 0.33 | - | 59.2 |
| CATCH ODDS | rule | 0.33 | - | 3.9 |
| GOAL ON TIME | rule | - | 0.33 | 89.7 |
| JOINT CHARGE NOW | rule | 0.33 | - | 288.8 |
| MARCH ODDS | rule | 0.33 | - | 2.3 |
| REFUSING RETIRES | rule | 0.33 | - | 3.6 |

### Plans: gs3-83c8646-p32

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 5.0 | 73% | 1203 | 773 | 64% |
| Mine | move | 29.3 | 95% | 2359 | 0 | 0% |
| Mine | shoot | 5.0 | 67% | 394 | 301 | 76% |
| Opponent | charge | 3.7 | 64% | 448 | 398 | 89% |
| Opponent | join | 1.0 | 67% | 31 | 0 | 0% |
| Opponent | move | 28.7 | 87% | 1211 | 0 | 0% |
| Opponent | shoot | 2.3 | 57% | 78 | 89 | 114% |
| Opponent | support | 0.3 | 100% | 31 | 0 | 0% |

### Battle groups: gs3-83c8646-p32

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 3.0 | 22% | 100% | 50% | 100% | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p32

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 7 | 54 (7) | 54 | 0 | 33 | 0% | 1.6 | 0 (1) | 83 (4) | 14 (2) | 76 (4) | 30 (3) |
| Mine | Clean-up | 2 | 291 (2) | 229 | 62 | 0 | 50% | 4.0 | 0 (1) | 367 (1) | - | 291 (2) | - |
| Mine | Fast Hammer | 11 | 64 (11) | 15 | 49 | 29 | 18% | 2.8 | 59 (3) | 54 (4) | 85 (4) | 49 (8) | 108 (3) |
| Mine | Shooter | 5 | 53 (5) | 42 | 11 | 43 | 0% | 1.0 | 0 (1) | 63 (4) | - | 53 (5) | - |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.5 | - | - | 0 (2) | - | 0 (2) |
| Opponent | Chaff | 9 | 90 (9) | 0 | 90 | 62 | 33% | 2.3 | 14 (4) | 172 (4) | 0 (1) | 90 (9) | - |
| Opponent | Character | 9 | 43 (9) | 43 | 0 | 15 | 22% | 2.7 | - | 62 (6) | 0 (3) | 30 (7) | 64 (2) |
| Opponent | Fast Hammer | 6 | 44 (6) | 44 | 0 | 55 | 33% | 3.8 | - | 0 (3) | 70 (3) | 50 (5) | 0 (1) |
| Opponent | Hammer | 4 | 21 (4) | 0 | 21 | 76 | 0% | 3.0 | 0 (1) | 31 (2) | 0 (1) | 27 (3) | 0 (1) |
| Opponent | Holder | 4 | 141 (4) | 52 | 89 | 46 | 0% | 1.2 | 0 (2) | 303 (2) | - | 303 (2) | 0 (2) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Wizard | 6 | 0 (6) | 0 | 0 | 94 | 33% | 2.5 | 0 (1) | 0 (1) | 0 (2) | 0 (2) | 0 (2) |

### Charged fights: gs3-83c8646-p32

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 3 | 160 | 768 | 4.7 | 1.1 | 165 | 43 | +122 | 7 of 14 | 12 of 14 | +60 | +132 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 28 | -28 | 2 of 2 | 1 of 2 | - | -28 |
| Opponent | Tomb Kings of Khemri | 1 | 123 | 300 | 3.0 | 1.0 | 100 | 0 | +100 | 1 of 3 | 3 of 3 | - | +100 |
| Opponent | Vampire Counts | 1 | 0 | 675 | 4.0 | 1.0 | 169 | 0 | +169 | 3 of 4 | 4 of 4 | - | +169 |
| **Opponent** | all armies | 3 | 41 | 325 | 3.0 | 1.0 | 108 | 6 | +102 | 6 of 9 | 8 of 9 | - | +102 |

### Effective charges: gs3-83c8646-p32

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 14 | 2 (net +0) | 0 | 0 | 0 | 4 (net +56) | 7 (net +212) | 1 | 0% (0 of 13) |
| Opponent | Orc & Goblin Tribes | 2 | 2 (net -28) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 3 | 0 | 0 | 0 | 0 | 0 | 1 (net +300) | 2 | 0% (0 of 1) |
| Opponent | Vampire Counts | 4 | 0 | 1 (net +0) | 1 (net +498) | 1 (net +0) | 0 | 1 (net +177) | 0 | 25% (1 of 4) |

### Charged fights, damage counted: gs3-83c8646-p32

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 274 | 380 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 7 | 403 | 237 | +212 | 320 | 99 | +221 | +54.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 432 | 56 | +56 | 64 | 16 | +48 | +11.2 |
| Mine | No odds | 1 | 400 | 75 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | All fights | 14 | 392 | 194 | +122 | 178 | 54 | +124 | +31.7 |
| Opponent | Long shot (under 50%) | 2 | 202 | 414 | -28 | 48 | 28 | +20 | +10.1 |
| Opponent | 50-54% | 1 | 186 | 342 | +0 | 57 | 0 | +57 | +30.6 |
| Opponent | Effective (55-75%) | 1 | 471 | 247 | +498 | 498 | 21 | +477 | +101.3 |
| Opponent | 76-89% | 1 | 471 | 247 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 451 | 177 | +238 | 238 | 29 | +209 | +46.4 |
| Opponent | No odds | 2 | 421 | 147 | +0 | 74 | 0 | +74 | +17.5 |
| Opponent | All fights | 9 | 364 | 257 | +102 | 142 | 15 | +127 | +34.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p32 | move | 23 | 5 (22%) | 4 (17%) | 4 (17%) | 14 (61%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1327 |
| Elixir of Power | Opponent | L1519 |
| Invocation of Nehek | Opponent | L1327 |
| Opal Amulet | Mine | L1422 |
| Ring of Doom | Mine | L1519 |
| Standard of the Fell Warrior | Mine | L1327 |

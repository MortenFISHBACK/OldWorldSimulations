# Doctrine scorecard: gs3-83c8646-p16

### Scorecard: gs3-83c8646-p16

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0528 | 6 | 1 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 430 |
| L0528 | 6 | 1 | Opponent | no | 6 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | - | 1 | 3 | 1 | 0 | 0 | 678 |
| L0616 | 4 | 1 | Opponent | no | 0 | - | 2 | 1 | 1 | 0 | 0 | 100 |
| L0632 | 2 | 1 | Mine | - | - | 3 | 3 | 1 | 0 | 0 | 0 | 495 |
| L0632 | 2 | 1 | Opponent | - | - | 4 | 0 | 5 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 0.0 | 3.0 | 1.3 | 2.3 | 0.3 | 0.0 | 0.0 | 534.3 |
| **Average** | | | Opponent | 0% | 3.0 | 4.0 | 0.7 | 3.0 | 0.7 | 0.0 | 0.0 | 33.3 |

### KPIs: gs3-83c8646-p16

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 100% (12 of 12) | 0% (0 of 10) | 55% (12 of 22) |
| Winner chose to follow up after the loser gave ground |  | - | 100% (6 of 6); on the table 100% | 100% (6 of 6); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 33% (1 of 3); on the table 33% | - | 33% (1 of 3); on the table 33% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 33% (1 of 3); on the table 33% | 100% (6 of 6); on the table 100% | 78% (7 of 9); on the table 78% |
| Magic missiles tried each own turn | 50%+ | - | 50% (3 of 6) | 50% (3 of 6) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 50% (3 of 6) | 50% (3 of 6) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 60% (6 of 10) | 60% (6 of 10) |
| Points that never fought | lower | 86% (5142 of 6000) | 76% (4531 of 5999) | 81% (9673 of 11999) |
|   infantry points that never fought | lower | 90% (1999 of 2232) | 24% (170 of 720) | 73% (2169 of 2952) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 78% (21 of 27) | 71% (15 of 21) | 75% (36 of 48) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 77% (3256 of 4232) | 76% (4123 of 5415) | 76% (7379 of 9647) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.0 (100%) | 1.0 (100%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Assailments |
| --- | --- | --- | --- | --- |
| tried | 0.7 | 0.0 | 1.0 | 0.0 |
| not cast | 3.3 | 2.0 | 1.0 | 4.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (100%) | 1.0 (100%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 1.3 (40%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (60%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.0 (100%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 70% (129 of 184) | 48% (19 of 40) | 66% (148 of 224) |
|   cavalry | 50% (9 of 18) | 57% (8 of 14) | 53% (17 of 32) |
|   character | 65% (13 of 20) | 0% (0 of 9) | 45% (13 of 29) |
|   infantry | 62% (32 of 52) | 0% (0 of 5) | 56% (32 of 57) |
|   monster | 40% (4 of 10) | - | 40% (4 of 10) |
|   war machine | 85% (71 of 84) | 92% (11 of 12) | 85% (82 of 96) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.0 (22%) | 1.0 (14%) | 5.0 (20%) |
| CHARGED: it charged | 2.0 (11%) | 0.3 (5%) | 2.3 (9%) |
| IN COMBAT: it fought this turn or the last | 0.3 (2%) | 0.0 (0%) | 0.3 (1%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.3 (5%) | 0.3 (1%) |
| NO TARGET IN RANGE | 5.7 (31%) | 4.3 (62%) | 10.0 (39%) |
| ONLY IN COMBAT: the only targets were in combat | 1.3 (7%) | 0.0 (0%) | 1.3 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 5.0 (27%) | 1.0 (14%) | 6.0 (24%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.7 | 1.0 | 82% | 2.0 pts | 12 pts |
| character | 4.3 | 3.3 | 54% | 10.0 pts | 43 pts |
| infantry | 21.7 | 9.3 | 77% | 8.6 pts | 186 pts |
| monster | 1.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 27.3 | 19.3 | 62% | 21.3 pts | 583 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.7 | 1.7 | 2.2 |
| Charges that made contact a game | 2.3 | 1.0 | 1.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.38 declared, 0.33 contact (21 units) | 0.25 declared, 0.15 contact (20 units) | 0.32 declared, 0.24 contact (41 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | - | 50% (1 of 2) | 50% (3 of 6) |
| Character in a unit | 86% (6 of 7) | 100% (3 of 3) | 100% (1 of 1) | 91% (10 of 11) |
| Character on its own | - | 50% (1 of 2) | 100% (3 of 3) | 80% (4 of 5) |
| Infantry | 71% (5 of 7) | 67% (4 of 6) | - | 69% (9 of 13) |
| Monster | 75% (3 of 4) | - | - | 75% (3 of 4) |
| Monstrous | 100% (1 of 1) | - | - | 100% (1 of 1) |
| War Machines | 75% (6 of 8) | - | - | 75% (6 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dwarfen Mountain Holds | 3 | 33% (1 of 3); on the table 33% | - | 86% | 78% (21 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (2 of 2); on the table 100% | - | 56% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 2 | 100% (4 of 4); on the table 100% | 50% (3 of 6) | 85% | 73% (11 of 15) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p16, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (1) | 40% (2) | 43% (3) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.67 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p16

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | 86% (6 of 7) | 60% (3 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 64% (68 of 107) | 50% (7 of 14) |
| Strategy | Support requests answered (helper made contact too) | 100% (2 of 2) | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 0% (0 of 12) | 20% (1 of 5) |
| Strategy | Lone characters that fought | 0% (0 of 1) | 20% (1 of 5) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 2.3 | 3.0 |
| Movement | Points that never moved of their own | 534.3 | 33.3 |
| Movement | Fights charged into per game | 1.7 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 4, net +0 | 2 of 3, net +58 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 4 | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 4 | 0 of 3 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 4, net -20 | 1 of 3, net +105 |
| Shooting | Shots by shooting units (incl. breath weapons) | 21.7 | 3.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (29 of 65) | 0% (0 of 11) |
| Shooting | Points destroyed by shooting units | 260.7 | 0.0 |
| Shooting | War machine shots | 23.7 | 3.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 62% (44 of 71) | 45% (5 of 11) |
| Shooting | Points destroyed by war machines | 0.0 | 106.7 |
| Magic | Magic missiles cast | - | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 100% (3 of 3) |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 0.7 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 0.0 | 133.3 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +54 | +27 |
| Combat | Net per 100 charger points, damage counted | +59.6 | +10.4 |
| Combat | First round won (charged fights) | 40% | 67% |
| Combat | Net points per charged fight | -12 | +73 |
| Combat | Net points per supported fight / lone fight | -30 / +0 | - / +73 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 5 | 1 of 3 |
| Game | Points lost | 240.0 | 227.3 |
| Game | VP from objectives | 606.7 | 403.3 |
| Game | Lone holders (player turns) | 0.0 | 3.0 |

- Mine won / drew / lost: 1 / 2 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +217 VP
- The side that went first won 0 of 1 games with a winner
- Points traded per game (both sides' losses): 467
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p16

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.7 | +45.5 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 6.0 | +80.9 | 0.0 | 0.0 | 19.0 | +383.2 | 0.0 | 20.0 |
| ARTILLERY RE-ROLL WEIGHED | 3.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | - | - | - | - | 0.7 | -30.0 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 2.3 | +0.0 | 511.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 24.3 | +510.9 | 1216.0 | 146.7 | 3.7 | +178.4 | 213.3 | 0.0 |
| CANNON SIGHT KEPT | 3.0 | +0.0 | 0.0 | 38.3 | - | - | - | - |
| CAST JOB | - | - | - | - | 1.3 | +2.8 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.3 | +9.5 | 0.0 | 0.0 |
| CHAFF PASSED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | +3.6 | 0.0 | 0.0 |
| CHARACTER GUNS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 4.7 | -56.8 | 0.0 | 0.0 | 26.7 | -1852.8 | 0.0 | 889.3 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 20.0 | 0.0 | 0.3 | +0.0 | 35.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 324.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 35.0 | - | - | - | - |
| COVER ONCE | 4.7 | -444.0 | 0.0 | 0.0 | 4.3 | -270.7 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 1.0 | -2.0 | 73.3 | 0.0 |
| DEPLOY BY FIGURES | 13.0 | -157.2 | 0.0 | 38.3 | 6.0 | +73.0 | 0.0 | 0.0 |
| EXACT ROUND | 2.7 | +25.2 | 0.0 | 20.0 | 1.3 | +2.1 | 73.3 | 0.0 |
| FALL BACK GOOD ORDER | 2.7 | +3.4 | 0.0 | 20.0 | 1.7 | +0.0 | 73.3 | 0.0 |
| FALLS SHORT | - | - | - | - | 17.0 | +184.7 | 0.0 | 268.0 |
| FEATURE BUFFS | - | - | - | - | 1.0 | +5.7 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +0.9 | 0.0 | 0.0 | 0.7 | +2.9 | 35.0 | 0.0 |
| FIVE ACTION | 132.7 | +6691.2 | 5319.3 | 353.3 | 80.0 | +2078.0 | 505.0 | 929.3 |
| FLANK NOT WEIGHED | 1.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 167.0 |
| FOLLOW UP WEIGHED | - | - | - | - | 0.3 | +51.1 | 0.0 | 0.0 |
| FOOT FIRST | - | - | - | - | 28.3 | +0.0 | 0.0 | 133.3 |
| FOUR ROUNDS | 2.7 | +17.0 | 0.0 | 20.0 | 1.7 | +92.3 | 73.3 | 0.0 |
| FREED FROM HIS FIGHT | 5.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FRIEND CHARGES FIRST | 0.3 | -20.6 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.3 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.3 | -1.0 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | - | - | - | - | 0.3 | -2.6 | 0.0 | 0.0 |
| GOAL ROUTE | - | - | - | - | 1.3 | +53.0 | 0.0 | 0.0 |
| GOAL WALK | 3.3 | +78.5 | 0.0 | 0.0 | 15.0 | +1158.1 | 0.0 | 0.0 |
| GUN FIGURES | 2.0 | +25.0 | 66.7 | 0.0 | - | - | - | - |
| GUN MASK | 0.7 | +65.4 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 5.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HE REFORMS ONCE FREED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 2.3 | +0.0 | 0.0 | 0.0 | 12.3 | +0.0 | 0.0 | 684.7 |
| HIS CHARGE LIST | 0.7 | +0.0 | 0.0 | 0.0 | 17.0 | +0.0 | 0.0 | 56.7 |
| HIS LEGAL MOVES | 2.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 314.0 |
| HIS MOVE AND SHOT | 1.3 | -10.0 | 0.0 | 0.0 | 8.0 | -153.7 | 0.0 | 314.0 |
| HIS ONE QUARTER | 2.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 2.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 314.0 |
| HIS RANDOM MOVE | 12.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 17.3 | +341.3 | 0.0 | 40.0 | 64.3 | +4608.4 | 0.0 | 281.3 |
| HIS SHOTS BY HIS RUN | 13.3 | +211.0 | 0.0 | 0.0 | 55.0 | +1478.3 | 0.0 | 929.3 |
| HIS TURN DENIED | - | - | - | - | 1.7 | +55.1 | 73.3 | 0.0 |
| HOLD ODDS | 9.3 | +0.0 | 0.0 | 0.0 | 11.3 | +0.0 | 0.0 | 74.0 |
| HOLDER ASSIGNMENT | 9.3 | +988.1 | 0.0 | 0.0 | 7.3 | +788.4 | 0.0 | 37.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -11.8 | 0.0 | 20.0 | 1.7 | -76.8 | 73.3 | 0.0 |
| IDLE COST | - | - | - | - | 22.3 | -389.6 | 0.0 | 371.0 |
| JOINT CHARGE NOW | 1.3 | +38.0 | 0.0 | 20.0 | 0.7 | +14.4 | 0.0 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 4.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | - | - | - | - | 1.3 | +77.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.0 | +0.0 | 56.7 | 175.0 | 1.3 | +0.0 | 73.3 | 0.0 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.3 | +25.0 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.3 | +5.4 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 2.0 | +4.7 | 0.0 | 20.0 | 0.7 | +2.1 | 35.0 | 0.0 |
| MANOEUVRE | 1.0 | -8.3 | 0.0 | 0.0 | 2.3 | +1.2 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 0.7 | +9.4 | 0.0 | 0.0 | 1.7 | +33.5 | 0.0 | 10.0 |
| MEETS IN TIME | 6.0 | +54.8 | 0.0 | 0.0 | 3.0 | +184.7 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | - | - | - | - | 1.7 | +3.5 | 0.0 | 0.0 |
| MISSILES NEXT TURN | - | - | - | - | 1.7 | +2.7 | 0.0 | 0.0 |
| MODEL FACING | 4.3 | +868.5 | 0.0 | 20.0 | - | - | - | - |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 37.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 3.0 | +224.5 | 0.0 | 40.0 | 1.7 | +104.2 | 0.0 | 314.0 |
| NEARER NOT NEEDED | 6.0 | +270.5 | 0.0 | 0.0 | 2.0 | +86.8 | 0.0 | 0.0 |
| NEAREST TO GOAL | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 1.0 | +45.1 | 0.0 | 0.0 | 1.7 | +104.2 | 0.0 | 314.0 |
| NO DOUBLE ROUNDS | 2.7 | -35.7 | 0.0 | 20.0 | 1.7 | -40.1 | 73.3 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 8.3 | -230.2 | 0.0 | 73.3 | 3.0 | -67.4 | 0.0 | 0.0 |
| ONE CHALLENGE TEST | - | - | - | - | 0.3 | +3.6 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.7 | -19.0 | 0.0 | 20.0 | 3.0 | -55.8 | 0.0 | 314.0 |
| ONE JOINT FIGURE | 0.3 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 2.3 | -36.7 | 0.0 | 0.0 | 3.3 | -31.8 | 0.0 | 37.0 |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 0.7 | +4.9 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.3 | +5.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.7 | +20.5 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.7 | -6.1 | 0.0 | 0.0 |
| PLAN RESULT | 59.7 | +3363.3 | 1199.0 | 368.3 | 37.0 | +197.5 | 113.3 | 327.3 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 157.0 |
| PROMISE BY ITS OWN SUM | 7.3 | -357.2 | 0.0 | 40.0 | 2.3 | -1.6 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 12.3 | +830.9 | 0.0 | 76.7 | 9.7 | +928.7 | 176.7 | 0.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.3 | +15.6 | 0.0 | 113.3 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | - | - | - | - | 2.7 | +101.5 | 0.0 | 10.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.3 | +0.0 | 0.0 | 10.0 |
| REDIRECT WEIGHED | 0.3 | +13.4 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 1.3 | -32.0 | 0.0 | 40.0 | 0.3 | -6.2 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 2.0 | +97.5 | 0.0 | 0.0 |
| RISK BY ARC | 1.7 | +122.3 | 0.0 | 0.0 | 1.3 | -3.7 | 38.3 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.7 | -8.8 | 73.3 | 0.0 |
| RUN DOWN | 2.7 | -17.4 | 0.0 | 20.0 | 1.0 | -4.9 | 35.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.0 | -53.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +15.7 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 1.3 | -16.3 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 1.7 | +28.5 | 0.0 | 0.0 | - | - | - | - |
| SET UP TOGETHER | - | - | - | - | 0.3 | +1.8 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.3 | -0.5 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 2.0 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 36.0 | +0.0 | 0.0 | 146.7 | 5.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 3.0 | +287.7 | 628.0 | 0.0 | 0.7 | +4.9 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 2.0 | +0.0 | 0.0 | 38.3 | - | - | - | - |
| SHOT OR CHARGE | 0.3 | -6.5 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 8.7 | +136.1 | 0.0 | 0.0 | 48.0 | -968.2 | 0.0 | 929.3 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 42.3 | +1812.6 | 0.0 | 146.7 | 7.7 | +280.0 | 0.0 | 0.0 |
| SPELL WORTH | - | - | - | - | 0.7 | +11.1 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 10.0 | +0.0 | 0.0 | 47.0 |
| STAND AND SHOOT | - | - | - | - | 1.0 | -9.8 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 103.7 | +0.0 | 5319.3 | 293.3 | 22.7 | +0.0 | 431.7 | 187.3 |
| STAY WORTH | 89.3 | +847.4 | 3950.0 | 340.0 | 12.3 | +308.1 | 431.7 | 0.0 |
| STUBBORN BY POINTS | - | - | - | - | 0.3 | +25.2 | 0.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.3 | +24.8 | 0.0 | 0.0 | 4.3 | +101.4 | 0.0 | 20.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 2.3 | +24.8 | 0.0 | 0.0 | 4.3 | +101.4 | 0.0 | 20.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +0.5 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 3.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -3.4 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 0.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 10.0 |
| THE STEP BACK IS MADE | 0.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 10.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 62.0 | +0.0 | 0.0 | 166.7 | 37.3 | +0.0 | 0.0 | 408.0 |
| TIED UP BY THE SUM | 0.7 | +18.1 | 0.0 | 0.0 | 0.7 | +81.1 | 35.0 | 0.0 |
| TIME ON OUR SIDE | 57.3 | +619.3 | 334.0 | 20.0 | - | - | - | - |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WEAPON BY POINTS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | 1.7 | -41.3 | 0.0 | 0.0 | 0.3 | +4.0 | 0.0 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +11.8 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | - | - | - | - | 3.0 | -207.0 | 0.0 | 314.0 |
| WHOLE FIGHT GAIN | 0.3 | +4.2 | 0.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 1.3 | +22.7 | 0.0 | 0.0 | 6.7 | +602.5 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p16

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 245 | 242 | 93 | 31.00 | +2374 | +25.5 |
| ARMY TABLE | 75 | 75 | 51 | 17.00 | +964 | +18.9 |
| HOLDER ASSIGNMENT | 50 | 50 | 47 | 15.67 | +2967 | +63.1 |
| HIS SHOTS BY HIS RUN | 205 | 202 | 45 | 15.00 | +651 | +14.5 |
| SHOT RISK POINTS | 170 | 169 | 40 | 13.33 | +977 | +24.4 |
| DEPLOY BY FIGURES | 57 | 57 | 39 | 13.00 | +580 | +14.9 |
| OFF BEST | 34 | 34 | 34 | 11.33 | -893 | -26.3 |
| TIME ON OUR SIDE | 172 | 156 | 29 | 9.67 | +157 | +5.4 |
| LEGAL CHARGES ONLY | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| CANNON PLANNED TARGET | 84 | 84 | 18 | 6.00 | -87 | -4.8 |
| HARD STAY DROPPED | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| FIVE ACTION | 638 | 630 | 15 | 5.00 | +413 | +27.5 |
| GOAL WALK | 55 | 55 | 14 | 4.67 | +792 | +56.6 |
| THE TABLE AGAIN | 36 | 36 | 14 | 4.67 | +0 | +0.0 |
| MODEL FACING | 13 | 13 | 13 | 4.33 | +2605 | +200.4 |
| PROMISE BY ITS OWN SUM | 29 | 29 | 13 | 4.33 | -1077 | -82.8 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 14 | 14 | 12 | 4.00 | +350 | +29.1 |
| ARTILLERY RE-ROLL WEIGHED | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| IDLE COST | 67 | 52 | 9 | 3.00 | +134 | +14.8 |
| SUPPORT ADDS | 20 | 18 | 9 | 3.00 | +57 | +6.4 |
| SUPPORT WORKED OUT | 20 | 18 | 9 | 3.00 | +57 | +6.4 |
| CHARGE LOSSES | 94 | 93 | 8 | 2.67 | +484 | +60.5 |
| SHOOTS FROM THE BEST SPOT | 11 | 11 | 8 | 2.67 | +301 | +37.6 |
| FOUR ROUNDS | 13 | 12 | 6 | 2.00 | +222 | +37.0 |
| JOINT CHARGE NOW | 6 | 6 | 6 | 2.00 | +157 | +26.2 |
| MEETS IN TIME | 27 | 27 | 6 | 2.00 | +34 | +5.6 |
| NEXT CHARGE BY LIST | 8 | 8 | 6 | 2.00 | +216 | +35.9 |
| RANDOM MOVE BY FIGURES | 10 | 10 | 6 | 2.00 | +47 | +7.8 |
| RESERVE FALL BACK | 6 | 6 | 6 | 2.00 | +292 | +48.7 |
| SHOOTERS IN TWO RANKS | 6 | 6 | 6 | 2.00 | +12 | +2.0 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CHAFF IN THE MOVE | 4 | 4 | 4 | 1.33 | +6 | +1.4 |
| FALLS SHORT | 51 | 36 | 4 | 1.33 | +170 | +42.5 |
| GOAL ROUTE | 4 | 4 | 4 | 1.33 | +124 | +31.0 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +233 | +58.2 |
| REDIRECT FOR A FRIEND IN REACH | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| RISK BY ARC | 9 | 8 | 4 | 1.33 | +192 | +48.1 |
| SHOTS AFTER THE MOVES | 24 | 24 | 4 | 1.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 150 | 120 | 4 | 1.33 | +35 | +8.8 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HIS TURN DENIED | 5 | 5 | 3 | 1.00 | +78 | +25.9 |
| STAY WORTH | 305 | 281 | 3 | 1.00 | +56 | +18.8 |
| THE ROW IN ITS ORDER | 16 | 3 | 3 | 1.00 | +0 | +0.0 |
| TIED UP BY THE SUM | 4 | 4 | 3 | 1.00 | +106 | +35.4 |
| WEAPON BY POINTS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +137 | +68.3 |
| BEST PRIZE | 2 | 2 | 2 | 0.67 | -90 | -45.0 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.67 | -18 | -9.1 |
| REDIRECT COUNTER | 8 | 7 | 2 | 0.67 | +52 | +26.1 |
| SEARCH SPOT | 3 | 3 | 2 | 0.67 | +47 | +23.5 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 24 | 24 | 2 | 0.67 | +178 | +88.9 |
| CHARGE NOW FIRST | 6 | 6 | 1 | 0.33 | -22 | -21.6 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +153 | +153.3 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | -3 | -3.1 |
| HIS MOVE AND SHOT | 28 | 28 | 1 | 0.33 | +18 | +17.5 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +75 | +75.0 |
| MANOEUVRE | 10 | 10 | 1 | 0.33 | +6 | +5.8 |
| MAX FOR POSITIONING | 7 | 6 | 1 | 0.33 | +6 | +6.0 |
| NEARER NOT NEEDED | 24 | 23 | 1 | 0.33 | +30 | +30.4 |
| ONE FIGHT FORMULA | 20 | 13 | 1 | 0.33 | +7 | +7.2 |
| OVERRUNS AWAY | 2 | 2 | 1 | 0.33 | +19 | +18.6 |
| QUARTER ODDS | 66 | 66 | 1 | 0.33 | +108 | +108.3 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +103 | +102.6 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -12 | -11.8 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +2 | +2.0 |
| SET UP BY THE SET | 5 | 5 | 1 | 0.33 | +22 | +22.2 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +76 | +75.5 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +36 | +35.5 |
| CANNON PLAN MISSED | 7 | 7 | 0 | 0.00 | - | - |
| CAST JOB | 4 | 4 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 18 | 18 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 40 | 40 | 0 | 0.00 | - | - |
| COVER ONCE | 27 | 16 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| EXACT ROUND | 12 | 11 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 13 | 12 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 3 | 3 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 16 | not checked | - | - | - | - |
| FOOT FIRST | 85 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 16 | 16 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 6 | not checked | - | - | - | - |
| GUN MASK | 2 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 44 | 44 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 53 | 53 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 16 | 16 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 16 | 16 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 16 | 16 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 62 | 62 | 0 | 0.00 | - | - |
| HONEST WORTH | 9 | 8 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 12 | 12 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 8 | 7 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 5 | 4 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 5 | 4 | 0 | 0.00 | - | - |
| NEAREST TO GOAL | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 13 | 12 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 17 | 11 | 0 | 0.00 | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS A LANE | 2 | 2 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 290 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 5 | 5 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 11 | 10 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 124 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 2 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 38 | 26 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 3 | 3 | 0 | 0.00 | - | - |
| STANDS STILL | 379 | 377 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 13 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 14 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 9 | not checked | - | - | - | - |
| THE TABLE BINDS | 298 | not checked | - | - | - | - |
| WAITS AGAIN | 6 | 6 | 0 | 0.00 | - | - |
| WHO FIGHTS | 6 | 5 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 9 | 9 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p16

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 7.00 | 3.00 | 28.3 |
| PROMISE BY ITS OWN SUM | rule | 4.00 | 0.33 | 82.8 |
| ARMY TABLE | rule | 0.33 | 3.00 | 15.5 |
| CANNON PLANNED TARGET | rule | 2.33 | - | 14.2 |
| HOLDER ASSIGNMENT | rule | 0.67 | 0.33 | 29.6 |
| BEST PRIZE | rule | - | 0.67 | 45.0 |
| PIVOT GUARDS FLANK | rule | - | 0.67 | 9.1 |
| AFTERMATH BAND | gate | 0.33 | - | 3.1 |
| CHARGE NOW FIRST | rule | 0.33 | - | 21.6 |
| DEPLOY BY FIGURES | rule | - | 0.33 | 5.8 |
| FALLBACK | gate | 0.33 | - | 7.6 |
| FIGHT ORDER BAND | gate | 0.33 | - | 3.0 |
| FRIENDS SHOTS CHECKED | rule | 0.33 | - | 3.1 |
| JOINT CHARGE NOW | rule | 0.33 | - | 15.6 |
| REFUSING RETIRES | rule | 0.33 | - | 11.8 |
| RULE SWITCHED OFF | gate | 0.33 | - | 31.9 |

### Plans: gs3-83c8646-p16

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.7 | 40% | 100 | 59 | 58% |
| Mine | join | 2.0 | 100% | 61 | 0 | 0% |
| Mine | move | 25.3 | 100% | 899 | 0 | 0% |
| Mine | shoot | 30.7 | 77% | 2079 | 3305 | 159% |
| Opponent | charge | 1.3 | 25% | 69 | 18 | 25% |
| Opponent | move | 31.0 | 96% | 1005 | 0 | 0% |
| Opponent | shoot | 3.7 | 45% | 380 | 180 | 47% |
| Opponent | support | 1.0 | 100% | 1 | 0 | 0% |

### Battle groups: gs3-83c8646-p16

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 2.7 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p16

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | Character | 13 | 7 (13) | 7 | 0 | 0 | 69% | 2.0 | 0 (3) | 12 (7) | 0 (3) | 11 (8) | 0 (5) |
| Mine | Clean-up | 3 | 0 (3) | 0 | 0 | 16 | 33% | 1.0 | 0 (1) | 0 (1) | 0 (1) | 0 (2) | 0 (1) |
| Mine | Hammer | 6 | 41 (6) | 0 | 41 | 0 | 67% | 2.0 | - | 61 (4) | 0 (2) | 56 (5) | 0 (1) |
| Mine | Shooter | 10 | 79 (10) | 33 | 46 | 7 | 0% | 2.1 | - | 154 (4) | 0 (6) | 142 (5) | 0 (5) |
| Mine | War machine | 17 | 12 (17) | 12 | 0 | 33 | 12% | 1.2 | 22 (9) | 0 (2) | 0 (6) | 0 (3) | 14 (14) |
| Opponent | Chaff | 5 | 23 (5) | 0 | 23 | 11 | 60% | 2.0 | 26 (4) | - | 0 (1) | 27 (4) | 0 (1) |
| Opponent | Character | 8 | 9 (8) | 9 | 0 | 18 | 62% | 4.7 | 0 (3) | 0 (1) | 19 (4) | 13 (5) | 0 (3) |
| Opponent | Clean-up | 3 | 35 (3) | 0 | 35 | 0 | 33% | 5.5 | 0 (1) | 69 (2) | - | 35 (3) | - |
| Opponent | Fast Hammer | 4 | 28 (4) | 0 | 28 | 0 | 50% | 2.5 | - | 49 (3) | 0 (1) | 43 (2) | 16 (2) |
| Opponent | Hammer | 3 | 30 (3) | 30 | 0 | 42 | 67% | 6.0 | 0 (1) | 35 (2) | - | 30 (3) | - |
| Opponent | Holder | 2 | 24 (2) | 24 | 0 | 44 | 50% | 6.0 | - | 24 (2) | - | 0 (1) | 43 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | War machine | 2 | 160 (2) | 160 | 0 | 0 | 0% | 1.0 | - | - | 160 (2) | - | 160 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (1) | 0 (1) | - | 0 (2) | - |

### Charged fights: gs3-83c8646-p16

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 3 | 261 | 0 | 1.7 | 1.4 | 0 | 12 | -12 | 1 of 5 | 2 of 5 | -30 | +0 |
| Opponent | Kingdom of Bretonnia | 1 | 320 | 220 | 3.0 | 1.0 | 73 | 0 | +73 | 1 of 3 | 2 of 3 | - | +73 |
| Opponent | Warriors of Chaos | 2 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 107 | 73 | 1.0 | 1.0 | 73 | 0 | +73 | 1 of 3 | 2 of 3 | - | +73 |

### Effective charges: gs3-83c8646-p16

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 5 | 1 (net +0) | 0 | 0 | 0 | 0 | 3 (net -20) | 1 | 0% (0 of 4) |
| Opponent | Kingdom of Bretonnia | 3 | 2 (net +58) | 0 | 0 | 0 | 0 | 1 (net +105) | 0 | 0% (0 of 3) |

### Charged fights, damage counted: gs3-83c8646-p16

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 60 | 396 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 97 | 138 | -20 | 121 | 28 | +93 | +95.7 |
| Mine | No odds | 1 | 105 | 137 | +0 | 20 | 26 | -7 | -6.4 |
| Mine | All fights | 5 | 91 | 189 | -12 | 76 | 22 | +54 | +59.6 |
| Opponent | Long shot (under 50%) | 2 | 244 | 149 | +58 | 58 | 70 | -13 | -5.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 275 | 105 | +105 | 105 | 0 | +105 | +38.2 |
| Opponent | All fights | 3 | 255 | 134 | +73 | 73 | 47 | +27 | +10.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p16 | move | 17 | 2 (12%) | 2 (12%) | 3 (18%) | 12 (71%) |

## Decision items and abilities without guidance

None: every decision item and ability on these lists has its guidance line.

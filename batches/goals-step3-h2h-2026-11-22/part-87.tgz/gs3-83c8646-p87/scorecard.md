# Doctrine scorecard: gs3-83c8646-p87

### Scorecard: gs3-83c8646-p87

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0417 | 3 | 1 | Mine | no | 3 | 3 | 2 | 2 | 1 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 0 | 1 | 1 | 0 | 1 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Mine | - | - | 2 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 3 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 548 |
| L0520 | 4 | 1 | Opponent | no | 8 | - | 0 | 8 | 1 | 0 | 0 | 65 |
| **Average** | | | Mine | 0% | 1.5 | 2.5 | 0.7 | 1.3 | 0.3 | 0.0 | 0.0 | 182.7 |
| **Average** | | | Opponent | 50% | 4.0 | 2.0 | 1.0 | 4.0 | 0.7 | 0.0 | 0.0 | 21.7 |

### KPIs: gs3-83c8646-p87

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 29% (4 of 14) | 0% (0 of 17) | 13% (4 of 31) |
| Winner chose to follow up after the loser gave ground |  | 50% (1 of 2); on the table 50% | 100% (2 of 2); on the table 100% | 75% (3 of 4); on the table 75% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 100% | - | 0% (0 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 33% (1 of 3); on the table 67% | 100% (3 of 3); on the table 100% | 67% (4 of 6); on the table 83% |
| Magic missiles tried each own turn | 50%+ | 50% (6 of 12) | 42% (5 of 12) | 46% (11 of 24) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 50% (6 of 12) | 42% (5 of 12) | 46% (11 of 24) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 64% (7 of 11) | 64% (7 of 11) |
| Points that never fought | lower | 75% (4524 of 5998) | 67% (3997 of 5997) | 71% (8521 of 11995) |
|   infantry points that never fought | lower | 78% (1115 of 1424) | 83% (1379 of 1662) | 81% (2494 of 3086) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 65% (15 of 23) | 68% (15 of 22) | 67% (30 of 45) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 60% (3085 of 5120) | 64% (3155 of 4957) | 62% (6240 of 10077) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (33%) | 1.7 (71%) | 2.3 (54%) |
| MARCHED: its unit marched | 1.3 (67%) | 0.7 (29%) | 2.0 (46%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 0.7 | 3.7 | 1.7 | 0.3 |
| not cast | 2.0 | 1.3 | 4.3 | 4.3 | 11.7 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (100%) | 2.3 (54%) | 1.0 (23%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 2.0 (46%) | 2.0 (46%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (8%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (23%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 11.7 (100%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.7 a game | 0.0 a game | 0.3 a game |
| stood (cast and not dispelled) | 100% (2 of 2) | - | 100% (2 of 2) |
| the unit moved after it | 0% (0 of 2) | - | 0% (0 of 2) |
| it charged on its next turn | 50% (1 of 2) | - | 50% (1 of 2) |
| the enemy charged it first | 0% (0 of 2) | - | 0% (0 of 2) |
| it fought by the end of its next turn | 0% (0 of 2) | - | 0% (0 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 2) | - | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | 50% (1 of 2) | - | 50% (1 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 81% (81 of 100) | 72% (56 of 78) | 77% (137 of 178) |
|   cavalry | 82% (9 of 11) | 91% (10 of 11) | 86% (19 of 22) |
|   character | 71% (17 of 24) | 56% (5 of 9) | 67% (22 of 33) |
|   chariot | 74% (17 of 23) | - | 74% (17 of 23) |
|   infantry | 75% (9 of 12) | 79% (34 of 43) | 78% (43 of 55) |
|   monster | - | 47% (7 of 15) | 47% (7 of 15) |
|   war machine | 97% (29 of 30) | - | 97% (29 of 30) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (32%) | 1.0 (14%) | 3.0 (22%) |
| CHARGED: it charged | 0.0 (0%) | 1.3 (18%) | 1.3 (10%) |
| IN COMBAT: it fought this turn or the last | 0.3 (5%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 3.7 (58%) | 3.3 (45%) | 7.0 (51%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 1.7 (23%) | 1.7 (12%) |
| SHELTERED: the target was sheltered | 0.3 (5%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 10.3 | 1.7 | 87% | 4.6 pts | 48 pts |
| character | 7.3 | 6.0 | 41% | 6.9 pts | 51 pts |
| chariot | 5.7 | 8.0 | 29% | 31.2 pts | 177 pts |
| infantry | 25.0 | 8.3 | 73% | 7.1 pts | 177 pts |
| monster | 2.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 9.7 | 16.7 | 48% | 61.1 pts | 590 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.7 | 2.7 | 2.2 |
| Charges that made contact a game | 1.0 | 2.0 | 1.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.23 declared, 0.14 contact (22 units) | 0.27 declared, 0.20 contact (30 units) | 0.25 declared, 0.17 contact (52 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 100% (4 of 4) | - | - | 100% (4 of 4) |
| Character in a unit | 100% (4 of 4) | 100% (1 of 1) | - | 100% (5 of 5) |
| Character on its own | 100% (2 of 2) | 0% (0 of 2) | 71% (5 of 7) | 64% (7 of 11) |
| Chariot | - | 50% (2 of 4) | - | 50% (2 of 4) |
| Infantry | 58% (7 of 12) | 0% (0 of 2) | - | 50% (7 of 14) |
| Monster | 67% (2 of 3) | 100% (2 of 2) | - | 80% (4 of 5) |
| Monstrous | 50% (1 of 2) | - | - | 50% (1 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 2 | 33% (1 of 3); on the table 67% | 50% (6 of 12) | 65% | 62% (10 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Dwarfen Mountain Holds | 1 | - | - | 97% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Lizardmen | 1 | 100% (1 of 1); on the table 100% | 83% (5 of 6) | 80% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Skaven | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 86% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Wood Elf Realms | 1 | 100% (1 of 1); on the table 100% | - | 35% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p87, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (3) | 100% (1) | 100% (4) |
| ...free all their last turn and able to turn (per game) | 1.00 | 0.33 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.00 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: gs3-83c8646-p87

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.0 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 20% (1 of 5) | 75% (6 of 8) |
| Strategy | Shoot objectives carried out (shot that target) | 32% (15 of 47) | 38% (5 of 13) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 0% (0 of 5) | 50% (1 of 2) |
| Strategy | Lone characters that fought | 33% (2 of 6) | 50% (3 of 6) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.3 | 4.0 |
| Movement | Points that never moved of their own | 182.7 | 21.7 |
| Movement | Fights charged into per game | 1.0 | 1.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 2 | 0 of 5 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 2, net +405 | 0 of 5 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 2, net +165 | 2 of 5, net +88 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 2 | 2 of 5, net +188 |
| Shooting | Shots by shooting units (incl. breath weapons) | 18.0 | 20.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 30% (16 of 54) | 50% (31 of 62) |
| Shooting | Points destroyed by shooting units | 104.7 | 113.0 |
| Shooting | War machine shots | 9.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 62% (18 of 29) | - |
| Shooting | Points destroyed by war machines | 91.7 | 0.0 |
| Magic | Magic missiles cast | 0.7 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 2) | 0% (0 of 2) |
| Magic | Wounds caused by magic missiles | 2.0 | 2.3 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 46.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 0.0 / 0.0 / 1.0 | 2.0 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 171.3 | 162.3 |
| Combat | Points run down | 0.0 | 21.7 |
| Combat | Net points per charged fight, damage counted | +77 | -10 |
| Combat | Net per 100 charger points, damage counted | +28.9 | -2.6 |
| Combat | First round won (charged fights) | 67% | 100% |
| Combat | Net points per charged fight | +190 | +110 |
| Combat | Net points per supported fight / lone fight | - / +190 | +65 / +122 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 3 | 2 of 5 |
| Game | Points lost | 343.3 | 398.0 |
| Game | VP from objectives | 526.7 | 790.0 |
| Game | Lone holders (player turns) | 1.5 | 4.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -225 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 741
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p87

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH IN POINTS | 0.3 | +11.5 | 0.0 | 103.3 | - | - | - | - |
| ARMY TABLE | 17.7 | +366.6 | 0.0 | 43.3 | 31.3 | +238.7 | 0.0 | 224.0 |
| ARTILLERY RE-ROLL WEIGHED | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 1.0 | +1.4 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 9.3 | +360.0 | 278.3 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | - | - | - | - | 0.3 | +1.9 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 2.0 | +16.1 | 0.0 | 21.7 | 1.3 | +14.6 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.3 | +2.4 | 0.0 | 36.3 |
| CHARACTER GUNS | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 22.3 | -538.1 | 0.0 | 363.3 | 23.7 | -804.5 | 0.0 | 146.7 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 36.3 | 0.0 | 1.0 | +0.0 | 140.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.3 | +0.0 | 0.0 | 43.3 | 11.0 | +0.0 | 0.0 | 144.0 |
| COMBAT PIVOT | 0.7 | +0.0 | 135.0 | 113.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.7 | +20.3 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 11.0 | -745.5 | 0.0 | 121.0 | 12.0 | -663.5 | 0.0 | 74.7 |
| DEPLOY BY FIGURES | 8.7 | -48.8 | 0.0 | 0.0 | 9.0 | -54.3 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | 0.7 | +29.4 | 0.0 | 37.3 | 1.3 | +18.9 | 74.7 | 0.0 |
| EXACT ROUND | 0.7 | -2.4 | 0.0 | 0.0 | 2.0 | +7.4 | 184.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.3 | +0.0 | 36.3 | 0.0 | 2.3 | +0.0 | 205.7 | 0.0 |
| FALLS SHORT | - | - | - | - | 27.7 | +167.9 | 0.0 | 97.7 |
| FEATURE BUFFS | 1.3 | +9.2 | 0.0 | 74.7 | - | - | - | - |
| FIGHT TO THE END | 0.3 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 101.7 | +5964.2 | 739.3 | 714.7 | 101.7 | +5228.6 | 587.0 | 432.7 |
| FLANK NOT WEIGHED | 11.0 | +0.0 | 0.0 | 114.3 | 7.3 | +0.0 | 0.0 | 36.3 |
| FOLLOW UP WEIGHED | 0.3 | +35.9 | 0.0 | 0.0 | 0.7 | +75.1 | 0.0 | 0.0 |
| FOOT FIRST | 26.7 | +0.0 | 0.0 | 314.0 | - | - | - | - |
| FOUR ROUNDS | 1.7 | +61.5 | 55.0 | 0.0 | 2.7 | +134.9 | 205.7 | 0.0 |
| FREED FROM HIS FIGHT | 7.7 | +0.0 | 0.0 | 210.7 | 10.3 | +0.0 | 0.0 | 18.0 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.7 | -51.1 | 103.3 | 0.0 |
| GIVES UP | - | - | - | - | 0.3 | -0.3 | 0.0 | 0.0 |
| GOAL WALK | 11.7 | +956.3 | 0.0 | 86.7 | 5.0 | +284.5 | 0.0 | 0.0 |
| GUN FIGURES | 3.3 | +74.3 | 74.0 | 0.0 | - | - | - | - |
| GUN MASK | 1.3 | +33.3 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 4.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 6.3 | +0.0 | 0.0 | 118.0 | 7.7 | +0.0 | 0.0 | 18.0 |
| HIS CHARGE BY HIS RUN | 19.0 | +0.0 | 0.0 | 363.3 | 13.3 | +0.0 | 0.0 | 76.7 |
| HIS CHARGE DENIED | 0.3 | +4.1 | 0.0 | 0.0 | 0.3 | +8.4 | 37.3 | 0.0 |
| HIS CHARGE LIST | 2.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 8.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.0 | -22.0 | 0.0 | 74.7 | 7.3 | -102.1 | 0.0 | 0.0 |
| HIS ONE QUARTER | 8.0 | +0.0 | 0.0 | 92.7 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 9.3 | +0.0 | 0.0 | 0.0 | 9.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 42.7 | +1341.5 | 0.0 | 379.0 | 61.3 | +2725.7 | 0.0 | 324.7 |
| HIS SHOTS BY HIS RUN | 41.0 | +549.0 | 0.0 | 450.0 | 61.3 | +1774.7 | 0.0 | 316.7 |
| HIS TURN DENIED | 0.3 | +4.8 | 18.7 | 0.0 | - | - | - | - |
| HOLD ODDS | 12.7 | +0.0 | 0.0 | 149.3 | 14.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 7.3 | +689.5 | 0.0 | 37.3 | 10.3 | +788.3 | 0.0 | 0.0 |
| HONEST WORTH | 1.7 | -31.0 | 55.0 | 0.0 | 2.7 | -85.5 | 205.7 | 0.0 |
| IDLE COST | - | - | - | - | 22.0 | -316.9 | 0.0 | 162.7 |
| JOINT CHARGE NOW | - | - | - | - | 0.7 | +0.3 | 43.3 | 0.0 |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.0 | +43.0 | 0.0 | 0.0 | 1.0 | +36.6 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.0 | +0.0 | 270.0 | 442.3 | 15.7 | +0.0 | 861.7 | 377.7 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.3 | +31.7 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +11.6 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 0.7 | +3.3 | 0.0 | 0.0 | 1.7 | +2.1 | 65.0 | 0.0 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.3 | -25.8 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.7 | +3.2 | 0.0 | 0.0 |
| MANOEUVRE | 1.3 | -4.9 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +34.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.7 | +25.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH ODDS | 0.3 | +16.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.7 | +10.8 | 0.0 | 0.0 | 0.7 | +0.8 | 0.0 | 0.0 |
| MARCH OVER CASTS | 1.3 | +96.6 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.3 | +23.1 | 0.0 | 21.7 | 3.0 | +39.6 | 0.0 | 0.0 |
| MEETS IN TIME | 5.0 | +152.8 | 0.0 | 0.0 | 4.7 | +143.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.3 | +45.5 | 0.0 | 0.0 | 2.0 | +12.6 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 3.3 | +55.5 | 0.0 | 0.0 | 3.0 | +16.5 | 0.0 | 0.0 |
| MOVE ORDER | 1.7 | +0.0 | 103.3 | 0.0 | 2.0 | +0.0 | 0.0 | 35.7 |
| MOVE SPELL IN RANGE | 2.0 | +66.3 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 4.0 | +342.9 | 0.0 | 0.0 | 8.7 | +511.5 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 7.0 | +296.5 | 0.0 | 0.0 | 4.7 | +216.0 | 0.0 | 0.0 |
| NEAREST TO GOAL | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 3.3 | +307.0 | 0.0 | 0.0 | 7.7 | +486.0 | 103.3 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 1.3 | -61.8 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.7 | -43.8 | 55.0 | 0.0 | 2.3 | -111.4 | 184.0 | 0.0 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.3 | +20.4 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 5.0 | -277.2 | 0.0 | 37.3 | 4.0 | -144.7 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 4.3 | -79.1 | 0.0 | 37.3 | 8.3 | -171.7 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +0.5 | 21.7 | 0.0 |
| ONE OBJECTIVE FORMULA | 3.7 | -83.3 | 0.0 | 37.3 | 3.3 | -61.4 | 0.0 | 0.0 |
| ONE ROUTE | 1.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.7 | +41.8 | 37.3 | 0.0 |
| OVERRUNS AWAY | 0.3 | +0.2 | 0.0 | 0.0 | 0.7 | +80.2 | 140.7 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +17.8 | 0.0 | 0.0 |
| PERIAPT WORTH | - | - | - | - | 0.3 | +40.6 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -2.2 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 45.3 | +531.5 | 461.7 | 448.7 | 47.7 | +351.7 | 149.7 | 396.3 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 5.3 | -35.9 | 0.0 | 0.0 | 9.3 | -162.8 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.3 | -11.6 | 0.0 | 0.0 |
| QUARTER ODDS | 21.3 | +1419.7 | 420.0 | 185.3 | 19.0 | +2554.1 | 278.0 | 70.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.7 | +49.0 | 0.0 | 70.0 |
| REAL GROUND | 1.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.7 | -12.2 | 0.0 | 0.0 | 1.3 | +24.7 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.7 | +73.8 | 0.0 | 43.3 | 1.7 | +24.3 | 0.0 | 9.0 |
| REDIRECT FOR A FRIEND IN REACH | 1.0 | +0.0 | 0.0 | 21.7 | 3.3 | +52.2 | 0.0 | 9.0 |
| REDIRECT WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | - | - | - | - | 2.7 | -33.6 | 0.0 | 0.0 |
| RESERVE FALL BACK | 1.3 | +43.9 | 0.0 | 0.0 | 0.7 | +14.7 | 0.0 | 0.0 |
| RISK BY ARC | 1.7 | +23.6 | 55.0 | 0.0 | 1.7 | -141.3 | 162.3 | 0.0 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.3 | -4.1 | 18.7 | 0.0 | 1.0 | +1.8 | 37.3 | 0.0 |
| RUN DOWN | 1.3 | -12.0 | 18.7 | 0.0 | 2.0 | -15.4 | 102.3 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.7 | -14.9 | 0.0 | 0.0 | 0.7 | -15.3 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +16.9 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 2.0 | -55.1 | 0.0 | 0.0 | 0.7 | -11.3 | 0.0 | 18.0 |
| SET UP BY THE SET | 2.7 | +129.7 | 0.0 | 0.0 | 1.0 | -33.8 | 0.0 | 18.0 |
| SET UP TOGETHER | - | - | - | - | 1.3 | +4.2 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.7 | -6.5 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | 0.3 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 15.7 | +0.0 | 0.0 | 37.3 | 4.7 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.7 | +89.3 | 38.3 | 0.0 | 2.7 | +43.8 | 92.7 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -12.9 | 103.3 | 0.0 |
| SHOT RISK POINTS | 27.7 | -425.2 | 0.0 | 406.7 | 42.7 | +338.4 | 0.0 | 360.0 |
| SHOTS AFTER THE MOVES | 4.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 19.3 | +929.6 | 0.0 | 74.7 | 16.3 | +336.6 | 0.0 | 18.7 |
| SPELL WORTH | - | - | - | - | 2.0 | +22.2 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 5.3 | +0.0 | 0.0 | 43.3 | 7.7 | +0.0 | 0.0 | 20.7 |
| STAND AND SHOOT | 0.3 | -1.6 | 0.0 | 0.0 | 1.0 | -9.4 | 37.3 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 5.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 56.3 | +0.0 | 684.3 | 264.7 | 34.7 | +0.0 | 381.3 | 43.3 |
| STAY WORTH | 32.0 | +751.9 | 393.3 | 0.0 | 11.3 | +94.7 | 103.3 | 35.7 |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 3.0 | +388.8 | 0.0 | 43.3 | 4.0 | +278.9 | 0.0 | 71.3 |
| SUPPORT WORKED OUT | 3.0 | +388.8 | 0.0 | 43.3 | 4.0 | +278.9 | 0.0 | 71.3 |
| SURE REACH TOGETHER | - | - | - | - | 1.0 | +3.4 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 21.7 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.7 | +0.0 | 0.0 | 21.7 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 78.7 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 57.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 50.0 | +0.0 | 0.0 | 357.3 | 47.3 | +0.0 | 0.0 | 181.3 |
| TIED UP BY THE SUM | 0.3 | +44.6 | 36.3 | 0.0 | 0.7 | +85.2 | 37.3 | 0.0 |
| TIME ON OUR SIDE | 54.0 | +648.5 | 0.0 | 308.0 | - | - | - | - |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.7 | -43.5 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.3 | +0.0 | 0.0 | 103.3 | - | - | - | - |
| WHO FIGHTS | 0.3 | -1.3 | 0.0 | 0.0 | 0.3 | -1.4 | 21.7 | 0.0 |
| WHO HITS BACK | 0.3 | +117.9 | 0.0 | 0.0 | 0.3 | +108.9 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.0 | -80.5 | 0.0 | 0.0 | 1.3 | -82.2 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +10.0 | 21.7 | 0.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 3.3 | +58.6 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p87

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 147 | 147 | 108 | 36.00 | +1217 | +11.3 |
| HIS SHOTS BY HIS RUN | 307 | 298 | 89 | 29.67 | +1184 | +13.3 |
| HIS SHOT LIST | 312 | 301 | 73 | 24.33 | +1146 | +15.7 |
| LEGAL CHARGES ONLY | 53 | 53 | 53 | 17.67 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 53 | 53 | 48 | 16.00 | +2880 | +60.0 |
| SHOT RISK POINTS | 211 | 207 | 45 | 15.00 | +1068 | +23.7 |
| DEPLOY BY FIGURES | 53 | 53 | 28 | 9.33 | +385 | +13.7 |
| OFF BEST | 27 | 27 | 27 | 9.00 | -1265 | -46.9 |
| FIVE ACTION | 610 | 595 | 22 | 7.33 | +760 | +34.5 |
| MOVE TO CHARGE COMPUTED | 38 | 37 | 22 | 7.33 | +1054 | +47.9 |
| TIME ON OUR SIDE | 162 | 140 | 21 | 7.00 | +100 | +4.7 |
| NEXT CHARGE BY LIST | 33 | 32 | 19 | 6.33 | +1054 | +55.5 |
| QUARTER ODDS | 121 | 121 | 19 | 6.33 | +1962 | +103.2 |
| GOAL WALK | 50 | 50 | 15 | 5.00 | +741 | +49.4 |
| HARD STAY DROPPED | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 16 | 16 | 15 | 5.00 | +169 | +11.3 |
| MEETS IN TIME | 29 | 29 | 13 | 4.33 | +307 | +23.6 |
| THE TABLE AGAIN | 36 | 36 | 13 | 4.33 | +0 | +0.0 |
| CANNON PLANNED TARGET | 28 | 28 | 12 | 4.00 | -873 | -72.7 |
| CHARGE LOSSES | 138 | 137 | 11 | 3.67 | +414 | +37.7 |
| IDLE COST | 66 | 51 | 11 | 3.67 | +85 | +7.7 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| COVER ONCE | 69 | 50 | 10 | 3.33 | +192 | +19.2 |
| PROMISE BY ITS OWN SUM | 44 | 44 | 10 | 3.33 | -596 | -59.6 |
| REDIRECT FOR A FRIEND IN REACH | 13 | 13 | 10 | 3.33 | +0 | +0.0 |
| SUPPORT ADDS | 21 | 20 | 10 | 3.33 | +545 | +54.5 |
| SUPPORT WORKED OUT | 21 | 20 | 10 | 3.33 | +545 | +54.5 |
| CHAFF IN THE MOVE | 10 | 9 | 7 | 2.33 | +8 | +1.2 |
| FALLS SHORT | 83 | 72 | 7 | 2.33 | +41 | +5.8 |
| FOUR ROUNDS | 13 | 13 | 7 | 2.33 | +114 | +16.3 |
| RANDOM MOVE BY FIGURES | 11 | 11 | 7 | 2.33 | +147 | +21.0 |
| SHOTS IN THE MOVE | 107 | 76 | 7 | 2.33 | +187 | +26.7 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +239 | +39.8 |
| RESERVE FALL BACK | 6 | 6 | 6 | 2.00 | +176 | +29.3 |
| STAY WORTH | 130 | 116 | 6 | 2.00 | +96 | +16.0 |
| ADVANCE LANE KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CANNON SIGHT KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| COMBAT PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| MARCH OF THE TABLE | 4 | 4 | 4 | 1.33 | -35 | -8.7 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +333 | +110.9 |
| MISSILES IN THE MOVE | 13 | 8 | 3 | 1.00 | +6 | +2.1 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +8 | +2.7 |
| TIED UP BY THE SUM | 3 | 3 | 3 | 1.00 | +30 | +10.2 |
| CHARGE NOW FIRST | 7 | 7 | 2 | 0.67 | -29 | -14.7 |
| EVASIVE BY THE ODDS | 6 | 6 | 2 | 0.67 | +92 | +46.0 |
| GUN MASK | 4 | 4 | 2 | 0.67 | +38 | +19.2 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +1 | +0.4 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +102 | +51.0 |
| MAX FOR POSITIONING | 13 | 12 | 2 | 0.67 | +1 | +0.4 |
| OPENS UP | 2 | 2 | 2 | 0.67 | +23 | +11.5 |
| RISK BY ARC | 10 | 10 | 2 | 0.67 | +10 | +5.1 |
| SET UP BY THE SET | 11 | 11 | 2 | 0.67 | +223 | +111.5 |
| SHOTS AFTER THE MOVES | 22 | 22 | 2 | 0.67 | +0 | +0.0 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 2 | 2 | 2 | 0.67 | -131 | -65.3 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +452 | +226.2 |
| WHOLE FIGHT DANGER | 10 | 10 | 2 | 0.67 | +7 | +3.7 |
| WOUNDS ON THE RANKS | 10 | 10 | 2 | 0.67 | +30 | +15.2 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +34 | +34.5 |
| CAST JOB | 1 | 1 | 1 | 0.33 | +0 | +0.5 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +7 | +7.4 |
| HIS CHARGE DENIED | 2 | 2 | 1 | 0.33 | +19 | +18.6 |
| HIS TURN DENIED | 1 | 1 | 1 | 0.33 | +14 | +13.8 |
| HONEST WORTH | 13 | 13 | 1 | 0.33 | +6 | +6.1 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +95 | +95.0 |
| LONG SHOT | 1 | 1 | 1 | 0.33 | +27 | +26.8 |
| MARCH ODDS | 1 | 1 | 1 | 0.33 | -34 | -33.8 |
| NEARER NOT NEEDED | 35 | 34 | 1 | 0.33 | +52 | +52.2 |
| NO DOUBLE ROUNDS | 12 | 12 | 1 | 0.33 | +12 | +12.2 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.33 | +39 | +38.6 |
| ONE FIGHT FORMULA | 38 | 23 | 1 | 0.33 | +1 | +0.8 |
| OVERRUNS AWAY | 3 | 3 | 1 | 0.33 | +12 | +12.2 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +54 | +53.5 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +122 | +121.9 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -7 | -6.7 |
| PROMISE READS THE TABLE | 1 | 1 | 1 | 0.33 | -30 | -30.5 |
| REDIRECT BY WHAT IT STOPS | 6 | 6 | 1 | 0.33 | +0 | +0.0 |
| REDIRECT COUNTER | 10 | 6 | 1 | 0.33 | +62 | +62.5 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +99 | +98.7 |
| ROUNDS AFTER TERROR | 4 | 4 | 1 | 0.33 | +19 | +18.6 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +51 | +50.8 |
| SURE REACH TOGETHER | 3 | 3 | 1 | 0.33 | +0 | +0.4 |
| THE ROW IN ITS ORDER | 15 | 1 | 1 | 0.33 | +0 | +0.0 |
| BACKUP TARGETS | 3 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CHARACTER GUNS | 6 | 6 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 55 | 55 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 2 | not checked | - | - | - | - |
| EXACT ROUND | 8 | 8 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 11 | 11 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 55 | not checked | - | - | - | - |
| FOOT FIRST | 80 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 54 | 52 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 10 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 42 | 40 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 97 | 96 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 22 | 22 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 31 | 31 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 31 | 31 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 39 | 39 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 56 | 55 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 8 | 8 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 2 | 2 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 81 | 81 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 11 | 11 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 7 | 7 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MANOEUVRE | 6 | 6 | 0 | 0.00 | - | - |
| MARCH CHECK | 2 | 2 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 8 | 8 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 19 | 15 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 6 | 3 | 0 | 0.00 | - | - |
| NEAREST TO GOAL | 7 | 7 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 4 | 1 | 0 | 0.00 | - | - |
| NO LATE CUT | 5 | 5 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 21 | 19 | 0 | 0.00 | - | - |
| ONE ROUTE | 8 | 8 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 279 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 8 | 8 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 8 | 8 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 7 | 7 | 0 | 0.00 | - | - |
| RUN DOWN | 10 | 10 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 8 | 8 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 4 | 2 | 0 | 0.00 | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 61 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 6 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 39 | 29 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 15 | 12 | 0 | 0.00 | - | - |
| STANDS STILL | 273 | 261 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 3 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 11 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 20 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 13 | not checked | - | - | - | - |
| THE TABLE BINDS | 292 | not checked | - | - | - | - |
| WAITS AGAIN | 9 | 9 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 1 | 1 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p87

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.33 | 2.67 | 38.0 |
| ARMY TABLE | rule | 2.33 | 3.67 | 43.8 |
| PROMISE BY ITS OWN SUM | rule | 0.67 | 2.67 | 59.6 |
| CANNON PLANNED TARGET | rule | 2.67 | - | 110.9 |
| MARCH OF THE TABLE | rule | 0.67 | 0.33 | 11.5 |
| RULE SWITCHED OFF | gate | - | 1.00 | 50.9 |
| CHARGE NOW FIRST | rule | 0.67 | - | 14.7 |
| NO REASON | gate | 0.67 | - | 155.5 |
| WALKS ON ITS ROUTE | rule | - | 0.67 | 65.3 |
| AFTERMATH BAND | gate | - | 0.33 | 2.7 |
| JOINT CHARGE NOW | rule | - | 0.33 | 4.6 |
| MARCH ODDS | rule | 0.33 | - | 33.8 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 6.7 |
| PROMISE READS THE TABLE | rule | - | 0.33 | 30.5 |

### Plans: gs3-83c8646-p87

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 50% | 97 | 101 | 105% |
| Mine | join | 0.7 | 100% | 23 | 0 | 0% |
| Mine | move | 29.7 | 99% | 1630 | 0 | 0% |
| Mine | shoot | 13.0 | 64% | 877 | 430 | 49% |
| Mine | support | 0.7 | 100% | 1 | 0 | 0% |
| Opponent | charge | 1.7 | 80% | 168 | 221 | 132% |
| Opponent | move | 42.7 | 94% | 1788 | 0 | 0% |
| Opponent | shoot | 2.3 | 43% | 110 | 130 | 119% |
| Opponent | support | 1.0 | 100% | 30 | 0 | 0% |

### Battle groups: gs3-83c8646-p87

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.7 | 40% | 50% | 0% | - | 0% | 0% | 0% | 50% | 50% |
| Opponent | REDIRECT COUNTER | 1.7 | 20% | 100% | 0% | - | 100% | 0% | 0% | 0% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p87

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | - | - | 0 (1) | 0 (1) | - |
| Mine | Character | 11 | 22 (11) | 22 | 0 | 13 | 27% | 2.0 | 0 (5) | 39 (4) | 36 (2) | 0 (8) | 76 (3) |
| Mine | Clean-up | 3 | 0 (3) | 0 | 0 | 0 | 33% | 5.5 | 0 (3) | - | - | 0 (1) | 0 (2) |
| Mine | Fast Hammer | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | - | 0 (1) | - | 0 (1) |
| Mine | Hammer | 10 | 39 (10) | 16 | 24 | 19 | 30% | 2.4 | 44 (3) | 30 (6) | 72 (1) | 46 (9) | 0 (1) |
| Mine | Holder | 2 | 252 (2) | 0 | 252 | 50 | 100% | - | - | 252 (2) | - | 504 (1) | 0 (1) |
| Mine | Shooter | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | - | 0 (1) | 0 (1) | - |
| Mine | War machine | 5 | 58 (5) | 58 | 0 | 0 | 0% | 1.0 | 17 (4) | 221 (1) | - | - | 58 (5) |
| Opponent | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | 0 (1) | - | 0 (1) | 0 (2) | - |
| Opponent | Character | 7 | 16 (7) | 16 | 0 | 16 | 43% | 1.5 | 0 (4) | 0 (1) | 42 (2) | 30 (3) | 7 (4) |
| Opponent | Clean-up | 6 | 11 (6) | 11 | 0 | 29 | 33% | 2.8 | 15 (3) | 5 (3) | - | 18 (4) | 0 (2) |
| Opponent | Fragile | 5 | 0 (5) | 0 | 0 | 54 | 80% | 1.0 | 0 (1) | 0 (4) | - | 0 (2) | 0 (3) |
| Opponent | Hammer | 6 | 20 (6) | 20 | 0 | 22 | 50% | 3.7 | 40 (2) | 10 (3) | 0 (1) | 25 (5) | 0 (1) |
| Opponent | Holder | 3 | 99 (3) | 0 | 99 | 10 | 67% | 1.0 | - | 145 (2) | 0 (1) | 145 (2) | 0 (1) |
| Opponent | Shooter | 9 | 113 (9) | 37 | 76 | 14 | 33% | 1.5 | 139 (3) | 169 (4) | 0 (2) | 203 (4) | 72 (5) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | 0 (1) | - | - | - | 0 (1) |

### Charged fights: gs3-83c8646-p87

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 124 | 285 | 1.5 | 1.0 | 190 | 0 | +190 | 2 of 3 | 2 of 3 | - | +190 |
| Mine | Dwarfen Mountain Holds | 1 | 340 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 196 | 190 | 1.0 | 1.0 | 190 | 0 | +190 | 2 of 3 | 2 of 3 | - | +190 |
| Opponent | Lizardmen | 1 | 478 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Skaven | 1 | 0 | 65 | 1.0 | 1.0 | 65 | 0 | +65 | 0 of 1 | 1 of 1 | - | +65 |
| Opponent | Wood Elf Realms | 1 | 0 | 487 | 4.0 | 1.2 | 122 | 0 | +122 | 2 of 4 | 4 of 4 | +65 | +141 |
| **Opponent** | all armies | 3 | 159 | 184 | 1.7 | 1.2 | 110 | 0 | +110 | 2 of 5 | 5 of 5 | +65 | +122 |

### Effective charges: gs3-83c8646-p87

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 3 | 0 | 0 | 1 (net +405) | 0 | 1 (net +165) | 0 | 1 | 50% (1 of 2) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +65) | 0 | 0% (0 of 1) |
| Opponent | Wood Elf Realms | 4 | 0 | 0 | 0 | 1 (net +0) | 2 (net +88) | 1 (net +310) | 0 | 0% (0 of 4) |

### Charged fights, damage counted: gs3-83c8646-p87

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 339 | 405 | +405 | 405 | 291 | +114 | +33.8 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 339 | 109 | +165 | 165 | 48 | +117 | +34.4 |
| Mine | No odds | 1 | 120 | 500 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | All fights | 3 | 266 | 338 | +190 | 190 | 113 | +77 | +28.9 |
| Opponent | 76-89% | 1 | 499 | 310 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 346 | 188 | +188 | 192 | 305 | -113 | -32.6 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 350 | 88 | +88 | 88 | 0 | +88 | +25.3 |
| Opponent | All fights | 5 | 378 | 172 | +110 | 112 | 122 | -10 | -2.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p87 | move | 30 | 1 (3%) | 1 (3%) | 5 (17%) | 24 (80%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0434 |
| Periapt of Soul Exchange | Opponent | L0520 |

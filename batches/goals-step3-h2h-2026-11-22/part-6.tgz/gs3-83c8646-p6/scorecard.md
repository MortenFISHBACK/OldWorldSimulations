# Doctrine scorecard: gs3-83c8646-p6

### Scorecard: gs3-83c8646-p6

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0913 | 1 | 1 | Mine | no | 2 | 4 | 3 | 2 | 0 | 0 | 0 | 420 |
| L0913 | 1 | 1 | Opponent | no | 12 | - | 0 | 1 | 1 | 0 | 0 | 540 |
| L0930 | 6 | 1 | Mine | no | 0 | 6 | 1 | 2 | 0 | 0 | 0 | 375 |
| L0930 | 6 | 1 | Opponent | no | 2 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 1 | 4 | 1 | 0 | 0 | 0 | 0 | 456 |
| L1021 | 1 | 1 | Opponent | no | 0 | - | 0 | 7 | 0 | 0 | 0 | 420 |
| **Average** | | | Mine | 0% | 1.0 | 4.7 | 1.7 | 1.3 | 0.0 | 0.0 | 0.0 | 417.0 |
| **Average** | | | Opponent | 0% | 4.7 | 2.0 | 0.3 | 3.3 | 0.3 | 0.0 | 0.0 | 320.0 |

### KPIs: gs3-83c8646-p6

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 67% (10 of 15) | 0% (0 of 11) | 38% (10 of 26) |
| Winner chose to follow up after the loser gave ground |  | - | 40% (2 of 5); on the table 60% | 40% (2 of 5); on the table 60% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (1 of 1); on the table 100% | 50% (3 of 6); on the table 67% | 57% (4 of 7); on the table 71% |
| Magic missiles tried each own turn | 50%+ | 44% (21 of 48) | 0% (0 of 12) | 35% (21 of 60) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 46% (21 of 46) | 0% (0 of 10) | 38% (21 of 56) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 85% (11 of 13) | 85% (11 of 13) |
| Points that never fought | lower | 69% (4161 of 5997) | 79% (4763 of 5999) | 74% (8924 of 11996) |
|   infantry points that never fought | lower | 100% (1591 of 1591) | 76% (1258 of 1660) | 88% (2849 of 3251) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 65% (22 of 34) | 83% (19 of 23) | 72% (41 of 57) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 1.7 uses a game | 50% (1 of 2); 1.7 uses a game | 75% (3 of 4); 1.7 uses a game |
| Bound items with another spell used |  | 100% (1 of 1); 0.3 uses a game | 0% (0 of 2); 0.0 uses a game | 33% (1 of 3); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 100% (2 of 2); 0.7 uses a game | 67% (2 of 3); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 68% (3879 of 5667) | 79% (4080 of 5150) | 74% (7959 of 10817) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 5.3 (59%) | 3.3 (83%) | 8.7 (67%) |
| MARCHED: its unit marched | 3.0 (33%) | 0.0 (0%) | 3.0 (23%) |
| IN COMBAT: engaged in combat | 0.7 (7%) | 0.0 (0%) | 0.7 (5%) |
| GONE: slain | 0.0 (0%) | 0.7 (17%) | 0.7 (5%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.3 | 3.3 | 1.0 | 7.0 | 0.0 | 0.7 |
| not cast | 0.7 | 4.7 | 1.0 | 13.0 | 2.0 | 19.3 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 4.3 (93%) | 0.0 (0%) | 8.7 (67%) | 1.0 (50%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.0 (23%) | 0.3 (17%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (5%) | 0.7 (33%) | 0.0 (0%) |
| GONE: slain | 0.7 (100%) | 0.0 (0%) | 0.7 (67%) | 0.7 (5%) | 0.0 (0%) | 1.7 (9%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (7%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.0 (0%) | 0.0 (0%) | 0.3 (33%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.7 (91%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.0 a game | 0.5 a game |
| stood (cast and not dispelled) | - | 100% (3 of 3) | 100% (3 of 3) |
| the unit moved after it | - | 0% (0 of 3) | 0% (0 of 3) |
| it charged on its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| the enemy charged it first | - | 0% (0 of 3) | 0% (0 of 3) |
| it fought by the end of its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 3) | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (3 of 3) | 100% (3 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (81 of 125) | 72% (29 of 40) | 67% (110 of 165) |
|   character | 100% (6 of 6) | 58% (7 of 12) | 72% (13 of 18) |
|   chariot | 64% (9 of 14) | 57% (4 of 7) | 62% (13 of 21) |
|   infantry | 56% (30 of 54) | 80% (12 of 15) | 61% (42 of 69) |
|   monster | 25% (3 of 12) | - | 25% (3 of 12) |
|   war machine | 85% (33 of 39) | 100% (6 of 6) | 87% (39 of 45) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.0 (20%) | 0.0 (0%) | 3.0 (16%) |
| CHARGED: it charged | 0.3 (2%) | 0.3 (9%) | 0.7 (4%) |
| IN COMBAT: it fought this turn or the last | 1.0 (7%) | 0.3 (9%) | 1.3 (7%) |
| NO TARGET IN RANGE | 3.3 (23%) | 2.3 (64%) | 5.7 (31%) |
| ONLY IN COMBAT: the only targets were in combat | 1.3 (9%) | 0.0 (0%) | 1.3 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 4.0 (27%) | 0.7 (18%) | 4.7 (25%) |
| SHELTERED: the target was sheltered | 0.7 (5%) | 0.0 (0%) | 0.7 (4%) |
| OTHER BAR | 1.0 (7%) | 0.0 (0%) | 1.0 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| character | 5.0 | 1.3 | 73% | 6.3 pts | 31 pts |
| chariot | 4.3 | 2.0 | 69% | 7.2 pts | 31 pts |
| infantry | 18.0 | 8.7 | 65% | 11.1 pts | 199 pts |
| monster | 1.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 13.0 | 8.7 | 64% | 25.7 pts | 334 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.0 | 1.0 | 1.5 |
| Charges that made contact a game | 2.0 | 0.7 | 1.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.67 declared, 0.67 contact (3 units) | 0.00 declared, 0.00 contact (2 units) | 0.40 declared, 0.40 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.21 declared, 0.21 contact (19 units) | 0.13 declared, 0.09 contact (23 units) | 0.17 declared, 0.14 contact (42 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 60% (3 of 5) | - | - | 60% (3 of 5) |
| Character in a unit | 100% (6 of 6) | 100% (2 of 2) | - | 100% (8 of 8) |
| Character on its own | 100% (1 of 1) | 75% (3 of 4) | 75% (3 of 4) | 78% (7 of 9) |
| Chariot | 100% (3 of 3) | 100% (2 of 2) | - | 100% (5 of 5) |
| Infantry | 64% (9 of 14) | 75% (3 of 4) | - | 67% (12 of 18) |
| Monster | - | 50% (1 of 2) | - | 50% (1 of 2) |
| Monstrous | - | 100% (2 of 2) | - | 100% (2 of 2) |
| War Machines | 38% (3 of 8) | - | - | 38% (3 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 2 | 100% (1 of 1); on the table 100% | 50% (12 of 24) | 78% | 71% (17 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 38% (9 of 24) | 52% | 50% (5 of 10) | 100% (2 of 2); 5.0 uses a game | 100% (1 of 1); 1.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| High Elf Realms | 1 | 25% (1 of 4); on the table 50% | 0% (0 of 6) | 88% | 75% (6 of 8) | 100% (1 of 1); 5.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game |
| Skaven | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 78% | 89% (8 of 9) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 1 | 100% (1 of 1); on the table 100% | - | 72% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p6, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 17% (1) | 12% (1) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p6

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 80% (4 of 5) | 100% (2 of 2) |
| Strategy | Shoot objectives carried out (shot that target) | 26% (14 of 53) | 82% (14 of 17) |
| Strategy | Hexes on a unit its side charged or shot that turn | 50% (2 of 4) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 9) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 40% (2 of 5) | 20% (1 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.3 | 3.3 |
| Movement | Points that never moved of their own | 417.0 | 320.0 |
| Movement | Fights charged into per game | 2.0 | 0.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 5 | 0 of 2 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 5, net +0 | 0 of 2 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 5 | 0 of 2 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 5, net +0 | 2 of 2, net +278 |
| Shooting | Shots by shooting units (incl. breath weapons) | 16.0 | 9.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 62% (30 of 48) | 63% (17 of 27) |
| Shooting | Points destroyed by shooting units | 0.0 | 56.7 |
| Shooting | War machine shots | 11.0 | 2.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (15 of 33) | 0% (0 of 6) |
| Shooting | Points destroyed by war machines | 268.3 | 0.0 |
| Magic | Magic missiles cast | 4.0 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 50% (6 of 12) | - |
| Magic | Wounds caused by magic missiles | 7.3 | 1.0 |
| Magic | Wounds caused by other spells | 1.3 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 1.3 / 0.7 / 0.0 | 1.3 / 1.3 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 118.3 | 185.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +27 | +260 |
| Combat | Net per 100 charger points, damage counted | +9.6 | +91.2 |
| Combat | First round won (charged fights) | 50% | 100% |
| Combat | Net points per charged fight | +31 | +278 |
| Combat | Net points per supported fight / lone fight | - / +31 | - / +278 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 6 | 1 of 2 |
| Game | Points lost | 351.3 | 445.7 |
| Game | VP from objectives | 623.3 | 810.0 |
| Game | Lone holders (player turns) | 1.0 | 4.7 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -79 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 797
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: gs3-83c8646-p6

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH IN POINTS | - | - | - | - | 1.0 | +29.7 | 0.0 | 0.0 |
| ARMY TABLE | 26.0 | +262.8 | 0.0 | 288.0 | 19.7 | +338.4 | 0.0 | 358.3 |
| ARTILLERY RE-ROLL WEIGHED | 4.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.3 | +0.0 | 133.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 11.0 | +498.9 | 605.0 | 96.7 | 2.0 | +75.8 | 98.3 | 70.0 |
| CANNON SIGHT KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 23.3 |
| CAST JOB | 3.3 | +52.1 | 96.7 | 0.0 | 0.7 | +11.1 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | - | - | - | - | 1.0 | +0.0 | 0.0 | 266.7 |
| CHAFF IN THE MOVE | - | - | - | - | 0.7 | +18.7 | 0.0 | 0.0 |
| CHARACTER GUNS | 6.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 13.7 | -521.0 | 0.0 | 288.0 | 32.3 | -1957.3 | 0.0 | 503.3 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 143.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 3.3 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 48.3 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 88.3 | - | - | - | - |
| CONVEYANCE SEARCH | - | - | - | - | 1.0 | +171.7 | 266.7 | 266.7 |
| COVER ONCE | 9.7 | -641.0 | 0.0 | 185.0 | 4.0 | -123.3 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -0.2 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 8.7 | -63.5 | 0.0 | 0.0 | 7.0 | +37.9 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 0.3 | +1.2 | 0.0 | 0.0 |
| EXACT ROUND | 1.7 | +5.3 | 118.3 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 88.3 | 0.0 |
| FALLS SHORT | - | - | - | - | 31.7 | +209.5 | 0.0 | 331.7 |
| FEATURE BUFFS | 2.0 | +45.7 | 0.0 | 0.0 | 2.3 | +27.7 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +9.2 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 102.7 | +7952.4 | 1564.3 | 564.7 | 92.0 | +4866.4 | 453.3 | 1188.3 |
| FLANK NOT WEIGHED | 1.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | - | - | - | - | 0.7 | +78.1 | 0.0 | 0.0 |
| FOOT FIRST | - | - | - | - | 21.0 | +0.0 | 0.0 | 70.0 |
| FOUR ROUNDS | 2.0 | +148.2 | 118.3 | 0.0 | 1.0 | +106.4 | 143.3 | 0.0 |
| FREED FROM HIS FIGHT | 5.3 | +0.0 | 0.0 | 83.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -0.6 | 48.3 | 0.0 | - | - | - | - |
| GOAL ON TIME | - | - | - | - | 0.3 | +52.1 | 0.0 | 0.0 |
| GOAL WALK | 12.7 | +1750.2 | 0.0 | 176.7 | 12.7 | +1633.0 | 0.0 | 0.0 |
| GUN FIGURES | 1.3 | +0.0 | 0.0 | 88.3 | - | - | - | - |
| GUN MASK | 3.3 | +67.6 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 133.3 |
| HE REFORMS ONCE FREED | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 4.0 | +0.0 | 0.0 | 176.7 | 12.3 | +0.0 | 0.0 | 236.7 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +3.2 | 0.0 | 0.0 |
| HIS CHARGE LIST | 8.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 118.3 |
| HIS LEGAL MOVES | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.7 | -72.5 | 0.0 | 0.0 | 8.0 | -138.4 | 0.0 | 266.7 |
| HIS ONE QUARTER | 2.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 15.0 | +0.0 | 0.0 | 111.3 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.7 | +0.0 | 0.0 | 111.3 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 37.0 | +768.0 | 0.0 | 260.0 | 69.7 | +6275.7 | 0.0 | 716.7 |
| HIS SHOTS BY HIS RUN | 30.7 | +549.1 | 0.0 | 111.3 | 70.0 | +2501.7 | 0.0 | 781.7 |
| HIS TURN DENIED | - | - | - | - | 0.3 | +29.8 | 55.0 | 0.0 |
| HOLD ODDS | 21.3 | +0.0 | 0.0 | 0.0 | 30.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 13.3 | +1335.1 | 0.0 | 0.0 | 16.7 | +1423.4 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.0 | -77.4 | 118.3 | 0.0 | 1.0 | -21.4 | 143.3 | 0.0 |
| IDLE COST | - | - | - | - | 12.3 | -280.3 | 0.0 | 346.7 |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.7 | +11.3 | 0.0 | 0.0 | 0.7 | +40.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 0.3 | +0.0 | 0.0 | 88.3 | 1.7 | +0.0 | 41.7 | 0.0 |
| LONE WIZARD KEPT IN | 1.3 | +60.0 | 0.0 | 0.0 | 0.3 | +58.3 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | -7.0 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 2.0 | +9.8 | 118.3 | 0.0 | 1.0 | +0.1 | 143.3 | 0.0 |
| LOST CHARGE | 0.3 | -3.1 | 48.3 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | - | - | - | - | 0.3 | +14.6 | 0.0 | 133.3 |
| MANOEUVRE | 2.7 | -4.7 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 1.7 | +181.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 2.3 | +88.8 | 0.0 | 0.0 | 0.3 | +11.4 | 0.0 | 133.3 |
| MARCH OVER CASTS | 1.7 | +33.7 | 0.0 | 55.7 | - | - | - | - |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.0 | +56.2 | 0.0 | 0.0 | 0.3 | +5.6 | 0.0 | 133.3 |
| MEETS IN TIME | 4.3 | +509.9 | 0.0 | 0.0 | 3.3 | +324.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 11.0 | +169.2 | 0.0 | 0.0 | 2.7 | +50.1 | 0.0 | 133.3 |
| MISSILES NEXT TURN | 14.0 | +181.7 | 0.0 | 55.7 | 3.3 | +23.0 | 0.0 | 266.7 |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 21.7 | 21.7 |
| MOVE SPELL SPOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 266.7 |
| MOVE TO CHARGE COMPUTED | 3.3 | +232.9 | 0.0 | 0.0 | 4.0 | +473.1 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 13.7 | +659.0 | 0.0 | 0.0 | 9.0 | +401.6 | 0.0 | 0.0 |
| NEAREST TO GOAL | - | - | - | - | 4.3 | +0.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 1.7 | +130.5 | 0.0 | 0.0 | 3.3 | +391.9 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.7 | -5.5 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.0 | -71.7 | 118.3 | 0.0 | 1.0 | -94.5 | 143.3 | 0.0 |
| NO LATE CUT | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 5.0 | -172.4 | 48.3 | 55.0 | 1.7 | -81.3 | 0.0 | 23.3 |
| OGRE LOADER SECOND SHOT | 3.3 | +21.1 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.3 | -110.0 | 0.0 | 0.0 | 4.0 | -52.6 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 1.0 | +25.8 | 0.0 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 7.0 | +94.5 | 0.0 | 0.0 | 8.7 | +102.4 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.3 | -14.4 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.3 | +0.4 | 0.0 | 0.0 | 0.3 | +5.8 | 0.0 | 0.0 |
| PERIAPT WORTH | - | - | - | - | 0.3 | +21.1 | 0.0 | 0.0 |
| PLAN RESULT | 45.0 | +967.5 | 795.3 | 530.3 | 43.0 | +331.5 | 83.3 | 764.0 |
| PROMISE BY ITS OWN SUM | 7.3 | -193.9 | 0.0 | 0.0 | 4.3 | -33.8 | 0.0 | 0.0 |
| QUARTER ODDS | 19.0 | +2181.2 | 336.0 | 111.3 | 15.7 | +1774.0 | 115.0 | 186.7 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.3 | +148.2 | 0.0 | 333.3 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 0.3 | +47.5 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.3 | -34.9 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.0 | -1.4 | 48.3 | 0.0 | 1.0 | -33.5 | 143.3 | 0.0 |
| ROUNDS AFTER TERROR | 1.0 | -30.8 | 0.0 | 0.0 | - | - | - | - |
| RUN DOWN | 1.7 | -29.5 | 48.3 | 0.0 | 0.7 | -19.5 | 55.0 | 0.0 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.7 | -95.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +14.7 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +7.1 | 48.3 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 1.3 | -34.1 | 0.0 | 0.0 | 0.3 | -16.6 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.7 | +52.1 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.7 | +15.9 | 0.0 | 133.3 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 16.7 | +0.0 | 0.0 | 96.7 | 6.3 | +0.0 | 0.0 | 203.3 |
| SHOOTS FROM THE BEST SPOT | 3.7 | +66.1 | 0.0 | 0.0 | 2.0 | +55.5 | 113.3 | 0.0 |
| SHOT OR CHARGE | 0.3 | -27.3 | 70.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 12.3 | -215.4 | 0.0 | 111.3 | 47.7 | -706.2 | 0.0 | 711.7 |
| SHOTS AFTER THE MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 29.0 | +1125.2 | 0.0 | 185.0 | 10.7 | +296.4 | 0.0 | 336.7 |
| SPELL WORTH | - | - | - | - | 3.3 | +89.3 | 266.7 | 266.7 |
| SPELLS IN THE FIGHT | 0.7 | +4.6 | 118.3 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 6.3 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 315.7 |
| STAND AND SHOOT | - | - | - | - | 0.7 | -9.4 | 88.3 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 3.7 | +0.0 | 0.0 | 266.7 |
| STANDS STILL | 51.3 | +0.0 | 1446.0 | 276.7 | 36.0 | +0.0 | 310.0 | 611.7 |
| STAY WORTH | 44.3 | +261.6 | 1376.0 | 290.0 | 14.7 | +226.6 | 196.7 | 743.3 |
| STUBBORN BY POINTS | 0.3 | +5.3 | 0.0 | 55.0 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 48.3 |
| SUPPORT ADDS | 2.3 | +41.1 | 0.0 | 0.0 | 2.7 | +175.2 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 2.3 | +41.1 | 0.0 | 0.0 | 2.7 | +175.2 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 133.3 |
| THE ROW KEEPS ITS WAY | 2.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 47.7 | +0.0 | 0.0 | 240.7 | 44.0 | +0.0 | 0.0 | 416.7 |
| TIED UP BY THE SUM | 0.3 | +37.0 | 48.3 | 0.0 | 0.3 | +66.6 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 35.7 | +572.7 | 0.0 | 103.3 | - | - | - | - |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | 0.3 | -3.5 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 2.0 | +0.0 | 74.7 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.7 | -6.1 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 3.3 | -269.5 | 0.0 | 176.7 | 1.7 | -145.7 | 0.0 | 70.0 |
| WOUNDS ON THE RANKS | 3.3 | +104.4 | 0.0 | 111.3 | 2.7 | +180.7 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p6

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 137 | 137 | 92 | 30.67 | +1510 | +16.4 |
| HOLDER ASSIGNMENT | 90 | 90 | 85 | 28.33 | +6063 | +71.3 |
| HIS SHOTS BY HIS RUN | 302 | 296 | 75 | 25.00 | +1628 | +21.7 |
| HIS SHOT LIST | 320 | 312 | 74 | 24.67 | +3196 | +43.2 |
| SHOT RISK POINTS | 180 | 178 | 39 | 13.00 | +2983 | +76.5 |
| DEPLOY BY FIGURES | 47 | 47 | 33 | 11.00 | +783 | +23.7 |
| GOAL WALK | 76 | 74 | 28 | 9.33 | +3683 | +131.5 |
| OFF BEST | 20 | 20 | 20 | 6.67 | -761 | -38.0 |
| THE TABLE AGAIN | 36 | 36 | 19 | 6.33 | +0 | +0.0 |
| CHARGE LOSSES | 138 | 136 | 16 | 5.33 | +1572 | +98.2 |
| ARTILLERY RE-ROLL WEIGHED | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| MEETS IN TIME | 23 | 23 | 11 | 3.67 | +1042 | +94.7 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 35 | 35 | 11 | 3.67 | -683 | -62.1 |
| RANDOM MOVE BY FIGURES | 13 | 13 | 11 | 3.67 | +444 | +40.4 |
| CAST JOB | 12 | 12 | 10 | 3.33 | +77 | +7.7 |
| MOVE TO CHARGE COMPUTED | 22 | 22 | 10 | 3.33 | +347 | +34.7 |
| OGRE LOADER SECOND SHOT | 10 | 10 | 10 | 3.33 | +63 | +6.3 |
| STAY WORTH | 177 | 158 | 10 | 3.33 | +105 | +10.5 |
| TIME ON OUR SIDE | 107 | 91 | 10 | 3.33 | +40 | +4.0 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| FIVE ACTION | 584 | 574 | 9 | 3.00 | +119 | +13.2 |
| SHOOTS FROM THE BEST SPOT | 17 | 17 | 9 | 3.00 | +121 | +13.5 |
| CANNON PLANNED TARGET | 39 | 39 | 7 | 2.33 | +160 | +22.8 |
| HARD STAY DROPPED | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| MARCH CHECK | 8 | 8 | 7 | 2.33 | +83 | +11.9 |
| NEXT CHARGE BY LIST | 15 | 15 | 7 | 2.33 | +217 | +31.0 |
| THE ROW IN ITS ORDER | 26 | 7 | 7 | 2.33 | +0 | +0.0 |
| FALLS SHORT | 95 | 79 | 6 | 2.00 | +18 | +3.0 |
| IDLE COST | 37 | 31 | 6 | 2.00 | +77 | +12.8 |
| LEGAL CHARGES ONLY | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| QUARTER ODDS | 104 | 104 | 6 | 2.00 | +371 | +61.8 |
| SHOTS AFTER THE MOVES | 23 | 23 | 6 | 2.00 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 5 | 5 | 5 | 1.67 | +355 | +71.0 |
| MARCH BY THE SUM | 5 | 5 | 5 | 1.67 | +543 | +108.6 |
| CASTER AWAY FROM SCREEN | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| FOUR ROUNDS | 9 | 8 | 4 | 1.33 | +131 | +32.7 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +154 | +38.5 |
| ONE OBJECTIVE FORMULA | 47 | 35 | 4 | 1.33 | +484 | +120.9 |
| SUPPORT ADDS | 15 | 15 | 4 | 1.33 | +70 | +17.5 |
| SUPPORT WORKED OUT | 15 | 15 | 4 | 1.33 | +70 | +17.5 |
| WOUNDS ON THE RANKS | 18 | 18 | 4 | 1.33 | +101 | +25.4 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 1.00 | +89 | +29.7 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SET UP BY THE SET | 7 | 7 | 3 | 1.00 | +69 | +23.2 |
| SHOTS IN THE MOVE | 119 | 87 | 3 | 1.00 | +61 | +20.4 |
| CHAFF IN THE MOVE | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| COVER ONCE | 41 | 30 | 2 | 0.67 | +94 | +46.9 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +234 | +117.2 |
| MAX FOR POSITIONING | 13 | 13 | 2 | 0.67 | +2 | +0.8 |
| NEARER NOT NEEDED | 68 | 62 | 2 | 0.67 | +48 | +24.2 |
| ONE FIGHT FORMULA | 28 | 16 | 2 | 0.67 | +34 | +16.9 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| WAR ENGINE JOBS | 6 | 6 | 2 | 0.67 | -71 | -35.7 |
| WHOLE FIGHT DANGER | 15 | 15 | 2 | 0.67 | +351 | +175.6 |
| ADVANCE LANE KEPT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FEATURE BUFFS | 13 | 13 | 1 | 0.33 | +5 | +4.9 |
| GOAL ON TIME | 1 | 1 | 1 | 0.33 | -50 | -50.0 |
| GUN MASK | 10 | 10 | 1 | 0.33 | +4 | +4.2 |
| HIS CHARGE DENIED | 1 | 1 | 1 | 0.33 | +8 | +7.6 |
| MANOEUVRE | 14 | 14 | 1 | 0.33 | +7 | +6.9 |
| MISSILES IN THE MOVE | 41 | 33 | 1 | 0.33 | +3 | +2.6 |
| MISSILES NEXT TURN | 52 | 37 | 1 | 0.33 | +0 | +0.0 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -43 | -43.1 |
| OVERRUNS AWAY | 2 | 2 | 1 | 0.33 | +8 | +7.6 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +63 | +63.3 |
| REDIRECT FOR A FRIEND IN REACH | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +44 | +44.1 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +21 | +21.4 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +16 | +16.0 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| TIED UP BY THE SUM | 2 | 1 | 1 | 0.33 | +8 | +7.6 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -11 | -10.6 |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CHARACTER GUNS | 30 | 30 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 4 | 4 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 32 | 32 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| EVASIVE BY THE ODDS | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 5 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 5 | 5 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 15 | not checked | - | - | - | - |
| FOOT FIRST | 63 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 18 | 18 | 0 | 0.00 | - | - |
| GIVES UP | 1 | not checked | - | - | - | - |
| GUN FIGURES | 4 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 10 | 10 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 49 | 49 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 34 | 31 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 7 | 7 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 32 | 32 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 17 | 17 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 9 | 9 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 45 | 41 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 8 | 8 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HOLD ODDS | 156 | 156 | 0 | 0.00 | - | - |
| HONEST WORTH | 9 | 8 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 14 | 14 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 9 | 8 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | not checked | - | - | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 8 | 8 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 3 | not checked | - | - | - | - |
| NEAREST TO GOAL | 13 | 13 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 9 | 8 | 0 | 0.00 | - | - |
| NO LATE CUT | 8 | 8 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 3 | 3 | 0 | 0.00 | - | - |
| ONE ROUTE | 8 | 8 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 264 | trace | - | - | - | - |
| REAL GROUND | 8 | 8 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 4 | 4 | 0 | 0.00 | - | - |
| RISK BY ARC | 6 | 5 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 7 | 6 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 5 | 5 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 5 | 5 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 69 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 10 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 39 | 33 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 11 | 11 | 0 | 0.00 | - | - |
| STANDS STILL | 262 | 259 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 21 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 13 | not checked | - | - | - | - |
| THE TABLE BINDS | 275 | not checked | - | - | - | - |
| WAITS AGAIN | 12 | 11 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p6

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.33 | 1.67 | 38.1 |
| ARMY TABLE | rule | 2.00 | 1.67 | 29.9 |
| PROMISE BY ITS OWN SUM | rule | 3.00 | 0.67 | 62.1 |
| HOLDER ASSIGNMENT | rule | 1.00 | 1.00 | 20.1 |
| RULE SWITCHED OFF | gate | 0.67 | - | 37.4 |
| WAR ENGINE JOBS | rule | 0.67 | - | 35.7 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 2.3 |
| GOAL ON TIME | rule | - | 0.33 | 50.0 |
| ONE PROMISE A TARGET | rule | 0.33 | - | 43.1 |
| WALKS ON ITS ROUTE | rule | 0.33 | - | 10.6 |

### Plans: gs3-83c8646-p6

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 33% | 92 | 64 | 69% |
| Mine | join | 0.7 | 100% | 9 | 0 | 0% |
| Mine | move | 29.3 | 97% | 2071 | 0 | 0% |
| Mine | shoot | 14.0 | 67% | 984 | 904 | 92% |
| Opponent | charge | 1.0 | 67% | 237 | 143 | 61% |
| Opponent | move | 36.3 | 94% | 2153 | 0 | 0% |
| Opponent | shoot | 5.0 | 67% | 269 | 188 | 70% |
| Opponent | support | 0.7 | 100% | 0 | 0 | - |

### Battle groups: gs3-83c8646-p6

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 0.3 | 100% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p6

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 10 | 22 (10) | 22 | 0 | 3 | 30% | 3.7 | 36 (5) | 0 (5) | - | 0 (6) | 63 (4) |
| Mine | Clean-up | 3 | 11 (3) | 0 | 11 | 0 | 100% | - | 0 (1) | 17 (2) | - | 11 (3) | - |
| Mine | Fast Hammer | 3 | 13 (3) | 0 | 13 | 71 | 0% | 2.0 | 18 (2) | - | 0 (1) | 13 (3) | - |
| Mine | Hammer | 6 | 0 (6) | 0 | 0 | 19 | 33% | 2.0 | 0 (2) | 0 (4) | - | 0 (5) | 0 (1) |
| Mine | Shooter | 6 | 120 (6) | 0 | 120 | 0 | 0% | 1.7 | 0 (1) | 212 (3) | 43 (2) | 120 (6) | - |
| Mine | War machine | 8 | 75 (8) | 75 | 0 | 38 | 0% | 1.6 | 144 (3) | 0 (3) | 80 (2) | 0 (1) | 84 (7) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 50% | 3.5 | 0 (1) | 0 (3) | - | 0 (3) | 0 (1) |
| Opponent | Chaff | 2 | 288 (2) | 0 | 288 | 44 | 100% | - | 514 (1) | 0 (1) | - | 514 (1) | 0 (1) |
| Opponent | Character | 9 | 15 (9) | 15 | 0 | 15 | 56% | 2.0 | 0 (1) | 21 (7) | 0 (1) | 0 (5) | 33 (4) |
| Opponent | Clean-up | 3 | 122 (3) | 0 | 122 | 0 | 67% | 4.0 | 0 (1) | 221 (2) | - | 221 (2) | 0 (1) |
| Opponent | Fast Hammer | 6 | 43 (6) | 0 | 43 | 0 | 83% | 1.0 | - | 50 (4) | 31 (2) | 43 (6) | - |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Hammer | 4 | 25 (4) | 25 | 0 | 74 | 25% | 3.3 | - | 47 (2) | 0 (2) | 25 (4) | - |
| Opponent | Holder | 4 | 42 (4) | 42 | 0 | 28 | 50% | 5.5 | - | 52 (3) | 0 (1) | 96 (2) | 0 (2) |
| Opponent | Shooter | 4 | 0 (4) | 0 | 0 | 28 | 50% | 1.0 | 0 (1) | 0 (1) | 0 (2) | 0 (3) | 0 (1) |
| Opponent | War machine | 2 | 121 (2) | 121 | 0 | 100 | 0% | 1.0 | - | - | 121 (2) | 243 (1) | 0 (1) |

### Charged fights: gs3-83c8646-p6

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 270 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 0 of 4 | 1 of 4 | - | +0 |
| Mine | Grand Cathay | 1 | 265 | 355 | 2.0 | 1.0 | 178 | 84 | +94 | 1 of 2 | 2 of 2 | - | +94 |
| **Mine** | all armies | 3 | 268 | 118 | 2.0 | 1.0 | 59 | 28 | +31 | 1 of 6 | 3 of 6 | - | +31 |
| Opponent | High Elf Realms | 1 | 170 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Skaven | 1 | 0 | 165 | 1.0 | 1.0 | 165 | 0 | +165 | 0 of 1 | 1 of 1 | - | +165 |
| Opponent | Warriors of Chaos | 1 | 0 | 390 | 1.0 | 1.0 | 390 | 0 | +390 | 1 of 1 | 1 of 1 | - | +390 |
| **Opponent** | all armies | 3 | 57 | 185 | 0.7 | 1.0 | 278 | 0 | +278 | 1 of 2 | 2 of 2 | - | +278 |

### Effective charges: gs3-83c8646-p6

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 4 | 0 | 2 (net +0) | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 25% (1 of 4) |
| Mine | Grand Cathay | 2 | 0 | 0 | 0 | 1 (net +43) | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +165) | 0 | 0% (0 of 1) |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +390) | 0 | 0% (0 of 1) |

### Charged fights, damage counted: gs3-83c8646-p6

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 50-54% | 2 | 265 | 230 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 1 | 265 | 230 | +0 | 28 | 0 | +28 | +10.4 |
| Mine | 76-89% | 1 | 334 | 210 | +43 | 210 | 167 | +43 | +12.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 227 | 80 | +0 | 40 | 13 | +27 | +12.1 |
| Mine | No odds | 1 | 334 | 145 | +145 | 145 | 81 | +64 | +19.2 |
| Mine | All fights | 6 | 282 | 188 | +31 | 70 | 43 | +27 | +9.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 286 | 215 | +278 | 340 | 80 | +260 | +91.2 |
| Opponent | All fights | 2 | 286 | 215 | +278 | 340 | 80 | +260 | +91.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p6 | move | 10 | 2 (20%) | 2 (20%) | 0 (0%) | 8 (80%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Periapt of Soul Exchange | Opponent | L1021 |
| Ring of Jet | Mine | L1021 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Opponent | L1021 |
| Twice-Blessed Armour | Mine | L1021 |

# Doctrine scorecard: gs3-83c8646-p58

### Scorecard: gs3-83c8646-p58

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1823 | 5 | 1 | Mine | no | - | 5 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 7 | 3 | 0 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Mine | no | 1 | 1 | 7 | 0 | 1 | 0 | 0 | 255 |
| L1923 | 3 | 1 | Opponent | yes | 10 | 2 | 1 | 1 | 0 | 0 | 0 | 72 |
| L2025 | 3 | 1 | Mine | yes | 6 | - | 0 | 1 | 1 | 0 | 0 | 210 |
| L2025 | 3 | 1 | Opponent | no | 6 | 3 | 5 | 1 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 3.5 | 3.0 | 3.3 | 0.7 | 1.0 | 0.0 | 0.0 | 155.0 |
| **Average** | | | Opponent | 67% | 8.0 | 2.3 | 4.3 | 1.7 | 0.3 | 0.0 | 0.0 | 24.0 |

### KPIs: gs3-83c8646-p58

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 12) | 0% (0 of 15) | 0% (0 of 27) |
| Winner chose to follow up after the loser gave ground |  | 100% (3 of 3); on the table 100% | 100% (3 of 3); on the table 100% | 100% (6 of 6); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 71% (5 of 7); on the table 71% | 71% (5 of 7); on the table 71% |
| Winner chose to follow up or pursue (all three) |  | 100% (3 of 3); on the table 100% | 82% (9 of 11); on the table 82% | 86% (12 of 14); on the table 86% |
| Magic missiles tried each own turn | 50%+ | 20% (6 of 30) | 17% (3 of 18) | 19% (9 of 48) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 35% (6 of 17) | 20% (3 of 15) | 28% (9 of 32) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (8 of 12) | - | 67% (8 of 12) |
| Points that never fought | lower | 24% (1439 of 5999) | 33% (1974 of 5999) | 28% (3413 of 11998) |
|   infantry points that never fought | lower | 64% (631 of 993) | 56% (577 of 1037) | 60% (1208 of 2030) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 55% (12 of 22) | 56% (9 of 16) | 55% (21 of 38) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (1 of 2); 0.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 57% (2943 of 5151) | 47% (2134 of 4500) | 53% (5077 of 9651) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (8%) | 3.7 (73%) | 4.3 (33%) |
| MARCHED: its unit marched | 1.0 (12%) | 0.0 (0%) | 1.0 (8%) |
| CHARGED: its unit charged | 0.7 (8%) | 0.0 (0%) | 0.7 (5%) |
| IN COMBAT: engaged in combat | 2.3 (29%) | 0.0 (0%) | 2.3 (18%) |
| REAR RANK: in a rear rank | 1.0 (12%) | 0.0 (0%) | 1.0 (8%) |
| GONE: slain | 2.0 (25%) | 1.0 (20%) | 3.0 (23%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (7%) | 0.3 (3%) |
| NOT OFFERED: not in the cast list | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 1.3 | 1.0 | 3.0 | 2.3 |
| not cast | 5.7 | 0.7 | 5.0 | 13.0 | 17.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (100%) | 0.0 (0%) | 4.3 (33%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (8%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (5%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (18%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 1.3 (24%) | 0.0 (0%) | 1.3 (27%) | 1.0 (8%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| GONE: slain | 2.0 (35%) | 0.0 (0%) | 1.7 (33%) | 3.0 (23%) | 7.0 (40%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (41%) | 0.0 (0%) | 2.0 (40%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 9.3 (53%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.0 a game | 0.5 a game |
| stood (cast and not dispelled) | - | 67% (2 of 3) | 67% (2 of 3) |
| the unit moved after it | - | 100% (2 of 2) | 100% (2 of 2) |
| it charged on its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| the enemy charged it first | - | 0% (0 of 2) | 0% (0 of 2) |
| it fought by the end of its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 2) | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (2 of 2) | 100% (2 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 47% (28 of 59) | 69% (50 of 72) | 60% (78 of 131) |
|   cavalry | - | 94% (15 of 16) | 94% (15 of 16) |
|   character | 83% (5 of 6) | 0% (0 of 14) | 25% (5 of 20) |
|   chariot | 44% (4 of 9) | - | 44% (4 of 9) |
|   infantry | 31% (10 of 32) | 83% (35 of 42) | 61% (45 of 74) |
|   monster | 75% (9 of 12) | - | 75% (9 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.3 (13%) | 0.0 (0%) | 1.3 (8%) |
| CHARGED: it charged | 0.3 (3%) | 1.7 (23%) | 2.0 (11%) |
| FLEEING: it fled or was fleeing | 0.7 (6%) | 0.0 (0%) | 0.7 (4%) |
| IN COMBAT: it fought this turn or the last | 0.3 (3%) | 0.3 (5%) | 0.7 (4%) |
| NO TARGET IN RANGE | 3.7 (35%) | 3.3 (45%) | 7.0 (40%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 1.3 (18%) | 1.7 (9%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.3 (23%) | 0.7 (9%) | 3.0 (17%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR | 1.0 (10%) | 0.0 (0%) | 1.0 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.7 | 1.7 | 76% | 3.5 pts | 20 pts |
| character | 1.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 1.3 | 0.7 | 75% | 16.2 pts | 22 pts |
| infantry | 17.7 | 7.0 | 70% | 5.5 pts | 98 pts |
| monster | 3.0 | 0.3 | 89% | 5.4 pts | 16 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.0 | 6.7 | 5.3 |
| Charges that made contact a game | 2.7 | 6.0 | 4.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 2.00 declared, 2.00 contact (1 units) | 2.00 declared, 2.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.43 declared, 0.29 contact (28 units) | 0.60 declared, 0.53 contact (30 units) | 0.52 declared, 0.41 contact (58 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | - | 67% (2 of 3) | - | 67% (2 of 3) |
| Character in a unit | 50% (1 of 2) | 0% (0 of 1) | - | 33% (1 of 3) |
| Character on its own | 33% (1 of 3) | 100% (3 of 3) | 29% (2 of 7) | 46% (6 of 13) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 50% (3 of 6) | - | - | 50% (3 of 6) |
| Monster | 50% (2 of 4) | 67% (2 of 3) | - | 57% (4 of 7) |
| Monstrous | - | 75% (3 of 4) | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 19% | 100% (7 of 7) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (1 of 1); on the table 100% | 8% (1 of 12) | 12% | 25% (2 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 100% (2 of 2); on the table 100% | 42% (5 of 12) | 41% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 2 | 88% (7 of 8); on the table 88% | 0% (0 of 6) | 39% | 40% (4 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 67% (2 of 3); on the table 67% | 25% (3 of 12) | 20% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p58, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 36% (5) | 50% (2) | 39% (7) |
| ...free all their last turn and able to turn (per game) | 1.67 | 0.00 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 1.00 | 0.00 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p58

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.7 | 2.3 |
| Strategy | Charge objectives carried out (made contact) | 100% (2 of 2) | 81% (13 of 16) |
| Strategy | Shoot objectives carried out (shot that target) | 8% (1 of 13) | 61% (11 of 18) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (2 of 2) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 50% (1 of 2) | - |
| Strategy | Joined characters whose unit fought | 67% (2 of 3) | 50% (1 of 2) |
| Strategy | Lone characters that fought | 100% (7 of 7) | 78% (7 of 9) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.7 | 1.7 |
| Movement | Points that never moved of their own | 155.0 | 24.0 |
| Movement | Fights charged into per game | 2.7 | 5.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 2 | 2 of 12, net +270 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | 0 of 12 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 2 | 1 of 12, net -68 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 2 | 6 of 12, net +271 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.7 | 19.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 52% (15 of 29) | 19% (11 of 59) |
| Shooting | Points destroyed by shooting units | 15.0 | 43.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.0 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 67% (2 of 3) | 0% (0 of 1) |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.7 / 0.0 / 1.3 / 0.0 | 1.3 / 0.0 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 574.7 | 737.3 |
| Combat | Points run down | 0.0 | 272.3 |
| Combat | Net points per charged fight, damage counted | +47 | +163 |
| Combat | Net per 100 charger points, damage counted | +25.0 | +56.7 |
| Combat | First round won (charged fights) | 38% | 80% |
| Combat | Net points per charged fight | +54 | +165 |
| Combat | Net points per supported fight / lone fight | - / +54 | +42 / +184 |
| Combat | Charged fights on a top-3 enemy unit | 4 of 8 | 7 of 15 |
| Game | Points lost | 1118.3 | 674.3 |
| Game | VP from objectives | 523.3 | 913.3 |
| Game | Lone holders (player turns) | 3.5 | 8.0 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -1041 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1793
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: gs3-83c8646-p58

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +3.8 | 0.0 | 0.0 |
| ARMY TABLE | 23.3 | +498.6 | 0.0 | 655.0 | 22.0 | -102.8 | 0.0 | 375.0 |
| ASSAILMENT BY POINTS | 1.0 | +2.5 | 0.0 | 180.0 | 0.3 | +0.5 | 0.0 | 70.3 |
| BACKUP TARGETS | 0.3 | +2.5 | 0.0 | 11.3 | 0.3 | +1.0 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.3 | -30.9 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.7 | +33.9 | 0.0 | 88.3 |
| CAST JOB | 2.3 | +16.8 | 0.0 | 360.0 | 0.3 | +1.6 | 180.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 1.0 | +9.0 | 22.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | - | - | - | - | 0.7 | +0.0 | 0.0 | 70.3 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.3 | +0.6 | 0.0 | 0.0 | 0.3 | +4.8 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | -0.5 | 0.0 | 0.0 | 0.7 | -2.7 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +7.9 | 0.0 | 65.7 | 0.7 | +4.3 | 0.0 | 0.0 |
| CHARGE LOSSES | 13.7 | -412.6 | 0.0 | 436.7 | 9.3 | -493.3 | 0.0 | 65.0 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 605.0 | 162.3 |
| CLOSES ON WHAT IT BEATS | 7.0 | +0.0 | 0.0 | 303.0 | 17.7 | +0.0 | 0.0 | 275.7 |
| CONVEYANCE SEARCH | - | - | - | - | 0.7 | +72.5 | 70.3 | 70.3 |
| COVER ONCE | 9.7 | -326.0 | 0.0 | 281.7 | 2.3 | -75.7 | 0.0 | 20.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -1.2 | 100.3 | 0.0 |
| DEPLOY BY FIGURES | 7.7 | +43.1 | 0.0 | 0.0 | 7.3 | +33.6 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.7 | -243.8 | 65.7 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +3.6 | 85.0 | 0.0 |
| EXACT ROUND | 0.3 | -3.9 | 0.0 | 0.0 | 4.7 | +9.1 | 701.3 | 126.7 |
| FALL BACK GOOD ORDER | - | - | - | - | 5.7 | +8.6 | 668.7 | 185.0 |
| FALLS SHORT | 3.7 | +26.1 | 0.0 | 85.0 | 13.3 | +116.7 | 0.0 | 240.3 |
| FEATURE BUFFS | 2.0 | +16.0 | 0.0 | 0.0 | 1.7 | +11.8 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 3.0 | +163.1 | 266.3 | 153.3 |
| FIRE IN ORDER | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 74.0 | +5010.0 | 44.0 | 1860.7 | 94.3 | +7098.8 | 1529.3 | 1157.0 |
| FLANK NOT WEIGHED | 12.3 | +0.0 | 0.0 | 459.3 | 2.7 | +0.0 | 0.0 | 90.0 |
| FOLLOW UP WEIGHED | 0.7 | +52.9 | 0.0 | 0.0 | 1.3 | +185.7 | 0.0 | 0.0 |
| FOOT FIRST | 1.7 | +0.0 | 0.0 | 121.7 | - | - | - | - |
| FOUR ROUNDS | 0.7 | +12.0 | 22.0 | 0.0 | 6.7 | +779.6 | 767.0 | 208.3 |
| FREED FROM HIS FIGHT | 14.0 | +0.0 | 0.0 | 416.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 1.3 | -9.4 | 0.0 | 45.3 | 0.7 | -3.2 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 1.3 | -24.8 | 0.0 | 23.3 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.3 | -0.9 | 21.7 | 15.0 |
| GOAL WALK | 12.0 | +922.4 | 0.0 | 424.3 | 6.0 | +359.8 | 0.0 | 75.0 |
| GUN FIGURES | 3.3 | +25.4 | 117.0 | 83.3 | - | - | - | - |
| HARD STAY DROPPED | 2.7 | +0.0 | 0.0 | 241.7 | 3.3 | +0.0 | 0.0 | 70.3 |
| HE REFORMS ONCE FREED | 7.3 | +0.0 | 0.0 | 115.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 12.0 | +0.0 | 0.0 | 436.7 | 1.7 | +0.0 | 0.0 | 65.0 |
| HIS CHARGE DENIED | 0.3 | +3.5 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 4.3 | +0.0 | 0.0 | 61.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.0 | +0.0 | 0.0 | 84.3 | 3.7 | +0.0 | 0.0 | 98.0 |
| HIS MOVE AND SHOT | 1.7 | -7.1 | 0.0 | 246.7 | 5.3 | -56.8 | 0.0 | 30.0 |
| HIS ONE QUARTER | 3.7 | +0.0 | 0.0 | 324.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 5.3 | +0.0 | 0.0 | 107.0 | 7.3 | +0.0 | 0.0 | 163.0 |
| HIS RANDOM MOVE | - | - | - | - | 11.0 | +0.0 | 0.0 | 523.0 |
| HIS RANDOM MOVER COMES | - | - | - | - | 3.7 | +0.0 | 0.0 | 25.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 34.7 | +441.6 | 0.0 | 1103.7 | 36.3 | +1104.9 | 0.0 | 365.3 |
| HIS SHOTS BY HIS RUN | 36.0 | +227.7 | 0.0 | 907.3 | 34.3 | +400.0 | 0.0 | 314.0 |
| HIS TURN DENIED | 0.3 | +0.7 | 22.0 | 0.0 | 1.3 | +26.7 | 122.0 | 15.0 |
| HOLD ODDS | 15.0 | +0.0 | 0.0 | 0.0 | 15.7 | +0.0 | 0.0 | 234.0 |
| HOLDER ASSIGNMENT | 8.3 | +611.0 | 0.0 | 0.0 | 9.3 | +776.6 | 0.0 | 128.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.3 | -1.2 | 22.0 | 0.0 | 5.3 | -159.1 | 767.0 | 145.7 |
| HUNT IN PAIRS | - | - | - | - | 1.7 | +44.2 | 0.0 | 88.3 |
| IDLE COST | 1.0 | -9.4 | 0.0 | 36.7 | 10.3 | -126.0 | 0.0 | 239.7 |
| JOINT CHARGE NOW | - | - | - | - | 1.7 | -61.3 | 0.0 | 127.7 |
| KEPT FROM ITS LAST STOP | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +6.3 | 0.0 | 0.0 | 1.7 | +89.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 6.0 | +0.0 | 667.7 | 646.3 | 10.0 | +0.0 | 626.3 | 914.3 |
| LONE WIZARD KEPT IN | 0.3 | +16.1 | 0.0 | 0.0 | 0.7 | +39.2 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +1.8 | 0.0 | 0.0 | 0.3 | +2.3 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | - | - | - | - | 5.0 | +6.1 | 286.0 | 185.0 |
| LOST CHARGE | - | - | - | - | 0.3 | -1.2 | 85.0 | 0.0 |
| MAKE SURE TOGETHER | 0.7 | +9.6 | 0.0 | 0.0 | 0.3 | +5.2 | 0.0 | 15.0 |
| MANOEUVRE | 1.7 | -1.5 | 0.0 | 0.0 | 1.3 | -6.7 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.7 | +68.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.7 | +28.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | +3.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.7 | +31.9 | 0.0 | 22.7 | 2.7 | +91.1 | 0.0 | 105.0 |
| MEETS IN TIME | 3.7 | +210.7 | 0.0 | 0.0 | 2.3 | +191.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.0 | +53.0 | 0.0 | 295.7 | 1.3 | +6.4 | 0.0 | 140.7 |
| MISSILES NEXT TURN | 4.3 | +60.5 | 0.0 | 295.7 | 2.7 | +8.6 | 0.0 | 140.7 |
| MOVE ORDER | 1.3 | +0.0 | 115.7 | 0.0 | 2.3 | +0.0 | 25.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 4.0 | +162.3 | 0.0 | 107.0 | 7.7 | +1086.8 | 0.0 | 332.3 |
| MOVES UNITS SPELL | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 5.3 | +222.7 | 0.0 | 0.0 | 10.7 | +372.8 | 0.0 | 168.7 |
| NEAREST TO GOAL | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 2.3 | +86.9 | 0.0 | 95.7 | 4.3 | +680.0 | 0.0 | 198.7 |
| NO DOUBLE ROUNDS | 0.7 | -15.1 | 22.0 | 0.0 | 5.3 | -352.3 | 767.0 | 175.0 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 5.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 2.0 | -0.9 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 1.7 | -75.9 | 0.0 | 30.0 | 4.3 | -70.1 | 0.0 | 90.3 |
| ONE CHECK AFTER THE LAST CHANGE | 1.0 | +0.0 | 0.0 | 100.3 | - | - | - | - |
| ONE FIGHT FORMULA | 2.3 | -32.4 | 0.0 | 22.7 | 5.3 | -132.9 | 0.0 | 219.0 |
| ONE JOINT FIGURE | - | - | - | - | 2.0 | +289.3 | 0.0 | 127.7 |
| ONE OBJECTIVE FORMULA | 4.3 | +74.3 | 0.0 | 0.0 | 4.3 | -54.2 | 0.0 | 86.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +9.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.3 | +1.9 | 0.0 | 0.0 | 1.7 | +16.1 | 216.0 | 49.0 |
| PERIAPT WORTH | 0.3 | +18.1 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -4.7 | 0.0 | 0.0 |
| PLAN RESULT | 36.0 | +32.7 | 44.0 | 1541.0 | 45.7 | +821.6 | 610.3 | 1011.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 6.0 | -217.7 | 0.0 | 0.0 | 9.7 | -373.7 | 0.0 | 49.0 |
| PROMISE KNOWS THE FIGHT | 0.7 | -3.6 | 0.0 | 61.7 | 0.7 | -2.3 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -2.4 | 0.0 | 11.3 | - | - | - | - |
| PURSUES BIG PREY | - | - | - | - | 0.3 | -8.3 | 0.0 | 0.0 |
| QUARTER ODDS | 18.3 | +2209.8 | 0.0 | 648.0 | 24.7 | +3151.6 | 930.7 | 16.7 |
| RANDOM MOVE BY FIGURES | 4.0 | +229.3 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 3.3 | +195.6 | 0.0 | 22.7 | 2.7 | +77.7 | 0.0 | 84.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.0 | +0.0 | 0.0 | 29.7 | 4.7 | +0.0 | 0.0 | 118.7 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | -30.9 | 0.0 | 0.0 |
| REFORMS TO MEET IT | - | - | - | - | 1.0 | -20.7 | 0.0 | 65.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 1.7 | +26.9 | 0.0 | 22.0 |
| RISK BY ARC | 0.7 | +47.0 | 22.0 | 0.0 | 4.7 | -86.3 | 546.7 | 154.0 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 5.0 | -258.0 | 565.3 | 98.3 |
| RUN DOWN | - | - | - | - | 6.0 | -67.6 | 587.0 | 185.0 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | - | - | - | - | 1.3 | +75.2 | 0.0 | 22.0 |
| SECOND LOOK | - | - | - | - | 1.0 | +53.4 | 102.3 | 0.0 |
| SELF MOVE SPELL | 2.0 | -3.8 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 2.7 | -40.4 | 0.0 | 228.3 |
| SET UP BY THE SET | 0.3 | -9.8 | 0.0 | 0.0 | 4.0 | -15.6 | 0.0 | 243.3 |
| SET UP TOGETHER | 0.7 | +9.6 | 0.0 | 0.0 | 0.3 | +5.2 | 0.0 | 15.0 |
| SET-UP MISSED | - | - | - | - | 0.3 | +5.4 | 0.0 | 70.3 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +1.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 2.7 | +0.0 | 0.0 | 180.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.3 | +13.6 | 0.0 | 200.7 | 1.0 | +5.0 | 61.7 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 1.3 | -12.1 | 123.3 | 0.0 |
| SHOT RISK POINTS | 17.0 | -67.7 | 0.0 | 281.3 | 24.7 | +137.1 | 0.0 | 308.7 |
| SHOTS AFTER THE MOVES | 1.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 11.0 | +204.7 | 0.0 | 307.0 | 17.3 | +222.2 | 0.0 | 106.0 |
| SPELL WORTH | 1.3 | +16.2 | 180.0 | 180.0 | - | - | - | - |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | -5.9 | 115.7 | 0.0 |
| SPOT AS THE GAME MOVES | 9.7 | +0.0 | 0.0 | 342.3 | 3.7 | +0.0 | 0.0 | 148.0 |
| STAND AND SHOOT | - | - | - | - | 1.3 | -7.1 | 200.7 | 0.0 |
| STANDS FOR A REASON | 1.7 | +0.0 | 22.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 23.0 | +0.0 | 22.0 | 778.7 | 39.0 | +0.0 | 762.3 | 45.3 |
| STAY WORTH | 8.7 | +45.6 | 22.0 | 123.3 | 23.0 | +94.5 | 376.7 | 106.0 |
| STRIKE BY THE ODDS | - | - | - | - | 1.7 | -3.6 | 115.7 | 179.0 |
| STUCK PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| STUPIDITY NEXT TURN | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 8.3 | +767.8 | 0.0 | 174.7 | 2.3 | +60.3 | 0.0 | 0.0 |
| SUPPORT NARROWED | - | - | - | - | 0.7 | +0.0 | 0.0 | 23.3 |
| SUPPORT WORKED OUT | 8.3 | +767.8 | 0.0 | 174.7 | 2.3 | +60.3 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 2.3 | +14.4 | 0.0 | 70.3 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 11.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -10.2 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 4.7 | +0.0 | 0.0 | 21.7 | 0.7 | +0.0 | 0.0 | 70.3 |
| THE ROW KEEPS ITS WAY | 3.7 | +0.0 | 0.0 | 65.7 | 2.3 | +0.0 | 0.0 | 84.7 |
| THE STEP BACK IS MADE | 2.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 84.7 |
| THE TABLE AGAIN | 5.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 31.0 | +0.0 | 0.0 | 757.7 | 45.7 | +0.0 | 0.0 | 533.7 |
| TIED UP BY THE SUM | - | - | - | - | 1.0 | +128.1 | 102.3 | 0.0 |
| TIME ON OUR SIDE | 30.7 | +309.7 | 0.0 | 928.7 | 29.7 | +199.0 | 0.0 | 347.7 |
| WAITS AGAIN | 1.7 | +0.0 | 0.0 | 22.7 | 1.7 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | 0.3 | -2.3 | 22.0 | 0.0 | 1.7 | +29.9 | 152.3 | 88.3 |
| WHO HITS BACK | 0.7 | +32.7 | 0.0 | 0.0 | 0.7 | +44.7 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 4.3 | -306.6 | 0.0 | 185.0 | 2.0 | -299.4 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 1.3 | +44.8 | 0.0 | 62.7 |
| WOUNDS ON THE RANKS | 1.7 | +1.5 | 0.0 | 0.0 | 0.3 | +1.4 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p58

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 136 | 136 | 92 | 30.67 | +615 | +6.7 |
| HIS SHOT LIST | 213 | 204 | 53 | 17.67 | +258 | +4.9 |
| LEGAL CHARGES ONLY | 48 | 48 | 48 | 16.00 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 53 | 53 | 47 | 15.67 | +2111 | +44.9 |
| FIVE ACTION | 505 | 492 | 39 | 13.00 | +3136 | +80.4 |
| HIS SHOTS BY HIS RUN | 211 | 203 | 29 | 9.67 | +95 | +3.3 |
| THE TABLE AGAIN | 34 | 34 | 28 | 9.33 | +0 | +0.0 |
| QUARTER ODDS | 129 | 127 | 27 | 9.00 | +2443 | +90.5 |
| MOVE TO CHARGE COMPUTED | 35 | 31 | 25 | 8.33 | +1156 | +46.3 |
| REDIRECT FOR A FRIEND IN REACH | 23 | 23 | 23 | 7.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 181 | 165 | 20 | 6.67 | +56 | +2.8 |
| DEPLOY BY FIGURES | 45 | 45 | 19 | 6.33 | +155 | +8.1 |
| HARD STAY DROPPED | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| OFF BEST | 18 | 18 | 18 | 6.00 | -438 | -24.3 |
| PROMISE BY ITS OWN SUM | 47 | 47 | 17 | 5.67 | -1774 | -104.4 |
| GOAL WALK | 54 | 54 | 16 | 5.33 | +1024 | +64.0 |
| NEXT CHARGE BY LIST | 20 | 20 | 15 | 5.00 | +1001 | +66.8 |
| FOUR ROUNDS | 22 | 21 | 11 | 3.67 | +569 | +51.7 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| SHOT RISK POINTS | 125 | 124 | 10 | 3.33 | +66 | +6.6 |
| SUPPORT ADDS | 32 | 30 | 10 | 3.33 | +151 | +15.1 |
| SUPPORT WORKED OUT | 32 | 30 | 10 | 3.33 | +151 | +15.1 |
| ADVANCE LANE KEPT | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| MEETS IN TIME | 18 | 18 | 8 | 2.67 | +507 | +63.4 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 8 | 2.67 | +688 | +86.0 |
| CAST JOB | 8 | 8 | 7 | 2.33 | +8 | +1.1 |
| SCOUT WAITS | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| CHARGE LOSSES | 69 | 66 | 6 | 2.00 | +357 | +59.6 |
| CHARGE NOW FIRST | 14 | 14 | 6 | 2.00 | -108 | -18.0 |
| FOLLOW UP WEIGHED | 6 | 6 | 6 | 2.00 | +716 | +119.3 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +286 | +47.6 |
| FEATURE BUFFS | 11 | 11 | 5 | 1.67 | +19 | +3.8 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | -184 | -36.8 |
| RESERVE FALL BACK | 5 | 5 | 5 | 1.67 | +81 | +16.1 |
| RISK BY ARC | 16 | 15 | 5 | 1.67 | +119 | +23.9 |
| SHOOTS FROM THE BEST SPOT | 10 | 10 | 5 | 1.67 | +4 | +0.8 |
| ASSAILMENT BY POINTS | 4 | 4 | 4 | 1.33 | +9 | +2.2 |
| CASTER AWAY FROM SCREEN | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| EXACT ROUND | 15 | 15 | 4 | 1.33 | +40 | +10.0 |
| MAX FOR POSITIONING | 13 | 12 | 4 | 1.33 | +3 | +0.6 |
| ONE JOINT FIGURE | 6 | 6 | 4 | 1.33 | +230 | +57.5 |
| SHOTS IN THE MOVE | 85 | 59 | 4 | 1.33 | +122 | +30.4 |
| STAY WORTH | 95 | 83 | 4 | 1.33 | +9 | +2.2 |
| STRIKE BY THE ODDS | 5 | 5 | 4 | 1.33 | +10 | +2.6 |
| THE ROW IN ITS ORDER | 16 | 4 | 4 | 1.33 | +0 | +0.0 |
| WHO HITS BACK | 4 | 4 | 4 | 1.33 | +145 | +36.3 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | -10 | -3.2 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +37 | +12.2 |
| COVER ONCE | 36 | 24 | 3 | 1.00 | +42 | +13.9 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +166 | +55.3 |
| PROMISE KNOWS THE FIGHT | 4 | 3 | 3 | 1.00 | -17 | -5.8 |
| SECOND LOOK | 3 | 3 | 3 | 1.00 | +160 | +53.4 |
| SURE REACH TOGETHER | 7 | 7 | 3 | 1.00 | +1 | +0.3 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +205 | +102.6 |
| SEARCH SPOT | 4 | 4 | 2 | 0.67 | +226 | +112.8 |
| SET UP BY THE SET | 13 | 13 | 2 | 0.67 | +112 | +56.1 |
| TIED UP BY THE SUM | 3 | 2 | 2 | 0.67 | +26 | +13.0 |
| WHOLE FIGHT DANGER | 19 | 17 | 2 | 0.67 | +137 | +68.6 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +11 | +11.3 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -95 | -95.2 |
| CASTING BLOCK | 3 | 3 | 1 | 0.33 | +2 | +1.8 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +2 | +1.7 |
| FIGHT TO THE END | 9 | 9 | 1 | 0.33 | +2 | +1.7 |
| HIS MOVE AND SHOT | 21 | 20 | 1 | 0.33 | +0 | +0.0 |
| HIS TURN DENIED | 5 | 4 | 1 | 0.33 | +60 | +60.4 |
| IDLE COST | 34 | 21 | 1 | 0.33 | +4 | +4.2 |
| LONG SHOT | 2 | 2 | 1 | 0.33 | +3 | +3.1 |
| LOST AFTER ESCAPE | 15 | 14 | 1 | 0.33 | +1 | +0.6 |
| MARCH CHECK | 2 | 2 | 1 | 0.33 | +29 | +28.7 |
| MISSILES IN THE MOVE | 13 | 8 | 1 | 0.33 | +2 | +2.3 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| ONE OBJECTIVE FORMULA | 26 | 18 | 1 | 0.33 | +48 | +48.5 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +54 | +54.4 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -14 | -14.0 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.33 | -25 | -25.0 |
| REDIRECT COUNTER | 18 | 16 | 1 | 0.33 | +13 | +13.3 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | -95 | -95.2 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +5 | +5.0 |
| SHOTS AFTER THE MOVES | 14 | 14 | 1 | 0.33 | +0 | +0.0 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SUPPORT NARROWED | 2 | 2 | 1 | 0.33 | -0 | -0.3 |
| WHOLE FIGHT GAIN | 4 | 4 | 1 | 0.33 | +18 | +17.7 |
| WOUNDS ON THE RANKS | 6 | 6 | 1 | 0.33 | +3 | +3.2 |
| BACKUP TARGETS | 2 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CHAFF IN THE MOVE | 2 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 74 | 74 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 2 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 17 | 16 | 0 | 0.00 | - | - |
| FALLS SHORT | 51 | 45 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 45 | not checked | - | - | - | - |
| FOOT FIRST | 5 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 43 | 37 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 6 | 6 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 3 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 10 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 23 | 17 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 41 | 41 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 16 | 16 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 20 | 18 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 27 | 27 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 38 | 35 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 33 | 31 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 11 | 9 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 92 | 92 | 0 | 0.00 | - | - |
| HONEST WORTH | 17 | 16 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 5 | 2 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 7 | 7 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 3 | not checked | - | - | - | - |
| MANOEUVRE | 9 | 9 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 21 | 14 | 0 | 0.00 | - | - |
| NEARER NOT NEEDED | 48 | 47 | 0 | 0.00 | - | - |
| NEAREST TO GOAL | 8 | 8 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 18 | 17 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 34 | 34 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 6 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 23 | 9 | 0 | 0.00 | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP | 1 | not checked | - | - | - | - |
| OVERRUNS AWAY | 6 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 245 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 3 | 3 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 2 | 2 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 15 | 14 | 0 | 0.00 | - | - |
| RUN DOWN | 18 | 17 | 0 | 0.00 | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 8 | 8 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 3 | 2 | 0 | 0.00 | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 28 | not checked | - | - | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL WORTH | 4 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 40 | 36 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 9 | 6 | 0 | 0.00 | - | - |
| STANDS STILL | 186 | 179 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 8 | 6 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 6 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 18 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 12 | not checked | - | - | - | - |
| THE TABLE BINDS | 230 | not checked | - | - | - | - |
| WAITS AGAIN | 10 | 10 | 0 | 0.00 | - | - |
| WHO FIGHTS | 6 | 6 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p58

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| ARMY TABLE | rule | 5.00 | 1.33 | 44.2 |
| PROMISE BY ITS OWN SUM | rule | 2.33 | 3.33 | 104.4 |
| JOB FIRST | gate | 1.00 | 3.33 | 27.4 |
| CHARGE NOW FIRST | rule | - | 1.67 | 21.5 |
| CHAFF PASSED | rule | 0.33 | 0.67 | 3.2 |
| JOINT CHARGE NOW | rule | - | 1.00 | 200.6 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | 0.67 | 5.8 |
| FIGHT ORDER BAND | gate | 0.33 | 0.33 | 0.9 |
| RULE SWITCHED OFF | gate | - | 0.67 | 38.1 |
| BEST PRIZE | rule | - | 0.33 | 95.2 |
| DEPLOY BY FIGURES | rule | 0.33 | - | 1.1 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 1.2 |
| NO REASON | gate | 0.33 | - | 3.8 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 14.0 |
| PURSUES BIG PREY | rule | - | 0.33 | 25.0 |
| REDIRECT WEIGHED | rule | - | 0.33 | 95.2 |

### Plans: gs3-83c8646-p58

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.7 | 0% | 66 | 4 | 6% |
| Mine | move | 32.0 | 92% | 1718 | 0 | 0% |
| Mine | shoot | 3.3 | 20% | 277 | 29 | 10% |
| Opponent | charge | 6.0 | 50% | 1128 | 714 | 63% |
| Opponent | join | 2.0 | 100% | 76 | 0 | 0% |
| Opponent | move | 33.0 | 94% | 1645 | 0 | 0% |
| Opponent | shoot | 4.7 | 64% | 235 | 108 | 46% |

### Battle groups: gs3-83c8646-p58

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.3 | 30% | 67% | 33% | 0% | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 2.7 | 25% | 50% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p58

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 7 | 20 (7) | 20 | 0 | 49 | 29% | 2.6 | 22 (6) | 0 (1) | - | 20 (7) | - |
| Mine | Character | 8 | 45 (8) | 45 | 0 | 93 | 12% | 2.0 | 18 (4) | - | 123 (1) | - | 48 (5) |
| Mine | Clean-up | 4 | 53 (4) | 0 | 53 | 32 | 50% | 3.5 | 62 (2) | 16 (1) | 158 (1) | 125 (1) | 21 (3) |
| Mine | Fast Hammer | 1 | 95 (1) | 95 | 0 | 0 | 0% | 2.0 | 95 (1) | - | - | - | 95 (1) |
| Mine | Hammer | 11 | 28 (11) | 16 | 11 | 64 | 18% | 1.8 | 0 (3) | 44 (7) | 0 (1) | 0 (4) | 45 (7) |
| Mine | Shooter | 3 | 23 (3) | 23 | 0 | 33 | 0% | 2.3 | 35 (2) | 0 (1) | - | 0 (1) | 35 (2) |
| Mine | Wizard | 2 | 37 (2) | 37 | 0 | 41 | 0% | 1.5 | 62 (1) | - | - | - | 62 (1) |
| Opponent | Chaff | 8 | 111 (8) | 19 | 92 | 62 | 12% | 1.9 | 126 (2) | 81 (4) | 164 (2) | 106 (5) | 122 (3) |
| Opponent | Character | 8 | 60 (8) | 60 | 0 | 19 | 25% | 3.0 | 40 (5) | 91 (3) | - | 68 (3) | 55 (5) |
| Opponent | Clean-up | 4 | 30 (4) | 30 | 0 | 87 | 50% | 3.5 | 118 (2) | 0 (2) | - | 118 (2) | 0 (2) |
| Opponent | Fast Hammer | 7 | 122 (7) | 122 | 0 | 31 | 43% | 3.2 | 51 (2) | 175 (5) | - | 52 (4) | 172 (3) |
| Opponent | Holder | 4 | 152 (4) | 15 | 136 | 23 | 0% | 1.8 | 300 (2) | - | 28 (2) | 188 (3) | 56 (1) |
| Opponent | Shooter | 4 | 11 (4) | 11 | 0 | 0 | 0% | 1.5 | 0 (2) | 22 (2) | - | 0 (2) | 15 (2) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 78 | 0% | 2.3 | 0 (1) | - | 0 (1) | - | 0 (2) |

### Charged fights: gs3-83c8646-p58

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 1 | 0 | 0 | 3.0 | 1.0 | 0 | 41 | -41 | 3 of 3 | 0 of 3 | - | -41 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 908 | 5.0 | 1.0 | 182 | 70 | +112 | 1 of 5 | 3 of 5 | - | +112 |
| Mine | Skaven | 1 | 45 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 15 | 303 | 2.7 | 1.0 | 114 | 59 | +54 | 4 of 8 | 3 of 8 | - | +54 |
| Opponent | Tomb Kings of Khemri | 2 | 64 | 1102 | 4.5 | 1.2 | 245 | 29 | +216 | 6 of 9 | 8 of 9 | +152 | +224 |
| Opponent | Vampire Counts | 1 | 0 | 802 | 6.0 | 1.2 | 134 | 44 | +90 | 1 of 6 | 4 of 6 | -68 | +121 |
| **Opponent** | all armies | 3 | 43 | 1002 | 5.0 | 1.2 | 200 | 35 | +165 | 7 of 15 | 12 of 15 | +42 | +184 |

### Effective charges: gs3-83c8646-p58

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 3 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 2 | 0% (0 of 1) |
| Mine | Orc & Goblin Tribes | 5 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 4 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 9 | 1 (net +590) | 0 | 0 | 1 (net +152) | 0 | 5 (net +218) | 2 | 0% (0 of 7) |
| Opponent | Vampire Counts | 6 | 1 (net -50) | 0 | 0 | 2 (net -41) | 1 (net -68) | 1 (net +540) | 1 | 0% (0 of 5) |

### Charged fights, damage counted: gs3-83c8646-p58

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 2 | 142 | 130 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | No odds | 6 | 202 | 230 | +72 | 162 | 99 | +62 | +30.8 |
| Mine | All fights | 8 | 187 | 206 | +54 | 121 | 75 | +47 | +25.0 |
| Opponent | Long shot (under 50%) | 2 | 122 | 166 | +270 | 328 | 25 | +302 | +246.9 |
| Opponent | 76-89% | 3 | 299 | 148 | +23 | 161 | 137 | +23 | +7.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 | 324 | 272 | +271 | 278 | 0 | +278 | +85.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 118 | 38 | -68 | 19 | 226 | -207 | -175.6 |
| Opponent | No odds | 3 | 372 | 99 | +102 | 104 | 0 | +104 | +28.0 |
| Opponent | All fights | 15 | 288 | 183 | +165 | 209 | 46 | +163 | +56.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p58 | move | 18 | 4 (22%) | 4 (22%) | 7 (39%) | 7 (39%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L2025 |
| Elixir of Power | Mine | L1923 |
| Fistful of Laurels | Mine | L1823 |
| Invocation of Nehek | Opponent | L2025 |
| Periapt of Soul Exchange | Mine | L2025 |

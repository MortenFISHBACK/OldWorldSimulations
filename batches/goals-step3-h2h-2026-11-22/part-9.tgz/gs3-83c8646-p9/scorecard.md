# Doctrine scorecard: gs3-83c8646-p9

### Scorecard: gs3-83c8646-p9

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1527 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1527 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1625 | 5 | 1 | Mine | yes | - | 2 | 1 | 1 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | no | - | - | 2 | 4 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | no | 2 | 2 | 4 | 0 | 1 | 0 | 0 | 218 |
| L1723 | 1 | 1 | Opponent | yes | 4 | 2 | 7 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 50% | 2.0 | 2.0 | 2.5 | 0.5 | 0.5 | 0.0 | 0.0 | 209.0 |
| **Average** | | | Opponent | 50% | 4.0 | 2.0 | 4.5 | 3.0 | 0.0 | 0.0 | 0.0 | 0.0 |

### KPIs: gs3-83c8646-p9

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 12) | 0% (0 of 11) | 0% (0 of 23) |
| Winner chose to follow up after the loser gave ground |  | 50% (2 of 4); on the table 50% | - | 50% (2 of 4); on the table 50% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 50% (2 of 4); on the table 50% | 100% (2 of 2); on the table 100% | 67% (4 of 6); on the table 67% |
| Magic missiles tried each own turn | 50%+ | - | 67% (8 of 12) | 67% (8 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 67% (8 of 12) | 67% (8 of 12) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 29% (1165 of 4000) | 59% (2367 of 3999) | 44% (3532 of 7999) |
|   infantry points that never fought | lower | 51% (526 of 1030) | 78% (513 of 660) | 61% (1039 of 1690) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 62% (8 of 13) | 64% (7 of 11) | 62% (15 of 24) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 1.7 uses a game | 0.0 uses a game | 100% (2 of 2); 0.8 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 58% (1849 of 3195) | 57% (1734 of 3054) | 57% (3583 of 6249) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.3 (100%) | 1.3 (100%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.7 | 1.3 | 0.7 | 2.7 | 0.3 | 1.7 |
| not cast | 4.3 | 1.7 | 0.3 | 1.3 | 1.7 | 17.3 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (80%) | 0.0 (0%) | 1.3 (100%) | 1.0 (60%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (8%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (4%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (20%) | 0.0 (0%) | 0.0 (0%) | 0.7 (40%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.3 (100%) | 0.0 (0%) | 0.3 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.3 (88%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.7 a game | 0.0 a game | 0.3 a game |
| stood (cast and not dispelled) | - | - | - |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (29 of 45) | 74% (34 of 46) | 69% (63 of 91) |
|   cavalry | 67% (8 of 12) | 100% (12 of 12) | 83% (20 of 24) |
|   character | - | 0% (0 of 11) | 0% (0 of 11) |
|   infantry | 65% (11 of 17) | 96% (22 of 23) | 82% (33 of 40) |
|   monster | 44% (4 of 9) | - | 44% (4 of 9) |
|   war machine | 86% (6 of 7) | - | 86% (6 of 7) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.3 (6%) | 0.0 (0%) | 0.3 (4%) |
| CHARGED: it charged | 0.0 (0%) | 1.0 (25%) | 1.0 (11%) |
| FLEEING: it fled or was fleeing | 0.3 (6%) | 0.0 (0%) | 0.3 (4%) |
| IN COMBAT: it fought this turn or the last | 0.7 (12%) | 0.0 (0%) | 0.7 (7%) |
| NO TARGET IN RANGE | 2.7 (50%) | 1.7 (42%) | 4.3 (46%) |
| ONLY IN COMBAT: the only targets were in combat | 1.0 (19%) | 0.7 (17%) | 1.7 (18%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (6%) | 0.3 (8%) | 0.7 (7%) |
| OTHER BAR | 0.0 (0%) | 0.3 (8%) | 0.3 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.0 | 1.0 | 86% | 3.4 pts | 24 pts |
| infantry | 16.7 | 2.3 | 88% | 3.9 pts | 65 pts |
| monster | 1.3 | 0.3 | 75% | 12.2 pts | 16 pts |
| war machine | 2.0 | 3.3 | 33% | 53.1 pts | 106 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.0 | 4.7 | 4.3 |
| Charges that made contact a game | 3.3 | 3.3 | 3.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (3 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.00 declared, 0.00 contact (3 units) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (5 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.57 declared, 0.48 contact (21 units) | 0.54 declared, 0.38 contact (26 units) | 0.55 declared, 0.43 contact (47 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | - | 50% (1 of 2) | - | 50% (1 of 2) |
| Character in a unit | 100% (1 of 1) | 100% (1 of 1) | - | 100% (2 of 2) |
| Character on its own | 100% (1 of 1) | 0% (0 of 2) | 50% (3 of 6) | 44% (4 of 9) |
| Infantry | 100% (4 of 4) | 50% (1 of 2) | - | 83% (5 of 6) |
| Monster | 60% (3 of 5) | - | - | 60% (3 of 5) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Kingdom of Bretonnia | 1 | 50% (1 of 2); on the table 50% | - | 34% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | 50% (1 of 2); on the table 50% | - | 24% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (2 of 2); on the table 100% | - | 43% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | - | 83% (5 of 6) | 75% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p9, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 40% (2) | 50% (3) | 45% (5) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.33 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.33 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: gs3-83c8646-p9

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 71% (5 of 7) | 43% (6 of 14) |
| Strategy | Shoot objectives carried out (shot that target) | 0% (0 of 11) | 0% (0 of 9) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | 0% (0 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 0% (0 of 1) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 83% (5 of 6) | 75% (3 of 4) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.5 | 3.0 |
| Movement | Points that never moved of their own | 209.0 | 0.0 |
| Movement | Fights charged into per game | 3.0 | 3.5 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 5 | 1 of 6, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 5, net +355 | 1 of 6, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 5, net +81 | 0 of 6 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 5, net +254 | 4 of 6, net +126 |
| Shooting | Shots by shooting units (incl. breath weapons) | 7.7 | 11.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (11 of 23) | 65% (22 of 34) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 2.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (3 of 6) | - |
| Shooting | Points destroyed by war machines | 25.0 | 0.0 |
| Magic | Magic missiles cast | - | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 0% (0 of 4) |
| Magic | Wounds caused by magic missiles | 1.3 | - |
| Magic | Points destroyed by magic (all spells) | 23.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.7 / 0.7 / 0.0 | 2.0 / 0.3 / 0.0 / 0.3 |
| Combat | Points destroyed in combat | 345.3 | 249.3 |
| Combat | Points run down | 0.0 | 61.0 |
| Combat | Net points per charged fight, damage counted | +84 | +83 |
| Combat | Net per 100 charger points, damage counted | +20.7 | +32.4 |
| Combat | First round won (charged fights) | 83% | 71% |
| Combat | Net points per charged fight | +118 | +72 |
| Combat | Net points per supported fight / lone fight | +149 / +88 | - / +72 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 6 | 1 of 7 |
| Game | Points lost | 648.0 | 540.5 |
| Game | VP from objectives | 505.0 | 935.0 |
| Game | Lone holders (player turns) | 2.0 | 4.0 |

- Mine won / drew / lost: 1 / 0 / 1 of 2 ended games (of 3); mean margin (Mine - Opponent) -488 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 1188
- Games not ended: 1 (L1527-1); findings 2, warnings 0

### Opponent rules: gs3-83c8646-p9

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH IN POINTS | 0.7 | +72.2 | 0.0 | 45.0 | - | - | - | - |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +4.1 | 0.0 | 0.0 |
| ARMY TABLE | 17.0 | +123.0 | 0.0 | 79.3 | 17.3 | +335.9 | 0.0 | 123.0 |
| ASSAILMENT BY POINTS | 0.7 | +2.3 | 0.0 | 123.3 | 0.3 | +0.9 | 0.0 | 0.0 |
| BACKUP TARGETS | - | - | - | - | 0.3 | +1.0 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.3 | -33.6 | 27.7 | 0.0 |
| CANNON PLANNED TARGET | 1.7 | +17.6 | 25.0 | 33.3 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 2.7 | +117.3 | 0.0 | 0.0 |
| CHAFF PASSED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.7 | +23.1 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 17.3 | -756.4 | 0.0 | 453.3 | 10.3 | -296.8 | 0.0 | 46.7 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 98.0 | 0.0 | 2.0 | +0.0 | 198.3 | 84.7 |
| CLOSES ON WHAT IT BEATS | 11.3 | +0.0 | 0.0 | 116.7 | 14.7 | +0.0 | 0.0 | 46.7 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 45.0 | 0.0 |
| COVER ONCE | 13.7 | -553.9 | 0.0 | 195.0 | 7.7 | -594.8 | 0.0 | 72.3 |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -1.0 | 45.0 | 16.7 |
| DEPLOY BY FIGURES | 7.3 | +4.0 | 0.0 | 0.0 | 7.7 | +7.5 | 0.0 | 0.0 |
| EXACT ROUND | 2.7 | +32.5 | 462.3 | 0.0 | 4.3 | +11.3 | 284.3 | 133.0 |
| FALL BACK GOOD ORDER | 2.7 | +0.0 | 297.3 | 0.0 | 3.7 | +8.1 | 243.3 | 133.0 |
| FALLS SHORT | 0.7 | +4.6 | 0.0 | 0.0 | 18.0 | +229.9 | 0.0 | 65.0 |
| FEATURE BUFFS | 1.0 | +22.4 | 0.0 | 45.0 | - | - | - | - |
| FIGHT LIFT | 1.0 | +14.0 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 1.7 | +61.3 | 398.3 | 0.0 | 2.0 | +11.6 | 78.3 | 101.3 |
| FIVE ACTION | 64.3 | +3654.0 | 594.0 | 571.7 | 81.0 | +5023.2 | 559.7 | 552.3 |
| FLANK NOT WEIGHED | 8.0 | +0.0 | 0.0 | 103.3 | 4.3 | +0.0 | 0.0 | 97.3 |
| FOLLOW UP WEIGHED | 0.3 | +114.5 | 0.0 | 0.0 | 0.3 | +31.0 | 0.0 | 0.0 |
| FOOT FIRST | - | - | - | - | 29.7 | +0.0 | 0.0 | 228.0 |
| FOUR ROUNDS | 3.3 | +277.2 | 494.0 | 0.0 | 4.7 | +208.5 | 329.3 | 133.0 |
| FREED FROM HIS FIGHT | 3.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| FRIEND CHARGES FIRST | 0.3 | -5.8 | 0.0 | 0.0 | 0.3 | -1.5 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -35.0 | 0.0 | 0.0 | 0.3 | -0.4 | 0.0 | 0.0 |
| GIVES UP | 1.0 | -4.0 | 264.7 | 0.0 | 0.3 | -0.8 | 58.3 | 0.0 |
| GOAL WALK | 9.3 | +796.0 | 0.0 | 116.7 | 5.3 | +421.4 | 0.0 | 147.0 |
| GUN MASK | 2.0 | +1.9 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 15.3 | +0.0 | 0.0 | 398.0 | 7.0 | +0.0 | 0.0 | 46.7 |
| HIS CHARGE DENIED | 0.7 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 5.7 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 25.0 |
| HIS LEGAL MOVES | 8.7 | +0.0 | 0.0 | 0.0 | 8.7 | +0.0 | 0.0 | 46.7 |
| HIS MOVE AND SHOT | 1.3 | -17.6 | 0.0 | 72.7 | 6.3 | -85.8 | 0.0 | 0.0 |
| HIS ONE QUARTER | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 12.0 | +0.0 | 0.0 | 47.0 | 12.7 | +0.0 | 0.0 | 93.3 |
| HIS RUN AFTER OUR TURN | 5.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 20.3 | +110.9 | 0.0 | 360.7 | 35.7 | +678.2 | 0.0 | 223.3 |
| HIS SHOTS BY HIS RUN | 18.3 | +96.3 | 0.0 | 477.3 | 31.3 | +415.6 | 0.0 | 193.3 |
| HIS TURN DENIED | - | - | - | - | 1.0 | +25.7 | 78.3 | 101.3 |
| HOLD ODDS | 9.7 | +0.0 | 0.0 | 90.0 | 15.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 6.7 | +707.8 | 0.0 | 45.0 | 11.0 | +930.8 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.3 | -92.5 | 494.0 | 0.0 | 4.0 | -112.2 | 329.3 | 101.3 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +5.1 | 0.0 | 0.0 |
| IDLE COST | 1.3 | -38.3 | 0.0 | 58.3 | 11.7 | -166.0 | 0.0 | 121.3 |
| JOINT CHARGE NOW | 1.0 | +92.8 | 114.7 | 0.0 | 0.7 | +39.4 | 0.0 | 31.7 |
| KEPT FROM ITS LAST STOP | 0.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +33.0 | 0.0 | 0.0 | 1.3 | +56.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 6.3 | +0.0 | 141.3 | 134.7 | 7.0 | +0.0 | 264.3 | 434.0 |
| LONE WIZARD KEPT IN | 0.3 | +7.9 | 0.0 | 0.0 | 0.3 | +7.5 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.3 | +1.5 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.7 | -1.0 | 313.7 | 0.0 | 3.7 | +7.7 | 151.0 | 133.0 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 1.3 | -99.5 | 0.0 | 0.0 |
| MANOEUVRE | 0.3 | +0.0 | 0.0 | 45.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | +98.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.7 | +26.7 | 0.0 | 0.0 | 4.0 | +125.2 | 0.0 | 15.0 |
| MEETS IN TIME | 4.0 | +232.5 | 0.0 | 0.0 | 4.3 | +194.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.7 | +36.9 | 0.0 | 0.0 | 2.3 | +18.4 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 2.0 | +27.4 | 0.0 | 0.0 | 3.7 | +14.0 | 0.0 | 0.0 |
| MOVE ORDER | 2.0 | +0.0 | 58.3 | 0.0 | 2.0 | +0.0 | 49.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 9.0 | +573.5 | 0.0 | 47.0 | 10.3 | +1027.5 | 0.0 | 46.7 |
| MOVES UNITS SPELL | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 7.0 | +224.2 | 0.0 | 72.7 | 9.0 | +274.9 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 7.0 | +516.7 | 0.0 | 0.0 | 7.0 | +632.6 | 0.0 | 46.7 |
| NEXT OBJECTIVE NEARER | 0.3 | -4.3 | 0.0 | 0.0 | 0.3 | -10.0 | 27.7 | 0.0 |
| NO DOUBLE ROUNDS | 2.0 | -134.5 | 128.0 | 0.0 | 4.3 | -115.5 | 329.3 | 116.3 |
| NO LATE CUT | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 5.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 5.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.0 | -1.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 1.7 | -60.6 | 0.0 | 0.0 | 3.3 | -167.0 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 5.7 | -115.8 | 0.0 | 0.0 | 6.0 | -105.0 | 0.0 | 23.3 |
| ONE JOINT FIGURE | - | - | - | - | 1.0 | +85.3 | 0.0 | 31.7 |
| ONE OBJECTIVE FORMULA | 2.7 | +72.2 | 0.0 | 0.0 | 4.3 | -34.8 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.7 | -42.0 | 0.0 | 0.0 | 0.7 | -25.2 | 0.0 | 0.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 5.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.3 | +0.4 | 15.0 | 0.0 | 1.7 | +54.2 | 210.0 | 0.0 |
| OWN CAST FIRST | - | - | - | - | 0.3 | -0.2 | 0.0 | 0.0 |
| PATHS CROSS | - | - | - | - | 1.0 | +10.7 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -0.6 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 28.0 | +540.0 | 374.3 | 518.7 | 39.3 | +387.4 | 165.0 | 558.3 |
| PROMISE BELOW ZERO | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 16.7 |
| PROMISE BY ITS OWN SUM | 10.0 | -106.1 | 0.0 | 47.0 | 10.7 | -472.2 | 0.0 | 0.0 |
| PROMISE IN STEPS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | -11.8 | 0.0 | 0.0 |
| QUARTER ODDS | 11.3 | +1113.7 | 16.7 | 55.3 | 15.7 | +1974.7 | 83.0 | 0.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | +36.9 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.7 | +41.8 | 0.0 | 0.0 | 7.0 | +838.2 | 0.0 | 65.0 |
| REDIRECT FOR A FRIEND IN REACH | 1.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 65.0 |
| REDIRECT WEIGHED | - | - | - | - | 1.3 | +14.3 | 0.0 | 116.3 |
| REFORMS TO MEET IT | 2.3 | -81.2 | 0.0 | 0.0 | 2.7 | -105.2 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.7 | +0.0 | 0.0 | 169.3 |
| RESERVE FALL BACK | 0.3 | +3.1 | 0.0 | 0.0 | 1.3 | +54.3 | 0.0 | 0.0 |
| RISK BY ARC | 3.3 | +122.1 | 494.0 | 0.0 | 4.0 | -31.4 | 271.0 | 116.3 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 3.3 | -68.9 | 151.0 | 118.0 |
| RUN DOWN | - | - | - | - | 3.3 | -23.0 | 151.0 | 118.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | -39.5 | 0.0 | 0.0 |
| SEARCH SPOT | - | - | - | - | 1.0 | +18.6 | 0.0 | 0.0 |
| SELF MOVE SPELL | 1.0 | +28.7 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 3.0 | -223.8 | 0.0 | 80.0 |
| SET UP BY THE SET | 2.3 | -3.3 | 133.7 | 0.0 | 5.7 | +200.9 | 0.0 | 80.0 |
| SHOOTERS IN TWO RANKS | 1.0 | +2.0 | 0.0 | 0.0 | 0.3 | +1.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 4.0 | +0.0 | 0.0 | 61.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +1.5 | 0.0 | 0.0 | 0.7 | +3.5 | 86.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 1.0 | -4.9 | 144.3 | 0.0 |
| SHOT RISK POINTS | 14.7 | -162.9 | 0.0 | 291.7 | 26.3 | -241.9 | 0.0 | 126.7 |
| SHOTS AFTER THE MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 8.7 | +181.2 | 0.0 | 164.3 | 11.7 | +50.0 | 0.0 | 0.0 |
| SPELL WORTH | 1.0 | +26.4 | 0.0 | 0.0 | - | - | - | - |
| SPELLS IN THE FIGHT | 0.3 | -3.7 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 4.3 | +0.0 | 0.0 | 74.7 | 6.3 | +0.0 | 0.0 | 99.7 |
| STAND AND SHOOT | - | - | - | - | 1.0 | -23.0 | 131.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 21.0 | +0.0 | 100.0 | 118.3 | 18.3 | +0.0 | 230.3 | 0.0 |
| STAY WORTH | 4.0 | +4.2 | 50.0 | 27.7 | 8.3 | +11.4 | 144.3 | 0.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.7 | +10.5 | 61.7 | 229.0 |
| STUPIDITY NEXT TURN | 0.3 | +0.0 | 0.0 | 47.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 3.7 | +94.7 | 0.0 | 0.0 | 5.7 | +279.6 | 0.0 | 30.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 49.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 3.7 | +94.7 | 0.0 | 0.0 | 5.7 | +279.6 | 0.0 | 30.0 |
| SURE REACH TOGETHER | 0.3 | +0.2 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 0.7 | +0.0 | 0.0 | 58.3 | 3.3 | +0.0 | 0.0 | 49.0 |
| THE STEP BACK IS MADE | 0.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 49.0 |
| THE TABLE AGAIN | 5.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 29.7 | +0.0 | 0.0 | 250.3 | 42.0 | +0.0 | 0.0 | 209.7 |
| TIED UP BY THE SUM | 1.0 | +105.8 | 65.7 | 0.0 | 1.7 | +184.7 | 178.3 | 0.0 |
| TIME ON OUR SIDE | 27.3 | +381.8 | 0.0 | 176.0 | 12.3 | +67.2 | 58.3 | 23.3 |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 1.0 | -10.6 | 376.7 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.7 | -7.9 | 133.7 | 0.0 | 0.7 | +4.3 | 90.0 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +1.7 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.7 | -11.9 | 196.7 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 3.7 | -541.2 | 0.0 | 161.7 | 0.7 | -46.7 | 0.0 | 46.7 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +8.2 | 0.0 | 15.0 |
| WOUNDS ON THE RANKS | 0.3 | +11.2 | 0.0 | 45.0 | 2.7 | +59.8 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p9

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 103 | 103 | 68 | 22.67 | +1120 | +16.5 |
| HOLDER ASSIGNMENT | 53 | 53 | 49 | 16.33 | +3298 | +67.3 |
| LEGAL CHARGES ONLY | 40 | 40 | 40 | 13.33 | +0 | +0.0 |
| HIS SHOT LIST | 168 | 163 | 34 | 11.33 | +222 | +6.5 |
| MOVE TO CHARGE COMPUTED | 58 | 54 | 29 | 9.67 | +991 | +34.2 |
| FIVE ACTION | 436 | 424 | 27 | 9.00 | +1206 | +44.7 |
| DEPLOY BY FIGURES | 45 | 45 | 25 | 8.33 | +242 | +9.7 |
| MEETS IN TIME | 25 | 25 | 19 | 6.33 | +1217 | +64.0 |
| PROMISE BY ITS OWN SUM | 62 | 62 | 19 | 6.33 | -1735 | -91.3 |
| REDIRECT FOR A FRIEND IN REACH | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 42 | 39 | 18 | 6.00 | +798 | +44.3 |
| THE TABLE AGAIN | 30 | 30 | 18 | 6.00 | +0 | +0.0 |
| FOUR ROUNDS | 24 | 24 | 15 | 5.00 | +441 | +29.4 |
| OFF BEST | 15 | 15 | 15 | 5.00 | -683 | -45.5 |
| SUPPORT ADDS | 28 | 28 | 15 | 5.00 | +284 | +18.9 |
| SUPPORT WORKED OUT | 28 | 28 | 15 | 5.00 | +284 | +18.9 |
| GOAL WALK | 44 | 44 | 13 | 4.33 | +646 | +49.7 |
| HIS SHOTS BY HIS RUN | 149 | 144 | 13 | 4.33 | +164 | +12.6 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| LANE BY FIGURES | 8 | 8 | 8 | 2.67 | +267 | +33.4 |
| QUARTER ODDS | 81 | 76 | 8 | 2.67 | +641 | +80.1 |
| SET UP BY THE SET | 24 | 24 | 8 | 2.67 | +250 | +31.3 |
| IDLE COST | 39 | 29 | 6 | 2.00 | +76 | +12.7 |
| TIED UP BY THE SUM | 8 | 8 | 6 | 2.00 | +99 | +16.5 |
| TIME ON OUR SIDE | 119 | 98 | 6 | 2.00 | +0 | +0.0 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| COVER ONCE | 64 | 45 | 5 | 1.67 | +77 | +15.4 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | +397 | +79.3 |
| MAX FOR POSITIONING | 17 | 16 | 5 | 1.67 | +20 | +4.0 |
| RESERVE FALL BACK | 5 | 5 | 5 | 1.67 | +172 | +34.4 |
| RISK BY ARC | 22 | 22 | 5 | 1.67 | +57 | +11.4 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 8 | 8 | 4 | 1.33 | +0 | +0.0 |
| CHARGE LOSSES | 83 | 81 | 4 | 1.33 | +614 | +153.6 |
| HARD STAY DROPPED | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| ONE PROMISE A TARGET | 4 | 4 | 4 | 1.33 | -201 | -50.3 |
| PROMISE KNOWS THE FIGHT | 6 | 5 | 4 | 1.33 | -36 | -8.9 |
| REDIRECT COUNTER | 26 | 24 | 4 | 1.33 | +182 | +45.5 |
| REDIRECT WEIGHED | 4 | 4 | 4 | 1.33 | +278 | +69.6 |
| SHOOTERS IN TWO RANKS | 4 | 4 | 4 | 1.33 | +11 | +2.8 |
| SHOT RISK POINTS | 123 | 118 | 4 | 1.33 | +26 | +6.4 |
| ASSAILMENT BY POINTS | 3 | 3 | 3 | 1.00 | +10 | +3.3 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| EXACT ROUND | 21 | 21 | 3 | 1.00 | +38 | +12.7 |
| FIGHT TO THE END | 11 | 11 | 3 | 1.00 | +194 | +64.5 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| OVERRUNS AWAY | 6 | 6 | 3 | 1.00 | +47 | +15.6 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +32 | +10.7 |
| SEARCH SPOT | 3 | 3 | 3 | 1.00 | +56 | +18.6 |
| SHOOTS FROM THE BEST SPOT | 4 | 4 | 3 | 1.00 | +2 | +0.5 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +216 | +108.2 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +69 | +34.6 |
| CHARGE NOW FIRST | 9 | 9 | 2 | 0.67 | -31 | -15.3 |
| FALLS SHORT | 56 | 46 | 2 | 0.67 | +37 | +18.6 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +436 | +218.1 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +46 | +23.1 |
| MISSILES IN THE MOVE | 12 | 9 | 2 | 0.67 | +56 | +27.8 |
| ONE JOINT FIGURE | 3 | 3 | 2 | 0.67 | +56 | +28.0 |
| ONE OBJECTIVE FORMULA | 21 | 16 | 2 | 0.67 | +26 | +13.0 |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 2 | 0.67 | +109 | +54.4 |
| REFUSING RETIRES | 2 | 2 | 2 | 0.67 | -35 | -17.7 |
| STAY WORTH | 37 | 31 | 2 | 0.67 | +1 | +0.6 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +32 | +15.8 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +12 | +12.3 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -101 | -100.8 |
| FALL BACK GOOD ORDER | 19 | 19 | 1 | 0.33 | +9 | +8.7 |
| HIS TURN DENIED | 3 | 3 | 1 | 0.33 | +9 | +8.7 |
| LOST AFTER ESCAPE | 16 | 16 | 1 | 0.33 | +0 | +0.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| OWN CAST FIRST | 1 | 1 | 1 | 0.33 | -1 | -0.7 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -2 | -1.7 |
| SHOTS AFTER THE MOVES | 14 | 14 | 1 | 0.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 61 | 42 | 1 | 0.33 | +36 | +36.2 |
| THE ROW IN ITS ORDER | 6 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +5 | +5.0 |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CANNON PLANNED TARGET | 5 | 5 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 78 | 77 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 3 | 3 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 37 | not checked | - | - | - | - |
| FOOT FIRST | 89 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 14 | 14 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 3 | 3 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 4 | 0 | 0.00 | - | - |
| GUN MASK | 6 | 6 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 6 | 6 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 67 | 65 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 38 | 34 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 52 | 49 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 23 | 22 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 9 | 7 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 74 | 71 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 29 | 29 | 0 | 0.00 | - | - |
| HOLD ODDS | 75 | 75 | 0 | 0.00 | - | - |
| HONEST WORTH | 22 | 22 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 18 | 18 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MANOEUVRE | 4 | 4 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 5 | 5 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 17 | 12 | 0 | 0.00 | - | - |
| NEARER NOT NEEDED | 48 | 46 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 19 | 19 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 30 | 30 | 0 | 0.00 | - | - |
| NO SECOND RUN | 30 | 30 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 3 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 35 | 15 | 0 | 0.00 | - | - |
| ONE ROUTE | 5 | 5 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 30 | 30 | 0 | 0.00 | - | - |
| PLAN RESULT | 202 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 6 | 6 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 5 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 15 | 13 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 4 | 4 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 10 | 10 | 0 | 0.00 | - | - |
| RUN DOWN | 10 | 10 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 3 | not checked | - | - | - | - |
| SET CREDITED ONCE | 9 | 9 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 23 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL WORTH | 3 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 32 | 28 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 5 | 5 | 0 | 0.00 | - | - |
| STANDS STILL | 118 | 113 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 6 | 6 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 12 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 8 | not checked | - | - | - | - |
| THE TABLE BINDS | 215 | not checked | - | - | - | - |
| WAITS AGAIN | 8 | 8 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 2 | 2 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 3 | 3 | 0 | 0.00 | - | - |
| WHO FIGHTS | 4 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 13 | 13 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 9 | 9 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p9

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 2.67 | 3.67 | 91.3 |
| JOB FIRST | gate | 1.67 | 2.00 | 53.0 |
| ARMY TABLE | rule | 2.00 | 1.00 | 47.2 |
| ONE PROMISE A TARGET | rule | 0.67 | 0.67 | 50.4 |
| PROMISE KNOWS THE FIGHT | rule | - | 1.33 | 8.9 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.67 | 18.2 |
| NO REASON | gate | - | 1.00 | 32.0 |
| CHARGE NOW FIRST | rule | - | 0.67 | 15.3 |
| REFUSING RETIRES | rule | - | 0.67 | 17.7 |
| BEST PRIZE | rule | - | 0.33 | 100.8 |
| JOINT CHARGE NOW | rule | 0.33 | - | 23.5 |
| OWN CAST FIRST | rule | - | 0.33 | 0.7 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 1.7 |
| SET UP BY THE SET | rule | - | 0.33 | 72.1 |
| TURN GATE | gate | - | 0.33 | 4.1 |

### Plans: gs3-83c8646-p9

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.0 | 78% | 244 | 462 | 190% |
| Mine | move | 22.3 | 88% | 1303 | 0 | 0% |
| Mine | shoot | 2.7 | 50% | 144 | 78 | 54% |
| Opponent | charge | 3.7 | 45% | 222 | 256 | 115% |
| Opponent | join | 2.3 | 100% | 88 | 0 | 0% |
| Opponent | move | 30.0 | 96% | 1582 | 0 | 0% |
| Opponent | shoot | 2.0 | 50% | 105 | 131 | 125% |
| Opponent | support | 1.3 | 100% | 0 | 0 | - |

### Battle groups: gs3-83c8646-p9

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.7 | 40% | 50% | 50% | 0% | 0% | 0% | 100% | 0% | 0% |
| Opponent | REDIRECT COUNTER | 7.0 | 10% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p9

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Mine | Character | 6 | 40 (6) | 40 | 0 | 8 | 17% | 2.2 | 21 (3) | 87 (2) | 0 (1) | 14 (4) | 87 (2) |
| Mine | Fast Hammer | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | 0 (1) | - | - | - | 0 (1) |
| Mine | Hammer | 4 | 39 (4) | 39 | 0 | 39 | 25% | 1.7 | 39 (3) | 40 (1) | - | 39 (4) | - |
| Mine | Shooter | 4 | 16 (4) | 0 | 16 | 100 | 0% | 1.0 | 0 (1) | 0 (2) | 72 (1) | 21 (3) | 0 (1) |
| Mine | Support | 3 | 0 (3) | 0 | 0 | 100 | 0% | 2.0 | - | - | - | - | - |
| Mine | War machine | 2 | 38 (2) | 38 | 0 | 50 | 0% | 1.0 | 0 (1) | 75 (1) | - | 38 (2) | - |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Opponent | Chaff | 6 | 93 (6) | 0 | 93 | 31 | 50% | 2.0 | 22 (4) | 0 (1) | 455 (1) | 105 (5) | 0 (1) |
| Opponent | Character | 5 | 39 (5) | 39 | 0 | 38 | 20% | 3.2 | 0 (1) | 0 (2) | 70 (2) | 0 (2) | 45 (3) |
| Opponent | Clean-up | 3 | 35 (3) | 22 | 13 | 87 | 0% | 1.7 | 100 (1) | 25 (2) | - | 29 (2) | 39 (1) |
| Opponent | Fast Hammer | 5 | 67 (5) | 67 | 0 | 8 | 60% | 1.5 | - | 67 (5) | - | 29 (3) | 115 (2) |
| Opponent | Hammer | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Holder | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.5 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 33% | 1.5 | 0 (2) | 0 (1) | - | 0 (1) | 0 (2) |

### Charged fights: gs3-83c8646-p9

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Kingdom of Bretonnia | 1 | 75 | 496 | 4.0 | 1.8 | 124 | 0 | +124 | 1 of 4 | 4 of 4 | +149 | +50 |
| Mine | Lizardmen | 1 | 70 | 540 | 2.0 | 1.0 | 270 | 163 | +107 | 1 of 2 | 1 of 2 | - | +107 |
| **Mine** | all armies | 2 | 72 | 518 | 3.0 | 1.5 | 173 | 54 | +118 | 2 of 6 | 5 of 6 | +149 | +88 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 505 | 5.0 | 1.0 | 101 | 0 | +101 | 1 of 5 | 4 of 5 | - | +101 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 0 of 2 | 1 of 2 | - | +0 |
| **Opponent** | all armies | 2 | 0 | 252 | 3.5 | 1.0 | 72 | 0 | +72 | 1 of 7 | 5 of 7 | - | +72 |

### Effective charges: gs3-83c8646-p9

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Kingdom of Bretonnia | 4 | 0 | 0 | 0 | 0 | 3 (net +81) | 1 (net +254) | 0 | 0% (0 of 4) |
| Mine | Lizardmen | 2 | 0 | 0 | 1 (net +355) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Opponent | Tomb Kings of Khemri | 5 | 0 | 0 | 1 (net +0) | 0 | 0 | 4 (net +126) | 0 | 20% (1 of 5) |
| Opponent | Vampire Counts | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |

### Charged fights, damage counted: gs3-83c8646-p9

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 405 | 440 | +355 | 540 | 243 | +297 | +73.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 585 | 254 | +254 | 254 | 0 | +254 | +43.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 439 | 81 | +81 | 81 | 49 | +32 | +7.3 |
| Mine | No odds | 1 | 141 | 70 | -141 | 0 | 141 | -141 | -100.0 |
| Mine | All fights | 6 | 408 | 168 | +118 | 173 | 88 | +84 | +20.7 |
| Opponent | Long shot (under 50%) | 1 | 50 | 100 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Effective (55-75%) | 1 | 195 | 135 | +0 | 39 | 0 | +39 | +20.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 376 | 154 | +126 | 126 | 0 | +126 | +33.5 |
| Opponent | No odds | 1 | 50 | 80 | +0 | 40 | 0 | +40 | +80.0 |
| Opponent | All fights | 7 | 257 | 133 | +72 | 83 | 0 | +83 | +32.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p9 | move | 26 | 4 (15%) | 4 (15%) | 4 (15%) | 18 (69%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1527, L1625 |
| Invocation of Nehek | Opponent | L1527, L1625 |
| Ring of Doom | Mine | L1527 |

# Doctrine scorecard: gs3-83c8646-p43

### Scorecard: gs3-83c8646-p43

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1126 | 4 | 1 | Mine | no | 4 | 2 | 2 | 0 | 0 | 0 | 0 | 165 |
| L1126 | 4 | 1 | Opponent | no | 4 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 5 | 1 | 0 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 1 | 5 | 1 | 0 | 0 | 275 |
| L1314 | 6 | 1 | Mine | no | 0 | 2 | 1 | 3 | 0 | 0 | 0 | 140 |
| L1314 | 6 | 1 | Opponent | no | 8 | 3 | 1 | 1 | 0 | 0 | 0 | 123 |
| **Average** | | | Mine | 0% | 2.0 | 2.0 | 2.7 | 1.3 | 0.0 | 0.0 | 0.0 | 211.7 |
| **Average** | | | Opponent | 0% | 6.0 | 2.5 | 1.7 | 2.3 | 0.3 | 0.0 | 0.0 | 132.7 |

### KPIs: gs3-83c8646-p43

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 13% (2 of 15) | 0% (0 of 18) | 6% (2 of 33) |
| Winner chose to follow up after the loser gave ground |  | 100% (4 of 4); on the table 100% | 50% (1 of 2); on the table 100% | 83% (5 of 6); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | 33% (1 of 3); on the table 100% | 50% (2 of 4); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (5 of 5); on the table 100% | 40% (2 of 5); on the table 100% | 70% (7 of 10); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 41% (17 of 41) | 63% (12 of 19) | 48% (29 of 60) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 57% (17 of 30) | 67% (12 of 18) | 60% (29 of 48) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 100% (9 of 9) | 100% (9 of 9) |
| Points that never fought | lower | 53% (2617 of 4955) | 47% (2790 of 5999) | 49% (5407 of 10954) |
|   infantry points that never fought | lower | 58% (595 of 1031) | 64% (921 of 1430) | 62% (1516 of 2461) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 62% (13 of 21) | 71% (15 of 21) | 67% (28 of 42) |
| Bound items with a magic missile used (at least once a game) |  | 83% (5 of 6); 6.7 uses a game | 0.0 uses a game | 83% (5 of 6); 3.3 uses a game |
| Bound items with another spell used |  | 0% (0 of 2); 0.0 uses a game | 33% (2 of 6); 0.7 uses a game | 25% (2 of 8); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 2); 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 33% (1 of 3); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 62% (2857 of 4623) | 67% (3634 of 5431) | 65% (6491 of 10054) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (4%) | 1.0 (43%) | 1.3 (13%) |
| MARCHED: its unit marched | 3.0 (38%) | 1.0 (43%) | 4.0 (39%) |
| CHARGED: its unit charged | 1.0 (12%) | 0.0 (0%) | 1.0 (10%) |
| IN COMBAT: engaged in combat | 2.0 (25%) | 0.3 (14%) | 2.3 (23%) |
| FLEEING: fleeing | 0.7 (8%) | 0.0 (0%) | 0.7 (6%) |
| OFF THE TABLE: off the table or not arrived | 1.0 (12%) | 0.0 (0%) | 1.0 (10%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 9.7 | 3.0 | 4.3 | 9.7 | 0.0 | 0.7 |
| not cast | 2.3 | 3.0 | 3.7 | 10.3 | 4.0 | 39.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (14%) | 3.0 (100%) | 0.0 (0%) | 1.3 (13%) | 1.3 (33%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.0 (39%) | 0.7 (17%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (10%) | 0.3 (8%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (14%) | 0.0 (0%) | 1.0 (27%) | 2.3 (23%) | 1.0 (25%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (6%) | 0.7 (17%) | 0.7 (2%) |
| OFF THE TABLE: off the table or not arrived | 1.0 (43%) | 0.0 (0%) | 1.0 (27%) | 1.0 (10%) | 0.0 (0%) | 2.3 (6%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.7 (29%) | 0.0 (0%) | 1.7 (45%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 35.3 (90%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 3.3 a game | 2.2 a game |
| stood (cast and not dispelled) | 67% (2 of 3) | 70% (7 of 10) | 69% (9 of 13) |
| the unit moved after it | 50% (1 of 2) | 100% (7 of 7) | 89% (8 of 9) |
| it charged on its next turn | 0% (0 of 2) | 0% (0 of 7) | 0% (0 of 9) |
| the enemy charged it first | 0% (0 of 2) | 0% (0 of 7) | 0% (0 of 9) |
| it fought by the end of its next turn | 0% (0 of 2) | 0% (0 of 7) | 0% (0 of 9) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 2) | 14% (1 of 7) | 11% (1 of 9) |
| none of these (no charge, no fight, no charge escaped) | 100% (2 of 2) | 86% (6 of 7) | 89% (8 of 9) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 89% (51 of 57) | 38% (11 of 29) | 72% (62 of 86) |
|   cavalry | - | 75% (3 of 4) | 75% (3 of 4) |
|   character | 50% (3 of 6) | 9% (1 of 11) | 24% (4 of 17) |
|   chariot | 100% (3 of 3) | - | 100% (3 of 3) |
|   infantry | 94% (17 of 18) | 50% (7 of 14) | 75% (24 of 32) |
|   war machine | 93% (28 of 30) | - | 93% (28 of 30) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.3 (67%) | 0.7 (11%) | 2.0 (25%) |
| CHARGED: it charged | 0.0 (0%) | 1.3 (22%) | 1.3 (17%) |
| MOVED: a war machine that moved | 0.3 (17%) | 0.0 (0%) | 0.3 (4%) |
| NO TARGET IN RANGE | 0.0 (0%) | 1.7 (28%) | 1.7 (21%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (6%) | 0.3 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 2.0 (33%) | 2.0 (25%) |
| OTHER BAR | 0.3 (17%) | 0.0 (0%) | 0.3 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.0 | 0.3 | 83% | 1.5 pts | 3 pts |
| character | 2.0 | 0.7 | 67% | 17.0 pts | 34 pts |
| chariot | 1.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 17.0 | 7.3 | 63% | 17.1 pts | 291 pts |
| war machine | 10.0 | 8.3 | 70% | 12.8 pts | 128 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 4.7 | 3.8 |
| Charges that made contact a game | 1.3 | 3.3 | 2.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.25 declared, 0.75 contact (4 units) | 0.67 declared, 0.67 contact (3 units) | 1.00 declared, 0.71 contact (7 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 2.00 declared, 2.00 contact (1 units) | 2.00 declared, 2.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.36 declared, 0.09 contact (11 units) | 0.40 declared, 0.24 contact (25 units) | 0.39 declared, 0.19 contact (36 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 62% (5 of 8) | - | 100% (1 of 1) | 67% (6 of 9) |
| Character on its own | 100% (2 of 2) | 40% (2 of 5) | 57% (4 of 7) | 57% (8 of 14) |
| Chariot | 100% (1 of 1) | - | - | 100% (1 of 1) |
| Infantry | 50% (4 of 8) | 100% (1 of 1) | 0% (0 of 1) | 50% (5 of 10) |
| Monster | 100% (1 of 1) | 100% (2 of 2) | - | 100% (3 of 3) |
| Monstrous | - | 100% (1 of 1) | - | 100% (1 of 1) |
| War Machines | 100% (4 of 4) | - | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 2 | 100% (4 of 4); on the table 100% | 47% (17 of 36) | 50% | 65% (11 of 17) | 80% (4 of 5); 7.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| High Elf Realms | 2 | 100% (2 of 2); on the table 100% | 17% (2 of 12) | 40% | 54% (7 of 13) | 100% (1 of 1); 3.0 uses a game | 25% (2 of 8); 1.0 uses a game | 0.0 uses a game |
| Skaven | 1 | 0% (0 of 1); on the table 100% | 100% (6 of 6) | 66% | 100% (7 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 1 | 33% (1 of 3); on the table 100% | 67% (4 of 6) | 45% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p43, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (2) | 67% (2) | 57% (4) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.67 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.67 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p43

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 5.0 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 25% (2 of 8) | 20% (2 of 10) |
| Strategy | Shoot objectives carried out (shot that target) | 17% (8 of 47) | 0% (0 of 11) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | 0% (0 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 40% (2 of 5) | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 0% (0 of 1) | 100% (1 of 1) |
| Strategy | Lone characters that fought | 62% (5 of 8) | 67% (4 of 6) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 1.3 | 2.3 |
| Movement | Points that never moved of their own | 211.7 | 132.7 |
| Movement | Fights charged into per game | 1.7 | 2.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 2 | 3 of 6, net +273 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | 2 of 6, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 2, net +52 | 0 of 6 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 2 | 1 of 6, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.0 | 5.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (11 of 24) | 60% (9 of 15) |
| Shooting | Points destroyed by shooting units | 47.7 | 0.0 |
| Shooting | War machine shots | 9.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 64% (18 of 28) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 3.3 | 3.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 60% (6 of 10) | 80% (8 of 10) |
| Magic | Wounds caused by magic missiles | 10.7 | - |
| Magic | Wounds caused by other spells | 4.3 | - |
| Magic | Points destroyed by magic (all spells) | 187.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.7 / 1.7 / 0.7 / 0.0 | 4.7 / 0.3 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 100.0 | 148.7 |
| Combat | Points run down | 0.0 | 77.7 |
| Combat | Net points per charged fight, damage counted | +72 | +145 |
| Combat | Net per 100 charger points, damage counted | +23.1 | +45.2 |
| Combat | First round won (charged fights) | 100% | 62% |
| Combat | Net points per charged fight | +90 | +171 |
| Combat | Net points per supported fight / lone fight | - / +90 | +0 / +195 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 5 | 5 of 8 |
| Game | Points lost | 720.0 | 469.7 |
| Game | VP from objectives | 570.0 | 340.0 |
| Game | Lone holders (player turns) | 2.0 | 6.0 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -42 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1190
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p43

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 41.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.3 | +10.4 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | 0.3 | +20.1 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 10.3 | -110.1 | 0.0 | 251.0 | 16.7 | +473.6 | 0.0 | 100.7 |
| ARTILLERY RE-ROLL WEIGHED | 3.0 | +0.0 | 0.0 | 110.0 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 0.3 | +6.4 | 0.0 | 0.0 |
| BOMBING RUN | 0.3 | +9.6 | 0.0 | 50.0 | - | - | - | - |
| CANNON PLANNED TARGET | 9.0 | +106.6 | 240.7 | 165.0 | - | - | - | - |
| CANNON SIGHT KEPT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 4.3 | +103.4 | 0.0 | 0.0 | 4.3 | +11.9 | 119.3 | 0.0 |
| CASTS AFTER FRIENDS | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.7 | +28.4 | 0.0 | 0.0 | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 2.0 | -65.1 | 77.7 | 0.0 |
| CHARGE LOSSES | 8.0 | -443.0 | 0.0 | 289.0 | 23.3 | -576.8 | 0.0 | 296.7 |
| CHARGE NOW FIRST | 5.0 | +0.0 | 56.7 | 0.0 | 1.0 | +0.0 | 55.0 | 0.0 |
| CHARGER SLAIN LOST | - | - | - | - | 0.7 | -11.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 10.0 | +0.0 | 0.0 | 339.3 | 8.7 | +0.0 | 0.0 | 66.7 |
| CONTINUE AHEAD WEIGHED | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 1.7 | +92.0 | 0.0 | 0.0 | 2.0 | +245.8 | 0.0 | 0.0 |
| COVER ONCE | 7.0 | -242.0 | 0.0 | 0.0 | 8.0 | -1639.1 | 0.0 | 100.7 |
| DENIED BY THE FIGHT | 0.7 | -1.3 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 6.3 | -33.8 | 0.0 | 0.0 | 7.7 | +92.6 | 0.0 | 41.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -0.5 | 0.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 1.0 | +17.4 | 0.0 | 0.0 |
| EXACT ROUND | 3.0 | +35.0 | 56.7 | 77.7 | 1.7 | +26.1 | 132.7 | 0.0 |
| FALL BACK GOOD ORDER | 2.7 | +11.1 | 21.7 | 77.7 | 2.3 | +2.6 | 174.3 | 0.0 |
| FALLS SHORT | - | - | - | - | 23.3 | +249.9 | 0.0 | 298.3 |
| FEATURE BUFFS | 1.3 | +3.5 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 1.3 | +7.6 | 0.0 | 0.0 | 0.7 | +6.2 | 197.0 | 0.0 |
| FIRE IN ORDER | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 81.3 | +4727.9 | 764.0 | 1597.7 | 75.7 | +5259.9 | 371.3 | 657.3 |
| FLANK NOT WEIGHED | 3.0 | +0.0 | 0.0 | 169.3 | 8.0 | +0.0 | 0.0 | 83.0 |
| FOCUS FIRE | 0.3 | +0.4 | 50.3 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.7 | +7.4 | 0.0 | 0.0 | 0.7 | +28.0 | 0.0 | 0.0 |
| FOOT FIRST | - | - | - | - | 17.0 | +0.0 | 0.0 | 222.7 |
| FOUR ROUNDS | 3.3 | +342.6 | 56.7 | 77.7 | 4.0 | +240.0 | 252.0 | 0.0 |
| FREED FROM HIS FIGHT | - | - | - | - | 5.3 | +0.0 | 0.0 | 0.0 |
| FRIEND CHARGES FIRST | 1.3 | -183.8 | 0.0 | 0.0 | 0.3 | -7.5 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 5.3 | -38.9 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.3 | -1.7 | 0.0 | 77.7 | 1.0 | -9.9 | 119.3 | 0.0 |
| GOAL ROUTE | - | - | - | - | 0.7 | +2.5 | 0.0 | 0.0 |
| GOAL WALK | 5.0 | +311.2 | 0.0 | 238.7 | 8.0 | +869.6 | 0.0 | 0.0 |
| GUN MASK | 3.7 | +70.9 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 5.0 | +0.0 | 0.0 | 238.7 | 11.7 | +0.0 | 0.0 | 201.3 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +16.6 | 0.0 | 0.0 |
| HIS CHARGE LIST | 2.7 | +0.0 | 0.0 | 100.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 5.3 | +0.0 | 0.0 | 100.7 | 7.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.7 | -22.5 | 0.0 | 50.3 | 8.7 | -33.9 | 0.0 | 222.7 |
| HIS ONE QUARTER | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 7.7 | +0.0 | 0.0 | 100.7 | 9.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 19.7 | +689.6 | 0.0 | 612.7 | 50.3 | +1915.5 | 0.0 | 470.0 |
| HIS SHOTS BY HIS RUN | 18.0 | +246.4 | 0.0 | 540.7 | 48.7 | +871.1 | 0.0 | 500.7 |
| HIS TURN DENIED | 1.0 | +11.5 | 21.7 | 0.0 | 1.3 | +49.6 | 55.0 | 0.0 |
| HOLD ODDS | 14.3 | +0.0 | 0.0 | 591.0 | 10.3 | +0.0 | 0.0 | 82.0 |
| HOLDER ASSIGNMENT | 10.7 | +949.5 | 0.0 | 320.7 | 7.0 | +872.5 | 0.0 | 82.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HONEST WORTH | 3.0 | -71.6 | 56.7 | 77.7 | 3.0 | -145.7 | 252.0 | 0.0 |
| HUNT IN PAIRS | 3.3 | +258.6 | 0.0 | 0.0 | 0.7 | +78.6 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 15.3 | -290.1 | 0.0 | 146.3 |
| JOINT CHARGE NOW | 0.7 | -1.5 | 0.0 | 0.0 | 1.0 | +134.6 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.7 | -12.1 | 0.0 | 0.0 |
| JOINT LOOK BACK | - | - | - | - | 0.3 | +7.7 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 3.7 | +0.0 | 0.0 | 151.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.0 | +10.6 | 0.0 | 0.0 | 1.3 | +77.8 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 1.7 | +0.0 | 47.7 | 77.7 | 1.3 | +0.0 | 155.3 | 41.0 |
| LONE WIZARD KEPT IN | 0.3 | +17.9 | 0.0 | 0.0 | 0.3 | +39.6 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 2.0 | -1.4 | 0.0 | 77.7 | 1.7 | +17.1 | 197.0 | 0.0 |
| MANOEUVRE | 0.7 | +16.6 | 0.0 | 0.0 | 3.3 | +10.5 | 0.0 | 72.0 |
| MARCH BY THE SUM | 1.0 | +101.3 | 0.0 | 0.0 | 1.0 | +89.5 | 0.0 | 0.0 |
| MARCH CHECK | 1.3 | +131.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 1.0 | +106.1 | 0.0 | 0.0 | 1.0 | +71.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | 1.7 | +102.3 | 0.0 | 0.0 | 1.0 | -60.7 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 6.3 | +380.6 | 0.0 | 0.0 | 4.3 | +105.4 | 0.0 | 0.0 |
| MEETS IN TIME | 2.3 | +324.6 | 0.0 | 0.0 | 3.3 | +387.1 | 0.0 | 41.0 |
| MISSILES IN THE MOVE | 10.0 | +181.5 | 0.0 | 0.0 | 4.3 | +15.0 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 11.0 | +130.2 | 0.0 | 0.0 | 5.0 | +13.1 | 0.0 | 0.0 |
| MISSILES ON ONE TARGET | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 119.3 | 0.7 | +0.0 | 50.3 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 0.3 | -2.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 5.3 | +532.3 | 0.0 | 0.0 | 5.0 | +564.7 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 2.7 | +151.2 | 0.0 | 100.7 | 5.3 | +216.9 | 0.0 | 50.3 |
| NEXT CHARGE BY LIST | 6.0 | +882.9 | 0.0 | 0.0 | 4.7 | +524.9 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -30.0 | 0.0 | 50.3 | 0.7 | -0.2 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 3.3 | -134.6 | 56.7 | 77.7 | 2.7 | -129.4 | 174.3 | 0.0 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 50.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.7 | -0.3 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 4.3 | -75.3 | 0.0 | 55.0 | 2.3 | -123.9 | 0.0 | 0.0 |
| OGRE LOADER SECOND SHOT | 4.3 | +39.6 | 0.0 | 110.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 6.3 | -170.3 | 0.0 | 0.0 | 5.3 | -141.8 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 0.7 | +16.8 | 0.0 | 0.0 | 0.3 | +18.2 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 5.3 | -335.2 | 0.0 | 50.3 | 1.7 | -44.9 | 0.0 | 41.0 |
| ONE PROMISE A TARGET | 1.7 | -189.9 | 0.0 | 0.0 | 1.7 | -86.9 | 0.0 | 0.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 0.7 | +2.7 | 100.7 | 0.0 | - | - | - | - |
| OPENS UP | 0.3 | +9.7 | 21.7 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.3 | +0.7 | 20.0 | 0.0 | 0.3 | +1.0 | 55.0 | 0.0 |
| OWN CAST FIRST | 1.3 | -10.1 | 0.0 | 0.0 | - | - | - | - |
| PATHS CROSS | 0.3 | +7.2 | 0.0 | 0.0 | - | - | - | - |
| PERIAPT WORTH | - | - | - | - | 0.3 | +18.1 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -7.4 | 0.0 | 0.0 |
| PLAN RESULT | 36.3 | +530.4 | 190.3 | 745.7 | 36.0 | +766.8 | 0.0 | 605.3 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 7.7 | -327.8 | 0.0 | 0.0 | 4.7 | -157.8 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 3.3 | -10.6 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 1.3 | -17.1 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 1.3 | +166.7 | 0.0 | 0.0 | 6.3 | +1255.5 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.0 | +74.9 | 0.0 | 70.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 1.3 | +102.9 | 0.0 | 41.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 0.7 | +0.0 | 0.0 | 32.7 |
| REDIRECT WEIGHED | 0.3 | +1.7 | 21.7 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 0.7 | -8.1 | 0.0 | 0.0 | 2.0 | -58.2 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| RISK BY ARC | 3.3 | +143.3 | 56.7 | 77.7 | 2.7 | -30.1 | 252.0 | 0.0 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | 0.3 | -2.1 | 0.0 | 0.0 | 1.0 | -28.9 | 174.3 | 0.0 |
| RUN DOWN | 1.0 | -3.6 | 21.7 | 0.0 | 3.3 | -53.7 | 252.0 | 0.0 |
| SEARCH SPOT | 0.7 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| SECOND LOOK | 0.7 | +34.4 | 0.0 | 77.7 | 0.3 | +1.4 | 77.7 | 0.0 |
| SET CREDITED ONCE | 2.3 | -88.7 | 0.0 | 0.0 | 1.7 | -48.3 | 0.0 | 0.0 |
| SET UP BY THE SET | 3.0 | +97.2 | 0.0 | 0.0 | 1.7 | +98.0 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.3 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| SET-UP ANY TARGET | 1.3 | +250.0 | 0.0 | 0.0 | 0.3 | +50.4 | 0.0 | 0.0 |
| SET-UP MISSED | 0.3 | +58.8 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 16.0 | +0.0 | 0.0 | 215.0 | 4.0 | +0.0 | 0.0 | 43.3 |
| SHOOTS FROM THE BEST SPOT | 6.3 | +286.4 | 235.3 | 0.0 | 2.0 | +21.2 | 0.0 | 43.3 |
| SHOT OR CHARGE | 1.0 | -25.6 | 0.0 | 0.0 | 0.3 | -0.1 | 119.3 | 0.0 |
| SHOT RISK POINTS | 10.7 | -81.5 | 0.0 | 302.0 | 33.0 | +44.7 | 0.0 | 318.0 |
| SHOTS AFTER THE MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 17.0 | +568.9 | 0.0 | 320.0 | 4.3 | +120.3 | 0.0 | 84.3 |
| SPELL SETS UP CHARGE | 1.3 | +250.0 | 0.0 | 0.0 | 0.3 | +50.4 | 0.0 | 0.0 |
| SPELL WORTH | 2.3 | +48.0 | 0.0 | 0.0 | 7.7 | +147.4 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 1.3 | +29.0 | 0.0 | 0.0 | 0.7 | -24.5 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 20.0 |
| STAND AND SHOOT | 0.3 | -2.1 | 21.7 | 0.0 | 1.3 | -24.4 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 6.0 | +0.0 | 119.3 | 0.0 |
| STANDS STILL | 41.3 | +0.0 | 707.3 | 640.0 | 24.7 | +0.0 | 119.3 | 86.7 |
| STAY WORTH | 29.0 | +166.6 | 472.0 | 380.0 | 5.0 | +35.4 | 119.3 | 106.0 |
| STRIKE BY THE ODDS | 0.3 | +0.2 | 0.0 | 77.7 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 70.0 |
| SUPPORT ADDS | 4.0 | +323.6 | 0.0 | 151.0 | 10.3 | +2549.8 | 0.0 | 0.0 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 4.0 | +323.6 | 0.0 | 151.0 | 10.3 | +2549.8 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +1.3 | 0.0 | 0.0 | 0.3 | +6.1 | 0.0 | 13.3 |
| SWIFTSTRIDE BY POINTS | 0.3 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 50.3 | 4.3 | +0.0 | 0.0 | 20.0 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 41.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 37.3 | +0.0 | 0.0 | 705.0 | 34.0 | +0.0 | 0.0 | 293.7 |
| TIED UP BY THE SUM | 1.0 | +72.5 | 56.7 | 0.0 | 0.3 | +53.3 | 55.0 | 0.0 |
| TIME ON OUR SIDE | 33.7 | +539.5 | 0.0 | 878.7 | - | - | - | - |
| WAITS AGAIN | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 0.0 | 100.0 | - | - | - | - |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -5.1 | 155.3 | 0.0 |
| WHO FIGHTS | - | - | - | - | 0.7 | +1.0 | 77.7 | 0.0 |
| WHO HITS BACK | 0.3 | +88.2 | 0.0 | 0.0 | 0.3 | +11.9 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | -4.7 | 77.7 | 0.0 |
| WHOLE FIGHT DANGER | 2.0 | -314.6 | 0.0 | 238.7 | 1.3 | -112.8 | 0.0 | 201.3 |
| WHOLE FIGHT GAIN | 0.7 | +6.1 | 0.0 | 0.0 | 0.3 | +17.5 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 1.3 | +3.9 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p43

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 81 | 81 | 59 | 19.67 | +1143 | +19.4 |
| HOLDER ASSIGNMENT | 53 | 53 | 47 | 15.67 | +2745 | +58.4 |
| HIS SHOT LIST | 210 | 203 | 44 | 14.67 | +1048 | +23.8 |
| FIVE ACTION | 471 | 461 | 33 | 11.00 | +2351 | +71.2 |
| HIS SHOTS BY HIS RUN | 200 | 195 | 26 | 8.67 | +498 | +19.2 |
| DEPLOY BY FIGURES | 42 | 42 | 22 | 7.33 | +452 | +20.5 |
| THE TABLE AGAIN | 36 | 36 | 21 | 7.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 31 | 29 | 20 | 6.67 | +827 | +41.3 |
| OFF BEST | 20 | 20 | 20 | 6.67 | -598 | -29.9 |
| GOAL WALK | 39 | 37 | 18 | 6.00 | +1132 | +62.9 |
| SHOT RISK POINTS | 131 | 127 | 18 | 6.00 | +500 | +27.8 |
| FOUR ROUNDS | 22 | 21 | 15 | 5.00 | +888 | +59.2 |
| NEXT CHARGE BY LIST | 32 | 32 | 15 | 5.00 | +1079 | +71.9 |
| SHOOTS FROM THE BEST SPOT | 25 | 25 | 14 | 4.67 | +38 | +2.7 |
| SUPPORT ADDS | 43 | 41 | 14 | 4.67 | +2751 | +196.5 |
| SUPPORT WORKED OUT | 43 | 41 | 14 | 4.67 | +2751 | +196.5 |
| CAST JOB | 26 | 26 | 13 | 4.33 | +79 | +6.1 |
| OGRE LOADER SECOND SHOT | 13 | 13 | 13 | 4.33 | +118 | +9.1 |
| PROMISE BY ITS OWN SUM | 37 | 37 | 12 | 4.00 | -1457 | -121.4 |
| ONE PROMISE A TARGET | 10 | 10 | 10 | 3.33 | -831 | -83.1 |
| PROMISE KNOWS THE FIGHT | 11 | 10 | 10 | 3.33 | -32 | -3.2 |
| ARTILLERY RE-ROLL WEIGHED | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 9 | 9 | 9 | 3.00 | +225 | +25.0 |
| IDLE COST | 46 | 34 | 8 | 2.67 | +47 | +5.8 |
| HARD STAY DROPPED | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| LANE BY FIGURES | 7 | 7 | 7 | 2.33 | +265 | +37.9 |
| MAX FOR POSITIONING | 32 | 30 | 7 | 2.33 | +82 | +11.7 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CHARGE LOSSES | 94 | 92 | 6 | 2.00 | +226 | +37.7 |
| MARCH BY THE SUM | 6 | 6 | 6 | 2.00 | +572 | +95.4 |
| MARCH OF THE TABLE | 6 | 6 | 6 | 2.00 | -531 | -88.5 |
| MEETS IN TIME | 17 | 17 | 6 | 2.00 | +411 | +68.5 |
| QUARTER ODDS | 23 | 23 | 6 | 2.00 | +538 | +89.6 |
| SHOTS IN THE MOVE | 64 | 55 | 6 | 2.00 | +175 | +29.1 |
| TIME ON OUR SIDE | 101 | 77 | 6 | 2.00 | +14 | +2.3 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | +399 | +79.8 |
| MANOEUVRE | 12 | 12 | 5 | 1.67 | +81 | +16.3 |
| RISK BY ARC | 18 | 17 | 5 | 1.67 | +208 | +41.6 |
| CHARGE NOW FIRST | 18 | 18 | 4 | 1.33 | -209 | -52.2 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +106 | +26.6 |
| MOVE ORDER | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| OWN CAST FIRST | 4 | 4 | 4 | 1.33 | -30 | -7.6 |
| SET UP BY THE SET | 14 | 14 | 4 | 1.33 | +157 | +39.2 |
| TIED UP BY THE SUM | 4 | 4 | 4 | 1.33 | +125 | +31.2 |
| WHOLE FIGHT DANGER | 10 | 10 | 4 | 1.33 | +577 | +144.3 |
| CONTINUE AHEAD WEIGHED | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| COVER ONCE | 45 | 32 | 3 | 1.00 | +32 | +10.8 |
| MARCH CHECK | 4 | 4 | 3 | 1.00 | +196 | +65.2 |
| MISSILES IN THE MOVE | 43 | 32 | 3 | 1.00 | +61 | +20.3 |
| SECOND LOOK | 3 | 3 | 3 | 1.00 | +107 | +35.8 |
| SHOTS AFTER THE MOVES | 19 | 19 | 3 | 1.00 | +0 | +0.0 |
| STAY WORTH | 102 | 96 | 3 | 1.00 | +4 | +1.3 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +85 | +42.4 |
| EXACT ROUND | 14 | 14 | 2 | 0.67 | +4 | +2.1 |
| FALLS SHORT | 70 | 59 | 2 | 0.67 | +0 | +0.0 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| GOAL ROUTE | 2 | 2 | 2 | 0.67 | +7 | +3.6 |
| GUN MASK | 11 | 11 | 2 | 0.67 | +115 | +57.6 |
| HIS TURN DENIED | 7 | 7 | 2 | 0.67 | +45 | +22.4 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +172 | +86.2 |
| REDIRECT FOR A FRIEND IN REACH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| REFUSING RETIRES | 2 | 2 | 2 | 0.67 | -31 | -15.4 |
| SURE REACH TOGETHER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +281 | +140.7 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +31 | +31.2 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +60 | +60.2 |
| BOMBING RUN | 1 | 1 | 1 | 0.33 | +29 | +28.9 |
| CANNON PLANNED TARGET | 27 | 27 | 1 | 0.33 | -12 | -11.8 |
| CANNON SIGHT KEPT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 3 | 3 | 1 | 0.33 | +24 | +24.0 |
| FIGHT TO THE END | 6 | 5 | 1 | 0.33 | +4 | +4.1 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +1 | +1.3 |
| HIS CHARGE DENIED | 1 | 1 | 1 | 0.33 | +41 | +40.6 |
| HUNT IN PAIRS | 12 | 9 | 1 | 0.33 | +34 | +33.7 |
| JOINT LOOK BACK | 1 | 1 | 1 | 0.33 | +23 | +23.1 |
| LOST AFTER ESCAPE | 11 | 10 | 1 | 0.33 | +4 | +4.1 |
| ONE FIGHT FORMULA | 35 | 23 | 1 | 0.33 | +0 | +0.0 |
| ONE JOINT FIGURE | 3 | 2 | 1 | 0.33 | +39 | +39.2 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +17 | +17.0 |
| OVERRUNS AWAY | 2 | 2 | 1 | 0.33 | +0 | +0.1 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +22 | +21.6 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +54 | +54.4 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -22 | -22.2 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +5 | +5.0 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +1 | +0.6 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +1 | +0.6 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -110 | -110.2 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| THE ROW IN ITS ORDER | 12 | 1 | 1 | 0.33 | +0 | +0.0 |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CASTS AFTER FRIENDS | 9 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 6 | 6 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 2 | 2 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 56 | 54 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 11 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 15 | 14 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 33 | not checked | - | - | - | - |
| FOOT FIRST | 51 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 16 | 15 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 5 | 5 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 16 | 16 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 4 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 9 | 8 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 50 | 50 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 28 | 28 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 38 | 38 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 34 | 32 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 4 | 4 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 51 | 50 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 5 | 5 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 74 | 74 | 0 | 0.00 | - | - |
| HONEST WORTH | 18 | 17 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 15 | 15 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 8 | 8 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 48 | 29 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 1 | trace | - | - | - | - |
| MOVE SPELL SPOT | 7 | not checked | - | - | - | - |
| NEARER NOT NEEDED | 24 | 23 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 3 | 3 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 18 | 17 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 21 | 18 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS A LANE | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 217 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 4 | 4 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 8 | 8 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 4 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 13 | 12 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 12 | 12 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 5 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 60 | not checked | - | - | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 5 | not checked | - | - | - | - |
| SPELL WORTH | 30 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 6 | 6 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 35 | 32 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 5 | 5 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 18 | 18 | 0 | 0.00 | - | - |
| STANDS STILL | 198 | 195 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 6 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 16 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 15 | not checked | - | - | - | - |
| THE TABLE BINDS | 214 | not checked | - | - | - | - |
| WAITS AGAIN | 7 | 7 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 2 | 2 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 3 | 2 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 4 | 4 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p43

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.67 | 2.00 | 28.9 |
| PROMISE BY ITS OWN SUM | rule | 3.00 | 1.00 | 121.4 |
| ONE PROMISE A TARGET | rule | 1.67 | 1.33 | 92.7 |
| PROMISE KNOWS THE FIGHT | rule | 3.00 | - | 3.5 |
| ARMY TABLE | rule | 1.00 | 1.67 | 58.3 |
| MARCH OF THE TABLE | rule | 1.00 | 1.00 | 88.5 |
| OWN CAST FIRST | rule | 1.33 | - | 7.6 |
| CHARGE NOW FIRST | rule | 0.67 | 0.33 | 69.5 |
| HOLDER ASSIGNMENT | rule | 1.00 | - | 12.2 |
| REFUSING RETIRES | rule | - | 0.67 | 15.4 |
| RULE SWITCHED OFF | gate | 0.67 | - | 17.6 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 11.8 |
| DEPLOY BY FIGURES | rule | - | 0.33 | 5.9 |
| JOINT CHARGE NOW | rule | 0.33 | - | 11.9 |
| NO REASON | gate | - | 0.33 | 70.9 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 22.2 |
| SUPPORT NARROWED | rule | - | 0.33 | 110.2 |

### Plans: gs3-83c8646-p43

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.0 | 44% | 264 | 68 | 26% |
| Mine | move | 20.0 | 93% | 1367 | 0 | 0% |
| Mine | shoot | 13.3 | 30% | 638 | 462 | 72% |
| Opponent | charge | 2.7 | 62% | 245 | 568 | 232% |
| Opponent | move | 30.3 | 90% | 2647 | 0 | 0% |
| Opponent | shoot | 3.0 | 44% | 23 | 199 | 881% |

### Battle groups: gs3-83c8646-p43

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 1.3 | 50% | 100% | 50% | 0% | 100% | 0% | 0% | 0% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p43

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 8 | 25 (8) | 25 | 0 | 24 | 12% | 1.9 | 58 (1) | 22 (5) | 27 (1) | 29 (6) | 19 (1) |
| Mine | Clean-up | 2 | 427 (2) | 0 | 427 | 0 | 0% | 2.5 | - | 427 (2) | - | 427 (2) | - |
| Mine | Fast Hammer | 2 | 0 (2) | 0 | 0 | 100 | 0% | 1.5 | - | 0 (2) | - | 0 (2) | - |
| Mine | Holder | 3 | 43 (3) | 43 | 0 | 0 | 67% | 4.0 | - | 0 (1) | 73 (2) | 43 (3) | - |
| Mine | Shooter | 3 | 63 (3) | 63 | 0 | 0 | 0% | 1.0 | - | 0 (1) | 81 (2) | 63 (3) | - |
| Mine | War machine | 6 | 0 (6) | 0 | 0 | 41 | 0% | 1.2 | - | 0 (2) | 0 (4) | - | 0 (6) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Chaff | 5 | 96 (5) | 96 | 0 | 75 | 40% | 3.0 | 0 (3) | - | 222 (2) | 0 (4) | 388 (1) |
| Opponent | Character | 6 | 54 (6) | 54 | 0 | 7 | 0% | 2.2 | - | 67 (3) | 45 (2) | 0 (3) | 143 (2) |
| Opponent | Clean-up | 6 | 52 (6) | 0 | 52 | 22 | 33% | 4.5 | 0 (1) | 66 (4) | 0 (1) | 39 (4) | 69 (2) |
| Opponent | Fast Hammer | 4 | 68 (4) | 68 | 0 | 76 | 25% | 2.7 | 132 (2) | 0 (2) | - | 0 (3) | 265 (1) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 28 | 67% | 4.0 | 0 (2) | 0 (1) | - | 0 (3) | - |
| Opponent | Holder | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Shooter | 4 | 41 (4) | 41 | 0 | 35 | 0% | 2.2 | - | 0 (2) | 62 (2) | 49 (3) | 0 (1) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | 0 (1) | - |

### Charged fights: gs3-83c8646-p43

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 2 | 144 | 150 | 2.0 | 1.0 | 75 | 0 | +75 | 0 of 4 | 4 of 4 | - | +75 |
| Mine | High Elf Realms | 1 | 417 | 151 | 1.0 | 1.0 | 151 | 0 | +151 | 0 of 1 | 1 of 1 | - | +151 |
| **Mine** | all armies | 3 | 235 | 150 | 1.7 | 1.0 | 90 | 0 | +90 | 0 of 5 | 5 of 5 | - | +90 |
| Opponent | High Elf Realms | 1 | 0 | 0 | 3.0 | 1.3 | 0 | 0 | +0 | 2 of 3 | 2 of 3 | +0 | +0 |
| Opponent | Skaven | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Vampire Counts | 1 | 0 | 1367 | 4.0 | 1.0 | 342 | 0 | +342 | 2 of 4 | 3 of 4 | - | +342 |
| **Opponent** | all armies | 3 | 0 | 456 | 2.7 | 1.1 | 171 | 0 | +171 | 5 of 8 | 5 of 8 | +0 | +195 |

### Effective charges: gs3-83c8646-p43

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 4 | 0 | 0 | 0 | 0 | 2 (net +52) | 0 | 2 | 0% (0 of 2) |
| Opponent | High Elf Realms | 3 | 1 (net +0) | 0 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 33% (1 of 3) |
| Opponent | Skaven | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Vampire Counts | 4 | 1 (net +819) | 0 | 1 (net +0) | 0 | 0 | 0 | 2 | 50% (1 of 2) |

### Charged fights, damage counted: gs3-83c8646-p43

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 301 | 52 | +52 | 52 | 0 | +52 | +17.4 |
| Mine | No odds | 3 | 317 | 134 | +115 | 121 | 36 | +85 | +26.7 |
| Mine | All fights | 5 | 310 | 102 | +90 | 93 | 22 | +72 | +23.1 |
| Opponent | Long shot (under 50%) | 3 | 328 | 409 | +273 | 311 | 49 | +262 | +80.0 |
| Opponent | Effective (55-75%) | 2 | 126 | 130 | +0 | 35 | 0 | +35 | +27.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 500 | 177 | +0 | 22 | 250 | -228 | -45.6 |
| Opponent | No odds | 2 | 414 | 192 | +274 | 274 | 8 | +266 | +64.2 |
| Opponent | All fights | 8 | 321 | 256 | +171 | 197 | 52 | +145 | +45.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p43 | move | 22 | 6 (27%) | 3 (14%) | 5 (23%) | 11 (50%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1126 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Opal Amulet | Opponent | L1314 |
| Periapt of Soul Exchange | Opponent | L1220 |
| Ring of Doom | Mine | L1126, L1220 |
| Ring of Jet | Mine | L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314 |

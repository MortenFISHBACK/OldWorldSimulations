# Doctrine scorecard: gs3-83c8646-p10

### Scorecard: gs3-83c8646-p10

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1823 | 5 | 1 | Mine | no | - | 6 | 3 | 3 | 1 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 5 | 1 | 2 | 0 | 0 | 132 |
| L1923 | 3 | 1 | Mine | no | 0 | 1 | 6 | 0 | 1 | 0 | 0 | 255 |
| L1923 | 3 | 1 | Opponent | yes | 5 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2025 | 3 | 1 | Mine | yes | 2 | - | 0 | 1 | 0 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 1.0 | 3.5 | 3.0 | 1.3 | 0.7 | 0.0 | 0.0 | 225.0 |
| **Average** | | | Opponent | 67% | 2.5 | 2.0 | 4.0 | 1.0 | 0.7 | 0.0 | 0.0 | 44.0 |

### KPIs: gs3-83c8646-p10

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 14) | 0% (0 of 15) | 0% (0 of 29) |
| Winner chose to follow up after the loser gave ground |  | 75% (3 of 4); on the table 75% | 100% (3 of 3); on the table 100% | 86% (6 of 7); on the table 86% |
| Winner chose to pursue after the loser fell back in good order |  | - | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fled |  | - | 70% (7 of 10); on the table 70% | 70% (7 of 10); on the table 70% |
| Winner chose to follow up or pursue (all three) |  | 75% (3 of 4); on the table 75% | 71% (10 of 14); on the table 71% | 72% (13 of 18); on the table 72% |
| Magic missiles tried each own turn | 50%+ | 17% (5 of 30) | 44% (8 of 18) | 27% (13 of 48) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 28% (5 of 18) | 47% (8 of 17) | 37% (13 of 35) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 33% (1 of 3) | - | 33% (1 of 3) |
| Points that never fought | lower | 29% (1719 of 5999) | 36% (2160 of 5999) | 32% (3879 of 11998) |
|   infantry points that never fought | lower | 70% (696 of 993) | 62% (642 of 1037) | 66% (1338 of 2030) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 59% (13 of 22) | 56% (9 of 16) | 58% (22 of 38) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (1 of 2); 0.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 58% (3011 of 5151) | 52% (2344 of 4500) | 55% (5355 of 9651) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (8%) | 2.7 (80%) | 3.3 (29%) |
| MARCHED: its unit marched | 1.3 (16%) | 0.0 (0%) | 1.3 (11%) |
| CHARGED: its unit charged | 1.3 (16%) | 0.3 (10%) | 1.7 (14%) |
| IN COMBAT: engaged in combat | 2.0 (24%) | 0.3 (10%) | 2.3 (20%) |
| REAR RANK: in a rear rank | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |
| GONE: slain | 1.7 (20%) | 0.0 (0%) | 1.7 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |
| STUPIDITY: Stupidity | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |
| NOT OFFERED: not in the cast list | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 0.7 | 2.0 | 4.3 | 3.0 |
| not cast | 5.7 | 1.3 | 4.0 | 11.7 | 17.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (50%) | 0.0 (0%) | 3.3 (29%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (11%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (14%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.7 (17%) | 2.3 (20%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 1.0 (18%) | 0.0 (0%) | 0.7 (17%) | 0.3 (3%) | 0.0 (0%) |
| GONE: slain | 1.0 (18%) | 0.0 (0%) | 0.7 (17%) | 1.7 (14%) | 1.7 (10%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (6%) | 0.0 (0%) | 0.3 (8%) | 0.3 (3%) | 1.0 (6%) |
| STUPIDITY: Stupidity | 0.3 (6%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.7 (50%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.0 (53%) | 0.0 (0%) | 1.7 (42%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.0 (76%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.3 a game | 1.7 a game | 1.0 a game |
| stood (cast and not dispelled) | 100% (1 of 1) | 80% (4 of 5) | 83% (5 of 6) |
| the unit moved after it | 0% (0 of 1) | 100% (4 of 4) | 80% (4 of 5) |
| it charged on its next turn | 0% (0 of 1) | 25% (1 of 4) | 20% (1 of 5) |
| the enemy charged it first | 100% (1 of 1) | 0% (0 of 4) | 20% (1 of 5) |
| it fought by the end of its next turn | 100% (1 of 1) | 0% (0 of 4) | 20% (1 of 5) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 1) | 0% (0 of 4) | 0% (0 of 5) |
| none of these (no charge, no fight, no charge escaped) | 0% (0 of 1) | 75% (3 of 4) | 60% (3 of 5) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 57% (32 of 56) | 66% (49 of 74) | 62% (81 of 130) |
|   cavalry | - | 93% (13 of 14) | 93% (13 of 14) |
|   character | 100% (6 of 6) | 0% (0 of 19) | 24% (6 of 25) |
|   chariot | 62% (5 of 8) | - | 62% (5 of 8) |
|   infantry | 36% (12 of 33) | 88% (36 of 41) | 65% (48 of 74) |
|   monster | 100% (9 of 9) | - | 100% (9 of 9) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (29%) | 0.0 (0%) | 2.3 (14%) |
| CHARGED: it charged | 0.3 (4%) | 2.0 (24%) | 2.3 (14%) |
| IN COMBAT: it fought this turn or the last | 0.3 (4%) | 1.0 (12%) | 1.3 (8%) |
| NO TARGET IN RANGE | 3.3 (42%) | 3.3 (40%) | 6.7 (41%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (8%) | 1.0 (12%) | 1.7 (10%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (4%) | 1.0 (12%) | 1.3 (8%) |
| SHELTERED: the target was sheltered | 0.7 (8%) | 0.0 (0%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.7 | 2.0 | 64% | 4.0 pts | 19 pts |
| character | 2.0 | 1.0 | 67% | 11.7 pts | 23 pts |
| chariot | 1.7 | 2.0 | 40% | 31.7 pts | 53 pts |
| infantry | 19.0 | 5.3 | 81% | 4.5 pts | 86 pts |
| monster | 3.0 | 1.0 | 67% | 6.1 pts | 18 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 9.7 | 6.3 |
| Charges that made contact a game | 2.3 | 8.0 | 5.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 1.00 declared, 0.50 contact (2 units) | 0.67 declared, 0.33 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 4.00 declared, 4.00 contact (1 units) | 4.00 declared, 4.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.32 declared, 0.25 contact (28 units) | 0.77 declared, 0.63 contact (30 units) | 0.55 declared, 0.45 contact (58 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | - | 67% (2 of 3) | - | 67% (2 of 3) |
| Character in a unit | 100% (1 of 1) | - | - | 100% (1 of 1) |
| Character on its own | 50% (2 of 4) | 50% (2 of 4) | 43% (3 of 7) | 47% (7 of 15) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 67% (4 of 6) | - | - | 67% (4 of 6) |
| Monster | 25% (1 of 4) | 100% (3 of 3) | - | 57% (4 of 7) |
| Monstrous | - | 75% (3 of 4) | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ogre Kingdoms | 1 | 0% (0 of 1); on the table 0% | 17% (1 of 6) | 41% | 71% (5 of 7) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 12) | 0% | 50% (4 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 100% (1 of 1); on the table 100% | 33% (4 of 12) | 45% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 2 | 67% (8 of 12); on the table 67% | 17% (1 of 6) | 33% | 50% (5 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (2 of 2); on the table 100% | 58% (7 of 12) | 42% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p10, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (9) | 67% (2) | 52% (11) |
| ...free all their last turn and able to turn (per game) | 2.33 | 0.67 | 3.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 2.00 | 0.33 | 2.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p10

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.7 | 2.3 |
| Strategy | Charge objectives carried out (made contact) | 100% (4 of 4) | 52% (12 of 23) |
| Strategy | Shoot objectives carried out (shot that target) | 7% (1 of 14) | 77% (17 of 22) |
| Strategy | Support requests answered (helper made contact too) | - | 60% (3 of 5) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 33% (1 of 3) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 0% (0 of 2) |
| Strategy | Joined characters whose unit fought | 0% (0 of 1) | 0% (0 of 3) |
| Strategy | Lone characters that fought | 78% (7 of 9) | 62% (5 of 8) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.3 | 1.0 |
| Movement | Points that never moved of their own | 225.0 | 44.0 |
| Movement | Fights charged into per game | 2.3 | 6.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 4 | 3 of 15, net +187 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 4 | 4 of 15, net +465 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 4 | 1 of 15, net +0 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 4, net +70 | 5 of 15, net +211 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.0 | 18.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 39% (13 of 33) | 24% (13 of 55) |
| Shooting | Points destroyed by shooting units | 15.0 | 29.7 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.3 | 2.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 4) | 17% (1 of 6) |
| Magic | Wounds caused by magic missiles | 3.0 | 0.3 |
| Magic | Wounds caused by other spells | 3.0 | 0.3 |
| Magic | Points destroyed by magic (all spells) | 22.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.0 / 0.0 / 1.7 / 0.0 | 1.7 / 0.7 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 194.3 | 641.3 |
| Combat | Points run down | 0.0 | 339.0 |
| Combat | Net points per charged fight, damage counted | +66 | +221 |
| Combat | Net per 100 charger points, damage counted | +41.5 | +60.7 |
| Combat | First round won (charged fights) | 57% | 89% |
| Combat | Net points per charged fight | +55 | +238 |
| Combat | Net points per supported fight / lone fight | - / +55 | +502 / +163 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 7 | 10 of 18 |
| Game | Points lost | 1504.7 | 232.0 |
| Game | VP from objectives | 396.7 | 903.3 |
| Game | Lone holders (player turns) | 1.0 | 2.5 |

- Mine won / drew / lost: 0 / 0 / 3 of 3 ended games (of 3); mean margin (Mine - Opponent) -1953 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 1737
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p10

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +140.6 | 0.0 | 99.0 | 0.3 | +8.2 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.7 | +145.3 | 0.0 | 0.0 |
| ARMY TABLE | 19.0 | +361.3 | 0.0 | 717.7 | 21.3 | +369.4 | 0.0 | 106.7 |
| ASSAILMENT BY POINTS | 0.3 | +0.1 | 0.0 | 108.7 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +2.5 | 0.0 | 0.0 | 0.7 | +3.0 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -12.1 | 131.0 | 0.0 |
| CAST JOB | 1.7 | +34.9 | 0.0 | 0.0 | 1.3 | +10.3 | 382.7 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 1.0 | +9.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 135.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.3 | +1.3 | 0.0 | 0.0 | 0.7 | +18.7 | 0.0 | 37.0 |
| CHAFF PASSED | - | - | - | - | 0.3 | -1.9 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +4.7 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 16.0 | -1538.5 | 0.0 | 1043.7 | 10.7 | -299.6 | 0.0 | 86.7 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 44.0 | 11.3 | 6.3 | +0.0 | 1630.3 | 22.7 |
| CLOSES ON WHAT IT BEATS | 8.3 | +0.0 | 0.0 | 102.3 | 16.3 | +0.0 | 0.0 | 67.3 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 70.0 | 0.7 | +0.0 | 180.0 | 0.0 |
| CONVEYANCE SEARCH | 0.3 | +22.0 | 0.0 | 135.0 | 1.3 | +70.4 | 0.0 | 0.0 |
| COVER ONCE | 12.3 | -486.0 | 0.0 | 338.3 | 3.7 | -77.2 | 0.0 | 20.0 |
| DENIED BY THE FIGHT | - | - | - | - | 2.0 | -10.3 | 435.0 | 87.7 |
| DEPLOY BY FIGURES | 7.7 | +43.1 | 0.0 | 0.0 | 7.3 | +33.6 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -11.5 | 65.7 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +3.6 | 85.0 | 0.0 |
| EXACT ROUND | 0.7 | +7.7 | 45.3 | 11.3 | 7.3 | +9.8 | 1478.0 | 87.7 |
| FALL BACK GOOD ORDER | 0.7 | +0.0 | 45.3 | 11.3 | 6.3 | +17.8 | 1172.0 | 87.7 |
| FALLS SHORT | 3.7 | +10.9 | 0.0 | 244.7 | 15.7 | +142.7 | 0.0 | 59.7 |
| FEATURE BUFFS | 2.3 | +15.8 | 0.0 | 0.0 | 1.7 | +10.8 | 0.0 | 22.0 |
| FIGHT TO THE END | - | - | - | - | 5.0 | +106.7 | 915.7 | 87.7 |
| FIRE IN ORDER | - | - | - | - | 0.7 | +0.0 | 0.0 | 44.0 |
| FIVE ACTION | 70.0 | +4401.7 | 220.7 | 1816.7 | 104.3 | +8588.3 | 2962.7 | 535.7 |
| FLANK NOT WEIGHED | 15.3 | +0.0 | 0.0 | 587.7 | 4.0 | +0.0 | 0.0 | 23.3 |
| FOLLOW UP WEIGHED | - | - | - | - | 0.7 | +157.0 | 0.0 | 0.0 |
| FOOT FIRST | - | - | - | - | 37.0 | +0.0 | 0.0 | 216.7 |
| FOUR ROUNDS | 1.3 | +4.7 | 67.3 | 29.7 | 10.0 | +1047.2 | 2089.3 | 87.7 |
| FREED FROM HIS FIGHT | 10.0 | +0.0 | 0.0 | 191.7 | - | - | - | - |
| FRIEND SHOOTS FIRST | 2.7 | -43.3 | 0.0 | 45.3 | 2.0 | -11.8 | 156.0 | 0.0 |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.3 | +53.8 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.7 | -4.9 | 148.0 | 0.0 |
| GOAL ROUTE | - | - | - | - | 0.7 | +85.0 | 0.0 | 0.0 |
| GOAL WALK | 12.3 | +1039.5 | 0.0 | 252.7 | 6.7 | +799.7 | 0.0 | 0.0 |
| GUN FIGURES | 3.7 | +80.6 | 95.0 | 43.3 | - | - | - | - |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 8.3 | +0.0 | 0.0 | 191.7 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 15.7 | +0.0 | 0.0 | 1043.7 | 5.3 | +0.0 | 0.0 | 46.7 |
| HIS CHARGE DENIED | - | - | - | - | 1.3 | +20.5 | 218.0 | 0.0 |
| HIS CHARGE LIST | 6.0 | +0.0 | 0.0 | 198.0 | 3.3 | +0.0 | 0.0 | 67.3 |
| HIS LEGAL MOVES | 6.7 | +0.0 | 0.0 | 89.7 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.7 | -3.4 | 0.0 | 101.3 | 8.0 | -90.0 | 0.0 | 118.0 |
| HIS ONE QUARTER | 2.3 | +0.0 | 0.0 | 25.3 | 4.3 | +0.0 | 0.0 | 46.7 |
| HIS OWN BEST MOVE | 9.0 | +0.0 | 0.0 | 101.0 | 10.0 | +0.0 | 0.0 | 30.0 |
| HIS RANDOM MOVE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVER COMES | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 39.3 | +303.7 | 0.0 | 1537.0 | 35.3 | +892.6 | 0.0 | 276.0 |
| HIS SHOTS BY HIS RUN | 37.3 | +152.8 | 0.0 | 1442.3 | 37.0 | +709.3 | 0.0 | 368.0 |
| HIS TURN DENIED | 0.3 | +0.3 | 22.0 | 11.3 | 2.0 | +27.3 | 435.0 | 87.7 |
| HOLD ODDS | 14.3 | +0.0 | 0.0 | 23.3 | 17.0 | +0.0 | 0.0 | 278.0 |
| HOLDER ASSIGNMENT | 8.3 | +538.1 | 0.0 | 11.7 | 9.3 | +751.1 | 0.0 | 128.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -11.9 | 67.3 | 29.7 | 7.0 | -266.9 | 1297.3 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 1.3 | +7.2 | 0.0 | 0.0 |
| IDLE COST | 2.0 | -30.6 | 0.0 | 231.7 | 13.0 | -153.0 | 0.0 | 0.0 |
| JOINT CHARGE NOW | - | - | - | - | 4.3 | +181.8 | 849.7 | 0.0 |
| JOINT LOOK BACK | - | - | - | - | 0.3 | +15.0 | 12.7 | 0.0 |
| KEPT FROM ITS LAST STOP | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +6.3 | 0.0 | 0.0 | 1.7 | +89.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.3 | +0.0 | 88.0 | 345.0 | 10.0 | +0.0 | 542.3 | 237.0 |
| LONE WIZARD KEPT IN | 0.3 | +16.1 | 0.0 | 0.0 | 0.7 | +39.2 | 0.0 | 0.0 |
| LONG SHOT | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 0.3 | -0.0 | 22.0 | 11.3 | 5.7 | +6.3 | 698.7 | 65.0 |
| LOST CHARGE | - | - | - | - | 0.3 | -1.2 | 85.0 | 0.0 |
| MANOEUVRE | 1.3 | -18.3 | 0.0 | 99.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 1.3 | +70.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.7 | +24.7 | 0.0 | 0.0 | 0.3 | +2.7 | 0.0 | 0.0 |
| MARCH OVER CASTS | 1.0 | -46.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.0 | +101.2 | 0.0 | 22.7 | 2.7 | +33.5 | 0.0 | 15.0 |
| MEETS IN TIME | 3.7 | +210.7 | 0.0 | 0.0 | 2.3 | +191.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.7 | +49.8 | 0.0 | 99.0 | 3.0 | +18.9 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 4.3 | +59.1 | 0.0 | 99.0 | 4.0 | +14.3 | 0.0 | 0.0 |
| MOVE ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 22.0 | 42.0 |
| MOVE TO CHARGE COMPUTED | 4.0 | +144.2 | 0.0 | 45.3 | 11.7 | +1064.8 | 0.0 | 30.0 |
| MOVES UNITS SPELL | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 6.3 | +281.1 | 0.0 | 77.3 | 11.3 | +398.3 | 0.0 | 42.0 |
| NEAREST TO GOAL | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 2.7 | +88.6 | 0.0 | 45.3 | 7.3 | +461.7 | 156.0 | 30.0 |
| NO DOUBLE ROUNDS | 1.0 | -9.4 | 45.3 | 18.3 | 8.7 | -428.8 | 1710.0 | 65.0 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 5.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 2.7 | -1.3 | 0.0 | 180.0 | - | - | - | - |
| OFF BEST | 0.7 | -3.3 | 0.0 | 0.0 | 6.0 | -116.3 | 167.7 | 64.0 |
| ONE CHECK AFTER THE LAST CHANGE | 1.3 | +0.0 | 0.0 | 116.7 | - | - | - | - |
| ONE FIGHT FORMULA | 3.7 | -41.4 | 0.0 | 22.7 | 7.7 | -157.9 | 0.0 | 15.0 |
| ONE JOINT FIGURE | - | - | - | - | 2.3 | +465.3 | 725.7 | 22.7 |
| ONE OBJECTIVE FORMULA | 5.3 | -6.8 | 0.0 | 11.7 | 4.3 | -68.1 | 0.0 | 86.0 |
| ONE PROMISE A TARGET | - | - | - | - | 2.0 | -65.7 | 156.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.7 | +25.4 | 36.7 | 0.0 |
| OVERRUNS AWAY | 0.7 | +20.0 | 23.3 | 18.3 | 2.7 | +28.1 | 443.3 | 65.0 |
| PERIAPT WORTH | 0.3 | +18.1 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 34.3 | +85.7 | 103.0 | 1686.7 | 51.0 | +1593.1 | 1004.0 | 464.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 4.0 | -30.9 | 0.0 | 0.0 | 11.3 | -405.1 | 0.0 | 0.0 |
| PROMISE IN STEPS | - | - | - | - | 1.3 | +0.0 | 156.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 4.7 | -7.8 | 156.0 | 0.0 |
| PROMISE READS THE TABLE | 1.3 | -38.8 | 0.0 | 0.0 | 1.0 | -37.7 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | - | - | - | - | 0.3 | -0.9 | 11.3 | 0.0 |
| QUARTER ODDS | 13.7 | +1340.9 | 46.7 | 223.3 | 29.7 | +3747.7 | 1432.3 | 99.3 |
| RANDOM MOVE BY FIGURES | 1.0 | +6.5 | 0.0 | 140.0 | - | - | - | - |
| REAL GROUND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 4.7 | +291.8 | 0.0 | 22.7 | 4.7 | +87.7 | 0.0 | 103.7 |
| REDIRECT FOR A FRIEND IN REACH | 1.3 | +0.0 | 0.0 | 29.7 | 7.0 | +0.0 | 0.0 | 141.3 |
| REDIRECT WEIGHED | - | - | - | - | 0.7 | +31.5 | 70.0 | 0.0 |
| REFORMS TO MEET IT | 0.3 | -0.0 | 0.0 | 0.0 | 2.7 | -90.5 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 1.3 | +20.6 | 0.0 | 44.0 |
| RISK BY ARC | 1.3 | -3.1 | 67.3 | 29.7 | 7.0 | -24.1 | 1433.7 | 65.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 4.3 | -151.3 | 776.7 | 65.0 |
| RUN DOWN | - | - | - | - | 6.7 | -46.5 | 939.7 | 65.0 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | - | - | - | - | 2.0 | +94.4 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 1.3 | +104.5 | 269.7 | 0.0 |
| SELF MOVE SPELL | 1.3 | -2.7 | 0.0 | 108.7 | - | - | - | - |
| SET CREDITED ONCE | 0.3 | -1.9 | 0.0 | 21.7 | 2.3 | -51.2 | 0.0 | 30.0 |
| SET UP BY THE SET | 1.0 | +22.5 | 0.0 | 21.7 | 4.3 | +3.8 | 177.0 | 30.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +6.7 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.7 | +25.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +1.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 4.0 | +0.0 | 0.0 | 139.7 | 7.7 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.7 | +45.8 | 23.3 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | - | - | - | - | 1.3 | -6.9 | 414.0 | 22.7 |
| SHOT RISK POINTS | 14.7 | -113.8 | 0.0 | 275.3 | 27.7 | +137.5 | 0.0 | 278.7 |
| SHOTS AFTER THE MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 11.0 | +268.0 | 0.0 | 261.0 | 16.3 | +209.9 | 0.0 | 148.0 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +6.7 | 0.0 | 0.0 |
| SPELL WORTH | 1.3 | +26.4 | 270.0 | 270.0 | - | - | - | - |
| SPELLS IN THE FIGHT | - | - | - | - | 1.0 | -62.2 | 205.3 | 22.7 |
| SPOT AS THE GAME MOVES | 6.0 | +0.0 | 0.0 | 402.3 | 6.7 | +0.0 | 0.0 | 15.0 |
| STAND AND SHOOT | - | - | - | - | 0.7 | -2.6 | 156.0 | 0.0 |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 22.7 | 0.0 |
| STANDS STILL | 20.7 | +0.0 | 153.3 | 511.0 | 40.0 | +0.0 | 873.3 | 0.0 |
| STAY WORTH | 7.7 | +92.0 | 0.0 | 61.7 | 21.3 | +100.9 | 873.3 | 82.0 |
| STRIKE BY THE ODDS | 0.3 | +0.0 | 0.0 | 78.0 | 1.0 | +65.6 | 262.0 | 65.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 10.7 | +1574.6 | 0.0 | 174.7 | 3.7 | +104.2 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 82.7 | 0.0 |
| SUPPORT WORKED OUT | 10.7 | +1574.6 | 0.0 | 174.7 | 3.7 | +104.2 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 1.0 | +4.4 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +6.1 | 0.0 | 65.7 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 11.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.7 | -26.1 | 0.0 | 0.0 | 1.0 | -107.8 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.7 | +0.0 | 11.7 | 78.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 23.3 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 23.3 |
| THE TABLE AGAIN | 5.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 31.0 | +0.0 | 0.0 | 766.0 | 49.0 | +0.0 | 0.0 | 224.0 |
| TIED UP BY THE SUM | - | - | - | - | 3.7 | +378.7 | 590.7 | 0.0 |
| TIME ON OUR SIDE | 30.3 | +314.2 | 65.0 | 549.3 | 25.7 | +182.3 | 0.0 | 126.0 |
| WAITS AGAIN | 3.3 | +0.0 | 0.0 | 11.3 | 2.3 | +0.0 | 0.0 | 30.0 |
| WAR ENGINE JOBS | 1.3 | +0.0 | 0.0 | 123.3 | - | - | - | - |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -50.1 | 198.0 | 0.0 |
| WHO FIGHTS | 0.7 | -3.7 | 22.0 | 18.3 | 1.7 | +95.9 | 360.3 | 87.7 |
| WHO GETS IN | - | - | - | - | 0.7 | +33.1 | 111.7 | 0.0 |
| WHO HITS BACK | - | - | - | - | 1.3 | +135.1 | 0.0 | 65.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | -5.0 | 99.0 | 0.0 |
| WHOLE FIGHT DANGER | 7.0 | -1421.7 | 0.0 | 864.3 | - | - | - | - |
| WHOLE FIGHT GAIN | - | - | - | - | 2.0 | +40.0 | 488.3 | 0.0 |
| WOUNDS ON THE RANKS | 1.7 | +4.3 | 0.0 | 23.3 | - | - | - | - |

### Rule changes: gs3-83c8646-p10

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 121 | 121 | 73 | 24.33 | +846 | +11.6 |
| FIVE ACTION | 523 | 512 | 47 | 15.67 | +1890 | +40.2 |
| HOLDER ASSIGNMENT | 53 | 53 | 47 | 15.67 | +2238 | +47.6 |
| HIS SHOT LIST | 224 | 220 | 44 | 14.67 | +419 | +9.5 |
| LEGAL CHARGES ONLY | 43 | 43 | 43 | 14.33 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 47 | 43 | 30 | 10.00 | +1239 | +41.3 |
| REDIRECT FOR A FRIEND IN REACH | 25 | 25 | 25 | 8.33 | +0 | +0.0 |
| THE TABLE AGAIN | 35 | 35 | 25 | 8.33 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 223 | 218 | 24 | 8.00 | +183 | +7.6 |
| QUARTER ODDS | 130 | 129 | 22 | 7.33 | +1806 | +82.1 |
| SUPPORT ADDS | 43 | 43 | 21 | 7.00 | +516 | +24.5 |
| SUPPORT WORKED OUT | 43 | 43 | 21 | 7.00 | +516 | +24.5 |
| OFF BEST | 20 | 20 | 20 | 6.67 | -359 | -17.9 |
| DEPLOY BY FIGURES | 45 | 45 | 19 | 6.33 | +155 | +8.1 |
| TIME ON OUR SIDE | 168 | 149 | 17 | 5.67 | +49 | +2.9 |
| GOAL WALK | 57 | 56 | 16 | 5.33 | +1230 | +76.8 |
| MOVE ORDER | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 30 | 26 | 15 | 5.00 | +477 | +31.8 |
| PROMISE BY ITS OWN SUM | 46 | 46 | 15 | 5.00 | -1308 | -87.2 |
| FOUR ROUNDS | 34 | 30 | 14 | 4.67 | +1046 | +74.7 |
| HARD STAY DROPPED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| JOINT CHARGE NOW | 13 | 13 | 13 | 4.33 | +545 | +41.9 |
| SHOT RISK POINTS | 127 | 123 | 11 | 3.67 | +154 | +14.0 |
| CAST JOB | 9 | 9 | 9 | 3.00 | +12 | +1.3 |
| MAX FOR POSITIONING | 20 | 19 | 9 | 3.00 | +34 | +3.8 |
| ADVANCE LANE KEPT | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| MEETS IN TIME | 18 | 18 | 8 | 2.67 | +507 | +63.4 |
| SHOTS IN THE MOVE | 82 | 59 | 8 | 2.67 | +213 | +26.6 |
| SCOUT WAITS | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +286 | +47.6 |
| ONE PROMISE A TARGET | 6 | 6 | 6 | 2.00 | -197 | -32.8 |
| PROMISE KNOWS THE FIGHT | 14 | 12 | 6 | 2.00 | -23 | -3.9 |
| STAY WORTH | 87 | 78 | 6 | 2.00 | +98 | +16.3 |
| TIED UP BY THE SUM | 11 | 9 | 6 | 2.00 | +294 | +49.1 |
| CHARGE NOW FIRST | 23 | 23 | 5 | 1.67 | -282 | -56.3 |
| SHOOTS FROM THE BEST SPOT | 8 | 8 | 5 | 1.67 | +14 | +2.8 |
| CASTER AWAY FROM SCREEN | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| IDLE COST | 45 | 27 | 4 | 1.33 | +72 | +17.9 |
| MARCH BY THE SUM | 4 | 4 | 4 | 1.33 | +212 | +53.0 |
| REDIRECT COUNTER | 28 | 23 | 4 | 1.33 | +235 | +58.7 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +62 | +15.4 |
| RISK BY ARC | 25 | 24 | 4 | 1.33 | +60 | +15.0 |
| SEARCH SPOT | 6 | 6 | 4 | 1.33 | +283 | +70.8 |
| SECOND LOOK | 4 | 4 | 4 | 1.33 | +314 | +78.4 |
| STRIKE BY THE ODDS | 4 | 4 | 4 | 1.33 | +162 | +40.4 |
| WHO HITS BACK | 4 | 4 | 4 | 1.33 | +364 | +91.1 |
| WHOLE FIGHT DANGER | 21 | 21 | 4 | 1.33 | +83 | +20.7 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| COVER ONCE | 48 | 34 | 3 | 1.00 | +6 | +1.9 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +166 | +55.3 |
| ONE JOINT FIGURE | 7 | 7 | 3 | 1.00 | +201 | +67.1 |
| SET UP BY THE SET | 16 | 16 | 3 | 1.00 | +124 | +41.3 |
| SUPPORT NARROWED | 4 | 4 | 3 | 1.00 | -90 | -30.1 |
| SURE REACH TOGETHER | 3 | 3 | 3 | 1.00 | +1 | +0.3 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +446 | +223.2 |
| AFTERMATH WITH FRIENDS | 2 | 2 | 2 | 0.67 | +436 | +217.9 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +14 | +7.1 |
| CHARGE LOSSES | 80 | 78 | 2 | 0.67 | +159 | +79.7 |
| FALLS SHORT | 58 | 48 | 2 | 0.67 | +20 | +9.8 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +471 | +235.5 |
| GOAL ROUTE | 2 | 2 | 2 | 0.67 | +255 | +127.4 |
| OVERRUNS AWAY | 10 | 10 | 2 | 0.67 | +36 | +18.0 |
| PROMISE READS THE TABLE | 7 | 7 | 2 | 0.67 | +1 | +0.6 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +366 | +183.1 |
| SHOTS AFTER THE MOVES | 15 | 15 | 2 | 0.67 | +0 | +0.0 |
| WHO FIGHTS | 7 | 6 | 2 | 0.67 | +165 | +82.3 |
| WHO GETS IN | 2 | 2 | 2 | 0.67 | +99 | +49.7 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.3 |
| CASTING BLOCK | 3 | 3 | 1 | 0.33 | +2 | +1.8 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -6 | -5.6 |
| EXACT ROUND | 24 | 20 | 1 | 0.33 | +6 | +6.5 |
| FIGHT TO THE END | 15 | 12 | 1 | 0.33 | +12 | +11.9 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +161 | +161.4 |
| HIS TURN DENIED | 7 | 7 | 1 | 0.33 | +6 | +6.5 |
| JOINT LOOK BACK | 1 | 1 | 1 | 0.33 | +45 | +45.1 |
| MARCH CHECK | 3 | 3 | 1 | 0.33 | +8 | +8.2 |
| MISSILES IN THE MOVE | 17 | 10 | 1 | 0.33 | +10 | +9.9 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| NEARER NOT NEEDED | 53 | 50 | 1 | 0.33 | +61 | +60.7 |
| NO DOUBLE ROUNDS | 29 | 26 | 1 | 0.33 | +129 | +129.1 |
| ONE FIGHT FORMULA | 34 | 20 | 1 | 0.33 | +10 | +10.2 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +54 | +54.4 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -3 | -2.7 |
| RANDOM MOVE BY FIGURES | 3 | 3 | 1 | 0.33 | +20 | +19.5 |
| SET CREDITED ONCE | 8 | 8 | 1 | 0.33 | +24 | +23.9 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +5 | +5.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +18 | +18.2 |
| THE ROW IN ITS ORDER | 15 | 1 | 1 | 0.33 | +0 | +0.0 |
| BACKUP TARGETS | 3 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 5 | trace | - | - | - | - |
| CHAFF IN THE MOVE | 3 | 2 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 74 | 74 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 5 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 6 | 6 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | not checked | - | - | - | - |
| FALL BACK GOOD ORDER | 21 | 19 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 12 | 12 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 58 | not checked | - | - | - | - |
| FOOT FIRST | 111 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 30 | 30 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 14 | 14 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 11 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 25 | 25 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 63 | 61 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 4 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 28 | 28 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 30 | 30 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 32 | 32 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 20 | 19 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 57 | 55 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 18 | 18 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 6 | 6 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 94 | 94 | 0 | 0.00 | - | - |
| HONEST WORTH | 25 | 21 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 4 | 2 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 4 | 4 | 0 | 0.00 | - | - |
| LONG SHOT | 4 | 4 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 18 | 16 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | not checked | - | - | - | - |
| MANOEUVRE | 6 | 6 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 25 | 14 | 0 | 0.00 | - | - |
| NEAREST TO GOAL | 7 | 6 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 35 | 35 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 8 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 29 | 21 | 0 | 0.00 | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP | 2 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 256 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 4 | 4 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 9 | 8 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 13 | 10 | 0 | 0.00 | - | - |
| RUN DOWN | 20 | 17 | 0 | 0.00 | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 4 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 35 | not checked | - | - | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 4 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 38 | 37 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 5 | 5 | 0 | 0.00 | - | - |
| STANDS STILL | 182 | 180 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE PROMISE ADDS | 5 | 5 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 11 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 10 | not checked | - | - | - | - |
| THE TABLE BINDS | 240 | not checked | - | - | - | - |
| WAITS AGAIN | 17 | 17 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 4 | 4 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 6 | 6 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 5 | 5 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p10

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 0.33 | 5.00 | 13.0 |
| PROMISE BY ITS OWN SUM | rule | 1.00 | 4.00 | 87.2 |
| ARMY TABLE | rule | 2.00 | 1.00 | 52.7 |
| ONE PROMISE A TARGET | rule | - | 2.00 | 32.8 |
| PROMISE KNOWS THE FIGHT | rule | - | 2.00 | 3.9 |
| CHARGE NOW FIRST | rule | - | 1.67 | 56.3 |
| JOINT CHARGE NOW | rule | - | 1.33 | 203.3 |
| NO REASON | gate | - | 1.00 | 48.6 |
| SUPPORT NARROWED | rule | 0.67 | 0.33 | 30.1 |
| AFTERMATH BAND | gate | 0.33 | - | 3.9 |
| CHAFF PASSED | rule | - | 0.33 | 5.6 |
| DEPLOY BY FIGURES | rule | 0.33 | - | 1.1 |
| PROMISE SHOT AWAY | rule | - | 0.33 | 2.7 |

### Plans: gs3-83c8646-p10

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 67% | 41 | 37 | 90% |
| Mine | move | 29.7 | 83% | 2410 | 0 | 0% |
| Mine | shoot | 3.7 | 36% | 285 | 49 | 17% |
| Opponent | charge | 9.3 | 75% | 1726 | 1422 | 82% |
| Opponent | join | 2.3 | 100% | 110 | 0 | 0% |
| Opponent | move | 33.7 | 95% | 1883 | 0 | 0% |
| Opponent | shoot | 5.7 | 59% | 365 | 171 | 47% |

### Battle groups: gs3-83c8646-p10

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.7 | 21% | 67% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 4.7 | 36% | 80% | 20% | 0% | 25% | 0% | 25% | 50% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p10

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 7 | 39 (7) | 39 | 0 | 37 | 43% | 2.0 | 45 (6) | 0 (1) | - | 39 (7) | - |
| Mine | Character | 8 | 10 (8) | 10 | 0 | 99 | 12% | 2.6 | 9 (3) | - | 0 (1) | - | 6 (4) |
| Mine | Clean-up | 4 | 87 (4) | 0 | 87 | 38 | 50% | 5.5 | 85 (2) | 78 (1) | 158 (1) | 172 (1) | 49 (3) |
| Mine | Fast Hammer | 1 | 18 (1) | 18 | 0 | 115 | 0% | 3.0 | 18 (1) | - | - | - | 18 (1) |
| Mine | Hammer | 11 | 12 (11) | 12 | 0 | 82 | 9% | 1.9 | 36 (3) | 0 (7) | 0 (1) | 8 (4) | 15 (7) |
| Mine | Shooter | 3 | 23 (3) | 23 | 0 | 33 | 0% | 2.7 | 35 (2) | 0 (1) | - | 0 (1) | 35 (2) |
| Mine | Wizard | 2 | 1 (2) | 1 | 0 | 126 | 0% | 2.0 | - | - | - | - | - |
| Opponent | Chaff | 8 | 109 (8) | 17 | 92 | 60 | 38% | 1.8 | 210 (2) | 102 (4) | 0 (2) | 157 (5) | 19 (3) |
| Opponent | Character | 8 | 94 (8) | 94 | 0 | 0 | 38% | 2.6 | 60 (5) | 149 (3) | - | 101 (3) | 90 (5) |
| Opponent | Clean-up | 4 | 202 (4) | 202 | 0 | 0 | 0% | 4.0 | 782 (2) | 0 (2) | - | 782 (2) | 0 (2) |
| Opponent | Fast Hammer | 7 | 58 (7) | 58 | 0 | 21 | 29% | 3.0 | 47 (2) | 66 (5) | - | 72 (4) | 47 (3) |
| Opponent | Holder | 4 | 68 (4) | 0 | 68 | 45 | 0% | 1.8 | 150 (2) | - | 0 (2) | 150 (2) | 0 (2) |
| Opponent | Shooter | 4 | 0 (4) | 0 | 0 | 0 | 0% | 1.2 | 0 (2) | 0 (2) | - | 0 (2) | 0 (2) |
| Opponent | Wizard | 3 | 10 (3) | 10 | 0 | 0 | 0% | 2.3 | 18 (1) | 0 (1) | 0 (1) | - | 10 (3) |

### Charged fights: gs3-83c8646-p10

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 1 | 0 | 136 | 3.0 | 1.0 | 45 | 0 | +45 | 1 of 3 | 2 of 3 | - | +45 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 252 | 4.0 | 1.0 | 63 | 0 | +63 | 1 of 4 | 2 of 4 | - | +63 |
| Mine | Skaven | 1 | 113 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 38 | 129 | 2.3 | 1.0 | 55 | 0 | +55 | 2 of 7 | 4 of 7 | - | +55 |
| Opponent | Tomb Kings of Khemri | 2 | 44 | 1625 | 6.0 | 1.3 | 271 | 16 | +255 | 6 of 12 | 11 of 12 | +600 | +140 |
| Opponent | Vampire Counts | 1 | 0 | 1230 | 6.0 | 1.3 | 205 | 0 | +205 | 4 of 6 | 5 of 6 | +210 | +204 |
| **Opponent** | all armies | 3 | 30 | 1493 | 6.0 | 1.3 | 249 | 11 | +238 | 10 of 18 | 16 of 18 | +502 | +163 |

### Effective charges: gs3-83c8646-p10

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 3 | 0 | 0 | 0 | 1 (net +66) | 0 | 1 (net +70) | 1 | 0% (0 of 2) |
| Mine | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 2 (net +33) | 0 | 0 | 2 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 12 | 1 (net +350) | 0 | 4 (net +465) | 0 | 1 (net +0) | 3 (net +90) | 3 | 44% (4 of 9) |
| Opponent | Vampire Counts | 6 | 2 (net +105) | 0 | 0 | 2 (net +118) | 0 | 2 (net +392) | 0 | 0% (0 of 6) |

### Charged fights, damage counted: gs3-83c8646-p10

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 3 | 48 | 66 | +44 | 44 | 11 | +33 | +68.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 185 | 70 | +70 | 70 | 37 | +33 | +17.8 |
| Mine | No odds | 3 | 261 | 312 | +62 | 110 | 0 | +110 | +42.1 |
| Mine | All fights | 7 | 159 | 172 | +55 | 76 | 10 | +66 | +41.5 |
| Opponent | Long shot (under 50%) | 3 | 381 | 333 | +187 | 196 | 54 | +142 | +37.1 |
| Opponent | Effective (55-75%) | 4 | 401 | 293 | +465 | 465 | 43 | +422 | +105.2 |
| Opponent | 76-89% | 2 | 346 | 118 | +118 | 118 | 0 | +118 | +34.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 372 | 231 | +211 | 213 | 6 | +207 | +55.6 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 195 | 40 | +0 | 38 | 11 | +27 | +13.8 |
| Opponent | No odds | 3 | 358 | 204 | +192 | 257 | 65 | +192 | +53.5 |
| Opponent | All fights | 18 | 365 | 234 | +238 | 253 | 32 | +221 | +60.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p10 | move | 23 | 6 (26%) | 5 (22%) | 7 (30%) | 10 (43%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L2025 |
| Elixir of Power | Mine | L1923 |
| Fistful of Laurels | Mine | L1823 |
| Invocation of Nehek | Opponent | L2025 |
| Periapt of Soul Exchange | Mine | L2025 |

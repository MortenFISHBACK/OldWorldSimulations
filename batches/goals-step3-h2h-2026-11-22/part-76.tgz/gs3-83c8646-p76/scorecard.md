# Doctrine scorecard: gs3-83c8646-p76

### Scorecard: gs3-83c8646-p76

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0533 | 5 | 1 | Mine | yes | - | - | 0 | 4 | 0 | 0 | 0 | 1166 |
| L0533 | 5 | 1 | Opponent | no | - | 4 | 1 | 5 | 0 | 0 | 0 | 19 |
| L0620 | 2 | 1 | Mine | - | - | - | 0 | 3 | 0 | 0 | 0 | 761 |
| L0620 | 2 | 1 | Opponent | - | - | - | 0 | 7 | 1 | 0 | 0 | 275 |
| L0709 | 1 | 1 | Mine | yes | 8 | 3 | 1 | 2 | 0 | 0 | 0 | 250 |
| L0709 | 1 | 1 | Opponent | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 583 |
| **Average** | | | Mine | 100% | 8.0 | 3.0 | 0.3 | 3.0 | 0.0 | 0.0 | 0.0 | 725.7 |
| **Average** | | | Opponent | 0% | 0.0 | 4.0 | 0.3 | 5.0 | 0.3 | 0.0 | 0.0 | 292.3 |

### KPIs: gs3-83c8646-p76

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 55% (6 of 11) | 12% (1 of 8) | 37% (7 of 19) |
| Winner chose to follow up after the loser gave ground |  | - | - | - |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | - | - | - |
| Magic missiles tried each own turn | 50%+ | - | 25% (6 of 24) | 25% (6 of 24) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 30% (6 of 20) | 30% (6 of 20) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 73% (8 of 11) | 73% (8 of 11) |
| Points that never fought | lower | 94% (4818 of 5106) | 95% (5684 of 5998) | 95% (10502 of 11104) |
|   infantry points that never fought | lower | 87% (1197 of 1380) | 95% (2050 of 2154) | 92% (3247 of 3534) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 82% (18 of 22) | 76% (22 of 29) | 78% (40 of 51) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game | 50% (1 of 2); 0.2 uses a game |
| Bound items with another spell used |  | 0% (0 of 1); 0.0 uses a game | 1.3 uses a game | 0% (0 of 1); 0.7 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 82% (3156 of 3848) | 68% (3720 of 5432) | 74% (6876 of 9280) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 3.3 (56%) | 3.3 (56%) |
| MARCHED: its unit marched | - | 0.7 (11%) | 0.7 (11%) |
| REAR RANK: in a rear rank | - | 0.7 (11%) | 0.7 (11%) |
| GONE: slain | - | 1.3 (22%) | 1.3 (22%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 6.0 | 2.7 | 2.0 | 0.7 | 0.0 |
| not cast | 2.0 | 1.3 | 6.0 | 1.3 | 12.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (25%) | 3.3 (56%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.7 (11%) | 0.0 (0%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (0%) | 0.7 (11%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 1.3 (22%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (100%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (100%) | 1.0 (75%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.0 (100%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 1.3 a game | 1.3 a game |
| stood (cast and not dispelled) | 25% (1 of 4) | 75% (3 of 4) | 50% (4 of 8) |
| the unit moved after it | 0% (0 of 1) | 100% (3 of 3) | 75% (3 of 4) |
| it charged on its next turn | 0% (0 of 1) | 0% (0 of 3) | 0% (0 of 4) |
| the enemy charged it first | 0% (0 of 1) | 0% (0 of 3) | 0% (0 of 4) |
| it fought by the end of its next turn | 0% (0 of 1) | 0% (0 of 3) | 0% (0 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 1) | 0% (0 of 3) | 0% (0 of 4) |
| none of these (no charge, no fight, no charge escaped) | 100% (1 of 1) | 100% (3 of 3) | 100% (4 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 72% (97 of 135) | 55% (54 of 99) | 65% (151 of 234) |
|   cavalry | 62% (5 of 8) | 22% (2 of 9) | 41% (7 of 17) |
|   character | 96% (25 of 26) | 100% (10 of 10) | 97% (35 of 36) |
|   chariot | - | 83% (5 of 6) | 83% (5 of 6) |
|   infantry | 62% (20 of 32) | 43% (21 of 49) | 51% (41 of 81) |
|   monster | 100% (3 of 3) | 17% (1 of 6) | 44% (4 of 9) |
|   war machine | 67% (44 of 66) | 79% (15 of 19) | 69% (59 of 85) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (13%) | 4.0 (27%) | 5.7 (20%) |
| CHARGED: it charged | 0.0 (0%) | 0.3 (2%) | 0.3 (1%) |
| IN COMBAT: it fought this turn or the last | 0.7 (5%) | 0.7 (4%) | 1.3 (5%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.3 (2%) | 0.3 (1%) |
| NO TARGET IN RANGE | 2.7 (21%) | 1.7 (11%) | 4.3 (16%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (2%) | 0.3 (1%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 6.7 (53%) | 4.7 (31%) | 11.3 (41%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 2.0 (13%) | 2.3 (8%) |
| OTHER BAR | 0.7 (5%) | 1.0 (7%) | 1.7 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| character | 11.7 | 8.3 | 49% | 11.6 pts | 136 pts |
| chariot | 1.7 | 1.0 | 80% | 32.6 pts | 54 pts |
| infantry | 22.7 | 7.0 | 79% | 6.9 pts | 157 pts |
| monster | 1.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 21.7 | 17.7 | 62% | 18.5 pts | 401 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.3 | 0.7 | 0.5 |
| Charges that made contact a game | 0.0 | 0.3 | 0.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | - | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.06 declared, 0.00 contact (18 units) | 0.07 declared, 0.04 contact (27 units) | 0.07 declared, 0.02 contact (45 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 60% (3 of 5) | 100% (1 of 1) | - | 67% (4 of 6) |
| Character in a unit | 100% (8 of 8) | 50% (1 of 2) | 0% (0 of 1) | 82% (9 of 11) |
| Character on its own | 100% (2 of 2) | - | 50% (1 of 2) | 75% (3 of 4) |
| Chariot | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Infantry | 80% (8 of 10) | 86% (6 of 7) | - | 82% (14 of 17) |
| Monster | 100% (1 of 1) | 50% (1 of 2) | - | 67% (2 of 3) |
| Monstrous | 100% (1 of 1) | 100% (1 of 1) | - | 100% (2 of 2) |
| War Machines | 71% (5 of 7) | - | - | 71% (5 of 7) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dwarfen Mountain Holds | 2 | - | - | 93% | 88% (15 of 17) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 2 | - | 25% (3 of 12) | 97% | 76% (13 of 17) | 0.0 uses a game | 0% (0 of 1); 2.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | - | 50% (3 of 6) | 89% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Wood Elf Realms | 1 | - | 0% (0 of 6) | 100% | 80% (8 of 10) | 50% (1 of 2); 1.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p76, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | - | - | - |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p76

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.3 | 0.7 |
| Strategy | Charge objectives carried out (made contact) | 0% (0 of 2) | - |
| Strategy | Shoot objectives carried out (shot that target) | 58% (44 of 76) | 65% (17 of 26) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 8) | 0% (0 of 8) |
| Strategy | Lone characters that fought | 0% (0 of 3) | 0% (0 of 4) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 3.0 | 5.0 |
| Movement | Points that never moved of their own | 725.7 | 292.3 |
| Movement | Fights charged into per game | 0.3 | 0.0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 18.0 | 13.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 63% (34 of 54) | 27% (11 of 41) |
| Shooting | Points destroyed by shooting units | 93.7 | 76.0 |
| Shooting | War machine shots | 14.7 | 6.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (22 of 44) | 20% (4 of 20) |
| Shooting | Points destroyed by war machines | 250.7 | 0.0 |
| Magic | Magic missiles cast | - | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 0% (0 of 3) |
| Magic | Wounds caused by magic missiles | - | 1.0 |
| Magic | Wounds caused by other spells | - | 0.7 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 20.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 4.0 / 0.0 / 0.0 / 0.7 |
| Combat | Points destroyed in combat | 0.0 | 35.0 |
| Combat | Points run down | 172.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +48 | - |
| Combat | Net per 100 charger points, damage counted | +34.3 | - |
| Combat | First round won (charged fights) | 100% | - |
| Combat | Net points per charged fight | +0 | - |
| Combat | Net points per supported fight / lone fight | - / +0 | - / - |
| Combat | Charged fights on a top-3 enemy unit | 0 of 1 | - |
| Game | Points lost | 172.7 | 618.3 |
| Game | VP from objectives | 570.0 | 616.7 |
| Game | Lone holders (player turns) | 8.0 | 0.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +451 VP
- The side that went first won 2 of 2 games with a winner
- Points traded per game (both sides' losses): 791
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p76

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 5.0 | +181.6 | 0.0 | 69.3 | 19.3 | +24.8 | 0.0 | 157.3 |
| ARTILLERY RE-ROLL WEIGHED | 3.3 | +0.0 | 0.0 | 83.3 | 1.0 | +0.0 | 0.0 | 83.3 |
| BACKUP TARGETS | 0.7 | +1.4 | 0.0 | 20.0 | - | - | - | - |
| BEST PRIZE | 0.3 | -88.9 | 34.7 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.3 | +0.0 | 21.7 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 16.7 | +439.5 | 1249.3 | 125.0 | 3.3 | +139.9 | 0.0 | 166.7 |
| CANNON SIGHT KEPT | 3.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.3 | +0.0 | 79.7 | 0.0 | - | - | - | - |
| CAST JOB | - | - | - | - | 2.0 | +6.2 | 135.0 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | - | - | - | - | 0.7 | +9.6 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CHARACTER GUNS | 6.0 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 159.3 |
| CHARGE LOSSES | 16.3 | -575.7 | 0.0 | 132.7 | 21.3 | -826.7 | 0.0 | 664.7 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 79.7 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 7.0 | +0.0 | 0.0 | 0.0 | 13.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 1.3 | +195.5 | 0.0 | 0.0 | 0.3 | +4.9 | 0.0 | 0.0 |
| COVER ONCE | 1.3 | -59.4 | 0.0 | 0.0 | 8.0 | -577.9 | 0.0 | 79.7 |
| DEPLOY BY FIGURES | 11.0 | -163.1 | 0.0 | 0.0 | 8.0 | -10.1 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 2.7 | +339.7 | 48.7 | 236.0 |
| EXACT ROUND | 0.3 | +4.5 | 79.7 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 0.3 | +0.0 | 79.7 | 0.0 | - | - | - | - |
| FALLS SHORT | 9.0 | +82.6 | 0.0 | 104.0 | 18.7 | +242.6 | 0.0 | 112.7 |
| FEATURE BUFFS | - | - | - | - | 2.0 | +5.4 | 0.0 | 159.3 |
| FIGHT TO THE END | 0.3 | -2.6 | 79.7 | 0.0 | - | - | - | - |
| FIRE IN ORDER | 0.7 | +0.0 | 69.3 | 0.0 | - | - | - | - |
| FIVE ACTION | 128.7 | +6396.5 | 3894.7 | 984.7 | 89.3 | +3864.9 | 179.3 | 1192.7 |
| FLANK NOT WEIGHED | 1.0 | +0.0 | 0.0 | 24.3 | 6.3 | +0.0 | 0.0 | 129.3 |
| FOLLOW UP WEIGHED | 0.3 | +26.3 | 0.0 | 0.0 | - | - | - | - |
| FOOT FIRST | 22.0 | +0.0 | 0.0 | 335.3 | - | - | - | - |
| FOUR ROUNDS | 0.7 | +46.9 | 159.3 | 0.0 | - | - | - | - |
| FREED FROM HIS FIGHT | - | - | - | - | 4.0 | +0.0 | 0.0 | 208.0 |
| FRIEND SHOOTS FIRST | 2.3 | -74.4 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.3 | +3.6 | 0.0 | 0.0 | - | - | - | - |
| GOAL ROUTE | 0.7 | +35.5 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 9.3 | +1083.1 | 0.0 | 0.0 | 11.0 | +512.9 | 0.0 | 159.3 |
| GUN FIGURES | 0.7 | +0.0 | 0.0 | 0.0 | 2.7 | +16.3 | 95.0 | 0.0 |
| GUN MASK | 1.3 | +20.1 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 6.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | 0.3 | +0.0 | 79.7 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 3.3 | +0.0 | 0.0 | 0.0 | 10.3 | +0.0 | 0.0 | 368.7 |
| HIS CHARGE LIST | 1.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.3 | +0.0 | 0.0 | 80.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 5.0 | -126.5 | 0.0 | 0.0 | 1.3 | -5.9 | 0.0 | 0.0 |
| HIS ONE QUARTER | 8.0 | +0.0 | 0.0 | 63.3 | 1.3 | +0.0 | 0.0 | 157.3 |
| HIS OWN BEST MOVE | 3.3 | +0.0 | 0.0 | 80.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 12.0 | +0.0 | 0.0 | 150.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 57.3 | +3614.6 | 0.0 | 444.7 | 60.0 | +4936.9 | 0.0 | 700.0 |
| HIS SHOTS BY HIS RUN | 36.0 | +1628.6 | 0.0 | 334.7 | 37.0 | +675.9 | 0.0 | 720.7 |
| HIS TURN DENIED | 0.7 | +5.9 | 159.3 | 0.0 | - | - | - | - |
| HOLD ODDS | 11.0 | +0.0 | 0.0 | 138.7 | 15.3 | +0.0 | 0.0 | 318.7 |
| HOLDER ASSIGNMENT | 6.7 | +755.3 | 0.0 | 69.3 | 7.7 | +844.8 | 0.0 | 79.7 |
| HONEST WORTH | 0.7 | -8.2 | 159.3 | 0.0 | - | - | - | - |
| IDLE COST | 4.7 | -51.6 | 0.0 | 0.0 | 12.0 | -184.2 | 0.0 | 28.0 |
| JOINT CHARGE NOW | 0.7 | +145.2 | 159.3 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 4.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +18.9 | 0.0 | 0.0 | - | - | - | - |
| LATE ONLY FROM HERE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.3 | +0.0 | 111.0 | 0.0 | 0.7 | +0.0 | 0.0 | 69.3 |
| LONE WIZARD KEPT IN | - | - | - | - | 1.0 | +89.6 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.3 | -3.1 | 79.7 | 0.0 | - | - | - | - |
| MANOEUVRE | 1.7 | -27.0 | 0.0 | 0.0 | 2.0 | -5.5 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.7 | +13.0 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 0.7 | +13.8 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +54.9 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 0.7 | -18.9 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 0.7 | +9.6 | 0.0 | 0.0 | - | - | - | - |
| MEETS IN TIME | 5.3 | +70.8 | 0.0 | 0.0 | 3.0 | +88.2 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | - | - | - | - | 4.7 | +51.6 | 0.0 | 149.0 |
| MISSILES NEXT TURN | - | - | - | - | 6.3 | +66.2 | 0.0 | 149.0 |
| MODEL FACING | 1.3 | +217.5 | 0.0 | 40.0 | - | - | - | - |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 2.0 | +67.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -11.2 | 0.0 | 0.0 | 1.0 | -43.4 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 3.3 | +160.3 | 0.0 | 40.0 | - | - | - | - |
| NEARER NOT NEEDED | 9.3 | +437.5 | 0.0 | 34.7 | 10.3 | +420.0 | 0.0 | 104.0 |
| NEAREST TO GOAL | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 2.0 | +117.5 | 0.0 | 0.0 | - | - | - | - |
| NEXT OBJECTIVE NEARER | 0.3 | -10.0 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 0.3 | -13.1 | 79.7 | 0.0 | - | - | - | - |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 2.0 | -0.8 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 2.3 | -89.7 | 0.0 | 34.7 | 3.3 | -129.6 | 0.0 | 83.3 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 3.3 | -50.2 | 0.0 | 20.0 | 0.3 | -6.2 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 0.3 | +21.9 | 79.7 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 1.3 | +40.0 | 0.0 | 34.7 | 4.3 | +87.3 | 0.0 | 79.7 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| PLAN RESULT | 56.7 | +1264.4 | 997.3 | 567.3 | 41.0 | +325.3 | 76.3 | 1025.0 |
| PROMISE BY ITS OWN SUM | 4.7 | -42.8 | 0.0 | 40.0 | - | - | - | - |
| PROMISE READS THE TABLE | 1.7 | -1.6 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | 1.3 | -13.6 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 26.0 | +1975.3 | 1071.3 | 362.7 | 12.0 | +1502.0 | 0.0 | 240.7 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.7 | +219.0 | 0.0 | 140.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | 0.3 | -88.9 | 34.7 | 0.0 | - | - | - | - |
| RISK BY ARC | 0.7 | -64.4 | 159.3 | 0.0 | - | - | - | - |
| RUN DOWN | 0.3 | -0.4 | 79.7 | 0.0 | - | - | - | - |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SET CREDITED ONCE | 1.7 | -56.0 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 2.3 | +74.2 | 0.0 | 0.0 | - | - | - | - |
| SET UP TOGETHER | 1.0 | +14.4 | 0.0 | 0.0 | - | - | - | - |
| SET-UP ANY TARGET | 0.3 | +18.6 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 1.3 | +2.7 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 26.3 | +0.0 | 0.0 | 208.3 | 7.7 | +0.0 | 0.0 | 166.7 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +14.2 | 83.3 | 0.0 | 3.0 | +70.4 | 20.0 | 0.0 |
| SHORT GUN FORWARD | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 40.0 | +764.9 | 0.0 | 306.0 | 32.3 | +65.7 | 0.0 | 708.0 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 32.0 | +1355.1 | 0.0 | 437.7 | 16.3 | +591.9 | 0.0 | 350.3 |
| SPELL SETS UP CHARGE | 0.3 | +18.6 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | - | - | - | - | 6.0 | +155.2 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 4.7 | +0.0 | 0.0 | 20.0 | 5.0 | +0.0 | 0.0 | 6.3 |
| STANDS FOR A REASON | - | - | - | - | 4.3 | +0.0 | 159.3 | 0.0 |
| STANDS STILL | 91.7 | +0.0 | 3735.3 | 696.0 | 33.7 | +0.0 | 179.3 | 655.3 |
| STAY WORTH | 68.0 | +938.6 | 2082.0 | 732.3 | 20.7 | -11.6 | 79.3 | 557.7 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 0.7 | +10.2 | 0.0 | 40.0 | 0.7 | +2.3 | 0.0 | 69.3 |
| SUPPORT WORKED OUT | 0.7 | +10.2 | 0.0 | 40.0 | 0.7 | +2.3 | 0.0 | 69.3 |
| SURE REACH TOGETHER | 0.3 | +19.1 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 0.7 | +0.0 | 0.0 | 35.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 0.3 | +0.0 | 0.0 | 35.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 55.3 | +0.0 | 0.0 | 387.3 | 40.0 | +0.0 | 0.0 | 491.7 |
| TIME ON OUR SIDE | 43.7 | +376.6 | 291.3 | 221.0 | 15.3 | +154.5 | 0.0 | 391.7 |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.3 | -4.5 | 79.7 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 0.7 | -47.9 | 0.0 | 0.0 | 1.0 | -88.0 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | 0.3 | +32.1 | 79.7 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 2.0 | +38.9 | 0.0 | 0.0 | 5.3 | +132.3 | 0.0 | 159.3 |

### Rule changes: gs3-83c8646-p76

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 352 | 346 | 84 | 28.00 | +1899 | +22.6 |
| ARMY TABLE | 73 | 73 | 55 | 18.33 | +529 | +9.6 |
| HIS SHOTS BY HIS RUN | 219 | 215 | 49 | 16.33 | +1152 | +23.5 |
| HOLDER ASSIGNMENT | 43 | 43 | 40 | 13.33 | +2899 | +72.5 |
| DEPLOY BY FIGURES | 57 | 57 | 39 | 13.00 | +626 | +16.0 |
| SHOT RISK POINTS | 217 | 212 | 37 | 12.33 | +1635 | +44.2 |
| HARD STAY DROPPED | 22 | 22 | 22 | 7.33 | +0 | +0.0 |
| GOAL WALK | 61 | 60 | 18 | 6.00 | +1275 | +70.8 |
| QUARTER ODDS | 114 | 114 | 18 | 6.00 | +1292 | +71.8 |
| OFF BEST | 17 | 17 | 17 | 5.67 | -658 | -38.7 |
| TIME ON OUR SIDE | 177 | 172 | 16 | 5.33 | +59 | +3.7 |
| ARTILLERY RE-ROLL WEIGHED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| CANNON SIGHT KEPT | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| CHARGE LOSSES | 113 | 111 | 12 | 4.00 | +676 | +56.4 |
| FIVE ACTION | 654 | 648 | 11 | 3.67 | +923 | +83.9 |
| IDLE COST | 50 | 40 | 11 | 3.67 | +96 | +8.7 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 11 | 3.67 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| MEETS IN TIME | 25 | 25 | 9 | 3.00 | +196 | +21.7 |
| EVASIVE BY THE ODDS | 8 | 8 | 8 | 2.67 | +1019 | +127.4 |
| RANDOM MOVE BY FIGURES | 11 | 11 | 8 | 2.67 | +657 | +82.2 |
| STAY WORTH | 266 | 248 | 8 | 2.67 | +30 | +3.8 |
| CANNON PLANNED TARGET | 60 | 60 | 6 | 2.00 | +2 | +0.3 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 5 | 5 | 5 | 1.67 | +10 | +2.0 |
| SHOOTS FROM THE BEST SPOT | 11 | 11 | 5 | 1.67 | +98 | +19.6 |
| CAST JOB | 6 | 6 | 4 | 1.33 | +0 | +0.0 |
| FALLS SHORT | 83 | 69 | 4 | 1.33 | +0 | +0.0 |
| MODEL FACING | 4 | 4 | 4 | 1.33 | +653 | +163.2 |
| MOVE TO CHARGE COMPUTED | 10 | 8 | 4 | 1.33 | +118 | +29.4 |
| NEARER NOT NEEDED | 59 | 59 | 4 | 1.33 | +106 | +26.5 |
| PROMISE BY ITS OWN SUM | 14 | 14 | 4 | 1.33 | -128 | -32.1 |
| PROMISE SHOT AWAY | 4 | 4 | 4 | 1.33 | -41 | -10.2 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 145 | 116 | 4 | 1.33 | +101 | +25.1 |
| WOUNDS ON THE RANKS | 22 | 22 | 4 | 1.33 | +87 | +21.7 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +269 | +89.6 |
| SHORT GUN FORWARD | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CASTING BLOCK | 2 | 2 | 2 | 0.67 | +5 | +2.6 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| GUN MASK | 4 | 4 | 2 | 0.67 | +19 | +9.3 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +436 | +217.8 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +39 | +19.5 |
| NEXT CHARGE BY LIST | 6 | 6 | 2 | 0.67 | +49 | +24.7 |
| SET UP BY THE SET | 7 | 5 | 2 | 0.67 | +35 | +17.5 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -267 | -266.6 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 1 | 1 | 1 | 0.33 | -78 | -77.7 |
| COVER ONCE | 28 | 24 | 1 | 0.33 | +20 | +19.6 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +79 | +78.8 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +11 | +11.0 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| LANE BY FIGURES | 1 | 1 | 1 | 0.33 | +57 | +56.6 |
| MANOEUVRE | 11 | 11 | 1 | 0.33 | +7 | +6.6 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -165 | -164.8 |
| MISSILES IN THE MOVE | 14 | 7 | 1 | 0.33 | +6 | +5.9 |
| MOVE SPELL IN RANGE | 6 | 4 | 1 | 0.33 | +2 | +2.2 |
| NEXT OBJECTIVE NEARER | 1 | 1 | 1 | 0.33 | +7 | +6.6 |
| ONE OBJECTIVE FORMULA | 17 | 10 | 1 | 0.33 | +171 | +170.8 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | -86 | -85.5 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +52 | +51.7 |
| BACKUP TARGETS | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 4 | trace | - | - | - | - |
| CHARACTER GUNS | 37 | 37 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 60 | 60 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 5 | not checked | - | - | - | - |
| EXACT ROUND | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 6 | 6 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 22 | not checked | - | - | - | - |
| FOOT FIRST | 66 | not checked | - | - | - | - |
| FOUR ROUNDS | 2 | 2 | 0 | 0.00 | - | - |
| FREED FROM HIS FIGHT | 12 | 12 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 7 | 5 | 0 | 0.00 | - | - |
| GOAL ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 10 | not checked | - | - | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 41 | 40 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 22 | 22 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 13 | 10 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 19 | 18 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 28 | 28 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 13 | 10 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 36 | 36 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 2 | 2 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HOLD ODDS | 79 | 79 | 0 | 0.00 | - | - |
| HONEST WORTH | 2 | 2 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 17 | 17 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH CHECK | 2 | 2 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MAX FOR POSITIONING | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 19 | 13 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 4 | trace | - | - | - | - |
| NEAREST TO GOAL | 5 | 5 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 1 | 1 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 6 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 11 | 9 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 293 | trace | - | - | - | - |
| PROMISE READS THE TABLE | 5 | 5 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| RISK BY ARC | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 5 | 3 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 3 | 3 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 102 | not checked | - | - | - | - |
| SHOTS AFTER THE MOVES | 27 | 27 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 18 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 29 | 25 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 13 | 13 | 0 | 0.00 | - | - |
| STANDS STILL | 376 | 374 | 0 | 0.00 | - | - |
| SUPPORT ADDS | 4 | 4 | 0 | 0.00 | - | - |
| SUPPORT WORKED OUT | 4 | 4 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 12 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 14 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 17 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 11 | not checked | - | - | - | - |
| THE TABLE BINDS | 286 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 5 | 5 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p76

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.00 | 3.33 | 34.3 |
| ARMY TABLE | rule | 0.67 | 2.33 | 88.1 |
| HOLDER ASSIGNMENT | rule | 0.67 | 1.00 | 8.0 |
| PROMISE BY ITS OWN SUM | rule | 1.33 | - | 32.1 |
| PROMISE SHOT AWAY | rule | 1.33 | - | 10.2 |
| BEST PRIZE | rule | 0.33 | - | 266.6 |
| CHARGE NOW FIRST | rule | 0.33 | - | 77.7 |
| MARCH OF THE TABLE | rule | - | 0.33 | 164.8 |
| NO REASON | gate | 0.33 | - | 108.8 |
| REDIRECT WEIGHED | rule | 0.33 | - | 85.5 |

### Plans: gs3-83c8646-p76

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.7 | 100% | 82 | 126 | 154% |
| Mine | join | 2.0 | 100% | 68 | 0 | 0% |
| Mine | move | 32.7 | 97% | 1677 | 0 | 0% |
| Mine | shoot | 21.3 | 66% | 679 | 1138 | 168% |
| Opponent | move | 33.0 | 93% | 1310 | 0 | 0% |
| Opponent | shoot | 8.0 | 46% | 288 | 325 | 113% |

### Deployment: positions vs output by unit type: gs3-83c8646-p76

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Character | 11 | 15 (11) | 15 | 0 | 5 | 36% | 2.4 | 0 (2) | 21 (9) | - | 18 (8) | 0 (3) |
| Mine | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 0% | 1.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 4 | 121 (4) | 71 | 50 | 0 | 100% | - | 0 (1) | 0 (1) | 293 (2) | 67 (3) | 273 (1) |
| Mine | Hammer | 5 | 0 (5) | 0 | 0 | 0 | 80% | 2.0 | 0 (1) | 0 (4) | - | 0 (3) | 0 (2) |
| Mine | Shooter | 5 | 0 (5) | 0 | 0 | 23 | 0% | 1.6 | 0 (2) | 0 (3) | - | 0 (5) | - |
| Mine | War machine | 11 | 46 (11) | 46 | 0 | 9 | 18% | 1.2 | 45 (6) | 48 (5) | - | 119 (2) | 31 (9) |
| Opponent | Chaff | 2 | 0 (2) | 0 | 0 | 100 | 100% | - | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Character | 8 | 9 (8) | 9 | 0 | 15 | 38% | 2.0 | 0 (2) | 13 (4) | 0 (1) | 14 (4) | 0 (3) |
| Opponent | Clean-up | 4 | 0 (4) | 0 | 0 | 35 | 100% | - | - | 0 (3) | 0 (1) | 0 (2) | 0 (2) |
| Opponent | Fast Hammer | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Hammer | 6 | 8 (6) | 8 | 0 | 16 | 50% | 3.0 | 0 (3) | 15 (3) | - | 12 (4) | 0 (2) |
| Opponent | Holder | 5 | 273 (5) | 0 | 273 | 22 | 60% | 3.0 | 0 (2) | 441 (2) | 288 (1) | 352 (4) | 0 (1) |
| Opponent | Shooter | 7 | 16 (7) | 16 | 0 | 85 | 14% | 2.5 | 0 (1) | 24 (2) | 18 (4) | 16 (3) | 16 (4) |
| Opponent | War machine | 3 | 33 (3) | 33 | 0 | 100 | 0% | 1.0 | - | - | 33 (3) | - | 33 (3) |
| Opponent | Wizard | 4 | 0 (4) | 0 | 0 | 15 | 25% | 2.0 | 0 (2) | 0 (1) | - | 0 (1) | 0 (2) |

### Charged fights: gs3-83c8646-p76

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 2 | 369 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Empire of Man | 1 | 295 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| **Mine** | all armies | 3 | 344 | 0 | 0.3 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Empire of Man | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Skaven | 1 | 120 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Wood Elf Realms | 1 | 168 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 96 | 0 | 0.0 | - | - | - | - | - | - | - | - |


### Charged fights, damage counted: gs3-83c8646-p76

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | No odds | 1 | 140 | 104 | +0 | 48 | 0 | +48 | +34.3 |
| Mine | All fights | 1 | 140 | 104 | +0 | 48 | 0 | +48 | +34.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p76 | move | 7 | 1 (14%) | 0 (0%) | 0 (0%) | 6 (86%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Horn of the Wild Hunt | Opponent | L0533 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Opponent | L0533 |
| Twice-Blessed Armour | Mine | L0709 |
| Witch Hunter's Ward | Mine | L0709 |

# Doctrine scorecard: gs3-83c8646-p56

### Scorecard: gs3-83c8646-p56

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1319 | 5 | 1 | Mine | no | - | 5 | 2 | 1 | 0 | 0 | 0 | 140 |
| L1319 | 5 | 1 | Opponent | no | - | 2 | 2 | 5 | 0 | 0 | 0 | 647 |
| L1335 | 3 | 1 | Mine | no | 7 | 2 | 2 | 0 | 0 | 0 | 0 | 540 |
| L1335 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 110 |
| L1431 | 3 | 1 | Mine | yes | 5 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 0 | 3 | 1 | 1 | 2 | 0 | 0 | 170 |
| **Average** | | | Mine | 33% | 6.0 | 3.0 | 3.3 | 0.7 | 0.0 | 0.0 | 0.0 | 226.7 |
| **Average** | | | Opponent | 0% | 0.0 | 2.3 | 2.3 | 2.3 | 0.7 | 0.0 | 0.0 | 309.0 |

### KPIs: gs3-83c8646-p56

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 8% (1 of 13) | 0% (0 of 12) | 4% (1 of 25) |
| Winner chose to follow up after the loser gave ground |  | 33% (1 of 3); on the table 33% | 100% (2 of 2); on the table 100% | 60% (3 of 5); on the table 60% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 4); on the table 50% | - | 0% (0 of 4); on the table 50% |
| Winner chose to pursue after the loser fled |  | 50% (2 of 4); on the table 50% | - | 50% (2 of 4); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 27% (3 of 11); on the table 45% | 100% (2 of 2); on the table 100% | 38% (5 of 13); on the table 54% |
| Magic missiles tried each own turn | 50%+ | 17% (3 of 18) | 46% (11 of 24) | 33% (14 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 23% (3 of 13) | 52% (11 of 21) | 41% (14 of 34) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 50% (5 of 10) | 50% (5 of 10) |
| Points that never fought | lower | 49% (2917 of 6000) | 34% (2058 of 6000) | 41% (4975 of 12000) |
|   infantry points that never fought | lower | 83% (1085 of 1315) | 35% (325 of 921) | 63% (1410 of 2236) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 48% (12 of 25) | 75% (24 of 32) | 63% (36 of 57) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 4.0 uses a game | 50% (1 of 2); 0.7 uses a game | 75% (3 of 4); 2.3 uses a game |
| Bound items with another spell used |  | 30% (3 of 10); 2.7 uses a game | 0.0 uses a game | 30% (3 of 10); 1.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 47% (2691 of 5720) | 72% (4201 of 5830) | 60% (6892 of 11550) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.3 (47%) | 1.7 (38%) | 4.0 (43%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.7 (15%) | 0.7 (7%) |
| CHARGED: its unit charged | 1.0 (20%) | 0.7 (15%) | 1.7 (18%) |
| IN COMBAT: engaged in combat | 1.0 (20%) | 0.3 (8%) | 1.3 (14%) |
| FLEEING: fleeing | 0.3 (7%) | 0.0 (0%) | 0.3 (4%) |
| GONE: slain | 0.3 (7%) | 0.0 (0%) | 0.3 (4%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.7 (15%) | 0.7 (7%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (8%) | 0.3 (4%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.3 | 1.3 | 2.7 | 4.7 | 0.0 | 4.3 |
| not cast | 2.7 | 2.7 | 3.3 | 9.3 | 2.0 | 19.7 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (75%) | 0.3 (10%) | 4.0 (43%) | 0.7 (33%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (7%) | 0.0 (0%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (18%) | 0.7 (33%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (12%) | 0.3 (10%) | 1.3 (14%) | 0.7 (33%) | 0.0 (0%) |
| FLEEING: fleeing | 0.3 (12%) | 0.0 (0%) | 0.3 (10%) | 0.3 (4%) | 0.0 (0%) | 1.0 (5%) |
| GONE: slain | 0.3 (12%) | 0.0 (0%) | 0.3 (10%) | 0.3 (4%) | 0.0 (0%) | 0.7 (3%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (7%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (12%) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (75%) | 0.0 (0%) | 2.0 (60%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.0 (92%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.3 a game | 0.3 a game | 1.3 a game |
| stood (cast and not dispelled) | 86% (6 of 7) | - | 86% (6 of 7) |
| the unit moved after it | 0% (0 of 6) | - | 0% (0 of 6) |
| it charged on its next turn | 0% (0 of 6) | - | 0% (0 of 6) |
| the enemy charged it first | 33% (2 of 6) | - | 33% (2 of 6) |
| it fought by the end of its next turn | 17% (1 of 6) | - | 17% (1 of 6) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 6) | - | 0% (0 of 6) |
| none of these (no charge, no fight, no charge escaped) | 67% (4 of 6) | - | 67% (4 of 6) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (61 of 96) | 68% (17 of 25) | 64% (78 of 121) |
|   cavalry | 58% (7 of 12) | 83% (10 of 12) | 71% (17 of 24) |
|   character | 32% (11 of 34) | 20% (1 of 5) | 31% (12 of 39) |
|   infantry | 77% (23 of 30) | 75% (6 of 8) | 76% (29 of 38) |
|   war machine | 100% (20 of 20) | - | 100% (20 of 20) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.3 (11%) | 1.0 (38%) | 2.3 (16%) |
| CHARGED: it charged | 2.7 (23%) | 1.7 (62%) | 4.3 (30%) |
| FLEEING: it fled or was fleeing | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 3.3 (29%) | 0.0 (0%) | 3.3 (23%) |
| ONLY IN COMBAT: the only targets were in combat | 2.0 (17%) | 0.0 (0%) | 2.0 (14%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (14%) | 0.0 (0%) | 1.7 (12%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 9.0 | 2.0 | 81% | 5.4 pts | 49 pts |
| character | 5.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 17.0 | 5.7 | 75% | 6.9 pts | 118 pts |
| war machine | 6.7 | 2.0 | 80% | 8.9 pts | 59 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 5.7 | 4.7 |
| Charges that made contact a game | 2.3 | 3.7 | 3.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.67 declared, 0.67 contact (3 units) | 0.00 declared, 0.00 contact (1 units) | 1.25 declared, 0.50 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.27 declared, 0.23 contact (22 units) | 0.74 declared, 0.48 contact (23 units) | 0.51 declared, 0.36 contact (45 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 47% (7 of 15) | 100% (2 of 2) | - | 53% (9 of 17) |
| Character in a unit | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Character on its own | 86% (6 of 7) | 80% (4 of 5) | 29% (2 of 7) | 63% (12 of 19) |
| Infantry | 58% (7 of 12) | 50% (1 of 2) | - | 57% (8 of 14) |
| Monster | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Monstrous | 100% (2 of 2) | 100% (2 of 2) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 3 | 27% (3 of 11); on the table 45% | 17% (3 of 18) | 49% | 48% (12 of 25) | 100% (2 of 2); 4.0 uses a game | 30% (3 of 10); 2.7 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | - | 58% (7 of 12) | 33% | 88% (7 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 1 | 100% (2 of 2); on the table 100% | 50% (3 of 6) | 30% | 83% (10 of 12) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | 17% (1 of 6) | 40% | 58% (7 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p56, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 75% (6) | 67% (2) | 73% (8) |
| ...free all their last turn and able to turn (per game) | 1.33 | 0.33 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.67 | 0.33 | 1.00 |
| ...with the charger already in that arc before they moved (per game) | 1.33 | 0.00 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p56

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 4.0 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 62% (5 of 8) | 43% (6 of 14) |
| Strategy | Shoot objectives carried out (shot that target) | 60% (21 of 35) | 9% (1 of 11) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | 50% (1 of 2) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 100% (1 of 1) | 100% (3 of 3) |
| Strategy | Joined characters whose unit fought | - | 0% (0 of 1) |
| Strategy | Lone characters that fought | 62% (5 of 8) | 82% (9 of 11) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.7 | 2.3 |
| Movement | Points that never moved of their own | 226.7 | 309.0 |
| Movement | Fights charged into per game | 2.0 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 5, net +393 | 2 of 7, net -120 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 5 | 0 of 7 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 5 | 1 of 7, net +70 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 of 5, net +128 | 2 of 7, net +276 |
| Shooting | Shots by shooting units (incl. breath weapons) | 14.3 | 6.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (19 of 43) | 50% (9 of 18) |
| Shooting | Points destroyed by shooting units | 41.7 | 0.0 |
| Shooting | War machine shots | 6.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (9 of 20) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.0 | 3.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 3) | 33% (3 of 9) |
| Magic | Wounds caused by magic missiles | 4.0 | 1.3 |
| Magic | Wounds caused by other spells | 5.7 | - |
| Magic | Points destroyed by magic (all spells) | 18.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.7 / 0.3 / 3.3 / 0.0 | 2.0 / 1.0 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 281.0 | 307.7 |
| Combat | Points run down | 181.7 | 0.0 |
| Combat | Net points per charged fight, damage counted | +177 | +36 |
| Combat | Net per 100 charger points, damage counted | +48.9 | +15.2 |
| Combat | First round won (charged fights) | 83% | 44% |
| Combat | Net points per charged fight | +207 | +46 |
| Combat | Net points per supported fight / lone fight | +350 / +179 | -44 / +72 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 6 | 4 of 9 |
| Game | Points lost | 307.7 | 958.3 |
| Game | VP from objectives | 773.3 | 496.7 |
| Game | Lone holders (player turns) | 6.0 | 0.0 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +954 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1266
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p56

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.7 | +94.8 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +2.8 | 0.0 | 0.0 |
| ARMY TABLE | 22.7 | -22.1 | 0.0 | 100.7 | 16.3 | +44.0 | 0.0 | 347.3 |
| ASSAILMENT BY POINTS | 1.0 | +4.2 | 0.0 | 133.3 | 0.3 | +2.7 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.3 | -0.4 | 0.0 | 0.0 |
| BOUND ASSAILMENT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 6.7 | +75.2 | 83.3 | 46.7 | - | - | - | - |
| CAST JOB | 0.3 | +1.0 | 56.7 | 0.0 | 0.7 | +22.9 | 0.0 | 130.0 |
| CASTING BLOCK | - | - | - | - | 3.0 | +48.9 | 100.7 | 0.0 |
| CASTS AFTER FRIENDS | 2.0 | +0.0 | 0.0 | 133.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 1.0 | +11.4 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.7 | -0.3 | 50.3 | 0.0 |
| CHARGE LOSSES | 17.0 | -621.8 | 0.0 | 619.0 | 17.3 | -922.5 | 0.0 | 1108.0 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 141.7 | 50.3 | 3.0 | +0.0 | 257.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.0 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 2.0 | +209.1 | 133.3 | 133.3 | - | - | - | - |
| COVER ONCE | 6.3 | -362.9 | 0.0 | 100.7 | 3.7 | -227.4 | 0.0 | 36.7 |
| DEFENSIVE FLOOR | 0.3 | +0.2 | 116.7 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -1.0 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 7.3 | -21.6 | 0.0 | 0.0 | 7.7 | +43.4 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | +13.6 | 67.0 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +1.0 | 50.3 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.3 | +1.2 | 0.0 | 116.7 |
| EVASIVE BY THE ODDS | - | - | - | - | 3.3 | +9.9 | 133.3 | 41.7 |
| EXACT ROUND | 1.0 | -9.6 | 233.3 | 0.0 | 3.0 | +11.9 | 73.7 | 42.0 |
| FALL BACK GOOD ORDER | 2.0 | +4.2 | 389.3 | 50.3 | 2.7 | +5.4 | 124.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 17.7 | +219.4 | 0.0 | 693.0 |
| FIGHT TO THE END | - | - | - | - | 2.0 | +27.2 | 100.7 | 0.0 |
| FIVE ACTION | 96.3 | +6043.7 | 1496.0 | 813.0 | 64.0 | +3785.6 | 408.3 | 1676.7 |
| FLANK NOT WEIGHED | 3.3 | +0.0 | 0.0 | 50.3 | 4.3 | +0.0 | 0.0 | 132.0 |
| FOOT FIRST | 35.7 | +0.0 | 0.0 | 298.3 | - | - | - | - |
| FOUR ROUNDS | 2.7 | +236.4 | 637.0 | 50.3 | 4.7 | +233.7 | 307.7 | 42.0 |
| FREED FROM HIS FIGHT | 1.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 151.3 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -19.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -4.6 | 0.0 | 100.7 | 1.0 | -8.4 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.3 | -2.2 | 0.0 | 0.0 |
| GOAL WALK | 4.7 | +187.3 | 0.0 | 0.0 | 3.3 | +178.5 | 0.0 | 0.0 |
| GUN MASK | 0.7 | -0.7 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 3.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 113.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 2.3 | +0.0 | 0.0 | 151.3 |
| HIS CHARGE BY HIS RUN | 9.3 | +0.0 | 0.0 | 302.0 | 8.7 | +0.0 | 0.0 | 812.7 |
| HIS CHARGE DENIED | 0.7 | +13.5 | 233.3 | 0.0 | 0.3 | +19.1 | 0.0 | 0.0 |
| HIS CHARGE LIST | 1.7 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 169.0 |
| HIS LEGAL MOVES | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.0 | -31.9 | 0.0 | 50.3 | 4.0 | -18.3 | 0.0 | 605.3 |
| HIS ONE QUARTER | 3.3 | +0.0 | 0.0 | 266.7 | 3.0 | +0.0 | 0.0 | 96.7 |
| HIS OWN BEST MOVE | 4.0 | +0.0 | 0.0 | 100.7 | 5.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 12.3 | +0.0 | 0.0 | 100.7 | - | - | - | - |
| HIS RANDOM MOVER COMES | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 39.0 | +1262.7 | 0.0 | 568.7 | 31.3 | +939.2 | 0.0 | 868.7 |
| HIS SHOTS BY HIS RUN | 31.3 | +503.1 | 0.0 | 669.3 | 44.0 | +760.2 | 0.0 | 1448.0 |
| HIS TURN DENIED | 0.7 | +5.6 | 169.0 | 0.0 | 1.0 | +41.3 | 0.0 | 42.0 |
| HOLD ODDS | 16.3 | +0.0 | 0.0 | 100.7 | 5.7 | +0.0 | 0.0 | 40.0 |
| HOLDER ASSIGNMENT | 10.3 | +652.2 | 0.0 | 50.3 | 5.7 | +464.8 | 0.0 | 40.0 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.0 | -63.5 | 403.7 | 50.3 | 3.0 | -83.8 | 207.0 | 0.0 |
| IDLE COST | - | - | - | - | 12.3 | -167.0 | 0.0 | 214.3 |
| JOINT CHARGE NOW | 0.7 | +186.9 | 233.3 | 0.0 | 2.0 | +41.5 | 50.3 | 42.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.3 | -2.7 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 40.0 |
| LANE BY FIGURES | 1.3 | +97.5 | 0.0 | 0.0 | 0.3 | +7.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.0 | +0.0 | 211.3 | 0.0 | 5.3 | +0.0 | 151.0 | 245.0 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.7 | +0.0 | 115.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.3 | -1.7 | 50.3 | 0.0 |
| LOST AFTER ESCAPE | 1.3 | -3.2 | 495.3 | 0.0 | 1.3 | +3.8 | 100.7 | 0.0 |
| MANOEUVRE | 1.0 | +0.0 | 0.0 | 0.0 | 1.7 | +3.5 | 0.0 | 163.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +2.9 | 0.0 | 65.0 |
| MARCH BY THE SUM | - | - | - | - | 0.3 | +107.3 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 0.7 | +27.2 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +0.2 | 0.0 | 65.0 |
| MARCH OVER CASTS | 0.3 | +18.3 | 0.0 | 0.0 | 0.7 | -17.9 | 0.0 | 65.0 |
| MARCH WHEELS ONLY | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 0.7 | +22.8 | 0.0 | 0.0 | 0.7 | +73.9 | 0.0 | 0.0 |
| MEETS IN TIME | 3.3 | +197.2 | 0.0 | 0.0 | 4.3 | +88.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 5.0 | +109.1 | 0.0 | 0.0 | 4.3 | +104.1 | 0.0 | 261.0 |
| MISSILES NEXT TURN | 6.3 | +52.2 | 0.0 | 133.3 | 5.0 | +81.9 | 0.0 | 261.0 |
| MOVE ORDER | 0.7 | +0.0 | 50.3 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 2.0 | +0.0 | 0.0 | 133.3 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 3.7 | +382.3 | 0.0 | 100.7 | 6.3 | +475.2 | 0.0 | 0.0 |
| MOVES UNITS SPELL | - | - | - | - | 0.3 | +1.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.3 | +225.9 | 0.0 | 0.0 | 7.3 | +279.6 | 0.0 | 334.3 |
| NEAREST TO GOAL | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 1.3 | +96.9 | 0.0 | 100.7 | 3.7 | +327.9 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -2.5 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 2.0 | -182.3 | 375.0 | 50.3 | 4.3 | -251.5 | 307.7 | 42.0 |
| NO LATE CUT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 6.3 | -174.2 | 0.0 | 0.0 | 4.0 | -137.3 | 0.0 | 38.7 |
| ONE FIGHT FORMULA | 3.7 | -104.3 | 0.0 | 100.7 | 4.7 | -65.4 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 0.3 | +19.4 | 116.7 | 0.0 | 0.3 | +9.9 | 0.0 | 42.0 |
| ONE OBJECTIVE FORMULA | 4.3 | +88.4 | 0.0 | 50.3 | 1.3 | +10.0 | 0.0 | 0.0 |
| ONE ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +28.6 | 0.0 | 0.0 | 0.7 | +20.7 | 23.3 | 0.0 |
| OVERRUNS AWAY | 0.7 | +38.0 | 74.7 | 50.3 | 1.3 | +9.4 | 174.3 | 0.0 |
| PLAN RESULT | 42.3 | +922.8 | 524.0 | 408.3 | 35.3 | +744.3 | 485.3 | 1362.3 |
| PROMISE BY ITS OWN SUM | 10.7 | -367.7 | 0.0 | 0.0 | 6.7 | -20.5 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.7 | +0.0 | 0.0 | 100.7 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 1.3 | -20.7 | 0.0 | 100.7 | 2.7 | -19.2 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.7 | -8.2 | 0.0 | 0.0 |
| QUARTER ODDS | 28.7 | +3086.6 | 802.0 | 266.7 | 14.7 | +2119.8 | 133.3 | 401.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.3 | +11.9 | 0.0 | 226.7 |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 0.3 | +70.9 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | - | - | - | - | 0.7 | -19.0 | 0.0 | 0.0 |
| REFUSING RETIRES | 1.3 | +0.0 | 0.0 | 151.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RISK BY ARC | 1.3 | -45.3 | 367.0 | 0.0 | 4.0 | -27.9 | 307.7 | 42.0 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.3 | -11.0 | 67.0 | 0.0 | 0.7 | -5.6 | 156.7 | 0.0 |
| RUN DOWN | 2.0 | -99.0 | 375.0 | 50.3 | 3.7 | -19.8 | 307.7 | 0.0 |
| SEARCH SPOT | 0.7 | +0.4 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| SELF MOVE SPELL | - | - | - | - | 2.0 | +2.5 | 0.0 | 0.0 |
| SET CREDITED ONCE | 1.3 | -83.7 | 0.0 | 0.0 | 1.7 | -52.7 | 0.0 | 0.0 |
| SET UP BY THE SET | 2.7 | +64.8 | 0.0 | 100.7 | 1.7 | +9.5 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.3 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| SET-UP MISSED | 0.3 | +45.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 9.3 | +0.0 | 0.0 | 46.7 | 3.3 | +0.0 | 0.0 | 65.0 |
| SHOOTS FROM THE BEST SPOT | 4.0 | +164.8 | 377.3 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 0.7 | -1.2 | 167.7 | 50.3 | 0.3 | -12.2 | 50.3 | 0.0 |
| SHOT RISK POINTS | 18.7 | -331.3 | 0.0 | 568.7 | 25.3 | -76.5 | 0.0 | 1122.0 |
| SHOTS AFTER THE MOVES | 4.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 19.0 | +534.4 | 0.0 | 46.7 | 5.0 | +133.3 | 0.0 | 74.7 |
| SPELL WORTH | 3.0 | +132.8 | 133.3 | 133.3 | 2.0 | +8.3 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.7 | +3.8 | 153.3 | 50.3 | 1.0 | -9.8 | 50.3 | 0.0 |
| SPOT AS THE GAME MOVES | 4.0 | +0.0 | 0.0 | 133.3 | 8.7 | +0.0 | 0.0 | 429.7 |
| STAND AND SHOOT | - | - | - | - | 1.3 | -9.9 | 133.3 | 42.0 |
| STANDS FOR A REASON | - | - | - | - | 3.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 50.3 | +0.0 | 859.0 | 93.3 | 18.0 | +0.0 | 100.7 | 603.3 |
| STAY WORTH | 26.7 | +118.7 | 481.7 | 70.0 | 9.3 | +93.8 | 0.0 | 168.0 |
| STRIKE BY THE ODDS | 0.3 | +2.4 | 131.0 | 0.0 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 3.3 | +234.4 | 0.0 | 0.0 | 2.0 | +235.0 | 0.0 | 116.7 |
| SUPPORT NARROWED | 0.7 | +0.0 | 74.7 | 50.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 3.3 | +234.4 | 0.0 | 0.0 | 2.0 | +235.0 | 0.0 | 116.7 |
| SURE REACH TOGETHER | 1.0 | +4.7 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 50.3 | - | - | - | - |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 65.0 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 216.3 |
| THE STEP BACK IS MADE | 0.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 216.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 46.3 | +0.0 | 0.0 | 381.3 | 27.0 | +0.0 | 0.0 | 664.3 |
| TIED UP BY THE SUM | 1.0 | +88.9 | 74.7 | 50.3 | 0.7 | +87.5 | 23.3 | 0.0 |
| TIME ON OUR SIDE | 50.3 | +513.2 | 273.0 | 302.0 | - | - | - | - |
| WAITS AGAIN | 2.3 | +0.0 | 0.0 | 100.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.3 | -3.1 | 0.0 | 0.0 |
| WHO FIGHTS | 0.3 | +5.4 | 116.7 | 0.0 | 0.3 | +0.6 | 50.3 | 0.0 |
| WHO GETS IN | - | - | - | - | 1.0 | +11.3 | 0.0 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.7 | +49.1 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +5.0 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.7 | -201.5 | 0.0 | 100.7 | 1.7 | -527.7 | 0.0 | 396.0 |
| WHOLE FIGHT GAIN | 0.3 | +30.1 | 116.7 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | - | - | - | - | 3.3 | +145.5 | 0.0 | 396.0 |

### Rule changes: gs3-83c8646-p56

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 117 | 117 | 80 | 26.67 | +485 | +6.1 |
| HIS SHOT LIST | 211 | 203 | 51 | 17.00 | +1231 | +24.1 |
| HIS SHOTS BY HIS RUN | 226 | 218 | 41 | 13.67 | +495 | +12.1 |
| HOLDER ASSIGNMENT | 48 | 48 | 41 | 13.67 | +2906 | +70.9 |
| FIVE ACTION | 481 | 468 | 32 | 10.67 | +1197 | +37.4 |
| LEGAL CHARGES ONLY | 31 | 31 | 31 | 10.33 | +0 | +0.0 |
| OFF BEST | 31 | 31 | 31 | 10.33 | -934 | -30.1 |
| DEPLOY BY FIGURES | 45 | 45 | 26 | 8.67 | +294 | +11.3 |
| THE TABLE AGAIN | 35 | 35 | 22 | 7.33 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 30 | 28 | 21 | 7.00 | +905 | +43.1 |
| PROMISE BY ITS OWN SUM | 52 | 52 | 17 | 5.67 | -1165 | -68.5 |
| TIME ON OUR SIDE | 151 | 126 | 16 | 5.33 | +50 | +3.1 |
| HARD STAY DROPPED | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| ADVANCE LANE KEPT | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 15 | 15 | 12 | 4.00 | +624 | +52.0 |
| SHOT RISK POINTS | 132 | 130 | 12 | 4.00 | +373 | +31.1 |
| QUARTER ODDS | 130 | 130 | 11 | 3.67 | +1114 | +101.3 |
| CHARGE LOSSES | 103 | 101 | 10 | 3.33 | +694 | +69.4 |
| FOUR ROUNDS | 22 | 22 | 9 | 3.00 | +464 | +51.6 |
| JOINT CHARGE NOW | 8 | 8 | 8 | 2.67 | +685 | +85.6 |
| MEETS IN TIME | 23 | 23 | 8 | 2.67 | +188 | +23.5 |
| COVER ONCE | 30 | 21 | 7 | 2.33 | +223 | +31.8 |
| PROMISE KNOWS THE FIGHT | 12 | 12 | 7 | 2.33 | -120 | -17.1 |
| SHOOTS FROM THE BEST SPOT | 12 | 12 | 7 | 2.33 | +78 | +11.2 |
| CANNON PLANNED TARGET | 20 | 20 | 6 | 2.00 | -7 | -1.2 |
| MOVE ORDER | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CASTING BLOCK | 9 | 9 | 5 | 1.67 | +24 | +4.8 |
| EVASIVE BY THE ODDS | 10 | 10 | 5 | 1.67 | +7 | +1.4 |
| GOAL WALK | 24 | 24 | 5 | 1.67 | +302 | +60.3 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +314 | +62.7 |
| RANDOM MOVE BY FIGURES | 10 | 10 | 5 | 1.67 | +36 | +7.1 |
| ASSAILMENT BY POINTS | 4 | 4 | 4 | 1.33 | +21 | +5.1 |
| FALLS SHORT | 53 | 48 | 4 | 1.33 | +171 | +42.6 |
| REFUSING RETIRES | 5 | 5 | 4 | 1.33 | -31 | -7.9 |
| SET UP BY THE SET | 13 | 13 | 4 | 1.33 | +173 | +43.4 |
| STAY WORTH | 108 | 95 | 4 | 1.33 | +42 | +10.4 |
| SUPPORT ADDS | 16 | 15 | 4 | 1.33 | +63 | +15.9 |
| SUPPORT WORKED OUT | 16 | 15 | 4 | 1.33 | +63 | +15.9 |
| TIED UP BY THE SUM | 5 | 5 | 4 | 1.33 | +169 | +42.2 |
| CAST JOB | 3 | 3 | 3 | 1.00 | +7 | +2.4 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +34 | +11.4 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| IDLE COST | 37 | 28 | 3 | 1.00 | +11 | +3.6 |
| SHOTS IN THE MOVE | 72 | 54 | 3 | 1.00 | +189 | +63.0 |
| WHO GETS IN | 3 | 3 | 3 | 1.00 | +34 | +11.3 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +284 | +142.2 |
| MANOEUVRE | 8 | 8 | 2 | 0.67 | +10 | +5.2 |
| MARCH CHECK | 2 | 2 | 2 | 0.67 | +50 | +25.2 |
| MISSILES IN THE MOVE | 28 | 20 | 2 | 0.67 | +20 | +10.1 |
| ONE OBJECTIVE FORMULA | 17 | 8 | 2 | 0.67 | +74 | +36.9 |
| OPENS UP | 3 | 3 | 2 | 0.67 | +29 | +14.6 |
| RISK BY ARC | 16 | 16 | 2 | 0.67 | +7 | +3.6 |
| SEARCH SPOT | 3 | 3 | 2 | 0.67 | +3 | +1.6 |
| THE ROW IN ITS ORDER | 15 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +125 | +62.5 |
| WHOLE FIGHT DANGER | 13 | 12 | 2 | 0.67 | +436 | +218.1 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +8 | +8.4 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -1 | -1.1 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.33 | +0 | +0.1 |
| CHAMPION KNOWS CHALLENGE | 2 | 2 | 1 | 0.33 | +2 | +2.0 |
| CHARGE NOW FIRST | 13 | 13 | 1 | 0.33 | -19 | -19.4 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.33 | +4 | +3.6 |
| FALL BACK GOOD ORDER | 14 | 14 | 1 | 0.33 | +2 | +2.0 |
| HONEST WORTH | 15 | 15 | 1 | 0.33 | +11 | +11.2 |
| LOST AFTER ESCAPE | 8 | 8 | 1 | 0.33 | +2 | +2.0 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +322 | +321.8 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -1 | -0.6 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| NEXT OBJECTIVE NEARER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| NO DOUBLE ROUNDS | 19 | 19 | 1 | 0.33 | +18 | +17.9 |
| OVERRUNS AWAY | 6 | 6 | 1 | 0.33 | +33 | +32.6 |
| REDIRECT FOR A FRIEND IN REACH | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SET CREDITED ONCE | 9 | 9 | 1 | 0.33 | +25 | +24.7 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +7 | +7.2 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SURE REACH TOGETHER | 4 | 4 | 1 | 0.33 | +0 | +0.5 |
| CASTS AFTER FRIENDS | 7 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 41 | 41 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 6 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 12 | 12 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 6 | 6 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 23 | not checked | - | - | - | - |
| FOOT FIRST | 107 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 15 | 15 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN MASK | 2 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 7 | 7 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 54 | 52 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 20 | 20 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 10 | 10 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 18 | 18 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 19 | 19 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 29 | 27 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 37 | 36 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 3 | 2 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 5 | 5 | 0 | 0.00 | - | - |
| HOLD ODDS | 66 | 65 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 9 | 8 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 2 | not checked | - | - | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 1 | 0 | 0.00 | - | - |
| MAX FOR POSITIONING | 4 | 3 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 34 | 26 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 6 | not checked | - | - | - | - |
| NEARER NOT NEEDED | 38 | 35 | 0 | 0.00 | - | - |
| NEAREST TO GOAL | 4 | 4 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 35 | 35 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 25 | 13 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 2 | 2 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 1 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 233 | trace | - | - | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 1 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 1 | not checked | - | - | - | - |
| REFORMS TO MEET IT | 2 | 2 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 17 | 17 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 38 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 17 | 17 | 0 | 0.00 | - | - |
| SPELL WORTH | 15 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 5 | 5 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 38 | 36 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 11 | 11 | 0 | 0.00 | - | - |
| STANDS STILL | 205 | 195 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 3 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 6 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 18 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 9 | not checked | - | - | - | - |
| THE TABLE BINDS | 220 | not checked | - | - | - | - |
| WAITS AGAIN | 8 | 8 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 1 | 1 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 10 | 10 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p56

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.67 | 2.33 | 34.2 |
| PROMISE BY ITS OWN SUM | rule | 4.67 | 1.00 | 68.5 |
| ARMY TABLE | rule | 2.33 | 2.00 | 92.4 |
| PROMISE KNOWS THE FIGHT | rule | 1.00 | 1.33 | 17.1 |
| HOLDER ASSIGNMENT | rule | 0.67 | 0.33 | 51.8 |
| JOINT CHARGE NOW | rule | - | 1.00 | 40.0 |
| REFUSING RETIRES | rule | 1.00 | - | 10.4 |
| CANNON PLANNED TARGET | rule | 0.67 | - | 3.5 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.67 | 21.9 |
| NO REASON | gate | 0.67 | - | 15.8 |
| WHO GETS IN | rule | - | 0.67 | 40.6 |
| BEST PRIZE | rule | - | 0.33 | 1.1 |
| CHARGE NOW FIRST | rule | 0.33 | - | 19.4 |
| DEPLOY BY FIGURES | rule | - | 0.33 | 6.7 |
| FALLBACK | gate | - | 0.33 | 33.2 |
| FIGHT ORDER BAND | gate | - | 0.33 | 3.4 |
| MARCH OF THE TABLE | rule | - | 0.33 | 0.6 |
| RULE SWITCHED OFF | gate | - | 0.33 | 1.9 |

### Plans: gs3-83c8646-p56

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.7 | 80% | 281 | 170 | 60% |
| Mine | move | 31.0 | 96% | 1537 | 0 | 0% |
| Mine | shoot | 9.7 | 66% | 489 | 753 | 154% |
| Opponent | charge | 4.3 | 69% | 485 | 619 | 128% |
| Opponent | join | 1.7 | 80% | 82 | 0 | 0% |
| Opponent | move | 26.3 | 86% | 1291 | 0 | 0% |
| Opponent | shoot | 3.0 | 56% | 149 | 125 | 84% |

### Battle groups: gs3-83c8646-p56

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p56

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 8 | 63 (8) | 63 | 0 | 13 | 25% | 2.2 | 84 (6) | 0 (2) | - | 80 (2) | 58 (6) |
| Mine | Clean-up | 3 | 39 (3) | 0 | 39 | 0 | 33% | 1.5 | 61 (2) | 0 (1) | - | 61 (2) | 0 (1) |
| Mine | Fast Hammer | 7 | 64 (7) | 44 | 20 | 43 | 29% | 3.6 | 102 (3) | 40 (3) | 20 (1) | 36 (2) | 75 (5) |
| Mine | Holder | 2 | 78 (2) | 0 | 78 | 0 | 50% | 5.0 | 78 (2) | - | - | 78 (2) | - |
| Mine | Shooter | 5 | 6 (5) | 6 | 0 | 0 | 0% | 1.8 | 0 (4) | 34 (1) | - | 0 (4) | 34 (1) |
| Mine | War machine | 4 | 45 (4) | 45 | 0 | 25 | 0% | 1.0 | 89 (2) | 0 (2) | - | 0 (2) | 89 (2) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 32 | 100% | - | 0 (3) | - | - | 0 (3) | - |
| Opponent | Character | 9 | 25 (9) | 25 | 0 | 45 | 11% | 2.9 | 37 (4) | 13 (4) | - | 10 (4) | 46 (4) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 38 | 33% | 1.5 | - | 0 (3) | - | 0 (1) | 0 (2) |
| Opponent | Fast Hammer | 3 | 34 (3) | 0 | 34 | 85 | 0% | 3.0 | 152 (1) | 0 (2) | - | 0 (1) | 67 (2) |
| Opponent | Hammer | 8 | 30 (8) | 30 | 0 | 35 | 38% | 3.2 | 33 (4) | 0 (2) | 60 (2) | 27 (5) | 36 (3) |
| Opponent | Holder | 3 | 0 (3) | 0 | 0 | 100 | 67% | 5.0 | 0 (1) | - | 0 (1) | - | 0 (2) |
| Opponent | Shooter | 3 | 41 (3) | 0 | 41 | 62 | 0% | 1.0 | - | 59 (2) | 0 (1) | - | 41 (3) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 34 | 0% | 1.3 | 0 (1) | 0 (2) | - | 0 (2) | 0 (1) |

### Charged fights: gs3-83c8646-p56

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 3 | 60 | 465 | 2.0 | 1.2 | 232 | 25 | +207 | 3 of 6 | 5 of 6 | +350 | +179 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 70 | 2.0 | 1.0 | 35 | 0 | +35 | 0 of 2 | 1 of 2 | - | +35 |
| Opponent | Warriors of Chaos | 1 | 0 | 151 | 3.0 | 1.3 | 50 | 40 | +10 | 1 of 3 | 1 of 3 | +151 | -60 |
| Opponent | Wood Elf Realms | 1 | 0 | 551 | 4.0 | 1.2 | 138 | 60 | +78 | 3 of 4 | 2 of 4 | -240 | +184 |
| **Opponent** | all armies | 3 | 0 | 257 | 3.0 | 1.2 | 86 | 40 | +46 | 4 of 9 | 4 of 9 | -44 | +72 |

### Effective charges: gs3-83c8646-p56

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 6 | 1 (net +393) | 0 | 0 | 0 | 0 | 4 (net +128) | 1 | 0% (0 of 5) |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 0 | 0 | 0 | 1 (net +70) | 0 | 1 | 0% (0 of 1) |
| Opponent | Warriors of Chaos | 3 | 0 | 1 (net +0) | 0 | 1 (net +151) | 0 | 0 | 1 | 0% (0 of 2) |
| Opponent | Wood Elf Realms | 4 | 2 (net -120) | 0 | 0 | 0 | 0 | 2 (net +276) | 0 | 0% (0 of 4) |

### Charged fights, damage counted: gs3-83c8646-p56

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 400 | 343 | +393 | 393 | 171 | +222 | +55.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 317 | 194 | +128 | 192 | 49 | +143 | +45.0 |
| Mine | No odds | 1 | 500 | 170 | +340 | 379 | 110 | +268 | +53.7 |
| Mine | All fights | 6 | 361 | 215 | +207 | 257 | 80 | +177 | +48.9 |
| Opponent | Long shot (under 50%) | 2 | 165 | 247 | -120 | 21 | 120 | -99 | -60.3 |
| Opponent | 50-54% | 1 | 116 | 143 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 76-89% | 1 | 232 | 151 | +151 | 151 | 0 | +151 | +65.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 312 | 276 | +276 | 310 | 55 | +255 | +81.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 350 | 70 | +70 | 70 | 31 | +39 | +11.0 |
| Opponent | No odds | 2 | 235 | 360 | -60 | 0 | 89 | -89 | -37.9 |
| Opponent | All fights | 9 | 236 | 236 | +46 | 98 | 62 | +36 | +15.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p56 | move | 21 | 9 (43%) | 5 (24%) | 5 (24%) | 7 (33%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Elixir of Power | Opponent | L1319 |
| Opal Amulet | Mine | L1431 |
| Ring of Doom | Opponent | L1431 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |

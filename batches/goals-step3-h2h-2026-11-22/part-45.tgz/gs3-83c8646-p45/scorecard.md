# Doctrine scorecard: gs3-83c8646-p45

### Scorecard: gs3-83c8646-p45

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1621 | 1 | 1 | Mine | no | 3 | 3 | 2 | 1 | 0 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 2 | - | 1 | 5 | 0 | 0 | 0 | 145 |
| L1719 | 3 | 1 | Mine | no | 3 | 2 | 3 | 0 | 2 | 0 | 0 | 322 |
| L1719 | 3 | 1 | Opponent | no | 4 | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Mine | no | 2 | - | 1 | 1 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | yes | 0 | 3 | 6 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 2.7 | 2.5 | 2.0 | 0.7 | 0.7 | 0.0 | 0.0 | 174.0 |
| **Average** | | | Opponent | 33% | 2.0 | 2.5 | 4.3 | 2.7 | 0.0 | 0.0 | 0.0 | 48.3 |

### KPIs: gs3-83c8646-p45

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 6% (1 of 16) | 8% (1 of 13) | 7% (2 of 29) |
| Winner chose to follow up after the loser gave ground |  | 100% (3 of 3); on the table 100% | 100% (3 of 3); on the table 100% | 100% (6 of 6); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | 67% (2 of 3); on the table 100% | 75% (3 of 4); on the table 100% |
| Winner chose to pursue after the loser fled |  | 50% (2 of 4); on the table 50% | 100% (4 of 4); on the table 100% | 75% (6 of 8); on the table 75% |
| Winner chose to follow up or pursue (all three) |  | 75% (6 of 8); on the table 75% | 90% (9 of 10); on the table 100% | 83% (15 of 18); on the table 89% |
| Magic missiles tried each own turn | 50%+ | - | 33% (12 of 36) | 33% (12 of 36) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 52% (12 of 23) | 52% (12 of 23) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 85% (11 of 13) | 85% (11 of 13) |
| Points that never fought | lower | 55% (3328 of 6000) | 38% (2279 of 5999) | 47% (5607 of 11999) |
|   infantry points that never fought | lower | 41% (483 of 1187) | 93% (828 of 888) | 63% (1311 of 2075) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 65% (13 of 20) | 56% (14 of 25) | 60% (27 of 45) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.3 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (2 of 2); 0.8 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 100% (3 of 3); 1.0 uses a game | 100% (4 of 4); 0.7 uses a game |
|   their share of the points of units over 100 pts | lower | 65% (3162 of 4880) | 51% (2676 of 5296) | 57% (5838 of 10176) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 2.0 (25%) | 2.0 (25%) |
| MARCHED: its unit marched | - | 1.7 (21%) | 1.7 (21%) |
| IN COMBAT: engaged in combat | - | 0.3 (4%) | 0.3 (4%) |
| GONE: slain | - | 3.3 (42%) | 3.3 (42%) |
| OFF THE TABLE: off the table or not arrived | - | 0.7 (8%) | 0.7 (8%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.7 | 0.0 | 0.3 | 4.0 | 1.3 |
| not cast | 2.3 | 2.0 | 5.7 | 8.0 | 26.7 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (25%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (21%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (86%) | 2.0 (100%) | 2.0 (35%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.3 (42%) | 0.0 (0%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.7 (12%) | 0.7 (8%) | 1.7 (6%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.3 (14%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.0 (0%) | 0.0 (0%) | 3.0 (53%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 25.0 (94%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 0.3 a game | 0.2 a game |
| stood (cast and not dispelled) | - | - | - |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 62% (60 of 97) | 32% (7 of 22) | 56% (67 of 119) |
|   cavalry | 67% (8 of 12) | - | 67% (8 of 12) |
|   character | 67% (4 of 6) | - | 67% (4 of 6) |
|   chariot | 75% (9 of 12) | 42% (5 of 12) | 58% (14 of 24) |
|   infantry | 52% (22 of 42) | 20% (2 of 10) | 46% (24 of 52) |
|   monster | 56% (10 of 18) | - | 56% (10 of 18) |
|   war machine | 100% (7 of 7) | - | 100% (7 of 7) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.0 (24%) | 0.3 (7%) | 3.3 (19%) |
| CHARGED: it charged | 0.7 (5%) | 0.0 (0%) | 0.7 (4%) |
| FLEEING: it fled or was fleeing | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 1.0 (8%) | 1.0 (20%) | 2.0 (12%) |
| NO TARGET IN RANGE | 4.0 (32%) | 0.0 (0%) | 4.0 (23%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (5%) | 0.7 (13%) | 1.3 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (14%) | 3.0 (60%) | 4.7 (27%) |
| OTHER BAR | 1.0 (8%) | 0.0 (0%) | 1.0 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.7 | 0.7 | 75% | 4.0 pts | 11 pts |
| character | 1.3 | 0.3 | 75% | 12.5 pts | 17 pts |
| chariot | 4.7 | 2.3 | 71% | 18.8 pts | 88 pts |
| infantry | 11.7 | 3.7 | 77% | 3.7 pts | 43 pts |
| monster | 3.3 | 1.0 | 80% | 7.2 pts | 24 pts |
| war machine | 2.3 | 1.7 | 57% | 27.1 pts | 63 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 4.3 | 4.0 |
| Charges that made contact a game | 2.7 | 3.7 | 3.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 0.50 contact (2 units) | - | 1.00 declared, 0.50 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.36 declared, 0.28 contact (25 units) | 0.54 declared, 0.46 contact (24 units) | 0.45 declared, 0.37 contact (49 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | - | 50% (1 of 2) | - | 50% (1 of 2) |
| Character in a unit | 100% (5 of 5) | 100% (2 of 2) | - | 100% (7 of 7) |
| Character on its own | 25% (1 of 4) | 100% (4 of 4) | 33% (2 of 6) | 50% (7 of 14) |
| Chariot | 25% (1 of 4) | - | - | 25% (1 of 4) |
| Infantry | 75% (3 of 4) | 67% (2 of 3) | - | 71% (5 of 7) |
| Monster | 33% (1 of 3) | 100% (2 of 2) | - | 60% (3 of 5) |
| Monstrous | - | 50% (3 of 6) | - | 50% (3 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Kingdom of Bretonnia | 1 | 0% (0 of 1); on the table 0% | - | 71% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | 83% (5 of 6); on the table 83% | - | 20% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (1 of 1); on the table 100% | - | 75% | 71% (5 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (8 of 8); on the table 100% | 40% (12 of 30) | 32% | 56% (9 of 16) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Skaven | 1 | 50% (1 of 2); on the table 100% | 0% (0 of 6) | 51% | 56% (5 of 9) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p45, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 33% (1) | 62% (5) | 55% (6) |
| ...free all their last turn and able to turn (per game) | 0.33 | 1.00 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.67 | 0.67 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 1.00 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p45

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.0 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | 40% (4 of 10) | 80% (4 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 42% (8 of 19) | 33% (2 of 6) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 0% (0 of 2) | 0% (0 of 6) |
| Strategy | Lone characters that fought | 43% (3 of 7) | 86% (6 of 7) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.7 | 2.7 |
| Movement | Points that never moved of their own | 174.0 | 48.3 |
| Movement | Fights charged into per game | 2.7 | 3.7 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 7, net +0 | 1 of 5, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 7, net +255 | 0 of 5 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 7, net +55 | 3 of 5, net +53 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 7, net -264 | 1 of 5, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 19.0 | 2.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 49% (28 of 57) | 57% (4 of 7) |
| Shooting | Points destroyed by shooting units | 142.3 | 0.0 |
| Shooting | War machine shots | 2.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 71% (5 of 7) | - |
| Shooting | Points destroyed by war machines | 131.7 | 0.0 |
| Magic | Magic missiles cast | - | 2.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 33% (2 of 6) |
| Magic | Wounds caused by magic missiles | 1.3 | 1.7 |
| Magic | Wounds caused by other spells | - | 1.7 |
| Magic | Points destroyed by magic (all spells) | 18.3 | 157.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.0 / 0.0 / 0.0 | 1.7 / 0.0 / 0.7 / 0.0 |
| Combat | Points destroyed in combat | 140.0 | 334.3 |
| Combat | Points run down | 278.7 | 158.7 |
| Combat | Net points per charged fight, damage counted | +43 | +13 |
| Combat | Net per 100 charger points, damage counted | +20.1 | +5.4 |
| Combat | First round won (charged fights) | 50% | 91% |
| Combat | Net points per charged fight | +20 | +44 |
| Combat | Net points per supported fight / lone fight | - / +20 | - / +44 |
| Combat | Charged fights on a top-3 enemy unit | 4 of 8 | 2 of 11 |
| Game | Points lost | 715.0 | 714.3 |
| Game | VP from objectives | 763.3 | 550.0 |
| Game | Lone holders (player turns) | 2.7 | 2.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +183 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 1429
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p45

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | 0.3 | +8.4 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 24.7 | +402.9 | 0.0 | 370.0 | 17.0 | +454.7 | 0.0 | 509.0 |
| ASSAILMENT BY POINTS | - | - | - | - | 0.3 | +0.4 | 0.0 | 0.0 |
| BACKUP TARGETS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.3 | -48.4 | 100.3 | 116.7 |
| CANNON PLANNED TARGET | 2.3 | +172.1 | 85.0 | 33.3 | - | - | - | - |
| CANNON SIGHT KEPT | 0.7 | +0.0 | 0.0 | 33.3 | - | - | - | - |
| CARRIES OUT SET-UP | 0.3 | +0.0 | 70.0 | 0.0 | - | - | - | - |
| CAST JOB | 1.3 | +18.3 | 36.7 | 0.0 | 1.3 | +5.5 | 157.0 | 36.7 |
| CHAFF IN THE MOVE | - | - | - | - | 1.0 | +28.9 | 0.0 | 36.7 |
| CHAFF PASSED | 0.7 | -0.6 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | - | - | - | - | 0.7 | +1.1 | 0.0 | 0.0 |
| CHARACTER GUNS | - | - | - | - | 3.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 14.0 | -268.7 | 0.0 | 517.7 | 16.7 | -789.3 | 0.0 | 489.0 |
| CHARGE NOT DECLARED | 0.7 | +0.0 | 193.7 | 0.0 | 0.3 | +0.0 | 27.7 | 0.0 |
| CHARGE NOW FIRST | 3.3 | +0.0 | 584.3 | 157.0 | 0.7 | +0.0 | 27.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 9.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 291.7 |
| COVER ONCE | 6.0 | -188.3 | 0.0 | 321.0 | 9.7 | -706.0 | 0.0 | 243.7 |
| DENIED BY THE FIGHT | - | - | - | - | 1.0 | -11.0 | 25.7 | 0.0 |
| DEPLOY BY FIGURES | 8.0 | +29.1 | 0.0 | 33.3 | 7.0 | +28.4 | 0.0 | 18.3 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +0.8 | 25.7 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.7 | +6.0 | 0.0 | 0.0 |
| EXACT ROUND | 3.3 | +36.6 | 584.3 | 204.0 | 0.7 | +2.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.7 | +0.0 | 348.7 | 204.0 | 1.0 | +1.6 | 25.7 | 0.0 |
| FALLS SHORT | 8.3 | +66.2 | 0.0 | 157.0 | 7.7 | +127.0 | 0.0 | 394.0 |
| FEATURE BUFFS | 0.7 | +7.1 | 0.0 | 0.0 | 3.0 | +24.1 | 0.0 | 55.0 |
| FIGHT TO THE END | 1.3 | +21.9 | 278.7 | 157.0 | - | - | - | - |
| FIVE ACTION | 92.3 | +8556.3 | 1327.7 | 1444.0 | 63.3 | +4563.8 | 543.3 | 1501.3 |
| FLANK NOT WEIGHED | 4.0 | +0.0 | 0.0 | 157.0 | 9.0 | +0.0 | 0.0 | 163.7 |
| FOCUS FIRE | 0.3 | +9.0 | 18.3 | 0.0 | - | - | - | - |
| FOOT FIRST | - | - | - | - | 12.3 | +0.0 | 0.0 | 582.3 |
| FOUR ROUNDS | 3.7 | +281.8 | 584.3 | 204.0 | 1.7 | +49.2 | 210.3 | 0.0 |
| FREED FROM HIS FIGHT | 1.7 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 1.7 | -3.8 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.3 | +0.8 | 0.0 | 0.0 | 0.3 | +11.5 | 0.0 | 0.0 |
| GOAL WALK | 9.3 | +622.3 | 0.0 | 0.0 | 12.0 | +1119.1 | 0.0 | 85.0 |
| GUN FIGURES | 2.3 | +26.2 | 153.3 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| GUN MASK | 0.7 | -3.7 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 58.3 | - | - | - | - |
| HE REFORMS ONCE FREED | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 9.0 | +0.0 | 0.0 | 517.7 | 12.7 | +0.0 | 0.0 | 404.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +1.1 | 157.0 | 0.0 |
| HIS CHARGE LIST | 2.0 | +0.0 | 0.0 | 27.7 | 10.0 | +0.0 | 0.0 | 86.7 |
| HIS LEGAL MOVES | 6.0 | +0.0 | 0.0 | 184.7 | 4.7 | +0.0 | 0.0 | 355.0 |
| HIS MOVE AND SHOT | 5.3 | -64.7 | 0.0 | 517.7 | 3.3 | -82.2 | 0.0 | 238.3 |
| HIS ONE QUARTER | 10.7 | +0.0 | 0.0 | 200.7 | 2.0 | +0.0 | 0.0 | 233.3 |
| HIS OWN BEST MOVE | 12.0 | +0.0 | 0.0 | 341.7 | 6.3 | +0.0 | 0.0 | 391.7 |
| HIS RANDOM MOVE | 15.7 | +0.0 | 0.0 | 490.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 34.3 | +874.5 | 0.0 | 490.0 | 36.7 | +925.0 | 0.0 | 1197.7 |
| HIS SHOTS BY HIS RUN | 32.0 | +238.8 | 0.0 | 569.3 | 34.3 | +774.0 | 0.0 | 615.0 |
| HIS TURN DENIED | 0.7 | +2.0 | 217.3 | 0.0 | 1.3 | +24.9 | 53.3 | 0.0 |
| HOLD ODDS | 20.0 | +0.0 | 0.0 | 83.0 | 17.7 | +0.0 | 0.0 | 231.7 |
| HOLDER ASSIGNMENT | 13.3 | +1130.7 | 0.0 | 55.3 | 10.7 | +876.5 | 0.0 | 158.3 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.7 | -73.7 | 584.3 | 204.0 | 1.3 | -37.7 | 53.3 | 0.0 |
| IDLE COST | 2.3 | -44.6 | 0.0 | 157.0 | 6.0 | -124.6 | 0.0 | 235.7 |
| JOINT CHARGE NOW | 1.0 | -88.2 | 326.0 | 0.0 | 0.3 | +69.7 | 157.0 | 0.0 |
| JOINT ON THE TABLE | - | - | - | - | 0.3 | +69.7 | 157.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 4.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 36.7 |
| LANE BY FIGURES | 1.0 | +47.2 | 0.0 | 0.0 | 0.7 | +11.3 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 10.0 | +0.0 | 73.3 | 571.7 | 3.7 | +0.0 | 304.3 | 519.7 |
| LONE WIZARD KEPT IN | 0.3 | +16.3 | 0.0 | 0.0 | 0.3 | +58.3 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.3 | +11.1 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 2.3 | +11.0 | 387.3 | 47.0 | 1.7 | +2.6 | 210.3 | 0.0 |
| MAKE SURE TOGETHER | 0.7 | +7.1 | 0.0 | 0.0 | 0.7 | +13.1 | 0.0 | 0.0 |
| MANOEUVRE | 2.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +2.2 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +13.4 | 0.0 | 0.0 | 0.7 | +53.3 | 0.0 | 0.0 |
| MARCH CHECK | 1.0 | +52.7 | 0.0 | 0.0 | 1.3 | +41.9 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +2.4 | 0.0 | 0.0 | 0.3 | +26.1 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.7 | +13.9 | 0.0 | 0.0 | 1.3 | +15.3 | 0.0 | 217.3 |
| MARCH WHEELS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 36.7 |
| MAX FOR POSITIONING | 2.7 | +46.3 | 0.0 | 0.0 | 1.3 | +25.6 | 0.0 | 18.3 |
| MEETS IN TIME | 2.0 | +244.3 | 0.0 | 0.0 | 3.3 | +240.7 | 0.0 | 18.3 |
| MISSILES IN THE MOVE | 1.3 | +18.4 | 0.0 | 0.0 | 5.0 | +84.0 | 0.0 | 145.3 |
| MISSILES NEXT TURN | 1.7 | +13.4 | 0.0 | 0.0 | 6.0 | +90.5 | 0.0 | 254.0 |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 18.3 |
| MOVE SPELL OUT OF RANGE | 0.7 | -37.2 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 14.0 | +967.1 | 0.0 | 314.0 | 3.0 | +220.6 | 0.0 | 36.7 |
| MOVES UNITS SPELL | - | - | - | - | 0.7 | +2.9 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 8.0 | +328.2 | 0.0 | 51.7 | 3.3 | +154.5 | 0.0 | 0.0 |
| NEAREST TO GOAL | - | - | - | - | 1.3 | +0.0 | 0.0 | 85.0 |
| NEXT CHARGE BY LIST | 8.0 | +655.2 | 0.0 | 314.0 | 3.0 | +220.6 | 0.0 | 36.7 |
| NEXT OBJECTIVE NEARER | 0.7 | -13.4 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 3.7 | -173.3 | 584.3 | 204.0 | 1.3 | -58.5 | 53.3 | 0.0 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 36.7 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 4.3 | -119.0 | 0.0 | 166.0 | 2.0 | -54.1 | 0.0 | 18.3 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 8.7 | -159.0 | 0.0 | 157.0 | 3.3 | -75.3 | 0.0 | 135.0 |
| ONE OBJECTIVE FORMULA | 5.7 | +25.0 | 0.0 | 27.7 | 3.7 | -2.2 | 0.0 | 18.3 |
| ONE PROMISE A TARGET | 2.0 | -2.1 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 36.7 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 1.0 | +10.6 | 88.3 | 0.0 | 0.7 | +3.9 | 25.7 | 0.0 |
| PERIAPT WORTH | - | - | - | - | 0.3 | +18.8 | 0.0 | 0.0 |
| PLAN RESULT | 42.0 | +927.4 | 406.7 | 1310.7 | 33.3 | +253.4 | 157.0 | 872.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 12.7 | -240.1 | 0.0 | 0.0 | 5.3 | -73.3 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 3.3 | -2.3 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.7 | -62.6 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 24.0 | +2844.6 | 350.0 | 475.0 | 15.7 | +1945.4 | 229.3 | 350.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.3 | +149.1 | 0.0 | 70.0 |
| REAL GROUND | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 36.7 |
| REDIRECT COUNTER | 3.0 | +116.5 | 0.0 | 0.0 | 2.0 | +52.4 | 0.0 | 55.0 |
| REDIRECT FOR A FRIEND IN REACH | 4.3 | +0.0 | 0.0 | 25.7 | 1.3 | +0.0 | 0.0 | 55.0 |
| REFORMS TO MEET IT | 2.0 | -75.5 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 55.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 1.7 | +30.7 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 3.3 | -52.7 | 499.3 | 204.0 | 1.7 | -15.4 | 210.3 | 0.0 |
| RISK ON THE WAY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | 1.0 | -43.0 | 212.0 | 0.0 | 0.3 | -9.2 | 0.0 | 0.0 |
| RUN DOWN | 3.0 | -60.2 | 514.3 | 47.0 | 1.3 | -18.8 | 53.3 | 0.0 |
| SCOUT SPOT | 0.7 | +1.7 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.0 | -82.0 | 0.0 | 36.7 |
| SEARCH SPOT | 1.0 | +16.3 | 0.0 | 27.7 | - | - | - | - |
| SECOND LOOK | 0.3 | +43.7 | 85.0 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | - | - | - | - | 3.3 | -4.5 | 0.0 | 217.3 |
| SET CREDITED ONCE | 1.3 | -11.6 | 0.0 | 0.0 | 2.0 | -41.4 | 0.0 | 0.0 |
| SET UP BY THE SET | 3.3 | +6.5 | 0.0 | 27.7 | 3.0 | +1.6 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.7 | +10.3 | 0.0 | 0.0 | 0.7 | +13.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 6.0 | +0.0 | 0.0 | 163.0 | 1.7 | +0.0 | 0.0 | 36.7 |
| SHOOTS FROM THE BEST SPOT | 2.0 | +112.6 | 171.7 | 25.7 | 0.3 | +26.1 | 88.0 | 0.0 |
| SHOT OR CHARGE | 0.7 | -11.4 | 18.3 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 24.7 | -172.7 | 0.0 | 517.7 | 25.3 | -57.2 | 0.0 | 630.7 |
| SHOTS AFTER THE MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 18.3 | +656.1 | 0.0 | 347.3 | 2.3 | +99.3 | 0.0 | 0.0 |
| SPELL WORTH | 1.7 | +3.7 | 0.0 | 0.0 | 2.0 | +59.4 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | -10.5 | 0.0 | 157.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 8.0 | +0.0 | 0.0 | 262.7 | 11.3 | +0.0 | 0.0 | 310.0 |
| STAND AND SHOOT | - | - | - | - | 1.0 | -9.9 | 53.3 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 1.3 | +0.0 | 0.0 | 36.7 |
| STANDS STILL | 32.0 | +0.0 | 743.3 | 641.3 | 13.7 | +0.0 | 333.0 | 171.7 |
| STAY WORTH | 19.3 | +369.3 | 228.3 | 361.7 | 1.0 | -15.5 | 157.0 | 0.0 |
| STRIKE BY THE ODDS | 0.3 | +10.2 | 18.3 | 0.0 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 1.3 | +0.0 | 0.0 | 70.0 |
| STUPIDITY NEXT TURN | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 4.0 | +238.8 | 0.0 | 144.3 | 5.0 | +577.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.7 | +0.0 | 178.7 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 4.0 | +238.8 | 0.0 | 144.3 | 5.0 | +577.0 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 1.0 | +8.7 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISE ADDS | 1.0 | -63.9 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 3.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 108.7 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 88.0 | 3.0 | +0.0 | 0.0 | 18.3 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 0.3 | +0.0 | 0.0 | 88.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 43.3 | +0.0 | 0.0 | 594.3 | 26.3 | +0.0 | 0.0 | 572.3 |
| TIED UP BY THE SUM | 1.0 | +73.8 | 326.0 | 0.0 | 0.3 | +38.3 | 27.7 | 0.0 |
| TIME ON OUR SIDE | 31.0 | +365.1 | 36.7 | 215.7 | 13.7 | +137.9 | 157.0 | 123.3 |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 18.3 |
| WEAPON BY POINTS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 1.0 | +3.7 | 155.0 | 0.0 | - | - | - | - |
| WHO GETS IN | - | - | - | - | 0.3 | +69.7 | 157.0 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +25.7 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 0.7 | -0.7 | 0.0 | 0.0 | 2.7 | -376.1 | 0.0 | 404.0 |
| WOUNDS ON THE RANKS | 2.3 | +13.7 | 0.0 | 0.0 | 3.3 | +196.3 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p45

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 125 | 125 | 76 | 25.33 | +2724 | +35.8 |
| HOLDER ASSIGNMENT | 72 | 72 | 66 | 22.00 | +3622 | +54.9 |
| HIS SHOT LIST | 213 | 207 | 44 | 14.67 | +502 | +11.4 |
| LEGAL CHARGES ONLY | 41 | 41 | 41 | 13.67 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 199 | 190 | 40 | 13.33 | +432 | +10.8 |
| MOVE TO CHARGE COMPUTED | 51 | 43 | 31 | 10.33 | +1657 | +53.5 |
| FIVE ACTION | 467 | 450 | 28 | 9.33 | +1599 | +57.1 |
| QUARTER ODDS | 119 | 113 | 26 | 8.67 | +1868 | +71.8 |
| DEPLOY BY FIGURES | 45 | 45 | 25 | 8.33 | +483 | +19.3 |
| SHOT RISK POINTS | 150 | 146 | 25 | 8.33 | +637 | +25.5 |
| THE TABLE AGAIN | 36 | 36 | 24 | 8.00 | +0 | +0.0 |
| GOAL WALK | 64 | 64 | 23 | 7.67 | +1657 | +72.0 |
| OFF BEST | 19 | 19 | 19 | 6.33 | -519 | -27.3 |
| NEXT CHARGE BY LIST | 33 | 30 | 18 | 6.00 | +1280 | +71.1 |
| PROMISE BY ITS OWN SUM | 54 | 54 | 18 | 6.00 | -940 | -52.2 |
| REDIRECT FOR A FRIEND IN REACH | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 134 | 113 | 14 | 4.67 | +39 | +2.8 |
| RANDOM MOVE BY FIGURES | 13 | 13 | 11 | 3.67 | +447 | +40.7 |
| MEETS IN TIME | 16 | 16 | 10 | 3.33 | +1336 | +133.6 |
| SET UP BY THE SET | 19 | 19 | 10 | 3.33 | +542 | +54.2 |
| COVER ONCE | 47 | 32 | 9 | 3.00 | +270 | +30.0 |
| SUPPORT ADDS | 27 | 26 | 9 | 3.00 | +372 | +41.4 |
| SUPPORT WORKED OUT | 27 | 26 | 9 | 3.00 | +372 | +41.4 |
| CHARGE LOSSES | 92 | 91 | 8 | 2.67 | +166 | +20.7 |
| MOVE ORDER | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 17 | 17 | 7 | 2.33 | +72 | +10.3 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| ONE PROMISE A TARGET | 6 | 6 | 6 | 2.00 | -6 | -1.1 |
| CAST JOB | 8 | 8 | 5 | 1.67 | +1 | +0.3 |
| FOUR ROUNDS | 16 | 15 | 5 | 1.67 | +186 | +37.2 |
| HARD STAY DROPPED | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +175 | +35.1 |
| RESERVE FALL BACK | 5 | 5 | 5 | 1.67 | +92 | +18.4 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| IDLE COST | 25 | 14 | 4 | 1.33 | +52 | +12.9 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | -55 | -13.9 |
| MARCH CHECK | 7 | 7 | 4 | 1.33 | +33 | +8.3 |
| MAX FOR POSITIONING | 12 | 11 | 4 | 1.33 | +16 | +3.9 |
| SHOOTS FROM THE BEST SPOT | 7 | 7 | 4 | 1.33 | +1 | +0.2 |
| STUCK PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHARGE NOT DECLARED | 3 | 3 | 3 | 1.00 | -611 | -203.8 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +200 | +66.7 |
| REDIRECT COUNTER | 15 | 12 | 3 | 1.00 | +16 | +5.3 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| TIED UP BY THE SUM | 4 | 4 | 3 | 1.00 | +84 | +28.0 |
| CANNON SIGHT KEPT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | -2 | -0.9 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +3 | +1.6 |
| CHARGE NOW FIRST | 12 | 12 | 2 | 0.67 | -28 | -14.2 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.67 | +18 | +8.9 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.67 | +37 | +18.4 |
| HIS MOVE AND SHOT | 26 | 26 | 2 | 0.67 | +9 | +4.6 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +224 | +112.0 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -86 | -42.8 |
| MOVES UNITS SPELL | 2 | 2 | 2 | 0.67 | +9 | +4.3 |
| NEARER NOT NEEDED | 34 | 29 | 2 | 0.67 | +68 | +33.8 |
| ONE OBJECTIVE FORMULA | 28 | 22 | 2 | 0.67 | +201 | +100.4 |
| PROMISE KNOWS THE FIGHT | 12 | 9 | 2 | 0.67 | -7 | -3.4 |
| SEARCH SPOT | 3 | 3 | 2 | 0.67 | +49 | +24.5 |
| SHOTS IN THE MOVE | 62 | 42 | 2 | 0.67 | +82 | +41.2 |
| THE ROW IN ITS ORDER | 20 | 2 | 2 | 0.67 | +0 | +0.0 |
| WEAPON BY POINTS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 10 | 10 | 2 | 0.67 | +18 | +9.2 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +25 | +25.3 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +1 | +1.1 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -145 | -145.2 |
| FALLS SHORT | 48 | 34 | 1 | 0.33 | +73 | +73.0 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +27 | +27.0 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.33 | +209 | +209.1 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +56 | +56.3 |
| RISK BY ARC | 15 | 14 | 1 | 0.33 | +17 | +16.9 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +131 | +131.1 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +4 | +4.0 |
| STAY WORTH | 61 | 52 | 1 | 0.33 | +1 | +1.4 |
| SURE REACH TOGETHER | 3 | 2 | 1 | 0.33 | +0 | +0.0 |
| WHO GETS IN | 1 | 1 | 1 | 0.33 | +209 | +209.1 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +77 | +77.2 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLANNED TARGET | 7 | 7 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 10 | 7 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 45 | 45 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 12 | 11 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 11 | 10 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 11 | 11 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 4 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 39 | not checked | - | - | - | - |
| FOOT FIRST | 37 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 22 | 20 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 5 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 8 | not checked | - | - | - | - |
| GUN MASK | 2 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 7 | 6 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 65 | 65 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 36 | 33 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 32 | 30 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 38 | 33 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 55 | 51 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 47 | 45 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 7 | 7 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 6 | 6 | 0 | 0.00 | - | - |
| HOLD ODDS | 113 | 113 | 0 | 0.00 | - | - |
| HONEST WORTH | 15 | 14 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 20 | 20 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 12 | 11 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 4 | not checked | - | - | - | - |
| MANOEUVRE | 13 | 13 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 6 | 6 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 19 | 10 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 23 | 14 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 2 | trace | - | - | - | - |
| NEAREST TO GOAL | 4 | 4 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 15 | 14 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 36 | 19 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 5 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 226 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 2 | not checked | - | - | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 6 | 5 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 3 | 3 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 4 | 4 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 4 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 13 | 12 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 10 | not checked | - | - | - | - |
| SET CREDITED ONCE | 10 | 10 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 7 | 5 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 23 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 14 | 14 | 0 | 0.00 | - | - |
| SPELL WORTH | 11 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 58 | 53 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 4 | 4 | 0 | 0.00 | - | - |
| STANDS STILL | 137 | 130 | 0 | 0.00 | - | - |
| STRIKE BY THE ODDS | 1 | 1 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 5 | 5 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 3 | not checked | - | - | - | - |
| THE PROMISE ADDS | 3 | 2 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 14 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 1 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 8 | not checked | - | - | - | - |
| THE TABLE BINDS | 209 | not checked | - | - | - | - |
| WAITS AGAIN | 9 | 8 | 0 | 0.00 | - | - |
| WHO FIGHTS | 3 | 2 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p45

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.33 | 2.00 | 27.3 |
| PROMISE BY ITS OWN SUM | rule | 5.00 | 1.00 | 52.2 |
| ARMY TABLE | rule | 3.33 | 1.00 | 36.1 |
| HOLDER ASSIGNMENT | rule | 0.67 | 0.67 | 48.8 |
| CHARGE NOT DECLARED | rule | 0.67 | 0.33 | 203.8 |
| ONE PROMISE A TARGET | rule | 1.00 | - | 16.9 |
| CHARGE NOW FIRST | rule | 0.33 | 0.33 | 14.2 |
| JOINT CHARGE NOW | rule | 0.67 | - | 162.8 |
| MARCH OF THE TABLE | rule | 0.33 | 0.33 | 42.8 |
| PROMISE KNOWS THE FIGHT | rule | 0.67 | - | 3.4 |
| BEST PRIZE | rule | - | 0.33 | 145.2 |
| CHAFF PASSED | rule | 0.33 | - | 1.7 |

### Plans: gs3-83c8646-p45

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.7 | 82% | 534 | 638 | 119% |
| Mine | move | 33.0 | 94% | 2406 | 0 | 0% |
| Mine | shoot | 5.3 | 69% | 546 | 290 | 53% |
| Opponent | charge | 1.3 | 50% | 205 | 241 | 118% |
| Opponent | move | 29.7 | 93% | 2047 | 0 | 0% |
| Opponent | shoot | 1.7 | 20% | 7 | 12 | 188% |
| Opponent | support | 0.7 | 50% | 0 | 0 | - |

### Battle groups: gs3-83c8646-p45

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.0 | 44% | 100% | 0% | - | 75% | 0% | 0% | 25% | 0% |
| Opponent | REDIRECT COUNTER | 2.0 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p45

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 152 (4) | 152 | 0 | 0 | 0% | 4.8 | 71 (2) | 71 (1) | 283 (1) | 283 (1) | 71 (3) |
| Mine | Chaff | 7 | 70 (7) | 39 | 31 | 29 | 14% | 2.0 | 138 (1) | 29 (4) | 103 (2) | 70 (7) | - |
| Mine | Character | 7 | 28 (7) | 28 | 0 | 29 | 43% | 2.5 | 18 (4) | 88 (2) | 0 (1) | 19 (4) | 42 (3) |
| Mine | Fast Hammer | 1 | 114 (1) | 114 | 0 | 0 | 0% | 1.0 | - | 114 (1) | - | - | 114 (1) |
| Mine | Hammer | 9 | 55 (9) | 30 | 25 | 56 | 22% | 1.6 | 60 (3) | 39 (5) | 149 (1) | 35 (5) | 74 (4) |
| Mine | Shooter | 4 | 71 (4) | 15 | 56 | 113 | 0% | 1.5 | 43 (2) | 105 (2) | - | 125 (1) | 58 (3) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Mine | War machine | 2 | 22 (2) | 22 | 0 | 50 | 0% | 1.0 | - | 22 (2) | - | - | 22 (2) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.5 | - | 0 (2) | - | - | 0 (2) |
| Opponent | Chaff | 3 | 36 (3) | 0 | 36 | 100 | 33% | 2.0 | 0 (1) | 0 (1) | 109 (1) | 36 (3) | - |
| Opponent | Character | 9 | 63 (9) | 63 | 0 | 37 | 33% | 2.7 | 78 (2) | 76 (3) | 0 (2) | 0 (4) | 94 (3) |
| Opponent | Clean-up | 1 | 220 (1) | 0 | 220 | 100 | 0% | 2.0 | - | 220 (1) | - | 220 (1) | - |
| Opponent | Fast Hammer | 4 | 54 (4) | 50 | 4 | 14 | 50% | 2.5 | 99 (2) | 55 (1) | 0 (1) | 53 (3) | 55 (1) |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | - | - | - | - |
| Opponent | Hammer | 10 | 51 (10) | 42 | 10 | 40 | 20% | 3.0 | 75 (3) | 39 (4) | 44 (3) | 71 (6) | 30 (4) |
| Opponent | Holder | 3 | 76 (3) | 0 | 76 | 0 | 100% | - | - | 107 (2) | 0 (1) | 76 (3) | - |
| Opponent | Shooter | 2 | 0 (2) | 0 | 0 | 50 | 50% | 1.0 | - | - | 0 (2) | 0 (1) | 0 (1) |
| Opponent | Wizard | 4 | 0 (4) | 0 | 0 | 63 | 25% | 1.7 | - | 0 (1) | 0 (2) | 0 (2) | 0 (1) |

### Charged fights: gs3-83c8646-p45

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Kingdom of Bretonnia | 1 | 206 | 0 | 3.0 | 1.0 | 0 | 88 | -88 | 2 of 3 | 2 of 3 | - | -88 |
| Mine | Lizardmen | 1 | 211 | 310 | 3.0 | 1.0 | 103 | 47 | +56 | 1 of 3 | 2 of 3 | - | +56 |
| Mine | Ogre Kingdoms | 1 | 460 | 255 | 2.0 | 1.0 | 128 | 0 | +128 | 1 of 2 | 0 of 2 | - | +128 |
| **Mine** | all armies | 3 | 292 | 188 | 2.7 | 1.0 | 71 | 51 | +20 | 4 of 8 | 4 of 8 | - | +20 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 425 | 5.0 | 1.0 | 85 | 36 | +48 | 1 of 10 | 10 of 10 | - | +48 |
| Opponent | Skaven | 1 | 471 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| **Opponent** | all armies | 3 | 157 | 283 | 3.7 | 1.0 | 77 | 33 | +44 | 2 of 11 | 10 of 11 | - | +44 |

### Effective charges: gs3-83c8646-p45

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Kingdom of Bretonnia | 3 | 0 | 0 | 0 | 2 (net +0) | 0 | 1 (net -264) | 0 | 0% (0 of 3) |
| Mine | Lizardmen | 3 | 0 | 0 | 0 | 1 (net -141) | 1 (net +55) | 0 | 1 | 0% (0 of 2) |
| Mine | Ogre Kingdoms | 2 | 1 (net +0) | 0 | 1 (net +255) | 0 | 0 | 0 | 0 | 50% (1 of 2) |
| Opponent | Orc & Goblin Tribes | 10 | 0 | 0 | 0 | 0 | 3 (net +53) | 1 (net +0) | 6 | 0% (0 of 4) |
| Opponent | Skaven | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: gs3-83c8646-p45

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 90 | 255 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 1 | 90 | 60 | +255 | 275 | 0 | +275 | +305.6 |
| Mine | 76-89% | 3 | 242 | 295 | -47 | 118 | 150 | -32 | -13.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 214 | 145 | -264 | 120 | 264 | -144 | -67.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 185 | 55 | +55 | 168 | 0 | +168 | +90.8 |
| Mine | No odds | 1 | 399 | 255 | +255 | 255 | 114 | +141 | +35.3 |
| Mine | All fights | 8 | 213 | 207 | +20 | 146 | 104 | +43 | +20.1 |
| Opponent | Long shot (under 50%) | 1 | 41 | 371 | +0 | 0 | 32 | -32 | -76.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 350 | 251 | +0 | 209 | 100 | +109 | +31.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 271 | 79 | +53 | 53 | 0 | +53 | +19.7 |
| Opponent | No odds | 6 | 249 | 90 | +54 | 123 | 138 | -15 | -6.2 |
| Opponent | All fights | 11 | 245 | 127 | +44 | 100 | 87 | +13 | +5.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p45 | move | 26 | 8 (31%) | 4 (15%) | 2 (8%) | 16 (62%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Elixir of Power | Opponent | L1719, L1819 |
| Fistful of Laurels | Mine | L1819 |
| Periapt of Soul Exchange | Opponent | L1621 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621 |

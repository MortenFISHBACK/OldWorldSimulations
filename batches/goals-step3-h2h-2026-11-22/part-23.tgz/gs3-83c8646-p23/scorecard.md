# Doctrine scorecard: gs3-83c8646-p23

### Scorecard: gs3-83c8646-p23

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2131 | 1 | 1 | Mine | yes | 1 | - | 1 | 5 | 0 | 0 | 0 | 145 |
| L2131 | 1 | 1 | Opponent | no | 0 | 4 | 1 | 2 | 1 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | no | 0 | 2 | 1 | 0 | 0 | 0 | 0 | 225 |
| L2235 | 3 | 1 | Opponent | no | 14 | 2 | 2 | 2 | 0 | 0 | 0 | 114 |
| L2429 | 5 | 1 | Mine | yes | - | - | 1 | 4 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 2 | 5 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 67% | 0.5 | 2.0 | 1.0 | 3.0 | 0.0 | 0.0 | 0.0 | 123.3 |
| **Average** | | | Opponent | 33% | 7.0 | 3.0 | 1.7 | 3.0 | 0.3 | 0.0 | 0.0 | 94.7 |

### KPIs: gs3-83c8646-p23

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 16) | 0% (0 of 15) | 0% (0 of 31) |
| Winner chose to follow up after the loser gave ground |  | 0% (0 of 2); on the table 100% | - | 0% (0 of 2); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | - | 0% (0 of 1); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 25% (1 of 4); on the table 75% | - | 25% (1 of 4); on the table 75% |
| Magic missiles tried each own turn | 50%+ | 25% (3 of 12) | - | 25% (3 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 25% (3 of 12) | - | 25% (3 of 12) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 62% (8 of 13) | 54% (7 of 13) | 58% (15 of 26) |
| Points that never fought | lower | 58% (3497 of 5997) | 65% (3902 of 5999) | 62% (7399 of 11996) |
|   infantry points that never fought | lower | 76% (1268 of 1675) | 81% (1056 of 1306) | 78% (2324 of 2981) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 71% (15 of 21) | 74% (23 of 31) | 73% (38 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.7 uses a game | 100% (2 of 2); 2.3 uses a game | 100% (3 of 3); 2.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 64% (3105 of 4866) | 68% (4019 of 5884) | 66% (7124 of 10750) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (44%) | - | 1.3 (44%) |
| MARCHED: its unit marched | 1.7 (56%) | - | 1.7 (56%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.7 | 2.7 | 1.0 | 1.0 | 1.3 |
| not cast | 5.3 | 5.3 | 1.0 | 3.0 | 22.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 5.3 (100%) | 0.0 (0%) | 1.3 (44%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (56%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.0 (13%) |
| HELD BACK: the computer weighed it and chose not to cast it | 5.3 (100%) | 0.0 (0%) | 1.0 (100%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 19.0 (84%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.0 a game | 0.5 a game |
| stood (cast and not dispelled) | - | 67% (2 of 3) | 67% (2 of 3) |
| the unit moved after it | - | 0% (0 of 2) | 0% (0 of 2) |
| it charged on its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| the enemy charged it first | - | 0% (0 of 2) | 0% (0 of 2) |
| it fought by the end of its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 2) | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (2 of 2) | 100% (2 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 72% (50 of 69) | 61% (23 of 38) | 68% (73 of 107) |
|   cavalry | 100% (12 of 12) | 75% (12 of 16) | 86% (24 of 28) |
|   character | 0% (0 of 9) | 20% (2 of 10) | 11% (2 of 19) |
|   chariot | 100% (13 of 13) | - | 100% (13 of 13) |
|   infantry | 71% (25 of 35) | 75% (9 of 12) | 72% (34 of 47) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.0 (0%) | 1.0 (20%) | 1.0 (9%) |
| CHARGED: it charged | 1.7 (26%) | 1.0 (20%) | 2.7 (24%) |
| NO TARGET IN RANGE | 3.3 (53%) | 3.0 (60%) | 6.3 (56%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (21%) | 0.0 (0%) | 1.3 (12%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 14.3 | 2.0 | 86% | 3.2 pts | 46 pts |
| character | 0.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 4.3 | 0.7 | 92% | 5.9 pts | 26 pts |
| infantry | 12.3 | 5.7 | 62% | 11.6 pts | 143 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.3 | 2.0 | 2.2 |
| Charges that made contact a game | 2.0 | 1.3 | 1.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | - | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.25 declared, 0.21 contact (28 units) | 0.24 declared, 0.16 contact (25 units) | 0.25 declared, 0.19 contact (53 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (4 of 6) | 100% (4 of 4) | - | 80% (8 of 10) |
| Character in a unit | 100% (3 of 3) | 100% (2 of 2) | 100% (1 of 1) | 100% (6 of 6) |
| Character on its own | 100% (4 of 4) | - | 29% (2 of 7) | 55% (6 of 11) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 73% (8 of 11) | 75% (3 of 4) | - | 73% (11 of 15) |
| Monster | 60% (3 of 5) | 100% (1 of 1) | - | 67% (4 of 6) |
| Monstrous | 100% (2 of 2) | - | - | 100% (2 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Skaven | 1 | 0% (0 of 2); on the table 100% | 50% (3 of 6) | 41% | 56% (5 of 9) | 100% (1 of 1); 5.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 1 | 50% (1 of 2); on the table 50% | - | 45% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | - | 0% (0 of 6) | 89% | 100% (7 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | - | - | 72% | 74% (14 of 19) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | - | 51% | 75% (9 of 12) | 100% (1 of 1); 5.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p23, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (1) | 75% (3) | 67% (4) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.67 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p23

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 83% (5 of 6) | 60% (3 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 41% (7 of 17) | 33% (3 of 9) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 1) | 60% (3 of 5) |
| Strategy | Joined characters whose unit fought | 20% (1 of 5) | 0% (0 of 3) |
| Strategy | Lone characters that fought | 67% (4 of 6) | 50% (3 of 6) |
| Movement | Charges halted short of contact | 0.0 | 0.7 |
| Movement | Idle units | 3.0 | 3.0 |
| Movement | Points that never moved of their own | 123.3 | 94.7 |
| Movement | Fights charged into per game | 2.0 | 1.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 5 | 0 of 4 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 5 | 0 of 4 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 5, net +118 | 2 of 4, net +58 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 5, net +0 | 2 of 4, net +98 |
| Shooting | Shots by shooting units (incl. breath weapons) | 17.7 | 8.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 21% (11 of 53) | 23% (6 of 26) |
| Shooting | Points destroyed by shooting units | 187.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.0 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 3) | - |
| Magic | Wounds caused by magic missiles | 0.3 | 2.7 |
| Magic | Wounds caused by other spells | 1.0 | - |
| Magic | Points destroyed by magic (all spells) | 38.7 | 18.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 4.3 / 0.3 / 0.7 / 0.0 | 0.0 / 1.7 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 76.0 | 265.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +39 | +77 |
| Combat | Net per 100 charger points, damage counted | +12.2 | +19.3 |
| Combat | First round won (charged fights) | 100% | 75% |
| Combat | Net points per charged fight | +13 | +78 |
| Combat | Net points per supported fight / lone fight | - / +13 | - / +78 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 6 | 2 of 4 |
| Game | Points lost | 250.0 | 381.3 |
| Game | VP from objectives | 970.0 | 490.0 |
| Game | Lone holders (player turns) | 0.5 | 7.0 |

- Mine won / drew / lost: 3 / 0 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +596 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 631
- Games not ended: 0; findings 2, warnings 0

### Opponent rules: gs3-83c8646-p23

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 41.7 |
| AFTERMATH IN POINTS | 0.3 | +34.9 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 32.0 | -74.7 | 0.0 | 148.3 | 22.0 | -106.0 | 0.0 | 240.3 |
| BACKUP TARGETS | - | - | - | - | 1.0 | +1.3 | 0.0 | 76.0 |
| CAST JOB | 0.7 | +2.1 | 0.0 | 0.0 | 1.7 | +19.0 | 21.7 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.0 | +20.9 | 0.0 | 20.0 | 1.3 | +17.5 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 1.3 | -1.4 | 65.0 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.7 | +31.8 | 0.0 | 41.7 |
| CHARACTER GUNS | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 11.0 | -511.5 | 0.0 | 130.0 | 22.3 | -430.9 | 0.0 | 385.0 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 42.0 | 0.0 | 0.7 | +0.0 | 85.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 13.3 | +0.0 | 0.0 | 0.0 | 11.7 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 1.0 | +11.4 | 0.0 | 0.0 |
| COVER ONCE | 5.0 | -336.7 | 0.0 | 0.0 | 8.3 | -415.0 | 0.0 | 277.3 |
| DEPLOY BY FIGURES | 7.7 | +9.0 | 0.0 | 0.0 | 7.7 | +16.7 | 0.0 | 41.7 |
| DUEL STOPS AT THE KILL | 0.3 | -1.1 | 41.7 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | - | - | - | - | 2.0 | +378.9 | 18.3 | 41.7 |
| EXACT ROUND | 1.7 | +6.1 | 76.0 | 21.7 | 1.0 | +5.0 | 18.3 | 38.7 |
| FALL BACK GOOD ORDER | 1.0 | +0.0 | 117.7 | 0.0 | 1.0 | +9.4 | 0.0 | 38.7 |
| FALLS SHORT | 7.7 | +111.4 | 0.0 | 20.0 | 14.3 | +193.3 | 0.0 | 225.0 |
| FEATURE BUFFS | 0.3 | +10.3 | 0.0 | 0.0 | 0.7 | +21.7 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +18.7 | 0.0 | 0.0 | - | - | - | - |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 102.0 | +6533.4 | 937.7 | 420.0 | 85.7 | +5674.5 | 146.7 | 1000.0 |
| FLANK NOT WEIGHED | 5.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 75.7 |
| FOCUS FIRE | 1.0 | +60.7 | 83.3 | 0.0 | - | - | - | - |
| FOOT FIRST | - | - | - | - | 24.3 | +0.0 | 0.0 | 235.0 |
| FOUR ROUNDS | 2.3 | +160.9 | 117.7 | 21.7 | 2.0 | +163.8 | 103.3 | 38.7 |
| FREED FROM HIS FIGHT | - | - | - | - | 3.0 | +0.0 | 0.0 | 167.3 |
| FRIEND SHOOTS FIRST | 0.7 | -2.1 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | - | - | - | - | 0.3 | -13.5 | 0.0 | 38.7 |
| GOAL WALK | 4.0 | +167.5 | 0.0 | 0.0 | 12.3 | +1141.1 | 0.0 | 83.3 |
| GUN FIGURES | 2.0 | +0.3 | 38.7 | 21.7 | - | - | - | - |
| HARD STAY DROPPED | 3.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 76.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 6.3 | +0.0 | 0.0 | 130.0 | 9.0 | +0.0 | 0.0 | 269.0 |
| HIS CHARGE DENIED | 0.3 | +9.4 | 34.0 | 0.0 | 0.3 | +31.2 | 65.0 | 0.0 |
| HIS CHARGE LIST | 9.3 | +0.0 | 0.0 | 60.0 | 9.0 | +0.0 | 0.0 | 84.0 |
| HIS LEGAL MOVES | 1.3 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 161.3 |
| HIS MOVE AND SHOT | 3.3 | -32.3 | 0.0 | 40.0 | 3.7 | -13.2 | 0.0 | 0.0 |
| HIS ONE QUARTER | 7.3 | +0.0 | 0.0 | 43.3 | 8.3 | +0.0 | 0.0 | 116.0 |
| HIS OWN BEST MOVE | 5.0 | +0.0 | 0.0 | 170.0 | 7.7 | +0.0 | 0.0 | 229.3 |
| HIS RANDOM MOVE | 28.3 | +0.0 | 0.0 | 231.7 | 14.3 | +0.0 | 0.0 | 193.3 |
| HIS RANDOM MOVER COMES | 2.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 33.7 | +472.1 | 0.0 | 193.3 | 46.0 | +864.4 | 0.0 | 843.7 |
| HIS SHOTS BY HIS RUN | 24.7 | +330.8 | 0.0 | 170.0 | 36.7 | +311.0 | 0.0 | 713.7 |
| HIS TURN DENIED | 0.3 | +4.5 | 42.0 | 0.0 | 0.3 | +17.8 | 0.0 | 0.0 |
| HOLD ODDS | 22.7 | +0.0 | 0.0 | 0.0 | 14.0 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 14.7 | +1185.4 | 0.0 | 0.0 | 9.0 | +663.0 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.0 | -77.4 | 117.7 | 0.0 | 1.7 | -84.1 | 103.3 | 0.0 |
| IDLE COST | 5.0 | -88.9 | 0.0 | 0.0 | 11.3 | -127.1 | 0.0 | 263.0 |
| KEPT FROM ITS LAST STOP | 5.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +16.4 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 9.7 | +0.0 | 349.0 | 18.3 | 3.7 | +0.0 | 0.0 | 307.3 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.3 | +9.4 | 0.0 | 65.0 |
| LONE WIZARD KEPT IN | 1.0 | +52.2 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 0.7 | +0.1 | 41.7 | 0.0 | 0.3 | -0.1 | 0.0 | 0.0 |
| LURE BY WHAT IT DRAWS | 0.3 | -19.6 | 0.0 | 20.0 | - | - | - | - |
| MANOEUVRE | 1.0 | +0.0 | 0.0 | 21.7 | 1.7 | +5.7 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +30.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.3 | +16.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.7 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | -45.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.0 | +20.2 | 0.0 | 0.0 | 1.3 | +9.5 | 0.0 | 0.0 |
| MEETS IN TIME | 5.3 | +188.6 | 0.0 | 0.0 | 3.7 | +115.9 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.7 | +33.6 | 0.0 | 0.0 | 3.3 | +45.6 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 4.3 | +27.6 | 0.0 | 0.0 | 3.0 | +24.4 | 0.0 | 0.0 |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 18.3 | 1.7 | +0.0 | 41.7 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 1.0 | -4.9 | 83.3 | 0.0 |
| MOVE TO CHARGE COMPUTED | 5.3 | +627.0 | 0.0 | 170.0 | 5.7 | +519.8 | 0.0 | 145.3 |
| NEARER NOT NEEDED | 10.3 | +340.3 | 0.0 | 20.0 | 6.3 | +272.3 | 0.0 | 76.0 |
| NEAREST TO GOAL | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 3.3 | +424.9 | 0.0 | 170.0 | 4.0 | +305.6 | 0.0 | 145.3 |
| NEXT OBJECTIVE NEARER | 0.3 | -10.0 | 0.0 | 0.0 | 0.3 | -15.9 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.0 | -89.7 | 117.7 | 0.0 | 1.3 | -59.5 | 85.0 | 38.7 |
| NO LATE CUT | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 5.3 | -4.5 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 6.3 | -289.9 | 0.0 | 18.3 | 6.0 | -211.9 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.3 | -67.8 | 0.0 | 65.0 | 6.7 | -225.4 | 0.0 | 214.3 |
| ONE OBJECTIVE FORMULA | 6.3 | +127.4 | 0.0 | 0.0 | 3.3 | +40.0 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.7 | +29.2 | 0.0 | 0.0 |
| ONE ROUTE | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +11.0 | 0.0 | 0.0 | 0.7 | +10.8 | 38.3 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.3 | +11.0 | 0.0 | 0.0 |
| PATHS CROSS | 0.3 | +4.4 | 0.0 | 0.0 | 0.7 | +6.2 | 0.0 | 0.0 |
| PERIAPT WORTH | 0.3 | +40.5 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 48.7 | +421.9 | 337.7 | 313.3 | 41.7 | +155.6 | 21.7 | 572.7 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 9.3 | -370.7 | 0.0 | 0.0 | 10.3 | -375.5 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -6.3 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 27.0 | +2462.2 | 41.7 | 65.0 | 25.0 | +2591.5 | 43.3 | 116.0 |
| RANDOM MOVE BY FIGURES | 4.3 | +68.0 | 0.0 | 48.3 | 4.3 | +78.1 | 0.0 | 0.0 |
| REAL GROUND | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.7 | +265.9 | 0.0 | 0.0 | 0.7 | +18.7 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 4.7 | +0.0 | 0.0 | 40.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.0 | -17.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 1.3 | +43.2 | 0.0 | 0.0 | 1.3 | +33.8 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.3 | +3.1 | 0.0 | 0.0 |
| RISK BY ARC | 0.7 | +26.7 | 41.7 | 0.0 | 2.0 | +23.3 | 103.3 | 38.7 |
| ROUNDS AFTER TERROR | 0.3 | -6.7 | 42.0 | 0.0 | - | - | - | - |
| RUN DOWN | 1.3 | -6.0 | 83.7 | 0.0 | 0.3 | -0.5 | 0.0 | 0.0 |
| SCOUT SPOT | 0.7 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | 0.7 | -8.7 | 0.0 | 0.0 | 1.3 | -97.3 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +3.3 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +15.6 | 0.0 | 0.0 | 0.3 | +6.0 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.7 | -5.8 | 0.0 | 0.0 | 0.3 | -0.4 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.7 | +1.8 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +1.3 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 6.0 | +0.0 | 0.0 | 18.3 | 3.7 | +0.0 | 0.0 | 38.0 |
| SHOOTS FROM THE BEST SPOT | 3.0 | +78.3 | 213.3 | 0.0 | 1.0 | +11.5 | 21.7 | 0.0 |
| SHOT OR CHARGE | 0.7 | -10.1 | 34.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 15.3 | -164.9 | 0.0 | 83.3 | 21.7 | -249.2 | 0.0 | 379.0 |
| SHOTS AFTER THE MOVES | 2.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 15.0 | +211.5 | 0.0 | 40.0 | 9.0 | +109.3 | 0.0 | 160.0 |
| SPELL WORTH | 0.7 | +9.7 | 0.0 | 0.0 | - | - | - | - |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | -2.7 | 0.0 | 38.7 |
| SPOT AS THE GAME MOVES | 6.0 | +0.0 | 0.0 | 105.0 | 11.0 | +0.0 | 0.0 | 119.0 |
| STAND AND SHOOT | 0.3 | -0.6 | 0.0 | 0.0 | 0.7 | -2.6 | 18.3 | 0.0 |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 84.0 |
| STANDS STILL | 44.7 | +0.0 | 820.0 | 85.0 | 32.7 | +0.0 | 43.3 | 352.0 |
| STAY WORTH | 16.7 | +67.0 | 568.0 | 21.7 | 11.7 | +78.1 | 0.0 | 236.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +7.9 | 21.7 | 0.0 |
| STUCK PIVOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 8.0 | +757.3 | 0.0 | 56.7 | 3.3 | +160.5 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 8.0 | +757.3 | 0.0 | 56.7 | 3.3 | +160.5 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.7 | +6.0 | 0.0 | 38.7 |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -6.3 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 41.7 |
| THE ROW KEEPS ITS WAY | 4.3 | +0.0 | 0.0 | 21.7 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 3.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 49.3 | +0.0 | 0.0 | 165.0 | 41.0 | +0.0 | 0.0 | 526.3 |
| TIED UP BY THE SUM | 1.7 | +231.0 | 117.7 | 0.0 | 0.7 | +84.3 | 38.3 | 0.0 |
| TIME ON OUR SIDE | 34.3 | +323.0 | 68.0 | 123.3 | 16.3 | +173.1 | 0.0 | 0.0 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| WEAPON BY POINTS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | 0.7 | +8.3 | 0.0 | 43.3 | 0.7 | +19.6 | 0.0 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +4.1 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.3 | +0.1 | 0.0 | 21.7 | 0.3 | +0.3 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 3.3 | -359.9 | 0.0 | 130.0 | 1.7 | -126.5 | 0.0 | 83.3 |
| WOUNDS ON THE RANKS | 0.7 | +1.9 | 0.0 | 0.0 | 4.0 | +95.4 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p23

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 162 | 162 | 111 | 37.00 | -112 | -1.0 |
| HOLDER ASSIGNMENT | 71 | 71 | 67 | 22.33 | +4168 | +62.2 |
| HIS SHOT LIST | 239 | 220 | 47 | 15.67 | +451 | +9.6 |
| LEGAL CHARGES ONLY | 40 | 40 | 40 | 13.33 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 184 | 169 | 39 | 13.00 | +278 | +7.1 |
| OFF BEST | 37 | 37 | 37 | 12.33 | -1506 | -40.7 |
| THE TABLE AGAIN | 36 | 36 | 31 | 10.33 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 59 | 59 | 25 | 8.33 | -2239 | -89.5 |
| DEPLOY BY FIGURES | 46 | 46 | 23 | 7.67 | +275 | +12.0 |
| QUARTER ODDS | 156 | 151 | 23 | 7.67 | +1273 | +55.3 |
| HARD STAY DROPPED | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| FIVE ACTION | 563 | 535 | 15 | 5.00 | +828 | +55.2 |
| RANDOM MOVE BY FIGURES | 26 | 26 | 15 | 5.00 | +438 | +29.2 |
| REDIRECT FOR A FRIEND IN REACH | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| TIME ON OUR SIDE | 152 | 124 | 14 | 4.67 | +12 | +0.8 |
| ADVANCE LANE KEPT | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 33 | 22 | 12 | 4.00 | +985 | +82.1 |
| MEETS IN TIME | 27 | 27 | 11 | 3.67 | +349 | +31.8 |
| NEXT CHARGE BY LIST | 22 | 19 | 11 | 3.67 | +972 | +88.3 |
| SUPPORT ADDS | 34 | 34 | 11 | 3.67 | +215 | +19.5 |
| SUPPORT WORKED OUT | 34 | 34 | 11 | 3.67 | +215 | +19.5 |
| FOUR ROUNDS | 13 | 12 | 10 | 3.33 | +244 | +24.4 |
| SHOOTS FROM THE BEST SPOT | 12 | 12 | 10 | 3.33 | +47 | +4.7 |
| GOAL WALK | 49 | 47 | 9 | 3.00 | +466 | +51.8 |
| MOVE ORDER | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| COVER ONCE | 40 | 25 | 8 | 2.67 | +162 | +20.2 |
| RESERVE FALL BACK | 8 | 8 | 8 | 2.67 | +231 | +28.9 |
| CHAFF IN THE MOVE | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| HOLDS AMBUSHERS | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| SHOT RISK POINTS | 111 | 100 | 7 | 2.33 | +74 | +10.6 |
| TIED UP BY THE SUM | 7 | 7 | 7 | 2.33 | +180 | +25.8 |
| IDLE COST | 49 | 29 | 6 | 2.00 | +21 | +3.5 |
| NEARER NOT NEEDED | 50 | 47 | 6 | 2.00 | +168 | +28.1 |
| CAST JOB | 7 | 7 | 5 | 1.67 | +6 | +1.3 |
| CHAFF PASSED | 4 | 4 | 4 | 1.33 | -4 | -1.0 |
| EVASIVE BY THE ODDS | 6 | 6 | 4 | 1.33 | +1135 | +283.8 |
| STUCK PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| FALLS SHORT | 66 | 56 | 3 | 1.00 | +27 | +8.9 |
| FOCUS FIRE | 3 | 3 | 3 | 1.00 | +182 | +60.7 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +157 | +52.2 |
| MAX FOR POSITIONING | 7 | 6 | 3 | 1.00 | +10 | +3.2 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +32 | +10.6 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +96 | +47.8 |
| CHARGE LOSSES | 100 | 89 | 2 | 0.67 | +253 | +126.5 |
| EXACT ROUND | 8 | 8 | 2 | 0.67 | +12 | +6.2 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +51 | +25.7 |
| MANOEUVRE | 8 | 8 | 2 | 0.67 | +17 | +8.5 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -4 | -1.9 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | +88 | +43.8 |
| RISK BY ARC | 8 | 7 | 2 | 0.67 | +49 | +24.6 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +65 | +32.3 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +5 | +2.5 |
| SHOTS IN THE MOVE | 72 | 53 | 2 | 0.67 | +23 | +11.5 |
| STAY WORTH | 85 | 74 | 2 | 0.67 | +37 | +18.4 |
| WHAT THE JOINER ADDS | 4 | 2 | 2 | 0.67 | +2 | +0.8 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +105 | +104.6 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 6 | 5 | 1 | 0.33 | +12 | +11.6 |
| FIGHT TO THE END | 1 | 1 | 1 | 0.33 | +37 | +37.5 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS CHARGE DENIED | 2 | 2 | 1 | 0.33 | +24 | +23.9 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +91 | +90.9 |
| MARCH CHECK | 1 | 1 | 1 | 0.33 | +8 | +7.7 |
| MISSILES IN THE MOVE | 21 | 13 | 1 | 0.33 | +7 | +7.1 |
| ONE FIGHT FORMULA | 30 | 8 | 1 | 0.33 | +19 | +19.2 |
| ONE OBJECTIVE FORMULA | 29 | 16 | 1 | 0.33 | +37 | +36.5 |
| OPENS UP | 3 | 3 | 1 | 0.33 | +7 | +6.7 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +122 | +121.5 |
| REDIRECT COUNTER | 10 | 9 | 1 | 0.33 | +15 | +15.3 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +9 | +9.2 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +10 | +10.1 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +24 | +23.7 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -2 | -1.7 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +12 | +12.5 |
| WHOLE FIGHT DANGER | 15 | 15 | 1 | 0.33 | +230 | +229.5 |
| BACKUP TARGETS | 3 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CHARACTER GUNS | 10 | 10 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 4 | 4 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 75 | 75 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 32 | not checked | - | - | - | - |
| FOOT FIRST | 73 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 9 | 9 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 6 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 46 | 43 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 55 | 54 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 25 | 22 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 21 | 15 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 47 | 45 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 38 | 30 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 128 | 125 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 8 | 8 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HOLD ODDS | 110 | 110 | 0 | 0.00 | - | - |
| HONEST WORTH | 11 | 10 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 25 | 25 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 4 | 4 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LOST AFTER ESCAPE | 3 | 3 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 22 | 17 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 3 | trace | - | - | - | - |
| NEAREST TO GOAL | 8 | 8 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 2 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 10 | 10 | 0 | 0.00 | - | - |
| NO LATE CUT | 9 | 9 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 16 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 271 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 6 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 3 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 5 | 5 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 0 | 0.00 | - | - |
| SET UP BY THE SET | 3 | 3 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 29 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 10 | 10 | 0 | 0.00 | - | - |
| SPELL WORTH | 2 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 51 | 43 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 11 | 7 | 0 | 0.00 | - | - |
| STANDS STILL | 232 | 221 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 6 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 25 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 19 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 14 | not checked | - | - | - | - |
| THE TABLE BINDS | 271 | not checked | - | - | - | - |
| WAITS AGAIN | 5 | 5 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 2 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 14 | 14 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p23

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.67 | 5.00 | 37.2 |
| PROMISE BY ITS OWN SUM | rule | 4.33 | 4.00 | 89.5 |
| ARMY TABLE | rule | 3.00 | 3.33 | 64.0 |
| CHAFF PASSED | rule | - | 1.33 | 1.0 |
| NO REASON | gate | - | 1.00 | 93.3 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.33 | 20.1 |
| MARCH OF THE TABLE | rule | 0.67 | - | 1.9 |
| RULE SWITCHED OFF | gate | 0.67 | - | 17.3 |
| SUPPORT NARROWED | rule | 0.33 | - | 1.7 |

### Plans: gs3-83c8646-p23

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.0 | 83% | 241 | 148 | 61% |
| Mine | join | 1.7 | 100% | 96 | 0 | 0% |
| Mine | move | 40.3 | 96% | 1934 | 0 | 0% |
| Mine | shoot | 4.3 | 69% | 255 | 274 | 107% |
| Mine | support | 0.3 | 100% | 0 | 0 | - |
| Opponent | charge | 1.7 | 60% | 151 | 103 | 68% |
| Opponent | join | 1.3 | 75% | 54 | 0 | 0% |
| Opponent | move | 35.7 | 97% | 1933 | 0 | 0% |
| Opponent | shoot | 2.3 | 71% | 120 | 52 | 44% |
| Opponent | support | 0.7 | 100% | 0 | 0 | - |

### Battle groups: gs3-83c8646-p23

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.7 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 0.7 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p23

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Chaff | 5 | 113 (5) | 0 | 113 | 36 | 40% | 1.7 | 139 (4) | 0 (1) | - | 139 (4) | 0 (1) |
| Mine | Character | 9 | 21 (9) | 21 | 0 | 9 | 33% | 3.7 | 20 (5) | 27 (3) | - | 43 (3) | 7 (5) |
| Mine | Clean-up | 2 | 8 (2) | 0 | 8 | 0 | 0% | 4.0 | - | 0 (1) | 14 (1) | 14 (1) | 0 (1) |
| Mine | Fast Hammer | 4 | 0 (4) | 0 | 0 | 24 | 50% | 1.5 | 0 (2) | 0 (2) | - | 0 (1) | 0 (3) |
| Mine | Hammer | 4 | 46 (4) | 46 | 0 | 22 | 25% | 1.0 | 0 (1) | 88 (2) | 0 (1) | 62 (3) | 0 (1) |
| Mine | Holder | 7 | 38 (7) | 0 | 38 | 0 | 100% | - | 104 (2) | 0 (3) | 0 (1) | 41 (6) | - |
| Mine | Shooter | 5 | 115 (5) | 85 | 31 | 63 | 0% | 1.2 | 391 (1) | 0 (2) | 104 (2) | 116 (3) | 114 (2) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | - | - | - | 0 (2) |
| Opponent | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Character | 9 | 12 (9) | 12 | 0 | 17 | 56% | 2.0 | 17 (6) | 0 (2) | 0 (1) | 17 (6) | 5 (3) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 5 | 34 (5) | 0 | 34 | 14 | 60% | 1.0 | 53 (3) | - | 0 (2) | 0 (2) | 61 (3) |
| Opponent | Hammer | 10 | 32 (10) | 32 | 0 | 31 | 30% | 2.9 | 62 (4) | 0 (5) | 0 (1) | 79 (4) | 0 (6) |
| Opponent | Holder | 4 | 12 (4) | 0 | 12 | 0 | 100% | - | 25 (1) | 21 (1) | 0 (1) | - | 15 (3) |
| Opponent | Shooter | 3 | 58 (3) | 0 | 58 | 31 | 0% | 1.3 | 0 (1) | 94 (2) | - | - | 58 (3) |

### Charged fights: gs3-83c8646-p23

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 1 | 427 | 0 | 1.0 | 1.0 | 0 | 275 | -275 | 0 of 1 | 1 of 1 | - | -275 |
| Mine | Tomb Kings of Khemri | 1 | 250 | 353 | 4.0 | 1.0 | 88 | 0 | +88 | 0 of 4 | 4 of 4 | - | +88 |
| Mine | Vampire Counts | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| **Mine** | all armies | 3 | 226 | 118 | 2.0 | 1.0 | 59 | 46 | +13 | 0 of 6 | 6 of 6 | - | +13 |
| Opponent | Warriors of Chaos | 2 | 28 | 30 | 1.0 | 1.0 | 30 | 0 | +30 | 1 of 2 | 1 of 2 | - | +30 |
| Opponent | Wood Elf Realms | 1 | 0 | 250 | 2.0 | 1.0 | 125 | 0 | +125 | 1 of 2 | 2 of 2 | - | +125 |
| **Opponent** | all armies | 3 | 18 | 103 | 1.3 | 1.0 | 78 | 0 | +78 | 2 of 4 | 3 of 4 | - | +78 |

### Effective charges: gs3-83c8646-p23

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 1 | 0 | 0 | 0 | 1 (net -275) | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 4 | 0 | 0 | 0 | 0 | 3 (net +118) | 0 | 1 | 0% (0 of 3) |
| Mine | Vampire Counts | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | Warriors of Chaos | 2 | 0 | 0 | 0 | 0 | 1 (net +60) | 1 (net +0) | 0 | 0% (0 of 2) |
| Opponent | Wood Elf Realms | 2 | 0 | 0 | 0 | 0 | 1 (net +55) | 1 (net +195) | 0 | 0% (0 of 2) |

### Charged fights, damage counted: gs3-83c8646-p23

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 1 | 65 | 170 | -275 | 0 | 329 | -329 | -505.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 161 | 170 | +0 | 57 | 0 | +57 | +35.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 418 | 118 | +118 | 168 | 0 | +168 | +40.2 |
| Mine | No odds | 1 | 411 | 125 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | All fights | 6 | 315 | 136 | +13 | 93 | 55 | +39 | +12.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 308 | 318 | +98 | 125 | 0 | +125 | +40.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 496 | 58 | +58 | 58 | 28 | +30 | +6.0 |
| Opponent | All fights | 4 | 402 | 188 | +78 | 91 | 14 | +77 | +19.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p23 | move | 19 | 5 (26%) | 3 (16%) | 0 (0%) | 14 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2429 |
| Invocation of Nehek | Mine | L2429 |
| Periapt of Soul Exchange | Mine | L2131 |
| Ring of Doom | Opponent | L2131 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |

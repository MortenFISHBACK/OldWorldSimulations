# Doctrine scorecard: gs3-83c8646-p93

### Scorecard: gs3-83c8646-p93

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1621 | 1 | 1 | Mine | no | 4 | 2 | 4 | 2 | 0 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 0 | - | 2 | 5 | 0 | 0 | 0 | 508 |
| L1719 | 3 | 1 | Mine | no | 7 | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Opponent | no | 3 | 2 | 6 | 1 | 0 | 0 | 0 | 226 |
| L1819 | 1 | 1 | Mine | yes | 0 | - | 2 | 0 | 0 | 0 | 0 | 68 |
| L1819 | 1 | 1 | Opponent | yes | 1 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 3.7 | 2.0 | 3.7 | 0.7 | 0.3 | 0.0 | 0.0 | 89.3 |
| **Average** | | | Opponent | 33% | 1.3 | 2.0 | 4.3 | 2.7 | 0.0 | 0.0 | 0.0 | 244.7 |

### KPIs: gs3-83c8646-p93

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 25% (4 of 16) | 12% (2 of 16) | 19% (6 of 32) |
| Winner chose to follow up after the loser gave ground |  | 67% (2 of 3); on the table 67% | 100% (2 of 2); on the table 100% | 80% (4 of 5); on the table 80% |
| Winner chose to pursue after the loser fell back in good order |  | 67% (2 of 3); on the table 67% | 100% (1 of 1); on the table 100% | 75% (3 of 4); on the table 75% |
| Winner chose to pursue after the loser fled |  | 67% (2 of 3); on the table 67% | 80% (4 of 5); on the table 80% | 75% (6 of 8); on the table 75% |
| Winner chose to follow up or pursue (all three) |  | 67% (6 of 9); on the table 67% | 88% (7 of 8); on the table 88% | 76% (13 of 17); on the table 76% |
| Magic missiles tried each own turn | 50%+ | - | 39% (14 of 36) | 39% (14 of 36) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 67% (14 of 21) | 67% (14 of 21) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 57% (4 of 7) | 57% (4 of 7) |
| Points that never fought | lower | 36% (2142 of 6000) | 45% (2717 of 5999) | 40% (4859 of 11999) |
|   infantry points that never fought | lower | 67% (792 of 1187) | 74% (656 of 888) | 70% (1448 of 2075) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 50% (10 of 20) | 60% (15 of 25) | 56% (25 of 45) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.7 uses a game | 100% (1 of 1); 1.0 uses a game | 100% (2 of 2); 1.3 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 67% (2 of 3); 0.7 uses a game | 75% (3 of 4); 0.5 uses a game |
|   their share of the points of units over 100 pts | lower | 44% (2171 of 4880) | 59% (3105 of 5296) | 52% (5276 of 10176) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.7 (23%) | 1.7 (23%) |
| MARCHED: its unit marched | - | 0.7 (9%) | 0.7 (9%) |
| IN COMBAT: engaged in combat | - | 0.7 (9%) | 0.7 (9%) |
| GONE: slain | - | 4.3 (59%) | 4.3 (59%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 2.7 | 0.0 | 0.0 | 4.7 | 2.7 |
| not cast | 3.3 | 2.0 | 6.0 | 7.3 | 25.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (23%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (9%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (9%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (60%) | 2.0 (100%) | 2.0 (33%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 1.0 (17%) | 4.3 (59%) | 4.0 (16%) |
| OTHER BAR: another bar (miscast, baggage ...) | 1.3 (40%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.0 (0%) | 0.0 (0%) | 3.0 (50%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 20.3 (80%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 56% (53 of 95) | 70% (14 of 20) | 58% (67 of 115) |
|   cavalry | 33% (4 of 12) | - | 33% (4 of 12) |
|   character | 100% (6 of 6) | - | 100% (6 of 6) |
|   chariot | 83% (10 of 12) | 75% (6 of 8) | 80% (16 of 20) |
|   infantry | 50% (20 of 40) | 67% (8 of 12) | 54% (28 of 52) |
|   monster | 39% (7 of 18) | - | 39% (7 of 18) |
|   war machine | 86% (6 of 7) | - | 86% (6 of 7) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.7 (26%) | 0.0 (0%) | 3.7 (23%) |
| CHARGED: it charged | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 1.3 (10%) | 0.7 (33%) | 2.0 (12%) |
| NO TARGET IN RANGE | 5.7 (40%) | 0.7 (33%) | 6.3 (40%) |
| ONLY IN COMBAT: the only targets were in combat | 1.0 (7%) | 0.0 (0%) | 1.0 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (10%) | 0.7 (33%) | 2.0 (12%) |
| OTHER BAR | 0.7 (5%) | 0.0 (0%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 1.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| character | 2.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 5.3 | 0.3 | 94% | 0.7 pts | 4 pts |
| infantry | 13.7 | 5.7 | 73% | 8.1 pts | 111 pts |
| monster | 2.3 | 1.0 | 86% | 4.7 pts | 11 pts |
| war machine | 2.0 | 2.0 | 67% | 42.0 pts | 84 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.3 | 5.7 | 5.0 |
| Charges that made contact a game | 3.7 | 4.7 | 4.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.50 declared, 0.50 contact (2 units) | - | 0.50 declared, 0.50 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.48 declared, 0.40 contact (25 units) | 0.71 declared, 0.58 contact (24 units) | 0.59 declared, 0.49 contact (49 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | - | 50% (1 of 2) | - | 50% (1 of 2) |
| Character in a unit | 57% (4 of 7) | 100% (2 of 2) | - | 67% (6 of 9) |
| Character on its own | 50% (1 of 2) | 50% (2 of 4) | 17% (1 of 6) | 33% (4 of 12) |
| Chariot | 50% (2 of 4) | - | - | 50% (2 of 4) |
| Infantry | 50% (2 of 4) | 67% (2 of 3) | - | 57% (4 of 7) |
| Monster | 67% (2 of 3) | 100% (2 of 2) | - | 80% (4 of 5) |
| Monstrous | - | 67% (4 of 6) | - | 67% (4 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Kingdom of Bretonnia | 1 | 0% (0 of 1); on the table 0% | - | 64% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | 86% (6 of 7); on the table 86% | - | 23% | 29% (2 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 0% (0 of 1); on the table 0% | - | 21% | 86% (6 of 7) | 100% (1 of 1); 5.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 88% (7 of 8); on the table 88% | 33% (10 of 30) | 36% | 50% (8 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Skaven | 1 | - | 67% (4 of 6) | 63% | 78% (7 of 9) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p93, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (2) | 56% (5) | 54% (7) |
| ...free all their last turn and able to turn (per game) | 0.67 | 1.00 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 1.00 | 1.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p93

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.0 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | 50% (5 of 10) | 71% (5 of 7) |
| Strategy | Shoot objectives carried out (shot that target) | 33% (8 of 24) | 17% (2 of 12) |
| Strategy | Joined characters whose unit fought | 50% (1 of 2) | 25% (2 of 8) |
| Strategy | Lone characters that fought | 71% (5 of 7) | 80% (4 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 0.7 | 2.7 |
| Movement | Points that never moved of their own | 89.3 | 244.7 |
| Movement | Fights charged into per game | 3.7 | 4.7 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 7, net +56 | 2 of 6, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 7 | 0 of 6 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 7, net +55 | 2 of 6, net +36 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 7, net +212 | 2 of 6, net +242 |
| Shooting | Shots by shooting units (incl. breath weapons) | 16.3 | 4.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 51% (25 of 49) | 64% (9 of 14) |
| Shooting | Points destroyed by shooting units | 140.3 | 0.0 |
| Shooting | War machine shots | 2.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 67% (4 of 6) | - |
| Shooting | Points destroyed by war machines | 66.7 | 0.0 |
| Magic | Magic missiles cast | - | 3.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 27% (3 of 11) |
| Magic | Wounds caused by magic missiles | 0.7 | 2.3 |
| Magic | Wounds caused by other spells | - | 0.7 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 73.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 0.0 / 1.0 / 0.0 | 1.7 / 0.0 / 1.3 / 0.0 |
| Combat | Points destroyed in combat | 193.7 | 277.3 |
| Combat | Points run down | 78.3 | 13.3 |
| Combat | Net points per charged fight, damage counted | +73 | +58 |
| Combat | Net per 100 charger points, damage counted | +28.3 | +25.0 |
| Combat | First round won (charged fights) | 82% | 86% |
| Combat | Net points per charged fight | +94 | +67 |
| Combat | Net points per supported fight / lone fight | - / +94 | - / +67 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 11 | 2 of 14 |
| Game | Points lost | 492.0 | 615.0 |
| Game | VP from objectives | 763.3 | 496.7 |
| Game | Lone holders (player turns) | 3.7 | 1.3 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +380 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 1107
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p93

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 17.7 | +122.9 | 0.0 | 55.3 | 15.0 | +493.4 | 0.0 | 158.3 |
| ASSAILMENT BY POINTS | 0.7 | +14.9 | 0.0 | 123.3 | 0.7 | +0.8 | 0.0 | 217.3 |
| BACKUP TARGETS | 1.0 | +5.3 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | 0.7 | -4.8 | 28.7 | 0.0 | 0.3 | -14.0 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 2.0 | +59.0 | 48.3 | 33.3 | - | - | - | - |
| CANNON SIGHT KEPT | 0.7 | +0.0 | 0.0 | 33.3 | - | - | - | - |
| CAST JOB | 1.3 | +17.5 | 36.7 | 0.0 | 1.3 | +6.3 | 0.0 | 36.7 |
| CASTING BLOCK | - | - | - | - | 2.0 | +28.3 | 11.3 | 0.0 |
| CHAFF IN THE MOVE | 0.7 | +3.5 | 0.0 | 0.0 | 1.0 | +33.6 | 0.0 | 36.7 |
| CHALLENGE BY POINTS | - | - | - | - | 1.0 | +57.6 | 0.0 | 108.7 |
| CHARACTER GUNS | - | - | - | - | 3.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 12.7 | -296.6 | 0.0 | 27.7 | 15.7 | -651.1 | 0.0 | 255.0 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 61.7 | 0.0 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 267.3 | 0.0 | 1.0 | +0.0 | 161.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 10.0 | +0.0 | 0.0 | 116.7 | 10.3 | +0.0 | 0.0 | 103.3 |
| COMBAT PIVOT | 0.3 | +0.0 | 108.7 | 61.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| COVER ONCE | 6.7 | -328.8 | 0.0 | 111.3 | 9.7 | -1286.9 | 0.0 | 69.3 |
| DENIED BY THE FIGHT | 0.7 | -6.9 | 48.3 | 0.0 | 0.3 | -23.5 | 78.0 | 0.0 |
| DEPLOY BY FIGURES | 8.0 | +29.1 | 0.0 | 33.3 | 7.0 | +28.4 | 0.0 | 88.3 |
| DUEL STOPS AT THE KILL | 0.7 | -11.7 | 37.3 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.7 | +4.7 | 85.0 | 0.0 | - | - | - | - |
| ELIXIR WORTH | - | - | - | - | 0.3 | +4.1 | 0.0 | 0.0 |
| EXACT ROUND | 2.7 | +35.1 | 248.3 | 0.0 | 1.7 | -26.9 | 169.3 | 0.0 |
| FALL BACK GOOD ORDER | 2.7 | +0.0 | 267.3 | 0.0 | 1.3 | +0.0 | 223.3 | 0.0 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | 7.0 | +122.6 | 0.0 | 0.0 | 6.7 | +157.7 | 0.0 | 158.3 |
| FEATURE BUFFS | 1.7 | +9.5 | 0.0 | 0.0 | 2.3 | +9.2 | 0.0 | 18.3 |
| FIGHT TO THE END | 1.0 | +2.2 | 37.3 | 0.0 | 0.7 | +0.4 | 139.7 | 0.0 |
| FIRE IN ORDER | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 89.7 | +8369.5 | 455.7 | 558.7 | 63.0 | +4944.3 | 258.7 | 740.7 |
| FLANK NOT WEIGHED | 6.0 | +0.0 | 0.0 | 24.7 | 8.3 | +0.0 | 0.0 | 89.0 |
| FOCUS FIRE | 0.3 | +9.0 | 18.3 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.7 | +292.6 | 0.0 | 0.0 | - | - | - | - |
| FOOT FIRST | 14.3 | +0.0 | 0.0 | 112.7 | - | - | - | - |
| FOUR ROUNDS | 3.3 | +277.3 | 285.7 | 0.0 | 2.3 | +64.3 | 247.3 | 0.0 |
| FREED FROM HIS FIGHT | 4.0 | +0.0 | 0.0 | 22.7 | 5.7 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 2.3 | -39.3 | 0.0 | 0.0 | 0.7 | -8.4 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.3 | +0.9 | 0.0 | 61.7 | - | - | - | - |
| GIVES UP | 0.3 | -16.8 | 0.0 | 0.0 | - | - | - | - |
| GOAL ROUTE | 1.0 | +73.6 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 10.7 | +635.1 | 0.0 | 116.7 | 12.0 | +1220.3 | 0.0 | 0.0 |
| GUN FIGURES | 2.0 | +0.0 | 0.0 | 0.0 | 1.7 | +33.7 | 0.0 | 0.0 |
| HARD STAY DROPPED | 3.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 3.7 | +0.0 | 0.0 | 22.7 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 7.0 | +0.0 | 0.0 | 27.7 | 9.7 | +0.0 | 0.0 | 255.0 |
| HIS CHARGE DENIED | 0.3 | +39.7 | 0.0 | 0.0 | 0.3 | +44.4 | 78.0 | 0.0 |
| HIS CHARGE LIST | 1.0 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 4.7 | +0.0 | 0.0 | 27.7 | 5.3 | +0.0 | 0.0 | 18.3 |
| HIS MOVE AND SHOT | 5.3 | -51.1 | 0.0 | 27.7 | 3.0 | -45.3 | 0.0 | 55.0 |
| HIS ONE QUARTER | 4.0 | +0.0 | 0.0 | 24.0 | 2.7 | +0.0 | 0.0 | 85.0 |
| HIS OWN BEST MOVE | 10.7 | +0.0 | 0.0 | 27.7 | 7.7 | +0.0 | 0.0 | 55.0 |
| HIS RANDOM MOVE | 10.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 37.0 | +734.5 | 0.0 | 217.7 | 34.7 | +961.2 | 0.0 | 476.7 |
| HIS SHOTS BY HIS RUN | 30.0 | +208.1 | 0.0 | 54.3 | 31.7 | +450.3 | 0.0 | 327.3 |
| HIS TURN DENIED | 0.7 | +10.6 | 66.7 | 0.0 | 0.3 | +5.5 | 61.7 | 0.0 |
| HOLD ODDS | 20.0 | +0.0 | 0.0 | 82.0 | 15.7 | +0.0 | 0.0 | 215.7 |
| HOLDER ASSIGNMENT | 12.7 | +1015.1 | 0.0 | 68.7 | 9.7 | +819.6 | 0.0 | 165.3 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.3 | -98.7 | 285.7 | 0.0 | 1.7 | -35.1 | 247.3 | 0.0 |
| IDLE COST | 1.7 | -41.0 | 0.0 | 0.0 | 5.0 | -98.3 | 0.0 | 18.3 |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 36.7 |
| LANE BY FIGURES | 1.0 | +47.2 | 0.0 | 0.0 | 0.7 | +11.3 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 13.0 | +0.0 | 475.7 | 261.0 | 4.7 | +0.0 | 290.7 | 489.3 |
| LONE WIZARD KEPT IN | 0.3 | +16.3 | 0.0 | 0.0 | 0.3 | +58.3 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 2.7 | -7.9 | 249.0 | 0.0 | 1.7 | +1.3 | 223.3 | 0.0 |
| MANOEUVRE | 1.0 | +12.5 | 0.0 | 0.0 | 2.3 | -0.1 | 0.0 | 51.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +9.9 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.3 | +58.6 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +20.5 | 0.0 | 0.0 | 1.3 | +45.5 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 36.7 |
| MAX FOR POSITIONING | 2.3 | +110.4 | 0.0 | 0.0 | 1.7 | +21.5 | 0.0 | 18.3 |
| MEETS IN TIME | 2.0 | +244.3 | 0.0 | 0.0 | 3.3 | +240.7 | 0.0 | 18.3 |
| MISSILES IN THE MOVE | 1.7 | +37.9 | 0.0 | 0.0 | 5.3 | +153.1 | 0.0 | 36.7 |
| MISSILES NEXT TURN | 1.3 | +17.0 | 0.0 | 0.0 | 5.3 | +58.9 | 0.0 | 36.7 |
| MISSILES ON ONE TARGET | - | - | - | - | 0.7 | -9.5 | 0.0 | 0.0 |
| MOVE ORDER | 1.7 | +0.0 | 11.3 | 0.0 | 1.0 | +0.0 | 0.0 | 18.3 |
| MOVE SPELL OUT OF RANGE | 0.7 | -37.2 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 11.0 | +901.1 | 0.0 | 0.0 | 2.7 | +187.5 | 0.0 | 36.7 |
| MOVES UNITS SPELL | - | - | - | - | 0.7 | +2.9 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 8.7 | +392.6 | 0.0 | 124.7 | 5.7 | +292.8 | 0.0 | 154.3 |
| NEAREST TO GOAL | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 7.3 | +719.0 | 0.0 | 0.0 | 2.0 | +172.0 | 0.0 | 36.7 |
| NO DOUBLE ROUNDS | 2.7 | -196.5 | 248.3 | 0.0 | 2.0 | -90.5 | 247.3 | 0.0 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 36.7 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 5.3 | -127.9 | 0.0 | 0.0 | 2.3 | -41.1 | 0.0 | 18.3 |
| ONE CHECK AFTER THE LAST CHANGE | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 9.3 | -167.6 | 0.0 | 0.0 | 2.7 | -41.5 | 0.0 | 36.7 |
| ONE OBJECTIVE FORMULA | 7.7 | -79.8 | 0.0 | 68.7 | 3.3 | -95.1 | 0.0 | 32.0 |
| ONE PROMISE A TARGET | 1.0 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 36.7 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +6.4 | 18.3 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.7 | +13.0 | 66.7 | 0.0 | 1.3 | +13.7 | 185.7 | 0.0 |
| PATHS CROSS | 0.7 | -10.1 | 0.0 | 0.0 | - | - | - | - |
| PERIAPT WORTH | - | - | - | - | 0.3 | +40.5 | 0.0 | 0.0 |
| PLAN RESULT | 42.0 | +600.3 | 296.7 | 693.3 | 34.0 | +244.9 | 61.7 | 673.7 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 11.0 | -219.6 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 1.3 | -13.9 | 0.0 | 0.0 | 0.7 | -8.2 | 0.0 | 0.0 |
| QUARTER ODDS | 22.3 | +3103.8 | 200.7 | 103.3 | 15.7 | +2279.8 | 163.7 | 115.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 2.3 | +115.7 | 0.0 | 166.7 |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 36.7 |
| REDIRECT BY WHAT IT STOPS | 0.7 | -10.9 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 4.3 | +233.7 | 0.0 | 13.3 | 2.0 | +54.6 | 0.0 | 55.0 |
| REDIRECT FOR A FRIEND IN REACH | 5.0 | +26.1 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 55.0 |
| REDIRECT WEIGHED | 0.3 | -3.2 | 13.7 | 0.0 | 0.3 | -14.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.3 | -48.4 | 0.0 | 0.0 | 0.7 | -0.4 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 55.3 | - | - | - | - |
| RESERVE FALL BACK | 0.3 | +15.8 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.3 | +99.3 | 182.3 | 0.0 | 1.7 | -1.2 | 247.3 | 0.0 |
| ROUNDS AFTER TERROR | 1.7 | -65.8 | 200.0 | 0.0 | 0.7 | -18.7 | 107.7 | 0.0 |
| RUN DOWN | 2.3 | -24.2 | 230.0 | 0.0 | 1.7 | -14.0 | 223.3 | 0.0 |
| SCOUT SPOT | 0.7 | +1.7 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.0 | -82.0 | 0.0 | 36.7 |
| SEARCH SPOT | 0.3 | -6.3 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SELF MOVE SPELL | - | - | - | - | 3.0 | -5.3 | 0.0 | 217.3 |
| SET CREDITED ONCE | 3.7 | -28.1 | 0.0 | 0.0 | 1.0 | -41.0 | 0.0 | 0.0 |
| SET UP BY THE SET | 5.0 | +55.9 | 0.0 | 0.0 | 2.7 | +47.4 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.3 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.3 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 7.3 | +0.0 | 0.0 | 33.3 | 2.7 | +0.0 | 0.0 | 36.7 |
| SHOOTS FROM THE BEST SPOT | 4.7 | +404.7 | 18.3 | 0.0 | 0.7 | +26.1 | 0.0 | 0.0 |
| SHOT OR CHARGE | 1.0 | -26.5 | 96.7 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 21.0 | -68.4 | 0.0 | 54.3 | 23.3 | -59.6 | 0.0 | 103.3 |
| SHOTS AFTER THE MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 15.3 | +586.3 | 0.0 | 117.0 | 4.7 | +223.0 | 0.0 | 0.0 |
| SPELL WORTH | 0.7 | +1.1 | 0.0 | 0.0 | 2.0 | +57.1 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.7 | -32.7 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 7.0 | +0.0 | 0.0 | 35.3 | 10.0 | +0.0 | 0.0 | 206.7 |
| STAND AND SHOOT | - | - | - | - | 1.0 | -9.1 | 169.3 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 1.7 | +0.0 | 11.3 | 36.7 |
| STANDS STILL | 29.7 | +0.0 | 170.0 | 122.0 | 14.7 | +0.0 | 11.3 | 345.7 |
| STANDS TO CAST | - | - | - | - | 0.3 | +7.3 | 0.0 | 0.0 |
| STAY WORTH | 21.0 | +373.5 | 151.7 | 127.7 | 4.0 | +34.2 | 11.3 | 0.0 |
| STRIKE BY THE ODDS | 0.7 | +10.2 | 127.0 | 61.7 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 9.0 | +410.4 | 0.0 | 22.7 | 3.0 | +365.3 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 85.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 9.0 | +410.4 | 0.0 | 22.7 | 3.0 | +365.3 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.7 | +0.6 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +0.3 | 0.0 | 11.3 | 0.3 | +0.8 | 0.0 | 18.3 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 13.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.7 | -31.7 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 4.0 | +0.0 | 0.0 | 11.3 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 3.3 | +0.0 | 0.0 | 13.3 | 3.3 | +0.0 | 0.0 | 85.0 |
| THE STEP BACK IS MADE | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 85.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 41.7 | +0.0 | 0.0 | 279.3 | 25.0 | +0.0 | 0.0 | 205.3 |
| TIED UP BY THE SUM | 1.0 | +136.7 | 145.0 | 0.0 | 0.3 | +50.4 | 78.0 | 0.0 |
| TIME ON OUR SIDE | 32.7 | +353.5 | 36.7 | 361.7 | 14.7 | +146.4 | 0.0 | 51.0 |
| WAITS AGAIN | 3.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 2.0 | +0.0 | 36.7 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.7 | -1.8 | 85.0 | 0.0 | 0.7 | +2.7 | 61.7 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.7 | +148.3 | 0.0 | 108.7 |
| WHOLE FIGHT DANGER | 2.0 | -81.2 | 0.0 | 0.0 | 1.7 | -249.5 | 0.0 | 255.0 |
| WOUNDS ON THE RANKS | 0.7 | +3.7 | 0.0 | 0.0 | 2.3 | +116.9 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p93

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 98 | 98 | 68 | 22.67 | +1366 | +20.1 |
| HOLDER ASSIGNMENT | 67 | 67 | 61 | 20.33 | +5039 | +82.6 |
| LEGAL CHARGES ONLY | 53 | 53 | 53 | 17.67 | +0 | +0.0 |
| HIS SHOT LIST | 215 | 206 | 50 | 16.67 | +673 | +13.5 |
| FIVE ACTION | 458 | 446 | 33 | 11.00 | +1607 | +48.7 |
| MOVE TO CHARGE COMPUTED | 41 | 40 | 26 | 8.67 | +1243 | +47.8 |
| DEPLOY BY FIGURES | 45 | 45 | 25 | 8.33 | +483 | +19.3 |
| GOAL WALK | 68 | 66 | 25 | 8.33 | +1877 | +75.1 |
| THE TABLE AGAIN | 36 | 36 | 25 | 8.33 | +0 | +0.0 |
| OFF BEST | 23 | 23 | 23 | 7.67 | -507 | -22.0 |
| HIS SHOTS BY HIS RUN | 185 | 177 | 22 | 7.33 | +112 | +5.1 |
| REDIRECT FOR A FRIEND IN REACH | 19 | 19 | 19 | 6.33 | +13 | +0.7 |
| SHOT RISK POINTS | 133 | 128 | 17 | 5.67 | +349 | +20.5 |
| NEXT CHARGE BY LIST | 28 | 28 | 16 | 5.33 | +1091 | +68.2 |
| TIME ON OUR SIDE | 142 | 123 | 13 | 4.33 | +53 | +4.1 |
| PROMISE BY ITS OWN SUM | 43 | 43 | 12 | 4.00 | -659 | -54.9 |
| SHOOTS FROM THE BEST SPOT | 16 | 16 | 12 | 4.00 | +276 | +23.0 |
| SUPPORT ADDS | 36 | 36 | 12 | 4.00 | +303 | +25.2 |
| SUPPORT WORKED OUT | 36 | 36 | 12 | 4.00 | +303 | +25.2 |
| HARD STAY DROPPED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| MEETS IN TIME | 16 | 16 | 10 | 3.33 | +1336 | +133.6 |
| STAY WORTH | 75 | 67 | 10 | 3.33 | +68 | +6.8 |
| FOUR ROUNDS | 17 | 17 | 8 | 2.67 | +198 | +24.8 |
| MOVE ORDER | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| QUARTER ODDS | 114 | 110 | 8 | 2.67 | +741 | +92.7 |
| SET UP BY THE SET | 23 | 20 | 7 | 2.33 | +271 | +38.7 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CAST JOB | 8 | 8 | 6 | 2.00 | +10 | +1.7 |
| CASTING BLOCK | 6 | 6 | 6 | 2.00 | +22 | +3.6 |
| WHOLE FIGHT DANGER | 11 | 11 | 6 | 2.00 | +571 | +95.1 |
| COVER ONCE | 49 | 29 | 5 | 1.67 | +188 | +37.6 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +175 | +35.1 |
| NEARER NOT NEEDED | 43 | 43 | 5 | 1.67 | +122 | +24.3 |
| REDIRECT COUNTER | 19 | 17 | 5 | 1.67 | +319 | +63.8 |
| ASSAILMENT BY POINTS | 4 | 4 | 4 | 1.33 | +47 | +11.8 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 7 | 7 | 4 | 1.33 | +347 | +86.8 |
| RISK BY ARC | 12 | 12 | 4 | 1.33 | +140 | +35.1 |
| SHOTS IN THE MOVE | 60 | 41 | 4 | 1.33 | +116 | +29.0 |
| TIED UP BY THE SUM | 4 | 4 | 4 | 1.33 | +242 | +60.6 |
| BEST PRIZE | 3 | 3 | 3 | 1.00 | -56 | -18.8 |
| CHAFF IN THE MOVE | 5 | 5 | 3 | 1.00 | +0 | +0.0 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +173 | +57.6 |
| CHARGE LOSSES | 85 | 83 | 3 | 1.00 | +18 | +6.1 |
| GOAL ROUTE | 3 | 3 | 3 | 1.00 | +100 | +33.3 |
| IDLE COST | 20 | 12 | 3 | 1.00 | +0 | +0.0 |
| MARCH CHECK | 5 | 5 | 3 | 1.00 | +60 | +20.1 |
| ONE PROMISE A TARGET | 3 | 3 | 3 | 1.00 | +4 | +1.4 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CANNON SIGHT KEPT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 9 | 9 | 2 | 0.67 | -169 | -84.7 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| EXACT ROUND | 13 | 13 | 2 | 0.67 | +14 | +7.2 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +878 | +438.9 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +224 | +112.0 |
| MANOEUVRE | 10 | 10 | 2 | 0.67 | +38 | +18.8 |
| MAX FOR POSITIONING | 12 | 9 | 2 | 0.67 | +4 | +1.9 |
| MISSILES IN THE MOVE | 21 | 14 | 2 | 0.67 | +46 | +23.0 |
| MOVES UNITS SPELL | 2 | 2 | 2 | 0.67 | +9 | +4.3 |
| ONE OBJECTIVE FORMULA | 33 | 27 | 2 | 0.67 | +89 | +44.7 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | -30 | -15.1 |
| PROMISE READS THE TABLE | 6 | 6 | 2 | 0.67 | +4 | +2.0 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +146 | +73.2 |
| SHOTS AFTER THE MOVES | 16 | 16 | 2 | 0.67 | +0 | +0.0 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +7 | +3.6 |
| SWIFTSTRIDE BY POINTS | 2 | 2 | 2 | 0.67 | +3 | +1.7 |
| WAR ENGINE JOBS | 6 | 6 | 2 | 0.67 | -4 | -1.8 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +79 | +39.4 |
| WOUNDS ON THE RANKS | 9 | 9 | 2 | 0.67 | +29 | +14.5 |
| BACKUP TARGETS | 3 | 3 | 1 | 0.33 | +9 | +8.9 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -66 | -65.9 |
| DUEL STOPS AT THE KILL | 2 | 2 | 1 | 0.33 | +4 | +4.2 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.33 | +12 | +12.2 |
| FALLS SHORT | 41 | 28 | 1 | 0.33 | +4 | +4.2 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +27 | +27.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +3 | +2.7 |
| HIS MOVE AND SHOT | 25 | 23 | 1 | 0.33 | +0 | +0.0 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +176 | +175.9 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +11 | +11.2 |
| OVERRUNS AWAY | 6 | 6 | 1 | 0.33 | +11 | +11.2 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +122 | +121.5 |
| REFUSING RETIRES | 2 | 2 | 1 | 0.33 | -0 | -0.2 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +48 | +47.5 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +4 | +4.0 |
| STANDS TO CAST | 1 | 1 | 1 | 0.33 | -14 | -14.2 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 19 | 1 | 1 | 0.33 | +0 | +0.0 |
| CANNON PLANNED TARGET | 6 | 6 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 11 | 11 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 61 | 60 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 12 | 12 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 12 | 12 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 5 | 5 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 43 | not checked | - | - | - | - |
| FOOT FIRST | 43 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 29 | 29 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 9 | 7 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 11 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 24 | 24 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 50 | 49 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 23 | 23 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 30 | 30 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 20 | 18 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 55 | 54 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 30 | 27 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 7 | 6 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 3 | 3 | 0 | 0.00 | - | - |
| HOLD ODDS | 107 | 107 | 0 | 0.00 | - | - |
| HONEST WORTH | 15 | 15 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 12 | 12 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 13 | 13 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 20 | 14 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 2 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 2 | trace | - | - | - | - |
| NEAREST TO GOAL | 4 | 4 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 14 | 14 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 5 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 36 | 24 | 0 | 0.00 | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 228 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 3 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 7 | 7 | 0 | 0.00 | - | - |
| RUN DOWN | 12 | 12 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SEARCH SPOT | 3 | 3 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 9 | not checked | - | - | - | - |
| SET CREDITED ONCE | 14 | 11 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 30 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL WORTH | 8 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 51 | 47 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 5 | 5 | 0 | 0.00 | - | - |
| STANDS STILL | 133 | 131 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 3 | 3 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 6 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 20 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 13 | not checked | - | - | - | - |
| THE TABLE BINDS | 200 | not checked | - | - | - | - |
| WAITS AGAIN | 13 | 11 | 0 | 0.00 | - | - |
| WHO FIGHTS | 4 | 4 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p93

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.33 | 2.00 | 22.6 |
| PROMISE BY ITS OWN SUM | rule | 4.00 | - | 54.9 |
| ARMY TABLE | rule | 2.00 | 1.33 | 38.7 |
| BEST PRIZE | rule | 0.67 | 0.33 | 18.8 |
| CHARGE NOW FIRST | rule | 0.67 | - | 84.7 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.33 | 23.6 |
| NO REASON | gate | 0.67 | - | 28.6 |
| ONE PROMISE A TARGET | rule | 0.67 | - | 35.2 |
| WAR ENGINE JOBS | rule | 0.67 | - | 1.8 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 65.9 |
| FALLBACK | gate | 0.33 | - | 19.0 |
| FIGHT ORDER BAND | gate | - | 0.33 | 1.0 |
| PATHS CROSS | rule | 0.33 | - | 30.2 |
| PROMISE READS THE TABLE | rule | - | 0.33 | 15.9 |
| STANDS TO CAST | rule | - | 0.33 | 14.2 |

### Plans: gs3-83c8646-p93

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.7 | 75% | 546 | 362 | 66% |
| Mine | move | 32.3 | 94% | 2112 | 0 | 0% |
| Mine | shoot | 6.7 | 45% | 884 | 239 | 27% |
| Mine | support | 0.3 | 100% | 13 | 0 | 0% |
| Opponent | charge | 2.0 | 50% | 188 | 193 | 103% |
| Opponent | move | 27.7 | 92% | 1842 | 0 | 0% |
| Opponent | shoot | 3.7 | 27% | 255 | 52 | 20% |
| Opponent | support | 0.7 | 50% | 0 | 0 | - |

### Battle groups: gs3-83c8646-p93

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.3 | 46% | 67% | 33% | 0% | 50% | 0% | 0% | 50% | 0% |
| Opponent | REDIRECT COUNTER | 2.0 | 33% | 50% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p93

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 23 (4) | 23 | 0 | 0 | 75% | 3.0 | 0 (3) | 61 (1) | - | - | 23 (4) |
| Mine | Chaff | 7 | 62 (7) | 0 | 62 | 28 | 0% | 2.7 | 225 (1) | 16 (4) | 76 (2) | 62 (7) | - |
| Mine | Character | 7 | 56 (7) | 56 | 0 | 0 | 14% | 3.5 | 55 (4) | 88 (2) | 16 (1) | 46 (4) | 72 (3) |
| Mine | Fast Hammer | 1 | 114 (1) | 114 | 0 | 100 | 0% | 1.0 | - | 114 (1) | - | - | 114 (1) |
| Mine | Hammer | 9 | 20 (9) | 3 | 18 | 41 | 33% | 1.5 | 9 (3) | 28 (5) | 0 (1) | 5 (5) | 35 (4) |
| Mine | Shooter | 4 | 160 (4) | 15 | 145 | 64 | 0% | 1.8 | 159 (2) | 160 (2) | - | 292 (1) | 128 (3) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | War machine | 2 | 72 (2) | 72 | 0 | 50 | 0% | 1.0 | - | 72 (2) | - | - | 72 (2) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.5 | - | 0 (2) | - | - | 0 (2) |
| Opponent | Chaff | 3 | 55 (3) | 0 | 55 | 100 | 33% | 2.5 | 0 (1) | 0 (1) | 164 (1) | 55 (3) | - |
| Opponent | Character | 9 | 46 (9) | 46 | 0 | 0 | 33% | 3.0 | 91 (4) | 0 (1) | 0 (4) | 26 (4) | 53 (5) |
| Opponent | Clean-up | 1 | 146 (1) | 0 | 146 | 100 | 0% | 2.0 | - | 146 (1) | - | 146 (1) | - |
| Opponent | Fast Hammer | 4 | 29 (4) | 26 | 4 | 14 | 50% | 2.5 | 51 (2) | 55 (1) | 0 (1) | 28 (3) | 55 (1) |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Hammer | 10 | 22 (10) | 14 | 8 | 54 | 30% | 3.7 | 28 (3) | 6 (4) | 34 (3) | 42 (6) | 0 (4) |
| Opponent | Holder | 3 | 19 (3) | 0 | 19 | 35 | 67% | 5.0 | - | 54 (1) | 0 (2) | 29 (2) | 0 (1) |
| Opponent | Shooter | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.5 | - | - | 0 (2) | 0 (1) | 0 (1) |
| Opponent | Wizard | 4 | 29 (4) | 29 | 0 | 63 | 0% | 1.8 | - | 0 (1) | 57 (2) | 36 (3) | - |

### Charged fights: gs3-83c8646-p93

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Kingdom of Bretonnia | 1 | 355 | 298 | 4.0 | 1.0 | 74 | 0 | +74 | 1 of 4 | 4 of 4 | - | +74 |
| Mine | Lizardmen | 1 | 211 | 871 | 5.0 | 1.0 | 174 | 37 | +137 | 1 of 5 | 4 of 5 | - | +137 |
| Mine | Ogre Kingdoms | 1 | 55 | 55 | 2.0 | 1.0 | 28 | 0 | +28 | 1 of 2 | 1 of 2 | - | +28 |
| **Mine** | all armies | 3 | 207 | 408 | 3.7 | 1.0 | 111 | 17 | +94 | 3 of 11 | 9 of 11 | - | +94 |
| Opponent | Orc & Goblin Tribes | 2 | 110 | 469 | 6.5 | 1.0 | 72 | 0 | +72 | 2 of 13 | 12 of 13 | - | +72 |
| Opponent | Skaven | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| **Opponent** | all armies | 3 | 73 | 313 | 4.7 | 1.0 | 67 | 0 | +67 | 2 of 14 | 12 of 14 | - | +67 |

### Effective charges: gs3-83c8646-p93

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Kingdom of Bretonnia | 4 | 1 (net +112) | 0 | 0 | 1 (net +0) | 0 | 1 (net +145) | 1 | 0% (0 of 3) |
| Mine | Lizardmen | 5 | 1 (net +0) | 0 | 0 | 0 | 1 (net +55) | 2 (net +245) | 1 | 0% (0 of 4) |
| Opponent | Orc & Goblin Tribes | 13 | 1 (net +0) | 0 | 0 | 0 | 2 (net +36) | 2 (net +242) | 8 | 0% (0 of 5) |
| Opponent | Skaven | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: gs3-83c8646-p93

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 209 | 86 | +56 | 61 | 69 | -8 | -3.9 |
| Mine | 76-89% | 1 | 371 | 440 | +0 | 275 | 247 | +28 | +7.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 392 | 212 | +212 | 212 | 38 | +174 | +44.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 185 | 55 | +55 | 55 | 0 | +55 | +29.7 |
| Mine | No odds | 4 | 173 | 168 | +59 | 106 | 51 | +54 | +31.4 |
| Mine | All fights | 11 | 258 | 179 | +94 | 137 | 64 | +73 | +28.3 |
| Opponent | Long shot (under 50%) | 2 | 30 | 132 | +0 | 45 | 15 | +30 | +100.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 350 | 242 | +242 | 242 | 0 | +242 | +69.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 292 | 74 | +36 | 55 | 103 | -48 | -16.4 |
| Opponent | No odds | 8 | 238 | 71 | +48 | 51 | 6 | +45 | +19.0 |
| Opponent | All fights | 14 | 232 | 105 | +67 | 78 | 20 | +58 | +25.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p93 | move | 24 | 6 (25%) | 6 (25%) | 3 (12%) | 15 (62%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Elixir of Power | Opponent | L1719, L1819 |
| Fistful of Laurels | Mine | L1819 |
| Periapt of Soul Exchange | Opponent | L1621 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621 |

# Doctrine scorecard: gs3-83c8646-p95

### Scorecard: gs3-83c8646-p95

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2227 | 1 | 1 | Mine | yes | 0 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | no | 1 | 1 | 4 | 3 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Mine | yes | 4 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Opponent | no | 6 | 2 | 1 | 2 | 0 | 0 | 0 | 340 |
| L2527 | 1 | 1 | Mine | no | 0 | 6 | 4 | 2 | 0 | 0 | 0 | 143 |
| L2527 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 67% | 1.3 | 3.3 | 3.7 | 1.3 | 0.0 | 0.0 | 0.0 | 47.7 |
| **Average** | | | Opponent | 0% | 2.3 | 1.7 | 2.7 | 2.3 | 0.0 | 0.0 | 0.0 | 113.3 |

### KPIs: gs3-83c8646-p95

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 15) | 0% (0 of 16) | 0% (0 of 31) |
| Winner chose to follow up after the loser gave ground |  | 100% (4 of 4); on the table 100% | 71% (5 of 7); on the table 71% | 82% (9 of 11); on the table 82% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 50% (1 of 2); on the table 50% | - | 50% (1 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 83% (5 of 6); on the table 83% | 71% (5 of 7); on the table 71% | 77% (10 of 13); on the table 77% |
| Magic missiles tried each own turn | 50%+ | 0% (0 of 5) | 59% (17 of 29) | 50% (17 of 34) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 0% (0 of 5) | 85% (17 of 20) | 68% (17 of 25) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 50% (6 of 12) | 50% (6 of 12) |
| Points that never fought | lower | 29% (1301 of 4451) | 27% (1617 of 6000) | 28% (2918 of 10451) |
|   infantry points that never fought | lower | 58% (539 of 931) | 69% (404 of 584) | 62% (943 of 1515) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 17% (2 of 12) | 67% (16 of 24) | 50% (18 of 36) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 11% (365 of 3249) | 54% (2765 of 5092) | 38% (3130 of 8341) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.7 (100%) | 0.7 (17%) | 2.3 (41%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.3 (8%) | 0.3 (6%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (17%) | 0.7 (12%) |
| GONE: slain | 0.0 (0%) | 2.3 (58%) | 2.3 (41%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- |
| tried | 9.0 | 5.7 | 0.7 | 2.3 |
| not cast | 7.0 | 5.7 | 1.3 | 25.7 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.3 (41%) | 0.7 (50%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.3 (6%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (5%) | 0.7 (12%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.0 (14%) | 2.3 (41%) | 0.0 (0%) | 4.0 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (5%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.3 (5%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.7 (50%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 5.0 (71%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 21.0 (82%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 69% (64 of 93) | - | 69% (64 of 93) |
|   cavalry | 100% (20 of 20) | - | 100% (20 of 20) |
|   character | 0% (0 of 19) | - | 0% (0 of 19) |
|   chariot | 100% (6 of 6) | - | 100% (6 of 6) |
|   infantry | 79% (38 of 48) | - | 79% (38 of 48) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| CHARGED: it charged | 1.3 (14%) | - | 1.3 (14%) |
| IN COMBAT: it fought this turn or the last | 0.7 (7%) | - | 0.7 (7%) |
| NO TARGET IN RANGE | 4.7 (48%) | - | 4.7 (48%) |
| ONLY IN COMBAT: the only targets were in combat | 1.3 (14%) | - | 1.3 (14%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (17%) | - | 1.7 (17%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 11.3 | 0.7 | 94% | 1.2 pts | 14 pts |
| chariot | 2.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 14.3 | 3.3 | 86% | 9.7 pts | 139 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.7 | 5.7 | 5.2 |
| Charges that made contact a game | 3.7 | 4.7 | 4.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.20 declared, 0.20 contact (5 units) | 0.20 declared, 0.20 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 2.50 declared, 2.50 contact (2 units) | 2.50 declared, 2.50 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.56 declared, 0.44 contact (25 units) | 0.52 declared, 0.38 contact (21 units) | 0.54 declared, 0.41 contact (46 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 83% (5 of 6) | 50% (1 of 2) | 0% (0 of 2) | 60% (6 of 10) |
| Character in a unit | 100% (3 of 3) | - | - | 100% (3 of 3) |
| Character on its own | 60% (3 of 5) | - | 14% (1 of 7) | 33% (4 of 12) |
| Infantry | 60% (3 of 5) | - | - | 60% (3 of 5) |
| Monster | 33% (2 of 6) | - | - | 33% (2 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Tomb Kings of Khemri | 2 | 67% (2 of 3); on the table 67% | - | 33% | 20% (2 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 3 | 88% (7 of 8); on the table 88% | 57% (16 of 28) | 21% | 57% (8 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 50% (1 of 2); on the table 50% | 17% (1 of 6) | 33% | 67% (8 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p95, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 57% (4) | 45% (5) | 50% (9) |
| ...free all their last turn and able to turn (per game) | 0.67 | 1.00 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.33 | 0.67 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.67 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.67 | 0.67 |

### Quality by phase: gs3-83c8646-p95

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 5.3 |
| Strategy | Charge objectives carried out (made contact) | 59% (10 of 17) | 58% (7 of 12) |
| Strategy | Shoot objectives carried out (shot that target) | 43% (6 of 14) | 0% (0 of 3) |
| Strategy | Support requests answered (helper made contact too) | 67% (2 of 3) | 100% (2 of 2) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 0% (0 of 2) | 50% (2 of 4) |
| Strategy | Lone characters that fought | 100% (6 of 6) | 69% (9 of 13) |
| Movement | Charges halted short of contact | 0.7 | 0.3 |
| Movement | Idle units | 1.3 | 2.3 |
| Movement | Points that never moved of their own | 47.7 | 113.3 |
| Movement | Fights charged into per game | 4.3 | 2.7 |
| Movement | Charges with odds: long shots (under 50%) | 3 of 12, net -2 | 2 of 7, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 3 of 12, net +87 | 0 of 7 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 12, net +369 | 1 of 7, net +66 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 12, net +394 | 2 of 7, net +72 |
| Shooting | Shots by shooting units (incl. breath weapons) | 23.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 34% (24 of 70) | - |
| Shooting | Points destroyed by shooting units | 103.7 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | - | 4.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 31% (4 of 13) |
| Magic | Wounds caused by magic missiles | - | 0.7 |
| Magic | Wounds caused by other spells | - | 0.7 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 4.0 / 0.0 / 0.0 / 0.0 | 2.7 / 0.0 / 1.0 / 0.3 |
| Combat | Points destroyed in combat | 542.0 | 123.7 |
| Combat | Points run down | 40.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +168 | -1 |
| Combat | Net per 100 charger points, damage counted | +65.9 | -0.2 |
| Combat | First round won (charged fights) | 77% | 62% |
| Combat | Net points per charged fight | +167 | +11 |
| Combat | Net points per supported fight / lone fight | +440 / +118 | +33 / +4 |
| Combat | Charged fights on a top-3 enemy unit | 6 of 13 | 7 of 8 |
| Game | Points lost | 387.3 | 898.0 |
| Game | VP from objectives | 990.0 | 566.7 |
| Game | Lone holders (player turns) | 1.3 | 2.3 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +1074 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 1285
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: gs3-83c8646-p95

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +152.6 | 0.0 | 0.0 | 0.7 | +159.2 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | 0.3 | +7.2 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 33.3 | +262.5 | 0.0 | 88.3 | 19.0 | -450.6 | 0.0 | 271.0 |
| ASSAILMENT BY POINTS | - | - | - | - | 0.3 | +1.9 | 0.0 | 0.0 |
| BACKUP TARGETS | - | - | - | - | 0.7 | +4.1 | 0.0 | 100.7 |
| BLOCKED CHARGE SKIPPED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | - | - | - | - | 1.0 | -2.0 | 0.0 | 0.0 |
| CAST JOB | - | - | - | - | 0.7 | +3.1 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.0 | +3.1 | 0.0 | 0.0 |
| CHAFF PASSED | 2.7 | -3.9 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.7 | +5.5 | 0.0 | 0.0 | 1.3 | +41.6 | 0.0 | 16.7 |
| CHARGE LIST READ AGAIN | 0.3 | -2.1 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 9.7 | -1368.6 | 0.0 | 253.3 | 18.0 | -1407.7 | 0.0 | 681.3 |
| CHARGE NOW FIRST | 2.7 | +0.0 | 351.7 | 80.0 | 2.3 | +0.0 | 131.0 | 127.0 |
| CLOSES ON WHAT IT BEATS | 13.7 | +0.0 | 0.0 | 50.0 | 17.7 | +0.0 | 0.0 | 48.3 |
| COMBAT PIVOT | 0.7 | +0.0 | 63.3 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| COVER ONCE | 7.0 | -368.3 | 0.0 | 20.0 | 8.0 | -568.4 | 0.0 | 230.3 |
| DEFENSIVE FLOOR | 0.3 | -50.7 | 62.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 7.7 | +43.2 | 0.0 | 0.0 | 6.0 | +17.1 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 1.0 | -129.2 | 143.3 | 0.0 | - | - | - | - |
| EXACT ROUND | 3.7 | +37.7 | 379.3 | 80.0 | 4.0 | +78.0 | 131.0 | 127.0 |
| FALL BACK GOOD ORDER | 3.7 | +8.0 | 526.7 | 65.0 | 2.3 | +0.0 | 0.0 | 62.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 23.7 | +254.3 | 0.0 | 559.0 |
| FEATURE BUFFS | 1.3 | +9.5 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.0 | +35.9 | 62.0 | 0.0 | 1.3 | +89.6 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 112.3 | +11601.6 | 759.3 | 597.3 | 81.3 | +6190.0 | 153.0 | 1162.3 |
| FLANK NOT WEIGHED | 8.0 | +0.0 | 0.0 | 61.7 | 12.0 | +0.0 | 0.0 | 78.7 |
| FOLLOW UP WEIGHED | 1.0 | +178.4 | 0.0 | 0.0 | 2.0 | +566.2 | 0.0 | 205.3 |
| FOOT FIRST | 39.3 | +0.0 | 0.0 | 187.0 | - | - | - | - |
| FOUR ROUNDS | 6.3 | +931.4 | 604.7 | 96.7 | 4.3 | +584.8 | 131.0 | 127.0 |
| FREED FROM HIS FIGHT | 2.7 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 0.0 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -0.1 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.3 | -0.3 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.3 | -0.7 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 1.0 | -10.7 | 129.0 | 0.0 | 0.7 | -9.3 | 0.0 | 0.0 |
| GOAL ROUTE | 0.3 | +54.7 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 10.7 | +1340.6 | 0.0 | 30.0 | 9.7 | +708.5 | 0.0 | 97.0 |
| HARD STAY DROPPED | 2.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 0.7 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 6.7 | +0.0 | 0.0 | 123.3 | 17.0 | +0.0 | 0.0 | 681.3 |
| HIS CHARGE DENIED | 0.3 | +15.7 | 15.0 | 15.0 | - | - | - | - |
| HIS CHARGE LIST | 5.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 15.0 |
| HIS LEGAL MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 1.3 | -5.8 | 0.0 | 0.0 | 2.7 | -35.3 | 0.0 | 40.0 |
| HIS ONE QUARTER | 9.7 | +0.0 | 0.0 | 50.0 | 6.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 9.3 | +0.0 | 0.0 | 130.0 | 8.0 | +0.0 | 0.0 | 207.3 |
| HIS RANDOM MOVE | 14.3 | +0.0 | 0.0 | 167.3 | - | - | - | - |
| HIS RANDOM MOVER COMES | 4.0 | +0.0 | 0.0 | 167.3 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 7.3 | +28.0 | 0.0 | 0.0 | 37.0 | +391.3 | 0.0 | 567.0 |
| HIS SHOTS BY HIS RUN | 11.0 | +14.7 | 0.0 | 174.0 | 37.0 | +324.5 | 0.0 | 923.7 |
| HIS TURN DENIED | 0.7 | +2.5 | 63.3 | 65.0 | 1.3 | +27.7 | 44.0 | 0.0 |
| HOLD ODDS | 28.0 | +0.0 | 0.0 | 44.0 | 13.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 17.3 | +1372.8 | 0.0 | 44.0 | 8.7 | +649.4 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.7 | -203.6 | 427.7 | 80.0 | 4.3 | -228.8 | 131.0 | 127.0 |
| IDLE COST | - | - | - | - | 16.3 | -157.1 | 0.0 | 252.7 |
| JOINT CHARGE NOW | 2.7 | +258.4 | 401.3 | 16.7 | 1.7 | +71.7 | 66.0 | 127.0 |
| JOINT KNOWS CHALLENGE | 0.3 | -8.2 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 6.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +38.9 | 0.0 | 0.0 | 0.7 | +32.2 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 16.7 | +0.0 | 832.0 | 167.7 | 6.7 | +0.0 | 15.0 | 118.7 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 1.0 | +45.9 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | - | - | - | - | 0.3 | -0.0 | 22.0 | 65.0 |
| MAKE SURE TOGETHER | 0.3 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | -1.8 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +0.8 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.3 | +8.2 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 0.3 | +0.4 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | +39.6 | 0.0 | 0.0 | 0.7 | +18.7 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 5.7 | +106.1 | 0.0 | 15.0 | 4.3 | +175.7 | 0.0 | 78.3 |
| MEETS IN TIME | 4.3 | +306.2 | 0.0 | 0.0 | 4.0 | +274.1 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.0 | +12.6 | 0.0 | 0.0 | 4.7 | +20.8 | 0.0 | 128.3 |
| MISSILES NEXT TURN | 2.7 | +10.8 | 0.0 | 0.0 | 5.3 | +14.6 | 0.0 | 128.3 |
| MOVE ORDER | 4.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 7.7 | +722.6 | 0.0 | 130.0 | 7.3 | +894.9 | 0.0 | 222.3 |
| NEARER NOT NEEDED | 13.3 | +424.1 | 0.0 | 61.7 | 7.7 | +265.8 | 0.0 | 182.0 |
| NEAREST TO GOAL | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 4.3 | +450.0 | 0.0 | 0.0 | 5.7 | +397.6 | 0.0 | 222.3 |
| NO DOUBLE ROUNDS | 5.0 | -165.7 | 480.7 | 80.0 | 3.3 | -128.1 | 131.0 | 127.0 |
| NO LATE CUT | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.7 | +8.1 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 1.0 | -0.3 | 0.0 | 0.0 |
| OFF BEST | 4.7 | -175.5 | 0.0 | 0.0 | 4.0 | -157.3 | 0.0 | 127.0 |
| ONE CHALLENGE TEST | - | - | - | - | 1.0 | +185.9 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.7 | -165.4 | 0.0 | 0.0 | 4.0 | -76.9 | 0.0 | 53.7 |
| ONE JOINT FIGURE | 0.7 | +103.5 | 143.3 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 8.7 | +46.3 | 0.0 | 22.0 | 4.0 | -47.9 | 0.0 | 0.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.7 | +48.4 | 15.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.7 | +23.1 | 63.3 | 65.0 | 0.3 | +5.5 | 22.0 | 0.0 |
| PATHS CROSS | - | - | - | - | 1.0 | +18.8 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -0.7 | 0.0 | 0.0 |
| PLAN RESULT | 51.0 | +426.3 | 373.7 | 428.7 | 43.3 | +332.6 | 0.0 | 847.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 65.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 12.3 | -435.2 | 0.0 | 130.0 | 9.0 | -640.6 | 0.0 | 260.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 1.0 | -0.5 | 0.0 | 0.0 |
| QUARTER ODDS | 33.3 | +3307.6 | 124.0 | 220.0 | 20.3 | +2020.7 | 65.0 | 62.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.0 | +42.4 | 0.0 | 0.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 4.3 | +220.7 | 0.0 | 37.0 | 4.3 | +227.1 | 0.0 | 15.0 |
| REDIRECT FOR A FRIEND IN REACH | 7.3 | +0.0 | 0.0 | 37.0 | 3.7 | +0.0 | 0.0 | 30.0 |
| REFORMS TO MEET IT | 3.3 | -200.6 | 0.0 | 130.0 | 1.0 | -38.4 | 0.0 | 15.0 |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 2.3 | +63.0 | 0.0 | 61.7 | - | - | - | - |
| RISK BY ARC | 3.7 | -10.5 | 398.7 | 65.0 | 3.3 | -56.6 | 131.0 | 127.0 |
| ROUNDS AFTER TERROR | 1.0 | -37.9 | 182.0 | 0.0 | - | - | - | - |
| RUN DOWN | 1.0 | -45.3 | 182.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 1.3 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | -58.3 | 0.0 | 0.0 |
| SEARCH SPOT | 1.3 | +18.0 | 0.0 | 0.0 | 0.7 | +1.7 | 0.0 | 0.0 |
| SECOND LOOK | 0.7 | +36.5 | 0.0 | 0.0 | 0.3 | +13.6 | 0.0 | 0.0 |
| SET CREDITED ONCE | 0.7 | -158.1 | 0.0 | 0.0 | 1.3 | -24.8 | 0.0 | 157.3 |
| SET UP BY THE SET | 1.3 | -1.1 | 0.0 | 0.0 | 2.3 | +109.4 | 0.0 | 157.3 |
| SET UP TOGETHER | 0.3 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.7 | -3.3 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +3.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 5.3 | +0.0 | 0.0 | 20.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +2.3 | 0.0 | 0.0 | 1.0 | +3.3 | 22.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -0.9 | 22.0 | 0.0 |
| SHOT RISK POINTS | 5.7 | -19.2 | 0.0 | 130.0 | 23.3 | +23.0 | 0.0 | 332.3 |
| SHOTS AFTER THE MOVES | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOTS IN THE MOVE | 20.7 | +115.3 | 0.0 | 103.7 | - | - | - | - |
| SPELL WORTH | - | - | - | - | 2.7 | +2.8 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 4.7 | +0.0 | 0.0 | 65.0 | 7.0 | +0.0 | 0.0 | 220.3 |
| STAND AND SHOOT | - | - | - | - | 1.3 | -3.8 | 66.0 | 65.0 |
| STANDS STILL | 43.7 | +0.0 | 154.7 | 115.0 | 17.7 | +0.0 | 22.0 | 0.0 |
| STAY WORTH | 15.7 | -6.2 | 154.7 | 60.0 | 0.3 | -0.3 | 0.0 | 0.0 |
| STRIKE BY THE ODDS | 0.7 | +34.6 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 124.0 |
| STUPIDITY NEXT TURN | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 25.7 | +4103.4 | 0.0 | 63.3 | 12.7 | +2449.6 | 0.0 | 284.0 |
| SUPPORT NARROWED | 1.7 | +0.0 | 130.0 | 31.7 | 1.3 | +0.0 | 44.0 | 62.0 |
| SUPPORT WORKED OUT | 25.7 | +4103.4 | 0.0 | 63.3 | 12.7 | +2449.6 | 0.0 | 284.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -72.2 | 0.0 | 0.0 | 0.3 | -1.6 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.7 | +0.0 | 0.0 | 65.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 67.0 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 54.0 | +0.0 | 0.0 | 250.3 | 39.3 | +0.0 | 0.0 | 497.7 |
| TIED UP BY THE SUM | 1.3 | +90.6 | 126.3 | 65.0 | 1.7 | +132.7 | 131.0 | 65.0 |
| TIME ON OUR SIDE | 53.7 | +502.1 | 0.0 | 190.3 | - | - | - | - |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 124.0 |
| WAR ENGINE CHARGES | - | - | - | - | 0.3 | +2.0 | 0.0 | 0.0 |
| WEAPON BY POINTS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 48.0 |
| WHAT THE JOINER ADDS | 3.3 | -27.9 | 372.0 | 33.3 | 1.3 | +18.0 | 0.0 | 0.0 |
| WHO FIGHTS | 2.3 | -41.4 | 254.0 | 15.0 | 2.0 | +7.3 | 22.0 | 65.0 |
| WHO GETS IN | 0.7 | +205.8 | 124.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | 1.7 | -16.5 | 186.0 | 16.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 6.3 | -1336.7 | 0.0 | 123.3 | 4.3 | -1246.2 | 0.0 | 394.0 |
| WHOLE FIGHT GAIN | 0.7 | +53.9 | 143.3 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 0.7 | +2.3 | 0.0 | 0.0 | 3.3 | +7.2 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p95

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 157 | 157 | 90 | 30.00 | +1494 | +16.6 |
| HOLDER ASSIGNMENT | 78 | 78 | 73 | 24.33 | +3814 | +52.2 |
| LEGAL CHARGES ONLY | 70 | 70 | 70 | 23.33 | +0 | +0.0 |
| FIVE ACTION | 581 | 567 | 49 | 16.33 | +4869 | +99.4 |
| SUPPORT ADDS | 115 | 114 | 39 | 13.00 | +3492 | +89.5 |
| SUPPORT WORKED OUT | 115 | 114 | 39 | 13.00 | +3492 | +89.5 |
| REDIRECT FOR A FRIEND IN REACH | 33 | 33 | 33 | 11.00 | +0 | +0.0 |
| QUARTER ODDS | 161 | 159 | 30 | 10.00 | +1569 | +52.3 |
| PROMISE BY ITS OWN SUM | 64 | 64 | 29 | 9.67 | -3228 | -111.3 |
| THE TABLE AGAIN | 36 | 36 | 29 | 9.67 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 45 | 35 | 27 | 9.00 | +1049 | +38.8 |
| OFF BEST | 26 | 26 | 26 | 8.67 | -998 | -38.4 |
| DEPLOY BY FIGURES | 41 | 41 | 22 | 7.33 | +162 | +7.4 |
| NEXT CHARGE BY LIST | 30 | 25 | 22 | 7.33 | +1065 | +48.4 |
| HIS SHOT LIST | 133 | 129 | 21 | 7.00 | +199 | +9.5 |
| TIME ON OUR SIDE | 161 | 136 | 17 | 5.67 | +18 | +1.1 |
| HIS SHOTS BY HIS RUN | 144 | 139 | 15 | 5.00 | +151 | +10.1 |
| MEETS IN TIME | 25 | 25 | 15 | 5.00 | +710 | +47.3 |
| MOVE ORDER | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| FOUR ROUNDS | 32 | 30 | 14 | 4.67 | +1337 | +95.5 |
| JOINT CHARGE NOW | 13 | 13 | 13 | 4.33 | +990 | +76.2 |
| GOAL WALK | 61 | 61 | 12 | 4.00 | +916 | +76.3 |
| IDLE COST | 49 | 32 | 12 | 4.00 | +37 | +3.1 |
| MAX FOR POSITIONING | 30 | 27 | 11 | 3.67 | +38 | +3.4 |
| SHOT RISK POINTS | 87 | 84 | 11 | 3.67 | +390 | +35.4 |
| COVER ONCE | 45 | 30 | 9 | 3.00 | +94 | +10.5 |
| FOLLOW UP WEIGHED | 9 | 9 | 9 | 3.00 | +2234 | +248.2 |
| HARD STAY DROPPED | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| CHAFF PASSED | 8 | 8 | 8 | 2.67 | -12 | -1.5 |
| HOLDS AMBUSHERS | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| RESERVE FALL BACK | 7 | 7 | 7 | 2.33 | +189 | +27.0 |
| TIED UP BY THE SUM | 9 | 8 | 7 | 2.33 | +230 | +32.9 |
| CASTS FROM BEHIND | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CHALLENGE BY POINTS | 6 | 6 | 6 | 2.00 | +141 | +23.6 |
| CHARGE NOW FIRST | 15 | 15 | 6 | 2.00 | -798 | -133.0 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +213 | +35.6 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 6 | 2.00 | +127 | +21.2 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHARGE LOSSES | 83 | 80 | 5 | 1.67 | +291 | +58.2 |
| FALLS SHORT | 71 | 57 | 4 | 1.33 | +13 | +3.1 |
| NEARER NOT NEEDED | 63 | 58 | 4 | 1.33 | +130 | +32.5 |
| RISK BY ARC | 21 | 20 | 4 | 1.33 | +109 | +27.3 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SEARCH SPOT | 6 | 6 | 4 | 1.33 | +59 | +14.7 |
| STRIKE BY THE ODDS | 4 | 4 | 4 | 1.33 | +36 | +9.0 |
| SUPPORT NARROWED | 9 | 9 | 4 | 1.33 | -288 | -72.0 |
| WHAT THE JOINER ADDS | 14 | 14 | 4 | 1.33 | +300 | +75.0 |
| WHOLE FIGHT DANGER | 32 | 32 | 4 | 1.33 | +46 | +11.4 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 1.00 | +936 | +311.9 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +138 | +45.9 |
| ONE OBJECTIVE FORMULA | 38 | 29 | 3 | 1.00 | +31 | +10.3 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +56 | +18.8 |
| SECOND LOOK | 3 | 3 | 3 | 1.00 | +150 | +50.2 |
| SET UP BY THE SET | 11 | 11 | 3 | 1.00 | +282 | +94.1 |
| CHAFF IN THE MOVE | 3 | 2 | 2 | 0.67 | +0 | +0.0 |
| FIGHT TO THE END | 7 | 7 | 2 | 0.67 | +106 | +52.9 |
| MISSILES IN THE MOVE | 23 | 9 | 2 | 0.67 | +1 | +0.7 |
| OPENS UP | 2 | 2 | 2 | 0.67 | +79 | +39.3 |
| REDIRECT COUNTER | 26 | 21 | 2 | 0.67 | +7 | +3.7 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +9 | +4.5 |
| SHOOTS FROM THE BEST SPOT | 5 | 5 | 2 | 0.67 | +6 | +2.9 |
| WEAPON BY POINTS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHO GETS IN | 2 | 2 | 2 | 0.67 | +618 | +308.8 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +22 | +21.7 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +6 | +5.8 |
| BLOCKED CHARGE SKIPPED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CAST JOB | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | -6 | -6.3 |
| EXACT ROUND | 23 | 22 | 1 | 0.33 | +0 | +0.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | -2 | -1.9 |
| GOAL ROUTE | 1 | 1 | 1 | 0.33 | +164 | +164.0 |
| MANOEUVRE | 3 | 3 | 1 | 0.33 | +8 | +8.3 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +24 | +24.5 |
| MARCH CHECK | 1 | 1 | 1 | 0.33 | +1 | +1.3 |
| NO DOUBLE ROUNDS | 25 | 23 | 1 | 0.33 | +66 | +66.5 |
| ONE JOINT FIGURE | 2 | 2 | 1 | 0.33 | +31 | +30.6 |
| OVERRUNS AWAY | 3 | 3 | 1 | 0.33 | +65 | +65.2 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -2 | -2.0 |
| PROMISE KNOWS THE FIGHT | 3 | 1 | 1 | 0.33 | -1 | -1.4 |
| SET CREDITED ONCE | 6 | 6 | 1 | 0.33 | +2 | +1.6 |
| SHOTS AFTER THE MOVES | 8 | 8 | 1 | 0.33 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 11 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 2 | 2 | 1 | 0.33 | +87 | +87.2 |
| BACKUP TARGETS | 2 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 3 | 3 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 94 | 91 | 0 | 0.00 | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 3 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 18 | 16 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 5 | 5 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 60 | not checked | - | - | - | - |
| FOOT FIRST | 118 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 27 | 26 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 5 | 4 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 19 | 19 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 71 | 68 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 27 | 26 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 26 | 22 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 12 | 11 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 48 | 47 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 52 | 42 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 43 | 43 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 12 | 12 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 6 | 5 | 0 | 0.00 | - | - |
| HOLD ODDS | 124 | 124 | 0 | 0.00 | - | - |
| HONEST WORTH | 27 | 25 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 22 | 22 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LOST AFTER ESCAPE | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 24 | 10 | 0 | 0.00 | - | - |
| NEAREST TO GOAL | 3 | 3 | 0 | 0.00 | - | - |
| NO LATE CUT | 6 | 6 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 3 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 3 | 3 | 0 | 0.00 | - | - |
| ONE FIGHT FORMULA | 29 | 12 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 283 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 13 | 10 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 3 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 3 | 3 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 18 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SHOTS IN THE MOVE | 62 | 43 | 0 | 0.00 | - | - |
| SPELL WORTH | 8 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 35 | 34 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS STILL | 184 | 183 | 0 | 0.00 | - | - |
| STAY WORTH | 48 | 40 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 9 | 7 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 10 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 14 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 13 | not checked | - | - | - | - |
| THE TABLE BINDS | 280 | not checked | - | - | - | - |
| WAITS AGAIN | 14 | 13 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 1 | 1 | 0 | 0.00 | - | - |
| WHO FIGHTS | 13 | 12 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 7 | 7 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 12 | 12 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p95

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 6.33 | 3.33 | 111.3 |
| JOB FIRST | gate | 4.33 | 3.67 | 41.5 |
| ARMY TABLE | rule | 3.33 | 2.33 | 67.9 |
| CHARGE NOW FIRST | rule | 1.00 | 1.00 | 133.0 |
| CHAFF PASSED | rule | 1.67 | - | 2.3 |
| HOLDER ASSIGNMENT | rule | 1.00 | 0.67 | 19.2 |
| JOINT CHARGE NOW | rule | 1.00 | 0.67 | 69.7 |
| SUPPORT NARROWED | rule | 0.67 | 0.67 | 72.0 |
| DEPLOY BY FIGURES | rule | 0.67 | - | 3.1 |
| AFTERMATH BAND | gate | 0.33 | - | 1.9 |
| CHARGE LIST READ AGAIN | rule | 0.33 | - | 6.3 |
| FRIENDS SHOTS CHECKED | rule | 0.33 | - | 1.9 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 2.0 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.33 | 1.4 |
| RULE SWITCHED OFF | gate | - | 0.33 | 0.8 |

### Plans: gs3-83c8646-p95

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 4.7 | 64% | 980 | 340 | 35% |
| Mine | join | 1.7 | 100% | 68 | 0 | 0% |
| Mine | move | 41.7 | 98% | 4249 | 0 | 0% |
| Mine | shoot | 3.0 | 33% | 152 | 87 | 57% |
| Opponent | charge | 4.0 | 50% | 626 | 311 | 50% |
| Opponent | join | 3.3 | 100% | 134 | 0 | 0% |
| Opponent | move | 35.3 | 92% | 2362 | 0 | 0% |
| Opponent | shoot | 0.3 | 100% | 13 | 22 | 165% |
| Opponent | support | 0.3 | 100% | 0 | 0 | - |

### Battle groups: gs3-83c8646-p95

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.3 | 15% | 50% | 0% | - | 0% | 0% | 50% | 50% | 0% |
| Opponent | REDIRECT COUNTER | 4.3 | 8% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p95

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 5 | 190 (5) | 0 | 190 | 19 | 0% | 1.0 | 0 (1) | 239 (4) | - | 139 (3) | 273 (2) |
| Mine | Character | 5 | 71 (5) | 71 | 0 | 3 | 0% | 2.4 | 79 (1) | 88 (3) | 27 (1) | 85 (4) | 28 (1) |
| Mine | Clean-up | 1 | 30 (1) | 30 | 0 | 0 | 0% | 3.0 | - | - | 30 (1) | 30 (1) | - |
| Mine | Fast | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (2) | - | - | 0 (2) | - |
| Mine | Fast Hammer | 4 | 108 (4) | 108 | 0 | 25 | 25% | 2.7 | 0 (1) | 144 (3) | - | 121 (1) | 104 (3) |
| Mine | Hammer | 1 | 127 (1) | 127 | 0 | 0 | 0% | 6.0 | - | 127 (1) | - | 127 (1) | - |
| Mine | Holder | 7 | 14 (7) | 0 | 14 | 14 | 14% | 1.7 | 32 (3) | 0 (3) | - | 21 (5) | 0 (1) |
| Mine | Shooter | 2 | 88 (2) | 88 | 0 | 52 | 0% | 1.5 | - | 168 (1) | 0 (1) | - | 88 (2) |
| Mine | Wizard | 3 | 0 (3) | 0 | 0 | 38 | 0% | 2.3 | - | - | 0 (2) | - | 0 (2) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 8 | 156 (8) | 0 | 156 | 34 | 50% | 3.5 | 229 (2) | 133 (4) | 143 (2) | 121 (7) | 400 (1) |
| Opponent | Character | 12 | 45 (12) | 45 | 0 | 44 | 33% | 3.4 | 0 (4) | 130 (2) | 28 (4) | 69 (8) | 41 (2) |
| Opponent | Fast Hammer | 7 | 7 (7) | 0 | 7 | 70 | 29% | 3.6 | 0 (2) | 10 (2) | 8 (3) | 9 (5) | 0 (2) |
| Opponent | Hammer | 3 | 73 (3) | 73 | 0 | 0 | 67% | 5.0 | 73 (3) | - | - | 73 (3) | - |
| Opponent | Holder | 3 | 44 (3) | 0 | 44 | 65 | 33% | 3.5 | - | 62 (2) | 0 (1) | - | 44 (3) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Wizard | 5 | 3 (5) | 3 | 0 | 55 | 0% | 1.6 | 5 (2) | 0 (2) | 0 (1) | 4 (4) | 0 (1) |

### Charged fights: gs3-83c8646-p95

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Tomb Kings of Khemri | 2 | 156 | 960 | 3.5 | 1.1 | 274 | 0 | +274 | 4 of 7 | 5 of 7 | +693 | +205 |
| Mine | Vampire Counts | 1 | 0 | 306 | 6.0 | 1.2 | 51 | 8 | +43 | 2 of 6 | 5 of 6 | +186 | +14 |
| **Mine** | all armies | 3 | 104 | 742 | 4.3 | 1.2 | 171 | 4 | +167 | 6 of 13 | 10 of 13 | +440 | +118 |
| Opponent | Vampire Counts | 2 | 0 | 98 | 3.0 | 1.2 | 32 | 8 | +24 | 6 of 6 | 4 of 6 | +0 | +29 |
| Opponent | Warriors of Chaos | 1 | 0 | 66 | 2.0 | 1.5 | 33 | 60 | -27 | 1 of 2 | 1 of 2 | +66 | -120 |
| **Opponent** | all armies | 3 | 0 | 87 | 2.7 | 1.2 | 33 | 21 | +11 | 7 of 8 | 5 of 8 | +33 | +4 |

### Effective charges: gs3-83c8646-p95

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Tomb Kings of Khemri | 7 | 0 | 0 | 1 (net +186) | 1 (net +0) | 2 (net +369) | 2 (net +498) | 1 | 17% (1 of 6) |
| Mine | Vampire Counts | 6 | 3 (net -2) | 0 | 2 (net +38) | 0 | 0 | 1 (net +186) | 0 | 33% (2 of 6) |
| Opponent | Vampire Counts | 6 | 2 (net +0) | 1 (net +0) | 0 | 1 (net +0) | 0 | 2 (net +72) | 0 | 0% (0 of 6) |
| Opponent | Warriors of Chaos | 2 | 0 | 0 | 0 | 0 | 1 (net +66) | 0 | 1 | 0% (0 of 1) |

### Charged fights, damage counted: gs3-83c8646-p95

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 3 | 189 | 299 | -2 | 15 | 17 | -2 | -0.9 |
| Mine | Effective (55-75%) | 3 | 165 | 107 | +87 | 110 | 11 | +99 | +60.3 |
| Mine | 76-89% | 1 | 411 | 380 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 199 | 173 | +394 | 394 | 11 | +384 | +192.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 415 | 123 | +369 | 369 | 0 | +369 | +88.9 |
| Mine | No odds | 1 | 411 | 380 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | All fights | 13 | 255 | 211 | +167 | 177 | 9 | +168 | +65.9 |
| Opponent | Long shot (under 50%) | 2 | 260 | 406 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 50-54% | 1 | 657 | 380 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 76-89% | 1 | 471 | 380 | +0 | 0 | 63 | -63 | -13.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 328 | 313 | +72 | 98 | 42 | +56 | +17.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 311 | 66 | +66 | 66 | 0 | +66 | +21.2 |
| Opponent | No odds | 1 | 120 | 431 | -120 | 0 | 120 | -120 | -100.0 |
| Opponent | All fights | 8 | 342 | 337 | +11 | 33 | 33 | -1 | -0.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p95 | move | 22 | 2 (9%) | 2 (9%) | 5 (23%) | 15 (68%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2527 |
| Charmed Shield | Opponent | L2227, L2527 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L2227, L2527 |
| Ring of Doom | Opponent | L2331 |

# Doctrine scorecard: gs3-83c8646-p67

### Scorecard: gs3-83c8646-p67

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1118 | 2 | 1 | Mine | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | - | 3 | 2 | 0 | 0 | 0 | 413 |
| L1135 | 1 | 1 | Mine | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 330 |
| L1135 | 1 | 1 | Opponent | no | 0 | 5 | 2 | 2 | 0 | 0 | 0 | 423 |
| L1228 | 4 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 165 |
| L1228 | 4 | 1 | Opponent | no | 4 | 3 | 3 | 1 | 0 | 0 | 0 | 287 |
| **Average** | | | Mine | 0% | 0.0 | 2.0 | 1.7 | 1.0 | 0.0 | 0.0 | 0.0 | 275.0 |
| **Average** | | | Opponent | 0% | 2.0 | 4.0 | 2.7 | 1.7 | 0.0 | 0.0 | 0.0 | 374.3 |

### KPIs: gs3-83c8646-p67

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 69% (9 of 13) | 0% (0 of 17) | 30% (9 of 30) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 0% (0 of 1); on the table 0% | 50% (1 of 2); on the table 50% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (2 of 2); on the table 100% | - | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | 33% (1 of 3); on the table 33% | - | 33% (1 of 3); on the table 33% |
| Winner chose to follow up or pursue (all three) |  | 67% (4 of 6); on the table 67% | 0% (0 of 1); on the table 0% | 57% (4 of 7); on the table 57% |
| Magic missiles tried each own turn | 50%+ | 25% (18 of 72) | 17% (3 of 18) | 23% (21 of 90) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 38% (18 of 48) | 23% (3 of 13) | 34% (21 of 61) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 53% (3150 of 5998) | 61% (3668 of 6000) | 57% (6818 of 11998) |
|   infantry points that never fought | lower | 73% (536 of 730) | 40% (312 of 782) | 56% (848 of 1512) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 64% (16 of 25) | 65% (17 of 26) | 65% (33 of 51) |
| Bound items with a magic missile used (at least once a game) |  | 57% (4 of 7); 3.3 uses a game | 50% (1 of 2); 1.0 uses a game | 56% (5 of 9); 2.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 3); 0.0 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 58% (3229 of 5614) | 64% (3628 of 5644) | 61% (6857 of 11258) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.3 (19%) | 1.0 (20%) | 4.3 (19%) |
| MARCHED: its unit marched | 6.0 (33%) | 0.3 (7%) | 6.3 (28%) |
| CHARGED: its unit charged | 0.7 (4%) | 0.7 (13%) | 1.3 (6%) |
| IN COMBAT: engaged in combat | 4.7 (26%) | 0.0 (0%) | 4.7 (20%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.3 (7%) | 0.3 (1%) |
| FLEEING: fleeing | 3.3 (19%) | 0.0 (0%) | 3.3 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 1.7 (33%) | 1.7 (7%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 1.0 (20%) | 1.0 (4%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 1.0 | 6.0 | 0.7 | 7.0 | 0.3 | 3.3 |
| not cast | 3.0 | 10.0 | 5.3 | 23.0 | 3.7 | 24.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.7 (37%) | 0.0 (0%) | 4.3 (19%) | 0.3 (9%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 6.3 (28%) | 1.3 (36%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (6%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.7 (20%) | 0.7 (18%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 1.7 (17%) | 1.3 (25%) | 0.3 (1%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 2.7 (27%) | 0.0 (0%) | 3.3 (14%) | 1.3 (36%) | 4.0 (16%) |
| OFF THE TABLE: off the table or not arrived | 1.7 (56%) | 0.7 (7%) | 1.7 (31%) | 1.7 (7%) | 0.0 (0%) | 3.3 (14%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.7 (7%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (4%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.3 (44%) | 0.7 (7%) | 2.3 (44%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.0 (65%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 0.7 a game | 0.3 a game |
| stood (cast and not dispelled) | - | 50% (1 of 2) | 50% (1 of 2) |
| the unit moved after it | - | 0% (0 of 1) | 0% (0 of 1) |
| it charged on its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| the enemy charged it first | - | 0% (0 of 1) | 0% (0 of 1) |
| it fought by the end of its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 1) | 0% (0 of 1) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (1 of 1) | 100% (1 of 1) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 70% (37 of 53) | 65% (45 of 69) | 67% (82 of 122) |
|   cavalry | - | 62% (10 of 16) | 62% (10 of 16) |
|   character | - | 100% (11 of 11) | 100% (11 of 11) |
|   chariot | 56% (5 of 9) | 100% (8 of 8) | 76% (13 of 17) |
|   infantry | 58% (7 of 12) | 38% (10 of 26) | 45% (17 of 38) |
|   monster | - | 75% (6 of 8) | 75% (6 of 8) |
|   war machine | 78% (25 of 32) | - | 78% (25 of 32) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (38%) | 4.3 (54%) | 6.3 (48%) |
| CHARGED: it charged | 0.7 (12%) | 0.7 (8%) | 1.3 (10%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.7 (8%) | 0.7 (5%) |
| MOVED: a war machine that moved | 0.3 (6%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 0.0 (0%) | 1.0 (12%) | 1.0 (8%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (4%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (19%) | 1.0 (12%) | 2.0 (15%) |
| SHELTERED: the target was sheltered | 1.0 (19%) | 0.0 (0%) | 1.0 (8%) |
| OTHER BAR | 0.3 (6%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| character | 3.7 | 1.0 | 73% | 14.6 pts | 53 pts |
| chariot | 4.3 | 2.3 | 62% | 23.4 pts | 101 pts |
| infantry | 7.7 | 2.3 | 70% | 12.4 pts | 95 pts |
| monster | 2.0 | 0.7 | 83% | 7.1 pts | 14 pts |
| war machine | 10.0 | 11.3 | 47% | 26.7 pts | 267 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.7 | 3.0 | 3.8 |
| Charges that made contact a game | 4.3 | 2.0 | 3.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.33 declared, 1.17 contact (6 units) | - | 1.33 declared, 1.17 contact (6 units) |
|   per unit a game, units carrying another wizard (or one alone) | 2.00 declared, 2.00 contact (1 units) | - | 2.00 declared, 2.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.44 declared, 0.44 contact (9 units) | 0.35 declared, 0.23 contact (26 units) | 0.37 declared, 0.29 contact (35 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (4 of 6) | - | 25% (1 of 4) | 50% (5 of 10) |
| Character in a unit | 100% (2 of 2) | 100% (2 of 2) | 100% (1 of 1) | 100% (5 of 5) |
| Character on its own | 0% (0 of 1) | 38% (3 of 8) | 50% (2 of 4) | 38% (5 of 13) |
| Chariot | 50% (2 of 4) | - | - | 50% (2 of 4) |
| Infantry | 75% (6 of 8) | - | - | 75% (6 of 8) |
| Monster | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Monstrous | 50% (1 of 2) | 100% (2 of 2) | - | 75% (3 of 4) |
| War Machines | 100% (6 of 6) | - | - | 100% (6 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 3 | 67% (4 of 6); on the table 67% | 25% (18 of 72) | 53% | 64% (16 of 25) | 57% (4 of 7); 3.3 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| Ogre Kingdoms | 1 | - | 17% (1 of 6) | 81% | 71% (5 of 7) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 0% (0 of 1); on the table 0% | 17% (1 of 6) | 49% | 29% (2 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | 17% (1 of 6) | 54% | 83% (10 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p67, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 83% (5) | 40% (2) | 64% (7) |
| ...free all their last turn and able to turn (per game) | 1.33 | 0.67 | 2.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 1.00 | 0.33 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p67

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 1.0 |
| Strategy | Charge objectives carried out (made contact) | 86% (12 of 14) | 62% (5 of 8) |
| Strategy | Shoot objectives carried out (shot that target) | 32% (14 of 44) | 64% (18 of 28) |
| Strategy | Support requests answered (helper made contact too) | 100% (2 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 38% (3 of 8) | 33% (1 of 3) |
| Strategy | Joined characters whose unit fought | 0% (0 of 4) | 0% (0 of 3) |
| Strategy | Lone characters that fought | 100% (8 of 8) | 60% (3 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 1.0 | 1.7 |
| Movement | Points that never moved of their own | 275.0 | 374.3 |
| Movement | Fights charged into per game | 3.3 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 3 of 10, net -263 | 2 of 5, net -45 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 10, net +0 | 1 of 5, net +233 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 10, net +56 | 0 of 5 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 of 10, net +68 | 2 of 5, net -190 |
| Shooting | Shots by shooting units (incl. breath weapons) | 4.0 | 15.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 25% (3 of 12) | 43% (20 of 46) |
| Shooting | Points destroyed by shooting units | 161.7 | 55.0 |
| Shooting | War machine shots | 8.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 40% (10 of 25) | - |
| Shooting | Points destroyed by war machines | 0.0 | 55.0 |
| Magic | Magic missiles cast | 5.0 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 60% (9 of 15) | 50% (1 of 2) |
| Magic | Wounds caused by magic missiles | 6.3 | - |
| Magic | Wounds caused by other spells | 7.7 | - |
| Magic | Points destroyed by magic (all spells) | 139.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 2.7 / 2.7 / 0.3 | 0.3 / 1.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 258.0 | 177.3 |
| Combat | Points run down | 37.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | -9 | -74 |
| Combat | Net per 100 charger points, damage counted | -2.6 | -35.3 |
| Combat | First round won (charged fights) | 50% | 33% |
| Combat | Net points per charged fight | -41 | -39 |
| Combat | Net points per supported fight / lone fight | -191 / +24 | - / -39 |
| Combat | Charged fights on a top-3 enemy unit | 4 of 10 | 4 of 6 |
| Game | Points lost | 556.0 | 765.3 |
| Game | VP from objectives | 863.3 | 226.7 |
| Game | Lone holders (player turns) | 0.0 | 2.0 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +946 VP
- The side that went first won 2 of 2 games with a winner
- Points traded per game (both sides' losses): 1321
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: gs3-83c8646-p67

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 7.3 | +62.7 | 0.0 | 0.0 | 24.0 | +148.6 | 0.0 | 402.0 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +10.2 | 0.0 | 30.0 |
| ARTILLERY RE-ROLL WEIGHED | 5.3 | +0.0 | 0.0 | 110.0 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +1.1 | 0.0 | 0.0 | 0.3 | +0.2 | 0.0 | 61.7 |
| BEST PRIZE | 0.7 | -77.1 | 13.3 | 0.0 | - | - | - | - |
| BOMBING RUN | 0.3 | +10.8 | 78.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 8.3 | +193.4 | 686.3 | 330.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 1.0 | +9.5 | 0.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 3.0 | +16.2 | 93.3 | 0.0 | 2.0 | +24.7 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 0.3 | +0.0 | 0.0 | 91.3 |
| CHAFF IN THE MOVE | - | - | - | - | 0.7 | +14.0 | 0.0 | 13.3 |
| CHALLENGE BY POINTS | - | - | - | - | 1.0 | +60.8 | 0.0 | 37.0 |
| CHARGE LOSSES | 19.7 | -346.1 | 0.0 | 408.0 | 16.3 | -763.2 | 0.0 | 490.7 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 239.7 | 304.0 | 1.0 | +0.0 | 77.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 4.3 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 22.7 |
| CONVEYANCE SEARCH | - | - | - | - | 0.7 | +35.9 | 0.0 | 91.3 |
| COVER ONCE | 5.7 | -344.7 | 0.0 | 0.0 | 8.3 | -1194.7 | 0.0 | 198.0 |
| DENIED BY THE FIGHT | 1.0 | -6.9 | 161.0 | 77.7 | 0.3 | -0.2 | 77.7 | 0.0 |
| DEPLOY BY FIGURES | 6.0 | -45.0 | 0.0 | 0.0 | 8.3 | -61.2 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | +2.0 | 52.7 | 77.7 | - | - | - | - |
| EVASIVE BY THE ODDS | - | - | - | - | 0.3 | +186.1 | 0.0 | 0.0 |
| EXACT ROUND | 2.0 | +28.3 | 200.3 | 100.0 | 1.3 | +13.4 | 77.7 | 30.0 |
| FALL BACK GOOD ORDER | 3.3 | +20.8 | 336.7 | 304.0 | 0.7 | +0.1 | 77.7 | 42.0 |
| FALLS SHORT | 0.7 | +10.1 | 0.0 | 0.0 | 24.7 | +318.0 | 0.0 | 384.3 |
| FEATURE BUFFS | 2.0 | +13.5 | 0.0 | 0.0 | - | - | - | - |
| FIGHT LIFT | - | - | - | - | 1.0 | +11.5 | 0.0 | 0.0 |
| FIGHT TO THE END | 2.0 | +15.5 | 114.3 | 276.3 | 0.7 | +7.2 | 77.7 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 73.3 | +4398.6 | 2007.3 | 1775.3 | 77.7 | +4595.1 | 617.7 | 1091.3 |
| FLANK NOT WEIGHED | 5.7 | +0.0 | 0.0 | 77.7 | 6.7 | +0.0 | 0.0 | 181.3 |
| FOLLOW UP WEIGHED | 0.7 | +126.4 | 0.0 | 77.7 | - | - | - | - |
| FOOT FIRST | 20.3 | +0.0 | 0.0 | 459.3 | - | - | - | - |
| FOUR ROUNDS | 4.7 | +515.7 | 336.7 | 448.7 | 2.7 | +213.1 | 132.7 | 253.3 |
| FREED FROM HIS FIGHT | 2.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 2.3 | -13.6 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.3 | -1.6 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 2.7 | +221.7 | 0.0 | 155.3 | 12.0 | +1067.2 | 0.0 | 0.0 |
| GUN MASK | 2.0 | +171.5 | 0.0 | 64.7 | - | - | - | - |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 52.7 |
| HE REFORMS ONCE FREED | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 13.7 | +0.0 | 0.0 | 155.3 | 10.7 | +0.0 | 0.0 | 334.7 |
| HIS CHARGE DENIED | 0.3 | +6.3 | 0.0 | 72.3 | 0.7 | +39.6 | 0.0 | 30.0 |
| HIS CHARGE LIST | 3.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 26.7 |
| HIS LEGAL MOVES | 5.0 | +0.0 | 0.0 | 408.0 | 6.3 | +0.0 | 0.0 | 156.0 |
| HIS MOVE AND SHOT | 4.0 | -29.9 | 0.0 | 0.0 | 11.7 | -128.6 | 0.0 | 323.3 |
| HIS ONE QUARTER | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 8.0 | +0.0 | 0.0 | 408.0 | 6.3 | +0.0 | 0.0 | 156.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 29.3 | +660.2 | 0.0 | 284.7 | 46.7 | +2404.7 | 0.0 | 714.7 |
| HIS SHOTS BY HIS RUN | 33.7 | +981.1 | 0.0 | 408.0 | 43.0 | +1272.0 | 0.0 | 714.7 |
| HIS TURN DENIED | 1.0 | +53.3 | 161.0 | 77.7 | 0.3 | +1.4 | 77.7 | 0.0 |
| HOLD ODDS | 16.3 | +0.0 | 0.0 | 129.3 | 4.3 | +0.0 | 0.0 | 26.7 |
| HOLDER ASSIGNMENT | 10.0 | +782.6 | 0.0 | 129.3 | 4.0 | +507.6 | 0.0 | 13.3 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.3 | -95.0 | 295.0 | 77.7 | 1.0 | -61.3 | 132.7 | 0.0 |
| HUNT IN PAIRS | 1.0 | +64.7 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | 0.7 | -19.6 | 0.0 | 0.0 | 13.3 | -217.7 | 0.0 | 125.0 |
| JOINT CHARGE NOW | 1.3 | +336.8 | 0.0 | 198.7 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 3.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +33.7 | 0.0 | 0.0 | 0.3 | +15.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 1.3 | +0.0 | 11.3 | 0.0 | 2.7 | +0.0 | 77.7 | 358.3 |
| LONE WIZARD KEPT IN | 0.7 | +52.8 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.3 | -1.1 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 3.3 | -6.0 | 216.0 | 448.7 | 1.0 | +4.4 | 0.0 | 72.0 |
| LOST CHARGE | 0.3 | -0.3 | 41.7 | 50.0 | - | - | - | - |
| MANOEUVRE | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | -6.7 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 1.7 | +231.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.7 | +62.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 1.7 | +190.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 2.3 | +43.6 | 0.0 | 0.0 | 0.3 | +8.4 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.7 | +105.3 | 0.0 | 77.7 | 3.0 | +157.9 | 0.0 | 73.0 |
| MEETS IN TIME | 1.7 | +155.5 | 0.0 | 0.0 | 4.0 | +307.2 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 7.0 | +113.4 | 0.0 | 142.3 | 3.3 | +35.8 | 0.0 | 52.7 |
| MISSILES NEXT TURN | 11.3 | +99.8 | 0.0 | 333.3 | 3.0 | +27.3 | 0.0 | 52.7 |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 11.3 | 0.0 |
| MOVE TO CHARGE COMPUTED | 4.7 | +380.2 | 0.0 | 0.0 | 2.3 | +175.5 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.0 | +263.0 | 0.0 | 0.0 | 7.0 | +352.5 | 0.0 | 99.3 |
| NEAREST TO GOAL | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 3.3 | +285.4 | 0.0 | 0.0 | 2.0 | +165.5 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.7 | -20.0 | 0.0 | 0.0 | 0.3 | -33.3 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 3.0 | -166.9 | 336.7 | 177.7 | 2.3 | -197.2 | 132.7 | 223.3 |
| NO LATE CUT | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.3 | -0.2 | 0.0 | 0.0 | 0.7 | -0.9 | 0.0 | 0.0 |
| OFF BEST | 4.0 | -149.1 | 0.0 | 64.7 | 2.3 | -103.9 | 0.0 | 37.0 |
| OGRE LOADER SECOND SHOT | 9.0 | +41.9 | 42.0 | 55.0 | - | - | - | - |
| ONE CHALLENGE TEST | - | - | - | - | 0.3 | -4.5 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.0 | -98.9 | 0.0 | 77.7 | 4.0 | -127.3 | 0.0 | 61.7 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | -26.4 | 0.0 | 42.0 |
| ONE OBJECTIVE FORMULA | 5.0 | +2.7 | 0.0 | 0.0 | 0.3 | -1.9 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.3 | +10.5 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +8.2 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 1.3 | +23.8 | 138.7 | 100.0 | 1.0 | +9.7 | 132.7 | 181.3 |
| PLAN RESULT | 33.7 | +736.1 | 1298.0 | 848.7 | 35.7 | +419.5 | 270.0 | 1143.3 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 5.7 | -122.6 | 0.0 | 0.0 | 3.0 | -73.2 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.7 | -12.2 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 10.3 | +1640.6 | 614.7 | 0.0 | 12.3 | +1463.7 | 0.0 | 223.3 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.3 | +5.4 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 3.3 | +422.8 | 0.0 | 24.7 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 2.3 | +0.0 | 0.0 | 36.0 |
| REDIRECT WEIGHED | 0.3 | -63.4 | 13.3 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 1.7 | -20.5 | 0.0 | 0.0 | 0.7 | -14.3 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 64.7 | - | - | - | - |
| RESERVE FALL BACK | 0.3 | +1.3 | 0.0 | 0.0 | 0.3 | +13.4 | 0.0 | 0.0 |
| RISK BY ARC | 4.0 | +117.9 | 336.7 | 376.3 | 2.3 | -92.0 | 132.7 | 223.3 |
| ROUNDS AFTER TERROR | 0.7 | -15.4 | 0.0 | 144.7 | - | - | - | - |
| RUN DOWN | 3.0 | -19.1 | 336.7 | 177.7 | 2.7 | -68.2 | 132.7 | 253.3 |
| SCOUT SPOT | - | - | - | - | 0.7 | +2.9 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | - | - | - | - | 0.3 | +0.9 | 0.0 | 61.7 |
| SET CREDITED ONCE | 1.0 | -78.1 | 0.0 | 0.0 | 1.7 | -124.4 | 0.0 | 74.0 |
| SET UP BY THE SET | 1.3 | +46.0 | 0.0 | 0.0 | 2.7 | +100.7 | 0.0 | 74.0 |
| SET UP TOGETHER | - | - | - | - | 0.3 | +3.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 13.7 | +0.0 | 0.0 | 394.7 | 9.0 | +0.0 | 0.0 | 61.7 |
| SHOOTS FROM THE BEST SPOT | 3.3 | +37.3 | 158.0 | 129.3 | 0.7 | +12.7 | 0.0 | 0.0 |
| SHOT OR CHARGE | 1.0 | -48.4 | 61.7 | 144.7 | 0.7 | -5.7 | 0.0 | 30.0 |
| SHOT RISK POINTS | 21.0 | -179.1 | 0.0 | 408.0 | 28.7 | +190.4 | 0.0 | 489.3 |
| SHOTS AFTER THE MOVES | 5.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 13.0 | +589.9 | 0.0 | 330.0 | 13.7 | +613.4 | 0.0 | 239.0 |
| SPELL WORTH | 0.7 | +7.5 | 0.0 | 0.0 | 1.7 | +25.9 | 91.3 | 91.3 |
| SPELLS IN THE FIGHT | 0.7 | +7.3 | 145.3 | 0.0 | 1.0 | -51.2 | 0.0 | 30.0 |
| SPOT AS THE GAME MOVES | 1.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 48.3 |
| STAND AND SHOOT | 1.3 | -9.6 | 220.0 | 77.7 | - | - | - | - |
| STANDS FOR A REASON | - | - | - | - | 11.3 | +0.0 | 100.0 | 46.7 |
| STANDS STILL | 39.0 | +0.0 | 1670.7 | 789.3 | 33.0 | +0.0 | 485.0 | 368.7 |
| STAY WORTH | 30.3 | +132.1 | 1167.7 | 990.0 | 22.0 | +218.5 | 265.0 | 223.3 |
| STRIKE BY THE ODDS | 1.7 | +34.4 | 362.7 | 263.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 1.7 | +34.6 | 0.0 | 0.0 | 4.3 | +406.2 | 0.0 | 74.0 |
| SUPPORT WORKED OUT | 1.7 | +34.6 | 0.0 | 0.0 | 4.3 | +406.2 | 0.0 | 74.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | -2.1 | 0.0 | 126.3 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 11.3 |
| THE ROW IN ITS ORDER | - | - | - | - | 4.3 | +0.0 | 0.0 | 11.3 |
| THE ROW KEEPS ITS WAY | 3.0 | +0.0 | 0.0 | 64.7 | 4.3 | +0.0 | 0.0 | 78.0 |
| THE STEP BACK IS MADE | 2.3 | +0.0 | 0.0 | 64.7 | 3.3 | +0.0 | 0.0 | 78.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 32.0 | +0.0 | 0.0 | 663.3 | 36.7 | +0.0 | 0.0 | 395.7 |
| TIED UP BY THE SUM | 1.7 | +169.7 | 125.3 | 100.0 | 0.7 | +160.8 | 55.0 | 0.0 |
| TIME ON OUR SIDE | 26.0 | +431.1 | 93.3 | 333.3 | - | - | - | - |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WALKS ON ITS ROUTE | 0.3 | -14.8 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | - | - | - | - | 1.3 | +0.0 | 220.0 | 0.0 |
| WHO FIGHTS | 0.7 | -2.1 | 41.7 | 100.0 | 0.7 | +2.9 | 0.0 | 42.0 |
| WHO HITS BACK | 0.7 | +42.5 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 1.0 | -56.5 | 0.0 | 0.0 | 3.0 | -348.6 | 0.0 | 260.7 |
| WOUNDS ON THE RANKS | 6.0 | +80.0 | 0.0 | 0.0 | 3.3 | +135.7 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p67

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 94 | 94 | 61 | 20.33 | +917 | +15.0 |
| HIS SHOTS BY HIS RUN | 230 | 222 | 61 | 20.33 | +1160 | +19.0 |
| HIS SHOT LIST | 228 | 221 | 53 | 17.67 | +1815 | +34.2 |
| HOLDER ASSIGNMENT | 42 | 42 | 36 | 12.00 | +1857 | +51.6 |
| OGRE LOADER SECOND SHOT | 27 | 27 | 27 | 9.00 | +126 | +4.7 |
| FIVE ACTION | 453 | 445 | 26 | 8.67 | +1798 | +69.2 |
| DEPLOY BY FIGURES | 43 | 43 | 22 | 7.33 | +408 | +18.6 |
| THE TABLE AGAIN | 36 | 36 | 22 | 7.33 | +0 | +0.0 |
| OFF BEST | 19 | 19 | 19 | 6.33 | -759 | -39.9 |
| ARTILLERY RE-ROLL WEIGHED | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| GOAL WALK | 44 | 44 | 15 | 5.00 | +904 | +60.2 |
| HARD STAY DROPPED | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| SHOT RISK POINTS | 149 | 142 | 12 | 4.00 | +772 | +64.3 |
| FOUR ROUNDS | 22 | 22 | 11 | 3.67 | +450 | +40.9 |
| MEETS IN TIME | 17 | 17 | 10 | 3.33 | +481 | +48.1 |
| QUARTER ODDS | 68 | 68 | 9 | 3.00 | +969 | +107.7 |
| SET UP BY THE SET | 12 | 12 | 9 | 3.00 | +316 | +35.1 |
| CASTING BLOCK | 15 | 15 | 8 | 2.67 | +26 | +3.3 |
| PROMISE BY ITS OWN SUM | 26 | 26 | 8 | 2.67 | -588 | -73.4 |
| SHOOTS FROM THE BEST SPOT | 12 | 12 | 8 | 2.67 | +51 | +6.4 |
| CHARGE LOSSES | 108 | 103 | 7 | 2.33 | +677 | +96.7 |
| REDIRECT FOR A FRIEND IN REACH | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 28 | 28 | 7 | 2.33 | +0 | +0.0 |
| STAY WORTH | 157 | 147 | 7 | 2.33 | +12 | +1.7 |
| TIED UP BY THE SUM | 7 | 7 | 7 | 2.33 | +432 | +61.8 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 21 | 16 | 6 | 2.00 | +375 | +62.5 |
| NEXT CHARGE BY LIST | 16 | 13 | 6 | 2.00 | +375 | +62.5 |
| STRIKE BY THE ODDS | 6 | 6 | 6 | 2.00 | +103 | +17.2 |
| TIME ON OUR SIDE | 78 | 66 | 6 | 2.00 | +18 | +2.9 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| IDLE COST | 42 | 27 | 5 | 1.67 | +60 | +11.9 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +148 | +29.7 |
| MARCH BY THE SUM | 5 | 5 | 5 | 1.67 | +694 | +138.8 |
| MARCH OF THE TABLE | 5 | 5 | 5 | 1.67 | -572 | -114.4 |
| SUPPORT ADDS | 18 | 18 | 5 | 1.67 | +200 | +40.0 |
| SUPPORT WORKED OUT | 18 | 18 | 5 | 1.67 | +200 | +40.0 |
| FALLS SHORT | 76 | 66 | 4 | 1.33 | +41 | +10.3 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | +1010 | +252.6 |
| MAX FOR POSITIONING | 23 | 22 | 4 | 1.33 | +26 | +6.5 |
| WOUNDS ON THE RANKS | 28 | 26 | 4 | 1.33 | +71 | +17.8 |
| CANNON PLANNED TARGET | 25 | 25 | 3 | 1.00 | +215 | +71.6 |
| CAST JOB | 3 | 3 | 3 | 1.00 | +1 | +0.4 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +182 | +60.8 |
| COVER ONCE | 42 | 30 | 3 | 1.00 | +196 | +65.3 |
| MARCH CHECK | 5 | 5 | 3 | 1.00 | +102 | +34.1 |
| MISSILES IN THE MOVE | 31 | 25 | 3 | 1.00 | +42 | +13.9 |
| ONE OBJECTIVE FORMULA | 16 | 15 | 3 | 1.00 | +125 | +41.6 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SHOTS IN THE MOVE | 80 | 64 | 3 | 1.00 | +232 | +77.3 |
| THE ROW IN ITS ORDER | 13 | 3 | 3 | 1.00 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 12 | 12 | 3 | 1.00 | +273 | +91.1 |
| BEST PRIZE | 2 | 2 | 2 | 0.67 | -231 | -115.7 |
| CHARGE NOW FIRST | 10 | 10 | 2 | 0.67 | -291 | -145.7 |
| EXACT ROUND | 10 | 10 | 2 | 0.67 | +32 | +16.2 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +379 | +189.6 |
| GUN MASK | 6 | 6 | 2 | 0.67 | +27 | +13.6 |
| HIS CHARGE DENIED | 3 | 3 | 2 | 0.67 | +41 | +20.4 |
| HIS MOVE AND SHOT | 47 | 44 | 2 | 0.67 | +0 | +0.0 |
| HUNT IN PAIRS | 3 | 3 | 2 | 0.67 | +96 | +47.8 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +158 | +79.2 |
| MISSILES NEXT TURN | 43 | 31 | 2 | 0.67 | +6 | +2.8 |
| MOVE ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| NEARER NOT NEEDED | 39 | 37 | 2 | 0.67 | +67 | +33.5 |
| OVERRUNS AWAY | 7 | 7 | 2 | 0.67 | +35 | +17.5 |
| REDIRECT COUNTER | 10 | 9 | 2 | 0.67 | +62 | +30.9 |
| REFUSING RETIRES | 2 | 2 | 2 | 0.67 | +32 | +16.0 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +44 | +22.0 |
| RISK BY ARC | 19 | 19 | 2 | 0.67 | +32 | +16.1 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +64 | +31.9 |
| BOMBING RUN | 1 | 1 | 1 | 0.33 | +32 | +32.5 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 2 | 2 | 1 | 0.33 | +33 | +32.7 |
| EVASIVE BY THE ODDS | 1 | 1 | 1 | 0.33 | +558 | +558.3 |
| FALL BACK GOOD ORDER | 12 | 12 | 1 | 0.33 | +58 | +57.6 |
| FIGHT TO THE END | 8 | 8 | 1 | 0.33 | +17 | +16.7 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS TURN DENIED | 4 | 4 | 1 | 0.33 | +99 | +98.9 |
| MANOEUVRE | 7 | 7 | 1 | 0.33 | +1 | +1.2 |
| ONE FIGHT FORMULA | 27 | 18 | 1 | 0.33 | +12 | +12.5 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | +32 | +31.6 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +20 | +19.9 |
| PROMISE READS THE TABLE | 2 | 2 | 1 | 0.33 | +11 | +11.1 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | -66 | -65.9 |
| SEARCH SPOT | 1 | 1 | 1 | 0.33 | +3 | +2.8 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | -6 | -6.4 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -44 | -44.4 |
| WHO FIGHTS | 4 | 4 | 1 | 0.33 | +7 | +7.0 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 2 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 37 | 37 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 2 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 6 | 6 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 37 | not checked | - | - | - | - |
| FOOT FIRST | 61 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 19 | 17 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 7 | 7 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 10 | 10 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 73 | 70 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 21 | 19 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 34 | 33 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 7 | 7 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 43 | 40 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 62 | 62 | 0 | 0.00 | - | - |
| HONEST WORTH | 10 | 10 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 14 | 14 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 13 | 13 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 8 | 8 | 0 | 0.00 | - | - |
| NEAREST TO GOAL | 2 | 2 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 3 | 3 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 16 | 16 | 0 | 0.00 | - | - |
| NO LATE CUT | 8 | 8 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 6 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 208 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 3 | 1 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 7 | 4 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 17 | 17 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 8 | 8 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 68 | not checked | - | - | - | - |
| SHOT OR CHARGE | 5 | 5 | 0 | 0.00 | - | - |
| SPELL WORTH | 7 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 5 | 5 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 21 | 18 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 34 | 33 | 0 | 0.00 | - | - |
| STANDS STILL | 216 | 211 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 22 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 17 | not checked | - | - | - | - |
| THE TABLE BINDS | 206 | not checked | - | - | - | - |
| WAITS AGAIN | 2 | 2 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 4 | 4 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p67

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.33 | 1.67 | 33.5 |
| PROMISE BY ITS OWN SUM | rule | 1.67 | 1.00 | 73.4 |
| ARMY TABLE | rule | 0.33 | 2.00 | 89.4 |
| MARCH OF THE TABLE | rule | 1.67 | - | 114.4 |
| BEST PRIZE | rule | 0.67 | - | 115.7 |
| CHARGE NOW FIRST | rule | 0.67 | - | 145.7 |
| HOLDER ASSIGNMENT | rule | 0.67 | - | 13.9 |
| NO REASON | gate | 0.67 | - | 51.5 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.33 | 35.0 |
| REDIRECT WEIGHED | rule | 0.33 | - | 65.9 |
| REFUSING RETIRES | rule | 0.33 | - | 1.0 |
| RULE SWITCHED OFF | gate | - | 0.33 | 118.8 |
| SWIFTSTRIDE BY POINTS | rule | 0.33 | - | 6.4 |
| WALKS ON ITS ROUTE | rule | 0.33 | - | 44.4 |

### Plans: gs3-83c8646-p67

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 4.0 | 42% | 636 | 285 | 45% |
| Mine | move | 16.7 | 96% | 1209 | 0 | 0% |
| Mine | shoot | 13.0 | 31% | 446 | 451 | 101% |
| Opponent | charge | 2.3 | 43% | 389 | 133 | 34% |
| Opponent | move | 24.3 | 89% | 1309 | 0 | 0% |
| Opponent | shoot | 8.7 | 31% | 777 | 287 | 37% |
| Opponent | support | 0.3 | 100% | 22 | 0 | 0% |

### Battle groups: gs3-83c8646-p67

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 3.3 | 30% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p67

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 12 | 59 (12) | 59 | 0 | 28 | 25% | 2.2 | - | 37 (8) | 98 (4) | 79 (7) | 44 (5) |
| Mine | Fast Hammer | 4 | 53 (4) | 23 | 30 | 15 | 50% | 2.0 | 78 (2) | 42 (2) | - | 36 (3) | 84 (1) |
| Mine | Holder | 5 | 24 (5) | 0 | 24 | 22 | 20% | 3.2 | - | 30 (4) | 0 (1) | 30 (4) | 0 (1) |
| Mine | Shooter | 2 | 531 (2) | 129 | 402 | 0 | 0% | 1.0 | 186 (1) | 877 (1) | - | 531 (2) | - |
| Mine | War machine | 6 | 0 (6) | 0 | 0 | 50 | 0% | 2.0 | 0 (2) | 0 (2) | 0 (2) | 0 (1) | 0 (5) |
| Opponent | Chaff | 6 | 38 (6) | 0 | 38 | 41 | 50% | 3.0 | 0 (5) | 250 (1) | - | 53 (5) | 0 (1) |
| Opponent | Character | 7 | 40 (7) | 40 | 0 | 14 | 14% | 1.7 | 72 (1) | 0 (3) | 152 (1) | 57 (4) | 0 (1) |
| Opponent | Clean-up | 3 | 73 (3) | 73 | 0 | 0 | 33% | 2.0 | - | 73 (3) | - | 114 (2) | 0 (1) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 4 | 37 (4) | 29 | 8 | 73 | 25% | 1.3 | - | 42 (3) | 0 (1) | 42 (3) | 0 (1) |
| Opponent | Hammer | 8 | 21 (8) | 21 | 0 | 52 | 25% | 1.7 | 45 (2) | 0 (2) | 25 (4) | 0 (5) | 56 (3) |
| Opponent | Holder | 1 | 81 (1) | 0 | 81 | 100 | 0% | 2.0 | - | 81 (1) | - | 81 (1) | - |
| Opponent | Shooter | 2 | 0 (2) | 0 | 0 | 56 | 0% | 1.0 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | 0 (1) | - | 0 (1) | - |

### Charged fights: gs3-83c8646-p67

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 3 | 301 | 178 | 3.3 | 1.3 | 53 | 94 | -41 | 4 of 10 | 5 of 10 | -191 | +24 |
| Opponent | Ogre Kingdoms | 1 | 330 | 0 | 3.0 | 1.0 | 0 | 30 | -30 | 3 of 3 | 0 of 3 | - | -30 |
| Opponent | Warriors of Chaos | 1 | 0 | 165 | 2.0 | 1.0 | 82 | 272 | -190 | 0 of 2 | 1 of 2 | - | -190 |
| Opponent | Wood Elf Realms | 1 | 0 | 233 | 1.0 | 1.0 | 233 | 0 | +233 | 1 of 1 | 1 of 1 | - | +233 |
| **Opponent** | all armies | 3 | 110 | 133 | 2.0 | 1.0 | 66 | 106 | -39 | 4 of 6 | 2 of 6 | - | -39 |

### Effective charges: gs3-83c8646-p67

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 10 | 3 (net -263) | 0 | 1 (net +0) | 0 | 2 (net +56) | 4 (net +68) | 0 | 10% (1 of 10) |
| Opponent | Ogre Kingdoms | 3 | 2 (net -45) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 2) |
| Opponent | Warriors of Chaos | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net -190) | 0 | 0% (0 of 2) |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 1 (net +233) | 0 | 0 | 0 | 0 | 100% (1 of 1) |

### Charged fights, damage counted: gs3-83c8646-p67

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 3 | 408 | 494 | -263 | 0 | 263 | -263 | -64.6 |
| Mine | Effective (55-75%) | 1 | 369 | 185 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 226 | 137 | +68 | 198 | 51 | +147 | +65.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 468 | 76 | +56 | 56 | 0 | +56 | +11.9 |
| Mine | All fights | 10 | 343 | 237 | -41 | 90 | 99 | -9 | -2.6 |
| Opponent | Long shot (under 50%) | 2 | 65 | 369 | -45 | 0 | 140 | -140 | -214.9 |
| Opponent | Effective (55-75%) | 1 | 102 | 233 | +233 | 233 | 0 | +233 | +228.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 494 | 185 | -190 | 82 | 272 | -190 | -38.4 |
| Opponent | No odds | 1 | 34 | 233 | +0 | 0 | 17 | -17 | -50.0 |
| Opponent | All fights | 6 | 209 | 262 | -39 | 66 | 140 | -74 | -35.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p67 | move | 18 | 5 (28%) | 5 (28%) | 3 (17%) | 10 (56%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Clockwork Compass | Mine | L1228 |
| Elixir of Power | Mine | L1118, L1135 |
| Fistful of Laurels | Opponent | L1118 |
| Ring of Doom | Mine | L1118, L1135, L1228 |
| Ring of Jet | Mine | L1118, L1135, L1228 |

# Doctrine scorecard: gs3-83c8646-p13

### Scorecard: gs3-83c8646-p13

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 3 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0106 | 4 | 1 | Opponent | no | 0 | 5 | 1 | 2 | 0 | 0 | 0 | 1061 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 2 | 1 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | 4 | 0 | 5 | 0 | 0 | 0 | 170 |
| L0206 | 2 | 1 | Opponent | - | - | 3 | 0 | 1 | 0 | 0 | 0 | 408 |
| **Average** | | | Mine | 0% | 3.0 | 4.0 | 0.0 | 3.0 | 0.3 | 0.0 | 0.0 | 56.7 |
| **Average** | | | Opponent | 0% | 0.0 | 3.3 | 1.3 | 1.3 | 0.0 | 0.0 | 0.0 | 489.7 |

### KPIs: gs3-83c8646-p13

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 8) | 65% (11 of 17) | 44% (11 of 25) |
| Winner chose to follow up after the loser gave ground |  | 100% (3 of 3); on the table 100% | - | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 100% (3 of 3); on the table 100% | - | 100% (3 of 3); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 41% (37 of 90) | - | 41% (37 of 90) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 56% (37 of 66) | - | 56% (37 of 66) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (4 of 6) | - | 67% (4 of 6) |
| Points that never fought | lower | 34% (1913 of 5699) | 81% (4844 of 6000) | 58% (6757 of 11699) |
|   infantry points that never fought | lower | 45% (1011 of 2239) | 95% (2011 of 2111) | 69% (3022 of 4350) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 50% (8 of 16) | 64% (16 of 25) | 59% (24 of 41) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 3.7 uses a game | 0.0 uses a game | 100% (4 of 4); 1.8 uses a game |
| Bound items with another spell used |  | 50% (1 of 2); 1.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.7 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (4 of 4); 1.3 uses a game | 0.0 uses a game | 100% (4 of 4); 0.7 uses a game |
|   their share of the points of units over 100 pts | lower | 36% (1425 of 3916) | 63% (2763 of 4382) | 50% (4188 of 8298) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 6.7 (38%) | - | 6.7 (38%) |
| MARCHED: its unit marched | 3.0 (17%) | - | 3.0 (17%) |
| IN COMBAT: engaged in combat | 3.7 (21%) | - | 3.7 (21%) |
| GONE: slain | 4.3 (25%) | - | 4.3 (25%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 0.3 | 5.7 | 12.3 | 0.0 | 2.7 |
| not cast | 1.7 | 3.7 | 4.3 | 17.7 | 2.0 | 25.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.3 (64%) | 0.0 (0%) | 6.7 (38%) | 1.7 (83%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.0 (17%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (18%) | 1.7 (38%) | 3.7 (21%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.7 (18%) | 2.0 (46%) | 4.3 (25%) | 0.0 (0%) | 1.7 (7%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (17%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (100%) | 0.0 (0%) | 0.7 (15%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 22.7 (89%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 7.0 a game | 0.0 a game | 3.5 a game |
| stood (cast and not dispelled) | 62% (13 of 21) | - | 62% (13 of 21) |
| the unit moved after it | 69% (9 of 13) | - | 69% (9 of 13) |
| it charged on its next turn | 0% (0 of 13) | - | 0% (0 of 13) |
| the enemy charged it first | 23% (3 of 13) | - | 23% (3 of 13) |
| it fought by the end of its next turn | 15% (2 of 13) | - | 15% (2 of 13) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 13) | - | 0% (0 of 13) |
| none of these (no charge, no fight, no charge escaped) | 77% (10 of 13) | - | 77% (10 of 13) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (15 of 23) | 61% (118 of 195) | 61% (133 of 218) |
|   cavalry | - | 56% (14 of 25) | 56% (14 of 25) |
|   character | - | 57% (12 of 21) | 57% (12 of 21) |
|   chariot | - | 67% (2 of 3) | 67% (2 of 3) |
|   infantry | 65% (15 of 23) | 60% (41 of 68) | 62% (56 of 91) |
|   monster | - | 73% (8 of 11) | 73% (8 of 11) |
|   war machine | - | 61% (41 of 67) | 61% (41 of 67) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (62%) | 1.0 (4%) | 2.7 (9%) |
| CHARGED: it charged | 0.0 (0%) | 1.7 (6%) | 1.7 (6%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (1%) | 0.3 (1%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.3 (1%) | 0.3 (1%) |
| NO TARGET IN RANGE | 0.7 (25%) | 11.0 (43%) | 11.7 (41%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.7 (3%) | 0.7 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (12%) | 5.0 (19%) | 5.3 (19%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 1.7 (6%) | 1.7 (6%) |
| OTHER BAR | 0.0 (0%) | 4.0 (16%) | 4.0 (14%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.7 | 1.7 | 78% | 2.2 pts | 17 pts |
| character | 4.0 | 7.3 | 33% | 17.7 pts | 71 pts |
| chariot | 0.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 27.0 | 11.7 | 68% | 4.4 pts | 119 pts |
| monster | 2.7 | 0.7 | 75% | 3.2 pts | 8 pts |
| war machine | 13.7 | 9.7 | 63% | 7.5 pts | 102 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.7 | 3.3 | 2.0 |
| Charges that made contact a game | 0.7 | 2.3 | 1.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.10 declared, 0.10 contact (20 units) | 0.37 declared, 0.26 contact (27 units) | 0.26 declared, 0.19 contact (47 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Character in a unit | 67% (2 of 3) | 33% (1 of 3) | - | 50% (3 of 6) |
| Character on its own | 100% (3 of 3) | 67% (2 of 3) | 50% (1 of 2) | 75% (6 of 8) |
| Infantry | 57% (4 of 7) | 29% (2 of 7) | - | 43% (6 of 14) |
| Monster | 60% (3 of 5) | - | - | 60% (3 of 5) |
| War Machines | 75% (6 of 8) | - | - | 75% (6 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 3 | 100% (3 of 3); on the table 100% | 41% (37 of 90) | 34% | 50% (8 of 16) | 100% (4 of 4); 3.7 uses a game | 50% (1 of 2); 1.3 uses a game | 100% (4 of 4); 1.3 uses a game |
| Dwarfen Mountain Holds | 2 | - | - | 86% | 65% (13 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | - | - | 70% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p13, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 20% (1) | 50% (1) | 29% (2) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.33 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.33 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p13

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 0.7 |
| Strategy | Charge objectives carried out (made contact) | 100% (2 of 2) | 40% (4 of 10) |
| Strategy | Shoot objectives carried out (shot that target) | 17% (2 of 12) | 49% (38 of 77) |
| Strategy | Support requests answered (helper made contact too) | - | 50% (1 of 2) |
| Strategy | Joined characters whose unit fought | 62% (5 of 8) | 0% (0 of 8) |
| Strategy | Lone characters that fought | 90% (9 of 10) | 50% (1 of 2) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 3.0 | 1.3 |
| Movement | Points that never moved of their own | 56.7 | 489.7 |
| Movement | Fights charged into per game | 0.7 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 2 | 3 of 5, net +332 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 2, net +60 | 0 of 5 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 2 | 0 of 5 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 2 | 1 of 5, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 5.0 | 26.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 33% (5 of 15) | 45% (36 of 80) |
| Shooting | Points destroyed by shooting units | 44.0 | 164.3 |
| Shooting | War machine shots | - | 13.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | - | 68% (28 of 41) |
| Shooting | Points destroyed by war machines | 0.0 | 49.0 |
| Magic | Magic missiles cast | 6.7 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 60% (12 of 20) | - |
| Magic | Wounds caused by magic missiles | 12.7 | - |
| Magic | Wounds caused by other spells | 0.7 | - |
| Magic | Points destroyed by magic (all spells) | 33.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 2.0 / 0.0 | 3.0 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 180.0 | 159.0 |
| Combat | Points run down | 0.0 | 274.0 |
| Combat | Net points per charged fight, damage counted | +22 | +198 |
| Combat | Net per 100 charger points, damage counted | +31.4 | +125.9 |
| Combat | First round won (charged fights) | 100% | 20% |
| Combat | Net points per charged fight | +48 | +142 |
| Combat | Net points per supported fight / lone fight | - / +48 | +55 / +160 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 2 | 4 of 6 |
| Game | Points lost | 618.0 | 354.7 |
| Game | VP from objectives | 636.7 | 860.0 |
| Game | Lone holders (player turns) | 3.0 | 0.0 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -550 VP
- The side that went first won 0 of 3 games with a winner
- Points traded per game (both sides' losses): 973
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: gs3-83c8646-p13

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 21.0 | -156.6 | 0.0 | 251.3 | 15.3 | +140.3 | 0.0 | 198.0 |
| ASSAILMENT BY POINTS | 0.3 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +0.7 | 0.0 | 28.3 | - | - | - | - |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -126.7 | 0.0 | 65.0 |
| CANNON PLAN MISSED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | - | - | - | - | 13.3 | +109.8 | 407.7 | 113.3 |
| CANNON SIGHT KEPT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 0.7 | +18.6 | 66.7 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 4.7 | +279.8 | 96.0 | 362.7 | - | - | - | - |
| CASTS AFTER FRIENDS | 4.3 | +0.0 | 0.0 | 31.7 | - | - | - | - |
| CATCH FLIERS | 0.3 | +8.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.0 | +5.8 | 0.0 | 36.7 | 0.7 | +35.6 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | -0.1 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 24.0 |
| CHALLENGE BY POINTS | 0.7 | +46.5 | 0.0 | 124.0 | - | - | - | - |
| CHARACTER GUNS | - | - | - | - | 6.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 23.0 | -1031.4 | 0.0 | 190.7 | 7.7 | -559.6 | 0.0 | 193.3 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 40.0 | 28.3 | 2.7 | +0.0 | 130.3 | 65.0 |
| CLOSES ON WHAT IT BEATS | 8.3 | +0.0 | 0.0 | 56.7 | 14.3 | +0.0 | 0.0 | 210.0 |
| CONVEYANCE SEARCH | 4.7 | +515.7 | 181.3 | 0.0 | - | - | - | - |
| COVER ONCE | 5.7 | -228.2 | 0.0 | 60.7 | 7.7 | -212.7 | 0.0 | 20.0 |
| DEFENSIVE ARMY | - | - | - | - | 0.3 | +0.0 | 90.7 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -8.4 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 6.7 | +87.5 | 0.0 | 0.0 | 12.3 | -197.3 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -245.9 | 0.0 | 0.0 |
| EXACT ROUND | 0.7 | +10.1 | 60.0 | 28.3 | 1.0 | +1.6 | 35.7 | 89.0 |
| FALL BACK GOOD ORDER | 0.3 | +0.0 | 40.0 | 28.3 | 2.3 | +4.5 | 21.7 | 150.0 |
| FALLS SHORT | 18.0 | +383.4 | 0.0 | 400.3 | 11.7 | +79.4 | 0.0 | 48.0 |
| FEATURE BUFFS | 13.7 | +355.5 | 0.0 | 93.3 | 1.3 | +34.1 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.3 | +47.4 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 65.0 | 21.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 68.7 | +6677.0 | 297.7 | 967.7 | 138.7 | +4740.5 | 1594.0 | 943.3 |
| FLANK NOT WEIGHED | 2.3 | +0.0 | 0.0 | 90.7 | 3.7 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.3 | +99.0 | 0.0 | 0.0 | - | - | - | - |
| FOOT FIRST | - | - | - | - | 22.7 | +0.0 | 0.0 | 105.3 |
| FOUR ROUNDS | 0.7 | +12.5 | 60.0 | 28.3 | 3.3 | +191.1 | 57.3 | 174.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 1.3 | -14.5 | 56.7 | 0.0 |
| GIVES UP | - | - | - | - | 0.3 | -6.1 | 0.0 | 0.0 |
| GOAL WALK | 14.0 | +2464.4 | 0.0 | 113.3 | - | - | - | - |
| GUN FIGURES | - | - | - | - | 1.0 | +19.3 | 90.7 | 0.0 |
| GUN MASK | - | - | - | - | 2.0 | +255.2 | 0.0 | 0.0 |
| HARD STAY DROPPED | - | - | - | - | 7.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 15.7 | +0.0 | 0.0 | 121.3 | 5.3 | +0.0 | 0.0 | 160.0 |
| HIS CHARGE LIST | 10.7 | +0.0 | 0.0 | 56.7 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.3 | +0.0 | 0.0 | 71.7 | 3.0 | +0.0 | 0.0 | 48.0 |
| HIS MOVE AND SHOT | 3.3 | -36.4 | 0.0 | 91.3 | 0.7 | -48.0 | 0.0 | 0.0 |
| HIS ONE QUARTER | - | - | - | - | 3.7 | +0.0 | 0.0 | 113.3 |
| HIS OWN BEST MOVE | 4.0 | +0.0 | 0.0 | 71.7 | 6.3 | +0.0 | 0.0 | 48.0 |
| HIS RANDOM MOVE | - | - | - | - | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 54.0 | +1640.0 | 0.0 | 576.7 | 55.0 | +2317.2 | 0.0 | 436.0 |
| HIS SHOTS BY HIS RUN | 45.7 | +690.8 | 0.0 | 576.7 | 42.0 | +883.3 | 0.0 | 421.3 |
| HIS TURN DENIED | 0.3 | +11.1 | 20.0 | 0.0 | 1.7 | +79.1 | 0.0 | 65.0 |
| HOLD ODDS | 37.0 | +0.0 | 0.0 | 186.7 | 17.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 12.3 | +1347.2 | 0.0 | 90.7 | 11.3 | +1467.9 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.7 | -1.4 | 60.0 | 28.3 | 2.3 | -122.2 | 57.3 | 154.0 |
| HUNT IN PAIRS | - | - | - | - | 1.3 | +178.6 | 0.0 | 0.0 |
| HUNT RESULT | 0.3 | +43.1 | 0.0 | 0.0 | - | - | - | - |
| HUNT THE GUNS | 0.3 | +44.7 | 40.0 | 28.3 | - | - | - | - |
| IDLE COST | 10.7 | -88.1 | 0.0 | 253.3 | 3.0 | -80.9 | 0.0 | 0.0 |
| JOINT CHARGE NOW | 0.3 | -1.6 | 20.0 | 0.0 | 1.3 | +30.4 | 0.0 | 20.0 |
| KEEPS SCOUTS OR AMBUSH | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 4.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +18.2 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 9.7 | +0.0 | 260.0 | 270.0 | 8.7 | +0.0 | 636.7 | 72.0 |
| LONE WIZARD KEPT IN | 2.7 | +247.6 | 0.0 | 0.0 | 0.7 | +60.4 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.3 | +0.0 | 18.3 | 0.0 |
| LOST AFTER ESCAPE | 0.3 | -0.0 | 20.0 | 0.0 | 1.0 | +0.7 | 17.3 | 20.0 |
| MANOEUVRE | 0.7 | -0.4 | 0.0 | 45.7 | 1.0 | -9.1 | 0.0 | 0.0 |
| MARCH BY THE SUM | 1.7 | +107.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.7 | +14.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.7 | -202.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.7 | +58.8 | 0.0 | 101.0 | 0.3 | +1.4 | 0.0 | 0.0 |
| MEETS IN TIME | 3.0 | +105.1 | 0.0 | 0.0 | 7.7 | +68.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 6.7 | +312.4 | 0.0 | 235.3 | - | - | - | - |
| MISSILES NEXT TURN | 7.7 | +245.0 | 0.0 | 144.7 | - | - | - | - |
| MISSILES ON ONE TARGET | 2.3 | -76.5 | 0.0 | 0.0 | - | - | - | - |
| MODEL FACING | - | - | - | - | 2.3 | +372.3 | 0.0 | 60.0 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 20.0 |
| MOVE SPELL OUT OF RANGE | 1.7 | -18.4 | 0.0 | 118.3 | - | - | - | - |
| MOVE SPELL SPOT | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.0 | +173.9 | 0.0 | 91.3 | 4.7 | +201.8 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 3.7 | +155.9 | 0.0 | 0.0 | 10.7 | +401.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 2.0 | +173.9 | 0.0 | 91.3 | 4.3 | +150.3 | 91.3 | 0.0 |
| NO DOUBLE ROUNDS | 0.7 | -12.8 | 60.0 | 28.3 | 3.0 | -107.5 | 57.3 | 109.0 |
| NO LATE CUT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 3.0 | -90.2 | 0.0 | 104.0 | 5.0 | -145.3 | 0.0 | 110.0 |
| ONE FIGHT FORMULA | 7.3 | -65.5 | 0.0 | 152.0 | 3.3 | -33.7 | 0.0 | 20.0 |
| ONE JOINT FIGURE | 0.3 | +2.8 | 20.0 | 0.0 | 1.0 | -46.1 | 0.0 | 20.0 |
| ONE OBJECTIVE FORMULA | 7.7 | -91.4 | 0.0 | 90.7 | 5.3 | -244.3 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.7 | +2.0 | 0.0 | 0.0 |
| ONE ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 1.0 | +28.8 | 35.7 | 24.0 |
| PLAN RESULT | 30.7 | +198.2 | 48.0 | 531.3 | 61.0 | +806.3 | 690.3 | 642.7 |
| PROMISE BY ITS OWN SUM | 2.7 | -7.8 | 0.0 | 28.3 | 4.7 | -78.1 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.3 | -0.3 | 20.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 5.3 | +1034.3 | 66.7 | 0.0 | 14.3 | +651.5 | 0.0 | 363.3 |
| RANDOM MOVE BY FIGURES | 2.0 | +18.5 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | +28.9 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.3 | +24.1 | 0.0 | 28.3 | 2.3 | +85.2 | 0.0 | 48.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.0 | +0.0 | 0.0 | 120.3 | 2.0 | +36.3 | 0.0 | 24.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +2.7 | 0.0 | 0.0 | 2.0 | +60.7 | 0.0 | 0.0 |
| RESERVE MOVE SPELL | 1.3 | +27.5 | 0.0 | 0.0 | - | - | - | - |
| RESTRAINS TO SHOOT | - | - | - | - | 0.3 | +17.3 | 0.0 | 0.0 |
| RISK BY ARC | 0.7 | -36.1 | 60.0 | 28.3 | 3.0 | -34.6 | 57.3 | 109.0 |
| RISK ON THE WAY | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.3 | -1.9 | 21.7 | 130.0 |
| RUN DOWN | 0.3 | -0.4 | 20.0 | 0.0 | 2.0 | -7.5 | 57.3 | 89.0 |
| SAME CHARGE LATER | - | - | - | - | 0.7 | -4.0 | 17.3 | 0.0 |
| SCOUT SPOT | 0.7 | +0.4 | 0.0 | 0.0 | 0.7 | -0.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +2.3 | 0.0 | 0.0 | 0.3 | +14.1 | 0.0 | 0.0 |
| SET CREDITED ONCE | 0.7 | -19.3 | 0.0 | 0.0 | 2.7 | -230.0 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.3 | +7.1 | 0.0 | 0.0 | 3.7 | +323.7 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.7 | +1.9 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 1.7 | +4.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 3.0 | +0.0 | 0.0 | 181.3 | 26.0 | +0.0 | 0.0 | 133.3 |
| SHOOTS FROM THE BEST SPOT | 1.7 | +56.3 | 35.0 | 0.0 | 1.3 | +22.7 | 0.0 | 0.0 |
| SHORT GUN FORWARD | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 1.0 | -6.3 | 39.0 | 65.0 |
| SHOT RISK POINTS | 37.7 | -293.8 | 0.0 | 435.0 | 38.7 | +511.0 | 0.0 | 421.3 |
| SHOTS AFTER THE MOVES | 0.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 4.7 | +137.2 | 0.0 | 43.3 | 48.0 | +1004.3 | 0.0 | 260.7 |
| SPELL SETS UP CHARGE | 0.7 | +270.7 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 0.7 | +3.6 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 7.3 | +0.0 | 0.0 | 45.7 | 3.3 | +0.0 | 0.0 | 24.0 |
| STAND AND SHOOT | 0.3 | -2.2 | 20.0 | 0.0 | 1.0 | -2.4 | 21.7 | 65.0 |
| STANDS FOR A REASON | 2.0 | +0.0 | 0.0 | 235.3 | 3.7 | +0.0 | 0.0 | 48.0 |
| STANDS STILL | 18.3 | +0.0 | 237.7 | 477.3 | 90.7 | +0.0 | 1536.7 | 461.3 |
| STAY WORTH | 4.3 | +230.1 | 48.0 | 0.0 | 65.0 | -306.8 | 906.3 | 121.7 |
| STOPS | 0.3 | +3.4 | 40.0 | 28.3 | - | - | - | - |
| STRIKE BY THE ODDS | - | - | - | - | 1.3 | +39.0 | 70.0 | 85.0 |
| SUPPORT ADDS | 4.7 | +301.5 | 0.0 | 28.3 | 2.0 | +87.7 | 0.0 | 40.0 |
| SUPPORT WORKED OUT | 4.7 | +301.5 | 0.0 | 28.3 | 2.0 | +87.7 | 0.0 | 40.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +1.2 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 32.3 | +0.0 | 0.0 | 469.7 | 61.0 | +0.0 | 0.0 | 311.3 |
| TIED UP BY THE SUM | - | - | - | - | 1.3 | +112.0 | 40.0 | 89.0 |
| TIME ON OUR SIDE | 7.7 | +160.1 | 0.0 | 95.0 | 46.7 | +432.0 | 224.7 | 115.0 |
| WAITS AGAIN | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| WEAPON BY POINTS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.3 | +9.2 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 4.0 | -377.6 | 0.0 | 43.3 | 0.7 | -318.3 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | 0.3 | +1.6 | 20.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 7.3 | +863.2 | 0.0 | 0.0 | - | - | - | - |

### Rule changes: gs3-83c8646-p13

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 327 | 316 | 84 | 28.00 | +1140 | +13.6 |
| ARMY TABLE | 109 | 109 | 81 | 27.00 | +392 | +4.8 |
| HIS SHOTS BY HIS RUN | 263 | 257 | 72 | 24.00 | +756 | +10.5 |
| HOLDER ASSIGNMENT | 71 | 71 | 69 | 23.00 | +3567 | +51.7 |
| LEGAL CHARGES ONLY | 55 | 55 | 55 | 18.33 | +0 | +0.0 |
| SHOT RISK POINTS | 229 | 220 | 46 | 15.33 | +883 | +19.2 |
| DEPLOY BY FIGURES | 57 | 57 | 34 | 11.33 | +500 | +14.7 |
| FIVE ACTION | 622 | 611 | 26 | 8.67 | +952 | +36.6 |
| GOAL WALK | 42 | 42 | 25 | 8.33 | +3834 | +153.4 |
| OFF BEST | 24 | 24 | 24 | 8.00 | -706 | -29.4 |
| HARD STAY DROPPED | 22 | 22 | 22 | 7.33 | +0 | +0.0 |
| TIME ON OUR SIDE | 163 | 151 | 20 | 6.67 | +121 | +6.0 |
| THE TABLE AGAIN | 36 | 36 | 19 | 6.33 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 15 | 15 | 15 | 5.00 | +104 | +6.9 |
| WOUNDS ON THE RANKS | 22 | 22 | 13 | 4.33 | +709 | +54.6 |
| CHARGE LOSSES | 92 | 92 | 12 | 4.00 | +297 | +24.7 |
| MEETS IN TIME | 32 | 32 | 12 | 4.00 | +122 | +10.1 |
| CANNON PLANNED TARGET | 40 | 40 | 11 | 3.67 | -9 | -0.8 |
| CHAFF PASSED | 10 | 10 | 10 | 3.33 | -0 | -0.0 |
| LONE WIZARD KEPT IN | 10 | 10 | 10 | 3.33 | +924 | +92.4 |
| SUPPORT ADDS | 20 | 20 | 10 | 3.33 | +369 | +36.9 |
| SUPPORT WORKED OUT | 20 | 20 | 10 | 3.33 | +369 | +36.9 |
| MOVE TO CHARGE COMPUTED | 20 | 17 | 9 | 3.00 | +208 | +23.2 |
| MOVE ORDER | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 19 | 18 | 8 | 2.67 | +208 | +26.0 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| CASTING BLOCK | 14 | 14 | 7 | 2.33 | +93 | +13.3 |
| MODEL FACING | 7 | 7 | 7 | 2.33 | +1117 | +159.6 |
| RESERVE FALL BACK | 7 | 7 | 7 | 2.33 | +190 | +27.2 |
| FOUR ROUNDS | 12 | 12 | 6 | 2.00 | +384 | +64.1 |
| PROMISE BY ITS OWN SUM | 22 | 22 | 6 | 2.00 | -258 | -42.9 |
| SET UP BY THE SET | 15 | 14 | 6 | 2.00 | +187 | +31.2 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| FALLS SHORT | 89 | 67 | 5 | 1.67 | +7 | +1.3 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | +86 | +17.2 |
| MARCH BY THE SUM | 5 | 5 | 5 | 1.67 | +322 | +64.4 |
| MAX FOR POSITIONING | 12 | 11 | 5 | 1.67 | +10 | +2.1 |
| SHOOTERS IN TWO RANKS | 5 | 5 | 5 | 1.67 | +12 | +2.4 |
| SHOOTS FROM THE BEST SPOT | 9 | 9 | 5 | 1.67 | +24 | +4.7 |
| CHARGE NOW FIRST | 9 | 9 | 4 | 1.33 | -56 | -14.1 |
| FEATURE BUFFS | 45 | 45 | 4 | 1.33 | +39 | +9.7 |
| GUN MASK | 6 | 6 | 4 | 1.33 | +264 | +65.9 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| IDLE COST | 41 | 24 | 4 | 1.33 | +38 | +9.5 |
| QUARTER ODDS | 59 | 57 | 4 | 1.33 | +156 | +38.9 |
| RANDOM MOVE BY FIGURES | 6 | 6 | 4 | 1.33 | +56 | +13.9 |
| RESERVE MOVE SPELL | 4 | 4 | 4 | 1.33 | +83 | +20.7 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 158 | 129 | 4 | 1.33 | +129 | +32.2 |
| STRIKE BY THE ODDS | 4 | 4 | 4 | 1.33 | +117 | +29.3 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| COVER ONCE | 40 | 29 | 3 | 1.00 | +153 | +50.8 |
| FIRE IN ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CAST JOB | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 5 | 3 | 2 | 0.67 | +104 | +51.8 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +139 | +69.6 |
| HIS TURN DENIED | 6 | 6 | 2 | 0.67 | +218 | +109.0 |
| HUNT IN PAIRS | 4 | 4 | 2 | 0.67 | +202 | +101.0 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +55 | +27.4 |
| MISSILES IN THE MOVE | 20 | 14 | 2 | 0.67 | +137 | +68.7 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | +6 | +2.9 |
| OVERRUNS AWAY | 3 | 3 | 2 | 0.67 | +43 | +21.7 |
| SEARCH SPOT | 2 | 2 | 2 | 0.67 | +49 | +24.5 |
| STAY WORTH | 208 | 198 | 2 | 0.67 | +221 | +110.3 |
| TIED UP BY THE SUM | 4 | 4 | 2 | 0.67 | +130 | +65.1 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +4 | +3.7 |
| EXACT ROUND | 5 | 5 | 1 | 0.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +297 | +297.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| ONE FIGHT FORMULA | 32 | 22 | 1 | 0.33 | +1 | +1.4 |
| ONE OBJECTIVE FORMULA | 39 | 30 | 1 | 0.33 | +71 | +70.9 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -1 | -0.9 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +182 | +181.8 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +52 | +51.8 |
| RISK BY ARC | 11 | 11 | 1 | 0.33 | +40 | +40.3 |
| SET CREDITED ONCE | 10 | 9 | 1 | 0.33 | +1 | +0.7 |
| SHOTS AFTER THE MOVES | 15 | 15 | 1 | 0.33 | +0 | +0.0 |
| STOPS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +1 | +0.6 |
| THE ROW IN ITS ORDER | 10 | 1 | 1 | 0.33 | +0 | +0.0 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +22 | +21.6 |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 13 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 20 | 20 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 68 | 61 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 14 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 1 | 1 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 8 | 8 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 18 | not checked | - | - | - | - |
| FOOT FIRST | 68 | not checked | - | - | - | - |
| FRIEND SHOOTS FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 3 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 63 | 63 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 45 | 45 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 19 | 18 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 12 | 11 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 11 | 11 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 31 | 30 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 12 | 12 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 163 | 163 | 0 | 0.00 | - | - |
| HONEST WORTH | 9 | 9 | 0 | 0.00 | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| KEPT FROM ITS LAST STOP | 22 | 22 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 3 | 3 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 4 | 4 | 0 | 0.00 | - | - |
| MANOEUVRE | 5 | 5 | 0 | 0.00 | - | - |
| MARCH CHECK | 2 | 2 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 3 | 3 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 23 | 15 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 7 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 5 | trace | - | - | - | - |
| MOVE SPELL SPOT | 7 | not checked | - | - | - | - |
| NEARER NOT NEEDED | 43 | 43 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 11 | 11 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 4 | 4 | 0 | 0.00 | - | - |
| ONE ROUTE | 3 | 3 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 275 | trace | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 2 | not checked | - | - | - | - |
| REAL GROUND | 3 | 3 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 11 | 7 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 6 | 6 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 7 | 7 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 87 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 2 | not checked | - | - | - | - |
| SPELL WORTH | 2 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 32 | 32 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 17 | 16 | 0 | 0.00 | - | - |
| STANDS STILL | 327 | 326 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 6 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 4 | not checked | - | - | - | - |
| THE TABLE BINDS | 280 | not checked | - | - | - | - |
| WAITS AGAIN | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 14 | 14 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p13

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.67 | 4.67 | 30.1 |
| ARMY TABLE | rule | 4.33 | 1.67 | 47.5 |
| HOLDER ASSIGNMENT | rule | 1.33 | 1.00 | 16.0 |
| PROMISE BY ITS OWN SUM | rule | 0.33 | 1.67 | 42.9 |
| CHARGE NOW FIRST | rule | 0.33 | 1.00 | 14.1 |
| CANNON PLANNED TARGET | rule | - | 0.67 | 4.6 |
| SET UP BY THE SET | rule | 0.67 | - | 3.4 |
| JOINT CHARGE NOW | rule | 0.33 | - | 4.9 |
| NO REASON | gate | - | 0.33 | 14.5 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 1.3 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 0.9 |
| RESERVE FALL BACK | rule | - | 0.33 | 5.7 |
| RULE SWITCHED OFF | gate | 0.33 | - | 29.1 |

### Plans: gs3-83c8646-p13

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.7 | 100% | 22 | 60 | 274% |
| Mine | move | 27.3 | 93% | 2631 | 0 | 0% |
| Mine | shoot | 2.7 | 62% | 306 | 138 | 45% |
| Opponent | charge | 3.0 | 44% | 282 | 101 | 36% |
| Opponent | move | 37.0 | 97% | 1219 | 0 | 0% |
| Opponent | shoot | 20.7 | 74% | 440 | 705 | 160% |
| Opponent | support | 0.3 | 100% | 18 | 0 | 0% |

### Packages: hunt the guns, gs3-83c8646-p13

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.3 | 1 | 0 | 100% | 100% | 0% | 2.0 | 134 | 129 | 100% | 77 |
| Opponent | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.3 | 1 | 0 | 100% | 100% | 0% | 2.0 | 134 | 129 | 100% | 77 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: gs3-83c8646-p13

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 2.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p13

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 4 | 0 (4) | 0 | 0 | 62 | 75% | 2.0 | 0 (2) | - | 0 (2) | 0 (3) | 0 (1) |
| Mine | Character | 15 | 12 (15) | 12 | 0 | 27 | 7% | 3.3 | - | 7 (7) | 42 (2) | 18 (6) | 15 (3) |
| Mine | Clean-up | 3 | 38 (3) | 38 | 0 | 67 | 33% | 4.0 | 0 (1) | 58 (2) | - | 38 (3) | - |
| Mine | Fast Hammer | 2 | 71 (2) | 71 | 0 | 100 | 50% | 4.0 | 71 (2) | - | - | 141 (1) | 0 (1) |
| Mine | Hammer | 6 | 52 (6) | 9 | 42 | 37 | 33% | 4.0 | 0 (1) | 67 (3) | 41 (2) | 53 (4) | 50 (2) |
| Mine | Holder | 5 | 24 (5) | 16 | 8 | 0 | 60% | 4.5 | 69 (2) | 0 (2) | 0 (1) | 92 (1) | 10 (4) |
| Mine | Shooter | 2 | 286 (2) | 55 | 231 | 50 | 0% | 1.0 | - | 572 (1) | 0 (1) | 286 (2) | - |
| Mine | Wizard | 3 | 0 (3) | 0 | 0 | 49 | 0% | 2.3 | - | - | - | - | - |
| Opponent | Chaff | 2 | 139 (2) | 0 | 139 | 50 | 0% | 1.0 | 0 (1) | 278 (1) | - | 139 (2) | - |
| Opponent | Character | 8 | 90 (8) | 90 | 0 | 0 | 38% | 2.2 | 276 (1) | 76 (6) | 0 (1) | 81 (4) | 93 (4) |
| Opponent | Clean-up | 6 | 11 (6) | 11 | 0 | 25 | 17% | 2.2 | 0 (1) | 17 (5) | - | 15 (5) | 0 (1) |
| Opponent | Fast Hammer | 4 | 11 (4) | 11 | 0 | 66 | 25% | 3.0 | 0 (1) | 33 (1) | 0 (2) | 14 (3) | 0 (1) |
| Opponent | Hammer | 3 | 52 (3) | 52 | 0 | 0 | 33% | 4.0 | 190 (1) | 172 (1) | 0 (1) | 181 (2) | 0 (1) |
| Opponent | Holder | 1 | 76 (1) | 76 | 0 | 0 | 0% | 3.0 | - | - | 76 (1) | - | 76 (1) |
| Opponent | Shooter | 10 | 115 (10) | 6 | 109 | 0 | 10% | 2.2 | 87 (2) | 118 (8) | - | 157 (8) | 0 (2) |
| Opponent | War machine | 12 | 19 (12) | 19 | 0 | 28 | 0% | 2.2 | 0 (10) | - | 103 (2) | 35 (2) | 15 (10) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (2) | - | - | 0 (2) |

### Charged fights: gs3-83c8646-p13

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 77 | 60 | 0.7 | 1.0 | 90 | 42 | +48 | 0 of 2 | 2 of 2 | - | +48 |
| Opponent | Dwarfen Mountain Holds | 2 | 292 | 131 | 1.5 | 1.3 | 87 | 55 | +32 | 2 of 3 | 1 of 3 | +55 | +21 |
| Opponent | Tomb Kings of Khemri | 1 | 55 | 952 | 3.0 | 1.0 | 317 | 65 | +252 | 2 of 3 | 0 of 2 | - | +252 |
| **Opponent** | all armies | 3 | 213 | 405 | 2.0 | 1.2 | 202 | 60 | +142 | 4 of 6 | 1 of 5 | +55 | +160 |

### Effective charges: gs3-83c8646-p13

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 0 | 0 | 1 (net +60) | 1 (net +35) | 0 | 0 | 0 | 50% (1 of 2) |
| Opponent | Dwarfen Mountain Holds | 3 | 2 (net +22) | 0 | 0 | 1 (net +52) | 0 | 0 | 0 | 0% (0 of 3) |
| Opponent | Tomb Kings of Khemri | 3 | 1 (net +952) | 0 | 0 | 0 | 0 | 1 (net +0) | 1 | 0% (0 of 2) |

### Charged fights, damage counted: gs3-83c8646-p13

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 52 | 60 | +60 | 60 | 52 | +8 | +15.4 |
| Mine | 76-89% | 1 | 85 | 120 | +35 | 120 | 85 | +35 | +41.2 |
| Mine | All fights | 2 | 68 | 90 | +48 | 90 | 68 | +22 | +31.4 |
| Opponent | Long shot (under 50%) | 3 | 190 | 445 | +332 | 579 | 138 | +441 | +231.6 |
| Opponent | 76-89% | 1 | 105 | 52 | +52 | 52 | 0 | +52 | +49.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 72 | 55 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | No odds | 1 | 195 | 836 | -195 | 8 | 195 | -187 | -95.9 |
| Opponent | All fights | 6 | 157 | 380 | +142 | 300 | 102 | +198 | +125.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p13 | move | 18 | 1 (6%) | 1 (6%) | 0 (0%) | 17 (94%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122 |
| Ring of Doom | Mine | L0206 |

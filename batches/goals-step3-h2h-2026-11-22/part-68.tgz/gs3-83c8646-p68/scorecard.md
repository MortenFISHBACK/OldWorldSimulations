# Doctrine scorecard: gs3-83c8646-p68

### Scorecard: gs3-83c8646-p68

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1323 | 3 | 1 | Mine | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 317 |
| L1323 | 3 | 1 | Opponent | no | 3 | 1 | 9 | 2 | 1 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Mine | - | - | 3 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | - | 3 | 0 | 1 | 0 | 0 | 228 |
| L1435 | 1 | 1 | Mine | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 1 | 0 | 4 | 0 | 0 | 0 | 110 |
| **Average** | | | Mine | 0% | 0.0 | 2.3 | 3.3 | 1.0 | 0.0 | 0.0 | 0.0 | 105.7 |
| **Average** | | | Opponent | 0% | 1.5 | 1.0 | 4.0 | 2.0 | 0.7 | 0.0 | 0.0 | 112.7 |

### KPIs: gs3-83c8646-p68

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 16) | 0% (0 of 17) | 0% (0 of 33) |
| Winner chose to follow up after the loser gave ground |  | 75% (3 of 4); on the table 75% | 0% (0 of 1); on the table 0% | 60% (3 of 5); on the table 60% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | 50% (1 of 2); on the table 50% | 67% (2 of 3); on the table 67% |
| Winner chose to pursue after the loser fled |  | 100% (2 of 2); on the table 100% | 0% (0 of 1); on the table 0% | 67% (2 of 3); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 86% (6 of 7); on the table 86% | 25% (1 of 4); on the table 25% | 64% (7 of 11); on the table 64% |
| Magic missiles tried each own turn | 50%+ | 44% (8 of 18) | - | 44% (8 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 50% (8 of 16) | - | 50% (8 of 16) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 24% (1467 of 6000) | 38% (2253 of 6000) | 31% (3720 of 12000) |
|   infantry points that never fought | lower | 38% (354 of 923) | 49% (567 of 1159) | 44% (921 of 2082) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 42% (11 of 26) | 71% (17 of 24) | 56% (28 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.0 uses a game | 100% (2 of 2); 2.7 uses a game | 100% (3 of 3); 1.8 uses a game |
| Bound items with another spell used |  | 43% (6 of 14); 2.7 uses a game | 0.0 uses a game | 43% (6 of 14); 1.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 30% (1731 of 5860) | 61% (3154 of 5131) | 44% (4885 of 10991) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (40%) | - | 1.3 (40%) |
| MARCHED: its unit marched | 1.3 (40%) | - | 1.3 (40%) |
| IN COMBAT: engaged in combat | 0.7 (20%) | - | 0.7 (20%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 5.3 | 2.7 | 5.0 | 2.7 | 2.0 |
| not cast | 2.7 | 7.3 | 3.0 | 3.3 | 26.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 5.7 (77%) | 0.0 (0%) | 1.3 (40%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (40%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.7 (22%) | 0.7 (20%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 1.7 (62%) | 1.7 (23%) | 1.7 (56%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.0 (38%) | 0.0 (0%) | 0.7 (22%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 24.3 (94%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 4.7 a game | 0.3 a game | 2.5 a game |
| stood (cast and not dispelled) | 86% (12 of 14) | 0% (0 of 1) | 80% (12 of 15) |
| the unit moved after it | 42% (5 of 12) | - | 42% (5 of 12) |
| it charged on its next turn | 0% (0 of 12) | - | 0% (0 of 12) |
| the enemy charged it first | 25% (3 of 12) | - | 25% (3 of 12) |
| it fought by the end of its next turn | 8% (1 of 12) | - | 8% (1 of 12) |
| it moved out of a charge the enemy had planned (not charged first) | 8% (1 of 12) | - | 8% (1 of 12) |
| none of these (no charge, no fight, no charge escaped) | 58% (7 of 12) | - | 58% (7 of 12) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 57% (49 of 86) | 57% (58 of 101) | 57% (107 of 187) |
|   cavalry | 58% (14 of 24) | 100% (21 of 21) | 78% (35 of 45) |
|   character | 23% (7 of 30) | 44% (8 of 18) | 31% (15 of 48) |
|   chariot | - | 62% (5 of 8) | 62% (5 of 8) |
|   infantry | 80% (16 of 20) | 39% (17 of 44) | 52% (33 of 64) |
|   monster | - | 70% (7 of 10) | 70% (7 of 10) |
|   war machine | 100% (12 of 12) | - | 100% (12 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.3 (11%) | 1.0 (7%) | 2.3 (9%) |
| CHARGED: it charged | 3.0 (24%) | 2.7 (19%) | 5.7 (21%) |
| FLEEING: it fled or was fleeing | 0.3 (3%) | 0.0 (0%) | 0.3 (1%) |
| IN COMBAT: it fought this turn or the last | 0.3 (3%) | 1.0 (7%) | 1.3 (5%) |
| NO TARGET IN RANGE | 4.0 (32%) | 4.3 (30%) | 8.3 (31%) |
| ONLY IN COMBAT: the only targets were in combat | 1.3 (11%) | 2.0 (14%) | 3.3 (12%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.0 (16%) | 2.0 (14%) | 4.0 (15%) |
| OTHER BAR | 0.0 (0%) | 1.3 (9%) | 1.3 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 19.7 | 1.7 | 92% | 0.6 pts | 12 pts |
| character | 9.3 | 1.3 | 89% | 5.2 pts | 49 pts |
| chariot | 1.7 | 0.7 | 80% | 25.0 pts | 42 pts |
| infantry | 16.3 | 6.0 | 80% | 13.1 pts | 213 pts |
| monster | 2.3 | 0.7 | 71% | 13.2 pts | 31 pts |
| war machine | 4.0 | 1.3 | 75% | 10.1 pts | 40 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.7 | 5.7 | 5.7 |
| Charges that made contact a game | 4.7 | 3.0 | 3.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.67 declared, 0.67 contact (3 units) | - | 0.67 declared, 0.67 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.65 declared, 0.52 contact (23 units) | 0.52 declared, 0.27 contact (33 units) | 0.57 declared, 0.38 contact (56 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 47% (8 of 17) | - | - | 47% (8 of 17) |
| Character in a unit | - | 100% (2 of 2) | - | 100% (2 of 2) |
| Character on its own | - | 33% (1 of 3) | 0% (0 of 8) | 9% (1 of 11) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 80% (8 of 10) | 100% (1 of 1) | - | 82% (9 of 11) |
| Monster | 50% (1 of 2) | 100% (1 of 1) | - | 67% (2 of 3) |
| Monstrous | 100% (2 of 2) | 100% (2 of 2) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 3 | 86% (6 of 7); on the table 86% | 44% (8 of 18) | 24% | 42% (11 of 26) | 100% (1 of 1); 1.0 uses a game | 43% (6 of 14); 2.7 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 0% (0 of 1); on the table 0% | - | 35% | 100% (7 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 33% (1 of 3); on the table 33% | - | 27% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | - | 51% | 67% (8 of 12) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p68, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 33% (1) | 57% (4) | 50% (5) |
| ...free all their last turn and able to turn (per game) | 0.33 | 1.33 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.67 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p68

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.0 | 1.7 |
| Strategy | Charge objectives carried out (made contact) | 73% (11 of 15) | 23% (3 of 13) |
| Strategy | Shoot objectives carried out (shot that target) | 64% (16 of 25) | 79% (19 of 24) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | 0% (0 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 1) | 0% (0 of 3) |
| Strategy | Joined characters whose unit fought | - | 33% (1 of 3) |
| Strategy | Lone characters that fought | 100% (7 of 7) | 75% (3 of 4) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 1.0 | 2.0 |
| Movement | Points that never moved of their own | 105.7 | 112.7 |
| Movement | Fights charged into per game | 4.3 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 10, net +0 | 2 of 6, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 10, net +92 | 2 of 6, net +290 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 4 of 10, net +105 | 0 of 6 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 10, net +84 | 2 of 6, net +88 |
| Shooting | Shots by shooting units (incl. breath weapons) | 14.3 | 21.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 26% (11 of 43) | 71% (46 of 65) |
| Shooting | Points destroyed by shooting units | 33.3 | 0.0 |
| Shooting | War machine shots | 4.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (6 of 12) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 2.3 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 14% (1 of 7) | - |
| Magic | Wounds caused by magic missiles | 2.3 | 0.7 |
| Magic | Wounds caused by other spells | 5.3 | - |
| Magic | Points destroyed by magic (all spells) | 113.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.7 / 0.3 / 1.7 / 0.0 | 3.0 / 1.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 333.0 | 213.7 |
| Combat | Points run down | 13.3 | 0.0 |
| Combat | Net points per charged fight, damage counted | +69 | +126 |
| Combat | Net per 100 charger points, damage counted | +20.3 | +67.6 |
| Combat | First round won (charged fights) | 77% | 11% |
| Combat | Net points per charged fight | +84 | +101 |
| Combat | Net points per supported fight / lone fight | +185 / +75 | - / +101 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 13 | 4 of 9 |
| Game | Points lost | 390.3 | 580.0 |
| Game | VP from objectives | 373.3 | 626.7 |
| Game | Lone holders (player turns) | 0.0 | 1.5 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -268 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 970
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p68

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +60.3 | 0.0 | 0.0 | 0.3 | +2.7 | 0.0 | 61.7 |
| ARMY TABLE | 29.7 | +585.7 | 0.0 | 699.0 | 26.3 | +119.4 | 0.0 | 413.3 |
| ASSAILMENT BY POINTS | 0.3 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | 0.7 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | 0.3 | -11.2 | 13.3 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.7 | +0.1 | 0.0 | 98.0 | - | - | - | - |
| CANNON PLANNED TARGET | 4.0 | +43.7 | 130.0 | 93.3 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.3 | +0.0 | 61.7 | 0.0 | 0.3 | -8.0 | 0.0 | 0.0 |
| CAST JOB | 0.7 | +12.8 | 44.0 | 0.0 | 0.7 | +16.5 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 4.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 0.3 | +3.4 | 0.0 | 11.3 |
| CHAFF PASSED | 0.7 | -0.4 | 130.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +25.3 | 0.0 | 50.3 | 0.3 | +20.5 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | 1.0 | -9.5 | 25.7 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 31.3 | -1408.8 | 0.0 | 483.0 | 13.0 | -699.4 | 0.0 | 370.0 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 61.0 | 0.0 | 2.7 | +0.0 | 139.0 | 65.0 |
| CHARGER SLAIN LOST | 0.7 | -6.5 | 0.0 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 9.0 | +0.0 | 0.0 | 0.0 | 11.0 | +0.0 | 0.0 | 116.0 |
| COMBAT PIVOT | - | - | - | - | 0.7 | +0.0 | 100.7 | 0.0 |
| CONVEYANCE SEARCH | 4.3 | +764.5 | 0.0 | 0.0 | 0.3 | +108.5 | 0.0 | 0.0 |
| COVER ONCE | 10.0 | -474.1 | 0.0 | 202.3 | 7.7 | -718.7 | 0.0 | 201.3 |
| DENIED BY THE FIGHT | 0.7 | -0.8 | 123.3 | 0.0 | 0.7 | -3.8 | 115.7 | 0.0 |
| DEPLOY BY FIGURES | 8.0 | -26.8 | 0.0 | 0.0 | 9.3 | +8.3 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -25.8 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 1.7 | +19.5 | 0.0 | 0.0 |
| EXACT ROUND | 2.7 | +7.3 | 298.0 | 0.0 | 3.0 | +77.0 | 185.7 | 153.3 |
| FALL BACK GOOD ORDER | 3.7 | +19.9 | 180.7 | 0.0 | 4.0 | +28.3 | 185.7 | 130.0 |
| FALLS SHORT | 14.0 | +80.8 | 0.0 | 169.7 | 13.0 | +110.4 | 0.0 | 80.7 |
| FEATURE BUFFS | 2.0 | +21.4 | 0.0 | 0.0 | 2.0 | +27.2 | 0.0 | 26.7 |
| FIGHT TO THE END | 0.7 | +0.1 | 25.7 | 0.0 | 1.0 | +2.4 | 115.7 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 94.0 | +4318.8 | 1015.3 | 1079.0 | 102.0 | +7592.9 | 185.7 | 1617.3 |
| FLANK NOT WEIGHED | 7.0 | +0.0 | 0.0 | 216.3 | 10.0 | +0.0 | 0.0 | 143.0 |
| FOLLOW UP WEIGHED | 1.3 | +29.3 | 0.0 | 0.0 | - | - | - | - |
| FOOT FIRST | 37.3 | +0.0 | 0.0 | 447.7 | - | - | - | - |
| FOUR ROUNDS | 5.0 | +246.6 | 365.7 | 0.0 | 5.0 | +362.9 | 185.7 | 164.7 |
| FREED FROM HIS FIGHT | 4.3 | +0.0 | 0.0 | 339.3 | 6.3 | +0.0 | 0.0 | 148.3 |
| FRIEND CHARGES FIRST | 0.3 | -8.9 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 1.7 | -61.3 | 0.0 | 0.0 | 0.7 | -0.1 | 0.0 | 61.7 |
| GIVES UP | 0.3 | -3.0 | 61.7 | 0.0 | 0.7 | -13.9 | 0.0 | 0.0 |
| GOAL WALK | 8.3 | +778.7 | 0.0 | 100.7 | 6.7 | +410.7 | 0.0 | 0.0 |
| GUN FIGURES | - | - | - | - | 1.3 | +0.0 | 0.0 | 61.7 |
| GUN MASK | 0.3 | -1.5 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 2.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 85.0 |
| HE REFORMS ONCE FREED | 2.7 | +0.0 | 0.0 | 231.3 | 4.3 | +0.0 | 0.0 | 148.3 |
| HIS CHARGE BY HIS RUN | 17.7 | +0.0 | 0.0 | 483.0 | 8.7 | +0.0 | 0.0 | 370.0 |
| HIS CHARGE DENIED | - | - | - | - | 1.0 | +34.4 | 115.7 | 0.0 |
| HIS CHARGE LIST | 12.0 | +0.0 | 0.0 | 648.7 | 4.7 | +0.0 | 0.0 | 13.3 |
| HIS LEGAL MOVES | 7.7 | +0.0 | 0.0 | 196.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 7.7 | -185.9 | 0.0 | 0.0 | 7.7 | -70.7 | 0.0 | 317.3 |
| HIS ONE QUARTER | 5.3 | +0.0 | 0.0 | 208.7 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 13.3 | +0.0 | 0.0 | 475.0 | 6.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 65.3 | +3754.1 | 0.0 | 784.3 | 55.7 | +1605.7 | 0.0 | 995.3 |
| HIS SHOTS BY HIS RUN | 56.7 | +1929.6 | 0.0 | 784.3 | 39.7 | +821.3 | 0.0 | 724.0 |
| HIS TURN DENIED | 2.0 | +189.8 | 262.0 | 0.0 | 1.7 | +28.2 | 70.0 | 65.0 |
| HOLD ODDS | 15.7 | +0.0 | 0.0 | 100.7 | 15.0 | +0.0 | 0.0 | 277.3 |
| HOLDER ASSIGNMENT | 9.0 | +844.2 | 0.0 | 50.3 | 9.0 | +710.8 | 0.0 | 186.7 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.7 | -134.0 | 242.3 | 0.0 | 3.7 | -152.4 | 185.7 | 0.0 |
| IDLE COST | 12.0 | -184.4 | 0.0 | 0.0 | 10.0 | -120.2 | 0.0 | 22.0 |
| JOINT CHARGE NOW | 0.7 | +9.7 | 123.3 | 0.0 | 1.0 | -21.4 | 46.7 | 0.0 |
| KEPT FROM ITS LAST STOP | 3.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 115.3 |
| LANE BY FIGURES | 1.7 | +82.5 | 0.0 | 0.0 | 1.0 | +20.0 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 7.0 | +0.0 | 438.7 | 50.3 | 7.0 | +0.0 | 158.3 | 167.7 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.3 | +37.5 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 2.7 | -1.7 | 224.0 | 0.0 | 1.0 | +0.1 | 0.0 | 23.3 |
| LURE BY WHAT IT DRAWS | 0.3 | -45.8 | 0.0 | 0.0 | 0.3 | -52.7 | 0.0 | 11.3 |
| MAKE SURE TOGETHER | - | - | - | - | 1.3 | +21.7 | 0.0 | 22.0 |
| MANOEUVRE | 1.0 | +0.0 | 0.0 | 0.0 | 2.7 | -11.9 | 0.0 | 137.3 |
| MARCH OF THE TABLE | 0.3 | +8.0 | 0.0 | 54.0 | - | - | - | - |
| MARCH OVER CASTS | 2.7 | +366.1 | 0.0 | 54.0 | - | - | - | - |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.7 | +21.0 | 0.0 | 54.0 | 1.0 | +13.9 | 0.0 | 22.0 |
| MEETS IN TIME | 3.3 | +208.6 | 0.0 | 0.0 | 6.0 | +79.8 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.7 | +26.4 | 0.0 | 54.0 | 3.7 | +98.8 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 6.3 | +56.2 | 0.0 | 108.0 | 3.3 | +77.0 | 0.0 | 0.0 |
| MOVE ORDER | 3.7 | +0.0 | 54.0 | 50.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 4.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 10.0 | +638.7 | 0.0 | 279.0 | 5.7 | +370.6 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.7 | +210.2 | 0.0 | 0.0 | 9.7 | +401.0 | 0.0 | 89.0 |
| NEAREST TO GOAL | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 6.3 | +368.8 | 0.0 | 47.7 | 4.0 | +262.0 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -0.0 | 0.0 | 50.3 | 0.3 | -10.0 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 5.0 | -120.6 | 365.7 | 0.0 | 4.7 | -288.3 | 185.7 | 164.7 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 1.0 | -1.8 | 0.0 | 0.0 |
| OFF BEST | 4.7 | -98.3 | 0.0 | 151.0 | 3.0 | -92.4 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 6.3 | -119.0 | 0.0 | 0.0 | 6.0 | -99.5 | 0.0 | 123.3 |
| ONE JOINT FIGURE | 0.7 | -27.6 | 123.3 | 0.0 | 0.3 | +19.0 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 4.3 | -101.2 | 0.0 | 50.3 | 4.0 | -20.2 | 0.0 | 71.3 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +12.1 | 38.0 | 0.0 | 1.0 | +21.6 | 70.0 | 0.0 |
| OVERRUNS AWAY | 1.7 | +12.0 | 129.3 | 0.0 | 1.0 | +1.6 | 0.0 | 11.3 |
| PATHS CROSS | 0.7 | +33.1 | 0.0 | 0.0 | 0.3 | +8.1 | 0.0 | 22.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -39.5 | 0.0 | 0.0 |
| PLAN RESULT | 42.7 | +365.7 | 336.7 | 788.3 | 48.0 | +550.6 | 198.0 | 1003.0 |
| PROMISE BY ITS OWN SUM | 11.3 | -158.2 | 0.0 | 0.0 | 7.3 | -138.1 | 0.0 | 0.0 |
| PROMISE IN STEPS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 0.7 | -1.3 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 0.3 | -3.3 | 0.0 | 0.0 | 0.3 | -0.1 | 0.0 | 0.0 |
| QUARTER ODDS | 13.7 | +1042.2 | 58.0 | 309.3 | 19.0 | +2237.1 | 70.0 | 286.7 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 2.3 | +39.4 | 0.0 | 82.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 2.0 | +0.0 | 0.0 | 80.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.7 | +6.3 | 73.7 | 0.0 |
| REFORMS TO MEET IT | 3.7 | -68.7 | 0.0 | 231.3 | 2.7 | -108.7 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.7 | +28.2 | 0.0 | 0.0 |
| RISK BY ARC | 3.3 | +40.7 | 229.0 | 0.0 | 3.0 | -4.8 | 115.7 | 76.3 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 1.3 | -48.3 | 99.7 | 0.0 | 3.0 | -43.7 | 185.7 | 130.0 |
| RUN DOWN | 3.7 | -25.8 | 285.7 | 0.0 | 3.7 | -7.5 | 115.7 | 141.3 |
| SCOUT SPOT | - | - | - | - | 1.3 | -0.1 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.0 | -40.3 | 0.0 | 11.3 |
| SEARCH SPOT | 0.3 | +54.8 | 0.0 | 0.0 | 1.3 | +101.0 | 0.0 | 38.0 |
| SECOND LOOK | - | - | - | - | 0.7 | +42.2 | 0.0 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 1.0 | -23.4 | 0.0 | 61.7 |
| SET UP BY THE SET | 2.7 | -33.6 | 0.0 | 0.0 | 2.0 | +7.6 | 0.0 | 73.0 |
| SET UP TOGETHER | - | - | - | - | 1.3 | +21.7 | 0.0 | 22.0 |
| SET-UP ANY TARGET | 2.0 | +180.7 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +2.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 7.7 | +0.0 | 0.0 | 93.3 | 8.0 | +0.0 | 0.0 | 116.0 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +109.5 | 156.0 | 0.0 | 3.3 | +370.5 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.7 | -3.9 | 75.0 | 0.0 | 0.3 | -9.2 | 0.0 | 23.3 |
| SHOT RISK POINTS | 47.0 | -771.1 | 0.0 | 676.3 | 21.3 | -68.1 | 0.0 | 485.3 |
| SHOTS AFTER THE MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.0 | +465.5 | 0.0 | 263.0 | 21.0 | +1401.8 | 0.0 | 473.0 |
| SPELL SETS UP CHARGE | 2.0 | +180.7 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 2.0 | +55.0 | 0.0 | 0.0 | 1.3 | +17.1 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 1.3 | +3.4 | 185.0 | 0.0 | 1.0 | -15.8 | 0.0 | 141.3 |
| SPOT AS THE GAME MOVES | 11.3 | +0.0 | 0.0 | 267.7 | 7.0 | +0.0 | 0.0 | 193.0 |
| STAND AND SHOOT | 1.0 | -2.8 | 85.7 | 0.0 | 2.0 | -15.7 | 70.0 | 11.3 |
| STANDS FOR A REASON | 4.0 | +0.0 | 101.7 | 0.0 | 1.0 | +0.0 | 0.0 | 22.0 |
| STANDS STILL | 31.0 | +0.0 | 649.7 | 294.7 | 40.3 | +0.0 | 0.0 | 741.3 |
| STAY WORTH | 24.3 | +91.7 | 189.7 | 194.0 | 22.3 | +399.4 | 0.0 | 507.7 |
| STRIKE BY THE ODDS | 0.3 | +26.8 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 3.3 | +337.7 | 0.0 | 100.7 | 1.3 | +67.8 | 0.0 | 90.0 |
| SUPPORT NARROWED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 3.3 | +337.7 | 0.0 | 100.7 | 1.3 | +67.8 | 0.0 | 90.0 |
| SURE REACH TOGETHER | 0.3 | +0.3 | 0.0 | 0.0 | 0.3 | +2.7 | 0.0 | 22.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.3 | +0.0 | 0.0 | 50.3 | 1.7 | +0.0 | 0.0 | 22.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -15.4 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.3 | +0.0 | 0.0 | 50.3 | 3.3 | +0.0 | 0.0 | 43.3 |
| THE ROW KEEPS ITS WAY | 3.0 | +0.0 | 0.0 | 47.7 | 5.0 | +0.0 | 0.0 | 100.7 |
| THE STEP BACK IS MADE | 1.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 61.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 44.0 | +0.0 | 0.0 | 515.7 | 47.3 | +0.0 | 0.0 | 680.3 |
| TIED UP BY THE SUM | 2.0 | +195.2 | 122.7 | 0.0 | 1.3 | +186.9 | 23.3 | 0.0 |
| TIME ON OUR SIDE | 23.3 | +287.3 | 44.0 | 193.3 | 32.3 | +330.7 | 0.0 | 629.0 |
| TWO OR MORE ARRIVE | - | - | - | - | 1.0 | +0.6 | 0.0 | 22.0 |
| WAITS AGAIN | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | 0.7 | +14.1 | 61.7 | 0.0 | 0.3 | -3.1 | 0.0 | 11.3 |
| WHO HITS BACK | 1.3 | +115.1 | 0.0 | 115.7 | 0.3 | +44.6 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 0.7 | -50.9 | 0.0 | 0.0 | 2.7 | -396.5 | 0.0 | 246.7 |
| WHOLE FIGHT GAIN | 0.3 | +8.2 | 61.7 | 0.0 | 0.3 | +29.7 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p68

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 168 | 168 | 129 | 43.00 | +2108 | +16.3 |
| HIS SHOT LIST | 363 | 349 | 97 | 32.33 | +3001 | +30.9 |
| HIS SHOTS BY HIS RUN | 289 | 275 | 59 | 19.67 | +945 | +16.0 |
| HOLDER ASSIGNMENT | 54 | 54 | 50 | 16.67 | +3233 | +64.7 |
| LEGAL CHARGES ONLY | 42 | 42 | 42 | 14.00 | +0 | +0.0 |
| SHOT RISK POINTS | 205 | 200 | 42 | 14.00 | +1636 | +38.9 |
| DEPLOY BY FIGURES | 52 | 52 | 32 | 10.67 | +353 | +11.0 |
| MOVE TO CHARGE COMPUTED | 47 | 42 | 27 | 9.00 | +972 | +36.0 |
| OFF BEST | 23 | 23 | 23 | 7.67 | -572 | -24.9 |
| THE TABLE AGAIN | 36 | 36 | 22 | 7.33 | +0 | +0.0 |
| HARD STAY DROPPED | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| CHARGE LOSSES | 133 | 128 | 19 | 6.33 | +1992 | +104.9 |
| FIVE ACTION | 588 | 569 | 19 | 6.33 | +636 | +33.5 |
| NEXT CHARGE BY LIST | 31 | 30 | 18 | 6.00 | +490 | +27.2 |
| PROMISE BY ITS OWN SUM | 56 | 56 | 16 | 5.33 | -889 | -55.6 |
| GOAL WALK | 45 | 44 | 15 | 5.00 | +824 | +54.9 |
| MOVE ORDER | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| QUARTER ODDS | 98 | 96 | 14 | 4.67 | +748 | +53.4 |
| TIME ON OUR SIDE | 167 | 145 | 14 | 4.67 | +88 | +6.3 |
| FOUR ROUNDS | 30 | 28 | 13 | 4.33 | +687 | +52.9 |
| MEETS IN TIME | 28 | 28 | 13 | 4.33 | +486 | +37.4 |
| ADVANCE LANE KEPT | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| COVER ONCE | 53 | 32 | 9 | 3.00 | +302 | +33.5 |
| TIED UP BY THE SUM | 10 | 10 | 9 | 3.00 | +381 | +42.3 |
| LANE BY FIGURES | 8 | 8 | 8 | 2.67 | +308 | +38.5 |
| SHOOTS FROM THE BEST SPOT | 12 | 12 | 8 | 2.67 | +333 | +41.6 |
| SHOTS IN THE MOVE | 111 | 92 | 8 | 2.67 | +417 | +52.2 |
| STAY WORTH | 140 | 133 | 8 | 2.67 | +142 | +17.7 |
| CHARGE NOW FIRST | 15 | 15 | 6 | 2.00 | -421 | -70.2 |
| REDIRECT FOR A FRIEND IN REACH | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| IDLE COST | 66 | 49 | 5 | 1.67 | +22 | +4.4 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | -35 | -7.0 |
| SCOUT WAITS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| SEARCH SPOT | 5 | 5 | 5 | 1.67 | +467 | +93.4 |
| SUPPORT ADDS | 14 | 14 | 5 | 1.67 | +118 | +23.6 |
| SUPPORT WORKED OUT | 14 | 14 | 5 | 1.67 | +118 | +23.6 |
| WHO HITS BACK | 5 | 5 | 5 | 1.67 | +212 | +42.5 |
| CAST JOB | 4 | 4 | 4 | 1.33 | +22 | +5.6 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +88 | +22.0 |
| RISK BY ARC | 19 | 18 | 4 | 1.33 | +82 | +20.4 |
| SET UP BY THE SET | 14 | 14 | 4 | 1.33 | +344 | +85.9 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FALLS SHORT | 81 | 70 | 3 | 1.00 | +9 | +3.0 |
| HIS TURN DENIED | 11 | 11 | 3 | 1.00 | +131 | +43.7 |
| HONEST WORTH | 22 | 20 | 3 | 1.00 | +43 | +14.3 |
| NEARER NOT NEEDED | 46 | 45 | 3 | 1.00 | +83 | +27.7 |
| NO DOUBLE ROUNDS | 29 | 28 | 3 | 1.00 | +43 | +14.3 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +124 | +41.2 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +189 | +94.5 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.67 | +0 | +0.1 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | -1 | -0.6 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +137 | +68.7 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MISSILES IN THE MOVE | 19 | 14 | 2 | 0.67 | +17 | +8.7 |
| ONE OBJECTIVE FORMULA | 25 | 19 | 2 | 0.67 | +98 | +49.0 |
| OPENS UP | 4 | 4 | 2 | 0.67 | +24 | +11.9 |
| PROMISE KNOWS THE FIGHT | 2 | 2 | 2 | 0.67 | -4 | -2.0 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +19 | +9.5 |
| REFUSING RETIRES | 3 | 3 | 2 | 0.67 | -12 | -6.0 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +85 | +42.3 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +127 | +63.3 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +6 | +3.0 |
| SURE REACH TOGETHER | 2 | 2 | 2 | 0.67 | +0 | +0.2 |
| WHOLE FIGHT DANGER | 10 | 10 | 2 | 0.67 | +17 | +8.7 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +3 | +2.9 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -34 | -33.7 |
| CANNON PLANNED TARGET | 12 | 12 | 1 | 0.33 | +0 | +0.0 |
| CARRIES OUT SET-UP | 2 | 2 | 1 | 0.33 | -24 | -24.0 |
| CHAFF IN THE MOVE | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EVASIVE BY THE ODDS | 5 | 5 | 1 | 0.33 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 23 | 21 | 1 | 0.33 | +6 | +5.8 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS CHARGE DENIED | 3 | 2 | 1 | 0.33 | +6 | +6.4 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +112 | +112.5 |
| MANOEUVRE | 11 | 11 | 1 | 0.33 | +5 | +4.6 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -24 | -24.0 |
| MAX FOR POSITIONING | 8 | 7 | 1 | 0.33 | +0 | +0.0 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -118 | -118.4 |
| ROUNDS AFTER TERROR | 13 | 12 | 1 | 0.33 | +10 | +9.9 |
| SHOTS AFTER THE MOVES | 24 | 24 | 1 | 0.33 | +0 | +0.0 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +70 | +70.3 |
| SUPPORT NARROWED | 2 | 2 | 1 | 0.33 | -1 | -1.3 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| BACKUP TARGETS | 2 | not checked | - | - | - | - |
| CASTS AFTER FRIENDS | 12 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 3 | 3 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 2 | 2 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 60 | 60 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 14 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | not checked | - | - | - | - |
| EXACT ROUND | 17 | 16 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 12 | 12 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 5 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 51 | not checked | - | - | - | - |
| FOOT FIRST | 112 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 32 | 32 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 7 | 6 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 4 | not checked | - | - | - | - |
| GUN MASK | 1 | 1 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 21 | 21 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 79 | 77 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 50 | 45 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 34 | 32 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 46 | 46 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 26 | 24 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 59 | 54 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 92 | 91 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 21 | 21 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 11 | 10 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 4 | not checked | - | - | - | - |
| MARCH OVER CASTS | 8 | 8 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 29 | 24 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 12 | not checked | - | - | - | - |
| NEAREST TO GOAL | 1 | 1 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 3 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 37 | 18 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 3 | 2 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 8 | 8 | 0 | 0.00 | - | - |
| PLAN RESULT | 272 | trace | - | - | - | - |
| PROMISE IN STEPS | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 7 | 6 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 19 | 18 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 22 | 20 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 4 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 6 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 47 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 6 | not checked | - | - | - | - |
| SPELL WORTH | 10 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 7 | 7 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 55 | 52 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 9 | 9 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 15 | 15 | 0 | 0.00 | - | - |
| STANDS STILL | 214 | 205 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 12 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 17 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 24 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 15 | not checked | - | - | - | - |
| THE TABLE BINDS | 274 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 3 | not checked | - | - | - | - |
| WAITS AGAIN | 6 | 5 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 1 | 1 | 0 | 0.00 | - | - |
| WHO FIGHTS | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 2 | 1 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p68

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| ARMY TABLE | rule | 3.33 | 3.67 | 55.3 |
| JOB FIRST | gate | 4.00 | 2.67 | 22.9 |
| PROMISE BY ITS OWN SUM | rule | 3.33 | 2.00 | 55.6 |
| CHARGE NOW FIRST | rule | 1.00 | 1.00 | 70.2 |
| HOLDER ASSIGNMENT | rule | 0.67 | 0.67 | 21.4 |
| CHAFF PASSED | rule | 0.67 | - | 0.6 |
| DEPLOY BY FIGURES | rule | - | 0.67 | 6.2 |
| JOINT CHARGE NOW | rule | - | 0.67 | 53.9 |
| NO REASON | gate | 0.67 | - | 18.8 |
| PROMISE KNOWS THE FIGHT | rule | 0.67 | - | 2.0 |
| REFUSING RETIRES | rule | 0.67 | - | 6.0 |
| BEST PRIZE | rule | 0.33 | - | 33.7 |
| CARRIES OUT SET-UP | rule | - | 0.33 | 24.0 |
| MARCH OF THE TABLE | rule | 0.33 | - | 24.0 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 118.4 |
| RULE SWITCHED OFF | gate | - | 0.33 | 76.2 |
| SUPPORT NARROWED | rule | 0.33 | - | 1.3 |

### Plans: gs3-83c8646-p68

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.0 | 44% | 524 | 152 | 29% |
| Mine | move | 32.3 | 98% | 1623 | 0 | 0% |
| Mine | shoot | 7.0 | 57% | 180 | 214 | 119% |
| Mine | support | 0.3 | 100% | 0 | 0 | - |
| Opponent | charge | 4.0 | 25% | 586 | 171 | 29% |
| Opponent | move | 36.3 | 94% | 1726 | 0 | 0% |
| Opponent | shoot | 6.7 | 40% | 1077 | 379 | 35% |
| Opponent | support | 1.0 | 67% | 0 | 0 | - |

### Battle groups: gs3-83c8646-p68

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 2.3 | 43% | 33% | 33% | 0% | 0% | 0% | 0% | 50% | 50% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p68

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 7 | 50 (7) | 50 | 0 | 12 | 0% | 2.7 | 38 (5) | 112 (1) | 37 (1) | 34 (5) | 82 (2) |
| Mine | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 14 | 26 (14) | 9 | 16 | 23 | 29% | 3.4 | 31 (8) | 19 (6) | - | 37 (9) | 6 (5) |
| Mine | Shooter | 4 | 10 (4) | 10 | 0 | 49 | 0% | 1.0 | 13 (3) | 0 (1) | - | 13 (3) | 0 (1) |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 100 | 0% | 1.0 | 0 (2) | - | - | - | 0 (2) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 7 | 28 (7) | 0 | 28 | 100 | 14% | 2.2 | - | 57 (4) | 0 (3) | 68 (4) | 0 (3) |
| Opponent | Character | 4 | 37 (4) | 37 | 0 | 0 | 0% | 1.8 | - | 37 (4) | - | 20 (2) | 51 (2) |
| Opponent | Clean-up | 4 | 0 (4) | 0 | 0 | 20 | 75% | 5.0 | 0 (1) | 0 (2) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | Fast Hammer | 4 | 80 (4) | 76 | 4 | 29 | 0% | 1.8 | 153 (2) | 0 (2) | - | 113 (3) | 0 (1) |
| Opponent | Hammer | 8 | 0 (8) | 0 | 0 | 40 | 25% | 3.0 | 0 (2) | 0 (3) | 0 (3) | 0 (4) | 0 (4) |
| Opponent | Holder | 3 | 156 (3) | 0 | 156 | 31 | 0% | 3.0 | 250 (1) | 0 (1) | 250 (1) | 250 (1) | 114 (2) |
| Opponent | Shooter | 4 | 55 (4) | 0 | 55 | 66 | 25% | 1.0 | 0 (1) | 118 (2) | 0 (1) | 107 (2) | 18 (2) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 0% | 1.3 | 0 (2) | 0 (1) | - | 0 (1) | 0 (2) |

### Charged fights: gs3-83c8646-p68

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 3 | 146 | 410 | 4.3 | 1.1 | 95 | 11 | +84 | 3 of 13 | 10 of 13 | +185 | +75 |
| Opponent | Ogre Kingdoms | 1 | 0 | 0 | 3.0 | 1.0 | 0 | 0 | +0 | 1 of 3 | 0 of 3 | - | +0 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 977 | 6.0 | 1.0 | 163 | 12 | +151 | 3 of 6 | 1 of 6 | - | +151 |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 0 | 326 | 3.0 | 1.0 | 109 | 8 | +101 | 4 of 9 | 1 of 9 | - | +101 |

### Effective charges: gs3-83c8646-p68

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 13 | 1 (net +0) | 0 | 2 (net +92) | 1 (net +0) | 4 (net +105) | 2 (net +84) | 3 | 20% (2 of 10) |
| Opponent | Ogre Kingdoms | 3 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 2 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 6 | 1 (net +0) | 0 | 2 (net +290) | 0 | 0 | 2 (net +88) | 1 | 40% (2 of 5) |

### Charged fights, damage counted: gs3-83c8646-p68

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 151 | 185 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 2 | 397 | 155 | +92 | 92 | 48 | +45 | +11.3 |
| Mine | 76-89% | 1 | 489 | 297 | +0 | 50 | 54 | -5 | -1.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 316 | 187 | +84 | 84 | 0 | +84 | +26.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 305 | 70 | +105 | 105 | 0 | +105 | +34.4 |
| Mine | No odds | 3 | 377 | 216 | +105 | 185 | 110 | +75 | +19.8 |
| Mine | All fights | 13 | 340 | 161 | +84 | 106 | 37 | +69 | +20.3 |
| Opponent | Long shot (under 50%) | 2 | 52 | 232 | +0 | 35 | 44 | -8 | -16.3 |
| Opponent | Effective (55-75%) | 2 | 313 | 238 | +290 | 290 | 0 | +290 | +92.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 195 | 288 | +88 | 88 | 0 | +88 | +45.4 |
| Opponent | No odds | 3 | 185 | 281 | +50 | 145 | 14 | +131 | +71.0 |
| Opponent | All fights | 9 | 186 | 262 | +101 | 140 | 14 | +126 | +67.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p68 | move | 25 | 8 (32%) | 5 (20%) | 2 (8%) | 15 (60%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Fistful of Laurels | Opponent | L1418 |
| Opal Amulet | Mine | L1418, L1435 |
| Standard of the Fell Warrior | Mine | L1323 |

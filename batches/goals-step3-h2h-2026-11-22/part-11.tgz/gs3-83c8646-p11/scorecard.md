# Doctrine scorecard: gs3-83c8646-p11

### Scorecard: gs3-83c8646-p11

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2127 | 3 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 555 |
| L2127 | 3 | 1 | Opponent | no | 6 | 5 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 3 | 6 | 1 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | yes | - | - | 1 | 2 | 0 | 0 | 0 | 170 |
| L2335 | 1 | 1 | Mine | no | 6 | 3 | 7 | 2 | 1 | 0 | 0 | 0 |
| L2335 | 1 | 1 | Opponent | no | 0 | 4 | 2 | 2 | 0 | 0 | 0 | 110 |
| **Average** | | | Mine | 33% | 3.0 | 3.0 | 4.3 | 1.7 | 0.3 | 0.0 | 0.0 | 185.0 |
| **Average** | | | Opponent | 33% | 3.0 | 4.5 | 2.0 | 2.3 | 0.0 | 0.0 | 0.0 | 93.3 |

### KPIs: gs3-83c8646-p11

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 7% (1 of 14) | 0% (0 of 15) | 3% (1 of 29) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 100% (6 of 6); on the table 100% | 100% (7 of 7); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 25% (1 of 4); on the table 25% | 100% (1 of 1); on the table 100% | 40% (2 of 5); on the table 40% |
| Winner chose to follow up or pursue (all three) |  | 50% (3 of 6); on the table 50% | 100% (7 of 7); on the table 100% | 77% (10 of 13); on the table 77% |
| Magic missiles tried each own turn | 50%+ | 33% (2 of 6) | 28% (5 of 18) | 29% (7 of 24) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 40% (2 of 5) | 33% (5 of 15) | 35% (7 of 20) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 64% (7 of 11) | 55% (6 of 11) | 59% (13 of 22) |
| Points that never fought | lower | 46% (2739 of 5999) | 36% (2146 of 6000) | 41% (4885 of 11999) |
|   infantry points that never fought | lower | 96% (1497 of 1552) | 29% (299 of 1035) | 69% (1796 of 2587) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 58% (11 of 19) | 67% (20 of 30) | 63% (31 of 49) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.7 uses a game | 50% (1 of 2); 1.0 uses a game | 67% (2 of 3); 1.3 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 52% (2342 of 4484) | 52% (2891 of 5546) | 52% (5233 of 10030) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (25%) | 2.7 (62%) | 3.0 (53%) |
| MARCHED: its unit marched | 0.7 (50%) | 0.3 (8%) | 1.0 (18%) |
| GONE: slain | 0.3 (25%) | 1.0 (23%) | 1.3 (24%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.3 (8%) | 0.3 (6%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 11.0 | 0.7 | 0.0 | 2.3 | 1.3 | 0.3 |
| not cast | 3.0 | 1.3 | 2.0 | 5.7 | 0.7 | 15.7 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (25%) | 0.7 (33%) | 3.0 (53%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (18%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.3 (11%) | 1.0 (75%) | 1.0 (50%) | 1.3 (24%) | 0.0 (0%) | 2.7 (17%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (6%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (100%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.7 (89%) | 0.0 (0%) | 0.3 (17%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.0 (83%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 73% (79 of 108) | 79% (26 of 33) | 74% (105 of 141) |
|   cavalry | 100% (14 of 14) | 82% (14 of 17) | 90% (28 of 31) |
|   character | 0% (0 of 20) | 80% (4 of 5) | 16% (4 of 25) |
|   chariot | 85% (11 of 13) | - | 85% (11 of 13) |
|   infantry | 89% (54 of 61) | 73% (8 of 11) | 86% (62 of 72) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.3 (3%) | 1.0 (43%) | 1.3 (11%) |
| CHARGED: it charged | 4.0 (41%) | 0.7 (29%) | 4.7 (39%) |
| IN COMBAT: it fought this turn or the last | 0.3 (3%) | 0.7 (29%) | 1.0 (8%) |
| NO TARGET IN RANGE | 4.0 (41%) | 0.0 (0%) | 4.0 (33%) |
| ONLY IN COMBAT: the only targets were in combat | 1.0 (10%) | 0.0 (0%) | 1.0 (8%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 14.0 | 0.7 | 95% | 1.9 pts | 27 pts |
| character | 1.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 3.7 | 1.0 | 73% | 5.7 pts | 21 pts |
| infantry | 23.7 | 6.7 | 85% | 6.5 pts | 154 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 6.0 | 2.3 | 4.2 |
| Charges that made contact a game | 3.0 | 2.0 | 2.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.50 declared, 0.50 contact (2 units) | 0.50 declared, 0.50 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.56 declared, 0.28 contact (32 units) | 0.27 declared, 0.23 contact (22 units) | 0.44 declared, 0.26 contact (54 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 100% (7 of 7) | 0% (0 of 1) | 0% (0 of 1) | 78% (7 of 9) |
| Character in a unit | 57% (4 of 7) | - | 0% (0 of 1) | 50% (4 of 8) |
| Character on its own | 100% (1 of 1) | 100% (1 of 1) | 29% (2 of 7) | 44% (4 of 9) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 82% (9 of 11) | 100% (1 of 1) | - | 83% (10 of 12) |
| Monster | 33% (2 of 6) | 100% (1 of 1) | - | 43% (3 of 7) |
| Monstrous | 100% (2 of 2) | - | - | 100% (2 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Skaven | 1 | 100% (1 of 1); on the table 100% | 33% (2 of 6) | 63% | 78% (7 of 9) | 100% (1 of 1); 5.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 2 | 40% (2 of 5); on the table 40% | - | 37% | 40% (4 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (7 of 7); on the table 100% | 33% (2 of 6) | 59% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | - | 17% (1 of 6) | 20% | 50% (6 of 12) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | 33% (2 of 6) | 28% | 83% (10 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p11, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 17% (1) | 75% (3) | 40% (4) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.67 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.67 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.33 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p11

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.0 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 40% (6 of 15) | 25% (1 of 4) |
| Strategy | Shoot objectives carried out (shot that target) | 58% (11 of 19) | 40% (4 of 10) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 100% (2 of 2) |
| Strategy | Joined characters whose unit fought | 0% (0 of 5) | 57% (4 of 7) |
| Strategy | Lone characters that fought | 100% (5 of 5) | 67% (4 of 6) |
| Movement | Charges halted short of contact | 2.0 | 0.0 |
| Movement | Idle units | 1.7 | 2.3 |
| Movement | Points that never moved of their own | 185.0 | 93.3 |
| Movement | Fights charged into per game | 3.0 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 8 | 1 of 3, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 8 | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 8, net +62 | 0 of 3 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 of 8, net +170 | 2 of 3, net +368 |
| Shooting | Shots by shooting units (incl. breath weapons) | 28.0 | 9.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 18% (15 of 84) | 69% (20 of 29) |
| Shooting | Points destroyed by shooting units | 62.0 | 70.3 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.7 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 2) | 25% (1 of 4) |
| Magic | Wounds caused by magic missiles | 4.0 | 2.7 |
| Magic | Wounds caused by other spells | - | 0.3 |
| Magic | Points destroyed by magic (all spells) | 31.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 5.7 / 0.0 / 0.0 / 0.0 | 2.0 / 0.7 / 0.3 / 1.0 |
| Combat | Points destroyed in combat | 236.3 | 417.0 |
| Combat | Points run down | 40.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +105 | +106 |
| Combat | Net per 100 charger points, damage counted | +37.5 | +46.4 |
| Combat | First round won (charged fights) | 78% | 50% |
| Combat | Net points per charged fight | +101 | +112 |
| Combat | Net points per supported fight / lone fight | - / +101 | - / +112 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 9 | 5 of 6 |
| Game | Points lost | 437.3 | 539.0 |
| Game | VP from objectives | 753.3 | 710.0 |
| Game | Lone holders (player turns) | 3.0 | 3.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +98 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 976
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: gs3-83c8646-p11

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | 0.3 | +32.7 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 40.3 | +699.0 | 0.0 | 327.7 | 25.7 | +83.6 | 0.0 | 422.7 |
| BACKUP TARGETS | 0.7 | +3.9 | 0.0 | 0.0 | 0.3 | +1.7 | 0.0 | 0.0 |
| BEST PRIZE | 0.3 | -9.6 | 41.7 | 0.0 | - | - | - | - |
| CAST JOB | 0.7 | +9.3 | 0.0 | 0.0 | 3.3 | +12.8 | 384.0 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 1.0 | +26.6 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 1.0 | +25.4 | 0.0 | 83.3 |
| CHARACTER GUNS | 4.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 17.0 | -602.9 | 0.0 | 670.0 | 29.3 | -1264.7 | 0.0 | 321.3 |
| CHARGE NOW FIRST | 3.7 | +0.0 | 184.0 | 65.0 | 1.0 | +0.0 | 245.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 14.7 | +0.0 | 0.0 | 360.0 | 9.7 | +0.0 | 0.0 | 198.0 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| COVER ONCE | 11.0 | -564.4 | 0.0 | 245.0 | 9.0 | -441.2 | 0.0 | 78.3 |
| DENIED BY THE FIGHT | 0.3 | -1.5 | 36.7 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.0 | +21.9 | 0.0 | 48.3 | 7.7 | +21.5 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 1.0 | +1.2 | 76.0 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | - | - | - | - | 4.0 | +310.3 | 22.0 | 0.0 |
| EXACT ROUND | 4.0 | +168.6 | 179.3 | 65.0 | 1.3 | -15.9 | 18.3 | 0.0 |
| FACES THE THREAT | - | - | - | - | 0.3 | +38.9 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 4.0 | +37.0 | 177.7 | 65.0 | 1.3 | +0.0 | 245.0 | 0.0 |
| FALLS SHORT | 7.0 | +57.8 | 0.0 | 44.0 | 20.7 | +209.7 | 0.0 | 176.7 |
| FEATURE BUFFS | 0.3 | +0.5 | 0.0 | 0.0 | 1.3 | +55.3 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.3 | +4.6 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 110.3 | +8642.5 | 470.3 | 1460.3 | 87.3 | +4449.7 | 647.3 | 815.3 |
| FLANK NOT WEIGHED | 8.7 | +0.0 | 0.0 | 465.7 | 9.3 | +0.0 | 0.0 | 100.0 |
| FOCUS FIRE | 0.3 | +31.7 | 0.0 | 0.0 | 0.7 | +16.6 | 44.0 | 36.7 |
| FOLLOW UP WEIGHED | 0.7 | +55.5 | 0.0 | 0.0 | 1.3 | +105.9 | 0.0 | 0.0 |
| FOOT FIRST | - | - | - | - | 25.0 | +0.0 | 0.0 | 274.0 |
| FOUR ROUNDS | 6.0 | +476.6 | 310.3 | 130.0 | 2.0 | +155.4 | 263.3 | 0.0 |
| FREED FROM HIS FIGHT | 5.7 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 120.3 |
| GOAL WALK | 15.7 | +1673.6 | 0.0 | 0.0 | 5.3 | +297.5 | 0.0 | 0.0 |
| GUN FIGURES | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 3.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 62.0 |
| HE REFORMS ONCE FREED | 2.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 120.3 |
| HIS CHARGE BY HIS RUN | 7.7 | +0.0 | 0.0 | 670.0 | 19.7 | +0.0 | 0.0 | 264.7 |
| HIS CHARGE LIST | 5.7 | +0.0 | 0.0 | 22.0 | 9.0 | +0.0 | 0.0 | 169.3 |
| HIS LEGAL MOVES | 6.0 | +0.0 | 0.0 | 245.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.0 | -34.4 | 0.0 | 0.0 | 6.0 | -70.4 | 0.0 | 0.0 |
| HIS ONE QUARTER | 8.3 | +0.0 | 0.0 | 425.0 | 9.7 | +0.0 | 0.0 | 289.3 |
| HIS OWN BEST MOVE | 9.3 | +0.0 | 0.0 | 375.0 | 11.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 22.0 | +0.0 | 0.0 | 259.3 | 13.0 | +0.0 | 0.0 | 157.3 |
| HIS RANDOM MOVER COMES | 8.0 | +0.0 | 0.0 | 129.3 | 3.0 | +0.0 | 0.0 | 33.3 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 42.7 | +567.5 | 0.0 | 266.0 | 57.0 | +1187.8 | 0.0 | 699.3 |
| HIS SHOTS BY HIS RUN | 37.3 | +356.7 | 0.0 | 731.7 | 61.0 | +1126.8 | 0.0 | 722.0 |
| HIS TURN DENIED | 2.0 | +18.6 | 89.3 | 65.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| HOLD ODDS | 15.7 | +0.0 | 0.0 | 66.0 | 18.0 | +0.0 | 0.0 | 274.7 |
| HOLDER ASSIGNMENT | 12.3 | +895.4 | 0.0 | 68.0 | 10.7 | +977.7 | 0.0 | 137.3 |
| HOLDS AMBUSHERS | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 5.7 | -200.5 | 310.3 | 65.0 | 2.0 | -51.4 | 263.3 | 0.0 |
| IDLE COST | 5.0 | -75.5 | 0.0 | 0.0 | 16.7 | -176.4 | 0.0 | 78.7 |
| JOINT CHARGE NOW | 0.3 | -6.0 | 0.0 | 0.0 | 0.3 | -5.4 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 1.7 | +0.0 | 0.0 | 22.0 | 0.7 | +0.0 | 0.0 | 93.3 |
| LANE BY FIGURES | 1.3 | +48.6 | 0.0 | 0.0 | 0.7 | +0.4 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 9.3 | +0.0 | 113.3 | 131.0 | 6.3 | +0.0 | 198.3 | 130.0 |
| LONE WIZARD KEPT IN | 1.3 | +77.2 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 0.3 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 1.3 | +4.6 | 83.3 | 65.0 | 0.7 | +0.0 | 83.3 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.7 | +3.9 | 0.0 | 0.0 |
| MANOEUVRE | 1.7 | -3.1 | 0.0 | 0.0 | 2.0 | +43.9 | 0.0 | 36.7 |
| MARCH AT ESCAPER | - | - | - | - | 0.7 | +1.1 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.3 | +13.0 | 0.0 | 52.7 |
| MARCH CHECK | 0.3 | +1.6 | 0.0 | 180.0 | 0.3 | +18.8 | 0.0 | 52.7 |
| MARCH OF THE TABLE | 0.3 | +23.7 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | -50.1 | 0.0 | 0.0 | 0.3 | -6.2 | 0.0 | 52.7 |
| MAX FOR POSITIONING | 0.3 | +0.2 | 0.0 | 0.0 | 2.3 | +46.6 | 0.0 | 16.7 |
| MEETS IN TIME | 4.3 | +147.4 | 0.0 | 48.3 | 4.3 | +410.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.7 | +43.0 | 0.0 | 360.0 | 4.0 | +30.6 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 3.3 | +38.2 | 0.0 | 360.0 | 6.0 | +34.0 | 0.0 | 52.7 |
| MOVE ORDER | 2.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 46.7 | 84.7 |
| MOVE TO CHARGE COMPUTED | 10.3 | +1651.3 | 0.0 | 195.0 | 13.7 | +1042.6 | 0.0 | 62.0 |
| NEARER NOT NEEDED | 13.7 | +529.8 | 0.0 | 92.0 | 8.3 | +355.0 | 0.0 | 89.3 |
| NEAREST TO GOAL | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 9.0 | +1529.8 | 0.0 | 195.0 | 11.3 | +941.0 | 0.0 | 62.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -0.1 | 0.0 | 46.7 |
| NO DOUBLE ROUNDS | 5.7 | -306.1 | 310.3 | 130.0 | 1.3 | -162.8 | 263.3 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.7 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 8.7 | -215.4 | 0.0 | 174.0 | 9.3 | -348.6 | 18.3 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.7 | -75.4 | 0.0 | 245.0 | 9.7 | -149.2 | 0.0 | 78.7 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +8.0 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 6.3 | -84.5 | 0.0 | 46.0 | 5.0 | -141.2 | 0.0 | 90.7 |
| ONE PROMISE A TARGET | 0.3 | -145.3 | 0.0 | 0.0 | 2.0 | -25.7 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 1.7 | +104.0 | 76.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 1.7 | +14.0 | 36.7 | 0.0 | 0.7 | +6.9 | 65.0 | 0.0 |
| PATHS CROSS | 0.7 | +2.1 | 0.0 | 0.0 | 1.3 | -46.4 | 0.0 | 0.0 |
| PERIAPT WORTH | 0.3 | +34.4 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 51.3 | +324.6 | 218.0 | 856.0 | 46.7 | +445.8 | 42.3 | 840.3 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 10.3 | -283.6 | 0.0 | 0.0 | 10.3 | -335.4 | 0.0 | 62.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 3.7 | -10.2 | 0.0 | 62.0 |
| PROMISE SHOT AWAY | 0.3 | -0.8 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 27.3 | +2639.6 | 341.0 | 701.3 | 21.0 | +2586.8 | 605.0 | 319.3 |
| RANDOM MOVE BY FIGURES | 3.7 | +162.9 | 0.0 | 48.3 | 3.7 | +42.5 | 0.0 | 113.3 |
| REDIRECT BY WHAT IT STOPS | 0.3 | -3.1 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 4.7 | +227.9 | 0.0 | 151.0 | 1.7 | +69.7 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 5.7 | +0.5 | 0.0 | 151.0 | 1.3 | +0.0 | 0.0 | 15.0 |
| REDIRECT WEIGHED | 0.3 | -9.6 | 41.7 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 1.7 | -55.7 | 0.0 | 0.0 | 1.7 | -6.3 | 0.0 | 0.0 |
| RESERVE FALL BACK | 3.3 | +31.5 | 0.0 | 68.0 | 0.7 | +5.3 | 0.0 | 38.0 |
| RISK BY ARC | 3.7 | -26.8 | 253.7 | 65.0 | 1.7 | +15.5 | 263.3 | 0.0 |
| ROUNDS AFTER TERROR | 3.7 | -59.3 | 212.0 | 130.0 | - | - | - | - |
| RUN DOWN | 4.7 | -122.6 | 253.7 | 130.0 | 0.3 | -0.6 | 18.3 | 0.0 |
| SCOUT SPOT | 1.3 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 0.3 | +0.2 | 0.0 | 0.0 | 0.7 | +84.8 | 0.0 | 0.0 |
| SECOND LOOK | 0.7 | +38.2 | 0.0 | 0.0 | 0.7 | +19.9 | 18.3 | 0.0 |
| SET CREDITED ONCE | 0.3 | -0.6 | 0.0 | 65.0 | 1.0 | -77.2 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.7 | -11.0 | 0.0 | 65.0 | 1.3 | +48.6 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.7 | +3.9 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +3.0 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 6.3 | +0.0 | 0.0 | 204.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.3 | +41.9 | 0.0 | 180.0 | - | - | - | - |
| SHOT OR CHARGE | 0.7 | -1.3 | 0.0 | 65.0 | 0.3 | -1.9 | 180.0 | 0.0 |
| SHOT RISK POINTS | 26.7 | -242.5 | 0.0 | 258.7 | 34.7 | -413.0 | 0.0 | 478.7 |
| SHOTS AFTER THE MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 26.3 | +328.8 | 0.0 | 92.0 | 6.7 | +81.3 | 0.0 | 74.7 |
| SPELL WORTH | 1.0 | +13.1 | 360.0 | 360.0 | 4.0 | +6.4 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 8.3 | +0.0 | 0.0 | 65.0 | 11.7 | +0.0 | 0.0 | 309.7 |
| STAND AND SHOOT | 1.7 | -16.0 | 122.7 | 0.0 | 0.3 | -0.8 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 2.7 | +0.0 | 0.0 | 52.7 |
| STANDS STILL | 36.0 | +0.0 | 160.0 | 383.0 | 28.0 | +0.0 | 384.0 | 218.7 |
| STAY WORTH | 20.0 | +88.1 | 40.0 | 22.0 | 9.0 | +56.4 | 384.0 | 46.7 |
| STRIKE BY THE ODDS | 0.7 | +281.4 | 0.0 | 130.0 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 9.0 | +605.7 | 0.0 | 65.0 | 4.3 | +156.3 | 0.0 | 178.7 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 18.3 | 0.0 |
| SUPPORT WORKED OUT | 9.0 | +605.7 | 0.0 | 65.0 | 4.3 | +156.3 | 0.0 | 178.7 |
| THE DEARER SUM KEEPS ITS PLAN | 3.7 | +0.0 | 0.0 | 65.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -96.3 | 0.0 | 0.0 | 0.3 | -0.2 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 41.7 |
| THE ROW KEEPS ITS WAY | 3.7 | +0.0 | 0.0 | 40.7 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 3.0 | +0.0 | 0.0 | 40.7 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 49.0 | +0.0 | 0.0 | 641.0 | 45.7 | +0.0 | 0.0 | 351.0 |
| TIED UP BY THE SUM | 2.7 | +338.2 | 131.3 | 0.0 | 0.3 | +57.8 | 65.0 | 0.0 |
| TIME ON OUR SIDE | 43.0 | +359.8 | 0.0 | 559.0 | 12.7 | +111.1 | 0.0 | 36.7 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 33.3 |
| WALKS ON ITS ROUTE | 0.3 | -11.4 | 0.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -41.8 | 0.0 | 0.0 |
| WHO FIGHTS | 0.7 | +79.7 | 0.0 | 65.0 | 0.7 | +14.8 | 0.0 | 0.0 |
| WHO HITS BACK | 0.3 | +18.3 | 0.0 | 18.3 | 0.7 | +34.3 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +1.8 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 5.7 | -429.8 | 0.0 | 540.0 | 3.7 | -808.4 | 0.0 | 105.3 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +5.4 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 7.0 | +158.6 | 0.0 | 105.3 |

### Rule changes: gs3-83c8646-p11

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 198 | 198 | 140 | 46.67 | +2477 | +17.7 |
| HOLDER ASSIGNMENT | 69 | 69 | 63 | 21.00 | +4051 | +64.3 |
| HIS SHOT LIST | 299 | 273 | 56 | 18.67 | +651 | +11.6 |
| OFF BEST | 54 | 54 | 54 | 18.00 | -1692 | -31.3 |
| LEGAL CHARGES ONLY | 47 | 47 | 47 | 15.67 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 295 | 275 | 43 | 14.33 | +503 | +11.7 |
| MOVE TO CHARGE COMPUTED | 72 | 61 | 39 | 13.00 | +2692 | +69.0 |
| NEXT CHARGE BY LIST | 61 | 53 | 35 | 11.67 | +2453 | +70.1 |
| FIVE ACTION | 593 | 560 | 27 | 9.00 | +1668 | +61.8 |
| DEPLOY BY FIGURES | 47 | 47 | 26 | 8.67 | +299 | +11.5 |
| THE TABLE AGAIN | 36 | 36 | 26 | 8.67 | +0 | +0.0 |
| GOAL WALK | 63 | 63 | 21 | 7.00 | +1431 | +68.1 |
| HARD STAY DROPPED | 21 | 21 | 21 | 7.00 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 62 | 62 | 21 | 7.00 | -1857 | -88.4 |
| REDIRECT FOR A FRIEND IN REACH | 21 | 21 | 21 | 7.00 | +0 | +0.0 |
| MOVE ORDER | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| QUARTER ODDS | 145 | 138 | 19 | 6.33 | +1810 | +95.2 |
| TIME ON OUR SIDE | 167 | 135 | 16 | 5.33 | +35 | +2.2 |
| FOUR ROUNDS | 24 | 20 | 15 | 5.00 | +857 | +57.2 |
| MEETS IN TIME | 26 | 26 | 13 | 4.33 | +1082 | +83.3 |
| RANDOM MOVE BY FIGURES | 22 | 22 | 13 | 4.33 | +616 | +47.4 |
| RESERVE FALL BACK | 12 | 12 | 12 | 4.00 | +110 | +9.2 |
| SHOT RISK POINTS | 184 | 171 | 12 | 4.00 | +135 | +11.2 |
| SUPPORT ADDS | 40 | 39 | 12 | 4.00 | +500 | +41.7 |
| SUPPORT WORKED OUT | 40 | 39 | 12 | 4.00 | +500 | +41.7 |
| ADVANCE LANE KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| COVER ONCE | 60 | 39 | 9 | 3.00 | +96 | +10.7 |
| HOLDS AMBUSHERS | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| ONE PROMISE A TARGET | 7 | 7 | 7 | 2.33 | -513 | -73.3 |
| TIED UP BY THE SUM | 9 | 8 | 7 | 2.33 | +513 | +73.3 |
| CAST JOB | 12 | 12 | 6 | 2.00 | +14 | +2.3 |
| FOLLOW UP WEIGHED | 6 | 6 | 6 | 2.00 | +484 | +80.7 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +147 | +24.5 |
| PATHS CROSS | 6 | 6 | 6 | 2.00 | -133 | -22.1 |
| EVASIVE BY THE ODDS | 12 | 12 | 5 | 1.67 | +825 | +165.0 |
| PROMISE KNOWS THE FIGHT | 12 | 9 | 5 | 1.67 | -31 | -6.1 |
| SHOOTS FROM THE BEST SPOT | 7 | 7 | 5 | 1.67 | +47 | +9.4 |
| STAY WORTH | 87 | 77 | 5 | 1.67 | +37 | +7.4 |
| CHARGE LOSSES | 139 | 130 | 4 | 1.33 | +69 | +17.1 |
| IDLE COST | 65 | 34 | 4 | 1.33 | +11 | +2.7 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +232 | +57.9 |
| MAX FOR POSITIONING | 8 | 7 | 4 | 1.33 | +65 | +16.2 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SECOND LOOK | 4 | 4 | 4 | 1.33 | +174 | +43.5 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +76 | +25.4 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FIRE IN ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FOCUS FIRE | 3 | 3 | 3 | 1.00 | +145 | +48.3 |
| MANOEUVRE | 11 | 11 | 3 | 1.00 | +139 | +46.4 |
| NO DOUBLE ROUNDS | 21 | 18 | 3 | 1.00 | +42 | +14.1 |
| OPENS UP | 5 | 4 | 3 | 1.00 | +114 | +37.9 |
| RISK BY ARC | 16 | 13 | 3 | 1.00 | +73 | +24.3 |
| SEARCH SPOT | 3 | 3 | 3 | 1.00 | +255 | +85.1 |
| SET UP BY THE SET | 9 | 9 | 3 | 1.00 | +520 | +173.2 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +10 | +3.3 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +113 | +37.5 |
| WHOLE FIGHT DANGER | 28 | 28 | 3 | 1.00 | +42 | +14.1 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 14 | 14 | 2 | 0.67 | -32 | -16.0 |
| FALLS SHORT | 83 | 63 | 2 | 0.67 | +55 | +27.6 |
| HIS TURN DENIED | 7 | 7 | 2 | 0.67 | +3 | +1.6 |
| HONEST WORTH | 23 | 19 | 2 | 0.67 | +8 | +3.8 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | -34 | -17.1 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -71 | -35.5 |
| MISSILES IN THE MOVE | 20 | 10 | 2 | 0.67 | +11 | +5.7 |
| NEARER NOT NEEDED | 66 | 62 | 2 | 0.67 | +62 | +31.0 |
| SHOTS IN THE MOVE | 99 | 73 | 2 | 0.67 | +10 | +5.0 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +514 | +256.9 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 19 | 2 | 2 | 0.67 | +0 | +0.0 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +98 | +98.0 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -33 | -33.2 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 3 | 3 | 1 | 0.33 | +0 | +0.4 |
| EXACT ROUND | 16 | 12 | 1 | 0.33 | +341 | +340.6 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +117 | +116.7 |
| FALL BACK GOOD ORDER | 16 | 14 | 1 | 0.33 | +96 | +96.0 |
| FIGHT TO THE END | 1 | 1 | 1 | 0.33 | +1 | +0.7 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +39 | +39.1 |
| MARCH CHECK | 2 | 2 | 1 | 0.33 | +5 | +4.8 |
| ONE FIGHT FORMULA | 40 | 20 | 1 | 0.33 | +7 | +7.2 |
| ONE JOINT FIGURE | 1 | 1 | 1 | 0.33 | +1 | +0.7 |
| ONE OBJECTIVE FORMULA | 34 | 22 | 1 | 0.33 | +34 | +34.2 |
| OVERRUNS AWAY | 7 | 6 | 1 | 0.33 | +1 | +0.7 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +103 | +103.3 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -2 | -2.4 |
| REDIRECT COUNTER | 19 | 16 | 1 | 0.33 | +130 | +130.4 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | -16 | -15.6 |
| SHOTS AFTER THE MOVES | 15 | 15 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -34 | -34.3 |
| WHOLE FIGHT GAIN | 1 | 1 | 1 | 0.33 | +1 | +0.7 |
| BACKUP TARGETS | 3 | 3 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 12 | 12 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 73 | 70 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 3 | 3 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 5 | 5 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 54 | not checked | - | - | - | - |
| FOOT FIRST | 75 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 37 | 37 | 0 | 0.00 | - | - |
| GUN FIGURES | 7 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 24 | 24 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 82 | 76 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 44 | 39 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 36 | 32 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 30 | 29 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 54 | 54 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 61 | 53 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 105 | 100 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 33 | 32 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 101 | 101 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 7 | 7 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 6 | 5 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 28 | 14 | 0 | 0.00 | - | - |
| NEAREST TO GOAL | 2 | 2 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 294 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 10 | 10 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 11 | 11 | 0 | 0.00 | - | - |
| RUN DOWN | 15 | 13 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 32 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 15 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 60 | 53 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 6 | 6 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 192 | 178 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 8 | 8 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 17 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 18 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 16 | not checked | - | - | - | - |
| THE TABLE BINDS | 284 | not checked | - | - | - | - |
| WAITS AGAIN | 6 | 6 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | not checked | - | - | - | - |
| WHO FIGHTS | 4 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | not checked | - | - | - | - |
| WOUNDS ON THE RANKS | 21 | 21 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p11

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 6.67 | 7.67 | 30.1 |
| ARMY TABLE | rule | 4.33 | 3.33 | 54.2 |
| PROMISE BY ITS OWN SUM | rule | 3.33 | 3.67 | 88.4 |
| ONE PROMISE A TARGET | rule | 0.33 | 2.00 | 73.3 |
| RULE SWITCHED OFF | gate | 2.00 | - | 30.0 |
| PROMISE KNOWS THE FIGHT | rule | - | 1.67 | 6.1 |
| NO REASON | gate | - | 1.33 | 53.5 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.67 | 11.2 |
| CHARGE NOW FIRST | rule | 0.67 | - | 16.0 |
| JOINT CHARGE NOW | rule | 0.33 | 0.33 | 17.1 |
| PATHS CROSS | rule | - | 0.67 | 77.0 |
| AFTERMATH BAND | gate | - | 0.33 | 2.4 |
| BEST PRIZE | rule | 0.33 | - | 33.2 |
| MARCH OF THE TABLE | rule | 0.33 | - | 71.0 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 2.4 |
| REDIRECT WEIGHED | rule | 0.33 | - | 15.6 |
| WALKS ON ITS ROUTE | rule | 0.33 | - | 34.3 |

### Plans: gs3-83c8646-p11

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 4.3 | 31% | 748 | 146 | 20% |
| Mine | move | 42.3 | 95% | 2834 | 0 | 0% |
| Mine | shoot | 4.7 | 50% | 204 | 179 | 88% |
| Opponent | charge | 2.0 | 83% | 265 | 266 | 100% |
| Opponent | join | 5.7 | 100% | 323 | 0 | 0% |
| Opponent | move | 36.3 | 93% | 1661 | 0 | 0% |
| Opponent | shoot | 2.7 | 12% | 68 | 180 | 265% |

### Battle groups: gs3-83c8646-p11

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.7 | 14% | 100% | 50% | 100% | 100% | 0% | 0% | 0% | 0% |
| Opponent | REDIRECT COUNTER | 1.7 | 20% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p11

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Chaff | 6 | 97 (6) | 0 | 97 | 96 | 0% | 1.2 | - | 112 (5) | 0 (1) | 112 (5) | 0 (1) |
| Mine | Character | 7 | 26 (7) | 26 | 0 | 22 | 14% | 3.3 | 34 (2) | 14 (3) | 27 (2) | 31 (4) | 14 (3) |
| Mine | Clean-up | 1 | 220 (1) | 0 | 220 | 0 | 0% | 5.0 | - | 220 (1) | - | - | 220 (1) |
| Mine | Fast Hammer | 6 | 74 (6) | 74 | 0 | 42 | 50% | 4.3 | 66 (4) | 94 (2) | - | - | 74 (6) |
| Mine | Hammer | 5 | 76 (5) | 36 | 40 | 16 | 20% | 2.0 | 66 (3) | 88 (2) | - | 114 (2) | 58 (3) |
| Mine | Holder | 8 | 19 (8) | 0 | 19 | 0 | 38% | 2.0 | 82 (2) | 0 (6) | - | 82 (2) | 0 (6) |
| Mine | Shooter | 5 | 0 (5) | 0 | 0 | 0 | 0% | 1.4 | 0 (2) | 0 (3) | - | 0 (4) | 0 (1) |
| Mine | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | 0 (1) | - | 0 (2) | 0 (1) |
| Opponent | Chaff | 4 | 173 (4) | 23 | 150 | 19 | 50% | 3.5 | 231 (3) | - | 0 (1) | 231 (3) | 0 (1) |
| Opponent | Character | 11 | 38 (11) | 38 | 0 | 13 | 27% | 4.0 | 81 (2) | 25 (8) | - | 26 (6) | 77 (4) |
| Opponent | Fast Hammer | 6 | 23 (6) | 2 | 22 | 28 | 33% | 3.5 | - | 27 (5) | 0 (1) | 4 (3) | 36 (3) |
| Opponent | Hammer | 8 | 26 (8) | 26 | 0 | 41 | 38% | 5.2 | 0 (3) | 40 (5) | - | 34 (6) | 0 (2) |
| Opponent | Holder | 3 | 0 (3) | 0 | 0 | 29 | 67% | 4.0 | 0 (1) | 0 (2) | - | - | 0 (3) |
| Opponent | Shooter | 3 | 101 (3) | 18 | 82 | 100 | 0% | 1.0 | - | 144 (2) | 0 (1) | 146 (2) | 0 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |

### Charged fights: gs3-83c8646-p11

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 1 | 281 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 551 | 4.0 | 1.0 | 138 | 24 | +113 | 2 of 8 | 7 of 8 | - | +113 |
| **Mine** | all armies | 3 | 94 | 367 | 3.0 | 1.0 | 122 | 22 | +101 | 2 of 9 | 7 of 9 | - | +101 |
| Opponent | Vampire Counts | 1 | 145 | 595 | 4.0 | 1.0 | 149 | 0 | +149 | 3 of 4 | 2 of 4 | - | +149 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 120 | -120 | 1 of 1 | 0 of 1 | - | -120 |
| Opponent | Wood Elf Realms | 1 | 66 | 195 | 1.0 | 1.0 | 195 | 0 | +195 | 1 of 1 | 1 of 1 | - | +195 |
| **Opponent** | all armies | 3 | 70 | 263 | 2.0 | 1.0 | 132 | 20 | +112 | 5 of 6 | 3 of 6 | - | +112 |

### Effective charges: gs3-83c8646-p11

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 8 | 0 | 1 (net -195) | 0 | 0 | 2 (net +62) | 4 (net +213) | 1 | 0% (0 of 7) |
| Opponent | Vampire Counts | 4 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +540) | 2 | 0% (0 of 2) |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +195) | 0 | 0% (0 of 1) |

### Charged fights, damage counted: gs3-83c8646-p11

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 50-54% | 1 | 195 | 201 | -195 | 22 | 195 | -173 | -88.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 207 | 131 | +170 | 170 | 8 | +163 | +78.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 431 | 120 | +62 | 92 | 0 | +92 | +21.2 |
| Mine | No odds | 1 | 440 | 125 | +125 | 125 | 0 | +125 | +28.4 |
| Mine | All fights | 9 | 282 | 136 | +101 | 131 | 26 | +105 | +37.5 |
| Opponent | Long shot (under 50%) | 1 | 50 | 210 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 485 | 318 | +368 | 368 | 0 | +368 | +75.8 |
| Opponent | No odds | 3 | 117 | 232 | -22 | 30 | 63 | -33 | -28.1 |
| Opponent | All fights | 6 | 228 | 257 | +112 | 138 | 31 | +106 | +46.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p11 | move | 28 | 4 (14%) | 3 (11%) | 3 (11%) | 21 (75%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L2127 |
| Invocation of Nehek | Opponent | L2127 |
| Periapt of Soul Exchange | Mine | L2127 |
| Ring of Doom | Opponent | L2231 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |

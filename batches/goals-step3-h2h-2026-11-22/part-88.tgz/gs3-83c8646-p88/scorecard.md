# Doctrine scorecard: gs3-83c8646-p88

### Scorecard: gs3-83c8646-p88

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0608 | 2 | 1 | Mine | - | - | - | 0 | 4 | 0 | 0 | 0 | 981 |
| L0608 | 2 | 1 | Opponent | - | - | - | 0 | 3 | 0 | 0 | 0 | 265 |
| L0624 | 6 | 1 | Mine | no | 5 | - | 0 | 2 | 0 | 0 | 0 | 435 |
| L0624 | 6 | 1 | Opponent | no | 1 | 6 | 1 | 4 | 0 | 0 | 0 | 235 |
| L0713 | 5 | 1 | Mine | no | - | 3 | 1 | 4 | 1 | 0 | 0 | 125 |
| L0713 | 5 | 1 | Opponent | yes | - | - | 1 | 2 | 0 | 0 | 0 | 140 |
| **Average** | | | Mine | 0% | 5.0 | 3.0 | 0.3 | 3.3 | 0.3 | 0.0 | 0.0 | 513.7 |
| **Average** | | | Opponent | 50% | 1.0 | 6.0 | 0.7 | 3.0 | 0.0 | 0.0 | 0.0 | 213.3 |

### KPIs: gs3-83c8646-p88

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 75% (9 of 12) | 0% (0 of 15) | 33% (9 of 27) |
| Winner chose to follow up after the loser gave ground |  | 0% (0 of 1); on the table 0% | 100% (1 of 1); on the table 100% | 50% (1 of 2); on the table 50% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (2 of 2); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 0% (0 of 1); on the table 0% | 100% (3 of 3); on the table 100% | 75% (3 of 4); on the table 75% |
| Magic missiles tried each own turn | 50%+ | 50% (3 of 6) | 42% (5 of 12) | 44% (8 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 100% (3 of 3) | 50% (5 of 10) | 62% (8 of 13) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 91% (5450 of 5999) | 77% (4613 of 5998) | 84% (10063 of 11997) |
|   infantry points that never fought | lower | 86% (1595 of 1858) | 84% (1246 of 1476) | 85% (2841 of 3334) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 80% (24 of 30) | 68% (17 of 25) | 75% (41 of 55) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (1 of 1); 1.3 uses a game | 100% (1 of 1); 0.7 uses a game |
| Bound items with another spell used |  | 100% (1 of 1); 0.7 uses a game | 0% (0 of 2); 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (2 of 2); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 73% (3473 of 4780) | 58% (3152 of 5477) | 65% (6625 of 10257) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (29%) | 0.7 (20%) |
| MARCHED: its unit marched | 0.0 (0%) | 1.0 (43%) | 1.0 (30%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (29%) | 0.7 (20%) |
| GONE: slain | 1.0 (100%) | 0.0 (0%) | 1.0 (30%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 8.0 | 0.7 | 1.7 | 2.7 | 0.3 | 1.0 |
| not cast | 0.0 | 3.3 | 0.3 | 3.3 | 1.7 | 11.0 |
| NOT CHOSEN: could have been cast at a target | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | - | 2.0 (60%) | 0.0 (0%) | 0.7 (20%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | - | 0.0 (0%) | 0.0 (0%) | 1.0 (30%) | 1.0 (60%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | - | 0.0 (0%) | 0.3 (100%) | 0.7 (20%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | - | 1.0 (30%) | 0.0 (0%) | 1.0 (30%) | 0.0 (0%) | 2.0 (18%) |
| OTHER BAR: another bar (miscast, baggage ...) | - | 0.3 (10%) | 0.0 (0%) | 0.0 (0%) | 0.7 (40%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 8.7 (79%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.7 a game | 0.8 a game |
| stood (cast and not dispelled) | - | 80% (4 of 5) | 80% (4 of 5) |
| the unit moved after it | - | 25% (1 of 4) | 25% (1 of 4) |
| it charged on its next turn | - | 0% (0 of 4) | 0% (0 of 4) |
| the enemy charged it first | - | 25% (1 of 4) | 25% (1 of 4) |
| it fought by the end of its next turn | - | 25% (1 of 4) | 25% (1 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 4) | 0% (0 of 4) |
| none of these (no charge, no fight, no charge escaped) | - | 75% (3 of 4) | 75% (3 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 62% (116 of 186) | 55% (38 of 69) | 60% (154 of 255) |
|   cavalry | 48% (11 of 23) | 75% (6 of 8) | 55% (17 of 31) |
|   character | 100% (7 of 7) | 50% (6 of 12) | 68% (13 of 19) |
|   chariot | - | 33% (2 of 6) | 33% (2 of 6) |
|   infantry | 60% (34 of 57) | 75% (9 of 12) | 62% (43 of 69) |
|   monster | 80% (8 of 10) | - | 80% (8 of 10) |
|   war machine | 63% (56 of 89) | 48% (15 of 31) | 59% (71 of 120) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.0 (13%) | 2.3 (23%) | 5.3 (16%) |
| IN COMBAT: it fought this turn or the last | 0.7 (3%) | 0.3 (3%) | 1.0 (3%) |
| MOVED: a war machine that moved | 1.0 (4%) | 1.0 (10%) | 2.0 (6%) |
| NO TARGET IN RANGE | 9.0 (39%) | 0.0 (0%) | 9.0 (27%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 8.0 (34%) | 6.3 (61%) | 14.3 (43%) |
| SHELTERED: the target was sheltered | 1.3 (6%) | 0.3 (3%) | 1.7 (5%) |
| STUPIDITY | 0.3 (1%) | 0.0 (0%) | 0.3 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.3 | 4.3 | 50% | 14.1 pts | 104 pts |
| character | 5.7 | 3.7 | 71% | 9.9 pts | 56 pts |
| chariot | 0.7 | 1.0 | 50% | 60.0 pts | 40 pts |
| infantry | 24.3 | 6.3 | 77% | 8.3 pts | 202 pts |
| monster | 3.0 | 0.7 | 78% | 5.2 pts | 16 pts |
| war machine | 23.7 | 18.7 | 63% | 17.0 pts | 402 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.3 | 1.3 | 0.8 |
| Charges that made contact a game | 0.3 | 1.3 | 0.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.50 declared, 0.50 contact (2 units) | 0.33 declared, 0.33 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.04 declared, 0.04 contact (24 units) | 0.15 declared, 0.15 contact (20 units) | 0.09 declared, 0.09 contact (44 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 100% (7 of 7) | 67% (2 of 3) | - | 90% (9 of 10) |
| Character in a unit | 100% (5 of 5) | - | - | 100% (5 of 5) |
| Character on its own | 100% (2 of 2) | 100% (3 of 3) | 0% (0 of 3) | 62% (5 of 8) |
| Chariot | - | 0% (0 of 1) | - | 0% (0 of 1) |
| Infantry | 50% (4 of 8) | 40% (2 of 5) | 0% (0 of 1) | 43% (6 of 14) |
| Monster | 100% (2 of 2) | - | - | 100% (2 of 2) |
| War Machines | 93% (14 of 15) | - | - | 93% (14 of 15) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dwarfen Mountain Holds | 2 | 0% (0 of 1); on the table 0% | - | 93% | 80% (16 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 2 | - | 50% (3 of 6) | 94% | 75% (15 of 20) | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| High Elf Realms | 1 | 100% (1 of 1); on the table 100% | 50% (3 of 6) | 68% | 75% (6 of 8) | 100% (1 of 1); 4.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (2 of 2); on the table 100% | 33% (2 of 6) | 62% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p88, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | - | - | - |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p88

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.0 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 100% (1 of 1) | 100% (4 of 4) |
| Strategy | Shoot objectives carried out (shot that target) | 65% (51 of 79) | 77% (20 of 26) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 0% (0 of 7) | 0% (0 of 3) |
| Strategy | Lone characters that fought | 33% (1 of 3) | 33% (3 of 9) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 3.3 | 3.0 |
| Movement | Points that never moved of their own | 513.7 | 213.3 |
| Movement | Fights charged into per game | 0.3 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 1 | 0 of 3 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 1, net -281 | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 1 | 1 of 3, net +0 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 1 | 2 of 3, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 20.7 | 7.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 69% (43 of 62) | 43% (10 of 23) |
| Shooting | Points destroyed by shooting units | 143.0 | 161.7 |
| Shooting | War machine shots | 18.7 | 5.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 54% (30 of 56) | 80% (12 of 15) |
| Shooting | Points destroyed by war machines | 23.3 | 40.0 |
| Magic | Magic missiles cast | 0.7 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 100% (2 of 2) | 67% (2 of 3) |
| Magic | Wounds caused by magic missiles | 1.0 | 1.3 |
| Magic | Wounds caused by other spells | 0.3 | 1.0 |
| Magic | Points destroyed by magic (all spells) | 147.3 | 35.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 6.7 / 0.3 / 0.7 / 0.3 |
| Combat | Points destroyed in combat | 0.0 | 93.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | -110 | -46 |
| Combat | Net per 100 charger points, damage counted | -60.5 | -10.9 |
| Combat | First round won (charged fights) | 100% | 100% |
| Combat | Net points per charged fight | -281 | +0 |
| Combat | Net points per supported fight / lone fight | - / -281 | +0 / +0 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 1 | 1 of 3 |
| Game | Points lost | 313.7 | 280.3 |
| Game | VP from objectives | 240.0 | 650.0 |
| Game | Lone holders (player turns) | 5.0 | 1.0 |

- Mine won / drew / lost: 0 / 0 / 3 of 3 ended games (of 3); mean margin (Mine - Opponent) -456 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 594
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p88

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +15.7 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 10.3 | -194.1 | 0.0 | 0.0 | 23.7 | +321.1 | 0.0 | 176.7 |
| ARTILLERY RE-ROLL WEIGHED | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 1.0 | +0.0 | 176.7 | 0.0 | 0.3 | +0.0 | 126.7 | 0.0 |
| CANNON PLANNED TARGET | 17.3 | +403.1 | 730.0 | 0.0 | 4.7 | +116.9 | 253.3 | 23.3 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 23.3 |
| CAST JOB | 0.7 | +36.1 | 0.0 | 253.3 | 0.7 | +2.4 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | - | - | - | - | 0.3 | +2.3 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 2.0 | +21.2 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | -0.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +8.5 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 3.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 17.7 | -785.7 | 0.0 | 150.0 | 21.0 | -1255.8 | 0.0 | 757.3 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 0.0 | 93.7 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 8.3 | +0.0 | 0.0 | 0.0 | 13.7 | +0.0 | 0.0 | 109.3 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 93.7 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 1.3 | +109.1 | 0.0 | 0.0 |
| COVER ONCE | 7.0 | -347.8 | 0.0 | 35.0 | 12.7 | -661.6 | 0.0 | 235.7 |
| DEFENSIVE ARMY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | 0.3 | -0.7 | 0.0 | 93.7 | 1.0 | -3.3 | 35.0 | 0.0 |
| DEPLOY BY FIGURES | 11.7 | -65.3 | 0.0 | 0.0 | 7.3 | -39.6 | 0.0 | 46.7 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -0.8 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 0.7 | +5.8 | 0.0 | 0.0 |
| EXACT ROUND | 0.3 | +6.5 | 0.0 | 93.7 | 1.0 | +1.3 | 70.0 | 0.0 |
| FALL BACK GOOD ORDER | 0.3 | +0.0 | 0.0 | 93.7 | 1.3 | +0.0 | 70.0 | 0.0 |
| FALLS SHORT | 3.7 | +54.0 | 0.0 | 0.0 | 30.0 | +287.5 | 0.0 | 471.3 |
| FEATURE BUFFS | 1.7 | +9.1 | 0.0 | 0.0 | 2.0 | +22.2 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.3 | +11.4 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 144.7 | +3930.6 | 3404.0 | 637.0 | 105.3 | +3907.1 | 1350.0 | 1208.0 |
| FLANK NOT WEIGHED | 3.0 | +0.0 | 0.0 | 70.0 | 7.0 | +0.0 | 0.0 | 88.3 |
| FOLLOW UP WEIGHED | 0.3 | +93.4 | 0.0 | 93.7 | 1.3 | +139.0 | 0.0 | 0.0 |
| FOOT FIRST | 18.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 0.3 | +46.1 | 0.0 | 93.7 | 1.3 | +93.1 | 70.0 | 0.0 |
| FREED FROM HIS FIGHT | 2.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| GOAL WALK | 2.0 | +199.1 | 0.0 | 0.0 | 12.0 | +882.3 | 0.0 | 0.0 |
| GROUND FLIERS | 0.3 | +7.4 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 80.0 | 176.7 |
| GUN MASK | 5.0 | +133.5 | 0.0 | 0.0 | 1.7 | +42.9 | 0.0 | 0.0 |
| HARD STAY DROPPED | 3.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 9.7 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 471.3 |
| HIS CHARGE LIST | 7.3 | +0.0 | 0.0 | 0.0 | 22.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 471.3 |
| HIS MOVE AND SHOT | 3.0 | -32.9 | 0.0 | 0.0 | 3.3 | -39.4 | 0.0 | 176.7 |
| HIS ONE QUARTER | 2.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 2.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 471.3 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 52.7 | +3587.2 | 0.0 | 220.0 | 70.3 | +6604.6 | 0.0 | 1052.0 |
| HIS SHOTS BY HIS RUN | 25.7 | +527.9 | 0.0 | 220.0 | 53.3 | +1292.0 | 0.0 | 1052.0 |
| HIS TURN DENIED | 0.3 | +2.9 | 0.0 | 93.7 | 1.0 | +59.9 | 35.0 | 0.0 |
| HOLD ODDS | 13.0 | +0.0 | 0.0 | 0.0 | 21.7 | +0.0 | 0.0 | 109.3 |
| HOLDER ASSIGNMENT | 8.0 | +717.8 | 0.0 | 0.0 | 10.7 | +1201.0 | 0.0 | 54.7 |
| HONEST WORTH | - | - | - | - | 1.3 | -51.5 | 70.0 | 0.0 |
| IDLE COST | 2.0 | -15.8 | 0.0 | 0.0 | 14.3 | -226.9 | 0.0 | 294.7 |
| JOINT CHARGE NOW | - | - | - | - | 0.7 | -5.1 | 70.0 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 3.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +5.0 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 3.3 | +0.0 | 147.3 | 468.3 | 1.3 | +0.0 | 93.7 | 0.0 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.3 | +35.4 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.3 | +4.4 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | - | - | - | - | 1.3 | +0.8 | 70.0 | 0.0 |
| LOST CHARGE | 0.3 | -0.4 | 0.0 | 93.7 | - | - | - | - |
| MAKE SURE TOGETHER | - | - | - | - | 0.7 | +2.4 | 0.0 | 147.3 |
| MANOEUVRE | 3.0 | -25.9 | 0.0 | 0.0 | 2.3 | -9.3 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.7 | +8.3 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 0.3 | -21.5 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | - | - | - | - | 3.3 | +39.8 | 0.0 | 147.3 |
| MEETS IN TIME | 6.0 | +151.3 | 0.0 | 0.0 | 3.0 | +152.8 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.0 | +42.4 | 0.0 | 126.7 | 3.0 | +26.3 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 1.0 | +56.0 | 0.0 | 126.7 | 4.3 | +30.3 | 0.0 | 0.0 |
| MODEL FACING | 3.3 | +795.4 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 54.7 | 0.0 |
| MOVE SPELL SPOT | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 0.7 | +18.1 | 0.0 | 0.0 | 2.7 | +74.7 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 11.7 | +506.4 | 0.0 | 0.0 | 9.3 | +417.7 | 0.0 | 109.3 |
| NEAREST TO GOAL | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 0.7 | +18.1 | 0.0 | 0.0 | 1.7 | +61.8 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -8.6 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 0.3 | -43.0 | 0.0 | 93.7 | 1.3 | -51.3 | 70.0 | 0.0 |
| NO LATE CUT | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 3.0 | -76.3 | 0.0 | 0.0 | 3.3 | -59.6 | 0.0 | 0.0 |
| ONE CHALLENGE TEST | - | - | - | - | 0.3 | +3.2 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 2.0 | -30.0 | 0.0 | 35.0 | 4.3 | -140.2 | 0.0 | 147.3 |
| ONE OBJECTIVE FORMULA | 3.3 | +40.0 | 0.0 | 0.0 | 5.0 | -47.3 | 0.0 | 0.0 |
| ONE ROUTE | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.7 | +3.9 | 0.0 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +24.1 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -2.6 | 0.0 | 147.3 |
| PLAN RESULT | 61.3 | +1071.2 | 1266.3 | 660.7 | 44.7 | +656.6 | 703.3 | 526.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 2.0 | -11.2 | 0.0 | 0.0 | 2.7 | -2.2 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 1.3 | -1.5 | 0.0 | 0.0 |
| QUARTER ODDS | 9.7 | +793.4 | 0.0 | 0.0 | 9.0 | +728.2 | 0.0 | 0.0 |
| REAL GROUND | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 3.0 | +226.6 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 3.3 | +0.0 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.3 | +15.1 | 0.0 | 0.0 |
| RISK BY ARC | 0.3 | +1.9 | 0.0 | 93.7 | 0.7 | -47.4 | 0.0 | 0.0 |
| RUN DOWN | - | - | - | - | 1.3 | -3.3 | 70.0 | 0.0 |
| SCOUT SPOT | 0.7 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 0.7 | +3.5 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | - | - | - | - | 1.3 | -3.2 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 1.7 | +43.7 | 0.0 | 147.3 |
| SHOOTERS IN TWO RANKS | 1.3 | +2.7 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 26.7 | +0.0 | 0.0 | 126.7 | 8.3 | +0.0 | 0.0 | 78.0 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +8.7 | 176.7 | 0.0 | 0.3 | +21.4 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 2.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOT RISK POINTS | 34.3 | +922.8 | 0.0 | 150.0 | 40.0 | -733.1 | 0.0 | 1052.0 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 36.3 | +1282.3 | 0.0 | 35.0 | 15.3 | +649.5 | 0.0 | 254.7 |
| SPELL WORTH | - | - | - | - | 8.0 | +196.2 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | +13.1 | 0.0 | 93.7 | 0.3 | +2.6 | 35.0 | 0.0 |
| SPOT AS THE GAME MOVES | 3.3 | +0.0 | 0.0 | 35.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | - | - | - | - | 1.3 | -14.1 | 70.0 | 0.0 |
| STANDS FOR A REASON | 1.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 109.3 |
| STANDS STILL | 102.0 | +0.0 | 3404.0 | 333.3 | 49.0 | +0.0 | 1280.0 | 450.7 |
| STAY WORTH | 64.0 | +172.5 | 930.0 | 288.3 | 25.3 | +248.5 | 1140.0 | 179.3 |
| SUPPORT ADDS | 2.3 | +79.2 | 0.0 | 70.0 | 1.0 | +96.2 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 93.7 | - | - | - | - |
| SUPPORT WORKED OUT | 2.3 | +79.2 | 0.0 | 70.0 | 1.0 | +96.2 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 2.0 | +35.1 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.3 | +0.0 | 0.0 | 35.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 60.0 | +0.0 | 0.0 | 231.7 | 46.3 | +0.0 | 0.0 | 604.0 |
| TIED UP BY THE SUM | - | - | - | - | 0.3 | +43.9 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 59.3 | +515.5 | 0.0 | 231.7 | 5.0 | +82.6 | 0.0 | 109.3 |
| WHO FIGHTS | - | - | - | - | 0.3 | -0.6 | 0.0 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +23.1 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.0 | -63.1 | 0.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 6.0 | +193.1 | 0.0 | 0.0 | 3.0 | +58.7 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p88

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 102 | 102 | 83 | 27.67 | +545 | +6.6 |
| HIS SHOT LIST | 369 | 360 | 80 | 26.67 | +2437 | +30.5 |
| HOLDER ASSIGNMENT | 56 | 56 | 55 | 18.33 | +4172 | +75.9 |
| HIS SHOTS BY HIS RUN | 237 | 230 | 48 | 16.00 | +667 | +13.9 |
| SHOT RISK POINTS | 223 | 221 | 35 | 11.67 | +2070 | +59.1 |
| DEPLOY BY FIGURES | 57 | 57 | 33 | 11.00 | +760 | +23.0 |
| TIME ON OUR SIDE | 193 | 182 | 28 | 9.33 | +42 | +1.5 |
| OFF BEST | 19 | 19 | 19 | 6.33 | -408 | -21.5 |
| STAY WORTH | 268 | 252 | 19 | 6.33 | +190 | +10.0 |
| HARD STAY DROPPED | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 13 | 4.33 | +0 | +0.0 |
| CHARGE LOSSES | 116 | 114 | 12 | 4.00 | +302 | +25.2 |
| FIVE ACTION | 750 | 741 | 12 | 4.00 | +624 | +52.0 |
| GOAL WALK | 42 | 40 | 12 | 4.00 | +886 | +73.8 |
| IDLE COST | 49 | 41 | 11 | 3.67 | +67 | +6.1 |
| QUARTER ODDS | 56 | 56 | 11 | 3.67 | +1210 | +110.0 |
| MODEL FACING | 10 | 10 | 10 | 3.33 | +2386 | +238.6 |
| MOVE ORDER | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| CANNON SIGHT KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| COVER ONCE | 59 | 47 | 7 | 2.33 | +124 | +17.6 |
| SHORT GUN FORWARD | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 29 | 29 | 6 | 2.00 | +0 | +0.0 |
| FALLS SHORT | 101 | 83 | 5 | 1.67 | +16 | +3.2 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +697 | +139.4 |
| MEETS IN TIME | 27 | 27 | 5 | 1.67 | +211 | +42.1 |
| MOVE TO CHARGE COMPUTED | 10 | 10 | 5 | 1.67 | +109 | +21.8 |
| SHOTS IN THE MOVE | 155 | 138 | 5 | 1.67 | +199 | +39.8 |
| SUPPORT ADDS | 10 | 8 | 5 | 1.67 | +286 | +57.1 |
| SUPPORT WORKED OUT | 10 | 8 | 5 | 1.67 | +286 | +57.1 |
| FOUR ROUNDS | 5 | 5 | 4 | 1.33 | +172 | +43.1 |
| MAX FOR POSITIONING | 10 | 10 | 4 | 1.33 | +2 | +0.6 |
| PROMISE BY ITS OWN SUM | 14 | 14 | 4 | 1.33 | -40 | -10.1 |
| SET UP BY THE SET | 4 | 4 | 4 | 1.33 | +68 | +16.9 |
| SHOOTERS IN TWO RANKS | 4 | 4 | 4 | 1.33 | +8 | +2.0 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | -0 | -0.0 |
| FIRE IN ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| GUN MASK | 20 | 18 | 3 | 1.00 | +185 | +61.6 |
| SHOOTS FROM THE BEST SPOT | 3 | 3 | 3 | 1.00 | +16 | +5.4 |
| SURE REACH TOGETHER | 6 | 6 | 3 | 1.00 | +38 | +12.6 |
| EVASIVE BY THE ODDS | 2 | 2 | 2 | 0.67 | +18 | +8.8 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | -15 | -7.7 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +17 | +8.7 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +25 | +12.4 |
| NEXT CHARGE BY LIST | 7 | 7 | 2 | 0.67 | +75 | +37.4 |
| PROMISE KNOWS THE FIGHT | 4 | 4 | 2 | 0.67 | -4 | -2.2 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SEARCH SPOT | 2 | 2 | 2 | 0.67 | +10 | +5.2 |
| THE ROW IN ITS ORDER | 15 | 2 | 2 | 0.67 | +0 | +0.0 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +47 | +47.0 |
| CANNON PLANNED TARGET | 66 | 66 | 1 | 0.33 | +0 | +0.0 |
| CAST JOB | 4 | 4 | 1 | 0.33 | +21 | +20.8 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +26 | +25.6 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| DEFENSIVE ARMY | 2 | 2 | 1 | 0.33 | -39 | -39.4 |
| FEATURE BUFFS | 11 | 11 | 1 | 0.33 | +1 | +0.8 |
| HIS TURN DENIED | 4 | 4 | 1 | 0.33 | +165 | +165.0 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +106 | +106.2 |
| LONG SHOT | 1 | 1 | 1 | 0.33 | +5 | +5.3 |
| MISSILES NEXT TURN | 16 | 12 | 1 | 0.33 | +0 | +0.0 |
| NEARER NOT NEEDED | 63 | 60 | 1 | 0.33 | +8 | +8.4 |
| NEXT OBJECTIVE NEARER | 1 | 1 | 1 | 0.33 | +5 | +5.0 |
| ONE FIGHT FORMULA | 19 | 17 | 1 | 0.33 | +2 | +2.0 |
| ONE OBJECTIVE FORMULA | 25 | 24 | 1 | 0.33 | +116 | +115.8 |
| OVERRUNS AWAY | 2 | 2 | 1 | 0.33 | +5 | +5.3 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +72 | +72.2 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -8 | -7.9 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +45 | +45.2 |
| SET UP TOGETHER | 5 | 5 | 1 | 0.33 | +10 | +10.5 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -18 | -17.5 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +36 | +36.3 |
| CANNON PLAN MISSED | 4 | 4 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 4 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAFF IN THE MOVE | 6 | 6 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 11 | 11 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 66 | 66 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 4 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 5 | 5 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 30 | not checked | - | - | - | - |
| FOOT FIRST | 54 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 15 | 15 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 8 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 50 | 48 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 89 | 84 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 18 | 18 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 19 | 19 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 15 | 15 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 24 | 24 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 104 | 104 | 0 | 0.00 | - | - |
| HONEST WORTH | 4 | 4 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 19 | 19 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 4 | 4 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MANOEUVRE | 16 | 16 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 12 | 8 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NEAREST TO GOAL | 2 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 5 | 5 | 0 | 0.00 | - | - |
| NO LATE CUT | 6 | 6 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 318 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 9 | 9 | 0 | 0.00 | - | - |
| RISK BY ARC | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 4 | 4 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 105 | not checked | - | - | - | - |
| SPELL WORTH | 24 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 25 | 19 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 13 | 13 | 0 | 0.00 | - | - |
| STANDS STILL | 453 | 449 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 12 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 19 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 10 | not checked | - | - | - | - |
| THE TABLE BINDS | 319 | not checked | - | - | - | - |
| TIED UP BY THE SUM | 1 | 1 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 6 | 6 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 27 | 27 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p88

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.00 | 2.33 | 22.5 |
| ARMY TABLE | rule | 1.33 | 3.00 | 101.1 |
| PROMISE BY ITS OWN SUM | rule | 0.67 | 0.67 | 10.1 |
| HOLDER ASSIGNMENT | rule | 0.67 | 0.33 | 24.2 |
| RULE SWITCHED OFF | gate | - | 1.00 | 15.8 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.67 | 2.2 |
| DEFENSIVE ARMY | rule | 0.33 | - | 39.4 |
| JOINT CHARGE NOW | rule | - | 0.33 | 26.2 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 7.9 |
| SUPPORT NARROWED | rule | 0.33 | - | 17.5 |

### Plans: gs3-83c8646-p88

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.3 | 100% | 11 | 57 | 512% |
| Mine | move | 39.7 | 97% | 899 | 0 | 0% |
| Mine | shoot | 21.3 | 69% | 630 | 1014 | 161% |
| Opponent | charge | 0.7 | 50% | 78 | 25 | 32% |
| Opponent | move | 36.3 | 98% | 1422 | 0 | 0% |
| Opponent | shoot | 7.7 | 61% | 378 | 632 | 167% |

### Battle groups: gs3-83c8646-p88

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 3.0 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p88

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 10 | 32 (10) | 32 | 0 | 49 | 40% | 2.5 | 80 (3) | 0 (5) | 0 (2) | 0 (8) | 93 (2) |
| Mine | Clean-up | 4 | 0 (4) | 0 | 0 | 20 | 50% | 1.5 | - | 0 (2) | 0 (2) | 0 (4) | - |
| Mine | Fast | 2 | 137 (2) | 137 | 0 | 0 | 50% | 1.0 | - | - | 137 (2) | 137 (2) | - |
| Mine | Fast Hammer | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | 0 (2) | 0 (1) | - | 0 (2) | 0 (1) |
| Mine | Hammer | 3 | 26 (3) | 0 | 26 | 0 | 100% | - | - | 36 (1) | 0 (2) | 30 (2) | 0 (1) |
| Mine | Shooter | 10 | 31 (10) | 19 | 13 | 7 | 0% | 2.3 | 32 (1) | 0 (4) | 46 (5) | 47 (7) | 0 (3) |
| Mine | War machine | 15 | 4 (15) | 4 | 0 | 7 | 13% | 1.7 | 19 (3) | - | 0 (12) | 11 (5) | 0 (10) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | - | 0 (2) | 0 (1) | 0 (1) | 0 (2) |
| Opponent | Character | 10 | 19 (10) | 19 | 0 | 22 | 70% | 1.3 | 35 (4) | 11 (3) | 0 (3) | 29 (6) | 10 (4) |
| Opponent | Clean-up | 2 | 75 (2) | 0 | 75 | 0 | 100% | - | - | 75 (2) | - | - | 75 (2) |
| Opponent | Fast Hammer | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | 0 (2) | 0 (1) | - | 0 (3) | - |
| Opponent | Hammer | 1 | 45 (1) | 45 | 0 | 100 | 0% | 5.0 | - | 45 (1) | - | 45 (1) | - |
| Opponent | Holder | 3 | 67 (3) | 0 | 67 | 0 | 67% | 5.0 | 44 (1) | 77 (2) | - | 102 (2) | 0 (1) |
| Opponent | Shooter | 4 | 69 (4) | 69 | 0 | 23 | 0% | 1.0 | 128 (2) | 0 (2) | - | 69 (4) | - |
| Opponent | War machine | 6 | 0 (6) | 0 | 0 | 11 | 17% | 2.0 | - | 0 (3) | 0 (3) | 0 (2) | 0 (4) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | 0 (1) | 0 (1) | 0 (1) |

### Charged fights: gs3-83c8646-p88

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 2 | 214 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Empire of Man | 1 | 512 | 0 | 1.0 | 1.0 | 0 | 281 | -281 | 1 of 1 | 1 of 1 | - | -281 |
| **Mine** | all armies | 3 | 314 | 0 | 0.3 | 1.0 | 0 | 281 | -281 | 1 of 1 | 1 of 1 | - | -281 |
| Opponent | Empire of Man | 1 | 225 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 1 | 380 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Vampire Counts | 1 | 105 | 0 | 2.0 | 1.5 | 0 | 0 | +0 | 1 of 2 | 2 of 2 | +0 | +0 |
| **Opponent** | all armies | 3 | 237 | 0 | 1.0 | 1.3 | 0 | 0 | +0 | 1 of 3 | 3 of 3 | +0 | +0 |

### Effective charges: gs3-83c8646-p88

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 1 | 0 | 0 | 1 (net -281) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | High Elf Realms | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | Vampire Counts | 2 | 0 | 0 | 0 | 0 | 1 (net +0) | 1 (net +0) | 0 | 0% (0 of 2) |

### Charged fights, damage counted: gs3-83c8646-p88

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 181 | 400 | -281 | 171 | 281 | -110 | -60.5 |
| Mine | All fights | 1 | 181 | 400 | -281 | 171 | 281 | -110 | -60.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 258 | 132 | +0 | 14 | 24 | -10 | -4.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 755 | 105 | +0 | 0 | 118 | -118 | -15.6 |
| Opponent | All fights | 3 | 423 | 123 | +0 | 9 | 55 | -46 | -10.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p88 | move | 13 | 1 (8%) | 1 (8%) | 2 (15%) | 10 (77%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0624 |
| Invocation of Nehek | Opponent | L0624 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Twice-Blessed Armour | Mine | L0713 |
| Witch Hunter's Ward | Mine | L0713 |
| Witch Hunter's Ward | Opponent | L0608 |

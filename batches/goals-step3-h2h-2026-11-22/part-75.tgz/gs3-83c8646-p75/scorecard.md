# Doctrine scorecard: gs3-83c8646-p75

### Scorecard: gs3-83c8646-p75

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0413 | 5 | 1 | Mine | yes | - | 5 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | yes | - | 4 | 1 | 2 | 1 | 0 | 0 | 140 |
| L0429 | 3 | 1 | Mine | no | 6 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 6 | 4 | 1 | 2 | 1 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 1215 |
| L0516 | 6 | 1 | Opponent | no | 17 | 6 | 1 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 3.0 | 3.0 | 1.7 | 1.3 | 0.0 | 0.0 | 0.0 | 405.0 |
| **Average** | | | Opponent | 33% | 11.5 | 4.7 | 1.0 | 2.0 | 0.7 | 0.0 | 0.0 | 103.3 |

### KPIs: gs3-83c8646-p75

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 36% (5 of 14) | 0% (0 of 16) | 17% (5 of 30) |
| Winner chose to follow up after the loser gave ground |  | 67% (2 of 3); on the table 67% | 100% (2 of 2); on the table 100% | 80% (4 of 5); on the table 80% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | 100% (1 of 1); on the table 100% | 50% (1 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 50% (2 of 4); on the table 50% | 100% (3 of 3); on the table 100% | 71% (5 of 7); on the table 71% |
| Magic missiles tried each own turn | 50%+ | 50% (6 of 12) | 67% (4 of 6) | 56% (10 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 50% (6 of 12) | 67% (4 of 6) | 56% (10 of 18) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 0% (0 of 1) | 0% (0 of 1) |
| Points that never fought | lower | 74% (4430 of 5998) | 67% (4024 of 5999) | 70% (8454 of 11997) |
|   infantry points that never fought | lower | 92% (1309 of 1424) | 81% (1348 of 1671) | 86% (2657 of 3095) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 52% (12 of 23) | 62% (13 of 21) | 57% (25 of 44) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (1 of 1); 1.7 uses a game | 100% (1 of 1); 0.8 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game | 50% (1 of 2); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 54% (2765 of 5120) | 59% (3132 of 5324) | 56% (5897 of 10444) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (67%) | 0.3 (50%) | 1.7 (62%) |
| MARCHED: its unit marched | 0.3 (17%) | 0.3 (50%) | 0.7 (25%) |
| CHARGED: its unit charged | 0.3 (17%) | 0.0 (0%) | 0.3 (12%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 7.7 | 2.0 | 3.3 | 0.7 | 0.0 |
| not cast | 2.3 | 2.0 | 2.7 | 1.3 | 12.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (17%) | 1.7 (62%) | 0.7 (50%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.7 (25%) | 0.3 (25%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.3 (12%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (17%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.7 (29%) | 0.0 (0%) | 0.0 (0%) | 0.3 (25%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (71%) | 1.7 (83%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 9.7 (81%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.3 a game | 1.7 a game | 1.0 a game |
| stood (cast and not dispelled) | 100% (1 of 1) | 100% (5 of 5) | 100% (6 of 6) |
| the unit moved after it | 100% (1 of 1) | 40% (2 of 5) | 50% (3 of 6) |
| it charged on its next turn | 0% (0 of 1) | 0% (0 of 5) | 0% (0 of 6) |
| the enemy charged it first | 0% (0 of 1) | 20% (1 of 5) | 17% (1 of 6) |
| it fought by the end of its next turn | 0% (0 of 1) | 0% (0 of 5) | 0% (0 of 6) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 1) | 0% (0 of 5) | 0% (0 of 6) |
| none of these (no charge, no fight, no charge escaped) | 100% (1 of 1) | 80% (4 of 5) | 83% (5 of 6) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 78% (72 of 92) | 59% (39 of 66) | 70% (111 of 158) |
|   cavalry | 80% (8 of 10) | 67% (6 of 9) | 74% (14 of 19) |
|   character | 85% (17 of 20) | 47% (8 of 17) | 68% (25 of 37) |
|   chariot | 61% (14 of 23) | - | 61% (14 of 23) |
|   infantry | 50% (6 of 12) | 69% (11 of 16) | 61% (17 of 28) |
|   war machine | 100% (27 of 27) | 58% (14 of 24) | 80% (41 of 51) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (30%) | 2.0 (22%) | 4.0 (26%) |
| CHARGED: it charged | 0.0 (0%) | 0.7 (7%) | 0.7 (4%) |
| IN COMBAT: it fought this turn or the last | 0.3 (5%) | 0.0 (0%) | 0.3 (2%) |
| MOVED: a war machine that moved | 0.0 (0%) | 1.3 (15%) | 1.3 (9%) |
| NO TARGET IN RANGE | 2.0 (30%) | 2.0 (22%) | 4.0 (26%) |
| ONLY IN COMBAT: the only targets were in combat | 1.3 (20%) | 0.0 (0%) | 1.3 (9%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (15%) | 3.0 (33%) | 4.0 (26%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.0 | 0.3 | 93% | 1.0 pts | 5 pts |
| character | 10.7 | 5.3 | 72% | 9.8 pts | 104 pts |
| chariot | 4.7 | 5.0 | 50% | 46.5 pts | 217 pts |
| infantry | 10.7 | 4.3 | 75% | 10.3 pts | 110 pts |
| war machine | 13.7 | 9.0 | 78% | 24.5 pts | 335 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.7 | 2.7 | 2.2 |
| Charges that made contact a game | 0.7 | 2.3 | 1.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (1 units) | 0.33 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.18 declared, 0.09 contact (22 units) | 0.38 declared, 0.33 contact (21 units) | 0.28 declared, 0.21 contact (43 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | 100% (2 of 2) | - | 67% (4 of 6) |
| Character in a unit | 67% (2 of 3) | 100% (1 of 1) | - | 75% (3 of 4) |
| Character on its own | 100% (1 of 1) | 50% (3 of 6) | 83% (5 of 6) | 69% (9 of 13) |
| Chariot | - | 25% (1 of 4) | - | 25% (1 of 4) |
| Infantry | 60% (6 of 10) | 17% (1 of 6) | - | 44% (7 of 16) |
| Monster | 100% (1 of 1) | - | - | 100% (1 of 1) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 2 | 67% (2 of 3); on the table 67% | 50% (6 of 12) | 67% | 50% (8 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Dwarfen Mountain Holds | 1 | 0% (0 of 1); on the table 0% | - | 87% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| High Elf Realms | 1 | - | 67% (4 of 6) | 92% | 88% (7 of 8) | 100% (1 of 1); 5.0 uses a game | 50% (1 of 2); 1.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (1 of 1); on the table 100% | - | 68% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 1 | 100% (2 of 2); on the table 100% | - | 40% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p75, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (3) | 0% (0) | 43% (3) |
| ...free all their last turn and able to turn (per game) | 1.00 | 0.00 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.00 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p75

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.0 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 40% (2 of 5) | 75% (6 of 8) |
| Strategy | Shoot objectives carried out (shot that target) | 30% (13 of 43) | 47% (8 of 17) |
| Strategy | Joined characters whose unit fought | 0% (0 of 5) | - |
| Strategy | Lone characters that fought | 50% (3 of 6) | 33% (3 of 9) |
| Movement | Charges halted short of contact | 0.3 | 0.3 |
| Movement | Idle units | 1.3 | 2.0 |
| Movement | Points that never moved of their own | 405.0 | 103.3 |
| Movement | Fights charged into per game | 0.7 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 2 | 2 of 7, net +48 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | 0 of 7 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 2 | 1 of 7, net +0 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 2, net +0 | 3 of 7, net +142 |
| Shooting | Shots by shooting units (incl. breath weapons) | 15.0 | 8.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 67% (30 of 45) | 62% (16 of 26) |
| Shooting | Points destroyed by shooting units | 477.7 | 0.0 |
| Shooting | War machine shots | 9.0 | 4.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 78% (21 of 27) | 71% (10 of 14) |
| Shooting | Points destroyed by war machines | 157.0 | 31.7 |
| Magic | Magic missiles cast | 1.3 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 50% (2 of 4) | 100% (4 of 4) |
| Magic | Wounds caused by magic missiles | 2.0 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.3 / 0.0 / 0.0 / 0.3 | 2.7 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 56.7 | 142.3 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +293 | +83 |
| Combat | Net per 100 charger points, damage counted | +150.4 | +26.2 |
| Combat | First round won (charged fights) | 100% | 86% |
| Combat | Net points per charged fight | +85 | +91 |
| Combat | Net points per supported fight / lone fight | - / +85 | - / +91 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 2 | 3 of 7 |
| Game | Points lost | 274.7 | 632.0 |
| Game | VP from objectives | 803.3 | 466.7 |
| Game | Lone holders (player turns) | 3.0 | 11.5 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +766 VP
- The side that went first won 2 of 2 games with a winner
- Points traded per game (both sides' losses): 907
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p75

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +11.9 | 0.0 | 103.3 | - | - | - | - |
| ARMY TABLE | 17.7 | +79.5 | 0.0 | 252.7 | 24.3 | +14.5 | 0.0 | 304.3 |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +3.0 | 0.0 | 0.0 | 0.3 | +0.2 | 0.0 | 0.0 |
| BEST PRIZE | 0.3 | -32.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 2.0 | +0.0 | 330.7 | 31.7 | - | - | - | - |
| CANNON PLANNED TARGET | 7.7 | +116.7 | 756.7 | 190.0 | 4.7 | +26.6 | 31.7 | 0.0 |
| CANNON SIGHT KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 0.7 | +109.5 | 294.7 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.7 | +7.1 | 0.0 | 0.0 | 0.3 | +10.0 | 0.0 | 10.0 |
| CHAFF PASSED | 1.3 | -4.1 | 0.0 | 0.0 | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -21.9 | 0.0 | 0.0 |
| CHARACTER GUNS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 7.3 | -240.8 | 0.0 | 78.0 | 19.3 | -1050.1 | 0.0 | 1076.7 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 392.0 | 103.3 | 1.0 | +0.0 | 206.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 9.0 | +0.0 | 0.0 | 0.0 | 9.7 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 103.3 | 0.3 | +0.0 | 0.0 | 56.7 |
| CONVEYANCE SEARCH | 0.3 | +0.2 | 0.0 | 0.0 | 1.7 | +272.9 | 147.3 | 0.0 |
| COVER ONCE | 8.7 | -702.4 | 0.0 | 63.3 | 6.7 | -310.5 | 0.0 | 40.7 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -1.1 | 31.7 | 0.0 |
| DEPLOY BY FIGURES | 8.3 | -70.5 | 0.0 | 0.0 | 7.3 | -39.1 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | 0.3 | +27.1 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 1.7 | +7.4 | 124.0 | 0.0 | 2.0 | +5.1 | 314.7 | 0.0 |
| FALL BACK GOOD ORDER | 1.0 | +0.0 | 67.3 | 0.0 | 2.0 | +0.0 | 275.7 | 0.0 |
| FALLS SHORT | - | - | - | - | 21.7 | +275.2 | 0.0 | 104.0 |
| FEATURE BUFFS | - | - | - | - | 1.3 | +1.9 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +0.1 | 40.7 | 0.0 | - | - | - | - |
| FIRE IN ORDER | 0.7 | +0.0 | 26.7 | 31.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 105.0 | +7426.5 | 4363.3 | 817.3 | 86.7 | +3748.8 | 378.0 | 1692.0 |
| FLANK NOT WEIGHED | 10.0 | +0.0 | 0.0 | 181.3 | 5.3 | +0.0 | 0.0 | 197.7 |
| FOCUS FIRE | 0.3 | +9.3 | 26.7 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.7 | +111.2 | 0.0 | 0.0 | 0.3 | +132.1 | 0.0 | 0.0 |
| FOOT FIRST | 26.3 | +0.0 | 0.0 | 140.7 | - | - | - | - |
| FOUR ROUNDS | 1.7 | +58.7 | 124.0 | 0.0 | 2.7 | +227.1 | 314.7 | 0.0 |
| FREED FROM HIS FIGHT | 3.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 1.3 | -64.6 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | - | - | - | - | 0.3 | -19.3 | 31.7 | 0.0 |
| GOAL WALK | 8.3 | +387.9 | 0.0 | 0.0 | 7.3 | +391.0 | 0.0 | 0.0 |
| GUN FIGURES | 2.3 | +43.3 | 320.0 | 0.0 | - | - | - | - |
| GUN MASK | 0.7 | +16.2 | 0.0 | 0.0 | 1.0 | +52.0 | 0.0 | 0.0 |
| HARD STAY DROPPED | 4.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 3.7 | +0.0 | 0.0 | 78.0 | 8.7 | +0.0 | 0.0 | 542.7 |
| HIS CHARGE LIST | 12.0 | +0.0 | 0.0 | 74.7 | 6.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 5.3 | +0.0 | 0.0 | 103.3 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.0 | -8.1 | 0.0 | 0.0 | 5.0 | -271.0 | 0.0 | 457.3 |
| HIS ONE QUARTER | 5.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 7.7 | +0.0 | 0.0 | 103.3 | 6.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 48.7 | +1678.1 | 0.0 | 230.7 | 49.7 | +4022.2 | 0.0 | 1011.0 |
| HIS SHOTS BY HIS RUN | 23.3 | +417.4 | 0.0 | 178.0 | 43.0 | +1578.4 | 0.0 | 1406.7 |
| HIS TURN DENIED | 0.3 | +0.7 | 26.7 | 0.0 | 0.3 | +16.6 | 31.7 | 0.0 |
| HOLD ODDS | 16.3 | +0.0 | 0.0 | 0.0 | 16.0 | +0.0 | 0.0 | 134.7 |
| HOLDER ASSIGNMENT | 11.3 | +857.6 | 0.0 | 0.0 | 9.0 | +956.5 | 0.0 | 67.3 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.7 | -28.0 | 124.0 | 0.0 | 2.3 | -73.0 | 314.7 | 0.0 |
| HUNT IN PAIRS | 0.7 | +3.3 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | - | - | - | - | 11.7 | -251.5 | 0.0 | 745.3 |
| KEPT FROM ITS LAST STOP | 3.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 53.3 |
| LANE BY FIGURES | 1.0 | +28.3 | 0.0 | 0.0 | 1.7 | +26.3 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 1.0 | +0.0 | 0.0 | 310.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.3 | +20.0 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +3.0 | 26.7 | 0.0 | 0.3 | +5.6 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.0 | +18.8 | 67.3 | 0.0 | 1.7 | +2.3 | 140.7 | 0.0 |
| MANOEUVRE | 1.7 | -1.9 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +33.1 | 0.0 | 0.0 | 0.3 | +18.0 | 0.0 | 0.0 |
| MARCH CHECK | 1.3 | +49.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | -33.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.3 | +61.4 | 0.0 | 103.3 | 0.3 | +4.5 | 0.0 | 0.0 |
| MEETS IN TIME | 2.7 | +138.5 | 0.0 | 0.0 | 3.3 | +217.9 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.7 | +118.4 | 0.0 | 0.0 | 3.0 | +16.1 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 2.7 | +103.5 | 0.0 | 0.0 | 3.3 | +16.6 | 0.0 | 0.0 |
| MOVE ORDER | 2.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 2.0 | +83.8 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 147.3 |
| MOVE TO CHARGE COMPUTED | 5.0 | +509.6 | 0.0 | 0.0 | 6.0 | +464.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 9.3 | +401.3 | 0.0 | 37.3 | 3.3 | +173.4 | 0.0 | 40.7 |
| NEAREST TO GOAL | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 3.3 | +394.2 | 0.0 | 0.0 | 4.7 | +341.7 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.7 | -110.3 | 124.0 | 0.0 | 2.3 | -123.8 | 314.7 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO RALLY LEFT | - | - | - | - | 0.3 | +14.8 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 5.0 | -198.8 | 0.0 | 166.7 | 2.3 | -68.7 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 40.7 |
| ONE FIGHT FORMULA | 4.3 | -93.2 | 0.0 | 0.0 | 3.7 | -64.7 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 4.0 | -59.2 | 0.0 | 0.0 | 3.0 | +62.2 | 0.0 | 40.7 |
| ONE PROMISE A TARGET | 1.0 | -11.8 | 0.0 | 0.0 | 0.7 | -42.6 | 0.0 | 0.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.7 | +1.1 | 26.7 | 0.0 | 0.7 | +38.0 | 206.7 | 0.0 |
| PLAN RESULT | 46.0 | +1660.7 | 625.3 | 549.3 | 38.0 | +246.1 | 103.3 | 1397.3 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 7.0 | -157.9 | 0.0 | 0.0 | 7.0 | -170.5 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | -7.0 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 19.3 | +2011.8 | 0.0 | 0.0 | 13.0 | +1479.8 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 0.3 | +0.0 | 0.0 | 56.7 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.7 | -9.2 | 0.0 | 0.0 | 0.3 | +37.0 | 0.0 | 10.0 |
| REDIRECT FOR A FRIEND IN REACH | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 10.0 |
| REDIRECT WEIGHED | 0.3 | -32.0 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 0.7 | -10.6 | 0.0 | 0.0 | 1.3 | -0.3 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.7 | +0.9 | 0.0 | 26.7 |
| RESTRAINS TO SHOOT | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.0 | -32.6 | 83.3 | 0.0 | 1.7 | -0.4 | 275.7 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.3 | -6.1 | 40.7 | 0.0 | 0.3 | -7.1 | 31.7 | 0.0 |
| RUN DOWN | 1.3 | -14.9 | 67.3 | 0.0 | 1.0 | -13.2 | 37.3 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.7 | +2.7 | 0.0 | 0.0 | 0.3 | -21.5 | 0.0 | 10.0 |
| SEARCH SPOT | 1.0 | +23.6 | 0.0 | 0.0 | 1.0 | -0.2 | 0.0 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 0.3 | -0.2 | 0.0 | 10.0 |
| SET UP BY THE SET | - | - | - | - | 1.0 | -40.4 | 0.0 | 10.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +37.2 | 147.3 | 0.0 |
| SHOOTER COUNTED ONCE | 0.7 | -7.3 | 0.0 | 0.0 | 0.3 | -0.9 | 0.0 | 10.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 15.0 | +0.0 | 0.0 | 293.3 | 6.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.7 | +103.3 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 0.7 | -14.9 | 26.7 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 23.3 | +818.0 | 0.0 | 152.7 | 29.7 | -459.7 | 0.0 | 955.0 |
| SHOTS AFTER THE MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 19.7 | +1105.8 | 0.0 | 330.7 | 14.0 | +341.6 | 0.0 | 26.7 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +37.2 | 147.3 | 0.0 |
| SPELL WORTH | 0.3 | +5.2 | 0.0 | 0.0 | 3.3 | +110.4 | 112.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | -0.5 | 0.0 | 0.0 | 0.3 | +2.5 | 37.3 | 0.0 |
| SPOT AS THE GAME MOVES | 4.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 174.0 |
| STAND AND SHOOT | 0.7 | -1.6 | 26.7 | 0.0 | 0.3 | -3.6 | 37.3 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 63.3 | +0.0 | 4239.3 | 817.3 | 32.7 | +0.0 | 63.3 | 56.7 |
| STAY WORTH | 34.0 | +536.4 | 3092.7 | 322.3 | 18.7 | +48.1 | 0.0 | 26.7 |
| SUPPORT ADDS | 4.7 | +363.9 | 0.0 | 0.0 | 2.7 | +302.5 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 103.3 | - | - | - | - |
| SUPPORT WORKED OUT | 4.7 | +363.9 | 0.0 | 0.0 | 2.7 | +302.5 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +7.1 | 0.0 | 0.0 | - | - | - | - |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +5.6 | 0.0 | 26.7 |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 3.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 50.3 | +0.0 | 0.0 | 408.7 | 38.3 | +0.0 | 0.0 | 822.7 |
| TIED UP BY THE SUM | 0.3 | +40.4 | 40.7 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 57.0 | +673.0 | 133.3 | 374.7 | - | - | - | - |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -9.8 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 2.3 | +0.0 | 884.0 | 103.3 | - | - | - | - |
| WHO FIGHTS | - | - | - | - | 0.3 | -1.8 | 37.3 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +40.7 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.0 | -161.1 | 0.0 | 78.0 | 1.7 | -157.1 | 0.0 | 385.7 |
| WOUNDS ON THE RANKS | 0.7 | +22.4 | 0.0 | 0.0 | 2.7 | +27.1 | 0.0 | 224.0 |

### Rule changes: gs3-83c8646-p75

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 126 | 126 | 96 | 32.00 | +1154 | +12.0 |
| HIS SHOT LIST | 295 | 289 | 73 | 24.33 | +2395 | +32.8 |
| HOLDER ASSIGNMENT | 61 | 61 | 57 | 19.00 | +3078 | +54.0 |
| HIS SHOTS BY HIS RUN | 199 | 191 | 42 | 14.00 | +933 | +22.2 |
| SHOT RISK POINTS | 159 | 158 | 40 | 13.33 | +533 | +13.3 |
| DEPLOY BY FIGURES | 47 | 47 | 31 | 10.33 | +372 | +12.0 |
| TIME ON OUR SIDE | 171 | 156 | 26 | 8.67 | +105 | +4.0 |
| FIVE ACTION | 575 | 563 | 22 | 7.33 | +899 | +40.9 |
| OFF BEST | 22 | 22 | 22 | 7.33 | -802 | -36.5 |
| THE TABLE AGAIN | 36 | 36 | 21 | 7.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 33 | 31 | 20 | 6.67 | +810 | +40.5 |
| QUARTER ODDS | 97 | 97 | 19 | 6.33 | +1077 | +56.7 |
| HARD STAY DROPPED | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 24 | 24 | 15 | 5.00 | +663 | +44.2 |
| PROMISE BY ITS OWN SUM | 42 | 42 | 13 | 4.33 | -985 | -75.8 |
| GOAL WALK | 47 | 45 | 12 | 4.00 | +614 | +51.2 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| COVER ONCE | 46 | 36 | 10 | 3.33 | +215 | +21.5 |
| CANNON SIGHT KEPT | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| FOUR ROUNDS | 13 | 13 | 8 | 2.67 | +303 | +37.9 |
| LANE BY FIGURES | 8 | 8 | 8 | 2.67 | +164 | +20.5 |
| SUPPORT ADDS | 22 | 22 | 8 | 2.67 | +623 | +77.9 |
| SUPPORT WORKED OUT | 22 | 22 | 8 | 2.67 | +623 | +77.9 |
| MEETS IN TIME | 18 | 18 | 7 | 2.33 | +19 | +2.8 |
| REDIRECT FOR A FRIEND IN REACH | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| STAY WORTH | 158 | 140 | 6 | 2.00 | +79 | +13.2 |
| MISSILES IN THE MOVE | 17 | 10 | 5 | 1.67 | +243 | +48.6 |
| ONE PROMISE A TARGET | 5 | 5 | 5 | 1.67 | -163 | -32.6 |
| SHOOTS FROM THE BEST SPOT | 8 | 8 | 5 | 1.67 | +17 | +3.3 |
| ARTILLERY RE-ROLL WEIGHED | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHAFF PASSED | 4 | 4 | 4 | 1.33 | -12 | -3.1 |
| CHARGE LOSSES | 80 | 79 | 4 | 1.33 | +22 | +5.6 |
| LEGAL CHARGES ONLY | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| MAX FOR POSITIONING | 8 | 8 | 4 | 1.33 | +99 | +24.8 |
| CANNON PLANNED TARGET | 37 | 37 | 3 | 1.00 | +0 | +0.0 |
| FIRE IN ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +730 | +243.3 |
| IDLE COST | 35 | 24 | 3 | 1.00 | +54 | +17.9 |
| MARCH CHECK | 4 | 4 | 3 | 1.00 | +16 | +5.2 |
| SEARCH SPOT | 6 | 6 | 3 | 1.00 | +71 | +23.6 |
| SHOTS AFTER THE MOVES | 20 | 20 | 3 | 1.00 | +0 | +0.0 |
| CAST JOB | 2 | 2 | 2 | 0.67 | +73 | +36.5 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| GUN MASK | 5 | 5 | 2 | 0.67 | +36 | +18.2 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +154 | +76.8 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +3 | +1.4 |
| RISK BY ARC | 8 | 8 | 2 | 0.67 | +41 | +20.6 |
| SET UP BY THE SET | 3 | 3 | 2 | 0.67 | +230 | +114.9 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| SHOTS IN THE MOVE | 101 | 75 | 2 | 0.67 | +66 | +33.2 |
| WHOLE FIGHT DANGER | 11 | 11 | 2 | 0.67 | +359 | +179.4 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +36 | +35.8 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -96 | -95.9 |
| CHAFF IN THE MOVE | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 9 | 9 | 1 | 0.33 | -7 | -7.2 |
| EVASIVE BY THE ODDS | 1 | 1 | 1 | 0.33 | +81 | +81.2 |
| FALLS SHORT | 65 | 49 | 1 | 0.33 | +7 | +7.0 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +28 | +28.0 |
| HIS MOVE AND SHOT | 24 | 24 | 1 | 0.33 | +1 | +0.6 |
| HIS TURN DENIED | 2 | 2 | 1 | 0.33 | +6 | +6.5 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +60 | +60.0 |
| LOST AFTER ESCAPE | 8 | 8 | 1 | 0.33 | +35 | +34.8 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.33 | +18 | +17.8 |
| ONE FIGHT FORMULA | 24 | 15 | 1 | 0.33 | +0 | +0.0 |
| PROMISE KNOWS THE FIGHT | 1 | 1 | 1 | 0.33 | -21 | -21.0 |
| REDIRECT COUNTER | 6 | 3 | 1 | 0.33 | +22 | +22.2 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +163 | +162.8 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -62 | -62.3 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +55 | +55.3 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -277 | -277.4 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +17 | +16.7 |
| THE ROW IN ITS ORDER | 19 | 1 | 1 | 0.33 | +0 | +0.0 |
| TIED UP BY THE SUM | 1 | 1 | 1 | 0.33 | +16 | +15.9 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -29 | -29.4 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +72 | +72.2 |
| BACKUP TARGETS | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 6 | 6 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 6 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 3 | 3 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 56 | 55 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 6 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 11 | 11 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 9 | 9 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 46 | not checked | - | - | - | - |
| FOOT FIRST | 79 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 21 | 19 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 7 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 12 | 10 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 37 | 36 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 56 | 52 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 25 | 24 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 30 | 30 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 43 | 40 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 6 | 6 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 97 | 97 | 0 | 0.00 | - | - |
| HONEST WORTH | 12 | 12 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 16 | 16 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| MANOEUVRE | 9 | 9 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 5 | 5 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 18 | 12 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 6 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 6 | not checked | - | - | - | - |
| NEARER NOT NEEDED | 38 | 38 | 0 | 0.00 | - | - |
| NEAREST TO GOAL | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 12 | 12 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 21 | 16 | 0 | 0.00 | - | - |
| ONE ROUTE | 5 | 5 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 4 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 252 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| RANDOM MOVE BY FIGURES | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 5 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 6 | 6 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 7 | 7 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 64 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 11 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 32 | 27 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 6 | 6 | 0 | 0.00 | - | - |
| STANDS STILL | 288 | 282 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 14 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 7 | not checked | - | - | - | - |
| THE TABLE BINDS | 266 | not checked | - | - | - | - |
| WAITS AGAIN | 5 | 5 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 7 | 7 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 10 | 10 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p75

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.33 | 2.33 | 29.8 |
| ARMY TABLE | rule | 1.33 | 4.67 | 36.3 |
| PROMISE BY ITS OWN SUM | rule | 2.33 | 2.00 | 75.8 |
| ONE PROMISE A TARGET | rule | 1.00 | 0.67 | 32.6 |
| HOLDER ASSIGNMENT | rule | 0.67 | 0.33 | 38.2 |
| NO REASON | gate | 0.67 | - | 103.2 |
| BEST PRIZE | rule | 0.33 | - | 95.9 |
| CHAFF PASSED | rule | 0.33 | - | 12.3 |
| CHARGE NOW FIRST | rule | - | 0.33 | 7.2 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | - | 21.0 |
| REFUSING RETIRES | rule | - | 0.33 | 62.3 |
| SUPPORT NARROWED | rule | 0.33 | - | 277.4 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 29.4 |

### Plans: gs3-83c8646-p75

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 50% | 165 | 113 | 69% |
| Mine | join | 0.3 | 100% | 11 | 0 | 0% |
| Mine | move | 32.0 | 99% | 1747 | 0 | 0% |
| Mine | shoot | 12.0 | 67% | 869 | 1547 | 178% |
| Mine | support | 0.3 | 100% | 9 | 0 | 0% |
| Opponent | charge | 1.7 | 60% | 192 | 231 | 120% |
| Opponent | move | 31.7 | 93% | 1472 | 0 | 0% |
| Opponent | shoot | 4.3 | 8% | 85 | 15 | 17% |
| Opponent | support | 0.3 | 0% | 0 | 0 | - |

### Battle groups: gs3-83c8646-p75

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.7 | 40% | 0% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p75

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 3 | 0 (3) | 0 | 0 | 0 | 67% | 6.0 | 0 (2) | - | 0 (1) | 0 (3) | - |
| Mine | Character | 11 | 24 (11) | 24 | 0 | 5 | 18% | 2.9 | 27 (5) | 25 (5) | 0 (1) | 25 (7) | 24 (4) |
| Mine | Clean-up | 3 | 70 (3) | 0 | 70 | 33 | 33% | 1.5 | 103 (2) | 0 (1) | - | 214 (1) | 0 (2) |
| Mine | Hammer | 7 | 82 (7) | 62 | 20 | 18 | 0% | 2.1 | 10 (1) | 98 (6) | - | 68 (6) | 150 (1) |
| Mine | Holder | 5 | 79 (5) | 0 | 79 | 0 | 100% | - | 36 (2) | 129 (2) | 50 (1) | 73 (1) | 80 (4) |
| Mine | War machine | 5 | 99 (5) | 99 | 0 | 60 | 0% | 1.0 | 0 (2) | 165 (3) | - | - | 99 (5) |
| Opponent | Chaff | 3 | 32 (3) | 0 | 32 | 100 | 33% | 1.5 | - | 27 (2) | 38 (1) | 38 (1) | 27 (2) |
| Opponent | Character | 8 | 19 (8) | 19 | 0 | 50 | 38% | 3.8 | 17 (7) | - | 35 (1) | 18 (6) | 22 (2) |
| Opponent | Clean-up | 1 | 154 (1) | 0 | 154 | 0 | 100% | - | 154 (1) | - | - | 154 (1) | - |
| Opponent | Fast Hammer | 4 | 16 (4) | 16 | 0 | 0 | 50% | 5.0 | 37 (2) | 0 (2) | - | 74 (1) | 0 (3) |
| Opponent | Hammer | 3 | 25 (3) | 0 | 25 | 61 | 33% | 4.0 | 0 (1) | 32 (2) | - | 0 (1) | 32 (2) |
| Opponent | Holder | 3 | 34 (3) | 0 | 34 | 28 | 67% | 3.0 | 123 (1) | 0 (1) | 0 (1) | 123 (1) | 0 (2) |
| Opponent | Shooter | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.5 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | War machine | 4 | 28 (4) | 28 | 0 | 0 | 25% | 1.7 | 48 (2) | 0 (2) | - | 0 (1) | 35 (3) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | 0 (1) | - |

### Charged fights: gs3-83c8646-p75

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 468 | 85 | 0.5 | 1.0 | 170 | 0 | +170 | 0 of 1 | 1 of 1 | - | +170 |
| Mine | Dwarfen Mountain Holds | 1 | 967 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| **Mine** | all armies | 3 | 635 | 57 | 0.7 | 1.0 | 85 | 0 | +85 | 0 of 2 | 2 of 2 | - | +85 |
| Opponent | High Elf Realms | 1 | 0 | 112 | 1.0 | 1.0 | 112 | 0 | +112 | 0 of 1 | 1 of 1 | - | +112 |
| Opponent | Kingdom of Bretonnia | 1 | 95 | 212 | 2.0 | 1.0 | 106 | 0 | +106 | 0 of 2 | 2 of 2 | - | +106 |
| Opponent | Warriors of Chaos | 1 | 0 | 310 | 4.0 | 1.0 | 78 | 0 | +78 | 3 of 4 | 3 of 4 | - | +78 |
| **Opponent** | all armies | 3 | 32 | 211 | 2.3 | 1.0 | 91 | 0 | +91 | 3 of 7 | 6 of 7 | - | +91 |

### Effective charges: gs3-83c8646-p75

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 1 | 0 | 0 | 0 | 1 (net +170) | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Dwarfen Mountain Holds | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | High Elf Realms | 1 | 0 | 0 | 0 | 1 (net +112) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Kingdom of Bretonnia | 2 | 1 (net +95) | 0 | 0 | 0 | 0 | 1 (net +117) | 0 | 0% (0 of 2) |
| Opponent | Warriors of Chaos | 4 | 1 (net +0) | 0 | 0 | 0 | 1 (net +0) | 2 (net +155) | 0 | 0% (0 of 4) |

### Charged fights, damage counted: gs3-83c8646-p75

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 1 | 339 | 170 | +170 | 170 | 48 | +122 | +35.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 50 | 80 | +0 | 504 | 40 | +464 | +927.2 |
| Mine | All fights | 2 | 194 | 125 | +85 | 337 | 44 | +293 | +150.4 |
| Opponent | Long shot (under 50%) | 2 | 240 | 288 | +48 | 48 | 34 | +13 | +5.6 |
| Opponent | 76-89% | 1 | 151 | 112 | +112 | 112 | 0 | +112 | +74.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 422 | 246 | +142 | 142 | 6 | +137 | +32.4 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 323 | 65 | +0 | 32 | 0 | +32 | +10.1 |
| Opponent | All fights | 7 | 317 | 213 | +91 | 95 | 12 | +83 | +26.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p75 | move | 20 | 5 (25%) | 3 (15%) | 2 (10%) | 13 (65%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Standard of the Fell Warrior | Opponent | L0413 |

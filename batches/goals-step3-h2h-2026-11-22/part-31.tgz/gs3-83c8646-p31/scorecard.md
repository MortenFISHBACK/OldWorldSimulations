# Doctrine scorecard: gs3-83c8646-p31

### Scorecard: gs3-83c8646-p31

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1122 | 6 | 1 | Mine | no | 1 | 3 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1122 | 6 | 1 | Opponent | no | 2 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1216 | 4 | 1 | Mine | no | 0 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1216 | 4 | 1 | Opponent | no | 0 | - | 2 | 1 | 0 | 0 | 0 | 200 |
| L1232 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 165 |
| L1232 | 2 | 1 | Opponent | - | - | - | 0 | 5 | 0 | 0 | 0 | 340 |
| **Average** | | | Mine | 0% | 0.5 | 2.3 | 2.3 | 0.0 | 0.3 | 0.0 | 0.0 | 165.0 |
| **Average** | | | Opponent | 0% | 1.0 | 2.0 | 2.3 | 2.3 | 0.0 | 0.0 | 0.0 | 180.0 |

### KPIs: gs3-83c8646-p31

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 7% (1 of 15) | 0% (0 of 13) | 4% (1 of 28) |
| Winner chose to follow up after the loser gave ground |  | 67% (2 of 3); on the table 67% | 100% (3 of 3); on the table 100% | 83% (5 of 6); on the table 83% |
| Winner chose to pursue after the loser fell back in good order |  | - | 50% (1 of 2); on the table 100% | 50% (1 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 0% (0 of 2); on the table 0% | 0% (0 of 2); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 67% (2 of 3); on the table 67% | 57% (4 of 7); on the table 71% | 60% (6 of 10); on the table 70% |
| Magic missiles tried each own turn | 50%+ | 50% (30 of 60) | 33% (2 of 6) | 48% (32 of 66) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 61% (30 of 49) | 33% (2 of 6) | 58% (32 of 55) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 71% (5 of 7) | 71% (5 of 7) |
| Points that never fought | lower | 38% (2287 of 5999) | 52% (3141 of 5999) | 45% (5428 of 11998) |
|   infantry points that never fought | lower | 30% (194 of 656) | 46% (522 of 1127) | 40% (716 of 1783) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 54% (14 of 26) | 63% (12 of 19) | 58% (26 of 45) |
| Bound items with a magic missile used (at least once a game) |  | 100% (8 of 8); 9.3 uses a game | 0.0 uses a game | 100% (8 of 8); 4.7 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 33% (1 of 3); 0.3 uses a game | 100% (1 of 1); 0.3 uses a game | 50% (2 of 4); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 49% (2819 of 5807) | 61% (2964 of 4858) | 54% (5783 of 10665) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (13%) | 1.3 (100%) | 2.7 (24%) |
| MARCHED: its unit marched | 4.3 (43%) | 0.0 (0%) | 4.3 (38%) |
| CHARGED: its unit charged | 0.7 (7%) | 0.0 (0%) | 0.7 (6%) |
| IN COMBAT: engaged in combat | 2.7 (27%) | 0.0 (0%) | 2.7 (24%) |
| GONE: slain | 0.3 (3%) | 0.0 (0%) | 0.3 (3%) |
| OFF THE TABLE: off the table or not arrived | 0.7 (7%) | 0.0 (0%) | 0.7 (6%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.7 | 0.0 | 2.7 | 10.7 | 1.7 | 5.3 |
| not cast | 2.3 | 2.0 | 1.3 | 11.3 | 6.3 | 22.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (100%) | 0.0 (0%) | 2.7 (24%) | 1.7 (26%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.3 (38%) | 2.0 (32%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (6%) | 0.3 (5%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.7 (50%) | 2.7 (24%) | 1.0 (16%) | 0.0 (0%) |
| GONE: slain | 1.0 (43%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.3 (25%) | 0.7 (6%) | 0.3 (5%) | 0.7 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (16%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.3 (57%) | 0.0 (0%) | 0.3 (25%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 20.7 (91%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.7 a game | 0.0 a game | 1.3 a game |
| stood (cast and not dispelled) | 62% (5 of 8) | - | 62% (5 of 8) |
| the unit moved after it | 40% (2 of 5) | - | 40% (2 of 5) |
| it charged on its next turn | 0% (0 of 5) | - | 0% (0 of 5) |
| the enemy charged it first | 0% (0 of 5) | - | 0% (0 of 5) |
| it fought by the end of its next turn | 0% (0 of 5) | - | 0% (0 of 5) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 5) | - | 0% (0 of 5) |
| none of these (no charge, no fight, no charge escaped) | 100% (5 of 5) | - | 100% (5 of 5) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 80% (32 of 40) | 57% (48 of 84) | 65% (80 of 124) |
|   cavalry | - | 76% (13 of 17) | 76% (13 of 17) |
|   character | - | 0% (0 of 17) | 0% (0 of 17) |
|   chariot | 83% (5 of 6) | 67% (4 of 6) | 75% (9 of 12) |
|   infantry | 100% (5 of 5) | 59% (19 of 32) | 65% (24 of 37) |
|   war machine | 76% (22 of 29) | 100% (12 of 12) | 83% (34 of 41) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.3 (12%) | 0.3 (3%) | 0.7 (5%) |
| CHARGED: it charged | 0.0 (0%) | 2.0 (17%) | 2.0 (14%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.7 (6%) | 0.7 (5%) |
| MOVED: a war machine that moved | 1.0 (38%) | 0.0 (0%) | 1.0 (7%) |
| NO TARGET IN RANGE | 0.0 (0%) | 5.7 (47%) | 5.7 (39%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.7 (6%) | 0.7 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (25%) | 2.7 (22%) | 3.3 (23%) |
| SHELTERED: the target was sheltered | 0.7 (25%) | 0.0 (0%) | 0.7 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.0 | 0.3 | 95% | 1.1 pts | 8 pts |
| chariot | 3.0 | 0.3 | 89% | 0.5 pts | 2 pts |
| infantry | 11.7 | 1.3 | 89% | 2.6 pts | 31 pts |
| war machine | 12.3 | 8.7 | 65% | 25.4 pts | 314 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.7 | 3.3 | 3.0 |
| Charges that made contact a game | 2.0 | 2.7 | 2.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.67 declared, 0.50 contact (6 units) | - | 0.67 declared, 0.50 contact (6 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 1.00 contact (2 units) | - | 1.00 declared, 1.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.25 declared, 0.12 contact (8 units) | 0.37 declared, 0.30 contact (27 units) | 0.34 declared, 0.26 contact (35 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 71% (5 of 7) | - | 0% (0 of 1) | 62% (5 of 8) |
| Character on its own | 0% (0 of 1) | 67% (6 of 9) | 50% (4 of 8) | 56% (10 of 18) |
| Chariot | 100% (1 of 1) | - | - | 100% (1 of 1) |
| Infantry | 20% (1 of 5) | 0% (0 of 2) | - | 14% (1 of 7) |
| Monster | 75% (3 of 4) | - | - | 75% (3 of 4) |
| Monstrous | 100% (1 of 1) | - | - | 100% (1 of 1) |
| War Machines | 83% (5 of 6) | - | - | 83% (5 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 3 | 67% (2 of 3); on the table 67% | 50% (30 of 60) | 38% | 54% (14 of 26) | 100% (8 of 8); 9.3 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Kingdom of Bretonnia | 1 | 0% (0 of 1); on the table 0% | - | 56% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 1 | 80% (4 of 5); on the table 80% | 33% (2 of 6) | 32% | 20% (1 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 0% (0 of 1); on the table 100% | - | 69% | 88% (7 of 8) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p31, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 20% (1) | 40% (2) | 30% (3) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.67 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.67 | 0.67 |

### Quality by phase: gs3-83c8646-p31

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 5.7 | 2.3 |
| Strategy | Charge objectives carried out (made contact) | 71% (5 of 7) | 50% (5 of 10) |
| Strategy | Shoot objectives carried out (shot that target) | 24% (10 of 41) | 28% (7 of 25) |
| Strategy | Joined characters whose unit fought | - | 0% (0 of 2) |
| Strategy | Lone characters that fought | 83% (10 of 12) | 50% (4 of 8) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.0 | 2.3 |
| Movement | Points that never moved of their own | 165.0 | 180.0 |
| Movement | Fights charged into per game | 2.0 | 2.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 4 | 2 of 7, net +92 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 4 | 0 of 7 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 4, net +55 | 1 of 7, net +0 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 4, net +0 | 1 of 7, net +165 |
| Shooting | Shots by shooting units (incl. breath weapons) | 3.3 | 14.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 60% (6 of 10) | 48% (21 of 44) |
| Shooting | Points destroyed by shooting units | 0.0 | 50.0 |
| Shooting | War machine shots | 7.3 | 4.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (11 of 22) | 58% (7 of 12) |
| Shooting | Points destroyed by war machines | 92.3 | 56.0 |
| Magic | Magic missiles cast | 8.3 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 28% (7 of 25) | - |
| Magic | Wounds caused by magic missiles | 14.3 | - |
| Magic | Wounds caused by other spells | 5.3 | - |
| Magic | Points destroyed by magic (all spells) | 139.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.0 / 0.0 / 3.0 / 0.3 | 3.0 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 83.3 | 367.3 |
| Combat | Points run down | 10.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +28 | +195 |
| Combat | Net per 100 charger points, damage counted | +10.7 | +71.9 |
| Combat | First round won (charged fights) | 67% | 88% |
| Combat | Net points per charged fight | -13 | +173 |
| Combat | Net points per supported fight / lone fight | - / -13 | - / +173 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 6 | 4 of 8 |
| Game | Points lost | 692.0 | 371.3 |
| Game | VP from objectives | 456.7 | 656.7 |
| Game | Lone holders (player turns) | 0.5 | 1.0 |

- Mine won / drew / lost: 0 / 2 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -449 VP
- The side that went first won 0 of 1 games with a winner
- Points traded per game (both sides' losses): 1063
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p31

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +35.9 | 0.0 | 0.0 | 0.3 | +11.8 | 0.0 | 0.0 |
| ARMY TABLE | 17.7 | -112.5 | 0.0 | 176.7 | 24.3 | +370.7 | 0.0 | 217.3 |
| ARTILLERY RE-ROLL WEIGHED | 3.7 | +0.0 | 0.0 | 220.0 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +0.7 | 0.0 | 0.0 | 0.3 | +1.2 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | +2.9 | 0.0 | 0.0 |
| BOMBING RUN | 0.3 | +7.1 | 0.0 | 50.0 | - | - | - | - |
| CANNON PLANNED TARGET | 7.0 | +49.5 | 203.7 | 275.0 | 4.0 | +53.6 | 401.3 | 0.0 |
| CANNON SIGHT KEPT | 3.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 6.7 | +144.2 | 140.0 | 252.7 | - | - | - | - |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 3.0 | +177.2 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | -1.8 | 0.0 | 32.3 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +21.2 | 0.0 | 144.7 | 0.7 | +43.0 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | +15.4 | 144.7 | 0.0 |
| CHARGE LOSSES | 20.7 | -774.4 | 0.0 | 446.7 | 21.0 | -830.8 | 0.0 | 278.0 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 10.0 | 0.0 | 2.7 | +0.0 | 437.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.3 | +0.0 | 0.0 | 126.3 | 10.3 | +0.0 | 0.0 | 65.0 |
| CONVEYANCE SEARCH | 2.3 | +281.8 | 252.7 | 252.7 | - | - | - | - |
| COVER ONCE | 6.3 | -402.2 | 0.0 | 671.7 | 8.7 | -674.1 | 0.0 | 64.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -3.0 | 158.7 | 0.0 |
| DEPLOY BY FIGURES | 5.0 | -32.6 | 0.0 | 0.0 | 7.7 | +106.3 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -25.5 | 0.0 | 0.0 | 0.3 | -17.5 | 32.3 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +0.3 | 32.3 | 0.0 |
| EXACT ROUND | 1.7 | +10.4 | 75.0 | 0.0 | 2.0 | +39.3 | 301.0 | 65.0 |
| FALL BACK GOOD ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 2.0 | +1.6 | 494.3 | 65.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 0.7 | +8.9 | 0.0 | 50.0 | 21.0 | +268.0 | 0.0 | 127.3 |
| FEATURE BUFFS | 1.3 | +37.3 | 0.0 | 272.0 | 1.0 | +14.9 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.0 | +7.7 | 56.7 | 0.0 | 0.7 | +17.0 | 136.0 | 65.0 |
| FIVE ACTION | 83.0 | +3603.8 | 834.3 | 2569.3 | 93.7 | +4852.3 | 1612.0 | 711.0 |
| FLANK NOT WEIGHED | 7.0 | +0.0 | 0.0 | 507.0 | 10.0 | +0.0 | 0.0 | 55.7 |
| FOLLOW UP WEIGHED | 0.7 | +164.0 | 0.0 | 0.0 | 1.0 | +269.9 | 0.0 | 0.0 |
| FOOT FIRST | - | - | - | - | 34.7 | +0.0 | 0.0 | 184.0 |
| FOUR ROUNDS | 2.7 | +215.1 | 85.0 | 0.0 | 3.3 | +214.4 | 636.7 | 65.0 |
| FREED FROM HIS FIGHT | 3.0 | +0.0 | 0.0 | 174.7 | 11.0 | +0.0 | 0.0 | 91.3 |
| FRIEND SHOOTS FIRST | 1.0 | -9.3 | 0.0 | 126.3 | 0.3 | -2.3 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -5.6 | 56.7 | 0.0 | 0.3 | -1.6 | 0.0 | 65.0 |
| GOAL WALK | 5.3 | +303.6 | 0.0 | 0.0 | 11.0 | +1060.7 | 0.0 | 314.7 |
| GUN MASK | 1.0 | +10.4 | 0.0 | 0.0 | 1.3 | +66.8 | 0.0 | 0.0 |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 1.3 | +0.0 | 0.0 | 64.7 | 8.0 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | - | - | - | - | 0.3 | +0.0 | 126.3 | 0.0 |
| HIS CHARGE BY HIS RUN | 12.3 | +0.0 | 0.0 | 336.7 | 14.0 | +0.0 | 0.0 | 148.0 |
| HIS CHARGE LIST | 9.7 | +0.0 | 0.0 | 480.3 | 19.0 | +0.0 | 0.0 | 53.3 |
| HIS LEGAL MOVES | 8.0 | +0.0 | 0.0 | 415.7 | 5.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.7 | -159.5 | 0.0 | 304.3 | 9.7 | -90.2 | 0.0 | 65.7 |
| HIS ONE QUARTER | 4.3 | +0.0 | 0.0 | 364.7 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 11.3 | +0.0 | 0.0 | 542.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 10.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 3.0 | +0.0 | 0.0 | 110.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 32.3 | +1589.5 | 0.0 | 943.3 | 63.7 | +4184.6 | 0.0 | 609.3 |
| HIS SHOTS BY HIS RUN | 26.7 | +580.3 | 0.0 | 513.3 | 39.3 | +465.2 | 0.0 | 609.3 |
| HIS TURN DENIED | 0.7 | +16.5 | 18.3 | 0.0 | 1.7 | +60.6 | 246.0 | 0.0 |
| HOLD ODDS | 12.7 | +0.0 | 0.0 | 673.3 | 17.0 | +0.0 | 0.0 | 91.3 |
| HOLDER ASSIGNMENT | 8.3 | +814.5 | 0.0 | 200.7 | 12.7 | +1145.2 | 0.0 | 64.0 |
| HOLDS AMBUSHERS | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.7 | -87.7 | 85.0 | 0.0 | 3.0 | -90.7 | 510.3 | 65.0 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +16.4 | 0.0 | 0.0 |
| IDLE COST | 0.7 | -11.0 | 0.0 | 0.0 | 18.7 | -319.3 | 0.0 | 167.3 |
| JOINT CHARGE NOW | - | - | - | - | 0.7 | +13.1 | 87.3 | 0.0 |
| KEEP FALLS | 0.3 | +13.9 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 0.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.0 | +5.1 | 0.0 | 0.0 | 1.7 | +108.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.7 | +0.0 | 130.7 | 136.0 | 7.3 | +0.0 | 136.0 | 189.0 |
| LONE WIZARD KEPT IN | 0.3 | +15.9 | 0.0 | 0.0 | 1.0 | +85.4 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.3 | +31.1 | 144.7 | 0.0 |
| LOST AFTER ESCAPE | 2.3 | -2.3 | 85.0 | 0.0 | 2.3 | +2.8 | 471.7 | 65.0 |
| MAKE SURE TOGETHER | 1.0 | +3.5 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 1.3 | +0.6 | 0.0 | 0.0 | 1.3 | +8.7 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.7 | +7.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.0 | +53.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH ODDS | 0.3 | +5.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.7 | +6.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 2.7 | +290.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 7.7 | +118.3 | 0.0 | 56.0 | 2.0 | +70.6 | 0.0 | 26.7 |
| MEETS IN TIME | 1.3 | +218.9 | 0.0 | 0.0 | 2.3 | +190.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 14.7 | +295.2 | 0.0 | 654.0 | 1.3 | +1.6 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 18.0 | +203.8 | 0.0 | 453.3 | 1.3 | +0.9 | 0.0 | 0.0 |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 65.0 |
| MOVE SPELL SPOT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 3.7 | +171.5 | 0.0 | 126.3 | 5.3 | +405.5 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.7 | +275.4 | 0.0 | 168.3 | 5.7 | +189.4 | 0.0 | 0.0 |
| NEAREST TO GOAL | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 3.0 | +143.0 | 10.0 | 0.0 | 4.3 | +243.1 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.0 | -95.6 | 28.3 | 0.0 | 2.7 | -63.3 | 459.7 | 65.0 |
| NO LATE CUT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.3 | +70.9 | 0.0 | 144.7 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.7 | -1.3 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.3 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 5.7 | -136.9 | 56.7 | 32.3 | 5.7 | -195.8 | 0.0 | 26.7 |
| OGRE LOADER SECOND SHOT | 5.0 | +29.4 | 0.0 | 110.0 | - | - | - | - |
| ONE CHALLENGE TEST | - | - | - | - | 0.3 | +15.4 | 144.7 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.7 | -82.9 | 0.0 | 126.3 | 6.0 | -146.0 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +4.3 | 32.3 | 0.0 |
| ONE OBJECTIVE FORMULA | 3.7 | -83.1 | 0.0 | 200.7 | 5.3 | -34.3 | 0.0 | 64.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | -13.3 | 0.0 | 0.0 |
| ONE ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +11.2 | 10.0 | 0.0 | 0.7 | +25.0 | 64.7 | 0.0 |
| OVERRUNS AWAY | 0.3 | +0.2 | 18.3 | 0.0 | 2.0 | +21.7 | 310.7 | 0.0 |
| OWN CAST FIRST | 0.3 | -1.1 | 0.0 | 0.0 | - | - | - | - |
| PATHS CROSS | - | - | - | - | 0.3 | +51.1 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -0.5 | 0.0 | 0.0 |
| PLAN RESULT | 37.0 | +880.6 | 138.0 | 1365.7 | 44.3 | +637.5 | 362.7 | 554.3 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 8.0 | -99.6 | 0.0 | 0.0 | 8.3 | -272.5 | 0.0 | 0.0 |
| PROMISE HOLDS THE SPOT | - | - | - | - | 0.3 | +46.7 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 3.0 | -0.1 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 1.0 | -9.3 | 0.0 | 126.3 | - | - | - | - |
| PROMISE SHOT AWAY | 0.3 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 7.0 | +703.5 | 0.0 | 476.7 | 6.7 | +536.3 | 625.3 | 0.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 2.3 | +80.2 | 0.0 | 56.7 |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 3.3 | +317.5 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 5.3 | +328.1 | 0.0 | 63.3 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 6.7 | +455.7 | 0.0 | 46.7 |
| REFORMS TO MEET IT | 0.7 | -1.7 | 0.0 | 0.0 | 1.7 | -62.9 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.7 | +4.7 | 0.0 | 50.0 | 1.7 | +51.4 | 0.0 | 53.3 |
| RISK BY ARC | 2.7 | +89.8 | 85.0 | 0.0 | 3.0 | -132.5 | 492.0 | 65.0 |
| ROUNDS AFTER TERROR | 0.7 | -9.8 | 10.0 | 0.0 | 2.0 | -49.1 | 333.3 | 65.0 |
| RUN DOWN | 1.3 | -5.3 | 10.0 | 0.0 | 3.0 | -35.4 | 492.0 | 65.0 |
| SAME CHARGE LATER | 0.7 | -2.3 | 10.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | - | - | - | - | 0.7 | +0.9 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -66.5 | 0.0 | 0.0 |
| SEARCH SPOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +8.5 | 56.7 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 0.3 | -49.8 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +39.0 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.0 | +3.5 | 0.0 | 0.0 | - | - | - | - |
| SET-UP ANY TARGET | 1.3 | +174.3 | 0.0 | 0.0 | - | - | - | - |
| SET-UP MISSED | 0.3 | +17.9 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 13.0 | +0.0 | 0.0 | 702.0 | 9.7 | +0.0 | 0.0 | 18.3 |
| SHOOTS FROM THE BEST SPOT | 4.0 | +311.1 | 137.0 | 401.3 | 3.0 | +144.1 | 100.0 | 0.0 |
| SHOT OR CHARGE | 0.7 | -1.8 | 10.0 | 0.0 | 1.3 | -169.3 | 289.3 | 0.0 |
| SHOT RISK POINTS | 21.7 | +13.0 | 0.0 | 336.7 | 38.3 | -221.3 | 0.0 | 609.3 |
| SHOTS AFTER THE MOVES | 5.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 12.0 | +349.3 | 0.0 | 439.7 | 17.7 | +420.6 | 0.0 | 71.7 |
| SPELL SETS UP CHARGE | 1.7 | +214.4 | 126.3 | 126.3 | - | - | - | - |
| SPELL WORTH | 2.7 | +49.0 | 289.3 | 289.3 | 1.0 | +28.5 | 0.0 | 20.0 |
| SPELLS IN THE FIGHT | 1.0 | +35.0 | 56.7 | 0.0 | 0.3 | -40.8 | 126.3 | 0.0 |
| SPOT AS THE GAME MOVES | 6.0 | +0.0 | 0.0 | 136.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | 0.3 | -0.3 | 0.0 | 0.0 | 0.7 | -3.0 | 64.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 3.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 36.7 | +0.0 | 749.3 | 1514.0 | 28.3 | +0.0 | 975.3 | 146.7 |
| STANDS TO CAST | 0.3 | +7.1 | 0.0 | 0.0 | - | - | - | - |
| STAY WORTH | 26.0 | -0.4 | 559.0 | 605.0 | 22.0 | -26.6 | 224.0 | 0.0 |
| STRIKE BY THE ODDS | - | - | - | - | 1.3 | +187.2 | 408.0 | 65.0 |
| SUPPORT ADDS | 9.3 | +802.0 | 0.0 | 64.7 | 4.0 | +238.5 | 0.0 | 99.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 9.3 | +802.0 | 0.0 | 64.7 | 4.0 | +238.5 | 0.0 | 99.0 |
| SURE REACH TOGETHER | 1.0 | +8.0 | 0.0 | 0.0 | - | - | - | - |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +0.7 | 0.0 | 26.7 |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -19.9 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.3 | +0.0 | 0.0 | 136.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 3.0 | +0.0 | 0.0 | 56.0 | 5.0 | +0.0 | 0.0 | 10.0 |
| THE STEP BACK IS MADE | 2.3 | +0.0 | 0.0 | 56.0 | 4.0 | +0.0 | 0.0 | 10.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 37.0 | +0.0 | 0.0 | 1229.7 | 44.0 | +0.0 | 0.0 | 294.7 |
| TIED UP BY THE SUM | 1.0 | +116.2 | 10.0 | 0.0 | 1.3 | +146.0 | 197.3 | 0.0 |
| TIME ON OUR SIDE | 37.3 | +556.6 | 247.0 | 729.7 | 4.3 | +46.6 | 0.0 | 0.0 |
| WAITS AGAIN | 3.7 | +0.0 | 0.0 | 112.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | 0.3 | -2.5 | 0.0 | 0.0 | 0.3 | -6.9 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 1.3 | +0.0 | 0.0 | 200.0 | - | - | - | - |
| WEAPON BY POINTS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 0.7 | +15.8 | 113.3 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.3 | -13.9 | 0.0 | 0.0 | 0.7 | +9.4 | 262.3 | 0.0 |
| WHO HITS BACK | 1.3 | +216.1 | 0.0 | 0.0 | 0.3 | +33.2 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.3 | +5.5 | 56.7 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 3.0 | -247.8 | 0.0 | 110.0 | 2.3 | -247.4 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +1.2 | 32.3 | 0.0 |
| WOUNDS ON THE RANKS | 5.3 | +169.7 | 0.0 | 272.0 | 0.3 | +2.4 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p31

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 126 | 126 | 89 | 29.67 | +1012 | +11.4 |
| HIS SHOT LIST | 288 | 274 | 70 | 23.33 | +1997 | +28.5 |
| HOLDER ASSIGNMENT | 63 | 63 | 58 | 19.33 | +3981 | +68.6 |
| LEGAL CHARGES ONLY | 39 | 39 | 39 | 13.00 | +0 | +0.0 |
| OFF BEST | 34 | 34 | 34 | 11.33 | -998 | -29.4 |
| HIS SHOTS BY HIS RUN | 198 | 186 | 33 | 11.00 | +635 | +19.2 |
| FIVE ACTION | 530 | 512 | 27 | 9.00 | +1843 | +68.3 |
| SHOT RISK POINTS | 180 | 172 | 25 | 8.33 | +1235 | +49.4 |
| THE TABLE AGAIN | 36 | 36 | 24 | 8.00 | +0 | +0.0 |
| DEPLOY BY FIGURES | 38 | 38 | 23 | 7.67 | +499 | +21.7 |
| PROMISE BY ITS OWN SUM | 49 | 49 | 17 | 5.67 | -1117 | -65.7 |
| REDIRECT FOR A FRIEND IN REACH | 20 | 20 | 16 | 5.33 | +348 | +21.8 |
| OGRE LOADER SECOND SHOT | 15 | 15 | 15 | 5.00 | +88 | +5.9 |
| GOAL WALK | 49 | 49 | 14 | 4.67 | +918 | +65.6 |
| MOVE ORDER | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| CAST JOB | 20 | 20 | 13 | 4.33 | +77 | +5.9 |
| SHOOTS FROM THE BEST SPOT | 21 | 21 | 13 | 4.33 | +54 | +4.2 |
| TIME ON OUR SIDE | 125 | 104 | 13 | 4.33 | +62 | +4.8 |
| MOVE TO CHARGE COMPUTED | 27 | 20 | 12 | 4.00 | +296 | +24.7 |
| SUPPORT ADDS | 40 | 38 | 12 | 4.00 | +1117 | +93.1 |
| SUPPORT WORKED OUT | 40 | 38 | 12 | 4.00 | +1117 | +93.1 |
| ARTILLERY RE-ROLL WEIGHED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| CANNON SIGHT KEPT | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| CHARGE LOSSES | 125 | 119 | 11 | 3.67 | +1523 | +138.4 |
| NEXT CHARGE BY LIST | 22 | 19 | 9 | 3.00 | +190 | +21.1 |
| LANE BY FIGURES | 8 | 8 | 8 | 2.67 | +340 | +42.4 |
| FOUR ROUNDS | 18 | 17 | 7 | 2.33 | +325 | +46.4 |
| HOLDS AMBUSHERS | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| RESERVE FALL BACK | 7 | 7 | 7 | 2.33 | +168 | +24.0 |
| SHOTS AFTER THE MOVES | 27 | 27 | 7 | 2.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 15 | 15 | 6 | 2.00 | -130 | -21.7 |
| COVER ONCE | 45 | 32 | 6 | 2.00 | +116 | +19.3 |
| MEETS IN TIME | 11 | 11 | 6 | 2.00 | +691 | +115.2 |
| TIED UP BY THE SUM | 7 | 7 | 6 | 2.00 | +196 | +32.6 |
| CANNON PLANNED TARGET | 33 | 33 | 5 | 1.67 | +0 | +0.0 |
| FALLS SHORT | 65 | 54 | 5 | 1.67 | +37 | +7.5 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +1302 | +260.4 |
| IDLE COST | 58 | 48 | 5 | 1.67 | +43 | +8.7 |
| MAX FOR POSITIONING | 29 | 26 | 5 | 1.67 | +20 | +4.0 |
| MISSILES IN THE MOVE | 48 | 37 | 5 | 1.67 | +200 | +40.0 |
| RANDOM MOVE BY FIGURES | 7 | 7 | 5 | 1.67 | +240 | +48.1 |
| REDIRECT BY WHAT IT STOPS | 10 | 10 | 5 | 1.67 | +137 | +27.5 |
| STAY WORTH | 144 | 132 | 5 | 1.67 | +293 | +58.7 |
| WHO HITS BACK | 5 | 5 | 5 | 1.67 | +681 | +136.2 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +304 | +76.0 |
| QUARTER ODDS | 41 | 39 | 4 | 1.33 | +309 | +77.2 |
| REDIRECT COUNTER | 16 | 12 | 4 | 1.33 | +268 | +67.0 |
| STRIKE BY THE ODDS | 4 | 4 | 4 | 1.33 | +61 | +15.2 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +192 | +64.2 |
| HARD STAY DROPPED | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HIS TURN DENIED | 7 | 7 | 3 | 1.00 | +25 | +8.5 |
| NEARER NOT NEEDED | 34 | 33 | 3 | 1.00 | +95 | +31.7 |
| ONE OBJECTIVE FORMULA | 27 | 26 | 3 | 1.00 | +75 | +24.9 |
| PROMISE KNOWS THE FIGHT | 9 | 5 | 3 | 1.00 | -0 | -0.1 |
| RISK BY ARC | 17 | 16 | 3 | 1.00 | +77 | +25.7 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +143 | +71.6 |
| CHAFF IN THE MOVE | 9 | 8 | 2 | 0.67 | +74 | +36.8 |
| EXACT ROUND | 11 | 10 | 2 | 0.67 | +19 | +9.7 |
| HIS MOVE AND SHOT | 43 | 40 | 2 | 0.67 | +8 | +3.8 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +39 | +19.7 |
| MANOEUVRE | 8 | 8 | 2 | 0.67 | +28 | +14.0 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +23 | +11.3 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -19 | -9.4 |
| OVERRUNS AWAY | 7 | 7 | 2 | 0.67 | +19 | +9.7 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHOTS IN THE MOVE | 89 | 73 | 2 | 0.67 | +176 | +88.2 |
| THE ROW IN ITS ORDER | 13 | 2 | 2 | 0.67 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 2 | 2 | 2 | 0.67 | -28 | -14.1 |
| WAR ENGINE JOBS | 4 | 4 | 2 | 0.67 | -12 | -5.9 |
| WEAPON BY POINTS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHO FIGHTS | 3 | 3 | 2 | 0.67 | +26 | +13.0 |
| WOUNDS ON THE RANKS | 17 | 17 | 2 | 0.67 | +8 | +4.2 |
| BLOWS WHERE AIMED | 1 | 1 | 1 | 0.33 | +8 | +7.5 |
| BOMBING RUN | 1 | 1 | 1 | 0.33 | +21 | +21.3 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -5 | -5.4 |
| DUEL STOPS AT THE KILL | 2 | 2 | 1 | 0.33 | +42 | +42.0 |
| FIGHT TO THE END | 5 | 4 | 1 | 0.33 | +47 | +47.3 |
| HONEST WORTH | 17 | 16 | 1 | 0.33 | +42 | +42.0 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +56 | +55.5 |
| MARCH CHECK | 3 | 3 | 1 | 0.33 | +10 | +9.7 |
| MARCH ODDS | 1 | 1 | 1 | 0.33 | -1 | -0.6 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.33 | +166 | +166.2 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -40 | -39.8 |
| OWN CAST FIRST | 1 | 1 | 1 | 0.33 | -3 | -3.2 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +153 | +153.3 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -2 | -1.5 |
| PROMISE HOLDS THE SPOT | 1 | 1 | 1 | 0.33 | +140 | +140.2 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -0 | -0.5 |
| SEARCH SPOT | 1 | 1 | 1 | 0.33 | +0 | +0.1 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +26 | +25.5 |
| SET UP TOGETHER | 3 | 2 | 1 | 0.33 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +4 | +4.0 |
| STANDS TO CAST | 1 | 1 | 1 | 0.33 | -4 | -4.2 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -23 | -22.8 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +2 | +2.2 |
| BACKUP TARGETS | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 5 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 53 | 51 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 7 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 11 | 11 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 7 | 7 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 51 | not checked | - | - | - | - |
| FOOT FIRST | 104 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 42 | 40 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 1 | 0 | 0.00 | - | - |
| GUN MASK | 7 | 7 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 28 | 26 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 79 | 75 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 86 | 81 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 40 | 38 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 19 | 17 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 52 | 47 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 32 | 31 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 9 | 9 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 89 | 89 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 11 | 11 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 14 | 13 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 3 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 8 | 8 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 58 | 45 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 5 | not checked | - | - | - | - |
| NEAREST TO GOAL | 7 | 7 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 14 | 14 | 0 | 0.00 | - | - |
| NO LATE CUT | 1 | 1 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 29 | 18 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 244 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 3 | 3 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 7 | 7 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 8 | 8 | 0 | 0.00 | - | - |
| RUN DOWN | 13 | 13 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SET UP BY THE SET | 4 | 4 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 4 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 68 | not checked | - | - | - | - |
| SHOT OR CHARGE | 6 | 6 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 5 | not checked | - | - | - | - |
| SPELL WORTH | 11 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 4 | 3 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 28 | 22 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 10 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 195 | 188 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 3 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 13 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 24 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 19 | not checked | - | - | - | - |
| THE TABLE BINDS | 243 | not checked | - | - | - | - |
| WAITS AGAIN | 13 | 10 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | not checked | - | - | - | - |
| WHOLE FIGHT | 1 | not checked | - | - | - | - |
| WHOLE FIGHT DANGER | 16 | 16 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p31

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.33 | 4.67 | 25.1 |
| ARMY TABLE | rule | 3.33 | 2.67 | 70.8 |
| PROMISE BY ITS OWN SUM | rule | 2.67 | 3.00 | 65.7 |
| HOLDER ASSIGNMENT | rule | 0.67 | 2.00 | 11.5 |
| CHARGE NOW FIRST | rule | 1.33 | 0.67 | 21.6 |
| MARCH OF THE TABLE | rule | 0.67 | - | 9.4 |
| NO REASON | gate | - | 0.67 | 112.1 |
| WALKS ON ITS ROUTE | rule | 0.33 | 0.33 | 14.1 |
| WAR ENGINE JOBS | rule | 0.67 | - | 5.9 |
| CHAFF PASSED | rule | 0.33 | - | 5.4 |
| FIGHT ORDER BAND | gate | - | 0.33 | 1.2 |
| JOINT CHARGE NOW | rule | - | 0.33 | 1.9 |
| MARCH ODDS | rule | 0.33 | - | 0.6 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 39.8 |
| OWN CAST FIRST | rule | 0.33 | - | 3.2 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 1.5 |
| RULE SWITCHED OFF | gate | 0.33 | - | 18.6 |
| STANDS TO CAST | rule | 0.33 | - | 4.2 |
| SUPPORT NARROWED | rule | 0.33 | - | 22.8 |

### Plans: gs3-83c8646-p31

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 71% | 185 | 187 | 101% |
| Mine | move | 23.0 | 97% | 1247 | 0 | 0% |
| Mine | shoot | 11.7 | 69% | 566 | 693 | 122% |
| Opponent | charge | 3.0 | 78% | 297 | 448 | 151% |
| Opponent | move | 34.0 | 94% | 1584 | 0 | 0% |
| Opponent | shoot | 5.7 | 41% | 207 | 190 | 92% |
| Opponent | support | 1.7 | 100% | 228 | 0 | 0% |

### Battle groups: gs3-83c8646-p31

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 5.3 | 6% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p31

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 12 | 17 (12) | 17 | 0 | 29 | 8% | 2.4 | 4 (3) | 21 (7) | 40 (1) | 20 (10) | 0 (1) |
| Mine | Clean-up | 2 | 107 (2) | 0 | 107 | 0 | 0% | 2.5 | 18 (1) | 186 (1) | - | 107 (2) | - |
| Mine | Fast Hammer | 2 | 41 (2) | 23 | 18 | 110 | 0% | 1.5 | - | 0 (1) | 58 (1) | 41 (2) | - |
| Mine | Holder | 2 | 105 (2) | 8 | 97 | 0 | 0% | 1.5 | - | 52 (1) | 167 (1) | 105 (2) | - |
| Mine | Shooter | 4 | 39 (4) | 0 | 39 | 43 | 25% | 2.7 | - | 39 (4) | - | 247 (1) | 0 (3) |
| Mine | War machine | 6 | 28 (6) | 28 | 0 | 50 | 0% | 1.3 | 0 (2) | 42 (4) | - | 0 (1) | 34 (5) |
| Opponent | Chaff | 7 | 104 (7) | 22 | 83 | 50 | 29% | 1.2 | 82 (2) | 123 (4) | 0 (1) | 99 (6) | 132 (1) |
| Opponent | Character | 7 | 16 (7) | 16 | 0 | 10 | 43% | 2.2 | 0 (1) | 0 (3) | 35 (3) | 24 (5) | 0 (2) |
| Opponent | Clean-up | 2 | 250 (2) | 233 | 17 | 0 | 50% | 5.0 | - | 250 (2) | - | 250 (2) | - |
| Opponent | Fast Hammer | 4 | 92 (4) | 61 | 30 | 50 | 0% | 4.2 | 0 (1) | 105 (2) | 146 (1) | 77 (3) | 146 (1) |
| Opponent | Hammer | 4 | 12 (4) | 0 | 12 | 23 | 25% | 2.0 | - | 12 (4) | - | 0 (3) | 27 (1) |
| Opponent | Holder | 5 | 112 (5) | 0 | 112 | 15 | 40% | 1.0 | 382 (1) | 109 (1) | 56 (3) | 255 (3) | 0 (2) |
| Opponent | Shooter | 1 | 141 (1) | 88 | 53 | 0 | 0% | 2.0 | - | 141 (1) | - | - | 141 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | War machine | 2 | 84 (2) | 84 | 0 | 0 | 0% | 1.0 | 84 (2) | - | - | - | 84 (2) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 29 | 33% | 1.0 | - | 0 (2) | - | - | 0 (2) |

### Charged fights: gs3-83c8646-p31

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 3 | 231 | 28 | 2.0 | 1.0 | 14 | 28 | -13 | 3 of 6 | 4 of 6 | - | -13 |
| Opponent | Kingdom of Bretonnia | 1 | 168 | 813 | 2.0 | 1.0 | 406 | 0 | +406 | 2 of 2 | 2 of 2 | - | +406 |
| Opponent | Tomb Kings of Khemri | 1 | 150 | 765 | 6.0 | 1.0 | 128 | 32 | +95 | 2 of 6 | 5 of 6 | - | +95 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 106 | 526 | 2.7 | 1.0 | 197 | 24 | +173 | 4 of 8 | 7 of 8 | - | +173 |

### Effective charges: gs3-83c8646-p31

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 6 | 0 | 1 (net +0) | 0 | 0 | 1 (net +55) | 2 (net +0) | 2 | 0% (0 of 4) |
| Opponent | Kingdom of Bretonnia | 2 | 1 (net +379) | 0 | 0 | 1 (net +434) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 6 | 1 (net -195) | 0 | 0 | 2 (net +252) | 1 (net +0) | 1 (net +165) | 1 | 0% (0 of 5) |

### Charged fights, damage counted: gs3-83c8646-p31

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 50-54% | 1 | 205 | 336 | +0 | 175 | 0 | +175 | +85.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 356 | 206 | +0 | 162 | 27 | +135 | +37.8 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 233 | 55 | +55 | 55 | 0 | +55 | +23.6 |
| Mine | No odds | 2 | 211 | 253 | -68 | 162 | 328 | -166 | -78.5 |
| Mine | All fights | 6 | 262 | 218 | -13 | 146 | 118 | +28 | +10.7 |
| Opponent | Long shot (under 50%) | 2 | 204 | 368 | +92 | 190 | 98 | +92 | +45.0 |
| Opponent | 76-89% | 3 | 160 | 288 | +312 | 345 | 7 | +338 | +210.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 411 | 165 | +165 | 165 | 0 | +165 | +40.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 431 | 97 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | No odds | 1 | 431 | 150 | +97 | 204 | 10 | +194 | +45.0 |
| Opponent | All fights | 8 | 270 | 252 | +173 | 223 | 28 | +195 | +71.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p31 | move | 17 | 2 (12%) | 1 (6%) | 2 (12%) | 13 (76%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122 |
| Ring of Doom | Mine | L1122, L1216, L1232 |
| Ring of Jet | Mine | L1122, L1216, L1232 |

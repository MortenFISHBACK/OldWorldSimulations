# Doctrine scorecard: gs3-83c8646-p69

### Scorecard: gs3-83c8646-p69

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1531 | 1 | 1 | Mine | no | 0 | 3 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | yes | 4 | 6 | 1 | 1 | 1 | 0 | 0 | 170 |
| L1629 | 3 | 1 | Mine | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 200 |
| L1629 | 3 | 1 | Opponent | no | 7 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Mine | no | - | 3 | 2 | 2 | 0 | 0 | 0 | 83 |
| L1727 | 5 | 1 | Opponent | no | - | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 0.0 | 3.0 | 3.0 | 1.7 | 0.0 | 0.0 | 0.0 | 94.3 |
| **Average** | | | Opponent | 33% | 5.5 | 3.7 | 2.0 | 1.7 | 0.3 | 0.0 | 0.0 | 56.7 |

### KPIs: gs3-83c8646-p69

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 16) | 0% (0 of 16) | 0% (0 of 32) |
| Winner chose to follow up after the loser gave ground |  | 83% (5 of 6); on the table 83% | 60% (3 of 5); on the table 80% | 73% (8 of 11); on the table 82% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | 100% (2 of 2); on the table 100% | 67% (2 of 3); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 71% (5 of 7); on the table 71% | 71% (5 of 7); on the table 86% | 71% (10 of 14); on the table 79% |
| Magic missiles tried each own turn | 50%+ | - | 25% (3 of 12) | 25% (3 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 25% (3 of 12) | 25% (3 of 12) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 67% (12 of 18) | 67% (12 of 18) |
| Points that never fought | lower | 36% (2187 of 6000) | 41% (2486 of 5999) | 39% (4673 of 11999) |
|   infantry points that never fought | lower | 71% (947 of 1332) | 72% (619 of 855) | 72% (1566 of 2187) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 55% (11 of 20) | 64% (16 of 25) | 60% (27 of 45) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.7 uses a game | 100% (1 of 1); 1.3 uses a game | 100% (3 of 3); 2.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 50% (2593 of 5135) | 58% (3173 of 5430) | 55% (5766 of 10565) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 2.7 (89%) | 2.7 (89%) |
| MARCHED: its unit marched | - | 0.3 (11%) | 0.3 (11%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 1.0 | 0.3 | 1.0 | 3.0 |
| not cast | 6.0 | 1.0 | 1.7 | 3.0 | 17.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 0.3 (20%) | 2.7 (89%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (11%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (10%) |
| STUPIDITY: Stupidity | 0.7 (11%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.3 (6%) | 1.0 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 5.0 (83%) | 0.0 (0%) | 1.3 (80%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.7 (86%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.3 a game | 0.0 a game | 0.2 a game |
| stood (cast and not dispelled) | - | - | - |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 49% (38 of 77) | 20% (1 of 5) | 48% (39 of 82) |
|   cavalry | 75% (6 of 8) | 50% (1 of 2) | 70% (7 of 10) |
|   character | 40% (4 of 10) | 0% (0 of 3) | 31% (4 of 13) |
|   chariot | 0% (0 of 2) | - | 0% (0 of 2) |
|   infantry | 46% (16 of 35) | - | 46% (16 of 35) |
|   monster | 17% (2 of 12) | - | 17% (2 of 12) |
|   war machine | 100% (10 of 10) | - | 100% (10 of 10) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (13%) | 0.0 (0%) | 1.7 (12%) |
| CHARGED: it charged | 2.3 (18%) | 0.3 (25%) | 2.7 (19%) |
| IN COMBAT: it fought this turn or the last | 1.0 (8%) | 0.0 (0%) | 1.0 (7%) |
| NO TARGET IN RANGE | 5.3 (41%) | 0.3 (25%) | 5.7 (40%) |
| ONLY IN COMBAT: the only targets were in combat | 1.3 (10%) | 0.0 (0%) | 1.3 (9%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (10%) | 0.7 (50%) | 2.0 (14%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.3 | 0.7 | 86% | 4.9 pts | 11 pts |
| character | 2.7 | 0.7 | 88% | 7.1 pts | 19 pts |
| infantry | 8.7 | 1.7 | 85% | 5.8 pts | 51 pts |
| monster | 0.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 3.3 | 2.3 | 70% | 19.1 pts | 64 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.7 | 2.7 | 3.7 |
| Charges that made contact a game | 3.7 | 1.3 | 2.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 0.75 contact (4 units) | 0.67 declared, 0.33 contact (3 units) | 0.86 declared, 0.57 contact (7 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.50 declared, 0.40 contact (20 units) | 0.32 declared, 0.16 contact (19 units) | 0.41 declared, 0.28 contact (39 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 80% (4 of 5) | 100% (3 of 3) | 100% (2 of 2) | 90% (9 of 10) |
| Character in a unit | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Character on its own | 60% (3 of 5) | 50% (1 of 2) | 44% (4 of 9) | 50% (8 of 16) |
| Chariot | 100% (1 of 1) | - | - | 100% (1 of 1) |
| Infantry | 71% (5 of 7) | 0% (0 of 3) | - | 50% (5 of 10) |
| Monster | 33% (2 of 6) | - | - | 33% (2 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 1 | 67% (2 of 3); on the table 67% | - | 19% | 71% (5 of 7) | 100% (2 of 2); 8.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 0% (0 of 1); on the table 0% | - | 49% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | 100% (3 of 3); on the table 100% | - | 42% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 75% (3 of 4); on the table 100% | 0% (0 of 6) | 47% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | 67% (2 of 3); on the table 67% | 50% (3 of 6) | 38% | 58% (11 of 19) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p69, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (1) | 56% (5) | 60% (6) |
| ...free all their last turn and able to turn (per game) | 0.33 | 1.33 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 1.00 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 1.00 | 1.00 |

### Quality by phase: gs3-83c8646-p69

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 4.3 |
| Strategy | Charge objectives carried out (made contact) | 50% (6 of 12) | 25% (2 of 8) |
| Strategy | Shoot objectives carried out (shot that target) | 39% (7 of 18) | 0% (0 of 4) |
| Strategy | Support requests answered (helper made contact too) | 50% (1 of 2) | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 0% (0 of 1) | 33% (1 of 3) |
| Strategy | Lone characters that fought | 88% (7 of 8) | 90% (9 of 10) |
| Movement | Charges halted short of contact | 0.3 | 0.3 |
| Movement | Idle units | 1.7 | 1.7 |
| Movement | Points that never moved of their own | 94.3 | 56.7 |
| Movement | Fights charged into per game | 3.7 | 1.3 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 9, net -100 | 2 of 4, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 9 | 0 of 4 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 5 of 9, net +49 | 1 of 4, net +316 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 9, net +0 | 0 of 4 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.3 | 1.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (17 of 34) | 25% (1 of 4) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 3.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 20% (2 of 10) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | - | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 0% (0 of 2) |
| Magic | Wounds caused by magic missiles | 2.3 | 2.3 |
| Magic | Wounds caused by other spells | 0.7 | - |
| Magic | Points destroyed by magic (all spells) | 62.0 | 58.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.7 / 2.3 / 0.0 | 1.7 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 425.7 | 180.7 |
| Combat | Points run down | 0.0 | 147.0 |
| Combat | Net points per charged fight, damage counted | +117 | +197 |
| Combat | Net per 100 charger points, damage counted | +37.5 | +95.6 |
| Combat | First round won (charged fights) | 82% | 75% |
| Combat | Net points per charged fight | +108 | +125 |
| Combat | Net points per supported fight / lone fight | - / +108 | - / +125 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 11 | 2 of 4 |
| Game | Points lost | 386.0 | 555.0 |
| Game | VP from objectives | 666.7 | 796.7 |
| Game | Lone holders (player turns) | 0.0 | 5.5 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +106 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 941
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p69

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +3.6 | 0.0 | 42.0 | 0.7 | +26.9 | 0.0 | 0.0 |
| ARMY TABLE | 19.0 | -325.9 | 0.0 | 96.7 | 25.0 | +5.1 | 0.0 | 492.3 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +1.1 | 0.0 | 28.3 |
| BACKUP TARGETS | 0.3 | +2.5 | 0.0 | 0.0 | 0.3 | +1.3 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 3.3 | +31.5 | 0.0 | 33.3 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | - | - | - | - | 0.3 | -26.6 | 61.7 | 0.0 |
| CAST JOB | 1.3 | +5.6 | 0.0 | 0.0 | 0.7 | +3.7 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.3 | +11.0 | 0.0 | 28.0 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +0.3 | 0.0 | 0.0 | 0.3 | +13.3 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -14.5 | 0.0 | 0.0 |
| CHARGE LOSSES | 7.0 | -452.7 | 0.0 | 84.0 | 17.3 | -1093.1 | 0.0 | 155.0 |
| CHARGE NOW FIRST | 4.0 | +0.0 | 162.0 | 0.0 | 0.7 | +0.0 | 47.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 9.7 | +0.0 | 0.0 | 76.7 | 13.0 | +0.0 | 0.0 | 36.0 |
| COMBAT PIVOT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 10.3 | -644.4 | 0.0 | 38.3 | 8.3 | -632.5 | 0.0 | 193.7 |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -1.8 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 7.3 | -26.0 | 0.0 | 0.0 | 6.3 | +63.8 | 0.0 | 139.0 |
| EXACT ROUND | 2.3 | -20.2 | 73.7 | 0.0 | 2.0 | +24.9 | 182.3 | 0.0 |
| FALL BACK GOOD ORDER | 3.3 | +3.1 | 141.3 | 0.0 | 2.0 | +0.1 | 73.7 | 0.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 38.7 |
| FALLS SHORT | - | - | - | - | 19.3 | +184.7 | 0.0 | 156.7 |
| FEATURE BUFFS | 2.3 | +115.8 | 0.0 | 84.0 | 1.3 | +99.3 | 0.0 | 0.0 |
| FIGHT LIFT | 0.3 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.7 | +19.7 | 0.0 | 0.0 | 0.7 | +0.6 | 47.0 | 0.0 |
| FIRE AND FLEE | 0.3 | +0.8 | 0.0 | 26.7 | - | - | - | - |
| FIVE ACTION | 80.0 | +6026.5 | 260.0 | 835.7 | 74.0 | +4241.6 | 305.7 | 714.7 |
| FLANK NOT WEIGHED | 7.0 | +0.0 | 0.0 | 42.0 | 11.7 | +0.0 | 0.0 | 315.7 |
| FOLLOW UP WEIGHED | 1.3 | +74.1 | 0.0 | 0.0 | 0.7 | +13.9 | 0.0 | 0.0 |
| FOOT FIRST | 16.7 | +0.0 | 0.0 | 219.3 | - | - | - | - |
| FOUR ROUNDS | 4.3 | +331.1 | 230.0 | 0.0 | 2.7 | +148.9 | 182.3 | 0.0 |
| FREED FROM HIS FIGHT | 3.3 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 2.7 | -2.0 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.3 | -0.2 | 0.0 | 42.0 | - | - | - | - |
| GOAL WALK | 7.3 | +698.3 | 0.0 | 0.0 | 6.0 | +465.2 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 20.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 3.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 5.0 | +0.0 | 0.0 | 0.0 | 10.0 | +0.0 | 0.0 | 155.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +6.1 | 0.0 | 0.0 |
| HIS CHARGE LIST | 4.3 | +0.0 | 0.0 | 0.0 | 10.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.7 | +0.0 | 0.0 | 47.0 | 4.3 | +0.0 | 0.0 | 279.0 |
| HIS MOVE AND SHOT | 2.0 | -62.4 | 0.0 | 0.0 | 3.3 | -71.4 | 0.0 | 0.0 |
| HIS ONE QUARTER | 0.7 | +0.0 | 0.0 | 0.0 | 9.0 | +0.0 | 0.0 | 100.0 |
| HIS OWN BEST MOVE | 6.0 | +0.0 | 0.0 | 47.0 | 5.7 | +0.0 | 0.0 | 309.0 |
| HIS RANDOM MOVE | 23.0 | +0.0 | 0.0 | 340.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 3.7 | +0.0 | 0.0 | 84.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 13.7 | +312.0 | 0.0 | 216.0 | 37.7 | +863.0 | 0.0 | 450.0 |
| HIS SHOTS BY HIS RUN | 11.0 | +164.8 | 0.0 | 170.0 | 38.0 | +791.0 | 0.0 | 341.3 |
| HIS TURN DENIED | - | - | - | - | 0.7 | +8.5 | 0.0 | 0.0 |
| HOLD ODDS | 16.7 | +0.0 | 0.0 | 226.7 | 13.3 | +0.0 | 0.0 | 28.3 |
| HOLDER ASSIGNMENT | 9.0 | +766.1 | 0.0 | 100.7 | 8.3 | +738.7 | 0.0 | 28.3 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.3 | -149.5 | 230.0 | 0.0 | 2.3 | -61.4 | 182.3 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +1.6 | 0.0 | 155.0 |
| IDLE COST | - | - | - | - | 15.3 | -194.8 | 0.0 | 226.7 |
| JOINT CHARGE NOW | 0.7 | -1.4 | 36.0 | 0.0 | 0.7 | +16.7 | 94.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 0.3 | +0.0 | 0.0 | 58.7 | 1.3 | +0.0 | 0.0 | 28.3 |
| LANE BY FIGURES | 1.3 | +91.8 | 0.0 | 0.0 | 1.0 | +8.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 15.3 | +0.0 | 265.3 | 256.0 | 4.7 | +0.0 | 123.3 | 155.0 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.3 | +2.4 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.3 | +5.0 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.3 | +0.3 | 47.0 | 0.0 |
| LOST AFTER ESCAPE | 1.3 | +10.2 | 77.0 | 0.0 | 2.3 | +12.7 | 155.7 | 0.0 |
| MAKE SURE TOGETHER | 0.7 | +4.7 | 0.0 | 0.0 | 0.7 | +3.4 | 0.0 | 0.0 |
| MANOEUVRE | 1.7 | -5.2 | 0.0 | 58.7 | 0.3 | +5.9 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.7 | +8.5 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +11.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.7 | +26.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.7 | +4.8 | 0.0 | 0.0 | 0.7 | +19.2 | 0.0 | 0.0 |
| MARCH OVER CASTS | 1.0 | +22.6 | 0.0 | 0.0 | 1.0 | +127.5 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.3 | +0.0 | 0.0 | 58.7 | 0.3 | +0.0 | 0.0 | 28.3 |
| MAX FOR POSITIONING | 3.3 | +43.7 | 0.0 | 0.0 | 4.0 | +52.3 | 0.0 | 247.0 |
| MEETS IN TIME | 3.7 | +211.0 | 0.0 | 0.0 | 3.3 | +109.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.7 | +20.4 | 0.0 | 0.0 | 2.7 | +39.3 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 3.3 | +28.7 | 0.0 | 0.0 | 4.3 | +49.9 | 0.0 | 0.0 |
| MOVE ORDER | 3.3 | +0.0 | 0.0 | 26.7 | 2.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 6.3 | +446.7 | 0.0 | 47.0 | 6.3 | +319.0 | 0.0 | 154.0 |
| MOVES UNITS SPELL | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 8.3 | +376.1 | 0.0 | 117.3 | 4.3 | +175.8 | 0.0 | 0.0 |
| NEAREST TO GOAL | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 5.7 | +427.9 | 0.0 | 0.0 | 4.3 | +162.9 | 0.0 | 30.0 |
| NEXT OBJECTIVE NEARER | 0.7 | -5.6 | 0.0 | 58.7 | - | - | - | - |
| NO DOUBLE ROUNDS | 4.3 | -179.7 | 230.0 | 0.0 | 2.0 | -84.1 | 120.7 | 0.0 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 58.7 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 1.3 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 5.7 | -163.9 | 25.0 | 100.7 | 4.0 | -133.4 | 0.0 | 67.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 6.3 | -245.3 | 0.0 | 0.0 | 5.0 | -96.4 | 0.0 | 115.7 |
| ONE OBJECTIVE FORMULA | 3.7 | -1.4 | 0.0 | 42.0 | 3.0 | -23.9 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | -26.3 | 0.0 | 0.0 |
| ONE ROUTE | 0.3 | +0.0 | 0.0 | 58.7 | 0.3 | +0.0 | 0.0 | 28.3 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 1.7 | +76.9 | 110.0 | 0.0 | 0.3 | +24.8 | 26.7 | 0.0 |
| OVERRUNS AWAY | 0.7 | +9.8 | 95.3 | 0.0 | - | - | - | - |
| PATHS CROSS | 0.3 | +15.2 | 0.0 | 0.0 | 0.7 | +12.2 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -9.0 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 36.7 | +288.9 | 159.0 | 583.7 | 39.0 | +177.1 | 61.7 | 475.3 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 8.0 | -165.4 | 0.0 | 47.0 | 6.7 | -209.8 | 0.0 | 124.0 |
| PROMISE KNOWS THE FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 1.0 | -0.8 | 0.0 | 0.0 |
| QUARTER ODDS | 21.0 | +2402.3 | 88.7 | 0.0 | 20.3 | +2557.2 | 123.3 | 100.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 6.0 | +272.2 | 0.0 | 0.0 |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 58.7 | 0.3 | +0.0 | 0.0 | 28.3 |
| REDIRECT COUNTER | 1.0 | +94.5 | 0.0 | 26.7 | 2.3 | +237.4 | 0.0 | 124.3 |
| REDIRECT FOR A FRIEND IN REACH | 1.7 | +0.0 | 0.0 | 26.7 | 1.3 | +0.0 | 0.0 | 96.3 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.0 | -42.8 | 0.0 | 0.0 | 1.0 | -18.3 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +5.9 | 0.0 | 18.0 |
| RISK BY ARC | 3.3 | +92.8 | 205.0 | 0.0 | 1.7 | -29.7 | 120.7 | 0.0 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 58.7 | 0.3 | +0.0 | 0.0 | 28.3 |
| ROUNDS AFTER TERROR | 1.3 | -26.4 | 67.0 | 0.0 | 1.3 | -30.9 | 94.0 | 0.0 |
| RUN DOWN | 2.3 | -118.6 | 144.0 | 0.0 | 2.3 | -19.8 | 155.7 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.0 | -98.2 | 0.0 | 18.0 |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +10.4 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +9.1 | 25.0 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | 1.7 | +46.5 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 1.0 | -84.7 | 0.0 | 20.0 | 1.0 | -7.6 | 0.0 | 0.0 |
| SET UP BY THE SET | 3.7 | -33.7 | 0.0 | 20.0 | 1.7 | +104.8 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.7 | +4.7 | 0.0 | 0.0 | 1.3 | +8.9 | 0.0 | 38.7 |
| SHOOTERS IN TWO RANKS | 1.0 | +2.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 5.7 | +0.0 | 0.0 | 92.0 | 3.0 | +0.0 | 0.0 | 67.0 |
| SHOOTS FROM THE BEST SPOT | 2.7 | +39.8 | 30.0 | 0.0 | 2.3 | +46.0 | 123.3 | 0.0 |
| SHOT OR CHARGE | 1.0 | -8.7 | 0.0 | 0.0 | 0.3 | -21.4 | 0.0 | 0.0 |
| SHOT RISK POINTS | 10.0 | -43.5 | 0.0 | 156.7 | 19.0 | -351.1 | 0.0 | 195.0 |
| SHOTS AFTER THE MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 11.3 | +283.0 | 0.0 | 177.3 | 0.7 | +10.2 | 0.0 | 28.3 |
| SPELL WORTH | 2.0 | +28.6 | 0.0 | 0.0 | 2.0 | +4.5 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | +0.5 | 0.0 | 0.0 | 0.7 | -38.8 | 61.7 | 0.0 |
| SPOT AS THE GAME MOVES | 4.7 | +0.0 | 0.0 | 67.0 | 7.0 | +0.0 | 0.0 | 63.7 |
| STAND AND SHOOT | 0.3 | -3.6 | 28.3 | 0.0 | 0.3 | -0.8 | 26.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 31.3 | +0.0 | 30.0 | 358.7 | 18.7 | +0.0 | 123.3 | 103.3 |
| STAY WORTH | 13.7 | -82.4 | 0.0 | 356.3 | 0.7 | +1.2 | 0.0 | 0.0 |
| STRIKE BY THE ODDS | 0.3 | +0.3 | 0.0 | 42.0 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | 0.3 | +0.0 | 0.0 | 47.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 7.3 | +648.1 | 0.0 | 279.3 | 6.0 | +455.4 | 0.0 | 246.3 |
| SUPPORT NARROWED | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 94.0 | 0.0 |
| SUPPORT WORKED OUT | 7.3 | +648.1 | 0.0 | 279.3 | 6.0 | +455.4 | 0.0 | 246.3 |
| SURE REACH TOGETHER | - | - | - | - | 1.0 | +2.3 | 0.0 | 38.7 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +2.9 | 0.0 | 67.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.0 | +0.0 | 0.0 | 20.0 | 3.3 | +0.0 | 20.0 | 193.7 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 18.0 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 18.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 37.0 | +0.0 | 0.0 | 394.3 | 35.3 | +0.0 | 0.0 | 405.0 |
| TIED UP BY THE SUM | 2.7 | +263.1 | 138.0 | 0.0 | 1.0 | +97.2 | 120.7 | 0.0 |
| TIME ON OUR SIDE | 39.0 | +481.5 | 0.0 | 554.3 | - | - | - | - |
| WAITS AGAIN | 2.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 30.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -8.5 | 123.3 | 0.0 |
| WHO FIGHTS | 0.3 | +4.3 | 0.0 | 0.0 | 0.3 | +2.1 | 61.7 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +9.3 | 61.7 | 0.0 |
| WHOLE FIGHT DANGER | 3.3 | -376.0 | 0.0 | 84.0 | 4.0 | -616.3 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 0.7 | +2.6 | 0.0 | 0.0 | 3.3 | +37.7 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p69

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 132 | 132 | 70 | 23.33 | +362 | +5.2 |
| LEGAL CHARGES ONLY | 60 | 60 | 60 | 20.00 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 52 | 52 | 49 | 16.33 | +2446 | +49.9 |
| OFF BEST | 29 | 29 | 29 | 9.67 | -892 | -30.8 |
| HIS SHOTS BY HIS RUN | 147 | 142 | 27 | 9.00 | +184 | +6.8 |
| THE TABLE AGAIN | 36 | 36 | 27 | 9.00 | +0 | +0.0 |
| DEPLOY BY FIGURES | 41 | 41 | 25 | 8.33 | +230 | +9.2 |
| HIS SHOT LIST | 154 | 149 | 23 | 7.67 | +270 | +11.7 |
| FIVE ACTION | 462 | 442 | 17 | 5.67 | +629 | +37.0 |
| MOVE ORDER | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| GOAL WALK | 40 | 40 | 14 | 4.67 | +868 | +62.0 |
| FOUR ROUNDS | 21 | 19 | 12 | 4.00 | +416 | +34.6 |
| PROMISE BY ITS OWN SUM | 44 | 44 | 12 | 4.00 | -1126 | -93.8 |
| RANDOM MOVE BY FIGURES | 18 | 18 | 12 | 4.00 | +817 | +68.1 |
| QUARTER ODDS | 124 | 120 | 11 | 3.67 | +915 | +83.1 |
| MOVE TO CHARGE COMPUTED | 38 | 31 | 10 | 3.33 | +536 | +53.5 |
| TIED UP BY THE SUM | 11 | 10 | 10 | 3.33 | +342 | +34.2 |
| NEXT CHARGE BY LIST | 30 | 28 | 9 | 3.00 | +492 | +54.7 |
| REDIRECT FOR A FRIEND IN REACH | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| SUPPORT ADDS | 40 | 38 | 9 | 3.00 | +659 | +73.2 |
| SUPPORT WORKED OUT | 40 | 38 | 9 | 3.00 | +659 | +73.2 |
| CHARGE LOSSES | 73 | 73 | 8 | 2.67 | +713 | +89.1 |
| MEETS IN TIME | 21 | 21 | 8 | 2.67 | +429 | +53.6 |
| TIME ON OUR SIDE | 117 | 95 | 8 | 2.67 | +36 | +4.5 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| COVER ONCE | 56 | 36 | 7 | 2.33 | +127 | +18.2 |
| IDLE COST | 46 | 34 | 7 | 2.33 | +59 | +8.4 |
| LANE BY FIGURES | 7 | 7 | 7 | 2.33 | +300 | +42.8 |
| CHARGE NOW FIRST | 14 | 14 | 6 | 2.00 | -194 | -32.4 |
| FOLLOW UP WEIGHED | 6 | 6 | 6 | 2.00 | +264 | +44.0 |
| HARD STAY DROPPED | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| MAX FOR POSITIONING | 22 | 20 | 5 | 1.67 | +13 | +2.7 |
| SET UP BY THE SET | 16 | 16 | 5 | 1.67 | +77 | +15.4 |
| SUPPORT NARROWED | 6 | 6 | 5 | 1.67 | -206 | -41.2 |
| CAST JOB | 6 | 6 | 4 | 1.33 | +7 | +1.8 |
| EXACT ROUND | 13 | 11 | 4 | 1.33 | +27 | +6.8 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | +46 | +11.5 |
| MARCH OF THE TABLE | 4 | 4 | 4 | 1.33 | -72 | -18.0 |
| OPENS UP | 6 | 5 | 4 | 1.33 | +105 | +26.4 |
| RISK BY ARC | 15 | 14 | 4 | 1.33 | +74 | +18.4 |
| SHOOTS FROM THE BEST SPOT | 15 | 15 | 4 | 1.33 | +16 | +4.0 |
| SHOT RISK POINTS | 87 | 85 | 4 | 1.33 | +42 | +10.4 |
| WHOLE FIGHT DANGER | 22 | 22 | 4 | 1.33 | +86 | +21.5 |
| AFTERMATH IN POINTS | 3 | 3 | 3 | 1.00 | +92 | +30.5 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHAFF IN THE MOVE | 4 | 4 | 3 | 1.00 | +6 | +1.9 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +82 | +27.4 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +6 | +2.0 |
| THE ROW IN ITS ORDER | 16 | 3 | 3 | 1.00 | +0 | +0.0 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +41 | +20.4 |
| FEATURE BUFFS | 11 | 11 | 2 | 0.67 | +143 | +71.4 |
| LOST AFTER ESCAPE | 11 | 10 | 2 | 0.67 | +9 | +4.7 |
| MANOEUVRE | 6 | 6 | 2 | 0.67 | +21 | +10.6 |
| MARCH CHECK | 2 | 2 | 2 | 0.67 | +29 | +14.3 |
| MISSILES IN THE MOVE | 16 | 7 | 2 | 0.67 | +2 | +0.8 |
| NEARER NOT NEEDED | 38 | 36 | 2 | 0.67 | +89 | +44.6 |
| NO DOUBLE ROUNDS | 19 | 18 | 2 | 0.67 | +40 | +20.1 |
| REDIRECT COUNTER | 10 | 9 | 2 | 0.67 | +155 | +77.5 |
| SEARCH SPOT | 4 | 4 | 2 | 0.67 | +31 | +15.5 |
| SHOTS AFTER THE MOVES | 10 | 10 | 2 | 0.67 | +0 | +0.0 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CARRIES OUT SET-UP | 1 | 1 | 1 | 0.33 | -80 | -79.7 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALLS SHORT | 58 | 51 | 1 | 0.33 | +0 | +0.0 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.33 | +2 | +2.3 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | -0 | -0.5 |
| HIS CHARGE DENIED | 1 | 1 | 1 | 0.33 | +13 | +13.2 |
| HIS MOVE AND SHOT | 16 | 16 | 1 | 0.33 | +17 | +17.2 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +15 | +15.0 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +35 | +35.0 |
| MISSILES NEXT TURN | 23 | 13 | 1 | 0.33 | +0 | +0.3 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -79 | -79.0 |
| OVERRUNS AWAY | 2 | 2 | 1 | 0.33 | +3 | +2.8 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -27 | -27.0 |
| PROMISE READS THE TABLE | 3 | 3 | 1 | 0.33 | +3 | +2.7 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +224 | +223.7 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -20 | -20.1 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +18 | +17.8 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +27 | +27.3 |
| SET UP TOGETHER | 6 | 4 | 1 | 0.33 | +10 | +10.0 |
| STAY WORTH | 43 | 37 | 1 | 0.33 | +3 | +3.1 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +1 | +0.8 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +9 | +8.8 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 2 | 1 | 0 | 0.00 | - | - |
| CANNON PLANNED TARGET | 10 | 10 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 68 | 65 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 16 | 16 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FIGHT TO THE END | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 56 | not checked | - | - | - | - |
| FOOT FIRST | 50 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 29 | 26 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 8 | 7 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 18 | 15 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 45 | 45 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 44 | 42 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 24 | 21 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 29 | 28 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 35 | 31 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 69 | 66 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 11 | 11 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HOLD ODDS | 90 | 89 | 0 | 0.00 | - | - |
| HONEST WORTH | 20 | 18 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 2 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 5 | 4 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 4 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 6 | 6 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 1 | 0 | 0.00 | - | - |
| NEAREST TO GOAL | 3 | 3 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO LATE CUT | 1 | 1 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 3 | 3 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 34 | 19 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 20 | 12 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 1 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 227 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 8 | 7 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 6 | 6 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 8 | 8 | 0 | 0.00 | - | - |
| RUN DOWN | 14 | 13 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 5 | not checked | - | - | - | - |
| SET CREDITED ONCE | 6 | 6 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 26 | not checked | - | - | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SHOTS IN THE MOVE | 36 | 24 | 0 | 0.00 | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 3 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 35 | 32 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 4 | 4 | 0 | 0.00 | - | - |
| STANDS STILL | 150 | 147 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 5 | 4 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 3 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 18 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 10 | not checked | - | - | - | - |
| THE TABLE BINDS | 217 | not checked | - | - | - | - |
| WAITS AGAIN | 11 | 10 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | not checked | - | - | - | - |
| WHO FIGHTS | 2 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | not checked | - | - | - | - |
| WOUNDS ON THE RANKS | 12 | 12 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p69

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.33 | 2.33 | 26.7 |
| ARMY TABLE | rule | 3.67 | 2.67 | 61.0 |
| PROMISE BY ITS OWN SUM | rule | 2.33 | 1.67 | 93.8 |
| CHARGE NOW FIRST | rule | 2.00 | - | 32.4 |
| SUPPORT NARROWED | rule | 1.33 | 0.33 | 41.2 |
| HOLDER ASSIGNMENT | rule | 0.33 | 1.00 | 28.2 |
| MARCH OF THE TABLE | rule | 0.33 | 0.67 | 23.9 |
| NO REASON | gate | 1.00 | - | 68.7 |
| RULE SWITCHED OFF | gate | - | 1.00 | 44.9 |
| JOINT CHARGE NOW | rule | 0.33 | 0.33 | 19.5 |
| AFTERMATH BAND | gate | 0.33 | - | 0.6 |
| CARRIES OUT SET-UP | rule | - | 0.33 | 79.7 |
| FALLBACK | gate | - | 0.33 | 7.1 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.33 | 9.7 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 79.0 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 27.0 |
| REFUSING RETIRES | rule | 0.33 | - | 20.1 |
| SET UP BY THE SET | rule | 0.33 | - | 238.1 |

### Plans: gs3-83c8646-p69

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.7 | 73% | 522 | 146 | 28% |
| Mine | move | 28.0 | 94% | 1988 | 0 | 0% |
| Mine | shoot | 5.0 | 47% | 217 | 142 | 66% |
| Opponent | charge | 1.3 | 75% | 99 | 121 | 122% |
| Opponent | join | 3.7 | 91% | 123 | 0 | 0% |
| Opponent | move | 32.7 | 95% | 1629 | 0 | 0% |
| Opponent | shoot | 0.7 | 50% | 77 | 56 | 74% |
| Opponent | support | 0.7 | 50% | 2 | 0 | 0% |

### Battle groups: gs3-83c8646-p69

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.0 | 33% | 100% | 100% | 0% | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 2.3 | 100% | 71% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p69

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | 0 (3) | - | - | 0 (3) | - |
| Mine | Chaff | 2 | 150 (2) | 0 | 150 | 50 | 0% | 1.5 | 300 (1) | 0 (1) | - | 300 (1) | 0 (1) |
| Mine | Character | 8 | 47 (8) | 47 | 0 | 5 | 12% | 2.7 | 10 (4) | 72 (3) | 179 (1) | 37 (5) | 78 (3) |
| Mine | Clean-up | 1 | 154 (1) | 0 | 154 | 0 | 100% | - | 154 (1) | - | - | 154 (1) | - |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 4 | 0 (4) | 0 | 0 | 32 | 25% | 2.3 | 0 (3) | 0 (1) | - | 0 (3) | 0 (1) |
| Mine | Hammer | 3 | 48 (3) | 35 | 13 | 26 | 33% | 1.5 | 137 (1) | 18 (2) | - | 137 (1) | 18 (2) |
| Mine | Shooter | 6 | 13 (6) | 0 | 13 | 45 | 33% | 1.0 | 0 (3) | 32 (3) | - | 27 (3) | 0 (3) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 50 | 0% | 1.0 | 0 (2) | - | - | 0 (1) | 0 (1) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 56 | 20% | 4.0 | 0 (2) | 0 (3) | - | 0 (1) | 0 (4) |
| Opponent | Character | 10 | 25 (10) | 25 | 0 | 52 | 10% | 3.8 | 41 (4) | 34 (4) | 0 (1) | 55 (6) | 8 (3) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 0% | 3.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 6 | 0 (6) | 0 | 0 | 28 | 67% | 4.5 | 0 (3) | 0 (3) | - | 0 (4) | 0 (2) |
| Opponent | Hammer | 5 | 80 (5) | 42 | 38 | 0 | 20% | 3.0 | 96 (3) | 52 (2) | - | 85 (4) | 59 (1) |
| Opponent | Holder | 4 | 67 (4) | 0 | 67 | 17 | 75% | 3.0 | 45 (2) | 92 (2) | - | 73 (2) | 59 (2) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Wizard | 3 | 39 (3) | 39 | 0 | 0 | 33% | 3.0 | 0 (1) | 0 (1) | 90 (1) | 90 (1) | 0 (2) |

### Charged fights: gs3-83c8646-p69

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 1 | 0 | 925 | 3.0 | 1.0 | 308 | 101 | +208 | 2 of 3 | 2 of 3 | - | +208 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 495 | 3.0 | 1.0 | 165 | 33 | +132 | 1 of 3 | 2 of 3 | - | +132 |
| Mine | Lizardmen | 1 | 186 | 174 | 5.0 | 1.0 | 35 | 0 | +35 | 0 of 5 | 5 of 5 | - | +35 |
| **Mine** | all armies | 3 | 62 | 531 | 3.7 | 1.0 | 145 | 37 | +108 | 3 of 11 | 9 of 11 | - | +108 |
| Opponent | Vampire Counts | 1 | 0 | 501 | 3.0 | 1.0 | 167 | 0 | +167 | 1 of 3 | 2 of 3 | - | +167 |
| Opponent | Warriors of Chaos | 2 | 88 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| **Opponent** | all armies | 3 | 58 | 167 | 1.3 | 1.0 | 125 | 0 | +125 | 2 of 4 | 3 of 4 | - | +125 |

### Effective charges: gs3-83c8646-p69

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 3 | 0 | 0 | 0 | 1 (net +507) | 1 (net +116) | 1 (net +0) | 0 | 0% (0 of 3) |
| Mine | Kingdom of Bretonnia | 3 | 1 (net -100) | 0 | 0 | 0 | 1 (net +0) | 0 | 1 | 0% (0 of 2) |
| Mine | Lizardmen | 5 | 0 | 0 | 0 | 0 | 3 (net +43) | 1 (net +0) | 1 | 0% (0 of 4) |
| Opponent | Vampire Counts | 3 | 1 (net +0) | 0 | 0 | 1 (net +185) | 1 (net +316) | 0 | 0 | 0% (0 of 3) |
| Opponent | Warriors of Chaos | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: gs3-83c8646-p69

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 275 | 494 | -100 | 119 | 181 | -62 | -22.6 |
| Mine | 76-89% | 1 | 497 | 201 | +507 | 809 | 302 | +507 | +102.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 304 | 130 | +0 | 98 | 0 | +98 | +32.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 308 | 65 | +49 | 49 | 0 | +49 | +15.9 |
| Mine | No odds | 2 | 256 | 84 | +270 | 300 | 100 | +200 | +78.3 |
| Mine | All fights | 11 | 312 | 132 | +108 | 179 | 62 | +117 | +37.5 |
| Opponent | Long shot (under 50%) | 2 | 83 | 239 | +0 | 143 | 0 | +143 | +172.3 |
| Opponent | 76-89% | 1 | 186 | 185 | +185 | 185 | 0 | +185 | +99.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 471 | 141 | +316 | 316 | 0 | +316 | +67.1 |
| Opponent | All fights | 4 | 206 | 201 | +125 | 197 | 0 | +197 | +95.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p69 | move | 23 | 6 (26%) | 4 (17%) | 4 (17%) | 13 (57%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1727 |
| Invocation of Nehek | Opponent | L1727 |
| Ring of Doom | Mine | L1531 |
| Ring of Doom | Opponent | L1531 |

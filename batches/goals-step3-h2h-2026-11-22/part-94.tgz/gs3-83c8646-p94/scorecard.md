# Doctrine scorecard: gs3-83c8646-p94

### Scorecard: gs3-83c8646-p94

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1835 | 5 | 1 | Mine | yes | - | - | 1 | 4 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | yes | - | 5 | 1 | 3 | 0 | 0 | 0 | 0 |
| L2021 | 5 | 1 | Mine | yes | - | - | 0 | 7 | 0 | 0 | 0 | 130 |
| L2021 | 5 | 1 | Opponent | yes | - | - | 0 | 8 | 0 | 0 | 0 | 0 |
| L2123 | 5 | 1 | Mine | no | - | - | 0 | 6 | 0 | 0 | 0 | 500 |
| L2123 | 5 | 1 | Opponent | yes | - | 3 | 2 | 3 | 0 | 0 | 0 | 72 |
| **Average** | | | Mine | 67% | - | - | 0.3 | 5.7 | 0.0 | 0.0 | 0.0 | 210.0 |
| **Average** | | | Opponent | 100% | - | 4.0 | 1.0 | 4.7 | 0.0 | 0.0 | 0.0 | 24.0 |

### KPIs: gs3-83c8646-p94

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 11) | 0% (0 of 9) | 0% (0 of 20) |
| Winner chose to follow up after the loser gave ground |  | - | 75% (3 of 4); on the table 75% | 75% (3 of 4); on the table 75% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 100% (1 of 1); on the table 100% | 60% (3 of 5); on the table 60% | 67% (4 of 6); on the table 67% |
| Magic missiles tried each own turn | 50%+ | 21% (4 of 19) | 39% (7 of 18) | 30% (11 of 37) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 21% (4 of 19) | 39% (7 of 18) | 30% (11 of 37) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (14 of 21) | 67% (10 of 15) | 67% (24 of 36) |
| Points that never fought | lower | 84% (4138 of 4949) | 75% (4502 of 5999) | 79% (8640 of 10948) |
|   infantry points that never fought | lower | 87% (1035 of 1187) | 100% (1770 of 1770) | 95% (2805 of 2957) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 90% (18 of 20) | 69% (18 of 26) | 78% (36 of 46) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.0 uses a game | 50% (1 of 2); 1.0 uses a game | 75% (3 of 4); 1.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (1 of 2); 0.3 uses a game | 100% (1 of 1); 0.7 uses a game | 67% (2 of 3); 0.5 uses a game |
|   their share of the points of units over 100 pts | lower | 93% (3848 of 4133) | 63% (3224 of 5082) | 77% (7072 of 9215) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.3 (47%) | 3.3 (91%) | 5.7 (65%) |
| MARCHED: its unit marched | 0.7 (13%) | 0.3 (9%) | 1.0 (12%) |
| REAR RANK: in a rear rank | 0.7 (13%) | 0.0 (0%) | 0.7 (8%) |
| NOT OFFERED: not in the cast list | 1.3 (27%) | 0.0 (0%) | 1.3 (15%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 7.3 | 0.0 | 0.0 | 3.7 | 0.0 |
| not cast | 2.7 | 4.0 | 2.0 | 8.7 | 28.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 4.0 (100%) | 0.0 (0%) | 5.7 (65%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (12%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (75%) | 0.0 (0%) | 2.0 (100%) | 0.7 (8%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (7%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (15%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.7 (25%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 25.7 (92%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 48% (30 of 62) | 53% (57 of 107) | 51% (87 of 169) |
|   cavalry | - | 77% (20 of 26) | 77% (20 of 26) |
|   character | 100% (6 of 6) | 6% (1 of 16) | 32% (7 of 22) |
|   chariot | 50% (6 of 12) | 75% (9 of 12) | 62% (15 of 24) |
|   infantry | 31% (10 of 32) | 51% (27 of 53) | 44% (37 of 85) |
|   monster | 67% (8 of 12) | - | 67% (8 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.0 (9%) | 1.3 (8%) | 2.3 (9%) |
| CHARGED: it charged | 0.3 (3%) | 2.7 (16%) | 3.0 (11%) |
| IN COMBAT: it fought this turn or the last | 0.3 (3%) | 0.3 (2%) | 0.7 (2%) |
| NO TARGET IN RANGE | 5.7 (53%) | 8.7 (52%) | 14.3 (52%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (2%) | 0.3 (1%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (16%) | 3.3 (20%) | 5.0 (18%) |
| OTHER BAR | 1.7 (16%) | 0.0 (0%) | 1.7 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 9.0 | 3.0 | 70% | 5.5 pts | 49 pts |
| character | 2.3 | 0.3 | 86% | 1.6 pts | 4 pts |
| chariot | 5.0 | 1.3 | 87% | 6.9 pts | 35 pts |
| infantry | 12.3 | 4.3 | 73% | 12.5 pts | 154 pts |
| monster | 2.7 | 0.7 | 88% | 4.8 pts | 13 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.3 | 4.3 | 2.8 |
| Charges that made contact a game | 1.0 | 2.7 | 1.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.15 declared, 0.11 contact (27 units) | 0.39 declared, 0.24 contact (33 units) | 0.28 declared, 0.18 contact (60 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (2 of 3) | - | - | 67% (2 of 3) |
| Character in a unit | 100% (3 of 3) | 50% (1 of 2) | - | 80% (4 of 5) |
| Character on its own | 50% (1 of 2) | 100% (1 of 1) | 60% (3 of 5) | 62% (5 of 8) |
| Chariot | 50% (3 of 6) | - | - | 50% (3 of 6) |
| Infantry | 100% (11 of 11) | 100% (2 of 2) | - | 100% (13 of 13) |
| Monster | 50% (1 of 2) | 100% (5 of 5) | - | 86% (6 of 7) |
| Monstrous | 50% (1 of 2) | 100% (2 of 2) | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ogre Kingdoms | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 92% | 100% (7 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Skaven | 3 | - | 47% (9 of 19) | 84% | 82% (18 of 22) | 100% (2 of 2); 1.7 uses a game | 0.0 uses a game | 67% (2 of 3); 1.0 uses a game |
| Tomb Kings of Khemri | 1 | 50% (1 of 2); on the table 50% | 0% (0 of 6) | 43% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 67% (2 of 3); on the table 67% | 33% (2 of 6) | 89% | 75% (9 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p94, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 75% (3) | 33% (1) | 57% (4) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.00 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.67 | 0.00 | 0.67 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.00 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p94

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.0 | 1.7 |
| Strategy | Charge objectives carried out (made contact) | 50% (1 of 2) | 0% (0 of 11) |
| Strategy | Shoot objectives carried out (shot that target) | 20% (3 of 15) | 61% (17 of 28) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 2) |
| Strategy | Joined characters whose unit fought | 0% (0 of 2) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 0% (0 of 4) | 50% (2 of 4) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 5.7 | 4.7 |
| Movement | Points that never moved of their own | 210.0 | 24.0 |
| Movement | Fights charged into per game | 1.3 | 1.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 2 | 0 of 4 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | 1 of 4, net -70 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 2 | 1 of 4, net +210 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 2, net -35 | 1 of 4, net +145 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.0 | 20.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (15 of 30) | 42% (25 of 60) |
| Shooting | Points destroyed by shooting units | 70.0 | 61.7 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.0 | 3.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (1 of 3) | 11% (1 of 9) |
| Magic | Wounds caused by magic missiles | 5.3 | 6.0 |
| Magic | Points destroyed by magic (all spells) | 23.3 | 33.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.7 / 0.0 / 0.0 / 0.0 | 3.7 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 23.3 | 119.7 |
| Combat | Points run down | 0.0 | 59.0 |
| Combat | Net points per charged fight, damage counted | +9 | +128 |
| Combat | Net per 100 charger points, damage counted | +12.7 | +29.0 |
| Combat | First round won (charged fights) | 25% | 80% |
| Combat | Net points per charged fight | +11 | +134 |
| Combat | Net points per supported fight / lone fight | - / +11 | +226 / +73 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 4 | 1 of 5 |
| Game | Points lost | 554.3 | 190.0 |
| Game | VP from objectives | 550.0 | 583.3 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -382 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 744
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p94

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +16.0 | 0.0 | 0.0 |
| ARMY TABLE | 32.3 | +214.3 | 0.0 | 451.3 | 41.3 | +7.7 | 0.0 | 180.0 |
| BACKUP TARGETS | - | - | - | - | 1.0 | +7.0 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.3 | -5.9 | 37.3 | 0.0 |
| CAST JOB | 2.7 | +10.1 | 0.0 | 0.0 | 1.0 | +1.7 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 2.7 | +100.3 | 76.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 2.3 | +61.0 | 0.0 | 34.7 | 0.7 | +0.5 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +22.4 | 0.0 | 37.3 | - | - | - | - |
| CHARACTER GUNS | 2.0 | +0.0 | 0.0 | 148.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 18.0 | -649.1 | 0.0 | 338.0 | 19.3 | -298.3 | 0.0 | 245.3 |
| CHARGE NOW FIRST | - | - | - | - | 2.0 | +0.0 | 192.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.0 | +0.0 | 0.0 | 148.0 | 16.3 | +0.0 | 0.0 | 43.3 |
| COVER ONCE | 4.3 | -265.1 | 0.0 | 43.3 | 2.3 | -68.4 | 0.0 | 23.3 |
| DENIED BY THE FIGHT | 0.3 | -0.9 | 38.0 | 0.0 | 0.3 | -0.9 | 74.0 | 0.0 |
| DEPLOY BY FIGURES | 8.0 | +39.9 | 0.0 | 0.0 | 8.7 | -90.4 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.7 | -42.1 | 148.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +59.0 | 70.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 1.3 | +13.6 | 0.0 | 0.0 |
| EXACT ROUND | 0.3 | -0.7 | 38.0 | 0.0 | 3.0 | +35.3 | 268.3 | 23.3 |
| FALL BACK GOOD ORDER | 0.7 | +0.0 | 38.0 | 0.0 | 3.0 | +33.1 | 346.3 | 23.3 |
| FALLS SHORT | 10.7 | +123.0 | 0.0 | 107.0 | 15.0 | +174.9 | 0.0 | 76.0 |
| FEATURE BUFFS | 3.3 | +59.6 | 0.0 | 0.0 | 2.3 | +22.8 | 0.0 | 114.0 |
| FIGHT TO THE END | 0.3 | +3.2 | 38.0 | 0.0 | 1.0 | +4.8 | 122.3 | 23.3 |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 0.0 | 38.0 |
| FIVE ACTION | 98.7 | +4178.9 | 152.0 | 740.3 | 112.7 | +6463.5 | 1532.7 | 520.3 |
| FLANK NOT WEIGHED | 4.0 | +0.0 | 0.0 | 59.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | - | - | - | - | 0.3 | +39.9 | 0.0 | 0.0 |
| FOUR ROUNDS | 0.7 | +20.4 | 38.0 | 0.0 | 4.3 | +177.6 | 502.0 | 23.3 |
| FREED FROM HIS FIGHT | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -35.1 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.3 | -2.9 | 0.0 | 0.0 | 2.0 | -7.1 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.7 | -32.0 | 122.3 | 23.3 |
| GOAL ON TIME | 0.7 | +36.0 | 0.0 | 0.0 | - | - | - | - |
| GOAL ROUTE | 1.0 | +8.7 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 10.0 | +465.0 | 0.0 | 0.0 | 15.3 | +849.4 | 0.0 | 93.3 |
| GUN FIGURES | 4.0 | +27.6 | 0.0 | 105.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HARD STAY DROPPED | 2.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 7.3 | +0.0 | 0.0 | 214.7 | 3.3 | +0.0 | 0.0 | 76.0 |
| HIS CHARGE LIST | 6.7 | +0.0 | 0.0 | 21.7 | 1.0 | +0.0 | 0.0 | 76.0 |
| HIS LEGAL MOVES | 1.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 46.7 |
| HIS MOVE AND SHOT | 2.3 | -5.1 | 0.0 | 48.3 | 2.0 | -20.1 | 0.0 | 76.0 |
| HIS ONE QUARTER | 8.3 | +0.0 | 0.0 | 156.7 | 6.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 2.7 | +0.0 | 0.0 | 22.7 | 6.0 | +0.0 | 0.0 | 46.7 |
| HIS RANDOM MOVE | 19.0 | +0.0 | 0.0 | 43.3 | 24.3 | +0.0 | 0.0 | 301.7 |
| HIS RANDOM MOVER COMES | 3.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 63.3 | +1712.9 | 0.0 | 573.7 | 48.0 | +1536.5 | 0.0 | 286.0 |
| HIS SHOTS BY HIS RUN | 47.3 | +869.7 | 0.0 | 573.7 | 37.3 | +578.6 | 0.0 | 292.0 |
| HIS TURN DENIED | 0.7 | +44.8 | 38.0 | 0.0 | 1.7 | +66.4 | 187.3 | 23.3 |
| HOLD ODDS | 14.0 | +0.0 | 0.0 | 0.0 | 10.3 | +0.0 | 0.0 | 266.0 |
| HOLDER ASSIGNMENT | 6.0 | +591.8 | 0.0 | 0.0 | 4.3 | +202.5 | 0.0 | 76.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.7 | -5.9 | 38.0 | 0.0 | 3.3 | -125.0 | 331.3 | 0.0 |
| IDLE COST | 4.3 | -64.9 | 0.0 | 67.0 | 13.7 | -175.6 | 0.0 | 21.7 |
| JOINT CHARGE NOW | - | - | - | - | 1.3 | +134.3 | 191.3 | 0.0 |
| KEPT FROM ITS LAST STOP | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 1.0 | +47.3 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 1.7 | +0.0 | 38.0 | 22.7 | 3.7 | +0.0 | 73.0 | 266.0 |
| LONE WIZARD KEPT IN | 0.7 | +58.5 | 0.0 | 0.0 | 0.7 | +54.5 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | -5.3 | 38.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 0.7 | +6.5 | 38.0 | 0.0 | 0.7 | +0.1 | 96.7 | 23.3 |
| LURE BY WHAT IT DRAWS | 0.3 | -18.3 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 2.3 | -1.1 | 0.0 | 0.0 | 1.3 | -1.9 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.7 | +9.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.7 | +19.5 | 0.0 | 0.0 | 0.3 | +48.8 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +27.6 | 0.0 | 0.0 | 1.0 | +65.0 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.7 | +52.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | -21.7 | 0.0 | 0.0 | 0.3 | -17.8 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 0.7 | +6.0 | 0.0 | 11.3 | 1.0 | +8.9 | 0.0 | 0.0 |
| MEETS IN TIME | 2.7 | +13.9 | 0.0 | 0.0 | 2.0 | +2.7 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 5.3 | +81.1 | 0.0 | 74.0 | 4.7 | +60.0 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 5.7 | +49.1 | 0.0 | 74.0 | 5.0 | +57.9 | 0.0 | 0.0 |
| MOVE ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 61.3 | 0.0 |
| MOVE TO CHARGE COMPUTED | 2.0 | +87.3 | 0.0 | 84.3 | 4.3 | +478.8 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 10.3 | +507.7 | 0.0 | 0.0 | 9.7 | +405.3 | 0.0 | 38.0 |
| NEAREST TO GOAL | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 0.7 | +48.9 | 0.0 | 0.0 | 3.0 | +368.0 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 0.7 | -41.9 | 38.0 | 0.0 | 4.0 | -34.7 | 502.0 | 23.3 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.1 | 0.0 | 0.0 | 0.3 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 1.3 | -38.6 | 0.0 | 43.3 | 3.0 | -99.2 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 2.0 | -17.8 | 0.0 | 73.0 | 3.3 | -59.2 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | +32.6 | 148.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 3.7 | +133.3 | 0.0 | 0.0 | 3.3 | +33.3 | 0.0 | 76.0 |
| ONE PROMISE A TARGET | 0.7 | -12.3 | 0.0 | 22.7 | 1.0 | -146.5 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | - | - | - | - | 0.7 | +3.1 | 22.7 | 0.0 |
| OPENS UP | - | - | - | - | 2.0 | +161.5 | 139.0 | 0.0 |
| OVERRUNS AWAY | 0.3 | +4.1 | 0.0 | 0.0 | 1.0 | +24.6 | 115.0 | 0.0 |
| PATHS CROSS | 0.3 | +13.5 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PERIAPT WORTH | 0.7 | +75.1 | 0.0 | 0.0 | 0.3 | +22.3 | 0.0 | 0.0 |
| PLAN RESULT | 48.3 | +79.3 | 114.0 | 861.7 | 51.3 | +800.4 | 270.0 | 291.3 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 2.7 | -7.3 | 0.0 | 61.7 | 4.0 | -65.1 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 61.7 | - | - | - | - |
| PROMISE READS THE TABLE | 0.3 | -21.1 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 25.7 | +2144.5 | 0.0 | 156.7 | 33.0 | +3307.4 | 194.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 7.0 | +188.0 | 0.0 | 118.3 | 5.0 | +35.5 | 0.0 | 140.0 |
| REDIRECT COUNTER | 2.7 | -7.6 | 0.0 | 23.0 | - | - | - | - |
| REDIRECT FOR A FRIEND IN REACH | 1.3 | +0.0 | 0.0 | 23.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.7 | +16.2 | 107.3 | 0.0 |
| REFORMS TO MEET IT | 0.3 | -14.9 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 1.7 | +36.9 | 0.0 | 76.0 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.3 | +10.9 | 0.0 | 38.0 |
| RISK BY ARC | 0.7 | -1.6 | 38.0 | 0.0 | 3.3 | -24.3 | 388.7 | 23.3 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.0 | -28.7 | 133.0 | 0.0 |
| RUN DOWN | 0.7 | -23.1 | 38.0 | 0.0 | 2.0 | -2.3 | 330.3 | 23.3 |
| SCOUT SPOT | 0.7 | -0.2 | 0.0 | 0.0 | 0.7 | +2.2 | 0.0 | 0.0 |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 3.7 | -146.7 | 0.0 | 34.7 | 0.7 | -19.3 | 0.0 | 0.0 |
| SEARCH SPOT | - | - | - | - | 0.7 | -0.7 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.7 | +26.3 | 55.7 | 0.0 |
| SET UP BY THE SET | 0.7 | -3.7 | 0.0 | 0.0 | 2.0 | -38.8 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.7 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 5.7 | +0.0 | 0.0 | 0.0 | 9.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +38.5 | 0.0 | 0.0 | 1.0 | +27.1 | 48.3 | 0.0 |
| SHOT OR CHARGE | 0.3 | -30.5 | 38.0 | 0.0 | 0.7 | -8.1 | 43.3 | 0.0 |
| SHOT RISK POINTS | 24.7 | -18.0 | 0.0 | 329.0 | 29.3 | -140.6 | 0.0 | 286.0 |
| SHOTS AFTER THE MOVES | 1.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 11.3 | +207.5 | 0.0 | 179.0 | 17.7 | +379.4 | 0.0 | 76.0 |
| SPELL WORTH | 3.7 | +46.0 | 0.0 | 0.0 | 3.7 | +15.8 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 6.0 | +0.0 | 0.0 | 140.0 | 8.0 | +0.0 | 0.0 | 61.3 |
| STAND AND SHOOT | - | - | - | - | 1.3 | -5.4 | 113.3 | 23.3 |
| STANDS FOR A REASON | 2.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 269.3 | 0.0 |
| STANDS STILL | 47.0 | +0.0 | 114.0 | 151.7 | 46.3 | +0.0 | 1030.7 | 208.3 |
| STAY WORTH | 15.3 | +124.0 | 114.0 | 61.7 | 26.3 | +330.3 | 837.3 | 38.0 |
| STRIKE BY THE ODDS | 0.3 | +0.0 | 0.0 | 70.0 | - | - | - | - |
| STUBBORN BY POINTS | - | - | - | - | 0.3 | +6.8 | 0.0 | 0.0 |
| STUCK PIVOT | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 70.0 |
| SUPPORT ADDS | 3.7 | +97.7 | 0.0 | 0.0 | 8.0 | +55.9 | 0.0 | 46.7 |
| SUPPORT WORKED OUT | 3.7 | +97.7 | 0.0 | 0.0 | 8.0 | +55.9 | 0.0 | 46.7 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 11.3 | 4.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -18.2 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 4.7 | +0.0 | 0.0 | 43.3 | 5.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 4.0 | +0.0 | 0.0 | 37.3 | 5.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 45.7 | +0.0 | 0.0 | 311.0 | 52.0 | +0.0 | 0.0 | 167.7 |
| TIED UP BY THE SUM | - | - | - | - | 1.7 | +169.4 | 144.0 | 0.0 |
| TIME ON OUR SIDE | 41.7 | +311.2 | 0.0 | 191.7 | 21.3 | +149.1 | 0.0 | 138.3 |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -7.2 | 0.0 | 0.0 |
| WHO FIGHTS | 0.3 | -5.9 | 38.0 | 0.0 | - | - | - | - |
| WHO GETS IN | - | - | - | - | 0.7 | +109.9 | 148.0 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +18.4 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +0.9 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 5.3 | -295.8 | 0.0 | 140.0 | 2.0 | -29.5 | 0.0 | 76.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.7 | +35.4 | 148.0 | 0.0 |
| WOUNDS ON THE RANKS | 1.3 | +25.3 | 0.0 | 0.0 | 0.7 | +15.2 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p94

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 221 | 221 | 144 | 48.00 | +1235 | +8.6 |
| HIS SHOT LIST | 334 | 329 | 85 | 28.33 | +1243 | +14.6 |
| HIS SHOTS BY HIS RUN | 254 | 252 | 54 | 18.00 | +634 | +11.7 |
| DEPLOY BY FIGURES | 50 | 50 | 32 | 10.67 | +348 | +10.9 |
| HOLDER ASSIGNMENT | 31 | 31 | 31 | 10.33 | +1817 | +58.6 |
| QUARTER ODDS | 176 | 173 | 28 | 9.33 | +1749 | +62.5 |
| GOAL WALK | 76 | 76 | 27 | 9.00 | +1935 | +71.7 |
| RANDOM MOVE BY FIGURES | 36 | 36 | 24 | 8.00 | +671 | +27.9 |
| THE TABLE AGAIN | 36 | 36 | 22 | 7.33 | +0 | +0.0 |
| MOVE ORDER | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 19 | 18 | 17 | 5.67 | +776 | +45.7 |
| STAY WORTH | 125 | 110 | 17 | 5.67 | +275 | +16.2 |
| FIVE ACTION | 634 | 628 | 16 | 5.33 | +716 | +44.7 |
| LEGAL CHARGES ONLY | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| IDLE COST | 54 | 38 | 15 | 5.00 | +127 | +8.4 |
| SHOT RISK POINTS | 162 | 158 | 14 | 4.67 | +271 | +19.3 |
| TIME ON OUR SIDE | 189 | 177 | 14 | 4.67 | +66 | +4.7 |
| OFF BEST | 13 | 13 | 13 | 4.33 | -414 | -31.8 |
| ADVANCE LANE KEPT | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| HARD STAY DROPPED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 11 | 11 | 10 | 3.33 | +652 | +65.2 |
| CAST JOB | 11 | 11 | 9 | 3.00 | +7 | +0.7 |
| THE ROW IN ITS ORDER | 31 | 9 | 9 | 3.00 | +0 | +0.0 |
| CASTING BLOCK | 8 | 8 | 8 | 2.67 | +59 | +7.4 |
| CHAFF IN THE MOVE | 9 | 9 | 7 | 2.33 | +0 | +0.0 |
| HOLDS AMBUSHERS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| MEETS IN TIME | 14 | 14 | 6 | 2.00 | +74 | +12.4 |
| STUCK PIVOT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SUPPORT ADDS | 35 | 34 | 6 | 2.00 | +24 | +4.0 |
| SUPPORT WORKED OUT | 35 | 34 | 6 | 2.00 | +24 | +4.0 |
| ONE PROMISE A TARGET | 5 | 5 | 5 | 1.67 | -477 | -95.3 |
| PROMISE BY ITS OWN SUM | 20 | 20 | 5 | 1.67 | -217 | -43.4 |
| REDIRECT FOR A FRIEND IN REACH | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| RESERVE FALL BACK | 5 | 5 | 5 | 1.67 | +111 | +22.1 |
| SCOUT WAITS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 6 | 6 | 4 | 1.33 | -322 | -80.5 |
| FOUR ROUNDS | 15 | 14 | 4 | 1.33 | +151 | +37.7 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | +403 | +100.7 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +339 | +84.7 |
| MARCH CHECK | 5 | 5 | 4 | 1.33 | +118 | +29.4 |
| WHOLE FIGHT DANGER | 22 | 22 | 4 | 1.33 | +40 | +9.9 |
| FEATURE BUFFS | 17 | 17 | 3 | 1.00 | +55 | +18.2 |
| GOAL ROUTE | 3 | 3 | 3 | 1.00 | +26 | +8.8 |
| LANE BY FIGURES | 3 | 3 | 3 | 1.00 | +142 | +47.3 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +205 | +68.3 |
| ONE OBJECTIVE FORMULA | 21 | 15 | 3 | 1.00 | +145 | +48.4 |
| OPENS UP | 6 | 5 | 3 | 1.00 | +75 | +25.1 |
| PERIAPT WORTH | 3 | 3 | 3 | 1.00 | +292 | +97.4 |
| TIED UP BY THE SUM | 5 | 4 | 3 | 1.00 | +106 | +35.4 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| EXACT ROUND | 10 | 10 | 2 | 0.67 | +10 | +5.2 |
| GOAL ON TIME | 2 | 2 | 2 | 0.67 | -1 | -0.3 |
| HIS MOVE AND SHOT | 13 | 13 | 2 | 0.67 | +60 | +30.2 |
| HIS TURN DENIED | 7 | 7 | 2 | 0.67 | +86 | +42.8 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -156 | -78.0 |
| MISSILES IN THE MOVE | 30 | 19 | 2 | 0.67 | +4 | +2.2 |
| NEARER NOT NEEDED | 60 | 60 | 2 | 0.67 | +90 | +45.2 |
| OPENS A LANE | 2 | 2 | 2 | 0.67 | +6 | +3.1 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +40 | +20.2 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +184 | +92.2 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +79 | +39.4 |
| SET UP BY THE SET | 8 | 8 | 2 | 0.67 | +243 | +121.7 |
| SHOOTS FROM THE BEST SPOT | 7 | 7 | 2 | 0.67 | +0 | +0.0 |
| WHO GETS IN | 2 | 2 | 2 | 0.67 | +330 | +164.9 |
| WOUNDS ON THE RANKS | 6 | 6 | 2 | 0.67 | +45 | +22.3 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +48 | +48.0 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -18 | -17.6 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +67 | +67.2 |
| CHARGE LOSSES | 112 | 111 | 1 | 0.33 | +30 | +30.2 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +69 | +69.4 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +120 | +119.6 |
| MANOEUVRE | 11 | 11 | 1 | 0.33 | +1 | +1.2 |
| MAX FOR POSITIONING | 5 | 5 | 1 | 0.33 | +0 | +0.0 |
| NO DOUBLE ROUNDS | 14 | 13 | 1 | 0.33 | +74 | +74.0 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -3 | -2.7 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +33 | +32.7 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +4 | +4.2 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +20 | +20.3 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +17 | +17.1 |
| BACKUP TARGETS | 3 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 15 | 15 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 70 | 70 | 0 | 0.00 | - | - |
| COVER ONCE | 20 | 14 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| EVASIVE BY THE ODDS | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 11 | 11 | 0 | 0.00 | - | - |
| FALLS SHORT | 77 | 62 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 15 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 6 | 6 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 7 | 7 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 14 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 6 | 6 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 32 | 32 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 23 | 23 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 19 | 18 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 44 | 42 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 26 | 25 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 130 | 128 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 12 | 12 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 73 | 73 | 0 | 0.00 | - | - |
| HONEST WORTH | 12 | 11 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 4 | 4 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 4 | 4 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 32 | 21 | 0 | 0.00 | - | - |
| NEAREST TO GOAL | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 16 | 10 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 2 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 4 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 299 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 8 | 3 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 1 | 1 | 0 | 0.00 | - | - |
| RISK BY ARC | 12 | 11 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 8 | 7 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 13 | 13 | 0 | 0.00 | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 45 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 15 | 15 | 0 | 0.00 | - | - |
| SHOTS IN THE MOVE | 87 | 62 | 0 | 0.00 | - | - |
| SPELL WORTH | 22 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 42 | 34 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 19 | 19 | 0 | 0.00 | - | - |
| STANDS STILL | 280 | 278 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 17 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 27 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 16 | not checked | - | - | - | - |
| THE TABLE BINDS | 293 | not checked | - | - | - | - |
| WAITS AGAIN | 5 | 4 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p94

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| ARMY TABLE | rule | 3.67 | 3.67 | 50.6 |
| JOB FIRST | gate | 1.00 | 3.00 | 32.1 |
| ONE PROMISE A TARGET | rule | 0.67 | 1.00 | 95.3 |
| PROMISE BY ITS OWN SUM | rule | 0.67 | 1.00 | 43.4 |
| CHARGE NOW FIRST | rule | - | 1.33 | 80.5 |
| MARCH OF THE TABLE | rule | 0.67 | - | 78.0 |
| BEST PRIZE | rule | - | 0.33 | 17.6 |
| JOINT CHARGE NOW | rule | - | 0.33 | 31.6 |
| NO REASON | gate | 0.33 | - | 28.4 |
| REFUSING RETIRES | rule | - | 0.33 | 2.7 |

### Plans: gs3-83c8646-p94

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.7 | 0% | 57 | 6 | 11% |
| Mine | move | 42.0 | 91% | 1194 | 0 | 0% |
| Mine | shoot | 3.7 | 45% | 166 | 73 | 44% |
| Mine | support | 2.0 | 83% | 3 | 0 | 0% |
| Opponent | charge | 3.3 | 60% | 410 | 304 | 74% |
| Opponent | move | 41.3 | 97% | 1436 | 0 | 0% |
| Opponent | shoot | 6.3 | 74% | 556 | 497 | 89% |
| Opponent | support | 0.3 | 0% | 0 | 0 | - |

### Battle groups: gs3-83c8646-p94

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.7 | 12% | 100% | 0% | - | 0% | 0% | 0% | 0% | 100% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p94

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 5 | 0 (5) | 0 | 0 | 61 | 60% | 2.0 | 0 (2) | 0 (3) | - | 0 (5) | - |
| Mine | Character | 6 | 5 (6) | 5 | 0 | 21 | 33% | 2.5 | 0 (4) | - | - | 0 (3) | 0 (1) |
| Mine | Clean-up | 6 | 0 (6) | 0 | 0 | 37 | 67% | 4.0 | 0 (3) | 0 (3) | - | 0 (2) | 0 (4) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 0 | 0% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Hammer | 11 | 3 (11) | 3 | 0 | 40 | 36% | 1.9 | 0 (6) | 8 (5) | - | 0 (6) | 7 (5) |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | Shooter | 4 | 0 (4) | 0 | 0 | 72 | 25% | 2.0 | 0 (3) | 0 (1) | - | 0 (1) | 0 (3) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 0 | 33% | 2.0 | 0 (2) | 0 (1) | - | 0 (1) | 0 (2) |
| Opponent | Character | 8 | 42 (8) | 42 | 0 | 0 | 25% | 2.0 | 12 (6) | 94 (2) | - | 82 (4) | 0 (4) |
| Opponent | Clean-up | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (2) | - | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 6 | 58 (6) | 58 | 0 | 17 | 33% | 2.0 | 64 (5) | 0 (1) | - | 59 (4) | 58 (2) |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Hammer | 10 | 21 (10) | 21 | 0 | 19 | 70% | 2.0 | 6 (5) | 34 (5) | - | 10 (6) | 34 (4) |
| Opponent | Holder | 2 | 0 (2) | 0 | 0 | 0 | 50% | 4.0 | - | - | 0 (1) | - | 0 (1) |
| Opponent | Shooter | 8 | 0 (8) | 0 | 0 | 22 | 25% | 1.5 | 0 (4) | 0 (4) | - | 0 (3) | 0 (5) |

### Charged fights: gs3-83c8646-p94

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 1 | 0 | 114 | 3.0 | 1.0 | 38 | 11 | +27 | 0 of 3 | 0 of 3 | - | +27 |
| Mine | Skaven | 2 | 140 | 0 | 0.5 | 1.0 | 0 | 35 | -35 | 0 of 1 | 1 of 1 | - | -35 |
| **Mine** | all armies | 3 | 93 | 38 | 1.3 | 1.0 | 28 | 17 | +11 | 0 of 4 | 1 of 4 | - | +11 |
| Opponent | Skaven | 1 | 65 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 742 | 5.0 | 1.4 | 148 | 14 | +134 | 1 of 5 | 4 of 5 | +226 | +73 |
| Opponent | Wood Elf Realms | 1 | 219 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 95 | 247 | 1.7 | 1.4 | 148 | 14 | +134 | 1 of 5 | 4 of 5 | +226 | +73 |

### Effective charges: gs3-83c8646-p94

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 3 | 0 | 0 | 0 | 1 (net +114) | 0 | 0 | 2 | 0% (0 of 1) |
| Mine | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net -35) | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 5 | 0 | 0 | 1 (net -70) | 1 (net +145) | 1 (net +210) | 1 (net +145) | 1 | 25% (1 of 4) |

### Charged fights, damage counted: gs3-83c8646-p94

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 1 | 40 | 114 | +114 | 125 | 0 | +125 | +312.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 112 | 145 | -35 | 78 | 35 | +43 | +38.5 |
| Mine | No odds | 2 | 62 | 102 | -17 | 26 | 92 | -66 | -107.3 |
| Mine | All fights | 4 | 69 | 116 | +11 | 64 | 55 | +9 | +12.7 |
| Opponent | Effective (55-75%) | 1 | 70 | 145 | -70 | 0 | 70 | -70 | -100.0 |
| Opponent | 76-89% | 1 | 195 | 145 | +145 | 145 | 32 | +112 | +57.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 195 | 145 | +145 | 145 | 0 | +145 | +74.4 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 871 | 210 | +210 | 210 | 0 | +210 | +24.1 |
| Opponent | No odds | 1 | 871 | 112 | +242 | 242 | 0 | +242 | +27.8 |
| Opponent | All fights | 5 | 440 | 151 | +134 | 148 | 20 | +128 | +29.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p94 | move | 14 | 1 (7%) | 0 (0%) | 2 (14%) | 11 (79%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Fistful of Laurels | Mine | L1835 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L2021 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L2021 |

# Doctrine scorecard: gs3-83c8646-p36

### Scorecard: gs3-83c8646-p36

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2630 | 2 | 1 | Mine | - | - | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 1 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 351 |
| L2832 | 6 | 1 | Opponent | no | 6 | 3 | 3 | 5 | 0 | 0 | 0 | 195 |
| L3133 | 1 | 1 | Mine | no | 5 | 5 | 1 | 2 | 2 | 0 | 0 | 340 |
| L3133 | 1 | 1 | Opponent | no | 0 | - | 0 | 4 | 0 | 0 | 0 | 19 |
| **Average** | | | Mine | 0% | 2.5 | 4.0 | 1.0 | 1.7 | 0.7 | 0.0 | 0.0 | 230.3 |
| **Average** | | | Opponent | 0% | 3.0 | 2.0 | 2.0 | 3.7 | 0.0 | 0.0 | 0.0 | 71.3 |

### KPIs: gs3-83c8646-p36

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 15) | 29% (4 of 14) | 14% (4 of 29) |
| Winner chose to follow up after the loser gave ground |  | 100% (3 of 3); on the table 100% | - | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 33% (1 of 3); on the table 33% | 67% (2 of 3); on the table 67% | 50% (3 of 6); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 71% (5 of 7); on the table 71% | 67% (2 of 3); on the table 67% | 70% (7 of 10); on the table 70% |
| Magic missiles tried each own turn | 50%+ | 50% (12 of 24) | 67% (4 of 6) | 53% (16 of 30) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 67% (12 of 18) | 67% (4 of 6) | 67% (16 of 24) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 56% (5 of 9) | 42% (5 of 12) | 48% (10 of 21) |
| Points that never fought | lower | 36% (1980 of 5481) | 39% (2321 of 5999) | 37% (4301 of 11480) |
|   infantry points that never fought | lower | 33% (236 of 713) | 35% (367 of 1054) | 34% (603 of 1767) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 68% (15 of 22) | 50% (12 of 24) | 59% (27 of 46) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.0 uses a game | 100% (2 of 2); 3.0 uses a game | 100% (3 of 3); 2.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 66% (3474 of 5235) | 45% (2474 of 5492) | 55% (5948 of 10727) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (17%) | 0.7 (100%) | 1.3 (29%) |
| MARCHED: its unit marched | 1.0 (25%) | 0.0 (0%) | 1.0 (21%) |
| CHARGED: its unit charged | 0.3 (8%) | 0.0 (0%) | 0.3 (7%) |
| IN COMBAT: engaged in combat | 0.7 (17%) | 0.0 (0%) | 0.7 (14%) |
| FLEEING: fleeing | 1.3 (33%) | 0.0 (0%) | 1.3 (29%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 2.0 | 2.3 | 0.0 | 5.3 | 1.7 | 1.0 |
| not cast | 6.0 | 1.7 | 2.0 | 4.7 | 0.3 | 3.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (20%) | 0.0 (0%) | 1.3 (29%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (21%) | 0.0 (0%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (7%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (14%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 1.3 (22%) | 1.3 (80%) | 1.3 (67%) | 1.3 (29%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (100%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.7 (78%) | 0.0 (0%) | 0.7 (33%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.0 (100%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 25% (1 of 4) | 55% (23 of 42) | 52% (24 of 46) |
|   cavalry | 25% (1 of 4) | 75% (6 of 8) | 58% (7 of 12) |
|   character | - | 45% (10 of 22) | 45% (10 of 22) |
|   infantry | - | 58% (7 of 12) | 58% (7 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.3 (33%) | 1.0 (16%) | 1.3 (18%) |
| CHARGED: it charged | 0.0 (0%) | 1.7 (26%) | 1.7 (23%) |
| FLEEING: it fled or was fleeing | 0.3 (33%) | 0.3 (5%) | 0.7 (9%) |
| NO TARGET IN RANGE | 0.0 (0%) | 1.3 (21%) | 1.3 (18%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.7 (11%) | 0.7 (9%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (33%) | 1.3 (21%) | 1.7 (23%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.3 | 0.3 | 86% | 4.0 pts | 9 pts |
| character | 3.3 | 0.3 | 90% | 2.1 pts | 7 pts |
| infantry | 5.3 | 1.0 | 81% | 6.6 pts | 35 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.0 | 3.7 | 2.8 |
| Charges that made contact a game | 1.7 | 3.7 | 2.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.50 declared, 1.00 contact (2 units) | - | 1.50 declared, 1.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 2.00 declared, 2.00 contact (1 units) | 2.00 declared, 2.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.17 declared, 0.17 contact (18 units) | 0.39 declared, 0.39 contact (23 units) | 0.29 declared, 0.29 contact (41 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 44% (4 of 9) | 0% (0 of 1) | 50% (1 of 2) | 42% (5 of 12) |
| Character in a unit | 100% (3 of 3) | 0% (0 of 3) | 100% (2 of 2) | 62% (5 of 8) |
| Character on its own | 100% (4 of 4) | - | 50% (3 of 6) | 70% (7 of 10) |
| Infantry | 0% (0 of 3) | 67% (2 of 3) | 0% (0 of 1) | 29% (2 of 7) |
| Monster | 100% (5 of 5) | 0% (0 of 1) | - | 83% (5 of 6) |
| Monstrous | 100% (2 of 2) | 100% (1 of 1) | - | 100% (3 of 3) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vampire Counts | 1 | 100% (3 of 3); on the table 100% | 33% (4 of 12) | 18% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 4 | 57% (4 of 7); on the table 57% | 67% (8 of 12) | 35% | 52% (16 of 31) | 100% (1 of 1); 0.8 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
| Wood Elf Realms | 1 | - | 67% (4 of 6) | 67% | 80% (8 of 10) | 100% (2 of 2); 9.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p36, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 17% (1) | 100% (3) | 44% (4) |
| ...free all their last turn and able to turn (per game) | 0.33 | 1.00 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 1.00 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.33 | 0.00 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.33 | 0.00 | 0.33 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 1.00 | 0.00 | 1.00 |

### Quality by phase: gs3-83c8646-p36

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.0 | 1.0 |
| Strategy | Charge objectives carried out (made contact) | 88% (7 of 8) | 50% (4 of 8) |
| Strategy | Shoot objectives carried out (shot that target) | 0% (0 of 6) | 80% (4 of 5) |
| Strategy | Support requests answered (helper made contact too) | 100% (2 of 2) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 2) | 33% (2 of 6) |
| Strategy | Lone characters that fought | 71% (5 of 7) | 100% (3 of 3) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.7 | 3.7 |
| Movement | Points that never moved of their own | 230.3 | 71.3 |
| Movement | Fights charged into per game | 1.7 | 2.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 5 | 1 of 7, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 5, net -560 | 0 of 7 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 5, net -88 | 3 of 7, net +57 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 5, net +86 | 0 of 7 |
| Shooting | Shots by shooting units (incl. breath weapons) | 0.3 | 10.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 100% (1 of 1) | 10% (3 of 30) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 2.0 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (2 of 6) | 0% (0 of 4) |
| Magic | Wounds caused by magic missiles | 4.3 | 3.0 |
| Magic | Wounds caused by other spells | 0.7 | - |
| Magic | Points destroyed by magic (all spells) | 34.7 | 134.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.0 / 1.0 / 0.0 | 0.3 / 1.0 / 0.0 / 1.7 |
| Combat | Points destroyed in combat | 46.3 | 651.0 |
| Combat | Points run down | 0.0 | 117.0 |
| Combat | Net points per charged fight, damage counted | -33 | +126 |
| Combat | Net per 100 charger points, damage counted | -7.2 | +32.1 |
| Combat | First round won (charged fights) | 80% | 62% |
| Combat | Net points per charged fight | -95 | +121 |
| Combat | Net points per supported fight / lone fight | -324 / +58 | +110 / +123 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 5 | 4 of 8 |
| Game | Points lost | 872.3 | 348.3 |
| Game | VP from objectives | 400.0 | 753.3 |
| Game | Lone holders (player turns) | 2.5 | 3.0 |

- Mine won / drew / lost: 0 / 1 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -886 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 1221
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p36

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 11.7 | +57.5 | 0.0 | 287.0 | 13.0 | +144.6 | 0.0 | 104.0 |
| BACKUP TARGETS | - | - | - | - | 0.3 | +3.9 | 0.0 | 0.0 |
| CAST JOB | 3.7 | +71.8 | 104.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.7 | +26.9 | 0.0 | 0.0 | 1.7 | +23.9 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.7 | +1.5 | 0.0 | 75.7 | 0.7 | +21.6 | 0.0 | 104.0 |
| CHAMPION KNOWS CHALLENGE | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | - | - | - | - | 7.0 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 7.3 | -395.0 | 0.0 | 213.0 | 9.7 | -510.9 | 0.0 | 231.3 |
| CHARGE NOW FIRST | 2.7 | +0.0 | 92.3 | 38.7 | 0.7 | +0.0 | 56.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 12.7 | +0.0 | 0.0 | 314.7 | 7.3 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | - | - | - | - | 0.7 | +0.0 | 181.3 | 0.0 |
| COVER ONCE | 3.7 | -257.1 | 0.0 | 174.3 | 4.7 | -275.0 | 0.0 | 0.0 |
| DEFENSIVE ARMY | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 5.7 | +53.7 | 0.0 | 36.7 | 7.7 | +84.7 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 1.0 | -112.6 | 317.0 | 0.0 |
| EXACT ROUND | 0.7 | +17.6 | 34.7 | 58.7 | 1.7 | +13.5 | 184.0 | 0.0 |
| FACES THE THREAT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 2.0 | +0.3 | 208.3 | 205.3 | 1.3 | +0.0 | 317.0 | 159.7 |
| FALLS SHORT | 16.7 | +273.1 | 0.0 | 413.0 | - | - | - | - |
| FEATURE BUFFS | 2.7 | +138.7 | 0.0 | 0.0 | 0.7 | +1.6 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.7 | +18.0 | 36.7 | 0.0 |
| FIVE ACTION | 57.0 | +4041.5 | 312.3 | 1328.7 | 91.0 | +3361.7 | 501.0 | 876.3 |
| FLANK NOT WEIGHED | 5.0 | +0.0 | 0.0 | 75.3 | 5.3 | +0.0 | 0.0 | 264.0 |
| FOLLOW UP WEIGHED | 0.7 | +189.2 | 0.0 | 181.3 | - | - | - | - |
| FOOT FIRST | - | - | - | - | 25.7 | +0.0 | 0.0 | 142.7 |
| FOUR ROUNDS | 2.7 | +193.4 | 208.3 | 225.3 | 3.0 | +501.4 | 501.0 | 159.7 |
| FREED FROM HIS FIGHT | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 1.3 | -3.2 | 0.0 | 77.3 | - | - | - | - |
| GIVES UP | - | - | - | - | 0.7 | -14.6 | 135.7 | 0.0 |
| GOAL WALK | 4.3 | +485.5 | 0.0 | 0.0 | 5.0 | +267.7 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 5.0 | +0.0 | 0.0 | 213.0 | 5.0 | +0.0 | 0.0 | 162.0 |
| HIS CHARGE DENIED | - | - | - | - | 1.0 | +13.8 | 73.3 | 159.7 |
| HIS CHARGE LIST | 2.7 | +0.0 | 0.0 | 130.0 | 6.3 | +0.0 | 0.0 | 69.3 |
| HIS LEGAL MOVES | 3.0 | +0.0 | 0.0 | 73.3 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.7 | -42.3 | 0.0 | 0.0 | 1.3 | -25.7 | 0.0 | 69.3 |
| HIS ONE QUARTER | 1.3 | +0.0 | 0.0 | 0.0 | 8.7 | +0.0 | 0.0 | 104.0 |
| HIS OWN BEST MOVE | 8.0 | +0.0 | 0.0 | 484.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 8.0 | +0.0 | 0.0 | 422.7 | 12.7 | +0.0 | 0.0 | 138.7 |
| HIS RANDOM MOVER COMES | - | - | - | - | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 23.7 | +742.4 | 0.0 | 382.3 | 33.7 | +235.6 | 0.0 | 69.3 |
| HIS SHOTS BY HIS RUN | 18.3 | +400.9 | 0.0 | 491.0 | 21.7 | +88.7 | 0.0 | 212.0 |
| HIS TURN DENIED | 0.3 | +5.8 | 0.0 | 0.0 | 0.3 | +0.3 | 135.7 | 0.0 |
| HOLD ODDS | 13.3 | +0.0 | 0.0 | 0.0 | 20.3 | +0.0 | 0.0 | 185.3 |
| HOLDER ASSIGNMENT | 7.3 | +670.5 | 0.0 | 0.0 | 12.0 | +1270.7 | 0.0 | 92.7 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.0 | -94.5 | 208.3 | 205.3 | 2.3 | -125.8 | 427.7 | 159.7 |
| IDLE COST | 14.0 | -252.8 | 0.0 | 412.7 | - | - | - | - |
| JOINT CHARGE NOW | 1.3 | +25.9 | 92.7 | 186.7 | 0.7 | -42.3 | 172.3 | 0.0 |
| KEPT FROM ITS LAST STOP | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +12.7 | 0.0 | 0.0 | 1.0 | +41.8 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.7 | +0.0 | 46.3 | 428.3 | 3.3 | +0.0 | 216.3 | 0.0 |
| LOST AFTER ESCAPE | 2.3 | +3.9 | 185.0 | 225.3 | 2.3 | -3.4 | 444.3 | 159.7 |
| LURE BY WHAT IT DRAWS | 1.3 | -54.3 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 1.0 | +18.0 | 0.0 | 0.0 | 0.7 | -1.8 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +40.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.7 | +10.5 | 0.0 | 0.0 | 0.3 | +20.5 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +11.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.0 | -77.8 | 0.0 | 166.7 | - | - | - | - |
| MARCH WHEELS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.3 | +23.8 | 0.0 | 257.3 | 1.3 | +35.4 | 0.0 | 0.0 |
| MEETS IN TIME | 3.3 | +215.2 | 0.0 | 0.0 | 3.0 | +308.9 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 5.3 | +73.9 | 0.0 | 135.7 | 3.3 | +49.3 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 6.7 | +36.2 | 0.0 | 302.3 | 3.3 | +31.4 | 0.0 | 0.0 |
| MOVE ORDER | 1.7 | +0.0 | 20.0 | 135.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 8.3 | +784.9 | 0.0 | 559.7 | 3.7 | +213.9 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 4.7 | +155.5 | 0.0 | 155.7 | 8.3 | +405.3 | 0.0 | 26.7 |
| NEAREST TO GOAL | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 7.3 | +692.6 | 0.0 | 406.7 | 2.7 | +188.3 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.7 | -66.0 | 115.7 | 205.3 | 3.0 | -131.3 | 501.0 | 159.7 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT WORTH A CAST | 1.0 | -0.2 | 0.0 | 0.0 | 3.0 | -5.5 | 0.0 | 0.0 |
| OFF BEST | 3.7 | -161.7 | 0.0 | 75.7 | 3.7 | -107.7 | 0.0 | 34.7 |
| ONE CHALLENGE TEST | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 7.7 | -195.5 | 0.0 | 332.7 | 4.0 | -102.8 | 0.0 | 159.7 |
| ONE JOINT FIGURE | 0.3 | +45.2 | 0.0 | 20.0 | 0.7 | +41.6 | 172.3 | 0.0 |
| ONE OBJECTIVE FORMULA | 4.0 | +0.0 | 0.0 | 0.0 | 5.0 | +71.5 | 0.0 | 46.3 |
| ONE PROMISE A TARGET | 1.7 | -25.8 | 0.0 | 149.0 | - | - | - | - |
| ONE ROUTE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +16.5 | 23.3 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 1.0 | +61.2 | 58.0 | 38.7 | 0.3 | +0.2 | 181.3 | 0.0 |
| OWN CAST FIRST | 1.7 | -21.4 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.3 | -9.1 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 29.0 | +72.8 | 129.3 | 1238.0 | 43.0 | +329.9 | 201.3 | 585.7 |
| PROMISE BELOW ZERO | 0.7 | +0.0 | 0.0 | 15.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 9.3 | -223.2 | 0.0 | 0.0 | 7.0 | -84.1 | 0.0 | 0.0 |
| PROMISE IN STEPS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 0.7 | -0.6 | 0.0 | 0.0 | 0.7 | -5.1 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 1.3 | -7.6 | 0.0 | 77.3 | - | - | - | - |
| PURSUES BIG PREY | 0.3 | -15.9 | 0.0 | 0.0 | - | - | - | - |
| PURSUES ON | - | - | - | - | 0.3 | +18.3 | 0.0 | 0.0 |
| QUARTER ODDS | 7.7 | +1219.4 | 138.7 | 38.7 | 9.3 | +683.1 | 0.0 | 138.7 |
| RANDOM MOVE BY FIGURES | 3.0 | +38.3 | 0.0 | 56.7 | 4.0 | +7.4 | 0.0 | 0.0 |
| REAL GROUND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 2.0 | +207.7 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.7 | +150.3 | 0.0 | 30.0 | 1.3 | -23.0 | 0.0 | 23.3 |
| REDIRECT FOR A FRIEND IN REACH | 3.3 | +0.0 | 0.0 | 35.0 | 2.3 | +299.9 | 0.0 | 23.3 |
| REFORMS TO MEET IT | 2.7 | -224.0 | 0.0 | 333.3 | 1.0 | -63.0 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 1.0 | +27.0 | 0.0 | 0.0 | 0.3 | +1.5 | 0.0 | 0.0 |
| RISK BY ARC | 1.3 | -32.5 | 115.7 | 38.7 | 2.3 | +22.8 | 464.3 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.0 | -62.1 | 392.7 | 0.0 |
| RUN DOWN | 2.7 | -17.5 | 208.3 | 225.3 | 0.3 | -9.6 | 135.7 | 0.0 |
| SAFER THAN THE JOB | 0.3 | +3.3 | 0.0 | 0.0 | - | - | - | - |
| SAME CHARGE LATER | 1.3 | -28.9 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | 0.7 | -47.6 | 0.0 | 0.0 | 1.0 | -46.3 | 0.0 | 0.0 |
| SEARCH SPOT | - | - | - | - | 0.3 | +9.4 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +31.4 | 0.0 | 0.0 |
| SET CREDITED ONCE | 1.3 | -18.2 | 0.0 | 30.0 | - | - | - | - |
| SET UP BY THE SET | 1.7 | +56.9 | 0.0 | 30.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 3.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 159.7 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +0.7 | 0.0 | 0.0 | 1.3 | +32.1 | 0.0 | 319.3 |
| SHOT RISK POINTS | 13.3 | -46.8 | 0.0 | 134.0 | 7.7 | +157.8 | 0.0 | 138.7 |
| SHOTS AFTER THE MOVES | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 0.3 | +2.8 | 0.0 | 0.0 | 10.0 | +170.2 | 0.0 | 159.7 |
| SPELL WORTH | 1.3 | +9.5 | 0.0 | 117.0 | 1.0 | +3.4 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | -14.0 | 0.0 | 159.7 |
| SPOT AS THE GAME MOVES | 8.3 | +0.0 | 0.0 | 348.3 | 4.0 | +0.0 | 0.0 | 206.0 |
| STAND AND SHOOT | 0.3 | -6.5 | 0.0 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| STANDS STILL | 11.0 | +0.0 | 104.0 | 0.0 | 51.0 | +0.0 | 0.0 | 485.3 |
| STAY WORTH | 2.3 | +44.9 | 34.7 | 0.0 | 4.0 | +25.2 | 0.0 | 159.7 |
| STRIKE BY THE ODDS | - | - | - | - | 1.0 | +16.0 | 498.3 | 0.0 |
| STUBBORN BY POINTS | - | - | - | - | 0.3 | +5.1 | 0.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 3.0 | +201.6 | 0.0 | 0.0 | 4.7 | +149.9 | 0.0 | 69.3 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 36.7 | 0.0 |
| SUPPORT WORKED OUT | 3.0 | +201.6 | 0.0 | 0.0 | 4.7 | +149.9 | 0.0 | 69.3 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +11.0 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 1.3 | +5.6 | 0.0 | 37.0 | 0.3 | +21.2 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 38.7 | - | - | - | - |
| THE PROMISE ADDS | 0.3 | -4.9 | 0.0 | 0.0 | 0.3 | -23.8 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 4.0 | +0.0 | 36.7 | 114.3 | 2.7 | +0.0 | 0.0 | 206.0 |
| THE ROW KEEPS ITS WAY | 4.0 | +0.0 | 0.0 | 20.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 3.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 27.3 | +0.0 | 0.0 | 523.3 | 43.0 | +0.0 | 0.0 | 345.0 |
| TIED UP BY THE SUM | 0.7 | +86.6 | 92.3 | 38.7 | 0.7 | +77.9 | 56.7 | 0.0 |
| TIME ON OUR SIDE | - | - | - | - | 75.7 | +683.2 | 0.0 | 695.0 |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | 0.3 | +34.4 | 0.0 | 20.0 | 0.7 | +3.5 | 51.7 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +5.0 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 1.0 | -219.8 | 0.0 | 135.7 | 5.3 | -388.7 | 0.0 | 92.7 |
| WHOLE FIGHT GAIN | 0.3 | +21.1 | 0.0 | 20.0 | 0.7 | +72.2 | 172.3 | 0.0 |
| WOUNDS ON THE RANKS | 2.0 | +187.3 | 0.0 | 0.0 | 0.7 | +6.5 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p36

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 58 | 58 | 54 | 18.00 | +4661 | +86.3 |
| TIME ON OUR SIDE | 227 | 216 | 46 | 15.33 | +71 | +1.5 |
| HIS SHOT LIST | 172 | 167 | 42 | 14.00 | +255 | +6.1 |
| ARMY TABLE | 74 | 74 | 41 | 13.67 | +835 | +20.4 |
| FIVE ACTION | 444 | 429 | 28 | 9.33 | +2270 | +81.1 |
| MOVE TO CHARGE COMPUTED | 36 | 30 | 24 | 8.00 | +1383 | +57.6 |
| OFF BEST | 22 | 22 | 22 | 7.33 | -808 | -36.7 |
| HARD STAY DROPPED | 21 | 21 | 21 | 7.00 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 21 | 21 | 21 | 7.00 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 30 | 29 | 21 | 7.00 | +756 | +36.0 |
| DEPLOY BY FIGURES | 40 | 40 | 20 | 6.67 | +187 | +9.4 |
| HIS SHOTS BY HIS RUN | 120 | 115 | 19 | 6.33 | +41 | +2.1 |
| REDIRECT FOR A FRIEND IN REACH | 17 | 17 | 17 | 5.67 | +633 | +37.2 |
| THE TABLE AGAIN | 36 | 36 | 17 | 5.67 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 49 | 49 | 16 | 5.33 | -922 | -57.6 |
| QUARTER ODDS | 51 | 49 | 10 | 3.33 | +1144 | +114.5 |
| RANDOM MOVE BY FIGURES | 21 | 21 | 10 | 3.33 | +137 | +13.7 |
| MEETS IN TIME | 19 | 19 | 9 | 3.00 | +312 | +34.6 |
| FOUR ROUNDS | 17 | 16 | 8 | 2.67 | +589 | +73.6 |
| IDLE COST | 42 | 25 | 8 | 2.67 | +103 | +12.9 |
| CAST JOB | 11 | 11 | 7 | 2.33 | +45 | +6.4 |
| CHARGE NOW FIRST | 10 | 10 | 7 | 2.33 | -431 | -61.5 |
| SHOT RISK POINTS | 63 | 60 | 7 | 2.33 | +110 | +15.8 |
| SUPPORT ADDS | 23 | 23 | 7 | 2.33 | +139 | +19.9 |
| SUPPORT WORKED OUT | 23 | 23 | 7 | 2.33 | +139 | +19.9 |
| JOINT CHARGE NOW | 6 | 6 | 6 | 2.00 | -49 | -8.2 |
| MOVE ORDER | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 6 | 6 | 6 | 2.00 | +5 | +0.8 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHARGE LOSSES | 51 | 51 | 5 | 1.67 | +253 | +50.7 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| ONE PROMISE A TARGET | 5 | 5 | 5 | 1.67 | -78 | -15.5 |
| OWN CAST FIRST | 5 | 5 | 5 | 1.67 | -64 | -12.8 |
| STAY WORTH | 19 | 17 | 5 | 1.67 | +99 | +19.9 |
| SWIFTSTRIDE BY POINTS | 5 | 5 | 5 | 1.67 | +80 | +16.1 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +69 | +17.3 |
| GOAL WALK | 28 | 28 | 4 | 1.33 | +234 | +58.5 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +164 | +40.9 |
| MAX FOR POSITIONING | 14 | 12 | 4 | 1.33 | +0 | +0.0 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +85 | +21.4 |
| TIED UP BY THE SUM | 4 | 4 | 4 | 1.33 | +69 | +17.3 |
| WHOLE FIGHT DANGER | 19 | 19 | 4 | 1.33 | +88 | +22.0 |
| CHAFF IN THE MOVE | 7 | 7 | 3 | 1.00 | +0 | +0.0 |
| COVER ONCE | 25 | 18 | 3 | 1.00 | +142 | +47.3 |
| HIS MOVE AND SHOT | 15 | 15 | 3 | 1.00 | +27 | +9.1 |
| PROMISE KNOWS THE FIGHT | 4 | 4 | 3 | 1.00 | -17 | -5.7 |
| REDIRECT BY WHAT IT STOPS | 6 | 6 | 3 | 1.00 | +316 | +105.4 |
| STRIKE BY THE ODDS | 3 | 3 | 3 | 1.00 | +48 | +16.0 |
| STUCK PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 8 | 8 | 3 | 1.00 | +130 | +43.4 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FALLS SHORT | 50 | 35 | 2 | 0.67 | +44 | +22.1 |
| FEATURE BUFFS | 10 | 10 | 2 | 0.67 | +72 | +36.2 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +568 | +283.9 |
| MANOEUVRE | 5 | 5 | 2 | 0.67 | +54 | +27.0 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +120 | +60.2 |
| NEARER NOT NEEDED | 39 | 35 | 2 | 0.67 | +182 | +90.9 |
| OVERRUNS AWAY | 4 | 4 | 2 | 0.67 | +88 | +44.1 |
| RISK BY ARC | 11 | 10 | 2 | 0.67 | +40 | +20.2 |
| THE ROW IN ITS ORDER | 20 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 3 | 3 | 2 | 0.67 | +50 | +25.0 |
| EXACT ROUND | 7 | 7 | 1 | 0.33 | +45 | +44.7 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS CHARGE DENIED | 3 | 3 | 1 | 0.33 | +5 | +5.3 |
| MARCH CHECK | 3 | 3 | 1 | 0.33 | +29 | +28.8 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -34 | -34.0 |
| NO DOUBLE ROUNDS | 14 | 13 | 1 | 0.33 | +61 | +60.9 |
| ONE FIGHT FORMULA | 35 | 19 | 1 | 0.33 | +44 | +44.2 |
| ONE JOINT FIGURE | 3 | 3 | 1 | 0.33 | +45 | +44.7 |
| ONE OBJECTIVE FORMULA | 27 | 23 | 1 | 0.33 | +43 | +43.4 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -27 | -27.4 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.33 | -48 | -47.6 |
| PURSUES ON | 1 | 1 | 1 | 0.33 | +55 | +54.9 |
| REFUSING RETIRES | 3 | 3 | 1 | 0.33 | -0 | -0.4 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.33 | +10 | +10.0 |
| SEARCH SPOT | 1 | 1 | 1 | 0.33 | +28 | +28.3 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +94 | +94.2 |
| SET UP BY THE SET | 5 | 5 | 1 | 0.33 | +77 | +76.9 |
| SHOTS IN THE MOVE | 31 | 26 | 1 | 0.33 | +17 | +16.8 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +15 | +15.3 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -2 | -2.5 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 3 | 3 | 1 | 0.33 | +45 | +44.7 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +15 | +15.1 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 21 | 20 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 60 | 59 | 0 | 0.00 | - | - |
| DEFENSIVE ARMY | 8 | 8 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 3 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 10 | 9 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 2 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 31 | not checked | - | - | - | - |
| FOOT FIRST | 77 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 6 | 6 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 1 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 30 | 30 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 27 | 26 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 16 | 12 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 30 | 28 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 38 | 32 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 62 | 61 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 12 | 12 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HOLD ODDS | 101 | 101 | 0 | 0.00 | - | - |
| HONEST WORTH | 13 | 12 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 6 | 6 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 14 | 13 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 26 | 15 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 30 | 18 | 0 | 0.00 | - | - |
| NEAREST TO GOAL | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 3 | 3 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 12 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 216 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 4 | 4 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 9 | 7 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 11 | 9 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 9 | 9 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 5 | 5 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 19 | not checked | - | - | - | - |
| SHOTS AFTER THE MOVES | 4 | 4 | 0 | 0.00 | - | - |
| SPELL WORTH | 7 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 37 | 34 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 2 | 2 | 0 | 0.00 | - | - |
| STANDS STILL | 186 | 183 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 4 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 21 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 15 | not checked | - | - | - | - |
| THE TABLE BINDS | 211 | not checked | - | - | - | - |
| WAITS AGAIN | 8 | 8 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p36

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.00 | 2.67 | 29.3 |
| PROMISE BY ITS OWN SUM | rule | 3.00 | 2.33 | 57.6 |
| CHARGE NOW FIRST | rule | 2.00 | 0.33 | 61.5 |
| HOLDER ASSIGNMENT | rule | - | 2.00 | 32.1 |
| ARMY TABLE | rule | 0.33 | 1.33 | 54.3 |
| ONE PROMISE A TARGET | rule | 1.67 | - | 15.5 |
| OWN CAST FIRST | rule | 1.00 | - | 21.2 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | 0.67 | 5.7 |
| JOINT CHARGE NOW | rule | 0.33 | 0.33 | 81.9 |
| NO REASON | gate | - | 0.67 | 38.1 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.33 | - | 209.3 |
| FALLBACK | gate | - | 0.33 | 23.2 |
| FIGHT ORDER BAND | gate | 0.33 | - | 1.5 |
| MARCH OF THE TABLE | rule | 0.33 | - | 34.0 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 27.4 |
| PURSUES BIG PREY | rule | 0.33 | - | 47.6 |
| SUPPORT NARROWED | rule | - | 0.33 | 2.5 |

### Plans: gs3-83c8646-p36

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 67% | 98 | 68 | 69% |
| Mine | join | 1.7 | 100% | 62 | 0 | 0% |
| Mine | move | 24.0 | 90% | 1359 | 0 | 0% |
| Mine | shoot | 1.7 | 20% | 192 | 5 | 2% |
| Mine | support | 0.7 | 100% | 0 | 0 | - |
| Opponent | charge | 2.3 | 86% | 350 | 299 | 86% |
| Opponent | move | 37.7 | 97% | 1227 | 0 | 0% |
| Opponent | shoot | 1.7 | 60% | 17 | 30 | 181% |
| Opponent | support | 1.3 | 100% | 94 | 0 | 0% |

### Battle groups: gs3-83c8646-p36

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.7 | 40% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 1.3 | 25% | 100% | 100% | 100% | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p36

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 5 | 0 (5) | 0 | 0 | 67 | 40% | 4.0 | 0 (2) | 0 (1) | 0 (2) | 0 (4) | 0 (1) |
| Mine | Character | 7 | 26 (7) | 26 | 0 | 51 | 43% | 3.5 | 0 (3) | 32 (4) | - | 35 (6) | 0 (1) |
| Mine | Clean-up | 2 | 14 (2) | 0 | 14 | 100 | 0% | 1.5 | - | 27 (1) | 0 (1) | 14 (2) | - |
| Mine | Fast Hammer | 3 | 23 (3) | 0 | 23 | 90 | 33% | 3.0 | 0 (1) | 43 (2) | - | 23 (3) | - |
| Mine | Hammer | 4 | 13 (4) | 13 | 0 | 22 | 50% | 3.0 | 23 (3) | 0 (1) | - | 0 (2) | 23 (2) |
| Mine | Holder | 4 | 30 (4) | 0 | 30 | 0 | 50% | 4.0 | 0 (1) | 48 (2) | 0 (1) | 37 (3) | 0 (1) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 64 | 0% | 2.0 | - | 0 (2) | - | 0 (2) | - |
| Opponent | Chaff | 5 | 27 (5) | 27 | 0 | 42 | 80% | 1.0 | 0 (3) | 64 (1) | 0 (1) | 30 (4) | 0 (1) |
| Opponent | Character | 8 | 79 (8) | 79 | 0 | 17 | 0% | 2.9 | 0 (2) | 68 (4) | 192 (2) | 101 (6) | 0 (2) |
| Opponent | Clean-up | 4 | 25 (4) | 0 | 25 | 0 | 50% | 3.5 | - | 31 (3) | 0 (1) | 0 (2) | 44 (2) |
| Opponent | Fast Hammer | 6 | 114 (6) | 53 | 61 | 11 | 50% | 4.0 | 140 (3) | 107 (2) | 0 (1) | 117 (4) | 102 (2) |
| Opponent | Hammer | 5 | 38 (5) | 0 | 38 | 22 | 60% | 3.5 | - | 38 (5) | - | 52 (4) | 0 (1) |
| Opponent | Holder | 2 | 96 (2) | 0 | 96 | 100 | 50% | 6.0 | - | - | 151 (1) | - | 151 (1) |
| Opponent | Shooter | 2 | 61 (2) | 0 | 61 | 0 | 0% | 2.0 | 0 (1) | 130 (1) | - | 61 (2) | - |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |

### Charged fights: gs3-83c8646-p36

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 1 | 0 | 173 | 2.0 | 1.5 | 86 | 280 | -194 | 0 of 2 | 1 of 2 | -560 | +173 |
| Mine | Warriors of Chaos | 2 | 52 | 70 | 1.5 | 1.3 | 46 | 76 | -29 | 1 of 3 | 3 of 3 | -88 | +0 |
| **Mine** | all armies | 3 | 35 | 104 | 1.7 | 1.4 | 62 | 157 | -95 | 1 of 5 | 4 of 5 | -324 | +58 |
| Opponent | Warriors of Chaos | 2 | 0 | 758 | 4.0 | 1.1 | 190 | 69 | +121 | 4 of 8 | 5 of 8 | +110 | +123 |
| Opponent | Wood Elf Realms | 1 | 402 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 134 | 506 | 2.7 | 1.1 | 190 | 69 | +121 | 4 of 8 | 5 of 8 | +110 | +123 |

### Effective charges: gs3-83c8646-p36

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 2 | 0 | 0 | 1 (net -560) | 0 | 0 | 1 (net +173) | 0 | 50% (1 of 2) |
| Mine | Warriors of Chaos | 3 | 0 | 0 | 0 | 1 (net +0) | 1 (net -88) | 1 (net +0) | 0 | 0% (0 of 3) |
| Opponent | Warriors of Chaos | 8 | 1 (net +0) | 1 (net -479) | 0 | 2 (net +638) | 3 (net +57) | 0 | 1 | 0% (0 of 7) |

### Charged fights, damage counted: gs3-83c8646-p36

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 560 | 717 | -560 | 125 | 560 | -435 | -77.7 |
| Mine | 76-89% | 1 | 144 | 236 | +0 | 118 | 0 | +118 | +81.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 308 | 138 | +86 | 120 | 0 | +120 | +38.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 988 | 139 | -88 | 139 | 227 | -88 | -8.9 |
| Mine | All fights | 5 | 461 | 274 | -95 | 124 | 157 | -33 | -7.2 |
| Opponent | Long shot (under 50%) | 1 | 499 | 494 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 50-54% | 1 | 479 | 499 | -479 | 0 | 479 | -479 | -100.0 |
| Opponent | 76-89% | 2 | 280 | 201 | +638 | 674 | 35 | +638 | +228.4 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 376 | 99 | +57 | 57 | 0 | +57 | +15.1 |
| Opponent | No odds | 1 | 479 | 357 | +0 | 43 | 0 | +43 | +8.9 |
| Opponent | All fights | 8 | 393 | 256 | +121 | 195 | 69 | +126 | +32.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p36 | move | 23 | 5 (22%) | 5 (22%) | 3 (13%) | 15 (65%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2630 |
| Horn of the Wild Hunt | Opponent | L3133 |
| Ring of Doom | Mine | L3133 |
| Ring of Doom | Opponent | L3133 |

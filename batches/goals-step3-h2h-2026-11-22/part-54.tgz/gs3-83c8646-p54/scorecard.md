# Doctrine scorecard: gs3-83c8646-p54

### Scorecard: gs3-83c8646-p54

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0913 | 1 | 1 | Mine | no | 11 | - | 0 | 1 | 0 | 0 | 0 | 479 |
| L0913 | 1 | 1 | Opponent | no | 3 | 4 | 1 | 1 | 1 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 1 | - | 1 | 2 | 0 | 0 | 0 | 250 |
| L0930 | 6 | 1 | Opponent | no | 3 | 2 | 1 | 4 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 5 | - | 0 | 0 | 1 | 0 | 0 | 465 |
| L1021 | 1 | 1 | Opponent | no | 0 | - | 0 | 7 | 2 | 0 | 0 | 565 |
| **Average** | | | Mine | 0% | 5.7 | - | 0.3 | 1.0 | 0.3 | 0.0 | 0.0 | 398.0 |
| **Average** | | | Opponent | 0% | 2.0 | 3.0 | 0.7 | 4.0 | 1.0 | 0.0 | 0.0 | 235.0 |

### KPIs: gs3-83c8646-p54

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 86% (12 of 14) | 0% (0 of 14) | 43% (12 of 28) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% | 100% (3 of 3); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 31% (15 of 48) | 8% (1 of 12) | 27% (16 of 60) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 38% (15 of 40) | 8% (1 of 12) | 31% (16 of 52) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 83% (10 of 12) | 83% (10 of 12) |
| Points that never fought | lower | 80% (4782 of 5997) | 83% (4968 of 5999) | 81% (9750 of 11996) |
|   infantry points that never fought | lower | 93% (1487 of 1591) | 100% (1660 of 1660) | 97% (3147 of 3251) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 59% (20 of 34) | 65% (15 of 23) | 61% (35 of 57) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 1.7 uses a game | 50% (1 of 2); 2.0 uses a game | 75% (3 of 4); 1.8 uses a game |
| Bound items with another spell used |  | 0% (0 of 1); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 100% (2 of 2); 0.7 uses a game | 67% (2 of 3); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 57% (3217 of 5667) | 66% (3398 of 5150) | 61% (6615 of 10817) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 5.0 (45%) | 3.0 (82%) | 8.0 (55%) |
| MARCHED: its unit marched | 3.3 (30%) | 0.3 (9%) | 3.7 (25%) |
| IN COMBAT: engaged in combat | 0.7 (6%) | 0.0 (0%) | 0.7 (5%) |
| GONE: slain | 2.0 (18%) | 0.0 (0%) | 2.0 (14%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (9%) | 0.3 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 2.3 | 1.7 | 5.3 | 0.7 | 1.0 |
| not cast | 0.0 | 5.0 | 0.3 | 14.7 | 1.3 | 19.0 |
| NO TARGET: no enemy in range, sight and arc it may target | - | 2.0 (40%) | 0.0 (0%) | 8.0 (55%) | 0.3 (25%) | 0.0 (0%) |
| MARCHED: its unit marched | - | 0.0 (0%) | 0.0 (0%) | 3.7 (25%) | 1.0 (75%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | - | 0.7 (13%) | 0.0 (0%) | 0.7 (5%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | - | 2.0 (40%) | 0.0 (0%) | 2.0 (14%) | 0.0 (0%) | 2.0 (11%) |
| OTHER BAR: another bar (miscast, baggage ...) | - | 0.3 (7%) | 0.3 (100%) | 0.3 (2%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.0 (89%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.7 a game | 0.8 a game |
| stood (cast and not dispelled) | - | 80% (4 of 5) | 80% (4 of 5) |
| the unit moved after it | - | 0% (0 of 4) | 0% (0 of 4) |
| it charged on its next turn | - | 0% (0 of 4) | 0% (0 of 4) |
| the enemy charged it first | - | 0% (0 of 4) | 0% (0 of 4) |
| it fought by the end of its next turn | - | 0% (0 of 4) | 0% (0 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 4) | 0% (0 of 4) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (4 of 4) | 100% (4 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (73 of 112) | 68% (30 of 44) | 66% (103 of 156) |
|   character | 100% (6 of 6) | 47% (7 of 15) | 62% (13 of 21) |
|   chariot | 93% (13 of 14) | 67% (6 of 9) | 83% (19 of 23) |
|   infantry | 44% (22 of 50) | 82% (14 of 17) | 54% (36 of 67) |
|   monster | 60% (6 of 10) | - | 60% (6 of 10) |
|   war machine | 81% (26 of 32) | 100% (3 of 3) | 83% (29 of 35) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.0 (31%) | 0.7 (14%) | 4.7 (26%) |
| CHARGED: it charged | 0.3 (3%) | 1.0 (21%) | 1.3 (8%) |
| IN COMBAT: it fought this turn or the last | 0.3 (3%) | 0.3 (7%) | 0.7 (4%) |
| MOVED: a war machine that moved | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 4.7 (36%) | 2.0 (43%) | 6.7 (38%) |
| ONLY IN COMBAT: the only targets were in combat | 1.7 (13%) | 0.0 (0%) | 1.7 (9%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (5%) | 0.7 (14%) | 1.3 (8%) |
| OTHER BAR | 1.0 (8%) | 0.0 (0%) | 1.0 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| character | 4.7 | 1.7 | 71% | 3.2 pts | 15 pts |
| chariot | 6.3 | 1.0 | 84% | 6.4 pts | 40 pts |
| infantry | 16.0 | 10.7 | 56% | 9.4 pts | 150 pts |
| monster | 4.0 | 0.3 | 92% | 1.0 pts | 4 pts |
| war machine | 9.7 | 9.0 | 59% | 42.4 pts | 410 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.3 | 1.3 | 0.8 |
| Charges that made contact a game | 0.0 | 1.3 | 0.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (3 units) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.05 declared, 0.00 contact (19 units) | 0.17 declared, 0.17 contact (23 units) | 0.12 declared, 0.10 contact (42 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 40% (2 of 5) | - | - | 40% (2 of 5) |
| Character in a unit | 100% (6 of 6) | 100% (2 of 2) | - | 100% (8 of 8) |
| Character on its own | 100% (1 of 1) | 25% (1 of 4) | 50% (2 of 4) | 44% (4 of 9) |
| Chariot | 67% (2 of 3) | 100% (2 of 2) | - | 80% (4 of 5) |
| Infantry | 36% (5 of 14) | 100% (4 of 4) | - | 50% (9 of 18) |
| Monster | - | 50% (1 of 2) | - | 50% (1 of 2) |
| Monstrous | - | 100% (2 of 2) | - | 100% (2 of 2) |
| War Machines | 62% (5 of 8) | - | - | 62% (5 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 2 | - | 38% (9 of 24) | 79% | 67% (16 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | 100% (1 of 1); on the table 100% | 25% (6 of 24) | 82% | 40% (4 of 10) | 100% (2 of 2); 5.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| High Elf Realms | 1 | - | 17% (1 of 6) | 83% | 50% (4 of 8) | 100% (1 of 1); 6.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game |
| Skaven | 1 | - | 0% (0 of 6) | 89% | 67% (6 of 9) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 1 | 100% (2 of 2); on the table 100% | - | 76% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p54, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | - | 0% (0) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p54

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 0% (0 of 1) | 75% (3 of 4) |
| Strategy | Shoot objectives carried out (shot that target) | 17% (9 of 53) | 69% (9 of 13) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 2) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 9) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 20% (1 of 5) | 40% (2 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.0 | 4.0 |
| Movement | Points that never moved of their own | 398.0 | 235.0 |
| Movement | Fights charged into per game | 0.0 | 1.3 |
| Movement | Charges with odds: long shots (under 50%) | - | 0 of 3 |
| Movement | Charges with odds: sweet spot (55-75%) | - | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | - | 2 of 3, net +114 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | - | 1 of 3, net +227 |
| Shooting | Shots by shooting units (incl. breath weapons) | 15.7 | 9.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 57% (27 of 47) | 41% (12 of 29) |
| Shooting | Points destroyed by shooting units | 0.0 | 55.7 |
| Shooting | War machine shots | 8.7 | 1.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 77% (20 of 26) | 0% (0 of 3) |
| Shooting | Points destroyed by war machines | 325.7 | 0.0 |
| Magic | Magic missiles cast | 4.7 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 14% (2 of 14) | - |
| Magic | Wounds caused by magic missiles | 11.0 | 4.3 |
| Magic | Points destroyed by magic (all spells) | 87.7 | 34.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.7 / 0.0 / 0.0 | 2.7 / 0.7 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 70.0 | 329.3 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | - | +212 |
| Combat | Net per 100 charger points, damage counted | - | +47.6 |
| Combat | First round won (charged fights) | - | 100% |
| Combat | Net points per charged fight | - | +212 |
| Combat | Net points per supported fight / lone fight | - / - | - / +212 |
| Combat | Charged fights on a top-3 enemy unit | - | 2 of 4 |
| Game | Points lost | 620.3 | 540.7 |
| Game | VP from objectives | 793.3 | 663.3 |
| Game | Lone holders (player turns) | 5.7 | 2.0 |

- Mine won / drew / lost: 1 / 2 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +124 VP
- The side that went first won 0 of 1 games with a winner
- Points traded per game (both sides' losses): 1161
- Games not ended: 0; findings 2, warnings 0

### Opponent rules: gs3-83c8646-p54

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 18.0 | +335.6 | 0.0 | 250.0 | 24.0 | +347.2 | 0.0 | 293.0 |
| ARTILLERY RE-ROLL WEIGHED | 4.3 | +0.0 | 0.0 | 83.3 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.3 | +0.0 | 23.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 8.7 | +925.6 | 930.3 | 166.7 | 1.0 | +21.9 | 0.0 | 70.0 |
| CANNON SIGHT KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 5.3 | +117.9 | 224.3 | 0.0 | 0.7 | +11.1 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF PASSED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | - | - | - | - | 0.3 | +1.1 | 0.0 | 0.0 |
| CHARACTER GUNS | 3.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 15.0 | -888.4 | 0.0 | 138.7 | 33.7 | -2366.8 | 0.0 | 1472.0 |
| CHARGE NOW FIRST | - | - | - | - | 0.7 | +0.0 | 117.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 6.3 | +0.0 | 0.0 | 0.0 | 13.3 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 88.3 | 0.3 | +0.0 | 0.0 | 70.0 |
| CONVEYANCE SEARCH | - | - | - | - | 1.7 | +217.4 | 198.0 | 0.0 |
| COVER ONCE | 9.7 | -620.8 | 0.0 | 41.7 | 5.3 | -234.6 | 0.0 | 21.7 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -4.2 | 75.7 | 0.0 |
| DEPLOY BY FIGURES | 8.7 | -63.5 | 0.0 | 0.0 | 7.0 | +37.9 | 0.0 | 23.3 |
| EXACT ROUND | 0.3 | +0.4 | 0.0 | 0.0 | 0.7 | +13.2 | 83.3 | 0.0 |
| FALL BACK GOOD ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 159.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 26.7 | +240.7 | 0.0 | 127.0 |
| FEATURE BUFFS | 5.0 | +51.3 | 0.0 | 0.0 | 3.3 | +30.5 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 93.0 | +8284.2 | 2859.7 | 901.3 | 96.3 | +4116.5 | 360.3 | 1987.7 |
| FLANK NOT WEIGHED | 7.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 32.7 |
| FOLLOW UP WEIGHED | - | - | - | - | 0.3 | +120.2 | 0.0 | 0.0 |
| FOOT FIRST | 10.0 | +0.0 | 0.0 | 55.7 | - | - | - | - |
| FOUR ROUNDS | 0.3 | +4.6 | 0.0 | 0.0 | 1.3 | +56.6 | 193.7 | 0.0 |
| FREED FROM HIS FIGHT | 6.7 | +0.0 | 0.0 | 83.3 | 2.3 | +0.0 | 0.0 | 43.3 |
| FRIENDS SHOTS CHECKED | 0.3 | +10.9 | 0.0 | 123.0 | - | - | - | - |
| GOAL ON TIME | 0.7 | +280.0 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 10.0 | +1332.7 | 0.0 | 0.0 | 13.3 | +1635.0 | 0.0 | 0.0 |
| GUN FIGURES | 1.0 | +64.8 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 43.3 |
| GUN MASK | 3.3 | +47.9 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 2.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 4.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 43.3 |
| HIS CHARGE BY HIS RUN | 5.7 | +0.0 | 0.0 | 138.7 | 10.3 | +0.0 | 0.0 | 457.7 |
| HIS CHARGE LIST | 2.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 91.7 |
| HIS LEGAL MOVES | 3.0 | +0.0 | 0.0 | 69.3 | 1.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 0.7 | -16.4 | 0.0 | 0.0 | 14.0 | -147.7 | 0.0 | 352.7 |
| HIS ONE QUARTER | 2.0 | +0.0 | 0.0 | 0.0 | 10.7 | +0.0 | 0.0 | 1096.7 |
| HIS OWN BEST MOVE | 3.0 | +0.0 | 0.0 | 69.3 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 12.7 | +0.0 | 0.0 | 111.3 | - | - | - | - |
| HIS RANDOM MOVER COMES | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 35.7 | +733.0 | 0.0 | 416.7 | 78.3 | +4625.9 | 0.0 | 1014.3 |
| HIS SHOTS BY HIS RUN | 20.7 | +228.9 | 0.0 | 69.3 | 77.0 | +3017.4 | 0.0 | 1817.7 |
| HIS TURN DENIED | - | - | - | - | 1.0 | +46.6 | 152.0 | 0.0 |
| HOLD ODDS | 25.3 | +0.0 | 0.0 | 69.3 | 26.0 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 13.7 | +1260.6 | 0.0 | 34.7 | 13.3 | +1407.4 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.3 | -2.0 | 0.0 | 0.0 | 1.3 | -71.4 | 193.7 | 0.0 |
| IDLE COST | - | - | - | - | 15.7 | -286.1 | 0.0 | 222.7 |
| KEPT FROM ITS LAST STOP | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.7 | +11.3 | 0.0 | 0.0 | 0.7 | +40.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 0.7 | +0.0 | 70.0 | 211.3 | 2.0 | +0.0 | 171.7 | 0.0 |
| LONE WIZARD KEPT IN | 1.3 | +60.0 | 0.0 | 0.0 | 0.3 | +58.3 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | -1.2 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 0.3 | +1.5 | 0.0 | 0.0 | 0.3 | +0.2 | 34.7 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.7 | +4.5 | 0.0 | 99.0 |
| MANOEUVRE | 3.7 | +10.2 | 0.0 | 0.0 | 2.7 | -11.4 | 0.0 | 0.0 |
| MARCH BY THE SUM | 1.7 | +46.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 3.0 | +188.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.3 | +37.4 | 0.0 | 0.0 | 0.3 | +27.3 | 0.0 | 0.0 |
| MARCH OVER CASTS | 2.3 | -192.4 | 0.0 | 0.0 | 0.3 | -60.6 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.0 | +65.1 | 0.0 | 0.0 | 0.7 | +3.6 | 0.0 | 99.0 |
| MEETS IN TIME | 4.3 | +509.9 | 0.0 | 0.0 | 3.3 | +324.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 10.7 | +217.0 | 0.0 | 55.7 | 2.7 | +53.1 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 13.3 | +192.5 | 0.0 | 55.7 | 4.0 | +35.0 | 0.0 | 0.0 |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | - | - | - | - | 1.3 | +0.0 | 0.0 | 99.0 |
| MOVE TO CHARGE COMPUTED | 2.0 | +60.9 | 0.0 | 0.0 | 5.0 | +464.8 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 11.7 | +576.1 | 0.0 | 0.0 | 10.0 | +476.5 | 0.0 | 0.0 |
| NEAREST TO GOAL | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 2.0 | +80.3 | 140.0 | 0.0 | 4.7 | +444.1 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 0.3 | -5.8 | 0.0 | 0.0 | 1.3 | -40.6 | 193.7 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 4.0 | -92.2 | 0.0 | 34.7 | 3.3 | -194.9 | 0.0 | 21.7 |
| OGRE LOADER SECOND SHOT | 2.3 | +63.0 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.7 | -76.1 | 0.0 | 34.7 | 4.0 | -112.3 | 0.0 | 99.0 |
| ONE OBJECTIVE FORMULA | 8.0 | +18.1 | 0.0 | 34.7 | 6.0 | +253.1 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 1.3 | -73.7 | 0.0 | 0.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +3.7 | 34.7 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 1.3 | +43.2 | 193.7 | 0.0 |
| PERIAPT WORTH | - | - | - | - | 0.3 | +21.1 | 0.0 | 0.0 |
| PLAN RESULT | 40.7 | +767.9 | 1640.7 | 987.7 | 43.7 | +216.6 | 159.7 | 1074.7 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 7.7 | -193.5 | 0.0 | 0.0 | 4.7 | -40.5 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.3 | -14.7 | 140.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 16.7 | +1593.0 | 1887.7 | 0.0 | 18.7 | +1774.3 | 0.0 | 1134.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.0 | +134.9 | 0.0 | 166.7 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.3 | -5.5 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 0.3 | +3.6 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +15.9 | 88.3 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 75.7 | - | - | - | - |
| RISK BY ARC | 0.3 | +2.8 | 0.0 | 0.0 | 1.3 | -105.9 | 193.7 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.0 | -20.6 | 152.0 | 0.0 |
| RUN DOWN | 0.3 | -3.0 | 0.0 | 0.0 | 0.7 | -4.3 | 110.3 | 0.0 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 0.3 | +8.2 | 0.0 | 0.0 | 1.0 | +12.5 | 0.0 | 0.0 |
| SET CREDITED ONCE | 0.3 | -11.9 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 0.7 | +9.4 | 0.0 | 0.0 | 0.3 | +4.0 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.7 | +4.5 | 0.0 | 99.0 |
| SET-UP MISSED | - | - | - | - | 0.3 | +68.4 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 17.3 | +0.0 | 0.0 | 242.3 | 3.7 | +0.0 | 0.0 | 70.0 |
| SHOOTS FROM THE BEST SPOT | 2.0 | +26.9 | 65.3 | 0.0 | 3.3 | +51.4 | 166.7 | 0.0 |
| SHOT RISK POINTS | 8.0 | -128.3 | 0.0 | 0.0 | 52.3 | -539.9 | 0.0 | 1575.0 |
| SHOTS AFTER THE MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 23.0 | +1643.5 | 0.0 | 318.7 | 9.0 | +212.4 | 0.0 | 212.3 |
| SPELL WORTH | - | - | - | - | 4.0 | +120.5 | 360.0 | 360.0 |
| SPOT AS THE GAME MOVES | 3.7 | +0.0 | 0.0 | 34.7 | 7.0 | +0.0 | 0.0 | 147.3 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -3.4 | 34.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 5.0 | +0.0 | 0.0 | 198.0 |
| STANDS STILL | 50.0 | +0.0 | 2859.7 | 832.0 | 35.7 | +0.0 | 166.7 | 1380.3 |
| STAY WORTH | 42.3 | +771.1 | 1292.7 | 493.0 | 11.7 | +149.4 | 0.0 | 352.3 |
| SUPPORT ADDS | 5.3 | +231.5 | 0.0 | 0.0 | 1.0 | +26.2 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 5.3 | +231.5 | 0.0 | 0.0 | 1.0 | +26.2 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +0.2 | 0.0 | 0.0 | 0.3 | +1.8 | 0.0 | 99.0 |
| THE DEARER SUM KEEPS ITS PLAN | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.3 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 51.0 |
| THE STEP BACK IS MADE | 1.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 51.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 44.3 | +0.0 | 0.0 | 367.3 | 45.0 | +0.0 | 0.0 | 899.7 |
| TIED UP BY THE SUM | - | - | - | - | 1.0 | +132.1 | 159.0 | 0.0 |
| TIME ON OUR SIDE | 34.7 | +557.0 | 0.0 | 200.7 | - | - | - | - |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.3 | -1.1 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 8.7 | -730.4 | 0.0 | 138.7 | 1.7 | -119.3 | 0.0 | 246.3 |
| WOUNDS ON THE RANKS | 2.0 | +45.5 | 0.0 | 0.0 | 2.3 | +58.6 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p54

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 126 | 126 | 94 | 31.33 | +1809 | +19.2 |
| HIS SHOT LIST | 342 | 325 | 81 | 27.00 | +1352 | +16.7 |
| HOLDER ASSIGNMENT | 81 | 81 | 76 | 25.33 | +5213 | +68.6 |
| HIS SHOTS BY HIS RUN | 293 | 285 | 71 | 23.67 | +1486 | +20.9 |
| SHOT RISK POINTS | 181 | 179 | 41 | 13.67 | +1722 | +42.0 |
| DEPLOY BY FIGURES | 47 | 47 | 33 | 11.00 | +783 | +23.7 |
| GOAL WALK | 70 | 70 | 27 | 9.00 | +2532 | +93.8 |
| OFF BEST | 22 | 22 | 22 | 7.33 | -861 | -39.2 |
| CAST JOB | 18 | 18 | 18 | 6.00 | +227 | +12.6 |
| THE TABLE AGAIN | 36 | 36 | 18 | 6.00 | +0 | +0.0 |
| QUARTER ODDS | 106 | 99 | 17 | 5.67 | +1210 | +71.2 |
| STAY WORTH | 162 | 147 | 15 | 5.00 | +119 | +7.9 |
| CHARGE LOSSES | 146 | 140 | 14 | 4.67 | +1130 | +80.7 |
| ARTILLERY RE-ROLL WEIGHED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 37 | 37 | 13 | 4.33 | -702 | -54.0 |
| HARD STAY DROPPED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| MEETS IN TIME | 23 | 23 | 11 | 3.67 | +1042 | +94.7 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 104 | 82 | 11 | 3.67 | +45 | +4.1 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 10 | 3.33 | +404 | +40.4 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 20 | 18 | 9 | 3.00 | +314 | +34.9 |
| FIVE ACTION | 568 | 549 | 8 | 2.67 | +281 | +35.1 |
| IDLE COST | 47 | 37 | 8 | 2.67 | +67 | +8.4 |
| LEGAL CHARGES ONLY | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 16 | 16 | 8 | 2.67 | +39 | +4.9 |
| MARCH CHECK | 9 | 9 | 7 | 2.33 | +151 | +21.6 |
| MOVE TO CHARGE COMPUTED | 21 | 17 | 7 | 2.33 | +309 | +44.1 |
| OGRE LOADER SECOND SHOT | 7 | 7 | 7 | 2.33 | +189 | +27.0 |
| NEARER NOT NEEDED | 65 | 57 | 6 | 2.00 | +338 | +56.4 |
| SHOTS IN THE MOVE | 96 | 72 | 6 | 2.00 | +168 | +27.9 |
| COVER ONCE | 45 | 30 | 5 | 1.67 | +181 | +36.2 |
| LONE WIZARD KEPT IN | 5 | 5 | 5 | 1.67 | +355 | +71.0 |
| MARCH BY THE SUM | 5 | 5 | 5 | 1.67 | +138 | +27.6 |
| CASTER AWAY FROM SCREEN | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +154 | +38.5 |
| MAX FOR POSITIONING | 11 | 10 | 4 | 1.33 | +27 | +6.8 |
| ONE OBJECTIVE FORMULA | 42 | 31 | 4 | 1.33 | +235 | +58.9 |
| ONE PROMISE A TARGET | 4 | 4 | 4 | 1.33 | -221 | -55.3 |
| PROMISE KNOWS THE FIGHT | 4 | 4 | 4 | 1.33 | -44 | -11.0 |
| SUPPORT ADDS | 19 | 19 | 4 | 1.33 | +9 | +2.2 |
| SUPPORT WORKED OUT | 19 | 19 | 4 | 1.33 | +9 | +2.2 |
| CANNON PLANNED TARGET | 29 | 29 | 3 | 1.00 | +56 | +18.7 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MANOEUVRE | 19 | 19 | 3 | 1.00 | +72 | +24.0 |
| REDIRECT FOR A FRIEND IN REACH | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SEARCH SPOT | 4 | 4 | 3 | 1.00 | +62 | +20.7 |
| THE ROW IN ITS ORDER | 19 | 3 | 3 | 1.00 | +0 | +0.0 |
| TIED UP BY THE SUM | 3 | 3 | 3 | 1.00 | +245 | +81.6 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FALLS SHORT | 80 | 62 | 2 | 0.67 | +4 | +2.1 |
| FOUR ROUNDS | 5 | 5 | 2 | 0.67 | +55 | +27.6 |
| GOAL ON TIME | 2 | 2 | 2 | 0.67 | -23 | -11.3 |
| GUN MASK | 10 | 10 | 2 | 0.67 | +10 | +5.0 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -194 | -96.9 |
| ONE FIGHT FORMULA | 23 | 10 | 2 | 0.67 | +21 | +10.7 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| SHOTS AFTER THE MOVES | 22 | 22 | 2 | 0.67 | +0 | +0.0 |
| SURE REACH TOGETHER | 2 | 2 | 2 | 0.67 | +3 | +1.3 |
| WAR ENGINE JOBS | 4 | 4 | 2 | 0.67 | -63 | -31.6 |
| WOUNDS ON THE RANKS | 13 | 13 | 2 | 0.67 | +1 | +0.4 |
| ADVANCE LANE KEPT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +3 | +3.3 |
| CHARGE NOW FIRST | 2 | 2 | 1 | 0.33 | -46 | -46.0 |
| FEATURE BUFFS | 25 | 25 | 1 | 0.33 | +7 | +6.8 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +360 | +360.5 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +33 | +32.8 |
| HIS MOVE AND SHOT | 44 | 44 | 1 | 0.33 | +0 | +0.3 |
| MISSILES IN THE MOVE | 40 | 30 | 1 | 0.33 | +5 | +4.8 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +63 | +63.3 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +94 | +93.9 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -3 | -2.6 |
| RISK BY ARC | 5 | 5 | 1 | 0.33 | +6 | +5.9 |
| SET UP BY THE SET | 3 | 3 | 1 | 0.33 | +7 | +6.8 |
| SET UP TOGETHER | 2 | 1 | 1 | 0.33 | +1 | +1.3 |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 4 | trace | - | - | - | - |
| CHARACTER GUNS | 23 | 23 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 59 | 59 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 5 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 3 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 31 | not checked | - | - | - | - |
| FOOT FIRST | 30 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 27 | 25 | 0 | 0.00 | - | - |
| GUN FIGURES | 5 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 18 | 18 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 48 | 46 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 21 | 21 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 14 | 11 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 38 | 38 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 22 | 19 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 38 | 34 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 18 | 14 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 3 | 3 | 0 | 0.00 | - | - |
| HOLD ODDS | 154 | 154 | 0 | 0.00 | - | - |
| HONEST WORTH | 5 | 5 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 12 | 12 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 2 | 2 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH OVER CASTS | 8 | 8 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 5 | 5 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 52 | 35 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NEAREST TO GOAL | 2 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 5 | 5 | 0 | 0.00 | - | - |
| NO LATE CUT | 5 | 5 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE ROUTE | 5 | 5 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 4 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 253 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 5 | 5 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 3 | 3 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 63 | not checked | - | - | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 32 | 27 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 15 | 13 | 0 | 0.00 | - | - |
| STANDS STILL | 257 | 242 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 3 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 26 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 17 | not checked | - | - | - | - |
| THE TABLE BINDS | 268 | not checked | - | - | - | - |
| WAITS AGAIN | 7 | 7 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 31 | 25 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p54

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.00 | 2.67 | 37.7 |
| ARMY TABLE | rule | 1.67 | 3.33 | 43.0 |
| PROMISE BY ITS OWN SUM | rule | 3.67 | 0.67 | 54.0 |
| HOLDER ASSIGNMENT | rule | 1.00 | 0.67 | 23.2 |
| ONE PROMISE A TARGET | rule | - | 1.33 | 55.3 |
| PROMISE KNOWS THE FIGHT | rule | 1.33 | - | 11.0 |
| GOAL ON TIME | rule | 0.67 | - | 11.3 |
| MARCH OF THE TABLE | rule | 0.33 | 0.33 | 96.9 |
| RULE SWITCHED OFF | gate | - | 0.67 | 53.5 |
| WAR ENGINE JOBS | rule | 0.67 | - | 31.6 |
| CHARGE NOW FIRST | rule | - | 0.33 | 46.0 |
| REFUSING RETIRES | rule | 0.33 | - | 2.6 |

### Plans: gs3-83c8646-p54

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.3 | 0% | 5 | 0 | 0% |
| Mine | join | 0.3 | 100% | 4 | 0 | 0% |
| Mine | move | 24.3 | 93% | 1651 | 0 | 0% |
| Mine | shoot | 15.7 | 45% | 1757 | 768 | 44% |
| Opponent | charge | 1.0 | 100% | 55 | 159 | 290% |
| Opponent | move | 39.0 | 95% | 2228 | 0 | 0% |
| Opponent | shoot | 3.7 | 27% | 125 | 58 | 46% |

### Battle groups: gs3-83c8646-p54

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 0.3 | 100% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p54

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 10 | 23 (10) | 23 | 0 | 23 | 40% | 3.5 | 26 (5) | 19 (5) | - | 27 (7) | 11 (3) |
| Mine | Clean-up | 3 | 66 (3) | 0 | 66 | 0 | 100% | - | 16 (1) | 92 (2) | - | 66 (3) | - |
| Mine | Fast Hammer | 3 | 6 (3) | 0 | 6 | 36 | 0% | 1.3 | 9 (2) | - | 0 (1) | 6 (3) | - |
| Mine | Hammer | 6 | 0 (6) | 0 | 0 | 35 | 33% | 1.8 | 0 (2) | 0 (4) | - | 0 (5) | 0 (1) |
| Mine | Shooter | 6 | 135 (6) | 0 | 135 | 33 | 0% | 1.8 | 0 (1) | 163 (3) | 159 (2) | 135 (6) | - |
| Mine | War machine | 8 | 90 (8) | 90 | 0 | 58 | 12% | 1.3 | 117 (3) | 0 (3) | 164 (2) | 0 (1) | 102 (7) |
| Mine | Wizard | 4 | 41 (4) | 41 | 0 | 0 | 0% | 3.0 | 0 (1) | 54 (3) | - | 0 (3) | 163 (1) |
| Opponent | Chaff | 2 | 72 (2) | 0 | 72 | 44 | 100% | - | 129 (1) | 0 (1) | - | 129 (1) | 0 (1) |
| Opponent | Character | 9 | 36 (9) | 36 | 0 | 31 | 44% | 2.6 | 0 (1) | 39 (7) | 66 (1) | 15 (5) | 64 (4) |
| Opponent | Clean-up | 3 | 67 (3) | 0 | 67 | 0 | 100% | - | 0 (1) | 122 (2) | - | 122 (2) | 0 (1) |
| Opponent | Fast Hammer | 6 | 40 (6) | 0 | 40 | 10 | 83% | 1.0 | - | 65 (4) | 0 (2) | 40 (6) | - |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Hammer | 4 | 80 (4) | 80 | 0 | 53 | 25% | 2.3 | - | 104 (2) | 53 (2) | 80 (4) | - |
| Opponent | Holder | 4 | 8 (4) | 0 | 8 | 28 | 100% | - | - | 8 (4) | - | 0 (1) | 10 (3) |
| Opponent | Shooter | 4 | 22 (4) | 22 | 0 | 28 | 25% | 1.7 | 0 (1) | 0 (1) | 31 (2) | 26 (3) | 0 (1) |
| Opponent | War machine | 2 | 0 (2) | 0 | 0 | 100 | 0% | 1.0 | - | - | 0 (2) | 0 (1) | 0 (1) |

### Charged fights: gs3-83c8646-p54

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 268 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Grand Cathay | 1 | 705 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 413 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 1 | 104 | 227 | 1.0 | 1.0 | 227 | 0 | +227 | 1 of 1 | 1 of 1 | - | +227 |
| Opponent | Skaven | 1 | 167 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Warriors of Chaos | 1 | 0 | 619 | 3.0 | 1.0 | 206 | 0 | +206 | 1 of 3 | 3 of 3 | - | +206 |
| **Opponent** | all armies | 3 | 90 | 282 | 1.3 | 1.0 | 212 | 0 | +212 | 2 of 4 | 4 of 4 | - | +212 |

### Effective charges: gs3-83c8646-p54

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | High Elf Realms | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +227) | 0 | 0% (0 of 1) |
| Opponent | Warriors of Chaos | 3 | 0 | 0 | 0 | 0 | 2 (net +114) | 0 | 1 | 0% (0 of 2) |

### Charged fights, damage counted: gs3-83c8646-p54

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 342 | 227 | +227 | 227 | 0 | +227 | +66.4 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 479 | 114 | +114 | 114 | 0 | +114 | +23.9 |
| Opponent | No odds | 1 | 479 | 265 | +390 | 390 | 0 | +390 | +81.4 |
| Opponent | All fights | 4 | 445 | 180 | +212 | 212 | 0 | +212 | +47.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p54 | move | 14 | 2 (14%) | 2 (14%) | 1 (7%) | 11 (79%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Periapt of Soul Exchange | Opponent | L1021 |
| Ring of Jet | Mine | L1021 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Opponent | L1021 |
| Twice-Blessed Armour | Mine | L1021 |

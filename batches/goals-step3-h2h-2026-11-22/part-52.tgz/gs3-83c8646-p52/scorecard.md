# Doctrine scorecard: gs3-83c8646-p52

### Scorecard: gs3-83c8646-p52

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0524 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 285 |
| L0524 | 2 | 1 | Opponent | - | - | - | 1 | 5 | 1 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 500 |
| L0612 | 6 | 1 | Opponent | no | 7 | 5 | 1 | 0 | 1 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | - | 0 | 4 | 0 | 0 | 0 | 576 |
| L0628 | 4 | 1 | Opponent | no | 10 | 6 | 1 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 0.0 | - | 0.0 | 2.7 | 0.0 | 0.0 | 0.0 | 453.7 |
| **Average** | | | Opponent | 0% | 8.5 | 5.5 | 1.0 | 2.3 | 0.7 | 0.0 | 0.0 | 110.0 |

### KPIs: gs3-83c8646-p52

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 100% (15 of 15) | 0% (0 of 13) | 54% (15 of 28) |
| Winner chose to follow up after the loser gave ground |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | - | 0% (0 of 1); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 0% (0 of 1); on the table 0% | 100% (1 of 1); on the table 100% | 50% (1 of 2); on the table 50% |
| Magic missiles tried each own turn | 50%+ | - | 30% (9 of 30) | 30% (9 of 30) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 41% (9 of 22) | 41% (9 of 22) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 77% (4637 of 6000) | 71% (4252 of 5998) | 74% (8889 of 11998) |
|   infantry points that never fought | lower | 81% (1810 of 2232) | 100% (694 of 694) | 86% (2504 of 2926) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 52% (14 of 27) | 57% (13 of 23) | 54% (27 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (3 of 3); 2.3 uses a game | 100% (3 of 3); 1.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 46% (1967 of 4232) | 64% (3687 of 5787) | 56% (5654 of 10019) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.7 (24%) | 1.7 (24%) |
| MARCHED: its unit marched | - | 2.7 (38%) | 2.7 (38%) |
| IN COMBAT: engaged in combat | - | 0.7 (10%) | 0.7 (10%) |
| GONE: slain | - | 2.0 (29%) | 2.0 (29%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 5.7 | 0.7 | 3.0 | 1.0 | 1.3 |
| not cast | 2.3 | 3.3 | 7.0 | 3.0 | 22.7 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (60%) | 1.7 (24%) | 0.3 (11%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 2.7 (38%) | 1.3 (44%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.7 (10%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.7 (29%) | 1.3 (40%) | 2.0 (29%) | 1.3 (44%) | 2.7 (12%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (71%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 20.0 (88%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (136 of 208) | 89% (8 of 9) | 66% (144 of 217) |
|   cavalry | 50% (10 of 20) | 50% (1 of 2) | 50% (11 of 22) |
|   character | 85% (22 of 26) | - | 85% (22 of 26) |
|   infantry | 53% (31 of 59) | - | 53% (31 of 59) |
|   monster | 67% (8 of 12) | - | 67% (8 of 12) |
|   war machine | 71% (65 of 91) | 100% (7 of 7) | 73% (72 of 98) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.3 (18%) | 0.3 (100%) | 4.7 (19%) |
| IN COMBAT: it fought this turn or the last | 0.3 (1%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET IN RANGE | 10.0 (42%) | 0.0 (0%) | 10.0 (41%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 7.3 (31%) | 0.0 (0%) | 7.3 (30%) |
| SHELTERED: the target was sheltered | 1.7 (7%) | 0.0 (0%) | 1.7 (7%) |
| OTHER BAR | 0.3 (1%) | 0.0 (0%) | 0.3 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.7 | 0.7 | 82% | 5.8 pts | 21 pts |
| character | 8.3 | 6.0 | 56% | 8.3 pts | 69 pts |
| infantry | 21.3 | 5.0 | 80% | 2.4 pts | 51 pts |
| monster | 3.0 | 1.0 | 67% | 8.8 pts | 26 pts |
| war machine | 24.0 | 14.3 | 74% | 24.5 pts | 587 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.0 | 2.3 | 1.2 |
| Charges that made contact a game | 0.0 | 1.7 | 0.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.33 declared, 0.33 contact (3 units) | 0.33 declared, 0.33 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.50 declared, 0.50 contact (2 units) | 0.50 declared, 0.50 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.00 declared, 0.00 contact (21 units) | 0.42 declared, 0.25 contact (12 units) | 0.15 declared, 0.09 contact (33 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 0% (0 of 4) | 100% (1 of 1) | 50% (1 of 2) | 29% (2 of 7) |
| Character in a unit | 62% (5 of 8) | 50% (2 of 4) | 100% (1 of 1) | 62% (8 of 13) |
| Character on its own | - | 67% (2 of 3) | 100% (2 of 2) | 80% (4 of 5) |
| Infantry | 14% (1 of 7) | 50% (3 of 6) | - | 31% (4 of 13) |
| Monster | 100% (2 of 2) | - | - | 100% (2 of 2) |
| War Machines | 70% (7 of 10) | - | - | 70% (7 of 10) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dwarfen Mountain Holds | 3 | 0% (0 of 1); on the table 0% | - | 77% | 52% (14 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | 100% (1 of 1); on the table 100% | 22% (4 of 18) | 62% | 44% (4 of 9) | 100% (3 of 3); 7.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Vampire Counts | 1 | - | 0% (0 of 6) | 97% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | - | 83% (5 of 6) | 53% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p52, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (1) | - | 50% (1) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.00 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.00 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: gs3-83c8646-p52

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | - | 71% (5 of 7) |
| Strategy | Shoot objectives carried out (shot that target) | 49% (44 of 90) | 36% (5 of 14) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 42% (5 of 12) | 33% (2 of 6) |
| Strategy | Lone characters that fought | 0% (0 of 1) | 67% (4 of 6) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.7 | 2.3 |
| Movement | Points that never moved of their own | 453.7 | 110.0 |
| Movement | Fights charged into per game | 0.0 | 1.3 |
| Movement | Charges with odds: long shots (under 50%) | - | 0 of 3 |
| Movement | Charges with odds: sweet spot (55-75%) | - | 1 of 3, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | - | 2 of 3, net +105 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | - | 0 of 3 |
| Shooting | Shots by shooting units (incl. breath weapons) | 25.7 | 0.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 36% (28 of 77) | 0% (0 of 1) |
| Shooting | Points destroyed by shooting units | 306.7 | 0.0 |
| Shooting | War machine shots | 21.7 | 2.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 72% (47 of 65) | 14% (1 of 7) |
| Shooting | Points destroyed by war machines | 156.7 | 40.0 |
| Magic | Magic missiles cast | - | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 0% (0 of 3) |
| Magic | Wounds caused by magic missiles | - | 1.0 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 20.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 4.3 / 0.0 / 0.3 / 0.7 |
| Combat | Points destroyed in combat | 16.7 | 35.0 |
| Combat | Points run down | 0.0 | 21.7 |
| Combat | Net points per charged fight, damage counted | - | +11 |
| Combat | Net per 100 charger points, damage counted | - | +3.7 |
| Combat | First round won (charged fights) | - | 50% |
| Combat | Net points per charged fight | - | +40 |
| Combat | Net points per supported fight / lone fight | - / - | +0 / +53 |
| Combat | Charged fights on a top-3 enemy unit | - | 2 of 4 |
| Game | Points lost | 248.3 | 535.0 |
| Game | VP from objectives | 773.3 | 626.7 |
| Game | Lone holders (player turns) | 0.0 | 8.5 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +383 VP
- The side that went first won 2 of 2 games with a winner
- Points traded per game (both sides' losses): 783
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p52

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 6.7 | -129.8 | 0.0 | 70.0 | 7.3 | +164.6 | 0.0 | 323.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| ASSAILMENT BY POINTS | - | - | - | - | 0.3 | +0.5 | 0.0 | 0.0 |
| BOMBING RUN | 0.3 | +3.3 | 0.0 | 20.0 | - | - | - | - |
| CANNON PLAN MISSED | 2.7 | +0.0 | 623.3 | 31.7 | - | - | - | - |
| CANNON PLANNED TARGET | 18.7 | +612.1 | 1580.3 | 241.7 | 2.3 | +149.6 | 80.0 | 55.0 |
| CANNON SIGHT KEPT | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 55.0 |
| CAST JOB | - | - | - | - | 4.0 | +26.5 | 190.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | - | - | - | - | 0.3 | +5.4 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.0 | +3.4 | 0.0 | 13.7 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 31.7 | - | - | - | - |
| CHALLENGE BY POINTS | 0.7 | +4.4 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 9.0 | -152.7 | 0.0 | 243.3 | 19.7 | -891.6 | 0.0 | 483.3 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 37.0 | 0.0 | 0.7 | +0.0 | 53.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 11.7 | +0.0 | 0.0 | 86.7 | 9.3 | +0.0 | 0.0 | 33.3 |
| COVER ONCE | 11.0 | -512.4 | 0.0 | 51.7 | 4.7 | -197.6 | 0.0 | 182.3 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -14.2 | 31.7 | 0.0 |
| DEPLOY BY FIGURES | 13.3 | -169.6 | 0.0 | 0.0 | 4.3 | +35.7 | 0.0 | 55.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -2.4 | 0.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +2.3 | 35.0 | 0.0 |
| EXACT ROUND | - | - | - | - | 1.0 | +3.1 | 88.3 | 0.0 |
| FALL BACK GOOD ORDER | - | - | - | - | 1.3 | +0.0 | 31.7 | 16.7 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | - | - | - | - | 22.0 | +307.9 | 0.0 | 376.0 |
| FIRE IN ORDER | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 137.3 | +5994.1 | 5239.7 | 993.3 | 62.3 | +2574.8 | 508.3 | 1086.7 |
| FLANK NOT WEIGHED | 2.3 | +0.0 | 0.0 | 56.7 | 2.3 | +0.0 | 0.0 | 93.0 |
| FOOT FIRST | 10.7 | +0.0 | 0.0 | 66.7 | - | - | - | - |
| FOUR ROUNDS | - | - | - | - | 2.3 | +114.0 | 123.3 | 16.7 |
| FRIEND SHOOTS FIRST | 4.3 | -182.4 | 37.0 | 0.0 | - | - | - | - |
| GIVES UP | - | - | - | - | 0.7 | -6.9 | 0.0 | 0.0 |
| GOAL WALK | 3.7 | +318.6 | 0.0 | 0.0 | 2.7 | +145.9 | 0.0 | 0.0 |
| GUN FIGURES | 2.7 | +60.6 | 112.0 | 0.0 | - | - | - | - |
| GUN MASK | 2.0 | +14.7 | 0.0 | 0.0 | 2.0 | +61.1 | 0.0 | 126.3 |
| HARD STAY DROPPED | 4.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 5.0 | +0.0 | 0.0 | 243.3 | 9.7 | +0.0 | 0.0 | 483.3 |
| HIS CHARGE LIST | 7.3 | +0.0 | 0.0 | 146.7 | 6.7 | +0.0 | 0.0 | 126.3 |
| HIS LEGAL MOVES | 1.3 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 1.3 | -3.6 | 0.0 | 40.0 | 5.3 | -42.1 | 0.0 | 126.3 |
| HIS ONE QUARTER | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS OWN BEST MOVE | 4.3 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 38.3 | +1155.9 | 0.0 | 150.0 | 39.0 | +3283.8 | 0.0 | 718.0 |
| HIS SHOTS BY HIS RUN | 25.7 | +349.7 | 0.0 | 290.0 | 37.7 | +872.4 | 0.0 | 662.7 |
| HIS TURN DENIED | - | - | - | - | 1.0 | +28.9 | 31.7 | 16.7 |
| HOLD ODDS | 8.7 | +0.0 | 0.0 | 0.0 | 14.0 | +0.0 | 0.0 | 186.0 |
| HOLDER ASSIGNMENT | 10.7 | +1072.1 | 0.0 | 0.0 | 9.3 | +1207.5 | 0.0 | 93.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | - | - | - | - | 2.0 | -82.3 | 123.3 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 2.0 | +153.9 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 14.0 | -346.2 | 0.0 | 260.7 |
| JOINT CHARGE NOW | - | - | - | - | 0.7 | +31.7 | 0.0 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +42.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 0.7 | +0.0 | 13.7 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | - | - | - | - | 1.0 | -14.1 | 35.0 | 0.0 |
| MANOEUVRE | 2.7 | -26.5 | 0.0 | 21.7 | 2.0 | -5.5 | 0.0 | 56.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.7 | +6.5 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.3 | +2.5 | 0.0 | 126.3 |
| MARCH CHECK | - | - | - | - | 2.0 | +179.2 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +11.5 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 1.0 | +226.5 | 0.0 | 126.3 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 1.0 | +4.9 | 0.0 | 20.0 | 1.3 | +42.2 | 0.0 | 126.3 |
| MEETS IN TIME | 9.3 | +185.0 | 0.0 | 0.0 | 2.3 | +331.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | - | - | - | - | 5.3 | +34.2 | 0.0 | 56.0 |
| MISSILES NEXT TURN | - | - | - | - | 9.3 | +59.9 | 0.0 | 339.0 |
| MODEL FACING | 4.0 | +1562.8 | 0.0 | 20.0 | - | - | - | - |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 4.3 | +196.3 | 0.0 | 0.0 | 2.3 | +123.9 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.0 | +282.4 | 0.0 | 0.0 | 5.3 | +258.2 | 0.0 | 0.0 |
| NEAREST TO GOAL | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 3.3 | +180.8 | 37.0 | 0.0 | 2.0 | +82.9 | 20.0 | 0.0 |
| NO DOUBLE ROUNDS | - | - | - | - | 1.3 | -25.2 | 123.3 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 4.7 | -292.0 | 0.0 | 101.7 | 4.7 | -108.3 | 0.0 | 20.0 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 2.0 | +13.0 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.3 | -20.1 | 0.0 | 20.0 | 1.3 | -28.9 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | +104.5 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 5.3 | -4.1 | 0.0 | 0.0 | 4.7 | +32.7 | 0.0 | 93.0 |
| ONE PROMISE A TARGET | 0.3 | +2.0 | 37.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.3 | +0.7 | 0.0 | 0.0 |
| PATHS CROSS | 0.3 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 60.0 | +2476.0 | 1984.7 | 463.3 | 29.7 | +162.4 | 171.7 | 960.0 |
| PROMISE BY ITS OWN SUM | 3.0 | -24.4 | 0.0 | 0.0 | 5.3 | -72.2 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.7 | +0.0 | 37.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.3 | -0.5 | 20.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -8.8 | 0.0 | 0.0 | 0.3 | -28.6 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | - | - | - | - | 0.3 | -1.0 | 40.0 | 0.0 |
| QUARTER ODDS | 17.3 | +868.2 | 0.0 | 140.0 | 2.3 | +932.5 | 105.0 | 0.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.3 | +4.7 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.7 | +43.8 | 0.0 | 43.3 | 0.7 | +32.5 | 0.0 | 13.7 |
| REDIRECT FOR A FRIEND IN REACH | 0.3 | +0.0 | 0.0 | 21.7 | 0.7 | +0.0 | 0.0 | 20.0 |
| REFORMS TO MEET IT | 2.3 | -16.5 | 0.0 | 0.0 | 0.3 | -0.2 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | 0.7 | +50.9 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | - | - | - | - | 1.3 | +1.4 | 53.3 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.0 | -8.0 | 31.7 | 16.7 |
| RUN DOWN | - | - | - | - | 1.7 | -4.3 | 91.7 | 0.0 |
| SAME CHARGE LATER | 0.3 | -8.6 | 37.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.3 | -49.7 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +1.8 | 0.0 | 0.0 |
| SET CREDITED ONCE | 0.7 | -7.8 | 0.0 | 0.0 | 2.0 | -140.6 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.7 | +1.9 | 0.0 | 0.0 | 2.7 | +72.6 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.3 | +1.7 | 0.0 | 20.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 2.0 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 29.7 | +0.0 | 0.0 | 276.7 | 5.0 | +0.0 | 0.0 | 55.0 |
| SHOOTS FROM THE BEST SPOT | 2.3 | +148.1 | 401.7 | 70.0 | 0.7 | +10.9 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -6.0 | 35.0 | 0.0 |
| SHOT RISK POINTS | 23.7 | +783.7 | 0.0 | 290.0 | 24.0 | -393.7 | 0.0 | 619.0 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 38.7 | +1769.6 | 0.0 | 320.0 | 2.7 | +158.3 | 0.0 | 92.0 |
| SPELL WORTH | - | - | - | - | 5.3 | +100.9 | 156.7 | 156.7 |
| SPOT AS THE GAME MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 74.0 |
| STAND AND SHOOT | - | - | - | - | 1.0 | -11.4 | 70.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 2.3 | +0.0 | 20.0 | 0.0 |
| STANDS STILL | 106.7 | +0.0 | 5239.7 | 770.0 | 15.0 | +0.0 | 385.0 | 150.0 |
| STAY WORTH | 68.3 | +530.4 | 3730.7 | 438.3 | 8.7 | +99.5 | 280.0 | 165.0 |
| SUPPORT ADDS | 1.3 | +28.3 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 1.3 | +28.3 | 0.0 | 0.0 | - | - | - | - |
| SURE REACH TOGETHER | 0.3 | +2.8 | 0.0 | 0.0 | - | - | - | - |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +1.0 | 0.0 | 56.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 0.7 | +0.0 | 0.0 | 21.7 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 58.0 | +0.0 | 0.0 | 465.0 | 31.0 | +0.0 | 0.0 | 535.0 |
| TIED UP BY THE SUM | - | - | - | - | 0.3 | +22.0 | 31.7 | 0.0 |
| TIME ON OUR SIDE | 54.3 | +622.8 | 107.3 | 236.7 | - | - | - | - |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WALKS ON ITS ROUTE | 0.3 | -14.5 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | - | - | - | - | 0.7 | +5.3 | 53.3 | 0.0 |
| WHOLE FIGHT DANGER | 1.3 | -65.9 | 0.0 | 63.3 | 1.7 | -275.7 | 0.0 | 483.3 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.7 | +54.7 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 1.3 | +19.1 | 0.0 | 0.0 | 4.7 | +251.2 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p52

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 232 | 232 | 91 | 30.33 | +1898 | +20.9 |
| HOLDER ASSIGNMENT | 60 | 60 | 56 | 18.67 | +4240 | +75.7 |
| HIS SHOTS BY HIS RUN | 190 | 185 | 50 | 16.67 | +308 | +6.2 |
| ARMY TABLE | 42 | 42 | 36 | 12.00 | +461 | +12.8 |
| DEPLOY BY FIGURES | 53 | 53 | 32 | 10.67 | +329 | +10.3 |
| SHOT RISK POINTS | 143 | 140 | 31 | 10.33 | +1191 | +38.4 |
| OFF BEST | 28 | 28 | 28 | 9.33 | -1201 | -42.9 |
| TIME ON OUR SIDE | 163 | 155 | 25 | 8.33 | +80 | +3.2 |
| FIVE ACTION | 599 | 592 | 21 | 7.00 | +470 | +22.4 |
| HARD STAY DROPPED | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| COVER ONCE | 47 | 43 | 15 | 5.00 | +228 | +15.2 |
| MOVE TO CHARGE COMPUTED | 20 | 17 | 15 | 5.00 | +259 | +17.3 |
| MEETS IN TIME | 35 | 35 | 14 | 4.67 | +462 | +33.0 |
| NEXT CHARGE BY LIST | 16 | 16 | 13 | 4.33 | +258 | +19.8 |
| THE TABLE AGAIN | 36 | 36 | 13 | 4.33 | +0 | +0.0 |
| MODEL FACING | 12 | 12 | 12 | 4.00 | +4688 | +390.7 |
| IDLE COST | 42 | 34 | 11 | 3.67 | +241 | +21.9 |
| CANNON SIGHT KEPT | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| GOAL WALK | 19 | 19 | 10 | 3.33 | +912 | +91.2 |
| ARTILLERY RE-ROLL WEIGHED | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| CHARGE LOSSES | 86 | 83 | 9 | 3.00 | +431 | +47.9 |
| PROMISE BY ITS OWN SUM | 25 | 25 | 9 | 3.00 | -290 | -32.2 |
| SHOOTS FROM THE BEST SPOT | 9 | 9 | 9 | 3.00 | +232 | +25.8 |
| STAY WORTH | 231 | 218 | 8 | 2.67 | +88 | +11.0 |
| CANNON PLANNED TARGET | 63 | 63 | 7 | 2.33 | -8 | -1.2 |
| CAST JOB | 12 | 12 | 6 | 2.00 | +10 | +1.7 |
| OGRE LOADER SECOND SHOT | 6 | 6 | 6 | 2.00 | +39 | +6.5 |
| SHOOTERS IN TWO RANKS | 6 | 6 | 6 | 2.00 | +12 | +2.0 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 24 | 24 | 6 | 2.00 | +0 | +0.0 |
| SHOTS IN THE MOVE | 124 | 104 | 6 | 2.00 | +386 | +64.4 |
| FALLS SHORT | 66 | 57 | 5 | 1.67 | +140 | +27.9 |
| MARCH CHECK | 6 | 6 | 5 | 1.67 | +310 | +62.1 |
| QUARTER ODDS | 59 | 57 | 5 | 1.67 | +546 | +109.1 |
| WOUNDS ON THE RANKS | 18 | 18 | 5 | 1.67 | +38 | +7.7 |
| GUN MASK | 12 | 12 | 4 | 1.33 | +141 | +35.2 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MAX FOR POSITIONING | 7 | 7 | 3 | 1.00 | +10 | +3.2 |
| NEARER NOT NEEDED | 34 | 33 | 3 | 1.00 | +67 | +22.3 |
| REDIRECT FOR A FRIEND IN REACH | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +13 | +6.6 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FOUR ROUNDS | 7 | 7 | 2 | 0.67 | +77 | +38.3 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HUNT IN PAIRS | 6 | 5 | 2 | 0.67 | +119 | +59.4 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +95 | +47.5 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +128 | +64.0 |
| LEGAL CHARGES ONLY | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MOVE ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| ONE JOINT FIGURE | 2 | 2 | 2 | 0.67 | +196 | +98.0 |
| RESTRAINS TO SHOOT | 2 | 2 | 2 | 0.67 | +153 | +76.5 |
| RISK BY ARC | 4 | 4 | 2 | 0.67 | +110 | +55.1 |
| SUPPORT ADDS | 4 | 4 | 2 | 0.67 | +6 | +2.8 |
| SUPPORT WORKED OUT | 4 | 4 | 2 | 0.67 | +6 | +2.8 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +2 | +1.5 |
| BOMBING RUN | 1 | 1 | 1 | 0.33 | +10 | +10.0 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 3 | 3 | 1 | 0.33 | -14 | -13.9 |
| HIS MOVE AND SHOT | 20 | 19 | 1 | 0.33 | +7 | +7.4 |
| HIS TURN DENIED | 3 | 3 | 1 | 0.33 | +78 | +78.1 |
| MANOEUVRE | 14 | 14 | 1 | 0.33 | +7 | +7.1 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +7 | +7.4 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -34 | -34.5 |
| MISSILES NEXT TURN | 28 | 20 | 1 | 0.33 | +0 | +0.1 |
| ONE OBJECTIVE FORMULA | 30 | 26 | 1 | 0.33 | +191 | +191.2 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | +6 | +5.9 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +4 | +3.5 |
| PROMISE KNOWS THE FIGHT | 1 | 1 | 1 | 0.33 | -2 | -1.6 |
| PROMISE READS THE TABLE | 2 | 2 | 1 | 0.33 | -16 | -16.1 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -3 | -3.1 |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SAME CHARGE LATER | 1 | 1 | 1 | 0.33 | +4 | +4.1 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +6 | +5.6 |
| SET UP BY THE SET | 10 | 10 | 1 | 0.33 | +2 | +2.2 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +3 | +3.1 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -44 | -43.5 |
| CANNON PLAN MISSED | 8 | 8 | 0 | 0.00 | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAFF IN THE MOVE | 3 | 3 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 10 | 10 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 63 | 63 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 3 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 4 | 4 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 14 | not checked | - | - | - | - |
| FOOT FIRST | 32 | not checked | - | - | - | - |
| FRIEND SHOOTS FIRST | 13 | 13 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 8 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 44 | 42 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 42 | 42 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 27 | 27 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 6 | 6 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 37 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 68 | 68 | 0 | 0.00 | - | - |
| HONEST WORTH | 6 | 6 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 5 | 5 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 3 | 3 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 16 | 11 | 0 | 0.00 | - | - |
| NEAREST TO GOAL | 3 | 3 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 17 | 15 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 269 | trace | - | - | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 8 | 7 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 5 | 5 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 1 | 1 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 8 | 8 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 104 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 16 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 21 | 17 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 7 | 7 | 0 | 0.00 | - | - |
| STANDS STILL | 365 | 361 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 8 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 10 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 2 | not checked | - | - | - | - |
| THE TABLE BINDS | 267 | not checked | - | - | - | - |
| TIED UP BY THE SUM | 1 | 1 | 0 | 0.00 | - | - |
| WAITS AGAIN | 4 | 4 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 9 | 9 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p52

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.33 | 4.67 | 37.7 |
| PROMISE BY ITS OWN SUM | rule | 1.67 | 1.33 | 32.2 |
| ARMY TABLE | rule | 0.67 | 0.33 | 102.4 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.67 | 9.3 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 8.5 |
| CHARGE NOW FIRST | rule | - | 0.33 | 13.9 |
| DEPLOY BY FIGURES | rule | 0.33 | - | 6.9 |
| MARCH OF THE TABLE | rule | - | 0.33 | 34.5 |
| NO REASON | gate | 0.33 | - | 183.7 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.33 | 1.6 |
| PROMISE READS THE TABLE | rule | - | 0.33 | 16.1 |
| PROMISE SHOT AWAY | rule | - | 0.33 | 3.1 |
| WALKS ON ITS ROUTE | rule | 0.33 | - | 43.5 |

### Plans: gs3-83c8646-p52

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | join | 1.3 | 100% | 46 | 0 | 0% |
| Mine | move | 32.0 | 97% | 846 | 0 | 0% |
| Mine | shoot | 26.7 | 65% | 1606 | 2476 | 154% |
| Opponent | charge | 1.7 | 20% | 114 | 49 | 43% |
| Opponent | join | 1.0 | 100% | 54 | 0 | 0% |
| Opponent | move | 22.7 | 90% | 726 | 0 | 0% |
| Opponent | shoot | 4.0 | 33% | 257 | 113 | 44% |
| Opponent | support | 0.3 | 100% | 15 | 0 | 0% |

### Battle groups: gs3-83c8646-p52

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.7 | 100% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 0.7 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p52

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Character | 13 | 17 (13) | 17 | 0 | 0 | 31% | 3.0 | 31 (6) | 0 (6) | 0 (1) | 19 (11) | 0 (2) |
| Mine | Clean-up | 4 | 0 (4) | 0 | 0 | 0 | 75% | 1.0 | 0 (1) | 0 (1) | 0 (2) | 0 (4) | - |
| Mine | Fast | 3 | 0 (3) | 0 | 0 | 73 | 0% | 2.0 | - | 0 (1) | 0 (2) | 0 (3) | - |
| Mine | Hammer | 4 | 88 (4) | 2 | 87 | 0 | 50% | 2.0 | 4 (1) | 147 (3) | - | 88 (4) | - |
| Mine | Shooter | 8 | 113 (8) | 33 | 80 | 8 | 0% | 2.4 | 164 (1) | 180 (4) | 9 (3) | 120 (6) | 98 (2) |
| Mine | War machine | 17 | 44 (17) | 44 | 0 | 24 | 12% | 1.5 | 0 (4) | 81 (9) | 0 (4) | 31 (3) | 47 (14) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 63 | 100% | - | 0 (2) | - | 0 (1) | 0 (3) | - |
| Opponent | Character | 10 | 6 (10) | 6 | 0 | 37 | 30% | 3.6 | 11 (3) | 5 (5) | 0 (2) | 8 (9) | 0 (1) |
| Opponent | Clean-up | 1 | 99 (1) | 99 | 0 | 100 | 100% | - | - | 99 (1) | - | 99 (1) | - |
| Opponent | Fast Hammer | 3 | 32 (3) | 4 | 28 | 0 | 67% | 6.0 | 0 (1) | 107 (1) | 0 (1) | 45 (2) | 0 (1) |
| Opponent | Holder | 6 | 102 (6) | 6 | 97 | 26 | 50% | 2.7 | 71 (1) | 108 (5) | - | 133 (4) | 51 (2) |
| Opponent | War machine | 2 | 36 (2) | 36 | 0 | 50 | 0% | 1.0 | - | 73 (1) | 0 (1) | - | 36 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 2.0 | 0 (1) | 0 (1) | - | 0 (2) | - |

### Charged fights: gs3-83c8646-p52

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 3 | 463 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 180 | 105 | 2.0 | 1.5 | 52 | 0 | +52 | 1 of 2 | 1 of 2 | +0 | +105 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 50 | -50 | 1 of 1 | 0 of 1 | - | -50 |
| Opponent | Warriors of Chaos | 1 | 0 | 105 | 1.0 | 1.0 | 105 | 0 | +105 | 0 of 1 | 1 of 1 | - | +105 |
| **Opponent** | all armies | 3 | 60 | 70 | 1.3 | 1.2 | 52 | 12 | +40 | 2 of 4 | 2 of 4 | +0 | +53 |

### Effective charges: gs3-83c8646-p52

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Grand Cathay | 2 | 0 | 0 | 1 (net +0) | 0 | 1 (net +105) | 0 | 0 | 50% (1 of 2) |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0 | 0 | 1 (net +105) | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: gs3-83c8646-p52

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Effective (55-75%) | 1 | 422 | 183 | +0 | 26 | 143 | -117 | -27.6 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 346 | 105 | +105 | 105 | 0 | +105 | +30.4 |
| Opponent | No odds | 1 | 50 | 239 | -50 | 0 | 50 | -50 | -100.0 |
| Opponent | All fights | 4 | 291 | 158 | +40 | 59 | 48 | +11 | +3.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p52 | move | 12 | 1 (8%) | 1 (8%) | 1 (8%) | 10 (83%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0524 |
| Clockwork Compass | Opponent | L0612 |
| Invocation of Nehek | Opponent | L0524 |
| Ring of Doom | Opponent | L0612 |
| Ring of Jet | Opponent | L0612 |

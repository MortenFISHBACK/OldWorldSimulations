# Doctrine scorecard: gs3-83c8646-p27

### Scorecard: gs3-83c8646-p27

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0413 | 5 | 1 | Mine | yes | - | - | 1 | 4 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | yes | - | 4 | 0 | 3 | 0 | 0 | 0 | 140 |
| L0429 | 3 | 1 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 7 | 4 | 0 | 5 | 1 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 0 | 2 | 1 | 0 | 0 | 0 | 0 | 1215 |
| L0516 | 6 | 1 | Opponent | no | 18 | 6 | 0 | 1 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 0.0 | 3.0 | 1.0 | 1.7 | 0.0 | 0.0 | 0.0 | 405.0 |
| **Average** | | | Opponent | 33% | 12.5 | 4.7 | 0.0 | 3.0 | 0.7 | 0.0 | 0.0 | 103.3 |

### KPIs: gs3-83c8646-p27

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 38% (5 of 13) | 0% (0 of 16) | 17% (5 of 29) |
| Winner chose to follow up after the loser gave ground |  | 100% (4 of 4); on the table 100% | 100% (4 of 4); on the table 100% | 100% (8 of 8); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | - | 0% (0 of 1); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 80% (4 of 5); on the table 80% | 100% (4 of 4); on the table 100% | 89% (8 of 9); on the table 89% |
| Magic missiles tried each own turn | 50%+ | 67% (8 of 12) | 83% (5 of 6) | 72% (13 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 67% (8 of 12) | 83% (5 of 6) | 72% (13 of 18) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 0% (0 of 2) | 0% (0 of 2) |
| Points that never fought | lower | 78% (4692 of 5998) | 59% (3530 of 5999) | 69% (8222 of 11997) |
|   infantry points that never fought | lower | 88% (1254 of 1424) | 100% (1671 of 1671) | 95% (2925 of 3095) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 65% (15 of 23) | 67% (14 of 21) | 66% (29 of 44) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (1 of 1); 1.3 uses a game | 100% (1 of 1); 0.7 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 65% (3328 of 5120) | 57% (3045 of 5324) | 61% (6373 of 10444) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (75%) | 0.0 (0%) | 1.0 (60%) |
| MARCHED: its unit marched | 0.3 (25%) | 0.3 (100%) | 0.7 (40%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 7.0 | 3.0 | 4.3 | 1.0 | 1.0 |
| not cast | 3.0 | 1.0 | 1.7 | 1.0 | 11.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (67%) | 1.0 (60%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.7 (40%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (12%) |
| OTHER BAR: another bar (miscast, baggage ...) | 1.0 (33%) | 0.0 (0%) | 0.0 (0%) | 1.0 (100%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (67%) | 0.3 (33%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 9.7 (88%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 2.0 a game | 1.5 a game |
| stood (cast and not dispelled) | 100% (3 of 3) | 50% (3 of 6) | 67% (6 of 9) |
| the unit moved after it | 67% (2 of 3) | 33% (1 of 3) | 50% (3 of 6) |
| it charged on its next turn | 0% (0 of 3) | 0% (0 of 3) | 0% (0 of 6) |
| the enemy charged it first | 0% (0 of 3) | 0% (0 of 3) | 0% (0 of 6) |
| it fought by the end of its next turn | 0% (0 of 3) | 0% (0 of 3) | 0% (0 of 6) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 3) | 0% (0 of 3) | 0% (0 of 6) |
| none of these (no charge, no fight, no charge escaped) | 100% (3 of 3) | 100% (3 of 3) | 100% (6 of 6) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 76% (73 of 96) | 56% (35 of 62) | 68% (108 of 158) |
|   cavalry | 50% (6 of 12) | 60% (3 of 5) | 53% (9 of 17) |
|   character | 90% (18 of 20) | 53% (9 of 17) | 73% (27 of 37) |
|   chariot | 61% (14 of 23) | - | 61% (14 of 23) |
|   infantry | 50% (6 of 12) | 56% (9 of 16) | 54% (15 of 28) |
|   war machine | 100% (29 of 29) | 58% (14 of 24) | 81% (43 of 53) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.3 (17%) | 1.0 (11%) | 2.3 (14%) |
| CHARGED: it charged | 0.3 (4%) | 1.3 (15%) | 1.7 (10%) |
| FLEEING: it fled or was fleeing | 0.7 (9%) | 0.0 (0%) | 0.7 (4%) |
| IN COMBAT: it fought this turn or the last | 1.0 (13%) | 0.0 (0%) | 1.0 (6%) |
| MOVED: a war machine that moved | 0.0 (0%) | 1.7 (19%) | 1.7 (10%) |
| NO TARGET IN RANGE | 1.7 (22%) | 2.7 (30%) | 4.3 (26%) |
| ONLY IN COMBAT: the only targets were in combat | 1.0 (13%) | 0.0 (0%) | 1.0 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (22%) | 2.0 (22%) | 3.7 (22%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.3 (4%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.3 | 0.3 | 90% | 1.5 pts | 5 pts |
| character | 12.7 | 4.0 | 76% | 6.2 pts | 79 pts |
| chariot | 4.7 | 2.7 | 50% | 26.4 pts | 123 pts |
| infantry | 9.3 | 4.3 | 71% | 9.0 pts | 84 pts |
| war machine | 14.3 | 13.7 | 72% | 43.2 pts | 618 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.3 | 2.0 | 1.7 |
| Charges that made contact a game | 1.0 | 1.0 | 1.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.18 declared, 0.14 contact (22 units) | 0.30 declared, 0.15 contact (20 units) | 0.24 declared, 0.14 contact (42 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 75% (3 of 4) | 100% (2 of 2) | - | 83% (5 of 6) |
| Character in a unit | 100% (3 of 3) | 100% (1 of 1) | - | 100% (4 of 4) |
| Character on its own | 100% (1 of 1) | 67% (4 of 6) | 33% (2 of 6) | 54% (7 of 13) |
| Chariot | - | 100% (4 of 4) | - | 100% (4 of 4) |
| Infantry | 60% (6 of 10) | 33% (2 of 6) | - | 50% (8 of 16) |
| Monster | 100% (1 of 1) | - | - | 100% (1 of 1) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 2 | 100% (4 of 4); on the table 100% | 67% (8 of 12) | 70% | 62% (10 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Dwarfen Mountain Holds | 1 | 0% (0 of 1); on the table 0% | - | 94% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| High Elf Realms | 1 | 100% (4 of 4); on the table 100% | 83% (5 of 6) | 51% | 75% (6 of 8) | 100% (1 of 1); 4.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | - | - | 77% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 1 | - | - | 49% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p27, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 33% (1) | 100% (1) | 50% (2) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.33 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.33 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p27

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.0 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 50% (2 of 4) | 50% (3 of 6) |
| Strategy | Shoot objectives carried out (shot that target) | 37% (14 of 38) | 39% (7 of 18) |
| Strategy | Joined characters whose unit fought | 0% (0 of 5) | - |
| Strategy | Lone characters that fought | 17% (1 of 6) | 67% (6 of 9) |
| Movement | Charges halted short of contact | 0.0 | 0.7 |
| Movement | Idle units | 1.7 | 3.0 |
| Movement | Points that never moved of their own | 405.0 | 103.3 |
| Movement | Fights charged into per game | 1.0 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 3, net +0 | 2 of 3, net +155 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 3 | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 3 | 1 of 3, net +65 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 3, net +0 | 0 of 3 |
| Shooting | Shots by shooting units (incl. breath weapons) | 14.7 | 7.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 57% (25 of 44) | 50% (11 of 22) |
| Shooting | Points destroyed by shooting units | 165.3 | 0.0 |
| Shooting | War machine shots | 9.7 | 4.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 90% (26 of 29) | 57% (8 of 14) |
| Shooting | Points destroyed by war machines | 92.3 | 0.0 |
| Magic | Magic missiles cast | 1.7 | 1.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 40% (2 of 5) | 0% (0 of 5) |
| Magic | Wounds caused by magic missiles | 2.7 | 0.3 |
| Magic | Wounds caused by other spells | - | 0.3 |
| Magic | Points destroyed by magic (all spells) | 28.3 | 37.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 3.3 / 0.0 / 0.0 / 0.7 | 2.7 / 0.0 / 1.0 / 0.0 |
| Combat | Points destroyed in combat | 211.7 | 125.0 |
| Combat | Points run down | 0.0 | 40.0 |
| Combat | Net points per charged fight, damage counted | +299 | +69 |
| Combat | Net per 100 charger points, damage counted | +179.1 | +21.6 |
| Combat | First round won (charged fights) | 67% | 67% |
| Combat | Net points per charged fight | +155 | +125 |
| Combat | Net points per supported fight / lone fight | - / +155 | - / +125 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 3 | 2 of 3 |
| Game | Points lost | 234.0 | 474.3 |
| Game | VP from objectives | 653.3 | 686.7 |
| Game | Lone holders (player turns) | 0.0 | 12.5 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +205 VP
- The side that went first won 3 of 3 games with a winner
- Points traded per game (both sides' losses): 708
- Games not ended: 0; findings 2, warnings 0

### Opponent rules: gs3-83c8646-p27

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 27.3 | +89.7 | 0.0 | 152.0 | 16.3 | +349.5 | 0.0 | 494.7 |
| ARTILLERY RE-ROLL WEIGHED | 2.0 | +0.0 | 0.0 | 31.7 | - | - | - | - |
| ASSAILMENT BY POINTS | - | - | - | - | 0.3 | +1.6 | 0.0 | 155.0 |
| BACKUP TARGETS | - | - | - | - | 0.7 | +1.0 | 0.0 | 92.3 |
| CANNON PLAN MISSED | 1.3 | +0.0 | 106.7 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 8.0 | +133.4 | 627.3 | 63.3 | 4.7 | +26.6 | 0.0 | 0.0 |
| CANNON SIGHT KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 1.7 | +80.3 | 0.0 | 0.0 | 0.7 | +5.4 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.3 | +2.1 | 0.0 | 0.0 | 0.7 | +4.0 | 0.0 | 20.0 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | - | - | - | - | 0.3 | +11.7 | 0.0 | 155.0 |
| CHARACTER GUNS | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 8.3 | -577.2 | 0.0 | 74.7 | 16.7 | -1015.6 | 0.0 | 408.7 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 155.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 6.3 | +0.0 | 0.0 | 40.0 | 13.0 | +0.0 | 0.0 | 247.3 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 103.3 | 0.3 | +0.0 | 0.0 | 56.7 |
| CONVEYANCE SEARCH | 1.0 | +23.0 | 0.0 | 0.0 | 2.0 | +236.9 | 0.0 | 0.0 |
| COVER ONCE | 8.0 | -1388.6 | 0.0 | 31.7 | 6.7 | -377.3 | 0.0 | 155.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -3.1 | 103.3 | 0.0 |
| DEPLOY BY FIGURES | 8.3 | -70.5 | 0.0 | 0.0 | 7.3 | -39.1 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | 0.7 | +27.1 | 0.0 | 37.3 | - | - | - | - |
| EXACT ROUND | 1.0 | +21.3 | 181.7 | 37.3 | 1.7 | -27.7 | 125.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.3 | +0.0 | 191.7 | 37.3 | 0.7 | +0.0 | 103.3 | 0.0 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | - | - | - | - | 22.3 | +233.4 | 0.0 | 286.0 |
| FIGHT TO THE END | - | - | - | - | 0.3 | +4.5 | 103.3 | 0.0 |
| FIRE IN ORDER | 0.7 | +0.0 | 26.7 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 105.3 | +5479.9 | 2189.3 | 485.3 | 88.7 | +4272.7 | 125.0 | 882.0 |
| FLANK NOT WEIGHED | 6.7 | +0.0 | 0.0 | 83.3 | 7.0 | +0.0 | 0.0 | 155.0 |
| FOCUS FIRE | 0.3 | +9.3 | 26.7 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 1.3 | +414.2 | 0.0 | 103.3 | 0.7 | +178.4 | 0.0 | 0.0 |
| FOOT FIRST | - | - | - | - | 32.7 | +0.0 | 0.0 | 120.0 |
| FOUR ROUNDS | 1.3 | +139.2 | 191.7 | 37.3 | 2.0 | +173.3 | 125.0 | 0.0 |
| FREED FROM HIS FIGHT | 4.3 | +0.0 | 0.0 | 77.3 | 3.7 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -5.7 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | - | - | - | - | 0.3 | -1.6 | 103.3 | 0.0 |
| GOAL ROUTE | - | - | - | - | 0.3 | +13.8 | 0.0 | 0.0 |
| GOAL WALK | 10.0 | +449.6 | 0.0 | 0.0 | 8.0 | +382.1 | 0.0 | 0.0 |
| GUN FIGURES | 3.7 | +14.1 | 155.0 | 0.0 | - | - | - | - |
| GUN MASK | 0.7 | +23.7 | 0.0 | 0.0 | 1.7 | +57.0 | 0.0 | 184.7 |
| HARD STAY DROPPED | 3.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 3.0 | +0.0 | 0.0 | 77.3 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 4.3 | +0.0 | 0.0 | 0.0 | 8.7 | +0.0 | 0.0 | 224.0 |
| HIS CHARGE LIST | 14.3 | +0.0 | 0.0 | 37.3 | 9.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 92.3 |
| HIS MOVE AND SHOT | 0.7 | -4.5 | 0.0 | 74.7 | 3.7 | -258.7 | 0.0 | 0.0 |
| HIS ONE QUARTER | 7.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 4.0 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 92.3 |
| HIS RANDOM MOVE | 4.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 44.3 | +1903.9 | 0.0 | 241.3 | 48.7 | +4221.5 | 0.0 | 882.0 |
| HIS SHOTS BY HIS RUN | 25.3 | +408.5 | 0.0 | 241.3 | 39.7 | +1482.8 | 0.0 | 572.0 |
| HIS TURN DENIED | 0.7 | +0.9 | 26.7 | 37.3 | 0.7 | +221.7 | 103.3 | 0.0 |
| HOLD ODDS | 15.7 | +0.0 | 0.0 | 160.0 | 19.3 | +0.0 | 0.0 | 277.3 |
| HOLDER ASSIGNMENT | 10.0 | +895.7 | 0.0 | 80.0 | 11.0 | +997.7 | 0.0 | 138.7 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.7 | -2.9 | 36.7 | 0.0 | 2.0 | -68.2 | 125.0 | 0.0 |
| HUNT IN PAIRS | 1.3 | +21.8 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | - | - | - | - | 12.7 | -282.8 | 0.0 | 293.7 |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 53.3 |
| LANE BY FIGURES | 1.0 | +28.3 | 0.0 | 0.0 | 1.7 | +26.3 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.7 | +0.0 | 211.7 | 206.7 | 1.0 | +0.0 | 103.3 | 0.0 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.3 | +20.0 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +3.0 | 26.7 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 0.7 | +0.3 | 181.7 | 0.0 | 1.3 | -1.8 | 0.0 | 0.0 |
| MANOEUVRE | 2.0 | +7.1 | 0.0 | 40.0 | 3.0 | -19.7 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.3 | +18.0 | 0.0 | 0.0 |
| MARCH CHECK | 1.3 | +63.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.0 | +119.7 | 0.0 | 0.0 | 0.7 | +5.1 | 0.0 | 0.0 |
| MEETS IN TIME | 2.7 | +138.5 | 0.0 | 0.0 | 3.3 | +217.9 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.7 | +106.3 | 0.0 | 0.0 | 3.0 | +14.6 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 3.0 | +78.9 | 0.0 | 0.0 | 3.3 | +14.1 | 0.0 | 0.0 |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 2.0 | +79.7 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -2.5 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 4.3 | +222.8 | 0.0 | 0.0 | 4.3 | +292.7 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 9.3 | +393.8 | 0.0 | 80.0 | 6.0 | +281.4 | 0.0 | 0.0 |
| NEAREST TO GOAL | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 2.7 | +114.1 | 0.0 | 0.0 | 3.7 | +252.7 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.3 | -97.8 | 191.7 | 37.3 | 2.0 | -170.3 | 125.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 4.7 | -210.1 | 0.0 | 0.0 | 2.0 | -55.9 | 0.0 | 92.3 |
| ONE FIGHT FORMULA | 3.7 | -96.5 | 0.0 | 0.0 | 4.0 | -99.6 | 0.0 | 92.3 |
| ONE OBJECTIVE FORMULA | 4.0 | -27.9 | 0.0 | 80.0 | 4.7 | +9.0 | 0.0 | 112.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.7 | -5.1 | 0.0 | 0.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.7 | +6.2 | 36.7 | 0.0 | - | - | - | - |
| PLAN RESULT | 46.0 | +813.2 | 515.3 | 364.7 | 38.7 | +184.1 | 206.7 | 948.7 |
| PROMISE BY ITS OWN SUM | 12.3 | -491.7 | 0.0 | 0.0 | 6.3 | -120.4 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 18.7 | +2078.0 | 0.0 | 112.0 | 16.0 | +2031.9 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 0.7 | +0.0 | 0.0 | 56.7 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.7 | +280.6 | 0.0 | 21.7 | 0.3 | +38.6 | 0.0 | 10.0 |
| REDIRECT FOR A FRIEND IN REACH | 1.7 | +0.0 | 0.0 | 43.3 | 0.3 | +0.0 | 0.0 | 10.0 |
| REDIRECT WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 1.0 | -10.8 | 0.0 | 0.0 | 0.7 | -38.3 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.7 | +0.9 | 0.0 | 26.7 |
| RESTRAINS TO SHOOT | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.0 | +29.8 | 191.7 | 0.0 | 1.3 | -74.6 | 103.3 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.3 | -5.8 | 21.7 | 0.0 |
| RUN DOWN | 0.7 | -2.5 | 36.7 | 0.0 | 0.3 | -0.1 | 21.7 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.7 | -3.7 | 0.0 | 0.0 | 0.7 | -43.1 | 0.0 | 20.0 |
| SEARCH SPOT | 0.7 | +2.4 | 0.0 | 0.0 | 0.7 | +6.4 | 0.0 | 0.0 |
| SET CREDITED ONCE | 0.7 | -7.4 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 0.7 | +7.4 | 0.0 | 0.0 | - | - | - | - |
| SET-UP ANY TARGET | 0.3 | +20.7 | 0.0 | 0.0 | - | - | - | - |
| SHOOTER COUNTED ONCE | 0.7 | -5.2 | 0.0 | 0.0 | 0.7 | -2.2 | 0.0 | 20.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 13.0 | +0.0 | 0.0 | 63.3 | 6.3 | +0.0 | 0.0 | 10.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +25.7 | 28.3 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 0.3 | -2.2 | 26.7 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 21.3 | +822.3 | 0.0 | 118.0 | 24.7 | -144.2 | 0.0 | 825.3 |
| SHOTS AFTER THE MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 19.3 | +890.1 | 0.0 | 63.3 | 14.0 | +329.8 | 0.0 | 26.7 |
| SPELL SETS UP CHARGE | 0.3 | +20.7 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | - | - | - | - | 3.0 | +105.2 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.7 | -18.1 | 155.0 | 37.3 | - | - | - | - |
| SPOT AS THE GAME MOVES | 4.3 | +0.0 | 0.0 | 40.0 | 6.0 | +0.0 | 0.0 | 26.7 |
| STAND AND SHOOT | 0.3 | -0.1 | 26.7 | 0.0 | 0.7 | -25.4 | 103.3 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 65.3 | +0.0 | 1997.7 | 213.3 | 34.0 | +0.0 | 0.0 | 56.7 |
| STAY WORTH | 30.3 | +224.5 | 901.3 | 164.0 | 21.7 | +92.3 | 0.0 | 26.7 |
| SUPPORT ADDS | 3.3 | +169.2 | 0.0 | 40.0 | 0.7 | +146.1 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 3.3 | +169.2 | 0.0 | 40.0 | 0.7 | +146.1 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +5.6 | 0.0 | 26.7 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 40.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.0 | +0.0 | 0.0 | 40.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.0 | +0.0 | 0.0 | 40.0 | 4.7 | +0.0 | 0.0 | 267.0 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 50.3 | +0.0 | 0.0 | 224.0 | 40.0 | +0.0 | 0.0 | 422.7 |
| TIED UP BY THE SUM | 0.3 | +11.8 | 10.0 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 59.3 | +664.4 | 357.3 | 210.0 | - | - | - | - |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 1.7 | +0.0 | 28.3 | 0.0 | - | - | - | - |
| WHO HITS BACK | - | - | - | - | 1.0 | +255.9 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.3 | -361.8 | 0.0 | 0.0 | 1.0 | -19.0 | 0.0 | 224.0 |
| WOUNDS ON THE RANKS | 0.7 | +78.1 | 0.0 | 0.0 | 2.7 | +20.2 | 0.0 | 224.0 |

### Rule changes: gs3-83c8646-p27

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 131 | 131 | 90 | 30.00 | +1086 | +12.1 |
| HIS SHOT LIST | 279 | 264 | 86 | 28.67 | +2300 | +26.7 |
| HOLDER ASSIGNMENT | 63 | 63 | 59 | 19.67 | +3537 | +59.9 |
| HIS SHOTS BY HIS RUN | 195 | 175 | 47 | 15.67 | +924 | +19.7 |
| DEPLOY BY FIGURES | 47 | 47 | 31 | 10.33 | +372 | +12.0 |
| PROMISE BY ITS OWN SUM | 56 | 56 | 29 | 9.67 | -1837 | -63.3 |
| TIME ON OUR SIDE | 178 | 155 | 27 | 9.00 | +101 | +3.8 |
| SHOT RISK POINTS | 138 | 131 | 23 | 7.67 | +690 | +30.0 |
| THE TABLE AGAIN | 36 | 36 | 22 | 7.33 | +0 | +0.0 |
| OFF BEST | 20 | 20 | 20 | 6.67 | -798 | -39.9 |
| QUARTER ODDS | 104 | 97 | 19 | 6.33 | +861 | +45.3 |
| FIVE ACTION | 582 | 559 | 18 | 6.00 | +445 | +24.7 |
| MOVE TO CHARGE COMPUTED | 26 | 20 | 14 | 4.67 | +410 | +29.3 |
| GOAL WALK | 54 | 52 | 13 | 4.33 | +528 | +40.7 |
| HARD STAY DROPPED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| CANNON SIGHT KEPT | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| LANE BY FIGURES | 8 | 8 | 8 | 2.67 | +164 | +20.5 |
| COVER ONCE | 44 | 32 | 7 | 2.33 | +183 | +26.1 |
| IDLE COST | 38 | 30 | 7 | 2.33 | +152 | +21.7 |
| MEETS IN TIME | 18 | 18 | 7 | 2.33 | +19 | +2.8 |
| NEXT CHARGE BY LIST | 19 | 13 | 7 | 2.33 | +374 | +53.4 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CAST JOB | 7 | 7 | 6 | 2.00 | +115 | +19.2 |
| CHARGE LOSSES | 75 | 68 | 6 | 2.00 | +594 | +99.0 |
| FOLLOW UP WEIGHED | 6 | 6 | 6 | 2.00 | +1778 | +296.3 |
| FOUR ROUNDS | 10 | 10 | 6 | 2.00 | +354 | +59.0 |
| REDIRECT FOR A FRIEND IN REACH | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SHOTS IN THE MOVE | 100 | 79 | 5 | 1.67 | +372 | +74.5 |
| FALLS SHORT | 67 | 56 | 4 | 1.33 | +3 | +0.8 |
| MARCH CHECK | 4 | 4 | 4 | 1.33 | +75 | +18.7 |
| MOVE ORDER | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| STAY WORTH | 156 | 141 | 4 | 1.33 | +13 | +3.3 |
| FIRE IN ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SEARCH SPOT | 4 | 4 | 3 | 1.00 | +26 | +8.8 |
| SHOOTS FROM THE BEST SPOT | 4 | 4 | 3 | 1.00 | +34 | +11.2 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +587 | +195.8 |
| CHAFF IN THE MOVE | 3 | 3 | 2 | 0.67 | +0 | +0.0 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| GUN MASK | 7 | 7 | 2 | 0.67 | +36 | +18.2 |
| HIS TURN DENIED | 4 | 4 | 2 | 0.67 | +89 | +44.4 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MAX FOR POSITIONING | 11 | 10 | 2 | 0.67 | +0 | +0.0 |
| MISSILES IN THE MOVE | 17 | 10 | 2 | 0.67 | +40 | +20.1 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -15 | -7.6 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +3 | +1.4 |
| RISK BY ARC | 7 | 7 | 2 | 0.67 | +35 | +17.4 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| SUPPORT ADDS | 12 | 10 | 2 | 0.67 | +6 | +3.2 |
| SUPPORT WORKED OUT | 12 | 10 | 2 | 0.67 | +6 | +3.2 |
| THE ROW IN ITS ORDER | 15 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 10 | 10 | 2 | 0.67 | +2 | +0.9 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +5 | +4.7 |
| CANNON PLANNED TARGET | 38 | 38 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +35 | +35.1 |
| EVASIVE BY THE ODDS | 2 | 2 | 1 | 0.33 | +81 | +81.2 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +28 | +28.0 |
| GOAL ROUTE | 1 | 1 | 1 | 0.33 | +41 | +41.3 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +60 | +60.0 |
| MANOEUVRE | 15 | 15 | 1 | 0.33 | +27 | +27.1 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +54 | +54.1 |
| NEARER NOT NEEDED | 46 | 45 | 1 | 0.33 | +34 | +33.9 |
| ONE FIGHT FORMULA | 23 | 13 | 1 | 0.33 | +2 | +2.3 |
| OVERRUNS AWAY | 2 | 2 | 1 | 0.33 | +8 | +7.9 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +71 | +71.2 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +55 | +55.3 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +17 | +16.7 |
| TIED UP BY THE SUM | 1 | 1 | 1 | 0.33 | +8 | +7.9 |
| BACKUP TARGETS | 2 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 4 | 4 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 6 | trace | - | - | - | - |
| CHARACTER GUNS | 5 | 5 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 5 | 5 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 58 | 54 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 9 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| EXACT ROUND | 8 | 8 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 6 | 6 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 41 | not checked | - | - | - | - |
| FOOT FIRST | 98 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 24 | 19 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 11 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 16 | 11 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 39 | 35 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 70 | 61 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 21 | 20 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 13 | 12 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 29 | 25 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 34 | 31 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 12 | 12 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 3 | 3 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 105 | 105 | 0 | 0.00 | - | - |
| HONEST WORTH | 8 | 8 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 4 | 3 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 15 | 15 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 6 | 6 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 19 | 12 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 6 | 3 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 1 | trace | - | - | - | - |
| MOVE SPELL SPOT | 6 | not checked | - | - | - | - |
| NEAREST TO GOAL | 8 | 8 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 10 | 10 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 26 | 20 | 0 | 0.00 | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 254 | trace | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 6 | 2 | 0 | 0.00 | - | - |
| RANDOM MOVE BY FIGURES | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 6 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 5 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 3 | 3 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SET UP BY THE SET | 2 | 2 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 58 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 18 | 18 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 9 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 31 | 25 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 6 | 6 | 0 | 0.00 | - | - |
| STANDS STILL | 298 | 288 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 6 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 20 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 10 | not checked | - | - | - | - |
| THE TABLE BINDS | 271 | not checked | - | - | - | - |
| WAITS AGAIN | 6 | 4 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 5 | 5 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 10 | 10 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p27

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 7.67 | 2.00 | 63.3 |
| JOB FIRST | gate | 4.67 | 2.00 | 39.9 |
| ARMY TABLE | rule | 4.33 | 2.00 | 53.9 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.33 | 54.9 |
| ONE PROMISE A TARGET | rule | - | 0.67 | 7.6 |

### Plans: gs3-83c8646-p27

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 67% | 131 | 181 | 138% |
| Mine | join | 0.3 | 100% | 11 | 0 | 0% |
| Mine | move | 33.3 | 99% | 1532 | 0 | 0% |
| Mine | shoot | 11.0 | 64% | 417 | 632 | 152% |
| Mine | support | 0.3 | 100% | 6 | 0 | 0% |
| Opponent | charge | 1.0 | 33% | 132 | 44 | 34% |
| Opponent | move | 32.7 | 96% | 1269 | 0 | 0% |
| Opponent | shoot | 4.7 | 43% | 320 | 140 | 44% |
| Opponent | support | 0.3 | 0% | 0 | 0 | - |

### Battle groups: gs3-83c8646-p27

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.7 | 20% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 0.3 | 100% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p27

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 3 | 0 (3) | 0 | 0 | 33 | 67% | 6.0 | 0 (2) | - | 0 (1) | 0 (3) | - |
| Mine | Character | 11 | 28 (11) | 28 | 0 | 0 | 27% | 2.5 | 7 (5) | 53 (5) | 0 (1) | 0 (7) | 58 (4) |
| Mine | Clean-up | 3 | 17 (3) | 0 | 17 | 33 | 33% | 2.0 | 26 (2) | 0 (1) | - | 54 (1) | 0 (2) |
| Mine | Hammer | 7 | 48 (7) | 28 | 20 | 18 | 0% | 2.4 | 0 (1) | 59 (6) | - | 59 (6) | 0 (1) |
| Mine | Holder | 5 | 107 (5) | 0 | 107 | 19 | 80% | 4.0 | 121 (2) | 129 (2) | 25 (1) | 242 (1) | 75 (4) |
| Mine | War machine | 5 | 58 (5) | 58 | 0 | 20 | 0% | 1.0 | 0 (2) | 97 (3) | - | - | 58 (5) |
| Opponent | Chaff | 3 | 32 (3) | 0 | 32 | 100 | 33% | 1.5 | - | 27 (2) | 38 (1) | 38 (1) | 27 (2) |
| Opponent | Character | 8 | 22 (8) | 22 | 0 | 27 | 25% | 3.3 | 24 (7) | - | 0 (1) | 27 (6) | 0 (2) |
| Opponent | Clean-up | 1 | 154 (1) | 0 | 154 | 0 | 100% | - | 154 (1) | - | - | 154 (1) | - |
| Opponent | Fast Hammer | 4 | 0 (4) | 0 | 0 | 0 | 100% | - | 0 (2) | 0 (2) | - | 0 (1) | 0 (3) |
| Opponent | Hammer | 3 | 25 (3) | 0 | 25 | 61 | 67% | 2.0 | 0 (1) | 32 (2) | - | 0 (1) | 32 (2) |
| Opponent | Holder | 3 | 48 (3) | 0 | 48 | 19 | 100% | - | 172 (1) | 0 (1) | 0 (1) | 172 (1) | 0 (2) |
| Opponent | Shooter | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.5 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | War machine | 4 | 0 (4) | 0 | 0 | 0 | 0% | 2.5 | 0 (2) | 0 (2) | - | 0 (1) | 0 (3) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | 0 (1) | - |

### Charged fights: gs3-83c8646-p27

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 42 | 232 | 1.0 | 1.0 | 232 | 0 | +232 | 2 of 2 | 1 of 2 | - | +232 |
| Mine | Dwarfen Mountain Holds | 1 | 773 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| **Mine** | all armies | 3 | 286 | 155 | 1.0 | 1.0 | 155 | 0 | +155 | 2 of 3 | 2 of 3 | - | +155 |
| Opponent | High Elf Realms | 1 | 112 | 310 | 2.0 | 1.0 | 155 | 0 | +155 | 2 of 2 | 1 of 2 | - | +155 |
| Opponent | Kingdom of Bretonnia | 1 | 0 | 65 | 1.0 | 1.0 | 65 | 0 | +65 | 0 of 1 | 1 of 1 | - | +65 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 37 | 125 | 1.0 | 1.0 | 125 | 0 | +125 | 2 of 3 | 2 of 3 | - | +125 |

### Effective charges: gs3-83c8646-p27

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 1 (net +0) | 0 | 0 | 1 (net +465) | 0 | 0 | 0 | 0% (0 of 2) |
| Mine | Dwarfen Mountain Holds | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | High Elf Realms | 2 | 2 (net +155) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Kingdom of Bretonnia | 1 | 0 | 0 | 0 | 0 | 1 (net +65) | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: gs3-83c8646-p27

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 112 | 400 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 76-89% | 1 | 339 | 365 | +465 | 465 | 0 | +465 | +137.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 50 | 80 | +0 | 504 | 72 | +432 | +865.0 |
| Mine | All fights | 3 | 167 | 282 | +155 | 323 | 24 | +299 | +179.1 |
| Opponent | Long shot (under 50%) | 2 | 294 | 310 | +155 | 177 | 106 | +71 | +24.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 371 | 65 | +65 | 65 | 0 | +65 | +17.5 |
| Opponent | All fights | 3 | 320 | 228 | +125 | 140 | 71 | +69 | +21.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p27 | move | 15 | 0 (0%) | 0 (0%) | 0 (0%) | 15 (100%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Standard of the Fell Warrior | Opponent | L0413 |

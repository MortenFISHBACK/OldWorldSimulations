# Doctrine scorecard: gs3-83c8646-p59

### Scorecard: gs3-83c8646-p59

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2127 | 3 | 1 | Mine | yes | 9 | 3 | 1 | 1 | 0 | 0 | 0 | 345 |
| L2127 | 3 | 1 | Opponent | no | 3 | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 3 | 5 | 0 | 0 | 0 | 0 | 369 |
| L2231 | 5 | 1 | Opponent | no | - | - | 0 | 3 | 2 | 0 | 0 | 170 |
| L2335 | 1 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L2335 | 1 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| **Average** | | | Mine | 100% | 9.0 | 3.0 | 3.0 | 0.5 | 0.0 | 0.0 | 0.0 | 357.0 |
| **Average** | | | Opponent | 0% | 3.0 | 3.0 | 1.0 | 2.5 | 1.0 | 0.0 | 0.0 | 85.0 |

### KPIs: gs3-83c8646-p59

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 12) | 0% (0 of 13) | 0% (0 of 25) |
| Winner chose to follow up after the loser gave ground |  | 100% (4 of 4); on the table 100% | 100% (1 of 1); on the table 100% | 100% (5 of 5); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 50% (1 of 2); on the table 50% | 100% (1 of 1); on the table 100% | 67% (2 of 3); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 83% (5 of 6); on the table 83% | 100% (2 of 2); on the table 100% | 88% (7 of 8); on the table 88% |
| Magic missiles tried each own turn | 50%+ | 33% (2 of 6) | 44% (7 of 16) | 41% (9 of 22) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 40% (2 of 5) | 47% (7 of 15) | 45% (9 of 20) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 38% (3 of 8) | 67% (6 of 9) | 53% (9 of 17) |
| Points that never fought | lower | 34% (1373 of 3999) | 64% (2577 of 4000) | 49% (3950 of 7999) |
|   infantry points that never fought | lower | 67% (783 of 1175) | 71% (290 of 410) | 68% (1073 of 1585) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 50% (7 of 14) | 78% (14 of 18) | 66% (21 of 32) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 0.3 uses a game | 50% (1 of 2); 1.7 uses a game | 67% (2 of 3); 1.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 37% (1134 of 3038) | 66% (2339 of 3546) | 53% (3473 of 6584) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (25%) | 2.3 (78%) | 2.7 (62%) |
| MARCHED: its unit marched | 0.7 (50%) | 0.3 (11%) | 1.0 (23%) |
| IN COMBAT: engaged in combat | 0.3 (25%) | 0.0 (0%) | 0.3 (8%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.3 (11%) | 0.3 (8%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 10.3 | 0.7 | 0.0 | 3.0 | 1.3 | 0.3 |
| not cast | 3.0 | 0.7 | 1.3 | 4.3 | 0.7 | 14.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (50%) | 0.3 (25%) | 2.7 (62%) | 0.3 (50%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (23%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (8%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.3 (50%) | 0.3 (25%) | 0.3 (8%) | 0.0 (0%) | 0.3 (2%) |
| STUPIDITY: Stupidity | 0.3 (11%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (50%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.7 (89%) | 0.0 (0%) | 0.7 (50%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.0 (93%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 73% (47 of 64) | - | 73% (47 of 64) |
|   cavalry | 88% (7 of 8) | - | 88% (7 of 8) |
|   character | 0% (0 of 12) | - | 0% (0 of 12) |
|   chariot | 100% (6 of 6) | - | 100% (6 of 6) |
|   infantry | 89% (34 of 38) | - | 89% (34 of 38) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| CHARGED: it charged | 1.3 (24%) | - | 1.3 (24%) |
| IN COMBAT: it fought this turn or the last | 0.7 (12%) | - | 0.7 (12%) |
| NO TARGET IN RANGE | 3.0 (53%) | - | 3.0 (53%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (12%) | - | 0.7 (12%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 2.0 | 1.0 | 50% | 10.4 pts | 21 pts |
| infantry | 13.0 | 4.7 | 74% | 14.1 pts | 183 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.3 | 2.0 | 3.2 |
| Charges that made contact a game | 3.0 | 1.3 | 2.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 1.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) | 0.33 declared, 0.33 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 1.00 contact (2 units) | 1.00 declared, 1.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.38 declared, 0.25 contact (32 units) | 0.18 declared, 0.09 contact (22 units) | 0.30 declared, 0.19 contact (54 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 75% (3 of 4) | 100% (1 of 1) | 0% (0 of 1) | 67% (4 of 6) |
| Character in a unit | 100% (6 of 6) | - | 100% (1 of 1) | 100% (7 of 7) |
| Character on its own | 100% (2 of 2) | - | 0% (0 of 4) | 33% (2 of 6) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 60% (3 of 5) | 100% (1 of 1) | - | 67% (4 of 6) |
| Monster | 50% (2 of 4) | 100% (1 of 1) | - | 60% (3 of 5) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Skaven | 1 | 100% (2 of 2); on the table 100% | 33% (2 of 6) | 50% | 67% (6 of 9) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 1 | 75% (3 of 4); on the table 75% | - | 19% | 20% (1 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (1 of 1); on the table 100% | 17% (1 of 6) | 52% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (1 of 1); on the table 100% | 67% (4 of 6) | 77% | 92% (11 of 12) | 100% (1 of 1); 5.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p59, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 0% (0) | 0% (0) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.33 | 0.67 |

### Quality by phase: gs3-83c8646-p59

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.0 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 45% (5 of 11) | 0% (0 of 6) |
| Strategy | Shoot objectives carried out (shot that target) | 70% (14 of 20) | 50% (5 of 10) |
| Strategy | Support requests answered (helper made contact too) | 50% (1 of 2) | - |
| Strategy | Joined characters whose unit fought | 50% (2 of 4) | 0% (0 of 6) |
| Strategy | Lone characters that fought | 100% (3 of 3) | 20% (1 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 0.5 | 2.5 |
| Movement | Points that never moved of their own | 357.0 | 85.0 |
| Movement | Fights charged into per game | 2.5 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 4, net +0 | 1 of 4, net +10 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 4, net +0 | 1 of 4, net +145 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 4, net +290 | 0 of 4 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 4 | 1 of 4, net +540 |
| Shooting | Shots by shooting units (incl. breath weapons) | 15.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 47% (22 of 47) | - |
| Shooting | Points destroyed by shooting units | 25.0 | 48.3 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.7 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 50% (1 of 2) | 0% (0 of 2) |
| Magic | Wounds caused by magic missiles | 0.7 | 1.7 |
| Magic | Wounds caused by other spells | 0.7 | - |
| Magic | Points destroyed by magic (all spells) | 124.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 5.3 / 0.0 / 0.3 / 0.0 | 2.3 / 0.7 / 0.0 / 1.0 |
| Combat | Points destroyed in combat | 128.3 | 375.3 |
| Combat | Points run down | 40.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +77 | +218 |
| Combat | Net per 100 charger points, damage counted | +19.9 | +74.3 |
| Combat | First round won (charged fights) | 100% | 75% |
| Combat | Net points per charged fight | +78 | +226 |
| Combat | Net points per supported fight / lone fight | +290 / +24 | - / +226 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 5 | 2 of 4 |
| Game | Points lost | 633.0 | 476.0 |
| Game | VP from objectives | 800.0 | 665.0 |
| Game | Lone holders (player turns) | 9.0 | 3.0 |

- Mine won / drew / lost: 1 / 0 / 1 of 2 ended games (of 3); mean margin (Mine - Opponent) -97 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 1109
- Games not ended: 1 (L2335-1); findings 1, warnings 0

### Opponent rules: gs3-83c8646-p59

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 24.7 | +118.0 | 0.0 | 537.7 | 22.7 | +599.0 | 0.0 | 186.0 |
| BACKUP TARGETS | 0.7 | +3.3 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | - | - | - | - | 2.7 | +10.9 | 81.3 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 1.0 | +47.1 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | - | - | - | - | 0.7 | +22.0 | 0.0 | 0.0 |
| CHARACTER GUNS | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 16.3 | -596.6 | 0.0 | 515.0 | 24.7 | -886.9 | 0.0 | 374.0 |
| CHARGE NOW FIRST | 1.7 | +0.0 | 105.0 | 0.0 | 1.3 | +0.0 | 88.3 | 15.0 |
| CLOSES ON WHAT IT BEATS | 8.3 | +0.0 | 0.0 | 0.0 | 9.0 | +0.0 | 0.0 | 40.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 50.0 |
| COVER ONCE | 5.7 | -276.7 | 0.0 | 198.3 | 10.0 | -399.2 | 0.0 | 80.0 |
| DENIED BY THE FIGHT | 0.7 | -4.2 | 80.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.0 | +21.9 | 0.0 | 48.3 | 7.7 | +21.5 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -0.3 | 0.0 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.3 | +19.6 | 0.0 | 0.0 | 0.3 | +6.8 | 48.3 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 1.7 | +244.5 | 0.0 | 0.0 |
| EXACT ROUND | 3.7 | -3.1 | 320.3 | 0.0 | 2.0 | +4.1 | 316.7 | 15.0 |
| FALL BACK GOOD ORDER | 3.7 | +6.1 | 263.7 | 0.0 | 1.0 | +0.0 | 250.0 | 0.0 |
| FALLS SHORT | 2.0 | +12.7 | 0.0 | 0.0 | 20.7 | +285.3 | 0.0 | 102.0 |
| FEATURE BUFFS | - | - | - | - | 2.0 | +5.2 | 0.0 | 80.0 |
| FIGHT TO THE END | 1.0 | +21.2 | 65.0 | 0.0 | 0.3 | +4.3 | 48.3 | 0.0 |
| FIRE IN ORDER | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 96.3 | +5962.3 | 671.0 | 1255.7 | 75.7 | +3933.2 | 398.0 | 593.0 |
| FLANK NOT WEIGHED | 5.3 | +0.0 | 0.0 | 360.0 | 6.0 | +0.0 | 0.0 | 40.0 |
| FOLLOW UP WEIGHED | 1.0 | +183.4 | 0.0 | 0.0 | 0.3 | +131.8 | 0.0 | 56.7 |
| FOOT FIRST | 21.0 | +0.0 | 0.0 | 107.0 | - | - | - | - |
| FOUR ROUNDS | 4.3 | +346.0 | 320.3 | 0.0 | 2.0 | +215.9 | 316.7 | 15.0 |
| FREED FROM HIS FIGHT | 3.3 | +0.0 | 0.0 | 18.3 | 4.3 | +0.0 | 0.0 | 80.0 |
| FRIEND SHOOTS FIRST | 1.0 | -16.1 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.3 | +28.2 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 1.3 | -15.9 | 56.7 | 0.0 | - | - | - | - |
| GOAL ROUTE | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 14.3 | +1670.5 | 0.0 | 0.0 | 6.0 | +334.3 | 0.0 | 0.0 |
| GUN FIGURES | 2.3 | +3.1 | 25.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 2.3 | +0.0 | 0.0 | 24.0 | 2.0 | +0.0 | 0.0 | 62.0 |
| HE REFORMS ONCE FREED | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 6.0 | +0.0 | 0.0 | 496.7 | 16.3 | +0.0 | 0.0 | 312.0 |
| HIS CHARGE DENIED | 1.3 | +29.2 | 182.0 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 4.3 | +0.0 | 0.0 | 18.3 | 5.7 | +0.0 | 0.0 | 176.7 |
| HIS LEGAL MOVES | 4.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 80.0 |
| HIS MOVE AND SHOT | 1.7 | -12.5 | 0.0 | 0.0 | 4.7 | -59.2 | 0.0 | 118.7 |
| HIS ONE QUARTER | 8.0 | +0.0 | 0.0 | 24.0 | 7.0 | +0.0 | 0.0 | 142.0 |
| HIS OWN BEST MOVE | 6.7 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 80.0 |
| HIS RANDOM MOVE | 20.3 | +0.0 | 0.0 | 214.0 | 8.3 | +0.0 | 0.0 | 124.0 |
| HIS RANDOM MOVER COMES | 6.3 | +0.0 | 0.0 | 84.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 5.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 38.3 | +609.3 | 0.0 | 336.0 | 49.0 | +1126.6 | 0.0 | 454.0 |
| HIS SHOTS BY HIS RUN | 31.7 | +270.0 | 0.0 | 574.3 | 53.0 | +561.3 | 0.0 | 578.0 |
| HIS TURN DENIED | 0.7 | +22.5 | 0.0 | 0.0 | 0.3 | +0.4 | 0.0 | 0.0 |
| HOLD ODDS | 18.0 | +0.0 | 0.0 | 84.7 | 15.3 | +0.0 | 0.0 | 160.0 |
| HOLDER ASSIGNMENT | 12.3 | +859.9 | 0.0 | 42.3 | 9.0 | +830.4 | 0.0 | 40.0 |
| HOLDS AMBUSHERS | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.0 | -107.4 | 320.3 | 0.0 | 2.0 | -68.2 | 316.7 | 15.0 |
| IDLE COST | 2.0 | -38.9 | 0.0 | 0.0 | 17.3 | -175.8 | 0.0 | 0.0 |
| JOINT CHARGE NOW | 0.3 | -26.5 | 40.0 | 0.0 | 0.3 | -1.1 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +48.6 | 0.0 | 0.0 | 0.7 | +0.4 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 9.0 | +0.0 | 321.7 | 114.3 | 3.3 | +0.0 | 180.0 | 70.0 |
| LONE WIZARD KEPT IN | 1.3 | +77.2 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +4.8 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.3 | +1.9 | 120.0 | 0.0 | 0.7 | +0.1 | 18.3 | 15.0 |
| LURE BY WHAT IT DRAWS | 0.7 | -46.3 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 0.7 | +0.0 | 0.0 | 0.0 | 2.7 | +5.1 | 0.0 | 80.0 |
| MARCH AT ESCAPER | 0.7 | +8.6 | 0.0 | 0.0 | 1.0 | +3.5 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +11.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.3 | +24.1 | 0.0 | 0.0 | 0.3 | +1.8 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | 1.0 | -46.6 | 0.0 | 180.0 | 0.3 | +23.7 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 0.3 | +2.3 | 0.0 | 180.0 | 2.0 | +42.8 | 0.0 | 62.0 |
| MEETS IN TIME | 4.3 | +147.4 | 0.0 | 48.3 | 4.3 | +410.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.0 | +34.5 | 0.0 | 360.0 | 5.3 | +43.8 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 3.0 | +29.7 | 0.0 | 180.0 | 6.0 | +34.5 | 0.0 | 0.0 |
| MOVE ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 6.0 | +695.2 | 0.0 | 0.0 | 6.3 | +744.7 | 0.0 | 124.0 |
| NEARER NOT NEEDED | 14.0 | +559.7 | 0.0 | 42.3 | 7.7 | +305.4 | 0.0 | 40.0 |
| NEAREST TO GOAL | 5.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 5.3 | +488.3 | 0.0 | 0.0 | 6.0 | +729.1 | 0.0 | 124.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.7 | -112.1 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 4.0 | -142.7 | 263.7 | 0.0 | 2.0 | -100.8 | 316.7 | 15.0 |
| NO OLD ONE-MOVE GUESS | 5.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 5.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.7 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 5.0 | -159.4 | 56.7 | 24.0 | 6.3 | -144.4 | 0.0 | 62.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 4.7 | -107.2 | 0.0 | 0.0 | 7.3 | -114.9 | 0.0 | 102.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 5.3 | -63.6 | 0.0 | 24.0 | 4.3 | -42.9 | 0.0 | 40.0 |
| ONE RUN A PLAN | 5.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 1.0 | +19.7 | 142.0 | 0.0 | 1.0 | +10.2 | 136.7 | 15.0 |
| PATHS CROSS | 0.3 | +2.1 | 0.0 | 0.0 | 0.3 | +3.2 | 0.0 | 0.0 |
| PERIAPT WORTH | 0.3 | +34.4 | 0.0 | 180.0 | - | - | - | - |
| PLAN RESULT | 43.0 | +370.7 | 353.7 | 847.3 | 38.3 | +247.3 | 36.7 | 491.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 7.3 | -339.3 | 0.0 | 0.0 | 6.0 | -51.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 1.7 | -7.5 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -4.5 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 17.7 | +1898.1 | 306.7 | 384.0 | 18.0 | +2227.8 | 180.0 | 317.3 |
| RANDOM MOVE BY FIGURES | 2.7 | +64.8 | 0.0 | 285.0 | 3.0 | +137.9 | 0.0 | 170.0 |
| REDIRECT BY WHAT IT STOPS | 0.7 | -2.8 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 4.3 | +226.0 | 0.0 | 42.3 | 0.7 | +13.2 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 5.0 | +5.2 | 0.0 | 107.0 | 1.3 | +0.0 | 0.0 | 15.0 |
| REFORMS TO MEET IT | 1.3 | -41.2 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 3.7 | +63.7 | 0.0 | 24.0 | 1.0 | +33.8 | 0.0 | 0.0 |
| RISK BY ARC | 3.7 | -5.6 | 263.7 | 0.0 | 1.7 | -17.4 | 136.7 | 15.0 |
| ROUNDS AFTER TERROR | 1.0 | -7.3 | 0.0 | 0.0 | - | - | - | - |
| RUN DOWN | 2.7 | -38.0 | 120.0 | 0.0 | 1.0 | -3.4 | 66.7 | 15.0 |
| SCOUT SPOT | 1.3 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | - | - | - | - | 0.7 | +33.3 | 0.0 | 0.0 |
| SECOND LOOK | 0.7 | +31.5 | 56.7 | 0.0 | - | - | - | - |
| SET UP BY THE SET | - | - | - | - | 0.3 | +19.2 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +3.0 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 5.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 4.7 | +61.1 | 237.3 | 360.0 | - | - | - | - |
| SHOT OR CHARGE | 0.3 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 24.3 | -274.5 | 0.0 | 574.3 | 30.3 | -324.4 | 0.0 | 294.0 |
| SHOTS AFTER THE MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 23.0 | +302.9 | 0.0 | 107.0 | 5.0 | +72.9 | 0.0 | 0.0 |
| SPELL WORTH | 1.3 | +51.9 | 360.0 | 360.0 | 3.7 | +8.0 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | +22.0 | 62.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 4.3 | +0.0 | 0.0 | 246.7 | 9.7 | +0.0 | 0.0 | 138.3 |
| STAND AND SHOOT | 0.7 | -2.8 | 0.0 | 0.0 | 0.3 | -0.3 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 3.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 39.0 | +0.0 | 350.7 | 762.7 | 22.0 | +0.0 | 81.3 | 118.7 |
| STAY WORTH | 18.0 | +86.6 | 113.3 | 83.0 | 8.3 | +66.2 | 81.3 | 0.0 |
| STRIKE BY THE ODDS | - | - | - | - | 1.0 | +7.4 | 0.0 | 153.3 |
| STUCK PIVOT | 0.3 | +0.0 | 0.0 | 70.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 4.0 | +459.1 | 0.0 | 0.0 | 3.3 | +140.2 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 25.0 | 0.0 | 0.3 | +0.0 | 70.0 | 0.0 |
| SUPPORT WORKED OUT | 4.0 | +459.1 | 0.0 | 0.0 | 3.3 | +140.2 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.7 | -24.4 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 3.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 5.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 44.3 | +0.0 | 0.0 | 305.3 | 39.3 | +0.0 | 0.0 | 204.0 |
| TIED UP BY THE SUM | 1.7 | +165.1 | 80.0 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 48.3 | +418.6 | 0.0 | 267.3 | 5.7 | +55.6 | 0.0 | 0.0 |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 40.0 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -16.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 0.7 | -14.5 | 113.3 | 0.0 | - | - | - | - |
| WHO FIGHTS | 1.3 | -6.3 | 167.0 | 0.0 | - | - | - | - |
| WHO GETS IN | 0.3 | -26.5 | 40.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.7 | +59.7 | 0.0 | 18.3 | 1.3 | +151.0 | 0.0 | 81.7 |
| WHOLE FIGHT | 0.3 | +9.8 | 56.7 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 4.7 | -330.8 | 0.0 | 466.7 | 3.0 | -493.3 | 0.0 | 136.7 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +1.1 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 5.0 | +81.2 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p59

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 142 | 142 | 95 | 31.67 | +1874 | +19.7 |
| HIS SHOT LIST | 262 | 247 | 63 | 21.00 | +702 | +11.1 |
| HOLDER ASSIGNMENT | 64 | 64 | 58 | 19.33 | +3935 | +67.8 |
| LEGAL CHARGES ONLY | 37 | 37 | 37 | 12.33 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 254 | 248 | 35 | 11.67 | +204 | +5.8 |
| OFF BEST | 34 | 34 | 34 | 11.33 | -911 | -26.8 |
| GOAL WALK | 61 | 61 | 28 | 9.33 | +1783 | +63.7 |
| FIVE ACTION | 516 | 499 | 27 | 9.00 | +2036 | +75.4 |
| DEPLOY BY FIGURES | 47 | 47 | 26 | 8.67 | +299 | +11.5 |
| MOVE TO CHARGE COMPUTED | 37 | 35 | 23 | 7.67 | +1634 | +71.0 |
| NEXT CHARGE BY LIST | 34 | 32 | 21 | 7.00 | +1658 | +79.0 |
| THE TABLE AGAIN | 32 | 32 | 21 | 7.00 | +0 | +0.0 |
| MOVE ORDER | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| QUARTER ODDS | 107 | 105 | 20 | 6.67 | +1836 | +91.8 |
| REDIRECT FOR A FRIEND IN REACH | 19 | 19 | 19 | 6.33 | +8 | +0.4 |
| RESERVE FALL BACK | 14 | 14 | 14 | 4.67 | +292 | +20.9 |
| HARD STAY DROPPED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| MEETS IN TIME | 26 | 26 | 13 | 4.33 | +1082 | +83.3 |
| SHOOTS FROM THE BEST SPOT | 14 | 14 | 12 | 4.00 | +46 | +3.8 |
| PROMISE BY ITS OWN SUM | 40 | 40 | 11 | 3.67 | -1171 | -106.4 |
| TIME ON OUR SIDE | 162 | 138 | 10 | 3.33 | +9 | +0.9 |
| ADVANCE LANE KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 17 | 17 | 9 | 3.00 | +608 | +67.5 |
| SHOT RISK POINTS | 164 | 160 | 9 | 3.00 | +54 | +6.0 |
| HOLDS AMBUSHERS | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| IDLE COST | 58 | 34 | 8 | 2.67 | +23 | +2.9 |
| FOUR ROUNDS | 19 | 17 | 7 | 2.33 | +299 | +42.7 |
| CHARGE LOSSES | 123 | 118 | 6 | 2.00 | +341 | +56.8 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +147 | +24.5 |
| SUPPORT ADDS | 22 | 21 | 6 | 2.00 | +234 | +38.9 |
| SUPPORT WORKED OUT | 22 | 21 | 6 | 2.00 | +234 | +38.9 |
| WHO HITS BACK | 6 | 6 | 6 | 2.00 | +350 | +58.4 |
| CHARGE NOW FIRST | 9 | 9 | 5 | 1.67 | -268 | -53.6 |
| COVER ONCE | 47 | 34 | 5 | 1.67 | +138 | +27.6 |
| GOAL ROUTE | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| STAY WORTH | 79 | 71 | 5 | 1.67 | +69 | +13.8 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +946 | +236.4 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +232 | +57.9 |
| NEARER NOT NEEDED | 65 | 63 | 4 | 1.33 | +190 | +47.4 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 84 | 70 | 4 | 1.33 | +31 | +7.8 |
| WHOLE FIGHT DANGER | 23 | 21 | 4 | 1.33 | +43 | +10.8 |
| CAST JOB | 8 | 8 | 3 | 1.00 | +0 | +0.1 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| EVASIVE BY THE ODDS | 5 | 5 | 3 | 1.00 | +701 | +233.6 |
| MAX FOR POSITIONING | 7 | 6 | 3 | 1.00 | +0 | +0.0 |
| MISSILES IN THE MOVE | 22 | 14 | 3 | 1.00 | +8 | +2.8 |
| PROMISE KNOWS THE FIGHT | 5 | 5 | 3 | 1.00 | -23 | -7.6 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +10 | +3.3 |
| STRIKE BY THE ODDS | 3 | 3 | 3 | 1.00 | +22 | +7.4 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 3 | 3 | 2 | 0.67 | +8 | +4.1 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +66 | +33.0 |
| EXACT ROUND | 17 | 16 | 2 | 0.67 | +1 | +0.6 |
| FALL BACK GOOD ORDER | 14 | 12 | 2 | 0.67 | +10 | +5.1 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | -83 | -41.6 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +36 | +17.8 |
| MARCH CHECK | 2 | 2 | 2 | 0.67 | +60 | +30.1 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +16 | +8.1 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +95 | +47.3 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| TIED UP BY THE SUM | 5 | 4 | 2 | 0.67 | +64 | +32.2 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALLS SHORT | 68 | 55 | 1 | 0.33 | +22 | +22.2 |
| FIGHT TO THE END | 4 | 4 | 1 | 0.33 | +9 | +9.3 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +85 | +84.7 |
| HIS CHARGE DENIED | 4 | 4 | 1 | 0.33 | +1 | +0.8 |
| LOST AFTER ESCAPE | 6 | 6 | 1 | 0.33 | +1 | +0.8 |
| MANOEUVRE | 10 | 10 | 1 | 0.33 | +23 | +23.1 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| MISSILES NEXT TURN | 27 | 18 | 1 | 0.33 | +0 | +0.0 |
| NO DOUBLE ROUNDS | 18 | 17 | 1 | 0.33 | +0 | +0.3 |
| OVERRUNS AWAY | 6 | 6 | 1 | 0.33 | +1 | +0.8 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +103 | +103.3 |
| PROMISE READS THE TABLE | 1 | 1 | 1 | 0.33 | +19 | +18.8 |
| REDIRECT COUNTER | 15 | 13 | 1 | 0.33 | +20 | +19.8 |
| REFORMS TO MEET IT | 4 | 4 | 1 | 0.33 | +5 | +4.6 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +100 | +100.0 |
| SET UP BY THE SET | 1 | 1 | 1 | 0.33 | +366 | +366.1 |
| SUPPORT NARROWED | 2 | 2 | 1 | 0.33 | -9 | -9.2 |
| THE PROMISE ADDS | 2 | 2 | 1 | 0.33 | +5 | +4.6 |
| THE ROW IN ITS ORDER | 18 | 1 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -48 | -48.1 |
| WHO GETS IN | 1 | 1 | 1 | 0.33 | -80 | -79.7 |
| BACKUP TARGETS | 2 | not checked | - | - | - | - |
| CHARACTER GUNS | 10 | 10 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 52 | 51 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 2 | 2 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 6 | 6 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 34 | not checked | - | - | - | - |
| FOOT FIRST | 63 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 23 | 22 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 3 | 3 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 7 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 6 | 6 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 67 | 66 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 30 | 29 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 22 | 20 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 19 | 19 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 45 | 44 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 39 | 37 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 86 | 82 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 22 | 20 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 31 | 31 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 3 | 3 | 0 | 0.00 | - | - |
| HOLD ODDS | 100 | 100 | 0 | 0.00 | - | - |
| HONEST WORTH | 18 | 16 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 6 | 6 | 0 | 0.00 | - | - |
| LONG SHOT | 3 | 3 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 5 | trace | - | - | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| NEAREST TO GOAL | 17 | 17 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 2 | not checked | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 32 | 32 | 0 | 0.00 | - | - |
| NO SECOND RUN | 32 | 32 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 36 | 17 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 29 | 23 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 32 | 32 | 0 | 0.00 | - | - |
| PLAN RESULT | 244 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| RISK BY ARC | 16 | 14 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 11 | 10 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 30 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 14 | 14 | 0 | 0.00 | - | - |
| SPELL WORTH | 15 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 42 | 34 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 10 | 9 | 0 | 0.00 | - | - |
| STANDS STILL | 183 | 174 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 4 | 4 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 19 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 13 | not checked | - | - | - | - |
| THE TABLE BINDS | 251 | not checked | - | - | - | - |
| WAITS AGAIN | 7 | 6 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | not checked | - | - | - | - |
| WHO FIGHTS | 4 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | not checked | - | - | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 15 | 15 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p59

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.67 | 5.33 | 17.8 |
| ARMY TABLE | rule | 2.67 | 2.00 | 34.9 |
| PROMISE BY ITS OWN SUM | rule | 2.67 | 1.00 | 106.4 |
| CHARGE NOW FIRST | rule | 0.67 | 1.00 | 53.6 |
| HOLDER ASSIGNMENT | rule | 1.00 | - | 7.3 |
| NO REASON | gate | 1.00 | - | 53.9 |
| PROMISE KNOWS THE FIGHT | rule | - | 1.00 | 7.6 |
| RULE SWITCHED OFF | gate | - | 1.00 | 64.5 |
| JOINT CHARGE NOW | rule | 0.33 | 0.33 | 41.6 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.33 | - | 74.5 |
| RESERVE FALL BACK | rule | 0.33 | - | 2.9 |
| SUPPORT NARROWED | rule | 0.33 | - | 9.2 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 48.1 |
| WHO GETS IN | rule | 0.33 | - | 79.7 |

### Plans: gs3-83c8646-p59

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.3 | 60% | 372 | 266 | 72% |
| Mine | move | 34.7 | 94% | 2131 | 0 | 0% |
| Mine | shoot | 4.3 | 38% | 148 | 104 | 70% |
| Mine | support | 0.7 | 100% | 3 | 0 | 0% |
| Opponent | charge | 1.7 | 60% | 95 | 137 | 143% |
| Opponent | join | 5.0 | 100% | 210 | 0 | 0% |
| Opponent | move | 28.7 | 95% | 1479 | 0 | 0% |
| Opponent | shoot | 3.0 | 78% | 82 | 111 | 135% |

### Battle groups: gs3-83c8646-p59

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.3 | 15% | 100% | 0% | - | 100% | 0% | 0% | 0% | 0% |
| Opponent | REDIRECT COUNTER | 0.7 | 50% | 100% | 0% | - | 100% | 0% | 0% | 0% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p59

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Chaff | 4 | 0 (4) | 0 | 0 | 118 | 0% | 1.5 | - | 0 (3) | 0 (1) | 0 (3) | 0 (1) |
| Mine | Character | 5 | 45 (5) | 45 | 0 | 35 | 20% | 4.5 | 38 (2) | 85 (1) | - | 38 (2) | 85 (1) |
| Mine | Clean-up | 1 | 293 (1) | 0 | 293 | 0 | 0% | 3.0 | - | 293 (1) | - | - | 293 (1) |
| Mine | Fast Hammer | 2 | 31 (2) | 31 | 0 | 0 | 50% | 5.0 | 31 (2) | - | - | - | 31 (2) |
| Mine | Hammer | 4 | 20 (4) | 20 | 0 | 69 | 25% | 2.0 | 29 (3) | 0 (1) | - | 50 (2) | 0 (2) |
| Mine | Holder | 7 | 95 (7) | 8 | 87 | 10 | 29% | 1.8 | 245 (2) | 56 (4) | - | 245 (2) | 56 (4) |
| Mine | Shooter | 3 | 32 (3) | 32 | 0 | 0 | 0% | 1.7 | 9 (2) | 115 (1) | - | 9 (2) | 115 (1) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | - | - | 0 (2) | - |
| Opponent | Chaff | 4 | 110 (4) | 23 | 88 | 50 | 50% | 3.0 | 147 (3) | - | 0 (1) | 147 (3) | 0 (1) |
| Opponent | Character | 9 | 46 (9) | 46 | 0 | 0 | 78% | 3.5 | 113 (2) | 0 (7) | - | 0 (5) | 107 (4) |
| Opponent | Fast Hammer | 4 | 44 (4) | 15 | 28 | 39 | 50% | 3.0 | - | 44 (4) | - | 0 (1) | 55 (3) |
| Opponent | Hammer | 3 | 70 (3) | 70 | 0 | 75 | 0% | 3.3 | - | 70 (3) | - | 94 (2) | 0 (1) |
| Opponent | Holder | 3 | 0 (3) | 0 | 0 | 29 | 67% | 5.0 | 0 (2) | 0 (1) | - | - | 0 (3) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |

### Charged fights: gs3-83c8646-p59

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 1 | 447 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 0 of 2 | 2 of 2 | - | +0 |
| Mine | Tomb Kings of Khemri | 1 | 0 | 460 | 3.0 | 1.3 | 153 | 24 | +129 | 0 of 3 | 3 of 3 | +290 | +49 |
| **Mine** | all armies | 2 | 224 | 230 | 2.5 | 1.2 | 92 | 14 | +78 | 0 of 5 | 5 of 5 | +290 | +24 |
| Opponent | Vampire Counts | 1 | 145 | 950 | 4.0 | 1.0 | 238 | 11 | +226 | 2 of 4 | 3 of 4 | - | +226 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 2 | 72 | 475 | 2.0 | 1.0 | 238 | 11 | +226 | 2 of 4 | 3 of 4 | - | +226 |

### Effective charges: gs3-83c8646-p59

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 2 | 1 (net +0) | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 50% (1 of 2) |
| Mine | Tomb Kings of Khemri | 3 | 0 | 0 | 0 | 1 (net +98) | 1 (net +290) | 0 | 1 | 0% (0 of 2) |
| Opponent | Vampire Counts | 4 | 1 (net +10) | 0 | 1 (net +145) | 1 (net +210) | 0 | 1 (net +540) | 0 | 25% (1 of 4) |

### Charged fights, damage counted: gs3-83c8646-p59

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 440 | 186 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 1 | 41 | 75 | +0 | 0 | 22 | -22 | -53.8 |
| Mine | 76-89% | 1 | 431 | 170 | +98 | 170 | 120 | +50 | +11.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 606 | 120 | +290 | 355 | 0 | +355 | +58.6 |
| Mine | No odds | 1 | 411 | 170 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | All fights | 5 | 386 | 144 | +78 | 105 | 28 | +77 | +19.9 |
| Opponent | Long shot (under 50%) | 1 | 45 | 55 | +10 | 72 | 64 | +8 | +17.9 |
| Opponent | Effective (55-75%) | 1 | 186 | 145 | +145 | 145 | 0 | +145 | +78.0 |
| Opponent | 76-89% | 1 | 471 | 210 | +210 | 210 | 32 | +178 | +37.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 471 | 440 | +540 | 540 | 0 | +540 | +114.6 |
| Opponent | All fights | 4 | 293 | 212 | +226 | 242 | 24 | +218 | +74.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p59 | move | 22 | 4 (18%) | 3 (14%) | 4 (18%) | 14 (64%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L2127 |
| Invocation of Nehek | Opponent | L2127 |
| Periapt of Soul Exchange | Mine | L2127 |
| Ring of Doom | Opponent | L2231 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |

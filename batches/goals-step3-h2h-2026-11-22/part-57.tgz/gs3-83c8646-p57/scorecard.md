# Doctrine scorecard: gs3-83c8646-p57

### Scorecard: gs3-83c8646-p57

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1527 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1527 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1625 | 5 | 1 | Mine | yes | - | 4 | 2 | 2 | 0 | 0 | 0 | 307 |
| L1625 | 5 | 1 | Opponent | no | - | 4 | 2 | 4 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | no | 1 | 2 | 6 | 0 | 0 | 0 | 0 | 230 |
| L1723 | 1 | 1 | Opponent | yes | 6 | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 50% | 1.0 | 3.0 | 4.0 | 1.0 | 0.0 | 0.0 | 0.0 | 268.5 |
| **Average** | | | Opponent | 50% | 6.0 | 3.0 | 3.5 | 2.5 | 0.5 | 0.0 | 0.0 | 0.0 |

### KPIs: gs3-83c8646-p57

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 15) | 0% (0 of 14) | 0% (0 of 29) |
| Winner chose to follow up after the loser gave ground |  | 67% (2 of 3); on the table 67% | 100% (1 of 1); on the table 100% | 75% (3 of 4); on the table 75% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 67% (2 of 3); on the table 67% | 100% (2 of 2); on the table 100% | 80% (4 of 5); on the table 80% |
| Magic missiles tried each own turn | 50%+ | - | 71% (10 of 14) | 71% (10 of 14) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 67% (4 of 6) | 67% (4 of 6) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 40% (1614 of 4000) | 52% (2097 of 3999) | 46% (3711 of 7999) |
|   infantry points that never fought | lower | 80% (823 of 1030) | 60% (393 of 660) | 72% (1216 of 1690) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 69% (9 of 13) | 64% (7 of 11) | 67% (16 of 24) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 1.7 uses a game | 0.0 uses a game | 100% (2 of 2); 0.8 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 65% (2069 of 3195) | 49% (1508 of 3054) | 57% (3577 of 6249) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 0.7 (50%) | 0.7 (50%) |
| IN COMBAT: engaged in combat | - | 0.3 (25%) | 0.3 (25%) |
| GONE: slain | - | 0.3 (25%) | 0.3 (25%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.3 | 1.7 | 0.7 | 3.3 | 0.3 | 1.7 |
| not cast | 5.3 | 1.7 | 0.7 | 1.3 | 1.7 | 20.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (20%) | 0.0 (0%) | 0.7 (50%) | 0.7 (40%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (6%) | 0.0 (0%) | 0.0 (0%) | 0.3 (25%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (25%) | 0.0 (0%) | 2.3 (11%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.7 (40%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.3 (6%) | 0.7 (40%) | 0.0 (0%) | 0.0 (0%) | 1.0 (60%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.7 (88%) | 0.0 (0%) | 0.7 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.0 (84%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.7 a game | 0.0 a game | 0.3 a game |
| stood (cast and not dispelled) | - | - | - |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 69% (38 of 55) | 62% (25 of 40) | 66% (63 of 95) |
|   cavalry | 92% (11 of 12) | 92% (11 of 12) | 92% (22 of 24) |
|   character | - | 0% (0 of 9) | 0% (0 of 9) |
|   infantry | 57% (12 of 21) | 74% (14 of 19) | 65% (26 of 40) |
|   monster | 60% (6 of 10) | - | 60% (6 of 10) |
|   war machine | 75% (9 of 12) | - | 75% (9 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.3 (6%) | 0.0 (0%) | 0.3 (3%) |
| CHARGED: it charged | 0.3 (6%) | 1.3 (27%) | 1.7 (16%) |
| FLEEING: it fled or was fleeing | 0.3 (6%) | 0.0 (0%) | 0.3 (3%) |
| IN COMBAT: it fought this turn or the last | 0.7 (12%) | 0.3 (7%) | 1.0 (9%) |
| MOVED: a war machine that moved | 0.3 (6%) | 0.0 (0%) | 0.3 (3%) |
| NO TARGET IN RANGE | 2.0 (35%) | 1.3 (27%) | 3.3 (31%) |
| ONLY IN COMBAT: the only targets were in combat | 1.0 (18%) | 1.7 (33%) | 2.7 (25%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 0.3 (7%) | 0.3 (3%) |
| SHELTERED: the target was sheltered | 0.7 (12%) | 0.0 (0%) | 0.7 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.3 | 1.0 | 91% | 0.9 pts | 7 pts |
| infantry | 14.7 | 4.0 | 82% | 5.3 pts | 78 pts |
| monster | 2.0 | 0.3 | 83% | 8.1 pts | 16 pts |
| war machine | 3.0 | 1.3 | 78% | 22.1 pts | 66 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.7 | 3.7 | 4.7 |
| Charges that made contact a game | 5.0 | 1.3 | 3.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (3 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 1.00 contact (2 units) | 2.00 declared, 0.00 contact (1 units) | 1.33 declared, 0.67 contact (3 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.68 declared, 0.59 contact (22 units) | 0.33 declared, 0.15 contact (27 units) | 0.49 declared, 0.35 contact (49 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | - | 100% (2 of 2) | - | 100% (2 of 2) |
| Character in a unit | 100% (1 of 1) | 100% (1 of 1) | - | 100% (2 of 2) |
| Character on its own | 100% (1 of 1) | 0% (0 of 2) | 33% (2 of 6) | 33% (3 of 9) |
| Infantry | 100% (4 of 4) | 100% (2 of 2) | - | 100% (6 of 6) |
| Monster | 60% (3 of 5) | - | - | 60% (3 of 5) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Kingdom of Bretonnia | 1 | - | - | 72% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | 67% (2 of 3); on the table 67% | - | 8% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (2 of 2); on the table 100% | - | 27% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | - | 100% (6 of 6) | 77% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p57, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | - | 33% (4) | 33% (4) |
| ...free all their last turn and able to turn (per game) | 0.00 | 1.33 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 1.00 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.33 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: gs3-83c8646-p57

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 71% (10 of 14) | 25% (2 of 8) |
| Strategy | Shoot objectives carried out (shot that target) | 5% (1 of 19) | 22% (2 of 9) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 0% (0 of 1) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 83% (5 of 6) | 75% (3 of 4) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 1.0 | 2.5 |
| Movement | Points that never moved of their own | 268.5 | 0.0 |
| Movement | Fights charged into per game | 4.5 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 8 | 0 of 3 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 8, net +195 | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 8, net +240 | 0 of 3 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 8, net -30 | 1 of 3, net +247 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.3 | 9.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 58% (18 of 31) | 41% (11 of 27) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 3.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 67% (6 of 9) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | - | 2.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 29% (2 of 7) |
| Magic | Wounds caused by magic missiles | 1.3 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.3 / 0.7 / 0.3 / 0.0 | 2.0 / 0.3 / 0.7 / 0.3 |
| Combat | Points destroyed in combat | 458.7 | 380.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +96 | +181 |
| Combat | Net per 100 charger points, damage counted | +31.4 | +41.7 |
| Combat | First round won (charged fights) | 89% | 75% |
| Combat | Net points per charged fight | +92 | +179 |
| Combat | Net points per supported fight / lone fight | - / +92 | - / +179 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 9 | 1 of 4 |
| Game | Points lost | 750.5 | 638.0 |
| Game | VP from objectives | 540.0 | 705.0 |
| Game | Lone holders (player turns) | 1.0 | 6.0 |

- Mine won / drew / lost: 1 / 0 / 1 of 2 ended games (of 3); mean margin (Mine - Opponent) -204 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 1388
- Games not ended: 1 (L1527-1); findings 2, warnings 0

### Opponent rules: gs3-83c8646-p57

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH IN POINTS | 0.3 | +83.5 | 0.0 | 61.7 | 0.3 | +47.0 | 0.0 | 0.0 |
| ARMY TABLE | 13.3 | +196.1 | 0.0 | 123.3 | 18.7 | +685.4 | 0.0 | 146.7 |
| ASSAILMENT BY POINTS | 0.3 | +1.1 | 0.0 | 61.7 | 0.3 | +1.1 | 0.0 | 0.0 |
| BACKUP TARGETS | - | - | - | - | 0.7 | +2.2 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.3 | -113.5 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 3.0 | +26.4 | 0.0 | 66.7 | - | - | - | - |
| CAST JOB | - | - | - | - | 0.3 | +0.5 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 3.3 | +245.3 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 1.0 | +14.7 | 0.0 | 264.7 |
| CHAMPION KNOWS CHALLENGE | 0.3 | -10.3 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 12.0 | -241.4 | 0.0 | 280.7 | 14.3 | -671.8 | 0.0 | 266.7 |
| CHARGE NOT DECLARED | 0.3 | +0.0 | 20.0 | 0.0 | - | - | - | - |
| CHARGE NOW FIRST | 3.0 | +0.0 | 101.7 | 0.0 | 2.0 | +0.0 | 243.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 10.0 | +0.0 | 0.0 | 0.0 | 16.7 | +0.0 | 0.0 | 393.3 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 258.3 | 180.0 |
| CONTINUE AHEAD WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 16.0 | -924.0 | 0.0 | 120.0 | 9.3 | -1056.6 | 0.0 | 222.7 |
| DEPLOY BY FIGURES | 7.3 | +4.0 | 0.0 | 0.0 | 7.7 | +7.5 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.7 | -146.1 | 123.3 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +72.5 | 0.0 | 0.0 | 0.7 | +6.6 | 35.7 | 0.0 |
| EXACT ROUND | 4.0 | +27.4 | 60.0 | 135.0 | 2.3 | +8.7 | 120.0 | 0.0 |
| FACES THE THREAT | - | - | - | - | 0.3 | +0.0 | 0.0 | 23.3 |
| FALL BACK GOOD ORDER | 2.7 | +0.0 | 169.7 | 135.0 | 3.3 | +16.4 | 243.3 | 0.0 |
| FALLS SHORT | 1.7 | +21.2 | 0.0 | 61.7 | 22.3 | +154.1 | 0.0 | 528.0 |
| FEATURE BUFFS | 0.7 | +13.9 | 0.0 | 0.0 | - | - | - | - |
| FIGHT LIFT | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.7 | +12.3 | 0.0 | 0.0 | 1.3 | +2.5 | 0.0 | 0.0 |
| FIVE ACTION | 72.0 | +5085.4 | 229.7 | 805.3 | 80.0 | +4181.0 | 460.7 | 1192.0 |
| FLANK NOT WEIGHED | 6.0 | +0.0 | 0.0 | 61.7 | 9.3 | +0.0 | 0.0 | 406.0 |
| FOLLOW UP WEIGHED | 2.0 | +444.4 | 0.0 | 135.0 | 0.3 | +18.1 | 0.0 | 0.0 |
| FOOT FIRST | 18.0 | +0.0 | 0.0 | 102.3 | - | - | - | - |
| FOUR ROUNDS | 5.3 | +386.8 | 229.7 | 135.0 | 3.7 | +270.2 | 279.0 | 0.0 |
| FREED FROM HIS FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 360.0 |
| FRIEND CHARGES FIRST | 0.3 | -13.3 | 0.0 | 0.0 | 0.3 | -13.5 | 0.0 | 0.0 |
| GIVES UP | 1.0 | -19.3 | 23.3 | 0.0 | 0.3 | -0.2 | 0.0 | 0.0 |
| GOAL ON TIME | 0.7 | +38.5 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 12.3 | +960.1 | 0.0 | 240.0 | 5.7 | +409.1 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HE REFORMS ONCE FREED | 0.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 11.0 | +0.0 | 0.0 | 280.7 | 11.7 | +0.0 | 0.0 | 266.7 |
| HIS CHARGE LIST | 6.0 | +0.0 | 0.0 | 240.3 | 8.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 10.7 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 169.3 |
| HIS MOVE AND SHOT | 2.7 | -20.7 | 0.0 | 55.3 | 5.7 | -100.2 | 0.0 | 0.0 |
| HIS ONE QUARTER | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 14.0 | +0.0 | 0.0 | 47.0 | 10.0 | +0.0 | 0.0 | 169.3 |
| HIS RUN AFTER OUR TURN | 5.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 25.0 | +122.8 | 0.0 | 349.0 | 40.3 | +919.5 | 0.0 | 226.7 |
| HIS SHOTS BY HIS RUN | 17.3 | +101.9 | 0.0 | 465.7 | 37.0 | +243.4 | 0.0 | 200.0 |
| HIS TURN DENIED | 0.7 | +2.0 | 20.0 | 0.0 | 1.3 | +38.0 | 123.3 | 0.0 |
| HOLD ODDS | 9.3 | +0.0 | 0.0 | 61.7 | 11.7 | +0.0 | 0.0 | 20.0 |
| HOLDER ASSIGNMENT | 7.0 | +713.3 | 0.0 | 61.7 | 8.7 | +764.2 | 0.0 | 40.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 5.0 | -192.5 | 229.7 | 135.0 | 3.7 | -132.4 | 279.0 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 1.0 | +10.6 | 0.0 | 0.0 |
| IDLE COST | 0.3 | -4.0 | 0.0 | 0.0 | 15.0 | -196.8 | 0.0 | 146.7 |
| JOINT CHARGE NOW | 0.3 | -2.1 | 0.0 | 0.0 | 0.7 | -50.9 | 123.3 | 0.0 |
| JOINT KNOWS CHALLENGE | 0.3 | -6.6 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 3.7 | +0.0 | 0.0 | 61.7 | 4.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +33.0 | 0.0 | 0.0 | 1.3 | +56.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 11.0 | +0.0 | 379.3 | 63.3 | 8.7 | +0.0 | 151.3 | 138.0 |
| LONE WIZARD KEPT IN | 0.3 | +7.9 | 0.0 | 0.0 | 0.3 | +7.5 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.3 | -3.1 | 65.0 | 135.0 | 1.7 | +0.3 | 123.3 | 0.0 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 2.0 | -204.1 | 0.0 | 46.7 |
| MANOEUVRE | 0.7 | +0.0 | 0.0 | 61.7 | 1.0 | +0.0 | 0.0 | 169.3 |
| MARCH CHECK | 0.3 | +11.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 2.3 | +0.0 | 0.0 | 61.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 0.7 | +4.6 | 0.0 | 0.0 | 3.3 | +67.5 | 0.0 | 0.0 |
| MEETS IN TIME | 4.0 | +232.5 | 0.0 | 0.0 | 4.3 | +194.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.0 | +28.4 | 0.0 | 0.0 | 3.0 | +17.8 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 2.0 | +21.0 | 0.0 | 0.0 | 3.7 | +15.4 | 0.0 | 0.0 |
| MOVE ORDER | 1.3 | +0.0 | 58.3 | 0.0 | 2.7 | +0.0 | 0.0 | 180.0 |
| MOVE TO CHARGE COMPUTED | 10.3 | +770.0 | 0.0 | 47.0 | 10.0 | +722.1 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 9.3 | +361.6 | 0.0 | 89.3 | 7.7 | +278.8 | 0.0 | 209.3 |
| NEAREST TO GOAL | 3.3 | +0.0 | 0.0 | 116.7 | - | - | - | - |
| NEXT CHARGE BY LIST | 8.7 | +667.8 | 0.0 | 0.0 | 7.3 | +503.6 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -0.6 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 5.0 | -149.5 | 229.7 | 135.0 | 3.0 | -105.1 | 155.7 | 0.0 |
| NO LATE CUT | 1.7 | +0.0 | 0.0 | 61.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 5.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 5.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.3 | -1.4 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 1.7 | -66.1 | 0.0 | 0.0 | 4.0 | -87.6 | 0.0 | 20.0 |
| ONE CHALLENGE TEST | 0.3 | +0.6 | 84.7 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.3 | -101.0 | 0.0 | 0.0 | 7.3 | -138.8 | 0.0 | 101.3 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | +10.7 | 123.3 | 0.0 |
| ONE OBJECTIVE FORMULA | 2.7 | +91.6 | 0.0 | 0.0 | 3.3 | -21.9 | 0.0 | 40.0 |
| ONE PROMISE A TARGET | 1.0 | -58.9 | 0.0 | 0.0 | 1.0 | -65.9 | 0.0 | 0.0 |
| ONE ROUTE | 2.3 | +0.0 | 0.0 | 61.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 5.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.7 | +45.5 | 43.3 | 0.0 | 0.7 | +25.8 | 35.7 | 0.0 |
| OVERRUNS AWAY | 1.0 | +128.2 | 43.3 | 0.0 | 0.7 | +27.2 | 58.3 | 0.0 |
| PATHS CROSS | - | - | - | - | 1.0 | +5.4 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -63.8 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 32.7 | +986.2 | 69.0 | 792.3 | 41.7 | +326.8 | 123.3 | 803.3 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 16.7 |
| PROMISE BY ITS OWN SUM | 9.0 | -126.5 | 0.0 | 47.0 | 13.0 | -431.7 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.0 | -7.8 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| QUARTER ODDS | 14.0 | +1690.5 | 16.7 | 204.7 | 13.3 | +1849.2 | 220.7 | 0.0 |
| REAL GROUND | 2.3 | +0.0 | 0.0 | 61.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 1.3 | +195.3 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.3 | +36.2 | 0.0 | 0.0 | 6.0 | +689.4 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 3.0 | -53.7 | 0.0 | 0.0 | 3.0 | -89.3 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 0.3 | +23.3 | 0.0 | 0.0 | 0.7 | +18.2 | 0.0 | 0.0 |
| RISK BY ARC | 5.0 | +118.8 | 229.7 | 135.0 | 3.0 | -119.2 | 155.7 | 0.0 |
| RISK ON THE WAY | 1.7 | +0.0 | 0.0 | 61.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 2.3 | -67.2 | 159.0 | 0.0 |
| RUN DOWN | - | - | - | - | 3.0 | -23.1 | 159.0 | 0.0 |
| SAME CHARGE LATER | 0.3 | -4.4 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.7 | -63.7 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +10.1 | 0.0 | 0.0 | 0.7 | +17.1 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +71.9 | 0.0 | 0.0 | 0.7 | +59.7 | 61.7 | 0.0 |
| SELF MOVE SPELL | 1.3 | +30.7 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 6.0 | -171.8 | 0.0 | 169.3 |
| SET UP BY THE SET | 0.7 | +27.1 | 0.0 | 0.0 | 10.0 | -26.1 | 0.0 | 169.3 |
| SHOOTERS IN TWO RANKS | 1.0 | +2.0 | 0.0 | 0.0 | 0.3 | +1.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 5.7 | +0.0 | 0.0 | 102.3 | 5.0 | +0.0 | 0.0 | 63.3 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +16.7 | 0.0 | 0.0 | 2.0 | +5.7 | 123.3 | 0.0 |
| SHOT OR CHARGE | 0.3 | -0.3 | 0.0 | 0.0 | 0.7 | -2.4 | 120.0 | 0.0 |
| SHOT RISK POINTS | 9.7 | -79.5 | 0.0 | 164.0 | 28.3 | -423.1 | 0.0 | 200.0 |
| SHOTS AFTER THE MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 13.0 | +246.3 | 0.0 | 191.7 | 8.3 | +47.7 | 0.0 | 60.0 |
| SPELL WORTH | 1.0 | +8.4 | 0.0 | 0.0 | - | - | - | - |
| SPELLS IN THE FIGHT | 0.7 | -1.0 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 4.0 | +0.0 | 0.0 | 47.0 | 8.3 | +0.0 | 0.0 | 81.7 |
| STAND AND SHOOT | - | - | - | - | 1.3 | -6.8 | 181.7 | 0.0 |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 27.0 | +0.0 | 0.0 | 260.0 | 17.3 | +0.0 | 181.7 | 529.3 |
| STAY WORTH | 7.3 | -4.7 | 0.0 | 127.7 | 4.7 | +10.8 | 58.3 | 40.0 |
| STUPIDITY NEXT TURN | 0.3 | +0.0 | 0.0 | 47.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 1.7 | +54.6 | 0.0 | 123.3 | 4.0 | +356.8 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 1.7 | +54.6 | 0.0 | 123.3 | 4.0 | +356.8 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +1.6 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 65.0 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 180.0 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 5.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 31.3 | +0.0 | 0.0 | 311.7 | 42.3 | +0.0 | 0.0 | 619.3 |
| TIED UP BY THE SUM | 3.0 | +293.4 | 80.0 | 135.0 | 1.7 | +207.6 | 120.0 | 0.0 |
| TIME ON OUR SIDE | 28.7 | +428.3 | 0.0 | 147.7 | 8.7 | +61.9 | 0.0 | 470.0 |
| WAITS AGAIN | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| WEAPON BY POINTS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | 1.0 | +53.2 | 0.0 | 0.0 | 1.0 | +29.4 | 0.0 | 0.0 |
| WHO HITS BACK | 0.3 | +3.7 | 0.0 | 0.0 | 0.7 | +23.7 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.3 | -161.4 | 0.0 | 116.7 | 4.0 | -365.7 | 0.0 | 66.7 |
| WHOLE FIGHT GAIN | 0.3 | +2.1 | 0.0 | 0.0 | 0.7 | +98.7 | 123.3 | 0.0 |
| WOUNDS ON THE RANKS | 1.0 | +20.7 | 0.0 | 61.7 | 3.0 | +80.8 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p57

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 96 | 96 | 75 | 25.00 | +2060 | +27.5 |
| LEGAL CHARGES ONLY | 59 | 59 | 59 | 19.67 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 47 | 47 | 43 | 14.33 | +3281 | +76.3 |
| FIVE ACTION | 456 | 444 | 34 | 11.33 | +3106 | +91.4 |
| HIS SHOT LIST | 196 | 190 | 31 | 10.33 | +214 | +6.9 |
| MOVE TO CHARGE COMPUTED | 61 | 56 | 30 | 10.00 | +1154 | +38.5 |
| DEPLOY BY FIGURES | 45 | 45 | 25 | 8.33 | +242 | +9.7 |
| NEXT CHARGE BY LIST | 48 | 45 | 24 | 8.00 | +1046 | +43.6 |
| THE TABLE AGAIN | 32 | 32 | 21 | 7.00 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 66 | 66 | 20 | 6.67 | -1674 | -83.7 |
| MEETS IN TIME | 25 | 25 | 19 | 6.33 | +1217 | +64.0 |
| REDIRECT FOR A FRIEND IN REACH | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| OFF BEST | 17 | 17 | 17 | 5.67 | -461 | -27.1 |
| FOUR ROUNDS | 27 | 26 | 15 | 5.00 | +590 | +39.3 |
| GOAL WALK | 54 | 54 | 15 | 5.00 | +914 | +61.0 |
| COVER ONCE | 76 | 55 | 14 | 4.67 | +201 | +14.4 |
| TIED UP BY THE SUM | 14 | 14 | 14 | 4.67 | +654 | +46.7 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 163 | 157 | 11 | 3.67 | +33 | +3.0 |
| QUARTER ODDS | 82 | 78 | 11 | 3.67 | +1101 | +100.1 |
| IDLE COST | 46 | 40 | 9 | 3.00 | +63 | +7.0 |
| FALLS SHORT | 72 | 62 | 8 | 2.67 | +90 | +11.2 |
| LANE BY FIGURES | 8 | 8 | 8 | 2.67 | +267 | +33.4 |
| SET UP BY THE SET | 32 | 32 | 8 | 2.67 | +268 | +33.4 |
| FOLLOW UP WEIGHED | 7 | 7 | 7 | 2.33 | +1387 | +198.2 |
| SHOOTS FROM THE BEST SPOT | 10 | 10 | 7 | 2.33 | +4 | +0.5 |
| SHOT RISK POINTS | 114 | 106 | 7 | 2.33 | +58 | +8.3 |
| CHAFF IN THE MOVE | 10 | 9 | 6 | 2.00 | +0 | +0.0 |
| COMBAT PIVOT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| ONE PROMISE A TARGET | 6 | 6 | 6 | 2.00 | -374 | -62.4 |
| RISK BY ARC | 24 | 23 | 6 | 2.00 | +156 | +26.0 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHARGE LOSSES | 79 | 75 | 4 | 1.33 | +302 | +75.5 |
| HARD STAY DROPPED | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| MAX FOR POSITIONING | 12 | 10 | 4 | 1.33 | +20 | +4.9 |
| SHOOTERS IN TWO RANKS | 4 | 4 | 4 | 1.33 | +11 | +2.8 |
| TIME ON OUR SIDE | 112 | 90 | 4 | 1.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +44 | +14.6 |
| CHARGE NOW FIRST | 15 | 15 | 3 | 1.00 | -163 | -54.2 |
| HIS MOVE AND SHOT | 25 | 24 | 3 | 1.00 | +4 | +1.3 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | -159 | -53.0 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +16 | +5.4 |
| PROMISE KNOWS THE FIGHT | 5 | 4 | 3 | 1.00 | -23 | -7.8 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +124 | +41.4 |
| SEARCH SPOT | 3 | 3 | 3 | 1.00 | +82 | +27.2 |
| SECOND LOOK | 3 | 3 | 3 | 1.00 | +395 | +131.6 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +77 | +25.5 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +392 | +195.8 |
| ASSAILMENT BY POINTS | 2 | 2 | 2 | 0.67 | +7 | +3.4 |
| EXACT ROUND | 19 | 18 | 2 | 0.67 | +13 | +6.7 |
| GOAL ON TIME | 2 | 2 | 2 | 0.67 | -41 | -20.6 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +46 | +23.1 |
| MISSILES IN THE MOVE | 15 | 10 | 2 | 0.67 | +30 | +15.2 |
| OPENS UP | 4 | 4 | 2 | 0.67 | +103 | +51.6 |
| OVERRUNS AWAY | 5 | 5 | 2 | 0.67 | +142 | +71.0 |
| REDIRECT BY WHAT IT STOPS | 4 | 4 | 2 | 0.67 | +0 | +0.0 |
| REFORMS TO MEET IT | 18 | 16 | 2 | 0.67 | +0 | +0.2 |
| SUPPORT ADDS | 17 | 17 | 2 | 0.67 | +304 | +152.0 |
| SUPPORT WORKED OUT | 17 | 17 | 2 | 0.67 | +304 | +152.0 |
| WEAPON BY POINTS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHO FIGHTS | 6 | 5 | 2 | 0.67 | +45 | +22.3 |
| WOUNDS ON THE RANKS | 12 | 12 | 2 | 0.67 | +50 | +25.1 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -340 | -340.5 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -61 | -60.8 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS TURN DENIED | 6 | 5 | 1 | 0.33 | +10 | +10.3 |
| MARCH CHECK | 1 | 1 | 1 | 0.33 | +4 | +4.4 |
| MISSILES NEXT TURN | 17 | 12 | 1 | 0.33 | +0 | +0.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| NEARER NOT NEEDED | 51 | 48 | 1 | 0.33 | +72 | +72.3 |
| NO DOUBLE ROUNDS | 24 | 23 | 1 | 0.33 | +22 | +22.0 |
| ONE FIGHT FORMULA | 38 | 15 | 1 | 0.33 | +1 | +1.2 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -191 | -191.4 |
| REDIRECT COUNTER | 22 | 20 | 1 | 0.33 | +38 | +38.5 |
| REFUSING RETIRES | 2 | 2 | 1 | 0.33 | -21 | -20.6 |
| SHOTS AFTER THE MOVES | 13 | 13 | 1 | 0.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 64 | 47 | 1 | 0.33 | +11 | +10.6 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 12 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 19 | 19 | 1 | 0.33 | +126 | +125.9 |
| WHOLE FIGHT GAIN | 3 | 3 | 1 | 0.33 | +55 | +55.1 |
| BACKUP TARGETS | 2 | 1 | 0 | 0.00 | - | - |
| CANNON PLANNED TARGET | 9 | 9 | 0 | 0.00 | - | - |
| CAST JOB | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 80 | 76 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 3 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 18 | 18 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FIGHT TO THE END | 6 | 6 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 46 | not checked | - | - | - | - |
| FOOT FIRST | 54 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 19 | 18 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 4 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 9 | 8 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 68 | 65 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 42 | 40 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 51 | 49 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 10 | 8 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 72 | 67 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 31 | 31 | 0 | 0.00 | - | - |
| HOLD ODDS | 63 | 62 | 0 | 0.00 | - | - |
| HONEST WORTH | 26 | 25 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 3 | 2 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 23 | 22 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 9 | 9 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 6 | 6 | 0 | 0.00 | - | - |
| MANOEUVRE | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 9 | 8 | 0 | 0.00 | - | - |
| NEAREST TO GOAL | 10 | 10 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO LATE CUT | 7 | 7 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 32 | 32 | 0 | 0.00 | - | - |
| NO SECOND RUN | 32 | 32 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 2 | 2 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 18 | 15 | 0 | 0.00 | - | - |
| ONE ROUTE | 9 | 8 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 32 | 32 | 0 | 0.00 | - | - |
| PLAN RESULT | 223 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 3 | 3 | 0 | 0.00 | - | - |
| REAL GROUND | 9 | 8 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 7 | 6 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 7 | 7 | 0 | 0.00 | - | - |
| RUN DOWN | 9 | 9 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 8 | 8 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 4 | not checked | - | - | - | - |
| SET CREDITED ONCE | 18 | 18 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 32 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL WORTH | 3 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 37 | 30 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 7 | 7 | 0 | 0.00 | - | - |
| STANDS STILL | 133 | 132 | 0 | 0.00 | - | - |
| STAY WORTH | 36 | 29 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 8 | 5 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 4 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 12 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 1 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 9 | not checked | - | - | - | - |
| THE TABLE BINDS | 221 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 4 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 4 | 4 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p57

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 2.00 | 4.67 | 83.7 |
| JOB FIRST | gate | 0.67 | 3.67 | 25.9 |
| ARMY TABLE | rule | 1.33 | 2.00 | 63.6 |
| ONE PROMISE A TARGET | rule | 1.00 | 1.00 | 62.4 |
| CHARGE NOW FIRST | rule | 0.33 | 0.67 | 54.2 |
| JOINT CHARGE NOW | rule | 0.33 | 0.67 | 53.0 |
| PROMISE KNOWS THE FIGHT | rule | 1.00 | - | 7.8 |
| GOAL ON TIME | rule | 0.67 | - | 20.6 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.33 | 1.6 |
| NO REASON | gate | 0.67 | - | 31.3 |
| SET UP BY THE SET | rule | - | 0.67 | 7.1 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.33 | - | 43.7 |
| BEST PRIZE | rule | - | 0.33 | 340.5 |
| CHARGE NOT DECLARED | rule | 0.33 | - | 60.8 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 191.4 |
| REFUSING RETIRES | rule | 0.33 | - | 20.6 |
| RULE SWITCHED OFF | gate | - | 0.33 | 17.6 |

### Plans: gs3-83c8646-p57

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 4.0 | 75% | 304 | 286 | 94% |
| Mine | move | 23.7 | 92% | 1417 | 0 | 0% |
| Mine | shoot | 5.0 | 40% | 175 | 700 | 400% |
| Opponent | charge | 2.7 | 62% | 299 | 214 | 72% |
| Opponent | join | 2.7 | 100% | 97 | 0 | 0% |
| Opponent | move | 31.7 | 96% | 1321 | 0 | 0% |
| Opponent | shoot | 2.0 | 50% | 155 | 113 | 73% |
| Opponent | support | 2.7 | 75% | 89 | 0 | 0% |

### Battle groups: gs3-83c8646-p57

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 6.0 | 17% | 67% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p57

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | 0 (1) | - | - | - | 0 (1) |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Mine | Character | 6 | 70 (6) | 70 | 0 | 29 | 17% | 2.8 | 19 (3) | 45 (2) | 217 (1) | 85 (4) | 45 (2) |
| Mine | Fast Hammer | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | 0 (1) | - | - | - | 0 (1) |
| Mine | Hammer | 4 | 7 (4) | 7 | 0 | 19 | 50% | 1.5 | 0 (3) | 34 (1) | - | 7 (4) | - |
| Mine | Shooter | 4 | 8 (4) | 0 | 8 | 91 | 0% | 1.0 | 0 (1) | 0 (2) | 36 (1) | 10 (3) | 0 (1) |
| Mine | Support | 3 | 0 (3) | 0 | 0 | 67 | 0% | 4.0 | - | 0 (3) | - | - | 0 (3) |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 50 | 0% | 1.0 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Opponent | Chaff | 6 | 93 (6) | 0 | 93 | 0 | 67% | 1.0 | 43 (4) | 0 (1) | 364 (1) | 105 (5) | 0 (1) |
| Opponent | Character | 5 | 48 (5) | 48 | 0 | 38 | 20% | 4.0 | 22 (1) | 0 (2) | 74 (2) | 0 (2) | 56 (3) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 100 | 0% | 3.0 | 0 (1) | 0 (2) | - | 0 (2) | 0 (1) |
| Opponent | Fast Hammer | 5 | 62 (5) | 62 | 0 | 30 | 40% | 2.0 | - | 62 (5) | - | 29 (3) | 104 (2) |
| Opponent | Hammer | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Holder | 2 | 0 (2) | 0 | 0 | 45 | 0% | 2.5 | - | 0 (1) | 0 (1) | 0 (1) | 0 (1) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 33% | 1.5 | 0 (2) | 0 (1) | - | 0 (1) | 0 (2) |

### Charged fights: gs3-83c8646-p57

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Kingdom of Bretonnia | 1 | 0 | 451 | 3.0 | 1.0 | 150 | 0 | +150 | 1 of 3 | 3 of 3 | - | +150 |
| Mine | Lizardmen | 1 | 0 | 925 | 6.0 | 1.0 | 154 | 91 | +63 | 2 of 6 | 5 of 6 | - | +63 |
| **Mine** | all armies | 2 | 0 | 688 | 4.5 | 1.0 | 153 | 61 | +92 | 3 of 9 | 8 of 9 | - | +92 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 715 | 4.0 | 1.0 | 179 | 0 | +179 | 1 of 4 | 3 of 4 | - | +179 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 2 | 0 | 358 | 2.0 | 1.0 | 179 | 0 | +179 | 1 of 4 | 3 of 4 | - | +179 |

### Effective charges: gs3-83c8646-p57

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Kingdom of Bretonnia | 3 | 0 | 0 | 0 | 1 (net +147) | 1 (net +50) | 1 (net +254) | 0 | 0% (0 of 3) |
| Mine | Lizardmen | 6 | 0 | 0 | 1 (net +195) | 0 | 2 (net +335) | 2 (net -172) | 1 | 20% (1 of 5) |
| Opponent | Tomb Kings of Khemri | 4 | 0 | 0 | 0 | 2 (net +142) | 0 | 1 (net +247) | 1 | 0% (0 of 3) |

### Charged fights, damage counted: gs3-83c8646-p57

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 399 | 195 | +195 | 195 | 0 | +195 | +48.9 |
| Mine | 76-89% | 1 | 275 | 147 | +147 | 147 | 0 | +147 | +53.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 286 | 170 | -30 | 105 | 135 | -30 | -10.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 358 | 60 | +240 | 251 | 0 | +251 | +70.0 |
| Mine | No odds | 1 | 141 | 70 | -141 | 0 | 141 | -141 | -100.0 |
| Mine | All fights | 9 | 305 | 122 | +92 | 156 | 61 | +96 | +31.4 |
| Opponent | 76-89% | 2 | 431 | 135 | +142 | 169 | 24 | +145 | +33.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 440 | 175 | +247 | 247 | 0 | +247 | +56.1 |
| Opponent | No odds | 1 | 431 | 185 | +185 | 185 | 0 | +185 | +42.9 |
| Opponent | All fights | 4 | 433 | 158 | +179 | 193 | 12 | +181 | +41.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p57 | move | 26 | 5 (19%) | 2 (8%) | 6 (23%) | 15 (58%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1527, L1625 |
| Invocation of Nehek | Opponent | L1527, L1625 |
| Ring of Doom | Mine | L1527 |

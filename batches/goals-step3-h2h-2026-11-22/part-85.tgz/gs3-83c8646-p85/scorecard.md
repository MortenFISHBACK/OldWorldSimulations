# Doctrine scorecard: gs3-83c8646-p85

### Scorecard: gs3-83c8646-p85

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 0 | - | 1 | 2 | 0 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 0 | 4 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | yes | 6 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Opponent | no | 1 | - | 0 | 3 | 0 | 0 | 0 | 196 |
| L0214 | 4 | 1 | Mine | no | 2 | - | 2 | 2 | 0 | 0 | 0 | 170 |
| L0214 | 4 | 1 | Opponent | no | 5 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 2.7 | - | 1.0 | 2.0 | 0.0 | 0.0 | 0.0 | 56.7 |
| **Average** | | | Opponent | 0% | 2.0 | 3.0 | 2.0 | 1.7 | 0.3 | 0.0 | 0.0 | 65.3 |

### KPIs: gs3-83c8646-p85

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 11) | 0% (0 of 17) | 0% (0 of 28) |
| Winner chose to follow up after the loser gave ground |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 0% (0 of 2); on the table 0% | 100% (2 of 2); on the table 100% | 50% (2 of 4); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 0% (0 of 2); on the table 0% | 100% (3 of 3); on the table 100% | 60% (3 of 5); on the table 60% |
| Magic missiles tried each own turn | 50%+ | 52% (44 of 84) | 42% (5 of 12) | 51% (49 of 96) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 52% (44 of 84) | 45% (5 of 11) | 52% (49 of 95) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 20% (1 of 5) | - | 20% (1 of 5) |
| Points that never fought | lower | 70% (3971 of 5699) | 72% (4308 of 6000) | 71% (8279 of 11699) |
|   infantry points that never fought | lower | 81% (1806 of 2239) | 100% (677 of 677) | 85% (2483 of 2916) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 75% (12 of 16) | 71% (17 of 24) | 72% (29 of 40) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 5.3 uses a game | 0.0 uses a game | 100% (4 of 4); 2.7 uses a game |
| Bound items with another spell used |  | 0% (0 of 2); 0.0 uses a game | 17% (2 of 12); 1.3 uses a game | 14% (2 of 14); 0.7 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 75% (3 of 4); 1.0 uses a game | 100% (1 of 1); 0.3 uses a game | 80% (4 of 5); 0.7 uses a game |
|   their share of the points of units over 100 pts | lower | 70% (2745 of 3916) | 76% (4317 of 5654) | 74% (7062 of 9570) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 8.0 (60%) | 0.7 (29%) | 8.7 (55%) |
| MARCHED: its unit marched | 3.3 (25%) | 1.0 (43%) | 4.3 (28%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.3 (14%) | 0.3 (2%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (14%) | 0.3 (2%) |
| REAR RANK: in a rear rank | 2.0 (15%) | 0.0 (0%) | 2.0 (13%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 1.0 | 3.7 | 11.0 | 16.3 | 2.0 | 1.0 |
| not cast | 1.0 | 9.3 | 3.0 | 15.7 | 2.0 | 35.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 7.7 (82%) | 0.3 (11%) | 8.7 (55%) | 1.3 (67%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.3 (28%) | 0.7 (33%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (0%) | 0.3 (11%) | 2.0 (13%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.7 (7%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.0 (100%) | 1.0 (11%) | 2.3 (78%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 34.0 (97%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 9.7 a game | 1.3 a game | 5.5 a game |
| stood (cast and not dispelled) | 72% (21 of 29) | 75% (3 of 4) | 73% (24 of 33) |
| the unit moved after it | 71% (15 of 21) | 0% (0 of 3) | 62% (15 of 24) |
| it charged on its next turn | 0% (0 of 21) | 0% (0 of 3) | 0% (0 of 24) |
| the enemy charged it first | 10% (2 of 21) | 0% (0 of 3) | 8% (2 of 24) |
| it fought by the end of its next turn | 5% (1 of 21) | 0% (0 of 3) | 4% (1 of 24) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 21) | 0% (0 of 3) | 0% (0 of 24) |
| none of these (no charge, no fight, no charge escaped) | 90% (19 of 21) | 100% (3 of 3) | 92% (22 of 24) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 58% (14 of 24) | 48% (24 of 50) | 51% (38 of 74) |
|   cavalry | - | 67% (16 of 24) | 67% (16 of 24) |
|   character | - | 0% (0 of 14) | 0% (0 of 14) |
|   infantry | 58% (14 of 24) | 67% (8 of 12) | 61% (22 of 36) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.0 (30%) | 1.3 (15%) | 2.3 (19%) |
| CHARGED: it charged | 0.0 (0%) | 1.7 (19%) | 1.7 (14%) |
| FLEEING: it fled or was fleeing | 0.7 (20%) | 0.0 (0%) | 0.7 (6%) |
| NO TARGET IN RANGE | 1.7 (50%) | 3.7 (42%) | 5.3 (44%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (4%) | 0.3 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 1.3 (15%) | 1.3 (11%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.3 (4%) | 0.3 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 10.7 | 3.7 | 72% | 2.8 pts | 29 pts |
| infantry | 9.7 | 2.7 | 76% | 6.1 pts | 59 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.0 | 3.0 | 2.0 |
| Charges that made contact a game | 0.7 | 2.0 | 1.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 1.00 declared, 0.50 contact (2 units) | 1.00 declared, 0.50 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.15 declared, 0.10 contact (20 units) | 0.32 declared, 0.23 contact (22 units) | 0.24 declared, 0.17 contact (42 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 62% (8 of 13) | - | - | 62% (8 of 13) |
| Character in a unit | 100% (4 of 4) | 88% (7 of 8) | - | 92% (11 of 12) |
| Character on its own | - | - | 80% (4 of 5) | 80% (4 of 5) |
| Infantry | 67% (2 of 3) | 40% (2 of 5) | - | 50% (4 of 8) |
| Monster | 100% (1 of 1) | 100% (1 of 1) | - | 100% (2 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 3 | 0% (0 of 2); on the table 0% | 52% (44 of 84) | 70% | 75% (12 of 16) | 100% (4 of 4); 5.3 uses a game | 0% (0 of 2); 0.0 uses a game | 75% (3 of 4); 1.0 uses a game |
| High Elf Realms | 2 | 100% (3 of 3); on the table 100% | 42% (5 of 12) | 58% | 61% (11 of 18) | 0.0 uses a game | 17% (2 of 12); 2.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | - | - | 100% | 100% (6 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p85, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 20% (1) | 0% (0) | 17% (1) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.00 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.00 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: gs3-83c8646-p85

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 67% (2 of 3) | 50% (3 of 6) |
| Strategy | Shoot objectives carried out (shot that target) | 0% (0 of 20) | 42% (5 of 12) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 3) | 33% (1 of 3) |
| Strategy | Joined characters whose unit fought | 31% (5 of 16) | 0% (0 of 2) |
| Strategy | Lone characters that fought | 0% (0 of 2) | 40% (2 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.0 | 1.7 |
| Movement | Points that never moved of their own | 56.7 | 65.3 |
| Movement | Fights charged into per game | 0.7 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 2, net +36 | 1 of 4, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | 0 of 4 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 2 | 2 of 4, net +84 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 2 | 1 of 4, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 4.7 | 12.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 71% (10 of 14) | 24% (9 of 38) |
| Shooting | Points destroyed by shooting units | 0.0 | 10.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 9.0 | 1.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 56% (15 of 27) | 20% (1 of 5) |
| Magic | Wounds caused by magic missiles | 14.3 | 0.7 |
| Magic | Wounds caused by other spells | - | 0.3 |
| Magic | Points destroyed by magic (all spells) | 229.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.3 / 1.0 / 0.0 / 1.0 | 0.0 / 2.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 41.0 | 74.0 |
| Combat | Points run down | 0.0 | 28.0 |
| Combat | Net points per charged fight, damage counted | +36 | -27 |
| Combat | Net per 100 charger points, damage counted | +68.3 | -7.2 |
| Combat | First round won (charged fights) | 50% | 67% |
| Combat | Net points per charged fight | +36 | +18 |
| Combat | Net points per supported fight / lone fight | - / +36 | - / +18 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 2 | 2 of 6 |
| Game | Points lost | 143.7 | 317.0 |
| Game | VP from objectives | 623.3 | 796.7 |
| Game | Lone holders (player turns) | 2.7 | 2.0 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +73 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 461
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p85

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 16.3 | +113.3 | 0.0 | 27.3 | 29.3 | +674.1 | 0.0 | 41.0 |
| ASSAILMENT BY POINTS | - | - | - | - | 0.3 | +3.4 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 1.0 | -86.6 | 28.3 | 0.0 |
| BOUND ASSAILMENT | - | - | - | - | 0.7 | +0.1 | 0.0 | 0.0 |
| CAST JOB | 0.7 | +1.7 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 5.3 | +1092.9 | 785.3 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 6.3 | +0.0 | 0.0 | 63.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | 0.3 | +6.5 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 3.7 | +147.9 | 0.0 | 142.7 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 1.0 | -1.6 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.7 | +17.5 | 0.0 | 0.0 | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -0.6 | 0.0 | 0.0 |
| CHARGE LOSSES | 9.0 | -646.7 | 0.0 | 0.0 | 18.7 | -1156.8 | 0.0 | 147.3 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 0.0 | 17.3 | 1.0 | +0.0 | 56.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 13.3 | +0.0 | 0.0 | 56.7 | 11.7 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 9.3 | +1115.3 | 0.0 | 63.3 | 1.3 | +140.1 | 0.0 | 0.0 |
| COVER ONCE | 5.0 | -657.5 | 0.0 | 0.0 | 7.7 | -210.0 | 0.0 | 32.7 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -0.5 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 7.0 | +41.0 | 0.0 | 0.0 | 7.3 | -4.5 | 0.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +0.3 | 28.0 | 0.0 |
| EXACT ROUND | 1.0 | +27.2 | 41.0 | 17.3 | 0.7 | +12.6 | 28.3 | 0.0 |
| FALL BACK GOOD ORDER | 0.7 | +0.0 | 41.0 | 0.0 | 1.3 | +0.0 | 28.3 | 0.0 |
| FALLS SHORT | 5.3 | +135.3 | 0.0 | 27.3 | 13.3 | +142.4 | 0.0 | 261.7 |
| FEATURE BUFFS | 9.0 | +293.4 | 0.0 | 0.0 | 3.3 | +107.1 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.3 | +33.3 | 0.0 | 0.0 |
| FIVE ACTION | 67.3 | +8162.4 | 1284.3 | 242.0 | 87.0 | +4034.1 | 189.7 | 653.0 |
| FLANK NOT WEIGHED | 5.3 | +0.0 | 0.0 | 20.0 | 6.3 | +0.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.0 | +23.5 | 41.0 | 17.3 | 2.0 | +244.7 | 56.3 | 0.0 |
| FREED FROM HIS FIGHT | - | - | - | - | 3.7 | +0.0 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.7 | -9.6 | 0.0 | 0.0 |
| GIVES UP ITS SCREEN | 0.3 | -1.1 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 2.3 | +425.9 | 0.0 | 0.0 | 2.7 | +148.2 | 0.0 | 0.0 |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 7.7 | +0.0 | 0.0 | 0.0 | 11.3 | +0.0 | 0.0 | 82.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +33.0 | 0.0 | 0.0 |
| HIS CHARGE LIST | 3.7 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 41.0 |
| HIS LEGAL MOVES | 1.3 | +0.0 | 0.0 | 0.0 | 8.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 6.7 | -82.1 | 0.0 | 0.0 | 6.7 | -252.0 | 0.0 | 65.3 |
| HIS ONE QUARTER | 2.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 1.7 | +0.0 | 0.0 | 0.0 | 9.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 8.3 | +0.0 | 0.0 | 88.7 |
| HIS RANDOM MOVER COMES | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 27.3 | +443.4 | 0.0 | 44.7 | 43.7 | +3727.3 | 0.0 | 219.3 |
| HIS SHOTS BY HIS RUN | 30.0 | +349.3 | 0.0 | 111.3 | 42.7 | +1756.1 | 0.0 | 219.3 |
| HIS TURN DENIED | - | - | - | - | 0.3 | +52.2 | 0.0 | 0.0 |
| HOLD ODDS | 25.0 | +0.0 | 0.0 | 0.0 | 20.0 | +0.0 | 0.0 | 130.7 |
| HOLDER ASSIGNMENT | 13.0 | +1288.6 | 0.0 | 0.0 | 13.7 | +1547.1 | 0.0 | 65.3 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | - | - | - | - | 2.0 | -90.0 | 56.3 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 1.0 | +55.8 | 0.0 | 196.3 |
| IDLE COST | 6.3 | -33.9 | 0.0 | 113.0 | 15.3 | -300.4 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 0.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 1.3 | +51.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.0 | +0.0 | 0.0 | 0.0 | 11.3 | +0.0 | 30.0 | 164.0 |
| LONE WIZARD KEPT IN | 2.7 | +108.0 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 0.7 | +1.5 | 0.0 | 17.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| LURE BY WHAT IT DRAWS | 1.3 | -107.3 | 0.0 | 112.7 | - | - | - | - |
| MANOEUVRE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +8.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.3 | +118.3 | 0.0 | 0.0 | 0.7 | +45.1 | 0.0 | 0.0 |
| MARCH CHECK | 1.0 | +36.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.3 | +16.4 | 0.0 | 0.0 | 0.7 | +35.5 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 1.0 | +53.2 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.0 | +75.7 | 0.0 | 95.0 | 1.3 | +21.3 | 0.0 | 0.0 |
| MEETS IN TIME | 4.0 | +400.5 | 0.0 | 0.0 | 3.7 | +573.2 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 10.0 | +964.7 | 0.0 | 0.0 | 1.3 | +8.0 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 9.7 | +508.6 | 0.0 | 0.0 | 2.7 | +12.9 | 0.0 | 0.0 |
| MISSILES ON ONE TARGET | 2.7 | -108.5 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 3.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 1.7 | +82.1 | 0.0 | 113.3 | 3.3 | +132.0 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 3.7 | +202.7 | 0.0 | 0.0 | 1.0 | +73.5 | 0.0 | 0.0 |
| NEAREST TO GOAL | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 0.3 | +33.4 | 0.0 | 0.0 | 3.3 | +132.0 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.7 | -6.4 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.0 | -18.7 | 41.0 | 17.3 | 2.0 | -40.8 | 56.3 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 28.3 | - | - | - | - |
| NOT WORTH A CAST | 2.0 | -1.7 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 3.0 | -103.7 | 0.0 | 37.3 | 5.3 | -222.8 | 0.0 | 41.0 |
| ONE CHALLENGE TEST | 0.3 | +3.1 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1.3 | +0.0 | 0.0 | 28.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.7 | -109.3 | 0.0 | 56.7 | 8.0 | -164.0 | 0.0 | 41.0 |
| ONE OBJECTIVE FORMULA | 8.0 | +29.2 | 0.0 | 0.0 | 6.0 | +120.3 | 0.0 | 65.3 |
| ONE ROUTE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | - | - | - | - | 0.3 | +4.1 | 10.0 | 0.0 |
| OVERRUNS AWAY | 0.7 | +10.6 | 41.0 | 0.0 | 0.7 | +28.8 | 28.3 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | -96.0 | 0.0 | 0.0 |
| PLAN RESULT | 31.0 | +792.9 | 0.0 | 139.7 | 38.3 | +159.1 | 10.0 | 668.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 3.7 | -111.0 | 0.0 | 113.3 | 6.0 | -34.6 | 0.0 | 0.0 |
| PROMISE IN STEPS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| QUARTER ODDS | 12.0 | +1694.5 | 41.0 | 17.3 | 17.7 | +2429.5 | 0.0 | 82.0 |
| RANDOM MOVE BY FIGURES | 1.7 | +2.5 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 4.3 | +194.5 | 0.0 | 132.7 | 0.7 | -61.5 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 5.7 | +0.0 | 0.0 | 76.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | -60.7 | 28.3 | 0.0 |
| REFORMS TO MEET IT | 0.3 | -0.7 | 0.0 | 0.0 | 1.7 | -2.7 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.7 | +0.0 | 0.0 | 47.7 |
| RESERVE MOVE SPELL | 0.3 | +7.6 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.0 | +10.9 | 41.0 | 17.3 | 1.7 | -19.4 | 56.3 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.0 | -41.7 | 56.3 | 0.0 |
| RUN DOWN | 1.0 | -3.9 | 41.0 | 17.3 | 1.7 | -6.8 | 28.0 | 0.0 |
| SCOUT SPOT | 0.3 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | 2.0 | -219.0 | 0.0 | 20.0 | - | - | - | - |
| SEARCH SPOT | 0.7 | +40.6 | 0.0 | 0.0 | 0.7 | +54.1 | 0.0 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 4.0 | -501.3 | 0.0 | 32.7 |
| SET UP BY THE SET | 0.3 | +0.0 | 0.0 | 0.0 | 5.3 | +751.2 | 0.0 | 32.7 |
| SET-UP ANY TARGET | 1.0 | +172.9 | 0.0 | 31.7 | - | - | - | - |
| SET-UP MISSED | 1.3 | +196.5 | 0.0 | 0.0 | - | - | - | - |
| SHOOTER COUNTED ONCE | 0.7 | -2.6 | 0.0 | 20.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 6.3 | +0.0 | 0.0 | 38.3 | 2.3 | +0.0 | 0.0 | 196.3 |
| SHOOTS FROM THE BEST SPOT | 3.3 | +78.0 | 65.3 | 0.0 | 1.3 | +26.8 | 0.0 | 392.7 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -14.3 | 28.3 | 0.0 |
| SHOT RISK POINTS | 21.7 | -115.9 | 0.0 | 54.7 | 48.3 | +686.9 | 0.0 | 219.3 |
| SHOTS AFTER THE MOVES | 1.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 5.0 | +290.0 | 0.0 | 0.0 | 11.0 | +158.8 | 0.0 | 196.3 |
| SPELL SETS UP CHARGE | 1.0 | +172.9 | 0.0 | 31.7 | - | - | - | - |
| SPELL WORTH | 2.3 | +34.8 | 392.7 | 0.0 | - | - | - | - |
| SPELLS IN THE FIGHT | 1.0 | -28.8 | 41.0 | 17.3 | 0.3 | +0.5 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 8.3 | +0.0 | 0.0 | 38.3 | 8.7 | +0.0 | 0.0 | 73.7 |
| STAND AND SHOOT | 0.3 | -2.4 | 41.0 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 392.7 |
| STANDS STILL | 22.0 | +0.0 | 1243.3 | 10.0 | 24.0 | +0.0 | 133.3 | 571.0 |
| STAY WORTH | 6.3 | +31.6 | 0.0 | 0.0 | 12.0 | +44.1 | 123.3 | 41.0 |
| SUPPORT ADDS | 9.0 | +1005.7 | 0.0 | 37.3 | 1.3 | +214.9 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 9.0 | +1005.7 | 0.0 | 37.3 | 1.3 | +214.9 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +2.6 | 0.0 | 32.7 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -22.2 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 17.3 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 17.3 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 32.7 | +0.0 | 0.0 | 150.7 | 42.0 | +0.0 | 0.0 | 302.7 |
| TIED UP BY THE SUM | - | - | - | - | 1.3 | +157.0 | 56.3 | 0.0 |
| TIME ON OUR SIDE | 19.7 | +506.1 | 0.0 | 0.0 | 13.7 | +151.7 | 0.0 | 47.7 |
| WAITS AGAIN | 2.7 | +0.0 | 0.0 | 113.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | 0.3 | -14.1 | 0.0 | 17.3 | - | - | - | - |
| WHO HITS BACK | 0.3 | +21.6 | 0.0 | 0.0 | 0.7 | +53.2 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 1.3 | -542.8 | 0.0 | 0.0 | 4.0 | -393.1 | 0.0 | 82.0 |
| WOUNDS ON THE RANKS | 2.7 | +79.3 | 0.0 | 0.0 | 0.7 | +13.5 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p85

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 137 | 137 | 85 | 28.33 | +1815 | +21.4 |
| HIS SHOT LIST | 213 | 209 | 79 | 26.33 | +1656 | +21.0 |
| HOLDER ASSIGNMENT | 80 | 80 | 72 | 24.00 | +3514 | +48.8 |
| HIS SHOTS BY HIS RUN | 218 | 211 | 54 | 18.00 | +996 | +18.4 |
| LEGAL CHARGES ONLY | 49 | 49 | 49 | 16.33 | +0 | +0.0 |
| SHOT RISK POINTS | 210 | 206 | 48 | 16.00 | +1996 | +41.6 |
| THE TABLE AGAIN | 36 | 36 | 28 | 9.33 | +0 | +0.0 |
| DEPLOY BY FIGURES | 43 | 43 | 27 | 9.00 | +313 | +11.6 |
| FIVE ACTION | 463 | 451 | 26 | 8.67 | +984 | +37.8 |
| OFF BEST | 25 | 25 | 25 | 8.33 | -980 | -39.2 |
| QUARTER ODDS | 89 | 85 | 19 | 6.33 | +1627 | +85.6 |
| REDIRECT FOR A FRIEND IN REACH | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| SUPPORT ADDS | 31 | 30 | 17 | 5.67 | +694 | +40.8 |
| SUPPORT WORKED OUT | 31 | 30 | 17 | 5.67 | +694 | +40.8 |
| CASTING BLOCK | 16 | 16 | 14 | 4.67 | +851 | +60.8 |
| MEETS IN TIME | 23 | 23 | 14 | 4.67 | +685 | +48.9 |
| TIME ON OUR SIDE | 100 | 80 | 12 | 4.00 | +39 | +3.2 |
| CHARGE LOSSES | 83 | 82 | 11 | 3.67 | +400 | +36.4 |
| IDLE COST | 65 | 60 | 10 | 3.33 | +51 | +5.1 |
| MISSILES IN THE MOVE | 34 | 25 | 10 | 3.33 | +1089 | +108.9 |
| SHOOTS FROM THE BEST SPOT | 14 | 14 | 10 | 3.33 | +23 | +2.3 |
| MOVE TO CHARGE COMPUTED | 15 | 15 | 9 | 3.00 | +136 | +15.1 |
| PROMISE BY ITS OWN SUM | 29 | 29 | 9 | 3.00 | -437 | -48.5 |
| GOAL WALK | 15 | 15 | 8 | 2.67 | +1248 | +156.0 |
| HARD STAY DROPPED | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 8 | 8 | 8 | 2.67 | +324 | +40.5 |
| MOVE ORDER | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 11 | 11 | 7 | 2.33 | +0 | +0.0 |
| COVER ONCE | 38 | 34 | 7 | 2.33 | +130 | +18.5 |
| SET UP BY THE SET | 17 | 17 | 7 | 2.33 | +967 | +138.2 |
| FOUR ROUNDS | 9 | 9 | 6 | 2.00 | +194 | +32.3 |
| FALLS SHORT | 56 | 49 | 5 | 1.67 | +32 | +6.3 |
| NEXT CHARGE BY LIST | 11 | 11 | 5 | 1.67 | +122 | +24.3 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +153 | +38.4 |
| MAX FOR POSITIONING | 16 | 15 | 4 | 1.33 | +3 | +0.7 |
| SEARCH SPOT | 4 | 4 | 4 | 1.33 | +284 | +71.0 |
| TIED UP BY THE SUM | 4 | 4 | 4 | 1.33 | +47 | +11.7 |
| BEST PRIZE | 3 | 3 | 3 | 1.00 | -260 | -86.6 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | -5 | -1.6 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +490 | +163.5 |
| MARCH OF THE TABLE | 3 | 3 | 3 | 1.00 | -156 | -51.9 |
| ONE OBJECTIVE FORMULA | 42 | 29 | 3 | 1.00 | +76 | +25.2 |
| REDIRECT WEIGHED | 3 | 3 | 3 | 1.00 | +63 | +20.9 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +92 | +30.8 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.67 | +0 | +0.2 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +53 | +26.4 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| EXACT ROUND | 5 | 5 | 2 | 0.67 | +11 | +5.4 |
| FEATURE BUFFS | 37 | 36 | 2 | 0.67 | +11 | +5.3 |
| MARCH CHECK | 3 | 3 | 2 | 0.67 | +10 | +5.1 |
| OVERRUNS AWAY | 4 | 4 | 2 | 0.67 | +3 | +1.6 |
| REDIRECT COUNTER | 15 | 9 | 2 | 0.67 | +80 | +39.8 |
| RISK BY ARC | 8 | 8 | 2 | 0.67 | +50 | +24.9 |
| SHOTS IN THE MOVE | 48 | 32 | 2 | 0.67 | +11 | +5.5 |
| THE ROW IN ITS ORDER | 15 | 2 | 2 | 0.67 | +0 | +0.0 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +10 | +10.3 |
| CATCH ODDS | 1 | 1 | 1 | 0.33 | -6 | -5.8 |
| CHARGE NOW FIRST | 4 | 4 | 1 | 0.33 | -33 | -32.7 |
| HIS CHARGE DENIED | 1 | 1 | 1 | 0.33 | +40 | +39.7 |
| HIS MOVE AND SHOT | 40 | 40 | 1 | 0.33 | +102 | +102.2 |
| HIS TURN DENIED | 1 | 1 | 1 | 0.33 | +150 | +149.9 |
| HONEST WORTH | 6 | 6 | 1 | 0.33 | +8 | +8.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| ONE FIGHT FORMULA | 38 | 28 | 1 | 0.33 | +4 | +3.6 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | -288 | -288.1 |
| RANDOM MOVE BY FIGURES | 5 | 5 | 1 | 0.33 | +7 | +7.4 |
| RESERVE MOVE SPELL | 1 | 1 | 1 | 0.33 | +23 | +22.7 |
| SCOUT WAITS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +8 | +7.7 |
| WHOLE FIGHT DANGER | 16 | 16 | 1 | 0.33 | +79 | +78.6 |
| WOUNDS ON THE RANKS | 10 | 10 | 1 | 0.33 | +9 | +9.4 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| CAST JOB | 3 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 22 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 75 | 72 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 32 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 6 | 6 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 35 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 11 | 11 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 6 | 6 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 57 | 56 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 26 | 25 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 29 | 28 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 14 | 14 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 33 | 32 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 25 | 23 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 7 | 7 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 135 | 132 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 3 | 3 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 10 | 10 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 4 | 4 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MANOEUVRE | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 37 | 26 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 8 | not checked | - | - | - | - |
| MOVE SPELL SPOT | 12 | not checked | - | - | - | - |
| NEARER NOT NEEDED | 14 | 14 | 0 | 0.00 | - | - |
| NEAREST TO GOAL | 1 | 1 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 9 | 9 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 6 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 5 | not checked | - | - | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 208 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 6 | 6 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 2 | 2 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 8 | 8 | 0 | 0.00 | - | - |
| SCOUT SPOT | 1 | 1 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 12 | 12 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 3 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 26 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 11 | 11 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 3 | not checked | - | - | - | - |
| SPELL WORTH | 7 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 51 | 48 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 18 | 17 | 0 | 0.00 | - | - |
| STANDS STILL | 138 | 137 | 0 | 0.00 | - | - |
| STAY WORTH | 55 | 47 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 21 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 12 | not checked | - | - | - | - |
| THE TABLE BINDS | 224 | not checked | - | - | - | - |
| WAITS AGAIN | 12 | 12 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p85

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.00 | 5.00 | 39.0 |
| ARMY TABLE | rule | 2.33 | 1.67 | 31.4 |
| PROMISE BY ITS OWN SUM | rule | 2.00 | 1.00 | 48.5 |
| HOLDER ASSIGNMENT | rule | 0.33 | 2.33 | 64.3 |
| BEST PRIZE | rule | - | 1.00 | 86.6 |
| MARCH OF THE TABLE | rule | 0.33 | 0.67 | 51.9 |
| REDIRECT WEIGHED | rule | - | 0.67 | 16.2 |
| SET UP BY THE SET | rule | - | 0.67 | 15.9 |
| CATCH ODDS | rule | 0.33 | - | 5.8 |
| CHAFF PASSED | rule | - | 0.33 | 4.7 |
| CHARGE NOW FIRST | rule | 0.33 | - | 32.7 |
| PATHS CROSS | rule | - | 0.33 | 288.1 |
| RULE SWITCHED OFF | gate | - | 0.33 | 44.3 |

### Plans: gs3-83c8646-p85

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.3 | 0% | 18 | 0 | 0% |
| Mine | move | 23.3 | 94% | 2310 | 0 | 0% |
| Mine | shoot | 5.7 | 47% | 1284 | 793 | 62% |
| Mine | support | 1.7 | 60% | 3 | 0 | 0% |
| Opponent | charge | 1.7 | 40% | 301 | 56 | 19% |
| Opponent | move | 33.0 | 95% | 1615 | 0 | 0% |
| Opponent | shoot | 3.7 | 73% | 127 | 103 | 81% |

### Battle groups: gs3-83c8646-p85

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.3 | 62% | 38% | 0% | - | 25% | 0% | 0% | 50% | 25% |
| Opponent | REDIRECT COUNTER | 0.7 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p85

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 3 | 0 (3) | 0 | 0 | 21 | 100% | - | 0 (1) | 0 (2) | - | 0 (3) | - |
| Mine | Character | 16 | 25 (16) | 25 | 0 | 3 | 25% | 1.8 | 0 (3) | 0 (6) | 59 (6) | 34 (10) | 0 (5) |
| Mine | Clean-up | 3 | 79 (3) | 79 | 0 | 33 | 33% | 5.5 | 79 (3) | - | - | 237 (1) | 0 (2) |
| Mine | Fast Hammer | 2 | 0 (2) | 0 | 0 | 100 | 0% | 2.5 | - | - | 0 (2) | 0 (1) | 0 (1) |
| Mine | Hammer | 7 | 27 (7) | 0 | 27 | 0 | 57% | 2.7 | 0 (2) | 40 (2) | 33 (3) | 36 (4) | 15 (3) |
| Mine | Holder | 3 | 0 (3) | 0 | 0 | 35 | 33% | 5.0 | - | 0 (1) | 0 (1) | 0 (2) | - |
| Mine | Shooter | 4 | 208 (4) | 0 | 208 | 0 | 0% | 2.5 | - | 369 (2) | 46 (2) | 277 (3) | 0 (1) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 3.0 | - | 0 (2) | - | 0 (2) | - |
| Opponent | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Character | 7 | 9 (7) | 9 | 0 | 20 | 29% | 1.8 | 10 (5) | 0 (2) | - | 13 (5) | 0 (2) |
| Opponent | Clean-up | 2 | 146 (2) | 0 | 146 | 50 | 0% | 2.0 | - | 146 (2) | - | 146 (2) | - |
| Opponent | Fast Hammer | 14 | 21 (14) | 2 | 19 | 16 | 50% | 3.4 | 0 (2) | 22 (9) | 31 (3) | 15 (11) | 49 (3) |
| Opponent | Hammer | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Opponent | Holder | 1 | 112 (1) | 0 | 112 | 0 | 100% | - | - | 112 (1) | - | - | 112 (1) |
| Opponent | Shooter | 2 | 8 (2) | 8 | 0 | 0 | 0% | 1.5 | - | 17 (1) | 0 (1) | 0 (1) | 17 (1) |

### Charged fights: gs3-83c8646-p85

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 229 | 41 | 0.7 | 1.0 | 62 | 26 | +36 | 0 of 2 | 1 of 2 | - | +36 |
| Opponent | High Elf Realms | 2 | 15 | 127 | 3.0 | 1.0 | 42 | 24 | +18 | 2 of 6 | 4 of 6 | - | +18 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 10 | 85 | 2.0 | 1.0 | 42 | 24 | +18 | 2 of 6 | 4 of 6 | - | +18 |

### Effective charges: gs3-83c8646-p85

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 2 (net +36) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | High Elf Realms | 6 | 1 (net +0) | 0 | 0 | 0 | 2 (net +84) | 1 (net +0) | 2 | 0% (0 of 4) |

### Charged fights, damage counted: gs3-83c8646-p85

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 52 | 137 | +36 | 62 | 26 | +36 | +68.3 |
| Mine | All fights | 2 | 52 | 137 | +36 | 62 | 26 | +36 | +68.3 |
| Opponent | Long shot (under 50%) | 1 | 500 | 272 | +0 | 0 | 250 | -250 | -50.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 143 | 77 | +0 | 15 | 0 | +15 | +10.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 489 | 84 | +84 | 84 | 0 | +84 | +17.3 |
| Opponent | No odds | 2 | 316 | 178 | -29 | 71 | 119 | -48 | -15.3 |
| Opponent | All fights | 6 | 376 | 146 | +18 | 54 | 81 | -27 | -7.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p85 | move | 26 | 4 (15%) | 1 (4%) | 1 (4%) | 21 (81%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130 |
| Opal Amulet | Opponent | L0114, L0214 |
| Ring of Doom | Mine | L0214 |

# Doctrine scorecard: gs3-83c8646-p30

### Scorecard: gs3-83c8646-p30

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0922 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 420 |
| L0922 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L1013 | 5 | 1 | Mine | yes | - | 2 | 3 | 1 | 0 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | yes | - | - | 0 | 3 | 0 | 0 | 0 | 70 |
| L1030 | 4 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1030 | 4 | 1 | Opponent | no | 2 | 5 | 0 | 1 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 0.0 | 2.0 | 1.7 | 0.7 | 0.0 | 0.0 | 0.0 | 360.0 |
| **Average** | | | Opponent | 33% | 1.0 | 3.5 | 0.7 | 2.3 | 0.3 | 0.0 | 0.0 | 23.3 |

### KPIs: gs3-83c8646-p30

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 14% (2 of 14) | 0% (0 of 17) | 6% (2 of 31) |
| Winner chose to follow up after the loser gave ground |  | 50% (1 of 2); on the table 50% | 100% (4 of 4); on the table 100% | 83% (5 of 6); on the table 83% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 67% (2 of 3); on the table 67% | - | 67% (2 of 3); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 60% (3 of 5); on the table 60% | 100% (4 of 4); on the table 100% | 78% (7 of 9); on the table 78% |
| Magic missiles tried each own turn | 50%+ | 35% (23 of 66) | 33% (2 of 6) | 35% (25 of 72) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 47% (23 of 49) | 67% (2 of 3) | 48% (25 of 52) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 59% (3550 of 5997) | 46% (2756 of 6000) | 53% (6306 of 11997) |
|   infantry points that never fought | lower | 82% (863 of 1052) | 81% (1056 of 1299) | 82% (1919 of 2351) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 66% (21 of 32) | 68% (13 of 19) | 67% (34 of 51) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 4.0 uses a game | 100% (1 of 1); 2.0 uses a game | 100% (5 of 5); 3.0 uses a game |
| Bound items with another spell used |  | 0% (0 of 2); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 4); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (1 of 2); 0.3 uses a game | 100% (1 of 1); 0.3 uses a game | 67% (2 of 3); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 57% (3298 of 5832) | 71% (3481 of 4916) | 63% (6779 of 10748) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.3 (23%) | 0.3 (25%) | 3.7 (23%) |
| MARCHED: its unit marched | 5.3 (37%) | 0.0 (0%) | 5.3 (34%) |
| IN COMBAT: engaged in combat | 4.3 (30%) | 0.0 (0%) | 4.3 (28%) |
| FLEEING: fleeing | 0.0 (0%) | 1.0 (75%) | 1.0 (6%) |
| GONE: slain | 1.3 (9%) | 0.0 (0%) | 1.3 (9%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.0 | 6.7 | 1.0 | 8.3 | 1.0 | 2.3 |
| not cast | 1.0 | 3.0 | 1.0 | 15.7 | 5.0 | 21.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (11%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.0 (100%) | 0.0 (0%) | 3.7 (23%) | 1.7 (33%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 5.3 (34%) | 1.7 (33%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.3 (28%) | 1.0 (20%) | 0.0 (0%) |
| FLEEING: fleeing | 1.0 (100%) | 0.0 (0%) | 1.0 (100%) | 1.0 (6%) | 0.0 (0%) | 1.7 (8%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (9%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (13%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.7 (82%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.0 a game | 0.5 a game |
| stood (cast and not dispelled) | - | 67% (2 of 3) | 67% (2 of 3) |
| the unit moved after it | - | 50% (1 of 2) | 50% (1 of 2) |
| it charged on its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| the enemy charged it first | - | 50% (1 of 2) | 50% (1 of 2) |
| it fought by the end of its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 2) | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | - | 50% (1 of 2) | 50% (1 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 78% (62 of 80) | 61% (43 of 70) | 70% (105 of 150) |
|   cavalry | - | 86% (6 of 7) | 86% (6 of 7) |
|   character | 100% (5 of 5) | 25% (3 of 12) | 47% (8 of 17) |
|   chariot | 80% (12 of 15) | 33% (2 of 6) | 67% (14 of 21) |
|   infantry | 64% (16 of 25) | 71% (29 of 41) | 68% (45 of 66) |
|   monster | 75% (3 of 4) | - | 75% (3 of 4) |
|   war machine | 84% (26 of 31) | 75% (3 of 4) | 83% (29 of 35) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.7 (11%) | 0.3 (4%) | 1.0 (7%) |
| CHARGED: it charged | 0.0 (0%) | 1.3 (15%) | 1.3 (9%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.3 (4%) | 0.3 (2%) |
| NO TARGET IN RANGE | 2.0 (33%) | 6.3 (70%) | 8.3 (56%) |
| ONLY IN COMBAT: the only targets were in combat | 1.3 (22%) | 0.0 (0%) | 1.3 (9%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (11%) | 0.7 (7%) | 1.3 (9%) |
| SHELTERED: the target was sheltered | 0.3 (6%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR | 1.0 (17%) | 0.0 (0%) | 1.0 (7%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.7 | 1.7 | 64% | 5.7 pts | 21 pts |
| character | 4.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 4.7 | 1.7 | 79% | 11.4 pts | 53 pts |
| infantry | 18.7 | 9.0 | 66% | 13.5 pts | 252 pts |
| monster | 2.0 | 0.3 | 83% | 8.0 pts | 16 pts |
| war machine | 9.7 | 8.7 | 55% | 35.9 pts | 347 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 1.7 | 2.3 |
| Charges that made contact a game | 3.0 | 1.0 | 2.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.50 declared, 1.50 contact (6 units) | 0.00 declared, 0.00 contact (1 units) | 1.29 declared, 1.29 contact (7 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.00 declared, 0.00 contact (16 units) | 0.21 declared, 0.12 contact (24 units) | 0.12 declared, 0.07 contact (40 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 71% (5 of 7) | - | - | 71% (5 of 7) |
| Character in a unit | 100% (4 of 4) | - | - | 100% (4 of 4) |
| Character on its own | - | 50% (4 of 8) | 50% (3 of 6) | 50% (7 of 14) |
| Chariot | 50% (1 of 2) | 100% (1 of 1) | - | 67% (2 of 3) |
| Infantry | 30% (3 of 10) | 100% (2 of 2) | - | 42% (5 of 12) |
| Monster | 100% (2 of 2) | 100% (1 of 1) | - | 100% (3 of 3) |
| Monstrous | - | 100% (1 of 1) | - | 100% (1 of 1) |
| War Machines | 100% (7 of 7) | - | - | 100% (7 of 7) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 1 | 0% (0 of 1); on the table 0% | 58% (7 of 12) | 68% | 83% (10 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 2 | 75% (3 of 4); on the table 75% | 30% (16 of 54) | 55% | 55% (11 of 20) | 100% (4 of 4); 6.0 uses a game | 0% (0 of 2); 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| High Elf Realms | 1 | 100% (1 of 1); on the table 100% | 33% (2 of 6) | 47% | 62% (5 of 8) | 100% (1 of 1); 6.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (3 of 3); on the table 100% | - | 58% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | - | - | 33% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p30, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (1) | 62% (5) | 60% (6) |
| ...free all their last turn and able to turn (per game) | 0.33 | 1.67 | 2.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.67 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p30

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 78% (7 of 9) | 40% (2 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 33% (16 of 49) | 62% (10 of 16) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 80% (4 of 5) | - |
| Strategy | Joined characters whose unit fought | 33% (2 of 6) | 0% (0 of 2) |
| Strategy | Lone characters that fought | 86% (6 of 7) | 88% (7 of 8) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 0.7 | 2.3 |
| Movement | Points that never moved of their own | 360.0 | 23.3 |
| Movement | Fights charged into per game | 2.7 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 8, net +202 | 1 of 3, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 8 | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 8, net +122 | 0 of 3 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 8, net +235 | 1 of 3, net +265 |
| Shooting | Shots by shooting units (incl. breath weapons) | 12.7 | 16.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 66% (25 of 38) | 59% (29 of 49) |
| Shooting | Points destroyed by shooting units | 183.7 | 130.7 |
| Shooting | War machine shots | 8.7 | 1.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 81% (21 of 26) | 100% (3 of 3) |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 5.3 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 50% (8 of 16) | 100% (2 of 2) |
| Magic | Wounds caused by magic missiles | 9.0 | 1.0 |
| Magic | Wounds caused by other spells | 3.3 | - |
| Magic | Points destroyed by magic (all spells) | 171.3 | 55.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 1.7 / 1.3 / 0.3 | 2.3 / 1.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 234.0 | 156.7 |
| Combat | Points run down | 214.3 | 0.0 |
| Combat | Net points per charged fight, damage counted | +199 | -89 |
| Combat | Net per 100 charger points, damage counted | +59.3 | -28.4 |
| Combat | First round won (charged fights) | 88% | 33% |
| Combat | Net points per charged fight | +219 | +88 |
| Combat | Net points per supported fight / lone fight | +173 / +225 | - / +88 |
| Combat | Charged fights on a top-3 enemy unit | 4 of 8 | 2 of 3 |
| Game | Points lost | 384.0 | 1009.0 |
| Game | VP from objectives | 840.0 | 483.3 |
| Game | Lone holders (player turns) | 0.0 | 1.0 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +1067 VP
- The side that went first won 2 of 2 games with a winner
- Points traded per game (both sides' losses): 1393
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p30

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +105.3 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH WITH FRIENDS | 0.3 | +28.9 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 15.3 | +71.8 | 0.0 | 0.0 | 29.7 | +412.5 | 0.0 | 740.3 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +1.0 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 4.0 | +0.0 | 0.0 | 151.7 | - | - | - | - |
| ASSAILMENT BY POINTS | 0.3 | +2.8 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 8.7 | +161.1 | 639.0 | 248.3 | 1.0 | +0.0 | 0.0 | 23.3 |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.3 | +0.0 | 57.7 | 0.0 | - | - | - | - |
| CAST JOB | 4.7 | +122.0 | 130.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | - | - | - | - | 0.7 | +0.0 | 0.0 | 133.3 |
| CHALLENGE BY POINTS | - | - | - | - | 0.7 | +41.8 | 0.0 | 191.0 |
| CHARACTER GUNS | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LIST READ AGAIN | - | - | - | - | 0.3 | +94.6 | 0.0 | 159.7 |
| CHARGE LOSSES | 10.3 | -462.6 | 0.0 | 0.0 | 31.0 | -1888.2 | 0.0 | 1166.0 |
| CHARGE NOW FIRST | 4.7 | +0.0 | 453.7 | 68.3 | 0.7 | +0.0 | 0.0 | 159.7 |
| CLOSES ON WHAT IT BEATS | 10.3 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 130.3 |
| COMBAT PIVOT | 1.0 | +0.0 | 0.0 | 156.7 | - | - | - | - |
| CONVEYANCE SEARCH | - | - | - | - | 1.0 | +223.6 | 249.0 | 133.3 |
| COVER ONCE | 9.3 | -422.4 | 0.0 | 130.7 | 9.7 | -925.5 | 0.0 | 196.3 |
| DEFENSIVE ARMY | 0.7 | +0.0 | 48.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -16.1 | 0.0 | 159.7 |
| DEPLOY BY FIGURES | 7.7 | -128.5 | 0.0 | 0.0 | 7.3 | +67.2 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -3.3 | 0.0 | 0.0 |
| EXACT ROUND | 2.0 | +55.8 | 390.7 | 68.3 | 1.0 | +4.7 | 0.0 | 192.3 |
| FALL BACK GOOD ORDER | 2.3 | +13.6 | 477.0 | 0.0 | 1.3 | +9.0 | 0.0 | 159.7 |
| FALLS SHORT | - | - | - | - | 22.0 | +186.4 | 0.0 | 522.0 |
| FEATURE BUFFS | 0.7 | +4.2 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 2.0 | +16.2 | 320.3 | 68.3 | 0.3 | +8.1 | 0.0 | 0.0 |
| FIVE ACTION | 95.0 | +6690.4 | 2621.0 | 1114.3 | 88.3 | +4426.1 | 1169.3 | 1611.7 |
| FLANK NOT WEIGHED | 5.7 | +0.0 | 0.0 | 151.3 | 6.3 | +0.0 | 0.0 | 313.0 |
| FOLLOW UP WEIGHED | - | - | - | - | 1.0 | +373.0 | 0.0 | 0.0 |
| FOOT FIRST | - | - | - | - | 29.0 | +0.0 | 0.0 | 362.3 |
| FOUR ROUNDS | 3.0 | +379.5 | 572.0 | 68.3 | 1.7 | +164.2 | 0.0 | 192.3 |
| FREED FROM HIS FIGHT | 4.0 | +0.0 | 0.0 | 55.0 | 1.7 | +0.0 | 0.0 | 227.0 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -31.2 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 1.7 | -131.0 | 0.0 | 65.0 |
| GIVES UP | - | - | - | - | 0.3 | -1.0 | 0.0 | 0.0 |
| GOAL ON TIME | - | - | - | - | 0.7 | +87.4 | 0.0 | 0.0 |
| GOAL WALK | 7.0 | +334.3 | 0.0 | 136.7 | 13.0 | +1604.0 | 0.0 | 162.0 |
| GUN FIGURES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| GUN MASK | 1.7 | +81.1 | 0.0 | 0.0 | 0.7 | +15.7 | 0.0 | 0.0 |
| HARD STAY DROPPED | 2.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 264.0 |
| HIS CHARGE BY HIS RUN | 5.3 | +0.0 | 0.0 | 0.0 | 18.3 | +0.0 | 0.0 | 672.3 |
| HIS CHARGE DENIED | 1.0 | +53.8 | 115.3 | 68.3 | 0.7 | +59.8 | 0.0 | 192.3 |
| HIS CHARGE LIST | 5.0 | +0.0 | 0.0 | 0.0 | 10.0 | +0.0 | 0.0 | 427.3 |
| HIS LEGAL MOVES | 4.7 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 1.7 | -22.2 | 0.0 | 0.0 | 11.0 | -293.9 | 0.0 | 367.3 |
| HIS ONE QUARTER | 5.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 190.0 |
| HIS OWN BEST MOVE | 6.0 | +0.0 | 0.0 | 0.0 | 9.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 32.0 | +1000.3 | 0.0 | 191.7 | 64.3 | +3876.3 | 0.0 | 1372.7 |
| HIS SHOTS BY HIS RUN | 31.3 | +579.1 | 0.0 | 0.0 | 54.3 | +1315.9 | 0.0 | 1126.7 |
| HIS TURN DENIED | - | - | - | - | 1.0 | +18.8 | 0.0 | 0.0 |
| HOLD ODDS | 12.3 | +0.0 | 0.0 | 0.0 | 8.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 7.0 | +687.4 | 0.0 | 0.0 | 5.3 | +551.2 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.0 | -97.8 | 572.0 | 68.3 | 1.0 | -44.0 | 0.0 | 159.7 |
| HUNT IN PAIRS | - | - | - | - | 2.7 | +107.4 | 0.0 | 160.0 |
| IDLE COST | - | - | - | - | 16.0 | -337.2 | 0.0 | 517.7 |
| JOINT CHARGE NOW | 0.3 | -36.7 | 57.7 | 0.0 | 1.0 | +66.7 | 0.0 | 192.3 |
| JOINT ON THE TABLE | - | - | - | - | 0.3 | +72.7 | 0.0 | 32.7 |
| KEEP FALLS | 0.3 | +6.6 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | 1.3 | +28.4 | 0.0 | 0.0 | 1.3 | +65.6 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 0.3 | +0.0 | 0.0 | 88.3 | 4.0 | +0.0 | 342.3 | 24.0 |
| LONE WIZARD KEPT IN | 0.7 | +10.0 | 0.0 | 0.0 | 0.7 | +48.3 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 2.3 | -2.4 | 433.0 | 68.3 | 1.0 | +2.6 | 0.0 | 192.3 |
| MAKE SURE TOGETHER | 0.7 | +6.2 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 1.7 | +145.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.0 | +54.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 1.7 | +130.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.7 | -134.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 6.0 | +102.7 | 0.0 | 0.0 | 3.3 | +142.1 | 0.0 | 65.0 |
| MEETS IN TIME | 2.7 | +167.4 | 0.0 | 0.0 | 2.0 | +137.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 12.7 | +313.4 | 0.0 | 0.0 | 2.3 | +31.6 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 15.3 | +223.1 | 0.0 | 68.3 | 2.7 | +20.3 | 0.0 | 133.3 |
| MOVE ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 50.3 |
| MOVE SPELL SPOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 133.3 |
| MOVE TO CHARGE COMPUTED | 3.3 | +247.0 | 0.0 | 0.0 | 4.7 | +382.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 2.0 | +94.0 | 0.0 | 0.0 | 1.3 | +79.5 | 0.0 | 50.3 |
| NEAREST TO GOAL | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 3.3 | +248.3 | 0.0 | 0.0 | 3.0 | +308.1 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.7 | -183.9 | 477.0 | 68.3 | 1.3 | -140.8 | 0.0 | 192.3 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 3.7 | -216.5 | 0.0 | 55.0 | 6.3 | -280.1 | 0.0 | 222.7 |
| OGRE LOADER SECOND SHOT | 3.0 | +7.1 | 0.0 | 55.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.7 | +0.0 | 0.0 | 66.0 |
| ONE FIGHT FORMULA | 6.0 | -140.7 | 0.0 | 0.0 | 5.7 | -137.1 | 0.0 | 131.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +9.7 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 4.0 | +60.8 | 0.0 | 0.0 | 1.7 | -3.7 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.3 | -16.1 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 1.0 | +8.4 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | 0.3 | +29.3 | 23.3 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.7 | +6.9 | 156.7 | 0.0 | 0.3 | +1.8 | 0.0 | 159.7 |
| PIVOT GUARDS FLANK | 0.7 | -5.9 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 41.7 | +1098.0 | 651.7 | 514.7 | 39.3 | +532.7 | 315.3 | 1575.7 |
| PROMISE BY ITS OWN SUM | 5.7 | -187.7 | 0.0 | 0.0 | 8.7 | -141.5 | 0.0 | 132.0 |
| PROMISE IN STEPS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 2.0 | -19.2 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.7 | -23.6 | 0.0 | 65.0 |
| QUARTER ODDS | 26.0 | +3372.6 | 1594.0 | 0.0 | 23.0 | +1956.4 | 0.0 | 382.3 |
| REDIRECT COUNTER | - | - | - | - | 0.7 | +38.2 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.0 | -43.4 | 0.0 | 0.0 | 0.7 | -17.8 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 0.3 | +0.6 | 0.0 | 0.0 | 0.7 | +43.0 | 0.0 | 0.0 |
| RISK BY ARC | 2.3 | +8.9 | 548.7 | 0.0 | 1.3 | -39.6 | 0.0 | 192.3 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.0 | -24.7 | 0.0 | 159.7 |
| RUN DOWN | 2.7 | -18.8 | 477.0 | 68.3 | 1.0 | -10.5 | 0.0 | 159.7 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +2.2 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | - | - | - | - | 0.7 | +2.8 | 0.0 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 3.0 | -155.3 | 0.0 | 65.0 |
| SET UP BY THE SET | - | - | - | - | 5.0 | +274.2 | 0.0 | 130.3 |
| SET UP TOGETHER | 0.7 | +6.2 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.3 | +0.7 | 0.0 | 0.0 | 0.3 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 15.3 | +0.0 | 0.0 | 399.7 | 5.7 | +0.0 | 0.0 | 23.3 |
| SHOOTS FROM THE BEST SPOT | 1.7 | +71.9 | 0.0 | 0.0 | 2.7 | +81.4 | 302.7 | 0.0 |
| SHOT OR CHARGE | 1.0 | -118.7 | 95.0 | 110.0 | - | - | - | - |
| SHOT RISK POINTS | 14.0 | -168.6 | 0.0 | 55.0 | 43.0 | -415.8 | 0.0 | 1009.3 |
| SHOTS AFTER THE MOVES | 5.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 20.7 | +646.7 | 0.0 | 399.7 | 16.0 | +574.6 | 0.0 | 70.7 |
| SPELL WORTH | - | - | - | - | 1.0 | +35.5 | 133.3 | 133.3 |
| SPELLS IN THE FIGHT | 1.0 | +16.1 | 234.0 | 0.0 | 0.7 | -9.0 | 0.0 | 192.3 |
| SPOT AS THE GAME MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 365.3 |
| STAND AND SHOOT | 0.7 | -7.3 | 249.0 | 0.0 | 0.3 | -2.3 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 3.3 | +0.0 | 151.3 | 0.0 |
| STANDS STILL | 47.7 | +0.0 | 2049.0 | 909.3 | 30.0 | +0.0 | 1169.3 | 321.7 |
| STAY WORTH | 32.3 | -221.4 | 959.3 | 580.0 | 17.0 | +227.3 | 756.7 | 94.0 |
| SUPPORT ADDS | 2.7 | +66.7 | 0.0 | 0.0 | 7.7 | +250.6 | 0.0 | 100.7 |
| SUPPORT NARROWED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 2.7 | +66.7 | 0.0 | 0.0 | 7.7 | +250.6 | 0.0 | 100.7 |
| SURE REACH TOGETHER | 1.7 | +11.4 | 0.0 | 0.0 | 0.3 | +8.5 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +6.2 | 0.0 | 133.3 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 3.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 232.0 |
| THE ROW KEEPS ITS WAY | 3.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 50.3 |
| THE STEP BACK IS MADE | 2.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 44.0 | +0.0 | 0.0 | 468.0 | 43.0 | +0.0 | 0.0 | 686.3 |
| TIED UP BY THE SUM | 1.0 | +105.0 | 104.3 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 37.3 | +470.0 | 178.0 | 522.3 | - | - | - | - |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 1.7 | +0.0 | 95.0 | 0.0 | - | - | - | - |
| WHO GETS IN | - | - | - | - | 0.7 | +71.4 | 0.0 | 192.3 |
| WHO HITS BACK | 0.3 | +13.5 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 2.0 | -271.6 | 0.0 | 0.0 | 6.0 | -734.4 | 0.0 | 668.7 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +6.3 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 1.7 | +30.3 | 0.0 | 0.0 | - | - | - | - |

### Rule changes: gs3-83c8646-p30

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 135 | 135 | 94 | 31.33 | +2432 | +25.9 |
| HIS SHOT LIST | 289 | 273 | 70 | 23.33 | +1283 | +18.3 |
| HIS SHOTS BY HIS RUN | 257 | 240 | 43 | 14.33 | +933 | +21.7 |
| HOLDER ASSIGNMENT | 37 | 37 | 34 | 11.33 | +1658 | +48.8 |
| OFF BEST | 30 | 30 | 30 | 10.00 | -1490 | -49.7 |
| DEPLOY BY FIGURES | 45 | 45 | 28 | 9.33 | +346 | +12.3 |
| FIVE ACTION | 550 | 527 | 28 | 9.33 | +1742 | +62.2 |
| THE TABLE AGAIN | 36 | 36 | 24 | 8.00 | +0 | +0.0 |
| QUARTER ODDS | 147 | 147 | 22 | 7.33 | +2239 | +101.8 |
| PROMISE BY ITS OWN SUM | 43 | 43 | 19 | 6.33 | -987 | -52.0 |
| GOAL WALK | 60 | 58 | 18 | 6.00 | +1742 | +96.8 |
| TIME ON OUR SIDE | 112 | 98 | 17 | 5.67 | +64 | +3.7 |
| SHOT RISK POINTS | 171 | 161 | 16 | 5.33 | +692 | +43.2 |
| MOVE TO CHARGE COMPUTED | 24 | 18 | 14 | 4.67 | +543 | +38.8 |
| HARD STAY DROPPED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 19 | 18 | 12 | 4.00 | +610 | +50.9 |
| CHARGE LOSSES | 124 | 113 | 10 | 3.33 | +525 | +52.5 |
| OGRE LOADER SECOND SHOT | 9 | 9 | 9 | 3.00 | +21 | +2.4 |
| ADVANCE LANE KEPT | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| LANE BY FIGURES | 8 | 8 | 8 | 2.67 | +282 | +35.2 |
| CAST JOB | 14 | 14 | 7 | 2.33 | +39 | +5.5 |
| IDLE COST | 48 | 35 | 7 | 2.33 | +168 | +24.0 |
| MEETS IN TIME | 14 | 14 | 7 | 2.33 | +90 | +12.9 |
| SHOOTS FROM THE BEST SPOT | 13 | 13 | 7 | 2.33 | +180 | +25.8 |
| CANNON SIGHT KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| COVER ONCE | 57 | 36 | 6 | 2.00 | +82 | +13.7 |
| FOUR ROUNDS | 14 | 14 | 6 | 2.00 | +409 | +68.2 |
| MAX FOR POSITIONING | 28 | 23 | 6 | 2.00 | +123 | +20.5 |
| PROMISE KNOWS THE FIGHT | 8 | 6 | 6 | 2.00 | -58 | -9.6 |
| CHARGE NOW FIRST | 16 | 16 | 5 | 1.67 | -173 | -34.6 |
| MARCH BY THE SUM | 5 | 5 | 5 | 1.67 | +437 | +87.4 |
| MARCH OF THE TABLE | 5 | 5 | 5 | 1.67 | -391 | -78.2 |
| SHOTS IN THE MOVE | 110 | 75 | 5 | 1.67 | +269 | +53.8 |
| SUPPORT ADDS | 31 | 29 | 5 | 1.67 | +127 | +25.4 |
| SUPPORT WORKED OUT | 31 | 29 | 5 | 1.67 | +127 | +25.4 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | +90 | +22.5 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +175 | +43.8 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FALLS SHORT | 66 | 51 | 3 | 1.00 | +20 | +6.8 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +1119 | +373.0 |
| GUN MASK | 7 | 7 | 3 | 1.00 | +119 | +39.8 |
| MARCH CHECK | 3 | 3 | 3 | 1.00 | +106 | +35.2 |
| MISSILES IN THE MOVE | 45 | 29 | 3 | 1.00 | +68 | +22.8 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +131 | +43.5 |
| THE ROW IN ITS ORDER | 24 | 3 | 3 | 1.00 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 24 | 22 | 3 | 1.00 | +52 | +17.5 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +126 | +62.8 |
| GOAL ON TIME | 2 | 2 | 2 | 0.67 | -8 | -4.2 |
| HIS CHARGE DENIED | 5 | 5 | 2 | 0.67 | +42 | +21.2 |
| HIS MOVE AND SHOT | 38 | 35 | 2 | 0.67 | +12 | +6.2 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| OPENS A LANE | 3 | 2 | 2 | 0.67 | +18 | +9.0 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.67 | -18 | -8.9 |
| SET UP BY THE SET | 15 | 13 | 2 | 0.67 | +160 | +80.2 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +6 | +3.0 |
| SURE REACH TOGETHER | 6 | 6 | 2 | 0.67 | +0 | +0.0 |
| TIED UP BY THE SUM | 3 | 3 | 2 | 0.67 | +87 | +43.6 |
| WHO GETS IN | 2 | 2 | 2 | 0.67 | +214 | +107.1 |
| WOUNDS ON THE RANKS | 5 | 5 | 2 | 0.67 | +3 | +1.5 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +316 | +315.9 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +87 | +86.6 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +8 | +8.4 |
| CANNON PLANNED TARGET | 29 | 29 | 1 | 0.33 | -50 | -50.0 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +284 | +283.7 |
| EXACT ROUND | 9 | 9 | 1 | 0.33 | +6 | +5.8 |
| FALL BACK GOOD ORDER | 11 | 11 | 1 | 0.33 | +33 | +32.7 |
| FIGHT TO THE END | 7 | 7 | 1 | 0.33 | +24 | +24.4 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.33 | +218 | +218.0 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +28 | +27.6 |
| NEARER NOT NEEDED | 10 | 10 | 1 | 0.33 | +23 | +23.1 |
| ONE FIGHT FORMULA | 35 | 20 | 1 | 0.33 | +16 | +16.2 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -48 | -48.3 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +82 | +81.5 |
| REDIRECT COUNTER | 2 | 2 | 1 | 0.33 | +41 | +40.8 |
| REDIRECT FOR A FRIEND IN REACH | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| RISK BY ARC | 11 | 11 | 1 | 0.33 | +24 | +24.4 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +8 | +8.3 |
| SET CREDITED ONCE | 9 | 7 | 1 | 0.33 | +89 | +88.8 |
| SHOTS AFTER THE MOVES | 22 | 22 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +18 | +18.5 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +22 | +22.1 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CHARACTER GUNS | 6 | 6 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 55 | 52 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 36 | not checked | - | - | - | - |
| FOOT FIRST | 87 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 17 | 15 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 1 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 15 | 11 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 71 | 68 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 45 | 41 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 31 | 28 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 23 | 23 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 45 | 38 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 3 | 3 | 0 | 0.00 | - | - |
| HOLD ODDS | 63 | 63 | 0 | 0.00 | - | - |
| HONEST WORTH | 12 | 12 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 8 | 7 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 10 | 10 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MANOEUVRE | 4 | 4 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 54 | 38 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 2 | not checked | - | - | - | - |
| NEAREST TO GOAL | 4 | 4 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 12 | 12 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 17 | 9 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 243 | trace | - | - | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 5 | 4 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 11 | 11 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 63 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL WORTH | 3 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 5 | 5 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 34 | 23 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 10 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 233 | 225 | 0 | 0.00 | - | - |
| STAY WORTH | 148 | 126 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 18 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 12 | not checked | - | - | - | - |
| THE TABLE BINDS | 261 | not checked | - | - | - | - |
| WAITS AGAIN | 7 | 7 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 5 | 5 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p30

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.00 | 5.33 | 49.5 |
| PROMISE BY ITS OWN SUM | rule | 2.67 | 3.67 | 52.0 |
| ARMY TABLE | rule | 1.00 | 1.33 | 46.1 |
| PROMISE KNOWS THE FIGHT | rule | 2.00 | - | 9.6 |
| CHARGE NOW FIRST | rule | 1.67 | - | 34.6 |
| MARCH OF THE TABLE | rule | 1.33 | - | 97.8 |
| JOINT CHARGE NOW | rule | 0.33 | 0.67 | 42.7 |
| NO REASON | gate | - | 1.00 | 78.9 |
| GOAL ON TIME | rule | - | 0.67 | 4.2 |
| PIVOT GUARDS FLANK | rule | 0.67 | - | 8.9 |
| RULE SWITCHED OFF | gate | 0.67 | - | 8.3 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 50.0 |
| ONE PROMISE A TARGET | rule | 0.33 | - | 48.3 |
| WHO GETS IN | rule | - | 0.33 | 3.9 |

### Plans: gs3-83c8646-p30

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.7 | 88% | 385 | 460 | 119% |
| Mine | move | 26.0 | 100% | 1578 | 0 | 0% |
| Mine | shoot | 13.0 | 54% | 731 | 638 | 87% |
| Opponent | charge | 1.3 | 25% | 241 | 46 | 19% |
| Opponent | move | 33.3 | 91% | 1767 | 0 | 0% |
| Opponent | shoot | 4.7 | 79% | 402 | 486 | 121% |

### Battle groups: gs3-83c8646-p30

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 0.7 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p30

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 13 | 105 (13) | 105 | 0 | 8 | 23% | 3.1 | 115 (2) | 65 (8) | 160 (3) | 69 (7) | 141 (6) |
| Mine | Fast Hammer | 4 | 79 (4) | 79 | 0 | 0 | 0% | 2.2 | 0 (2) | 355 (1) | 0 (1) | 0 (2) | 159 (2) |
| Mine | Hammer | 4 | 40 (4) | 0 | 40 | 55 | 25% | 2.7 | - | 40 (4) | - | 0 (2) | 90 (2) |
| Mine | Holder | 2 | 70 (2) | 0 | 70 | 0 | 100% | - | 0 (1) | 140 (1) | - | 70 (2) | - |
| Mine | Shooter | 5 | 41 (5) | 22 | 19 | 0 | 0% | 1.4 | 35 (2) | 59 (2) | 0 (1) | 36 (4) | 69 (1) |
| Mine | War machine | 7 | 0 (7) | 0 | 0 | 44 | 0% | 1.0 | 0 (1) | 0 (2) | 0 (4) | 0 (3) | 0 (4) |
| Opponent | Chaff | 4 | 79 (4) | 79 | 0 | 50 | 0% | 2.2 | 0 (1) | 315 (1) | 0 (2) | 79 (4) | - |
| Opponent | Character | 8 | 17 (8) | 17 | 0 | 65 | 0% | 2.5 | 0 (3) | 40 (3) | - | 26 (5) | 0 (1) |
| Opponent | Clean-up | 2 | 0 (2) | 0 | 0 | 50 | 50% | 5.0 | 0 (2) | - | - | 0 (2) | - |
| Opponent | Fast Hammer | 6 | 0 (6) | 0 | 0 | 71 | 67% | 3.5 | 0 (3) | 0 (3) | - | 0 (3) | 0 (3) |
| Opponent | Hammer | 2 | 35 (2) | 0 | 35 | 50 | 0% | 4.0 | - | 35 (2) | - | 52 (1) | 18 (1) |
| Opponent | Holder | 6 | 88 (6) | 0 | 88 | 0 | 50% | 1.0 | 0 (2) | 232 (3) | 0 (1) | 196 (4) | 0 (2) |
| Opponent | Shooter | 2 | 97 (2) | 97 | 0 | 0 | 0% | 1.0 | - | 97 (2) | - | 102 (1) | 93 (1) |
| Opponent | War machine | 2 | 0 (2) | 0 | 0 | 100 | 0% | 1.0 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 1.0 | - | 0 (2) | - | - | 0 (2) |

### Charged fights: gs3-83c8646-p30

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 1 | 267 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Grand Cathay | 2 | 399 | 978 | 4.0 | 1.1 | 244 | 26 | +219 | 4 of 8 | 7 of 8 | +173 | +225 |
| **Mine** | all armies | 3 | 355 | 652 | 2.7 | 1.1 | 244 | 26 | +219 | 4 of 8 | 7 of 8 | +173 | +225 |
| Opponent | High Elf Realms | 1 | 330 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 1 | 227 | 265 | 2.0 | 1.0 | 132 | 0 | +132 | 1 of 2 | 1 of 2 | - | +132 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| **Opponent** | all armies | 3 | 186 | 88 | 1.0 | 1.0 | 88 | 0 | +88 | 2 of 3 | 1 of 3 | - | +88 |

### Effective charges: gs3-83c8646-p30

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 8 | 2 (net +202) | 0 | 0 | 2 (net +316) | 2 (net +122) | 2 (net +235) | 0 | 0% (0 of 8) |
| Opponent | Tomb Kings of Khemri | 2 | 0 | 1 (net +0) | 0 | 0 | 0 | 1 (net +265) | 0 | 0% (0 of 2) |
| Opponent | Warriors of Chaos | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: gs3-83c8646-p30

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 270 | 270 | +202 | 327 | 102 | +225 | +83.3 |
| Mine | 76-89% | 2 | 369 | 266 | +316 | 316 | 53 | +263 | +71.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 270 | 235 | +235 | 235 | 48 | +187 | +69.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 436 | 122 | +122 | 122 | 0 | +122 | +27.8 |
| Mine | All fights | 8 | 336 | 223 | +219 | 250 | 51 | +199 | +59.3 |
| Opponent | Long shot (under 50%) | 1 | 98 | 369 | +0 | 0 | 229 | -229 | -233.6 |
| Opponent | 50-54% | 1 | 431 | 189 | +0 | 26 | 335 | -309 | -71.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 411 | 265 | +265 | 317 | 46 | +271 | +66.0 |
| Opponent | All fights | 3 | 313 | 274 | +88 | 114 | 203 | -89 | -28.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p30 | move | 26 | 4 (15%) | 3 (12%) | 3 (12%) | 19 (73%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Ring of Jet | Mine | L1013, L1030 |
| Standard of the Fell Warrior | Opponent | L1013 |
| Twice-Blessed Armour | Mine | L1013, L1030 |

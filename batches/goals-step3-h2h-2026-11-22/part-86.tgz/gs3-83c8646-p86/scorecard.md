# Doctrine scorecard: gs3-83c8646-p86

### Scorecard: gs3-83c8646-p86

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0230 | 2 | 1 | Mine | - | - | 2 | 4 | 5 | 0 | 0 | 0 | 170 |
| L0230 | 2 | 1 | Opponent | - | - | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | no | 4 | - | 0 | 1 | 0 | 0 | 0 | 340 |
| L0315 | 3 | 1 | Opponent | no | 2 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | - | 0 | 1 | 0 | 0 | 0 | 370 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 4 | 7 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 4.0 | 2.0 | 1.3 | 2.3 | 0.0 | 0.0 | 0.0 | 293.3 |
| **Average** | | | Opponent | 0% | 2.0 | 2.0 | 2.0 | 3.0 | 0.0 | 0.0 | 0.0 | 0.0 |

### KPIs: gs3-83c8646-p86

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 47% (7 of 15) | 0% (0 of 15) | 23% (7 of 30) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 67% (2 of 3); on the table 67% | 100% (1 of 1); on the table 100% | 75% (3 of 4); on the table 75% |
| Winner chose to follow up or pursue (all three) |  | 75% (3 of 4); on the table 75% | 100% (3 of 3); on the table 100% | 86% (6 of 7); on the table 86% |
| Magic missiles tried each own turn | 50%+ | 23% (7 of 30) | - | 23% (7 of 30) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 25% (7 of 28) | - | 25% (7 of 28) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 20% (1 of 5) | 75% (9 of 12) | 59% (10 of 17) |
| Points that never fought | lower | 62% (3679 of 5897) | 51% (3032 of 5999) | 56% (6711 of 11896) |
|   infantry points that never fought | lower | 87% (1251 of 1437) | 53% (365 of 688) | 76% (1616 of 2125) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 82% (18 of 22) | 43% (9 of 21) | 63% (27 of 43) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 1.7 uses a game | 100% (2 of 2); 2.3 uses a game | 100% (4 of 4); 2.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 75% (3 of 4); 1.0 uses a game | 100% (1 of 1); 0.3 uses a game | 80% (4 of 5); 0.7 uses a game |
|   their share of the points of units over 100 pts | lower | 77% (3460 of 4484) | 43% (2379 of 5470) | 59% (5839 of 9954) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 6.3 (83%) | - | 6.3 (83%) |
| MARCHED: its unit marched | 0.7 (9%) | - | 0.7 (9%) |
| GONE: slain | 0.7 (9%) | - | 0.7 (9%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 0.3 | 1.3 | 7.3 | 2.3 | 0.0 |
| not cast | 1.7 | 1.7 | 0.7 | 7.7 | 8.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 6.3 (83%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (9%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.3 (50%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (9%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 1.7 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (100%) | 0.0 (0%) | 0.3 (50%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 8.0 (100%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 5.3 a game | 2.0 a game | 3.7 a game |
| stood (cast and not dispelled) | 75% (12 of 16) | - | 75% (12 of 16) |
| the unit moved after it | 67% (8 of 12) | - | 67% (8 of 12) |
| it charged on its next turn | 0% (0 of 12) | - | 0% (0 of 12) |
| the enemy charged it first | 0% (0 of 12) | - | 0% (0 of 12) |
| it fought by the end of its next turn | 0% (0 of 12) | - | 0% (0 of 12) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 12) | - | 0% (0 of 12) |
| none of these (no charge, no fight, no charge escaped) | 100% (12 of 12) | - | 100% (12 of 12) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 68% (40 of 59) | 27% (10 of 37) | 52% (50 of 96) |
|   character | - | 14% (3 of 21) | 14% (3 of 21) |
|   chariot | 50% (7 of 14) | 25% (1 of 4) | 44% (8 of 18) |
|   infantry | - | 50% (6 of 12) | 50% (6 of 12) |
|   war machine | 73% (33 of 45) | - | 73% (33 of 45) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.0 (16%) | 0.7 (7%) | 1.7 (11%) |
| CHARGED: it charged | 0.0 (0%) | 3.7 (41%) | 3.7 (24%) |
| IN COMBAT: it fought this turn or the last | 1.0 (16%) | 0.0 (0%) | 1.0 (7%) |
| MOVED: a war machine that moved | 1.7 (26%) | 0.0 (0%) | 1.7 (11%) |
| NO TARGET IN RANGE | 0.3 (5%) | 2.0 (22%) | 2.3 (15%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 1.7 (19%) | 1.7 (11%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.3 (37%) | 1.0 (11%) | 3.3 (22%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| character | 1.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 2.7 | 2.7 | 38% | 36.6 pts | 98 pts |
| infantry | 3.0 | 1.0 | 67% | 5.9 pts | 18 pts |
| war machine | 11.3 | 9.7 | 56% | 28.1 pts | 318 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.3 | 4.7 | 3.0 |
| Charges that made contact a game | 0.7 | 3.7 | 2.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | - | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (4 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.21 declared, 0.11 contact (19 units) | 0.61 declared, 0.48 contact (23 units) | 0.43 declared, 0.31 contact (42 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 20% (1 of 5) | - | 100% (1 of 1) | 33% (2 of 6) |
| Character in a unit | 100% (4 of 4) | 50% (2 of 4) | - | 75% (6 of 8) |
| Character on its own | - | - | 40% (2 of 5) | 40% (2 of 5) |
| Chariot | 0% (0 of 1) | 75% (3 of 4) | - | 60% (3 of 5) |
| Infantry | 33% (1 of 3) | 67% (2 of 3) | - | 50% (3 of 6) |
| Monster | 67% (2 of 3) | 100% (1 of 1) | - | 75% (3 of 4) |
| Monstrous | 100% (1 of 1) | - | - | 100% (1 of 1) |
| War Machines | 100% (6 of 6) | 50% (1 of 2) | - | 88% (7 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1 | 67% (2 of 3); on the table 67% | 17% (3 of 18) | 84% | 83% (5 of 6) | 100% (2 of 2); 5.0 uses a game | 0.0 uses a game | 50% (1 of 2); 1.0 uses a game |
| Chaos Dwarfs | 2 | 100% (1 of 1); on the table 100% | 33% (4 of 12) | 52% | 81% (13 of 16) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| High Elf Realms | 1 | 100% (2 of 2); on the table 100% | - | 66% | 43% (3 of 7) | 100% (2 of 2); 7.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | 100% (1 of 1); on the table 100% | - | 43% | 43% (6 of 14) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.5 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p86, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 64% (7) | 50% (1) | 62% (8) |
| ...free all their last turn and able to turn (per game) | 2.00 | 0.33 | 2.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 1.67 | 0.33 | 2.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p86

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 2.3 |
| Strategy | Charge objectives carried out (made contact) | 50% (2 of 4) | 77% (10 of 13) |
| Strategy | Shoot objectives carried out (shot that target) | 67% (24 of 36) | 0% (0 of 3) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 12% (1 of 8) | 100% (2 of 2) |
| Strategy | Lone characters that fought | 50% (2 of 4) | 60% (3 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.3 | 3.0 |
| Movement | Points that never moved of their own | 293.3 | 0.0 |
| Movement | Fights charged into per game | 0.7 | 3.7 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 2, net -52 | 0 of 11 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | 2 of 11, net +42 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 2 | 1 of 11, net +0 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 2 | 5 of 11, net +206 |
| Shooting | Shots by shooting units (incl. breath weapons) | 2.3 | 6.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 71% (5 of 7) | 53% (10 of 19) |
| Shooting | Points destroyed by shooting units | 10.0 | 0.0 |
| Shooting | War machine shots | 11.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 26% (9 of 34) | - |
| Shooting | Points destroyed by war machines | 38.3 | 0.0 |
| Magic | Magic missiles cast | 0.7 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 2) | - |
| Magic | Wounds caused by magic missiles | 3.7 | 1.0 |
| Magic | Points destroyed by magic (all spells) | 32.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 0.3 / 1.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 0.0 | 620.7 |
| Combat | Points run down | 32.7 | 31.7 |
| Combat | Net points per charged fight, damage counted | +14 | +137 |
| Combat | Net per 100 charger points, damage counted | +20.4 | +39.4 |
| Combat | First round won (charged fights) | 50% | 82% |
| Combat | Net points per charged fight | +14 | +158 |
| Combat | Net points per supported fight / lone fight | - / +14 | - / +158 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 2 | 5 of 11 |
| Game | Points lost | 679.3 | 163.7 |
| Game | VP from objectives | 586.7 | 923.3 |
| Game | Lone holders (player turns) | 4.0 | 2.0 |

- Mine won / drew / lost: 0 / 1 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -884 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 843
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: gs3-83c8646-p86

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 12.7 | +597.5 | 0.0 | 241.3 | 14.7 | +347.0 | 0.0 | 112.0 |
| ARTILLERY RE-ROLL WEIGHED | 5.0 | +0.0 | 0.0 | 153.3 | - | - | - | - |
| BEST PRIZE | - | - | - | - | 0.3 | +6.4 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.3 | +0.0 | 38.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 9.7 | +53.0 | 106.7 | 153.3 | - | - | - | - |
| CANNON SIGHT KEPT | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 2.0 | +28.2 | 0.0 | 56.7 | 0.7 | +61.6 | 206.7 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 0.7 | +88.7 | 65.3 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 3.3 | +0.0 | 0.0 | 28.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | -0.1 | 38.3 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +12.4 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LIST READ AGAIN | - | - | - | - | 0.7 | +65.5 | 28.3 | 0.0 |
| CHARGE LOSSES | 9.3 | -501.6 | 0.0 | 270.0 | 14.7 | -506.0 | 0.0 | 65.3 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 26.7 | 17.3 | 3.3 | +0.0 | 653.3 | 38.3 |
| CLOSES ON WHAT IT BEATS | 8.3 | +0.0 | 0.0 | 0.0 | 10.3 | +0.0 | 0.0 | 142.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 103.3 | - | - | - | - |
| CONVEYANCE SEARCH | 3.3 | +168.0 | 0.0 | 28.3 | - | - | - | - |
| COVER ONCE | 9.3 | -314.2 | 0.0 | 177.3 | 5.0 | -182.9 | 0.0 | 32.7 |
| DEPLOY BY FIGURES | 10.0 | -94.4 | 0.0 | 0.0 | 7.0 | +28.2 | 0.0 | 32.7 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -82.6 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +2.6 | 26.7 | 0.0 | 0.3 | +0.2 | 76.7 | 0.0 |
| ENGINEER BY LORE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 1.0 | +3.3 | 73.3 | 0.0 | 4.0 | +16.7 | 578.3 | 38.3 |
| FALL BACK GOOD ORDER | 1.3 | +0.0 | 73.3 | 17.3 | 4.7 | +77.1 | 605.0 | 38.3 |
| FALLS SHORT | 1.3 | +8.3 | 0.0 | 28.3 | 20.3 | +298.2 | 0.0 | 236.3 |
| FEATURE BUFFS | 4.0 | +82.1 | 0.0 | 0.0 | 2.0 | +53.2 | 0.0 | 0.0 |
| FIGHT LIFT | - | - | - | - | 0.3 | +2.0 | 38.3 | 0.0 |
| FIGHT TO THE END | 1.0 | +0.1 | 73.3 | 0.0 | 1.0 | +2.6 | 206.7 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 94.3 | +3210.7 | 352.0 | 1209.3 | 76.3 | +5597.6 | 1198.3 | 477.7 |
| FLANK NOT WEIGHED | 9.3 | +0.0 | 0.0 | 87.0 | 3.3 | +0.0 | 0.0 | 56.0 |
| FOLLOW UP WEIGHED | 0.3 | +17.8 | 0.0 | 0.0 | 0.7 | +162.6 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.3 | +37.0 | 73.3 | 17.3 | 5.0 | +636.9 | 681.7 | 38.3 |
| FREED FROM HIS FIGHT | 5.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FRIEND CHARGES FIRST | 0.3 | -22.7 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 1.3 | -84.8 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.7 | -0.7 | 46.7 | 0.0 | - | - | - | - |
| GOAL WALK | 5.7 | +649.6 | 0.0 | 448.0 | 13.7 | +1225.1 | 0.0 | 96.7 |
| GROUND FLIERS | 0.3 | +8.5 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 2.0 | +9.7 | 10.0 | 310.0 | - | - | - | - |
| HARD STAY DROPPED | 3.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HE REFORMS ONCE FREED | 4.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 8.0 | +0.0 | 0.0 | 270.0 | 6.7 | +0.0 | 0.0 | 65.3 |
| HIS CHARGE DENIED | - | - | - | - | 0.7 | +15.1 | 206.7 | 0.0 |
| HIS CHARGE LIST | 6.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 4.7 | +0.0 | 0.0 | 413.3 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 5.7 | -48.5 | 0.0 | 270.0 | 2.0 | -27.6 | 0.0 | 20.0 |
| HIS ONE QUARTER | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS OWN BEST MOVE | 5.7 | +0.0 | 0.0 | 413.3 | 5.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 8.0 | +0.0 | 0.0 | 206.7 | 11.0 | +0.0 | 0.0 | 277.3 |
| HIS RANDOM MOVER COMES | 2.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 112.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 23.0 | +400.1 | 0.0 | 304.7 | 57.7 | +3054.3 | 0.0 | 243.3 |
| HIS SHOTS BY HIS RUN | 24.7 | +229.5 | 0.0 | 737.3 | 32.3 | +868.6 | 0.0 | 132.0 |
| HIS TURN DENIED | - | - | - | - | 1.0 | +18.3 | 180.0 | 0.0 |
| HOLD ODDS | 22.0 | +0.0 | 0.0 | 0.0 | 21.0 | +0.0 | 0.0 | 65.3 |
| HOLDER ASSIGNMENT | 10.3 | +1061.8 | 0.0 | 0.0 | 11.0 | +1045.9 | 0.0 | 32.7 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.3 | -1.6 | 26.7 | 0.0 | 4.3 | -236.8 | 621.7 | 0.0 |
| HUNT RESULT | - | - | - | - | 0.3 | +31.0 | 0.0 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.3 | +33.6 | 28.3 | 0.0 |
| IDLE COST | 0.7 | -13.6 | 0.0 | 0.0 | 13.3 | -243.0 | 0.0 | 48.3 |
| KEEP FALLS | 0.7 | +5.2 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | - | - | - | - | 1.0 | +49.3 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.0 | +0.0 | 0.0 | 310.0 | 1.3 | +0.0 | 120.7 | 26.7 |
| LONE WIZARD KEPT IN | 0.7 | +17.5 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 1.0 | -0.0 | 73.3 | 0.0 | 2.3 | +1.7 | 341.7 | 38.3 |
| LURE BY WHAT IT DRAWS | 0.7 | -39.5 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 1.3 | +11.8 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 2.0 | -2.7 | 0.0 | 0.0 | 0.7 | +3.9 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | - | - | - | - | 0.3 | +23.8 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +20.5 | 0.0 | 0.0 | 0.7 | +30.1 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +2.1 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 0.7 | -18.6 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 1.7 | +28.2 | 0.0 | 0.0 | 1.7 | +26.1 | 0.0 | 46.7 |
| MEETS IN TIME | 4.3 | +78.0 | 0.0 | 0.0 | 1.3 | +99.3 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 4.3 | +98.1 | 0.0 | 55.3 | 2.7 | +42.4 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 5.0 | +76.1 | 0.0 | 55.3 | 3.3 | +44.6 | 0.0 | 0.0 |
| MISSILES ON ONE TARGET | 0.3 | -10.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 32.7 | 32.7 |
| MOVE SPELL IN RANGE | 3.7 | +97.5 | 0.0 | 56.7 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.7 | -14.8 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 3.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 7.7 | +312.1 | 0.0 | 0.0 | 3.7 | +343.0 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | 0.3 | +2.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.7 | +273.0 | 0.0 | 0.0 | 6.3 | +272.6 | 0.0 | 82.7 |
| NEXT CHARGE BY LIST | 6.0 | +244.0 | 0.0 | 0.0 | 2.7 | +189.6 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -60.1 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 1.3 | -38.5 | 73.3 | 17.3 | 4.3 | -364.6 | 681.7 | 38.3 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.3 | +10.8 | 0.0 | 28.3 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 4.7 | -58.3 | 0.0 | 0.0 | 1.3 | -57.4 | 0.0 | 0.0 |
| OGRE LOADER SECOND SHOT | 1.7 | +1.8 | 38.3 | 76.7 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.3 | -34.9 | 0.0 | 28.3 | 6.7 | -162.2 | 0.0 | 71.0 |
| ONE OBJECTIVE FORMULA | 6.7 | -107.4 | 0.0 | 0.0 | 7.7 | -87.8 | 0.0 | 32.7 |
| ONE PROMISE A TARGET | 1.0 | +4.7 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 1.0 | +1.5 | 98.0 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 1.0 | +52.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.7 | +1.3 | 131.7 | 0.0 |
| PATHS CROSS | 0.7 | +14.2 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.3 | -1.4 | 0.0 | 103.3 | - | - | - | - |
| PLAN RESULT | 41.7 | +310.1 | 43.3 | 1113.7 | 37.0 | +859.4 | 516.7 | 166.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 6.0 | -70.4 | 0.0 | 0.0 | 7.3 | -337.1 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 4.3 | -42.9 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| QUARTER ODDS | 8.7 | +392.7 | 0.0 | 0.0 | 8.3 | +1296.0 | 235.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 1.7 | +0.8 | 0.0 | 56.7 | 4.0 | +9.6 | 0.0 | 0.0 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 1.7 | +19.1 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.0 | +146.0 | 0.0 | 0.0 | 2.7 | +37.9 | 0.0 | 56.7 |
| REDIRECT FOR A FRIEND IN REACH | 1.7 | +0.0 | 0.0 | 27.0 | 1.0 | +23.7 | 0.0 | 0.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.7 | +23.4 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.0 | -14.8 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +49.3 | 0.0 | 0.0 |
| RISK BY ARC | 1.0 | +19.9 | 46.7 | 17.3 | 3.3 | -72.0 | 576.7 | 38.3 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.3 | -31.7 | 76.7 | 0.0 |
| RUN DOWN | 1.0 | -7.0 | 73.3 | 0.0 | 1.0 | -4.9 | 108.3 | 38.3 |
| SEARCH SPOT | 0.7 | +1.3 | 0.0 | 28.3 | - | - | - | - |
| SECOND LOOK | - | - | - | - | 0.7 | +75.3 | 0.0 | 0.0 |
| SELF MOVE SPELL | - | - | - | - | 2.0 | +535.9 | 0.0 | 0.0 |
| SET CREDITED ONCE | 1.7 | -5.7 | 0.0 | 0.0 | 0.3 | -4.3 | 0.0 | 0.0 |
| SET UP BY THE SET | 2.3 | +6.9 | 0.0 | 0.0 | 1.0 | -22.5 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.7 | +13.0 | 0.0 | 17.3 | - | - | - | - |
| SET-UP ANY TARGET | 0.3 | +101.6 | 0.0 | 0.0 | - | - | - | - |
| SET-UP MISSED | 0.7 | +108.2 | 28.3 | 28.3 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +0.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 12.3 | +0.0 | 0.0 | 181.7 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +19.5 | 20.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | - | - | - | - | 0.7 | -7.0 | 206.7 | 0.0 |
| SHOT RISK POINTS | 11.3 | -186.7 | 0.0 | 117.3 | 21.3 | -146.9 | 0.0 | 66.7 |
| SHOTS AFTER THE MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 14.7 | +340.1 | 0.0 | 360.0 | 5.7 | +94.4 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.3 | +101.6 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | - | - | - | - | 0.3 | +1.8 | 38.3 | 0.0 |
| SPOT AS THE GAME MOVES | 9.3 | +0.0 | 0.0 | 251.0 | 5.0 | +0.0 | 0.0 | 32.7 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -15.7 | 103.3 | 0.0 |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 53.7 | +0.0 | 278.7 | 420.0 | 20.3 | +0.0 | 516.7 | 0.0 |
| STAY WORTH | 25.0 | -574.5 | 258.7 | 563.3 | 7.3 | +80.2 | 516.7 | 38.3 |
| STOPS | - | - | - | - | 0.3 | +2.1 | 28.3 | 0.0 |
| STRIKE BY THE ODDS | 0.7 | +8.6 | 0.0 | 74.0 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 6.0 | +346.8 | 0.0 | 413.3 | 3.0 | +38.3 | 0.0 | 93.3 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 6.0 | +346.8 | 0.0 | 413.3 | 3.0 | +38.3 | 0.0 | 93.3 |
| SURE REACH TOGETHER | 1.3 | +5.8 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -6.8 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 3.0 | +0.0 | 0.0 | 224.0 | 3.7 | +0.0 | 0.0 | 32.7 |
| THE ROW KEEPS ITS WAY | 4.0 | +0.0 | 0.0 | 31.7 | 3.0 | +0.0 | 0.0 | 73.3 |
| THE STEP BACK IS MADE | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 50.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 40.3 | +0.0 | 0.0 | 567.7 | 34.0 | +0.0 | 0.0 | 219.7 |
| TIED UP BY THE SUM | - | - | - | - | 1.3 | +140.3 | 108.3 | 38.3 |
| TIME ON OUR SIDE | 50.3 | +549.5 | 0.0 | 496.7 | 6.0 | +28.3 | 0.0 | 0.0 |
| WAITS AGAIN | 1.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | 0.7 | -0.3 | 46.7 | 0.0 | 0.7 | +0.8 | 31.7 | 38.3 |
| WHOLE FIGHT DANGER | 4.7 | -397.2 | 0.0 | 270.0 | 3.7 | -197.1 | 0.0 | 65.3 |
| WOUNDS ON THE RANKS | 0.7 | +0.9 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p86

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 64 | 64 | 63 | 21.00 | +4453 | +70.7 |
| ARMY TABLE | 82 | 82 | 44 | 14.67 | +2925 | +66.5 |
| HIS SHOT LIST | 242 | 238 | 44 | 14.67 | +1302 | +29.6 |
| DEPLOY BY FIGURES | 51 | 51 | 35 | 11.67 | +435 | +12.4 |
| TIME ON OUR SIDE | 169 | 152 | 30 | 10.00 | +59 | +2.0 |
| HIS SHOTS BY HIS RUN | 171 | 167 | 25 | 8.33 | +323 | +12.9 |
| THE TABLE AGAIN | 36 | 36 | 22 | 7.33 | +0 | +0.0 |
| FIVE ACTION | 512 | 501 | 19 | 6.33 | +872 | +45.9 |
| GOAL WALK | 58 | 58 | 19 | 6.33 | +1460 | +76.9 |
| OFF BEST | 18 | 18 | 18 | 6.00 | -347 | -19.3 |
| MOVE TO CHARGE COMPUTED | 34 | 26 | 17 | 5.67 | +385 | +22.6 |
| ARTILLERY RE-ROLL WEIGHED | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 40 | 40 | 15 | 5.00 | -1223 | -81.5 |
| FOUR ROUNDS | 19 | 17 | 13 | 4.33 | +518 | +39.9 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 26 | 21 | 12 | 4.00 | +302 | +25.2 |
| LEGAL CHARGES ONLY | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 17 | 17 | 10 | 3.33 | +31 | +3.1 |
| HARD STAY DROPPED | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| MEETS IN TIME | 17 | 17 | 9 | 3.00 | +159 | +17.7 |
| SUPPORT ADDS | 27 | 25 | 9 | 3.00 | +358 | +39.7 |
| SUPPORT WORKED OUT | 27 | 25 | 9 | 3.00 | +358 | +39.7 |
| CANNON PLANNED TARGET | 29 | 29 | 7 | 2.33 | +8 | +1.2 |
| CANNON SIGHT KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| SHOT RISK POINTS | 98 | 96 | 7 | 2.33 | +213 | +30.5 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CHARGE LOSSES | 72 | 71 | 6 | 2.00 | +636 | +106.0 |
| COVER ONCE | 43 | 33 | 6 | 2.00 | +30 | +5.0 |
| FALLS SHORT | 65 | 52 | 5 | 1.67 | +55 | +11.0 |
| OGRE LOADER SECOND SHOT | 5 | 5 | 5 | 1.67 | +5 | +1.1 |
| PROMISE KNOWS THE FIGHT | 15 | 11 | 5 | 1.67 | -129 | -25.8 |
| REDIRECT FOR A FRIEND IN REACH | 8 | 8 | 5 | 1.67 | +0 | +0.0 |
| RISK BY ARC | 13 | 11 | 5 | 1.67 | +54 | +10.7 |
| STUCK PIVOT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 25 | 25 | 5 | 1.67 | +216 | +43.2 |
| IDLE COST | 42 | 27 | 4 | 1.33 | +17 | +4.3 |
| ONE OBJECTIVE FORMULA | 43 | 35 | 4 | 1.33 | +122 | +30.6 |
| SET UP BY THE SET | 10 | 10 | 4 | 1.33 | +87 | +21.8 |
| THE ROW IN ITS ORDER | 20 | 4 | 4 | 1.33 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +541 | +180.4 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| LANE BY FIGURES | 3 | 3 | 3 | 1.00 | +148 | +49.3 |
| MARCH CHECK | 3 | 3 | 3 | 1.00 | +21 | +7.1 |
| MISSILES IN THE MOVE | 21 | 13 | 3 | 1.00 | +40 | +13.3 |
| ONE PROMISE A TARGET | 3 | 3 | 3 | 1.00 | +14 | +4.7 |
| QUARTER ODDS | 51 | 51 | 3 | 1.00 | +156 | +52.0 |
| REDIRECT COUNTER | 14 | 9 | 3 | 1.00 | +294 | +98.0 |
| SHOTS AFTER THE MOVES | 14 | 14 | 3 | 1.00 | +0 | +0.0 |
| TIED UP BY THE SUM | 4 | 3 | 3 | 1.00 | +89 | +29.6 |
| CAST JOB | 8 | 8 | 2 | 0.67 | +60 | +29.8 |
| CASTING BLOCK | 2 | 2 | 2 | 0.67 | +226 | +112.8 |
| CHARGE LIST READ AGAIN | 2 | 2 | 2 | 0.67 | +197 | +98.3 |
| CHARGE NOW FIRST | 12 | 12 | 2 | 0.67 | -271 | -135.6 |
| EXACT ROUND | 15 | 14 | 2 | 0.67 | +2 | +1.2 |
| HONEST WORTH | 14 | 12 | 2 | 0.67 | +30 | +15.0 |
| KEEP FALLS | 2 | 2 | 2 | 0.67 | +24 | +11.9 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +53 | +26.3 |
| MOVES UNITS SPELL | 2 | 2 | 2 | 0.67 | +62 | +31.2 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +42 | +21.2 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | -37 | -18.4 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +226 | +113.1 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +2 | +1.0 |
| SHOOTS FROM THE BEST SPOT | 4 | 4 | 2 | 0.67 | +0 | +0.0 |
| STAY WORTH | 97 | 89 | 2 | 0.67 | +33 | +16.7 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +26 | +12.8 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -152 | -152.2 |
| BLOCKED CHARGE SKIPPED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -0 | -0.2 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +37 | +37.2 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 18 | 16 | 1 | 0.33 | +69 | +69.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS CHARGE DENIED | 2 | 2 | 1 | 0.33 | +0 | +0.3 |
| HIS TURN DENIED | 3 | 3 | 1 | 0.33 | +6 | +5.6 |
| LOST AFTER ESCAPE | 10 | 9 | 1 | 0.33 | +2 | +2.2 |
| MANOEUVRE | 8 | 8 | 1 | 0.33 | +12 | +11.6 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +71 | +71.4 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -6 | -6.4 |
| MAX FOR POSITIONING | 10 | 10 | 1 | 0.33 | +0 | +0.0 |
| MISSILES NEXT TURN | 25 | 17 | 1 | 0.33 | +3 | +3.2 |
| MOVE SPELL IN RANGE | 11 | 11 | 1 | 0.33 | +0 | +0.0 |
| NEARER NOT NEEDED | 36 | 33 | 1 | 0.33 | +8 | +7.7 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.33 | +21 | +20.9 |
| OPENS UP | 3 | 2 | 1 | 0.33 | +18 | +17.7 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -4 | -4.3 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +148 | +148.0 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +4 | +3.9 |
| SHOTS IN THE MOVE | 61 | 43 | 1 | 0.33 | +3 | +2.6 |
| STOPS | 1 | 1 | 1 | 0.33 | +6 | +6.1 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -190 | -189.5 |
| SURE REACH TOGETHER | 4 | 4 | 1 | 0.33 | +0 | +0.0 |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 14 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 56 | 53 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 10 | not checked | - | - | - | - |
| DUEL STOPS AT THE KILL | 1 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 2 | 2 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 18 | 18 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FIGHT TO THE END | 6 | 6 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 38 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 17 | 15 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 4 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 6 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 13 | 13 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 44 | 43 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 32 | 32 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 22 | 22 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 23 | 23 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 8 | 8 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 33 | 30 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 57 | 57 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 20 | 20 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 129 | 129 | 0 | 0.00 | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| KEPT FROM ITS LAST STOP | 10 | 10 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 4 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 2 | trace | - | - | - | - |
| MOVE SPELL SPOT | 9 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 17 | 16 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 33 | 21 | 0 | 0.00 | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS A LANE | 3 | not checked | - | - | - | - |
| OVERRUNS AWAY | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 236 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 5 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 3 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 4 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 6 | 6 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 6 | 6 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 5 | 3 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 43 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 1 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 43 | 37 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 7 | 7 | 0 | 0.00 | - | - |
| STANDS STILL | 222 | 220 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 3 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 21 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 13 | not checked | - | - | - | - |
| THE TABLE BINDS | 223 | not checked | - | - | - | - |
| WAITS AGAIN | 11 | 11 | 0 | 0.00 | - | - |
| WHO FIGHTS | 4 | 4 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 3 | 3 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p86

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.00 | 1.00 | 19.3 |
| PROMISE BY ITS OWN SUM | rule | 2.33 | 2.67 | 81.5 |
| PROMISE KNOWS THE FIGHT | rule | 1.67 | - | 25.8 |
| ARMY TABLE | rule | - | 1.00 | 55.1 |
| CANNON PLANNED TARGET | rule | 0.67 | - | 0.7 |
| CHARGE NOW FIRST | rule | - | 0.67 | 135.6 |
| NO REASON | gate | 0.67 | - | 28.2 |
| ONE PROMISE A TARGET | rule | 0.67 | - | 2.2 |
| AFTERMATH BAND | gate | - | 0.33 | 0.7 |
| BEST PRIZE | rule | - | 0.33 | 152.2 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 46.9 |
| MARCH OF THE TABLE | rule | - | 0.33 | 6.4 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 4.3 |
| REDIRECT WEIGHED | rule | - | 0.33 | 152.2 |
| SUPPORT NARROWED | rule | - | 0.33 | 189.5 |

### Plans: gs3-83c8646-p86

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 50% | 37 | 50 | 135% |
| Mine | move | 30.7 | 97% | 1345 | 0 | 0% |
| Mine | shoot | 9.7 | 55% | 158 | 260 | 164% |
| Opponent | charge | 4.0 | 58% | 565 | 579 | 102% |
| Opponent | move | 31.7 | 95% | 1734 | 0 | 0% |
| Opponent | shoot | 1.0 | 100% | 216 | 280 | 130% |
| Opponent | support | 0.3 | 100% | 9 | 0 | 0% |

### Packages: hunt the guns, gs3-83c8646-p86

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Opponent | 0.3 | 1 | 0 | 100% | 100% | 0% | 2.0 | 101 | 93 | 100% | 38 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 1.0 | 1 | 0 | 100% | 100% | 0% | 2.0 | 101 | 93 | 100% | 115 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: gs3-83c8646-p86

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.0 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 2.7 | 25% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p86

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Character | 6 | 0 (6) | 0 | 0 | 0 | 67% | 1.0 | 0 (1) | 0 (2) | 0 (3) | 0 (1) | 0 (5) |
| Mine | Clean-up | 7 | 125 (7) | 0 | 125 | 28 | 57% | 4.7 | 194 (2) | 103 (4) | 0 (1) | 195 (5) | 0 (2) |
| Mine | Fast Hammer | 2 | 47 (2) | 47 | 0 | 0 | 50% | 4.0 | - | - | 47 (2) | 94 (1) | 0 (1) |
| Mine | Hammer | 9 | 29 (9) | 8 | 21 | 62 | 33% | 1.7 | 3 (4) | 61 (4) | 0 (1) | 59 (5) | 0 (4) |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | War machine | 8 | 10 (8) | 10 | 0 | 19 | 0% | 2.0 | 19 (4) | 0 (4) | - | - | 10 (8) |
| Mine | Wizard | 6 | 18 (6) | 18 | 0 | 31 | 33% | 2.2 | 0 (2) | 0 (2) | 47 (2) | - | 18 (6) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 77 | 33% | 3.5 | 0 (1) | 0 (1) | 0 (1) | 0 (3) | - |
| Opponent | Character | 7 | 58 (7) | 58 | 0 | 0 | 0% | 2.3 | 0 (1) | 84 (5) | 0 (1) | 39 (5) | 94 (2) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast | 1 | 142 (1) | 142 | 0 | 0 | 0% | 5.0 | 142 (1) | - | - | 142 (1) | - |
| Opponent | Fast Hammer | 9 | 51 (9) | 7 | 45 | 18 | 44% | 2.0 | 102 (4) | 31 (5) | - | 111 (5) | 0 (4) |
| Opponent | Hammer | 4 | 104 (4) | 0 | 104 | 0 | 75% | 4.0 | - | 104 (4) | - | 148 (3) | 0 (1) |
| Opponent | Holder | 2 | 39 (2) | 39 | 0 | 37 | 0% | 5.0 | 39 (2) | - | - | 61 (1) | 0 (1) |
| Opponent | Shooter | 2 | 119 (2) | 0 | 119 | 0 | 0% | 1.0 | 119 (2) | - | - | 286 (1) | 0 (1) |

### Charged fights: gs3-83c8646-p86

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 98 | 80 | 2.0 | 1.0 | 40 | 26 | +14 | 0 of 2 | 1 of 2 | - | +14 |
| Mine | Chaos Dwarfs | 2 | 72 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 81 | 27 | 0.7 | 1.0 | 40 | 26 | +14 | 0 of 2 | 1 of 2 | - | +14 |
| Opponent | High Elf Realms | 1 | 0 | 800 | 5.0 | 1.0 | 160 | 0 | +160 | 3 of 5 | 5 of 5 | - | +160 |
| Opponent | Warriors of Chaos | 2 | 0 | 468 | 3.0 | 1.0 | 156 | 0 | +156 | 2 of 6 | 4 of 6 | - | +156 |
| **Opponent** | all armies | 3 | 0 | 578 | 3.7 | 1.0 | 158 | 0 | +158 | 5 of 11 | 9 of 11 | - | +158 |

### Effective charges: gs3-83c8646-p86

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 1 (net -52) | 0 | 0 | 1 (net +80) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | High Elf Realms | 5 | 0 | 0 | 1 (net +85) | 1 (net +310) | 0 | 3 (net +135) | 0 | 20% (1 of 5) |
| Opponent | Warriors of Chaos | 6 | 0 | 0 | 1 (net +0) | 2 (net +155) | 1 (net +0) | 2 (net +312) | 0 | 17% (1 of 6) |

### Charged fights, damage counted: gs3-83c8646-p86

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 52 | 717 | -52 | 0 | 52 | -52 | -100.0 |
| Mine | 76-89% | 1 | 85 | 80 | +80 | 80 | 0 | +80 | +94.1 |
| Mine | All fights | 2 | 68 | 398 | +14 | 40 | 26 | +14 | +20.4 |
| Opponent | Effective (55-75%) | 2 | 45 | 85 | +42 | 119 | 63 | +55 | +123.1 |
| Opponent | 76-89% | 3 | 495 | 310 | +207 | 207 | 55 | +151 | +30.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 349 | 206 | +206 | 206 | 31 | +175 | +50.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 499 | 91 | +0 | 65 | 0 | +65 | +13.0 |
| Opponent | All fights | 11 | 347 | 202 | +158 | 178 | 41 | +137 | +39.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p86 | move | 23 | 5 (22%) | 5 (22%) | 4 (17%) | 14 (61%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Ring of Doom | Mine | L0230 |
| Ring of Doom | Opponent | L0315 |

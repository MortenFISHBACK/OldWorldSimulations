# Doctrine scorecard: gs3-83c8646-p65

### Scorecard: gs3-83c8646-p65

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0721 | 1 | 1 | Mine | no | 3 | 3 | 1 | 1 | 0 | 0 | 0 | 295 |
| L0721 | 1 | 1 | Opponent | yes | 4 | - | 0 | 6 | 1 | 0 | 0 | 555 |
| L0810 | 6 | 1 | Mine | no | 6 | - | 0 | 2 | 0 | 0 | 0 | 760 |
| L0810 | 6 | 1 | Opponent | no | 12 | 2 | 0 | 0 | 1 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | - | 2 | 2 | 0 | 0 | 0 | 0 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 3 | 6 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 4.5 | 3.0 | 1.0 | 1.7 | 0.0 | 0.0 | 0.0 | 351.7 |
| **Average** | | | Opponent | 67% | 8.0 | 2.0 | 1.0 | 4.0 | 0.7 | 0.0 | 0.0 | 295.0 |

### KPIs: gs3-83c8646-p65

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 100% (17 of 17) | 0% (0 of 14) | 55% (17 of 31) |
| Winner chose to follow up after the loser gave ground |  | 0% (0 of 1); on the table 0% | 100% (17 of 17); on the table 100% | 94% (17 of 18); on the table 94% |
| Winner chose to pursue after the loser fell back in good order |  | - | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 0% (0 of 1); on the table 0% | 94% (17 of 18); on the table 94% | 89% (17 of 19); on the table 89% |
| Magic missiles tried each own turn | 50%+ | 67% (4 of 6) | 33% (12 of 36) | 38% (16 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 67% (4 of 6) | 41% (12 of 29) | 46% (16 of 35) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 62% (8 of 13) | 62% (8 of 13) |
| Points that never fought | lower | 73% (4387 of 5999) | 87% (5224 of 5998) | 80% (9611 of 11997) |
|   infantry points that never fought | lower | 100% (968 of 968) | 92% (1021 of 1113) | 96% (1989 of 2081) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 73% (22 of 30) | 60% (15 of 25) | 67% (37 of 55) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (3 of 3); 3.3 uses a game | 100% (3 of 3); 1.7 uses a game |
| Bound items with another spell used |  | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 3); 0.0 uses a game | 50% (1 of 2); 0.3 uses a game | 20% (1 of 5); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 67% (3584 of 5378) | 63% (3269 of 5181) | 65% (6853 of 10559) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.0 (38%) | 3.0 (35%) |
| MARCHED: its unit marched | 0.7 (100%) | 2.0 (25%) | 2.7 (31%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.7 (8%) | 0.7 (8%) |
| GONE: slain | 0.0 (0%) | 2.3 (29%) | 2.3 (27%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.7 | 2.0 | 3.7 | 5.3 | 0.3 | 0.0 |
| not cast | 4.3 | 0.0 | 2.3 | 8.7 | 3.7 | 28.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | - | 0.0 (0%) | 3.0 (35%) | 1.3 (36%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | - | 0.0 (0%) | 2.7 (31%) | 1.0 (27%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | - | 0.0 (0%) | 0.7 (8%) | 0.0 (0%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.7 (15%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.0 (23%) | - | 1.3 (57%) | 2.3 (27%) | 1.3 (36%) | 5.3 (19%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (8%) |
| STUPIDITY: Stupidity | 0.7 (15%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (46%) | - | 1.0 (43%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 20.3 (73%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 3.7 a game | 1.8 a game |
| stood (cast and not dispelled) | - | 36% (4 of 11) | 36% (4 of 11) |
| the unit moved after it | - | 100% (4 of 4) | 100% (4 of 4) |
| it charged on its next turn | - | 0% (0 of 4) | 0% (0 of 4) |
| the enemy charged it first | - | 0% (0 of 4) | 0% (0 of 4) |
| it fought by the end of its next turn | - | 0% (0 of 4) | 0% (0 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 4) | 0% (0 of 4) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (4 of 4) | 100% (4 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 79% (74 of 94) | 77% (24 of 31) | 78% (98 of 125) |
|   cavalry | 83% (19 of 23) | - | 83% (19 of 23) |
|   chariot | 100% (8 of 8) | 62% (8 of 13) | 76% (16 of 21) |
|   infantry | 83% (10 of 12) | 80% (8 of 10) | 82% (18 of 22) |
|   war machine | 73% (37 of 51) | 100% (8 of 8) | 76% (45 of 59) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.3 (20%) | 0.0 (0%) | 1.3 (15%) |
| CHARGED: it charged | 0.7 (10%) | 0.0 (0%) | 0.7 (7%) |
| MOVED: a war machine that moved | 1.7 (25%) | 0.0 (0%) | 1.7 (19%) |
| NO TARGET IN RANGE | 0.3 (5%) | 2.3 (100%) | 2.7 (30%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (5%) | 0.0 (0%) | 0.3 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (15%) | 0.0 (0%) | 1.0 (11%) |
| SHELTERED: the target was sheltered | 0.3 (5%) | 0.0 (0%) | 0.3 (4%) |
| OTHER BAR | 1.0 (15%) | 0.0 (0%) | 1.0 (11%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 12.3 | 6.7 | 68% | 15.1 pts | 187 pts |
| chariot | 5.3 | 2.0 | 75% | 14.5 pts | 78 pts |
| infantry | 6.0 | 4.7 | 44% | 14.8 pts | 89 pts |
| war machine | 15.3 | 13.0 | 63% | 35.0 pts | 536 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.0 | 3.3 | 2.2 |
| Charges that made contact a game | 0.7 | 2.0 | 1.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.40 declared, 0.00 contact (5 units) | 0.33 declared, 0.00 contact (6 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.14 declared, 0.09 contact (22 units) | 0.36 declared, 0.27 contact (22 units) | 0.25 declared, 0.18 contact (44 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 44% (4 of 9) | 33% (1 of 3) | 100% (1 of 1) | 46% (6 of 13) |
| Character in a unit | 100% (5 of 5) | - | - | 100% (5 of 5) |
| Character on its own | 100% (6 of 6) | 50% (1 of 2) | 50% (2 of 4) | 75% (9 of 12) |
| Chariot | 100% (3 of 3) | 100% (2 of 2) | - | 100% (5 of 5) |
| Infantry | 33% (1 of 3) | 100% (1 of 1) | 50% (1 of 2) | 50% (3 of 6) |
| Monster | - | 0% (0 of 1) | - | 0% (0 of 1) |
| War Machines | 69% (9 of 13) | - | - | 69% (9 of 13) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 3 | 0% (0 of 1); on the table 0% | 67% (4 of 6) | 73% | 73% (22 of 30) | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| Grand Cathay | 1 | - | 38% (9 of 24) | 100% | 30% (3 of 10) | 100% (2 of 2); 9.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 0% (0 of 1); on the table 0% | 17% (1 of 6) | 85% | 78% (7 of 9) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 1 | 100% (17 of 17); on the table 100% | 33% (2 of 6) | 76% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p65, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 100% (2) | 67% (2) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.67 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.33 | 0.33 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p65

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.0 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 50% (2 of 4) | 60% (6 of 10) |
| Strategy | Shoot objectives carried out (shot that target) | 22% (11 of 49) | 38% (8 of 21) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | 100% (1 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 25% (1 of 4) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 5) | 0% (0 of 2) |
| Strategy | Lone characters that fought | 22% (2 of 9) | 18% (2 of 11) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 1.7 | 4.0 |
| Movement | Points that never moved of their own | 351.7 | 295.0 |
| Movement | Fights charged into per game | 0.7 | 1.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 2 | 1 of 4, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | 0 of 4 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 2 | 0 of 4 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 2, net +46 | 2 of 4, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 13.7 | 5.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 32% (13 of 41) | 50% (8 of 16) |
| Shooting | Points destroyed by shooting units | 357.7 | 0.0 |
| Shooting | War machine shots | 12.3 | 3.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 54% (20 of 37) | 33% (3 of 9) |
| Shooting | Points destroyed by war machines | 215.3 | 85.0 |
| Magic | Magic missiles cast | 1.3 | 3.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 4) | 20% (2 of 10) |
| Magic | Wounds caused by magic missiles | 4.7 | 6.7 |
| Magic | Points destroyed by magic (all spells) | 21.7 | 27.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.3 / 1.3 / 0.0 / 0.0 | 3.3 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 0.0 | 0.0 |
| Combat | Points run down | 30.7 | 41.7 |
| Combat | Net points per charged fight, damage counted | +4 | +76 |
| Combat | Net per 100 charger points, damage counted | +2.3 | +42.9 |
| Combat | First round won (charged fights) | 100% | 75% |
| Combat | Net points per charged fight | +46 | +76 |
| Combat | Net points per supported fight / lone fight | - / +46 | +0 / +101 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 2 | 3 of 4 |
| Game | Points lost | 435.0 | 734.3 |
| Game | VP from objectives | 570.0 | 726.7 |
| Game | Lone holders (player turns) | 4.5 | 8.0 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +209 VP
- The side that went first won 0 of 3 games with a winner
- Points traded per game (both sides' losses): 1169
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p65

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +62.2 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 18.7 | +235.9 | 0.0 | 134.7 | 15.3 | +247.7 | 0.0 | 502.3 |
| ARTILLERY RE-ROLL WEIGHED | 3.7 | +0.0 | 0.0 | 83.3 | 0.3 | +0.0 | 0.0 | 55.0 |
| BACKUP TARGETS | 0.3 | +0.2 | 0.0 | 0.0 | 0.3 | +9.2 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.7 | +0.0 | 144.7 | 41.7 | 0.7 | +0.0 | 98.0 | 0.0 |
| CANNON PLANNED TARGET | 11.3 | +802.0 | 1366.3 | 83.3 | 2.7 | +206.2 | 279.3 | 110.0 |
| CANNON SIGHT KEPT | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CAST JOB | - | - | - | - | 5.0 | +112.3 | 157.3 | 367.3 |
| CASTS AFTER FRIENDS | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 2.0 | +56.9 | 0.0 | 0.0 |
| CHAFF PASSED | 1.7 | -2.3 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | - | - | - | - | 2.0 | +0.0 | 0.0 | 296.0 |
| CHARGE LOSSES | 14.0 | -555.2 | 0.0 | 293.3 | 21.0 | -1915.5 | 0.0 | 1406.3 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 30.7 | 0.0 | 1.7 | +0.0 | 109.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.7 | +0.0 | 0.0 | 0.0 | 15.3 | +0.0 | 0.0 | 397.3 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | - | - | - | - | 3.3 | +386.0 | 434.0 | 289.3 |
| COVER ONCE | 6.7 | -363.4 | 0.0 | 67.3 | 8.3 | -638.6 | 0.0 | 536.0 |
| DEFENSIVE ARMY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | 0.3 | -10.9 | 30.7 | 0.0 | 0.7 | -0.8 | 41.7 | 0.0 |
| DEPLOY BY FIGURES | 7.0 | -106.9 | 0.0 | 0.0 | 7.3 | -20.3 | 0.0 | 48.3 |
| EDGE GIVE GROUND | - | - | - | - | 0.7 | +96.9 | 134.7 | 0.0 |
| EXACT ROUND | 1.0 | +5.6 | 0.0 | 0.0 | 3.3 | +17.5 | 218.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.0 | +13.0 | 30.7 | 0.0 | 3.0 | +2.0 | 150.7 | 0.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 25.3 | +316.2 | 0.0 | 1336.7 |
| FEATURE BUFFS | - | - | - | - | 3.3 | +38.0 | 0.0 | 108.0 |
| FIGHT TO THE END | 1.0 | +11.4 | 30.7 | 0.0 | 1.0 | +101.6 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 41.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 98.7 | +7331.2 | 4239.3 | 728.0 | 91.7 | +4344.4 | 904.0 | 2597.7 |
| FLANK NOT WEIGHED | 3.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 137.0 |
| FOLLOW UP WEIGHED | - | - | - | - | 3.3 | +388.3 | 0.0 | 0.0 |
| FOOT FIRST | 18.7 | +0.0 | 0.0 | 79.3 | - | - | - | - |
| FOUR ROUNDS | 1.3 | +63.2 | 30.7 | 0.0 | 3.3 | +247.2 | 218.0 | 0.0 |
| FREED FROM HIS FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 1.0 | -128.7 | 0.0 | 0.0 | 0.7 | -55.0 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.7 | -2.2 | 41.7 | 0.0 |
| GOAL WALK | 5.3 | +585.1 | 0.0 | 0.0 | 15.7 | +1093.9 | 0.0 | 498.7 |
| GUN FIGURES | 3.0 | +27.8 | 54.0 | 0.0 | 2.3 | +5.1 | 0.0 | 65.0 |
| GUN MASK | 2.3 | +46.3 | 0.0 | 0.0 | 0.7 | +24.1 | 0.0 | 0.0 |
| HARD STAY DROPPED | 2.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 8.0 | +0.0 | 0.0 | 134.7 | 13.0 | +0.0 | 0.0 | 757.0 |
| HIS CHARGE DENIED | 1.0 | +12.9 | 30.7 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 4.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 43.3 |
| HIS LEGAL MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.3 | -46.4 | 0.0 | 0.0 | 3.3 | -147.7 | 0.0 | 144.7 |
| HIS ONE QUARTER | 2.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 21.7 |
| HIS OWN BEST MOVE | 5.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 16.3 | +0.0 | 0.0 | 158.7 | - | - | - | - |
| HIS RANDOM MOVER COMES | 1.3 | +0.0 | 0.0 | 158.7 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 31.3 | +836.2 | 0.0 | 182.7 | 54.3 | +3277.1 | 0.0 | 966.0 |
| HIS SHOTS BY HIS RUN | 26.0 | +602.0 | 0.0 | 24.0 | 50.0 | +1853.4 | 0.0 | 1662.3 |
| HIS TURN DENIED | - | - | - | - | 2.0 | +81.2 | 83.3 | 0.0 |
| HOLD ODDS | 11.3 | +0.0 | 0.0 | 158.7 | 23.3 | +0.0 | 0.0 | 338.7 |
| HOLDER ASSIGNMENT | 9.3 | +880.8 | 0.0 | 79.3 | 12.0 | +913.6 | 0.0 | 115.3 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.7 | -8.2 | 30.7 | 0.0 | 3.3 | -73.6 | 218.0 | 0.0 |
| IDLE COST | - | - | - | - | 15.0 | -184.5 | 0.0 | 560.3 |
| JOINT CHARGE NOW | 0.7 | +12.9 | 0.0 | 0.0 | 1.0 | -76.2 | 0.0 | 0.0 |
| KEEP FALLS | 0.3 | +9.5 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +1.4 | 0.0 | 0.0 | 1.0 | +51.5 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.0 | +0.0 | 0.0 | 244.0 | 6.3 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.7 | +46.6 | 0.0 | 0.0 | 0.3 | +58.3 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 1.0 | +1.1 | 0.0 | 43.3 |
| LOST AFTER ESCAPE | - | - | - | - | 1.0 | +2.7 | 41.7 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.3 | +2.8 | 0.0 | 0.0 |
| MANOEUVRE | 2.7 | -3.2 | 0.0 | 0.0 | 2.3 | -0.3 | 0.0 | 86.3 |
| MARCH CHECK | - | - | - | - | 1.0 | +37.4 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.7 | +17.7 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.7 | +66.6 | 0.0 | 0.0 | 0.7 | +123.3 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.3 | +16.3 | 0.0 | 0.0 | 4.7 | +90.7 | 0.0 | 345.0 |
| MEETS IN TIME | 4.0 | +342.3 | 0.0 | 0.0 | 4.3 | +157.8 | 0.0 | 48.3 |
| MISSILES IN THE MOVE | 1.3 | +47.5 | 0.0 | 0.0 | 8.0 | +128.2 | 0.0 | 618.0 |
| MISSILES NEXT TURN | 1.7 | +76.6 | 0.0 | 0.0 | 9.0 | +114.9 | 0.0 | 961.0 |
| MOVE ORDER | 1.0 | +0.0 | 79.3 | 0.0 | 3.3 | +0.0 | 30.7 | 95.7 |
| MOVE SPELL SPOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 5.3 | +651.7 | 0.0 | 0.0 | 6.3 | +722.1 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 9.7 | +411.6 | 0.0 | 79.3 | 8.3 | +374.9 | 0.0 | 178.7 |
| NEAREST TO GOAL | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 4.3 | +534.9 | 0.0 | 0.0 | 6.3 | +722.1 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 0.3 | -24.3 | 30.7 | 0.0 | 2.3 | -67.5 | 218.0 | 0.0 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 9.3 | -443.1 | 0.0 | 109.0 | 1.3 | -26.4 | 0.0 | 117.3 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 0.3 | +36.0 | 41.7 | 0.0 |
| ONE FIGHT FORMULA | 5.0 | -102.1 | 0.0 | 79.3 | 6.0 | -145.2 | 0.0 | 345.0 |
| ONE JOINT FIGURE | 0.3 | +25.3 | 0.0 | 0.0 | 0.3 | +10.8 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 3.0 | +26.5 | 0.0 | 0.0 | 8.3 | +3.1 | 0.0 | 115.3 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | -71.9 | 0.0 | 0.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 0.7 | +9.9 | 43.3 | 0.0 | 0.3 | +4.4 | 15.0 | 0.0 |
| OWN CAST FIRST | 0.7 | -4.8 | 0.0 | 0.0 | 0.3 | -9.3 | 0.0 | 0.0 |
| PATHS CROSS | - | - | - | - | 1.3 | +42.8 | 0.0 | 0.0 |
| PERIAPT WORTH | - | - | - | - | 0.3 | +24.8 | 0.0 | 180.0 |
| PLAN RESULT | 43.3 | +1883.6 | 1163.3 | 551.7 | 45.7 | +341.2 | 242.0 | 1107.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 6.7 | -243.1 | 0.0 | 0.0 | 5.0 | -14.8 | 0.0 | 0.0 |
| PROMISE IN STEPS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 2.0 | -7.5 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | 1.0 | -10.2 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 22.3 | +1808.6 | 271.3 | 134.7 | 17.0 | +1762.6 | 134.7 | 86.7 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.3 | +194.0 | 0.0 | 48.3 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.3 | +7.0 | 0.0 | 0.0 | 2.0 | +167.2 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.3 | -4.0 | 0.0 | 0.0 | 1.3 | -5.1 | 0.0 | 0.0 |
| RISK BY ARC | 1.3 | -24.8 | 30.7 | 0.0 | 1.7 | +8.9 | 83.3 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.3 | -6.3 | 134.7 | 0.0 |
| RUN DOWN | 0.3 | -0.0 | 30.7 | 0.0 | 2.0 | -16.0 | 218.0 | 0.0 |
| SAFER THAN THE JOB | - | - | - | - | 0.3 | +23.0 | 0.0 | 0.0 |
| SCOUT SPOT | 0.7 | +4.7 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.0 | -88.0 | 0.0 | 55.0 |
| SEARCH SPOT | - | - | - | - | 0.7 | +7.7 | 0.0 | 0.0 |
| SET CREDITED ONCE | 1.0 | -5.3 | 0.0 | 0.0 | 2.3 | -111.1 | 0.0 | 180.0 |
| SET UP BY THE SET | 2.3 | +35.9 | 0.0 | 0.0 | 4.0 | +120.4 | 0.0 | 180.0 |
| SET UP TOGETHER | 0.7 | +18.5 | 0.0 | 0.0 | 0.3 | +2.8 | 0.0 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.7 | +88.0 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.7 | +72.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 16.3 | +0.0 | 0.0 | 138.0 | 7.3 | +0.0 | 0.0 | 409.3 |
| SHOOTS FROM THE BEST SPOT | 2.0 | +196.3 | 444.0 | 0.0 | 1.3 | +21.8 | 0.0 | 65.0 |
| SHORT GUN FORWARD | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -0.0 | 41.7 | 55.0 |
| SHOT REPLANNED | - | - | - | - | 0.3 | +0.0 | 43.3 | 0.0 |
| SHOT RISK POINTS | 17.7 | -86.3 | 0.0 | 24.0 | 34.7 | +5.8 | 0.0 | 1375.3 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 24.3 | +1854.0 | 0.0 | 138.0 | 7.7 | +338.5 | 0.0 | 323.0 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.7 | +88.0 | 0.0 | 0.0 |
| SPELL WORTH | 1.0 | +2.2 | 0.0 | 0.0 | 4.3 | +64.6 | 360.0 | 360.0 |
| SPOT AS THE GAME MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 11.0 | +0.0 | 0.0 | 218.7 |
| STANDS FOR A REASON | - | - | - | - | 4.3 | +0.0 | 24.0 | 471.3 |
| STANDS STILL | 64.0 | +0.0 | 4208.7 | 434.7 | 28.7 | +0.0 | 686.0 | 1125.7 |
| STAY WORTH | 30.7 | +854.9 | 2426.0 | 356.3 | 14.0 | +90.1 | 638.0 | 416.7 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +1.3 | 67.3 | 0.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.0 | +131.1 | 0.0 | 0.0 | 1.3 | +90.6 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 30.7 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 2.0 | +131.1 | 0.0 | 0.0 | 1.3 | +90.6 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.7 | -10.8 | 0.0 | 134.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 144.7 |
| THE ROW KEEPS ITS WAY | 1.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 30.7 |
| THE STEP BACK IS MADE | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 43.3 | +0.0 | 0.0 | 364.0 | 44.3 | +0.0 | 0.0 | 1274.7 |
| TIED UP BY THE SUM | 0.7 | +58.7 | 30.7 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 45.3 | +529.7 | 0.0 | 294.3 | - | - | - | - |
| WAITS AGAIN | 4.0 | +0.0 | 0.0 | 158.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | +1.9 | 0.0 | 0.0 |
| WHO FIGHTS | - | - | - | - | 1.0 | +57.4 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +0.9 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 1.7 | -225.9 | 0.0 | 134.7 | 3.0 | -201.9 | 0.0 | 230.7 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +1.0 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 4.0 | +43.3 | 0.0 | 0.0 | 3.7 | +114.4 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p65

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 102 | 102 | 83 | 27.67 | +1376 | +16.6 |
| HIS SHOT LIST | 257 | 250 | 64 | 21.33 | +1401 | +21.9 |
| HIS SHOTS BY HIS RUN | 228 | 224 | 61 | 20.33 | +1235 | +20.2 |
| HOLDER ASSIGNMENT | 64 | 64 | 59 | 19.67 | +4354 | +73.8 |
| FIVE ACTION | 571 | 558 | 45 | 15.00 | +2601 | +57.8 |
| SHOT RISK POINTS | 157 | 155 | 43 | 14.33 | +1427 | +33.2 |
| LEGAL CHARGES ONLY | 34 | 34 | 34 | 11.33 | +0 | +0.0 |
| OFF BEST | 32 | 32 | 32 | 10.67 | -1408 | -44.0 |
| TIME ON OUR SIDE | 136 | 126 | 30 | 10.00 | +124 | +4.1 |
| DEPLOY BY FIGURES | 43 | 43 | 25 | 8.33 | +379 | +15.2 |
| MOVE TO CHARGE COMPUTED | 35 | 32 | 24 | 8.00 | +1236 | +51.5 |
| NEXT CHARGE BY LIST | 32 | 30 | 22 | 7.33 | +1236 | +56.2 |
| GOAL WALK | 63 | 62 | 21 | 7.00 | +1627 | +77.5 |
| THE TABLE AGAIN | 36 | 36 | 21 | 7.00 | +0 | +0.0 |
| QUARTER ODDS | 118 | 114 | 16 | 5.33 | +1248 | +78.0 |
| CAST JOB | 15 | 15 | 13 | 4.33 | +156 | +12.0 |
| MOVE ORDER | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| CHARGE LOSSES | 105 | 105 | 12 | 4.00 | +514 | +42.9 |
| MEETS IN TIME | 25 | 25 | 12 | 4.00 | +880 | +73.3 |
| FOLLOW UP WEIGHED | 10 | 10 | 10 | 3.33 | +1165 | +116.5 |
| HARD STAY DROPPED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 35 | 35 | 8 | 2.67 | -774 | -96.7 |
| RANDOM MOVE BY FIGURES | 13 | 13 | 8 | 2.67 | +582 | +72.7 |
| SET UP BY THE SET | 19 | 19 | 8 | 2.67 | +168 | +21.0 |
| SHOOTS FROM THE BEST SPOT | 10 | 10 | 8 | 2.67 | +324 | +40.5 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| COVER ONCE | 45 | 30 | 7 | 2.33 | +168 | +24.0 |
| PROMISE KNOWS THE FIGHT | 6 | 6 | 6 | 2.00 | -23 | -3.8 |
| SHOTS IN THE MOVE | 96 | 71 | 6 | 2.00 | +305 | +50.9 |
| CHAFF PASSED | 5 | 5 | 5 | 1.67 | -7 | -1.4 |
| IDLE COST | 45 | 37 | 5 | 1.67 | +23 | +4.7 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | -190 | -38.0 |
| WOUNDS ON THE RANKS | 23 | 23 | 5 | 1.67 | +41 | +8.1 |
| FALLS SHORT | 76 | 59 | 4 | 1.33 | +37 | +9.2 |
| FOUR ROUNDS | 14 | 14 | 4 | 1.33 | +296 | +74.0 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +159 | +39.7 |
| PATHS CROSS | 4 | 4 | 4 | 1.33 | +128 | +32.1 |
| REDIRECT FOR A FRIEND IN REACH | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CANNON PLANNED TARGET | 42 | 42 | 3 | 1.00 | +60 | +19.9 |
| CHARGE NOW FIRST | 6 | 6 | 3 | 1.00 | -284 | -94.5 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +315 | +104.9 |
| MARCH CHECK | 3 | 3 | 3 | 1.00 | +40 | +13.4 |
| NEARER NOT NEEDED | 54 | 53 | 3 | 1.00 | +101 | +33.7 |
| OWN CAST FIRST | 3 | 3 | 3 | 1.00 | -42 | -14.0 |
| PROMISE SHOT AWAY | 3 | 3 | 3 | 1.00 | -31 | -10.2 |
| SHOTS AFTER THE MOVES | 27 | 27 | 3 | 1.00 | +0 | +0.0 |
| SUPPORT ADDS | 10 | 10 | 3 | 1.00 | +20 | +6.7 |
| SUPPORT WORKED OUT | 10 | 10 | 3 | 1.00 | +20 | +6.7 |
| THE ROW IN ITS ORDER | 13 | 3 | 3 | 1.00 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 14 | 14 | 3 | 1.00 | +33 | +11.0 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| EDGE GIVE GROUND | 2 | 2 | 2 | 0.67 | +80 | +40.2 |
| EXACT ROUND | 13 | 13 | 2 | 0.67 | +29 | +14.5 |
| FIGHT TO THE END | 6 | 6 | 2 | 0.67 | +178 | +88.9 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| GUN MASK | 9 | 9 | 2 | 0.67 | +72 | +36.1 |
| HIS TURN DENIED | 6 | 6 | 2 | 0.67 | +72 | +36.1 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -53 | -26.5 |
| MAX FOR POSITIONING | 18 | 17 | 2 | 0.67 | +8 | +3.9 |
| ONE JOINT FIGURE | 2 | 2 | 2 | 0.67 | +28 | +14.2 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHORT GUN FORWARD | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 2 | 2 | 2 | 0.67 | -33 | -16.3 |
| TIED UP BY THE SUM | 2 | 2 | 2 | 0.67 | +63 | +31.6 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +186 | +186.5 |
| BACKUP TARGETS | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -13 | -13.3 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 12 | 12 | 1 | 0.33 | +28 | +28.2 |
| FALLBACK BY WORTH | 1 | 1 | 1 | 0.33 | +2 | +1.7 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +45 | +45.1 |
| MISSILES IN THE MOVE | 28 | 18 | 1 | 0.33 | +16 | +15.8 |
| MISSILES NEXT TURN | 32 | 22 | 1 | 0.33 | +28 | +27.9 |
| NO DOUBLE ROUNDS | 8 | 8 | 1 | 0.33 | +12 | +12.0 |
| OGRE LOADER SECOND SHOT | 1 | 1 | 1 | 0.33 | +108 | +108.0 |
| ONE FIGHT FORMULA | 33 | 22 | 1 | 0.33 | +0 | +0.0 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -216 | -215.6 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +74 | +74.4 |
| RISK BY ARC | 9 | 9 | 1 | 0.33 | +13 | +13.3 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.33 | +69 | +69.0 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +23 | +23.1 |
| SET CREDITED ONCE | 10 | 10 | 1 | 0.33 | +10 | +10.0 |
| SHOT REPLANNED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +4 | +3.9 |
| CANNON PLAN MISSED | 4 | 4 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 4 | trace | - | - | - | - |
| CHAFF IN THE MOVE | 6 | 4 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 6 | 6 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 69 | 68 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 10 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 1 | 1 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 10 | 10 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 27 | not checked | - | - | - | - |
| FOOT FIRST | 56 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 1 | not checked | - | - | - | - |
| FRIEND SHOOTS FIRST | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 16 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 63 | 63 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 24 | 22 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 17 | 17 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 23 | 23 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 19 | 16 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 32 | 30 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 49 | 39 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 4 | 4 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 104 | 104 | 0 | 0.00 | - | - |
| HONEST WORTH | 12 | 12 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 7 | 7 | 0 | 0.00 | - | - |
| LONG SHOT | 3 | 3 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 3 | 3 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MANOEUVRE | 15 | 15 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 1 | not checked | - | - | - | - |
| NEAREST TO GOAL | 2 | 2 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 34 | 24 | 0 | 0.00 | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS A LANE | 3 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 267 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 7 | 6 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 5 | 5 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 7 | 7 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 3 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 2 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 71 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 2 | not checked | - | - | - | - |
| SPELL WORTH | 16 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 41 | 38 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 13 | 12 | 0 | 0.00 | - | - |
| STANDS STILL | 278 | 274 | 0 | 0.00 | - | - |
| STAY WORTH | 134 | 125 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 2 | 2 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 10 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 13 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 6 | not checked | - | - | - | - |
| THE TABLE BINDS | 263 | not checked | - | - | - | - |
| WAITS AGAIN | 13 | 13 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p65

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 7.33 | 1.33 | 39.8 |
| ARMY TABLE | rule | 2.00 | 1.33 | 74.2 |
| PROMISE BY ITS OWN SUM | rule | 2.33 | 0.33 | 96.7 |
| NO REASON | gate | 2.00 | - | 62.3 |
| PROMISE KNOWS THE FIGHT | rule | - | 2.00 | 3.8 |
| CHARGE NOW FIRST | rule | 0.33 | 0.67 | 94.5 |
| HOLDER ASSIGNMENT | rule | 1.00 | - | 23.6 |
| OWN CAST FIRST | rule | 0.67 | 0.33 | 14.0 |
| JOINT CHARGE NOW | rule | - | 0.67 | 120.9 |
| MARCH OF THE TABLE | rule | - | 0.67 | 26.5 |
| PROMISE SHOT AWAY | rule | 0.67 | - | 15.3 |
| CHAFF PASSED | rule | 0.33 | - | 6.9 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 13.3 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 215.6 |
| SET UP BY THE SET | rule | - | 0.33 | 34.6 |
| SWIFTSTRIDE BY POINTS | rule | 0.33 | - | 37.1 |

### Plans: gs3-83c8646-p65

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 25% | 90 | 41 | 46% |
| Mine | join | 0.7 | 100% | 9 | 0 | 0% |
| Mine | move | 28.7 | 98% | 1552 | 0 | 0% |
| Mine | shoot | 12.7 | 58% | 1507 | 1843 | 122% |
| Opponent | charge | 2.3 | 43% | 407 | 68 | 17% |
| Opponent | join | 2.7 | 100% | 100 | 0 | 0% |
| Opponent | move | 35.0 | 93% | 1806 | 0 | 0% |
| Opponent | shoot | 5.0 | 40% | 348 | 273 | 78% |
| Opponent | support | 0.7 | 50% | 0 | 0 | - |

### Battle groups: gs3-83c8646-p65

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 2.0 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p65

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |
| Mine | Character | 12 | 4 (12) | 4 | 0 | 23 | 75% | 3.3 | 0 (4) | 0 (3) | 10 (3) | 7 (6) | 0 (4) |
| Mine | Fast Hammer | 5 | 20 (5) | 10 | 10 | 47 | 20% | 3.2 | 19 (3) | 0 (1) | 38 (1) | 17 (3) | 24 (2) |
| Mine | Hammer | 4 | 28 (4) | 0 | 28 | 0 | 50% | 1.0 | 0 (1) | 40 (3) | - | 0 (3) | 97 (1) |
| Mine | Shooter | 5 | 188 (5) | 157 | 31 | 24 | 0% | 1.0 | 265 (1) | 0 (2) | 304 (2) | 188 (5) | - |
| Mine | War machine | 11 | 46 (11) | 46 | 0 | 27 | 9% | 1.5 | 10 (5) | 76 (6) | - | 0 (2) | 56 (9) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 3.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 19 | 100% | - | 0 (3) | 0 (2) | - | 0 (5) | - |
| Opponent | Character | 11 | 7 (11) | 7 | 0 | 52 | 36% | 2.1 | 0 (3) | 0 (2) | 19 (3) | 16 (4) | 4 (4) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 6 | 48 (6) | 28 | 20 | 27 | 33% | 1.5 | 21 (3) | 88 (3) | - | 42 (4) | 54 (2) |
| Opponent | Fragile | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (2) | - | - | 0 (2) |
| Opponent | Hammer | 4 | 59 (4) | 59 | 0 | 51 | 50% | 2.5 | 0 (2) | 203 (1) | 0 (1) | 85 (3) | 0 (1) |
| Opponent | Holder | 4 | 142 (4) | 0 | 142 | 19 | 75% | 3.0 | - | 161 (1) | 136 (3) | 184 (3) | 0 (1) |
| Opponent | Shooter | 2 | 0 (2) | 0 | 0 | 100 | 0% | 2.0 | - | - | 0 (2) | 0 (1) | 0 (1) |
| Opponent | War machine | 2 | 77 (2) | 77 | 0 | 50 | 0% | 1.0 | - | 77 (2) | - | 79 (1) | 76 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | - | - | 0 (2) | - |

### Charged fights: gs3-83c8646-p65

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 3 | 595 | 31 | 0.7 | 1.0 | 46 | 0 | +46 | 0 of 2 | 2 of 2 | - | +46 |
| Opponent | Grand Cathay | 1 | 336 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Vampire Counts | 1 | 0 | 304 | 4.0 | 1.5 | 76 | 0 | +76 | 3 of 4 | 3 of 4 | +0 | +101 |
| **Opponent** | all armies | 3 | 112 | 101 | 1.3 | 1.5 | 76 | 0 | +76 | 3 of 4 | 3 of 4 | +0 | +101 |

### Effective charges: gs3-83c8646-p65

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +46) | 0 | 0% (0 of 2) |
| Opponent | Vampire Counts | 4 | 1 (net +0) | 0 | 0 | 1 (net +304) | 0 | 2 (net +0) | 0 | 0% (0 of 4) |

### Charged fights, damage counted: gs3-83c8646-p65

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 176 | 139 | +46 | 46 | 42 | +4 | +2.3 |
| Mine | All fights | 2 | 176 | 139 | +46 | 46 | 42 | +4 | +2.3 |
| Opponent | Long shot (under 50%) | 1 | 50 | 125 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 76-89% | 1 | 186 | 202 | +304 | 304 | 0 | +304 | +163.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 236 | 265 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | All fights | 4 | 177 | 214 | +76 | 76 | 0 | +76 | +42.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p65 | move | 18 | 1 (6%) | 0 (0%) | 2 (11%) | 15 (83%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0827 |
| Invocation of Nehek | Opponent | L0827 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Jet | Opponent | L0810 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721 |
| Twice-Blessed Armour | Opponent | L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |

# Doctrine scorecard: gs3-83c8646-p79

### Scorecard: gs3-83c8646-p79

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1122 | 6 | 1 | Mine | no | 5 | 4 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1122 | 6 | 1 | Opponent | no | 4 | 3 | 3 | 0 | 0 | 0 | 0 | 72 |
| L1216 | 4 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1216 | 4 | 1 | Opponent | no | 0 | - | 0 | 0 | 1 | 0 | 0 | 200 |
| L1232 | 2 | 1 | Mine | - | - | 4 | 3 | 0 | 0 | 0 | 0 | 165 |
| L1232 | 2 | 1 | Opponent | - | - | 4 | 3 | 4 | 0 | 0 | 0 | 170 |
| **Average** | | | Mine | 0% | 2.5 | 3.3 | 2.7 | 0.0 | 0.0 | 0.0 | 0.0 | 165.0 |
| **Average** | | | Opponent | 0% | 2.0 | 3.5 | 2.0 | 1.3 | 0.3 | 0.0 | 0.0 | 147.3 |

### KPIs: gs3-83c8646-p79

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 20% (3 of 15) | 0% (0 of 12) | 11% (3 of 27) |
| Winner chose to follow up after the loser gave ground |  | 67% (2 of 3); on the table 100% | 100% (2 of 2); on the table 100% | 80% (4 of 5); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | 0% (0 of 1); on the table 0% | 50% (1 of 2); on the table 50% |
| Winner chose to pursue after the loser fled |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 75% (3 of 4); on the table 100% | 75% (3 of 4); on the table 75% | 75% (6 of 8); on the table 88% |
| Magic missiles tried each own turn | 50%+ | 27% (16 of 60) | 0% (0 of 6) | 24% (16 of 66) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 29% (16 of 56) | 0% (0 of 6) | 26% (16 of 62) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 82% (9 of 11) | 82% (9 of 11) |
| Points that never fought | lower | 45% (2706 of 5999) | 46% (2780 of 5999) | 46% (5486 of 11998) |
|   infantry points that never fought | lower | 44% (291 of 656) | 94% (1064 of 1127) | 76% (1355 of 1783) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 69% (18 of 26) | 63% (12 of 19) | 67% (30 of 45) |
| Bound items with a magic missile used (at least once a game) |  | 88% (7 of 8); 7.0 uses a game | 0.0 uses a game | 88% (7 of 8); 3.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 33% (1 of 3); 0.3 uses a game | 100% (1 of 1); 0.3 uses a game | 50% (2 of 4); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 69% (4027 of 5807) | 60% (2906 of 4858) | 65% (6933 of 10665) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 5.0 (34%) | 2.0 (100%) | 7.0 (42%) |
| MARCHED: its unit marched | 5.7 (39%) | 0.0 (0%) | 5.7 (34%) |
| CHARGED: its unit charged | 2.0 (14%) | 0.0 (0%) | 2.0 (12%) |
| IN COMBAT: engaged in combat | 1.0 (7%) | 0.0 (0%) | 1.0 (6%) |
| GONE: slain | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.7 (5%) | 0.0 (0%) | 0.7 (4%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 6.7 | 0.7 | 3.7 | 5.3 | 1.3 | 1.7 |
| not cast | 1.3 | 1.3 | 0.3 | 16.7 | 6.7 | 26.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (25%) | 0.0 (0%) | 7.0 (42%) | 1.7 (25%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 5.7 (34%) | 1.3 (20%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (12%) | 1.0 (15%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.3 (100%) | 1.0 (6%) | 0.3 (5%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) | 0.0 (0%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (25%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 1.0 (75%) | 0.0 (0%) | 0.7 (4%) | 2.3 (35%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.0 (75%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 25.3 (96%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 3.7 a game | 0.0 a game | 1.8 a game |
| stood (cast and not dispelled) | 45% (5 of 11) | - | 45% (5 of 11) |
| the unit moved after it | 60% (3 of 5) | - | 60% (3 of 5) |
| it charged on its next turn | 0% (0 of 5) | - | 0% (0 of 5) |
| the enemy charged it first | 40% (2 of 5) | - | 40% (2 of 5) |
| it fought by the end of its next turn | 0% (0 of 5) | - | 0% (0 of 5) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 5) | - | 0% (0 of 5) |
| none of these (no charge, no fight, no charge escaped) | 60% (3 of 5) | - | 60% (3 of 5) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 79% (30 of 38) | 62% (48 of 78) | 67% (78 of 116) |
|   cavalry | - | 72% (13 of 18) | 72% (13 of 18) |
|   character | - | 0% (0 of 15) | 0% (0 of 15) |
|   chariot | 80% (4 of 5) | 100% (5 of 5) | 90% (9 of 10) |
|   infantry | 83% (5 of 6) | 68% (21 of 31) | 70% (26 of 37) |
|   war machine | 78% (21 of 27) | 100% (9 of 9) | 83% (30 of 36) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.7 (25%) | 0.3 (3%) | 1.0 (8%) |
| CHARGED: it charged | 0.0 (0%) | 2.3 (23%) | 2.3 (18%) |
| IN COMBAT: it fought this turn or the last | 0.3 (12%) | 0.3 (3%) | 0.7 (5%) |
| MOVED: a war machine that moved | 1.0 (38%) | 0.0 (0%) | 1.0 (8%) |
| NO TARGET IN RANGE | 0.0 (0%) | 4.7 (47%) | 4.7 (37%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 1.7 (17%) | 1.7 (13%) |
| SHELTERED: the target was sheltered | 0.3 (12%) | 0.0 (0%) | 0.3 (3%) |
| STUPIDITY | 0.0 (0%) | 0.7 (7%) | 0.7 (5%) |
| OTHER BAR | 0.3 (12%) | 0.0 (0%) | 0.3 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.3 | 1.7 | 77% | 4.1 pts | 30 pts |
| chariot | 3.0 | 0.3 | 89% | 0.5 pts | 2 pts |
| infantry | 12.0 | 3.0 | 81% | 4.6 pts | 55 pts |
| war machine | 11.0 | 12.0 | 58% | 32.6 pts | 359 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 4.0 | 3.5 |
| Charges that made contact a game | 2.0 | 2.7 | 2.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.50 contact (6 units) | - | 1.00 declared, 0.50 contact (6 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 1.00 contact (1 units) | - | 1.00 declared, 1.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.22 declared, 0.22 contact (9 units) | 0.44 declared, 0.30 contact (27 units) | 0.39 declared, 0.28 contact (36 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 71% (5 of 7) | - | 0% (0 of 1) | 62% (5 of 8) |
| Character on its own | 100% (1 of 1) | 78% (7 of 9) | 75% (6 of 8) | 78% (14 of 18) |
| Chariot | 100% (1 of 1) | - | - | 100% (1 of 1) |
| Infantry | 60% (3 of 5) | 0% (0 of 2) | - | 43% (3 of 7) |
| Monster | 25% (1 of 4) | - | - | 25% (1 of 4) |
| Monstrous | 100% (1 of 1) | - | - | 100% (1 of 1) |
| War Machines | 83% (5 of 6) | - | - | 83% (5 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 3 | 75% (3 of 4); on the table 100% | 27% (16 of 60) | 45% | 69% (18 of 26) | 88% (7 of 8); 7.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Kingdom of Bretonnia | 1 | - | - | 82% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 6) | 38% | 20% (1 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 50% (1 of 2); on the table 50% | - | 18% | 88% (7 of 8) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p79, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 86% (6) | 75% (3) | 82% (9) |
| ...free all their last turn and able to turn (per game) | 1.00 | 1.00 | 2.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 1.00 | 0.00 | 1.00 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 1.00 | 1.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 1.00 | 1.00 |

### Quality by phase: gs3-83c8646-p79

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 5.7 | 2.3 |
| Strategy | Charge objectives carried out (made contact) | 56% (5 of 9) | 60% (6 of 10) |
| Strategy | Shoot objectives carried out (shot that target) | 31% (10 of 32) | 44% (8 of 18) |
| Strategy | Support requests answered (helper made contact too) | - | 50% (1 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 2) | - |
| Strategy | Joined characters whose unit fought | - | 0% (0 of 3) |
| Strategy | Lone characters that fought | 58% (7 of 12) | 71% (5 of 7) |
| Movement | Charges halted short of contact | 1.0 | 0.7 |
| Movement | Idle units | 0.0 | 1.3 |
| Movement | Points that never moved of their own | 165.0 | 147.3 |
| Movement | Fights charged into per game | 2.0 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 5 | 0 of 4 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 5, net +100 | 0 of 4 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 5, net +80 | 0 of 4 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 5, net +0 | 3 of 4, net +218 |
| Shooting | Shots by shooting units (incl. breath weapons) | 3.0 | 16.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (4 of 9) | 40% (19 of 48) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 7.3 | 3.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 41% (9 of 22) | 33% (3 of 9) |
| Shooting | Points destroyed by war machines | 24.0 | 55.0 |
| Magic | Magic missiles cast | 4.3 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 38% (5 of 13) | - |
| Magic | Wounds caused by magic missiles | 7.7 | - |
| Magic | Wounds caused by other spells | 1.0 | - |
| Magic | Points destroyed by magic (all spells) | 102.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.3 / 0.7 / 0.7 / 1.0 | 3.3 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 26.7 | 383.0 |
| Combat | Points run down | 0.0 | 73.7 |
| Combat | Net points per charged fight, damage counted | +110 | +238 |
| Combat | Net per 100 charger points, damage counted | +39.0 | +61.4 |
| Combat | First round won (charged fights) | 100% | 100% |
| Combat | Net points per charged fight | +53 | +207 |
| Combat | Net points per supported fight / lone fight | - / +53 | +0 / +242 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 6 | 2 of 7 |
| Game | Points lost | 663.0 | 305.0 |
| Game | VP from objectives | 476.7 | 443.3 |
| Game | Lone holders (player turns) | 2.5 | 2.0 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -376 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 968
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p79

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +44.8 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 15.0 | +21.9 | 0.0 | 219.3 | 26.0 | +524.4 | 0.0 | 69.7 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -89.3 | 73.7 | 0.0 |
| BOMBING RUN | 0.3 | +9.0 | 0.0 | 50.0 | - | - | - | - |
| CANNON PLANNED TARGET | 6.7 | +52.4 | 24.0 | 330.0 | 3.0 | +146.3 | 55.0 | 33.3 |
| CANNON SIGHT KEPT | 3.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 3.3 | +182.7 | 369.3 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 3.7 | +77.1 | 0.0 | 46.7 |
| CHALLENGE BY POINTS | - | - | - | - | 0.7 | +42.5 | 0.0 | 46.3 |
| CHARGE LOSSES | 21.3 | -876.4 | 0.0 | 834.7 | 25.3 | -843.9 | 0.0 | 276.0 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 3.0 | +0.0 | 257.0 | 0.0 | 2.3 | +0.0 | 298.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 2.7 | +0.0 | 0.0 | 0.0 | 10.7 | +0.0 | 0.0 | 24.0 |
| COMBAT PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 3.3 | +231.5 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 7.3 | -661.8 | 0.0 | 178.7 | 9.3 | -930.3 | 0.0 | 184.3 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -2.9 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 5.0 | -32.6 | 0.0 | 0.0 | 7.7 | +106.3 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.7 | +12.2 | 72.3 | 0.0 | 0.7 | +57.4 | 174.3 | 0.0 |
| EXACT ROUND | 2.3 | +6.2 | 26.7 | 0.0 | 3.0 | +20.1 | 358.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.0 | +4.6 | 45.7 | 0.0 | 2.7 | +19.6 | 169.3 | 0.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 0.7 | +4.8 | 0.0 | 0.0 | 23.7 | +197.6 | 0.0 | 256.7 |
| FEATURE BUFFS | 1.0 | +40.4 | 0.0 | 0.0 | 0.7 | +15.0 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +0.6 | 0.0 | 0.0 | 0.3 | +15.4 | 0.0 | 0.0 |
| FIVE ACTION | 79.0 | +4467.6 | 489.7 | 1814.7 | 93.3 | +4503.5 | 568.0 | 504.0 |
| FLANK NOT WEIGHED | 7.0 | +0.0 | 0.0 | 243.0 | 9.0 | +0.0 | 0.0 | 194.3 |
| FOLLOW UP WEIGHED | 0.7 | +74.8 | 0.0 | 0.0 | 0.7 | +250.3 | 0.0 | 0.0 |
| FOOT FIRST | 18.3 | +0.0 | 0.0 | 568.7 | - | - | - | - |
| FOUR ROUNDS | 3.0 | +249.5 | 72.3 | 0.0 | 4.0 | +457.6 | 408.0 | 0.0 |
| FREED FROM HIS FIGHT | 2.0 | +0.0 | 0.0 | 110.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 1.7 | -90.2 | 0.0 | 26.7 |
| GIVES UP | 0.3 | -1.1 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 8.0 | +403.5 | 0.0 | 0.0 | 9.3 | +1098.9 | 0.0 | 45.7 |
| GUN MASK | 2.0 | +11.3 | 0.0 | 0.0 | 2.0 | +62.5 | 0.0 | 0.0 |
| HARD STAY DROPPED | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 0.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 12.7 | +0.0 | 0.0 | 605.3 | 13.0 | +0.0 | 0.0 | 276.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +3.4 | 0.0 | 0.0 |
| HIS CHARGE LIST | 9.3 | +0.0 | 0.0 | 238.7 | 14.0 | +0.0 | 0.0 | 26.7 |
| HIS LEGAL MOVES | 7.3 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.7 | -16.8 | 0.0 | 119.3 | 16.7 | -197.1 | 0.0 | 74.7 |
| HIS ONE QUARTER | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 9.7 | +0.0 | 0.0 | 0.0 | 9.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 8.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.7 | +0.0 | 0.0 | 110.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 31.7 | +1950.5 | 0.0 | 944.7 | 64.3 | +3498.2 | 0.0 | 380.0 |
| HIS SHOTS BY HIS RUN | 29.0 | +522.8 | 0.0 | 834.7 | 51.7 | +637.9 | 0.0 | 404.0 |
| HIS TURN DENIED | - | - | - | - | 0.7 | +26.8 | 110.0 | 0.0 |
| HOLD ODDS | 14.7 | +0.0 | 0.0 | 386.0 | 15.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 9.0 | +914.5 | 0.0 | 193.0 | 11.0 | +957.3 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.0 | -126.3 | 72.3 | 0.0 | 3.7 | -130.6 | 408.0 | 0.0 |
| HUNT IN PAIRS | 2.0 | +101.3 | 0.0 | 0.0 | 0.7 | +1.9 | 0.0 | 0.0 |
| IDLE COST | 0.3 | -4.4 | 0.0 | 0.0 | 17.3 | -335.4 | 0.0 | 24.0 |
| JOINT CHARGE NOW | - | - | - | - | 1.7 | +13.4 | 110.0 | 0.0 |
| KEEP FALLS | 0.3 | +4.7 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 0.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.0 | +5.1 | 0.0 | 0.0 | 1.7 | +108.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 1.0 | +0.0 | 0.0 | 236.3 | 4.3 | +0.0 | 0.0 | 133.3 |
| LONE WIZARD KEPT IN | 0.3 | +15.9 | 0.0 | 0.0 | 1.0 | +85.4 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.0 | +0.1 | 0.0 | 0.0 | 2.3 | +13.4 | 73.7 | 0.0 |
| MAKE SURE TOGETHER | 0.7 | +2.1 | 0.0 | 0.0 | 0.3 | +0.2 | 0.0 | 0.0 |
| MANOEUVRE | 0.7 | +6.2 | 0.0 | 50.0 | 0.7 | +9.4 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 1.0 | +4.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 1.3 | +140.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 2.0 | +77.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 1.7 | +46.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 4.3 | +483.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 8.0 | +205.5 | 0.0 | 0.0 | 3.7 | +57.8 | 0.0 | 63.3 |
| MEETS IN TIME | 1.3 | +218.9 | 0.0 | 0.0 | 2.3 | +190.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 10.3 | +289.8 | 0.0 | 73.7 | 0.7 | +0.8 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 16.0 | +210.0 | 0.0 | 73.7 | 1.3 | +0.9 | 0.0 | 0.0 |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 6.0 | +335.2 | 0.0 | 0.0 | 6.7 | +840.5 | 0.0 | 24.0 |
| NEARER NOT NEEDED | 2.3 | +101.0 | 0.0 | 119.3 | 7.0 | +257.3 | 0.0 | 0.0 |
| NEAREST TO GOAL | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 4.3 | +270.7 | 0.0 | 0.0 | 6.0 | +784.3 | 0.0 | 24.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 1.0 | -134.6 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 3.0 | -129.9 | 72.3 | 0.0 | 3.7 | -211.1 | 408.0 | 0.0 |
| NO LATE CUT | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.3 | +27.3 | 0.0 | 0.0 | 0.3 | +0.9 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 1.0 | -22.5 | 0.0 | 10.0 |
| NOT WORTH A CAST | 1.0 | -0.3 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 6.3 | -147.5 | 0.0 | 325.0 | 10.0 | -379.7 | 0.0 | 70.0 |
| OGRE LOADER SECOND SHOT | 3.3 | +36.7 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1.3 | +0.0 | 0.0 | 193.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 7.7 | -159.6 | 0.0 | 0.0 | 6.0 | -119.1 | 0.0 | 116.3 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | +100.6 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 4.3 | -18.4 | 0.0 | 193.0 | 3.0 | +39.9 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | -33.0 | 0.0 | 0.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +8.5 | 26.7 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | - | - | - | - | 0.7 | +14.2 | 73.7 | 0.0 |
| OWN CAST FIRST | 0.7 | -6.2 | 0.0 | 0.0 | - | - | - | - |
| PATHS CROSS | 0.3 | -2.0 | 0.0 | 0.0 | 0.3 | +78.2 | 0.0 | 0.0 |
| PLAN RESULT | 35.0 | +447.3 | 24.0 | 1117.3 | 45.0 | +461.0 | 248.0 | 490.7 |
| PROMISE BELOW ZERO | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 9.3 | -161.0 | 0.0 | 0.0 | 7.3 | -180.8 | 0.0 | 0.0 |
| PROMISE HOLDS THE SPOT | - | - | - | - | 0.3 | +16.4 | 0.0 | 24.0 |
| PROMISE KNOWS THE FIGHT | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 24.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.7 | -14.7 | 0.0 | 26.7 |
| PROMISE SHOT AWAY | - | - | - | - | 0.3 | -14.0 | 0.0 | 0.0 |
| QUARTER ODDS | 7.3 | +1324.3 | 0.0 | 0.0 | 8.0 | +951.7 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.7 | +97.8 | 0.0 | 0.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 3.7 | +79.5 | 0.0 | 46.7 |
| REDIRECT COUNTER | - | - | - | - | 3.3 | +268.1 | 0.0 | 63.3 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 5.3 | +122.4 | 0.0 | 97.3 |
| REDIRECT WEIGHED | 0.3 | +36.2 | 46.3 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 3.3 | -73.1 | 0.0 | 0.0 | 2.0 | -67.6 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.7 | +6.8 | 0.0 | 50.0 | 2.3 | +82.7 | 0.0 | 53.3 |
| RISK BY ARC | 2.7 | +140.2 | 72.3 | 0.0 | 2.3 | -151.6 | 298.0 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.7 | -9.6 | 45.7 | 0.0 | 3.3 | -112.4 | 408.0 | 0.0 |
| RUN DOWN | 1.7 | -15.4 | 72.3 | 0.0 | 3.3 | -61.2 | 279.3 | 0.0 |
| SCOUT SPOT | - | - | - | - | 0.7 | +0.9 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -66.5 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +2.8 | 0.0 | 0.0 | 0.3 | +1.9 | 0.0 | 26.7 |
| SECOND LOOK | - | - | - | - | 0.3 | +18.8 | 55.0 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 3.3 | -162.5 | 0.0 | 104.0 |
| SET UP BY THE SET | 2.0 | +5.2 | 0.0 | 0.0 | 6.3 | -67.9 | 50.0 | 104.0 |
| SET UP TOGETHER | 0.7 | +2.1 | 0.0 | 0.0 | 0.3 | +0.2 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 1.3 | +110.1 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 10.0 | +0.0 | 0.0 | 330.0 | 6.3 | +0.0 | 0.0 | 60.0 |
| SHOOTS FROM THE BEST SPOT | 3.3 | +50.7 | 0.0 | 0.0 | 1.7 | +7.6 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -2.1 | 0.0 | 0.0 | 0.3 | -4.3 | 50.0 | 0.0 |
| SHOT RISK POINTS | 25.0 | +650.5 | 0.0 | 558.7 | 40.0 | +60.2 | 0.0 | 101.3 |
| SHOTS AFTER THE MOVES | 5.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 11.3 | +398.1 | 0.0 | 545.0 | 16.3 | +341.4 | 0.0 | 86.7 |
| SPELL SETS UP CHARGE | 1.3 | +110.1 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 2.7 | +47.5 | 0.0 | 0.0 | 2.0 | +52.1 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | +16.3 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 4.7 | +0.0 | 0.0 | 73.7 | 6.7 | +0.0 | 0.0 | 36.7 |
| STAND AND SHOOT | 0.3 | -0.5 | 26.7 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | - | - | - | - | 8.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 32.3 | +0.0 | 417.3 | 1090.0 | 27.0 | +0.0 | 160.0 | 100.0 |
| STAY WORTH | 21.3 | -353.9 | 92.3 | 810.0 | 20.7 | +9.0 | 160.0 | 133.3 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| STUBBORN BY POINTS | 0.3 | +4.8 | 0.0 | 55.0 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 7.3 | +774.5 | 0.0 | 100.0 | 1.3 | +114.9 | 0.0 | 53.3 |
| SUPPORT NARROWED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 7.3 | +774.5 | 0.0 | 100.0 | 1.3 | +114.9 | 0.0 | 53.3 |
| SURE REACH TOGETHER | 1.3 | +20.7 | 0.0 | 0.0 | 0.7 | +11.8 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 3.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 35.3 | +0.0 | 0.0 | 692.3 | 41.7 | +0.0 | 0.0 | 248.7 |
| TIED UP BY THE SUM | 1.7 | +169.5 | 72.3 | 0.0 | 1.0 | +150.0 | 105.0 | 0.0 |
| TIME ON OUR SIDE | 30.7 | +559.1 | 0.0 | 651.0 | 6.7 | +34.6 | 0.0 | 0.0 |
| WAITS AGAIN | 3.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | +4.9 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 1.3 | +0.0 | 0.0 | 100.0 | - | - | - | - |
| WEAPON BY POINTS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | - | - | - | - | 0.3 | -3.1 | 119.3 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +46.7 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 5.3 | -459.5 | 0.0 | 496.0 | 1.7 | -175.6 | 0.0 | 276.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.7 | +45.9 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 5.3 | +44.5 | 0.0 | 238.7 | - | - | - | - |

### Rule changes: gs3-83c8646-p79

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 123 | 123 | 76 | 25.33 | +2030 | +26.7 |
| HIS SHOT LIST | 288 | 274 | 73 | 24.33 | +1720 | +23.6 |
| HOLDER ASSIGNMENT | 60 | 60 | 55 | 18.33 | +3722 | +67.7 |
| OFF BEST | 49 | 49 | 49 | 16.33 | -1581 | -32.3 |
| HIS SHOTS BY HIS RUN | 242 | 230 | 34 | 11.33 | +376 | +11.1 |
| FIVE ACTION | 517 | 494 | 29 | 9.67 | +1800 | +62.1 |
| DEPLOY BY FIGURES | 38 | 38 | 23 | 7.67 | +499 | +21.7 |
| SHOT RISK POINTS | 195 | 186 | 23 | 7.67 | +918 | +39.9 |
| MOVE TO CHARGE COMPUTED | 38 | 27 | 20 | 6.67 | +1304 | +65.2 |
| THE TABLE AGAIN | 36 | 36 | 20 | 6.67 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 31 | 26 | 19 | 6.33 | +1297 | +68.3 |
| PROMISE BY ITS OWN SUM | 50 | 50 | 18 | 6.00 | -1025 | -57.0 |
| LEGAL CHARGES ONLY | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| FOUR ROUNDS | 21 | 21 | 14 | 4.67 | +864 | +61.7 |
| GOAL WALK | 52 | 52 | 14 | 4.67 | +931 | +66.5 |
| SET UP BY THE SET | 25 | 24 | 13 | 4.33 | +161 | +12.4 |
| SUPPORT ADDS | 26 | 24 | 13 | 4.33 | +938 | +72.1 |
| SUPPORT WORKED OUT | 26 | 24 | 13 | 4.33 | +938 | +72.1 |
| TIME ON OUR SIDE | 112 | 79 | 13 | 4.33 | +41 | +3.1 |
| COVER ONCE | 50 | 31 | 12 | 4.00 | +245 | +20.4 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 16 | 16 | 12 | 4.00 | +180 | +15.0 |
| CANNON SIGHT KEPT | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 15 | 15 | 11 | 3.67 | +53 | +4.8 |
| OGRE LOADER SECOND SHOT | 10 | 10 | 10 | 3.33 | +110 | +11.0 |
| CAST JOB | 10 | 10 | 9 | 3.00 | +106 | +11.8 |
| RANDOM MOVE BY FIGURES | 11 | 11 | 9 | 3.00 | +294 | +32.6 |
| RESERVE FALL BACK | 9 | 9 | 9 | 3.00 | +268 | +29.8 |
| HARD STAY DROPPED | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| LANE BY FIGURES | 8 | 8 | 8 | 2.67 | +340 | +42.4 |
| MAX FOR POSITIONING | 35 | 32 | 8 | 2.67 | +17 | +2.2 |
| SHOTS AFTER THE MOVES | 28 | 28 | 8 | 2.67 | +0 | +0.0 |
| TIED UP BY THE SUM | 8 | 8 | 8 | 2.67 | +131 | +16.4 |
| ARTILLERY RE-ROLL WEIGHED | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| HOLDS AMBUSHERS | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| MISSILES IN THE MOVE | 33 | 26 | 7 | 2.33 | +327 | +46.7 |
| CANNON PLANNED TARGET | 29 | 29 | 6 | 2.00 | +0 | +0.0 |
| MEETS IN TIME | 11 | 11 | 6 | 2.00 | +691 | +115.2 |
| CHARGE NOW FIRST | 16 | 16 | 5 | 1.67 | -277 | -55.3 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | +40 | +8.0 |
| MARCH OF THE TABLE | 5 | 5 | 5 | 1.67 | -140 | -28.0 |
| NEARER NOT NEEDED | 28 | 28 | 5 | 1.67 | +141 | +28.3 |
| CHAFF IN THE MOVE | 11 | 11 | 4 | 1.33 | +67 | +16.8 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +975 | +243.8 |
| IDLE COST | 53 | 41 | 4 | 1.33 | +36 | +9.0 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +304 | +76.0 |
| MANOEUVRE | 4 | 4 | 4 | 1.33 | +47 | +11.6 |
| MARCH BY THE SUM | 4 | 4 | 4 | 1.33 | +420 | +104.9 |
| MARCH CHECK | 6 | 6 | 4 | 1.33 | +45 | +11.2 |
| QUARTER ODDS | 46 | 46 | 4 | 1.33 | +366 | +91.5 |
| RISK BY ARC | 15 | 15 | 4 | 1.33 | +49 | +12.3 |
| THE ROW IN ITS ORDER | 16 | 4 | 4 | 1.33 | +0 | +0.0 |
| WAR ENGINE JOBS | 4 | 4 | 4 | 1.33 | -152 | -38.0 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHARGE LOSSES | 140 | 134 | 3 | 1.00 | +246 | +82.0 |
| FALLS SHORT | 73 | 61 | 3 | 1.00 | +65 | +21.7 |
| STAY WORTH | 126 | 107 | 3 | 1.00 | +14 | +4.8 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +127 | +63.7 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| EXACT ROUND | 16 | 16 | 2 | 0.67 | +6 | +3.1 |
| GUN MASK | 12 | 10 | 2 | 0.67 | +54 | +27.2 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.67 | +50 | +24.9 |
| ONE FIGHT FORMULA | 41 | 24 | 2 | 0.67 | +34 | +17.1 |
| ONE OBJECTIVE FORMULA | 22 | 17 | 2 | 0.67 | +125 | +62.4 |
| OWN CAST FIRST | 2 | 2 | 2 | 0.67 | -19 | -9.4 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +229 | +114.4 |
| REDIRECT COUNTER | 10 | 8 | 2 | 0.67 | +228 | +113.8 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SEARCH SPOT | 2 | 2 | 2 | 0.67 | +14 | +7.0 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SUPPORT NARROWED | 2 | 2 | 2 | 0.67 | -223 | -111.5 |
| SURE REACH TOGETHER | 6 | 5 | 2 | 0.67 | +2 | +0.9 |
| WEAPON BY POINTS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 16 | 16 | 2 | 0.67 | +5 | +2.5 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +134 | +134.3 |
| BOMBING RUN | 1 | 1 | 1 | 0.33 | +27 | +27.1 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -31 | -30.9 |
| EDGE GIVE GROUND | 4 | 4 | 1 | 0.33 | +2 | +1.6 |
| FALL BACK GOOD ORDER | 14 | 14 | 1 | 0.33 | +2 | +1.6 |
| FEATURE BUFFS | 5 | 5 | 1 | 0.33 | +22 | +22.4 |
| HUNT IN PAIRS | 8 | 4 | 1 | 0.33 | +19 | +19.4 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +112 | +111.6 |
| NEXT OBJECTIVE NEARER | 3 | 1 | 1 | 0.33 | +11 | +11.4 |
| NO DOUBLE ROUNDS | 20 | 20 | 1 | 0.33 | +2 | +1.6 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -99 | -99.1 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +10 | +10.3 |
| PROMISE HOLDS THE SPOT | 1 | 1 | 1 | 0.33 | +49 | +49.2 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -42 | -42.1 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +246 | +245.5 |
| ROUNDS AFTER TERROR | 12 | 12 | 1 | 0.33 | +2 | +1.6 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +56 | +56.3 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +4 | +4.0 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +1 | +0.9 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +14 | +14.3 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | +15 | +14.7 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +123 | +123.2 |
| WHOLE FIGHT DANGER | 21 | 21 | 1 | 0.33 | +150 | +150.3 |
| WHOLE FIGHT GAIN | 2 | 2 | 1 | 0.33 | +31 | +30.9 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 5 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 40 | 40 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 10 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 48 | not checked | - | - | - | - |
| FOOT FIRST | 55 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 18 | 18 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 5 | 3 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 14 | 14 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 77 | 74 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 70 | 67 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 44 | 40 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 64 | 61 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 12 | 12 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 58 | 51 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 24 | 20 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 8 | 8 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HOLD ODDS | 91 | 90 | 0 | 0.00 | - | - |
| HONEST WORTH | 20 | 20 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 12 | 11 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 10 | 10 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 3 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 13 | 13 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 52 | 37 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 5 | not checked | - | - | - | - |
| NEAREST TO GOAL | 4 | 4 | 0 | 0.00 | - | - |
| NO LATE CUT | 5 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 3 | 3 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 3 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 7 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 2 | 2 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 240 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 6 | 3 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 11 | 11 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 16 | 13 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 15 | 15 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 10 | 9 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 3 | 2 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 4 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 49 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SHOTS IN THE MOVE | 83 | 58 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 4 | not checked | - | - | - | - |
| SPELL WORTH | 14 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 34 | 28 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 24 | 19 | 0 | 0.00 | - | - |
| STANDS STILL | 178 | 168 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 11 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 19 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 9 | not checked | - | - | - | - |
| THE TABLE BINDS | 231 | not checked | - | - | - | - |
| WAITS AGAIN | 14 | 12 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p79

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 6.33 | 7.67 | 26.3 |
| PROMISE BY ITS OWN SUM | rule | 4.00 | 2.00 | 57.0 |
| ARMY TABLE | rule | 1.33 | 2.33 | 66.5 |
| RULE SWITCHED OFF | gate | - | 2.00 | 68.0 |
| CHARGE NOW FIRST | rule | 0.67 | 1.00 | 55.3 |
| MARCH OF THE TABLE | rule | 1.67 | - | 28.0 |
| HOLDER ASSIGNMENT | rule | 0.33 | 1.00 | 6.5 |
| WAR ENGINE JOBS | rule | 1.33 | - | 38.0 |
| JOINT CHARGE NOW | rule | - | 0.67 | 70.0 |
| OWN CAST FIRST | rule | 0.67 | - | 9.4 |
| SUPPORT NARROWED | rule | 0.67 | - | 111.5 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 30.9 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 99.1 |
| PATHS CROSS | rule | 0.33 | - | 5.9 |
| PROMISE SHOT AWAY | rule | - | 0.33 | 42.1 |
| TURN GATE | gate | - | 0.33 | 66.9 |

### Plans: gs3-83c8646-p79

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.0 | 33% | 183 | 115 | 63% |
| Mine | move | 24.0 | 97% | 1529 | 0 | 0% |
| Mine | shoot | 9.0 | 30% | 640 | 332 | 52% |
| Opponent | charge | 2.3 | 57% | 479 | 304 | 63% |
| Opponent | move | 35.3 | 95% | 1615 | 0 | 0% |
| Opponent | shoot | 5.3 | 50% | 243 | 157 | 64% |
| Opponent | support | 2.0 | 83% | 56 | 0 | 0% |

### Battle groups: gs3-83c8646-p79

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 3.3 | 10% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p79

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 12 | 11 (12) | 11 | 0 | 12 | 17% | 2.5 | 35 (3) | 4 (7) | - | 14 (9) | 0 (1) |
| Mine | Clean-up | 2 | 173 (2) | 0 | 173 | 61 | 0% | 2.5 | 158 (1) | 186 (1) | - | 173 (2) | - |
| Mine | Fast Hammer | 2 | 24 (2) | 0 | 24 | 100 | 0% | 3.0 | - | 0 (1) | 34 (1) | 24 (2) | - |
| Mine | Holder | 2 | 0 (2) | 0 | 0 | 67 | 0% | 3.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Shooter | 4 | 80 (4) | 50 | 29 | 0 | 0% | 2.5 | 17 (1) | 104 (3) | - | 111 (3) | 0 (1) |
| Mine | War machine | 6 | 7 (6) | 7 | 0 | 83 | 0% | 1.2 | 22 (2) | 0 (4) | - | 0 (1) | 9 (5) |
| Opponent | Chaff | 7 | 48 (7) | 0 | 48 | 60 | 29% | 1.4 | 0 (2) | 71 (4) | 0 (1) | 58 (6) | 0 (1) |
| Opponent | Character | 7 | 17 (7) | 17 | 0 | 10 | 29% | 2.8 | 0 (1) | 0 (3) | 40 (3) | 27 (5) | 0 (2) |
| Opponent | Clean-up | 2 | 52 (2) | 0 | 52 | 0 | 50% | 4.0 | - | 52 (2) | - | 52 (2) | - |
| Opponent | Fast Hammer | 4 | 146 (4) | 146 | 0 | 21 | 25% | 5.3 | 0 (1) | 249 (2) | 0 (1) | 184 (3) | 0 (1) |
| Opponent | Hammer | 4 | 98 (4) | 78 | 20 | 0 | 50% | 3.5 | - | 98 (4) | - | 142 (3) | 45 (1) |
| Opponent | Holder | 5 | 104 (5) | 0 | 104 | 37 | 0% | 2.6 | 382 (1) | 93 (2) | 0 (2) | 236 (3) | 0 (2) |
| Opponent | Shooter | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 0% | 4.0 | 0 (1) | - | - | - | 0 (1) |
| Opponent | War machine | 2 | 82 (2) | 82 | 0 | 50 | 0% | 1.0 | 82 (2) | - | - | - | 82 (2) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 33% | 1.0 | - | 0 (3) | - | - | 0 (3) |

### Charged fights: gs3-83c8646-p79

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 3 | 126 | 106 | 2.0 | 1.0 | 53 | 0 | +53 | 0 of 6 | 6 of 6 | - | +53 |
| Opponent | Kingdom of Bretonnia | 1 | 165 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 1450 | 5.0 | 1.0 | 290 | 0 | +290 | 1 of 5 | 5 of 5 | - | +290 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 2.0 | 1.5 | 0 | 0 | +0 | 1 of 2 | 2 of 2 | +0 | +0 |
| **Opponent** | all armies | 3 | 55 | 483 | 2.3 | 1.1 | 207 | 0 | +207 | 2 of 7 | 7 of 7 | +0 | +242 |

### Effective charges: gs3-83c8646-p79

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 6 | 0 | 0 | 1 (net +100) | 0 | 1 (net +80) | 3 (net +0) | 1 | 20% (1 of 5) |
| Opponent | Tomb Kings of Khemri | 5 | 0 | 0 | 0 | 1 (net +165) | 0 | 1 (net +654) | 3 | 0% (0 of 2) |
| Opponent | Warriors of Chaos | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +0) | 0 | 0% (0 of 2) |

### Charged fights, damage counted: gs3-83c8646-p79

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 379 | 275 | +100 | 526 | 166 | +360 | +95.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 252 | 136 | +0 | 26 | 0 | +26 | +10.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 334 | 80 | +80 | 80 | 0 | +80 | +24.0 |
| Mine | No odds | 1 | 217 | 139 | +139 | 139 | 0 | +139 | +64.1 |
| Mine | All fights | 6 | 281 | 150 | +53 | 137 | 28 | +110 | +39.0 |
| Opponent | 76-89% | 1 | 431 | 165 | +165 | 165 | 0 | +165 | +38.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 415 | 260 | +218 | 308 | 18 | +290 | +69.8 |
| Opponent | No odds | 3 | 346 | 162 | +210 | 210 | 0 | +210 | +60.8 |
| Opponent | All fights | 7 | 388 | 204 | +207 | 246 | 8 | +238 | +61.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p79 | move | 28 | 8 (29%) | 7 (25%) | 2 (7%) | 18 (64%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122 |
| Ring of Doom | Mine | L1122, L1216, L1232 |
| Ring of Jet | Mine | L1122, L1216, L1232 |

# Doctrine scorecard: gs3-83c8646-p26

### Scorecard: gs3-83c8646-p26

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0226 | 4 | 1 | Mine | no | 0 | - | 0 | 5 | 0 | 0 | 0 | 0 |
| L0226 | 4 | 1 | Opponent | no | 6 | 3 | 1 | 3 | 0 | 0 | 0 | 60 |
| L0311 | 5 | 1 | Mine | no | - | - | 0 | 3 | 0 | 0 | 0 | 675 |
| L0311 | 5 | 1 | Opponent | yes | - | 3 | 0 | 1 | 0 | 0 | 0 | 330 |
| L0327 | 3 | 1 | Mine | no | 12 | 3 | 2 | 0 | 0 | 0 | 0 | 370 |
| L0327 | 3 | 1 | Opponent | no | 3 | 4 | 2 | 4 | 0 | 0 | 0 | 60 |
| **Average** | | | Mine | 0% | 6.0 | 3.0 | 0.7 | 2.7 | 0.0 | 0.0 | 0.0 | 348.3 |
| **Average** | | | Opponent | 33% | 4.5 | 3.3 | 1.0 | 2.7 | 0.0 | 0.0 | 0.0 | 150.0 |

### KPIs: gs3-83c8646-p26

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 50% (6 of 12) | 0% (0 of 14) | 23% (6 of 26) |
| Winner chose to follow up after the loser gave ground |  | 0% (0 of 1); on the table 0% | 100% (3 of 3); on the table 100% | 75% (3 of 4); on the table 75% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 0% (0 of 1); on the table 0% | 100% (4 of 4); on the table 100% | 80% (4 of 5); on the table 80% |
| Magic missiles tried each own turn | 50%+ | 40% (12 of 30) | 26% (11 of 42) | 32% (23 of 72) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 52% (12 of 23) | 32% (11 of 34) | 40% (23 of 57) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (2 of 3) | - | 67% (2 of 3) |
| Points that never fought | lower | 56% (3279 of 5897) | 61% (3658 of 5999) | 58% (6937 of 11896) |
|   infantry points that never fought | lower | 81% (1165 of 1437) | 55% (502 of 919) | 71% (1667 of 2356) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 68% (15 of 22) | 74% (14 of 19) | 71% (29 of 41) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 1.7 uses a game | 100% (2 of 2); 0.7 uses a game | 100% (4 of 4); 1.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (4 of 4); 1.3 uses a game | 0% (0 of 1); 0.0 uses a game | 80% (4 of 5); 0.7 uses a game |
|   their share of the points of units over 100 pts | lower | 59% (2667 of 4484) | 61% (3144 of 5148) | 60% (5811 of 9632) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.0 (50%) | 5.3 (52%) | 8.3 (51%) |
| MARCHED: its unit marched | 0.7 (11%) | 2.0 (19%) | 2.7 (16%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| IN COMBAT: engaged in combat | 0.3 (6%) | 2.3 (23%) | 2.7 (16%) |
| GONE: slain | 2.0 (33%) | 0.3 (3%) | 2.3 (14%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.0 | 1.0 | 3.0 | 7.7 | 0.7 | 2.3 |
| not cast | 5.0 | 1.0 | 3.0 | 16.3 | 1.3 | 21.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.0 (100%) | 0.3 (11%) | 8.3 (51%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.7 (16%) | 0.0 (0%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 1.0 (33%) | 2.7 (16%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.3 (7%) | 0.0 (0%) | 0.0 (0%) | 2.3 (14%) | 0.0 (0%) | 3.3 (15%) |
| STUPIDITY: Stupidity | 0.7 (13%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (100%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.0 (80%) | 0.0 (0%) | 1.7 (56%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.0 (83%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 3.0 a game | 0.0 a game | 1.5 a game |
| stood (cast and not dispelled) | 56% (5 of 9) | - | 56% (5 of 9) |
| the unit moved after it | 20% (1 of 5) | - | 20% (1 of 5) |
| it charged on its next turn | 0% (0 of 5) | - | 0% (0 of 5) |
| the enemy charged it first | 40% (2 of 5) | - | 40% (2 of 5) |
| it fought by the end of its next turn | 0% (0 of 5) | - | 0% (0 of 5) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 5) | - | 0% (0 of 5) |
| none of these (no charge, no fight, no charge escaped) | 60% (3 of 5) | - | 60% (3 of 5) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 69% (35 of 51) | 88% (14 of 16) | 73% (49 of 67) |
|   chariot | 45% (10 of 22) | 100% (3 of 3) | 52% (13 of 25) |
|   infantry | - | 83% (5 of 6) | 83% (5 of 6) |
|   war machine | 86% (25 of 29) | 86% (6 of 7) | 86% (31 of 36) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (38%) | 0.3 (50%) | 2.3 (39%) |
| CHARGED: it charged | 1.0 (19%) | 0.0 (0%) | 1.0 (17%) |
| IN COMBAT: it fought this turn or the last | 0.3 (6%) | 0.0 (0%) | 0.3 (6%) |
| MOVED: a war machine that moved | 1.0 (19%) | 0.0 (0%) | 1.0 (17%) |
| NO TARGET IN RANGE | 0.3 (6%) | 0.0 (0%) | 0.3 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (12%) | 0.3 (50%) | 1.0 (17%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| chariot | 4.3 | 2.0 | 77% | 10.7 pts | 46 pts |
| infantry | 3.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 10.7 | 8.3 | 75% | 19.6 pts | 209 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.0 | 4.0 | 2.5 |
| Charges that made contact a game | 1.0 | 2.7 | 1.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (4 units) | 1.20 declared, 1.00 contact (5 units) | 0.67 declared, 0.56 contact (9 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 1.00 contact (1 units) | 1.00 declared, 1.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.15 declared, 0.15 contact (20 units) | 0.25 declared, 0.10 contact (20 units) | 0.20 declared, 0.12 contact (40 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 100% (2 of 2) | - | 100% (2 of 2) | 100% (4 of 4) |
| Character in a unit | 100% (7 of 7) | 50% (1 of 2) | - | 89% (8 of 9) |
| Character on its own | - | 100% (1 of 1) | 0% (0 of 4) | 20% (1 of 5) |
| Chariot | 100% (1 of 1) | 50% (2 of 4) | - | 60% (3 of 5) |
| Infantry | 100% (1 of 1) | 33% (1 of 3) | 100% (1 of 1) | 60% (3 of 5) |
| Monster | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Monstrous | - | 100% (1 of 1) | - | 100% (1 of 1) |
| War Machines | 75% (6 of 8) | 50% (1 of 2) | - | 70% (7 of 10) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1 | - | 50% (3 of 6) | 26% | 67% (4 of 6) | 100% (2 of 2); 5.0 uses a game | 0.0 uses a game | 100% (2 of 2); 2.0 uses a game |
| Chaos Dwarfs | 2 | 0% (0 of 1); on the table 0% | 38% (9 of 24) | 70% | 69% (11 of 16) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Grand Cathay | 1 | - | 21% (5 of 24) | 82% | 75% (6 of 8) | 100% (2 of 2); 2.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Vampire Counts | 2 | 100% (4 of 4); on the table 100% | 33% (6 of 18) | 51% | 73% (8 of 11) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p26, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 43% (3) | 100% (2) | 56% (5) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.67 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.33 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: gs3-83c8646-p26

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 50% (1 of 2) | 36% (4 of 11) |
| Strategy | Shoot objectives carried out (shot that target) | 45% (18 of 40) | 58% (7 of 12) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 0% (0 of 1) | - |
| Strategy | Joined characters whose unit fought | 71% (5 of 7) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 0% (0 of 5) | 50% (4 of 8) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.7 | 2.7 |
| Movement | Points that never moved of their own | 348.3 | 150.0 |
| Movement | Fights charged into per game | 1.0 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 2 | 1 of 7, net -599 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | 0 of 7 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 2, net +0 | 3 of 7, net +65 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 2 | 0 of 7 |
| Shooting | Shots by shooting units (incl. breath weapons) | 3.3 | 2.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 60% (6 of 10) | 75% (6 of 8) |
| Shooting | Points destroyed by shooting units | 50.0 | 0.0 |
| Shooting | War machine shots | 8.7 | 2.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 31% (8 of 26) | 83% (5 of 6) |
| Shooting | Points destroyed by war machines | 100.0 | 103.3 |
| Magic | Magic missiles cast | 2.0 | 2.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 83% (5 of 6) | 38% (3 of 8) |
| Magic | Wounds caused by magic missiles | 2.7 | 2.0 |
| Magic | Wounds caused by other spells | - | 2.3 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 131.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.3 / 0.0 / 0.0 / 0.0 | 1.7 / 0.0 / 1.3 / 0.3 |
| Combat | Points destroyed in combat | 228.0 | 178.3 |
| Combat | Points run down | 0.0 | 28.3 |
| Combat | Net points per charged fight, damage counted | -5 | +18 |
| Combat | Net per 100 charger points, damage counted | -1.5 | +4.1 |
| Combat | First round won (charged fights) | 67% | 86% |
| Combat | Net points per charged fight | +15 | -15 |
| Combat | Net points per supported fight / lone fight | - / +15 | -40 / -11 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 3 | 1 of 7 |
| Game | Points lost | 555.0 | 359.7 |
| Game | VP from objectives | 590.0 | 760.0 |
| Game | Lone holders (player turns) | 6.0 | 4.5 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -327 VP
- The side that went first won 2 of 2 games with a winner
- Points traded per game (both sides' losses): 915
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p26

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 10.7 | +200.3 | 0.0 | 0.0 | 17.7 | +306.0 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 3.7 | +0.0 | 0.0 | 36.7 | 2.0 | +0.0 | 0.0 | 55.0 |
| ASSAILMENT BY POINTS | - | - | - | - | 0.3 | +1.4 | 0.0 | 199.7 |
| BOMBING RUN | - | - | - | - | 0.3 | +5.7 | 0.0 | 50.0 |
| CANNON PLAN MISSED | 0.7 | +0.0 | 0.0 | 83.3 | - | - | - | - |
| CANNON PLANNED TARGET | 8.0 | +31.1 | 175.0 | 310.0 | 2.0 | +88.8 | 206.7 | 55.0 |
| CANNON SIGHT KEPT | 3.0 | +0.0 | 0.0 | 105.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 3.7 | +45.1 | 0.0 | 0.0 | 0.7 | +2.5 | 56.7 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 1.3 | +45.7 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.3 | +10.7 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.3 | +73.1 | 0.0 | 56.7 | 1.0 | +12.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +17.9 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 8.3 | -315.6 | 0.0 | 336.7 | 14.0 | -444.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 15.0 | 0.0 | 2.7 | +0.0 | 283.3 | 199.7 |
| CLOSES ON WHAT IT BEATS | 10.7 | +0.0 | 0.0 | 0.0 | 13.7 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 3.3 | +314.0 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 12.0 | -362.8 | 0.0 | 233.3 | 1.3 | -40.7 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 10.0 | +28.6 | 0.0 | 76.7 | 7.0 | +82.9 | 0.0 | 55.0 |
| ENGINEER BY LORE | 1.3 | +0.0 | 0.0 | 28.3 | - | - | - | - |
| EXACT ROUND | 0.7 | +8.4 | 15.0 | 0.0 | 2.3 | +15.0 | 263.3 | 213.0 |
| FALL BACK GOOD ORDER | 0.7 | +0.0 | 15.0 | 0.0 | 2.0 | +0.3 | 178.3 | 199.7 |
| FALLS SHORT | - | - | - | - | 25.3 | +150.4 | 0.0 | 130.0 |
| FEATURE BUFFS | 5.7 | +63.0 | 0.0 | 113.3 | 0.7 | +23.6 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.3 | +26.5 | 0.0 | 199.7 |
| FIRE IN ORDER | 0.7 | +0.0 | 15.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 92.7 | +4151.2 | 440.0 | 1086.7 | 90.3 | +5355.5 | 1043.3 | 859.3 |
| FLANK NOT WEIGHED | 8.7 | +0.0 | 0.0 | 131.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| FOCUS FIRE | 0.3 | +6.3 | 15.0 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | - | - | - | - | 0.7 | +56.2 | 0.0 | 199.7 |
| FOOT FIRST | - | - | - | - | 22.0 | +0.0 | 0.0 | 106.7 |
| FOUR ROUNDS | 1.0 | +51.6 | 15.0 | 0.0 | 4.0 | +323.8 | 320.0 | 412.7 |
| FREED FROM HIS FIGHT | 4.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 1.3 | -35.9 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | - | - | - | - | 0.7 | -11.6 | 56.7 | 213.0 |
| GOAL ROUTE | - | - | - | - | 0.7 | +53.9 | 0.0 | 0.0 |
| GOAL WALK | 9.7 | +904.0 | 0.0 | 0.0 | 8.3 | +494.7 | 0.0 | 50.0 |
| GROUND FLIERS | 0.7 | +9.6 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 3.0 | +4.0 | 65.0 | 103.3 | - | - | - | - |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 50.0 |
| HE REFORMS ONCE FREED | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 6.3 | +0.0 | 0.0 | 130.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | 0.3 | +5.1 | 0.0 | 0.0 | 0.3 | +2.0 | 0.0 | 0.0 |
| HIS CHARGE LIST | 13.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.3 | -15.8 | 0.0 | 263.3 | 5.0 | -84.1 | 0.0 | 0.0 |
| HIS ONE QUARTER | 4.7 | +0.0 | 0.0 | 0.0 | 9.7 | +0.0 | 0.0 | 56.7 |
| HIS OWN BEST MOVE | 6.3 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 26.7 | +535.7 | 0.0 | 206.7 | 57.0 | +2424.2 | 0.0 | 123.3 |
| HIS SHOTS BY HIS RUN | 21.3 | +293.0 | 0.0 | 320.0 | 33.3 | +708.3 | 0.0 | 108.3 |
| HIS TURN DENIED | - | - | - | - | 0.7 | +6.0 | 73.3 | 0.0 |
| HOLD ODDS | 21.7 | +0.0 | 0.0 | 170.0 | 13.7 | +0.0 | 0.0 | 30.0 |
| HOLDER ASSIGNMENT | 8.3 | +659.9 | 0.0 | 56.7 | 9.0 | +912.1 | 0.0 | 15.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -29.4 | 15.0 | 0.0 | 3.0 | -127.9 | 263.3 | 199.7 |
| IDLE COST | - | - | - | - | 16.7 | -250.4 | 0.0 | 160.0 |
| JOINT CHARGE NOW | - | - | - | - | 0.7 | +26.0 | 113.3 | 213.0 |
| KEPT FROM ITS LAST STOP | 3.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 1.3 | +40.9 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 0.3 | +0.0 | 199.7 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.7 | +44.0 | 0.0 | 0.0 | 0.3 | +31.7 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | - | - | - | - | 1.3 | +1.7 | 141.7 | 0.0 |
| MANOEUVRE | 0.3 | -3.9 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.7 | +13.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.3 | +20.6 | 0.0 | 0.0 | 0.3 | +1.3 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +8.4 | 0.0 | 0.0 | 0.3 | +24.1 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +1.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.7 | -30.6 | 0.0 | 0.0 | 1.0 | -39.7 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.0 | +4.9 | 0.0 | 0.0 | 2.0 | +15.9 | 0.0 | 0.0 |
| MEETS IN TIME | 4.3 | +186.0 | 0.0 | 0.0 | 3.0 | +268.1 | 0.0 | 55.0 |
| MISSILES IN THE MOVE | 5.0 | +66.9 | 0.0 | 0.0 | 4.0 | +52.6 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 7.0 | +59.0 | 0.0 | 0.0 | 7.0 | +53.5 | 0.0 | 0.0 |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 1.0 | -3.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 6.0 | +509.9 | 0.0 | 0.0 | 4.7 | +244.3 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 4.7 | +185.1 | 0.0 | 0.0 | 6.3 | +319.4 | 0.0 | 0.0 |
| NEAREST TO GOAL | - | - | - | - | 1.0 | +0.0 | 0.0 | 50.0 |
| NEXT CHARGE BY LIST | 2.7 | +211.2 | 0.0 | 0.0 | 2.7 | +138.1 | 56.7 | 0.0 |
| NO DOUBLE ROUNDS | 0.7 | -36.4 | 0.0 | 0.0 | 3.3 | -117.4 | 263.3 | 399.3 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.3 | +10.8 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | -0.2 | 0.0 | 28.3 | - | - | - | - |
| NOT WORTH A CAST | - | - | - | - | 0.3 | -0.0 | 0.0 | 0.0 |
| OFF BEST | 2.7 | -52.0 | 0.0 | 0.0 | 3.7 | -180.4 | 0.0 | 20.0 |
| OGRE LOADER SECOND SHOT | 0.3 | +0.6 | 0.0 | 0.0 | 3.0 | +23.1 | 0.0 | 55.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.3 | -32.6 | 0.0 | 0.0 | 5.3 | -107.9 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 2.3 | -24.0 | 0.0 | 0.0 | 4.3 | +131.1 | 0.0 | 15.0 |
| ONE PROMISE A TARGET | 0.7 | +36.1 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +14.3 | 36.7 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 1.3 | +30.9 | 141.7 | 0.0 |
| PATHS CROSS | 0.3 | +2.2 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.3 | -3.3 | 0.0 | 28.3 | 0.3 | -1.8 | 0.0 | 0.0 |
| PLAN RESULT | 41.0 | +246.6 | 50.0 | 900.0 | 43.0 | +653.6 | 386.7 | 651.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 9.0 | -324.3 | 0.0 | 0.0 | 7.0 | -230.1 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.7 | -1.8 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 24.3 | +2174.4 | 0.0 | 0.0 | 23.3 | +2947.6 | 235.0 | 256.3 |
| RANDOM MOVE BY FIGURES | 1.0 | +0.8 | 0.0 | 56.7 | - | - | - | - |
| REAL GROUND | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 1.3 | +27.8 | 0.0 | 56.7 | - | - | - | - |
| REDIRECT COUNTER | 2.0 | +37.7 | 0.0 | 56.7 | 1.7 | +4.2 | 0.0 | 15.0 |
| REDIRECT FOR A FRIEND IN REACH | 1.7 | +23.9 | 0.0 | 85.0 | 2.0 | +0.0 | 0.0 | 28.3 |
| REDIRECT WEIGHED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.3 | -34.9 | 0.0 | 0.0 | 0.3 | -0.2 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +0.3 | 0.0 | 50.0 |
| RESTRAINS TO SHOOT | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 0.3 | -0.7 | 0.0 | 0.0 | 3.0 | -18.9 | 320.0 | 213.0 |
| RISK ON THE WAY | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 2.0 | -38.2 | 93.3 | 199.7 |
| RUN DOWN | - | - | - | - | 2.7 | -8.2 | 206.7 | 199.7 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.7 | -124.6 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +10.1 | 0.0 | 0.0 | 1.3 | +51.5 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +3.0 | 15.0 | 0.0 | 0.3 | +16.3 | 28.3 | 0.0 |
| SET UP BY THE SET | 0.3 | -6.7 | 0.0 | 0.0 | 0.7 | +10.8 | 0.0 | 0.0 |
| SET-UP MISSED | 0.3 | +7.6 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 14.0 | +0.0 | 0.0 | 346.7 | 5.3 | +0.0 | 0.0 | 175.0 |
| SHOOTS FROM THE BEST SPOT | 4.7 | +80.5 | 15.0 | 0.0 | 1.3 | +1.9 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -1.3 | 28.3 | 0.0 |
| SHOT RISK POINTS | 11.7 | -212.5 | 0.0 | 320.0 | 35.0 | -121.3 | 0.0 | 136.7 |
| SHOTS AFTER THE MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 12.7 | +304.6 | 0.0 | 486.7 | 4.7 | +205.5 | 0.0 | 155.0 |
| SPELL WORTH | 0.3 | +6.2 | 0.0 | 0.0 | 2.7 | +27.0 | 399.3 | 399.3 |
| SPELLS IN THE FIGHT | - | - | - | - | 1.0 | +15.6 | 170.0 | 199.7 |
| SPOT AS THE GAME MOVES | 5.0 | +0.0 | 0.0 | 56.7 | 5.7 | +0.0 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 2.0 | +0.0 | 0.0 | 200.0 |
| STANDS STILL | 54.0 | +0.0 | 425.0 | 766.7 | 32.7 | +0.0 | 723.3 | 396.7 |
| STAY WORTH | 21.7 | -250.7 | 300.0 | 553.3 | 11.7 | +240.3 | 723.3 | 465.0 |
| STRIKE BY THE ODDS | 0.3 | +4.2 | 13.3 | 56.7 | - | - | - | - |
| STUCK PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| STUPIDITY NEXT TURN | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 1.7 | +14.2 | 0.0 | 0.0 | 1.0 | +6.9 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 1.7 | +14.2 | 0.0 | 0.0 | 1.0 | +6.9 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -13.8 | 28.3 | 0.0 |
| THE ROW IN ITS ORDER | 3.3 | +0.0 | 28.3 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.7 | +0.0 | 0.0 | 103.3 | 5.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.7 | +0.0 | 0.0 | 103.3 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 44.7 | +0.0 | 0.0 | 478.3 | 44.3 | +0.0 | 0.0 | 243.3 |
| TIED UP BY THE SUM | 0.7 | +69.6 | 15.0 | 0.0 | 1.0 | +153.3 | 93.3 | 0.0 |
| TIME ON OUR SIDE | 46.7 | +462.0 | 15.0 | 131.7 | - | - | - | - |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | 0.3 | +38.7 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 1.7 | +0.0 | 115.0 | 0.0 | 0.7 | +0.0 | 0.0 | 100.0 |
| WHO FIGHTS | - | - | - | - | 0.3 | +0.9 | 0.0 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +11.0 | 0.0 | 13.3 |
| WHOLE FIGHT DANGER | 0.7 | -73.3 | 0.0 | 73.3 | 0.7 | -104.1 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 0.7 | +2.9 | 0.0 | 0.0 | 2.3 | +61.0 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p26

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 251 | 236 | 53 | 17.67 | +912 | +17.2 |
| ARMY TABLE | 85 | 85 | 50 | 16.67 | +1049 | +21.0 |
| HOLDER ASSIGNMENT | 52 | 52 | 50 | 16.67 | +2932 | +58.6 |
| HIS SHOTS BY HIS RUN | 164 | 154 | 33 | 11.00 | +318 | +9.6 |
| DEPLOY BY FIGURES | 51 | 51 | 31 | 10.33 | +306 | +9.9 |
| GOAL WALK | 54 | 51 | 21 | 7.00 | +1353 | +64.4 |
| SHOT RISK POINTS | 140 | 134 | 21 | 7.00 | +703 | +33.5 |
| PROMISE BY ITS OWN SUM | 48 | 48 | 20 | 6.67 | -1663 | -83.2 |
| OFF BEST | 19 | 19 | 19 | 6.33 | -697 | -36.7 |
| TIME ON OUR SIDE | 140 | 119 | 19 | 6.33 | +86 | +4.5 |
| FIVE ACTION | 549 | 527 | 18 | 6.00 | +1188 | +66.0 |
| ARTILLERY RE-ROLL WEIGHED | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| QUARTER ODDS | 143 | 140 | 17 | 5.67 | +1989 | +117.0 |
| MOVE TO CHARGE COMPUTED | 32 | 21 | 16 | 5.33 | +876 | +54.7 |
| THE TABLE AGAIN | 36 | 36 | 16 | 5.33 | +0 | +0.0 |
| MEETS IN TIME | 22 | 22 | 11 | 3.67 | +245 | +22.3 |
| NEXT CHARGE BY LIST | 16 | 14 | 11 | 3.67 | +517 | +47.0 |
| REDIRECT FOR A FRIEND IN REACH | 11 | 11 | 11 | 3.67 | +56 | +5.1 |
| CANNON SIGHT KEPT | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| HARD STAY DROPPED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| OGRE LOADER SECOND SHOT | 10 | 10 | 10 | 3.33 | +71 | +7.1 |
| FOUR ROUNDS | 15 | 13 | 9 | 3.00 | +354 | +39.3 |
| IDLE COST | 50 | 34 | 9 | 3.00 | +100 | +11.1 |
| MOVE ORDER | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| CHAFF IN THE MOVE | 7 | 7 | 7 | 2.33 | +110 | +15.7 |
| LEGAL CHARGES ONLY | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| COVER ONCE | 40 | 27 | 6 | 2.00 | +23 | +3.8 |
| FALLS SHORT | 76 | 66 | 6 | 2.00 | +0 | +0.0 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| SUPPORT ADDS | 8 | 8 | 5 | 1.67 | +33 | +6.6 |
| SUPPORT WORKED OUT | 8 | 8 | 5 | 1.67 | +33 | +6.6 |
| CANNON PLANNED TARGET | 30 | 30 | 4 | 1.33 | +0 | +0.0 |
| CASTING BLOCK | 4 | 4 | 4 | 1.33 | +32 | +8.0 |
| CHARGE NOW FIRST | 10 | 10 | 4 | 1.33 | -63 | -15.8 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +123 | +30.7 |
| SEARCH SPOT | 5 | 5 | 4 | 1.33 | +185 | +46.3 |
| SHOOTS FROM THE BEST SPOT | 18 | 18 | 4 | 1.33 | +0 | +0.1 |
| SHOTS AFTER THE MOVES | 14 | 14 | 4 | 1.33 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 9 | 8 | 4 | 1.33 | +20 | +5.0 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +227 | +75.7 |
| MARCH CHECK | 3 | 3 | 3 | 1.00 | +57 | +19.1 |
| MAX FOR POSITIONING | 9 | 9 | 3 | 1.00 | +1 | +0.2 |
| MISSILES IN THE MOVE | 27 | 14 | 3 | 1.00 | +15 | +5.1 |
| SET UP BY THE SET | 3 | 3 | 3 | 1.00 | +130 | +43.3 |
| SHOTS IN THE MOVE | 52 | 39 | 3 | 1.00 | +116 | +38.8 |
| THE ROW IN ITS ORDER | 18 | 3 | 3 | 1.00 | +0 | +0.0 |
| TIED UP BY THE SUM | 5 | 3 | 3 | 1.00 | +91 | +30.5 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHARGE LOSSES | 67 | 64 | 2 | 0.67 | +50 | +25.1 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +168 | +84.2 |
| GOAL ROUTE | 2 | 2 | 2 | 0.67 | +162 | +80.8 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +78 | +38.9 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +66 | +32.8 |
| MISSILES NEXT TURN | 42 | 27 | 2 | 0.67 | +18 | +8.9 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | +109 | +54.3 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.67 | -15 | -7.7 |
| RANDOM MOVE BY FIGURES | 3 | 3 | 2 | 0.67 | +2 | +1.2 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +72 | +36.0 |
| RISK BY ARC | 10 | 9 | 2 | 0.67 | +21 | +10.6 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +58 | +28.9 |
| STAY WORTH | 100 | 89 | 2 | 0.67 | +13 | +6.4 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| BOMBING RUN | 1 | 1 | 1 | 0.33 | +17 | +17.2 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +54 | +53.8 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FEATURE BUFFS | 19 | 18 | 1 | 0.33 | +1 | +0.8 |
| FIGHT TO THE END | 1 | 1 | 1 | 0.33 | +76 | +75.5 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +19 | +19.0 |
| HIS CHARGE DENIED | 2 | 2 | 1 | 0.33 | +3 | +2.8 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -3 | -2.9 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.33 | +23 | +22.7 |
| ONE FIGHT FORMULA | 29 | 16 | 1 | 0.33 | +21 | +21.4 |
| ONE OBJECTIVE FORMULA | 20 | 15 | 1 | 0.33 | +86 | +86.0 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +43 | +42.9 |
| OVERRUNS AWAY | 4 | 4 | 1 | 0.33 | +3 | +2.8 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +7 | +6.6 |
| REDIRECT COUNTER | 11 | 6 | 1 | 0.33 | +24 | +24.1 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +1 | +0.9 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| SPELLS IN THE FIGHT | 3 | 3 | 1 | 0.33 | +20 | +19.9 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +12 | +12.5 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +2 | +2.4 |
| THE PROMISE ADDS | 1 | 1 | 1 | 0.33 | +5 | +5.1 |
| WAR ENGINE CHARGES | 1 | 1 | 1 | 0.33 | +74 | +74.0 |
| WAR ENGINE JOBS | 7 | 7 | 1 | 0.33 | -3 | -3.4 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +12 | +11.8 |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CAST JOB | 13 | 13 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 73 | 71 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 10 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| EXACT ROUND | 9 | 8 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 8 | 7 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 30 | not checked | - | - | - | - |
| FOOT FIRST | 66 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 14 | 10 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| GUN FIGURES | 9 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 10 | 6 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 28 | 26 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 51 | 48 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 24 | 20 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 25 | 25 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 43 | 41 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 39 | 32 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 18 | 18 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HOLD ODDS | 106 | 104 | 0 | 0.00 | - | - |
| HONEST WORTH | 12 | 10 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 18 | 18 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 4 | 4 | 0 | 0.00 | - | - |
| LONG SHOT | 4 | 4 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 4 | 4 | 0 | 0.00 | - | - |
| MANOEUVRE | 7 | 7 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 10 | 10 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 3 | trace | - | - | - | - |
| MOVE SPELL SPOT | 3 | not checked | - | - | - | - |
| NEARER NOT NEEDED | 33 | 31 | 0 | 0.00 | - | - |
| NEAREST TO GOAL | 3 | 3 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 12 | 11 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE ROUTE | 10 | 10 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 252 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 10 | 10 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 5 | 3 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 5 | 5 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 6 | 5 | 0 | 0.00 | - | - |
| RUN DOWN | 8 | 7 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 5 | 5 | 0 | 0.00 | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 58 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 9 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 32 | 30 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 6 | 6 | 0 | 0.00 | - | - |
| STANDS STILL | 260 | 256 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 4 | 4 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 25 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 15 | not checked | - | - | - | - |
| THE TABLE BINDS | 267 | not checked | - | - | - | - |
| WAITS AGAIN | 6 | 5 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 4 | 4 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p26

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 4.00 | 2.67 | 83.2 |
| JOB FIRST | gate | 2.33 | 3.33 | 37.4 |
| ARMY TABLE | rule | 1.33 | 0.33 | 96.5 |
| CHARGE NOW FIRST | rule | 0.33 | 1.00 | 15.8 |
| DEPLOY BY FIGURES | rule | 0.67 | 0.33 | 6.0 |
| HOLDER ASSIGNMENT | rule | 1.00 | - | 17.7 |
| PIVOT GUARDS FLANK | rule | 0.33 | 0.33 | 7.7 |
| MARCH OF THE TABLE | rule | - | 0.33 | 2.9 |
| NO REASON | gate | - | 0.33 | 4.2 |
| RULE SWITCHED OFF | gate | 0.33 | - | 56.5 |
| WAR ENGINE JOBS | rule | 0.33 | - | 3.4 |

### Plans: gs3-83c8646-p26

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.7 | 50% | 33 | 28 | 85% |
| Mine | move | 28.7 | 94% | 1491 | 0 | 0% |
| Mine | shoot | 11.0 | 33% | 127 | 219 | 172% |
| Mine | support | 0.7 | 0% | 21 | 0 | 0% |
| Opponent | charge | 3.7 | 82% | 296 | 330 | 111% |
| Opponent | join | 1.3 | 75% | 50 | 0 | 0% |
| Opponent | move | 33.3 | 96% | 1330 | 0 | 0% |
| Opponent | shoot | 3.7 | 45% | 352 | 324 | 92% |
| Opponent | support | 1.0 | 100% | 0 | 0 | - |

### Battle groups: gs3-83c8646-p26

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.0 | 67% | 25% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 1.7 | 20% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p26

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 0% | 4.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Character | 8 | 53 (8) | 53 | 0 | 0 | 38% | 2.8 | 59 (7) | 0 (1) | - | 0 (2) | 67 (6) |
| Mine | Clean-up | 4 | 137 (4) | 0 | 137 | 0 | 100% | - | 128 (3) | 165 (1) | - | 194 (2) | 81 (2) |
| Mine | Fast Hammer | 5 | 0 (5) | 0 | 0 | 52 | 80% | 3.0 | 0 (1) | 0 (2) | 0 (2) | 0 (5) | - |
| Mine | Hammer | 9 | 17 (9) | 8 | 9 | 20 | 22% | 2.6 | 10 (3) | 22 (5) | 0 (1) | 18 (6) | 15 (3) |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | War machine | 8 | 25 (8) | 25 | 0 | 79 | 0% | 1.0 | 17 (6) | 45 (2) | - | 43 (5) | 0 (3) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 22 | 25% | 4.0 | 0 (4) | - | - | 0 (2) | 0 (2) |
| Opponent | Chaff | 8 | 108 (8) | 0 | 108 | 46 | 62% | 3.7 | 60 (3) | 166 (4) | 0 (1) | 117 (7) | 50 (1) |
| Opponent | Character | 8 | 45 (8) | 45 | 0 | 26 | 50% | 2.2 | 28 (3) | 63 (5) | - | 34 (1) | 48 (7) |
| Opponent | Clean-up | 5 | 0 (5) | 0 | 0 | 0 | 80% | 4.0 | 0 (2) | 0 (1) | 0 (2) | 0 (2) | 0 (3) |
| Opponent | Fast Hammer | 2 | 0 (2) | 0 | 0 | 28 | 50% | 1.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Hammer | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Holder | 1 | 0 (1) | 0 | 0 | 0 | 0% | 4.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Shooter | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | War machine | 2 | 94 (2) | 94 | 0 | 50 | 0% | 1.0 | 188 (1) | 0 (1) | - | - | 94 (2) |
| Opponent | Wizard | 4 | 0 (4) | 0 | 0 | 10 | 50% | 3.5 | 0 (3) | 0 (1) | - | 0 (3) | 0 (1) |

### Charged fights: gs3-83c8646-p26

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Chaos Dwarfs | 2 | 225 | 22 | 1.5 | 1.0 | 15 | 0 | +15 | 1 of 3 | 2 of 3 | - | +15 |
| **Mine** | all armies | 3 | 150 | 15 | 1.0 | 1.0 | 15 | 0 | +15 | 1 of 3 | 2 of 3 | - | +15 |
| Opponent | Grand Cathay | 1 | 535 | 340 | 2.0 | 1.0 | 170 | 0 | +170 | 0 of 2 | 2 of 2 | - | +170 |
| Opponent | Vampire Counts | 2 | 85 | 98 | 2.5 | 1.2 | 39 | 128 | -89 | 1 of 5 | 4 of 5 | -40 | -101 |
| **Opponent** | all armies | 3 | 235 | 178 | 2.3 | 1.1 | 76 | 91 | -15 | 1 of 7 | 6 of 7 | -40 | -11 |

### Effective charges: gs3-83c8646-p26

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 3 | 0 | 0 | 0 | 1 (net +0) | 1 (net +0) | 0 | 1 | 0% (0 of 2) |
| Opponent | Grand Cathay | 2 | 0 | 0 | 0 | 2 (net +170) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Vampire Counts | 5 | 1 (net -599) | 1 (net -40) | 0 | 0 | 3 (net +65) | 0 | 0 | 0% (0 of 5) |

### Charged fights, damage counted: gs3-83c8646-p26

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 1 | 310 | 471 | +0 | 118 | 177 | -59 | -19.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 310 | 60 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | No odds | 1 | 310 | 45 | +45 | 45 | 0 | +45 | +14.5 |
| Mine | All fights | 3 | 310 | 192 | +15 | 54 | 59 | -5 | -1.5 |
| Opponent | Long shot (under 50%) | 1 | 499 | 272 | -599 | 90 | 599 | -509 | -101.9 |
| Opponent | 50-54% | 1 | 539 | 170 | -40 | 142 | 40 | +102 | +18.9 |
| Opponent | 76-89% | 2 | 369 | 170 | +170 | 170 | 0 | +170 | +46.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 443 | 75 | +65 | 70 | 5 | +65 | +14.7 |
| Opponent | All fights | 7 | 443 | 144 | -15 | 112 | 93 | +18 | +4.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p26 | move | 18 | 3 (17%) | 1 (6%) | 2 (11%) | 13 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0226, L0327 |
| Elixir of Power | Opponent | L0311 |
| Invocation of Nehek | Opponent | L0327 |
| Ring of Doom | Mine | L0226 |
| Ring of Doom | Opponent | L0311 |
| Ring of Jet | Opponent | L0311 |

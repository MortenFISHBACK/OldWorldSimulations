# Doctrine scorecard: gs3-83c8646-p34

### Scorecard: gs3-83c8646-p34

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1831 | 1 | 1 | Mine | no | 2 | - | 2 | 2 | 0 | 0 | 0 | 34 |
| L1831 | 1 | 1 | Opponent | no | 5 | 6 | 1 | 1 | 1 | 0 | 0 | 340 |
| L1932 | 6 | 1 | Mine | no | 2 | 2 | 3 | 1 | 1 | 0 | 0 | 260 |
| L1932 | 6 | 1 | Opponent | no | 9 | 1 | 4 | 3 | 1 | 0 | 0 | 305 |
| L2033 | 5 | 1 | Mine | yes | - | - | 0 | 6 | 2 | 0 | 0 | 420 |
| L2033 | 5 | 1 | Opponent | yes | - | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 2.0 | 2.0 | 1.7 | 3.0 | 1.0 | 0.0 | 0.0 | 238.0 |
| **Average** | | | Opponent | 33% | 7.0 | 3.0 | 2.3 | 2.3 | 0.7 | 0.0 | 0.0 | 215.0 |

### KPIs: gs3-83c8646-p34

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 9) | 7% (1 of 15) | 4% (1 of 24) |
| Winner chose to follow up after the loser gave ground |  | 100% (3 of 3); on the table 100% | 100% (3 of 3); on the table 100% | 100% (6 of 6); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 25% (1 of 4); on the table 100% | 25% (1 of 4); on the table 100% |
| Winner chose to pursue after the loser fled |  | 50% (1 of 2); on the table 50% | 33% (1 of 3); on the table 67% | 40% (2 of 5); on the table 60% |
| Winner chose to follow up or pursue (all three) |  | 80% (4 of 5); on the table 80% | 50% (5 of 10); on the table 90% | 60% (9 of 15); on the table 87% |
| Magic missiles tried each own turn | 50%+ | 0% (0 of 18) | 17% (1 of 6) | 4% (1 of 24) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 0% (0 of 16) | 17% (1 of 6) | 5% (1 of 22) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 71% (5 of 7) | 44% (7 of 16) | 52% (12 of 23) |
| Points that never fought | lower | 51% (3039 of 5999) | 46% (2775 of 5999) | 48% (5814 of 11998) |
|   infantry points that never fought | lower | 92% (913 of 993) | 78% (759 of 967) | 85% (1672 of 1960) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 73% (16 of 22) | 57% (17 of 30) | 63% (33 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 0.3 uses a game | 100% (3 of 3); 3.3 uses a game | 100% (4 of 4); 1.8 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (2 of 2); 0.7 uses a game | 0% (0 of 1); 0.0 uses a game | 67% (2 of 3); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 69% (3577 of 5151) | 47% (2759 of 5838) | 58% (6336 of 10989) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.3 (39%) | 1.7 (100%) | 4.0 (52%) |
| MARCHED: its unit marched | 0.7 (11%) | 0.0 (0%) | 0.7 (9%) |
| CHARGED: its unit charged | 0.3 (6%) | 0.0 (0%) | 0.3 (4%) |
| IN COMBAT: engaged in combat | 0.7 (11%) | 0.0 (0%) | 0.7 (9%) |
| REAR RANK: in a rear rank | 1.7 (28%) | 0.0 (0%) | 1.7 (22%) |
| NOT OFFERED: not in the cast list | 0.3 (6%) | 0.0 (0%) | 0.3 (4%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 1.7 | 0.0 | 0.0 | 0.3 | 0.3 | 2.0 |
| not cast | 6.3 | 2.0 | 4.0 | 7.7 | 3.3 | 21.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (67%) | 0.0 (0%) | 4.0 (52%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (9%) | 0.3 (10%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.3 (10%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (9%) | 0.3 (10%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (32%) | 0.0 (0%) | 2.0 (50%) | 1.7 (22%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (20%) | 1.7 (8%) |
| OFF THE TABLE: off the table or not arrived | 1.3 (21%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (40%) | 2.3 (11%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (10%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.0 (47%) | 0.7 (33%) | 2.0 (50%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.0 (80%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 43% (27 of 63) | 49% (17 of 35) | 45% (44 of 98) |
|   cavalry | - | 33% (2 of 6) | 33% (2 of 6) |
|   character | 100% (6 of 6) | 40% (6 of 15) | 57% (12 of 21) |
|   chariot | 92% (11 of 12) | - | 92% (11 of 12) |
|   infantry | 14% (5 of 35) | 64% (9 of 14) | 29% (14 of 49) |
|   monster | 50% (5 of 10) | - | 50% (5 of 10) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (22%) | 0.7 (11%) | 3.3 (19%) |
| CHARGED: it charged | 0.0 (0%) | 2.3 (39%) | 2.3 (13%) |
| FLEEING: it fled or was fleeing | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.3 (3%) | 1.0 (17%) | 1.3 (7%) |
| NO TARGET IN RANGE | 5.0 (42%) | 0.0 (0%) | 5.0 (28%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (6%) | 0.0 (0%) | 0.7 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.7 (22%) | 1.7 (28%) | 4.3 (24%) |
| STUPIDITY | 0.0 (0%) | 0.3 (6%) | 0.3 (2%) |
| OTHER BAR | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 0.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| character | 4.0 | 1.3 | 75% | 7.9 pts | 32 pts |
| chariot | 3.7 | 2.3 | 64% | 14.2 pts | 52 pts |
| infantry | 7.0 | 3.0 | 62% | 13.3 pts | 93 pts |
| monster | 2.0 | 0.3 | 83% | 6.4 pts | 13 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.3 | 3.0 | 2.7 |
| Charges that made contact a game | 1.3 | 2.0 | 1.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | - | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.25 declared, 0.14 contact (28 units) | 0.36 declared, 0.24 contact (25 units) | 0.30 declared, 0.19 contact (53 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 29% (2 of 7) | 50% (1 of 2) | - | 33% (3 of 9) |
| Character in a unit | 100% (4 of 4) | 100% (1 of 1) | 50% (1 of 2) | 86% (6 of 7) |
| Character on its own | 100% (6 of 6) | 67% (2 of 3) | 25% (1 of 4) | 69% (9 of 13) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 100% (5 of 5) | 33% (1 of 3) | - | 75% (6 of 8) |
| Monster | 50% (2 of 4) | 33% (1 of 3) | - | 43% (3 of 7) |
| Monstrous | 100% (2 of 2) | 50% (2 of 4) | - | 67% (4 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ogre Kingdoms | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 67% | 57% (4 of 7) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 6) | 6% | 75% (6 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 1 | 50% (1 of 2); on the table 50% | 0% (0 of 6) | 79% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 2 | 38% (3 of 8); on the table 88% | 17% (1 of 6) | 49% | 50% (10 of 20) | 100% (1 of 1); 2.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (2 of 2); on the table 100% | - | 42% | 70% (7 of 10) | 100% (2 of 2); 5.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p34, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 60% (3) | 67% (2) | 62% (5) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.00 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.00 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: gs3-83c8646-p34

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.7 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 50% (1 of 2) | 80% (4 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 33% (3 of 9) | 0% (0 of 5) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 0% (0 of 2) | 17% (1 of 6) |
| Strategy | Lone characters that fought | 62% (5 of 8) | 80% (4 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 3.0 | 2.3 |
| Movement | Points that never moved of their own | 238.0 | 215.0 |
| Movement | Fights charged into per game | 1.3 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 1 | 2 of 4, net +130 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 1 | 0 of 4 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 1 | 0 of 4 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 1, net +135 | 2 of 4, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.0 | 6.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 41% (11 of 27) | 40% (8 of 20) |
| Shooting | Points destroyed by shooting units | 38.7 | 91.7 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | - | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 0% (0 of 1) |
| Magic | Wounds caused by magic missiles | 0.7 | 1.0 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 21.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.0 / 1.7 / 0.0 | 0.0 / 0.0 / 0.3 / 0.3 |
| Combat | Points destroyed in combat | 148.0 | 509.3 |
| Combat | Points run down | 90.7 | 18.3 |
| Combat | Net points per charged fight, damage counted | -140 | +32 |
| Combat | Net per 100 charger points, damage counted | -66.4 | +11.3 |
| Combat | First round won (charged fights) | 50% | 67% |
| Combat | Net points per charged fight | -134 | +4 |
| Combat | Net points per supported fight / lone fight | - / -134 | - / +4 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 4 | 5 of 6 |
| Game | Points lost | 788.3 | 401.3 |
| Game | VP from objectives | 533.3 | 780.0 |
| Game | Lone holders (player turns) | 2.0 | 7.0 |

- Mine won / drew / lost: 0 / 1 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -689 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 1190
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p34

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +34.4 | 0.0 | 0.0 |
| ARMY TABLE | 30.3 | +511.6 | 0.0 | 542.0 | 12.7 | -2.4 | 0.0 | 115.3 |
| ASSAILMENT BY POINTS | 2.0 | +11.1 | 0.0 | 321.3 | 0.3 | +1.5 | 0.0 | 78.0 |
| BEST PRIZE | 0.3 | -13.6 | 45.7 | 0.0 | - | - | - | - |
| CAST JOB | - | - | - | - | 2.3 | +3.3 | 11.3 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.3 | +40.8 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | - | - | - | - | 0.3 | +2.8 | 0.0 | 45.7 |
| CHARACTER GUNS | - | - | - | - | 5.0 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 13.0 | -713.0 | 0.0 | 600.0 | 9.7 | -435.1 | 0.0 | 181.3 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 55.0 | 0.0 | 0.3 | +0.0 | 78.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 13.3 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 10.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 5.0 | -320.7 | 0.0 | 178.0 | 2.0 | -62.3 | 0.0 | 90.7 |
| DEPLOY BY FIGURES | 8.0 | +101.6 | 0.0 | 0.0 | 7.7 | -43.8 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -280.8 | 131.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +13.4 | 0.0 | 0.0 |
| ELIXIR WORTH | 0.3 | +12.2 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 0.7 | +1.8 | 55.0 | 0.0 | 1.7 | +9.2 | 175.0 | 0.0 |
| FALL BACK GOOD ORDER | 0.7 | +0.0 | 55.0 | 0.0 | 2.0 | +11.5 | 306.0 | 0.0 |
| FALLS SHORT | 13.0 | +116.6 | 0.0 | 267.0 | 5.7 | +105.7 | 0.0 | 0.0 |
| FEATURE BUFFS | 2.7 | +83.5 | 0.0 | 36.7 | 1.3 | +77.7 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.3 | +4.6 | 131.0 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 95.0 | +5776.1 | 93.7 | 1153.7 | 70.7 | +5063.8 | 317.3 | 490.7 |
| FLANK NOT WEIGHED | 9.3 | +0.0 | 0.0 | 245.0 | 2.0 | +0.0 | 0.0 | 90.7 |
| FOLLOW UP WEIGHED | 0.3 | +106.4 | 0.0 | 70.0 | 0.3 | +53.3 | 0.0 | 0.0 |
| FOOT FIRST | - | - | - | - | 10.0 | +0.0 | 0.0 | 157.3 |
| FOUR ROUNDS | 0.7 | +37.5 | 55.0 | 0.0 | 2.3 | +221.2 | 306.0 | 0.0 |
| FREED FROM HIS FIGHT | 5.0 | +0.0 | 0.0 | 80.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 1.3 | -54.5 | 227.7 | 0.0 |
| GOAL WALK | 9.3 | +892.3 | 0.0 | 156.7 | 9.0 | +554.6 | 0.0 | 105.3 |
| GUN FIGURES | 2.7 | +107.9 | 0.0 | 21.7 | - | - | - | - |
| GUN MASK | 0.7 | +14.7 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 38.7 |
| HE REFORMS ONCE FREED | 3.0 | +0.0 | 0.0 | 80.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 5.3 | +0.0 | 0.0 | 226.7 | 3.7 | +0.0 | 0.0 | 181.3 |
| HIS CHARGE LIST | 2.0 | +0.0 | 0.0 | 131.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 1.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 5.7 | -71.0 | 0.0 | 287.3 | 3.3 | -42.7 | 0.0 | 0.0 |
| HIS ONE QUARTER | 14.0 | +0.0 | 0.0 | 132.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 1.7 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 24.3 | +0.0 | 0.0 | 577.7 | 12.0 | +0.0 | 0.0 | 70.7 |
| HIS RANDOM MOVER COMES | 6.7 | +0.0 | 0.0 | 373.3 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 43.0 | +1044.1 | 0.0 | 877.0 | 21.0 | +634.0 | 0.0 | 204.7 |
| HIS SHOTS BY HIS RUN | 42.7 | +816.9 | 0.0 | 952.3 | 18.3 | +686.4 | 0.0 | 56.7 |
| HOLD ODDS | 23.3 | +0.0 | 0.0 | 73.3 | 17.7 | +0.0 | 0.0 | 91.3 |
| HOLDER ASSIGNMENT | 14.0 | +1332.4 | 0.0 | 18.3 | 9.7 | +1030.6 | 0.0 | 45.7 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.7 | -25.5 | 55.0 | 0.0 | 2.0 | -112.4 | 306.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.3 | +2.8 | 0.0 | 0.0 |
| IDLE COST | 8.7 | -149.0 | 0.0 | 130.3 | 5.3 | -45.7 | 0.0 | 0.0 |
| JOINT CHARGE NOW | - | - | - | - | 0.7 | +24.1 | 156.7 | 0.0 |
| KEPT FROM ITS LAST STOP | 3.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +7.5 | 0.0 | 0.0 | 0.3 | +10.9 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 1.0 | +0.0 | 56.7 | 295.3 | 6.0 | +0.0 | 646.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.3 | +26.7 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 0.3 | +0.3 | 45.0 | 0.0 | 1.7 | +1.9 | 287.7 | 0.0 |
| LURE BY WHAT IT DRAWS | 1.3 | -300.7 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | - | - | - | - | 1.7 | +6.7 | 0.0 | 0.0 |
| MANOEUVRE | 1.7 | +3.3 | 0.0 | 0.0 | 2.0 | +1.5 | 0.0 | 90.7 |
| MARCH BY THE SUM | 0.7 | +105.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.3 | +63.1 | 0.0 | 0.0 | 0.3 | +20.5 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.7 | +43.8 | 0.0 | 108.7 | - | - | - | - |
| MARCH WHEELS ONLY | 2.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.3 | +100.6 | 0.0 | 127.0 | 2.0 | +15.8 | 0.0 | 38.7 |
| MEETS IN TIME | 4.7 | +443.6 | 0.0 | 0.0 | 2.7 | +274.2 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.3 | +26.7 | 0.0 | 0.0 | 5.3 | +58.8 | 0.0 | 36.0 |
| MISSILES NEXT TURN | 2.7 | +24.1 | 0.0 | 108.7 | 5.3 | +35.7 | 0.0 | 36.0 |
| MOVE ORDER | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.7 | -8.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.0 | +90.7 | 0.0 | 0.0 | 5.7 | +362.8 | 0.0 | 34.7 |
| MOVES UNITS SPELL | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 9.0 | +385.7 | 0.0 | 96.7 | 5.7 | +280.7 | 0.0 | 45.7 |
| NEAREST TO GOAL | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 1.3 | +62.5 | 0.0 | 0.0 | 2.7 | +129.8 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -1.1 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 0.7 | -28.5 | 55.0 | 0.0 | 2.3 | -68.5 | 306.0 | 0.0 |
| NO LATE CUT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT WORTH A CAST | 1.0 | -0.8 | 0.0 | 0.0 | 2.7 | -5.1 | 0.0 | 78.0 |
| OFF BEST | 4.0 | -99.3 | 0.0 | 108.7 | 3.3 | -104.4 | 18.3 | 38.7 |
| ONE CHECK AFTER THE LAST CHANGE | 1.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 1.7 | -15.0 | 0.0 | 108.7 | 6.0 | -166.6 | 0.0 | 38.7 |
| ONE OBJECTIVE FORMULA | 5.0 | +116.2 | 0.0 | 18.3 | 3.3 | +23.3 | 0.0 | 45.7 |
| ONE PROMISE A TARGET | - | - | - | - | 0.7 | -12.8 | 0.0 | 0.0 |
| ONE ROUTE | 2.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +16.7 | 10.0 | 0.0 | 0.7 | +81.2 | 18.3 | 0.0 |
| OVERRUNS AWAY | 0.3 | +55.0 | 10.0 | 0.0 | - | - | - | - |
| PERIAPT WORTH | 0.3 | +42.9 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.3 | -0.3 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 45.0 | +84.8 | 0.0 | 1087.3 | 36.0 | +312.0 | 321.7 | 567.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 1.3 | +0.0 | 0.0 | 0.0 | 9.0 | -277.9 | 0.0 | 34.7 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.7 | -0.4 | 0.0 | 34.7 |
| QUARTER ODDS | 22.3 | +2279.1 | 38.7 | 213.3 | 13.3 | +1674.0 | 11.3 | 0.0 |
| RANDOM MOVE BY FIGURES | 2.3 | +118.5 | 0.0 | 140.0 | 5.3 | +94.0 | 0.0 | 113.3 |
| REAL GROUND | 2.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 5.0 | +481.7 | 0.0 | 36.7 | 0.7 | +16.7 | 0.0 | 10.0 |
| REDIRECT FOR A FRIEND IN REACH | 6.7 | +0.0 | 0.0 | 48.0 | 4.3 | +0.0 | 0.0 | 10.0 |
| REFORMS TO MEET IT | 0.7 | -9.1 | 0.0 | 0.0 | 2.0 | -39.6 | 0.0 | 0.0 |
| RISK BY ARC | 0.7 | -51.6 | 55.0 | 0.0 | 1.7 | +58.4 | 306.0 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.7 | -14.8 | 55.0 | 0.0 | 1.3 | -46.6 | 287.7 | 0.0 |
| RUN DOWN | 0.7 | -4.5 | 55.0 | 0.0 | 1.7 | -13.0 | 287.7 | 0.0 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | 0.7 | -6.6 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.7 | +55.5 | 18.3 | 0.0 |
| SELF MOVE SPELL | 2.0 | -3.3 | 0.0 | 217.3 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 1.3 | -14.5 | 0.0 | 0.0 |
| SET UP BY THE SET | - | - | - | - | 3.0 | +28.8 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 1.7 | +6.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 3.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 38.7 |
| SHOOTS FROM THE BEST SPOT | 2.7 | +117.2 | 38.7 | 0.0 | 0.7 | +49.1 | 0.0 | 0.0 |
| SHOT RISK POINTS | 30.0 | +256.8 | 0.0 | 628.7 | 10.7 | +128.9 | 0.0 | 0.0 |
| SHOTS AFTER THE MOVES | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOTS IN THE MOVE | 8.7 | +293.8 | 0.0 | 99.7 | 7.3 | +356.7 | 0.0 | 36.0 |
| SPELL WORTH | 1.7 | +11.5 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 11.3 | +0.0 | 0.0 | 619.7 | 5.0 | +0.0 | 0.0 | 127.3 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -7.2 | 0.0 | 0.0 |
| STANDS FOR A REASON | 0.3 | +0.0 | 0.0 | 131.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 31.0 | +0.0 | 38.7 | 191.3 | 25.7 | +0.0 | 11.3 | 123.3 |
| STAY WORTH | 8.7 | +130.3 | 0.0 | 78.0 | 6.0 | +102.2 | 0.0 | 36.0 |
| STRIKE BY THE ODDS | 0.3 | +3.5 | 34.7 | 70.0 | 0.7 | +56.6 | 131.0 | 0.0 |
| STUBBORN BY POINTS | - | - | - | - | 0.3 | +1.2 | 0.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 9.3 | +838.5 | 0.0 | 73.3 | 2.7 | +17.6 | 0.0 | 10.0 |
| SUPPORT WORKED OUT | 9.3 | +838.5 | 0.0 | 73.3 | 2.7 | +17.6 | 0.0 | 10.0 |
| SURE REACH TOGETHER | - | - | - | - | 1.0 | +3.1 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.7 | +0.6 | 0.0 | 22.7 | 0.7 | +0.3 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 5.7 | +0.0 | 0.0 | 131.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 6.3 | +0.0 | 0.0 | 78.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 4.7 | +0.0 | 0.0 | 78.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 44.3 | +0.0 | 0.0 | 435.0 | 32.7 | +0.0 | 0.0 | 210.0 |
| TIED UP BY THE SUM | 0.7 | +83.3 | 55.0 | 0.0 | 1.3 | +201.1 | 175.0 | 0.0 |
| TIME ON OUR SIDE | 24.0 | +208.5 | 0.0 | 112.0 | 28.0 | +286.6 | 0.0 | 226.3 |
| WAITS AGAIN | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -39.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | - | - | - | - | 0.3 | -2.4 | 0.0 | 0.0 |
| WHO HITS BACK | 0.3 | +6.3 | 0.0 | 78.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 4.0 | -357.4 | 0.0 | 486.7 | 3.3 | -140.6 | 0.0 | 181.3 |
| WOUNDS ON THE RANKS | 1.3 | +18.0 | 0.0 | 0.0 | 2.0 | +801.5 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p34

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 129 | 129 | 75 | 25.00 | +940 | +12.5 |
| HOLDER ASSIGNMENT | 71 | 71 | 65 | 21.67 | +4329 | +66.6 |
| HIS SHOTS BY HIS RUN | 183 | 180 | 42 | 14.00 | +270 | +6.4 |
| REDIRECT FOR A FRIEND IN REACH | 33 | 33 | 33 | 11.00 | +0 | +0.0 |
| HIS SHOT LIST | 192 | 190 | 31 | 10.33 | +253 | +8.2 |
| SHOT RISK POINTS | 122 | 122 | 30 | 10.00 | +446 | +14.9 |
| DEPLOY BY FIGURES | 47 | 47 | 25 | 8.33 | +356 | +14.2 |
| THE TABLE AGAIN | 36 | 36 | 24 | 8.00 | +0 | +0.0 |
| TIME ON OUR SIDE | 156 | 138 | 24 | 8.00 | +48 | +2.0 |
| QUARTER ODDS | 107 | 104 | 23 | 7.67 | +1642 | +71.4 |
| OFF BEST | 22 | 22 | 22 | 7.33 | -611 | -27.8 |
| LEGAL CHARGES ONLY | 21 | 21 | 21 | 7.00 | +0 | +0.0 |
| GOAL WALK | 55 | 55 | 16 | 5.33 | +1547 | +96.7 |
| FIVE ACTION | 497 | 486 | 13 | 4.33 | +566 | +43.5 |
| MEETS IN TIME | 22 | 22 | 12 | 4.00 | +685 | +57.1 |
| RANDOM MOVE BY FIGURES | 23 | 23 | 12 | 4.00 | +637 | +53.1 |
| CHARGE LOSSES | 68 | 68 | 11 | 3.67 | +1351 | +122.8 |
| IDLE COST | 42 | 25 | 11 | 3.67 | +79 | +7.2 |
| PROMISE BY ITS OWN SUM | 31 | 31 | 11 | 3.67 | -834 | -75.8 |
| HARD STAY DROPPED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| MOVE ORDER | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 22 | 22 | 10 | 3.33 | +476 | +47.6 |
| SUPPORT ADDS | 36 | 36 | 9 | 3.00 | +206 | +22.9 |
| SUPPORT WORKED OUT | 36 | 36 | 9 | 3.00 | +206 | +22.9 |
| SHOOTS FROM THE BEST SPOT | 10 | 10 | 8 | 2.67 | +159 | +19.8 |
| ASSAILMENT BY POINTS | 7 | 7 | 7 | 2.33 | +38 | +5.4 |
| MOVE TO CHARGE COMPUTED | 23 | 17 | 6 | 2.00 | +51 | +8.6 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| MARCH CHECK | 5 | 5 | 5 | 1.67 | +122 | +24.3 |
| NEXT CHARGE BY LIST | 12 | 11 | 5 | 1.67 | +51 | +10.3 |
| TIED UP BY THE SUM | 6 | 5 | 5 | 1.67 | +291 | +58.2 |
| ADVANCE LANE KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| STAY WORTH | 44 | 38 | 4 | 1.33 | +18 | +4.4 |
| SWIFTSTRIDE BY POINTS | 4 | 4 | 4 | 1.33 | +3 | +0.7 |
| THE ROW IN ITS ORDER | 23 | 4 | 4 | 1.33 | +0 | +0.0 |
| FOUR ROUNDS | 9 | 8 | 3 | 1.00 | +266 | +88.5 |
| MANOEUVRE | 11 | 11 | 3 | 1.00 | +14 | +4.8 |
| MAX FOR POSITIONING | 13 | 11 | 3 | 1.00 | +13 | +4.3 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| STRIKE BY THE ODDS | 3 | 3 | 3 | 1.00 | +180 | +60.2 |
| FEATURE BUFFS | 12 | 12 | 2 | 0.67 | +10 | +4.8 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +479 | +239.6 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +72 | +36.2 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +55 | +27.5 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +318 | +158.8 |
| NEARER NOT NEEDED | 44 | 41 | 2 | 0.67 | +69 | +34.5 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -38 | -19.2 |
| OPENS UP | 3 | 2 | 2 | 0.67 | +11 | +5.6 |
| REDIRECT COUNTER | 17 | 12 | 2 | 0.67 | +43 | +21.4 |
| RISK BY ARC | 7 | 6 | 2 | 0.67 | +94 | +47.1 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +167 | +83.3 |
| SET UP BY THE SET | 9 | 8 | 2 | 0.67 | +0 | +0.2 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +103 | +103.4 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -48 | -47.7 |
| CAST JOB | 7 | 7 | 1 | 0.33 | +0 | +0.5 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +8 | +8.4 |
| CHARGE NOW FIRST | 3 | 3 | 1 | 0.33 | -112 | -111.8 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| COVER ONCE | 21 | 8 | 1 | 0.33 | +6 | +6.4 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +26 | +25.8 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.33 | +36 | +36.5 |
| EXACT ROUND | 7 | 6 | 1 | 0.33 | +0 | +0.2 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HORN WORTH | 1 | 1 | 1 | 0.33 | +8 | +8.4 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +80 | +80.2 |
| MISSILES IN THE MOVE | 20 | 10 | 1 | 0.33 | +6 | +6.1 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| NEXT OBJECTIVE NEARER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| ONE FIGHT FORMULA | 23 | 9 | 1 | 0.33 | +6 | +6.1 |
| ONE OBJECTIVE FORMULA | 25 | 19 | 1 | 0.33 | +6 | +6.1 |
| OVERRUNS AWAY | 1 | 1 | 1 | 0.33 | +0 | +0.2 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +129 | +128.7 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -1 | -1.0 |
| PROMISE KNOWS THE FIGHT | 2 | 1 | 1 | 0.33 | -1 | -1.2 |
| SHOTS IN THE MOVE | 48 | 32 | 1 | 0.33 | +1 | +1.1 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +4 | +3.5 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -117 | -117.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +0 | +0.3 |
| CHARACTER GUNS | 15 | 15 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 64 | 61 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 8 | 7 | 0 | 0.00 | - | - |
| FALLS SHORT | 56 | 43 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 34 | not checked | - | - | - | - |
| FOOT FIRST | 30 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 17 | 17 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 8 | not checked | - | - | - | - |
| GUN MASK | 2 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 9 | 9 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 27 | 27 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 8 | 8 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 16 | 15 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 27 | 27 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 57 | 57 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 24 | 19 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 109 | 105 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 30 | 30 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 123 | 123 | 0 | 0.00 | - | - |
| HONEST WORTH | 8 | 7 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 14 | 14 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 6 | 6 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 5 | not checked | - | - | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 9 | 9 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 24 | 13 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 2 | trace | - | - | - | - |
| NEAREST TO GOAL | 2 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 9 | 8 | 0 | 0.00 | - | - |
| NO LATE CUT | 5 | 5 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 11 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 8 | not checked | - | - | - | - |
| ONE ROUTE | 9 | 9 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 243 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 9 | 9 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 8 | 6 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 6 | 6 | 0 | 0.00 | - | - |
| RUN DOWN | 7 | 7 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SEARCH SPOT | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 4 | 3 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 5 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 20 | not checked | - | - | - | - |
| SHOTS AFTER THE MOVES | 5 | 5 | 0 | 0.00 | - | - |
| SPELL WORTH | 5 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 49 | 39 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 5 | 5 | 0 | 0.00 | - | - |
| STANDS STILL | 170 | 169 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 3 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 3 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 28 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 16 | not checked | - | - | - | - |
| THE TABLE BINDS | 231 | not checked | - | - | - | - |
| WAITS AGAIN | 3 | 3 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 10 | 10 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p34

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.33 | 2.67 | 25.4 |
| ARMY TABLE | rule | 2.67 | 2.00 | 28.5 |
| PROMISE BY ITS OWN SUM | rule | - | 3.67 | 75.8 |
| HOLDER ASSIGNMENT | rule | 1.00 | - | 23.7 |
| NO REASON | gate | - | 0.67 | 9.9 |
| ONE PROMISE A TARGET | rule | - | 0.67 | 19.2 |
| RULE SWITCHED OFF | gate | 0.67 | - | 67.5 |
| BEST PRIZE | rule | 0.33 | - | 47.7 |
| CHARGE NOW FIRST | rule | 0.33 | - | 111.8 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 1.0 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.33 | 1.2 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 117.0 |

### Plans: gs3-83c8646-p34

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.7 | 100% | 32 | 55 | 172% |
| Mine | move | 41.0 | 94% | 2402 | 0 | 0% |
| Mine | shoot | 2.7 | 12% | 216 | 30 | 14% |
| Mine | support | 0.7 | 100% | 1 | 0 | 0% |
| Opponent | charge | 1.7 | 80% | 260 | 289 | 111% |
| Opponent | join | 2.3 | 86% | 70 | 0 | 0% |
| Opponent | move | 30.3 | 91% | 1496 | 0 | 0% |
| Opponent | shoot | 1.7 | 80% | 100 | 23 | 23% |

### Battle groups: gs3-83c8646-p34

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 5.0 | 20% | 67% | 0% | - | 0% | 0% | 0% | 67% | 33% |
| Opponent | REDIRECT COUNTER | 0.7 | 100% | 100% | 0% | - | 0% | 0% | 50% | 50% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p34

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 8 | 61 (8) | 0 | 61 | 31 | 62% | 2.7 | 0 (1) | 100 (3) | 54 (4) | 61 (8) | - |
| Mine | Character | 7 | 33 (7) | 33 | 0 | 31 | 14% | 2.5 | 44 (4) | 0 (1) | - | 67 (3) | 0 (2) |
| Mine | Clean-up | 3 | 0 (3) | 0 | 0 | 14 | 100% | - | 0 (1) | 0 (2) | - | 0 (3) | - |
| Mine | Fast Hammer | 1 | 0 (1) | 0 | 0 | 115 | 0% | 3.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Hammer | 11 | 40 (11) | 25 | 15 | 36 | 27% | 2.4 | 32 (5) | 57 (5) | 0 (1) | 69 (6) | 0 (5) |
| Mine | Shooter | 3 | 0 (3) | 0 | 0 | 67 | 33% | 3.0 | 0 (2) | 0 (1) | - | - | 0 (3) |
| Mine | Wizard | 3 | 0 (3) | 0 | 0 | 101 | 33% | 2.5 | 0 (1) | 0 (2) | - | 0 (2) | 0 (1) |
| Opponent | Chaff | 4 | 0 (4) | 0 | 0 | 31 | 100% | - | 0 (3) | - | 0 (1) | 0 (4) | - |
| Opponent | Character | 8 | 52 (8) | 52 | 0 | 5 | 38% | 2.6 | 33 (3) | 59 (5) | - | 16 (6) | 142 (2) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | - | - | 0 (1) | 0 (1) | - |
| Opponent | Fast Hammer | 5 | 83 (5) | 0 | 83 | 51 | 40% | 2.0 | 86 (2) | 108 (2) | 22 (1) | 121 (3) | 12 (2) |
| Opponent | Hammer | 8 | 47 (8) | 47 | 0 | 29 | 25% | 2.8 | 51 (3) | 48 (4) | 0 (1) | 62 (6) | 0 (2) |
| Opponent | Holder | 4 | 49 (4) | 0 | 49 | 0 | 100% | - | 125 (1) | 22 (3) | - | 32 (2) | 68 (2) |
| Opponent | Shooter | 2 | 77 (2) | 77 | 0 | 0 | 0% | 1.5 | 31 (1) | 117 (1) | - | 31 (1) | 117 (1) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 38 | 33% | 3.5 | - | 0 (2) | - | 0 (1) | 0 (1) |

### Charged fights: gs3-83c8646-p34

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 1 | 116 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 442 | 3.0 | 1.0 | 147 | 326 | -179 | 1 of 3 | 2 of 3 | - | -179 |
| Mine | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 39 | 147 | 1.3 | 1.0 | 110 | 245 | -134 | 1 of 4 | 2 of 4 | - | -134 |
| Opponent | Warriors of Chaos | 2 | 0 | 130 | 2.0 | 1.0 | 65 | 0 | +65 | 3 of 4 | 3 of 4 | - | +65 |
| Opponent | Wood Elf Realms | 1 | 340 | 210 | 2.0 | 1.0 | 105 | 223 | -118 | 2 of 2 | 1 of 2 | - | -118 |
| **Opponent** | all armies | 3 | 113 | 157 | 2.0 | 1.0 | 78 | 74 | +4 | 5 of 6 | 4 of 6 | - | +4 |

### Effective charges: gs3-83c8646-p34

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Orc & Goblin Tribes | 3 | 0 | 0 | 0 | 0 | 0 | 1 (net +135) | 2 | 0% (0 of 1) |
| Opponent | Warriors of Chaos | 4 | 2 (net +130) | 0 | 0 | 0 | 0 | 2 (net +0) | 0 | 0% (0 of 4) |

### Charged fights, damage counted: gs3-83c8646-p34

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 350 | 135 | +135 | 135 | 0 | +135 | +38.6 |
| Mine | No odds | 3 | 165 | 269 | -224 | 140 | 372 | -232 | -140.5 |
| Mine | All fights | 4 | 211 | 235 | -134 | 139 | 279 | -140 | -66.4 |
| Opponent | Long shot (under 50%) | 2 | 308 | 297 | +130 | 141 | 19 | +122 | +39.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 494 | 245 | +0 | 126 | 27 | +99 | +20.1 |
| Opponent | No odds | 2 | 52 | 210 | -118 | 122 | 247 | -124 | -239.4 |
| Opponent | All fights | 6 | 284 | 251 | +4 | 130 | 98 | +32 | +11.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p34 | move | 17 | 2 (12%) | 2 (12%) | 3 (18%) | 12 (71%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Elixir of Power | Mine | L1932 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L2033 |
| Periapt of Soul Exchange | Mine | L2033 |
| Ring of Doom | Opponent | L1831, L2033 |

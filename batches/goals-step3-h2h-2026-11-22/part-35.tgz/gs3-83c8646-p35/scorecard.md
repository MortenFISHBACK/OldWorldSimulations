# Doctrine scorecard: gs3-83c8646-p35

### Scorecard: gs3-83c8646-p35

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2223 | 3 | 1 | Mine | no | 0 | 2 | 7 | 2 | 0 | 0 | 0 | 127 |
| L2223 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 1 | 0 | 0 | 66 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 6 | 2 | 2 | 0 | 0 | 72 |
| L2327 | 5 | 1 | Opponent | yes | - | 1 | 4 | 2 | 1 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Mine | no | 4 | 3 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 549 |
| **Average** | | | Mine | 33% | 2.0 | 2.3 | 5.7 | 2.0 | 0.7 | 0.0 | 0.0 | 66.3 |
| **Average** | | | Opponent | 33% | 0.0 | 1.7 | 3.7 | 1.3 | 0.7 | 0.0 | 0.0 | 205.0 |

### KPIs: gs3-83c8646-p35

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 17) | 33% (6 of 18) | 17% (6 of 35) |
| Winner chose to follow up after the loser gave ground |  | 100% (7 of 7); on the table 100% | 92% (11 of 12); on the table 92% | 95% (18 of 19); on the table 95% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 100% (3 of 3); on the table 100% | - | 100% (3 of 3); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (10 of 10); on the table 100% | 92% (11 of 12); on the table 92% | 95% (21 of 22); on the table 95% |
| Magic missiles tried each own turn | 50%+ | 17% (1 of 6) | - | 17% (1 of 6) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 17% (1 of 6) | - | 17% (1 of 6) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 46% (2134 of 4626) | 34% (2015 of 6000) | 39% (4149 of 10626) |
|   infantry points that never fought | lower | 94% (872 of 932) | 47% (579 of 1219) | 67% (1451 of 2151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 38% (5 of 13) | 76% (16 of 21) | 62% (21 of 34) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (2 of 2); 3.3 uses a game | 100% (2 of 2); 1.7 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 36% (1342 of 3685) | 69% (3435 of 4954) | 55% (4777 of 8639) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (40%) | - | 0.7 (40%) |
| MARCHED: its unit marched | 0.7 (40%) | - | 0.7 (40%) |
| CHARGED: its unit charged | 0.3 (20%) | - | 0.3 (20%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 15.3 | 0.3 | 2.0 | 0.3 | 1.3 | 0.0 |
| not cast | 2.7 | 1.7 | 2.0 | 1.7 | 0.7 | 24.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.7 (100%) | 0.3 (17%) | 0.7 (40%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (40%) | 0.3 (50%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (20%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.7 (25%) | 0.0 (0%) | 0.7 (33%) | 0.0 (0%) | 0.0 (0%) | 2.7 (11%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (50%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (75%) | 0.0 (0%) | 1.0 (50%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 21.3 (89%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.7 a game | 0.3 a game | 1.0 a game |
| stood (cast and not dispelled) | 80% (4 of 5) | 100% (1 of 1) | 83% (5 of 6) |
| the unit moved after it | 50% (2 of 4) | 100% (1 of 1) | 60% (3 of 5) |
| it charged on its next turn | 0% (0 of 4) | 0% (0 of 1) | 0% (0 of 5) |
| the enemy charged it first | 0% (0 of 4) | 0% (0 of 1) | 0% (0 of 5) |
| it fought by the end of its next turn | 0% (0 of 4) | 0% (0 of 1) | 0% (0 of 5) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 4) | 0% (0 of 1) | 0% (0 of 5) |
| none of these (no charge, no fight, no charge escaped) | 100% (4 of 4) | 100% (1 of 1) | 100% (5 of 5) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 62% (35 of 56) | 63% (42 of 67) | 63% (77 of 123) |
|   cavalry | 78% (7 of 9) | 69% (9 of 13) | 73% (16 of 22) |
|   character | 0% (0 of 13) | 30% (6 of 20) | 18% (6 of 33) |
|   chariot | 60% (3 of 5) | - | 60% (3 of 5) |
|   infantry | 86% (25 of 29) | 79% (27 of 34) | 83% (52 of 63) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.0 (0%) | 0.7 (8%) | 0.7 (4%) |
| CHARGED: it charged | 3.7 (52%) | 2.0 (24%) | 5.7 (37%) |
| IN COMBAT: it fought this turn or the last | 0.7 (10%) | 1.7 (20%) | 2.3 (15%) |
| NO TARGET IN RANGE | 1.0 (14%) | 2.3 (28%) | 3.3 (22%) |
| ONLY IN COMBAT: the only targets were in combat | 1.0 (14%) | 0.3 (4%) | 1.3 (9%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (10%) | 1.3 (16%) | 2.0 (13%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 8.3 | 2.3 | 80% | 4.3 pts | 36 pts |
| character | 2.0 | 0.3 | 83% | 5.4 pts | 11 pts |
| chariot | 1.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 29.0 | 13.0 | 72% | 9.9 pts | 286 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 6.7 | 5.3 | 6.0 |
| Charges that made contact a game | 5.3 | 4.7 | 5.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.00 contact (1 units) | - | 1.00 declared, 0.00 contact (1 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.33 declared, 0.33 contact (3 units) | 0.25 declared, 0.25 contact (4 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.95 declared, 0.80 contact (20 units) | 0.50 declared, 0.43 contact (30 units) | 0.68 declared, 0.58 contact (50 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 40% (2 of 5) | 100% (1 of 1) | 100% (1 of 1) | 57% (4 of 7) |
| Character in a unit | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Character on its own | 100% (5 of 5) | 0% (0 of 1) | 38% (3 of 8) | 57% (8 of 14) |
| Infantry | 50% (1 of 2) | 60% (3 of 5) | - | 57% (4 of 7) |
| Monster | 75% (3 of 4) | - | - | 75% (3 of 4) |
| Monstrous | 100% (1 of 1) | - | - | 100% (1 of 1) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Tomb Kings of Khemri | 3 | 100% (2 of 2); on the table 100% | - | 37% | 55% (6 of 11) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 2 | 100% (17 of 17); on the table 100% | 17% (1 of 6) | 39% | 46% (6 of 13) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 67% (2 of 3); on the table 67% | - | 43% | 90% (9 of 10) | 100% (2 of 2); 10.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p35, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 67% (2) | 40% (4) | 46% (6) |
| ...free all their last turn and able to turn (per game) | 0.33 | 1.33 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 1.33 | 1.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 1.00 | 0.33 | 1.33 |

### Quality by phase: gs3-83c8646-p35

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 76% (13 of 17) | 83% (10 of 12) |
| Strategy | Shoot objectives carried out (shot that target) | 43% (6 of 14) | 55% (6 of 11) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 1) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 2) | 0% (0 of 2) |
| Strategy | Lone characters that fought | 71% (5 of 7) | 73% (8 of 11) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 2.0 | 1.3 |
| Movement | Points that never moved of their own | 66.3 | 205.0 |
| Movement | Fights charged into per game | 5.7 | 4.0 |
| Movement | Charges with odds: long shots (under 50%) | 6 of 14, net +254 | 1 of 11, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 14, net +0 | 2 of 11, net +130 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 4 of 14, net +111 | 3 of 11, net +0 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 14, net +63 | 2 of 11, net +60 |
| Shooting | Shots by shooting units (incl. breath weapons) | 12.7 | 20.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 63% (24 of 38) | 31% (19 of 61) |
| Shooting | Points destroyed by shooting units | 33.0 | 24.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.3 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 1) | - |
| Magic | Wounds caused by magic missiles | 0.3 | 0.3 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 6.7 / 0.3 / 0.0 / 0.0 | 3.7 / 0.0 / 0.0 / 1.3 |
| Combat | Points destroyed in combat | 693.3 | 352.0 |
| Combat | Points run down | 252.7 | 0.0 |
| Combat | Net points per charged fight, damage counted | +140 | +73 |
| Combat | Net per 100 charger points, damage counted | +50.3 | +32.4 |
| Combat | First round won (charged fights) | 82% | 83% |
| Combat | Net points per charged fight | +149 | +71 |
| Combat | Net points per supported fight / lone fight | - / +149 | +540 / +28 |
| Combat | Charged fights on a top-3 enemy unit | 6 of 17 | 4 of 12 |
| Game | Points lost | 433.0 | 879.0 |
| Game | VP from objectives | 676.7 | 433.3 |
| Game | Lone holders (player turns) | 2.0 | 0.0 |

- Mine won / drew / lost: 1 / 2 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +702 VP
- The side that went first won 1 of 1 games with a winner
- Points traded per game (both sides' losses): 1312
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p35

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.3 | +1.8 | 0.0 | 0.0 |
| ARMY TABLE | 27.0 | +404.0 | 0.0 | 128.0 | 23.3 | -162.9 | 0.0 | 91.3 |
| BACKUP TARGETS | 1.0 | +1.5 | 0.0 | 0.0 | 0.3 | +1.7 | 0.0 | 0.0 |
| CAST JOB | 0.7 | +7.3 | 157.3 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 63.3 |
| CASTS FROM BEHIND | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 2.7 | +82.7 | 0.0 | 20.0 | 1.0 | +53.6 | 0.0 | 0.0 |
| CHAFF PASSED | 1.3 | -1.3 | 0.0 | 46.0 | 0.3 | -2.4 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.7 | +21.8 | 0.0 | 0.0 | 1.0 | +6.6 | 0.0 | 78.7 |
| CHAMPION KNOWS CHALLENGE | 0.3 | -4.9 | 91.3 | 0.0 | - | - | - | - |
| CHARACTER GUNS | - | - | - | - | 3.3 | +0.0 | 0.0 | 182.7 |
| CHARGE LIST READ AGAIN | 0.3 | +9.8 | 78.7 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 20.3 | -373.9 | 0.0 | 300.0 | 19.7 | -1328.1 | 0.0 | 832.7 |
| CHARGE NOW FIRST | 3.0 | +0.0 | 380.7 | 180.0 | 1.3 | +0.0 | 70.0 | 23.3 |
| CHARGER SLAIN LOST | 0.3 | -9.8 | 91.3 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 11.0 | +0.0 | 0.0 | 170.0 | 14.0 | +0.0 | 0.0 | 127.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 1.3 | +106.6 | 0.0 | 0.0 | 0.3 | +42.1 | 63.3 | 63.3 |
| COVER ONCE | 8.0 | -261.0 | 0.0 | 65.0 | 11.0 | -440.6 | 0.0 | 231.0 |
| DEPLOY BY FIGURES | 7.0 | +1.1 | 0.0 | 0.0 | 7.7 | -34.6 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 1.3 | -136.7 | 143.3 | 360.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.3 | +7.2 | 22.0 | 0.0 | 0.3 | +10.2 | 22.0 | 0.0 |
| EXACT ROUND | 3.7 | +25.2 | 295.3 | 24.0 | 3.0 | +38.8 | 250.0 | 23.3 |
| FALL BACK GOOD ORDER | 5.7 | +0.0 | 550.7 | 384.0 | 2.3 | +0.0 | 424.0 | 0.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 8.7 | +75.5 | 0.0 | 20.0 | 14.3 | +121.7 | 0.0 | 256.0 |
| FEATURE BUFFS | - | - | - | - | 0.7 | +4.1 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.0 | +87.9 | 91.3 | 0.0 | 1.0 | +56.3 | 180.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 18.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 94.3 | +6701.9 | 1131.3 | 970.0 | 92.0 | +5840.1 | 909.0 | 1406.7 |
| FLANK NOT WEIGHED | 7.3 | +0.0 | 0.0 | 85.0 | 13.0 | +0.0 | 0.0 | 211.3 |
| FOLLOW UP WEIGHED | 1.7 | +182.2 | 0.0 | 0.0 | 0.7 | +220.2 | 0.0 | 0.0 |
| FOOT FIRST | - | - | - | - | 21.7 | +0.0 | 0.0 | 365.7 |
| FOUR ROUNDS | 7.0 | +1007.6 | 648.7 | 384.0 | 4.3 | +337.9 | 492.0 | 23.3 |
| FREED FROM HIS FIGHT | 1.7 | +0.0 | 0.0 | 0.0 | 13.0 | +0.0 | 0.0 | 91.3 |
| FRIEND CHARGES FIRST | 0.3 | -2.3 | 0.0 | 0.0 | 0.7 | -23.4 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 1.3 | -28.5 | 30.0 | 0.0 | 1.0 | -10.9 | 0.0 | 46.7 |
| GIVES UP | 1.7 | -33.0 | 103.3 | 180.0 | 1.0 | -43.9 | 180.0 | 0.0 |
| GOAL WALK | 7.3 | +730.5 | 0.0 | 0.0 | 7.0 | +440.3 | 0.0 | 0.0 |
| HARD STAY DROPPED | 3.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 23.3 |
| HE REFORMS ONCE FREED | 1.0 | +0.0 | 0.0 | 0.0 | 8.3 | +0.0 | 0.0 | 34.7 |
| HELPER UNSEEN | - | - | - | - | 0.3 | +0.0 | 22.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 9.7 | +0.0 | 0.0 | 235.0 | 15.0 | +0.0 | 0.0 | 686.0 |
| HIS CHARGE DENIED | 0.3 | +18.6 | 0.0 | 0.0 | 0.3 | +13.9 | 0.0 | 0.0 |
| HIS CHARGE LIST | 5.0 | +0.0 | 0.0 | 0.0 | 10.7 | +0.0 | 0.0 | 65.0 |
| HIS LEGAL MOVES | 9.3 | +0.0 | 0.0 | 84.0 | 6.0 | +0.0 | 0.0 | 182.7 |
| HIS MOVE AND SHOT | 6.3 | -32.2 | 0.0 | 65.0 | 5.7 | -57.8 | 0.0 | 100.0 |
| HIS ONE QUARTER | 9.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 129.3 |
| HIS OWN BEST MOVE | 15.0 | +0.0 | 0.0 | 214.0 | 11.3 | +0.0 | 0.0 | 294.3 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 41.0 | +961.8 | 0.0 | 411.0 | 41.0 | +505.2 | 0.0 | 897.3 |
| HIS SHOTS BY HIS RUN | 42.7 | +593.1 | 0.0 | 498.0 | 45.0 | +300.2 | 0.0 | 1060.7 |
| HIS TURN DENIED | 0.7 | +36.9 | 20.0 | 0.0 | 2.0 | +6.1 | 108.0 | 0.0 |
| HOLD ODDS | 13.7 | +0.0 | 0.0 | 44.0 | 11.7 | +0.0 | 0.0 | 124.0 |
| HOLDER ASSIGNMENT | 9.3 | +553.2 | 0.0 | 44.0 | 8.0 | +585.9 | 0.0 | 102.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 6.7 | -364.7 | 648.7 | 360.0 | 4.3 | -128.3 | 492.0 | 23.3 |
| HORN WORTH | - | - | - | - | 0.3 | +1.2 | 0.0 | 0.0 |
| HUNT IN PAIRS | 3.3 | +111.8 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | 4.0 | -73.8 | 0.0 | 0.0 | 10.3 | -139.8 | 0.0 | 126.7 |
| JOINT CHARGE NOW | 0.3 | -35.6 | 91.3 | 0.0 | 0.3 | -19.2 | 24.0 | 0.0 |
| JOINT KNOWS CHALLENGE | 0.3 | -1.0 | 91.3 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 22.0 | 3.3 | +0.0 | 0.0 | 44.0 |
| LANE BY FIGURES | 1.0 | +25.1 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 19.0 | +0.0 | 237.3 | 1534.0 | 14.0 | +0.0 | 525.0 | 443.7 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.3 | +1.7 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 1.0 | +19.6 | 0.0 | 0.0 | 0.3 | +7.5 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 1.0 | +0.6 | 91.3 | 0.0 | 0.3 | -0.0 | 0.0 | 0.0 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| MANOEUVRE | 1.7 | +0.0 | 0.0 | 0.0 | 2.0 | -1.3 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +31.4 | 0.0 | 0.0 | 0.3 | +14.1 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 1.3 | +51.3 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | -34.7 | 0.0 | 0.0 | 0.3 | -0.9 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.3 | +54.2 | 0.0 | 0.0 | 4.0 | +108.9 | 0.0 | 0.0 |
| MEETS IN TIME | 3.7 | +86.8 | 0.0 | 0.0 | 4.0 | +290.1 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 0.3 | +17.2 | 0.0 | 0.0 | 3.7 | +57.6 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 1.0 | +20.0 | 0.0 | 0.0 | 3.3 | +39.7 | 0.0 | 0.0 |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 11.0 | +1060.7 | 0.0 | 130.0 | 9.0 | +373.3 | 0.0 | 111.7 |
| NEARER NOT NEEDED | 14.3 | +592.3 | 0.0 | 86.0 | 7.7 | +326.8 | 0.0 | 155.3 |
| NEAREST TO GOAL | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 8.7 | +890.5 | 30.0 | 130.0 | 5.0 | +238.9 | 0.0 | 88.3 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -9.2 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 5.3 | -185.1 | 568.7 | 24.0 | 2.7 | -68.0 | 84.0 | 0.0 |
| NO LATE CUT | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 1.0 | +26.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 1.3 | -1.7 | 0.0 | 0.0 |
| OFF BEST | 5.7 | -220.6 | 98.7 | 68.0 | 7.0 | -446.3 | 0.0 | 83.3 |
| ONE CHALLENGE TEST | 0.3 | +82.3 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 6.3 | -119.8 | 0.0 | 89.0 | 7.7 | -148.4 | 0.0 | 88.3 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +6.7 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 5.3 | -104.4 | 0.0 | 22.0 | 3.0 | -43.6 | 0.0 | 60.0 |
| ONE PROMISE A TARGET | 0.7 | -26.0 | 0.0 | 0.0 | 0.3 | -19.4 | 0.0 | 0.0 |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 1.3 | +58.8 | 88.3 | 0.0 | 0.7 | +32.2 | 20.0 | 0.0 |
| OVERRUNS AWAY | 2.0 | +28.9 | 193.0 | 0.0 | 1.0 | +15.7 | 48.0 | 23.3 |
| PATHS CROSS | - | - | - | - | 0.7 | +3.5 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -3.7 | 0.0 | 0.0 |
| PLAN RESULT | 45.7 | +581.5 | 345.0 | 836.0 | 45.7 | +694.0 | 503.3 | 1128.7 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 65.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 10.7 | -232.6 | 0.0 | 0.0 | 12.7 | -234.8 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.7 | +0.0 | 30.0 | 0.0 | 0.3 | +0.0 | 0.0 | 23.3 |
| PROMISE KNOWS THE FIGHT | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -3.4 | 0.0 | 0.0 | 0.7 | -9.7 | 0.0 | 23.3 |
| PURSUES BIG PREY | 0.3 | -17.6 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 24.3 | +3043.5 | 549.3 | 24.0 | 24.7 | +2161.9 | 68.0 | 508.7 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.3 | +38.7 | 0.0 | 20.0 | - | - | - | - |
| REDIRECT COUNTER | 4.7 | +129.4 | 0.0 | 132.0 | 4.3 | +142.6 | 0.0 | 84.0 |
| REDIRECT FOR A FRIEND IN REACH | 4.3 | +49.5 | 0.0 | 154.0 | 3.7 | +0.0 | 0.0 | 55.0 |
| REFORMS TO MEET IT | 5.0 | -102.4 | 0.0 | 0.0 | 2.7 | -55.7 | 0.0 | 46.7 |
| REFUSING RETIRES | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 1.3 | +37.8 | 0.0 | 46.0 | 1.3 | +30.6 | 0.0 | 40.0 |
| RISK BY ARC | 5.3 | +21.4 | 398.7 | 204.0 | 3.7 | -11.0 | 312.0 | 23.3 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | 0.7 | -1.7 | 78.7 | 0.0 | - | - | - | - |
| RUN DOWN | 1.3 | -6.5 | 170.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 1.3 | +0.5 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 1.0 | -47.8 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 1.0 | +16.1 | 0.0 | 22.0 | 1.3 | +3.3 | 0.0 | 0.0 |
| SECOND LOOK | 1.3 | +33.4 | 142.7 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.7 | -1.2 | 0.0 | 40.0 | 4.0 | -96.6 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.7 | +1.2 | 0.0 | 40.0 | 6.0 | +150.7 | 180.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +1.3 | 0.0 | 0.0 | 0.3 | +1.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 6.3 | +0.0 | 0.0 | 22.0 | 3.7 | +0.0 | 0.0 | 42.0 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +2.9 | 143.3 | 0.0 | 1.0 | +8.4 | 24.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -1.3 | 78.7 | 0.0 | 0.3 | -6.0 | 0.0 | 0.0 |
| SHOT RISK POINTS | 27.0 | +15.6 | 0.0 | 235.0 | 29.7 | -33.1 | 0.0 | 541.3 |
| SHOTS AFTER THE MOVES | 2.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 18.3 | +152.1 | 0.0 | 132.0 | 12.7 | +307.9 | 0.0 | 237.3 |
| SPELL SETS UP CHARGE | 0.3 | +113.0 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 4.0 | +57.0 | 0.0 | 0.0 | 4.7 | +25.9 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 6.3 | +0.0 | 0.0 | 20.0 | 8.0 | +0.0 | 0.0 | 248.3 |
| STAND AND SHOOT | 0.7 | -2.2 | 22.0 | 24.0 | 1.0 | -1.0 | 70.0 | 23.3 |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 22.0 | 2.0 | +0.0 | 0.0 | 66.0 |
| STANDS STILL | 37.0 | +0.0 | 482.7 | 110.0 | 27.3 | +0.0 | 417.0 | 492.7 |
| STAY WORTH | 11.7 | -3.2 | 213.3 | 44.0 | 12.0 | +155.0 | 328.0 | 166.0 |
| STRIKE BY THE ODDS | 0.7 | +12.6 | 0.0 | 360.0 | - | - | - | - |
| STUPIDITY NEXT TURN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 4.3 | +230.3 | 0.0 | 0.0 | 17.7 | +1991.7 | 0.0 | 99.7 |
| SUPPORT NARROWED | - | - | - | - | 0.7 | +0.0 | 24.0 | 23.3 |
| SUPPORT WORKED OUT | 4.3 | +230.3 | 0.0 | 0.0 | 17.7 | +1991.7 | 0.0 | 99.7 |
| SURE REACH TOGETHER | - | - | - | - | 0.7 | +0.9 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 44.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -3.4 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 25.0 |
| THE STEP BACK IS MADE | 2.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 25.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 44.7 | +0.0 | 0.0 | 282.0 | 45.3 | +0.0 | 0.0 | 548.3 |
| TIED UP BY THE SUM | 3.3 | +359.5 | 356.0 | 0.0 | 2.0 | +175.2 | 86.0 | 0.0 |
| TIME ON OUR SIDE | 36.3 | +301.9 | 0.0 | 438.0 | 18.7 | +204.4 | 0.0 | 294.0 |
| WAITS AGAIN | 0.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| WEAPON BY POINTS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | 0.7 | -54.4 | 157.3 | 0.0 | 1.3 | +75.5 | 720.0 | 0.0 |
| WHO FIGHTS | 0.7 | -3.7 | 22.0 | 24.0 | 1.3 | +11.1 | 44.0 | 0.0 |
| WHO GETS IN | - | - | - | - | 0.3 | -19.2 | 24.0 | 0.0 |
| WHO HITS BACK | 1.0 | +13.7 | 0.0 | 0.0 | 1.3 | +112.3 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.3 | +25.6 | 78.7 | 0.0 | 0.7 | -0.2 | 360.0 | 0.0 |
| WHOLE FIGHT DANGER | 1.3 | -80.2 | 0.0 | 105.0 | 5.3 | -1125.6 | 0.0 | 642.7 |
| WHOLE FIGHT GAIN | 0.3 | +35.6 | 91.3 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | - | - | - | - | 4.0 | +23.4 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p35

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| LEGAL CHARGES ONLY | 99 | 99 | 99 | 33.00 | +0 | +0.0 |
| ARMY TABLE | 151 | 151 | 94 | 31.33 | +495 | +5.3 |
| FIVE ACTION | 559 | 538 | 55 | 18.33 | +4704 | +85.5 |
| HOLDER ASSIGNMENT | 52 | 52 | 46 | 15.33 | +2200 | +47.8 |
| OFF BEST | 38 | 38 | 38 | 12.67 | -2000 | -52.6 |
| HIS SHOT LIST | 246 | 237 | 33 | 11.00 | +473 | +14.3 |
| QUARTER ODDS | 147 | 145 | 30 | 10.00 | +2124 | +70.8 |
| HIS SHOTS BY HIS RUN | 263 | 250 | 29 | 9.67 | +191 | +6.6 |
| MOVE TO CHARGE COMPUTED | 60 | 53 | 29 | 9.67 | +1216 | +41.9 |
| PROMISE BY ITS OWN SUM | 70 | 70 | 28 | 9.33 | -1402 | -50.1 |
| THE TABLE AGAIN | 36 | 36 | 28 | 9.33 | +0 | +0.0 |
| SUPPORT ADDS | 66 | 66 | 24 | 8.00 | +1771 | +73.8 |
| SUPPORT WORKED OUT | 66 | 66 | 24 | 8.00 | +1771 | +73.8 |
| REDIRECT FOR A FRIEND IN REACH | 24 | 24 | 23 | 7.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 165 | 137 | 20 | 6.67 | +82 | +4.1 |
| FOUR ROUNDS | 34 | 32 | 18 | 6.00 | +1335 | +74.2 |
| NEXT CHARGE BY LIST | 41 | 40 | 17 | 5.67 | +1057 | +62.2 |
| DEPLOY BY FIGURES | 44 | 44 | 16 | 5.33 | +134 | +8.4 |
| GOAL WALK | 43 | 42 | 16 | 5.33 | +794 | +49.7 |
| HARD STAY DROPPED | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| TIED UP BY THE SUM | 16 | 14 | 12 | 4.00 | +435 | +36.2 |
| MEETS IN TIME | 23 | 23 | 9 | 3.00 | +517 | +57.5 |
| MOVE ORDER | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| SHOT RISK POINTS | 170 | 166 | 9 | 3.00 | +173 | +19.3 |
| CHARGE LOSSES | 120 | 118 | 8 | 2.67 | +1120 | +140.0 |
| COVER ONCE | 57 | 36 | 8 | 2.67 | +155 | +19.4 |
| RESERVE FALL BACK | 8 | 8 | 8 | 2.67 | +205 | +25.7 |
| SET UP BY THE SET | 20 | 20 | 8 | 2.67 | +226 | +28.2 |
| FOLLOW UP WEIGHED | 7 | 7 | 7 | 2.33 | +1207 | +172.5 |
| WHO HITS BACK | 7 | 7 | 7 | 2.33 | +234 | +33.4 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| FALLS SHORT | 69 | 64 | 6 | 2.00 | +30 | +5.0 |
| SCOUT WAITS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SEARCH SPOT | 7 | 7 | 6 | 2.00 | +58 | +9.7 |
| CHAFF PASSED | 5 | 5 | 5 | 1.67 | -11 | -2.2 |
| CHALLENGE BY POINTS | 5 | 5 | 5 | 1.67 | +85 | +17.0 |
| IDLE COST | 43 | 23 | 5 | 1.67 | +30 | +6.1 |
| STAY WORTH | 71 | 64 | 5 | 1.67 | +58 | +11.5 |
| CHAFF IN THE MOVE | 11 | 10 | 4 | 1.33 | +65 | +16.2 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +81 | +20.3 |
| MARCH CHECK | 4 | 4 | 4 | 1.33 | +58 | +14.6 |
| NEARER NOT NEEDED | 66 | 64 | 4 | 1.33 | +148 | +37.1 |
| REDIRECT COUNTER | 27 | 21 | 4 | 1.33 | +242 | +60.5 |
| RISK BY ARC | 27 | 25 | 4 | 1.33 | +23 | +5.8 |
| SECOND LOOK | 4 | 4 | 4 | 1.33 | +100 | +25.1 |
| SHOTS IN THE MOVE | 93 | 73 | 4 | 1.33 | +189 | +47.2 |
| CASTS FROM BEHIND | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| EXACT ROUND | 20 | 19 | 3 | 1.00 | +17 | +5.7 |
| FIGHT TO THE END | 6 | 6 | 3 | 1.00 | +233 | +77.7 |
| LANE BY FIGURES | 3 | 3 | 3 | 1.00 | +75 | +25.1 |
| MAX FOR POSITIONING | 19 | 15 | 3 | 1.00 | +8 | +2.7 |
| ONE PROMISE A TARGET | 3 | 3 | 3 | 1.00 | -136 | -45.4 |
| CAST JOB | 2 | 2 | 2 | 0.67 | +9 | +4.7 |
| CHARGE NOW FIRST | 13 | 13 | 2 | 0.67 | -330 | -165.1 |
| EDGE GIVE GROUND | 2 | 2 | 2 | 0.67 | +5 | +2.3 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | -164 | -82.2 |
| MANOEUVRE | 11 | 11 | 2 | 0.67 | +13 | +6.6 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +136 | +68.2 |
| OVERRUNS AWAY | 9 | 9 | 2 | 0.67 | +30 | +15.2 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +10 | +5.2 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +9 | +4.5 |
| SHOOTS FROM THE BEST SPOT | 5 | 5 | 2 | 0.67 | +5 | +2.5 |
| SHOTS AFTER THE MOVES | 14 | 14 | 2 | 0.67 | +0 | +0.0 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +38 | +18.9 |
| WHAT THE JOINER ADDS | 6 | 4 | 2 | 0.67 | +84 | +42.1 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +5 | +5.4 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +29 | +29.4 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS CHARGE DENIED | 2 | 2 | 1 | 0.33 | +20 | +20.5 |
| HIS MOVE AND SHOT | 36 | 34 | 1 | 0.33 | +3 | +2.8 |
| HIS TURN DENIED | 8 | 8 | 1 | 0.33 | +5 | +4.5 |
| HORN WORTH | 1 | 1 | 1 | 0.33 | +4 | +3.6 |
| HUNT IN PAIRS | 10 | 4 | 1 | 0.33 | +18 | +18.1 |
| NO DOUBLE ROUNDS | 24 | 22 | 1 | 0.33 | +5 | +4.6 |
| ONE CHALLENGE TEST | 1 | 1 | 1 | 0.33 | +149 | +149.2 |
| OPENS UP | 6 | 6 | 1 | 0.33 | +26 | +25.5 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -11 | -11.1 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.33 | -53 | -52.8 |
| REFUSING RETIRES | 3 | 3 | 1 | 0.33 | -3 | -3.3 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 6 | 6 | 1 | 0.33 | +42 | +41.7 |
| WHO GETS IN | 1 | 1 | 1 | 0.33 | -58 | -57.6 |
| WHOLE FIGHT DANGER | 20 | 20 | 1 | 0.33 | +111 | +110.6 |
| WHOLE FIGHT GAIN | 1 | 1 | 1 | 0.33 | +106 | +105.6 |
| BACKUP TARGETS | 4 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 5 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 10 | 9 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 75 | 75 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 5 | not checked | - | - | - | - |
| DUEL STOPS AT THE KILL | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 24 | 22 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 61 | not checked | - | - | - | - |
| FOOT FIRST | 65 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 44 | 42 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 3 | 3 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 7 | 7 | 0 | 0.00 | - | - |
| GIVES UP | 8 | 7 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 28 | 27 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 74 | 74 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 47 | 47 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 46 | 45 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 44 | 44 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 79 | 77 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 76 | 76 | 0 | 0.00 | - | - |
| HONEST WORTH | 33 | 31 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 18 | 18 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 4 | 4 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 12 | 8 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 13 | 9 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NEAREST TO GOAL | 4 | 3 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 4 | 4 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 42 | 21 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 25 | 22 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 274 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 7 | 3 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 3 | 3 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 23 | 20 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 4 | 3 | 0 | 0.00 | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 14 | 14 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 30 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 1 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 26 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 43 | 40 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 5 | 5 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 7 | 0 | 0.00 | - | - |
| STANDS STILL | 193 | 184 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 2 | 2 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 2 | 2 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 2 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 10 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 10 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 10 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 11 | not checked | - | - | - | - |
| THE TABLE BINDS | 270 | not checked | - | - | - | - |
| WAITS AGAIN | 12 | 12 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 3 | 2 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 12 | 12 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p35

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.33 | 5.33 | 55.1 |
| PROMISE BY ITS OWN SUM | rule | 3.67 | 5.33 | 51.9 |
| ARMY TABLE | rule | 2.00 | 3.67 | 69.2 |
| CHAFF PASSED | rule | 1.00 | 0.33 | 2.8 |
| ONE PROMISE A TARGET | rule | 0.67 | 0.33 | 45.4 |
| RULE SWITCHED OFF | gate | 1.00 | - | 42.7 |
| AFTERMATH BAND | gate | 0.33 | 0.33 | 2.4 |
| CHARGE NOW FIRST | rule | 0.67 | - | 165.1 |
| JOINT CHARGE NOW | rule | 0.33 | 0.33 | 82.2 |
| NO REASON | gate | - | 0.67 | 93.8 |
| FALLBACK | gate | - | 0.33 | 81.5 |
| FIGHT ORDER BAND | gate | - | 0.33 | 0.8 |
| HOLDER ASSIGNMENT | rule | - | 0.33 | 16.4 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 11.1 |
| PURSUES BIG PREY | rule | 0.33 | - | 52.8 |
| REFUSING RETIRES | rule | 0.33 | - | 3.3 |
| WHO GETS IN | rule | - | 0.33 | 57.6 |

### Plans: gs3-83c8646-p35

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 6.0 | 72% | 859 | 446 | 52% |
| Mine | join | 1.3 | 100% | 67 | 0 | 0% |
| Mine | move | 34.3 | 96% | 1773 | 0 | 0% |
| Mine | shoot | 3.3 | 70% | 156 | 135 | 87% |
| Mine | support | 0.7 | 50% | 58 | 0 | 0% |
| Opponent | charge | 4.3 | 92% | 472 | 603 | 128% |
| Opponent | join | 2.7 | 100% | 100 | 0 | 0% |
| Opponent | move | 35.0 | 93% | 2392 | 0 | 0% |
| Opponent | shoot | 3.0 | 67% | 248 | 91 | 37% |
| Opponent | support | 0.7 | 100% | 62 | 0 | 0% |

### Battle groups: gs3-83c8646-p35

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.7 | 64% | 33% | 11% | 0% | 12% | 0% | 0% | 88% | 0% |
| Opponent | REDIRECT COUNTER | 4.3 | 23% | 100% | 33% | 0% | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p35

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 5 | 99 (5) | 62 | 37 | 61 | 0% | 1.2 | 244 (2) | - | 0 (3) | 244 (2) | 0 (3) |
| Mine | Character | 7 | 94 (7) | 94 | 0 | 24 | 14% | 2.3 | 92 (4) | 96 (3) | - | 126 (3) | 68 (4) |
| Mine | Clean-up | 4 | 52 (4) | 0 | 52 | 0 | 100% | - | 0 (2) | 68 (2) | - | 109 (2) | 0 (2) |
| Mine | Fast Hammer | 4 | 55 (4) | 55 | 0 | 44 | 25% | 2.3 | 0 (1) | 14 (2) | 260 (1) | 19 (2) | 83 (2) |
| Mine | Holder | 4 | 18 (4) | 18 | 0 | 0 | 0% | 1.2 | 0 (1) | 0 (1) | 35 (2) | 0 (1) | 24 (3) |
| Mine | Shooter | 1 | 29 (1) | 29 | 0 | 0 | 0% | 3.0 | 29 (1) | - | - | 29 (1) | - |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | - | - | 0 (2) | - |
| Opponent | Chaff | 8 | 23 (8) | 16 | 7 | 76 | 25% | 2.5 | 53 (3) | 0 (2) | 20 (3) | 53 (3) | 10 (5) |
| Opponent | Character | 10 | 29 (10) | 29 | 0 | 35 | 10% | 2.3 | 48 (4) | 23 (4) | 0 (1) | 41 (6) | 18 (3) |
| Opponent | Fast Hammer | 9 | 31 (9) | 31 | 0 | 58 | 11% | 2.2 | 42 (3) | 35 (4) | 0 (2) | 42 (3) | 23 (6) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 53 | 33% | 2.0 | 0 (2) | 0 (1) | - | 0 (2) | 0 (1) |
| Opponent | Holder | 1 | 350 (1) | 100 | 250 | 0 | 0% | 1.0 | - | 350 (1) | - | - | 350 (1) |
| Opponent | Shooter | 4 | 90 (4) | 11 | 80 | 63 | 0% | 1.0 | 64 (1) | 300 (2) | 0 (1) | 101 (2) | 78 (2) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 56 | 0% | 1.3 | 0 (2) | 0 (1) | - | 0 (2) | 0 (1) |

### Charged fights: gs3-83c8646-p35

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Tomb Kings of Khemri | 2 | 50 | 715 | 5.5 | 1.0 | 130 | 0 | +130 | 4 of 11 | 9 of 11 | - | +130 |
| Mine | Vampire Counts | 1 | 0 | 1159 | 6.0 | 1.0 | 193 | 10 | +183 | 2 of 6 | 5 of 6 | - | +183 |
| **Mine** | all armies | 3 | 33 | 863 | 5.7 | 1.0 | 152 | 4 | +149 | 6 of 17 | 14 of 17 | - | +149 |
| Opponent | Tomb Kings of Khemri | 1 | 72 | 0 | 5.0 | 1.0 | 0 | 14 | -14 | 1 of 5 | 3 of 5 | - | -14 |
| Opponent | Vampire Counts | 1 | 0 | 996 | 5.0 | 1.2 | 199 | 15 | +184 | 3 of 5 | 5 of 5 | +540 | +95 |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 0 of 2 | 2 of 2 | - | +0 |
| **Opponent** | all armies | 3 | 24 | 332 | 4.0 | 1.1 | 83 | 12 | +71 | 4 of 12 | 10 of 12 | +540 | +28 |

### Effective charges: gs3-83c8646-p35

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Tomb Kings of Khemri | 11 | 2 (net +332) | 0 | 0 | 0 | 4 (net +111) | 3 (net +63) | 2 | 0% (0 of 9) |
| Mine | Vampire Counts | 6 | 4 (net +216) | 0 | 1 (net +0) | 0 | 0 | 0 | 1 | 20% (1 of 5) |
| Opponent | Tomb Kings of Khemri | 5 | 0 | 0 | 0 | 1 (net -70) | 3 (net +0) | 1 (net +0) | 0 | 0% (0 of 5) |
| Opponent | Vampire Counts | 5 | 1 (net +0) | 0 | 2 (net +130) | 1 (net +540) | 0 | 1 (net +120) | 0 | 40% (2 of 5) |
| Opponent | Wood Elf Realms | 2 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |

### Charged fights, damage counted: gs3-83c8646-p35

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 6 | 238 | 221 | +254 | 277 | 46 | +232 | +97.3 |
| Mine | Effective (55-75%) | 1 | 285 | 224 | +0 | 10 | 0 | +10 | +3.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 346 | 153 | +63 | 63 | 0 | +63 | +18.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 421 | 62 | +111 | 118 | 11 | +107 | +25.4 |
| Mine | No odds | 3 | 102 | 123 | +123 | 123 | 0 | +123 | +120.7 |
| Mine | All fights | 17 | 279 | 154 | +149 | 159 | 19 | +140 | +50.3 |
| Opponent | Long shot (under 50%) | 1 | 50 | 66 | +0 | 55 | 0 | +55 | +110.0 |
| Opponent | 50-54% | 1 | 19 | 60 | +0 | 9 | 10 | -0 | -2.6 |
| Opponent | Effective (55-75%) | 2 | 116 | 130 | +130 | 130 | 15 | +116 | +100.0 |
| Opponent | 76-89% | 2 | 296 | 256 | +235 | 270 | 35 | +235 | +79.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 128 | 130 | +60 | 98 | 38 | +60 | +46.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 440 | 62 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | No odds | 1 | 236 | 60 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | All fights | 12 | 225 | 117 | +71 | 88 | 15 | +73 | +32.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p35 | move | 28 | 5 (18%) | 4 (14%) | 2 (7%) | 21 (75%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2433 |
| Charmed Shield | Opponent | L2327 |
| Horn of the Wild Hunt | Opponent | L2433 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L2327 |
| Ring of Doom | Opponent | L2433 |

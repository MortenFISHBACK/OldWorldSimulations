# Doctrine scorecard: gs3-83c8646-p2

### Scorecard: gs3-83c8646-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0218 | 2 | 1 | Mine | - | - | - | 0 | 7 | 0 | 0 | 0 | 255 |
| L0218 | 2 | 1 | Opponent | - | - | - | 1 | 4 | 0 | 0 | 0 | 74 |
| L0235 | 1 | 1 | Mine | no | 1 | 6 | 0 | 6 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Opponent | no | 0 | 3 | 2 | 3 | 0 | 0 | 0 | 125 |
| L0319 | 1 | 1 | Mine | no | 5 | - | 0 | 0 | 0 | 0 | 0 | 420 |
| L0319 | 1 | 1 | Opponent | no | 3 | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 3.0 | 6.0 | 0.0 | 4.3 | 0.0 | 0.0 | 0.0 | 225.0 |
| **Average** | | | Opponent | 0% | 1.5 | 3.0 | 1.3 | 2.7 | 0.0 | 0.0 | 0.0 | 66.3 |

### KPIs: gs3-83c8646-p2

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 10) | 0% (0 of 12) | 0% (0 of 22) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | 100% (2 of 2); on the table 100% | 67% (2 of 3); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 50% (1 of 2); on the table 50% | 100% (4 of 4); on the table 100% | 83% (5 of 6); on the table 83% |
| Magic missiles tried each own turn | 50%+ | 40% (17 of 42) | 12% (3 of 24) | 30% (20 of 66) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 45% (17 of 38) | 14% (3 of 22) | 33% (20 of 60) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (8 of 12) | - | 67% (8 of 12) |
| Points that never fought | lower | 50% (2886 of 5797) | 68% (4060 of 6000) | 59% (6946 of 11797) |
|   infantry points that never fought | lower | 55% (749 of 1374) | 61% (515 of 842) | 57% (1264 of 2216) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 60% (12 of 20) | 59% (16 of 27) | 60% (28 of 47) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 4.3 uses a game | 50% (1 of 2); 0.7 uses a game | 83% (5 of 6); 2.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 80% (4 of 5); 1.3 uses a game | 0% (0 of 1); 0.0 uses a game | 67% (4 of 6); 0.7 uses a game |
|   their share of the points of units over 100 pts | lower | 50% (2010 of 4039) | 55% (3032 of 5515) | 53% (5042 of 9554) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 6.3 (76%) | 0.7 (10%) | 7.0 (46%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.3 (5%) | 0.3 (2%) |
| IN COMBAT: engaged in combat | 1.0 (12%) | 0.0 (0%) | 1.0 (7%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 4.7 (67%) | 4.7 (30%) |
| GONE: slain | 0.3 (4%) | 0.0 (0%) | 0.3 (2%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.7 (10%) | 0.7 (4%) |
| STUPIDITY: Stupidity | 0.7 (8%) | 0.0 (0%) | 0.7 (4%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.7 (10%) | 0.7 (4%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- |
| tried | 1.7 | 3.0 | 6.7 | 1.0 |
| not cast | 2.3 | 7.0 | 15.3 | 27.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (9%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (14%) | 0.0 (0%) | 7.0 (46%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (5%) | 1.0 (7%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (86%) | 3.7 (52%) | 4.7 (30%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.3 (5%) | 0.7 (4%) | 0.7 (2%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.3 (5%) | 0.7 (4%) | 1.3 (5%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.7 (4%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.0 (0%) | 2.3 (33%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 22.7 (84%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.7 a game | 1.3 a game | 1.5 a game |
| stood (cast and not dispelled) | 80% (4 of 5) | 50% (2 of 4) | 67% (6 of 9) |
| the unit moved after it | 100% (4 of 4) | 0% (0 of 2) | 67% (4 of 6) |
| it charged on its next turn | 0% (0 of 4) | 0% (0 of 2) | 0% (0 of 6) |
| the enemy charged it first | 25% (1 of 4) | 0% (0 of 2) | 17% (1 of 6) |
| it fought by the end of its next turn | 0% (0 of 4) | 0% (0 of 2) | 0% (0 of 6) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 4) | 0% (0 of 2) | 0% (0 of 6) |
| none of these (no charge, no fight, no charge escaped) | 75% (3 of 4) | 100% (2 of 2) | 83% (5 of 6) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 69% (25 of 36) | 53% (43 of 81) | 58% (68 of 117) |
|   cavalry | - | 56% (9 of 16) | 56% (9 of 16) |
|   character | - | 64% (7 of 11) | 64% (7 of 11) |
|   chariot | 42% (5 of 12) | 42% (5 of 12) | 42% (10 of 24) |
|   infantry | - | 40% (12 of 30) | 40% (12 of 30) |
|   monster | - | 83% (10 of 12) | 83% (10 of 12) |
|   war machine | 83% (20 of 24) | - | 83% (20 of 24) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.3 (36%) | 2.3 (18%) | 3.7 (22%) |
| CHARGED: it charged | 0.0 (0%) | 0.7 (5%) | 0.7 (4%) |
| IN COMBAT: it fought this turn or the last | 0.3 (9%) | 0.0 (0%) | 0.3 (2%) |
| MOVED: a war machine that moved | 0.7 (18%) | 0.0 (0%) | 0.7 (4%) |
| NO TARGET IN RANGE | 0.7 (18%) | 6.0 (47%) | 6.7 (41%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 0.7 (5%) | 0.7 (4%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 1.0 (8%) | 1.0 (6%) |
| OTHER BAR | 0.7 (18%) | 1.7 (13%) | 2.3 (14%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.7 | 0.3 | 91% | 1.9 pts | 7 pts |
| character | 2.3 | 1.0 | 71% | 12.1 pts | 28 pts |
| chariot | 3.3 | 3.7 | 40% | 24.0 pts | 80 pts |
| infantry | 4.0 | 3.0 | 42% | 10.8 pts | 43 pts |
| monster | 3.3 | 5.3 | 40% | 26.4 pts | 88 pts |
| war machine | 6.7 | 4.0 | 65% | 7.9 pts | 52 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.3 | 5.0 | 2.7 |
| Charges that made contact a game | 0.3 | 2.7 | 1.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | - | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.04 declared, 0.04 contact (25 units) | 0.52 declared, 0.28 contact (29 units) | 0.30 declared, 0.17 contact (54 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 33% (1 of 3) | 100% (1 of 1) | - | 50% (2 of 4) |
| Character in a unit | 80% (4 of 5) | 40% (2 of 5) | - | 60% (6 of 10) |
| Character on its own | 100% (3 of 3) | 100% (3 of 3) | 0% (0 of 2) | 75% (6 of 8) |
| Chariot | 50% (1 of 2) | 50% (1 of 2) | - | 50% (2 of 4) |
| Infantry | 40% (2 of 5) | 0% (0 of 3) | - | 25% (2 of 8) |
| Monster | 100% (2 of 2) | 100% (1 of 1) | - | 100% (3 of 3) |
| Monstrous | 100% (2 of 2) | 25% (1 of 4) | - | 50% (3 of 6) |
| War Machines | 100% (3 of 3) | 100% (1 of 1) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 2 | 100% (1 of 1); on the table 100% | 57% (17 of 30) | 32% | 50% (6 of 12) | 100% (4 of 4); 6.5 uses a game | 0.0 uses a game | 75% (3 of 4); 1.5 uses a game |
| Chaos Dwarfs | 1 | 0% (0 of 1); on the table 0% | 0% (0 of 12) | 84% | 75% (6 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Ogre Kingdoms | 1 | 100% (3 of 3); on the table 100% | 0% (0 of 6) | 90% | 71% (5 of 7) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 12) | 50% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Wood Elf Realms | 1 | - | 50% (3 of 6) | 63% | 50% (6 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p2, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 38% (3) | 0% (0) | 33% (3) |
| ...free all their last turn and able to turn (per game) | 1.00 | 0.00 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.00 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | 100% (1 of 1) | 33% (2 of 6) |
| Strategy | Shoot objectives carried out (shot that target) | 57% (13 of 23) | 12% (2 of 16) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 25% (1 of 4) |
| Strategy | Joined characters whose unit fought | 90% (9 of 10) | 0% (0 of 1) |
| Strategy | Lone characters that fought | 40% (2 of 5) | 62% (5 of 8) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 4.3 | 2.7 |
| Movement | Points that never moved of their own | 225.0 | 66.3 |
| Movement | Fights charged into per game | 0.3 | 2.7 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 1, net +0 | 1 of 5, net -30 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 1 | 0 of 5 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 1 | 1 of 5, net +85 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 1 | 2 of 5, net +92 |
| Shooting | Shots by shooting units (incl. breath weapons) | 1.7 | 14.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 80% (4 of 5) | 18% (8 of 44) |
| Shooting | Points destroyed by shooting units | 0.0 | 66.7 |
| Shooting | War machine shots | 6.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 30% (6 of 20) | - |
| Shooting | Points destroyed by war machines | 0.0 | 45.7 |
| Magic | Magic missiles cast | 2.0 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 17% (1 of 6) | 0% (0 of 2) |
| Magic | Wounds caused by magic missiles | 10.0 | 2.7 |
| Magic | Wounds caused by other spells | 1.0 | - |
| Magic | Points destroyed by magic (all spells) | 105.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.7 / 0.0 | 0.0 / 1.3 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 128.7 | 123.0 |
| Combat | Points run down | 0.0 | 27.0 |
| Combat | Net points per charged fight, damage counted | +0 | -98 |
| Combat | Net per 100 charger points, damage counted | +0.0 | -56.9 |
| Combat | First round won (charged fights) | 0% | 75% |
| Combat | Net points per charged fight | +0 | -108 |
| Combat | Net points per supported fight / lone fight | - / +0 | - / -108 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 1 | 3 of 8 |
| Game | Points lost | 329.3 | 495.7 |
| Game | VP from objectives | 816.7 | 1023.3 |
| Game | Lone holders (player turns) | 3.0 | 1.5 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +8 VP
- The side that went first won 2 of 2 games with a winner
- Points traded per game (both sides' losses): 825
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | - | - | - | - | 1.0 | +0.0 | 0.0 | 41.7 |
| ARMY TABLE | 15.3 | +132.1 | 0.0 | 169.3 | 25.0 | +504.8 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.7 | +0.0 | 0.0 | 36.7 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 0.7 | +4.6 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.3 | +0.0 | 18.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 5.7 | +46.2 | 73.3 | 73.3 | - | - | - | - |
| CANNON SIGHT KEPT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 0.3 | +1.3 | 41.7 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.7 | +66.8 | 0.0 | 0.0 | 1.3 | +85.2 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.7 | +19.5 | 0.0 | 20.0 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 1.0 | -0.4 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -6.4 | 0.0 | 41.7 |
| CHARGE LOSSES | 15.3 | -475.3 | 0.0 | 152.0 | 10.7 | -487.2 | 0.0 | 197.7 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 36.7 | 0.0 |
| CHARGE NOW FIRST | - | - | - | - | 1.0 | +0.0 | 55.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 13.7 | +0.0 | 0.0 | 113.3 | 7.0 | +0.0 | 0.0 | 36.7 |
| COMBAT PIVOT | 1.0 | +0.0 | 114.3 | 56.7 | - | - | - | - |
| CONVEYANCE SEARCH | 1.7 | +251.7 | 0.0 | 0.0 | 1.3 | +89.9 | 0.0 | 0.0 |
| COVER ONCE | 2.0 | -32.6 | 0.0 | 0.0 | 3.7 | -126.8 | 0.0 | 52.7 |
| DEFENSIVE FLOOR | - | - | - | - | 0.3 | -8.7 | 0.0 | 41.7 |
| DEPLOY BY FIGURES | 9.7 | +22.3 | 0.0 | 28.3 | 8.3 | +76.7 | 0.0 | 41.7 |
| ENGINEER BY LORE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 0.3 | +8.7 | 0.0 | 17.3 | 2.0 | +19.3 | 137.7 | 41.7 |
| FALL BACK GOOD ORDER | 0.3 | +0.8 | 0.0 | 17.3 | 2.0 | +0.1 | 137.7 | 0.0 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 10.0 | - | - | - | - |
| FALLS SHORT | 17.7 | +232.2 | 0.0 | 27.0 | 4.0 | +110.4 | 0.0 | 0.0 |
| FEATURE BUFFS | 10.3 | +426.6 | 0.0 | 0.0 | 0.7 | +16.7 | 0.0 | 105.3 |
| FIGHT TO THE END | - | - | - | - | 0.7 | +1.2 | 27.0 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 95.3 | +7402.9 | 151.7 | 700.7 | 99.7 | +6919.6 | 485.7 | 415.3 |
| FLANK NOT WEIGHED | 5.3 | +0.0 | 0.0 | 103.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +5.7 | 0.0 | 0.0 |
| FOOT FIRST | - | - | - | - | 19.3 | +0.0 | 0.0 | 154.3 |
| FOUR ROUNDS | 0.3 | +6.2 | 0.0 | 17.3 | 2.7 | +79.2 | 137.7 | 41.7 |
| FREED FROM HIS FIGHT | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.3 | -1.7 | 0.0 | 0.0 |
| GOAL ROUTE | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| GOAL WALK | 8.0 | +1044.1 | 0.0 | 113.3 | 15.3 | +1187.1 | 0.0 | 0.0 |
| GROUND FLIERS | 0.7 | +10.5 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 1.7 | +10.3 | 114.3 | 0.0 | 1.7 | +99.6 | 63.0 | 0.0 |
| HARD STAY DROPPED | 2.3 | +0.0 | 0.0 | 17.3 | 4.3 | +0.0 | 0.0 | 41.7 |
| HE REFORMS ONCE FREED | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 8.3 | +0.0 | 0.0 | 117.3 | 2.0 | +0.0 | 0.0 | 197.7 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +9.8 | 28.3 | 0.0 |
| HIS CHARGE LIST | 2.0 | +0.0 | 0.0 | 34.7 | 1.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 1.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 9.0 | -124.9 | 0.0 | 202.3 | 1.3 | -46.2 | 0.0 | 0.0 |
| HIS ONE QUARTER | 7.7 | +0.0 | 0.0 | 69.3 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 2.7 | +0.0 | 0.0 | 56.7 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 13.0 | +0.0 | 0.0 | 116.7 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 64.0 | +2106.4 | 0.0 | 362.7 | 57.3 | +2683.5 | 0.0 | 290.3 |
| HIS SHOTS BY HIS RUN | 52.3 | +815.1 | 0.0 | 502.0 | 38.7 | +1118.9 | 0.0 | 351.0 |
| HIS TURN DENIED | - | - | - | - | 0.3 | +1.3 | 27.0 | 0.0 |
| HOLD ODDS | 29.0 | +0.0 | 0.0 | 60.7 | 23.7 | +0.0 | 0.0 | 210.7 |
| HOLDER ASSIGNMENT | 13.7 | +1362.5 | 0.0 | 30.3 | 15.7 | +1299.4 | 0.0 | 52.7 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | - | - | - | - | 2.3 | -46.2 | 137.7 | 0.0 |
| IDLE COST | 18.3 | -107.3 | 0.0 | 130.7 | 3.7 | -58.9 | 0.0 | 18.3 |
| KEPT FROM ITS LAST STOP | 0.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +17.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.3 | +0.0 | 167.0 | 141.7 | 1.0 | +0.0 | 66.7 | 0.0 |
| LONE WIZARD KEPT IN | 1.3 | +116.7 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.3 | -2.7 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.3 | -0.3 | 0.0 | 17.3 | 1.0 | -0.1 | 63.7 | 0.0 |
| MANOEUVRE | 1.7 | -5.5 | 0.0 | 0.0 | 4.7 | +10.3 | 0.0 | 52.7 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +54.1 | 0.0 | 0.0 | 0.3 | +15.6 | 0.0 | 0.0 |
| MARCH CHECK | 1.0 | +28.2 | 0.0 | 27.0 | 1.0 | +48.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | -4.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.7 | +29.7 | 0.0 | 55.3 | 0.3 | +6.6 | 0.0 | 11.3 |
| MEETS IN TIME | 3.3 | +262.7 | 0.0 | 0.0 | 3.0 | +302.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 5.0 | +264.7 | 0.0 | 27.0 | 5.0 | +158.4 | 0.0 | 52.7 |
| MISSILES NEXT TURN | 5.7 | +212.9 | 0.0 | 27.0 | 4.7 | +75.7 | 0.0 | 52.7 |
| MISSILES ON ONE TARGET | 0.7 | -39.3 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 1.0 | +0.0 | 56.7 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | - | - | - | - | 0.7 | +6.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 3.3 | -242.1 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 4.0 | +1232.7 | 0.0 | 56.7 | 2.7 | +115.8 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.7 | +36.7 | 0.0 | 0.0 | 0.3 | +1.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 4.3 | +224.3 | 0.0 | 30.3 | 13.7 | +602.9 | 0.0 | 52.7 |
| NEAREST TO GOAL | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 2.0 | +648.3 | 0.0 | 0.0 | 0.7 | +15.2 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 0.3 | -14.1 | 0.0 | 17.3 | 2.7 | -61.1 | 137.7 | 41.7 |
| NO LATE CUT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 5.7 | -981.6 | 0.0 | 67.0 | 4.0 | -94.3 | 0.0 | 52.7 |
| OGRE LOADER SECOND SHOT | 0.7 | +4.2 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 27.0 | - | - | - | - |
| ONE FIGHT FORMULA | 4.7 | -57.8 | 0.0 | 28.3 | 3.0 | -31.1 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 7.7 | +204.6 | 0.0 | 30.3 | 5.3 | -154.4 | 0.0 | 52.7 |
| ONE PROMISE A TARGET | 1.3 | -504.6 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 0.3 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.7 | +32.1 | 65.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.3 | +19.7 | 28.3 | 0.0 |
| PLAN RESULT | 44.0 | +174.1 | 227.0 | 510.3 | 45.0 | +159.0 | 85.0 | 447.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 17.3 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 8.0 | -1996.4 | 0.0 | 56.7 | 6.3 | -182.8 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | - | - | - | - | 0.3 | -1.7 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 2.7 | -5.9 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 17.7 | +1891.2 | 41.7 | 324.7 | 17.7 | +1572.9 | 147.0 | 41.7 |
| RANDOM MOVE BY FIGURES | 4.0 | +70.9 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.7 | +86.8 | 0.0 | 65.3 | 1.3 | -1.3 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.7 | +0.0 | 0.0 | 93.7 | 2.3 | +0.0 | 0.0 | 22.7 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -50.6 | 0.0 | 0.0 | 0.3 | -1.5 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 41.7 |
| RISK BY ARC | 0.3 | +14.1 | 0.0 | 17.3 | 1.7 | -25.2 | 55.3 | 41.7 |
| RISK ON THE WAY | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.7 | -9.9 | 65.0 | 0.0 |
| RUN DOWN | 0.3 | -0.2 | 0.0 | 17.3 | 1.7 | -8.3 | 72.7 | 0.0 |
| SCOUT SPOT | - | - | - | - | 0.7 | -0.1 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 1.3 | -14.6 | 0.0 | 20.0 | - | - | - | - |
| SEARCH SPOT | 0.7 | -0.3 | 0.0 | 0.0 | 1.0 | +1.2 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.7 | +12.6 | 28.3 | 0.0 |
| SET CREDITED ONCE | 1.3 | -17.2 | 0.0 | 0.0 | 0.3 | -0.2 | 0.0 | 0.0 |
| SET UP BY THE SET | 2.0 | +64.0 | 0.0 | 0.0 | 0.7 | +13.1 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.3 | +2.0 | 0.0 | 0.0 | - | - | - | - |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +77.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 7.7 | +0.0 | 0.0 | 73.3 | 6.7 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.7 | +97.3 | 0.0 | 0.0 | 3.3 | +222.7 | 56.7 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -4.9 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.3 | +0.0 | 18.3 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 53.0 | +573.8 | 0.0 | 426.0 | 42.0 | +312.3 | 0.0 | 373.7 |
| SHOTS AFTER THE MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 9.0 | +171.5 | 0.0 | 73.3 | 18.3 | +447.4 | 0.0 | 52.7 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +77.0 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | -3.4 | 0.0 | 41.7 |
| SPOT AS THE GAME MOVES | 9.0 | +0.0 | 0.0 | 161.0 | 8.3 | +0.0 | 0.0 | 132.7 |
| STANDS FOR A REASON | 1.3 | +0.0 | 0.0 | 54.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 38.0 | +0.0 | 151.7 | 216.0 | 44.3 | +0.0 | 348.0 | 117.3 |
| STAY WORTH | 18.3 | +35.8 | 151.7 | 110.0 | 22.7 | +194.2 | 228.3 | 52.7 |
| STUCK PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 2.7 | +69.5 | 0.0 | 0.0 | 1.3 | +291.8 | 0.0 | 0.0 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 28.3 | 0.0 |
| SUPPORT WORKED OUT | 2.7 | +69.5 | 0.0 | 0.0 | 1.3 | +291.8 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| SWIFTSTRIDE BY POINTS | 0.3 | +0.0 | 0.0 | 10.0 | 0.7 | +24.6 | 0.0 | 114.3 |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 4.7 | +0.0 | 28.3 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 5.0 | +0.0 | 0.0 | 34.7 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 2.7 | +0.0 | 0.0 | 47.7 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 43.0 | +0.0 | 0.0 | 313.3 | 46.7 | +0.0 | 0.0 | 124.0 |
| TIED UP BY THE SUM | - | - | - | - | 0.3 | +11.6 | 27.0 | 0.0 |
| TIME ON OUR SIDE | 9.7 | +154.0 | 0.0 | 30.3 | 61.7 | +515.2 | 28.3 | 223.0 |
| WAITS AGAIN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | 0.3 | -6.4 | 0.0 | 17.3 | 1.3 | +2.8 | 45.7 | 0.0 |
| WHO HITS BACK | 0.3 | +5.4 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 0.7 | -159.3 | 0.0 | 0.0 | 0.3 | -101.6 | 0.0 | 114.3 |
| WOUNDS ON THE RANKS | 4.7 | +250.7 | 0.0 | 0.0 | 3.0 | +487.7 | 0.0 | 114.3 |

### Rule changes: gs3-83c8646-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 364 | 356 | 109 | 36.33 | +1103 | +10.1 |
| HIS SHOTS BY HIS RUN | 273 | 261 | 94 | 31.33 | +1071 | +11.4 |
| SHOT RISK POINTS | 285 | 275 | 92 | 30.67 | +1403 | +15.2 |
| HOLDER ASSIGNMENT | 88 | 88 | 82 | 27.33 | +3718 | +45.3 |
| ARMY TABLE | 121 | 121 | 75 | 25.00 | +1405 | +18.7 |
| DEPLOY BY FIGURES | 54 | 54 | 36 | 12.00 | +491 | +13.6 |
| TIME ON OUR SIDE | 214 | 187 | 32 | 10.67 | +121 | +3.8 |
| OFF BEST | 29 | 29 | 29 | 9.67 | -3228 | -111.3 |
| THE TABLE AGAIN | 36 | 36 | 27 | 9.00 | +0 | +0.0 |
| GOAL WALK | 70 | 68 | 20 | 6.67 | +877 | +43.8 |
| HARD STAY DROPPED | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| QUARTER ODDS | 106 | 101 | 20 | 6.67 | +1685 | +84.3 |
| PROMISE BY ITS OWN SUM | 43 | 43 | 19 | 6.33 | -6538 | -344.1 |
| REDIRECT FOR A FRIEND IN REACH | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| FIVE ACTION | 585 | 562 | 16 | 5.33 | +978 | +61.1 |
| MEETS IN TIME | 19 | 19 | 13 | 4.33 | +889 | +68.4 |
| MOVE TO CHARGE COMPUTED | 20 | 14 | 12 | 4.00 | +2289 | +190.8 |
| LEGAL CHARGES ONLY | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| MOVE ORDER | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| PROMISE SHOT AWAY | 8 | 8 | 8 | 2.67 | -17 | -2.2 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 8 | 2.67 | +213 | +26.6 |
| CASTER AWAY FROM SCREEN | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CASTING BLOCK | 6 | 6 | 6 | 2.00 | +246 | +41.0 |
| NEXT CHARGE BY LIST | 8 | 7 | 6 | 2.00 | +1711 | +285.2 |
| WOUNDS ON THE RANKS | 23 | 23 | 6 | 2.00 | +700 | +116.6 |
| ARTILLERY RE-ROLL WEIGHED | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| MAX FOR POSITIONING | 6 | 6 | 5 | 1.67 | +0 | +0.0 |
| NEARER NOT NEEDED | 54 | 50 | 5 | 1.67 | +156 | +31.1 |
| FALLS SHORT | 65 | 50 | 4 | 1.33 | +169 | +42.3 |
| FOUR ROUNDS | 9 | 8 | 4 | 1.33 | +103 | +25.7 |
| HIS MOVE AND SHOT | 31 | 31 | 4 | 1.33 | +3 | +0.6 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +350 | +87.5 |
| MISSILES IN THE MOVE | 30 | 22 | 4 | 1.33 | +144 | +36.1 |
| ONE PROMISE A TARGET | 4 | 4 | 4 | 1.33 | -1514 | -378.4 |
| SUPPORT ADDS | 12 | 10 | 4 | 1.33 | +49 | +12.2 |
| SUPPORT WORKED OUT | 12 | 10 | 4 | 1.33 | +49 | +12.2 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | -1 | -0.4 |
| CHARGE LOSSES | 78 | 74 | 3 | 1.00 | +408 | +136.1 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| IDLE COST | 66 | 52 | 3 | 1.00 | +2 | +0.6 |
| MARCH CHECK | 6 | 6 | 3 | 1.00 | +41 | +13.5 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 1.00 | +114 | +38.2 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SEARCH SPOT | 5 | 5 | 3 | 1.00 | +10 | +3.4 |
| SHOTS AFTER THE MOVES | 14 | 14 | 3 | 1.00 | +0 | +0.0 |
| SHOTS IN THE MOVE | 82 | 61 | 3 | 1.00 | +86 | +28.8 |
| SWIFTSTRIDE BY POINTS | 3 | 3 | 3 | 1.00 | +74 | +24.6 |
| CANNON SIGHT KEPT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 2 | 2 | 2 | 0.67 | +8 | +3.9 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +17 | +8.5 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +53 | +26.6 |
| MANOEUVRE | 19 | 19 | 2 | 0.67 | +40 | +19.8 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +209 | +104.5 |
| OGRE LOADER SECOND SHOT | 2 | 2 | 2 | 0.67 | +12 | +6.2 |
| RISK BY ARC | 6 | 5 | 2 | 0.67 | +38 | +19.0 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +38 | +18.8 |
| SET UP BY THE SET | 8 | 8 | 2 | 0.67 | +27 | +13.6 |
| SHOOTS FROM THE BEST SPOT | 18 | 18 | 2 | 0.67 | +178 | +88.9 |
| STAY WORTH | 123 | 105 | 2 | 0.67 | +2 | +0.9 |
| THE ROW IN ITS ORDER | 31 | 2 | 2 | 0.67 | +0 | +0.0 |
| CANNON PLANNED TARGET | 17 | 17 | 1 | 0.33 | +0 | +0.2 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -220 | -219.7 |
| EXACT ROUND | 7 | 6 | 1 | 0.33 | +3 | +3.3 |
| FEATURE BUFFS | 33 | 33 | 1 | 0.33 | +8 | +8.1 |
| FIGHT TO THE END | 2 | 2 | 1 | 0.33 | +1 | +0.6 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| GOAL ROUTE | 1 | 1 | 1 | 0.33 | +1 | +0.6 |
| HONEST WORTH | 7 | 6 | 1 | 0.33 | +3 | +3.3 |
| NO DOUBLE ROUNDS | 9 | 8 | 1 | 0.33 | +3 | +3.3 |
| ONE OBJECTIVE FORMULA | 39 | 22 | 1 | 0.33 | +172 | +171.8 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +57 | +56.9 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -28 | -27.7 |
| SET UP TOGETHER | 1 | 1 | 1 | 0.33 | +5 | +5.0 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SHOT REPLANNED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -56 | -55.8 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| TIED UP BY THE SUM | 1 | 1 | 1 | 0.33 | +20 | +19.9 |
| WHO FIGHTS | 5 | 4 | 1 | 0.33 | +1 | +0.6 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +16 | +16.2 |
| WHOLE FIGHT DANGER | 3 | 3 | 1 | 0.33 | +351 | +351.4 |
| BACKUP TARGETS | 2 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CAST JOB | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 6 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 3 | 3 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 62 | 62 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 9 | not checked | - | - | - | - |
| COVER ONCE | 17 | 9 | 0 | 0.00 | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 7 | 6 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 21 | not checked | - | - | - | - |
| FOOT FIRST | 58 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 10 | 8 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| GUN FIGURES | 10 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 7 | 5 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 31 | 31 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | not checked | - | - | - | - |
| HIS CHARGE LIST | 11 | 11 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 16 | 12 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 38 | 33 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 22 | 18 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 39 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HOLD ODDS | 158 | 158 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 15 | 15 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 4 | 4 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 7 | 7 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 31 | 23 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 2 | not checked | - | - | - | - |
| MOVE SPELL IN RANGE | 2 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 10 | trace | - | - | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NEAREST TO GOAL | 5 | 5 | 0 | 0.00 | - | - |
| NO LATE CUT | 1 | 1 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 23 | 14 | 0 | 0.00 | - | - |
| ONE ROUTE | 7 | 7 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | not checked | - | - | - | - |
| OPENS UP | 2 | 2 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 1 | not checked | - | - | - | - |
| PLAN RESULT | 267 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 2 | not checked | - | - | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 7 | 7 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 9 | 8 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 3 | 2 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 4 | 4 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 6 | 5 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 5 | 5 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 43 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 52 | 51 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 12 | 12 | 0 | 0.00 | - | - |
| STANDS STILL | 247 | 238 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 6 | not checked | - | - | - | - |
| THE PROMISED MOVE | 3 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 20 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 14 | not checked | - | - | - | - |
| THE TABLE BINDS | 269 | not checked | - | - | - | - |
| WAITS AGAIN | 2 | 2 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 6 | 6 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.33 | 3.33 | 122.0 |
| PROMISE BY ITS OWN SUM | rule | 3.33 | 3.00 | 344.1 |
| HOLDER ASSIGNMENT | rule | 0.67 | 2.67 | 18.7 |
| ARMY TABLE | rule | 1.33 | 1.33 | 58.3 |
| PROMISE SHOT AWAY | rule | 2.67 | - | 2.2 |
| ONE PROMISE A TARGET | rule | 1.33 | - | 378.4 |
| NO REASON | gate | - | 0.67 | 27.8 |
| CHAFF PASSED | rule | - | 0.33 | 0.7 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 219.7 |
| REFUSING RETIRES | rule | - | 0.33 | 27.7 |
| RULE SWITCHED OFF | gate | 0.33 | - | 0.8 |
| SUPPORT NARROWED | rule | - | 0.33 | 55.8 |

### Plans: gs3-83c8646-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | move | 37.3 | 95% | 2662 | 0 | 0% |
| Mine | shoot | 6.3 | 58% | 445 | 174 | 39% |
| Mine | support | 0.3 | 0% | 1 | 0 | 0% |
| Opponent | charge | 1.7 | 60% | 55 | 71 | 129% |
| Opponent | move | 39.3 | 97% | 2671 | 0 | 0% |
| Opponent | shoot | 4.0 | 42% | 453 | 88 | 19% |

### Battle groups: gs3-83c8646-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.7 | 80% | 100% | 0% | - | 25% | 0% | 0% | 75% | 0% |
| Opponent | REDIRECT COUNTER | 1.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | - | 0 (2) | - | 0 (2) | - |
| Mine | Character | 11 | 19 (11) | 19 | 0 | 10 | 18% | 3.1 | - | 4 (6) | 41 (4) | 20 (10) | - |
| Mine | Clean-up | 2 | 242 (2) | 0 | 242 | 49 | 100% | - | 316 (1) | - | 165 (1) | 242 (2) | - |
| Mine | Fast Hammer | 10 | 0 (10) | 0 | 0 | 76 | 70% | 5.0 | 0 (6) | 0 (1) | 0 (3) | 0 (7) | 0 (3) |
| Mine | Hammer | 9 | 54 (9) | 19 | 35 | 4 | 33% | 3.0 | 54 (2) | 38 (4) | 94 (3) | 54 (9) | - |
| Mine | Holder | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | - | 0 (1) | - | 0 (2) |
| Mine | War machine | 4 | 0 (4) | 0 | 0 | 19 | 0% | 1.2 | 0 (4) | - | - | - | 0 (4) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 50% | 3.5 | 0 (2) | 0 (1) | 0 (1) | 0 (2) | 0 (2) |
| Opponent | Blocker | 1 | 184 (1) | 184 | 0 | 0 | 0% | 4.0 | 184 (1) | - | - | 184 (1) | - |
| Opponent | Chaff | 8 | 68 (8) | 0 | 68 | 23 | 75% | 2.5 | 141 (3) | 0 (4) | 0 (1) | 76 (7) | 0 (1) |
| Opponent | Character | 7 | 15 (7) | 15 | 0 | 19 | 14% | 2.7 | 57 (1) | 0 (3) | 17 (1) | 8 (3) | 31 (2) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 0 | 67% | 3.0 | - | 0 (3) | - | 0 (3) | - |
| Opponent | Fast Hammer | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Hammer | 10 | 74 (10) | 17 | 57 | 12 | 40% | 2.8 | 19 (5) | 130 (4) | 83 (1) | 39 (5) | 99 (5) |
| Opponent | Shooter | 4 | 153 (4) | 38 | 115 | 30 | 0% | 2.2 | 0 (1) | 131 (2) | 318 (1) | 124 (3) | 259 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 126 | 0% | 5.0 | - | - | - | - | - |

### Charged fights: gs3-83c8646-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 158 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| Mine | Chaos Dwarfs | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 106 | 0 | 0.3 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| Opponent | Ogre Kingdoms | 1 | 137 | 166 | 4.0 | 1.0 | 42 | 0 | +42 | 1 of 4 | 3 of 4 | - | +42 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 1190 | -1190 | 1 of 1 | 1 of 1 | - | -1190 |
| Opponent | Wood Elf Realms | 1 | 200 | 284 | 3.0 | 1.0 | 95 | 42 | +53 | 1 of 3 | 2 of 3 | - | +53 |
| **Opponent** | all armies | 3 | 112 | 150 | 2.7 | 1.0 | 56 | 164 | -108 | 3 of 8 | 6 of 8 | - | -108 |

### Effective charges: gs3-83c8646-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Ogre Kingdoms | 4 | 0 | 0 | 0 | 1 (net +0) | 0 | 1 (net +81) | 2 | 0% (0 of 2) |
| Opponent | Wood Elf Realms | 3 | 1 (net -30) | 0 | 0 | 0 | 1 (net +85) | 1 (net +104) | 0 | 0% (0 of 3) |

### Charged fights, damage counted: gs3-83c8646-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 52 | 125 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | All fights | 1 | 52 | 125 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Long shot (under 50%) | 1 | 125 | 272 | -30 | 95 | 125 | -30 | -24.0 |
| Opponent | 76-89% | 1 | 77 | 85 | +0 | 0 | 2 | -2 | -2.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 108 | 66 | +92 | 92 | 0 | +92 | +86.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 499 | 85 | +85 | 85 | 0 | +85 | +17.0 |
| Opponent | No odds | 3 | 156 | 222 | -368 | 73 | 415 | -342 | -219.5 |
| Opponent | All fights | 8 | 173 | 155 | -108 | 73 | 171 | -98 | -56.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p2 | move | 15 | 1 (7%) | 0 (0%) | 2 (13%) | 12 (80%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Elixir of Power | Opponent | L0319 |
| Fistful of Laurels | Opponent | L0218 |
| Ring of Doom | Mine | L0218, L0235 |

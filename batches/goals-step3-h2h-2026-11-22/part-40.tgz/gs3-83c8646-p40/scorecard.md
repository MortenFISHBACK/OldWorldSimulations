# Doctrine scorecard: gs3-83c8646-p40

### Scorecard: gs3-83c8646-p40

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0608 | 2 | 1 | Mine | - | - | 6 | 1 | 2 | 0 | 0 | 0 | 811 |
| L0608 | 2 | 1 | Opponent | - | - | - | 0 | 3 | 0 | 0 | 0 | 300 |
| L0624 | 6 | 1 | Mine | no | 10 | - | 1 | 2 | 0 | 0 | 0 | 435 |
| L0624 | 6 | 1 | Opponent | no | 0 | 3 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | yes | - | - | 0 | 4 | 1 | 0 | 0 | 250 |
| L0713 | 5 | 1 | Opponent | yes | - | - | 0 | 3 | 2 | 0 | 0 | 140 |
| **Average** | | | Mine | 50% | 10.0 | 6.0 | 0.7 | 2.7 | 0.3 | 0.0 | 0.0 | 498.7 |
| **Average** | | | Opponent | 50% | 0.0 | 3.0 | 1.3 | 2.7 | 0.7 | 0.0 | 0.0 | 146.7 |

### KPIs: gs3-83c8646-p40

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 45% (5 of 11) | 0% (0 of 15) | 19% (5 of 26) |
| Winner chose to follow up after the loser gave ground |  | 50% (1 of 2); on the table 50% | 100% (2 of 2); on the table 100% | 75% (3 of 4); on the table 75% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 50% (1 of 2); on the table 50% | 100% (3 of 3); on the table 100% | 80% (4 of 5); on the table 80% |
| Magic missiles tried each own turn | 50%+ | 67% (4 of 6) | 33% (4 of 12) | 44% (8 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 80% (4 of 5) | 36% (4 of 11) | 50% (8 of 16) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 87% (5240 of 5999) | 85% (5101 of 5998) | 86% (10341 of 11997) |
|   infantry points that never fought | lower | 74% (1372 of 1858) | 75% (1105 of 1476) | 74% (2477 of 3334) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 77% (23 of 30) | 76% (19 of 25) | 76% (42 of 55) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (1 of 1); 2.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Bound items with another spell used |  | 0% (0 of 1); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (2 of 2); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 70% (3342 of 4780) | 80% (4372 of 5477) | 75% (7714 of 10257) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (50%) | 1.0 (38%) | 1.3 (40%) |
| MARCHED: its unit marched | 0.0 (0%) | 1.0 (38%) | 1.0 (30%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.3 (12%) | 0.3 (10%) |
| GONE: slain | 0.3 (50%) | 0.3 (12%) | 0.7 (20%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 7.7 | 0.0 | 1.3 | 2.7 | 0.3 | 0.0 |
| not cast | 0.3 | 4.0 | 0.7 | 3.3 | 1.7 | 12.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.7 (92%) | 0.0 (0%) | 1.3 (40%) | 0.7 (40%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (30%) | 0.7 (40%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (10%) | 0.3 (20%) | 0.0 (0%) |
| GONE: slain | 0.3 (100%) | 0.3 (8%) | 0.3 (50%) | 0.7 (20%) | 0.0 (0%) | 1.7 (14%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.0 (0%) | 0.0 (0%) | 0.3 (50%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 10.3 (86%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.3 a game | 0.7 a game |
| stood (cast and not dispelled) | - | 75% (3 of 4) | 75% (3 of 4) |
| the unit moved after it | - | 67% (2 of 3) | 67% (2 of 3) |
| it charged on its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| the enemy charged it first | - | 0% (0 of 3) | 0% (0 of 3) |
| it fought by the end of its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 3) | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (3 of 3) | 100% (3 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 68% (119 of 175) | 72% (49 of 68) | 69% (168 of 243) |
|   cavalry | 55% (11 of 20) | 78% (7 of 9) | 62% (18 of 29) |
|   character | 100% (8 of 8) | 90% (9 of 10) | 94% (17 of 18) |
|   chariot | - | 83% (5 of 6) | 83% (5 of 6) |
|   infantry | 57% (28 of 49) | 100% (12 of 12) | 66% (40 of 61) |
|   monster | 75% (9 of 12) | - | 75% (9 of 12) |
|   war machine | 73% (63 of 86) | 52% (16 of 31) | 68% (79 of 117) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.7 (20%) | 1.0 (16%) | 4.7 (19%) |
| CHARGED: it charged | 0.3 (2%) | 0.0 (0%) | 0.3 (1%) |
| MOVED: a war machine that moved | 0.3 (2%) | 0.7 (11%) | 1.0 (4%) |
| NO TARGET IN RANGE | 7.7 (41%) | 0.3 (5%) | 8.0 (32%) |
| ONLY IN COMBAT: the only targets were in combat | 1.0 (5%) | 0.0 (0%) | 1.0 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 5.0 (27%) | 3.7 (58%) | 8.7 (35%) |
| SHELTERED: the target was sheltered | 0.7 (4%) | 0.7 (11%) | 1.3 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 8.0 | 4.7 | 62% | 13.2 pts | 105 pts |
| character | 6.0 | 3.0 | 72% | 14.0 pts | 84 pts |
| chariot | 1.7 | 1.0 | 60% | 7.8 pts | 13 pts |
| infantry | 25.3 | 6.3 | 78% | 7.6 pts | 192 pts |
| monster | 3.0 | 0.7 | 78% | 1.2 pts | 4 pts |
| war machine | 26.3 | 20.3 | 59% | 17.5 pts | 462 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.7 | 1.3 | 1.0 |
| Charges that made contact a game | 0.7 | 0.7 | 0.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.50 declared, 0.00 contact (2 units) | 0.33 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.08 declared, 0.08 contact (24 units) | 0.15 declared, 0.10 contact (20 units) | 0.11 declared, 0.09 contact (44 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 86% (6 of 7) | 67% (2 of 3) | - | 80% (8 of 10) |
| Character in a unit | 100% (4 of 4) | - | - | 100% (4 of 4) |
| Character on its own | 67% (2 of 3) | 100% (3 of 3) | 67% (2 of 3) | 78% (7 of 9) |
| Chariot | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Infantry | 50% (4 of 8) | 40% (2 of 5) | 100% (1 of 1) | 50% (7 of 14) |
| Monster | 100% (2 of 2) | - | - | 100% (2 of 2) |
| War Machines | 87% (13 of 15) | - | - | 87% (13 of 15) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dwarfen Mountain Holds | 2 | 50% (1 of 2); on the table 50% | - | 81% | 75% (15 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 2 | 100% (1 of 1); on the table 100% | 67% (4 of 6) | 84% | 80% (16 of 20) | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| High Elf Realms | 1 | - | 33% (2 of 6) | 100% | 88% (7 of 8) | 100% (1 of 1); 6.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (2 of 2); on the table 100% | 33% (2 of 6) | 86% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p40, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | - | 100% (1) | 100% (1) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: gs3-83c8646-p40

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.0 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 100% (2 of 2) | 67% (2 of 3) |
| Strategy | Shoot objectives carried out (shot that target) | 60% (47 of 78) | 77% (20 of 26) |
| Strategy | Joined characters whose unit fought | 33% (2 of 6) | 67% (2 of 3) |
| Strategy | Lone characters that fought | 0% (0 of 4) | 11% (1 of 9) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.7 | 2.7 |
| Movement | Points that never moved of their own | 498.7 | 146.7 |
| Movement | Fights charged into per game | 0.7 | 0.7 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 2, net +0 | 0 of 1 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 2 | 0 of 1 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 2 | 0 of 1 |
| Shooting | Shots by shooting units (incl. breath weapons) | 20.3 | 11.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 62% (38 of 61) | 52% (17 of 33) |
| Shooting | Points destroyed by shooting units | 125.0 | 212.3 |
| Shooting | War machine shots | 21.0 | 5.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 57% (36 of 63) | 88% (14 of 16) |
| Shooting | Points destroyed by war machines | 156.7 | 42.7 |
| Magic | Magic missiles cast | 1.0 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 67% (2 of 3) | 25% (1 of 4) |
| Magic | Wounds caused by magic missiles | 2.0 | 4.7 |
| Magic | Points destroyed by magic (all spells) | 99.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 5.3 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 0.0 | 0.0 |
| Combat | Points run down | 0.0 | 62.0 |
| Combat | Net points per charged fight, damage counted | +1 | +76 |
| Combat | Net per 100 charger points, damage counted | +1.7 | +72.4 |
| Combat | First round won (charged fights) | 0% | 50% |
| Combat | Net points per charged fight | +0 | +93 |
| Combat | Net points per supported fight / lone fight | - / +0 | - / +93 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 2 | 2 of 2 |
| Game | Points lost | 317.0 | 364.0 |
| Game | VP from objectives | 883.3 | 313.3 |
| Game | Lone holders (player turns) | 10.0 | 0.0 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +586 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 681
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: gs3-83c8646-p40

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +8.2 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 11.0 | +106.3 | 0.0 | 0.0 | 23.7 | +540.0 | 0.0 | 109.3 |
| ARTILLERY RE-ROLL WEIGHED | 2.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.3 | -17.7 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 1.0 | +0.0 | 133.3 | 0.0 | 0.3 | +0.0 | 126.7 | 0.0 |
| CANNON PLANNED TARGET | 17.3 | +457.5 | 757.3 | 0.0 | 4.7 | +206.1 | 253.3 | 23.3 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 23.3 |
| CAST JOB | 1.7 | +251.6 | 317.0 | 253.3 | 0.7 | +11.3 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.3 | +28.8 | 0.0 | 0.0 | 0.3 | +2.3 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.3 | +21.5 | 0.0 | 0.0 |
| CHAFF PASSED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | - | - | - | - | 0.3 | +0.8 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.7 | -3.0 | 124.0 | 0.0 |
| CHARACTER GUNS | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 16.0 | -732.9 | 0.0 | 164.0 | 27.3 | -1534.0 | 0.0 | 1050.7 |
| CHARGE NOW FIRST | - | - | - | - | 1.0 | +0.0 | 102.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 9.3 | +0.0 | 0.0 | 0.0 | 10.7 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 1.0 | +63.2 | 133.3 | 133.3 |
| COVER ONCE | 14.0 | -806.7 | 0.0 | 228.7 | 9.7 | -451.9 | 0.0 | 317.0 |
| DEFENSIVE ARMY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 11.7 | -65.3 | 0.0 | 0.0 | 7.3 | -39.6 | 0.0 | 46.7 |
| EVASIVE BY THE ODDS | - | - | - | - | 0.3 | +46.1 | 0.0 | 0.0 |
| EXACT ROUND | 0.3 | +1.2 | 0.0 | 0.0 | 0.3 | +0.5 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 0.7 | +0.1 | 0.0 | 0.0 | 1.0 | +0.0 | 62.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 29.7 | +432.2 | 0.0 | 412.0 |
| FEATURE BUFFS | 1.3 | +4.6 | 0.0 | 0.0 | 1.7 | +2.4 | 0.0 | 100.7 |
| FIRE IN ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 148.7 | +5588.3 | 1918.7 | 672.7 | 103.3 | +3811.6 | 1451.3 | 1436.0 |
| FLANK NOT WEIGHED | 4.3 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 133.3 |
| FOLLOW UP WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FOOT FIRST | - | - | - | - | 23.7 | +0.0 | 0.0 | 124.0 |
| FOUR ROUNDS | 0.7 | +43.3 | 0.0 | 0.0 | 1.3 | +44.9 | 124.0 | 0.0 |
| FRIEND SHOOTS FIRST | 2.0 | -2.0 | 0.0 | 40.0 | - | - | - | - |
| GOAL ROUTE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| GOAL WALK | 4.0 | +391.7 | 0.0 | 0.0 | 13.0 | +936.6 | 0.0 | 100.7 |
| GUN FIGURES | 1.7 | +11.5 | 0.0 | 0.0 | 2.0 | -10.8 | 0.0 | 0.0 |
| GUN MASK | 5.7 | +176.4 | 0.0 | 0.0 | 0.7 | +12.8 | 0.0 | 0.0 |
| HARD STAY DROPPED | 4.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | - | - | - | - | 0.7 | +0.0 | 124.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 11.3 | +0.0 | 0.0 | 164.0 | 13.3 | +0.0 | 0.0 | 533.3 |
| HIS CHARGE LIST | 7.7 | +0.0 | 0.0 | 51.3 | 18.7 | +0.0 | 0.0 | 864.0 |
| HIS LEGAL MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 8.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.0 | -60.7 | 0.0 | 0.0 | 5.7 | -45.0 | 0.0 | 40.0 |
| HIS ONE QUARTER | 0.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 3.0 | +0.0 | 0.0 | 0.0 | 9.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 56.3 | +3718.2 | 0.0 | 171.3 | 69.0 | +6793.3 | 0.0 | 1122.7 |
| HIS SHOTS BY HIS RUN | 32.7 | +1215.9 | 0.0 | 244.0 | 54.3 | +1857.4 | 0.0 | 1389.3 |
| HIS TURN DENIED | - | - | - | - | 0.7 | +41.6 | 124.0 | 0.0 |
| HOLD ODDS | 16.3 | +0.0 | 0.0 | 124.0 | 19.7 | +0.0 | 0.0 | 310.7 |
| HOLDER ASSIGNMENT | 11.0 | +958.1 | 0.0 | 124.0 | 10.0 | +1040.0 | 0.0 | 105.0 |
| HONEST WORTH | 0.3 | -1.0 | 0.0 | 0.0 | 1.0 | -30.4 | 124.0 | 0.0 |
| IDLE COST | - | - | - | - | 16.0 | -237.6 | 0.0 | 149.3 |
| KEEPS SCOUTS OR AMBUSH | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +5.0 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 4.7 | +0.0 | 337.0 | 299.3 | 2.0 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.3 | +35.4 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.3 | +0.1 | 0.0 | 0.0 | 0.7 | +2.0 | 124.0 | 0.0 |
| MANOEUVRE | 2.7 | -32.1 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 0.3 | +15.1 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | - | - | - | - | 2.0 | +13.6 | 0.0 | 266.7 |
| MEETS IN TIME | 6.0 | +151.3 | 0.0 | 0.0 | 3.0 | +152.8 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.3 | +163.2 | 0.0 | 126.7 | 3.7 | +67.1 | 0.0 | 266.7 |
| MISSILES NEXT TURN | 1.7 | +94.8 | 0.0 | 126.7 | 4.7 | +35.3 | 0.0 | 266.7 |
| MODEL FACING | 4.7 | +1066.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 50.3 | 99.0 |
| MOVE SPELL SPOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 3.0 | +98.0 | 0.0 | 0.0 | 1.0 | +70.7 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 11.0 | +448.5 | 0.0 | 0.0 | 9.0 | +401.6 | 0.0 | 0.0 |
| NEAREST TO GOAL | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 2.0 | +53.1 | 0.0 | 0.0 | 1.0 | +70.7 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -10.0 | 0.0 | 0.0 | 0.7 | -17.6 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 0.7 | -24.3 | 0.0 | 0.0 | 1.0 | -10.1 | 124.0 | 0.0 |
| NO LATE CUT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 4.3 | -127.3 | 0.0 | 20.0 | 4.3 | -129.6 | 0.0 | 54.7 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 2.7 | -23.0 | 0.0 | 82.0 | 4.0 | -114.4 | 0.0 | 266.7 |
| ONE JOINT FIGURE | 0.3 | -89.8 | 0.0 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 6.3 | -256.4 | 0.0 | 124.0 | 5.3 | +96.8 | 0.0 | 54.7 |
| ONE ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 3.0 | +53.3 | 1200.0 | 253.3 | - | - | - | - |
| PATHS CROSS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PLAN RESULT | 63.0 | +1333.8 | 548.0 | 548.7 | 45.7 | +341.1 | 361.0 | 714.7 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 6.0 | -109.1 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 2.3 | -14.7 | 0.0 | 40.0 | - | - | - | - |
| PROMISE SHOT AWAY | 0.3 | -6.1 | 50.3 | 0.0 | - | - | - | - |
| QUARTER ODDS | 12.7 | +931.0 | 1066.7 | 253.3 | 8.0 | +556.3 | 1013.3 | 0.0 |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | - | - | - | - | 2.7 | +156.5 | 0.0 | 20.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.7 | +0.0 | 0.0 | 20.0 |
| REFORMS TO MEET IT | 0.7 | -42.8 | 0.0 | 0.0 | 0.7 | -29.6 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RISK BY ARC | 0.3 | +16.2 | 0.0 | 0.0 | 0.7 | +27.8 | 62.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.7 | -3.9 | 124.0 | 0.0 |
| RUN DOWN | - | - | - | - | 1.0 | -1.5 | 124.0 | 0.0 |
| SCOUT SPOT | 0.7 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.0 | -56.4 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +1.5 | 0.0 | 0.0 | 0.7 | +37.6 | 0.0 | 0.0 |
| SET CREDITED ONCE | 3.7 | -117.4 | 0.0 | 40.0 | 1.0 | -36.9 | 0.0 | 0.0 |
| SET UP BY THE SET | 4.3 | +82.7 | 0.0 | 40.0 | 2.3 | +21.3 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.3 | +7.0 | 0.0 | 0.0 | - | - | - | - |
| SET-UP MISSED | - | - | - | - | 0.3 | +72.1 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.7 | -0.9 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 1.3 | +2.7 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 25.7 | +0.0 | 0.0 | 188.7 | 8.7 | +0.0 | 0.0 | 23.3 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +7.7 | 40.0 | 0.0 | 1.3 | +20.9 | 51.3 | 0.0 |
| SHORT GUN FORWARD | 2.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOT RISK POINTS | 34.7 | +600.7 | 0.0 | 171.3 | 45.7 | -204.0 | 0.0 | 1002.0 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 35.3 | +1450.7 | 0.0 | 144.0 | 16.3 | +882.6 | 0.0 | 399.3 |
| SPELL WORTH | - | - | - | - | 7.7 | +200.6 | 266.7 | 266.7 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | +0.4 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 4.0 | +0.0 | 0.0 | 20.0 | 7.7 | +0.0 | 0.0 | 70.3 |
| STANDS FOR A REASON | - | - | - | - | 3.7 | +0.0 | 0.0 | 266.7 |
| STANDS STILL | 107.7 | +0.0 | 1918.7 | 497.3 | 42.0 | +0.0 | 1327.3 | 354.0 |
| STAY WORTH | 66.3 | +475.6 | 1545.7 | 279.0 | 22.0 | +268.8 | 356.0 | 179.3 |
| STRIKE BY THE ODDS | 0.7 | +13.1 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 0.3 | +26.7 | 0.0 | 0.0 | 3.3 | +26.6 | 0.0 | 0.0 |
| SUPPORT NARROWED | 1.3 | +0.0 | 40.0 | 0.0 | 0.7 | +0.0 | 40.0 | 0.0 |
| SUPPORT WORKED OUT | 0.3 | +26.7 | 0.0 | 0.0 | 3.3 | +26.6 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 1.0 | +6.6 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 50.3 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 63.0 | +0.0 | 0.0 | 296.3 | 45.3 | +0.0 | 0.0 | 718.0 |
| TIED UP BY THE SUM | - | - | - | - | 0.3 | +43.2 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 75.0 | +630.1 | 0.0 | 169.7 | 2.3 | +41.3 | 0.0 | 0.0 |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.7 | -68.1 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 0.7 | -23.1 | 0.0 | 124.0 | 2.0 | -174.5 | 0.0 | 266.7 |
| WOUNDS ON THE RANKS | 5.3 | +347.1 | 0.0 | 0.0 | 3.7 | +97.7 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p40

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 376 | 365 | 99 | 33.00 | +4142 | +41.8 |
| ARMY TABLE | 104 | 104 | 79 | 26.33 | +1554 | +19.7 |
| HIS SHOTS BY HIS RUN | 261 | 254 | 63 | 21.00 | +1130 | +17.9 |
| HOLDER ASSIGNMENT | 63 | 63 | 62 | 20.67 | +4345 | +70.1 |
| SHOT RISK POINTS | 241 | 233 | 38 | 12.67 | +1830 | +48.1 |
| DEPLOY BY FIGURES | 57 | 57 | 33 | 11.00 | +760 | +23.0 |
| TIME ON OUR SIDE | 232 | 212 | 28 | 9.33 | +37 | +1.3 |
| OFF BEST | 26 | 26 | 26 | 8.67 | -771 | -29.7 |
| LEGAL CHARGES ONLY | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 18 | 6.00 | +0 | +0.0 |
| GOAL WALK | 51 | 49 | 16 | 5.33 | +1135 | +70.9 |
| HARD STAY DROPPED | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| MODEL FACING | 14 | 14 | 14 | 4.67 | +3201 | +228.6 |
| ARTILLERY RE-ROLL WEIGHED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| CHARGE LOSSES | 130 | 123 | 11 | 3.67 | +1089 | +99.0 |
| FIVE ACTION | 756 | 743 | 11 | 3.67 | +506 | +46.0 |
| IDLE COST | 48 | 39 | 9 | 3.00 | +86 | +9.6 |
| COVER ONCE | 71 | 52 | 8 | 2.67 | +109 | +13.6 |
| MOVE ORDER | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| STAY WORTH | 265 | 255 | 8 | 2.67 | +44 | +5.6 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| CANNON SIGHT KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| CAST JOB | 7 | 7 | 7 | 2.33 | +275 | +39.3 |
| GUN MASK | 19 | 18 | 7 | 2.33 | +186 | +26.6 |
| SHORT GUN FORWARD | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 155 | 139 | 7 | 2.33 | +395 | +56.4 |
| PROMISE BY ITS OWN SUM | 24 | 24 | 6 | 2.00 | -327 | -54.6 |
| SET UP BY THE SET | 20 | 18 | 6 | 2.00 | +47 | +7.9 |
| MEETS IN TIME | 27 | 27 | 5 | 1.67 | +211 | +42.1 |
| QUARTER ODDS | 62 | 61 | 5 | 1.67 | +131 | +26.2 |
| REDIRECT FOR A FRIEND IN REACH | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 29 | 29 | 5 | 1.67 | +0 | +0.0 |
| SUPPORT ADDS | 11 | 11 | 5 | 1.67 | +60 | +11.9 |
| SUPPORT WORKED OUT | 11 | 11 | 5 | 1.67 | +60 | +11.9 |
| SEARCH SPOT | 4 | 4 | 4 | 1.33 | +117 | +29.3 |
| SHOOTERS IN TWO RANKS | 4 | 4 | 4 | 1.33 | +8 | +2.0 |
| CHAFF IN THE MOVE | 4 | 4 | 3 | 1.00 | +16 | +5.2 |
| FIRE IN ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 12 | 10 | 3 | 1.00 | +32 | +10.7 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FALLS SHORT | 89 | 77 | 2 | 0.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| GOAL ROUTE | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HIS MOVE AND SHOT | 29 | 27 | 2 | 0.67 | +1 | +0.4 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +17 | +8.7 |
| NEXT CHARGE BY LIST | 9 | 9 | 2 | 0.67 | +32 | +16.0 |
| ONE OBJECTIVE FORMULA | 35 | 32 | 2 | 0.67 | +310 | +155.0 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 8 | 8 | 2 | 0.67 | +44 | +21.9 |
| SUPPORT NARROWED | 6 | 6 | 2 | 0.67 | -35 | -17.5 |
| WHOLE FIGHT DANGER | 8 | 8 | 2 | 0.67 | +133 | +66.6 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +24 | +24.5 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -53 | -53.0 |
| CANNON PLANNED TARGET | 66 | 66 | 1 | 0.33 | +0 | +0.0 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +2 | +2.3 |
| CHARGE NOW FIRST | 3 | 3 | 1 | 0.33 | -7 | -7.2 |
| FOUR ROUNDS | 6 | 6 | 1 | 0.33 | +16 | +15.6 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +106 | +106.2 |
| MAX FOR POSITIONING | 6 | 6 | 1 | 0.33 | +2 | +2.5 |
| MISSILES IN THE MOVE | 15 | 13 | 1 | 0.33 | +105 | +104.9 |
| MISSILES NEXT TURN | 19 | 16 | 1 | 0.33 | +0 | +0.0 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| PROMISE READS THE TABLE | 7 | 7 | 1 | 0.33 | -35 | -35.3 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -18 | -18.4 |
| REFUSING RETIRES | 2 | 2 | 1 | 0.33 | -10 | -10.5 |
| RISK BY ARC | 3 | 3 | 1 | 0.33 | +16 | +15.6 |
| STRIKE BY THE ODDS | 2 | 2 | 1 | 0.33 | +17 | +17.4 |
| SURE REACH TOGETHER | 3 | 2 | 1 | 0.33 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 14 | 1 | 1 | 0.33 | +0 | +0.0 |
| TIED UP BY THE SUM | 1 | 1 | 1 | 0.33 | +13 | +13.3 |
| CANNON PLAN MISSED | 4 | 4 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 10 | 10 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 60 | 59 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 1 | 1 | 0 | 0.00 | - | - |
| EVASIVE BY THE ODDS | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 5 | 5 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 9 | 9 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 37 | not checked | - | - | - | - |
| FOOT FIRST | 71 | not checked | - | - | - | - |
| FRIEND SHOOTS FIRST | 6 | 4 | 0 | 0.00 | - | - |
| GUN FIGURES | 11 | not checked | - | - | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 74 | 67 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 79 | 75 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 33 | 32 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 10 | 9 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 36 | 35 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HOLD ODDS | 108 | 107 | 0 | 0.00 | - | - |
| HONEST WORTH | 4 | 4 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 14 | 13 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 3 | 3 | 0 | 0.00 | - | - |
| MANOEUVRE | 17 | 17 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 1 | 1 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 3 | not checked | - | - | - | - |
| NEARER NOT NEEDED | 60 | 56 | 0 | 0.00 | - | - |
| NEAREST TO GOAL | 8 | 8 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 3 | 3 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 5 | 5 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 20 | 16 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE ROUTE | 1 | 1 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS A LANE | 9 | 8 | 0 | 0.00 | - | - |
| PLAN RESULT | 326 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 1 | 1 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 8 | 8 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 4 | 4 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 3 | 3 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 14 | 12 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 103 | not checked | - | - | - | - |
| SPELL WORTH | 23 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 35 | 28 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 11 | 11 | 0 | 0.00 | - | - |
| STANDS STILL | 449 | 444 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 13 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 21 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 10 | not checked | - | - | - | - |
| THE TABLE BINDS | 325 | not checked | - | - | - | - |
| WAITS AGAIN | 3 | 3 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 27 | 26 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p40

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.67 | 3.33 | 32.1 |
| ARMY TABLE | rule | 0.67 | 3.67 | 60.1 |
| PROMISE BY ITS OWN SUM | rule | 2.00 | - | 54.6 |
| HOLDER ASSIGNMENT | rule | 1.00 | 0.33 | 18.8 |
| NO REASON | gate | - | 1.00 | 30.3 |
| RULE SWITCHED OFF | gate | 0.67 | - | 3.6 |
| SUPPORT NARROWED | rule | 0.67 | - | 17.5 |
| BEST PRIZE | rule | - | 0.33 | 53.0 |
| CHARGE NOW FIRST | rule | - | 0.33 | 7.2 |
| PROMISE READS THE TABLE | rule | 0.33 | - | 35.3 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 18.4 |
| REFUSING RETIRES | rule | - | 0.33 | 10.5 |

### Plans: gs3-83c8646-p40

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.3 | 0% | 10 | 8 | 77% |
| Mine | move | 40.7 | 98% | 1242 | 0 | 0% |
| Mine | shoot | 22.0 | 64% | 1057 | 1326 | 125% |
| Opponent | charge | 0.7 | 0% | 54 | 0 | 0% |
| Opponent | join | 0.3 | 100% | 13 | 0 | 0% |
| Opponent | move | 37.3 | 96% | 1293 | 0 | 0% |
| Opponent | shoot | 7.0 | 67% | 347 | 341 | 98% |
| Opponent | support | 0.3 | 100% | 0 | 0 | - |

### Battle groups: gs3-83c8646-p40

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 2.7 | 12% | 100% | 0% | - | 100% | 0% | 0% | 0% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p40

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 10 | 34 (10) | 34 | 0 | 37 | 60% | 3.0 | 83 (3) | 0 (5) | 0 (2) | 19 (8) | 63 (2) |
| Mine | Clean-up | 4 | 0 (4) | 0 | 0 | 0 | 50% | 2.5 | - | 0 (2) | 0 (2) | 0 (4) | - |
| Mine | Fast | 2 | 0 (2) | 0 | 0 | 50 | 0% | 2.5 | - | - | 0 (2) | 0 (2) | - |
| Mine | Fast Hammer | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | 0 (2) | 0 (1) | - | 0 (2) | 0 (1) |
| Mine | Hammer | 3 | 86 (3) | 0 | 86 | 0 | 33% | 6.0 | - | 120 (1) | 0 (2) | 100 (2) | 0 (1) |
| Mine | Shooter | 10 | 110 (10) | 15 | 95 | 18 | 0% | 2.0 | 177 (1) | 263 (4) | 22 (5) | 70 (7) | 190 (3) |
| Mine | War machine | 15 | 29 (15) | 29 | 0 | 7 | 13% | 1.7 | 125 (3) | - | 0 (12) | 76 (5) | 0 (10) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 38 | 67% | 4.0 | - | 0 (2) | 0 (1) | 0 (1) | 0 (2) |
| Opponent | Character | 10 | 0 (10) | 0 | 0 | 35 | 50% | 3.0 | 0 (4) | 0 (3) | 0 (3) | 0 (6) | 0 (4) |
| Opponent | Clean-up | 2 | 35 (2) | 35 | 0 | 0 | 0% | 6.0 | - | 35 (2) | - | - | 35 (2) |
| Opponent | Fast Hammer | 3 | 0 (3) | 0 | 0 | 23 | 100% | - | 0 (2) | 0 (1) | - | 0 (3) | - |
| Opponent | Hammer | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Holder | 3 | 58 (3) | 0 | 58 | 0 | 100% | - | 15 (1) | 77 (2) | - | 89 (2) | 0 (1) |
| Opponent | Shooter | 4 | 105 (4) | 90 | 14 | 23 | 0% | 1.0 | 194 (2) | 0 (2) | - | 105 (4) | - |
| Opponent | War machine | 6 | 20 (6) | 20 | 0 | 11 | 33% | 1.0 | - | 48 (3) | 0 (3) | 0 (2) | 28 (4) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.5 | - | 0 (1) | 0 (1) | 0 (1) | 0 (1) |

### Charged fights: gs3-83c8646-p40

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 2 | 112 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 2 | 0 of 2 | - | +0 |
| Mine | Empire of Man | 1 | 918 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 381 | 0 | 0.7 | 1.0 | 0 | 0 | +0 | 1 of 2 | 0 of 2 | - | +0 |
| Opponent | Empire of Man | 1 | 308 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 1 | 457 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Vampire Counts | 1 | 0 | 186 | 2.0 | 1.0 | 93 | 0 | +93 | 2 of 2 | 1 of 2 | - | +93 |
| **Opponent** | all armies | 3 | 255 | 62 | 0.7 | 1.0 | 93 | 0 | +93 | 2 of 2 | 1 of 2 | - | +93 |

### Effective charges: gs3-83c8646-p40

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 2 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Vampire Counts | 2 | 0 | 1 (net +186) | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |

### Charged fights, damage counted: gs3-83c8646-p40

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 50 | 371 | +0 | 22 | 25 | -3 | -6.4 |
| Mine | 76-89% | 1 | 60 | 60 | +0 | 45 | 40 | +5 | +8.3 |
| Mine | All fights | 2 | 55 | 216 | +0 | 33 | 32 | +1 | +1.7 |
| Opponent | 50-54% | 1 | 161 | 186 | +186 | 186 | 0 | +186 | +115.5 |
| Opponent | No odds | 1 | 50 | 250 | +0 | 0 | 33 | -33 | -66.7 |
| Opponent | All fights | 2 | 106 | 218 | +93 | 93 | 17 | +76 | +72.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p40 | move | 13 | 0 (0%) | 0 (0%) | 0 (0%) | 13 (100%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0624 |
| Invocation of Nehek | Opponent | L0624 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Twice-Blessed Armour | Mine | L0713 |
| Witch Hunter's Ward | Mine | L0713 |
| Witch Hunter's Ward | Opponent | L0608 |

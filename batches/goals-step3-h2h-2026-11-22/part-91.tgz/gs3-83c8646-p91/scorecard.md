# Doctrine scorecard: gs3-83c8646-p91

### Scorecard: gs3-83c8646-p91

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1126 | 4 | 1 | Mine | no | 0 | 2 | 0 | 0 | 0 | 0 | 0 | 165 |
| L1126 | 4 | 1 | Opponent | no | 7 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 6 | 0 | 0 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 2 | 2 | 0 | 0 | 0 | 925 |
| L1314 | 6 | 1 | Mine | no | 0 | 2 | 0 | 3 | 1 | 0 | 0 | 70 |
| L1314 | 6 | 1 | Opponent | no | 6 | 2 | 3 | 3 | 0 | 0 | 0 | 123 |
| **Average** | | | Mine | 0% | 0.0 | 2.0 | 2.0 | 1.0 | 0.3 | 0.0 | 0.0 | 188.3 |
| **Average** | | | Opponent | 0% | 6.5 | 2.0 | 3.0 | 2.3 | 0.0 | 0.0 | 0.0 | 349.3 |

### KPIs: gs3-83c8646-p91

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 13% (2 of 15) | 0% (0 of 16) | 6% (2 of 31) |
| Winner chose to follow up after the loser gave ground |  | 50% (4 of 8); on the table 62% | 75% (3 of 4); on the table 100% | 58% (7 of 12); on the table 75% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 56% (5 of 9); on the table 67% | 75% (3 of 4); on the table 100% | 62% (8 of 13); on the table 77% |
| Magic missiles tried each own turn | 50%+ | 31% (12 of 39) | 74% (14 of 19) | 45% (26 of 58) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 36% (12 of 33) | 74% (14 of 19) | 50% (26 of 52) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 67% (6 of 9) | 67% (6 of 9) |
| Points that never fought | lower | 41% (2008 of 4955) | 46% (2756 of 5999) | 43% (4764 of 10954) |
|   infantry points that never fought | lower | 65% (666 of 1031) | 44% (624 of 1430) | 52% (1290 of 2461) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 62% (13 of 21) | 67% (14 of 21) | 64% (27 of 42) |
| Bound items with a magic missile used (at least once a game) |  | 83% (5 of 6); 4.3 uses a game | 0.0 uses a game | 83% (5 of 6); 2.2 uses a game |
| Bound items with another spell used |  | 0% (0 of 2); 0.0 uses a game | 0% (0 of 6); 0.0 uses a game | 0% (0 of 8); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 2); 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 33% (1 of 3); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 59% (2731 of 4623) | 54% (2938 of 5431) | 56% (5669 of 10054) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (7%) | 0.7 (40%) | 1.3 (12%) |
| MARCHED: its unit marched | 3.7 (41%) | 0.7 (40%) | 4.3 (41%) |
| CHARGED: its unit charged | 2.0 (22%) | 0.3 (20%) | 2.3 (22%) |
| IN COMBAT: engaged in combat | 1.7 (19%) | 0.0 (0%) | 1.7 (16%) |
| FLEEING: fleeing | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.7 (7%) | 0.0 (0%) | 0.7 (6%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 10.7 | 2.7 | 4.3 | 8.7 | 0.0 | 1.0 |
| not cast | 1.3 | 3.3 | 3.7 | 10.7 | 4.0 | 39.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (25%) | 2.7 (80%) | 1.0 (27%) | 1.3 (12%) | 0.7 (17%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.3 (41%) | 0.7 (17%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (22%) | 1.0 (25%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.3 (9%) | 1.7 (16%) | 1.3 (33%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.3 (8%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (6%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.7 (20%) | 0.0 (0%) | 0.7 (6%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.0 (75%) | 0.0 (0%) | 2.3 (64%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 35.7 (91%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.3 a game | 4.0 a game | 2.2 a game |
| stood (cast and not dispelled) | 100% (1 of 1) | 58% (7 of 12) | 62% (8 of 13) |
| the unit moved after it | 100% (1 of 1) | 86% (6 of 7) | 88% (7 of 8) |
| it charged on its next turn | 0% (0 of 1) | 0% (0 of 7) | 0% (0 of 8) |
| the enemy charged it first | 0% (0 of 1) | 0% (0 of 7) | 0% (0 of 8) |
| it fought by the end of its next turn | 0% (0 of 1) | 0% (0 of 7) | 0% (0 of 8) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 1) | 14% (1 of 7) | 12% (1 of 8) |
| none of these (no charge, no fight, no charge escaped) | 100% (1 of 1) | 86% (6 of 7) | 88% (7 of 8) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 70% (42 of 60) | 58% (18 of 31) | 66% (60 of 91) |
|   cavalry | - | 83% (5 of 6) | 83% (5 of 6) |
|   character | 17% (1 of 6) | 27% (3 of 11) | 24% (4 of 17) |
|   chariot | 67% (4 of 6) | - | 67% (4 of 6) |
|   infantry | 87% (13 of 15) | 71% (10 of 14) | 79% (23 of 29) |
|   war machine | 73% (24 of 33) | - | 73% (24 of 33) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (39%) | 0.7 (15%) | 3.0 (29%) |
| CHARGED: it charged | 0.0 (0%) | 0.7 (15%) | 0.7 (6%) |
| IN COMBAT: it fought this turn or the last | 0.3 (6%) | 0.3 (8%) | 0.7 (6%) |
| MOVED: a war machine that moved | 1.3 (22%) | 0.0 (0%) | 1.3 (13%) |
| NO TARGET IN RANGE | 0.0 (0%) | 1.3 (31%) | 1.3 (13%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (6%) | 0.3 (8%) | 0.7 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (17%) | 1.0 (23%) | 2.0 (19%) |
| SHELTERED: the target was sheltered | 0.7 (11%) | 0.0 (0%) | 0.7 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| character | 3.0 | 1.0 | 67% | 15.4 pts | 46 pts |
| chariot | 1.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 14.0 | 5.3 | 69% | 13.6 pts | 190 pts |
| war machine | 8.7 | 5.3 | 69% | 13.6 pts | 118 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 4.7 | 3.8 |
| Charges that made contact a game | 1.3 | 4.0 | 2.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.25 declared, 0.50 contact (4 units) | 0.33 declared, 0.00 contact (3 units) | 0.86 declared, 0.29 contact (7 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 3.00 declared, 3.00 contact (1 units) | 3.00 declared, 3.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.36 declared, 0.18 contact (11 units) | 0.40 declared, 0.36 contact (25 units) | 0.39 declared, 0.31 contact (36 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 75% (6 of 8) | - | 0% (0 of 1) | 67% (6 of 9) |
| Character on its own | 50% (1 of 2) | 60% (3 of 5) | 43% (3 of 7) | 50% (7 of 14) |
| Chariot | 100% (1 of 1) | - | - | 100% (1 of 1) |
| Infantry | 62% (5 of 8) | 100% (1 of 1) | 0% (0 of 1) | 60% (6 of 10) |
| Monster | 100% (1 of 1) | 100% (2 of 2) | - | 100% (3 of 3) |
| Monstrous | - | 0% (0 of 1) | - | 0% (0 of 1) |
| War Machines | 100% (4 of 4) | - | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 2 | 56% (5 of 9); on the table 67% | 33% (12 of 36) | 32% | 59% (10 of 17) | 80% (4 of 5); 4.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| High Elf Realms | 2 | 100% (1 of 1); on the table 100% | 50% (5 of 10) | 65% | 69% (9 of 13) | 100% (1 of 1); 2.5 uses a game | 0% (0 of 8); 0.0 uses a game | 0.0 uses a game |
| Skaven | 1 | 100% (1 of 1); on the table 100% | 100% (6 of 6) | 43% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 1 | 50% (1 of 2); on the table 100% | 50% (3 of 6) | 33% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p91, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 67% (6) | 75% (3) | 69% (9) |
| ...free all their last turn and able to turn (per game) | 1.67 | 1.00 | 2.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 1.00 | 1.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p91

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 5.0 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 45% (5 of 11) | 55% (6 of 11) |
| Strategy | Shoot objectives carried out (shot that target) | 19% (8 of 43) | 7% (1 of 15) |
| Strategy | Hexes on a unit its side charged or shot that turn | 20% (1 of 5) | - |
| Strategy | Joined characters whose unit fought | - | 100% (1 of 1) |
| Strategy | Lone characters that fought | 78% (7 of 9) | 50% (3 of 6) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 1.0 | 2.3 |
| Movement | Points that never moved of their own | 188.3 | 349.3 |
| Movement | Fights charged into per game | 1.7 | 3.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 5 | 3 of 9, net +99 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 5 | 0 of 9 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 4 of 5, net +110 | 0 of 9 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 5 | 3 of 9, net +55 |
| Shooting | Shots by shooting units (incl. breath weapons) | 6.0 | 8.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 56% (10 of 18) | 48% (12 of 25) |
| Shooting | Points destroyed by shooting units | 100.7 | 0.0 |
| Shooting | War machine shots | 8.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 58% (14 of 24) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 2.7 | 4.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 88% (7 of 8) | 57% (8 of 14) |
| Magic | Wounds caused by magic missiles | 1.7 | 0.7 |
| Magic | Wounds caused by other spells | 1.3 | 1.0 |
| Magic | Points destroyed by magic (all spells) | 60.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.7 / 1.7 / 0.3 / 0.0 | 6.3 / 0.3 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 231.0 | 257.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +66 | +66 |
| Combat | Net per 100 charger points, damage counted | +22.4 | +17.5 |
| Combat | First round won (charged fights) | 80% | 60% |
| Combat | Net points per charged fight | +83 | +67 |
| Combat | Net points per supported fight / lone fight | - / +83 | +0 / +74 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 5 | 7 of 10 |
| Game | Points lost | 533.0 | 476.3 |
| Game | VP from objectives | 403.3 | 480.0 |
| Game | Lone holders (player turns) | 0.0 | 6.5 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -299 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 1009
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p91

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 41.0 |
| AFTERMATH IN POINTS | 1.0 | +167.6 | 0.0 | 0.0 | 0.3 | +6.3 | 0.0 | 20.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +15.4 | 0.0 | 0.0 |
| ARMY TABLE | 9.3 | +102.5 | 0.0 | 129.3 | 17.0 | +434.7 | 0.0 | 50.3 |
| ARTILLERY RE-ROLL WEIGHED | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BOMBING RUN | 0.3 | +12.5 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 8.0 | +246.0 | 537.3 | 110.0 | - | - | - | - |
| CANNON SIGHT KEPT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 3.3 | +64.4 | 0.0 | 57.0 | 5.3 | +17.1 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +19.9 | 0.0 | 0.0 | 0.7 | +14.8 | 0.0 | 47.7 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.7 | -41.1 | 57.0 | 47.7 |
| CHARGE LOSSES | 11.0 | -916.3 | 0.0 | 279.3 | 19.0 | -587.5 | 0.0 | 341.3 |
| CHARGE NOW FIRST | 4.3 | +0.0 | 144.7 | 72.3 | 2.7 | +0.0 | 0.0 | 47.7 |
| CLOSES ON WHAT IT BEATS | 9.3 | +0.0 | 0.0 | 359.0 | 11.3 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.7 | +0.0 | 50.3 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CONTINUE AHEAD WEIGHED | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 1.3 | +164.9 | 0.0 | 0.0 | 3.0 | +433.9 | 0.0 | 0.0 |
| COVER ONCE | 7.3 | -262.4 | 0.0 | 64.7 | 10.0 | -1940.5 | 0.0 | 98.0 |
| DENIED BY THE FIGHT | 1.3 | -2.3 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 6.3 | -33.8 | 0.0 | 0.0 | 7.7 | +92.6 | 0.0 | 41.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -16.2 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | 0.3 | +3.7 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 2.3 | +40.3 | 50.0 | 0.0 | 2.7 | +40.6 | 55.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.3 | +17.8 | 34.3 | 72.3 | 3.0 | +45.6 | 57.0 | 47.7 |
| FALLS SHORT | - | - | - | - | 22.0 | +269.0 | 0.0 | 144.0 |
| FEATURE BUFFS | 1.3 | +3.2 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.7 | +6.1 | 0.0 | 72.3 | 1.7 | +6.8 | 57.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 83.3 | +5107.5 | 1083.7 | 1417.0 | 75.7 | +6414.4 | 112.0 | 627.7 |
| FLANK NOT WEIGHED | 5.0 | +0.0 | 0.0 | 164.3 | 6.7 | +0.0 | 0.0 | 148.3 |
| FOCUS FIRE | 0.3 | +0.8 | 50.3 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 1.0 | +171.1 | 0.0 | 0.0 | 1.3 | +416.9 | 0.0 | 47.7 |
| FOOT FIRST | 26.3 | +0.0 | 0.0 | 600.0 | - | - | - | - |
| FOUR ROUNDS | 3.7 | +419.8 | 158.0 | 72.3 | 4.0 | +550.2 | 112.0 | 47.7 |
| FREED FROM HIS FIGHT | 2.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 148.3 |
| FRIEND CHARGES FIRST | 0.3 | -40.4 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 4.7 | -47.7 | 0.0 | 144.7 | 0.7 | -109.9 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.3 | -7.2 | 0.0 | 0.0 |
| GOAL ON TIME | 0.7 | +34.6 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 5.3 | +358.1 | 0.0 | 100.7 | 7.7 | +779.7 | 0.0 | 0.0 |
| GUN FIGURES | - | - | - | - | 0.7 | +1.5 | 0.0 | 0.0 |
| GUN MASK | 1.7 | +27.0 | 0.0 | 89.3 | - | - | - | - |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 148.3 |
| HIS CHARGE BY HIS RUN | 9.3 | +0.0 | 0.0 | 279.3 | 10.3 | +0.0 | 0.0 | 151.0 |
| HIS CHARGE DENIED | 0.3 | +26.0 | 47.7 | 0.0 | 0.3 | +33.0 | 0.0 | 0.0 |
| HIS CHARGE LIST | 5.7 | +0.0 | 0.0 | 110.0 | 9.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 5.3 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 95.3 |
| HIS MOVE AND SHOT | 0.3 | -1.0 | 0.0 | 0.0 | 7.0 | -27.2 | 0.0 | 0.0 |
| HIS ONE QUARTER | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 9.0 | +0.0 | 0.0 | 0.0 | 9.3 | +0.0 | 0.0 | 95.3 |
| HIS RANDOM MOVE | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 19.7 | +947.8 | 0.0 | 311.3 | 48.7 | +1977.9 | 0.0 | 373.0 |
| HIS SHOTS BY HIS RUN | 21.0 | +280.6 | 0.0 | 646.3 | 42.7 | +835.1 | 0.0 | 443.0 |
| HIS TURN DENIED | 1.7 | +12.6 | 21.7 | 0.0 | 0.3 | +16.5 | 55.0 | 0.0 |
| HOLD ODDS | 13.7 | +0.0 | 0.0 | 473.0 | 11.0 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 8.3 | +849.4 | 0.0 | 265.0 | 7.3 | +832.9 | 0.0 | 41.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HONEST WORTH | 3.7 | -112.7 | 158.0 | 72.3 | 3.7 | -201.3 | 112.0 | 47.7 |
| HUNT IN PAIRS | 2.7 | +188.9 | 0.0 | 72.3 | 0.7 | +91.3 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 15.3 | -297.1 | 0.0 | 126.3 |
| JOINT CHARGE NOW | 0.3 | +3.0 | 0.0 | 72.3 | 0.3 | -57.9 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 4.0 | +0.0 | 0.0 | 302.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.0 | +10.6 | 0.0 | 0.0 | 1.3 | +77.8 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 100.7 | - | - | - | - |
| LEGAL CHARGES ONLY | 3.0 | +0.0 | 67.7 | 114.0 | 4.7 | +0.0 | 89.3 | 208.7 |
| LONE WIZARD KEPT IN | 0.3 | +17.9 | 0.0 | 0.0 | 0.3 | +39.6 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 2.0 | -1.1 | 12.7 | 72.3 | 2.3 | +10.7 | 0.0 | 47.7 |
| MANOEUVRE | 1.0 | +1.0 | 0.0 | 57.0 | 2.7 | +4.7 | 0.0 | 119.7 |
| MARCH BY THE SUM | 1.3 | +82.4 | 0.0 | 0.0 | 0.3 | +7.5 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +16.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 1.3 | +108.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 2.0 | +109.5 | 0.0 | 0.0 | 0.3 | -4.3 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 2.3 | +0.0 | 0.0 | 201.3 | 1.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 6.7 | +342.3 | 0.0 | 186.3 | 4.3 | +180.1 | 0.0 | 0.0 |
| MEETS IN TIME | 2.3 | +324.6 | 0.0 | 0.0 | 3.3 | +387.1 | 0.0 | 41.0 |
| MISSILES IN THE MOVE | 8.0 | +116.2 | 0.0 | 57.0 | 4.3 | +34.6 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 10.7 | +100.9 | 0.0 | 114.0 | 5.0 | +30.5 | 0.0 | 0.0 |
| MOVE ORDER | 1.3 | +0.0 | 50.3 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 7.3 | +1071.8 | 0.0 | 144.7 | 4.3 | +676.6 | 0.0 | 95.3 |
| NEARER NOT NEEDED | 1.7 | +90.1 | 0.0 | 0.0 | 5.7 | +294.7 | 0.0 | 50.3 |
| NEAREST TO GOAL | 2.0 | +0.0 | 0.0 | 100.7 | - | - | - | - |
| NEXT CHARGE BY LIST | 5.7 | +1207.7 | 0.0 | 0.0 | 3.0 | +542.0 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.7 | -36.1 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 3.3 | -169.5 | 144.7 | 72.3 | 3.7 | -311.1 | 112.0 | 47.7 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.0 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 3.0 | -60.4 | 0.0 | 0.0 | 2.7 | -95.5 | 57.0 | 0.0 |
| OGRE LOADER SECOND SHOT | 3.3 | +74.5 | 0.0 | 0.0 | - | - | - | - |
| ONE CHALLENGE TEST | 0.3 | +10.5 | 47.7 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.3 | -145.3 | 0.0 | 72.3 | 5.7 | -167.6 | 0.0 | 47.7 |
| ONE JOINT FIGURE | 0.3 | +9.8 | 0.0 | 72.3 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 4.3 | -229.4 | 0.0 | 114.0 | 1.7 | +3.8 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 1.7 | -302.5 | 0.0 | 0.0 | 0.7 | -3.5 | 0.0 | 0.0 |
| ONE ROUTE | 2.3 | +0.0 | 0.0 | 201.3 | 1.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.7 | +16.9 | 35.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.7 | +20.0 | 12.7 | 0.0 | 0.7 | +3.0 | 0.0 | 0.0 |
| OWN CAST FIRST | 1.0 | -4.4 | 0.0 | 0.0 | 0.3 | -1.9 | 0.0 | 0.0 |
| PATHS CROSS | 0.3 | +4.2 | 0.0 | 0.0 | 0.3 | +48.1 | 0.0 | 0.0 |
| PERIAPT WORTH | - | - | - | - | 0.3 | +18.1 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -24.4 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 37.3 | +692.2 | 329.0 | 694.3 | 35.7 | +479.8 | 0.0 | 599.3 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 72.3 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 9.7 | -468.9 | 0.0 | 0.0 | 4.3 | -135.1 | 0.0 | 47.7 |
| PROMISE KNOWS THE FIGHT | 3.7 | -11.7 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 47.7 |
| PROMISE READS THE TABLE | 1.7 | -95.4 | 0.0 | 144.7 | 0.3 | -35.1 | 0.0 | 47.7 |
| QUARTER ODDS | 5.0 | +433.6 | 0.0 | 165.0 | 7.0 | +1545.3 | 55.0 | 0.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.0 | +27.3 | 0.0 | 140.0 |
| REAL GROUND | 2.3 | +0.0 | 0.0 | 201.3 | 1.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 1.7 | +136.7 | 0.0 | 28.3 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 2.0 | +0.0 | 0.0 | 13.3 |
| REDIRECT WEIGHED | 0.3 | +1.7 | 21.7 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | - | - | - | - | 1.7 | -23.1 | 0.0 | 47.7 |
| REFUSING RETIRES | - | - | - | - | 1.0 | +0.0 | 0.0 | 95.3 |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +1.0 | 0.0 | 0.0 |
| RISK BY ARC | 3.7 | +137.0 | 158.0 | 72.3 | 2.7 | -88.9 | 57.0 | 47.7 |
| RISK ON THE WAY | 1.0 | +0.0 | 0.0 | 50.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.7 | -5.1 | 47.7 | 72.3 | 1.7 | -79.7 | 0.0 | 0.0 |
| RUN DOWN | 1.7 | -10.2 | 129.7 | 72.3 | 3.7 | -112.7 | 112.0 | 47.7 |
| SEARCH SPOT | 0.7 | +3.0 | 0.0 | 57.0 | 1.3 | +123.9 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +6.3 | 57.0 | 0.0 |
| SET CREDITED ONCE | 1.3 | -35.9 | 0.0 | 144.7 | - | - | - | - |
| SET UP BY THE SET | 2.7 | -16.5 | 0.0 | 144.7 | 1.0 | +1.5 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.7 | +1.7 | 0.0 | 0.0 | - | - | - | - |
| SET-UP ANY TARGET | 0.7 | +191.8 | 0.0 | 0.0 | 0.3 | +50.0 | 0.0 | 0.0 |
| SET-UP MISSED | 0.3 | +44.7 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 15.0 | +0.0 | 0.0 | 222.0 | 5.0 | +0.0 | 0.0 | 43.3 |
| SHOOTS FROM THE BEST SPOT | 4.7 | +82.9 | 21.7 | 0.0 | 3.3 | +251.2 | 0.0 | 43.3 |
| SHOT OR CHARGE | 0.7 | -17.1 | 0.0 | 0.0 | 0.3 | -2.3 | 0.0 | 0.0 |
| SHOT RISK POINTS | 10.3 | +234.5 | 0.0 | 165.3 | 32.7 | +97.7 | 0.0 | 463.3 |
| SHOTS AFTER THE MOVES | 5.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.7 | +614.5 | 0.0 | 252.3 | 6.0 | +380.9 | 0.0 | 43.3 |
| SPELL SETS UP CHARGE | 0.7 | +191.8 | 0.0 | 0.0 | 0.3 | +50.0 | 0.0 | 0.0 |
| SPELL WORTH | 3.0 | +58.4 | 0.0 | 0.0 | 8.0 | +175.3 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 1.3 | +28.9 | 0.0 | 0.0 | 0.3 | -30.3 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 4.3 | +0.0 | 0.0 | 151.0 | 6.7 | +0.0 | 0.0 | 47.7 |
| STAND AND SHOOT | 0.3 | -2.1 | 21.7 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | - | - | - | - | 6.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 42.0 | +0.0 | 925.7 | 497.0 | 25.3 | +0.0 | 0.0 | 226.7 |
| STAY WORTH | 25.3 | +142.1 | 904.0 | 220.0 | 6.7 | +119.8 | 0.0 | 65.0 |
| STRIKE BY THE ODDS | 0.3 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 7.3 | +718.4 | 0.0 | 401.0 | 11.0 | +2536.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 47.7 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 7.3 | +718.4 | 0.0 | 401.0 | 11.0 | +2536.0 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +1.1 | 0.0 | 0.0 | 0.3 | +7.1 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 1.0 | -266.9 | 0.0 | 0.0 | 0.3 | -35.1 | 0.0 | 47.7 |
| THE ROW IN ITS ORDER | 2.3 | +0.0 | 0.0 | 151.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 63.7 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 35.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 37.3 | +0.0 | 0.0 | 617.3 | 33.7 | +0.0 | 0.0 | 220.0 |
| TIED UP BY THE SUM | 1.7 | +139.5 | 110.3 | 0.0 | 0.3 | +55.9 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 35.7 | +547.2 | 0.0 | 452.3 | - | - | - | - |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -24.4 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | - | - | - | - | 1.3 | -9.3 | 55.0 | 0.0 |
| WHO HITS BACK | 0.7 | +40.3 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 4.7 | -769.6 | 0.0 | 114.0 | 1.0 | -89.6 | 0.0 | 151.0 |
| WHOLE FIGHT GAIN | 0.3 | +2.1 | 0.0 | 72.3 | - | - | - | - |
| WOUNDS ON THE RANKS | - | - | - | - | 2.0 | +5.9 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p91

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 79 | 79 | 58 | 19.33 | +1583 | +27.3 |
| HOLDER ASSIGNMENT | 47 | 47 | 41 | 13.67 | +3058 | +74.6 |
| HIS SHOT LIST | 205 | 193 | 40 | 13.33 | +1372 | +34.3 |
| FIVE ACTION | 477 | 462 | 37 | 12.33 | +3762 | +101.7 |
| MOVE TO CHARGE COMPUTED | 35 | 33 | 25 | 8.33 | +1364 | +54.6 |
| HIS SHOTS BY HIS RUN | 191 | 181 | 24 | 8.00 | +311 | +13.0 |
| LEGAL CHARGES ONLY | 23 | 23 | 23 | 7.67 | +0 | +0.0 |
| DEPLOY BY FIGURES | 42 | 42 | 22 | 7.33 | +452 | +20.5 |
| THE TABLE AGAIN | 36 | 36 | 21 | 7.00 | +0 | +0.0 |
| SHOT RISK POINTS | 129 | 123 | 19 | 6.33 | +713 | +37.5 |
| SUPPORT ADDS | 55 | 52 | 19 | 6.33 | +2617 | +137.7 |
| SUPPORT WORKED OUT | 55 | 52 | 19 | 6.33 | +2617 | +137.7 |
| SHOOTS FROM THE BEST SPOT | 24 | 24 | 18 | 6.00 | +340 | +18.9 |
| OFF BEST | 17 | 17 | 17 | 5.67 | -468 | -27.5 |
| PROMISE BY ITS OWN SUM | 42 | 42 | 17 | 5.67 | -1812 | -106.6 |
| CAST JOB | 26 | 26 | 14 | 4.67 | +54 | +3.9 |
| NEXT CHARGE BY LIST | 26 | 25 | 14 | 4.67 | +1524 | +108.8 |
| GOAL WALK | 39 | 39 | 13 | 4.33 | +743 | +57.1 |
| FOUR ROUNDS | 23 | 22 | 12 | 4.00 | +1026 | +85.5 |
| TIME ON OUR SIDE | 107 | 84 | 12 | 4.00 | +56 | +4.7 |
| QUARTER ODDS | 36 | 36 | 11 | 3.67 | +703 | +63.9 |
| OGRE LOADER SECOND SHOT | 10 | 10 | 10 | 3.33 | +224 | +22.4 |
| CHARGE LOSSES | 90 | 87 | 9 | 3.00 | +703 | +78.1 |
| ARTILLERY RE-ROLL WEIGHED | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| MOVE ORDER | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| PROMISE KNOWS THE FIGHT | 12 | 11 | 8 | 2.67 | -35 | -4.4 |
| FOLLOW UP WEIGHED | 7 | 7 | 7 | 2.33 | +1764 | +252.0 |
| LANE BY FIGURES | 7 | 7 | 7 | 2.33 | +265 | +37.9 |
| ONE PROMISE A TARGET | 7 | 7 | 7 | 2.33 | -918 | -131.1 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| FALLS SHORT | 66 | 53 | 6 | 2.00 | +58 | +9.7 |
| IDLE COST | 46 | 35 | 6 | 2.00 | +61 | +10.1 |
| MAX FOR POSITIONING | 33 | 31 | 6 | 2.00 | +70 | +11.7 |
| MEETS IN TIME | 17 | 17 | 6 | 2.00 | +411 | +68.5 |
| RANDOM MOVE BY FIGURES | 9 | 9 | 6 | 2.00 | +82 | +13.7 |
| REDIRECT FOR A FRIEND IN REACH | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SHOTS IN THE MOVE | 68 | 62 | 6 | 2.00 | +230 | +38.3 |
| STAY WORTH | 96 | 94 | 6 | 2.00 | +6 | +1.1 |
| TIED UP BY THE SUM | 6 | 6 | 6 | 2.00 | +252 | +42.1 |
| WHOLE FIGHT DANGER | 17 | 17 | 6 | 2.00 | +1053 | +175.5 |
| CHARGE NOW FIRST | 21 | 21 | 5 | 1.67 | -196 | -39.1 |
| MARCH BY THE SUM | 5 | 5 | 5 | 1.67 | +270 | +54.0 |
| SEARCH SPOT | 6 | 6 | 5 | 1.67 | +381 | +76.2 |
| AFTERMATH IN POINTS | 4 | 4 | 4 | 1.33 | +522 | +130.4 |
| COMBAT PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| MARCH OF THE TABLE | 4 | 4 | 4 | 1.33 | -325 | -81.2 |
| OWN CAST FIRST | 4 | 4 | 4 | 1.33 | -19 | -4.7 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +104 | +34.7 |
| CONTINUE AHEAD WEIGHED | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| COVER ONCE | 52 | 35 | 3 | 1.00 | +32 | +10.8 |
| HARD STAY DROPPED | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MANOEUVRE | 11 | 11 | 3 | 1.00 | +18 | +5.9 |
| ONE OBJECTIVE FORMULA | 18 | 15 | 3 | 1.00 | +222 | +74.1 |
| RISK BY ARC | 19 | 18 | 3 | 1.00 | +54 | +18.1 |
| WAR ENGINE JOBS | 3 | 3 | 3 | 1.00 | -10 | -3.4 |
| GOAL ON TIME | 2 | 2 | 2 | 0.67 | -3 | -1.4 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | -164 | -82.2 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +172 | +86.2 |
| MISSILES IN THE MOVE | 37 | 27 | 2 | 0.67 | +16 | +8.0 |
| NEXT OBJECTIVE NEARER | 2 | 2 | 2 | 0.67 | +19 | +9.3 |
| OPENS UP | 2 | 2 | 2 | 0.67 | +31 | +15.5 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +157 | +78.4 |
| SHOTS AFTER THE MOVES | 20 | 20 | 2 | 0.67 | +0 | +0.0 |
| SURE REACH TOGETHER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +57 | +28.6 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +46 | +46.2 |
| BOMBING RUN | 1 | 1 | 1 | 0.33 | +37 | +37.4 |
| CANNON PLANNED TARGET | 24 | 24 | 1 | 0.33 | +0 | +0.0 |
| CANNON SIGHT KEPT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 15 | 15 | 1 | 0.33 | +6 | +6.0 |
| FALL BACK GOOD ORDER | 16 | 15 | 1 | 0.33 | +6 | +6.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +2 | +2.4 |
| GUN MASK | 5 | 5 | 1 | 0.33 | +35 | +35.4 |
| HIS CHARGE DENIED | 2 | 2 | 1 | 0.33 | +61 | +61.0 |
| HIS TURN DENIED | 6 | 6 | 1 | 0.33 | +17 | +17.0 |
| HUNT IN PAIRS | 10 | 9 | 1 | 0.33 | +34 | +33.7 |
| LOST AFTER ESCAPE | 13 | 13 | 1 | 0.33 | +6 | +6.0 |
| MARCH CHECK | 2 | 2 | 1 | 0.33 | +2 | +1.7 |
| MISSILES NEXT TURN | 47 | 33 | 1 | 0.33 | +2 | +2.3 |
| NEARER NOT NEEDED | 22 | 21 | 1 | 0.33 | +50 | +49.5 |
| OVERRUNS AWAY | 4 | 4 | 1 | 0.33 | +45 | +45.2 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +54 | +54.4 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -73 | -73.1 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +5 | +5.0 |
| REFUSING RETIRES | 3 | 3 | 1 | 0.33 | -4 | -3.7 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +3 | +3.0 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +19 | +19.0 |
| SET UP BY THE SET | 11 | 11 | 1 | 0.33 | -2 | -1.6 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +2 | +1.7 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -78 | -78.4 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -73 | -73.1 |
| CASTS AFTER FRIENDS | 7 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 2 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 62 | 60 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 13 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EVASIVE BY THE ODDS | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 7 | 6 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 35 | not checked | - | - | - | - |
| FOOT FIRST | 79 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 19 | 16 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 16 | 16 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 2 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 11 | 8 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 59 | 58 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 44 | 44 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 39 | 37 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 22 | 22 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 2 | 2 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 55 | 52 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 7 | 7 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 2 | 2 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 74 | 72 | 0 | 0.00 | - | - |
| HONEST WORTH | 22 | 21 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 21 | 21 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 7 | 7 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 12 | 12 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 6 | not checked | - | - | - | - |
| NEAREST TO GOAL | 6 | 6 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 21 | 20 | 0 | 0.00 | - | - |
| NO LATE CUT | 11 | 11 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 3 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 33 | 18 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE ROUTE | 12 | 12 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 219 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 6 | 6 | 0 | 0.00 | - | - |
| REAL GROUND | 12 | 12 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 5 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 5 | 5 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 4 | 4 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 7 | 7 | 0 | 0.00 | - | - |
| RUN DOWN | 16 | 15 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 3 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 60 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 3 | not checked | - | - | - | - |
| SPELL WORTH | 33 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 5 | 5 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 33 | 28 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 19 | 18 | 0 | 0.00 | - | - |
| STANDS STILL | 202 | 194 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 4 | not checked | - | - | - | - |
| THE PROMISE ADDS | 4 | 4 | 0 | 0.00 | - | - |
| THE ROW IN ITS ORDER | 12 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 18 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 15 | not checked | - | - | - | - |
| THE TABLE BINDS | 213 | not checked | - | - | - | - |
| WAITS AGAIN | 8 | 8 | 0 | 0.00 | - | - |
| WHO FIGHTS | 4 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 6 | 6 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p91

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 4.33 | 1.33 | 106.6 |
| JOB FIRST | gate | 2.33 | 1.67 | 26.9 |
| PROMISE KNOWS THE FIGHT | rule | 2.67 | - | 4.4 |
| ARMY TABLE | rule | 1.00 | 1.33 | 57.2 |
| ONE PROMISE A TARGET | rule | 1.67 | 0.67 | 131.1 |
| CHARGE NOW FIRST | rule | 0.67 | 0.67 | 48.8 |
| MARCH OF THE TABLE | rule | 1.33 | - | 81.2 |
| OWN CAST FIRST | rule | 1.00 | 0.33 | 4.7 |
| WAR ENGINE JOBS | rule | 1.00 | - | 3.4 |
| GOAL ON TIME | rule | 0.67 | - | 1.4 |
| NO REASON | gate | 0.67 | - | 29.8 |
| RULE SWITCHED OFF | gate | - | 0.67 | 41.5 |
| DEPLOY BY FIGURES | rule | - | 0.33 | 5.9 |
| FIGHT ORDER BAND | gate | - | 0.33 | 2.6 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 2.5 |
| JOINT CHARGE NOW | rule | - | 0.33 | 173.6 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 73.1 |
| REFUSING RETIRES | rule | - | 0.33 | 3.7 |
| SET UP BY THE SET | rule | - | 0.33 | 1.6 |
| SUPPORT NARROWED | rule | 0.33 | - | 78.4 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 73.1 |

### Plans: gs3-83c8646-p91

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.3 | 50% | 455 | 104 | 23% |
| Mine | move | 22.3 | 94% | 1426 | 0 | 0% |
| Mine | shoot | 11.7 | 46% | 537 | 588 | 110% |
| Opponent | charge | 3.0 | 22% | 375 | 365 | 97% |
| Opponent | move | 28.7 | 94% | 2943 | 0 | 0% |
| Opponent | shoot | 4.0 | 42% | 196 | 115 | 59% |

### Battle groups: gs3-83c8646-p91

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 1.7 | 60% | 100% | 33% | 0% | 50% | 0% | 50% | 0% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p91

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 8 | 19 (8) | 19 | 0 | 24 | 12% | 1.9 | 0 (1) | 27 (5) | 11 (1) | 17 (6) | 45 (1) |
| Mine | Clean-up | 2 | 225 (2) | 0 | 225 | 47 | 0% | 3.0 | - | 225 (2) | - | 225 (2) | - |
| Mine | Fast Hammer | 2 | 12 (2) | 0 | 12 | 0 | 0% | 1.5 | - | 12 (2) | - | 12 (2) | - |
| Mine | Holder | 3 | 43 (3) | 43 | 0 | 0 | 67% | 3.0 | - | 0 (1) | 143 (1) | 62 (2) | - |
| Mine | Shooter | 3 | 76 (3) | 69 | 7 | 22 | 0% | 1.0 | - | 31 (1) | 89 (2) | 76 (3) | - |
| Mine | War machine | 6 | 0 (6) | 0 | 0 | 41 | 0% | 1.3 | - | 0 (2) | 0 (4) | - | 0 (6) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | - | - | - | - | - |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 75 | 20% | 3.0 | 0 (3) | - | 0 (2) | 0 (4) | 0 (1) |
| Opponent | Character | 6 | 42 (6) | 42 | 0 | 7 | 0% | 2.0 | - | 21 (3) | 60 (2) | 10 (3) | 75 (2) |
| Opponent | Clean-up | 6 | 49 (6) | 0 | 49 | 11 | 33% | 4.0 | 0 (1) | 62 (4) | 0 (1) | 29 (4) | 75 (2) |
| Opponent | Fast Hammer | 4 | 0 (4) | 0 | 0 | 100 | 50% | 2.5 | 0 (2) | 0 (2) | - | 0 (3) | 0 (1) |
| Opponent | Hammer | 3 | 58 (3) | 58 | 0 | 28 | 0% | 3.7 | 0 (2) | 131 (1) | - | 58 (3) | - |
| Opponent | Holder | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Shooter | 4 | 0 (4) | 0 | 0 | 35 | 0% | 2.0 | - | 0 (2) | 0 (2) | 0 (3) | 0 (1) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | 0 (1) | - |

### Charged fights: gs3-83c8646-p91

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 2 | 19 | 245 | 2.0 | 1.0 | 122 | 54 | +68 | 0 of 4 | 3 of 4 | - | +68 |
| Mine | High Elf Realms | 1 | 445 | 143 | 1.0 | 1.0 | 143 | 0 | +143 | 0 of 1 | 1 of 1 | - | +143 |
| **Mine** | all armies | 3 | 161 | 211 | 1.7 | 1.0 | 127 | 43 | +83 | 0 of 5 | 4 of 5 | - | +83 |
| Opponent | High Elf Realms | 1 | 0 | 0 | 3.0 | 1.0 | 0 | 0 | +0 | 3 of 3 | 2 of 3 | - | +0 |
| Opponent | Skaven | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 1 of 2 | 0 of 2 | - | +0 |
| Opponent | Vampire Counts | 1 | 0 | 727 | 5.0 | 1.2 | 145 | 12 | +133 | 3 of 5 | 4 of 5 | +0 | +167 |
| **Opponent** | all armies | 3 | 0 | 242 | 3.3 | 1.1 | 73 | 6 | +67 | 7 of 10 | 6 of 10 | +0 | +74 |

### Effective charges: gs3-83c8646-p91

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 4 | 0 | 0 | 0 | 1 (net -22) | 3 (net +98) | 0 | 0 | 0% (0 of 4) |
| Mine | High Elf Realms | 1 | 0 | 0 | 0 | 0 | 1 (net +143) | 0 | 0 | 0% (0 of 1) |
| Opponent | High Elf Realms | 3 | 0 | 1 (net +0) | 0 | 1 (net +0) | 0 | 1 (net +0) | 0 | 0% (0 of 3) |
| Opponent | Skaven | 2 | 2 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Vampire Counts | 5 | 1 (net +296) | 0 | 0 | 1 (net +0) | 0 | 2 (net +82) | 1 | 0% (0 of 4) |

### Charged fights, damage counted: gs3-83c8646-p91

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 1 | 217 | 192 | -22 | 195 | 217 | -22 | -10.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 316 | 66 | +110 | 125 | 36 | +88 | +28.0 |
| Mine | All fights | 5 | 296 | 92 | +83 | 139 | 72 | +66 | +22.4 |
| Opponent | Long shot (under 50%) | 3 | 232 | 303 | +99 | 99 | 18 | +81 | +34.9 |
| Opponent | 50-54% | 1 | 143 | 500 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 76-89% | 2 | 494 | 424 | +0 | 21 | 121 | -100 | -20.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 549 | 257 | +55 | 115 | 10 | +105 | +19.1 |
| Opponent | No odds | 1 | 329 | 171 | +206 | 382 | 74 | +308 | +93.7 |
| Opponent | All fights | 10 | 380 | 320 | +67 | 106 | 40 | +66 | +17.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p91 | move | 20 | 5 (25%) | 3 (15%) | 2 (10%) | 13 (65%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1126 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Opal Amulet | Opponent | L1314 |
| Periapt of Soul Exchange | Opponent | L1220 |
| Ring of Doom | Mine | L1126, L1220 |
| Ring of Jet | Mine | L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314 |

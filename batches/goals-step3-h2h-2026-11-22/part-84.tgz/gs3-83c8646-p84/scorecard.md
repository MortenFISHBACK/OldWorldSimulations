# Doctrine scorecard: gs3-83c8646-p84

### Scorecard: gs3-83c8646-p84

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2630 | 2 | 1 | Mine | - | - | 3 | 4 | 3 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 1 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 127 |
| L2832 | 6 | 1 | Opponent | no | 2 | 4 | 3 | 6 | 1 | 0 | 0 | 335 |
| L3133 | 1 | 1 | Mine | no | 7 | - | 0 | 3 | 2 | 0 | 0 | 340 |
| L3133 | 1 | 1 | Opponent | no | 0 | 5 | 2 | 3 | 0 | 0 | 0 | 406 |
| **Average** | | | Mine | 0% | 3.5 | 3.0 | 1.3 | 2.3 | 0.7 | 0.0 | 0.0 | 155.7 |
| **Average** | | | Opponent | 0% | 1.0 | 3.3 | 2.7 | 3.7 | 0.3 | 0.0 | 0.0 | 247.0 |

### KPIs: gs3-83c8646-p84

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 13) | 31% (5 of 16) | 17% (5 of 29) |
| Winner chose to follow up after the loser gave ground |  | 100% (3 of 3); on the table 100% | - | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 50% (1 of 2); on the table 100% | 50% (1 of 2); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (3 of 3); on the table 100% | 50% (1 of 2); on the table 100% | 80% (4 of 5); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 50% (12 of 24) | 67% (4 of 6) | 53% (16 of 30) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 60% (12 of 20) | 67% (4 of 6) | 62% (16 of 26) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 62% (5 of 8) | 67% (6 of 9) | 65% (11 of 17) |
| Points that never fought | lower | 50% (2728 of 5481) | 59% (3528 of 5999) | 54% (6256 of 11480) |
|   infantry points that never fought | lower | 92% (653 of 713) | 57% (603 of 1054) | 71% (1256 of 1767) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 59% (13 of 22) | 67% (16 of 24) | 63% (29 of 46) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 0.7 uses a game | 100% (2 of 2); 2.7 uses a game | 100% (3 of 3); 1.7 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 52% (2725 of 5235) | 61% (3340 of 5492) | 57% (6065 of 10727) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (25%) | 0.7 (100%) | 1.7 (36%) |
| MARCHED: its unit marched | 1.0 (25%) | 0.0 (0%) | 1.0 (21%) |
| CHARGED: its unit charged | 0.7 (17%) | 0.0 (0%) | 0.7 (14%) |
| IN COMBAT: engaged in combat | 1.0 (25%) | 0.0 (0%) | 1.0 (21%) |
| GONE: slain | 0.3 (8%) | 0.0 (0%) | 0.3 (7%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 2.3 | 2.3 | 0.0 | 5.3 | 1.3 | 0.3 |
| not cast | 5.7 | 1.3 | 2.0 | 4.7 | 0.7 | 3.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (9%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (25%) | 0.0 (0%) | 1.7 (36%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (21%) | 0.0 (0%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (14%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (6%) | 0.3 (25%) | 0.3 (17%) | 1.0 (21%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (7%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (100%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 5.3 (94%) | 0.7 (50%) | 1.7 (83%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.3 (91%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 50% (2 of 4) | 51% (21 of 41) | 51% (23 of 45) |
|   cavalry | 50% (2 of 4) | 67% (6 of 9) | 62% (8 of 13) |
|   character | - | 45% (9 of 20) | 45% (9 of 20) |
|   infantry | - | 50% (6 of 12) | 50% (6 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.3 (50%) | 1.3 (20%) | 1.7 (23%) |
| CHARGED: it charged | 0.0 (0%) | 2.3 (35%) | 2.3 (32%) |
| FLEEING: it fled or was fleeing | 0.3 (50%) | 0.0 (0%) | 0.3 (5%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (5%) | 0.3 (5%) |
| NO TARGET IN RANGE | 0.0 (0%) | 1.3 (20%) | 1.3 (18%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 1.3 (20%) | 1.3 (18%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.7 | 0.7 | 75% | 9.8 pts | 26 pts |
| character | 3.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 4.0 | 1.3 | 67% | 11.2 pts | 45 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.3 | 4.3 | 2.8 |
| Charges that made contact a game | 0.7 | 2.7 | 1.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.50 declared, 0.50 contact (2 units) | - | 1.50 declared, 0.50 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 3.00 declared, 3.00 contact (1 units) | 3.00 declared, 3.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.06 declared, 0.06 contact (18 units) | 0.43 declared, 0.22 contact (23 units) | 0.27 declared, 0.15 contact (41 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (6 of 9) | 0% (0 of 1) | 50% (1 of 2) | 58% (7 of 12) |
| Character in a unit | 67% (2 of 3) | 67% (2 of 3) | 100% (3 of 3) | 78% (7 of 9) |
| Character on its own | 100% (4 of 4) | - | 20% (1 of 5) | 56% (5 of 9) |
| Infantry | 33% (1 of 3) | 67% (2 of 3) | 0% (0 of 1) | 43% (3 of 7) |
| Monster | 80% (4 of 5) | 0% (0 of 1) | - | 67% (4 of 6) |
| Monstrous | 100% (2 of 2) | 100% (1 of 1) | - | 100% (3 of 3) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vampire Counts | 1 | - | 17% (2 of 12) | 37% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 4 | 80% (4 of 5); on the table 100% | 83% (10 of 12) | 50% | 61% (19 of 31) | 100% (1 of 1); 0.5 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
| Wood Elf Realms | 1 | - | 67% (4 of 6) | 90% | 80% (8 of 10) | 100% (2 of 2); 8.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p84, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 33% (2) | 100% (2) | 50% (4) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.33 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.33 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.33 | 0.00 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.33 | 0.00 | 0.33 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 1.00 | 0.00 | 1.00 |

### Quality by phase: gs3-83c8646-p84

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.0 | 1.0 |
| Strategy | Charge objectives carried out (made contact) | 50% (2 of 4) | 38% (3 of 8) |
| Strategy | Shoot objectives carried out (shot that target) | 0% (0 of 8) | 100% (3 of 3) |
| Strategy | Joined characters whose unit fought | 33% (1 of 3) | 0% (0 of 6) |
| Strategy | Lone characters that fought | 50% (3 of 6) | 100% (3 of 3) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 2.3 | 3.7 |
| Movement | Points that never moved of their own | 155.7 | 247.0 |
| Movement | Fights charged into per game | 0.7 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 2 | 2 of 5, net +360 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 2, net +0 | 0 of 5 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 2, net +0 | 2 of 5, net +85 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 2 | 0 of 5 |
| Shooting | Shots by shooting units (incl. breath weapons) | 0.7 | 9.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (1 of 2) | 18% (5 of 28) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 2.7 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 38% (3 of 8) | 0% (0 of 4) |
| Magic | Wounds caused by magic missiles | 4.7 | 3.0 |
| Magic | Wounds caused by other spells | 2.0 | - |
| Magic | Points destroyed by magic (all spells) | 111.3 | 134.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 0.0 / 0.3 / 0.0 | 0.7 / 1.3 / 0.0 / 1.3 |
| Combat | Points destroyed in combat | 142.7 | 418.0 |
| Combat | Points run down | 0.0 | 59.0 |
| Combat | Net points per charged fight, damage counted | +53 | +243 |
| Combat | Net per 100 charger points, damage counted | +19.6 | +56.8 |
| Combat | First round won (charged fights) | 100% | 83% |
| Combat | Net points per charged fight | +0 | +238 |
| Combat | Net points per supported fight / lone fight | - / +0 | +305 / +205 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 2 | 3 of 6 |
| Game | Points lost | 614.7 | 378.7 |
| Game | VP from objectives | 546.7 | 870.0 |
| Game | Lone holders (player turns) | 3.5 | 1.0 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -576 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 993
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: gs3-83c8646-p84

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 9.7 | +399.8 | 0.0 | 38.7 | 12.7 | +40.6 | 0.0 | 236.0 |
| BACKUP TARGETS | 0.3 | +0.3 | 0.0 | 0.0 | 0.3 | +3.9 | 0.0 | 0.0 |
| CAST JOB | 4.0 | +91.6 | 315.3 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 1.7 | +4.9 | 0.0 | 46.7 |
| CHALLENGE BY POINTS | 0.3 | +20.9 | 0.0 | 166.7 | - | - | - | - |
| CHARACTER GUNS | - | - | - | - | 6.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 8.7 | -1044.2 | 0.0 | 517.3 | 10.3 | -501.9 | 0.0 | 389.7 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 130.7 | 0.0 | 2.0 | +0.0 | 455.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 16.0 | +0.0 | 0.0 | 476.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | - | - | - | - | 0.7 | +0.0 | 13.3 | 56.7 |
| COVER ONCE | 5.0 | -484.8 | 0.0 | 220.0 | 6.0 | -242.6 | 0.0 | 46.3 |
| DEFENSIVE ARMY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 5.7 | +53.7 | 0.0 | 36.7 | 7.7 | +84.7 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.7 | -91.0 | 181.3 | 0.0 |
| EXACT ROUND | 0.7 | -0.3 | 56.0 | 166.7 | 1.7 | +1.3 | 260.0 | 0.0 |
| FACES THE THREAT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.0 | +1.6 | 88.7 | 166.7 | 1.7 | +0.1 | 385.0 | 0.0 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | 18.0 | +400.9 | 0.0 | 201.3 | - | - | - | - |
| FEATURE BUFFS | 2.7 | +131.9 | 0.0 | 0.0 | 1.7 | +15.2 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +0.9 | 32.7 | 0.0 | 1.0 | +17.1 | 203.3 | 0.0 |
| FIVE ACTION | 57.0 | +4365.1 | 404.0 | 894.0 | 90.7 | +4440.4 | 491.7 | 941.3 |
| FLANK NOT WEIGHED | 5.0 | +0.0 | 0.0 | 102.0 | 6.3 | +0.0 | 0.0 | 116.0 |
| FOLLOW UP WEIGHED | 0.7 | +49.3 | 0.0 | 0.0 | 0.3 | +306.1 | 0.0 | 0.0 |
| FOOT FIRST | 9.0 | +0.0 | 0.0 | 83.3 | - | - | - | - |
| FOUR ROUNDS | 1.3 | +37.5 | 88.7 | 166.7 | 3.3 | +610.4 | 491.7 | 0.0 |
| FREED FROM HIS FIGHT | 2.0 | +0.0 | 0.0 | 13.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -23.8 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 2.0 | -4.2 | 0.0 | 154.7 | - | - | - | - |
| GIVES UP | 0.3 | -2.5 | 23.3 | 166.7 | 0.3 | -8.1 | 0.0 | 0.0 |
| GOAL ROUTE | 0.7 | +108.1 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 4.0 | +446.5 | 0.0 | 0.0 | 4.7 | +260.8 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 45.0 |
| HE REFORMS ONCE FREED | 2.0 | +0.0 | 0.0 | 13.3 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 7.3 | +0.0 | 0.0 | 517.3 | 7.3 | +0.0 | 0.0 | 139.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.7 | +8.5 | 73.3 | 0.0 |
| HIS CHARGE LIST | 3.3 | +0.0 | 0.0 | 130.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.7 | +0.0 | 0.0 | 436.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.0 | -48.6 | 0.0 | 0.0 | 4.0 | -32.5 | 0.0 | 171.3 |
| HIS ONE QUARTER | 2.0 | +0.0 | 0.0 | 77.3 | 9.0 | +0.0 | 0.0 | 172.0 |
| HIS OWN BEST MOVE | 7.3 | +0.0 | 0.0 | 590.7 | 7.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 8.0 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 172.0 |
| HIS RANDOM MOVER COMES | - | - | - | - | 2.0 | +0.0 | 0.0 | 172.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 18.7 | +629.4 | 0.0 | 186.0 | 41.3 | +195.0 | 0.0 | 305.0 |
| HIS SHOTS BY HIS RUN | 20.3 | +520.3 | 0.0 | 614.0 | 25.7 | +145.1 | 0.0 | 636.3 |
| HIS TURN DENIED | - | - | - | - | 0.7 | +4.2 | 37.0 | 0.0 |
| HOLD ODDS | 16.0 | +0.0 | 0.0 | 0.0 | 22.0 | +0.0 | 0.0 | 264.7 |
| HOLDER ASSIGNMENT | 9.3 | +920.4 | 0.0 | 0.0 | 12.3 | +1208.2 | 0.0 | 178.7 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -44.6 | 88.7 | 166.7 | 2.3 | -127.1 | 418.3 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 1.3 | +88.9 | 0.0 | 0.0 |
| IDLE COST | 13.0 | -216.5 | 0.0 | 88.7 | - | - | - | - |
| JOINT CHARGE NOW | - | - | - | - | 0.3 | +4.3 | 36.7 | 0.0 |
| KEPT FROM ITS LAST STOP | 0.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +12.7 | 0.0 | 0.0 | 1.0 | +41.8 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.7 | +0.0 | 32.7 | 534.7 | 1.0 | +0.0 | 166.7 | 118.7 |
| LOST AFTER ESCAPE | 0.7 | +0.3 | 56.0 | 166.7 | 2.0 | -5.7 | 384.7 | 0.0 |
| LURE BY WHAT IT DRAWS | 0.7 | -39.3 | 0.0 | 0.0 | 0.7 | -37.2 | 0.0 | 46.7 |
| MANOEUVRE | 1.0 | +18.0 | 0.0 | 0.0 | 1.0 | -1.8 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +11.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.0 | +28.8 | 0.0 | 0.0 | 0.3 | +20.5 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +21.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | -14.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.3 | +57.6 | 0.0 | 0.0 | 1.3 | +79.0 | 0.0 | 0.0 |
| MEETS IN TIME | 3.3 | +215.2 | 0.0 | 0.0 | 3.0 | +308.9 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 5.3 | +77.4 | 0.0 | 0.0 | 3.3 | +56.5 | 0.0 | 86.0 |
| MISSILES NEXT TURN | 6.3 | +56.3 | 0.0 | 0.0 | 3.3 | +30.1 | 0.0 | 86.0 |
| MOVE ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 6.3 | +808.0 | 0.0 | 228.0 | 6.7 | +918.0 | 0.0 | 32.7 |
| NEARER NOT NEEDED | 5.0 | +195.9 | 0.0 | 181.3 | 9.3 | +453.4 | 0.0 | 26.7 |
| NEAREST TO GOAL | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 4.3 | +526.8 | 0.0 | 112.0 | 5.3 | +746.5 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.3 | -28.1 | 88.7 | 166.7 | 3.0 | -194.2 | 478.3 | 0.0 |
| NO LATE CUT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 1.0 | +0.0 | 0.0 | 13.3 | - | - | - | - |
| NOT WORTH A CAST | 1.3 | -0.8 | 0.0 | 0.0 | 3.0 | -5.6 | 0.0 | 0.0 |
| OFF BEST | 3.0 | -132.3 | 0.0 | 0.0 | 2.7 | -124.4 | 0.0 | 0.0 |
| ONE CHALLENGE TEST | - | - | - | - | 0.3 | -4.4 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.3 | -79.2 | 0.0 | 295.3 | 3.3 | -118.2 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | -1.3 | 36.7 | 0.0 |
| ONE OBJECTIVE FORMULA | 5.0 | +93.9 | 0.0 | 0.0 | 4.7 | -16.3 | 0.0 | 132.3 |
| ONE ROUTE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 1.0 | +30.3 | 56.0 | 166.7 | 0.3 | +30.0 | 37.0 | 0.0 |
| OVERRUNS AWAY | 0.3 | +1.5 | 32.7 | 0.0 | 0.7 | +0.8 | 218.3 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -9.1 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 29.3 | +102.3 | 197.7 | 1029.0 | 42.7 | +482.3 | 390.3 | 737.3 |
| PROMISE BELOW ZERO | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 9.7 | -327.3 | 0.0 | 0.0 | 7.7 | -86.6 | 0.0 | 32.7 |
| PROMISE KNOWS THE FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | -5.1 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 1.3 | -15.0 | 0.0 | 77.3 | - | - | - | - |
| QUARTER ODDS | 8.0 | +957.0 | 157.3 | 77.3 | 10.0 | +882.2 | 0.0 | 329.3 |
| RANDOM MOVE BY FIGURES | 2.7 | +15.7 | 0.0 | 56.7 | 3.0 | +10.5 | 0.0 | 56.7 |
| REAL GROUND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.3 | +53.0 | 0.0 | 0.0 | 1.0 | +92.1 | 0.0 | 23.3 |
| REDIRECT FOR A FRIEND IN REACH | 4.0 | +0.0 | 0.0 | 46.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | 0.3 | +0.0 | 0.0 | 166.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -8.6 | 0.0 | 0.0 | 3.3 | -174.7 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.7 | +19.3 | 0.0 | 0.0 | 0.3 | +1.5 | 0.0 | 0.0 |
| RISK BY ARC | 1.3 | +14.3 | 88.7 | 166.7 | 2.3 | +30.1 | 441.7 | 0.0 |
| ROUNDS AFTER TERROR | 1.0 | -34.1 | 56.0 | 166.7 | 1.0 | -49.5 | 218.3 | 0.0 |
| RUN DOWN | 1.3 | -10.8 | 88.7 | 166.7 | 0.7 | -56.8 | 37.0 | 0.0 |
| SAFER THAN THE JOB | 0.3 | +3.3 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | 0.3 | -23.8 | 0.0 | 13.3 | 1.0 | -46.3 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +1.2 | 0.0 | 0.0 | 0.3 | +9.4 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.7 | +73.5 | 13.3 | 0.0 |
| SET CREDITED ONCE | 0.7 | -14.2 | 0.0 | 0.0 | 1.3 | -59.2 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.0 | +46.1 | 0.0 | 0.0 | 2.0 | +254.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 4.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 23.3 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +8.9 | 0.0 | 0.0 | 0.7 | +18.9 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -0.6 | 32.7 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 12.0 | -98.3 | 0.0 | 224.7 | 12.0 | +180.6 | 0.0 | 375.0 |
| SHOTS AFTER THE MOVES | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 0.7 | +6.0 | 0.0 | 0.0 | 8.7 | +141.6 | 0.0 | 86.0 |
| SPELL WORTH | 2.0 | +13.9 | 0.0 | 0.0 | 1.0 | +5.7 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 7.3 | +0.0 | 0.0 | 200.0 | 4.0 | +0.0 | 0.0 | 125.0 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -1.3 | 37.0 | 0.0 |
| STANDS FOR A REASON | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| STANDS STILL | 12.7 | +0.0 | 315.3 | 13.3 | 49.3 | +0.0 | 0.0 | 408.0 |
| STAY WORTH | 2.7 | +70.6 | 65.3 | 0.0 | 4.7 | +40.2 | 0.0 | 164.7 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +4.7 | 181.3 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 6.3 | +1088.6 | 0.0 | 52.0 | 2.3 | +60.5 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.7 | +0.0 | 65.3 | 0.0 | 0.7 | +0.0 | 50.0 | 0.0 |
| SUPPORT WORKED OUT | 6.3 | +1088.6 | 0.0 | 52.0 | 2.3 | +60.5 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 1.0 | +16.7 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +30.0 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 38.7 | - | - | - | - |
| THE PROMISE ADDS | 0.3 | -12.2 | 0.0 | 0.0 | 0.3 | -27.2 | 0.0 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 4.3 | +0.0 | 36.7 | 38.7 | 2.0 | +0.0 | 0.0 | 46.3 |
| THE ROW KEEPS ITS WAY | 3.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 86.0 |
| THE STEP BACK IS MADE | 3.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 86.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 27.7 | +0.0 | 0.0 | 328.7 | 42.0 | +0.0 | 0.0 | 449.3 |
| TIED UP BY THE SUM | 1.0 | +146.2 | 56.0 | 166.7 | 1.3 | +154.6 | 107.0 | 0.0 |
| TIME ON OUR SIDE | - | - | - | - | 70.7 | +688.0 | 0.0 | 482.0 |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 32.7 |
| WHO FIGHTS | - | - | - | - | 0.3 | +0.6 | 36.7 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +5.0 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.0 | -805.5 | 0.0 | 362.7 | 3.7 | -435.1 | 0.0 | 172.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +17.3 | 36.7 | 0.0 |
| WOUNDS ON THE RANKS | 2.7 | +271.3 | 0.0 | 0.0 | 2.0 | +13.7 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p84

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 65 | 65 | 61 | 20.33 | +3893 | +63.8 |
| ARMY TABLE | 67 | 67 | 39 | 13.00 | +1422 | +36.5 |
| TIME ON OUR SIDE | 212 | 201 | 36 | 12.00 | +27 | +0.7 |
| HIS SHOT LIST | 180 | 177 | 30 | 10.00 | +217 | +7.2 |
| MOVE TO CHARGE COMPUTED | 39 | 33 | 24 | 8.00 | +2148 | +89.5 |
| HARD STAY DROPPED | 22 | 22 | 22 | 7.33 | +0 | +0.0 |
| DEPLOY BY FIGURES | 40 | 40 | 20 | 6.67 | +187 | +9.4 |
| PROMISE BY ITS OWN SUM | 52 | 52 | 19 | 6.33 | -1242 | -65.3 |
| NEXT CHARGE BY LIST | 29 | 25 | 18 | 6.00 | +1492 | +82.9 |
| FIVE ACTION | 443 | 427 | 17 | 5.67 | +1664 | +97.9 |
| OFF BEST | 17 | 17 | 17 | 5.67 | -770 | -45.3 |
| THE TABLE AGAIN | 36 | 36 | 17 | 5.67 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 138 | 134 | 11 | 3.67 | +80 | +7.3 |
| LEGAL CHARGES ONLY | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 17 | 17 | 11 | 3.67 | +79 | +7.2 |
| MEETS IN TIME | 19 | 19 | 9 | 3.00 | +312 | +34.6 |
| SUPPORT ADDS | 26 | 26 | 8 | 2.67 | +464 | +57.9 |
| SUPPORT WORKED OUT | 26 | 26 | 8 | 2.67 | +464 | +57.9 |
| FOUR ROUNDS | 14 | 12 | 7 | 2.33 | +900 | +128.6 |
| GOAL WALK | 26 | 26 | 7 | 2.33 | +348 | +49.8 |
| CAST JOB | 12 | 12 | 6 | 2.00 | +73 | +12.2 |
| CHARGE NOW FIRST | 12 | 12 | 6 | 2.00 | -326 | -54.4 |
| IDLE COST | 39 | 25 | 6 | 2.00 | +34 | +5.8 |
| MOVE ORDER | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| TIED UP BY THE SUM | 7 | 6 | 6 | 2.00 | +138 | +23.0 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| SHOT RISK POINTS | 72 | 70 | 5 | 1.67 | +83 | +16.5 |
| STAY WORTH | 22 | 18 | 5 | 1.67 | +162 | +32.4 |
| COVER ONCE | 33 | 25 | 4 | 1.33 | +146 | +36.6 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +164 | +40.9 |
| QUARTER ODDS | 54 | 53 | 4 | 1.33 | +567 | +141.8 |
| SHOOTS FROM THE BEST SPOT | 6 | 6 | 4 | 1.33 | +1 | +0.3 |
| SUPPORT NARROWED | 4 | 4 | 4 | 1.33 | -547 | -136.8 |
| FALLS SHORT | 54 | 41 | 3 | 1.00 | +82 | +27.2 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +1066 | +355.4 |
| MARCH CHECK | 4 | 4 | 3 | 1.00 | +83 | +27.6 |
| MAX FOR POSITIONING | 11 | 11 | 3 | 1.00 | +4 | +1.5 |
| ONE OBJECTIVE FORMULA | 29 | 25 | 3 | 1.00 | +152 | +50.5 |
| OPENS UP | 4 | 4 | 3 | 1.00 | +25 | +8.4 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +62 | +20.8 |
| SEARCH SPOT | 3 | 3 | 3 | 1.00 | +32 | +10.7 |
| SET UP BY THE SET | 9 | 9 | 3 | 1.00 | +503 | +167.8 |
| WOUNDS ON THE RANKS | 14 | 14 | 3 | 1.00 | +139 | +46.3 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FEATURE BUFFS | 13 | 13 | 2 | 0.67 | +94 | +47.2 |
| GOAL ROUTE | 2 | 2 | 2 | 0.67 | +324 | +162.2 |
| HONEST WORTH | 11 | 9 | 2 | 0.67 | +70 | +35.0 |
| MANOEUVRE | 6 | 6 | 2 | 0.67 | +54 | +27.0 |
| NEARER NOT NEEDED | 43 | 41 | 2 | 0.67 | +101 | +50.3 |
| PROMISE KNOWS THE FIGHT | 5 | 5 | 2 | 0.67 | -15 | -7.6 |
| REDIRECT COUNTER | 7 | 6 | 2 | 0.67 | +21 | +10.6 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +365 | +182.6 |
| RISK BY ARC | 11 | 10 | 2 | 0.67 | +21 | +10.3 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +221 | +110.3 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 19 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +63 | +62.8 |
| CHARGE LOSSES | 57 | 57 | 1 | 0.33 | +28 | +27.9 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS CHARGE DENIED | 2 | 2 | 1 | 0.33 | +5 | +5.2 |
| HUNT IN PAIRS | 4 | 4 | 1 | 0.33 | +3 | +3.3 |
| JOINT CHARGE NOW | 1 | 1 | 1 | 0.33 | +13 | +12.8 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +34 | +33.7 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -64 | -64.5 |
| MISSILES IN THE MOVE | 26 | 17 | 1 | 0.33 | +0 | +0.0 |
| MISSILES NEXT TURN | 29 | 18 | 1 | 0.33 | +0 | +0.0 |
| NO DOUBLE ROUNDS | 13 | 12 | 1 | 0.33 | +11 | +10.8 |
| ONE FIGHT FORMULA | 23 | 15 | 1 | 0.33 | +47 | +46.9 |
| OVERRUNS AWAY | 3 | 3 | 1 | 0.33 | +3 | +3.2 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -27 | -27.4 |
| RUN DOWN | 6 | 6 | 1 | 0.33 | +59 | +59.1 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.33 | +10 | +10.0 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +14 | +14.2 |
| SURE REACH TOGETHER | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +90 | +90.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +15 | +15.1 |
| WHOLE FIGHT GAIN | 1 | 1 | 1 | 0.33 | +5 | +5.2 |
| BACKUP TARGETS | 2 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 20 | 20 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 64 | 64 | 0 | 0.00 | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| EXACT ROUND | 7 | 7 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 8 | 7 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 4 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 34 | not checked | - | - | - | - |
| FOOT FIRST | 27 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 8 | 8 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 6 | 6 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 1 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 6 | 6 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 44 | 44 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 21 | 20 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 21 | 18 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 18 | 18 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 33 | 33 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 44 | 39 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 47 | 47 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 6 | 6 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HOLD ODDS | 114 | 113 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 10 | 9 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 8 | 7 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 1 | 0 | 0.00 | - | - |
| NEAREST TO GOAL | 4 | 4 | 0 | 0.00 | - | - |
| NO LATE CUT | 1 | not checked | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 3 | 3 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 13 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 1 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 216 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 4 | 4 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 12 | 11 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 6 | 6 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 6 | 6 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 16 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 3 | 3 | 0 | 0.00 | - | - |
| SHOTS IN THE MOVE | 28 | 23 | 0 | 0.00 | - | - |
| SPELL WORTH | 9 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 34 | 32 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 4 | 4 | 0 | 0.00 | - | - |
| STANDS STILL | 186 | 183 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 24 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 18 | not checked | - | - | - | - |
| THE TABLE BINDS | 209 | not checked | - | - | - | - |
| WAITS AGAIN | 6 | 5 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 17 | 17 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p84

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 4.33 | 2.00 | 65.3 |
| JOB FIRST | gate | 2.33 | 1.67 | 26.0 |
| HOLDER ASSIGNMENT | rule | 0.67 | 2.33 | 28.0 |
| ARMY TABLE | rule | 0.67 | 1.67 | 91.1 |
| CHARGE NOW FIRST | rule | 1.33 | 0.67 | 54.4 |
| SUPPORT NARROWED | rule | 0.67 | 0.67 | 136.8 |
| NO REASON | gate | 0.67 | - | 106.8 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.67 | 7.6 |
| RULE SWITCHED OFF | gate | - | 0.67 | 13.5 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.33 | 217.8 |
| MARCH OF THE TABLE | rule | 0.33 | - | 64.5 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 27.4 |

### Plans: gs3-83c8646-p84

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 50% | 83 | 56 | 68% |
| Mine | join | 1.7 | 100% | 195 | 0 | 0% |
| Mine | move | 24.3 | 90% | 1861 | 0 | 0% |
| Mine | shoot | 2.0 | 17% | 284 | 46 | 16% |
| Opponent | charge | 2.7 | 88% | 479 | 456 | 95% |
| Opponent | move | 38.0 | 99% | 1819 | 0 | 0% |
| Opponent | shoot | 1.0 | 67% | 18 | 26 | 147% |
| Opponent | support | 1.0 | 67% | 0 | 0 | - |

### Battle groups: gs3-83c8646-p84

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 1.0 | 33% | 100% | 100% | 0% | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p84

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 5 | 0 (5) | 0 | 0 | 41 | 40% | 4.0 | 0 (2) | 0 (1) | 0 (2) | 0 (4) | 0 (1) |
| Mine | Character | 7 | 9 (7) | 9 | 0 | 49 | 57% | 3.7 | 0 (3) | 11 (4) | - | 7 (6) | 14 (1) |
| Mine | Clean-up | 2 | 14 (2) | 0 | 14 | 100 | 0% | 1.5 | - | 27 (1) | 0 (1) | 14 (2) | - |
| Mine | Fast Hammer | 3 | 40 (3) | 0 | 40 | 52 | 33% | 3.5 | 0 (1) | 75 (2) | - | 40 (3) | - |
| Mine | Hammer | 4 | 33 (4) | 33 | 0 | 22 | 50% | 3.0 | 57 (3) | 0 (1) | - | 76 (2) | 0 (2) |
| Mine | Holder | 4 | 25 (4) | 0 | 25 | 0 | 100% | - | 0 (1) | 31 (3) | - | 28 (1) | 22 (3) |
| Mine | Wizard | 2 | 43 (2) | 43 | 0 | 0 | 0% | 2.0 | - | 43 (2) | - | 43 (2) | - |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 42 | 80% | 1.0 | 0 (3) | 0 (1) | 0 (1) | 0 (4) | 0 (1) |
| Opponent | Character | 8 | 59 (8) | 59 | 0 | 0 | 25% | 1.7 | 57 (2) | 62 (4) | 56 (2) | 52 (6) | 80 (2) |
| Opponent | Clean-up | 4 | 49 (4) | 0 | 49 | 28 | 75% | 1.0 | - | 63 (3) | 0 (1) | 0 (2) | 88 (2) |
| Opponent | Fast Hammer | 6 | 55 (6) | 23 | 33 | 11 | 67% | 2.5 | 98 (3) | 0 (2) | 0 (1) | 70 (4) | 0 (2) |
| Opponent | Hammer | 5 | 125 (5) | 0 | 125 | 21 | 60% | 3.5 | - | 125 (5) | - | 174 (4) | 0 (1) |
| Opponent | Holder | 2 | 0 (2) | 0 | 0 | 100 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Shooter | 2 | 61 (2) | 0 | 61 | 111 | 0% | 2.0 | 0 (1) | 130 (1) | - | 61 (2) | - |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |

### Charged fights: gs3-83c8646-p84

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 1 | 98 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 0 of 2 | 2 of 2 | - | +0 |
| Mine | Warriors of Chaos | 2 | 118 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 111 | 0 | 0.7 | 1.0 | 0 | 0 | +0 | 0 of 2 | 2 of 2 | - | +0 |
| Opponent | Warriors of Chaos | 2 | 0 | 716 | 3.0 | 1.3 | 238 | 0 | +238 | 3 of 6 | 5 of 6 | +305 | +205 |
| Opponent | Wood Elf Realms | 1 | 402 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 134 | 477 | 2.0 | 1.3 | 238 | 0 | +238 | 3 of 6 | 5 of 6 | +305 | +205 |

### Effective charges: gs3-83c8646-p84

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 2 | 0 | 0 | 1 (net +0) | 0 | 1 (net +0) | 0 | 0 | 50% (1 of 2) |
| Opponent | Warriors of Chaos | 6 | 2 (net +360) | 0 | 0 | 1 (net +500) | 2 (net +85) | 0 | 1 | 0% (0 of 5) |

### Charged fights, damage counted: gs3-83c8646-p84

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 45 | 98 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 499 | 98 | +0 | 106 | 0 | +106 | +21.3 |
| Mine | All fights | 2 | 272 | 98 | +0 | 53 | 0 | +53 | +19.6 |
| Opponent | Long shot (under 50%) | 2 | 494 | 426 | +360 | 377 | 0 | +377 | +76.3 |
| Opponent | 76-89% | 1 | 652 | 500 | +500 | 500 | 0 | +500 | +76.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 320 | 85 | +85 | 85 | 4 | +82 | +25.5 |
| Opponent | No odds | 1 | 285 | 40 | +40 | 40 | 0 | +40 | +14.0 |
| Opponent | All fights | 6 | 428 | 260 | +238 | 244 | 1 | +243 | +56.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p84 | move | 18 | 3 (17%) | 3 (17%) | 2 (11%) | 13 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2630 |
| Horn of the Wild Hunt | Opponent | L3133 |
| Ring of Doom | Mine | L3133 |
| Ring of Doom | Opponent | L3133 |

# Doctrine scorecard: gs3-83c8646-p3

### Scorecard: gs3-83c8646-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0405 | 3 | 1 | Mine | no | 6 | 2 | 2 | 4 | 0 | 0 | 0 | 139 |
| L0405 | 3 | 1 | Opponent | no | 6 | - | 0 | 2 | 0 | 0 | 0 | 1381 |
| L0421 | 1 | 1 | Mine | no | 3 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 0 | 6 | 0 | 0 | 0 | 210 |
| L0508 | 4 | 1 | Mine | no | 7 | - | 0 | 2 | 0 | 0 | 0 | 380 |
| L0508 | 4 | 1 | Opponent | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 560 |
| **Average** | | | Mine | 0% | 5.3 | 2.5 | 1.3 | 2.0 | 0.0 | 0.0 | 0.0 | 173.0 |
| **Average** | | | Opponent | 0% | 2.0 | - | 0.0 | 3.7 | 0.0 | 0.0 | 0.0 | 717.0 |

### KPIs: gs3-83c8646-p3

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 11) | 62% (5 of 8) | 26% (5 of 19) |
| Winner chose to follow up after the loser gave ground |  | 33% (1 of 3); on the table 100% | 50% (1 of 2); on the table 50% | 40% (2 of 5); on the table 80% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 100% | 0% (0 of 2); on the table 50% |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 40% (2 of 5); on the table 80% | 50% (2 of 4); on the table 75% | 44% (4 of 9); on the table 78% |
| Magic missiles tried each own turn | 50%+ | 17% (2 of 12) | 17% (1 of 6) | 17% (3 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 18% (2 of 11) | 33% (1 of 3) | 21% (3 of 14) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 40% (4 of 10) | 40% (4 of 10) |
| Points that never fought | lower | 69% (4109 of 5998) | 79% (4742 of 5999) | 74% (8851 of 11997) |
|   infantry points that never fought | lower | 78% (1115 of 1424) | 86% (1464 of 1703) | 82% (2579 of 3127) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% (14 of 23) | 69% (18 of 26) | 65% (32 of 49) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (1 of 1); 0.7 uses a game | 100% (1 of 1); 0.3 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 54% (2754 of 5120) | 65% (3058 of 4677) | 59% (5812 of 9797) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.3 (70%) | 0.0 (0%) | 2.3 (47%) |
| MARCHED: its unit marched | 0.7 (20%) | 0.7 (40%) | 1.3 (27%) |
| IN COMBAT: engaged in combat | 0.3 (10%) | 0.3 (20%) | 0.7 (13%) |
| GONE: slain | 0.0 (0%) | 0.7 (40%) | 0.7 (13%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.0 | 0.3 | 1.0 | 1.7 | 1.0 |
| not cast | 3.0 | 3.7 | 5.0 | 2.3 | 11.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.0 (82%) | 2.3 (47%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.3 (27%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (9%) | 0.7 (13%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.7 (22%) | 0.0 (0%) | 0.7 (13%) | 0.0 (0%) | 1.7 (15%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (100%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (78%) | 0.3 (9%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 9.0 (82%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.3 a game | 0.0 a game | 0.2 a game |
| stood (cast and not dispelled) | 100% (1 of 1) | - | 100% (1 of 1) |
| the unit moved after it | 0% (0 of 1) | - | 0% (0 of 1) |
| it charged on its next turn | 0% (0 of 1) | - | 0% (0 of 1) |
| the enemy charged it first | 0% (0 of 1) | - | 0% (0 of 1) |
| it fought by the end of its next turn | 0% (0 of 1) | - | 0% (0 of 1) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 1) | - | 0% (0 of 1) |
| none of these (no charge, no fight, no charge escaped) | 100% (1 of 1) | - | 100% (1 of 1) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 55% (46 of 83) | 70% (74 of 105) | 64% (120 of 188) |
|   cavalry | 42% (5 of 12) | 0% (0 of 7) | 26% (5 of 19) |
|   character | 50% (5 of 10) | 76% (19 of 25) | 69% (24 of 35) |
|   chariot | 52% (12 of 23) | 38% (5 of 13) | 47% (17 of 36) |
|   infantry | 17% (2 of 12) | 67% (14 of 21) | 48% (16 of 33) |
|   war machine | 85% (22 of 26) | 92% (36 of 39) | 89% (58 of 65) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (19%) | 1.7 (16%) | 4.0 (18%) |
| CHARGED: it charged | 0.7 (5%) | 0.0 (0%) | 0.7 (3%) |
| FLEEING: it fled or was fleeing | 0.7 (5%) | 0.0 (0%) | 0.7 (3%) |
| NO TARGET IN RANGE | 5.3 (43%) | 5.0 (48%) | 10.3 (46%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 0.0 (0%) | 0.3 (1%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 3.0 (24%) | 2.7 (26%) | 5.7 (25%) |
| OTHER BAR | 0.0 (0%) | 1.0 (10%) | 1.0 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 1.7 | 0.7 | 80% | 1.8 pts | 3 pts |
| character | 8.7 | 5.0 | 65% | 15.9 pts | 138 pts |
| chariot | 5.7 | 9.3 | 29% | 13.6 pts | 77 pts |
| infantry | 8.0 | 4.3 | 58% | 17.6 pts | 141 pts |
| war machine | 19.3 | 18.0 | 57% | 24.1 pts | 466 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.3 | 0.0 | 1.2 |
| Charges that made contact a game | 2.3 | 0.0 | 1.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.50 contact (2 units) | 0.00 declared, 0.00 contact (1 units) | 0.33 declared, 0.33 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.27 declared, 0.27 contact (22 units) | 0.00 declared, 0.00 contact (22 units) | 0.14 declared, 0.14 contact (44 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 33% (1 of 3) | 100% (1 of 1) | - | 50% (2 of 4) |
| Character in a unit | 100% (9 of 9) | 50% (1 of 2) | - | 91% (10 of 11) |
| Character on its own | 67% (2 of 3) | 0% (0 of 2) | 67% (2 of 3) | 50% (4 of 8) |
| Chariot | 50% (1 of 2) | 80% (4 of 5) | - | 71% (5 of 7) |
| Infantry | 75% (6 of 8) | 40% (2 of 5) | 0% (0 of 1) | 57% (8 of 14) |
| Monster | - | 0% (0 of 1) | - | 0% (0 of 1) |
| War Machines | 75% (3 of 4) | - | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 2 | 40% (2 of 5); on the table 80% | 17% (2 of 12) | 53% | 56% (9 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Dwarfen Mountain Holds | 2 | 67% (2 of 3); on the table 67% | - | 88% | 71% (10 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | - | - | 100% | 70% (7 of 10) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 0% (0 of 1); on the table 100% | 17% (1 of 6) | 60% | 67% (6 of 9) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p3, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | - | 75% (3) | 75% (3) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: gs3-83c8646-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 57% (4 of 7) | - |
| Strategy | Shoot objectives carried out (shot that target) | 53% (18 of 34) | 82% (37 of 45) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 5) | 11% (1 of 9) |
| Strategy | Lone characters that fought | 50% (3 of 6) | 33% (2 of 6) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.0 | 3.7 |
| Movement | Points that never moved of their own | 173.0 | 717.0 |
| Movement | Fights charged into per game | 2.0 | 0.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 6 | - |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 6, net +0 | - |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 6, net +145 | - |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 6, net +540 | - |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.0 | 13.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (12 of 24) | 87% (34 of 39) |
| Shooting | Points destroyed by shooting units | 89.0 | 46.3 |
| Shooting | War machine shots | 7.3 | 12.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 23% (5 of 22) | 44% (16 of 36) |
| Shooting | Points destroyed by war machines | 176.0 | 125.0 |
| Magic | Wounds caused by magic missiles | - | 0.3 |
| Magic | Wounds caused by other spells | - | 1.0 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 1.7 | 1.3 / 0.0 / 0.7 / 0.0 |
| Combat | Points destroyed in combat | 274.3 | 21.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +59 | - |
| Combat | Net per 100 charger points, damage counted | +17.4 | - |
| Combat | First round won (charged fights) | 50% | - |
| Combat | Net points per charged fight | +137 | - |
| Combat | Net points per supported fight / lone fight | +0 / +165 | - / - |
| Combat | Charged fights on a top-3 enemy unit | 5 of 6 | - |
| Game | Points lost | 256.3 | 699.3 |
| Game | VP from objectives | 973.3 | 843.3 |
| Game | Lone holders (player turns) | 5.3 | 2.0 |

- Mine won / drew / lost: 3 / 0 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +550 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 956
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.7 | +21.9 | 0.0 | 0.0 | 0.7 | +233.0 | 0.0 | 0.0 |
| ARMY TABLE | 16.0 | +716.8 | 0.0 | 196.0 | 8.3 | +95.1 | 0.0 | 183.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 43.3 |
| ASSAILMENT BY POINTS | - | - | - | - | 0.7 | +3.3 | 0.0 | 360.0 |
| BLOWS WHERE AIMED | 0.3 | -57.7 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 1.7 | +0.0 | 233.3 | 31.7 | 0.3 | +0.0 | 21.7 | 0.0 |
| CANNON PLANNED TARGET | 6.7 | +26.8 | 565.3 | 95.0 | 12.0 | +362.7 | 525.0 | 190.0 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 0.7 | +8.9 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 180.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.3 | +10.2 | 0.0 | 30.3 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 3.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 20.3 | -906.8 | 0.0 | 206.7 | 8.7 | -571.5 | 0.0 | 314.7 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 180.0 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 11.0 | +0.0 | 0.0 | 43.3 | 4.0 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.3 | +11.5 | 46.3 | 0.0 | - | - | - | - |
| COVER ONCE | 2.0 | -56.8 | 0.0 | 31.7 | 3.3 | -167.0 | 0.0 | 180.0 |
| DEFENSIVE ARMY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | 0.3 | -0.3 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.7 | +40.3 | 0.0 | 0.0 | 9.0 | -53.5 | 0.0 | 135.0 |
| DUEL STOPS AT THE KILL | 0.7 | -45.0 | 0.0 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 1.0 | +11.5 | 228.3 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.3 | +0.0 | 180.0 | 0.0 | - | - | - | - |
| FALLS SHORT | 8.0 | +24.3 | 0.0 | 92.7 | 9.3 | +121.4 | 0.0 | 201.7 |
| FEATURE BUFFS | - | - | - | - | 2.0 | +13.4 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| FIRE IN ORDER | 1.3 | +0.0 | 41.7 | 31.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 91.7 | +5874.4 | 1628.3 | 682.7 | 87.0 | +4260.0 | 1670.0 | 1302.0 |
| FLANK NOT WEIGHED | 1.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 201.7 |
| FOLLOW UP WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 2.3 | +419.8 | 228.3 | 0.0 | - | - | - | - |
| FREED FROM HIS FIGHT | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| FRIEND CHARGES FIRST | 0.3 | -29.1 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 1.3 | -5.8 | 0.0 | 103.3 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.3 | -1.4 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 13.3 | +1955.9 | 0.0 | 43.3 | 3.0 | +87.8 | 0.0 | 0.0 |
| GUN FIGURES | 4.0 | +40.5 | 21.7 | 103.3 | 2.3 | +0.9 | 0.0 | 21.7 |
| HARD STAY DROPPED | 2.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 3.7 | +0.0 | 0.0 | 103.3 | 4.0 | +0.0 | 0.0 | 180.0 |
| HIS CHARGE LIST | 0.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 43.3 |
| HIS LEGAL MOVES | 4.3 | +0.0 | 0.0 | 103.3 | - | - | - | - |
| HIS MOVE AND SHOT | 1.7 | -26.8 | 0.0 | 0.0 | 2.7 | -50.0 | 0.0 | 36.7 |
| HIS ONE QUARTER | 4.7 | +0.0 | 0.0 | 103.3 | 5.0 | +0.0 | 0.0 | 48.3 |
| HIS OWN BEST MOVE | 4.3 | +0.0 | 0.0 | 103.3 | - | - | - | - |
| HIS RANDOM MOVE | 3.7 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS RANDOM MOVER COMES | 1.3 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 46.0 | +2452.6 | 0.0 | 406.0 | 34.3 | +1280.8 | 0.0 | 638.7 |
| HIS SHOTS BY HIS RUN | 34.7 | +997.3 | 0.0 | 386.0 | 25.0 | +443.0 | 0.0 | 528.7 |
| HIS TURN DENIED | 0.3 | +8.4 | 0.0 | 0.0 | - | - | - | - |
| HOLD ODDS | 13.0 | +0.0 | 0.0 | 0.0 | 16.0 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 9.0 | +897.7 | 0.0 | 0.0 | 9.7 | +900.4 | 0.0 | 67.3 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.0 | -88.3 | 228.3 | 0.0 | - | - | - | - |
| HUNT IN PAIRS | 0.7 | +109.5 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | 7.7 | -140.9 | 0.0 | 68.0 | 8.7 | -105.8 | 0.0 | 262.0 |
| JOINT CHARGE NOW | 1.3 | -40.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +36.6 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 2.0 | +0.0 | 0.0 | 21.7 | 0.3 | +0.0 | 0.0 | 180.0 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.7 | +63.4 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 1.3 | -2.5 | 0.0 | 0.0 | - | - | - | - |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.3 | -22.6 | 0.0 | 18.3 |
| MANOEUVRE | 1.7 | +1.5 | 0.0 | 0.0 | 1.7 | +3.1 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +1.0 | 0.0 | 0.0 | 0.3 | +49.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +17.6 | 0.0 | 0.0 | 0.3 | +24.1 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.7 | -37.4 | 0.0 | 0.0 | 0.3 | -17.6 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.7 | +15.7 | 0.0 | 0.0 | 0.3 | +0.9 | 0.0 | 0.0 |
| MEETS IN TIME | 2.7 | +300.6 | 0.0 | 0.0 | 3.7 | +178.8 | 0.0 | 41.7 |
| MISSILES IN THE MOVE | 1.7 | +16.2 | 0.0 | 0.0 | 1.3 | +26.2 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 3.3 | +34.9 | 0.0 | 0.0 | 2.3 | +15.7 | 0.0 | 180.0 |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 1.3 | +57.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 3.3 | -180.7 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.0 | +130.0 | 0.0 | 103.3 | - | - | - | - |
| NEARER NOT NEEDED | 5.3 | +217.4 | 0.0 | 0.0 | 6.7 | +279.6 | 0.0 | 0.0 |
| NEAREST TO GOAL | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 3.0 | +218.4 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 1.7 | -109.7 | 228.3 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 0.3 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 5.7 | -142.1 | 0.0 | 238.3 | 3.0 | -76.6 | 0.0 | 41.7 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.3 | -85.9 | 0.0 | 0.0 | - | - | - | - |
| ONE JOINT FIGURE | 1.0 | +384.2 | 0.0 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 1.7 | +26.7 | 0.0 | 0.0 | 4.7 | +72.9 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.3 | -10.0 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.7 | +2.8 | 0.0 | 0.0 | - | - | - | - |
| PERIAPT WORTH | - | - | - | - | 0.3 | +18.0 | 0.0 | 180.0 |
| PIVOT GUARDS FLANK | 0.3 | -1.8 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 41.0 | +749.2 | 455.0 | 423.0 | 40.7 | +729.4 | 446.0 | 904.7 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 4.0 | -137.3 | 0.0 | 0.0 | 2.7 | -82.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.0 | -1.3 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 0.7 | -2.3 | 0.0 | 103.3 | - | - | - | - |
| QUARTER ODDS | 24.3 | +2313.1 | 263.0 | 270.0 | 23.3 | +2063.0 | 1033.3 | 350.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.3 | +16.5 | 0.0 | 145.0 |
| REAL GROUND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.3 | +36.3 | 0.0 | 21.7 | 1.3 | +4.4 | 0.0 | 40.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 0.7 | +0.0 | 0.0 | 18.3 |
| RESERVE FALL BACK | 0.7 | +3.6 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.0 | -108.6 | 180.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | 0.7 | -16.3 | 0.0 | 0.0 | - | - | - | - |
| RUN DOWN | 1.0 | -4.9 | 0.0 | 0.0 | - | - | - | - |
| SAME CHARGE LATER | 0.3 | -5.8 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | -166.9 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 3.0 | -190.2 | 0.0 | 206.7 | - | - | - | - |
| SET UP BY THE SET | 3.3 | +251.3 | 0.0 | 206.7 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | 0.7 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 10.0 | +0.0 | 0.0 | 95.0 | 15.0 | +0.0 | 0.0 | 208.3 |
| SHOOTS FROM THE BEST SPOT | 3.7 | +51.3 | 0.0 | 0.0 | - | - | - | - |
| SHORT GUN FORWARD | - | - | - | - | 0.3 | +0.0 | 0.0 | 45.0 |
| SHOT OR CHARGE | 0.7 | -12.5 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 31.3 | +306.6 | 0.0 | 356.7 | 19.3 | +124.0 | 0.0 | 693.7 |
| SHOTS AFTER THE MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.7 | +376.7 | 0.0 | 230.0 | 21.3 | +684.2 | 0.0 | 211.7 |
| SPELL WORTH | - | - | - | - | 3.0 | +66.9 | 360.0 | 360.0 |
| SPOT AS THE GAME MOVES | 7.3 | +0.0 | 0.0 | 103.3 | 4.3 | +0.0 | 0.0 | 180.0 |
| STANDS FOR A REASON | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 180.0 |
| STANDS STILL | 48.0 | +0.0 | 1400.0 | 492.7 | 54.3 | +0.0 | 1670.0 | 883.0 |
| STAY WORTH | 27.7 | +230.1 | 964.0 | 325.0 | 39.7 | +73.3 | 843.3 | 744.0 |
| STRIKE BY THE ODDS | 0.7 | -54.6 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 48.3 |
| SUPPORT ADDS | - | - | - | - | 3.3 | +192.9 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | - | - | - | - | 3.3 | +192.9 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 1.3 | +36.0 | 0.0 | 103.3 | - | - | - | - |
| SWIFTSTRIDE BY POINTS | 0.3 | +3.5 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 4.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 4.7 | +0.0 | 0.0 | 21.7 | 4.0 | +0.0 | 0.0 | 58.3 |
| THE STEP BACK IS MADE | 3.0 | +0.0 | 0.0 | 21.7 | 3.0 | +0.0 | 0.0 | 36.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 43.0 | +0.0 | 0.0 | 309.7 | 40.7 | +0.0 | 0.0 | 520.3 |
| TIME ON OUR SIDE | 22.7 | +320.6 | 269.3 | 86.7 | 17.3 | +207.0 | 0.0 | 132.3 |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -20.0 | 0.0 | 67.3 |
| WAR ENGINE CHARGES | 0.3 | +9.8 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | 0.7 | +38.6 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.3 | -2.1 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 1.3 | -68.3 | 0.0 | 0.0 | 2.3 | -372.8 | 0.0 | 180.0 |
| WHOLE FIGHT GAIN | 1.0 | +168.4 | 0.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 2.7 | +185.7 | 0.0 | 0.0 | 2.3 | +43.3 | 0.0 | 134.7 |

### Rule changes: gs3-83c8646-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 241 | 225 | 59 | 19.67 | +582 | +9.9 |
| ARMY TABLE | 73 | 73 | 58 | 19.33 | +2501 | +43.1 |
| HOLDER ASSIGNMENT | 56 | 56 | 52 | 17.33 | +2746 | +52.8 |
| HIS SHOTS BY HIS RUN | 179 | 168 | 42 | 14.00 | +469 | +11.2 |
| DEPLOY BY FIGURES | 53 | 53 | 38 | 12.67 | +613 | +16.1 |
| SHOT RISK POINTS | 152 | 139 | 30 | 10.00 | +722 | +24.1 |
| OFF BEST | 26 | 26 | 26 | 8.67 | -656 | -25.2 |
| GOAL WALK | 49 | 44 | 23 | 7.67 | +2594 | +112.8 |
| TIME ON OUR SIDE | 120 | 99 | 16 | 5.33 | +58 | +3.6 |
| THE TABLE AGAIN | 36 | 36 | 13 | 4.33 | +0 | +0.0 |
| FIVE ACTION | 536 | 520 | 12 | 4.00 | +487 | +40.6 |
| IDLE COST | 49 | 41 | 12 | 4.00 | +74 | +6.1 |
| HARD STAY DROPPED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| QUARTER ODDS | 143 | 137 | 10 | 3.33 | +694 | +69.4 |
| ADVANCE LANE KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| MOVE ORDER | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| CHARGE LOSSES | 87 | 79 | 8 | 2.67 | +462 | +57.8 |
| LEGAL CHARGES ONLY | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 20 | 20 | 7 | 2.33 | -658 | -94.0 |
| SHOOTS FROM THE BEST SPOT | 11 | 11 | 6 | 2.00 | +57 | +9.5 |
| STAY WORTH | 202 | 176 | 6 | 2.00 | +154 | +25.6 |
| CANNON PLANNED TARGET | 56 | 56 | 5 | 1.67 | +0 | +0.0 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| FIRE IN ORDER | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| FOUR ROUNDS | 7 | 7 | 5 | 1.67 | +290 | +58.0 |
| MEETS IN TIME | 19 | 19 | 5 | 1.67 | +199 | +39.8 |
| SET UP BY THE SET | 10 | 8 | 5 | 1.67 | +378 | +75.6 |
| SHOTS IN THE MOVE | 114 | 76 | 5 | 1.67 | +87 | +17.4 |
| AFTERMATH IN POINTS | 4 | 4 | 4 | 1.33 | +765 | +191.2 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | -120 | -30.0 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +110 | +27.4 |
| NEXT CHARGE BY LIST | 9 | 9 | 4 | 1.33 | +125 | +31.2 |
| RANDOM MOVE BY FIGURES | 10 | 10 | 4 | 1.33 | +50 | +12.4 |
| SHOOTERS IN TWO RANKS | 4 | 4 | 4 | 1.33 | +8 | +2.0 |
| STRIKE BY THE ODDS | 5 | 5 | 4 | 1.33 | +9 | +2.3 |
| CHAFF IN THE MOVE | 4 | 4 | 3 | 1.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 6 | 5 | 3 | 1.00 | +108 | +35.8 |
| ONE JOINT FIGURE | 3 | 3 | 3 | 1.00 | +120 | +40.2 |
| STUCK PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 3 | 3 | 3 | 1.00 | +120 | +40.2 |
| ASSAILMENT BY POINTS | 2 | 2 | 2 | 0.67 | +10 | +4.9 |
| CHARGE NOW FIRST | 6 | 6 | 2 | 0.67 | -30 | -15.2 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| COVER ONCE | 16 | 13 | 2 | 0.67 | +35 | +17.7 |
| FALLS SHORT | 52 | 48 | 2 | 0.67 | +22 | +10.8 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +190 | +95.2 |
| MANOEUVRE | 10 | 10 | 2 | 0.67 | +14 | +6.9 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +150 | +75.0 |
| MAX FOR POSITIONING | 6 | 6 | 2 | 0.67 | +3 | +1.5 |
| REDIRECT FOR A FRIEND IN REACH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +11 | +5.3 |
| SUPPORT ADDS | 10 | 6 | 2 | 0.67 | +75 | +37.3 |
| SUPPORT NARROWED | 2 | 2 | 2 | 0.67 | -24 | -11.9 |
| SUPPORT WORKED OUT | 10 | 6 | 2 | 0.67 | +75 | +37.3 |
| SURE REACH TOGETHER | 4 | 2 | 2 | 0.67 | +41 | +20.7 |
| WHAT THE JOINER ADDS | 2 | 2 | 2 | 0.67 | +186 | +93.0 |
| WOUNDS ON THE RANKS | 15 | 14 | 2 | 0.67 | +39 | +19.3 |
| CAST JOB | 3 | 3 | 1 | 0.33 | +1 | +0.9 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | -4 | -4.3 |
| MARCH CHECK | 2 | 2 | 1 | 0.33 | +53 | +52.9 |
| MISSILES IN THE MOVE | 9 | 7 | 1 | 0.33 | +0 | +0.3 |
| ONE OBJECTIVE FORMULA | 19 | 11 | 1 | 0.33 | +28 | +28.1 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -30 | -30.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +54 | +54.0 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -5 | -5.4 |
| PROMISE KNOWS THE FIGHT | 3 | 3 | 1 | 0.33 | -4 | -4.0 |
| REDIRECT COUNTER | 5 | 3 | 1 | 0.33 | +56 | +56.4 |
| SET CREDITED ONCE | 9 | 7 | 1 | 0.33 | +0 | +0.2 |
| SHORT GUN FORWARD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +10 | +10.4 |
| THE ROW IN ITS ORDER | 21 | 1 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -60 | -60.0 |
| WAR ENGINE JOBS | 3 | 3 | 1 | 0.33 | -130 | -129.6 |
| WHOLE FIGHT DANGER | 11 | 11 | 1 | 0.33 | +3 | +3.2 |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 6 | 6 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 27 | 27 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 45 | 44 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 1 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| EVASIVE BY THE ODDS | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 3 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 4 | 4 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 6 | 6 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 13 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 8 | 8 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 4 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 19 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 8 | 8 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 23 | 22 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 15 | 11 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 13 | 12 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 13 | 13 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 29 | 24 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 13 | 12 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 11 | 11 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 4 | 4 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HOLD ODDS | 87 | 86 | 0 | 0.00 | - | - |
| HONEST WORTH | 6 | 6 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 2 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 4 | 3 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 4 | 4 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 17 | 11 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 4 | 1 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 10 | trace | - | - | - | - |
| NEARER NOT NEEDED | 36 | 33 | 0 | 0.00 | - | - |
| NEAREST TO GOAL | 2 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 5 | 5 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 10 | 4 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 245 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| RISK BY ARC | 6 | 6 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 3 | 3 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SEARCH SPOT | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 75 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 20 | 20 | 0 | 0.00 | - | - |
| SPELL WORTH | 9 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 35 | 24 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 7 | 7 | 0 | 0.00 | - | - |
| STANDS STILL | 307 | 301 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 26 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 18 | not checked | - | - | - | - |
| THE TABLE BINDS | 251 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 4 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 1 | 1 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.00 | 3.00 | 25.1 |
| PROMISE BY ITS OWN SUM | rule | 1.00 | 1.33 | 94.0 |
| RULE SWITCHED OFF | gate | 1.33 | - | 30.8 |
| ARMY TABLE | rule | 0.33 | 0.67 | 82.5 |
| CHARGE NOW FIRST | rule | 0.67 | - | 15.2 |
| JOINT CHARGE NOW | rule | 0.67 | - | 197.0 |
| SUPPORT NARROWED | rule | 0.67 | - | 11.9 |
| AFTERMATH BAND | gate | 0.33 | - | 4.3 |
| FRIENDS SHOTS CHECKED | rule | 0.33 | - | 4.3 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 46.1 |
| ONE PROMISE A TARGET | rule | 0.33 | - | 30.0 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 5.4 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | - | 4.0 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 60.0 |
| WAR ENGINE JOBS | rule | 0.33 | - | 129.6 |

### Plans: gs3-83c8646-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.0 | 50% | 349 | 226 | 65% |
| Mine | join | 0.3 | 100% | 11 | 0 | 0% |
| Mine | move | 28.3 | 95% | 2016 | 0 | 0% |
| Mine | shoot | 10.3 | 61% | 341 | 523 | 153% |
| Opponent | join | 1.0 | 100% | 35 | 0 | 0% |
| Opponent | move | 26.0 | 88% | 1172 | 0 | 0% |
| Opponent | shoot | 13.0 | 67% | 529 | 729 | 138% |
| Opponent | support | 0.7 | 100% | 0 | 0 | - |

### Battle groups: gs3-83c8646-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 1.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | 0 (1) | - | 0 (1) | 0 (2) | - |
| Mine | Character | 11 | 40 (11) | 40 | 0 | 0 | 18% | 1.9 | 32 (5) | 75 (4) | 0 (2) | 26 (7) | 55 (4) |
| Mine | Clean-up | 3 | 99 (3) | 0 | 99 | 0 | 33% | 3.5 | 99 (3) | - | - | 150 (2) | 0 (1) |
| Mine | Hammer | 8 | 18 (8) | 4 | 15 | 20 | 25% | 1.7 | 0 (2) | 22 (6) | - | 30 (5) | 7 (3) |
| Mine | Holder | 4 | 105 (4) | 0 | 105 | 27 | 75% | 1.0 | 0 (1) | 138 (3) | - | 259 (1) | 48 (3) |
| Mine | Shooter | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | 0 (1) | - | - | - | 0 (1) |
| Mine | War machine | 5 | 111 (5) | 111 | 0 | 40 | 0% | 1.0 | 111 (5) | - | - | 278 (2) | 0 (3) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 100 | 100% | - | 0 (1) | 0 (1) | 0 (1) | 0 (1) | 0 (2) |
| Opponent | Character | 14 | 7 (14) | 7 | 0 | 39 | 50% | 2.1 | 10 (10) | 0 (3) | - | 9 (9) | 0 (4) |
| Opponent | Clean-up | 4 | 96 (4) | 0 | 96 | 0 | 100% | - | - | 96 (4) | - | 96 (4) | - |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Hammer | 6 | 55 (6) | 26 | 29 | 23 | 17% | 3.0 | 75 (2) | 0 (1) | 64 (3) | 55 (6) | - |
| Opponent | Holder | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | - | 0 (2) | 0 (1) | 0 (1) | 0 (2) |
| Opponent | Shooter | 4 | 12 (4) | 0 | 12 | 54 | 50% | 2.0 | - | 20 (3) | 0 (1) | 12 (4) | - |
| Opponent | War machine | 9 | 38 (9) | 38 | 0 | 62 | 11% | 1.0 | 38 (9) | - | - | 0 (1) | 44 (8) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | 0 (1) | - |

### Charged fights: gs3-83c8646-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 32 | 412 | 3.0 | 1.2 | 137 | 0 | +137 | 5 of 6 | 3 of 6 | +0 | +165 |
| Mine | Dwarfen Mountain Holds | 1 | 730 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 265 | 274 | 2.0 | 1.2 | 137 | 0 | +137 | 5 of 6 | 3 of 6 | +0 | +165 |
| Opponent | Dwarfen Mountain Holds | 1 | 449 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 1 | 65 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 171 | 0 | 0.0 | - | - | - | - | - | - | - | - |

### Effective charges: gs3-83c8646-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 6 | 0 | 0 | 1 (net +0) | 3 (net +46) | 1 (net +145) | 1 (net +540) | 0 | 17% (1 of 6) |

### Charged fights, damage counted: gs3-83c8646-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 422 | 239 | +0 | 151 | 241 | -90 | -21.4 |
| Mine | 76-89% | 3 | 267 | 229 | +46 | 46 | 77 | -31 | -11.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 339 | 440 | +540 | 540 | 145 | +395 | +116.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 480 | 145 | +145 | 145 | 0 | +145 | +30.2 |
| Mine | All fights | 6 | 340 | 252 | +137 | 162 | 103 | +59 | +17.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p3 | move | 7 | 2 (29%) | 2 (29%) | 1 (14%) | 4 (57%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Periapt of Soul Exchange | Opponent | L0421 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421 |
| Witch Hunter's Ward | Opponent | L0508 |

# Doctrine scorecard: gs3-83c8646-p37

### Scorecard: gs3-83c8646-p37

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 11 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 3 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | yes | 2 | 5 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Opponent | no | 0 | 4 | 2 | 2 | 0 | 0 | 0 | 98 |
| L0214 | 4 | 1 | Mine | no | 5 | - | 0 | 3 | 0 | 0 | 0 | 170 |
| L0214 | 4 | 1 | Opponent | no | 2 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 6.0 | 5.0 | 0.3 | 2.0 | 0.0 | 0.0 | 0.0 | 56.7 |
| **Average** | | | Opponent | 0% | 1.7 | 2.7 | 1.3 | 1.7 | 0.0 | 0.0 | 0.0 | 32.7 |

### KPIs: gs3-83c8646-p37

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 6) | 0% (0 of 18) | 0% (0 of 24) |
| Winner chose to follow up after the loser gave ground |  | 33% (1 of 3); on the table 100% | 100% (2 of 2); on the table 100% | 60% (3 of 5); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 50% (1 of 2); on the table 50% | 100% (1 of 1); on the table 100% | 67% (2 of 3); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 40% (2 of 5); on the table 80% | 100% (3 of 3); on the table 100% | 62% (5 of 8); on the table 88% |
| Magic missiles tried each own turn | 50%+ | 44% (37 of 84) | 33% (4 of 12) | 43% (41 of 96) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 59% (37 of 63) | 36% (4 of 11) | 55% (41 of 74) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 20% (1 of 5) | - | 20% (1 of 5) |
| Points that never fought | lower | 44% (2495 of 5699) | 53% (3168 of 6000) | 48% (5663 of 11699) |
|   infantry points that never fought | lower | 56% (1244 of 2239) | 48% (327 of 677) | 54% (1571 of 2916) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 50% (8 of 16) | 58% (14 of 24) | 55% (22 of 40) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 5.7 uses a game | 0.0 uses a game | 100% (4 of 4); 2.8 uses a game |
| Bound items with another spell used |  | 50% (1 of 2); 0.3 uses a game | 42% (5 of 12); 2.7 uses a game | 43% (6 of 14); 1.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 75% (3 of 4); 1.0 uses a game | 100% (1 of 1); 0.3 uses a game | 80% (4 of 5); 0.7 uses a game |
|   their share of the points of units over 100 pts | lower | 41% (1606 of 3916) | 56% (3177 of 5654) | 50% (4783 of 9570) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 6.0 (38%) | 0.3 (12%) | 6.3 (35%) |
| MARCHED: its unit marched | 2.7 (17%) | 1.3 (50%) | 4.0 (22%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.7 (25%) | 0.7 (4%) |
| IN COMBAT: engaged in combat | 1.3 (9%) | 0.3 (12%) | 1.7 (9%) |
| GONE: slain | 5.7 (36%) | 0.0 (0%) | 5.7 (31%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 1.3 | 3.3 | 9.0 | 13.7 | 0.7 | 1.0 |
| not cast | 0.7 | 9.3 | 5.0 | 18.3 | 3.3 | 35.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 6.0 (64%) | 0.3 (7%) | 6.3 (35%) | 1.3 (40%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.0 (22%) | 0.3 (10%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (4%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (9%) | 0.7 (20%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (4%) |
| GONE: slain | 0.0 (0%) | 1.3 (14%) | 2.3 (47%) | 5.7 (31%) | 1.0 (30%) | 2.7 (8%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 1.3 (14%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.7 (100%) | 0.7 (7%) | 2.3 (47%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 30.3 (87%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 8.7 a game | 0.7 a game | 4.7 a game |
| stood (cast and not dispelled) | 58% (15 of 26) | 100% (2 of 2) | 61% (17 of 28) |
| the unit moved after it | 80% (12 of 15) | 50% (1 of 2) | 76% (13 of 17) |
| it charged on its next turn | 0% (0 of 15) | 0% (0 of 2) | 0% (0 of 17) |
| the enemy charged it first | 20% (3 of 15) | 0% (0 of 2) | 18% (3 of 17) |
| it fought by the end of its next turn | 7% (1 of 15) | 0% (0 of 2) | 6% (1 of 17) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 15) | 0% (0 of 2) | 0% (0 of 17) |
| none of these (no charge, no fight, no charge escaped) | 80% (12 of 15) | 100% (2 of 2) | 82% (14 of 17) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 36% (8 of 22) | 30% (17 of 56) | 32% (25 of 78) |
|   cavalry | - | 52% (11 of 21) | 52% (11 of 21) |
|   character | - | 0% (0 of 23) | 0% (0 of 23) |
|   infantry | 36% (8 of 22) | 50% (6 of 12) | 41% (14 of 34) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (57%) | 2.0 (15%) | 4.7 (26%) |
| CHARGED: it charged | 0.0 (0%) | 2.7 (21%) | 2.7 (15%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| NO TARGET IN RANGE | 1.7 (36%) | 5.3 (41%) | 7.0 (40%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (7%) | 2.0 (15%) | 2.3 (13%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.3 | 1.3 | 82% | 1.0 pts | 8 pts |
| infantry | 6.7 | 2.7 | 70% | 5.1 pts | 34 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.3 | 4.3 | 2.3 |
| Charges that made contact a game | 0.3 | 2.7 | 1.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 1.50 declared, 0.50 contact (2 units) | 1.50 declared, 0.50 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.05 declared, 0.05 contact (20 units) | 0.45 declared, 0.32 contact (22 units) | 0.26 declared, 0.19 contact (42 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 54% (7 of 13) | - | - | 54% (7 of 13) |
| Character in a unit | 100% (3 of 3) | 71% (5 of 7) | - | 80% (8 of 10) |
| Character on its own | 100% (1 of 1) | 100% (1 of 1) | 40% (2 of 5) | 57% (4 of 7) |
| Infantry | 67% (2 of 3) | 0% (0 of 5) | - | 25% (2 of 8) |
| Monster | 0% (0 of 1) | 100% (1 of 1) | - | 50% (1 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 3 | 40% (2 of 5); on the table 80% | 44% (37 of 84) | 44% | 50% (8 of 16) | 100% (4 of 4); 5.7 uses a game | 50% (1 of 2); 0.3 uses a game | 75% (3 of 4); 1.0 uses a game |
| High Elf Realms | 2 | 100% (3 of 3); on the table 100% | 33% (4 of 12) | 41% | 44% (8 of 18) | 0.0 uses a game | 42% (5 of 12); 4.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | - | - | 77% | 100% (6 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p37, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 17% (1) | 100% (1) | 29% (2) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.33 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.33 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p37

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 100% (1 of 1) | 25% (3 of 12) |
| Strategy | Shoot objectives carried out (shot that target) | 7% (1 of 14) | 44% (4 of 9) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | 50% (2 of 4) |
| Strategy | Hexes on a unit its side charged or shot that turn | 50% (1 of 2) | 33% (1 of 3) |
| Strategy | Joined characters whose unit fought | 62% (8 of 13) | 0% (0 of 2) |
| Strategy | Lone characters that fought | 60% (3 of 5) | 60% (3 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 2.0 | 1.7 |
| Movement | Points that never moved of their own | 56.7 | 32.7 |
| Movement | Fights charged into per game | 0.3 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 1 | 0 of 5 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 1 | 1 of 5, net -417 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 1 | 2 of 5, net +84 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 1, net +285 | 1 of 5, net +1017 |
| Shooting | Shots by shooting units (incl. breath weapons) | 2.7 | 8.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 38% (3 of 8) | 4% (1 of 24) |
| Shooting | Points destroyed by shooting units | 50.3 | 10.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 6.7 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 30% (6 of 20) | 50% (2 of 4) |
| Magic | Wounds caused by magic missiles | 15.0 | 1.3 |
| Magic | Wounds caused by other spells | 0.3 | 2.0 |
| Magic | Points destroyed by magic (all spells) | 65.3 | 34.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.7 / 0.7 / 0.3 | 0.0 / 1.3 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 196.7 | 249.7 |
| Combat | Points run down | 95.0 | 142.3 |
| Combat | Net points per charged fight, damage counted | +261 | +55 |
| Combat | Net per 100 charger points, damage counted | +31.2 | +12.7 |
| Combat | First round won (charged fights) | 100% | 67% |
| Combat | Net points per charged fight | +285 | +99 |
| Combat | Net points per supported fight / lone fight | - / +285 | +300 / -1 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 1 | 3 of 6 |
| Game | Points lost | 440.0 | 407.3 |
| Game | VP from objectives | 743.3 | 763.3 |
| Game | Lone holders (player turns) | 6.0 | 1.7 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +10 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 847
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p37

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 11.7 | +30.2 | 0.0 | 146.7 | 17.3 | +449.0 | 0.0 | 177.0 |
| BACKUP TARGETS | 0.3 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -10.0 | 124.0 | 0.0 |
| BOUND ASSAILMENT | - | - | - | - | 1.0 | +0.2 | 0.0 | 136.3 |
| CAST JOB | 0.7 | +43.9 | 0.0 | 0.0 | 0.7 | +1.7 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 6.3 | +500.2 | 421.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 5.0 | +0.0 | 0.0 | 268.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 1.3 | +22.4 | 0.0 | 40.0 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 0.3 | -0.8 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.7 | +4.6 | 0.0 | 0.0 | 0.3 | +9.8 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -9.0 | 0.0 | 50.3 |
| CHARGE LOSSES | 9.3 | -506.5 | 0.0 | 291.3 | 14.7 | -778.4 | 0.0 | 529.0 |
| CHARGE NOW FIRST | - | - | - | - | 1.7 | +0.0 | 117.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 15.3 | +0.0 | 0.0 | 71.3 | 11.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 8.0 | +1201.9 | 167.3 | 300.0 | 0.7 | +36.1 | 0.0 | 0.0 |
| COVER ONCE | 6.0 | -263.8 | 0.0 | 145.7 | 12.0 | -350.8 | 0.0 | 168.7 |
| DENIED BY THE FIGHT | - | - | - | - | 1.0 | -1.1 | 43.3 | 0.0 |
| DEPLOY BY FIGURES | 7.0 | +41.0 | 0.0 | 0.0 | 7.3 | -4.5 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.7 | -311.7 | 124.0 | 0.0 |
| EXACT ROUND | - | - | - | - | 1.7 | -7.9 | 219.7 | 0.0 |
| FALL BACK GOOD ORDER | - | - | - | - | 1.7 | +0.0 | 141.3 | 50.3 |
| FALLS SHORT | 8.3 | +197.1 | 0.0 | 21.7 | 7.3 | +75.3 | 0.0 | 280.3 |
| FEATURE BUFFS | 9.0 | +331.2 | 0.0 | 36.7 | 2.0 | +52.5 | 0.0 | 0.0 |
| FIGHT LIFT | 0.3 | +5.1 | 95.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | - | - | - | - | 0.7 | +51.8 | 124.0 | 0.0 |
| FIVE ACTION | 68.7 | +7407.3 | 706.0 | 757.3 | 83.0 | +4242.3 | 505.0 | 827.3 |
| FLANK NOT WEIGHED | 4.0 | +0.0 | 0.0 | 200.3 | 6.0 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.3 | +41.0 | 0.0 | 0.0 | - | - | - | - |
| FOOT FIRST | - | - | - | - | 26.3 | +0.0 | 0.0 | 315.0 |
| FOUR ROUNDS | 0.3 | +26.5 | 95.0 | 0.0 | 4.0 | +364.0 | 415.0 | 50.3 |
| FREED FROM HIS FIGHT | 0.7 | +0.0 | 0.0 | 56.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 2.0 | -2.4 | 0.0 | 0.0 |
| GOAL WALK | 3.0 | +439.1 | 0.0 | 0.0 | 2.7 | +174.1 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 50.3 |
| HE REFORMS ONCE FREED | 0.7 | +0.0 | 0.0 | 56.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 7.3 | +0.0 | 0.0 | 291.3 | 8.7 | +0.0 | 0.0 | 305.7 |
| HIS CHARGE DENIED | - | - | - | - | 0.7 | +37.2 | 56.7 | 0.0 |
| HIS CHARGE LIST | 4.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.3 | +0.0 | 0.0 | 0.0 | 9.0 | +0.0 | 0.0 | 190.0 |
| HIS MOVE AND SHOT | 6.7 | -66.0 | 0.0 | 291.3 | 4.7 | -227.5 | 0.0 | 100.7 |
| HIS ONE QUARTER | 1.7 | +0.0 | 0.0 | 28.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 2.3 | +0.0 | 0.0 | 0.0 | 10.3 | +0.0 | 0.0 | 190.0 |
| HIS RANDOM MOVE | - | - | - | - | 8.0 | +0.0 | 0.0 | 82.0 |
| HIS RANDOM MOVER COMES | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 23.3 | +276.9 | 0.0 | 465.3 | 50.3 | +3172.2 | 0.0 | 685.7 |
| HIS SHOTS BY HIS RUN | 28.7 | +293.4 | 0.0 | 487.3 | 38.3 | +1284.3 | 0.0 | 695.0 |
| HIS TURN DENIED | - | - | - | - | 2.0 | +151.8 | 189.0 | 50.3 |
| HOLD ODDS | 27.7 | +0.0 | 0.0 | 210.3 | 21.3 | +0.0 | 0.0 | 65.3 |
| HOLDER ASSIGNMENT | 14.7 | +1428.1 | 0.0 | 96.0 | 14.0 | +1688.1 | 0.0 | 32.7 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.3 | -2.2 | 95.0 | 0.0 | 3.0 | -136.1 | 291.0 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +7.1 | 0.0 | 0.0 |
| IDLE COST | 8.7 | -56.0 | 0.0 | 118.7 | 9.7 | -195.1 | 0.0 | 185.3 |
| JOINT CHARGE NOW | 0.3 | +19.5 | 95.0 | 0.0 | 2.3 | +45.8 | 313.0 | 50.3 |
| JOINT ON THE TABLE | - | - | - | - | 0.3 | +61.3 | 21.7 | 0.0 |
| KEPT FROM ITS LAST STOP | 1.7 | +0.0 | 0.0 | 99.3 | 3.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 1.3 | +51.1 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| LEGAL CHARGES ONLY | 5.7 | +0.0 | 145.3 | 276.3 | 7.3 | +0.0 | 244.0 | 0.0 |
| LONE WIZARD KEPT IN | 2.7 | +108.0 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 0.3 | -15.1 | 95.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 0.3 | +0.2 | 95.0 | 0.0 | 2.7 | +0.7 | 315.0 | 50.3 |
| MANOEUVRE | 0.7 | +15.5 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +8.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | - | - | - | - | 1.0 | +61.6 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +18.2 | 0.0 | 0.0 | 0.3 | +69.2 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +16.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | - | - | - | - | 0.3 | +164.7 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.0 | +174.4 | 0.0 | 75.0 | 0.3 | +3.5 | 0.0 | 0.0 |
| MEETS IN TIME | 4.0 | +400.5 | 0.0 | 0.0 | 3.7 | +573.2 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 8.3 | +654.9 | 0.0 | 124.0 | 1.3 | +3.5 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 8.3 | +365.7 | 0.0 | 124.0 | 2.3 | +3.8 | 0.0 | 0.0 |
| MISSILES ON ONE TARGET | 2.0 | -83.9 | 0.0 | 124.0 | - | - | - | - |
| MOVE ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 41.0 |
| MOVE SPELL NOT WORTH | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 3.0 | +0.0 | 0.0 | 21.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 2.0 | +103.1 | 0.0 | 56.7 | 3.0 | +92.6 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 3.0 | +158.6 | 0.0 | 145.7 | 1.7 | +70.7 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 1.7 | +73.9 | 0.0 | 56.7 | 1.0 | +38.5 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 0.3 | -37.8 | 95.0 | 0.0 | 4.0 | -125.7 | 415.0 | 50.3 |
| NO LATE CUT | 1.0 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.3 | -1.3 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 3.0 | -133.1 | 0.0 | 162.3 | 3.0 | -199.4 | 0.0 | 50.3 |
| ONE CHALLENGE TEST | - | - | - | - | 0.3 | -9.0 | 0.0 | 50.3 |
| ONE FIGHT FORMULA | 3.3 | -37.9 | 0.0 | 56.7 | 5.7 | -98.3 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | -85.1 | 0.0 | 50.3 |
| ONE OBJECTIVE FORMULA | 8.0 | -35.7 | 0.0 | 18.3 | 5.7 | -91.0 | 0.0 | 32.7 |
| ONE PROMISE A TARGET | 0.7 | -1.2 | 0.0 | 56.7 | - | - | - | - |
| ONE ROUTE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.7 | +11.5 | 43.3 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +82.6 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -2.3 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 30.3 | +470.5 | 232.0 | 520.0 | 38.0 | +189.9 | 316.3 | 767.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 95.0 |
| PROMISE BY ITS OWN SUM | 2.3 | -59.6 | 0.0 | 0.0 | 6.3 | -27.7 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.3 | -31.1 | 0.0 | 56.7 | - | - | - | - |
| PROMISE READS THE TABLE | - | - | - | - | 1.3 | -1.4 | 0.0 | 0.0 |
| PURSUES BIG PREY | 0.3 | -136.2 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 13.0 | +2015.4 | 285.0 | 84.0 | 11.7 | +1640.9 | 28.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 1.7 | +33.3 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 3.0 | +335.2 | 0.0 | 104.7 | - | - | - | - |
| REDIRECT FOR A FRIEND IN REACH | 5.0 | +0.0 | 0.0 | 131.3 | - | - | - | - |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 57.7 |
| RESERVE MOVE SPELL | 0.7 | +144.3 | 124.0 | 242.3 | - | - | - | - |
| RISK BY ARC | 0.3 | +17.7 | 95.0 | 0.0 | 3.0 | -142.1 | 365.3 | 50.3 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.7 | -66.0 | 202.0 | 0.0 |
| RUN DOWN | 0.3 | -19.1 | 95.0 | 0.0 | 3.3 | -17.3 | 291.0 | 0.0 |
| SCOUT SPOT | 0.3 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | 0.7 | -5.1 | 0.0 | 20.0 | - | - | - | - |
| SEARCH SPOT | 1.0 | +14.7 | 0.0 | 0.0 | 0.3 | +0.4 | 0.0 | 0.0 |
| SET CREDITED ONCE | 2.3 | -33.0 | 0.0 | 126.0 | 5.7 | -672.7 | 0.0 | 305.7 |
| SET UP BY THE SET | 3.0 | +76.0 | 0.0 | 126.0 | 7.0 | +480.4 | 0.0 | 305.7 |
| SET-UP ANY TARGET | 1.0 | +140.5 | 0.0 | 0.0 | - | - | - | - |
| SET-UP MISSED | 0.7 | +57.9 | 0.0 | 31.7 | - | - | - | - |
| SHOOTER COUNTED ONCE | 0.7 | -2.6 | 0.0 | 20.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 5.3 | +0.0 | 0.0 | 31.7 | 3.0 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +34.7 | 0.0 | 0.0 | 2.3 | +10.7 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -4.2 | 95.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 22.3 | -225.0 | 0.0 | 455.3 | 42.3 | +469.5 | 0.0 | 736.0 |
| SHOTS AFTER THE MOVES | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 3.3 | +240.5 | 0.0 | 43.3 | 9.7 | +125.6 | 0.0 | 41.0 |
| SPELL SETS UP CHARGE | 1.0 | +140.5 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 2.0 | +51.6 | 95.0 | 118.3 | - | - | - | - |
| SPELLS IN THE FIGHT | - | - | - | - | 1.7 | +17.8 | 184.7 | 50.3 |
| SPOT AS THE GAME MOVES | 8.7 | +0.0 | 0.0 | 389.0 | 7.0 | +0.0 | 0.0 | 290.7 |
| STAND AND SHOOT | - | - | - | - | 1.0 | -7.7 | 65.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 22.3 | +0.0 | 611.0 | 136.0 | 28.3 | +0.0 | 90.0 | 413.7 |
| STAY WORTH | 8.7 | +260.0 | 516.0 | 21.7 | 11.3 | +42.0 | 68.3 | 41.0 |
| STRIKE BY THE ODDS | 0.3 | +11.1 | 0.0 | 124.0 | 1.0 | +15.8 | 31.7 | 115.3 |
| SUPPORT ADDS | 6.7 | +684.5 | 0.0 | 91.3 | 0.3 | +1.3 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 6.7 | +684.5 | 0.0 | 91.3 | 0.3 | +1.3 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 1.0 | +1.4 | 0.0 | 17.3 | 0.7 | +0.4 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.3 | +0.0 | 0.0 | 10.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.3 | +0.0 | 0.0 | 141.3 | 4.0 | +0.0 | 0.0 | 32.7 |
| THE STEP BACK IS MADE | 2.3 | +0.0 | 0.0 | 141.3 | 2.0 | +0.0 | 0.0 | 32.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 33.7 | +0.0 | 0.0 | 388.7 | 39.3 | +0.0 | 0.0 | 359.7 |
| TIED UP BY THE SUM | - | - | - | - | 1.3 | +114.2 | 100.0 | 0.0 |
| TIME ON OUR SIDE | 15.7 | +336.4 | 0.0 | 219.0 | 29.3 | +324.3 | 0.0 | 292.7 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | - | - | - | - | 0.3 | +1.6 | 17.3 | 0.0 |
| WHO GETS IN | 0.3 | +19.5 | 95.0 | 0.0 | 0.7 | +16.1 | 0.0 | 50.3 |
| WHO HITS BACK | 0.7 | +83.8 | 0.0 | 0.0 | 0.3 | +44.0 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.3 | -405.1 | 0.0 | 0.0 | 1.3 | -16.4 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 1.0 | +109.1 | 248.0 | 0.0 |
| WOUNDS ON THE RANKS | 2.7 | +39.9 | 0.0 | 248.0 | 1.3 | +114.1 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p37

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 86 | 86 | 78 | 26.00 | +3347 | +42.9 |
| HIS SHOT LIST | 221 | 216 | 60 | 20.00 | +860 | +14.3 |
| ARMY TABLE | 87 | 87 | 53 | 17.67 | +722 | +13.6 |
| HIS SHOTS BY HIS RUN | 201 | 194 | 47 | 15.67 | +534 | +11.4 |
| SHOT RISK POINTS | 194 | 188 | 44 | 14.67 | +1194 | +27.1 |
| LEGAL CHARGES ONLY | 39 | 39 | 39 | 13.00 | +0 | +0.0 |
| TIME ON OUR SIDE | 135 | 115 | 30 | 10.00 | +186 | +6.2 |
| DEPLOY BY FIGURES | 43 | 43 | 27 | 9.00 | +313 | +11.6 |
| FIVE ACTION | 455 | 447 | 23 | 7.67 | +1939 | +84.3 |
| OFF BEST | 18 | 18 | 18 | 6.00 | -997 | -55.4 |
| THE TABLE AGAIN | 36 | 36 | 17 | 5.67 | +0 | +0.0 |
| CASTING BLOCK | 19 | 19 | 16 | 5.33 | +574 | +35.9 |
| HARD STAY DROPPED | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| MEETS IN TIME | 23 | 23 | 14 | 4.67 | +685 | +48.9 |
| MOVE ORDER | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| QUARTER ODDS | 74 | 73 | 12 | 4.00 | +1274 | +106.2 |
| SUPPORT ADDS | 21 | 21 | 12 | 4.00 | +569 | +47.4 |
| SUPPORT WORKED OUT | 21 | 21 | 12 | 4.00 | +569 | +47.4 |
| SET UP BY THE SET | 30 | 30 | 10 | 3.33 | +60 | +6.0 |
| CHARGE LOSSES | 72 | 70 | 9 | 3.00 | +767 | +85.2 |
| COVER ONCE | 54 | 43 | 9 | 3.00 | +73 | +8.1 |
| GOAL WALK | 17 | 17 | 8 | 2.67 | +1248 | +156.0 |
| JOINT CHARGE NOW | 8 | 8 | 8 | 2.67 | +196 | +24.5 |
| LONE WIZARD KEPT IN | 8 | 8 | 8 | 2.67 | +324 | +40.5 |
| STAY WORTH | 60 | 55 | 8 | 2.67 | +193 | +24.1 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| FOUR ROUNDS | 13 | 13 | 6 | 2.00 | +450 | +75.0 |
| PROMISE BY ITS OWN SUM | 26 | 26 | 6 | 2.00 | -262 | -43.6 |
| REDIRECT COUNTER | 9 | 9 | 6 | 2.00 | +362 | +60.3 |
| SHOOTS FROM THE BEST SPOT | 11 | 11 | 6 | 2.00 | +73 | +12.2 |
| IDLE COST | 55 | 54 | 5 | 1.67 | +35 | +6.9 |
| MAX FOR POSITIONING | 10 | 8 | 5 | 1.67 | +24 | +4.7 |
| MOVE TO CHARGE COMPUTED | 15 | 14 | 5 | 1.67 | +251 | +50.2 |
| FEATURE BUFFS | 33 | 33 | 4 | 1.33 | +69 | +17.1 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +153 | +38.4 |
| MISSILES IN THE MOVE | 29 | 20 | 4 | 1.33 | +487 | +121.7 |
| PROMISE KNOWS THE FIGHT | 4 | 4 | 4 | 1.33 | -93 | -23.3 |
| SEARCH SPOT | 4 | 4 | 4 | 1.33 | +45 | +11.3 |
| STRIKE BY THE ODDS | 4 | 4 | 4 | 1.33 | +81 | +20.2 |
| BOUND ASSAILMENT | 3 | 3 | 3 | 1.00 | +1 | +0.2 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +43 | +14.5 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +185 | +61.6 |
| NEXT CHARGE BY LIST | 8 | 8 | 3 | 1.00 | +157 | +52.3 |
| SHOTS IN THE MOVE | 39 | 34 | 3 | 1.00 | +179 | +59.7 |
| WHO GETS IN | 3 | 3 | 3 | 1.00 | +107 | +35.6 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +149 | +49.6 |
| CHAFF IN THE MOVE | 4 | 4 | 2 | 0.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 5 | 5 | 2 | 0.67 | -116 | -57.8 |
| FALLS SHORT | 47 | 41 | 2 | 0.67 | +9 | +4.6 |
| HIS CHARGE DENIED | 2 | 2 | 2 | 0.67 | +67 | +33.3 |
| HIS TURN DENIED | 6 | 6 | 2 | 0.67 | +175 | +87.4 |
| MARCH CHECK | 3 | 3 | 2 | 0.67 | +138 | +69.2 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -4 | -1.8 |
| REFUSING RETIRES | 4 | 4 | 2 | 0.67 | +90 | +45.0 |
| RESERVE MOVE SPELL | 2 | 2 | 2 | 0.67 | +433 | +216.4 |
| SURE REACH TOGETHER | 5 | 5 | 2 | 0.67 | +0 | +0.0 |
| TIED UP BY THE SUM | 4 | 4 | 2 | 0.67 | +71 | +35.4 |
| WHOLE FIGHT DANGER | 11 | 11 | 2 | 0.67 | +106 | +53.1 |
| BACKUP TARGETS | 1 | 1 | 1 | 0.33 | +1 | +0.8 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -2 | -2.5 |
| EXACT ROUND | 5 | 5 | 1 | 0.33 | +6 | +6.0 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +123 | +123.0 |
| HIS MOVE AND SHOT | 34 | 34 | 1 | 0.33 | +74 | +73.7 |
| HONEST WORTH | 10 | 10 | 1 | 0.33 | +6 | +6.0 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.33 | +184 | +184.0 |
| MANOEUVRE | 6 | 6 | 1 | 0.33 | +51 | +50.8 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -49 | -49.3 |
| MISSILES NEXT TURN | 32 | 21 | 1 | 0.33 | +0 | +0.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| NEARER NOT NEEDED | 14 | 14 | 1 | 0.33 | +61 | +61.4 |
| NO DOUBLE ROUNDS | 13 | 13 | 1 | 0.33 | +6 | +6.0 |
| ONE OBJECTIVE FORMULA | 41 | 30 | 1 | 0.33 | +38 | +37.6 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +248 | +247.8 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -7 | -7.0 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.33 | -408 | -408.5 |
| RANDOM MOVE BY FIGURES | 5 | 5 | 1 | 0.33 | +100 | +99.9 |
| RISK BY ARC | 10 | 10 | 1 | 0.33 | +6 | +6.0 |
| SCOUT WAITS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 10 | 1 | 1 | 0.33 | +0 | +0.0 |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CAST JOB | 4 | 4 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 17 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 80 | 80 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 26 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 5 | 5 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FIGHT TO THE END | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 30 | not checked | - | - | - | - |
| FOOT FIRST | 79 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 6 | 6 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 48 | 48 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 22 | 22 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 34 | 33 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 14 | 13 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 38 | 37 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 24 | 23 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 4 | 4 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 147 | 147 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 15 | 15 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 9 | 9 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 6 | not checked | - | - | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL SPOT | 11 | not checked | - | - | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE FIGHT FORMULA | 27 | 18 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 2 | 2 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 205 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 4 | 4 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 5 | 5 | 0 | 0.00 | - | - |
| RUN DOWN | 11 | 11 | 0 | 0.00 | - | - |
| SCOUT SPOT | 1 | 1 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 24 | 24 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 3 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 25 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 7 | 7 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 3 | not checked | - | - | - | - |
| SPELL WORTH | 6 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 5 | 5 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 47 | 44 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 3 | 3 | 0 | 0.00 | - | - |
| STANDS STILL | 152 | 151 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 4 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 19 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 13 | not checked | - | - | - | - |
| THE TABLE BINDS | 219 | not checked | - | - | - | - |
| WAITS AGAIN | 3 | 3 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 3 | 3 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 12 | 12 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p37

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.33 | 2.33 | 33.0 |
| HOLDER ASSIGNMENT | rule | 0.67 | 2.33 | 22.5 |
| ARMY TABLE | rule | 2.00 | 0.33 | 45.4 |
| PROMISE BY ITS OWN SUM | rule | 1.00 | 1.00 | 43.6 |
| JOINT CHARGE NOW | rule | - | 1.33 | 75.5 |
| PROMISE KNOWS THE FIGHT | rule | 1.33 | - | 23.3 |
| CHARGE NOW FIRST | rule | - | 0.67 | 57.8 |
| NO REASON | gate | - | 0.67 | 207.4 |
| ONE PROMISE A TARGET | rule | 0.67 | - | 1.8 |
| SET UP BY THE SET | rule | - | 0.67 | 57.1 |
| AFTERMATH BAND | gate | 0.33 | - | 3.0 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.33 | - | 117.6 |
| CHAFF PASSED | rule | - | 0.33 | 2.5 |
| MARCH OF THE TABLE | rule | 0.33 | - | 49.3 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 7.0 |
| PURSUES BIG PREY | rule | 0.33 | - | 408.5 |
| REFUSING RETIRES | rule | - | 0.33 | 3.6 |
| WHO GETS IN | rule | - | 0.33 | 45.0 |
| WHO HITS BACK | rule | 0.33 | - | 3.0 |

### Plans: gs3-83c8646-p37

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.3 | 100% | 131 | 95 | 72% |
| Mine | move | 25.7 | 96% | 2166 | 0 | 0% |
| Mine | shoot | 4.0 | 58% | 794 | 375 | 47% |
| Mine | support | 0.3 | 0% | 3 | 0 | 0% |
| Opponent | charge | 3.3 | 60% | 351 | 124 | 35% |
| Opponent | move | 32.3 | 93% | 1486 | 0 | 0% |
| Opponent | shoot | 2.3 | 71% | 84 | 66 | 78% |

### Battle groups: gs3-83c8646-p37

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.0 | 44% | 25% | 0% | - | 25% | 0% | 0% | 75% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p37

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 3 | 0 (3) | 0 | 0 | 61 | 100% | - | 0 (1) | 0 (2) | - | 0 (3) | - |
| Mine | Character | 16 | 10 (16) | 10 | 0 | 25 | 12% | 1.9 | 17 (3) | 16 (7) | 0 (2) | 7 (7) | 22 (5) |
| Mine | Clean-up | 3 | 0 (3) | 0 | 0 | 67 | 33% | 4.5 | 0 (3) | - | - | 0 (1) | 0 (2) |
| Mine | Fast Hammer | 2 | 0 (2) | 0 | 0 | 50 | 50% | 3.0 | - | - | 0 (2) | 0 (1) | 0 (1) |
| Mine | Hammer | 7 | 79 (7) | 44 | 35 | 21 | 29% | 2.8 | 155 (2) | 86 (2) | 21 (3) | 98 (4) | 55 (3) |
| Mine | Holder | 3 | 88 (3) | 0 | 88 | 35 | 67% | 6.0 | 0 (1) | 130 (2) | - | 156 (1) | 56 (2) |
| Mine | Shooter | 4 | 266 (4) | 58 | 208 | 25 | 0% | 4.0 | - | 532 (2) | 0 (2) | 354 (3) | 0 (1) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 3.0 | - | 0 (2) | - | 0 (2) | - |
| Opponent | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Character | 7 | 39 (7) | 39 | 0 | 0 | 29% | 2.6 | 47 (5) | 0 (2) | - | 58 (5) | 0 (2) |
| Opponent | Clean-up | 2 | 122 (2) | 0 | 122 | 50 | 0% | 2.0 | - | 122 (2) | - | 122 (2) | - |
| Opponent | Fast Hammer | 14 | 35 (14) | 9 | 26 | 44 | 50% | 2.6 | 29 (2) | 27 (9) | 56 (3) | 27 (11) | 74 (3) |
| Opponent | Hammer | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | - | 0 (1) | 0 (1) | - |
| Opponent | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Shooter | 2 | 8 (2) | 8 | 0 | 0 | 0% | 1.5 | - | 17 (1) | 0 (1) | 0 (1) | 17 (1) |

### Charged fights: gs3-83c8646-p37

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 116 | 95 | 0.3 | 1.0 | 285 | 0 | +285 | 1 of 1 | 1 of 1 | - | +285 |
| Opponent | High Elf Realms | 2 | 67 | 593 | 2.5 | 1.4 | 237 | 83 | +154 | 2 of 5 | 4 of 5 | +300 | +56 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 173 | -173 | 1 of 1 | 0 of 1 | - | -173 |
| **Opponent** | all armies | 3 | 45 | 395 | 2.0 | 1.3 | 198 | 98 | +99 | 3 of 6 | 4 of 6 | +300 | -1 |

### Effective charges: gs3-83c8646-p37

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +285) | 0 | 0% (0 of 1) |
| Opponent | High Elf Realms | 5 | 0 | 0 | 1 (net -417) | 1 (net +0) | 2 (net +84) | 1 (net +1017) | 0 | 20% (1 of 5) |

### Charged fights, damage counted: gs3-83c8646-p37

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 836 | 285 | +285 | 285 | 24 | +261 | +31.2 |
| Mine | All fights | 1 | 836 | 285 | +285 | 285 | 24 | +261 | +31.2 |
| Opponent | Effective (55-75%) | 1 | 651 | 272 | -417 | 211 | 925 | -714 | -109.7 |
| Opponent | 76-89% | 1 | 151 | 52 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 640 | 322 | +1017 | 1102 | 54 | +1047 | +163.6 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 489 | 84 | +84 | 84 | 0 | +84 | +17.3 |
| Opponent | No odds | 1 | 173 | 836 | -173 | 0 | 173 | -173 | -100.0 |
| Opponent | All fights | 6 | 432 | 275 | +99 | 247 | 192 | +55 | +12.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p37 | move | 17 | 1 (6%) | 0 (0%) | 0 (0%) | 16 (94%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130 |
| Opal Amulet | Opponent | L0114, L0214 |
| Ring of Doom | Mine | L0214 |

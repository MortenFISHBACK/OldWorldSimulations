# Doctrine scorecard: gs3-83c8646-p66

### Scorecard: gs3-83c8646-p66

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0918 | 6 | 1 | Mine | no | 6 | - | 0 | 2 | 0 | 0 | 0 | 375 |
| L0918 | 6 | 1 | Opponent | no | 3 | - | 2 | 2 | 0 | 0 | 0 | 0 |
| L0934 | 4 | 1 | Mine | no | 0 | 4 | 0 | 2 | 0 | 0 | 0 | 295 |
| L0934 | 4 | 1 | Opponent | no | 0 | 3 | 1 | 6 | 0 | 0 | 0 | 0 |
| L1026 | 6 | 1 | Mine | no | 9 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 8 | 6 | 1 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 5.0 | 3.0 | 0.7 | 1.3 | 0.0 | 0.0 | 0.0 | 333.3 |
| **Average** | | | Opponent | 0% | 3.7 | 4.5 | 1.3 | 3.3 | 0.0 | 0.0 | 0.0 | 0.0 |

### KPIs: gs3-83c8646-p66

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 54% (7 of 13) | 0% (0 of 13) | 27% (7 of 26) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 100% (4 of 4); on the table 100% | 100% (5 of 5); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | 0% (0 of 1); on the table 0% | 50% (1 of 2); on the table 50% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 100% (2 of 2); on the table 100% | 80% (4 of 5); on the table 80% | 86% (6 of 7); on the table 86% |
| Magic missiles tried each own turn | 50%+ | 35% (17 of 48) | 17% (2 of 12) | 32% (19 of 60) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 46% (17 of 37) | 18% (2 of 11) | 40% (19 of 48) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 76% (4575 of 5997) | 84% (5051 of 5998) | 80% (9626 of 11995) |
|   infantry points that never fought | lower | 87% (1383 of 1591) | 95% (1087 of 1147) | 90% (2470 of 2738) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 71% (24 of 34) | 80% (16 of 20) | 74% (40 of 54) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 1.3 uses a game | 100% (1 of 1); 1.0 uses a game | 100% (3 of 3); 1.2 uses a game |
| Bound items with another spell used |  | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 70% (3975 of 5667) | 83% (4328 of 5186) | 77% (8303 of 10853) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 5.0 (48%) | 0.0 (0%) | 5.0 (37%) |
| MARCHED: its unit marched | 1.7 (16%) | 0.7 (20%) | 2.3 (17%) |
| IN COMBAT: engaged in combat | 1.7 (16%) | 0.3 (10%) | 2.0 (15%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 1.0 (30%) | 1.0 (7%) |
| OFF THE TABLE: off the table or not arrived | 2.0 (19%) | 0.0 (0%) | 2.0 (15%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (10%) | 0.3 (2%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 1.0 (30%) | 1.0 (7%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 1.0 | 6.3 | 1.0 | 1.0 |
| not cast | 2.0 | 5.0 | 13.7 | 3.0 | 15.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (40%) | 5.0 (37%) | 0.7 (22%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 2.3 (17%) | 0.7 (22%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 2.0 (15%) | 0.7 (22%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (100%) | 2.0 (40%) | 1.0 (7%) | 0.0 (0%) | 0.0 (0%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 1.0 (20%) | 2.0 (15%) | 1.0 (33%) | 2.3 (16%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 1.0 (7%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.3 (82%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (80 of 132) | 76% (59 of 78) | 66% (139 of 210) |
|   cavalry | - | 60% (6 of 10) | 60% (6 of 10) |
|   character | 100% (4 of 4) | 88% (14 of 16) | 90% (18 of 20) |
|   chariot | 73% (11 of 15) | 100% (11 of 11) | 85% (22 of 26) |
|   infantry | 47% (27 of 58) | 59% (17 of 29) | 51% (44 of 87) |
|   monster | 42% (5 of 12) | 92% (11 of 12) | 67% (16 of 24) |
|   war machine | 77% (33 of 43) | - | 77% (33 of 43) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 5.0 (29%) | 3.3 (53%) | 8.3 (35%) |
| IN COMBAT: it fought this turn or the last | 2.0 (12%) | 0.0 (0%) | 2.0 (8%) |
| MOVED: a war machine that moved | 0.3 (2%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET IN RANGE | 3.0 (17%) | 2.3 (37%) | 5.3 (23%) |
| ONLY IN COMBAT: the only targets were in combat | 1.3 (8%) | 0.0 (0%) | 1.3 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 4.7 (27%) | 0.7 (11%) | 5.3 (23%) |
| SHELTERED: the target was sheltered | 0.7 (4%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR | 0.3 (2%) | 0.0 (0%) | 0.3 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| character | 6.0 | 0.7 | 89% | 2.8 pts | 17 pts |
| chariot | 7.3 | 6.3 | 59% | 12.7 pts | 93 pts |
| infantry | 16.3 | 6.0 | 71% | 5.7 pts | 94 pts |
| monster | 7.0 | 2.7 | 76% | 4.4 pts | 31 pts |
| war machine | 11.3 | 12.7 | 56% | 25.9 pts | 294 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.3 | 2.3 | 1.8 |
| Charges that made contact a game | 1.3 | 1.3 | 1.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 1.00 contact (3 units) | 1.00 declared, 1.00 contact (1 units) | 1.00 declared, 1.00 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.05 declared, 0.05 contact (20 units) | 0.19 declared, 0.10 contact (31 units) | 0.14 declared, 0.08 contact (51 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | - | - | 50% (2 of 4) |
| Character in a unit | 100% (5 of 5) | 100% (1 of 1) | - | 100% (6 of 6) |
| Character on its own | - | 67% (2 of 3) | 80% (4 of 5) | 75% (6 of 8) |
| Chariot | 100% (3 of 3) | 50% (1 of 2) | - | 80% (4 of 5) |
| Infantry | 36% (4 of 11) | 100% (2 of 2) | 0% (0 of 1) | 43% (6 of 14) |
| Monster | 100% (1 of 1) | 0% (0 of 1) | - | 50% (1 of 2) |
| Monstrous | 100% (2 of 2) | 100% (5 of 5) | - | 100% (7 of 7) |
| War Machines | 100% (8 of 8) | - | - | 100% (8 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 2 | 100% (2 of 2); on the table 100% | 46% (11 of 24) | 79% | 75% (18 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 25% (6 of 24) | 71% | 60% (6 of 10) | 100% (2 of 2); 4.0 uses a game | 0% (0 of 1); 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Ogre Kingdoms | 1 | 100% (4 of 4); on the table 100% | 0% (0 of 6) | 94% | 86% (6 of 7) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | - | 33% (2 of 6) | 64% | 80% (4 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 0% (0 of 1); on the table 0% | - | 95% | 75% (6 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p66, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 33% (1) | 20% (1) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p66

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 100% (2 of 2) | 50% (3 of 6) |
| Strategy | Shoot objectives carried out (shot that target) | 44% (24 of 55) | 83% (19 of 23) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 100% (2 of 2) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 9) | 0% (0 of 1) |
| Strategy | Lone characters that fought | 40% (2 of 5) | 20% (1 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.3 | 3.3 |
| Movement | Points that never moved of their own | 333.3 | 0.0 |
| Movement | Fights charged into per game | 1.3 | 1.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 2 | 1 of 3, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 2, net +45 | 0 of 3 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 2, net +0 | 0 of 3 |
| Shooting | Shots by shooting units (incl. breath weapons) | 16.0 | 20.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 25% (12 of 48) | 44% (27 of 61) |
| Shooting | Points destroyed by shooting units | 36.3 | 88.3 |
| Shooting | War machine shots | 11.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 64% (21 of 33) | - |
| Shooting | Points destroyed by war machines | 9.0 | 0.0 |
| Magic | Magic missiles cast | 3.7 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 45% (5 of 11) | 100% (1 of 1) |
| Magic | Wounds caused by magic missiles | 6.3 | - |
| Magic | Wounds caused by other spells | 2.0 | 1.3 |
| Magic | Points destroyed by magic (all spells) | 18.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.7 / 0.3 / 0.0 | 2.0 / 0.0 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 71.7 | 125.0 |
| Combat | Points run down | 0.0 | 123.0 |
| Combat | Net points per charged fight, damage counted | +27 | +132 |
| Combat | Net per 100 charger points, damage counted | +9.1 | +72.1 |
| Combat | First round won (charged fights) | 100% | 50% |
| Combat | Net points per charged fight | -38 | +94 |
| Combat | Net points per supported fight / lone fight | - / -38 | - / +94 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 4 | 1 of 4 |
| Game | Points lost | 336.3 | 244.3 |
| Game | VP from objectives | 683.3 | 693.3 |
| Game | Lone holders (player turns) | 5.0 | 3.7 |

- Mine won / drew / lost: 0 / 2 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -112 VP
- The side that went first won 0 of 1 games with a winner
- Points traded per game (both sides' losses): 581
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p66

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 15.3 | +194.4 | 0.0 | 0.0 | 29.0 | +225.4 | 0.0 | 113.7 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +24.9 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 6.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.3 | +0.0 | 36.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 10.0 | +40.7 | 47.7 | 41.7 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 2.0 | +37.0 | 51.7 | 0.0 | 0.7 | +0.9 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 0.3 | +7.2 | 0.0 | 9.0 |
| CHAFF PASSED | 0.3 | -1.9 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 7.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 20.0 | -546.1 | 0.0 | 176.7 | 28.0 | -825.5 | 0.0 | 269.3 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 175.7 | 123.0 | 0.3 | +0.0 | 123.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 4.7 | +0.0 | 0.0 | 0.0 | 20.0 | +0.0 | 0.0 | 132.3 |
| COVER ONCE | 9.0 | -279.5 | 0.0 | 83.3 | 3.3 | -200.3 | 0.0 | 73.0 |
| DEFENSIVE ARMY | 0.3 | +0.0 | 35.7 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -7.9 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 9.0 | -55.1 | 0.0 | 0.0 | 9.0 | +40.5 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 1.0 | +2.2 | 0.0 | 0.0 |
| EXACT ROUND | 1.0 | +1.7 | 88.0 | 123.0 | 1.7 | -15.0 | 123.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.0 | +0.0 | 71.3 | 123.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 5.3 | +70.4 | 0.0 | 0.0 | 26.3 | +273.2 | 0.0 | 110.7 |
| FIGHT TO THE END | - | - | - | - | 0.7 | +4.0 | 0.0 | 0.0 |
| FIVE ACTION | 104.3 | +4589.9 | 290.7 | 766.0 | 112.0 | +4548.8 | 329.3 | 793.3 |
| FLANK NOT WEIGHED | 9.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 72.7 |
| FOCUS FIRE | 0.7 | +2.6 | 18.0 | 0.0 | - | - | - | - |
| FOOT FIRST | 10.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 1.3 | +90.9 | 108.0 | 246.0 | 2.0 | +82.4 | 246.0 | 0.0 |
| FREED FROM HIS FIGHT | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.3 | -4.2 | 20.0 | 123.0 | 0.7 | -7.0 | 0.0 | 0.0 |
| GOAL ON TIME | 0.7 | +26.7 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 5.7 | +332.2 | 0.0 | 176.7 | 20.3 | +1812.1 | 0.0 | 73.3 |
| GUN FIGURES | 2.0 | +35.7 | 9.0 | 176.7 | 1.7 | +29.2 | 0.0 | 61.7 |
| GUN MASK | 5.3 | +421.5 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 4.0 | +0.0 | 0.0 | 88.3 | 4.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 10.7 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 146.0 |
| HIS CHARGE LIST | 8.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 5.3 | -66.5 | 0.0 | 0.0 | 17.7 | -185.8 | 0.0 | 22.7 |
| HIS ONE QUARTER | 1.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 37.3 |
| HIS OWN BEST MOVE | 5.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 44.3 | +1309.9 | 0.0 | 436.7 | 85.7 | +6513.8 | 0.0 | 640.0 |
| HIS SHOTS BY HIS RUN | 39.0 | +739.0 | 0.0 | 353.3 | 68.7 | +1449.2 | 0.0 | 598.7 |
| HIS TURN DENIED | - | - | - | - | 0.7 | +26.1 | 0.0 | 0.0 |
| HOLD ODDS | 17.3 | +0.0 | 0.0 | 0.0 | 21.0 | +0.0 | 0.0 | 111.3 |
| HOLDER ASSIGNMENT | 12.7 | +1354.6 | 0.0 | 0.0 | 15.3 | +1375.2 | 0.0 | 55.7 |
| HOLDS AMBUSHERS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -48.5 | 108.0 | 246.0 | 1.7 | -51.4 | 123.0 | 0.0 |
| IDLE COST | 2.7 | -40.1 | 0.0 | 0.0 | 22.0 | -368.4 | 0.0 | 72.0 |
| JOINT CHARGE NOW | - | - | - | - | 0.7 | +197.1 | 246.0 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.3 | -2.0 | 123.0 | 0.0 |
| KEEP FALLS | 0.3 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 4.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 111.3 |
| LANE BY FIGURES | 0.7 | +15.4 | 0.0 | 0.0 | 1.3 | +93.2 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | - | - | - | - | 3.7 | +0.0 | 125.0 | 107.0 |
| LONE WIZARD KEPT IN | 1.3 | +43.3 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.7 | -0.2 | 56.7 | 246.0 | 1.3 | +3.5 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 1.0 | +6.9 | 0.0 | 9.0 |
| MANOEUVRE | 3.3 | -8.0 | 0.0 | 0.0 | 3.3 | -1.0 | 0.0 | 18.7 |
| MARCH AT ESCAPER | 0.7 | +5.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +33.1 | 0.0 | 0.0 | 0.3 | +4.6 | 0.0 | 0.0 |
| MARCH CHECK | 1.7 | +91.1 | 0.0 | 0.0 | 1.0 | +55.3 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.7 | +16.1 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.7 | -16.1 | 0.0 | 0.0 | 0.3 | -22.2 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.0 | +4.7 | 0.0 | 0.0 | 2.0 | +18.4 | 0.0 | 35.3 |
| MEETS IN TIME | 3.7 | +414.2 | 0.0 | 0.0 | 3.7 | +549.1 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 10.0 | +135.0 | 0.0 | 0.0 | 2.0 | +27.6 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 12.7 | +126.8 | 0.0 | 0.0 | 3.3 | +26.3 | 0.0 | 0.0 |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 20.3 | 35.7 |
| MOVE TO CHARGE COMPUTED | 2.3 | +206.8 | 0.0 | 0.0 | 1.0 | +34.1 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 7.0 | +336.7 | 0.0 | 0.0 | 5.7 | +244.5 | 0.0 | 0.0 |
| NEAREST TO GOAL | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 0.7 | +135.0 | 0.0 | 0.0 | 1.0 | +34.1 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -3.6 | 0.0 | 0.0 | 0.7 | -16.5 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.3 | -42.5 | 108.0 | 246.0 | 1.7 | -95.0 | 123.0 | 0.0 |
| NO LATE CUT | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 71.3 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 6.3 | -218.5 | 20.0 | 299.7 | 4.7 | -21.6 | 0.0 | 45.7 |
| OGRE LOADER SECOND SHOT | 6.0 | +15.0 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.3 | -46.3 | 0.0 | 0.0 | 3.3 | -84.2 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 4.0 | +31.3 | 0.0 | 0.0 | 4.7 | +59.1 | 0.0 | 0.0 |
| ONE ROUTE | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +7.9 | 15.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | - | - | - | - | 1.0 | +3.4 | 0.0 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | -2.6 | 0.0 | 0.0 |
| PLAN RESULT | 45.0 | +524.1 | 55.0 | 631.0 | 50.3 | +318.7 | 0.0 | 457.3 |
| PROMISE BY ITS OWN SUM | 7.3 | -218.0 | 0.0 | 176.7 | 2.7 | -109.3 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.3 | -8.8 | 0.0 | 0.0 |
| QUARTER ODDS | 13.3 | +711.7 | 72.7 | 0.0 | 11.3 | +897.5 | 0.0 | 37.3 |
| REAL GROUND | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 3.0 | +291.7 | 0.0 | 53.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 5.0 | +0.0 | 0.0 | 24.0 |
| REFORMS TO MEET IT | 0.7 | -44.9 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 2.0 | +44.9 | 0.0 | 0.0 |
| RISK BY ARC | 1.3 | +42.2 | 108.0 | 246.0 | 1.7 | -29.2 | 246.0 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.3 | -6.1 | 0.0 | 0.0 |
| RUN DOWN | - | - | - | - | 1.7 | -23.8 | 123.0 | 0.0 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +7.2 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.0 | -121.9 | 0.0 | 18.0 |
| SEARCH SPOT | 1.3 | +7.5 | 0.0 | 0.0 | 1.0 | +2.4 | 0.0 | 9.0 |
| SECOND LOOK | 0.7 | +21.6 | 56.7 | 246.0 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 0.3 | -2.9 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.3 | +1.7 | 0.0 | 0.0 | 1.7 | -92.9 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 1.0 | +6.9 | 0.0 | 9.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 18.3 | +0.0 | 0.0 | 41.7 | 8.0 | +0.0 | 0.0 | 70.7 |
| SHOOTS FROM THE BEST SPOT | 3.7 | +38.4 | 0.0 | 0.0 | 3.0 | +40.9 | 83.3 | 0.0 |
| SHOT OR CHARGE | 0.3 | -0.9 | 15.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 22.7 | -430.9 | 0.0 | 260.0 | 57.3 | +87.5 | 0.0 | 510.7 |
| SHOTS AFTER THE MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 28.7 | +858.8 | 0.0 | 171.7 | 19.0 | +334.5 | 0.0 | 160.7 |
| SPELL WORTH | - | - | - | - | 4.0 | +50.3 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.7 | +6.2 | 56.7 | 246.0 | 0.3 | +2.1 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 4.3 | +0.0 | 0.0 | 0.0 | 8.3 | +0.0 | 0.0 | 45.3 |
| STAND AND SHOOT | - | - | - | - | 1.0 | -5.9 | 0.0 | 0.0 |
| STANDS FOR A REASON | 2.7 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 55.0 | +0.0 | 182.7 | 343.3 | 34.3 | +0.0 | 83.3 | 270.7 |
| STAY WORTH | 50.0 | +149.8 | 95.0 | 343.3 | 29.7 | +324.2 | 0.0 | 355.3 |
| SUPPORT ADDS | 1.3 | +66.5 | 0.0 | 0.0 | 0.7 | +6.3 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 1.3 | +66.5 | 0.0 | 0.0 | 0.7 | +6.3 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.7 | +0.6 | 0.0 | 0.0 | 0.3 | +1.2 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +0.9 | 0.0 | 11.3 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 88.3 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 72.0 |
| THE ROW KEEPS ITS WAY | 3.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 2.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 47.3 | +0.0 | 0.0 | 218.3 | 54.7 | +0.0 | 0.0 | 405.7 |
| TIED UP BY THE SUM | 1.0 | +113.9 | 71.3 | 123.0 | - | - | - | - |
| TIME ON OUR SIDE | 45.7 | +529.8 | 50.7 | 176.7 | 12.0 | +148.3 | 0.0 | 123.3 |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -3.3 | 0.0 | 0.0 |
| WAR ENGINE JOBS | - | - | - | - | 3.3 | +0.0 | 0.0 | 123.3 |
| WHO HITS BACK | - | - | - | - | 1.0 | +46.6 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.0 | -89.4 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +19.7 | 123.0 | 0.0 |
| WOUNDS ON THE RANKS | 7.0 | +59.9 | 0.0 | 0.0 | 1.3 | +27.0 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p66

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 390 | 380 | 158 | 52.67 | +3089 | +19.6 |
| ARMY TABLE | 133 | 133 | 101 | 33.67 | +1028 | +10.2 |
| HOLDER ASSIGNMENT | 84 | 84 | 78 | 26.00 | +4295 | +55.1 |
| HIS SHOTS BY HIS RUN | 323 | 308 | 77 | 25.67 | +1356 | +17.6 |
| SHOT RISK POINTS | 240 | 231 | 46 | 15.33 | +1682 | +36.6 |
| OFF BEST | 33 | 33 | 33 | 11.00 | -720 | -21.8 |
| DEPLOY BY FIGURES | 54 | 54 | 32 | 10.67 | +492 | +15.4 |
| GOAL WALK | 78 | 78 | 31 | 10.33 | +1331 | +42.9 |
| HARD STAY DROPPED | 24 | 24 | 24 | 8.00 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 20 | 20 | 20 | 6.67 | +118 | +5.9 |
| ARTILLERY RE-ROLL WEIGHED | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| TIME ON OUR SIDE | 173 | 143 | 19 | 6.33 | +119 | +6.3 |
| IDLE COST | 74 | 51 | 18 | 6.00 | +151 | +8.4 |
| MEETS IN TIME | 22 | 22 | 18 | 6.00 | +1382 | +76.8 |
| OGRE LOADER SECOND SHOT | 18 | 18 | 18 | 6.00 | +45 | +2.5 |
| THE TABLE AGAIN | 36 | 36 | 16 | 5.33 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 30 | 30 | 15 | 5.00 | -982 | -65.5 |
| REDIRECT FOR A FRIEND IN REACH | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| STAY WORTH | 239 | 211 | 15 | 5.00 | +107 | +7.1 |
| MOVE ORDER | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| GUN MASK | 16 | 16 | 12 | 4.00 | +915 | +76.2 |
| LEGAL CHARGES ONLY | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| FALLS SHORT | 95 | 80 | 8 | 2.67 | +26 | +3.2 |
| SHOTS IN THE MOVE | 143 | 117 | 8 | 2.67 | +55 | +6.8 |
| CHARGE LOSSES | 144 | 137 | 7 | 2.33 | +662 | +94.5 |
| COVER ONCE | 37 | 32 | 7 | 2.33 | +83 | +11.9 |
| MOVE TO CHARGE COMPUTED | 10 | 7 | 7 | 2.33 | +402 | +57.4 |
| FIVE ACTION | 649 | 630 | 6 | 2.00 | +94 | +15.6 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +326 | +54.3 |
| MARCH CHECK | 8 | 8 | 6 | 2.00 | +87 | +14.5 |
| RESERVE FALL BACK | 6 | 6 | 6 | 2.00 | +135 | +22.4 |
| WOUNDS ON THE RANKS | 25 | 23 | 6 | 2.00 | +33 | +5.4 |
| FOUR ROUNDS | 10 | 9 | 5 | 1.67 | +87 | +17.5 |
| MAX FOR POSITIONING | 9 | 9 | 5 | 1.67 | +1 | +0.2 |
| MISSILES IN THE MOVE | 36 | 25 | 5 | 1.67 | +7 | +1.3 |
| NEXT CHARGE BY LIST | 5 | 5 | 5 | 1.67 | +402 | +80.4 |
| SCOUT WAITS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| ADVANCE LANE KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +130 | +32.5 |
| ONE OBJECTIVE FORMULA | 26 | 23 | 4 | 1.33 | +266 | +66.5 |
| QUARTER ODDS | 74 | 74 | 4 | 1.33 | +56 | +14.1 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHARGE NOW FIRST | 7 | 7 | 3 | 1.00 | -42 | -13.8 |
| EVASIVE BY THE ODDS | 3 | 3 | 3 | 1.00 | +7 | +2.2 |
| HIS MOVE AND SHOT | 69 | 67 | 3 | 1.00 | +6 | +1.9 |
| MANOEUVRE | 20 | 20 | 3 | 1.00 | +82 | +27.5 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +113 | +37.7 |
| MARCH OF THE TABLE | 3 | 3 | 3 | 1.00 | -50 | -16.8 |
| REDIRECT COUNTER | 9 | 9 | 3 | 1.00 | +522 | +174.0 |
| SEARCH SPOT | 7 | 7 | 3 | 1.00 | +42 | +14.1 |
| SET UP BY THE SET | 6 | 6 | 3 | 1.00 | +180 | +60.2 |
| SHOTS AFTER THE MOVES | 29 | 29 | 3 | 1.00 | +0 | +0.0 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +53 | +17.8 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FOCUS FIRE | 2 | 2 | 2 | 0.67 | +8 | +3.9 |
| GOAL ON TIME | 2 | 2 | 2 | 0.67 | -73 | -36.5 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +591 | +295.7 |
| MISSILES NEXT TURN | 48 | 30 | 2 | 0.67 | +3 | +1.6 |
| NEARER NOT NEEDED | 38 | 36 | 2 | 0.67 | +75 | +37.3 |
| RISK BY ARC | 9 | 8 | 2 | 0.67 | +55 | +27.5 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +65 | +32.4 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| TIED UP BY THE SUM | 3 | 2 | 2 | 0.67 | +52 | +26.2 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -6 | -5.7 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -5 | -5.2 |
| FIGHT TO THE END | 2 | 2 | 1 | 0.33 | +5 | +5.2 |
| HIS TURN DENIED | 2 | 2 | 1 | 0.33 | +14 | +14.4 |
| HOLDS AMBUSHERS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +2 | +2.0 |
| NEXT OBJECTIVE NEARER | 3 | 2 | 1 | 0.33 | +5 | +4.6 |
| ONE FIGHT FORMULA | 20 | 14 | 1 | 0.33 | +3 | +2.6 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | -8 | -7.8 |
| PROMISE READS THE TABLE | 1 | 1 | 1 | 0.33 | -25 | -24.8 |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 1 | 0.33 | +17 | +16.7 |
| SPELLS IN THE FIGHT | 3 | 2 | 1 | 0.33 | +6 | +6.5 |
| SUPPORT ADDS | 6 | 6 | 1 | 0.33 | +2 | +1.9 |
| SUPPORT WORKED OUT | 6 | 6 | 1 | 0.33 | +2 | +1.9 |
| SURE REACH TOGETHER | 3 | 3 | 1 | 0.33 | +3 | +3.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +3 | +2.6 |
| THE ROW IN ITS ORDER | 21 | 1 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -10 | -9.9 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLANNED TARGET | 30 | 30 | 0 | 0.00 | - | - |
| CAST JOB | 8 | 8 | 0 | 0.00 | - | - |
| CHAFF IN THE MOVE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 23 | 21 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 74 | 74 | 0 | 0.00 | - | - |
| DEFENSIVE ARMY | 1 | 1 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 8 | 8 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 6 | 5 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 42 | not checked | - | - | - | - |
| FOOT FIRST | 30 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 10 | 10 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 11 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 10 | 10 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 51 | 47 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 40 | 36 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 24 | 23 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 14 | 14 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 33 | 30 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 115 | 115 | 0 | 0.00 | - | - |
| HONEST WORTH | 9 | 8 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 24 | 24 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 6 | 5 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 3 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 10 | 10 | 0 | 0.00 | - | - |
| NEAREST TO GOAL | 5 | 5 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 9 | 8 | 0 | 0.00 | - | - |
| NO LATE CUT | 8 | 8 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 7 | not checked | - | - | - | - |
| ONE ROUTE | 10 | 10 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 286 | trace | - | - | - | - |
| REAL GROUND | 10 | 10 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 2 | 2 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 5 | 5 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 3 | 3 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 79 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 38 | 33 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 32 | 29 | 0 | 0.00 | - | - |
| STANDS STILL | 268 | 257 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 27 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 18 | not checked | - | - | - | - |
| THE TABLE BINDS | 306 | not checked | - | - | - | - |
| WAITS AGAIN | 3 | 3 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 10 | 10 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 6 | 6 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p66

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.67 | 3.00 | 26.3 |
| PROMISE BY ITS OWN SUM | rule | 4.33 | 0.67 | 65.5 |
| ARMY TABLE | rule | 0.67 | 2.33 | 39.8 |
| HOLDER ASSIGNMENT | rule | 0.67 | 1.67 | 33.2 |
| CHARGE NOW FIRST | rule | 1.00 | - | 13.8 |
| MARCH OF THE TABLE | rule | 0.67 | 0.33 | 16.8 |
| AFTERMATH BAND | gate | - | 0.67 | 1.9 |
| GOAL ON TIME | rule | 0.67 | - | 36.5 |
| NO REASON | gate | 0.67 | - | 5.0 |
| RULE SWITCHED OFF | gate | - | 0.67 | 5.1 |
| CHAFF PASSED | rule | 0.33 | - | 5.7 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 5.2 |
| FALLBACK | gate | - | 0.33 | 12.8 |
| PATHS CROSS | rule | - | 0.33 | 7.8 |
| PROMISE READS THE TABLE | rule | - | 0.33 | 24.8 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 9.9 |

### Plans: gs3-83c8646-p66

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 75% | 72 | 90 | 125% |
| Mine | move | 27.7 | 99% | 1420 | 0 | 0% |
| Mine | shoot | 16.0 | 48% | 545 | 434 | 80% |
| Opponent | charge | 1.7 | 40% | 227 | 275 | 121% |
| Opponent | move | 41.7 | 94% | 1858 | 0 | 0% |
| Opponent | shoot | 6.0 | 17% | 342 | 43 | 13% |
| Opponent | support | 1.0 | 67% | 11 | 0 | 0% |

### Battle groups: gs3-83c8646-p66

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 3.0 | 22% | 100% | 100% | 50% | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p66

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 12 | 15 (12) | 15 | 0 | 21 | 42% | 3.0 | 21 (4) | 6 (6) | 32 (2) | 10 (8) | 21 (4) |
| Mine | Clean-up | 2 | 58 (2) | 0 | 58 | 0 | 100% | - | - | - | 58 (2) | 58 (2) | - |
| Mine | Fast Hammer | 3 | 78 (3) | 0 | 78 | 0 | 0% | 2.3 | 0 (1) | 121 (2) | - | 109 (2) | 0 (1) |
| Mine | Hammer | 7 | 2 (7) | 2 | 0 | 17 | 43% | 1.2 | 0 (1) | 4 (3) | 0 (3) | 0 (5) | 5 (2) |
| Mine | Shooter | 6 | 142 (6) | 17 | 125 | 0 | 0% | 2.0 | 105 (1) | 231 (2) | 96 (3) | 136 (5) | 173 (1) |
| Mine | War machine | 8 | 0 (8) | 0 | 0 | 35 | 0% | 1.1 | 0 (1) | 0 (4) | 0 (3) | - | 0 (8) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 5.0 | - | 0 (2) | - | 0 (2) | - |
| Opponent | Chaff | 11 | 321 (11) | 154 | 167 | 34 | 55% | 2.8 | 142 (3) | 390 (1) | 384 (7) | 321 (11) | - |
| Opponent | Character | 6 | 0 (6) | 0 | 0 | 0 | 0% | 2.2 | 0 (2) | 0 (2) | 0 (2) | 0 (2) | 0 (4) |
| Opponent | Clean-up | 4 | 41 (4) | 0 | 41 | 49 | 25% | 1.7 | - | 84 (2) | 0 (2) | 55 (3) | 0 (1) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Opponent | Hammer | 10 | 14 (10) | 14 | 0 | 16 | 50% | 1.4 | 0 (4) | 29 (4) | 0 (2) | 0 (2) | 18 (8) |
| Opponent | Holder | 1 | 59 (1) | 0 | 59 | 0 | 100% | - | - | 59 (1) | - | - | 59 (1) |
| Opponent | Shooter | 1 | 112 (1) | 0 | 112 | 0 | 0% | 1.0 | - | 112 (1) | - | 112 (1) | - |

### Charged fights: gs3-83c8646-p66

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 96 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Mine | Grand Cathay | 1 | 0 | 215 | 3.0 | 1.0 | 72 | 123 | -51 | 0 of 3 | 3 of 3 | - | -51 |
| **Mine** | all armies | 3 | 64 | 72 | 1.3 | 1.0 | 54 | 92 | -38 | 0 of 4 | 4 of 4 | - | -38 |
| Opponent | Ogre Kingdoms | 1 | 265 | 375 | 2.0 | 1.0 | 188 | 0 | +188 | 0 of 2 | 0 of 2 | - | +188 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| **Opponent** | all armies | 3 | 88 | 125 | 1.3 | 1.0 | 94 | 0 | +94 | 1 of 4 | 2 of 4 | - | +94 |

### Effective charges: gs3-83c8646-p66

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Mine | Grand Cathay | 3 | 0 | 0 | 0 | 0 | 1 (net +45) | 0 | 2 | 0% (0 of 1) |
| Opponent | Ogre Kingdoms | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Vampire Counts | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: gs3-83c8646-p66

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 265 | 109 | +0 | 264 | 0 | +264 | +99.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 205 | 45 | +45 | 45 | 0 | +45 | +22.0 |
| Mine | No odds | 2 | 369 | 85 | -100 | 85 | 184 | -100 | -27.0 |
| Mine | All fights | 4 | 302 | 81 | -38 | 120 | 92 | +27 | +9.1 |
| Opponent | Long shot (under 50%) | 1 | 90 | 104 | +0 | 40 | 36 | +4 | +4.4 |
| Opponent | 76-89% | 2 | 304 | 154 | +0 | 121 | 43 | +79 | +25.9 |
| Opponent | No odds | 1 | 34 | 125 | +375 | 375 | 8 | +366 | +1077.9 |
| Opponent | All fights | 4 | 183 | 134 | +94 | 164 | 33 | +132 | +72.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p66 | move | 12 | 2 (17%) | 2 (17%) | 1 (8%) | 9 (75%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0934, L1026 |
| Fistful of Laurels | Opponent | L0918 |
| Ring of Jet | Mine | L1026 |
| Twice-Blessed Armour | Mine | L1026 |

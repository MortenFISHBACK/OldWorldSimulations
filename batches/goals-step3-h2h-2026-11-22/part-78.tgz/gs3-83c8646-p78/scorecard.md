# Doctrine scorecard: gs3-83c8646-p78

### Scorecard: gs3-83c8646-p78

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0922 | 4 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 367 |
| L0922 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 1 | 0 | 0 | 0 |
| L1013 | 5 | 1 | Mine | yes | - | 5 | 2 | 1 | 0 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | no | - | - | 0 | 2 | 0 | 0 | 0 | 482 |
| L1030 | 4 | 1 | Mine | no | 2 | 3 | 6 | 0 | 0 | 0 | 0 | 165 |
| L1030 | 4 | 1 | Opponent | no | 5 | 6 | 0 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 1.0 | 4.0 | 2.7 | 0.3 | 0.0 | 0.0 | 0.0 | 287.3 |
| **Average** | | | Opponent | 0% | 2.5 | 4.0 | 1.3 | 2.0 | 0.3 | 0.0 | 0.0 | 160.7 |

### KPIs: gs3-83c8646-p78

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 29% (4 of 14) | 0% (0 of 15) | 14% (4 of 29) |
| Winner chose to follow up after the loser gave ground |  | 50% (1 of 2); on the table 100% | 100% (1 of 1); on the table 100% | 67% (2 of 3); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 67% (2 of 3); on the table 67% | 0% (0 of 1); on the table 0% | 50% (2 of 4); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 67% (4 of 6); on the table 83% | 50% (1 of 2); on the table 50% | 62% (5 of 8); on the table 75% |
| Magic missiles tried each own turn | 50%+ | 42% (28 of 66) | 0% (0 of 6) | 39% (28 of 72) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 53% (28 of 53) | 0% (0 of 6) | 47% (28 of 59) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 67% (4018 of 5997) | 72% (4312 of 6000) | 69% (8330 of 11997) |
|   infantry points that never fought | lower | 80% (843 of 1052) | 57% (746 of 1299) | 68% (1589 of 2351) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 69% (22 of 32) | 74% (14 of 19) | 71% (36 of 51) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 5.0 uses a game | 100% (1 of 1); 0.7 uses a game | 100% (5 of 5); 2.8 uses a game |
| Bound items with another spell used |  | 0% (0 of 2); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 4); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (1 of 2); 0.3 uses a game | 100% (1 of 1); 0.3 uses a game | 67% (2 of 3); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 61% (3550 of 5832) | 71% (3481 of 4916) | 65% (7031 of 10748) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 5.3 (42%) | 2.0 (100%) | 7.3 (50%) |
| MARCHED: its unit marched | 3.0 (24%) | 0.0 (0%) | 3.0 (20%) |
| IN COMBAT: engaged in combat | 3.3 (26%) | 0.0 (0%) | 3.3 (23%) |
| OFF THE TABLE: off the table or not arrived | 1.0 (8%) | 0.0 (0%) | 1.0 (7%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 6.3 | 2.0 | 9.3 | 2.0 | 1.7 |
| not cast | 0.0 | 3.7 | 0.0 | 14.7 | 4.0 | 22.3 |
| NOT CHOSEN: could have been cast at a target | - | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 1.0 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | - | 3.3 (91%) | - | 7.3 (50%) | 0.7 (17%) | 0.0 (0%) |
| MARCHED: its unit marched | - | 0.0 (0%) | - | 3.0 (20%) | 1.0 (25%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | - | 0.3 (9%) | - | 3.3 (23%) | 1.0 (25%) | 0.0 (0%) |
| OFF THE TABLE: off the table or not arrived | - | 0.0 (0%) | - | 1.0 (7%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | - | 0.0 (0%) | - | 0.0 (0%) | 1.3 (33%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | - | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 21.3 (96%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 2.0 a game | 1.0 a game |
| stood (cast and not dispelled) | - | 83% (5 of 6) | 83% (5 of 6) |
| the unit moved after it | - | 40% (2 of 5) | 40% (2 of 5) |
| it charged on its next turn | - | 0% (0 of 5) | 0% (0 of 5) |
| the enemy charged it first | - | 0% (0 of 5) | 0% (0 of 5) |
| it fought by the end of its next turn | - | 0% (0 of 5) | 0% (0 of 5) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 5) | 0% (0 of 5) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (5 of 5) | 100% (5 of 5) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 77% (67 of 87) | 60% (50 of 83) | 69% (117 of 170) |
|   cavalry | - | 78% (7 of 9) | 78% (7 of 9) |
|   character | 100% (4 of 4) | 30% (6 of 20) | 42% (10 of 24) |
|   chariot | 94% (16 of 17) | 50% (3 of 6) | 83% (19 of 23) |
|   infantry | 65% (15 of 23) | 63% (24 of 38) | 64% (39 of 61) |
|   monster | 50% (3 of 6) | - | 50% (3 of 6) |
|   war machine | 78% (29 of 37) | 100% (10 of 10) | 83% (39 of 47) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.0 (15%) | 1.3 (12%) | 2.3 (13%) |
| CHARGED: it charged | 0.0 (0%) | 1.7 (15%) | 1.7 (9%) |
| IN COMBAT: it fought this turn or the last | 0.3 (5%) | 0.0 (0%) | 0.3 (2%) |
| MOVED: a war machine that moved | 0.7 (10%) | 0.0 (0%) | 0.7 (4%) |
| NO TARGET IN RANGE | 2.0 (30%) | 5.0 (45%) | 7.0 (40%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 1.3 (12%) | 1.3 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (15%) | 1.7 (15%) | 2.7 (15%) |
| SHELTERED: the target was sheltered | 0.3 (5%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR | 1.3 (20%) | 0.0 (0%) | 1.3 (8%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.3 | 1.0 | 77% | 2.6 pts | 11 pts |
| character | 4.3 | 1.0 | 77% | 10.6 pts | 46 pts |
| chariot | 6.3 | 3.7 | 63% | 13.2 pts | 84 pts |
| infantry | 15.3 | 8.0 | 70% | 11.3 pts | 173 pts |
| monster | 1.3 | 1.0 | 50% | 10.6 pts | 14 pts |
| war machine | 13.3 | 10.3 | 68% | 24.7 pts | 329 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.7 | 2.3 | 2.5 |
| Charges that made contact a game | 2.3 | 1.3 | 1.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.17 declared, 1.17 contact (6 units) | 0.00 declared, 0.00 contact (1 units) | 1.00 declared, 1.00 contact (7 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.07 declared, 0.00 contact (15 units) | 0.29 declared, 0.17 contact (24 units) | 0.21 declared, 0.10 contact (39 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 86% (6 of 7) | - | - | 86% (6 of 7) |
| Character in a unit | 100% (3 of 3) | 100% (2 of 2) | - | 100% (5 of 5) |
| Character on its own | 100% (1 of 1) | 33% (2 of 6) | 50% (3 of 6) | 46% (6 of 13) |
| Chariot | 100% (2 of 2) | 100% (1 of 1) | - | 100% (3 of 3) |
| Infantry | 50% (5 of 10) | 50% (1 of 2) | - | 50% (6 of 12) |
| Monster | 50% (1 of 2) | 100% (1 of 1) | - | 67% (2 of 3) |
| Monstrous | - | 100% (1 of 1) | - | 100% (1 of 1) |
| War Machines | 100% (7 of 7) | - | - | 100% (7 of 7) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 1 | 0% (0 of 1); on the table 100% | 50% (6 of 12) | 55% | 75% (9 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 2 | 80% (4 of 5); on the table 80% | 41% (22 of 54) | 73% | 65% (13 of 20) | 100% (4 of 4); 7.5 uses a game | 0% (0 of 2); 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| High Elf Realms | 1 | - | 0% (0 of 6) | 88% | 88% (7 of 8) | 100% (1 of 1); 2.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 50% (1 of 2); on the table 50% | - | 48% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | - | - | 79% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p78, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 67% (2) | 71% (5) | 70% (7) |
| ...free all their last turn and able to turn (per game) | 0.67 | 1.33 | 2.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.67 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p78

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 86% (6 of 7) | 50% (3 of 6) |
| Strategy | Shoot objectives carried out (shot that target) | 24% (13 of 55) | 45% (15 of 33) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 67% (4 of 6) | - |
| Strategy | Joined characters whose unit fought | 25% (1 of 4) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 56% (5 of 9) | 33% (2 of 6) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 0.3 | 2.0 |
| Movement | Points that never moved of their own | 287.3 | 160.7 |
| Movement | Fights charged into per game | 2.3 | 1.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 5 | 1 of 3, net -135 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 5 | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 5, net +0 | 0 of 3 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 5, net +50 | 2 of 3, net +114 |
| Shooting | Shots by shooting units (incl. breath weapons) | 13.3 | 16.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 55% (22 of 40) | 69% (34 of 49) |
| Shooting | Points destroyed by shooting units | 24.0 | 55.0 |
| Shooting | War machine shots | 9.7 | 3.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 72% (21 of 29) | 70% (7 of 10) |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 6.7 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 20% (4 of 20) | - |
| Magic | Wounds caused by magic missiles | 6.3 | - |
| Magic | Wounds caused by other spells | 5.0 | - |
| Magic | Points destroyed by magic (all spells) | 257.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 2.0 / 1.3 / 0.7 | 2.7 / 1.3 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 158.3 | 95.7 |
| Combat | Points run down | 81.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +94 | +63 |
| Combat | Net per 100 charger points, damage counted | +36.2 | +17.1 |
| Combat | First round won (charged fights) | 86% | 75% |
| Combat | Net points per charged fight | +86 | +23 |
| Combat | Net points per supported fight / lone fight | - / +86 | - / +23 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 7 | 4 of 4 |
| Game | Points lost | 327.7 | 497.3 |
| Game | VP from objectives | 660.0 | 450.0 |
| Game | Lone holders (player turns) | 1.0 | 2.5 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +446 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 825
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p78

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +44.9 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH WITH FRIENDS | 0.3 | +32.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 15.3 | +588.9 | 0.0 | 302.7 | 26.3 | +239.9 | 0.0 | 88.7 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +1.0 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 7.0 | +0.0 | 0.0 | 165.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 48.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 9.7 | +74.0 | 490.0 | 165.0 | 3.3 | +19.0 | 0.0 | 23.3 |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 55.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 9.0 | +221.1 | 566.0 | 126.0 | 0.7 | +10.6 | 0.0 | 108.0 |
| CASTER AWAY FROM SCREEN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +40.4 | 0.0 | 0.0 | 0.3 | +8.7 | 0.0 | 57.7 |
| CHARACTER GUNS | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 13.0 | -399.4 | 0.0 | 0.0 | 28.7 | -984.7 | 0.0 | 546.7 |
| CHARGE NOW FIRST | 2.7 | +0.0 | 165.3 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 8.0 | +0.0 | 0.0 | 0.0 | 8.7 | +0.0 | 0.0 | 23.3 |
| COMBAT PIVOT | 0.7 | +0.0 | 57.7 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | - | - | - | - | 1.3 | +84.0 | 0.0 | 0.0 |
| COVER ONCE | 8.3 | -332.5 | 0.0 | 63.0 | 10.0 | -739.7 | 0.0 | 224.7 |
| DENIED BY THE FIGHT | 0.3 | -0.2 | 57.7 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 7.7 | -128.5 | 0.0 | 55.0 | 7.3 | +67.2 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -14.1 | 63.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 0.3 | +57.0 | 0.0 | 0.0 |
| EXACT ROUND | 1.7 | +6.3 | 233.7 | 0.0 | 1.7 | +77.4 | 130.7 | 65.0 |
| FALL BACK GOOD ORDER | 2.0 | +0.4 | 352.0 | 0.0 | 1.7 | +36.8 | 193.7 | 65.0 |
| FALLS SHORT | - | - | - | - | 21.3 | +101.2 | 0.0 | 372.7 |
| FEATURE BUFFS | 1.3 | +14.1 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 1.7 | +12.0 | 258.7 | 0.0 | 0.7 | +13.2 | 63.0 | 0.0 |
| FIVE ACTION | 102.7 | +4943.1 | 2339.3 | 884.7 | 96.7 | +5163.0 | 455.0 | 861.0 |
| FLANK NOT WEIGHED | 3.3 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 56.0 |
| FOLLOW UP WEIGHED | 0.7 | +111.1 | 0.0 | 0.0 | 0.7 | +120.0 | 0.0 | 0.0 |
| FOOT FIRST | 18.0 | +0.0 | 0.0 | 165.0 | - | - | - | - |
| FOUR ROUNDS | 2.7 | +135.2 | 384.7 | 0.0 | 2.3 | +316.6 | 193.7 | 65.0 |
| FREED FROM HIS FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 2.0 | -19.6 | 23.3 | 0.0 | 1.7 | -26.7 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.3 | +16.8 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | - | - | - | - | 0.3 | -17.5 | 63.0 | 0.0 |
| GOAL ON TIME | 1.0 | +46.3 | 0.0 | 0.0 | - | - | - | - |
| GOAL ROUTE | 1.7 | +83.6 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 9.3 | +497.9 | 0.0 | 0.0 | 8.3 | +963.2 | 0.0 | 0.0 |
| GUN FIGURES | 1.7 | +79.5 | 0.0 | 0.0 | - | - | - | - |
| GUN MASK | 1.0 | +49.5 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HARD STAY DROPPED | 4.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 180.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 6.7 | +0.0 | 0.0 | 0.0 | 14.0 | +0.0 | 0.0 | 546.7 |
| HIS CHARGE DENIED | 0.7 | +25.9 | 57.7 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 8.3 | +0.0 | 0.0 | 0.0 | 10.7 | +0.0 | 0.0 | 186.7 |
| HIS LEGAL MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 294.7 |
| HIS MOVE AND SHOT | 2.7 | -66.1 | 0.0 | 0.0 | 13.7 | -252.3 | 0.0 | 0.0 |
| HIS ONE QUARTER | 7.7 | +0.0 | 0.0 | 75.7 | 1.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 4.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 294.7 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 39.0 | +1204.1 | 0.0 | 428.7 | 63.0 | +4628.1 | 0.0 | 641.3 |
| HIS SHOTS BY HIS RUN | 34.7 | +859.8 | 0.0 | 428.7 | 45.7 | +777.4 | 0.0 | 641.3 |
| HIS TURN DENIED | - | - | - | - | 1.0 | +70.8 | 0.0 | 65.0 |
| HOLD ODDS | 9.3 | +0.0 | 0.0 | 126.0 | 7.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 6.0 | +524.2 | 0.0 | 126.0 | 4.7 | +555.5 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.7 | -94.4 | 384.7 | 0.0 | 2.0 | -125.3 | 193.7 | 0.0 |
| HUNT IN PAIRS | 0.7 | +23.3 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | - | - | - | - | 19.7 | -380.0 | 0.0 | 194.7 |
| JOINT CHARGE NOW | 0.7 | -20.2 | 93.3 | 0.0 | - | - | - | - |
| KEEP FALLS | 0.3 | +6.6 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +28.4 | 0.0 | 0.0 | 1.3 | +65.6 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 0.7 | +0.0 | 122.7 | 0.0 | 3.3 | +0.0 | 0.0 | 387.3 |
| LONE WIZARD KEPT IN | 0.7 | +10.0 | 0.0 | 0.0 | 0.7 | +48.3 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.7 | -28.6 | 294.3 | 0.0 | - | - | - | - |
| MANOEUVRE | 0.3 | -9.8 | 0.0 | 0.0 | 1.7 | +8.7 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.7 | +6.9 | 0.0 | 0.0 | 0.3 | +5.3 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +52.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.7 | +11.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH ODDS | 0.3 | +7.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 1.7 | +72.4 | 0.0 | 0.0 | 0.3 | +27.9 | 0.0 | 0.0 |
| MARCH OVER CASTS | 1.0 | -65.7 | 0.0 | 0.0 | 0.3 | -24.1 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.3 | +85.3 | 0.0 | 63.0 | - | - | - | - |
| MEETS IN TIME | 2.7 | +167.4 | 0.0 | 0.0 | 2.0 | +137.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 13.0 | +274.7 | 0.0 | 126.0 | 1.0 | +12.7 | 0.0 | 54.0 |
| MISSILES NEXT TURN | 16.7 | +249.0 | 0.0 | 126.0 | 1.7 | +11.7 | 0.0 | 54.0 |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 2.3 | +123.3 | 0.0 | 0.0 | 3.0 | +209.0 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 2.7 | +124.2 | 0.0 | 0.0 | 1.7 | +89.0 | 0.0 | 0.0 |
| NEAREST TO GOAL | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 2.3 | +117.3 | 46.7 | 0.0 | 2.3 | +116.1 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.0 | -81.8 | 233.7 | 0.0 | 2.0 | -148.2 | 130.7 | 65.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 3.0 | -212.5 | 0.0 | 0.0 | 4.0 | -212.4 | 0.0 | 0.0 |
| OGRE LOADER SECOND SHOT | 6.0 | +44.3 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 6.0 | -100.9 | 0.0 | 0.0 | 5.3 | -126.3 | 0.0 | 93.3 |
| ONE OBJECTIVE FORMULA | 3.0 | +16.0 | 0.0 | 63.0 | 1.7 | +4.1 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.7 | -14.2 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 1.3 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | 0.3 | +15.6 | 32.7 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.7 | +4.3 | 57.7 | 0.0 | 0.7 | +1.6 | 63.0 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PLAN RESULT | 44.7 | +1406.0 | 833.0 | 387.3 | 43.0 | +510.7 | 227.0 | 863.0 |
| PROMISE BY ITS OWN SUM | 7.0 | -153.7 | 0.0 | 0.0 | 3.3 | -92.9 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.7 | +0.0 | 23.3 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.0 | -15.5 | 46.7 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 1.7 | -36.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | - | - | - | - | 1.0 | -18.0 | 0.0 | 0.0 |
| QUARTER ODDS | 29.3 | +2414.1 | 823.0 | 522.7 | 25.0 | +2384.1 | 282.0 | 65.3 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.3 | -16.9 | 0.0 | 0.0 | 0.7 | -3.5 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 1.3 | +47.9 | 0.0 | 0.0 |
| RISK BY ARC | 2.0 | +47.6 | 325.3 | 0.0 | 1.3 | -100.0 | 63.0 | 65.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.7 | -43.4 | 118.0 | 65.0 |
| RUN DOWN | 2.7 | -17.0 | 384.7 | 0.0 | 0.7 | -1.0 | 63.0 | 0.0 |
| SAME CHARGE LATER | 0.3 | -5.6 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +2.2 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +36.9 | 0.0 | 0.0 | 1.0 | +4.2 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +29.2 | 57.7 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 1.3 | -99.1 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 1.3 | +117.3 | 0.0 | 0.0 | 2.0 | -21.8 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.7 | 0.0 | 0.0 | 0.3 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 19.0 | +0.0 | 0.0 | 228.0 | 11.0 | +0.0 | 0.0 | 77.3 |
| SHOOTS FROM THE BEST SPOT | 1.7 | +85.8 | 32.7 | 0.0 | 7.3 | +137.9 | 151.3 | 0.0 |
| SHOT OR CHARGE | 0.3 | -3.6 | 93.3 | 0.0 | 1.0 | -4.0 | 0.0 | 0.0 |
| SHOT RISK POINTS | 17.7 | -82.6 | 0.0 | 302.7 | 37.7 | -396.5 | 0.0 | 546.7 |
| SHOTS AFTER THE MOVES | 5.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 23.0 | +824.7 | 0.0 | 228.0 | 17.7 | +649.9 | 0.0 | 101.3 |
| SPELL WORTH | - | - | - | - | 2.0 | +32.9 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | +18.3 | 93.3 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 3.7 | +0.0 | 0.0 | 75.7 | 5.0 | +0.0 | 0.0 | 84.3 |
| STANDS FOR A REASON | - | - | - | - | 7.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 53.3 | +0.0 | 1954.7 | 456.0 | 41.3 | +0.0 | 261.3 | 514.7 |
| STAY WORTH | 41.3 | -259.2 | 1344.7 | 330.0 | 27.3 | +288.8 | 110.0 | 0.0 |
| STRIKE BY THE ODDS | - | - | - | - | 1.0 | +51.0 | 20.0 | 195.0 |
| SUPPORT ADDS | 0.7 | +8.3 | 0.0 | 0.0 | 3.7 | +221.3 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.7 | +0.0 | 23.3 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 0.7 | +8.3 | 0.0 | 0.0 | 3.7 | +221.3 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.7 | +0.5 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -24.9 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 3.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 3.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 3.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 48.0 | +0.0 | 0.0 | 442.3 | 47.0 | +0.0 | 0.0 | 398.0 |
| TIED UP BY THE SUM | 1.3 | +129.6 | 165.3 | 0.0 | 0.3 | +65.6 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 37.3 | +515.8 | 0.0 | 126.0 | - | - | - | - |
| WAITS AGAIN | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WEAPON BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 0.7 | -51.5 | 115.3 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.7 | -3.1 | 84.3 | 0.0 | 0.3 | +14.9 | 0.0 | 65.0 |
| WHOLE FIGHT | 0.3 | +1.0 | 57.7 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 1.7 | -103.4 | 0.0 | 0.0 | 2.7 | -133.1 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | 0.3 | +27.6 | 93.3 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 0.7 | +7.0 | 0.0 | 0.0 | 1.0 | +17.2 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p78

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 306 | 304 | 86 | 28.67 | +1960 | +22.8 |
| ARMY TABLE | 125 | 125 | 74 | 24.67 | +2268 | +30.6 |
| HIS SHOTS BY HIS RUN | 241 | 240 | 41 | 13.67 | +737 | +18.0 |
| HOLDER ASSIGNMENT | 32 | 32 | 29 | 9.67 | +1029 | +35.5 |
| QUARTER ODDS | 163 | 162 | 29 | 9.67 | +2135 | +73.6 |
| DEPLOY BY FIGURES | 45 | 45 | 28 | 9.33 | +346 | +12.3 |
| GOAL WALK | 53 | 53 | 25 | 8.33 | +2082 | +83.3 |
| HARD STAY DROPPED | 24 | 24 | 24 | 8.00 | +0 | +0.0 |
| CAST JOB | 29 | 29 | 23 | 7.67 | +283 | +12.3 |
| ARTILLERY RE-ROLL WEIGHED | 21 | 21 | 21 | 7.00 | +0 | +0.0 |
| FIVE ACTION | 598 | 589 | 21 | 7.00 | +1054 | +50.2 |
| OFF BEST | 21 | 21 | 21 | 7.00 | -1275 | -60.7 |
| SHOT RISK POINTS | 166 | 166 | 20 | 6.67 | +548 | +27.4 |
| THE TABLE AGAIN | 36 | 36 | 19 | 6.33 | +0 | +0.0 |
| OGRE LOADER SECOND SHOT | 18 | 18 | 18 | 6.00 | +133 | +7.4 |
| IDLE COST | 59 | 45 | 15 | 5.00 | +251 | +16.7 |
| TIME ON OUR SIDE | 112 | 96 | 13 | 4.33 | +91 | +7.0 |
| CHARGE LOSSES | 125 | 125 | 12 | 4.00 | +511 | +42.6 |
| LEGAL CHARGES ONLY | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 31 | 31 | 12 | 4.00 | -740 | -61.7 |
| SHOOTS FROM THE BEST SPOT | 27 | 27 | 11 | 3.67 | +180 | +16.4 |
| COVER ONCE | 55 | 42 | 10 | 3.33 | +207 | +20.7 |
| MOVE TO CHARGE COMPUTED | 16 | 12 | 9 | 3.00 | +356 | +39.6 |
| ADVANCE LANE KEPT | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| FOUR ROUNDS | 15 | 14 | 8 | 2.67 | +473 | +59.1 |
| LANE BY FIGURES | 8 | 8 | 8 | 2.67 | +282 | +35.2 |
| NEXT CHARGE BY LIST | 14 | 14 | 8 | 2.67 | +92 | +11.5 |
| STAY WORTH | 206 | 181 | 8 | 2.67 | +196 | +24.4 |
| MEETS IN TIME | 14 | 14 | 7 | 2.33 | +90 | +12.9 |
| MOVE ORDER | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| SET UP BY THE SET | 10 | 10 | 7 | 2.33 | +402 | +57.4 |
| CANNON SIGHT KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| MARCH OF THE TABLE | 6 | 6 | 6 | 2.00 | -301 | -50.1 |
| SHOTS IN THE MOVE | 122 | 85 | 6 | 2.00 | +322 | +53.7 |
| GOAL ROUTE | 5 | 5 | 5 | 1.67 | +251 | +50.2 |
| SEARCH SPOT | 5 | 5 | 5 | 1.67 | +124 | +24.7 |
| EXACT ROUND | 10 | 9 | 4 | 1.33 | +39 | +9.8 |
| FALLS SHORT | 64 | 49 | 4 | 1.33 | +20 | +5.0 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +693 | +173.3 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +175 | +43.8 |
| MAX FOR POSITIONING | 13 | 12 | 4 | 1.33 | +48 | +12.1 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +144 | +35.9 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| TIED UP BY THE SUM | 5 | 4 | 4 | 1.33 | +196 | +49.0 |
| CANNON PLANNED TARGET | 39 | 39 | 3 | 1.00 | +0 | +0.0 |
| CHARGE NOW FIRST | 11 | 11 | 3 | 1.00 | -28 | -9.5 |
| GOAL ON TIME | 3 | 3 | 3 | 1.00 | -8 | -2.8 |
| MISSILES IN THE MOVE | 42 | 26 | 3 | 1.00 | +69 | +22.9 |
| PROMISE KNOWS THE FIGHT | 3 | 3 | 3 | 1.00 | -46 | -15.4 |
| PROMISE SHOT AWAY | 3 | 3 | 3 | 1.00 | -54 | -17.9 |
| REDIRECT FOR A FRIEND IN REACH | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 29 | 29 | 3 | 1.00 | +0 | +0.0 |
| STRIKE BY THE ODDS | 3 | 3 | 3 | 1.00 | +100 | +33.2 |
| WHOLE FIGHT DANGER | 13 | 13 | 3 | 1.00 | +88 | +29.4 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +147 | +73.7 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FEATURE BUFFS | 4 | 4 | 2 | 0.67 | +8 | +3.8 |
| HIS TURN DENIED | 3 | 3 | 2 | 0.67 | +150 | +75.0 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | -60 | -30.2 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +157 | +78.6 |
| ONE FIGHT FORMULA | 34 | 22 | 2 | 0.67 | +14 | +6.9 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -43 | -21.3 |
| RISK BY ARC | 10 | 9 | 2 | 0.67 | +113 | +56.4 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +6 | +3.0 |
| THE ROW IN ITS ORDER | 18 | 2 | 2 | 0.67 | +0 | +0.0 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +135 | +134.6 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +96 | +96.0 |
| EVASIVE BY THE ODDS | 1 | 1 | 1 | 0.33 | +171 | +170.9 |
| FALL BACK GOOD ORDER | 11 | 10 | 1 | 0.33 | +56 | +55.9 |
| FRIEND SHOOTS FIRST | 11 | 11 | 1 | 0.33 | +1 | +0.6 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +50 | +50.5 |
| HONEST WORTH | 14 | 13 | 1 | 0.33 | +124 | +123.6 |
| HUNT IN PAIRS | 2 | 1 | 1 | 0.33 | +34 | +34.1 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +28 | +27.6 |
| MANOEUVRE | 6 | 6 | 1 | 0.33 | +26 | +26.2 |
| MARCH CHECK | 2 | 1 | 1 | 0.33 | +26 | +26.0 |
| MARCH ODDS | 1 | 1 | 1 | 0.33 | -12 | -11.5 |
| MISSILES NEXT TURN | 55 | 38 | 1 | 0.33 | +9 | +9.4 |
| NO DOUBLE ROUNDS | 12 | 12 | 1 | 0.33 | +1 | +0.8 |
| OPENS A LANE | 4 | 2 | 1 | 0.33 | +0 | +0.0 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +278 | +278.3 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +88 | +87.7 |
| WAR ENGINE JOBS | 3 | 3 | 1 | 0.33 | -14 | -13.8 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 3 | 2 | 1 | 0.33 | +26 | +26.4 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 5 | trace | - | - | - | - |
| CHARACTER GUNS | 4 | 4 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 50 | 50 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 4 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 7 | 6 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 29 | not checked | - | - | - | - |
| FOOT FIRST | 54 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 14 | 14 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 5 | not checked | - | - | - | - |
| GUN MASK | 7 | 7 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 8 | 8 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 62 | 62 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 57 | 57 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 22 | 22 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 49 | 49 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 28 | 28 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 29 | 25 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 50 | 50 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 4 | 4 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 5 | 4 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 5 | not checked | - | - | - | - |
| NEARER NOT NEEDED | 13 | 13 | 0 | 0.00 | - | - |
| NEAREST TO GOAL | 1 | 1 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 14 | 8 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 4 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 263 | trace | - | - | - | - |
| PROMISE IN STEPS | 6 | 6 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 5 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 3 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 5 | 5 | 0 | 0.00 | - | - |
| RUN DOWN | 10 | 9 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 90 | not checked | - | - | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL WORTH | 6 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 26 | 21 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 23 | 23 | 0 | 0.00 | - | - |
| STANDS STILL | 284 | 280 | 0 | 0.00 | - | - |
| SUPPORT ADDS | 13 | 13 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 2 | 2 | 0 | 0.00 | - | - |
| SUPPORT WORKED OUT | 13 | 13 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 2 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 24 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 17 | not checked | - | - | - | - |
| THE TABLE BINDS | 285 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 4 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | not checked | - | - | - | - |
| WHOLE FIGHT | 1 | not checked | - | - | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 5 | 5 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p78

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.67 | 4.00 | 63.6 |
| PROMISE BY ITS OWN SUM | rule | 3.33 | 0.67 | 61.7 |
| ARMY TABLE | rule | - | 3.33 | 79.2 |
| MARCH OF THE TABLE | rule | 1.67 | 0.33 | 50.1 |
| CHARGE NOW FIRST | rule | 0.67 | 0.33 | 9.5 |
| GOAL ON TIME | rule | 1.00 | - | 2.8 |
| PROMISE KNOWS THE FIGHT | rule | 1.00 | - | 15.4 |
| PROMISE SHOT AWAY | rule | - | 1.00 | 17.9 |
| ONE PROMISE A TARGET | rule | - | 0.67 | 21.3 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 16.9 |
| JOINT CHARGE NOW | rule | 0.33 | - | 82.7 |
| MARCH ODDS | rule | 0.33 | - | 11.5 |
| NO REASON | gate | 0.33 | - | 2.0 |
| WAR ENGINE JOBS | rule | 0.33 | - | 13.8 |

### Plans: gs3-83c8646-p78

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.0 | 67% | 314 | 109 | 35% |
| Mine | join | 0.3 | 100% | 4 | 0 | 0% |
| Mine | move | 26.7 | 100% | 1240 | 0 | 0% |
| Mine | shoot | 15.7 | 72% | 571 | 1297 | 227% |
| Opponent | charge | 1.3 | 50% | 165 | 135 | 82% |
| Opponent | move | 32.0 | 95% | 1544 | 0 | 0% |
| Opponent | shoot | 9.7 | 48% | 641 | 376 | 59% |

### Deployment: positions vs output by unit type: gs3-83c8646-p78

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 13 | 52 (13) | 52 | 0 | 12 | 31% | 2.8 | 134 (2) | 44 (6) | 13 (3) | 77 (7) | 30 (4) |
| Mine | Fast Hammer | 4 | 0 (4) | 0 | 0 | 0 | 25% | 1.3 | 0 (2) | 0 (1) | 0 (1) | 0 (2) | 0 (2) |
| Mine | Hammer | 4 | 39 (4) | 22 | 17 | 47 | 25% | 2.7 | - | 39 (4) | - | 0 (2) | 87 (2) |
| Mine | Holder | 2 | 35 (2) | 0 | 35 | 0 | 100% | - | 0 (1) | 70 (1) | - | 35 (2) | - |
| Mine | Shooter | 5 | 21 (5) | 11 | 9 | 0 | 0% | 2.0 | 35 (2) | 19 (2) | 0 (1) | 25 (4) | 0 (1) |
| Mine | War machine | 7 | 0 (7) | 0 | 0 | 32 | 0% | 1.0 | 0 (1) | 0 (2) | 0 (4) | 0 (3) | 0 (4) |
| Opponent | Chaff | 4 | 10 (4) | 0 | 10 | 50 | 0% | 1.8 | 0 (1) | 42 (1) | 0 (2) | 10 (4) | - |
| Opponent | Character | 8 | 29 (8) | 29 | 0 | 16 | 38% | 1.6 | 15 (3) | 38 (5) | - | 27 (7) | 34 (1) |
| Opponent | Clean-up | 2 | 0 (2) | 0 | 0 | 50 | 50% | 6.0 | 0 (2) | - | - | 0 (2) | - |
| Opponent | Fast Hammer | 6 | 5 (6) | 5 | 0 | 17 | 67% | 3.0 | 0 (3) | 10 (3) | - | 11 (3) | 0 (3) |
| Opponent | Hammer | 2 | 70 (2) | 0 | 70 | 50 | 0% | 2.5 | - | 70 (2) | - | 139 (1) | 0 (1) |
| Opponent | Holder | 6 | 60 (6) | 0 | 60 | 66 | 17% | 2.4 | 0 (2) | 260 (2) | 0 (2) | 200 (3) | 0 (3) |
| Opponent | Shooter | 2 | 49 (2) | 49 | 0 | 48 | 0% | 1.0 | - | 49 (2) | - | 0 (1) | 93 (1) |
| Opponent | War machine | 2 | 0 (2) | 0 | 0 | 50 | 0% | 1.0 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 1.0 | - | 0 (2) | - | - | 0 (2) |

### Charged fights: gs3-83c8646-p78

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 1 | 72 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Grand Cathay | 2 | 386 | 302 | 3.5 | 1.0 | 86 | 0 | +86 | 0 of 7 | 6 of 7 | - | +86 |
| **Mine** | all armies | 3 | 281 | 201 | 2.3 | 1.0 | 86 | 0 | +86 | 0 of 7 | 6 of 7 | - | +86 |
| Opponent | High Elf Realms | 1 | 165 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 287 | 4.0 | 1.0 | 72 | 49 | +23 | 4 of 4 | 3 of 4 | - | +23 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 55 | 96 | 1.3 | 1.0 | 72 | 49 | +23 | 4 of 4 | 3 of 4 | - | +23 |

### Effective charges: gs3-83c8646-p78

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 7 | 0 | 1 (net +280) | 0 | 0 | 1 (net +0) | 3 (net +50) | 2 | 0% (0 of 5) |
| Opponent | Tomb Kings of Khemri | 4 | 1 (net -135) | 0 | 0 | 0 | 0 | 2 (net +114) | 1 | 0% (0 of 3) |

### Charged fights, damage counted: gs3-83c8646-p78

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 50-54% | 1 | 334 | 230 | +280 | 280 | 0 | +280 | +83.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 248 | 108 | +50 | 50 | 0 | +50 | +20.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 334 | 98 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | No odds | 2 | 205 | 202 | +86 | 166 | 51 | +115 | +56.1 |
| Mine | All fights | 7 | 260 | 151 | +86 | 109 | 15 | +94 | +36.2 |
| Opponent | Long shot (under 50%) | 1 | 195 | 209 | -135 | 171 | 195 | -24 | -12.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 421 | 246 | +114 | 190 | 48 | +142 | +33.8 |
| Opponent | No odds | 1 | 431 | 227 | +0 | 0 | 10 | -10 | -2.3 |
| Opponent | All fights | 4 | 367 | 232 | +23 | 138 | 75 | +63 | +17.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p78 | move | 19 | 6 (32%) | 3 (16%) | 4 (21%) | 9 (47%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Ring of Jet | Mine | L1013, L1030 |
| Standard of the Fell Warrior | Opponent | L1013 |
| Twice-Blessed Armour | Mine | L1013, L1030 |

# Doctrine scorecard: gs3-83c8646-p19

### Scorecard: gs3-83c8646-p19

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1118 | 2 | 1 | Mine | - | - | 2 | 1 | 1 | 1 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | - | 0 | 3 | 0 | 0 | 0 | 228 |
| L1135 | 1 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 165 |
| L1135 | 1 | 1 | Opponent | no | 0 | - | 1 | 3 | 0 | 0 | 0 | 298 |
| L1228 | 4 | 1 | Mine | no | 1 | 3 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1228 | 4 | 1 | Opponent | no | 8 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 0.5 | 2.3 | 1.3 | 0.3 | 0.3 | 0.0 | 0.0 | 275.0 |
| **Average** | | | Opponent | 0% | 4.0 | - | 0.3 | 2.3 | 0.0 | 0.0 | 0.0 | 175.3 |

### KPIs: gs3-83c8646-p19

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 14% (2 of 14) | 6% (1 of 18) | 9% (3 of 32) |
| Winner chose to follow up after the loser gave ground |  | - | - | - |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | - | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | 100% (2 of 2); on the table 100% | 67% (2 of 3); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 0% (0 of 2); on the table 0% | 100% (2 of 2); on the table 100% | 50% (2 of 4); on the table 50% |
| Magic missiles tried each own turn | 50%+ | 38% (27 of 72) | 39% (7 of 18) | 38% (34 of 90) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 46% (27 of 59) | 58% (7 of 12) | 48% (34 of 71) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 57% (3405 of 5998) | 39% (2315 of 6000) | 48% (5720 of 11998) |
|   infantry points that never fought | lower | 100% (730 of 730) | 66% (517 of 782) | 82% (1247 of 1512) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 80% (20 of 25) | 69% (18 of 26) | 75% (38 of 51) |
| Bound items with a magic missile used (at least once a game) |  | 71% (5 of 7); 6.3 uses a game | 50% (1 of 2); 1.3 uses a game | 67% (6 of 9); 3.8 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 3); 0.0 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 76% (4281 of 5614) | 64% (3625 of 5644) | 70% (7906 of 11258) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.3 (22%) | 0.0 (0%) | 3.3 (18%) |
| MARCHED: its unit marched | 6.7 (44%) | 0.0 (0%) | 6.7 (36%) |
| CHARGED: its unit charged | 0.7 (4%) | 0.0 (0%) | 0.7 (4%) |
| IN COMBAT: engaged in combat | 3.3 (22%) | 0.0 (0%) | 3.3 (18%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.3 (9%) | 0.3 (2%) |
| FLEEING: fleeing | 1.0 (7%) | 0.0 (0%) | 1.0 (5%) |
| GONE: slain | 0.0 (0%) | 0.3 (9%) | 0.3 (2%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 1.7 (45%) | 1.7 (9%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 1.3 (36%) | 1.3 (7%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 1.0 | 6.3 | 0.3 | 11.3 | 0.3 | 2.0 |
| not cast | 3.0 | 9.7 | 5.7 | 18.7 | 3.7 | 26.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 4.7 (48%) | 0.0 (0%) | 3.3 (18%) | 0.3 (9%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 6.7 (36%) | 1.3 (36%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (4%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.3 (18%) | 0.7 (18%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 1.7 (17%) | 1.7 (29%) | 0.3 (2%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (9%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 2.0 (21%) | 0.0 (0%) | 1.0 (5%) | 1.0 (27%) | 2.7 (10%) |
| GONE: slain | 0.0 (0%) | 0.3 (3%) | 0.3 (6%) | 0.3 (2%) | 0.0 (0%) | 3.3 (13%) |
| OFF THE TABLE: off the table or not arrived | 1.7 (56%) | 0.0 (0%) | 1.7 (29%) | 1.7 (9%) | 0.0 (0%) | 3.3 (13%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (7%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.3 (44%) | 1.0 (10%) | 2.0 (35%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.3 (59%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 0.3 a game | 0.2 a game |
| stood (cast and not dispelled) | - | 100% (1 of 1) | 100% (1 of 1) |
| the unit moved after it | - | 0% (0 of 1) | 0% (0 of 1) |
| it charged on its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| the enemy charged it first | - | 0% (0 of 1) | 0% (0 of 1) |
| it fought by the end of its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 1) | 0% (0 of 1) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (1 of 1) | 100% (1 of 1) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 73% (36 of 49) | 69% (50 of 72) | 71% (86 of 121) |
|   cavalry | - | 83% (10 of 12) | 83% (10 of 12) |
|   character | - | 83% (10 of 12) | 83% (10 of 12) |
|   chariot | 62% (5 of 8) | 100% (11 of 11) | 84% (16 of 19) |
|   infantry | 50% (6 of 12) | 37% (10 of 27) | 41% (16 of 39) |
|   monster | - | 90% (9 of 10) | 90% (9 of 10) |
|   war machine | 86% (25 of 29) | - | 86% (25 of 29) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (62%) | 2.3 (32%) | 5.0 (43%) |
| CHARGED: it charged | 0.3 (8%) | 0.0 (0%) | 0.3 (3%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.3 (5%) | 0.3 (3%) |
| MOVED: a war machine that moved | 0.3 (8%) | 0.0 (0%) | 0.3 (3%) |
| NO TARGET IN RANGE | 0.0 (0%) | 2.7 (36%) | 2.7 (23%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (5%) | 0.3 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 1.7 (23%) | 1.7 (14%) |
| SHELTERED: the target was sheltered | 0.7 (15%) | 0.0 (0%) | 0.7 (6%) |
| OTHER BAR | 0.3 (8%) | 0.0 (0%) | 0.3 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.0 | 0.3 | 92% | 0.4 pts | 2 pts |
| character | 3.3 | 1.3 | 80% | 18.8 pts | 63 pts |
| chariot | 5.3 | 3.0 | 81% | 26.6 pts | 142 pts |
| infantry | 7.0 | 0.3 | 95% | 1.9 pts | 13 pts |
| monster | 3.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 9.3 | 7.0 | 54% | 20.4 pts | 190 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 0.3 | 1.7 |
| Charges that made contact a game | 2.7 | 0.3 | 1.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.17 declared, 1.00 contact (6 units) | - | 1.17 declared, 1.00 contact (6 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 1.00 contact (1 units) | - | 1.00 declared, 1.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.11 declared, 0.11 contact (9 units) | 0.04 declared, 0.04 contact (26 units) | 0.06 declared, 0.06 contact (35 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (4 of 6) | - | 50% (2 of 4) | 60% (6 of 10) |
| Character in a unit | 100% (3 of 3) | 0% (0 of 2) | 100% (1 of 1) | 67% (4 of 6) |
| Character on its own | - | 75% (6 of 8) | 50% (2 of 4) | 67% (8 of 12) |
| Chariot | 75% (3 of 4) | - | - | 75% (3 of 4) |
| Infantry | 75% (6 of 8) | - | - | 75% (6 of 8) |
| Monster | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Monstrous | 100% (2 of 2) | 100% (2 of 2) | - | 100% (4 of 4) |
| War Machines | 100% (6 of 6) | - | - | 100% (6 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 3 | 0% (0 of 2); on the table 0% | 38% (27 of 72) | 57% | 80% (20 of 25) | 71% (5 of 7); 6.3 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 48% | 71% (5 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (2 of 2); on the table 100% | 100% (6 of 6) | 8% | 29% (2 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | 17% (1 of 6) | 60% | 92% (11 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p19, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (1) | 0% (0) | 33% (1) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.00 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p19

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 1.0 |
| Strategy | Charge objectives carried out (made contact) | 88% (7 of 8) | 100% (1 of 1) |
| Strategy | Shoot objectives carried out (shot that target) | 47% (21 of 45) | 65% (15 of 23) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 33% (2 of 6) | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 25% (1 of 4) | 100% (4 of 4) |
| Strategy | Lone characters that fought | 75% (6 of 8) | 50% (2 of 4) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.3 | 2.3 |
| Movement | Points that never moved of their own | 275.0 | 175.3 |
| Movement | Fights charged into per game | 2.3 | 0.3 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 6, net -292 | 1 of 1, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 6, net +532 | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 6 | 0 of 1 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 6, net +79 | 0 of 1 |
| Shooting | Shots by shooting units (incl. breath weapons) | 3.7 | 16.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 11) | 60% (30 of 50) |
| Shooting | Points destroyed by shooting units | 0.0 | 132.7 |
| Shooting | War machine shots | 8.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 40% (10 of 25) | - |
| Shooting | Points destroyed by war machines | 0.0 | 55.0 |
| Magic | Magic missiles cast | 6.7 | 1.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 15% (3 of 20) | 40% (2 of 5) |
| Magic | Wounds caused by magic missiles | 11.3 | 0.7 |
| Magic | Wounds caused by other spells | 0.7 | - |
| Magic | Points destroyed by magic (all spells) | 86.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.3 / 2.0 / 0.3 / 0.0 | 0.3 / 0.3 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 162.0 | 118.3 |
| Combat | Points run down | 250.7 | 126.3 |
| Combat | Net points per charged fight, damage counted | +67 | +48 |
| Combat | Net per 100 charger points, damage counted | +19.3 | +46.8 |
| Combat | First round won (charged fights) | 57% | 0% |
| Combat | Net points per charged fight | +37 | +0 |
| Combat | Net points per supported fight / lone fight | -584 / +140 | - / +0 |
| Combat | Charged fights on a top-3 enemy unit | 4 of 7 | 1 of 1 |
| Game | Points lost | 487.3 | 634.3 |
| Game | VP from objectives | 740.0 | 553.3 |
| Game | Lone holders (player turns) | 0.5 | 4.0 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +483 VP
- The side that went first won 2 of 2 games with a winner
- Points traded per game (both sides' losses): 1122
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: gs3-83c8646-p19

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 8.3 | -3.4 | 0.0 | 136.7 | 35.0 | +559.2 | 0.0 | 355.7 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +24.9 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 4.7 | +0.0 | 0.0 | 55.0 | - | - | - | - |
| ASSAILMENT BY POINTS | 0.3 | +2.6 | 0.0 | 68.3 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +1.1 | 0.0 | 50.0 | 0.7 | +8.1 | 0.0 | 0.0 |
| BEST PRIZE | 0.3 | -13.7 | 0.0 | 0.0 | - | - | - | - |
| BOMBING RUN | 0.3 | +10.8 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 7.7 | +397.5 | 150.0 | 275.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 4.0 | +127.9 | 123.3 | 155.3 | 2.0 | +9.7 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 3.0 | +35.1 | 61.7 | 0.0 | 1.3 | +15.5 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 0.3 | +0.0 | 0.0 | 91.3 |
| CHALLENGE BY POINTS | - | - | - | - | 0.7 | +46.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 17.7 | -392.9 | 0.0 | 255.3 | 20.3 | -916.5 | 0.0 | 200.7 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 199.7 | 50.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.0 | +0.0 | 0.0 | 252.7 | 9.0 | +0.0 | 0.0 | 100.3 |
| CONVEYANCE SEARCH | - | - | - | - | 0.3 | +34.2 | 0.0 | 91.3 |
| COVER ONCE | 5.3 | -233.6 | 0.0 | 272.3 | 10.3 | -1790.8 | 0.0 | 330.3 |
| DENIED BY THE FIGHT | 0.7 | -3.8 | 99.3 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 6.0 | -45.0 | 0.0 | 0.0 | 8.3 | -61.2 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | +2.0 | 52.7 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | - | - | - | - | 0.3 | +17.4 | 0.0 | 0.0 |
| EXACT ROUND | 1.0 | +33.8 | 73.0 | 50.0 | 0.3 | -15.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.3 | +25.9 | 272.7 | 176.3 | 0.3 | +0.1 | 0.0 | 0.0 |
| FALLS SHORT | 5.0 | +101.3 | 0.0 | 77.7 | 21.7 | +275.5 | 0.0 | 127.7 |
| FEATURE BUFFS | 1.3 | +2.5 | 0.0 | 0.0 | 0.7 | +2.5 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.3 | +37.8 | 52.7 | 194.7 | - | - | - | - |
| FIVE ACTION | 79.7 | +6368.3 | 757.7 | 1704.7 | 82.3 | +5143.2 | 860.7 | 810.7 |
| FLANK NOT WEIGHED | 3.0 | +0.0 | 0.0 | 155.3 | 4.7 | +0.0 | 0.0 | 115.7 |
| FOOT FIRST | - | - | - | - | 13.0 | +0.0 | 0.0 | 90.7 |
| FOUR ROUNDS | 3.0 | +521.0 | 272.7 | 244.7 | 0.3 | +20.8 | 0.0 | 0.0 |
| FREED FROM HIS FIGHT | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 1.0 | -0.6 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.3 | -1.6 | 11.3 | 0.0 | - | - | - | - |
| GOAL ROUTE | - | - | - | - | 0.7 | +52.4 | 0.0 | 0.0 |
| GOAL WALK | 3.3 | +222.2 | 0.0 | 0.0 | 12.7 | +1227.4 | 0.0 | 0.0 |
| GUN FIGURES | - | - | - | - | 1.7 | +46.6 | 55.0 | 0.0 |
| GUN MASK | 1.3 | +235.5 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 77.7 | 5.7 | +0.0 | 0.0 | 114.3 |
| HE REFORMS ONCE FREED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 9.7 | +0.0 | 0.0 | 255.3 | 9.3 | +0.0 | 0.0 | 200.7 |
| HIS CHARGE LIST | 2.0 | +0.0 | 0.0 | 0.0 | 8.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 4.0 | +0.0 | 0.0 | 100.0 | 4.3 | +0.0 | 0.0 | 231.3 |
| HIS MOVE AND SHOT | 5.7 | -34.6 | 0.0 | 155.3 | 10.0 | -72.3 | 0.0 | 0.0 |
| HIS ONE QUARTER | 4.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 6.0 | +0.0 | 0.0 | 100.0 | 4.3 | +0.0 | 0.0 | 231.3 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 31.3 | +812.4 | 0.0 | 365.3 | 54.3 | +2918.0 | 0.0 | 613.3 |
| HIS SHOTS BY HIS RUN | 35.7 | +798.2 | 0.0 | 754.7 | 47.3 | +1345.0 | 0.0 | 613.3 |
| HIS TURN DENIED | 1.0 | +13.5 | 161.0 | 0.0 | - | - | - | - |
| HOLD ODDS | 13.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 9.3 | +994.6 | 0.0 | 0.0 | 5.3 | +650.5 | 0.0 | 38.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.3 | -66.0 | 272.7 | 68.3 | 0.3 | -8.8 | 0.0 | 0.0 |
| HUNT IN PAIRS | 2.0 | +293.5 | 0.0 | 194.7 | - | - | - | - |
| IDLE COST | 0.7 | -17.4 | 0.0 | 0.0 | 12.3 | -182.1 | 0.0 | 0.0 |
| JOINT CHARGE NOW | 0.7 | +117.9 | 0.0 | 194.7 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | 1.3 | +33.7 | 0.0 | 0.0 | 0.3 | +15.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | - | - | - | - | 2.3 | +0.0 | 50.0 | 216.0 |
| LONE WIZARD KEPT IN | 0.7 | +52.8 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 2.7 | -2.3 | 261.3 | 244.7 | 0.3 | +7.2 | 0.0 | 0.0 |
| MANOEUVRE | 1.7 | -1.1 | 0.0 | 0.0 | 2.7 | +21.0 | 0.0 | 115.7 |
| MARCH BY THE SUM | 1.7 | +257.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.7 | +99.5 | 0.0 | 126.3 | - | - | - | - |
| MARCH OF THE TABLE | 1.7 | +173.0 | 0.0 | 77.7 | - | - | - | - |
| MARCH OVER CASTS | 2.7 | +29.4 | 0.0 | 77.7 | - | - | - | - |
| MAX FOR POSITIONING | 5.7 | +191.3 | 0.0 | 272.3 | 4.3 | +198.0 | 0.0 | 0.0 |
| MEETS IN TIME | 1.7 | +155.5 | 0.0 | 0.0 | 4.0 | +307.2 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 9.7 | +264.1 | 0.0 | 204.0 | 3.7 | +30.1 | 0.0 | 168.3 |
| MISSILES NEXT TURN | 14.3 | +182.2 | 0.0 | 204.0 | 3.3 | +19.5 | 0.0 | 168.3 |
| MISSILES ON ONE TARGET | 0.7 | -10.5 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 3.0 | +307.0 | 0.0 | 100.0 | 2.0 | +90.3 | 0.0 | 231.3 |
| NEARER NOT NEEDED | 6.7 | +293.3 | 0.0 | 0.0 | 5.3 | +262.5 | 0.0 | 168.3 |
| NEAREST TO GOAL | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 2.3 | +237.3 | 0.0 | 100.0 | 2.7 | +106.9 | 155.3 | 231.3 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 1.0 | -93.3 | 0.0 | 76.0 |
| NO DOUBLE ROUNDS | 1.7 | -144.0 | 211.0 | 50.0 | 0.3 | -8.3 | 0.0 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.3 | -0.3 | 0.0 | 0.0 | 1.0 | -1.5 | 0.0 | 0.0 |
| OFF BEST | 3.3 | -168.5 | 0.0 | 0.0 | 5.7 | -211.2 | 0.0 | 0.0 |
| OGRE LOADER SECOND SHOT | 7.0 | +39.2 | 0.0 | 55.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 6.3 | -126.2 | 0.0 | 196.0 | 4.7 | -124.1 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 5.7 | +96.8 | 0.0 | 0.0 | 2.3 | -32.8 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.7 | -4.3 | 155.3 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +8.2 | 11.3 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.7 | +29.7 | 61.7 | 50.0 | - | - | - | - |
| OWN CAST FIRST | 0.7 | -13.5 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 34.7 | +518.8 | 326.7 | 869.7 | 35.7 | +269.2 | 297.7 | 827.3 |
| PROMISE BY ITS OWN SUM | 3.7 | -69.7 | 0.0 | 0.0 | 4.0 | -21.1 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| QUARTER ODDS | 14.0 | +2208.2 | 0.0 | 220.0 | 13.7 | +1589.3 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.3 | +5.4 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 3.3 | +583.5 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.3 | -2.3 | 0.0 | 0.0 | 0.7 | -29.8 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +11.3 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 3.0 | +76.2 | 272.7 | 244.7 | - | - | - | - |
| RUN DOWN | 1.7 | -15.8 | 211.0 | 50.0 | 0.3 | -2.8 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 0.7 | +2.9 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | -22.6 | 0.0 | 0.0 | - | - | - | - |
| SECOND LOOK | 0.3 | +13.1 | 0.0 | 50.0 | - | - | - | - |
| SET CREDITED ONCE | 1.3 | -283.6 | 0.0 | 252.7 | 2.3 | -92.2 | 0.0 | 0.0 |
| SET UP BY THE SET | 2.3 | +383.7 | 0.0 | 389.3 | 4.0 | +299.6 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.7 | +12.2 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 15.0 | +0.0 | 0.0 | 352.7 | 7.0 | +0.0 | 0.0 | 98.7 |
| SHOOTS FROM THE BEST SPOT | 4.7 | +247.9 | 74.0 | 0.0 | 1.3 | +8.0 | 155.3 | 0.0 |
| SHOT OR CHARGE | 0.3 | -15.5 | 61.7 | 77.7 | - | - | - | - |
| SHOT RISK POINTS | 17.7 | -104.2 | 0.0 | 365.3 | 38.3 | +40.6 | 0.0 | 76.0 |
| SHOTS AFTER THE MOVES | 4.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 13.3 | +815.3 | 0.0 | 330.0 | 16.3 | +532.6 | 0.0 | 289.7 |
| SPELL WORTH | 0.7 | +7.4 | 0.0 | 0.0 | 1.3 | +10.2 | 91.3 | 91.3 |
| SPELLS IN THE FIGHT | 0.7 | +16.4 | 162.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 2.3 | +0.0 | 0.0 | 194.7 | 6.0 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | 1.0 | -11.8 | 199.7 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 41.7 | +0.0 | 485.0 | 815.3 | 37.3 | +0.0 | 860.7 | 378.7 |
| STAY WORTH | 32.0 | +112.0 | 411.0 | 870.3 | 18.3 | +230.4 | 485.3 | 38.0 |
| STRIKE BY THE ODDS | 0.7 | +23.2 | 0.0 | 194.7 | 0.3 | +3.3 | 0.0 | 0.0 |
| STUBBORN BY POINTS | - | - | - | - | 0.3 | +2.6 | 0.0 | 0.0 |
| SUPPORT ADDS | 3.0 | +191.7 | 0.0 | 0.0 | 10.3 | +874.5 | 0.0 | 0.0 |
| SUPPORT NARROWED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 3.0 | +191.7 | 0.0 | 0.0 | 10.3 | +874.5 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +0.2 | 0.0 | 11.3 |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 36.7 | +0.0 | 0.0 | 675.0 | 39.7 | +0.0 | 0.0 | 367.3 |
| TIED UP BY THE SUM | 1.0 | +97.6 | 58.0 | 50.0 | - | - | - | - |
| TIME ON OUR SIDE | 25.7 | +395.6 | 0.0 | 322.3 | 13.3 | +125.1 | 0.0 | 277.7 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 231.3 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -16.6 | 0.0 | 38.0 |
| WAR ENGINE JOBS | - | - | - | - | 1.3 | +0.0 | 155.3 | 123.3 |
| WHO FIGHTS | 0.3 | -0.9 | 0.0 | 50.0 | - | - | - | - |
| WHO HITS BACK | 0.3 | +69.8 | 0.0 | 0.0 | 0.3 | +30.4 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 0.7 | -81.0 | 0.0 | 0.0 | 2.3 | -304.6 | 0.0 | 200.7 |
| WOUNDS ON THE RANKS | 3.3 | +55.0 | 0.0 | 0.0 | 4.7 | +280.3 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p19

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 130 | 130 | 98 | 32.67 | +1826 | +18.6 |
| HIS SHOTS BY HIS RUN | 249 | 236 | 65 | 21.67 | +1483 | +22.8 |
| HIS SHOT LIST | 257 | 240 | 63 | 21.00 | +1387 | +22.0 |
| HOLDER ASSIGNMENT | 44 | 44 | 38 | 12.67 | +2756 | +72.5 |
| OFF BEST | 27 | 27 | 27 | 9.00 | -1139 | -42.2 |
| SHOT RISK POINTS | 168 | 159 | 23 | 7.67 | +668 | +29.1 |
| DEPLOY BY FIGURES | 43 | 43 | 22 | 7.33 | +408 | +18.6 |
| HARD STAY DROPPED | 22 | 22 | 22 | 7.33 | +0 | +0.0 |
| OGRE LOADER SECOND SHOT | 21 | 21 | 21 | 7.00 | +118 | +5.6 |
| QUARTER ODDS | 83 | 79 | 17 | 5.67 | +2216 | +130.3 |
| CAST JOB | 18 | 18 | 16 | 5.33 | +112 | +7.0 |
| FIVE ACTION | 486 | 467 | 15 | 5.00 | +559 | +37.3 |
| GOAL WALK | 48 | 47 | 15 | 5.00 | +1016 | +67.7 |
| ARTILLERY RE-ROLL WEIGHED | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 12 | 4.00 | +0 | +0.0 |
| SET UP BY THE SET | 19 | 19 | 11 | 3.67 | +810 | +73.7 |
| SUPPORT ADDS | 40 | 33 | 11 | 3.67 | +285 | +25.9 |
| SUPPORT WORKED OUT | 40 | 33 | 11 | 3.67 | +285 | +25.9 |
| TIME ON OUR SIDE | 117 | 104 | 11 | 3.67 | +103 | +9.3 |
| MEETS IN TIME | 17 | 17 | 10 | 3.33 | +481 | +48.1 |
| SHOOTS FROM THE BEST SPOT | 18 | 18 | 10 | 3.33 | +92 | +9.2 |
| FOUR ROUNDS | 10 | 10 | 9 | 3.00 | +682 | +75.8 |
| NEXT CHARGE BY LIST | 15 | 13 | 9 | 3.00 | +404 | +44.9 |
| CHARGE LOSSES | 114 | 110 | 8 | 2.67 | +728 | +91.0 |
| COVER ONCE | 47 | 34 | 8 | 2.67 | +565 | +70.6 |
| MOVE TO CHARGE COMPUTED | 15 | 11 | 8 | 2.67 | +416 | +52.0 |
| LEGAL CHARGES ONLY | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| MISSILES IN THE MOVE | 40 | 32 | 6 | 2.00 | +166 | +27.7 |
| WOUNDS ON THE RANKS | 24 | 24 | 6 | 2.00 | +343 | +57.2 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +148 | +29.7 |
| MARCH BY THE SUM | 5 | 5 | 5 | 1.67 | +772 | +154.3 |
| MARCH OF THE TABLE | 5 | 5 | 5 | 1.67 | -519 | -103.8 |
| SHOTS IN THE MOVE | 89 | 70 | 5 | 1.67 | +178 | +35.7 |
| STAY WORTH | 151 | 135 | 5 | 1.67 | +64 | +12.9 |
| CASTING BLOCK | 13 | 13 | 4 | 1.33 | +47 | +11.8 |
| FALLS SHORT | 80 | 64 | 4 | 1.33 | +22 | +5.4 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| HUNT IN PAIRS | 6 | 5 | 4 | 1.33 | +459 | +114.8 |
| MOVE ORDER | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 23 | 23 | 4 | 1.33 | -272 | -68.1 |
| MARCH CHECK | 5 | 5 | 3 | 1.00 | +148 | +49.4 |
| MISSILES NEXT TURN | 53 | 40 | 3 | 1.00 | +6 | +1.9 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 24 | 24 | 3 | 1.00 | +0 | +0.0 |
| STRIKE BY THE ODDS | 3 | 3 | 3 | 1.00 | +79 | +26.5 |
| TIED UP BY THE SUM | 3 | 3 | 3 | 1.00 | +99 | +32.9 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +138 | +68.9 |
| EXACT ROUND | 4 | 4 | 2 | 0.67 | +66 | +33.0 |
| GOAL ROUTE | 2 | 2 | 2 | 0.67 | +157 | +78.7 |
| GUN MASK | 4 | 4 | 2 | 0.67 | +316 | +158.0 |
| HIS MOVE AND SHOT | 47 | 47 | 2 | 0.67 | +0 | +0.0 |
| IDLE COST | 39 | 25 | 2 | 0.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +354 | +176.9 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +158 | +79.2 |
| LOST AFTER ESCAPE | 9 | 9 | 2 | 0.67 | +8 | +4.2 |
| MANOEUVRE | 13 | 13 | 2 | 0.67 | +84 | +42.2 |
| NEARER NOT NEEDED | 36 | 35 | 2 | 0.67 | +94 | +46.9 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -13 | -6.5 |
| OVERRUNS AWAY | 2 | 2 | 2 | 0.67 | +66 | +33.0 |
| OWN CAST FIRST | 2 | 2 | 2 | 0.67 | -40 | -20.2 |
| REDIRECT FOR A FRIEND IN REACH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SUPPORT NARROWED | 2 | 2 | 2 | 0.67 | -290 | -144.8 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +124 | +62.1 |
| WHOLE FIGHT DANGER | 9 | 9 | 2 | 0.67 | +951 | +475.4 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +8 | +7.9 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -41 | -41.0 |
| BOMBING RUN | 1 | 1 | 1 | 0.33 | +32 | +32.5 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 8 | 8 | 1 | 0.33 | +0 | +0.3 |
| FIGHT TO THE END | 4 | 4 | 1 | 0.33 | +16 | +16.0 |
| MAX FOR POSITIONING | 30 | 27 | 1 | 0.33 | +6 | +5.7 |
| ONE FIGHT FORMULA | 33 | 24 | 1 | 0.33 | +7 | +7.2 |
| ONE OBJECTIVE FORMULA | 24 | 19 | 1 | 0.33 | +43 | +43.2 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +20 | +19.9 |
| REDIRECT COUNTER | 10 | 10 | 1 | 0.33 | +237 | +237.1 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +34 | +33.8 |
| RISK BY ARC | 9 | 9 | 1 | 0.33 | +16 | +16.0 |
| RUN DOWN | 6 | 6 | 1 | 0.33 | +0 | +0.3 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +39 | +39.4 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SPELLS IN THE FIGHT | 2 | 2 | 1 | 0.33 | +12 | +12.2 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +8 | +7.9 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +1 | +0.6 |
| THE ROW IN ITS ORDER | 11 | 1 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -50 | -49.7 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 3 | 2 | 0 | 0.00 | - | - |
| CANNON PLANNED TARGET | 23 | 23 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CHARGE NOW FIRST | 6 | 6 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 48 | 47 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 1 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EVASIVE BY THE ODDS | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 6 | 6 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 23 | not checked | - | - | - | - |
| FOOT FIRST | 39 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 3 | 3 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 5 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 57 | 57 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 31 | 26 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 25 | 25 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 19 | 19 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 31 | 29 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 3 | 3 | 0 | 0.00 | - | - |
| HOLD ODDS | 57 | 57 | 0 | 0.00 | - | - |
| HONEST WORTH | 8 | 8 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 7 | 7 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 8 | 8 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 2 | not checked | - | - | - | - |
| NEAREST TO GOAL | 5 | 5 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 3 | 3 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 6 | 6 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 7 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 211 | trace | - | - | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 2 | not checked | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 3 | 3 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SEARCH SPOT | 1 | 1 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 11 | 11 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 66 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 6 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 25 | 21 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 18 | 18 | 0 | 0.00 | - | - |
| STANDS STILL | 237 | 224 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 6 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 22 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 16 | not checked | - | - | - | - |
| THE TABLE BINDS | 229 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 4 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 4 | 4 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p19

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.33 | 4.00 | 33.2 |
| ARMY TABLE | rule | 1.67 | 2.67 | 101.5 |
| MARCH OF THE TABLE | rule | 1.67 | - | 103.8 |
| NO REASON | gate | - | 1.67 | 81.8 |
| PROMISE BY ITS OWN SUM | rule | 0.67 | 0.67 | 68.1 |
| HOLDER ASSIGNMENT | rule | 0.67 | - | 13.0 |
| ONE PROMISE A TARGET | rule | - | 0.67 | 6.5 |
| OWN CAST FIRST | rule | 0.67 | - | 20.2 |
| SUPPORT NARROWED | rule | - | 0.67 | 144.8 |
| BEST PRIZE | rule | 0.33 | - | 41.0 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 49.7 |

### Plans: gs3-83c8646-p19

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.0 | 56% | 460 | 227 | 49% |
| Mine | move | 19.3 | 100% | 1682 | 0 | 0% |
| Mine | shoot | 12.3 | 35% | 556 | 292 | 52% |
| Opponent | move | 28.7 | 94% | 1799 | 0 | 0% |
| Opponent | shoot | 6.7 | 30% | 603 | 269 | 45% |
| Opponent | support | 0.3 | 0% | 22 | 0 | 0% |

### Battle groups: gs3-83c8646-p19

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 3.3 | 20% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p19

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 12 | 62 (12) | 62 | 0 | 28 | 25% | 2.6 | - | 0 (7) | 142 (5) | 34 (7) | 84 (5) |
| Mine | Fast Hammer | 4 | 0 (4) | 0 | 0 | 15 | 25% | 3.3 | 0 (2) | 0 (2) | - | 0 (3) | 0 (1) |
| Mine | Holder | 5 | 54 (5) | 13 | 41 | 0 | 60% | 2.0 | - | 67 (4) | 0 (1) | 71 (3) | 26 (2) |
| Mine | Shooter | 2 | 289 (2) | 0 | 289 | 0 | 0% | 1.0 | 62 (1) | 515 (1) | - | 289 (2) | - |
| Mine | War machine | 6 | 0 (6) | 0 | 0 | 50 | 0% | 1.3 | 0 (2) | 0 (2) | 0 (2) | 0 (1) | 0 (5) |
| Opponent | Chaff | 6 | 188 (6) | 0 | 188 | 26 | 50% | 4.0 | 0 (5) | 1250 (1) | - | 265 (5) | 0 (1) |
| Opponent | Character | 7 | 31 (7) | 31 | 0 | 35 | 0% | 2.1 | 175 (1) | 18 (4) | - | 69 (4) | 0 (1) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 36 | 33% | 3.5 | - | 0 (3) | - | 0 (2) | 0 (1) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 4 | 60 (4) | 33 | 26 | 14 | 0% | 2.0 | - | 67 (3) | 0 (1) | 67 (3) | 0 (1) |
| Opponent | Hammer | 8 | 21 (8) | 21 | 0 | 55 | 25% | 2.0 | 45 (2) | 0 (2) | 25 (4) | 33 (5) | 0 (3) |
| Opponent | Holder | 1 | 54 (1) | 0 | 54 | 100 | 0% | 2.0 | - | 54 (1) | - | 54 (1) | - |
| Opponent | Shooter | 2 | 0 (2) | 0 | 0 | 56 | 0% | 1.0 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | 0 (1) | - | 0 (1) | - |

### Charged fights: gs3-83c8646-p19

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 3 | 86 | 330 | 2.3 | 1.1 | 142 | 105 | +37 | 4 of 7 | 4 of 7 | -584 | +140 |
| Opponent | Ogre Kingdoms | 1 | 563 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| **Opponent** | all armies | 3 | 188 | 0 | 0.3 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |

### Effective charges: gs3-83c8646-p19

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 7 | 2 (net -292) | 0 | 1 (net +532) | 1 (net +301) | 0 | 2 (net +79) | 1 | 17% (1 of 6) |
| Opponent | Wood Elf Realms | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: gs3-83c8646-p19

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 459 | 426 | -292 | 181 | 424 | -243 | -53.0 |
| Mine | Effective (55-75%) | 1 | 369 | 185 | +532 | 532 | 105 | +427 | +115.6 |
| Mine | 76-89% | 1 | 369 | 251 | +301 | 301 | 0 | +301 | +81.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 301 | 149 | +79 | 142 | 0 | +142 | +47.2 |
| Mine | No odds | 1 | 150 | 125 | -150 | 96 | 155 | -59 | -39.4 |
| Mine | All fights | 7 | 344 | 244 | +37 | 225 | 158 | +67 | +19.3 |
| Opponent | Long shot (under 50%) | 1 | 102 | 358 | +0 | 48 | 0 | +48 | +46.8 |
| Opponent | All fights | 1 | 102 | 358 | +0 | 48 | 0 | +48 | +46.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p19 | move | 17 | 2 (12%) | 2 (12%) | 3 (18%) | 12 (71%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Clockwork Compass | Mine | L1228 |
| Elixir of Power | Mine | L1118, L1135 |
| Fistful of Laurels | Opponent | L1118 |
| Ring of Doom | Mine | L1118, L1135, L1228 |
| Ring of Jet | Mine | L1118, L1135, L1228 |

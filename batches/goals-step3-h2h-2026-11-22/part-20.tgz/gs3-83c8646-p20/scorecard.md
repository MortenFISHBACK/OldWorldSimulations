# Doctrine scorecard: gs3-83c8646-p20

### Scorecard: gs3-83c8646-p20

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1323 | 3 | 1 | Mine | no | 4 | 2 | 2 | 0 | 1 | 0 | 0 | 317 |
| L1323 | 3 | 1 | Opponent | yes | 0 | 2 | 8 | 2 | 3 | 0 | 0 | 60 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 5 | 4 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | - | 5 | 0 | 1 | 0 | 0 | 77 |
| L1435 | 1 | 1 | Mine | no | 0 | 4 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 2.0 | 2.7 | 3.0 | 1.7 | 0.3 | 0.0 | 0.0 | 105.7 |
| **Average** | | | Opponent | 50% | 0.0 | 2.0 | 5.0 | 1.0 | 1.3 | 0.0 | 0.0 | 45.7 |

### KPIs: gs3-83c8646-p20

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 16) | 0% (0 of 17) | 0% (0 of 33) |
| Winner chose to follow up after the loser gave ground |  | 67% (4 of 6); on the table 83% | - | 67% (4 of 6); on the table 83% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (2 of 2); on the table 100% | 100% (2 of 2); on the table 100% | 100% (4 of 4); on the table 100% |
| Winner chose to pursue after the loser fled |  | 100% (3 of 3); on the table 100% | - | 100% (3 of 3); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 82% (9 of 11); on the table 91% | 100% (2 of 2); on the table 100% | 85% (11 of 13); on the table 92% |
| Magic missiles tried each own turn | 50%+ | 39% (7 of 18) | - | 39% (7 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 41% (7 of 17) | - | 41% (7 of 17) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 38% (2253 of 6000) | 48% (2850 of 6000) | 43% (5103 of 12000) |
|   infantry points that never fought | lower | 38% (354 of 923) | 70% (817 of 1159) | 56% (1171 of 2082) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 54% (14 of 26) | 71% (17 of 24) | 62% (31 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.0 uses a game | 100% (2 of 2); 0.7 uses a game | 100% (3 of 3); 0.8 uses a game |
| Bound items with another spell used |  | 29% (4 of 14); 3.0 uses a game | 0.0 uses a game | 29% (4 of 14); 1.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 49% (2897 of 5860) | 69% (3551 of 5131) | 59% (6448 of 10991) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (27%) | - | 1.0 (27%) |
| MARCHED: its unit marched | 2.3 (64%) | - | 2.3 (64%) |
| IN COMBAT: engaged in combat | 0.3 (9%) | - | 0.3 (9%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 5.7 | 3.0 | 3.3 | 2.3 | 1.7 |
| not cast | 2.3 | 7.0 | 4.7 | 3.7 | 26.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 4.0 (57%) | 0.0 (0%) | 1.0 (27%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (64%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (5%) | 0.7 (14%) | 0.3 (9%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 1.7 (71%) | 1.7 (24%) | 1.7 (36%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| GONE: slain | 0.3 (14%) | 0.7 (10%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (5%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.3 (14%) | 0.0 (0%) | 2.3 (50%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 24.0 (91%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 3.3 a game | 0.0 a game | 1.7 a game |
| stood (cast and not dispelled) | 70% (7 of 10) | - | 70% (7 of 10) |
| the unit moved after it | 57% (4 of 7) | - | 57% (4 of 7) |
| it charged on its next turn | 0% (0 of 7) | - | 0% (0 of 7) |
| the enemy charged it first | 43% (3 of 7) | - | 43% (3 of 7) |
| it fought by the end of its next turn | 29% (2 of 7) | - | 29% (2 of 7) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 7) | - | 0% (0 of 7) |
| none of these (no charge, no fight, no charge escaped) | 57% (4 of 7) | - | 57% (4 of 7) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 49% (42 of 86) | 55% (57 of 103) | 52% (99 of 189) |
|   cavalry | 36% (9 of 25) | 81% (17 of 21) | 57% (26 of 46) |
|   character | 19% (5 of 27) | 42% (8 of 19) | 28% (13 of 46) |
|   chariot | - | 73% (8 of 11) | 73% (8 of 11) |
|   infantry | 73% (16 of 22) | 40% (17 of 42) | 52% (33 of 64) |
|   monster | - | 70% (7 of 10) | 70% (7 of 10) |
|   war machine | 100% (12 of 12) | - | 100% (12 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (16%) | 1.7 (11%) | 4.0 (13%) |
| CHARGED: it charged | 2.0 (14%) | 2.7 (17%) | 4.7 (16%) |
| IN COMBAT: it fought this turn or the last | 1.7 (11%) | 1.0 (7%) | 2.7 (9%) |
| NO TARGET IN RANGE | 5.0 (34%) | 4.3 (28%) | 9.3 (31%) |
| ONLY IN COMBAT: the only targets were in combat | 1.3 (9%) | 0.7 (4%) | 2.0 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.0 (14%) | 4.0 (26%) | 6.0 (20%) |
| SHELTERED: the target was sheltered | 0.3 (2%) | 0.0 (0%) | 0.3 (1%) |
| OTHER BAR | 0.0 (0%) | 1.0 (7%) | 1.0 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 12.3 | 1.7 | 86% | 2.9 pts | 36 pts |
| character | 7.0 | 1.3 | 81% | 4.0 pts | 28 pts |
| chariot | 2.7 | 0.7 | 88% | 15.6 pts | 42 pts |
| infantry | 16.0 | 4.0 | 83% | 11.1 pts | 177 pts |
| monster | 3.0 | 1.0 | 78% | 20.8 pts | 62 pts |
| war machine | 4.0 | 0.7 | 92% | 3.9 pts | 16 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 7.0 | 5.0 |
| Charges that made contact a game | 2.3 | 4.3 | 3.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.33 declared, 0.33 contact (3 units) | - | 0.33 declared, 0.33 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.35 declared, 0.26 contact (23 units) | 0.64 declared, 0.39 contact (33 units) | 0.52 declared, 0.34 contact (56 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 47% (8 of 17) | - | - | 47% (8 of 17) |
| Character on its own | - | 80% (4 of 5) | 38% (3 of 8) | 54% (7 of 13) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 90% (9 of 10) | 0% (0 of 1) | - | 82% (9 of 11) |
| Monster | 50% (1 of 2) | 100% (1 of 1) | - | 67% (2 of 3) |
| Monstrous | 50% (1 of 2) | 100% (2 of 2) | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 3 | 82% (9 of 11); on the table 91% | 39% (7 of 18) | 38% | 54% (14 of 26) | 100% (1 of 1); 1.0 uses a game | 29% (4 of 14); 3.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | - | - | 32% | 100% (7 of 7) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (2 of 2); on the table 100% | - | 27% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | - | 84% | 67% (8 of 12) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p20, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 60% (3) | 0% (0) | 43% (3) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.00 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p20

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.0 | 1.7 |
| Strategy | Charge objectives carried out (made contact) | 62% (5 of 8) | 31% (4 of 13) |
| Strategy | Shoot objectives carried out (shot that target) | 38% (11 of 29) | 47% (8 of 17) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 50% (2 of 4) | 50% (2 of 4) |
| Strategy | Joined characters whose unit fought | - | 0% (0 of 1) |
| Strategy | Lone characters that fought | 86% (6 of 7) | 50% (3 of 6) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.7 | 1.0 |
| Movement | Points that never moved of their own | 105.7 | 45.7 |
| Movement | Fights charged into per game | 2.3 | 4.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 6 | 3 of 8, net +98 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 6, net +0 | 0 of 8 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 6, net +81 | 0 of 8 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 6, net +310 | 4 of 8, net +88 |
| Shooting | Shots by shooting units (incl. breath weapons) | 12.3 | 21.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 22% (8 of 37) | 69% (44 of 64) |
| Shooting | Points destroyed by shooting units | 23.3 | 0.0 |
| Shooting | War machine shots | 4.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 75% (9 of 12) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 2.3 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 14% (1 of 7) | - |
| Magic | Wounds caused by magic missiles | 2.0 | - |
| Magic | Wounds caused by other spells | 5.3 | - |
| Magic | Points destroyed by magic (all spells) | 87.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 1.3 / 1.7 / 0.0 | 4.0 / 1.3 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 185.0 | 315.7 |
| Combat | Points run down | 155.3 | 0.0 |
| Combat | Net points per charged fight, damage counted | +111 | +78 |
| Combat | Net per 100 charger points, damage counted | +27.3 | +30.9 |
| Combat | First round won (charged fights) | 100% | 38% |
| Combat | Net points per charged fight | +141 | +72 |
| Combat | Net points per supported fight / lone fight | - / +141 | - / +72 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 7 | 5 of 13 |
| Game | Points lost | 339.3 | 835.0 |
| Game | VP from objectives | 626.7 | 836.7 |
| Game | Lone holders (player turns) | 2.0 | 0.0 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) +165 VP
- The side that went first won 0 of 3 games with a winner
- Points traded per game (both sides' losses): 1174
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p20

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.7 | +117.1 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 24.0 | -51.8 | 0.0 | 407.3 | 28.0 | +421.6 | 0.0 | 266.3 |
| ASSAILMENT BY POINTS | 0.3 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | 1.0 | +7.5 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | - | - | - | - | 0.3 | -12.2 | 0.0 | 0.0 |
| BOUND ASSAILMENT | 1.3 | +0.2 | 0.0 | 145.7 | - | - | - | - |
| CANNON PLAN MISSED | 0.3 | +0.0 | 23.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 4.0 | +43.6 | 306.7 | 46.7 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 2.7 | +25.9 | 44.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.3 | -1.0 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 1.0 | +72.8 | 0.0 | 109.3 | 0.3 | +16.4 | 0.0 | 41.7 |
| CHAMPION KNOWS CHALLENGE | 0.3 | -3.0 | 52.7 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 20.3 | -994.1 | 0.0 | 196.0 | 14.3 | -610.6 | 0.0 | 419.0 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 234.3 | 0.0 | 3.0 | +0.0 | 202.7 | 130.0 |
| CHARGER SLAIN LOST | 0.3 | -2.8 | 52.7 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 10.7 | +0.0 | 0.0 | 0.0 | 10.0 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | - | - | - | - | 1.7 | +0.0 | 115.7 | 130.0 |
| CONTINUE AHEAD WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 3.0 | +465.2 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 11.3 | -693.5 | 0.0 | 47.7 | 7.3 | -578.2 | 0.0 | 330.3 |
| DENIED BY THE FIGHT | 0.3 | -0.2 | 0.0 | 0.0 | 0.3 | -0.6 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 8.0 | -26.8 | 0.0 | 0.0 | 9.3 | +8.3 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -82.5 | 99.0 | 0.0 | 0.3 | -74.9 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.7 | +11.1 | 78.0 | 0.0 | 0.3 | +11.5 | 0.0 | 65.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 1.7 | +31.9 | 0.0 | 0.0 |
| EXACT ROUND | 1.3 | +9.0 | 135.3 | 0.0 | 2.7 | +29.4 | 71.0 | 130.0 |
| FALL BACK GOOD ORDER | 3.0 | +14.3 | 287.0 | 0.0 | 4.3 | +22.1 | 226.0 | 130.0 |
| FALLS SHORT | 10.3 | +107.8 | 0.0 | 0.0 | 12.0 | +121.1 | 0.0 | 42.0 |
| FEATURE BUFFS | 1.7 | +11.1 | 0.0 | 0.0 | 2.0 | +14.0 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 1.3 | +9.2 | 47.7 | 65.0 |
| FIRE IN ORDER | 1.0 | +0.0 | 65.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 95.3 | +4671.0 | 1121.0 | 753.7 | 101.0 | +6970.9 | 273.7 | 1517.0 |
| FLANK NOT WEIGHED | 6.7 | +0.0 | 0.0 | 143.7 | 8.7 | +0.0 | 0.0 | 186.0 |
| FOLLOW UP WEIGHED | 0.3 | +45.0 | 0.0 | 0.0 | 1.0 | +113.6 | 0.0 | 0.0 |
| FOOT FIRST | - | - | - | - | 25.0 | +0.0 | 0.0 | 181.7 |
| FOUR ROUNDS | 3.0 | +274.3 | 287.0 | 0.0 | 5.3 | +473.5 | 273.7 | 195.0 |
| FREED FROM HIS FIGHT | 3.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 30.0 |
| FRIEND SHOOTS FIRST | 0.7 | -5.3 | 0.0 | 0.0 | 0.3 | -1.6 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.7 | +38.2 | 0.0 | 115.7 | - | - | - | - |
| GOAL ROUTE | - | - | - | - | 1.7 | +80.4 | 0.0 | 0.0 |
| GOAL WALK | 6.3 | +443.1 | 0.0 | 201.3 | 6.3 | +357.0 | 0.0 | 0.0 |
| GUN FIGURES | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +115.7 | 0.0 | 0.0 |
| GUN MASK | 1.7 | +29.3 | 0.0 | 0.0 | 0.3 | +11.0 | 0.0 | 61.7 |
| HARD STAY DROPPED | 2.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 103.7 |
| HE REFORMS ONCE FREED | 2.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 30.0 |
| HIS CHARGE BY HIS RUN | 16.3 | +0.0 | 0.0 | 196.0 | 10.3 | +0.0 | 0.0 | 366.3 |
| HIS CHARGE DENIED | - | - | - | - | 1.7 | +26.2 | 47.7 | 0.0 |
| HIS CHARGE LIST | 7.3 | +0.0 | 0.0 | 314.0 | 7.0 | +0.0 | 0.0 | 236.3 |
| HIS LEGAL MOVES | 7.7 | +0.0 | 0.0 | 95.3 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 6.3 | -206.6 | 0.0 | 0.0 | 6.0 | -46.2 | 0.0 | 83.3 |
| HIS ONE QUARTER | 5.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 52.7 |
| HIS OWN BEST MOVE | 8.7 | +0.0 | 0.0 | 95.3 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 60.7 | +4091.2 | 0.0 | 559.7 | 68.0 | +2060.3 | 0.0 | 1104.3 |
| HIS SHOTS BY HIS RUN | 51.3 | +1737.9 | 0.0 | 610.0 | 43.7 | +725.1 | 0.0 | 771.7 |
| HIS TURN DENIED | 0.7 | +27.4 | 78.0 | 0.0 | 0.3 | +5.6 | 23.3 | 0.0 |
| HOLD ODDS | 18.7 | +0.0 | 0.0 | 186.7 | 14.0 | +0.0 | 0.0 | 44.0 |
| HOLDER ASSIGNMENT | 10.3 | +1023.6 | 0.0 | 93.3 | 10.0 | +843.2 | 0.0 | 22.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.0 | -169.3 | 287.0 | 0.0 | 3.0 | -131.4 | 273.7 | 65.0 |
| IDLE COST | 5.3 | -92.1 | 0.0 | 0.0 | 9.0 | -118.0 | 0.0 | 63.7 |
| JOINT CHARGE NOW | - | - | - | - | 1.7 | +195.3 | 47.7 | 0.0 |
| KEPT FROM ITS LAST STOP | 4.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.7 | +82.5 | 0.0 | 0.0 | 1.0 | +20.0 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 9.0 | +0.0 | 332.7 | 569.3 | 4.3 | +0.0 | 261.3 | 243.7 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.3 | +37.5 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.3 | +1.1 | 47.7 | 0.0 |
| LOST AFTER ESCAPE | 1.3 | +1.8 | 165.0 | 0.0 | 3.7 | +2.1 | 191.3 | 130.0 |
| MANOEUVRE | 1.0 | +0.0 | 0.0 | 0.0 | 2.7 | -4.6 | 0.0 | 36.7 |
| MARCH AT ESCAPER | 0.3 | +3.5 | 0.0 | 0.0 | 0.3 | +22.4 | 0.0 | 99.0 |
| MARCH BY THE SUM | 0.3 | +14.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | - | - | - | - | 0.3 | +10.2 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 1.0 | +25.8 | 0.0 | 0.0 | 0.7 | +22.9 | 0.0 | 151.7 |
| MARCH OVER CASTS | 1.7 | +278.0 | 0.0 | 0.0 | 0.7 | -49.4 | 0.0 | 151.7 |
| MARCH WHEELS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.7 | +19.3 | 0.0 | 0.0 | 3.0 | +101.6 | 0.0 | 61.7 |
| MEETS IN TIME | 3.3 | +208.6 | 0.0 | 0.0 | 6.0 | +79.8 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.7 | +39.8 | 0.0 | 0.0 | 2.0 | +49.8 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 6.3 | +29.9 | 0.0 | 0.0 | 3.3 | +64.9 | 0.0 | 151.7 |
| MOVE ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 123.3 | 11.3 |
| MOVE SPELL SPOT | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 6.3 | +653.5 | 0.0 | 95.3 | 5.3 | +579.9 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 8.3 | +348.2 | 0.0 | 50.3 | 9.3 | +368.1 | 0.0 | 59.0 |
| NEAREST TO GOAL | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 5.3 | +545.4 | 0.0 | 95.3 | 4.3 | +374.4 | 0.0 | 61.7 |
| NEXT OBJECTIVE NEARER | 1.0 | -21.6 | 0.0 | 0.0 | 0.3 | -77.3 | 0.0 | 52.7 |
| NO DOUBLE ROUNDS | 2.7 | -146.5 | 265.0 | 0.0 | 4.3 | -360.9 | 273.7 | 195.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 6.3 | -320.2 | 0.0 | 47.7 | 5.3 | -332.0 | 0.0 | 72.7 |
| ONE CHECK AFTER THE LAST CHANGE | 1.3 | +0.0 | 0.0 | 93.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 6.0 | -157.1 | 0.0 | 47.7 | 5.0 | -104.8 | 0.0 | 85.0 |
| ONE JOINT FIGURE | - | - | - | - | 1.0 | +50.6 | 47.7 | 0.0 |
| ONE OBJECTIVE FORMULA | 5.3 | +80.6 | 0.0 | 93.3 | 5.3 | -199.8 | 0.0 | 22.0 |
| ONE ROUTE | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +5.6 | 22.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 1.7 | +67.0 | 166.0 | 0.0 | 1.3 | +11.8 | 59.0 | 65.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.7 | -41.1 | 0.0 | 0.0 |
| PLAN RESULT | 42.0 | +296.1 | 535.7 | 615.3 | 47.7 | +569.9 | 315.7 | 1220.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 9.3 | -268.1 | 0.0 | 0.0 | 14.0 | -567.4 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | -0.5 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.7 | -6.4 | 23.3 | 0.0 | - | - | - | - |
| QUARTER ODDS | 17.0 | +1490.0 | 312.7 | 280.0 | 18.3 | +2198.4 | 23.3 | 235.3 |
| REAL GROUND | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 3.7 | +197.0 | 0.0 | 57.3 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 4.3 | +0.0 | 0.0 | 68.7 |
| REDIRECT WEIGHED | 0.3 | +5.5 | 41.7 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 1.0 | -29.4 | 0.0 | 0.0 | 1.7 | -41.2 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 164.0 |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +8.0 | 0.0 | 22.0 |
| RISK BY ARC | 2.7 | -70.3 | 287.0 | 0.0 | 4.0 | -100.1 | 250.3 | 130.0 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 1.0 | -49.0 | 99.0 | 0.0 | 2.3 | -50.9 | 167.0 | 65.0 |
| RUN DOWN | 2.3 | -37.5 | 243.0 | 0.0 | 4.7 | -42.9 | 250.3 | 195.0 |
| SCOUT SPOT | - | - | - | - | 1.3 | -0.1 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | -81.5 | 0.0 | 22.7 |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +113.2 | 0.0 | 61.7 |
| SECOND LOOK | 0.3 | +17.1 | 0.0 | 0.0 | 1.0 | +8.8 | 50.3 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 0.7 | -44.0 | 0.0 | 0.0 |
| SET UP BY THE SET | - | - | - | - | 1.7 | +136.2 | 0.0 | 61.7 |
| SET-UP ANY TARGET | 0.7 | +80.9 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +2.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 9.3 | +0.0 | 0.0 | 46.7 | 6.0 | +0.0 | 0.0 | 89.3 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +33.1 | 0.0 | 0.0 | 1.7 | +129.6 | 0.0 | 61.7 |
| SHOT OR CHARGE | - | - | - | - | 0.7 | -17.8 | 0.0 | 0.0 |
| SHOT RISK POINTS | 39.7 | -418.9 | 0.0 | 196.0 | 24.7 | -142.0 | 0.0 | 300.3 |
| SHOTS AFTER THE MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 15.3 | +306.3 | 0.0 | 105.7 | 20.3 | +688.0 | 0.0 | 336.7 |
| SPELL SETS UP CHARGE | 0.7 | +80.9 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 1.7 | +41.2 | 0.0 | 0.0 | 2.0 | +49.4 | 226.3 | 226.3 |
| SPELLS IN THE FIGHT | - | - | - | - | 1.3 | -14.2 | 47.7 | 65.0 |
| SPOT AS THE GAME MOVES | 7.0 | +0.0 | 0.0 | 98.0 | 6.0 | +0.0 | 0.0 | 173.0 |
| STAND AND SHOOT | 1.3 | -11.4 | 100.0 | 0.0 | 1.0 | -5.9 | 23.3 | 65.0 |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 41.7 | +0.0 | 834.0 | 270.3 | 38.3 | +0.0 | 0.0 | 432.3 |
| STAY WORTH | 24.3 | +90.0 | 574.0 | 70.0 | 17.3 | +95.5 | 0.0 | 114.3 |
| SUPPORT ADDS | 4.7 | +191.5 | 0.0 | 202.7 | 12.0 | +741.9 | 0.0 | 155.7 |
| SUPPORT NARROWED | - | - | - | - | 0.7 | +0.0 | 47.7 | 0.0 |
| SUPPORT WORKED OUT | 4.7 | +191.5 | 0.0 | 202.7 | 12.0 | +741.9 | 0.0 | 155.7 |
| SURE REACH TOGETHER | 0.7 | +12.4 | 0.0 | 0.0 | - | - | - | - |
| SWIFTSTRIDE BY POINTS | 0.7 | +6.3 | 0.0 | 50.3 | 0.3 | +0.5 | 0.0 | 11.3 |
| THE DEARER SUM KEEPS ITS PLAN | 3.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 61.7 |
| THE ROW IN ITS ORDER | 3.3 | +0.0 | 0.0 | 50.3 | 3.3 | +0.0 | 0.0 | 78.0 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 0.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 45.7 | +0.0 | 0.0 | 347.3 | 47.3 | +0.0 | 0.0 | 590.0 |
| TIED UP BY THE SUM | 1.7 | +174.9 | 135.3 | 0.0 | 1.7 | +284.6 | 202.7 | 65.0 |
| TIME ON OUR SIDE | 35.7 | +396.6 | 44.0 | 207.3 | 30.7 | +342.7 | 0.0 | 556.7 |
| WAITS AGAIN | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 61.7 |
| WALKS ON ITS ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | 1.3 | +176.4 | 0.0 | 115.7 | 0.3 | +66.8 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 1.7 | -120.7 | 0.0 | 100.7 | 2.3 | -347.2 | 0.0 | 221.3 |
| WHOLE FIGHT GAIN | - | - | - | - | 1.0 | +49.6 | 47.7 | 0.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 0.3 | +30.4 | 0.0 | 52.7 |

### Rule changes: gs3-83c8646-p20

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 386 | 367 | 119 | 39.67 | +2030 | +17.1 |
| ARMY TABLE | 156 | 156 | 114 | 38.00 | +1153 | +10.1 |
| HIS SHOTS BY HIS RUN | 285 | 273 | 75 | 25.00 | +1401 | +18.7 |
| HOLDER ASSIGNMENT | 61 | 61 | 57 | 19.00 | +2900 | +50.9 |
| LEGAL CHARGES ONLY | 40 | 40 | 40 | 13.33 | +0 | +0.0 |
| SHOT RISK POINTS | 193 | 190 | 39 | 13.00 | +1354 | +34.7 |
| OFF BEST | 35 | 35 | 35 | 11.67 | -1957 | -55.9 |
| DEPLOY BY FIGURES | 52 | 52 | 32 | 10.67 | +353 | +11.0 |
| PROMISE BY ITS OWN SUM | 70 | 70 | 28 | 9.33 | -2506 | -89.5 |
| SUPPORT ADDS | 50 | 49 | 26 | 8.67 | +454 | +17.5 |
| SUPPORT WORKED OUT | 50 | 49 | 26 | 8.67 | +454 | +17.5 |
| QUARTER ODDS | 106 | 106 | 22 | 7.33 | +1539 | +69.9 |
| THE TABLE AGAIN | 36 | 36 | 22 | 7.33 | +0 | +0.0 |
| FIVE ACTION | 589 | 567 | 20 | 6.67 | +847 | +42.4 |
| MOVE TO CHARGE COMPUTED | 35 | 31 | 20 | 6.67 | +1144 | +57.2 |
| HARD STAY DROPPED | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| TIME ON OUR SIDE | 199 | 163 | 18 | 6.00 | +23 | +1.3 |
| MOVE ORDER | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 29 | 27 | 15 | 5.00 | +1044 | +69.6 |
| MEETS IN TIME | 28 | 28 | 13 | 4.33 | +486 | +37.4 |
| REDIRECT FOR A FRIEND IN REACH | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| ADVANCE LANE KEPT | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| FOUR ROUNDS | 25 | 24 | 12 | 4.00 | +426 | +35.5 |
| GOAL WALK | 38 | 38 | 10 | 3.33 | +292 | +29.2 |
| TIED UP BY THE SUM | 10 | 10 | 9 | 3.00 | +343 | +38.1 |
| LANE BY FIGURES | 8 | 8 | 8 | 2.67 | +308 | +38.5 |
| CHARGE NOW FIRST | 15 | 15 | 7 | 2.33 | -347 | -49.6 |
| SHOOTS FROM THE BEST SPOT | 9 | 9 | 7 | 2.33 | +102 | +14.6 |
| STAY WORTH | 125 | 107 | 7 | 2.33 | +109 | +15.6 |
| CHARGE LOSSES | 104 | 101 | 6 | 2.00 | +81 | +13.5 |
| COVER ONCE | 56 | 37 | 6 | 2.00 | +120 | +20.1 |
| COMBAT PIVOT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| GOAL ROUTE | 5 | 5 | 5 | 1.67 | +241 | +48.2 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | +586 | +117.2 |
| MARCH OF THE TABLE | 5 | 5 | 5 | 1.67 | -146 | -29.3 |
| MAX FOR POSITIONING | 17 | 15 | 5 | 1.67 | +13 | +2.5 |
| SCOUT WAITS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 23 | 23 | 5 | 1.67 | +0 | +0.0 |
| WHO HITS BACK | 5 | 5 | 5 | 1.67 | +154 | +30.9 |
| BOUND ASSAILMENT | 4 | 4 | 4 | 1.33 | +1 | +0.2 |
| CAST JOB | 8 | 8 | 4 | 1.33 | +24 | +5.9 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +268 | +66.9 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +476 | +119.0 |
| IDLE COST | 43 | 33 | 4 | 1.33 | +69 | +17.2 |
| SECOND LOOK | 4 | 4 | 4 | 1.33 | +78 | +19.5 |
| SET UP BY THE SET | 5 | 5 | 4 | 1.33 | +521 | +130.2 |
| SHOTS IN THE MOVE | 107 | 82 | 4 | 1.33 | +171 | +42.7 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FALLS SHORT | 67 | 61 | 3 | 1.00 | +60 | +20.2 |
| FIRE IN ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 3 | 3 | 3 | 1.00 | +21 | +6.8 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +351 | +175.7 |
| CANNON PLANNED TARGET | 12 | 12 | 2 | 0.67 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.67 | +115 | +57.3 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| NEARER NOT NEEDED | 53 | 50 | 2 | 0.67 | +34 | +16.9 |
| ONE JOINT FIGURE | 3 | 3 | 2 | 0.67 | +30 | +15.0 |
| ONE OBJECTIVE FORMULA | 32 | 28 | 2 | 0.67 | +47 | +23.4 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.67 | -123 | -61.7 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -19 | -9.5 |
| RISK BY ARC | 20 | 19 | 2 | 0.67 | +113 | +56.7 |
| SEARCH SPOT | 3 | 3 | 2 | 0.67 | +339 | +169.7 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +6 | +3.0 |
| SUPPORT NARROWED | 2 | 2 | 2 | 0.67 | -60 | -29.9 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +1 | +0.6 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -37 | -36.7 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -3 | -3.0 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EVASIVE BY THE ODDS | 5 | 5 | 1 | 0.33 | +2 | +1.7 |
| FIGHT TO THE END | 4 | 4 | 1 | 0.33 | +7 | +7.2 |
| HIS CHARGE DENIED | 5 | 4 | 1 | 0.33 | +23 | +22.8 |
| HIS TURN DENIED | 3 | 3 | 1 | 0.33 | +2 | +1.6 |
| HONEST WORTH | 18 | 18 | 1 | 0.33 | +58 | +57.7 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +112 | +112.5 |
| MANOEUVRE | 11 | 11 | 1 | 0.33 | +29 | +28.9 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +43 | +43.0 |
| MARCH CHECK | 1 | 1 | 1 | 0.33 | +23 | +23.0 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +8 | +8.1 |
| OVERRUNS AWAY | 9 | 9 | 1 | 0.33 | +58 | +57.7 |
| PROMISE KNOWS THE FIGHT | 6 | 4 | 1 | 0.33 | -1 | -1.4 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +13 | +13.1 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +24 | +24.0 |
| SURE REACH TOGETHER | 2 | 2 | 1 | 0.33 | +2 | +2.0 |
| THE ROW IN ITS ORDER | 20 | 1 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 12 | 12 | 1 | 0.33 | +12 | +11.6 |
| WHOLE FIGHT GAIN | 3 | 3 | 1 | 0.33 | +7 | +7.2 |
| WOUNDS ON THE RANKS | 1 | 1 | 1 | 0.33 | +18 | +18.3 |
| BACKUP TARGETS | 3 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 7 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 62 | 62 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 9 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 3 | 3 | 0 | 0.00 | - | - |
| EXACT ROUND | 12 | 11 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 22 | 21 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 11 | 11 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 46 | not checked | - | - | - | - |
| FOOT FIRST | 75 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 27 | 26 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 3 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 6 | not checked | - | - | - | - |
| GUN MASK | 6 | 6 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 14 | 14 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 80 | 79 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 43 | 42 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 29 | 27 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 37 | 37 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 29 | 29 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 38 | 35 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 98 | 98 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 18 | 18 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 15 | 14 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 7 | 7 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 7 | 7 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 17 | 16 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 29 | 23 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 7 | not checked | - | - | - | - |
| NEAREST TO GOAL | 2 | 2 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 4 | 4 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 21 | 20 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 5 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 33 | 20 | 0 | 0.00 | - | - |
| ONE ROUTE | 7 | 7 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 269 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 7 | 7 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 11 | 7 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 8 | 8 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 3 | 3 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 10 | 10 | 0 | 0.00 | - | - |
| RUN DOWN | 21 | 20 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 2 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 46 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 2 | not checked | - | - | - | - |
| SPELL WORTH | 11 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 4 | 3 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 39 | 32 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 7 | 7 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 13 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 240 | 224 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 12 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 16 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 8 | not checked | - | - | - | - |
| THE TABLE BINDS | 279 | not checked | - | - | - | - |
| WAITS AGAIN | 10 | 9 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p20

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.67 | 4.67 | 62.8 |
| PROMISE BY ITS OWN SUM | rule | 3.67 | 5.67 | 89.5 |
| ARMY TABLE | rule | 6.67 | 2.33 | 33.1 |
| CHARGE NOW FIRST | rule | 0.67 | 1.67 | 49.6 |
| MARCH OF THE TABLE | rule | 0.67 | 0.67 | 36.6 |
| HOLDER ASSIGNMENT | rule | - | 1.00 | 37.5 |
| AFTERMATH BAND | gate | 0.33 | 0.33 | 3.1 |
| DEPLOY BY FIGURES | rule | - | 0.67 | 6.2 |
| FIGHT ORDER BAND | gate | 0.33 | 0.33 | 2.6 |
| JOINT CHARGE NOW | rule | - | 0.67 | 24.8 |
| PIVOT GUARDS FLANK | rule | - | 0.67 | 61.7 |
| PROMISE SHOT AWAY | rule | 0.67 | - | 9.5 |
| SUPPORT NARROWED | rule | - | 0.67 | 29.9 |
| BEST PRIZE | rule | - | 0.33 | 36.7 |
| CHAFF PASSED | rule | 0.33 | - | 3.0 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.33 | 1.4 |
| WHO HITS BACK | rule | 0.33 | - | 2.7 |

### Plans: gs3-83c8646-p20

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 71% | 317 | 234 | 74% |
| Mine | move | 31.7 | 98% | 1558 | 0 | 0% |
| Mine | shoot | 8.0 | 29% | 261 | 62 | 24% |
| Opponent | charge | 4.3 | 46% | 659 | 379 | 57% |
| Opponent | move | 39.0 | 93% | 2167 | 0 | 0% |
| Opponent | shoot | 4.0 | 42% | 407 | 191 | 47% |
| Opponent | support | 0.3 | 100% | 0 | 0 | - |

### Battle groups: gs3-83c8646-p20

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 3.7 | 27% | 67% | 33% | 0% | 0% | 0% | 0% | 50% | 50% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p20

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 7 | 60 (7) | 60 | 0 | 12 | 0% | 1.6 | 36 (5) | 217 (1) | 0 (1) | 29 (5) | 121 (2) |
| Mine | Clean-up | 1 | 78 (1) | 0 | 78 | 122 | 0% | 2.0 | 78 (1) | - | - | 78 (1) | - |
| Mine | Fast Hammer | 14 | 66 (14) | 26 | 41 | 15 | 57% | 2.5 | 66 (8) | 67 (6) | - | 60 (9) | 78 (5) |
| Mine | Shooter | 4 | 0 (4) | 0 | 0 | 26 | 0% | 1.0 | 0 (3) | 0 (1) | - | 0 (3) | 0 (1) |
| Mine | War machine | 2 | 50 (2) | 50 | 0 | 50 | 0% | 1.0 | 50 (2) | - | - | - | 50 (2) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 7 | 176 (7) | 0 | 176 | 89 | 14% | 2.5 | - | 345 (4) | 16 (3) | 405 (4) | 14 (3) |
| Opponent | Character | 4 | 42 (4) | 42 | 0 | 0 | 0% | 1.2 | - | 42 (4) | - | 0 (2) | 78 (2) |
| Opponent | Clean-up | 4 | 42 (4) | 42 | 0 | 20 | 50% | 1.0 | 0 (1) | 70 (2) | 0 (1) | 52 (3) | 0 (1) |
| Opponent | Fast Hammer | 4 | 60 (4) | 51 | 9 | 81 | 0% | 1.8 | 17 (2) | 108 (2) | - | 13 (3) | 178 (1) |
| Opponent | Hammer | 8 | 0 (8) | 0 | 0 | 55 | 25% | 2.7 | 0 (2) | 0 (3) | 0 (3) | 0 (4) | 0 (4) |
| Opponent | Holder | 3 | 141 (3) | 0 | 141 | 31 | 33% | 2.0 | 205 (2) | - | 0 (1) | 450 (1) | 0 (2) |
| Opponent | Shooter | 4 | 55 (4) | 0 | 55 | 0 | 0% | 1.5 | 0 (1) | 118 (2) | 0 (1) | 94 (2) | 28 (2) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 101 | 0% | 2.3 | 0 (1) | - | - | - | 0 (1) |

### Charged fights: gs3-83c8646-p20

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 3 | 110 | 330 | 2.3 | 1.0 | 141 | 0 | +141 | 2 of 7 | 7 of 7 | - | +141 |
| Opponent | Ogre Kingdoms | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 17 | -17 | 1 of 2 | 0 of 2 | - | -17 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 1025 | 9.0 | 1.0 | 114 | 22 | +92 | 3 of 9 | 5 of 9 | - | +92 |
| Opponent | Wood Elf Realms | 1 | 0 | 143 | 2.0 | 1.0 | 72 | 0 | +72 | 1 of 2 | 0 of 2 | - | +72 |
| **Opponent** | all armies | 3 | 0 | 389 | 4.3 | 1.0 | 90 | 18 | +72 | 5 of 13 | 5 of 13 | - | +72 |

### Effective charges: gs3-83c8646-p20

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 7 | 0 | 0 | 1 (net +0) | 0 | 3 (net +81) | 2 (net +310) | 1 | 17% (1 of 6) |
| Opponent | Tomb Kings of Khemri | 9 | 2 (net +76) | 0 | 0 | 1 (net +0) | 0 | 4 (net +88) | 2 | 0% (0 of 7) |
| Opponent | Wood Elf Realms | 2 | 1 (net +143) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |

### Charged fights, damage counted: gs3-83c8646-p20

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 489 | 297 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 489 | 242 | +310 | 363 | 0 | +363 | +74.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 295 | 57 | +81 | 81 | 0 | +81 | +27.5 |
| Mine | No odds | 1 | 489 | 125 | +125 | 183 | 375 | -192 | -39.3 |
| Mine | All fights | 7 | 406 | 154 | +141 | 164 | 54 | +111 | +27.3 |
| Opponent | Long shot (under 50%) | 3 | 164 | 244 | +98 | 163 | 82 | +81 | +49.6 |
| Opponent | 76-89% | 1 | 195 | 400 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 374 | 200 | +88 | 132 | 0 | +132 | +35.3 |
| Opponent | No odds | 5 | 221 | 283 | +59 | 72 | 23 | +49 | +22.2 |
| Opponent | All fights | 13 | 253 | 257 | +72 | 106 | 28 | +78 | +30.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p20 | move | 26 | 6 (23%) | 4 (15%) | 3 (12%) | 17 (65%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Fistful of Laurels | Opponent | L1418 |
| Opal Amulet | Mine | L1418, L1435 |
| Standard of the Fell Warrior | Mine | L1323 |

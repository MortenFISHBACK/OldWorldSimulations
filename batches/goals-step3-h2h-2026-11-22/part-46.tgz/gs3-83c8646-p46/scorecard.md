# Doctrine scorecard: gs3-83c8646-p46

### Scorecard: gs3-83c8646-p46

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1835 | 5 | 1 | Mine | no | - | 2 | 1 | 4 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | no | - | - | 0 | 5 | 0 | 0 | 0 | 110 |
| L2021 | 5 | 1 | Mine | no | - | - | 1 | 4 | 0 | 0 | 0 | 130 |
| L2021 | 5 | 1 | Opponent | no | - | - | 0 | 7 | 0 | 0 | 0 | 0 |
| L2123 | 5 | 1 | Mine | yes | - | - | 0 | 6 | 0 | 0 | 0 | 145 |
| L2123 | 5 | 1 | Opponent | yes | - | 3 | 4 | 0 | 1 | 0 | 0 | 72 |
| **Average** | | | Mine | 33% | - | 2.0 | 0.7 | 4.7 | 0.0 | 0.0 | 0.0 | 91.7 |
| **Average** | | | Opponent | 33% | - | 3.0 | 1.3 | 4.0 | 0.3 | 0.0 | 0.0 | 60.7 |

### KPIs: gs3-83c8646-p46

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 15) | 0% (0 of 11) | 0% (0 of 26) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (2 of 2); on the table 100% | 75% (3 of 4); on the table 75% | 83% (5 of 6); on the table 83% |
| Magic missiles tried each own turn | 50%+ | 25% (5 of 20) | 26% (5 of 19) | 26% (10 of 39) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 25% (5 of 20) | 26% (5 of 19) | 26% (10 of 39) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 64% (16 of 25) | 79% (11 of 14) | 69% (27 of 39) |
| Points that never fought | lower | 78% (3850 of 4949) | 78% (4663 of 5999) | 78% (8513 of 10948) |
|   infantry points that never fought | lower | 89% (1055 of 1187) | 91% (1613 of 1770) | 90% (2668 of 2957) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 75% (15 of 20) | 77% (20 of 26) | 76% (35 of 46) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.7 uses a game | 50% (1 of 2); 1.0 uses a game | 75% (3 of 4); 1.8 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 2); 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 33% (1 of 3); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 71% (2943 of 4133) | 77% (3921 of 5082) | 74% (6864 of 9215) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.7 (53%) | 4.3 (93%) | 7.0 (72%) |
| MARCHED: its unit marched | 0.3 (7%) | 0.3 (7%) | 0.7 (7%) |
| REAR RANK: in a rear rank | 0.7 (13%) | 0.0 (0%) | 0.7 (7%) |
| NOT OFFERED: not in the cast list | 1.3 (27%) | 0.0 (0%) | 1.3 (14%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 6.7 | 0.0 | 0.0 | 3.3 | 0.3 |
| not cast | 3.3 | 4.0 | 2.0 | 9.7 | 27.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 4.0 (100%) | 0.0 (0%) | 7.0 (72%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (7%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (60%) | 0.0 (0%) | 2.0 (100%) | 0.7 (7%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (14%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.3 (40%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 27.3 (99%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (47 of 71) | 56% (61 of 109) | 60% (108 of 180) |
|   cavalry | - | 81% (22 of 27) | 81% (22 of 27) |
|   character | 83% (5 of 6) | 7% (1 of 15) | 29% (6 of 21) |
|   chariot | 88% (15 of 17) | 73% (8 of 11) | 82% (23 of 28) |
|   infantry | 42% (15 of 36) | 54% (30 of 56) | 49% (45 of 92) |
|   monster | 100% (12 of 12) | - | 100% (12 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.3 (4%) | 1.7 (10%) | 2.0 (8%) |
| CHARGED: it charged | 0.7 (8%) | 0.7 (4%) | 1.3 (6%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 1.0 (6%) | 1.0 (4%) |
| NO TARGET IN RANGE | 5.7 (71%) | 9.3 (58%) | 15.0 (62%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (4%) | 0.3 (2%) | 0.7 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (8%) | 2.7 (17%) | 3.3 (14%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.3 (2%) | 0.3 (1%) |
| OTHER BAR | 0.3 (4%) | 0.0 (0%) | 0.3 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 10.0 | 3.0 | 77% | 5.2 pts | 52 pts |
| character | 2.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 7.7 | 2.3 | 83% | 5.2 pts | 40 pts |
| infantry | 16.0 | 7.3 | 77% | 8.0 pts | 128 pts |
| monster | 4.0 | 0.0 | 100% | 0.0 pts | 0 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.7 | 2.3 | 2.0 |
| Charges that made contact a game | 1.3 | 0.7 | 1.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.19 declared, 0.15 contact (27 units) | 0.21 declared, 0.06 contact (33 units) | 0.20 declared, 0.10 contact (60 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (2 of 3) | - | - | 67% (2 of 3) |
| Character in a unit | 100% (5 of 5) | 100% (2 of 2) | - | 100% (7 of 7) |
| Character on its own | - | 100% (1 of 1) | 60% (3 of 5) | 67% (4 of 6) |
| Chariot | 33% (2 of 6) | - | - | 33% (2 of 6) |
| Infantry | 91% (10 of 11) | 100% (2 of 2) | - | 92% (12 of 13) |
| Monster | 50% (1 of 2) | 60% (3 of 5) | - | 57% (4 of 7) |
| Monstrous | 100% (2 of 2) | 100% (2 of 2) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ogre Kingdoms | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 96% | 86% (6 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Skaven | 3 | 100% (2 of 2); on the table 100% | 48% (10 of 21) | 70% | 73% (16 of 22) | 100% (2 of 2); 2.3 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Tomb Kings of Khemri | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 6) | 61% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 0% (0 of 1); on the table 0% | 0% (0 of 6) | 94% | 83% (10 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p46, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | - | 0% (0) | 0% (0) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p46

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.0 | 1.7 |
| Strategy | Charge objectives carried out (made contact) | 80% (4 of 5) | 0% (0 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 73% (22 of 30) | 44% (14 of 32) |
| Strategy | Support requests answered (helper made contact too) | 100% (2 of 2) | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 0% (0 of 4) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 50% (1 of 2) | 25% (1 of 4) |
| Movement | Charges halted short of contact | 0.3 | 0.3 |
| Movement | Idle units | 4.7 | 4.0 |
| Movement | Points that never moved of their own | 91.7 | 60.7 |
| Movement | Fights charged into per game | 1.0 | 0.7 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 3, net -38 | - |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 3 | - |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 3 | - |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 3 | - |
| Shooting | Shots by shooting units (incl. breath weapons) | 15.7 | 22.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 30% (14 of 47) | 35% (23 of 66) |
| Shooting | Points destroyed by shooting units | 91.7 | 139.7 |
| Shooting | Points destroyed by war machines | 34.0 | 0.0 |
| Magic | Magic missiles cast | 1.3 | 2.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 4) | 17% (1 of 6) |
| Magic | Wounds caused by magic missiles | 5.3 | 2.0 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.0 / 0.3 / 0.0 | 3.3 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 116.7 | 70.0 |
| Combat | Points run down | 38.0 | 12.7 |
| Combat | Net points per charged fight, damage counted | +58 | -124 |
| Combat | Net per 100 charger points, damage counted | +120.0 | -93.3 |
| Combat | First round won (charged fights) | 0% | 50% |
| Combat | Net points per charged fight | +25 | +11 |
| Combat | Net points per supported fight / lone fight | +114 / -19 | - / +11 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 3 | 1 of 2 |
| Game | Points lost | 253.0 | 280.3 |
| Game | VP from objectives | 700.0 | 483.3 |

- Mine won / drew / lost: 1 / 2 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +261 VP
- The side that went first won 0 of 1 games with a winner
- Points traded per game (both sides' losses): 533
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p46

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 17.0 | +76.0 | 0.0 | 102.7 | 37.0 | +485.1 | 0.0 | 146.3 |
| BEST PRIZE | - | - | - | - | 0.7 | -32.4 | 100.7 | 0.0 |
| CAST JOB | 0.7 | +14.8 | 0.0 | 0.0 | 1.0 | +2.0 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 3.3 | +166.1 | 76.0 | 0.0 | 0.7 | +11.2 | 22.7 | 0.0 |
| CHAFF IN THE MOVE | 3.0 | +107.5 | 0.0 | 18.3 | - | - | - | - |
| CHAFF PASSED | 0.7 | -0.9 | 0.0 | 0.0 | 1.3 | -5.2 | 0.0 | 0.0 |
| CHARACTER GUNS | 4.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LIST READ AGAIN | - | - | - | - | 0.3 | +12.8 | 70.0 | 0.0 |
| CHARGE LOSSES | 13.7 | -692.2 | 0.0 | 123.3 | 18.3 | -700.8 | 0.0 | 231.0 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 38.0 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 6.7 | +0.0 | 0.0 | 30.7 | 8.7 | +0.0 | 0.0 | 70.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 70.0 | 0.7 | +0.0 | 0.0 | 23.3 |
| COVER ONCE | 6.7 | -261.7 | 0.0 | 92.3 | 5.0 | -175.4 | 0.0 | 61.3 |
| DENIED BY THE FIGHT | 0.7 | -1.8 | 38.0 | 0.0 | 0.3 | -2.3 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 8.0 | +39.9 | 0.0 | 0.0 | 8.7 | -90.4 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -22.0 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 1.3 | +10.6 | 0.0 | 0.0 |
| EXACT ROUND | 1.3 | -13.1 | 114.0 | 0.0 | 2.0 | +11.4 | 70.0 | 46.7 |
| FALL BACK GOOD ORDER | 1.0 | +0.1 | 38.0 | 12.7 | 2.3 | +24.5 | 70.0 | 46.7 |
| FALLS SHORT | 8.7 | +99.9 | 0.0 | 30.7 | 14.3 | +104.7 | 0.0 | 38.0 |
| FEATURE BUFFS | 2.0 | +12.1 | 0.0 | 0.0 | 0.3 | +1.6 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.0 | +5.1 | 76.0 | 0.0 | 0.3 | +0.5 | 0.0 | 23.3 |
| FIRE IN ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 113.0 | +6063.8 | 666.0 | 596.7 | 119.7 | +6402.1 | 1363.0 | 715.3 |
| FLANK NOT WEIGHED | 4.3 | +0.0 | 0.0 | 92.3 | 2.3 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.7 | +26.2 | 0.0 | 0.0 | 1.0 | +156.0 | 0.0 | 0.0 |
| FOOT FIRST | - | - | - | - | 29.3 | +0.0 | 0.0 | 176.0 |
| FOUR ROUNDS | 1.7 | +59.7 | 114.0 | 12.7 | 2.3 | +87.4 | 70.0 | 46.7 |
| FREED FROM HIS FIGHT | 3.7 | +0.0 | 0.0 | 80.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -5.8 | 0.0 | 0.0 | 3.3 | -21.7 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 1.0 | -7.4 | 0.0 | 46.7 |
| GIVES UP ITS SCREEN | 0.7 | -5.1 | 76.0 | 0.0 | - | - | - | - |
| GOAL ROUTE | - | - | - | - | 0.3 | +0.7 | 0.0 | 0.0 |
| GOAL WALK | 9.7 | +609.6 | 0.0 | 0.0 | 12.3 | +774.0 | 0.0 | 0.0 |
| GUN FIGURES | 3.3 | +29.5 | 0.0 | 61.7 | 1.0 | +0.0 | 12.7 | 21.7 |
| HARD STAY DROPPED | 2.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.0 | +0.0 | 0.0 | 18.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 6.3 | +0.0 | 0.0 | 61.7 | 5.7 | +0.0 | 0.0 | 46.7 |
| HIS CHARGE LIST | 8.3 | +0.0 | 0.0 | 106.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.3 | -23.5 | 0.0 | 0.0 | 1.7 | -44.8 | 0.0 | 0.0 |
| HIS ONE QUARTER | 3.3 | +0.0 | 0.0 | 18.3 | 17.3 | +0.0 | 0.0 | 179.3 |
| HIS OWN BEST MOVE | - | - | - | - | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 15.0 | +0.0 | 0.0 | 0.0 | 36.0 | +0.0 | 0.0 | 456.7 |
| HIS RANDOM MOVER COMES | 1.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 48.3 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 64.3 | +1591.1 | 0.0 | 260.0 | 57.3 | +1532.3 | 0.0 | 413.3 |
| HIS SHOTS BY HIS RUN | 41.0 | +566.0 | 0.0 | 301.0 | 46.0 | +811.2 | 0.0 | 182.7 |
| HIS TURN DENIED | 1.3 | +74.4 | 114.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| HOLD ODDS | 12.3 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 5.7 | +567.3 | 0.0 | 0.0 | 4.0 | +277.1 | 0.0 | 38.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.7 | -9.9 | 38.0 | 0.0 | 1.7 | -53.5 | 70.0 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 0.3 | +13.0 | 0.0 | 0.0 |
| IDLE COST | 4.7 | -59.2 | 0.0 | 0.0 | 13.3 | -173.7 | 0.0 | 0.0 |
| JOINT CHARGE NOW | 1.0 | -35.0 | 114.0 | 0.0 | 0.7 | +68.3 | 0.0 | 23.3 |
| KEPT FROM ITS LAST STOP | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 1.0 | +47.3 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 1.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 140.0 | 251.3 |
| LONE WIZARD KEPT IN | 0.7 | +58.5 | 0.0 | 0.0 | 0.7 | +54.5 | 0.0 | 0.0 |
| LONG SHOT | 0.7 | -8.8 | 38.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 1.7 | -0.3 | 114.0 | 12.7 | - | - | - | - |
| LURE BY WHAT IT DRAWS | 1.3 | -50.9 | 0.0 | 36.7 | - | - | - | - |
| MANOEUVRE | 1.7 | +9.0 | 0.0 | 0.0 | 1.7 | -10.4 | 0.0 | 23.3 |
| MARCH AT ESCAPER | 0.3 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.3 | +16.0 | 0.0 | 0.0 | 0.7 | +44.5 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +48.4 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 0.3 | +1.6 | 0.0 | 0.0 | 1.3 | +27.4 | 0.0 | 23.3 |
| MEETS IN TIME | 2.7 | +13.9 | 0.0 | 0.0 | 2.0 | +2.7 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 7.0 | +172.4 | 0.0 | 0.0 | 5.0 | +92.6 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 6.3 | +67.4 | 0.0 | 0.0 | 5.7 | +65.8 | 0.0 | 0.0 |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 34.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 1.3 | +50.9 | 0.0 | 0.0 | 7.0 | +462.6 | 0.0 | 46.7 |
| NEARER NOT NEEDED | 11.3 | +490.6 | 0.0 | 0.0 | 11.3 | +475.2 | 0.0 | 38.0 |
| NEAREST TO GOAL | - | - | - | - | 3.3 | +0.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | - | - | - | - | 5.3 | +336.0 | 0.0 | 46.7 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.7 | -3.8 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.7 | -61.8 | 114.0 | 12.7 | 1.7 | -23.1 | 0.0 | 46.7 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.1 | 0.0 | 0.0 | 1.0 | -0.4 | 0.0 | 0.0 |
| OFF BEST | 1.3 | -19.0 | 0.0 | 0.0 | 2.0 | -101.8 | 70.0 | 0.0 |
| ONE FIGHT FORMULA | 2.7 | -27.0 | 0.0 | 61.7 | 3.3 | -104.8 | 0.0 | 23.3 |
| ONE JOINT FIGURE | 0.7 | -4.7 | 76.0 | 0.0 | 0.7 | +30.9 | 0.0 | 23.3 |
| ONE OBJECTIVE FORMULA | 3.3 | +100.2 | 0.0 | 0.0 | 2.7 | +84.6 | 0.0 | 38.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | +2.3 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +19.6 | 0.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 1.0 | +10.6 | 0.0 | 23.3 |
| PATHS CROSS | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | -6.6 | 0.0 | 0.0 |
| PERIAPT WORTH | - | - | - | - | 0.3 | +20.4 | 0.0 | 0.0 |
| PLAN RESULT | 54.3 | +295.3 | 459.3 | 592.7 | 53.0 | +419.6 | 612.7 | 560.7 |
| PROMISE BELOW ZERO | - | - | - | - | 0.7 | +0.0 | 0.0 | 23.3 |
| PROMISE BY ITS OWN SUM | 1.3 | -7.3 | 0.0 | 0.0 | 5.0 | -147.4 | 0.0 | 0.0 |
| PROMISE IN STEPS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 0.7 | -42.2 | 0.0 | 0.0 | 1.3 | -4.1 | 0.0 | 0.0 |
| QUARTER ODDS | 33.7 | +2084.7 | 476.0 | 245.3 | 36.0 | +3151.3 | 68.0 | 357.7 |
| RANDOM MOVE BY FIGURES | 8.3 | +277.2 | 0.0 | 166.7 | 4.7 | +71.0 | 0.0 | 236.7 |
| REDIRECT COUNTER | 3.0 | +81.7 | 0.0 | 0.0 | 0.3 | +9.0 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.3 | +0.0 | 0.0 | 62.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.7 | -32.4 | 100.7 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -29.7 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 2.7 | +59.4 | 0.0 | 38.0 |
| RISK BY ARC | 1.7 | +34.2 | 114.0 | 12.7 | 2.0 | -19.9 | 70.0 | 46.7 |
| RUN DOWN | 1.3 | -8.4 | 114.0 | 0.0 | 1.0 | -0.1 | 0.0 | 23.3 |
| SCOUT SPOT | 0.7 | -0.2 | 0.0 | 0.0 | 0.7 | +2.2 | 0.0 | 0.0 |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 3.0 | -137.7 | 0.0 | 25.3 | - | - | - | - |
| SEARCH SPOT | - | - | - | - | 0.3 | -2.9 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.7 | +13.8 | 70.0 | 23.3 |
| SET UP BY THE SET | - | - | - | - | 2.0 | -33.7 | 0.0 | 46.7 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 10.7 | +0.0 | 0.0 | 52.7 | 11.0 | +0.0 | 0.0 | 38.0 |
| SHOOTS FROM THE BEST SPOT | 1.7 | +92.5 | 0.0 | 0.0 | 1.3 | +69.5 | 123.3 | 0.0 |
| SHOT OR CHARGE | 0.7 | -33.7 | 38.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 26.3 | +50.0 | 0.0 | 231.0 | 25.7 | +48.0 | 0.0 | 452.7 |
| SHOTS AFTER THE MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.0 | +701.8 | 0.0 | 83.3 | 19.7 | +653.0 | 0.0 | 38.0 |
| SPELL WORTH | 3.7 | +50.6 | 0.0 | 0.0 | 3.0 | +14.5 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | -6.4 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 6.3 | +0.0 | 0.0 | 72.3 | 5.7 | +0.0 | 0.0 | 48.3 |
| STAND AND SHOOT | 0.7 | -4.2 | 76.0 | 0.0 | 1.0 | -7.5 | 0.0 | 23.3 |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 56.0 | +0.0 | 552.0 | 328.3 | 56.3 | +0.0 | 1293.0 | 349.0 |
| STAY WORTH | 22.0 | +504.0 | 280.0 | 61.7 | 30.7 | +530.4 | 1001.0 | 21.7 |
| STUCK PIVOT | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 70.0 |
| SUPPORT ADDS | 4.3 | +435.8 | 0.0 | 30.7 | 11.7 | +129.7 | 0.0 | 46.7 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 4.3 | +435.8 | 0.0 | 30.7 | 11.7 | +129.7 | 0.0 | 46.7 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +7.0 | 0.0 | 38.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.7 | -36.4 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 3.7 | +0.0 | 0.0 | 11.3 | 4.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 4.3 | +0.0 | 0.0 | 30.7 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 2.3 | +0.0 | 0.0 | 30.7 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 53.0 | +0.0 | 0.0 | 239.7 | 56.3 | +0.0 | 0.0 | 216.0 |
| TIED UP BY THE SUM | 0.3 | +30.5 | 38.0 | 0.0 | 0.7 | +32.7 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 41.7 | +361.8 | 0.0 | 61.7 | 26.3 | +217.1 | 0.0 | 23.3 |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 23.3 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -29.4 | 140.0 | 0.0 |
| WHO FIGHTS | 1.0 | -11.9 | 76.0 | 0.0 | 0.3 | -0.5 | 0.0 | 23.3 |
| WHO HITS BACK | 0.3 | +33.3 | 0.0 | 0.0 | 0.3 | +19.4 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +1.8 | 70.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.3 | -293.0 | 0.0 | 0.0 | 5.0 | -185.0 | 0.0 | 48.3 |
| WHOLE FIGHT GAIN | 0.7 | +25.2 | 76.0 | 0.0 | 0.3 | +32.4 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 1.7 | +28.6 | 0.0 | 0.0 | 0.3 | +7.6 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p46

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 162 | 162 | 113 | 37.67 | +1375 | +12.2 |
| HIS SHOT LIST | 365 | 362 | 79 | 26.33 | +1204 | +15.2 |
| HIS SHOTS BY HIS RUN | 261 | 256 | 61 | 20.33 | +472 | +7.7 |
| DEPLOY BY FIGURES | 50 | 50 | 32 | 10.67 | +348 | +10.9 |
| HOLDER ASSIGNMENT | 29 | 29 | 29 | 9.67 | +1747 | +60.2 |
| SHOT RISK POINTS | 156 | 154 | 28 | 9.33 | +533 | +19.0 |
| RANDOM MOVE BY FIGURES | 39 | 39 | 27 | 9.00 | +1045 | +38.7 |
| STAY WORTH | 158 | 141 | 24 | 8.00 | +498 | +20.7 |
| QUARTER ODDS | 209 | 209 | 23 | 7.67 | +2022 | +87.9 |
| TIME ON OUR SIDE | 204 | 188 | 23 | 7.67 | +102 | +4.4 |
| IDLE COST | 54 | 47 | 22 | 7.33 | +154 | +7.0 |
| FIVE ACTION | 698 | 692 | 20 | 6.67 | +1108 | +55.4 |
| THE TABLE AGAIN | 36 | 36 | 19 | 6.33 | +0 | +0.0 |
| HARD STAY DROPPED | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| GOAL WALK | 66 | 66 | 16 | 5.33 | +1098 | +68.7 |
| LEGAL CHARGES ONLY | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| MOVE ORDER | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| CASTING BLOCK | 12 | 12 | 12 | 4.00 | +250 | +20.9 |
| ADVANCE LANE KEPT | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| OFF BEST | 10 | 10 | 10 | 3.33 | -363 | -36.3 |
| CHAFF IN THE MOVE | 9 | 9 | 9 | 3.00 | +8 | +0.9 |
| MOVE TO CHARGE COMPUTED | 25 | 22 | 9 | 3.00 | +447 | +49.7 |
| STUCK PIVOT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| SUPPORT ADDS | 48 | 47 | 9 | 3.00 | +114 | +12.7 |
| SUPPORT WORKED OUT | 48 | 47 | 9 | 3.00 | +114 | +12.7 |
| CHARGE LOSSES | 96 | 96 | 8 | 2.67 | +121 | +15.1 |
| RESERVE FALL BACK | 8 | 8 | 8 | 2.67 | +178 | +22.3 |
| PROMISE BY ITS OWN SUM | 19 | 19 | 7 | 2.33 | -464 | -66.3 |
| THE ROW IN ITS ORDER | 25 | 7 | 7 | 2.33 | +0 | +0.0 |
| CHAFF PASSED | 6 | 6 | 6 | 2.00 | -18 | -3.0 |
| HOLDS AMBUSHERS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| MEETS IN TIME | 14 | 14 | 6 | 2.00 | +74 | +12.4 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +547 | +109.3 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | +100 | +20.0 |
| SCOUT WAITS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 9 | 9 | 5 | 1.67 | +21 | +4.1 |
| FOUR ROUNDS | 12 | 11 | 4 | 1.33 | +124 | +30.9 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +339 | +84.7 |
| MISSILES IN THE MOVE | 36 | 27 | 4 | 1.33 | +53 | +13.3 |
| NEXT CHARGE BY LIST | 16 | 16 | 4 | 1.33 | +203 | +50.8 |
| WHOLE FIGHT DANGER | 22 | 22 | 4 | 1.33 | +72 | +18.0 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FIRE IN ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HIS TURN DENIED | 5 | 5 | 3 | 1.00 | +55 | +18.2 |
| LANE BY FIGURES | 3 | 3 | 3 | 1.00 | +142 | +47.3 |
| MARCH CHECK | 3 | 3 | 3 | 1.00 | +106 | +35.4 |
| BEST PRIZE | 2 | 2 | 2 | 0.67 | -97 | -48.5 |
| CAST JOB | 5 | 5 | 2 | 0.67 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| COVER ONCE | 35 | 28 | 2 | 0.67 | +17 | +8.7 |
| FALLS SHORT | 69 | 62 | 2 | 0.67 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 18 | 13 | 2 | 0.67 | +128 | +64.1 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | -20 | -9.9 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | -31 | -15.4 |
| RISK BY ARC | 11 | 10 | 2 | 0.67 | +34 | +17.0 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +42 | +20.8 |
| SET UP BY THE SET | 6 | 6 | 2 | 0.67 | +11 | +5.6 |
| SHOTS IN THE MOVE | 107 | 75 | 2 | 0.67 | +94 | +46.9 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +128 | +64.0 |
| WHOLE FIGHT GAIN | 3 | 3 | 2 | 0.67 | +34 | +17.0 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +38 | +38.5 |
| GIVES UP | 3 | 3 | 1 | 0.33 | +7 | +7.0 |
| GOAL ROUTE | 1 | 1 | 1 | 0.33 | +2 | +2.0 |
| MANOEUVRE | 10 | 10 | 1 | 0.33 | +27 | +27.0 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -145 | -145.2 |
| MISSILES NEXT TURN | 36 | 28 | 1 | 0.33 | +0 | +0.0 |
| NEARER NOT NEEDED | 68 | 67 | 1 | 0.33 | +29 | +28.7 |
| NO DOUBLE ROUNDS | 10 | 10 | 1 | 0.33 | +7 | +7.0 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | +7 | +6.8 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +57 | +57.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +61 | +61.2 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +21 | +21.0 |
| CHARACTER GUNS | 23 | 23 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 46 | 46 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EVASIVE BY THE ODDS | 4 | 4 | 0 | 0.00 | - | - |
| EXACT ROUND | 10 | 9 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 10 | 9 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 7 | 7 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 20 | not checked | - | - | - | - |
| FOOT FIRST | 88 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 17 | 17 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 12 | 11 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 13 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 10 | 10 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 36 | 36 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 27 | 27 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 8 | 8 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 12 | 12 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 62 | 62 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 9 | 8 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 153 | 151 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 22 | 22 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 58 | 58 | 0 | 0.00 | - | - |
| HONEST WORTH | 7 | 6 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 4 | 4 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 5 | 5 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MAX FOR POSITIONING | 5 | 5 | 0 | 0.00 | - | - |
| NEAREST TO GOAL | 10 | 10 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 18 | 12 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 4 | 4 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 322 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 2 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 6 | 6 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 10 | 9 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 2 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 7 | 7 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 9 | 9 | 0 | 0.00 | - | - |
| SEARCH SPOT | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 65 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 22 | 22 | 0 | 0.00 | - | - |
| SPELL WORTH | 20 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 36 | 30 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 5 | 5 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 9 | 9 | 0 | 0.00 | - | - |
| STANDS STILL | 337 | 335 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 10 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 1 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 23 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 14 | not checked | - | - | - | - |
| THE TABLE BINDS | 328 | not checked | - | - | - | - |
| TIED UP BY THE SUM | 3 | 3 | 0 | 0.00 | - | - |
| WAITS AGAIN | 12 | 11 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | not checked | - | - | - | - |
| WHO FIGHTS | 4 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | not checked | - | - | - | - |
| WOUNDS ON THE RANKS | 6 | 6 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p46

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| ARMY TABLE | rule | 1.33 | 2.67 | 66.6 |
| JOB FIRST | gate | 1.00 | 1.67 | 41.2 |
| PROMISE BY ITS OWN SUM | rule | 0.67 | 1.67 | 66.3 |
| CHAFF PASSED | rule | 0.67 | 1.00 | 3.6 |
| BEST PRIZE | rule | - | 0.67 | 48.5 |
| JOINT CHARGE NOW | rule | 0.67 | - | 68.8 |
| MARCH OF THE TABLE | rule | 0.33 | - | 145.2 |
| NO REASON | gate | - | 0.33 | 2.5 |
| PATHS CROSS | rule | - | 0.33 | 19.9 |
| REDIRECT WEIGHED | rule | - | 0.33 | 34.4 |
| RULE SWITCHED OFF | gate | 0.33 | - | 30.2 |

### Plans: gs3-83c8646-p46

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.7 | 60% | 110 | 120 | 109% |
| Mine | move | 43.3 | 96% | 1544 | 0 | 0% |
| Mine | shoot | 7.3 | 41% | 552 | 175 | 32% |
| Mine | support | 2.0 | 83% | 1 | 0 | 0% |
| Opponent | charge | 2.0 | 0% | 231 | 12 | 5% |
| Opponent | move | 42.0 | 98% | 1626 | 0 | 0% |
| Opponent | shoot | 9.0 | 33% | 726 | 408 | 56% |

### Battle groups: gs3-83c8646-p46

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.0 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p46

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 5 | 56 (5) | 56 | 0 | 44 | 60% | 1.5 | 0 (2) | 106 (3) | - | 56 (5) | - |
| Mine | Character | 6 | 5 (6) | 5 | 0 | 0 | 33% | 2.5 | 6 (4) | 0 (2) | - | 7 (3) | 0 (3) |
| Mine | Clean-up | 6 | 0 (6) | 0 | 0 | 25 | 50% | 4.7 | 0 (3) | 0 (3) | - | 0 (2) | 0 (4) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | Hammer | 11 | 19 (11) | 19 | 0 | 24 | 27% | 1.8 | 15 (6) | 26 (5) | - | 21 (6) | 16 (5) |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Shooter | 4 | 0 (4) | 0 | 0 | 0 | 25% | 3.3 | 0 (3) | 0 (1) | - | 0 (1) | 0 (3) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 0 | 33% | 1.5 | 0 (2) | 0 (1) | - | 0 (1) | 0 (2) |
| Opponent | Character | 8 | 9 (8) | 9 | 0 | 0 | 25% | 3.0 | 0 (6) | 24 (2) | - | 17 (4) | 0 (4) |
| Opponent | Clean-up | 2 | 19 (2) | 19 | 0 | 0 | 50% | 5.0 | 19 (2) | - | - | 41 (1) | 0 (1) |
| Opponent | Fast Hammer | 6 | 34 (6) | 34 | 0 | 17 | 17% | 2.8 | 37 (5) | 0 (1) | - | 19 (4) | 58 (2) |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Hammer | 10 | 20 (10) | 20 | 0 | 34 | 80% | 1.5 | 10 (5) | 29 (5) | - | 9 (6) | 34 (4) |
| Opponent | Holder | 2 | 0 (2) | 0 | 0 | 0 | 50% | 5.0 | - | 0 (2) | - | - | 0 (2) |
| Opponent | Shooter | 8 | 22 (8) | 22 | 0 | 31 | 0% | 2.0 | 43 (4) | 0 (4) | - | 8 (3) | 37 (5) |

### Charged fights: gs3-83c8646-p46

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 1 | 102 | 114 | 2.0 | 1.5 | 57 | 0 | +57 | 0 of 2 | 0 of 2 | +114 | +0 |
| Mine | Skaven | 2 | 138 | 0 | 0.5 | 1.0 | 0 | 38 | -38 | 0 of 1 | 0 of 1 | - | -38 |
| **Mine** | all armies | 3 | 126 | 38 | 1.0 | 1.3 | 38 | 13 | +25 | 0 of 3 | 0 of 3 | +114 | -19 |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 1 | 200 | 92 | 2.0 | 1.0 | 46 | 35 | +11 | 1 of 2 | 1 of 2 | - | +11 |
| Opponent | Wood Elf Realms | 1 | 219 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 140 | 31 | 0.7 | 1.0 | 46 | 35 | +11 | 1 of 2 | 1 of 2 | - | +11 |

### Effective charges: gs3-83c8646-p46

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 2 | 0 | 0 | 0 | 2 (net +57) | 0 | 0 | 0 | 0% (0 of 2) |
| Mine | Skaven | 1 | 1 (net -38) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: gs3-83c8646-p46

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 38 | 92 | -38 | 9 | 38 | -29 | -75.8 |
| Mine | 76-89% | 2 | 54 | 114 | +57 | 136 | 34 | +102 | +188.8 |
| Mine | All fights | 3 | 49 | 107 | +25 | 93 | 35 | +58 | +120.0 |
| Opponent | No odds | 2 | 132 | 266 | +11 | 46 | 170 | -124 | -93.3 |
| Opponent | All fights | 2 | 132 | 266 | +11 | 46 | 170 | -124 | -93.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p46 | move | 12 | 5 (42%) | 2 (17%) | 2 (17%) | 5 (42%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Fistful of Laurels | Mine | L1835 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L2021 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L2021 |

# Doctrine scorecard: gs3-83c8646-p72

### Scorecard: gs3-83c8646-p72

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2535 | 3 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 0 | 3 | 4 | 3 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | no | - | 3 | 3 | 4 | 1 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 125 |
| L3033 | 3 | 1 | Mine | yes | 2 | 2 | 0 | 3 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 6 | 2 | 3 | 3 | 0 | 0 | 0 | 19 |
| **Average** | | | Mine | 33% | 1.0 | 2.5 | 1.0 | 3.0 | 0.3 | 0.0 | 0.0 | 0.0 |
| **Average** | | | Opponent | 33% | 3.0 | 2.3 | 3.3 | 3.0 | 0.0 | 0.0 | 0.0 | 48.0 |

### KPIs: gs3-83c8646-p72

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 15) | 40% (6 of 15) | 20% (6 of 30) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 100% (10 of 10); on the table 100% | 100% (11 of 11); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 100% | 100% (2 of 2); on the table 100% | 67% (2 of 3); on the table 100% |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 67% (2 of 3); on the table 100% | 100% (12 of 12); on the table 100% | 93% (14 of 15); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 46% (11 of 24) | 39% (7 of 18) | 43% (18 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 55% (11 of 20) | 39% (7 of 18) | 47% (18 of 38) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 38% (2275 of 5999) | 59% (3568 of 6000) | 49% (5843 of 11999) |
|   infantry points that never fought | lower | 34% (262 of 780) | 81% (1558 of 1918) | 67% (1820 of 2698) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 78% (14 of 18) | 65% (22 of 34) | 69% (36 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 50% (2 of 4); 1.3 uses a game | 50% (2 of 4); 0.7 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 74% (3562 of 4808) | 52% (3107 of 5962) | 62% (6669 of 10770) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.0 (46%) | 2.7 (73%) | 4.7 (58%) |
| MARCHED: its unit marched | 0.3 (8%) | 1.0 (27%) | 1.3 (17%) |
| IN COMBAT: engaged in combat | 0.7 (15%) | 0.0 (0%) | 0.7 (8%) |
| GONE: slain | 0.7 (15%) | 0.0 (0%) | 0.7 (8%) |
| STUPIDITY: Stupidity | 0.7 (15%) | 0.0 (0%) | 0.7 (8%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.7 | 3.0 | 4.0 | 6.0 | 1.7 | 2.0 |
| not cast | 4.3 | 0.3 | 2.0 | 8.0 | 4.3 | 22.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (100%) | 0.0 (0%) | 4.7 (58%) | 2.0 (46%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (17%) | 0.3 (8%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (8%) | 0.0 (0%) | 0.0 (0%) | 0.7 (8%) | 0.3 (8%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (8%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (8%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (38%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.0 (92%) | 0.0 (0%) | 2.0 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 20.3 (92%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 2.7 a game | 2.0 a game |
| stood (cast and not dispelled) | 75% (3 of 4) | 38% (3 of 8) | 50% (6 of 12) |
| the unit moved after it | 100% (3 of 3) | 0% (0 of 3) | 50% (3 of 6) |
| it charged on its next turn | 0% (0 of 3) | 0% (0 of 3) | 0% (0 of 6) |
| the enemy charged it first | 0% (0 of 3) | 0% (0 of 3) | 0% (0 of 6) |
| it fought by the end of its next turn | 0% (0 of 3) | 0% (0 of 3) | 0% (0 of 6) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 3) | 0% (0 of 3) | 0% (0 of 6) |
| none of these (no charge, no fight, no charge escaped) | 100% (3 of 3) | 100% (3 of 3) | 100% (6 of 6) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 0% (0 of 2) | 66% (65 of 98) | 65% (65 of 100) |
|   cavalry | - | 71% (32 of 45) | 71% (32 of 45) |
|   character | 0% (0 of 2) | 73% (11 of 15) | 65% (11 of 17) |
|   infantry | - | 58% (22 of 38) | 58% (22 of 38) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.0 (0%) | 4.7 (42%) | 4.7 (40%) |
| CHARGED: it charged | 0.3 (50%) | 2.7 (24%) | 3.0 (26%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.3 (3%) | 0.3 (3%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 1.0 (9%) | 1.0 (9%) |
| NO TARGET IN RANGE | 0.3 (50%) | 1.0 (9%) | 1.3 (11%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 1.3 (12%) | 1.3 (11%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 14.0 | 0.7 | 95% | 0.4 pts | 6 pts |
| character | 3.7 | 0.7 | 82% | 2.4 pts | 9 pts |
| infantry | 10.3 | 5.7 | 65% | 10.2 pts | 105 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.7 | 5.7 | 3.7 |
| Charges that made contact a game | 1.0 | 5.0 | 3.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (4 units) | - | 0.00 declared, 0.00 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 0.67 contact (3 units) | - | 1.00 declared, 0.67 contact (3 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.10 declared, 0.05 contact (20 units) | 0.55 declared, 0.48 contact (31 units) | 0.37 declared, 0.31 contact (51 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 73% (8 of 11) | 0% (0 of 2) | 100% (1 of 1) | 64% (9 of 14) |
| Character in a unit | 100% (4 of 4) | 60% (3 of 5) | 0% (0 of 1) | 70% (7 of 10) |
| Character on its own | 100% (1 of 1) | 100% (1 of 1) | 40% (2 of 5) | 57% (4 of 7) |
| Infantry | 83% (10 of 12) | 67% (2 of 3) | - | 80% (12 of 15) |
| Monster | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Monstrous | 60% (3 of 5) | - | - | 60% (3 of 5) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vampire Counts | 2 | 67% (2 of 3); on the table 100% | 46% (11 of 24) | 25% | 75% (9 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | - | - | 63% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Wood Elf Realms | 3 | 100% (12 of 12); on the table 100% | 39% (7 of 18) | 59% | 65% (22 of 34) | 50% (2 of 4); 1.3 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p72, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 54% (7) | 0% (0) | 47% (7) |
| ...free all their last turn and able to turn (per game) | 2.33 | 0.00 | 2.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 1.67 | 0.00 | 1.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.00 | 0.00 | 1.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p72

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 0.7 |
| Strategy | Charge objectives carried out (made contact) | 40% (2 of 5) | 73% (11 of 15) |
| Strategy | Shoot objectives carried out (shot that target) | 50% (1 of 2) | 50% (7 of 14) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 75% (3 of 4) |
| Strategy | Joined characters whose unit fought | 40% (2 of 5) | 17% (1 of 6) |
| Strategy | Lone characters that fought | 67% (6 of 9) | 100% (2 of 2) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 3.0 | 3.0 |
| Movement | Points that never moved of their own | 0.0 | 48.0 |
| Movement | Fights charged into per game | 1.0 | 4.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 2 | 2 of 12, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | 1 of 12, net +580 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 2, net +125 | 3 of 12, net +84 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 2 | 4 of 12, net +30 |
| Shooting | Shots by shooting units (incl. breath weapons) | 1.3 | 21.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 4) | 65% (42 of 65) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 3.0 | 1.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (3 of 9) | 0% (0 of 5) |
| Magic | Wounds caused by magic missiles | - | 6.0 |
| Magic | Wounds caused by other spells | 3.7 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 94.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.7 / 0.3 / 1.7 / 0.3 | 0.7 / 1.3 / 0.0 / 1.3 |
| Combat | Points destroyed in combat | 234.3 | 372.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +283 | +96 |
| Combat | Net per 100 charger points, damage counted | +71.0 | +49.9 |
| Combat | First round won (charged fights) | 100% | 79% |
| Combat | Net points per charged fight | +283 | +85 |
| Combat | Net points per supported fight / lone fight | - / +283 | +60 / +87 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 3 | 3 of 14 |
| Game | Points lost | 561.7 | 322.3 |
| Game | VP from objectives | 543.3 | 836.7 |
| Game | Lone holders (player turns) | 1.0 | 3.0 |

- Mine won / drew / lost: 0 / 1 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -544 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 884
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p72

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 23.3 | +642.0 | 0.0 | 478.0 | 40.3 | +426.9 | 0.0 | 114.0 |
| ASSAILMENT BY POINTS | 1.0 | +4.2 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | 0.7 | +1.2 | 0.0 | 0.0 | 0.3 | +1.1 | 0.0 | 0.0 |
| CAST JOB | 0.3 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | - | - | - | - | 0.7 | +16.1 | 98.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 6.0 | +158.3 | 0.0 | 45.0 | 0.7 | +55.6 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 2.7 | -0.5 | 0.0 | 38.0 |
| CHALLENGE BY POINTS | 0.3 | +1.4 | 0.0 | 193.3 | 1.0 | +28.9 | 0.0 | 241.3 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -3.7 | 0.0 | 0.0 |
| CHARACTER GUNS | - | - | - | - | 5.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 25.0 | -1027.9 | 0.0 | 550.0 | 11.0 | -541.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 41.7 | 0.0 | 3.3 | +0.0 | 357.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 17.0 | +0.0 | 0.0 | 165.3 | 4.7 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 1.3 | +25.9 | 0.0 | 0.0 | 1.7 | +130.4 | 0.0 | 0.0 |
| COVER ONCE | 8.7 | -677.7 | 0.0 | 258.7 | 15.0 | -468.3 | 0.0 | 199.7 |
| DEFENSIVE ARMY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | - | - | - | - | 0.3 | -7.1 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 7.0 | +35.9 | 0.0 | 0.0 | 10.0 | -110.5 | 0.0 | 0.0 |
| EXACT ROUND | 0.7 | +2.6 | 38.0 | 0.0 | 3.0 | +17.9 | 290.7 | 0.0 |
| FALL BACK GOOD ORDER | 1.3 | +5.8 | 41.7 | 0.0 | 3.3 | +0.2 | 133.7 | 0.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 24.3 | +298.5 | 0.0 | 303.0 | - | - | - | - |
| FEATURE BUFFS | 0.3 | +4.4 | 0.0 | 0.0 | 0.7 | +1.3 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +0.3 | 41.7 | 0.0 | 1.3 | +55.0 | 193.3 | 0.0 |
| FIVE ACTION | 84.3 | +4363.4 | 79.7 | 1047.0 | 103.3 | +8341.7 | 530.7 | 593.3 |
| FLANK NOT WEIGHED | 10.3 | +0.0 | 0.0 | 271.3 | 5.0 | +0.0 | 0.0 | 199.7 |
| FOLLOW UP WEIGHED | 0.3 | +37.2 | 0.0 | 0.0 | 2.0 | +248.1 | 0.0 | 0.0 |
| FOOT FIRST | 32.3 | +0.0 | 0.0 | 233.3 | - | - | - | - |
| FOUR ROUNDS | 1.7 | +85.4 | 79.7 | 0.0 | 5.0 | +444.9 | 392.7 | 0.0 |
| FREED FROM HIS FIGHT | 5.0 | +0.0 | 0.0 | 287.3 | 4.3 | +0.0 | 0.0 | 399.3 |
| FRIEND SHOOTS FIRST | - | - | - | - | 1.7 | -7.9 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -7.2 | 0.0 | 0.0 | 0.3 | -1.0 | 0.0 | 0.0 |
| GOAL WALK | 4.0 | +322.7 | 0.0 | 0.0 | 18.3 | +1430.9 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 4.0 | +0.0 | 0.0 | 287.3 | 4.7 | +0.0 | 0.0 | 798.7 |
| HIS CHARGE BY HIS RUN | 16.7 | +0.0 | 0.0 | 422.7 | 8.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.7 | +44.3 | 0.0 | 0.0 |
| HIS CHARGE LIST | 14.0 | +0.0 | 0.0 | 317.3 | 10.3 | +0.0 | 0.0 | 399.3 |
| HIS LEGAL MOVES | 4.7 | +0.0 | 0.0 | 186.0 | 9.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 5.3 | -57.1 | 0.0 | 80.3 | 1.7 | -8.6 | 0.0 | 0.0 |
| HIS ONE QUARTER | 6.3 | +0.0 | 0.0 | 98.0 | 6.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 11.0 | +0.0 | 0.0 | 248.0 | 10.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 71.0 | +1624.6 | 0.0 | 908.0 | 25.0 | +122.4 | 0.0 | 121.3 |
| HIS SHOTS BY HIS RUN | 59.3 | +850.5 | 0.0 | 765.7 | 26.0 | +168.6 | 0.0 | 437.3 |
| HIS TURN DENIED | 0.3 | +2.0 | 38.0 | 0.0 | 0.7 | +3.3 | 20.0 | 0.0 |
| HOLD ODDS | 15.3 | +0.0 | 0.0 | 40.0 | 15.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 9.0 | +631.6 | 0.0 | 20.0 | 11.3 | +865.8 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HONEST WORTH | 1.7 | -76.2 | 79.7 | 0.0 | 4.3 | -105.0 | 310.7 | 0.0 |
| HORN WORTH | - | - | - | - | 0.3 | +3.9 | 0.0 | 0.0 |
| IDLE COST | 18.3 | -208.9 | 0.0 | 98.3 | - | - | - | - |
| JOINT CHARGE NOW | 0.3 | +36.7 | 0.0 | 0.0 | 1.3 | +119.0 | 40.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 0.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +4.5 | 0.0 | 0.0 | 0.7 | +50.8 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 7.7 | +0.0 | 72.7 | 1186.0 | 12.3 | +0.0 | 603.0 | 148.7 |
| LOST AFTER ESCAPE | 0.3 | +0.2 | 41.7 | 0.0 | 1.3 | +1.4 | 213.3 | 0.0 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.7 | -29.8 | 0.0 | 0.0 |
| MANOEUVRE | 3.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +8.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.3 | +42.6 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 2.7 | +115.6 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 1.3 | +279.1 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.0 | +93.3 | 0.0 | 77.0 | 2.7 | +37.1 | 0.0 | 0.0 |
| MEETS IN TIME | 4.0 | +174.0 | 0.0 | 0.0 | 5.7 | +191.1 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.3 | +14.7 | 0.0 | 20.0 | 6.0 | +193.9 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 5.0 | +12.7 | 0.0 | 20.0 | 6.7 | +136.2 | 0.0 | 0.0 |
| MOVE ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL NOT WORTH | - | - | - | - | 0.3 | -0.4 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 2.0 | -64.2 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 9.7 | +1131.5 | 0.0 | 62.0 | 5.7 | +339.6 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 10.7 | +401.9 | 0.0 | 62.0 | 8.7 | +415.9 | 0.0 | 0.0 |
| NEAREST TO GOAL | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 10.0 | +1159.8 | 0.0 | 62.0 | 1.3 | +83.3 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.7 | -39.7 | 0.0 | 0.0 | 1.0 | -32.8 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.7 | -58.8 | 79.7 | 0.0 | 3.3 | -210.0 | 377.7 | 0.0 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 2.7 | -5.0 | 0.0 | 0.0 |
| OFF BEST | 7.7 | -265.8 | 0.0 | 144.7 | 5.0 | -219.7 | 0.0 | 199.7 |
| ONE CHECK AFTER THE LAST CHANGE | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 4.3 | -85.6 | 0.0 | 82.0 | 9.7 | -153.6 | 0.0 | 237.7 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | +9.1 | 20.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 6.3 | -100.0 | 0.0 | 20.0 | 4.0 | +7.3 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.7 | -39.7 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.7 | +25.4 | 38.0 | 0.0 | 0.3 | +26.2 | 15.0 | 0.0 |
| OVERRUNS AWAY | 0.3 | +1.6 | 38.0 | 0.0 | 0.3 | +0.7 | 62.0 | 0.0 |
| PATHS CROSS | 1.7 | +5.7 | 0.0 | 0.0 | 0.3 | +40.7 | 0.0 | 0.0 |
| PLAN RESULT | 45.7 | +62.5 | 79.7 | 956.0 | 47.7 | +446.3 | 649.3 | 628.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 62.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 8.7 | -231.1 | 0.0 | 0.0 | 12.0 | -222.8 | 0.0 | 399.3 |
| PROMISE KNOWS THE FIGHT | 1.0 | -2.3 | 0.0 | 62.0 | 0.3 | -7.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 1.7 | -15.9 | 0.0 | 0.0 |
| QUARTER ODDS | 23.3 | +1786.0 | 79.7 | 222.0 | 28.3 | +3711.5 | 109.0 | 76.0 |
| REAL GROUND | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.7 | -10.0 | 0.0 | 0.0 | 2.0 | +39.7 | 0.0 | 0.0 |
| REDIRECT COUNTER | 3.0 | +206.0 | 0.0 | 15.0 | 1.0 | +28.5 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.3 | +23.9 | 0.0 | 0.0 | 2.7 | +176.5 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 2.3 | -92.3 | 0.0 | 62.0 | 4.0 | -113.3 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.7 | +9.7 | 0.0 | 0.0 | 1.0 | +49.0 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.3 | +3.0 | 0.0 | 0.0 |
| RISK BY ARC | 1.3 | -35.3 | 38.0 | 0.0 | 3.0 | +90.9 | 356.0 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.3 | -3.0 | 38.0 | 0.0 | - | - | - | - |
| RUN DOWN | 1.3 | -5.6 | 79.7 | 0.0 | 0.3 | -3.7 | 0.0 | 0.0 |
| SAFER THAN THE JOB | 1.0 | +28.5 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | 3.7 | -22.3 | 0.0 | 45.0 | - | - | - | - |
| SEARCH SPOT | 2.3 | +36.5 | 0.0 | 0.0 | 0.7 | +6.8 | 0.0 | 0.0 |
| SET CREDITED ONCE | 1.7 | -14.4 | 0.0 | 15.0 | 2.0 | -96.3 | 0.0 | 0.0 |
| SET UP BY THE SET | 2.0 | +19.3 | 0.0 | 15.0 | 2.3 | +112.7 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.7 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +0.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 2.3 | +0.0 | 0.0 | 15.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +113.0 | 0.0 | 0.0 | 1.7 | +96.5 | 40.0 | 0.0 |
| SHOT RISK POINTS | 51.7 | -328.7 | 0.0 | 851.0 | 7.7 | -73.9 | 0.0 | 0.0 |
| SHOTS AFTER THE MOVES | 0.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 1.0 | +56.6 | 0.0 | 0.0 | 23.0 | +289.2 | 0.0 | 237.7 |
| SPELL WORTH | 2.0 | +5.3 | 0.0 | 0.0 | 1.3 | +9.4 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | -2.5 | 20.0 | 0.0 |
| SPOT AS THE GAME MOVES | 14.3 | +0.0 | 0.0 | 518.0 | 7.3 | +0.0 | 0.0 | 34.7 |
| STAND AND SHOOT | 0.3 | -0.6 | 38.0 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | 3.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| STANDS STILL | 16.3 | +0.0 | 0.0 | 222.0 | 41.7 | +0.0 | 138.0 | 399.3 |
| STAY WORTH | 0.3 | +1.0 | 0.0 | 0.0 | 20.0 | +95.2 | 98.0 | 38.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.7 | +10.7 | 20.0 | 0.0 |
| STUBBORN BY POINTS | - | - | - | - | 0.3 | +9.3 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 9.0 | +1011.9 | 0.0 | 361.0 | 4.3 | +162.6 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 41.7 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 9.0 | +1011.9 | 0.0 | 361.0 | 4.3 | +162.6 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +2.6 | 0.0 | 32.7 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 5.3 | +0.0 | 124.0 | 33.3 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 6.0 | +0.0 | 0.0 | 134.3 | 0.3 | +0.0 | 0.0 | 41.7 |
| THE STEP BACK IS MADE | 3.0 | +0.0 | 0.0 | 52.7 | 0.3 | +0.0 | 0.0 | 41.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 47.7 | +0.0 | 0.0 | 449.3 | 49.3 | +0.0 | 0.0 | 279.3 |
| TIED UP BY THE SUM | 1.0 | +173.5 | 0.0 | 0.0 | 0.7 | +124.8 | 64.0 | 0.0 |
| TIME ON OUR SIDE | - | - | - | - | 53.0 | +572.3 | 0.0 | 640.7 |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 76.0 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -1.7 | 0.0 | 0.0 |
| WHO FIGHTS | - | - | - | - | 1.3 | -13.4 | 82.0 | 0.0 |
| WHO HITS BACK | 0.3 | +22.7 | 0.0 | 62.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 4.0 | -437.5 | 0.0 | 320.7 | 2.7 | -446.5 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 8.0 | +187.0 | 0.0 | 40.0 | 2.0 | +70.3 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p72

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 191 | 191 | 136 | 45.33 | +2820 | +20.7 |
| LEGAL CHARGES ONLY | 60 | 60 | 60 | 20.00 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 61 | 61 | 54 | 18.00 | +3023 | +56.0 |
| HIS SHOT LIST | 288 | 271 | 44 | 14.67 | +248 | +5.6 |
| OFF BEST | 38 | 38 | 38 | 12.67 | -1457 | -38.3 |
| QUARTER ODDS | 155 | 147 | 37 | 12.33 | +2052 | +55.5 |
| FIVE ACTION | 563 | 534 | 36 | 12.00 | +2775 | +77.1 |
| DEPLOY BY FIGURES | 51 | 51 | 35 | 11.67 | +412 | +11.8 |
| HIS SHOTS BY HIS RUN | 256 | 245 | 33 | 11.00 | +233 | +7.1 |
| TIME ON OUR SIDE | 159 | 131 | 28 | 9.33 | +165 | +5.9 |
| MOVE TO CHARGE COMPUTED | 46 | 43 | 24 | 8.00 | +1801 | +75.0 |
| THE TABLE AGAIN | 36 | 36 | 22 | 7.33 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 62 | 62 | 20 | 6.67 | -1362 | -68.1 |
| SHOT RISK POINTS | 178 | 165 | 20 | 6.67 | +170 | +8.5 |
| GOAL WALK | 67 | 67 | 18 | 6.00 | +658 | +36.6 |
| NEXT CHARGE BY LIST | 34 | 31 | 17 | 5.67 | +1541 | +90.7 |
| MOVE ORDER | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| HARD STAY DROPPED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 18 | 18 | 13 | 4.33 | +14 | +1.0 |
| ADVANCE LANE KEPT | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 20 | 19 | 11 | 3.67 | +72 | +6.5 |
| FOUR ROUNDS | 20 | 20 | 11 | 3.67 | +742 | +67.5 |
| WOUNDS ON THE RANKS | 30 | 30 | 11 | 3.67 | +266 | +24.2 |
| CHARGE LOSSES | 108 | 105 | 9 | 3.00 | +1513 | +168.2 |
| COVER ONCE | 71 | 48 | 9 | 3.00 | +126 | +14.0 |
| MEETS IN TIME | 29 | 29 | 9 | 3.00 | +409 | +45.5 |
| CHAFF PASSED | 8 | 8 | 8 | 2.67 | -1 | -0.2 |
| SHOOTS FROM THE BEST SPOT | 8 | 8 | 8 | 2.67 | +251 | +31.4 |
| FOLLOW UP WEIGHED | 7 | 7 | 7 | 2.33 | +856 | +122.3 |
| SEARCH SPOT | 9 | 9 | 7 | 2.33 | +130 | +18.6 |
| WHOLE FIGHT DANGER | 20 | 20 | 7 | 2.33 | +922 | +131.8 |
| PATHS CROSS | 6 | 6 | 6 | 2.00 | +139 | +23.2 |
| SET UP BY THE SET | 13 | 13 | 6 | 2.00 | +93 | +15.6 |
| SUPPORT ADDS | 40 | 40 | 6 | 2.00 | +102 | +16.9 |
| SUPPORT WORKED OUT | 40 | 40 | 6 | 2.00 | +102 | +16.9 |
| CHARGE NOW FIRST | 13 | 13 | 5 | 1.67 | -194 | -38.8 |
| IDLE COST | 55 | 38 | 5 | 1.67 | +17 | +3.4 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | +467 | +93.4 |
| RESERVE FALL BACK | 5 | 5 | 5 | 1.67 | +176 | +35.2 |
| TIED UP BY THE SUM | 5 | 5 | 5 | 1.67 | +290 | +58.1 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +91 | +22.8 |
| MARCH CHECK | 8 | 8 | 4 | 1.33 | +168 | +41.9 |
| PROMISE KNOWS THE FIGHT | 4 | 4 | 4 | 1.33 | -28 | -7.0 |
| SCREEN BY WHAT IT SAVES | 11 | 11 | 4 | 1.33 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 26 | 4 | 4 | 1.33 | +0 | +0.0 |
| ASSAILMENT BY POINTS | 3 | 3 | 3 | 1.00 | +13 | +4.2 |
| FALLS SHORT | 73 | 61 | 3 | 1.00 | +48 | +15.9 |
| LANE BY FIGURES | 3 | 3 | 3 | 1.00 | +166 | +55.2 |
| NEARER NOT NEEDED | 58 | 55 | 3 | 1.00 | +110 | +36.5 |
| REDIRECT BY WHAT IT STOPS | 8 | 8 | 3 | 1.00 | +14 | +4.5 |
| SAFER THAN THE JOB | 3 | 3 | 3 | 1.00 | +86 | +28.5 |
| SHOTS IN THE MOVE | 72 | 45 | 3 | 1.00 | +45 | +15.1 |
| CASTING BLOCK | 2 | 2 | 2 | 0.67 | +30 | +15.0 |
| HIS MOVE AND SHOT | 21 | 20 | 2 | 0.67 | +0 | +0.0 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -119 | -59.6 |
| REDIRECT COUNTER | 12 | 10 | 2 | 0.67 | +128 | +63.8 |
| SET CREDITED ONCE | 11 | 11 | 2 | 0.67 | +5 | +2.7 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +2 | +1.0 |
| STAY WORTH | 61 | 48 | 2 | 0.67 | +6 | +2.9 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +32 | +15.9 |
| SUPPORT NARROWED | 3 | 3 | 2 | 0.67 | -118 | -58.9 |
| CAST JOB | 1 | 1 | 1 | 0.33 | +0 | +0.2 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 11 | 11 | 1 | 0.33 | +2 | +2.1 |
| FALL BACK GOOD ORDER | 14 | 14 | 1 | 0.33 | +9 | +9.0 |
| HORN WORTH | 1 | 1 | 1 | 0.33 | +12 | +11.6 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +128 | +127.6 |
| MAX FOR POSITIONING | 14 | 13 | 1 | 0.33 | +25 | +25.1 |
| NO DOUBLE ROUNDS | 15 | 15 | 1 | 0.33 | +139 | +138.9 |
| ONE OBJECTIVE FORMULA | 31 | 25 | 1 | 0.33 | +42 | +42.3 |
| OPENS UP | 3 | 3 | 1 | 0.33 | +37 | +37.4 |
| PROMISE READS THE TABLE | 5 | 5 | 1 | 0.33 | -23 | -22.6 |
| REFUSING RETIRES | 2 | 2 | 1 | 0.33 | -2 | -1.8 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +9 | +8.9 |
| RISK BY ARC | 13 | 13 | 1 | 0.33 | +80 | +79.5 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +28 | +28.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +8 | +7.7 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -5 | -5.1 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +43 | +43.2 |
| BACKUP TARGETS | 3 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 7 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 17 | 16 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 65 | 59 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 9 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 1 | 1 | 0 | 0.00 | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 3 | 3 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 5 | 5 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 46 | not checked | - | - | - | - |
| FOOT FIRST | 97 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 28 | 26 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 26 | 22 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 76 | 75 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 73 | 66 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 41 | 39 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 38 | 32 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 64 | 61 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 3 | 3 | 0 | 0.00 | - | - |
| HOLD ODDS | 92 | 92 | 0 | 0.00 | - | - |
| HONEST WORTH | 18 | 18 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 12 | 12 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 5 | 5 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MANOEUVRE | 11 | 11 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 5 | 5 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 28 | 19 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 35 | 25 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 6 | trace | - | - | - | - |
| NEAREST TO GOAL | 4 | 4 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 5 | 5 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 8 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 42 | 22 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 2 | 2 | 0 | 0.00 | - | - |
| ONE ROUTE | 5 | 5 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 280 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 5 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 19 | 17 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 3 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 5 | 5 | 0 | 0.00 | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 25 | not checked | - | - | - | - |
| SHOTS AFTER THE MOVES | 11 | 11 | 0 | 0.00 | - | - |
| SPELL WORTH | 10 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 65 | 60 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 9 | 9 | 0 | 0.00 | - | - |
| STANDS STILL | 174 | 164 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 7 | 7 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 19 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 10 | not checked | - | - | - | - |
| THE TABLE BINDS | 291 | not checked | - | - | - | - |
| WAITS AGAIN | 8 | 8 | 0 | 0.00 | - | - |
| WHO FIGHTS | 4 | 4 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p72

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.67 | 3.67 | 28.3 |
| PROMISE BY ITS OWN SUM | rule | 1.67 | 5.00 | 68.1 |
| ARMY TABLE | rule | - | 5.00 | 57.1 |
| NO REASON | gate | 2.00 | - | 71.0 |
| CHARGE NOW FIRST | rule | 0.67 | 1.00 | 38.8 |
| PROMISE KNOWS THE FIGHT | rule | 1.00 | 0.33 | 7.0 |
| RULE SWITCHED OFF | gate | - | 1.33 | 59.8 |
| CHAFF PASSED | rule | - | 0.67 | 0.7 |
| HOLDER ASSIGNMENT | rule | - | 0.67 | 15.4 |
| ONE PROMISE A TARGET | rule | 0.67 | - | 59.6 |
| SUPPORT NARROWED | rule | - | 0.67 | 58.9 |
| JOINT CHARGE NOW | rule | - | 0.33 | 10.4 |
| PATHS CROSS | rule | 0.33 | - | 15.7 |
| PROMISE READS THE TABLE | rule | - | 0.33 | 22.6 |
| REFUSING RETIRES | rule | - | 0.33 | 1.8 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 5.1 |

### Plans: gs3-83c8646-p72

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 50% | 221 | 62 | 28% |
| Mine | join | 5.3 | 100% | 245 | 0 | 0% |
| Mine | move | 36.0 | 94% | 1753 | 0 | 0% |
| Mine | shoot | 0.7 | 0% | 80 | 0 | 0% |
| Mine | support | 2.3 | 86% | 59 | 0 | 0% |
| Opponent | charge | 4.3 | 62% | 755 | 402 | 53% |
| Opponent | move | 39.0 | 97% | 2605 | 0 | 0% |
| Opponent | shoot | 3.0 | 33% | 261 | 44 | 17% |
| Opponent | support | 1.3 | 100% | 88 | 0 | 0% |

### Battle groups: gs3-83c8646-p72

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.0 | 44% | 50% | 0% | - | 25% | 0% | 0% | 75% | 0% |
| Opponent | REDIRECT COUNTER | 1.0 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p72

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 77 (9) | 18 | 58 | 19 | 44% | 4.2 | 99 (7) | 0 (1) | 0 (1) | 87 (8) | 0 (1) |
| Mine | Character | 10 | 30 (10) | 30 | 0 | 28 | 30% | 3.3 | 66 (6) | 0 (4) | - | 83 (4) | 0 (6) |
| Mine | Clean-up | 1 | 49 (1) | 49 | 0 | 0 | 0% | 5.0 | 49 (1) | - | - | 49 (1) | - |
| Mine | Fast Hammer | 8 | 8 (8) | 0 | 8 | 48 | 50% | 3.8 | 4 (2) | 0 (4) | 31 (2) | 0 (1) | 11 (7) |
| Mine | Hammer | 2 | 94 (2) | 0 | 94 | 46 | 0% | 5.0 | 173 (1) | 0 (1) | - | 173 (1) | 0 (1) |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 0% | 1.5 | 0 (3) | - | 0 (1) | 0 (2) | 0 (2) |
| Opponent | Chaff | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (2) | - | - | 0 (2) | - |
| Opponent | Character | 7 | 58 (7) | 58 | 0 | 26 | 0% | 1.1 | 36 (5) | 146 (1) | 0 (1) | 36 (3) | 68 (4) |
| Opponent | Clean-up | 2 | 83 (2) | 0 | 83 | 0 | 0% | 3.0 | 167 (1) | 0 (1) | - | 167 (1) | 0 (1) |
| Opponent | Fast Hammer | 5 | 45 (5) | 5 | 40 | 15 | 0% | 1.2 | 85 (2) | 15 (2) | 0 (1) | 85 (2) | 10 (3) |
| Opponent | Hammer | 11 | 23 (11) | 23 | 0 | 18 | 64% | 3.8 | 0 (3) | 47 (6) | 0 (2) | 128 (2) | 4 (9) |
| Opponent | Shooter | 8 | 31 (8) | 0 | 31 | 10 | 0% | 1.2 | 21 (2) | 46 (5) | 0 (1) | 16 (3) | 37 (5) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 4.0 | - | - | 0 (1) | - | 0 (1) |

### Charged fights: gs3-83c8646-p72

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 2 | 0 | 424 | 1.5 | 1.0 | 283 | 0 | +283 | 1 of 3 | 3 of 3 | - | +283 |
| Mine | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 0 | 283 | 1.0 | 1.0 | 283 | 0 | +283 | 1 of 3 | 3 of 3 | - | +283 |
| Opponent | Wood Elf Realms | 3 | 95 | 468 | 4.7 | 1.1 | 100 | 16 | +85 | 3 of 14 | 11 of 14 | +60 | +87 |

### Effective charges: gs3-83c8646-p72

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 3 | 0 | 0 | 0 | 1 (net +125) | 1 (net +125) | 0 | 1 | 0% (0 of 2) |
| Opponent | Wood Elf Realms | 14 | 2 (net +0) | 0 | 1 (net +580) | 2 (net +25) | 3 (net +84) | 4 (net +30) | 2 | 8% (1 of 12) |

### Charged fights, damage counted: gs3-83c8646-p72

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 1 | 254 | 125 | +125 | 125 | 0 | +125 | +49.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 471 | 125 | +125 | 125 | 0 | +125 | +26.5 |
| Mine | No odds | 1 | 471 | 499 | +599 | 599 | 0 | +599 | +127.2 |
| Mine | All fights | 3 | 399 | 250 | +283 | 283 | 0 | +283 | +71.0 |
| Opponent | Long shot (under 50%) | 2 | 106 | 260 | +0 | 40 | 23 | +17 | +16.4 |
| Opponent | Effective (55-75%) | 1 | 499 | 480 | +580 | 580 | 0 | +580 | +116.2 |
| Opponent | 76-89% | 2 | 102 | 50 | +25 | 25 | 0 | +25 | +24.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 110 | 129 | +30 | 98 | 58 | +40 | +36.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 409 | 84 | +84 | 84 | 21 | +63 | +15.4 |
| Opponent | No odds | 2 | 52 | 178 | +90 | 215 | 52 | +163 | +313.9 |
| Opponent | All fights | 14 | 192 | 159 | +85 | 127 | 32 | +96 | +49.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p72 | move | 28 | 2 (7%) | 2 (7%) | 3 (11%) | 23 (82%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2535, L2735 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2535, L2735 |
| Ring of Doom | Opponent | L3033 |

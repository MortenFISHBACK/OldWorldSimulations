# Doctrine scorecard: gs3-83c8646-p82

### Scorecard: gs3-83c8646-p82

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1831 | 1 | 1 | Mine | no | 3 | - | 4 | 1 | 2 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 5 | 5 | 1 | 0 | 1 | 0 | 0 | 340 |
| L1932 | 6 | 1 | Mine | no | 7 | 2 | 8 | 0 | 2 | 0 | 0 | 0 |
| L1932 | 6 | 1 | Opponent | no | 0 | 1 | 7 | 3 | 1 | 0 | 0 | 305 |
| L2033 | 5 | 1 | Mine | yes | - | - | 0 | 6 | 2 | 0 | 0 | 420 |
| L2033 | 5 | 1 | Opponent | yes | - | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 5.0 | 2.0 | 4.0 | 2.3 | 2.0 | 0.0 | 0.0 | 140.0 |
| **Average** | | | Opponent | 33% | 2.5 | 2.7 | 3.3 | 2.0 | 0.7 | 0.0 | 0.0 | 215.0 |

### KPIs: gs3-83c8646-p82

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 22% (2 of 9) | 8% (1 of 13) | 14% (3 of 22) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | 100% (6 of 6); on the table 100% | 100% (8 of 8); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 50% (1 of 2); on the table 50% | 20% (1 of 5); on the table 20% | 29% (2 of 7); on the table 29% |
| Winner chose to follow up or pursue (all three) |  | 75% (3 of 4); on the table 75% | 64% (7 of 11); on the table 64% | 67% (10 of 15); on the table 67% |
| Magic missiles tried each own turn | 50%+ | 6% (1 of 18) | 17% (1 of 6) | 8% (2 of 24) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 6% (1 of 16) | 17% (1 of 6) | 9% (2 of 22) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 71% (5 of 7) | 42% (8 of 19) | 50% (13 of 26) |
| Points that never fought | lower | 38% (2254 of 5999) | 42% (2522 of 5999) | 40% (4776 of 11998) |
|   infantry points that never fought | lower | 86% (853 of 993) | 78% (759 of 967) | 82% (1612 of 1960) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 77% (17 of 22) | 50% (15 of 30) | 62% (32 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 0.3 uses a game | 100% (3 of 3); 3.0 uses a game | 100% (4 of 4); 1.7 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (2 of 2); 0.7 uses a game | 0% (0 of 1); 0.0 uses a game | 67% (2 of 3); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 75% (3854 of 5151) | 43% (2523 of 5838) | 58% (6377 of 10989) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.3 (41%) | 1.3 (80%) | 3.7 (50%) |
| MARCHED: its unit marched | 0.3 (6%) | 0.3 (20%) | 0.7 (9%) |
| CHARGED: its unit charged | 0.3 (6%) | 0.0 (0%) | 0.3 (5%) |
| IN COMBAT: engaged in combat | 0.7 (12%) | 0.0 (0%) | 0.7 (9%) |
| REAR RANK: in a rear rank | 1.7 (29%) | 0.0 (0%) | 1.7 (23%) |
| NOT OFFERED: not in the cast list | 0.3 (6%) | 0.0 (0%) | 0.3 (5%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 1.7 | 0.0 | 0.3 | 0.7 | 0.3 | 1.3 |
| not cast | 6.3 | 2.0 | 3.7 | 7.3 | 3.3 | 22.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (67%) | 0.0 (0%) | 3.7 (50%) | 0.3 (10%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (9%) | 0.7 (20%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (5%) | 0.3 (10%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (9%) | 0.3 (10%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (32%) | 0.0 (0%) | 2.0 (55%) | 1.7 (23%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (4%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| OFF THE TABLE: off the table or not arrived | 1.3 (21%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (40%) | 2.7 (12%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (10%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (5%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.0 (47%) | 0.7 (33%) | 1.7 (45%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.3 (78%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.3 a game | 0.0 a game | 0.2 a game |
| stood (cast and not dispelled) | - | - | - |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 42% (25 of 59) | 49% (17 of 35) | 45% (42 of 94) |
|   cavalry | - | 33% (2 of 6) | 33% (2 of 6) |
|   character | 83% (5 of 6) | 40% (6 of 15) | 52% (11 of 21) |
|   chariot | 89% (8 of 9) | - | 89% (8 of 9) |
|   infantry | 12% (4 of 34) | 64% (9 of 14) | 27% (13 of 48) |
|   monster | 80% (8 of 10) | - | 80% (8 of 10) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.3 (29%) | 0.7 (11%) | 4.0 (23%) |
| CHARGED: it charged | 0.0 (0%) | 2.7 (44%) | 2.7 (15%) |
| FLEEING: it fled or was fleeing | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 1.0 (17%) | 1.0 (6%) |
| NO TARGET IN RANGE | 6.0 (53%) | 0.0 (0%) | 6.0 (35%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (12%) | 1.7 (28%) | 3.0 (17%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 0.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| character | 3.7 | 0.7 | 91% | 4.1 pts | 15 pts |
| chariot | 2.7 | 2.7 | 50% | 28.5 pts | 76 pts |
| infantry | 6.7 | 3.0 | 60% | 14.0 pts | 93 pts |
| monster | 2.7 | 0.3 | 88% | 2.8 pts | 7 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.7 | 4.0 | 4.3 |
| Charges that made contact a game | 2.0 | 2.7 | 2.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | - | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.50 declared, 0.21 contact (28 units) | 0.46 declared, 0.31 contact (26 units) | 0.48 declared, 0.26 contact (54 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 29% (2 of 7) | 50% (1 of 2) | - | 33% (3 of 9) |
| Character in a unit | 100% (3 of 3) | 100% (1 of 1) | 50% (1 of 2) | 83% (5 of 6) |
| Character on its own | 86% (6 of 7) | 100% (3 of 3) | 25% (1 of 4) | 71% (10 of 14) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 80% (4 of 5) | 33% (1 of 3) | - | 62% (5 of 8) |
| Monster | 50% (2 of 4) | 67% (2 of 3) | - | 57% (4 of 7) |
| Monstrous | 100% (2 of 2) | 50% (2 of 4) | - | 67% (4 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 34% | 71% (5 of 7) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (2 of 2); on the table 100% | 17% (1 of 6) | 0% | 75% (6 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 1 | 50% (1 of 2); on the table 50% | 0% (0 of 6) | 79% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 2 | 56% (5 of 9); on the table 56% | 17% (1 of 6) | 42% | 40% (8 of 20) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (2 of 2); on the table 100% | - | 42% | 70% (7 of 10) | 100% (2 of 2); 5.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p82, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 75% (6) | 60% (3) | 69% (9) |
| ...free all their last turn and able to turn (per game) | 1.33 | 0.33 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.00 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 1.00 | 0.00 | 1.00 |

### Quality by phase: gs3-83c8646-p82

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.7 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 33% (1 of 3) | 75% (6 of 8) |
| Strategy | Shoot objectives carried out (shot that target) | 0% (0 of 4) | 0% (0 of 8) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 50% (1 of 2) | 20% (1 of 5) |
| Strategy | Lone characters that fought | 62% (5 of 8) | 83% (5 of 6) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.3 | 2.0 |
| Movement | Points that never moved of their own | 140.0 | 215.0 |
| Movement | Fights charged into per game | 2.0 | 2.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 1 | 2 of 6, net +321 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 1 | 0 of 6 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 1 | 1 of 6, net +68 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 1, net +135 | 3 of 6, net +18 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.3 | 6.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (11 of 25) | 40% (8 of 20) |
| Shooting | Points destroyed by shooting units | 0.0 | 91.7 |
| Shooting | Points destroyed by war machines | 38.7 | 0.0 |
| Magic | Magic missiles cast | 0.3 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 100% (1 of 1) | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 21.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.0 / 0.3 / 0.0 | 0.0 / 0.0 / 0.3 / 0.3 |
| Combat | Points destroyed in combat | 130.0 | 674.0 |
| Combat | Points run down | 90.7 | 52.0 |
| Combat | Net points per charged fight, damage counted | -55 | +100 |
| Combat | Net per 100 charger points, damage counted | -26.7 | +40.9 |
| Combat | First round won (charged fights) | 33% | 75% |
| Combat | Net points per charged fight | -89 | +66 |
| Combat | Net points per supported fight / lone fight | - / -89 | - / +66 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 6 | 5 of 8 |
| Game | Points lost | 1132.0 | 383.3 |
| Game | VP from objectives | 546.7 | 756.7 |
| Game | Lone holders (player turns) | 5.0 | 2.5 |

- Mine won / drew / lost: 0 / 0 / 3 of 3 ended games (of 3); mean margin (Mine - Opponent) -984 VP
- The side that went first won 0 of 3 games with a winner
- Points traded per game (both sides' losses): 1515
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: gs3-83c8646-p82

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +34.4 | 0.0 | 0.0 |
| ARMY TABLE | 29.0 | +535.4 | 0.0 | 1009.3 | 15.0 | -120.9 | 0.0 | 115.3 |
| ASSAILMENT BY POINTS | 1.3 | +10.5 | 0.0 | 108.7 | 0.3 | +1.5 | 0.0 | 78.0 |
| BEST PRIZE | 0.3 | -13.6 | 45.7 | 0.0 | - | - | - | - |
| CAST JOB | - | - | - | - | 2.0 | +2.8 | 22.7 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 108.7 | - | - | - | - |
| CHAFF IN THE MOVE | 1.0 | +60.3 | 0.0 | 55.0 | - | - | - | - |
| CHALLENGE BY POINTS | - | - | - | - | 0.7 | +6.2 | 0.0 | 84.3 |
| CHARACTER GUNS | - | - | - | - | 5.0 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 12.3 | -904.2 | 0.0 | 758.0 | 9.0 | -247.7 | 0.0 | 181.3 |
| CHARGE NOT DECLARED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE NOW FIRST | 0.7 | +0.0 | 55.0 | 0.0 | 1.0 | +0.0 | 89.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 9.7 | +0.0 | 0.0 | 153.3 | 7.0 | +0.0 | 0.0 | 10.0 |
| COMBAT PIVOT | 0.7 | +0.0 | 56.7 | 30.0 | - | - | - | - |
| COVER ONCE | 3.7 | -222.8 | 0.0 | 100.0 | 2.3 | -59.2 | 0.0 | 90.7 |
| DEPLOY BY FIGURES | 8.0 | +101.6 | 0.0 | 0.0 | 7.7 | -43.8 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -280.8 | 131.0 | 0.0 |
| ELIXIR WORTH | 0.3 | +9.5 | 0.0 | 116.7 | - | - | - | - |
| EXACT ROUND | 0.7 | +1.8 | 55.0 | 0.0 | 2.3 | +37.8 | 238.3 | 38.7 |
| FALL BACK GOOD ORDER | 1.0 | +0.0 | 55.0 | 0.0 | 1.7 | +11.3 | 306.0 | 0.0 |
| FALLS SHORT | 13.3 | +123.7 | 0.0 | 248.7 | 6.7 | +101.4 | 0.0 | 0.0 |
| FEATURE BUFFS | 2.7 | +83.5 | 0.0 | 0.0 | 1.3 | +77.7 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.3 | +4.6 | 131.0 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 90.3 | +5008.9 | 55.0 | 2248.3 | 74.7 | +5450.8 | 644.3 | 416.0 |
| FLANK NOT WEIGHED | 8.3 | +0.0 | 0.0 | 292.0 | 3.7 | +0.0 | 0.0 | 90.7 |
| FOLLOW UP WEIGHED | 1.0 | +209.7 | 0.0 | 70.0 | 2.0 | +75.3 | 0.0 | 95.3 |
| FOOT FIRST | 5.7 | +0.0 | 0.0 | 167.0 | - | - | - | - |
| FOUR ROUNDS | 1.0 | +37.5 | 55.0 | 0.0 | 3.3 | +292.3 | 387.7 | 38.7 |
| FREED FROM HIS FIGHT | 4.0 | +0.0 | 0.0 | 301.3 | 4.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.7 | -0.6 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 1.7 | -54.5 | 227.7 | 38.7 |
| GOAL WALK | 9.0 | +903.5 | 0.0 | 156.7 | 9.7 | +556.2 | 0.0 | 105.3 |
| GUN FIGURES | 2.3 | +66.8 | 38.7 | 83.3 | - | - | - | - |
| GUN MASK | 0.3 | +8.7 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 1.7 | +0.0 | 0.0 | 80.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 4.7 | +0.0 | 0.0 | 278.7 | 2.7 | +0.0 | 0.0 | 181.3 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +2.0 | 18.3 | 0.0 |
| HIS CHARGE LIST | 1.7 | +0.0 | 0.0 | 131.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 1.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.0 | -20.6 | 0.0 | 70.0 | 1.3 | -17.5 | 0.0 | 0.0 |
| HIS ONE QUARTER | 13.0 | +0.0 | 0.0 | 398.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 1.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 27.0 | +0.0 | 0.0 | 1250.7 | 12.0 | +0.0 | 0.0 | 70.7 |
| HIS RANDOM MOVER COMES | 7.7 | +0.0 | 0.0 | 631.3 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 46.0 | +1102.3 | 0.0 | 1379.3 | 23.3 | +966.4 | 0.0 | 91.3 |
| HIS SHOTS BY HIS RUN | 42.7 | +844.0 | 0.0 | 1130.3 | 15.0 | +224.0 | 0.0 | 0.0 |
| HOLD ODDS | 24.3 | +0.0 | 0.0 | 81.7 | 17.0 | +0.0 | 0.0 | 91.3 |
| HOLDER ASSIGNMENT | 14.0 | +1331.5 | 0.0 | 50.0 | 10.0 | +1110.4 | 0.0 | 45.7 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -27.0 | 55.0 | 0.0 | 3.0 | -140.4 | 387.7 | 0.0 |
| HORN WORTH | - | - | - | - | 0.3 | +2.8 | 0.0 | 0.0 |
| IDLE COST | 7.7 | -133.2 | 0.0 | 234.3 | 5.0 | -58.3 | 0.0 | 38.7 |
| JOINT CHARGE NOW | - | - | - | - | 1.0 | +24.4 | 156.7 | 0.0 |
| KEPT FROM ITS LAST STOP | 3.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +7.5 | 0.0 | 0.0 | 0.3 | +10.9 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 2.0 | +0.0 | 0.0 | 366.3 | 5.7 | +0.0 | 533.3 | 38.7 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.3 | +5.8 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.3 | +26.7 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 0.3 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 0.3 | +0.3 | 45.0 | 0.0 | 1.7 | +2.6 | 287.7 | 38.7 |
| LURE BY WHAT IT DRAWS | 1.0 | -168.7 | 0.0 | 18.3 | - | - | - | - |
| MAKE SURE TOGETHER | - | - | - | - | 1.7 | +6.7 | 0.0 | 0.0 |
| MANOEUVRE | 1.3 | +3.2 | 0.0 | 102.0 | 1.7 | +3.2 | 0.0 | 90.7 |
| MARCH BY THE SUM | 0.3 | +42.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.3 | +66.7 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | +49.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 2.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.3 | +70.9 | 0.0 | 13.3 | 1.7 | +14.5 | 0.0 | 0.0 |
| MEETS IN TIME | 4.7 | +443.6 | 0.0 | 0.0 | 2.7 | +274.2 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.7 | +29.4 | 0.0 | 108.7 | 4.7 | +68.7 | 0.0 | 36.0 |
| MISSILES NEXT TURN | 2.7 | +28.0 | 0.0 | 108.7 | 5.3 | +47.5 | 0.0 | 36.0 |
| MOVE ORDER | 4.3 | +0.0 | 13.3 | 78.0 | 0.3 | +0.0 | 0.0 | 38.7 |
| MOVE SPELL OUT OF RANGE | 0.3 | -32.6 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 0.3 | +1.1 | 0.0 | 36.7 | 4.3 | +289.3 | 0.0 | 34.7 |
| MOVES UNITS SPELL | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 9.3 | +409.8 | 0.0 | 245.7 | 4.7 | +219.3 | 0.0 | 45.7 |
| NEAREST TO GOAL | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | - | - | - | - | 2.0 | +169.3 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.7 | -10.6 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.0 | -30.8 | 55.0 | 0.0 | 3.3 | -98.4 | 387.7 | 38.7 |
| NO LATE CUT | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 1.0 | +0.0 | 0.0 | 108.7 | - | - | - | - |
| NOT WORTH A CAST | 1.0 | -0.8 | 0.0 | 0.0 | 2.7 | -5.1 | 0.0 | 78.0 |
| OFF BEST | 2.7 | -68.6 | 0.0 | 170.3 | 2.7 | -84.3 | 18.3 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 0.7 | -13.7 | 0.0 | 0.0 | 4.0 | -87.8 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 5.0 | +47.6 | 0.0 | 31.7 | 3.3 | +113.9 | 0.0 | 45.7 |
| ONE ROUTE | 2.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +16.7 | 10.0 | 0.0 | 0.7 | +52.9 | 18.3 | 0.0 |
| OVERRUNS AWAY | 0.3 | +55.0 | 10.0 | 0.0 | - | - | - | - |
| PERIAPT WORTH | 0.3 | +42.9 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.3 | -0.3 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 45.0 | +104.7 | 0.0 | 1626.7 | 37.0 | +356.5 | 425.0 | 474.3 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 0.7 | -1.1 | 0.0 | 36.7 | 8.0 | -175.6 | 0.0 | 34.7 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.7 | -0.4 | 0.0 | 34.7 |
| PROMISE READS THE TABLE | - | - | - | - | 0.7 | -0.6 | 0.0 | 0.0 |
| PURSUES BIG PREY | - | - | - | - | 0.3 | -5.9 | 0.0 | 0.0 |
| QUARTER ODDS | 19.7 | +2030.9 | 0.0 | 570.7 | 15.7 | +1672.4 | 245.3 | 38.7 |
| RANDOM MOVE BY FIGURES | 2.3 | +118.5 | 0.0 | 140.0 | 6.3 | +42.0 | 0.0 | 0.0 |
| REAL GROUND | 2.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.3 | +13.5 | 0.0 | 18.3 | - | - | - | - |
| REDIRECT COUNTER | 4.3 | +468.6 | 0.0 | 13.3 | 0.7 | +16.7 | 0.0 | 10.0 |
| REDIRECT FOR A FRIEND IN REACH | 7.3 | +0.0 | 0.0 | 162.3 | 3.3 | +0.0 | 0.0 | 10.0 |
| REFORMS TO MEET IT | - | - | - | - | 2.0 | -32.8 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.0 | -36.8 | 55.0 | 0.0 | 2.0 | +32.0 | 287.7 | 38.7 |
| RISK ON THE WAY | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.7 | -14.8 | 55.0 | 0.0 | 1.3 | -52.1 | 287.7 | 0.0 |
| RUN DOWN | 1.0 | -4.8 | 55.0 | 0.0 | 2.3 | -13.6 | 317.3 | 38.7 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | 0.7 | -6.6 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.7 | +10.6 | 18.3 | 0.0 |
| SELF MOVE SPELL | 2.0 | +1.9 | 0.0 | 217.3 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 1.0 | -11.1 | 0.0 | 0.0 |
| SET UP BY THE SET | - | - | - | - | 2.7 | +23.3 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 1.7 | +6.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 1.7 | +0.0 | 0.0 | 80.0 | 2.7 | +0.0 | 0.0 | 38.7 |
| SHOOTS FROM THE BEST SPOT | 1.7 | +64.4 | 0.0 | 0.0 | 3.0 | +120.4 | 234.0 | 0.0 |
| SHOT RISK POINTS | 29.7 | +414.3 | 0.0 | 844.3 | 11.7 | +1059.8 | 0.0 | 0.0 |
| SHOTS AFTER THE MOVES | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 8.0 | +319.2 | 0.0 | 406.7 | 7.0 | +347.2 | 0.0 | 36.0 |
| SPELL WORTH | 1.7 | +11.5 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 10.7 | +0.0 | 0.0 | 711.0 | 6.7 | +0.0 | 0.0 | 109.3 |
| STANDS FOR A REASON | 0.3 | +0.0 | 0.0 | 131.0 | 2.0 | +0.0 | 22.7 | 0.0 |
| STANDS STILL | 29.0 | +0.0 | 0.0 | 379.3 | 31.0 | +0.0 | 256.7 | 10.0 |
| STAY WORTH | 8.3 | +144.6 | 0.0 | 368.7 | 6.0 | +101.4 | 22.7 | 36.0 |
| STRIKE BY THE ODDS | 0.3 | +3.5 | 34.7 | 70.0 | 1.0 | +67.2 | 0.0 | 38.7 |
| STUBBORN BY POINTS | - | - | - | - | 0.3 | +1.2 | 0.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 8.0 | +515.9 | 0.0 | 80.0 | 2.7 | +17.6 | 0.0 | 10.0 |
| SUPPORT WORKED OUT | 8.0 | +515.9 | 0.0 | 80.0 | 2.7 | +17.6 | 0.0 | 10.0 |
| SURE REACH TOGETHER | - | - | - | - | 1.0 | +3.1 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 5.0 | +0.0 | 0.0 | 126.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 4.7 | +0.0 | 0.0 | 11.3 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 3.7 | +0.0 | 0.0 | 18.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 40.7 | +0.0 | 0.0 | 837.3 | 32.3 | +0.0 | 0.0 | 210.0 |
| TIED UP BY THE SUM | 0.7 | +83.3 | 55.0 | 0.0 | 1.7 | +211.7 | 186.3 | 0.0 |
| TIME ON OUR SIDE | 23.3 | +207.3 | 0.0 | 442.3 | 28.7 | +293.6 | 0.0 | 226.3 |
| WAITS AGAIN | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -39.0 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 4.7 | -569.5 | 0.0 | 592.7 | 2.7 | -130.8 | 0.0 | 181.3 |
| WOUNDS ON THE RANKS | - | - | - | - | 1.0 | +142.8 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p82

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 132 | 132 | 76 | 25.33 | +409 | +5.4 |
| HOLDER ASSIGNMENT | 72 | 72 | 66 | 22.00 | +3902 | +59.1 |
| HIS SHOTS BY HIS RUN | 173 | 171 | 41 | 13.67 | +275 | +6.7 |
| HIS SHOT LIST | 208 | 204 | 34 | 11.33 | +593 | +17.4 |
| REDIRECT FOR A FRIEND IN REACH | 32 | 32 | 32 | 10.67 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 30 | 10.00 | +0 | +0.0 |
| SHOT RISK POINTS | 124 | 122 | 27 | 9.00 | +723 | +26.8 |
| DEPLOY BY FIGURES | 47 | 47 | 25 | 8.33 | +356 | +14.2 |
| TIME ON OUR SIDE | 156 | 138 | 25 | 8.33 | +48 | +1.9 |
| LEGAL CHARGES ONLY | 23 | 23 | 23 | 7.67 | +0 | +0.0 |
| QUARTER ODDS | 106 | 105 | 17 | 5.67 | +1122 | +66.0 |
| GOAL WALK | 56 | 56 | 16 | 5.33 | +1436 | +89.8 |
| OFF BEST | 16 | 16 | 16 | 5.33 | -459 | -28.7 |
| FIVE ACTION | 495 | 487 | 14 | 4.67 | +698 | +49.9 |
| MOVE ORDER | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 26 | 26 | 13 | 4.33 | +482 | +37.1 |
| MEETS IN TIME | 22 | 22 | 12 | 4.00 | +685 | +57.1 |
| PROMISE BY ITS OWN SUM | 26 | 26 | 10 | 3.33 | -530 | -53.0 |
| FOLLOW UP WEIGHED | 9 | 9 | 9 | 3.00 | +855 | +95.0 |
| HARD STAY DROPPED | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| IDLE COST | 38 | 24 | 9 | 3.00 | +49 | +5.4 |
| SHOOTS FROM THE BEST SPOT | 14 | 14 | 9 | 3.00 | +227 | +25.2 |
| CHARGE LOSSES | 64 | 63 | 7 | 2.33 | +929 | +132.7 |
| SUPPORT ADDS | 32 | 31 | 7 | 2.33 | +208 | +29.7 |
| SUPPORT WORKED OUT | 32 | 31 | 7 | 2.33 | +208 | +29.7 |
| WHOLE FIGHT DANGER | 22 | 21 | 6 | 2.00 | +20 | +3.4 |
| ASSAILMENT BY POINTS | 5 | 5 | 5 | 1.67 | +36 | +7.2 |
| FOUR ROUNDS | 13 | 12 | 5 | 1.67 | +371 | +74.2 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| MANOEUVRE | 9 | 9 | 5 | 1.67 | +19 | +3.8 |
| MARCH CHECK | 5 | 5 | 5 | 1.67 | +89 | +17.8 |
| MOVE TO CHARGE COMPUTED | 14 | 9 | 5 | 1.67 | +246 | +49.2 |
| TIED UP BY THE SUM | 7 | 6 | 5 | 1.67 | +292 | +58.4 |
| ADVANCE LANE KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| NEARER NOT NEEDED | 42 | 39 | 4 | 1.33 | +149 | +37.3 |
| NEXT CHARGE BY LIST | 6 | 5 | 4 | 1.33 | +260 | +65.1 |
| CHAFF IN THE MOVE | 3 | 3 | 3 | 1.00 | +27 | +8.9 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | +73 | +24.5 |
| MAX FOR POSITIONING | 9 | 9 | 3 | 1.00 | +13 | +4.3 |
| REDIRECT COUNTER | 15 | 13 | 3 | 1.00 | +117 | +39.1 |
| RISK BY ARC | 9 | 9 | 3 | 1.00 | +108 | +36.1 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| STRIKE BY THE ODDS | 4 | 4 | 3 | 1.00 | +171 | +57.0 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +19 | +9.4 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| COVER ONCE | 18 | 8 | 2 | 0.67 | +8 | +3.8 |
| EXACT ROUND | 9 | 8 | 2 | 0.67 | +68 | +33.8 |
| FEATURE BUFFS | 12 | 12 | 2 | 0.67 | +10 | +4.8 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +55 | +27.5 |
| OPENS UP | 3 | 2 | 2 | 0.67 | +12 | +6.1 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +32 | +15.8 |
| SET UP BY THE SET | 8 | 7 | 2 | 0.67 | +0 | +0.2 |
| THE ROW IN ITS ORDER | 25 | 2 | 2 | 0.67 | +0 | +0.0 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +103 | +103.4 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -48 | -47.7 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -13 | -13.0 |
| CHARGE NOW FIRST | 5 | 5 | 1 | 0.33 | -112 | -111.8 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.33 | +28 | +28.4 |
| FALLS SHORT | 60 | 46 | 1 | 0.33 | +0 | +0.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS MOVE AND SHOT | 13 | 13 | 1 | 0.33 | +10 | +9.5 |
| HORN WORTH | 1 | 1 | 1 | 0.33 | +8 | +8.4 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +80 | +80.2 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +127 | +126.8 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| NEXT OBJECTIVE NEARER | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 25 | 21 | 1 | 0.33 | +29 | +28.6 |
| OVERRUNS AWAY | 1 | 1 | 1 | 0.33 | +0 | +0.2 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +129 | +128.7 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -1 | -1.0 |
| PROMISE KNOWS THE FIGHT | 2 | 1 | 1 | 0.33 | -1 | -1.2 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.33 | -18 | -17.8 |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| REFUSING RETIRES | 2 | 2 | 1 | 0.33 | -2 | -2.5 |
| SHOTS IN THE MOVE | 45 | 29 | 1 | 0.33 | +97 | +96.6 |
| STAY WORTH | 43 | 38 | 1 | 0.33 | +4 | +3.8 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +4 | +3.5 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.1 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -117 | -117.0 |
| WOUNDS ON THE RANKS | 3 | 3 | 1 | 0.33 | +58 | +57.5 |
| CAST JOB | 6 | 6 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CHARACTER GUNS | 15 | 15 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 50 | 49 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 8 | 7 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 36 | not checked | - | - | - | - |
| FOOT FIRST | 17 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 25 | 25 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 5 | 4 | 0 | 0.00 | - | - |
| GUN FIGURES | 7 | not checked | - | - | - | - |
| GUN MASK | 1 | 1 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 12 | 12 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 22 | 22 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 8 | 8 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 14 | 13 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 50 | 50 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 22 | 19 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 117 | 114 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 33 | 32 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 124 | 124 | 0 | 0.00 | - | - |
| HONEST WORTH | 12 | 11 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 21 | 21 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 6 | 6 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 3 | 3 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 5 | not checked | - | - | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 12 | 12 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 19 | 9 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 24 | 12 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 1 | trace | - | - | - | - |
| NEAREST TO GOAL | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 13 | 12 | 0 | 0.00 | - | - |
| NO LATE CUT | 7 | 7 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 3 | 3 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 11 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 14 | 6 | 0 | 0.00 | - | - |
| ONE ROUTE | 12 | 12 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 246 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 12 | 12 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 6 | 5 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 3 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 6 | 6 | 0 | 0.00 | - | - |
| RUN DOWN | 10 | 10 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SEARCH SPOT | 3 | 3 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 3 | 2 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 5 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 13 | not checked | - | - | - | - |
| SHOTS AFTER THE MOVES | 4 | 4 | 0 | 0.00 | - | - |
| SPELL WORTH | 5 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 52 | 39 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 7 | 7 | 0 | 0.00 | - | - |
| STANDS STILL | 180 | 179 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 3 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 3 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 20 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 14 | not checked | - | - | - | - |
| THE TABLE BINDS | 219 | not checked | - | - | - | - |
| WAITS AGAIN | 5 | 5 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p82

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| ARMY TABLE | rule | 3.00 | 2.67 | 59.2 |
| JOB FIRST | gate | 2.33 | 1.67 | 25.3 |
| PROMISE BY ITS OWN SUM | rule | 0.33 | 3.00 | 53.0 |
| HOLDER ASSIGNMENT | rule | 1.00 | 0.33 | 28.2 |
| RULE SWITCHED OFF | gate | - | 1.00 | 48.4 |
| BEST PRIZE | rule | 0.33 | - | 47.7 |
| CHARGE NOT DECLARED | rule | 0.33 | - | 13.0 |
| CHARGE NOW FIRST | rule | 0.33 | - | 111.8 |
| NO REASON | gate | 0.33 | - | 9.8 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 1.0 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.33 | 1.2 |
| PURSUES BIG PREY | rule | - | 0.33 | 17.8 |
| REFUSING RETIRES | rule | 0.33 | - | 2.5 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 117.0 |

### Plans: gs3-83c8646-p82

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 100% | 36 | 60 | 166% |
| Mine | move | 41.7 | 91% | 2182 | 0 | 0% |
| Mine | shoot | 1.3 | 50% | 88 | 45 | 51% |
| Mine | support | 1.0 | 100% | 1 | 0 | 0% |
| Opponent | charge | 2.7 | 75% | 411 | 340 | 83% |
| Opponent | join | 1.0 | 67% | 23 | 0 | 0% |
| Opponent | move | 31.0 | 94% | 1589 | 0 | 0% |
| Opponent | shoot | 2.3 | 43% | 106 | 17 | 16% |

### Battle groups: gs3-83c8646-p82

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.3 | 8% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 0.7 | 100% | 100% | 0% | - | 50% | 0% | 50% | 0% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p82

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 8 | 99 (8) | 0 | 99 | 83 | 12% | 4.4 | 0 (1) | 220 (3) | 36 (4) | 99 (8) | - |
| Mine | Character | 7 | 26 (7) | 26 | 0 | 51 | 14% | 2.7 | 36 (4) | - | - | 53 (3) | 0 (1) |
| Mine | Clean-up | 3 | 0 (3) | 0 | 0 | 14 | 100% | - | 0 (1) | 0 (2) | - | 0 (3) | - |
| Mine | Fast Hammer | 1 | 0 (1) | 0 | 0 | 115 | 0% | 3.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Hammer | 11 | 40 (11) | 28 | 12 | 54 | 18% | 2.6 | 47 (5) | 41 (5) | 0 (1) | 61 (6) | 11 (5) |
| Mine | Shooter | 3 | 0 (3) | 0 | 0 | 67 | 33% | 3.0 | 0 (2) | 0 (1) | - | - | 0 (3) |
| Mine | Wizard | 3 | 0 (3) | 0 | 0 | 101 | 33% | 2.5 | 0 (1) | 0 (2) | - | 0 (2) | 0 (1) |
| Opponent | Chaff | 4 | 0 (4) | 0 | 0 | 31 | 100% | - | 0 (3) | - | 0 (1) | 0 (4) | - |
| Opponent | Character | 8 | 84 (8) | 84 | 0 | 10 | 25% | 2.8 | 44 (3) | 100 (5) | - | 50 (6) | 172 (2) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | - | - | 0 (1) | 0 (1) | - |
| Opponent | Fast Hammer | 5 | 34 (5) | 8 | 26 | 51 | 20% | 3.0 | 22 (2) | 49 (2) | 22 (1) | 46 (3) | 12 (2) |
| Opponent | Hammer | 8 | 38 (8) | 38 | 0 | 14 | 25% | 2.8 | 75 (3) | 16 (4) | 0 (1) | 50 (6) | 0 (2) |
| Opponent | Holder | 4 | 71 (4) | 0 | 71 | 0 | 100% | - | 125 (1) | 52 (3) | - | 22 (1) | 88 (3) |
| Opponent | Shooter | 2 | 77 (2) | 77 | 0 | 0 | 0% | 1.5 | 31 (1) | 117 (1) | - | 31 (1) | 117 (1) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 38 | 67% | 1.0 | - | 0 (2) | - | 0 (1) | 0 (1) |

### Charged fights: gs3-83c8646-p82

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 1 | 116 | 0 | 2.0 | 1.0 | 0 | 45 | -45 | 0 of 2 | 0 of 2 | - | -45 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 442 | 4.0 | 1.0 | 110 | 222 | -111 | 2 of 4 | 2 of 4 | - | -111 |
| Mine | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 39 | 147 | 2.0 | 1.0 | 74 | 163 | -89 | 2 of 6 | 2 of 6 | - | -89 |
| Opponent | Warriors of Chaos | 2 | 0 | 440 | 3.0 | 1.0 | 147 | 19 | +128 | 3 of 6 | 5 of 6 | - | +128 |
| Opponent | Wood Elf Realms | 1 | 340 | 210 | 2.0 | 1.0 | 105 | 223 | -118 | 2 of 2 | 1 of 2 | - | -118 |
| **Opponent** | all armies | 3 | 113 | 364 | 2.7 | 1.0 | 136 | 70 | +66 | 5 of 8 | 6 of 8 | - | +66 |

### Effective charges: gs3-83c8646-p82

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 0 | 0 | 1 (net +135) | 3 | 0% (0 of 1) |
| Opponent | Warriors of Chaos | 6 | 2 (net +321) | 0 | 0 | 0 | 1 (net +68) | 3 (net +18) | 0 | 0% (0 of 6) |

### Charged fights, damage counted: gs3-83c8646-p82

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 350 | 135 | +135 | 135 | 0 | +135 | +38.6 |
| Mine | No odds | 5 | 176 | 282 | -134 | 103 | 195 | -93 | -52.7 |
| Mine | All fights | 6 | 205 | 258 | -89 | 108 | 163 | -55 | -26.7 |
| Opponent | Long shot (under 50%) | 2 | 308 | 320 | +321 | 396 | 58 | +338 | +109.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 375 | 182 | +18 | 103 | 0 | +103 | +27.4 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 116 | 34 | +68 | 68 | 0 | +68 | +58.6 |
| Opponent | No odds | 2 | 52 | 210 | -118 | 122 | 247 | -124 | -239.4 |
| Opponent | All fights | 8 | 245 | 205 | +66 | 176 | 76 | +100 | +40.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p82 | move | 9 | 2 (22%) | 2 (22%) | 1 (11%) | 6 (67%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Elixir of Power | Mine | L1932 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L2033 |
| Periapt of Soul Exchange | Mine | L2033 |
| Ring of Doom | Opponent | L1831, L2033 |

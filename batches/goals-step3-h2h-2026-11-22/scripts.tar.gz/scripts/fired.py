# Count lines in the game logs that name each step 3 rule, per part side (step 3 on = Opponent in 1-48, Mine in 49-96).
import tarfile, sys, collections
D='/mnt/project-files/goals-step3-h2h-2026-11-22'
tags=['GOAL ON TIME','NEAREST TO GOAL','GOAL ROUTE','FOOT FIRST','GOAL WALK']
c=collections.Counter(); games=0
for n in range(1,97):
    with tarfile.open(f'{D}/part-{n}/batch.tgz') as tf:
        for m in tf.getmembers():
            if m.name.count('/')==1 and m.name.endswith('.log.jsonl'):
                games+=1; s=tf.extractfile(m).read().decode('utf8','replace')
                for t in tags: c[(t, n<=48)]+=s.count(t)
print('games',games)
for t in tags: print(f'{t:16} parts 1-48 (on=Opponent): {c[(t,True)]:7}   parts 49-96 (on=Mine): {c[(t,False)]:7}')

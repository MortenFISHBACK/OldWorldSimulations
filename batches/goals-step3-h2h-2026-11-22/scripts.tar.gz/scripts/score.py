# Score the step 3 head-to-head: margin = VP of the side with step 3 ON minus the other side.
import csv, io, sys, tarfile, statistics as st, glob, os
D = sys.argv[1] if len(sys.argv) > 1 else '/mnt/project-files/goals-step3-h2h-2026-11-22'
rows, missing = [], []
for n in range(1, 97):
    t = f'{D}/part-{n}/batch.tgz'
    if not os.path.exists(f'{D}/part-{n}/done'): missing.append(n); continue
    with tarfile.open(t) as tf:
        m = [x for x in tf.getmembers() if x.name.count('/') == 1 and x.name.endswith('/games.csv')]
        for r in csv.DictReader(io.TextIOWrapper(tf.extractfile(m[0]))):
            r['part'] = n; r['on'] = 'Opponent' if n <= 48 else 'Mine'; rows.append(r)
sc, un = [], []
for r in rows:
    if r['ended'] != 'yes' or '-' not in r['vp_mine_opponent']: un.append((r['pair'], r['part'], r['ended'], r['minutes'], r['round'])); continue
    a, b = map(int, r['vp_mine_opponent'].split('-'))
    r['margin'] = (b - a) if r['on'] == 'Opponent' else (a - b)
    r['res'] = 'draw' if r['winner'] not in ('Mine', 'Opponent') else ('on' if r['winner'] == r['on'] else 'off')
    sc.append(r)
ms = [r['margin'] for r in sc]
print('parts in', 96 - len(missing), 'missing', missing)
print('scored', len(sc), 'unscored', un)
if ms:
    print('margin mean %.0f sd %.0f se %.0f' % (st.mean(ms), st.pstdev(ms), st.pstdev(ms) / len(ms) ** .5))
    print('wins', {k: sum(r['res'] == k for r in sc) for k in ('on', 'off', 'draw')})
    mins = [float(r['minutes']) for r in sc]; print('minutes mean %.1f median %.1f' % (st.mean(mins), st.median(mins)))
    by = {}
    for r in sc: by.setdefault((r['pair'], r['scenario']), {})[r['on']] = r['margin']
    both = [v['Mine'] + v['Opponent'] for v in by.values() if len(v) == 2]
    if both:
        print('pairs both ways %d sum-margin mean %.0f sd %.0f se %.0f; step 3 better %d worse %d even %d' % (len(both), st.mean(both), st.pstdev(both), st.pstdev(both) / len(both) ** .5, sum(x > 0 for x in both), sum(x < 0 for x in both), sum(x == 0 for x in both)))

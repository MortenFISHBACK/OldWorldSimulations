# Doctrine scorecard: gs3-83c8646-p63

### Scorecard: gs3-83c8646-p63

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0409 | 1 | 1 | Mine | no | 14 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 420 |
| L0425 | 5 | 1 | Mine | yes | - | 3 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | no | - | 6 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 380 |
| L0512 | 2 | 1 | Opponent | - | - | - | 1 | 1 | 1 | 0 | 0 | 165 |
| **Average** | | | Mine | 50% | 14.0 | 3.0 | 0.7 | 2.7 | 0.0 | 0.0 | 0.0 | 126.7 |
| **Average** | | | Opponent | 0% | 0.0 | 6.0 | 1.0 | 2.0 | 0.3 | 0.0 | 0.0 | 195.0 |

### KPIs: gs3-83c8646-p63

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 29% (4 of 14) | 0% (0 of 11) | 16% (4 of 25) |
| Winner chose to follow up after the loser gave ground |  | 100% (8 of 8); on the table 100% | - | 100% (8 of 8); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 100% (9 of 9); on the table 100% | - | 100% (9 of 9); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 33% (4 of 12) | 39% (14 of 36) | 38% (18 of 48) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 44% (4 of 9) | 44% (14 of 32) | 44% (18 of 41) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 71% (4282 of 5998) | 70% (4224 of 5998) | 71% (8506 of 11996) |
|   infantry points that never fought | lower | 73% (1046 of 1424) | 94% (1119 of 1187) | 83% (2165 of 2611) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% (14 of 23) | 89% (24 of 27) | 76% (38 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (3 of 3); 2.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 64% (3290 of 5120) | 91% (4979 of 5442) | 78% (8269 of 10562) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (38%) | 3.7 (50%) | 4.7 (47%) |
| MARCHED: its unit marched | 0.7 (25%) | 2.3 (32%) | 3.0 (30%) |
| IN COMBAT: engaged in combat | 1.0 (38%) | 0.7 (9%) | 1.7 (17%) |
| GONE: slain | 0.0 (0%) | 0.7 (9%) | 0.7 (7%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 6.7 | 1.7 | 2.7 | 6.0 | 0.7 | 0.7 |
| not cast | 3.3 | 4.3 | 3.3 | 10.0 | 1.3 | 19.3 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.7 (85%) | 2.0 (60%) | 4.7 (47%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.0 (30%) | 1.0 (75%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (10%) | 0.3 (8%) | 1.0 (30%) | 1.7 (17%) | 0.3 (25%) | 0.0 (0%) |
| GONE: slain | 0.7 (20%) | 0.0 (0%) | 0.0 (0%) | 0.7 (7%) | 0.0 (0%) | 1.7 (9%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.3 (8%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (70%) | 0.0 (0%) | 0.3 (10%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.7 (91%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.7 a game | 2.0 a game | 1.3 a game |
| stood (cast and not dispelled) | 100% (2 of 2) | 67% (4 of 6) | 75% (6 of 8) |
| the unit moved after it | 50% (1 of 2) | 100% (4 of 4) | 83% (5 of 6) |
| it charged on its next turn | 0% (0 of 2) | 0% (0 of 4) | 0% (0 of 6) |
| the enemy charged it first | 0% (0 of 2) | 0% (0 of 4) | 0% (0 of 6) |
| it fought by the end of its next turn | 0% (0 of 2) | 0% (0 of 4) | 0% (0 of 6) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 2) | 25% (1 of 4) | 17% (1 of 6) |
| none of these (no charge, no fight, no charge escaped) | 100% (2 of 2) | 75% (3 of 4) | 83% (5 of 6) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 62% (57 of 92) | 74% (46 of 62) | 67% (103 of 154) |
|   cavalry | 58% (7 of 12) | - | 58% (7 of 12) |
|   character | 78% (14 of 18) | 100% (8 of 8) | 85% (22 of 26) |
|   chariot | 21% (5 of 24) | 100% (6 of 6) | 37% (11 of 30) |
|   infantry | 58% (7 of 12) | 68% (15 of 22) | 65% (22 of 34) |
|   monster | - | 33% (2 of 6) | 33% (2 of 6) |
|   war machine | 92% (24 of 26) | 75% (15 of 20) | 85% (39 of 46) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (20%) | 0.7 (12%) | 3.0 (18%) |
| IN COMBAT: it fought this turn or the last | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.3 (6%) | 0.3 (2%) |
| NO TARGET IN RANGE | 5.7 (49%) | 1.0 (19%) | 6.7 (39%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (6%) | 0.0 (0%) | 0.7 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.0 (17%) | 2.0 (38%) | 4.0 (24%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 1.0 (19%) | 1.3 (8%) |
| OTHER BAR | 0.3 (3%) | 0.3 (6%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| character | 7.3 | 1.3 | 82% | 6.1 pts | 45 pts |
| chariot | 3.7 | 2.3 | 64% | 8.4 pts | 31 pts |
| infantry | 9.7 | 2.3 | 79% | 4.4 pts | 43 pts |
| monster | 1.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 13.3 | 9.0 | 62% | 21.6 pts | 288 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.0 | 1.0 | 1.5 |
| Charges that made contact a game | 2.0 | 1.0 | 1.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 1.00 contact (2 units) | 0.33 declared, 0.33 contact (3 units) | 0.60 declared, 0.60 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.50 declared, 0.50 contact (2 units) | 0.50 declared, 0.50 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.18 declared, 0.18 contact (22 units) | 0.06 declared, 0.06 contact (18 units) | 0.12 declared, 0.12 contact (40 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 75% (3 of 4) | 100% (2 of 2) | - | 83% (5 of 6) |
| Character in a unit | 80% (4 of 5) | 100% (1 of 1) | - | 83% (5 of 6) |
| Character on its own | 100% (2 of 2) | 83% (5 of 6) | 75% (3 of 4) | 83% (10 of 12) |
| Chariot | - | 100% (5 of 5) | - | 100% (5 of 5) |
| Infantry | 50% (6 of 12) | 67% (2 of 3) | - | 53% (8 of 15) |
| Monstrous | - | 100% (1 of 1) | - | 100% (1 of 1) |
| War Machines | 80% (4 of 5) | - | - | 80% (4 of 5) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 2 | 100% (7 of 7); on the table 100% | 33% (4 of 12) | 76% | 56% (9 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Dwarfen Mountain Holds | 1 | 100% (2 of 2); on the table 100% | - | 62% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | - | 67% (8 of 12) | 100% | 92% (11 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 17% (3 of 18) | 81% | 78% (7 of 9) | 100% (3 of 3); 6.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Vampire Counts | 1 | - | 50% (3 of 6) | 30% | 100% (6 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p63, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (1) | 25% (1) | 33% (2) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.33 | 0.67 |

### Quality by phase: gs3-83c8646-p63

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 67% (4 of 6) | 100% (2 of 2) |
| Strategy | Shoot objectives carried out (shot that target) | 35% (13 of 37) | 56% (19 of 34) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | - |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 50% (1 of 2) |
| Strategy | Joined characters whose unit fought | 60% (3 of 5) | 0% (0 of 5) |
| Strategy | Lone characters that fought | 33% (2 of 6) | 44% (4 of 9) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.7 | 2.0 |
| Movement | Points that never moved of their own | 126.7 | 195.0 |
| Movement | Fights charged into per game | 1.7 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 5, net +666 | 1 of 2, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 5 | 1 of 2, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 5, net +60 | 0 of 2 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 5, net +0 | 0 of 2 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.0 | 10.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (15 of 33) | 39% (12 of 31) |
| Shooting | Points destroyed by shooting units | 144.7 | 0.0 |
| Shooting | War machine shots | 8.0 | 5.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 42% (10 of 24) | 47% (7 of 15) |
| Shooting | Points destroyed by war machines | 55.0 | 31.7 |
| Magic | Magic missiles cast | 1.0 | 2.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 67% (2 of 3) | 43% (3 of 7) |
| Magic | Wounds caused by magic missiles | 4.7 | 3.7 |
| Magic | Points destroyed by magic (all spells) | 84.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 3.7 / 0.0 / 0.0 / 0.0 | 1.3 / 0.7 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 284.7 | 0.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +185 | +17 |
| Combat | Net per 100 charger points, damage counted | +54.0 | +5.5 |
| Combat | First round won (charged fights) | 100% | 0% |
| Combat | Net points per charged fight | +157 | -23 |
| Combat | Net points per supported fight / lone fight | +666 / +30 | - / -23 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 5 | 2 of 3 |
| Game | Points lost | 63.3 | 583.3 |
| Game | VP from objectives | 970.0 | 363.3 |
| Game | Lone holders (player turns) | 14.0 | 0.0 |

- Mine won / drew / lost: 3 / 0 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +1193 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 647
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p63

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 18.7 | +268.1 | 0.0 | 0.0 | 18.7 | +63.3 | 0.0 | 25.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| ASSAILMENT BY POINTS | - | - | - | - | 0.3 | +0.5 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.3 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 1.0 | +0.0 | 345.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 7.0 | +217.4 | 690.7 | 63.3 | 5.0 | +52.9 | 63.3 | 41.7 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CAST JOB | - | - | - | - | 5.3 | +28.4 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 0.7 | +4.9 | 0.0 | 30.0 |
| CHALLENGE BY POINTS | 0.3 | +6.2 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| CHARACTER GUNS | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 15.0 | -220.9 | 0.0 | 0.0 | 14.3 | -517.3 | 0.0 | 699.3 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 8.0 | +0.0 | 0.0 | 0.0 | 9.7 | +0.0 | 0.0 | 144.7 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.7 | +81.8 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| COVER ONCE | 3.7 | -449.3 | 0.0 | 0.0 | 4.0 | -347.1 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.3 | -20.0 | 132.7 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -10.1 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 8.7 | +61.0 | 0.0 | 0.0 | 6.3 | +5.3 | 0.0 | 96.7 |
| DUEL STOPS AT THE KILL | 0.3 | -3.4 | 132.7 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | 0.3 | +35.9 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 1.0 | +17.9 | 157.7 | 0.0 | 0.3 | +19.3 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.7 | +0.0 | 280.3 | 0.0 | 0.7 | +0.3 | 0.0 | 0.0 |
| FALLS SHORT | 7.3 | +131.3 | 0.0 | 0.0 | 16.3 | +119.0 | 0.0 | 828.0 |
| FEATURE BUFFS | - | - | - | - | 0.7 | +9.6 | 0.0 | 265.3 |
| FIGHT LIFT | 0.7 | +3.9 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 1.0 | +74.5 | 265.3 | 0.0 | 0.7 | +22.7 | 0.0 | 0.0 |
| FIVE ACTION | 104.3 | +6744.9 | 3053.3 | 190.0 | 89.3 | +3226.1 | 126.7 | 1476.0 |
| FLANK NOT WEIGHED | 2.7 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 169.7 |
| FOLLOW UP WEIGHED | 2.7 | +346.6 | 0.0 | 0.0 | - | - | - | - |
| FOOT FIRST | 24.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 2.0 | +302.2 | 305.3 | 0.0 | 1.0 | +207.8 | 0.0 | 0.0 |
| FREED FROM HIS FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 194.7 |
| FRIEND SHOOTS FIRST | 0.3 | -6.0 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.3 | +15.0 | 0.0 | 0.0 | - | - | - | - |
| GATEWAY ESCAPE | - | - | - | - | 0.7 | +61.0 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.3 | -2.1 | 0.0 | 0.0 |
| GOAL WALK | 15.3 | +1313.1 | 0.0 | 0.0 | 4.0 | +109.9 | 0.0 | 169.3 |
| GUN FIGURES | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| GUN MASK | 0.7 | +20.7 | 0.0 | 0.0 | 0.3 | -6.7 | 0.0 | 144.7 |
| HARD STAY DROPPED | 3.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 2.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 410.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +23.7 | 0.0 | 0.0 |
| HIS CHARGE LIST | 7.7 | +0.0 | 0.0 | 0.0 | 9.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 144.7 |
| HIS MOVE AND SHOT | 7.3 | -26.0 | 0.0 | 0.0 | 2.3 | -26.9 | 0.0 | 0.0 |
| HIS ONE QUARTER | 4.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 2.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 144.7 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 51.7 | +3815.2 | 0.0 | 0.0 | 47.0 | +3343.4 | 0.0 | 1392.7 |
| HIS SHOTS BY HIS RUN | 33.3 | +850.5 | 0.0 | 0.0 | 32.0 | +587.6 | 0.0 | 749.3 |
| HIS TURN DENIED | - | - | - | - | 0.3 | +59.1 | 0.0 | 0.0 |
| HOLD ODDS | 16.3 | +0.0 | 0.0 | 0.0 | 12.0 | +0.0 | 0.0 | 530.7 |
| HOLDER ASSIGNMENT | 9.3 | +946.4 | 0.0 | 0.0 | 7.7 | +948.7 | 0.0 | 132.7 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.0 | -122.0 | 305.3 | 0.0 | 1.0 | -63.8 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.7 | +80.5 | 0.0 | 0.0 | 1.3 | +325.1 | 0.0 | 289.3 |
| IDLE COST | 5.0 | -90.6 | 0.0 | 0.0 | 13.3 | -204.5 | 0.0 | 314.0 |
| JOINT CHARGE NOW | 0.7 | +72.8 | 265.3 | 0.0 | 0.3 | -45.6 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +64.9 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 4.3 | +0.0 | 315.3 | 0.0 | 4.7 | +0.0 | 0.0 | 415.7 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.7 | +30.1 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +28.0 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 0.7 | -0.3 | 132.7 | 0.0 | 1.0 | -6.6 | 0.0 | 0.0 |
| MANOEUVRE | 2.7 | -29.9 | 0.0 | 0.0 | 2.3 | +7.2 | 0.0 | 56.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +6.6 | 0.0 | 0.0 | 0.7 | +16.0 | 0.0 | 0.0 |
| MARCH CHECK | 1.3 | +66.7 | 0.0 | 0.0 | 4.0 | +375.6 | 0.0 | 289.3 |
| MARCH OF THE TABLE | - | - | - | - | 1.0 | +14.8 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | +6.6 | 0.0 | 0.0 | 1.3 | +191.0 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.7 | +117.6 | 0.0 | 0.0 | 2.7 | +114.8 | 0.0 | 289.3 |
| MEETS IN TIME | 5.3 | +153.6 | 0.0 | 0.0 | 2.3 | +33.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.3 | +70.3 | 0.0 | 0.0 | 8.3 | +55.8 | 0.0 | 345.3 |
| MISSILES NEXT TURN | 2.7 | +58.4 | 0.0 | 0.0 | 10.7 | +83.9 | 0.0 | 345.3 |
| MOVE ORDER | 2.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 3.0 | +117.3 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -29.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 1.3 | +104.9 | 0.0 | 0.0 | 3.0 | +116.8 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 7.7 | +315.0 | 0.0 | 0.0 | 10.0 | +422.3 | 0.0 | 188.7 |
| NEAREST TO GOAL | 3.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 0.7 | +21.8 | 0.0 | 0.0 | 2.7 | +111.7 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.0 | -71.8 | 40.0 | 0.0 | 0.3 | -9.4 | 0.0 | 0.0 |
| NO LATE CUT | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 2.7 | -132.2 | 0.0 | 0.0 | 4.0 | -133.0 | 0.0 | 0.0 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 3.0 | +32.2 | 31.7 | 0.0 |
| ONE FIGHT FORMULA | 3.0 | -33.7 | 0.0 | 0.0 | 1.0 | -20.7 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +79.0 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 3.3 | +73.3 | 0.0 | 0.0 | 3.0 | +33.3 | 0.0 | 0.0 |
| ONE ROUTE | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +24.2 | 25.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.3 | +0.2 | 15.0 | 0.0 | 0.3 | +2.7 | 0.0 | 0.0 |
| PATHS CROSS | 0.3 | +1.9 | 0.0 | 0.0 | 1.0 | +4.5 | 0.0 | 0.0 |
| PLAN RESULT | 46.3 | +1533.4 | 991.7 | 126.7 | 40.3 | +196.1 | 297.0 | 742.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 4.7 | -211.2 | 0.0 | 0.0 | 3.7 | -32.5 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| QUARTER ODDS | 18.0 | +1566.6 | 25.0 | 0.0 | 18.3 | +1070.7 | 0.0 | 100.0 |
| REAL GROUND | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.7 | +83.6 | 0.0 | 0.0 | 1.0 | +103.5 | 0.0 | 15.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 0.7 | +0.0 | 0.0 | 15.0 |
| REFORMS TO MEET IT | - | - | - | - | 0.3 | -6.9 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 0.3 | +14.2 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.3 | +52.5 | 280.3 | 0.0 | 1.0 | -43.5 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.3 | -4.7 | 0.0 | 0.0 |
| RUN DOWN | - | - | - | - | 0.7 | -3.3 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.3 | -32.0 | 0.0 | 0.0 | 0.7 | -19.6 | 0.0 | 30.0 |
| SEARCH SPOT | 0.7 | +27.1 | 0.0 | 0.0 | 0.7 | +0.4 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +12.0 | 0.0 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +10.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 13.0 | +0.0 | 0.0 | 63.3 | 11.0 | +0.0 | 0.0 | 56.7 |
| SHOOTS FROM THE BEST SPOT | 4.0 | +140.3 | 254.0 | 0.0 | 2.3 | +16.4 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.7 | -13.1 | 265.3 | 0.0 | 0.3 | -2.4 | 0.0 | 0.0 |
| SHOT RISK POINTS | 28.7 | +457.5 | 0.0 | 0.0 | 22.7 | +212.2 | 0.0 | 848.0 |
| SHOTS AFTER THE MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 14.7 | +696.9 | 0.0 | 95.0 | 16.7 | +359.6 | 0.0 | 96.7 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +10.0 | 0.0 | 0.0 |
| SPELL WORTH | 1.0 | +5.2 | 0.0 | 0.0 | 1.3 | +26.6 | 289.3 | 289.3 |
| SPOT AS THE GAME MOVES | 4.7 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 242.3 |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 61.7 | +0.0 | 2748.0 | 190.0 | 39.0 | +0.0 | 126.7 | 533.7 |
| STAY WORTH | 28.0 | +313.9 | 1626.0 | 221.7 | 25.0 | +12.1 | 63.3 | 180.0 |
| SUPPORT ADDS | 2.0 | +197.7 | 0.0 | 0.0 | 3.7 | +223.7 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 2.0 | +197.7 | 0.0 | 0.0 | 3.7 | +223.7 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +20.7 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 84.7 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 56.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 51.3 | +0.0 | 0.0 | 63.3 | 43.7 | +0.0 | 0.0 | 698.0 |
| TIME ON OUR SIDE | 44.0 | +415.3 | 401.3 | 0.0 | 19.3 | +180.7 | 0.0 | 0.0 |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | +34.5 | 0.0 | 0.0 |
| WHO FIGHTS | 0.3 | +2.9 | 132.7 | 0.0 | - | - | - | - |
| WHO GETS IN | 0.7 | +72.8 | 265.3 | 0.0 | - | - | - | - |
| WHOLE FIGHT | - | - | - | - | 0.3 | +0.7 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 0.7 | -2.7 | 0.0 | 0.0 | 2.0 | -233.1 | 0.0 | 265.3 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +45.6 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 2.0 | +49.8 | 0.0 | 0.0 | 0.7 | +2.3 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p63

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 296 | 287 | 102 | 34.00 | +1885 | +18.5 |
| ARMY TABLE | 112 | 112 | 84 | 28.00 | +1437 | +17.1 |
| HOLDER ASSIGNMENT | 51 | 51 | 49 | 16.33 | +3616 | +73.8 |
| HIS SHOTS BY HIS RUN | 196 | 191 | 38 | 12.67 | +259 | +6.8 |
| SHOT RISK POINTS | 154 | 152 | 35 | 11.67 | +1287 | +36.8 |
| LEGAL CHARGES ONLY | 27 | 27 | 27 | 9.00 | +0 | +0.0 |
| TIME ON OUR SIDE | 190 | 178 | 26 | 8.67 | +108 | +4.1 |
| DEPLOY BY FIGURES | 45 | 45 | 22 | 7.33 | +460 | +20.9 |
| OFF BEST | 20 | 20 | 20 | 6.67 | -796 | -39.8 |
| THE TABLE AGAIN | 36 | 36 | 17 | 5.67 | +0 | +0.0 |
| GOAL WALK | 58 | 58 | 16 | 5.33 | +626 | +39.1 |
| MARCH CHECK | 16 | 16 | 16 | 5.33 | +411 | +25.7 |
| MOVE ORDER | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| HARD STAY DROPPED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 19 | 19 | 13 | 4.33 | +87 | +6.7 |
| CAST JOB | 16 | 16 | 11 | 3.67 | +16 | +1.5 |
| PROMISE BY ITS OWN SUM | 25 | 25 | 11 | 3.67 | -731 | -66.4 |
| SUPPORT ADDS | 17 | 17 | 11 | 3.67 | +143 | +13.0 |
| SUPPORT WORKED OUT | 17 | 17 | 11 | 3.67 | +143 | +13.0 |
| MEETS IN TIME | 23 | 23 | 10 | 3.33 | +383 | +38.3 |
| IDLE COST | 55 | 45 | 9 | 3.00 | +65 | +7.2 |
| MOVE TO CHARGE COMPUTED | 13 | 11 | 9 | 3.00 | +219 | +24.3 |
| OGRE LOADER SECOND SHOT | 9 | 9 | 9 | 3.00 | +97 | +10.7 |
| FOLLOW UP WEIGHED | 8 | 8 | 8 | 2.67 | +1040 | +130.0 |
| CHARGE LOSSES | 88 | 86 | 7 | 2.33 | +690 | +98.6 |
| FIVE ACTION | 581 | 571 | 7 | 2.33 | +603 | +86.2 |
| QUARTER ODDS | 109 | 108 | 7 | 2.33 | +375 | +53.6 |
| STAY WORTH | 159 | 150 | 7 | 2.33 | +55 | +7.8 |
| NEXT CHARGE BY LIST | 10 | 8 | 6 | 2.00 | +106 | +17.7 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| FOUR ROUNDS | 9 | 8 | 5 | 1.67 | +608 | +121.7 |
| CANNON SIGHT KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| COVER ONCE | 23 | 18 | 4 | 1.33 | +15 | +3.7 |
| FALLS SHORT | 71 | 66 | 4 | 1.33 | +29 | +7.2 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +195 | +48.6 |
| PATHS CROSS | 4 | 4 | 4 | 1.33 | +19 | +4.8 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | +82 | +27.2 |
| MANOEUVRE | 15 | 15 | 3 | 1.00 | +26 | +8.6 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +68 | +22.5 |
| MARCH OF THE TABLE | 3 | 3 | 3 | 1.00 | -44 | -14.8 |
| MAX FOR POSITIONING | 13 | 13 | 3 | 1.00 | +28 | +9.3 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +6 | +2.0 |
| THE ROW IN ITS ORDER | 18 | 3 | 3 | 1.00 | +0 | +0.0 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +19 | +9.7 |
| EXACT ROUND | 4 | 4 | 2 | 0.67 | +78 | +39.0 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HUNT IN PAIRS | 6 | 6 | 2 | 0.67 | +425 | +212.6 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +90 | +45.1 |
| REDIRECT COUNTER | 5 | 5 | 2 | 0.67 | +40 | +19.9 |
| REDIRECT FOR A FRIEND IN REACH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SEARCH SPOT | 4 | 4 | 2 | 0.67 | +83 | +41.3 |
| WHO GETS IN | 2 | 2 | 2 | 0.67 | +218 | +109.2 |
| WOUNDS ON THE RANKS | 8 | 8 | 2 | 0.67 | +94 | +47.2 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +2 | +1.5 |
| CANNON PLANNED TARGET | 36 | 36 | 1 | 0.33 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -98 | -97.7 |
| EVASIVE BY THE ODDS | 1 | 1 | 1 | 0.33 | +108 | +107.6 |
| FIGHT TO THE END | 5 | 4 | 1 | 0.33 | +5 | +4.9 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +45 | +45.0 |
| HONEST WORTH | 9 | 8 | 1 | 0.33 | +5 | +4.9 |
| MISSILES IN THE MOVE | 29 | 20 | 1 | 0.33 | +46 | +46.2 |
| NEARER NOT NEEDED | 53 | 50 | 1 | 0.33 | +30 | +30.4 |
| ONE JOINT FIGURE | 1 | 1 | 1 | 0.33 | +219 | +218.9 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +52 | +51.5 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +43 | +42.7 |
| RISK BY ARC | 7 | 6 | 1 | 0.33 | +41 | +41.1 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +36 | +35.9 |
| SHOTS AFTER THE MOVES | 19 | 19 | 1 | 0.33 | +0 | +0.0 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +37 | +36.9 |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 3 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 6 | trace | - | - | - | - |
| CHARACTER GUNS | 6 | 6 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 53 | 52 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 7 | 7 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 30 | not checked | - | - | - | - |
| FOOT FIRST | 74 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 12 | 12 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GATEWAY ESCAPE | 2 | not checked | - | - | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 7 | not checked | - | - | - | - |
| GUN MASK | 3 | 3 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 7 | 7 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 18 | 18 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 52 | 52 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 10 | 10 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 29 | 29 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 15 | 15 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 12 | 12 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HOLD ODDS | 85 | 84 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 12 | 11 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 5 | 4 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 10 | 9 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 40 | 33 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 9 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 1 | trace | - | - | - | - |
| MOVE SPELL SPOT | 1 | not checked | - | - | - | - |
| NEAREST TO GOAL | 11 | 11 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 4 | 4 | 0 | 0.00 | - | - |
| NO LATE CUT | 6 | 6 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| ONE FIGHT FORMULA | 12 | 7 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 19 | 11 | 0 | 0.00 | - | - |
| ONE ROUTE | 10 | 9 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 260 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 10 | 9 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 1 | 1 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 2 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 72 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SHOTS IN THE MOVE | 94 | 77 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 7 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 31 | 27 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 3 | 3 | 0 | 0.00 | - | - |
| STANDS STILL | 302 | 300 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 10 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 16 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 10 | not checked | - | - | - | - |
| THE TABLE BINDS | 285 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 3 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 4 | 4 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | not checked | - | - | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | not checked | - | - | - | - |
| WHOLE FIGHT DANGER | 8 | 8 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p63

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.33 | 3.33 | 35.5 |
| ARMY TABLE | rule | 3.33 | 0.33 | 47.2 |
| PROMISE BY ITS OWN SUM | rule | 2.00 | 1.67 | 66.4 |
| MARCH OF THE TABLE | rule | - | 1.00 | 14.8 |
| JOINT CHARGE NOW | rule | 0.33 | 0.33 | 82.8 |
| RULE SWITCHED OFF | gate | - | 0.67 | 93.0 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 97.7 |
| PATHS CROSS | rule | - | 0.33 | 4.2 |
| TURN GATE | gate | 0.33 | - | 5.9 |
| WHO GETS IN | rule | 0.33 | - | 28.7 |

### Plans: gs3-83c8646-p63

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 75% | 242 | 184 | 76% |
| Mine | join | 1.7 | 100% | 57 | 0 | 0% |
| Mine | move | 33.0 | 100% | 2053 | 0 | 0% |
| Mine | shoot | 10.0 | 70% | 752 | 1350 | 180% |
| Mine | support | 0.3 | 100% | 0 | 0 | - |
| Opponent | charge | 0.7 | 50% | 106 | 5 | 5% |
| Opponent | join | 1.7 | 100% | 93 | 0 | 0% |
| Opponent | move | 28.3 | 96% | 923 | 0 | 0% |
| Opponent | shoot | 9.3 | 39% | 304 | 191 | 63% |
| Opponent | support | 0.3 | 100% | 0 | 0 | - |

### Battle groups: gs3-83c8646-p63

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.7 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 1.0 | 33% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p63

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Character | 11 | 58 (11) | 58 | 0 | 0 | 27% | 2.1 | 50 (8) | 89 (3) | - | 79 (8) | 0 (3) |
| Mine | Clean-up | 6 | 134 (6) | 0 | 134 | 0 | 83% | 4.0 | 57 (3) | 222 (2) | 250 (1) | 164 (5) | 0 (1) |
| Mine | Fast Hammer | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Hammer | 6 | 0 (6) | 0 | 0 | 0 | 67% | 3.0 | 0 (2) | 0 (4) | - | 0 (5) | 0 (1) |
| Mine | Holder | 2 | 49 (2) | 16 | 32 | 0 | 50% | 2.0 | 65 (1) | 32 (1) | - | 49 (2) | - |
| Mine | Shooter | 2 | 105 (2) | 0 | 105 | 0 | 0% | 2.0 | 209 (1) | 0 (1) | - | 105 (2) | - |
| Mine | War machine | 5 | 35 (5) | 35 | 0 | 40 | 0% | 1.0 | 87 (2) | 0 (1) | 0 (2) | - | 35 (5) |
| Opponent | Chaff | 4 | 0 (4) | 0 | 0 | 73 | 25% | 4.0 | 0 (4) | - | - | 0 (3) | 0 (1) |
| Opponent | Character | 9 | 0 (9) | 0 | 0 | 40 | 44% | 2.8 | 0 (2) | 0 (4) | 0 (2) | 0 (6) | 0 (2) |
| Opponent | Clean-up | 2 | 0 (2) | 0 | 0 | 57 | 100% | - | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 1 | 0 (1) | 0 | 0 | 114 | 0% | 4.0 | 0 (1) | - | - | - | 0 (1) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 0 | 33% | 2.0 | - | 0 (3) | - | 0 (2) | 0 (1) |
| Opponent | Holder | 3 | 19 (3) | 0 | 19 | 31 | 33% | 2.0 | - | 27 (2) | - | 52 (1) | 0 (1) |
| Opponent | Shooter | 3 | 77 (3) | 0 | 77 | 0 | 0% | 1.0 | - | 231 (1) | 0 (2) | 115 (2) | 0 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | War machine | 5 | 13 (5) | 13 | 0 | 41 | 20% | 1.0 | - | - | 13 (5) | - | 13 (5) |
| Opponent | Wizard | 5 | 0 (5) | 0 | 0 | 0 | 0% | 3.0 | 0 (3) | 0 (2) | - | 0 (2) | 0 (3) |

### Charged fights: gs3-83c8646-p63

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 127 | 393 | 2.5 | 1.2 | 157 | 0 | +157 | 2 of 5 | 5 of 5 | +666 | +30 |
| Mine | Dwarfen Mountain Holds | 1 | 599 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 284 | 262 | 1.7 | 1.2 | 157 | 0 | +157 | 2 of 5 | 5 of 5 | +666 | +30 |
| Opponent | Empire of Man | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 95 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 34 | -34 | 1 of 2 | 0 of 2 | - | -34 |
| **Opponent** | all armies | 3 | 32 | 0 | 1.0 | 1.0 | 0 | 23 | -23 | 2 of 3 | 0 of 3 | - | -23 |

### Effective charges: gs3-83c8646-p63

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 5 | 1 (net +666) | 0 | 0 | 0 | 2 (net +60) | 2 (net +0) | 0 | 0% (0 of 5) |
| Opponent | Grand Cathay | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Vampire Counts | 2 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 1 | 100% (1 of 1) |

### Charged fights, damage counted: gs3-83c8646-p63

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 619 | 348 | +666 | 666 | 0 | +666 | +107.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 239 | 346 | +0 | 70 | 0 | +70 | +29.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 310 | 60 | +60 | 60 | 0 | +60 | +19.4 |
| Mine | All fights | 5 | 343 | 232 | +157 | 185 | 0 | +185 | +54.0 |
| Opponent | Long shot (under 50%) | 1 | 379 | 239 | +0 | 159 | 88 | +71 | +18.6 |
| Opponent | Effective (55-75%) | 1 | 480 | 139 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | No odds | 1 | 68 | 339 | -68 | 48 | 68 | -20 | -28.8 |
| Opponent | All fights | 3 | 309 | 239 | -23 | 69 | 52 | +17 | +5.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p63 | move | 5 | 0 (0%) | 0 (0%) | 2 (40%) | 3 (60%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0425 |
| Clockwork Compass | Opponent | L0512 |
| Invocation of Nehek | Opponent | L0425 |
| Ring of Doom | Opponent | L0512 |
| Ring of Jet | Opponent | L0512 |

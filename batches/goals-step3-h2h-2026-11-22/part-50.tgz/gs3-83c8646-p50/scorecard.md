# Doctrine scorecard: gs3-83c8646-p50

### Scorecard: gs3-83c8646-p50

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0218 | 2 | 1 | Mine | - | - | - | 0 | 9 | 0 | 0 | 0 | 255 |
| L0218 | 2 | 1 | Opponent | - | - | - | 0 | 6 | 0 | 0 | 0 | 336 |
| L0235 | 1 | 1 | Mine | no | 0 | 4 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Opponent | no | 1 | 3 | 0 | 4 | 1 | 0 | 0 | 235 |
| L0319 | 1 | 1 | Mine | no | 7 | 5 | 1 | 0 | 0 | 0 | 0 | 480 |
| L0319 | 1 | 1 | Opponent | no | 3 | 2 | 3 | 3 | 1 | 0 | 0 | 104 |
| **Average** | | | Mine | 0% | 3.5 | 4.5 | 1.3 | 4.3 | 0.0 | 0.0 | 0.0 | 245.0 |
| **Average** | | | Opponent | 0% | 2.0 | 2.5 | 1.0 | 4.3 | 0.7 | 0.0 | 0.0 | 225.0 |

### KPIs: gs3-83c8646-p50

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 42% (5 of 12) | 0% (0 of 12) | 21% (5 of 24) |
| Winner chose to follow up after the loser gave ground |  | 67% (2 of 3); on the table 100% | 100% (1 of 1); on the table 100% | 75% (3 of 4); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | - | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fled |  | 50% (2 of 4); on the table 100% | - | 50% (2 of 4); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 50% (4 of 8); on the table 88% | 100% (1 of 1); on the table 100% | 56% (5 of 9); on the table 89% |
| Magic missiles tried each own turn | 50%+ | 52% (22 of 42) | 21% (5 of 24) | 41% (27 of 66) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 52% (22 of 42) | 28% (5 of 18) | 45% (27 of 60) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 92% (11 of 12) | - | 92% (11 of 12) |
| Points that never fought | lower | 79% (4602 of 5797) | 69% (4114 of 6000) | 74% (8716 of 11797) |
|   infantry points that never fought | lower | 93% (1279 of 1374) | 100% (842 of 842) | 96% (2121 of 2216) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 60% (12 of 20) | 56% (15 of 27) | 57% (27 of 47) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 6.3 uses a game | 50% (1 of 2); 1.3 uses a game | 83% (5 of 6); 3.8 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 60% (3 of 5); 1.0 uses a game | 0% (0 of 1); 0.0 uses a game | 50% (3 of 6); 0.5 uses a game |
|   their share of the points of units over 100 pts | lower | 52% (2113 of 4039) | 57% (3138 of 5515) | 55% (5251 of 9554) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 6.0 (90%) | 0.0 (0%) | 6.0 (46%) |
| MARCHED: its unit marched | 0.7 (10%) | 0.3 (5%) | 1.0 (8%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 1.0 (16%) | 1.0 (8%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 2.7 (42%) | 2.7 (21%) |
| GONE: slain | 0.0 (0%) | 1.0 (16%) | 1.0 (8%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 1.3 (21%) | 1.3 (10%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- |
| tried | 1.0 | 3.3 | 9.0 | 0.3 |
| not cast | 3.0 | 6.7 | 13.0 | 26.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.7 (14%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (11%) | 0.3 (5%) | 6.0 (46%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.0 (8%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (11%) | 0.3 (5%) | 1.0 (8%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (67%) | 3.3 (50%) | 2.7 (21%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| GONE: slain | 0.3 (11%) | 0.7 (10%) | 1.0 (8%) | 2.0 (8%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 1.3 (10%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.0 (0%) | 2.0 (30%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 20.7 (78%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.7 a game | 0.7 a game | 1.7 a game |
| stood (cast and not dispelled) | 75% (6 of 8) | 100% (2 of 2) | 80% (8 of 10) |
| the unit moved after it | 100% (6 of 6) | 0% (0 of 2) | 75% (6 of 8) |
| it charged on its next turn | 0% (0 of 6) | 0% (0 of 2) | 0% (0 of 8) |
| the enemy charged it first | 0% (0 of 6) | 0% (0 of 2) | 0% (0 of 8) |
| it fought by the end of its next turn | 0% (0 of 6) | 0% (0 of 2) | 0% (0 of 8) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 6) | 0% (0 of 2) | 0% (0 of 8) |
| none of these (no charge, no fight, no charge escaped) | 100% (6 of 6) | 100% (2 of 2) | 100% (8 of 8) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 62% (18 of 29) | 55% (46 of 83) | 57% (64 of 112) |
|   cavalry | - | 72% (13 of 18) | 72% (13 of 18) |
|   character | - | 55% (6 of 11) | 55% (6 of 11) |
|   chariot | 20% (2 of 10) | 58% (7 of 12) | 41% (9 of 22) |
|   infantry | - | 33% (10 of 30) | 33% (10 of 30) |
|   monster | - | 83% (10 of 12) | 83% (10 of 12) |
|   war machine | 84% (16 of 19) | - | 84% (16 of 19) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.0 (27%) | 1.7 (14%) | 2.7 (17%) |
| CHARGED: it charged | 0.3 (9%) | 0.3 (3%) | 0.7 (4%) |
| IN COMBAT: it fought this turn or the last | 0.7 (18%) | 0.3 (3%) | 1.0 (6%) |
| MOVED: a war machine that moved | 0.7 (18%) | 0.0 (0%) | 0.7 (4%) |
| NO TARGET IN RANGE | 0.3 (9%) | 6.7 (54%) | 7.0 (44%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (9%) | 0.0 (0%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 1.3 (11%) | 1.3 (8%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| OTHER BAR | 0.3 (9%) | 1.7 (14%) | 2.0 (12%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.7 | 1.3 | 80% | 3.3 pts | 22 pts |
| character | 2.0 | 1.3 | 33% | 12.4 pts | 25 pts |
| chariot | 3.0 | 3.7 | 33% | 39.9 pts | 120 pts |
| infantry | 3.3 | 2.0 | 70% | 6.9 pts | 23 pts |
| monster | 3.3 | 3.0 | 50% | 13.3 pts | 44 pts |
| war machine | 5.3 | 1.7 | 75% | 3.4 pts | 18 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.0 | 2.3 | 2.2 |
| Charges that made contact a game | 1.3 | 1.0 | 1.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | - | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.24 declared, 0.16 contact (25 units) | 0.24 declared, 0.10 contact (29 units) | 0.24 declared, 0.13 contact (54 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 33% (1 of 3) | 100% (1 of 1) | - | 50% (2 of 4) |
| Character in a unit | 100% (5 of 5) | 60% (3 of 5) | - | 80% (8 of 10) |
| Character on its own | 33% (1 of 3) | 67% (2 of 3) | 50% (1 of 2) | 50% (4 of 8) |
| Chariot | 50% (1 of 2) | 0% (0 of 2) | - | 25% (1 of 4) |
| Infantry | 60% (3 of 5) | 33% (1 of 3) | - | 50% (4 of 8) |
| Monster | 50% (1 of 2) | 0% (0 of 1) | - | 33% (1 of 3) |
| Monstrous | 100% (2 of 2) | 50% (2 of 4) | - | 67% (4 of 6) |
| War Machines | 67% (2 of 3) | 100% (1 of 1) | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 2 | 50% (1 of 2); on the table 50% | 60% (18 of 30) | 91% | 67% (8 of 12) | 100% (4 of 4); 9.5 uses a game | 0.0 uses a game | 75% (3 of 4); 1.5 uses a game |
| Chaos Dwarfs | 1 | 50% (3 of 6); on the table 100% | 33% (4 of 12) | 57% | 50% (4 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 100% | 57% (4 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (1 of 1); on the table 100% | 8% (1 of 12) | 33% | 50% (4 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Wood Elf Realms | 1 | - | 67% (4 of 6) | 73% | 58% (7 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p50, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 50% (1) | 25% (1) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p50

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | 67% (4 of 6) | 0% (0 of 3) |
| Strategy | Shoot objectives carried out (shot that target) | 42% (11 of 26) | 33% (4 of 12) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 67% (2 of 3) |
| Strategy | Joined characters whose unit fought | 0% (0 of 11) | 0% (0 of 1) |
| Strategy | Lone characters that fought | 0% (0 of 4) | 75% (6 of 8) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 4.3 | 4.3 |
| Movement | Points that never moved of their own | 245.0 | 225.0 |
| Movement | Fights charged into per game | 1.0 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 3 | - |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 3 | - |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 3 | - |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 3, net +74 | - |
| Shooting | Shots by shooting units (incl. breath weapons) | 0.7 | 16.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (1 of 2) | 24% (12 of 49) |
| Shooting | Points destroyed by shooting units | 108.7 | 72.7 |
| Shooting | War machine shots | 5.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 19% (3 of 16) | - |
| Shooting | Points destroyed by war machines | 18.3 | 28.3 |
| Magic | Magic missiles cast | 4.3 | 1.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 23% (3 of 13) | 20% (1 of 5) |
| Magic | Wounds caused by magic missiles | 13.3 | 3.7 |
| Magic | Wounds caused by other spells | - | 0.7 |
| Magic | Points destroyed by magic (all spells) | 105.0 | 46.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 0.0 / 1.0 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 309.3 | 206.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +131 | +63 |
| Combat | Net per 100 charger points, damage counted | +68.3 | +18.1 |
| Combat | First round won (charged fights) | 67% | 100% |
| Combat | Net points per charged fight | +74 | +63 |
| Combat | Net points per supported fight / lone fight | +393 / -85 | - / +63 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 3 | 1 of 3 |
| Game | Points lost | 461.3 | 476.3 |
| Game | VP from objectives | 730.0 | 1016.7 |
| Game | Lone holders (player turns) | 3.5 | 2.0 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -152 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 938
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p50

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | - | - | - | - | 1.0 | +0.0 | 0.0 | 41.7 |
| ARMY TABLE | 14.0 | +223.3 | 0.0 | 176.0 | 26.3 | +383.3 | 0.0 | 321.3 |
| ARTILLERY RE-ROLL WEIGHED | 2.7 | +0.0 | 0.0 | 160.0 | - | - | - | - |
| ASSAILMENT BY POINTS | - | - | - | - | 0.7 | +0.2 | 0.0 | 52.0 |
| BLOWS WHERE AIMED | 0.7 | -5.6 | 131.0 | 17.3 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 18.3 | 36.7 | - | - | - | - |
| CANNON PLANNED TARGET | 4.7 | +113.7 | 195.7 | 320.0 | - | - | - | - |
| CANNON SIGHT KEPT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 2.7 | +9.3 | 0.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 2.0 | +294.4 | 0.0 | 0.0 | 0.7 | +11.4 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 91.3 |
| CHAFF IN THE MOVE | 0.7 | +16.3 | 0.0 | 0.0 | 0.7 | +0.4 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 0.7 | -0.9 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | 0.3 | -23.1 | 131.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 14.0 | -252.8 | 0.0 | 17.3 | 9.0 | -557.4 | 0.0 | 269.3 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 298.7 | 45.7 | 0.3 | +0.0 | 36.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 12.0 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 2.0 | +293.0 | 0.0 | 0.0 | 0.7 | +105.7 | 0.0 | 91.3 |
| COVER ONCE | 2.7 | -75.5 | 0.0 | 0.0 | 6.3 | -227.3 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | 0.3 | -8.3 | 0.0 | 28.3 | 0.3 | -0.3 | 28.3 | 0.0 |
| DEPLOY BY FIGURES | 9.7 | +22.3 | 0.0 | 28.3 | 8.3 | +76.7 | 0.0 | 41.7 |
| ENGINEER BY LORE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 1.3 | +9.8 | 131.0 | 74.0 | 1.3 | +12.9 | 65.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.7 | +16.4 | 131.0 | 104.3 | 1.0 | +0.0 | 65.0 | 0.0 |
| FALLBACK BY WORTH | 0.3 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | 23.7 | +286.4 | 0.0 | 93.7 | 3.0 | +61.8 | 0.0 | 0.0 |
| FEATURE BUFFS | 11.0 | +470.8 | 0.0 | 110.0 | 1.3 | +52.9 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +4.1 | 131.0 | 0.0 | - | - | - | - |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 36.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 94.3 | +7478.1 | 925.0 | 1097.0 | 100.7 | +6486.2 | 397.7 | 403.3 |
| FLANK NOT WEIGHED | 5.7 | +0.0 | 0.0 | 28.3 | 2.3 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.7 | +96.3 | 0.0 | 28.3 | - | - | - | - |
| FOUR ROUNDS | 2.0 | +448.4 | 262.0 | 104.3 | 1.3 | +46.7 | 65.0 | 0.0 |
| FREED FROM HIS FIGHT | 0.3 | +0.0 | 0.0 | 17.3 | 3.7 | +0.0 | 0.0 | 0.0 |
| FRIEND CHARGES FIRST | 0.3 | -19.7 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.3 | -58.8 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | - | - | - | - | 0.3 | -2.3 | 28.3 | 0.0 |
| GOAL WALK | 8.0 | +837.3 | 0.0 | 28.3 | 13.0 | +1036.5 | 0.0 | 0.0 |
| GUN FIGURES | 0.7 | +7.9 | 108.7 | 0.0 | 1.7 | +38.5 | 28.3 | 0.0 |
| HARD STAY DROPPED | 4.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 0.3 | +0.0 | 0.0 | 17.3 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 8.3 | +0.0 | 0.0 | 17.3 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.7 | +15.6 | 28.3 | 0.0 |
| HIS CHARGE LIST | 1.7 | +0.0 | 0.0 | 56.7 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 1.0 | +0.0 | 0.0 | 56.7 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 6.7 | -117.1 | 0.0 | 113.3 | 1.3 | -32.9 | 0.0 | 0.0 |
| HIS ONE QUARTER | 5.3 | +0.0 | 0.0 | 27.0 | 5.0 | +0.0 | 0.0 | 217.3 |
| HIS OWN BEST MOVE | 2.3 | +0.0 | 0.0 | 85.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 28.7 | +0.0 | 0.0 | 22.7 |
| HIS RANDOM MOVER COMES | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 63.3 | +2260.7 | 0.0 | 342.7 | 66.0 | +3359.1 | 0.0 | 403.3 |
| HIS SHOTS BY HIS RUN | 52.0 | +929.6 | 0.0 | 352.7 | 40.3 | +1224.8 | 0.0 | 351.3 |
| HIS TURN DENIED | 0.3 | +12.0 | 0.0 | 28.3 | 0.3 | +10.8 | 36.7 | 0.0 |
| HOLD ODDS | 31.7 | +0.0 | 0.0 | 227.0 | 23.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 13.7 | +1456.9 | 0.0 | 37.0 | 14.0 | +1434.1 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.7 | -18.3 | 131.0 | 104.3 | 1.0 | -51.9 | 36.7 | 0.0 |
| IDLE COST | 17.3 | -97.2 | 0.0 | 27.3 | 3.7 | -40.8 | 0.0 | 18.3 |
| JOINT CHARGE NOW | 0.7 | -106.2 | 262.0 | 0.0 | - | - | - | - |
| KEEP FALLS | 0.7 | +12.5 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 3.0 | +0.0 | 0.0 | 27.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +17.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 0.7 | +0.0 | 131.0 | 206.7 | 2.3 | +0.0 | 235.0 | 239.7 |
| LONE WIZARD KEPT IN | 1.3 | +116.7 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 1.0 | +5.1 | 262.0 | 28.3 | 0.7 | -0.0 | 65.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.7 | +8.1 | 0.0 | 0.0 |
| MANOEUVRE | 0.7 | +0.0 | 0.0 | 0.0 | 3.3 | -1.1 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +32.1 | 0.0 | 0.0 | 0.7 | +21.9 | 0.0 | 52.0 |
| MARCH CHECK | 1.3 | +67.8 | 0.0 | 27.0 | 1.0 | +45.9 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | -4.4 | 0.0 | 0.0 | 0.7 | +44.5 | 0.0 | 160.7 |
| MARCH WHEELS ONLY | 1.7 | +0.0 | 0.0 | 27.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.3 | +29.9 | 0.0 | 28.3 | 1.7 | +21.5 | 0.0 | 0.0 |
| MEETS IN TIME | 3.3 | +262.7 | 0.0 | 0.0 | 3.0 | +302.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 7.7 | +410.7 | 0.0 | 54.0 | 3.7 | +69.4 | 0.0 | 52.0 |
| MISSILES NEXT TURN | 8.7 | +289.1 | 0.0 | 54.0 | 4.0 | +56.5 | 0.0 | 160.7 |
| MISSILES ON ONE TARGET | 1.0 | -110.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 0.7 | -12.1 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 4.3 | +462.0 | 0.0 | 85.0 | 3.0 | +122.8 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.7 | +36.7 | 0.0 | 0.0 | 0.3 | +1.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 3.3 | +179.5 | 0.0 | 0.0 | 11.7 | +563.9 | 0.0 | 0.0 |
| NEAREST TO GOAL | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 2.3 | +266.5 | 36.7 | 28.3 | 1.3 | +51.8 | 34.7 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -7.0 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.0 | -126.6 | 262.0 | 104.3 | 1.3 | -10.1 | 65.0 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.3 | +4.5 | 0.0 | 46.7 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 2.7 | -73.5 | 0.0 | 196.7 | 1.3 | -13.5 | 0.0 | 0.0 |
| OGRE LOADER SECOND SHOT | 0.7 | +0.4 | 0.0 | 76.7 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.3 | -38.1 | 0.0 | 28.3 | 3.3 | -50.5 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 6.7 | +80.2 | 0.0 | 10.0 | 6.0 | -140.5 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.3 | -13.7 | 0.0 | 0.0 | 0.7 | -9.0 | 0.0 | 0.0 |
| ONE ROUTE | 1.7 | +0.0 | 0.0 | 27.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 0.3 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.7 | +37.2 | 36.7 | 0.0 |
| OVERRUNS AWAY | 0.7 | +9.5 | 0.0 | 56.7 | - | - | - | - |
| PATHS CROSS | 0.3 | +1.4 | 0.0 | 0.0 | 0.3 | +2.9 | 0.0 | 0.0 |
| PLAN RESULT | 43.0 | +485.0 | 110.0 | 676.0 | 44.0 | +204.6 | 74.0 | 220.0 |
| PROMISE BELOW ZERO | 0.7 | +0.0 | 0.0 | 17.3 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 5.3 | -112.5 | 0.0 | 56.7 | 4.7 | -113.3 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| QUARTER ODDS | 17.0 | +1510.4 | 778.3 | 399.0 | 17.0 | +2116.7 | 144.7 | 321.3 |
| RANDOM MOVE BY FIGURES | 4.0 | +47.0 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | 1.7 | +0.0 | 0.0 | 27.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.7 | +23.1 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 1.3 | +42.5 | 0.0 | 95.0 | 1.7 | -46.5 | 0.0 | 11.3 |
| REDIRECT FOR A FRIEND IN REACH | 2.7 | +30.1 | 0.0 | 95.0 | 2.3 | +0.0 | 0.0 | 22.7 |
| REDIRECT WEIGHED | 0.3 | +0.0 | 0.0 | 30.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 2.0 | -63.2 | 0.0 | 28.3 | 1.0 | -8.6 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESTRAINS TO SHOOT | 0.3 | +7.9 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.0 | +34.9 | 131.0 | 58.7 | 0.7 | -4.9 | 65.0 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.3 | -2.9 | 36.7 | 0.0 |
| RUN DOWN | 2.0 | -72.8 | 262.0 | 104.3 | 0.7 | -0.6 | 65.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 0.7 | -0.1 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | - | - | - | - | 0.3 | +0.8 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +43.7 | 36.7 | 0.0 |
| SELF MOVE SPELL | - | - | - | - | 0.3 | -0.3 | 0.0 | 108.7 |
| SET CREDITED ONCE | 1.3 | -37.7 | 0.0 | 37.3 | 0.3 | -6.2 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.7 | +72.7 | 0.0 | 37.3 | 0.3 | +6.2 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.7 | +8.1 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.3 | +12.0 | 0.0 | 91.3 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 8.3 | +0.0 | 0.0 | 320.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 3.0 | +93.9 | 271.7 | 0.0 | 0.7 | +23.5 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.7 | -39.7 | 131.0 | 17.3 | - | - | - | - |
| SHOT REPLANNED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 54.3 | +524.1 | 0.0 | 324.3 | 49.7 | +603.0 | 0.0 | 403.3 |
| SHOTS AFTER THE MOVES | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 6.7 | +177.0 | 0.0 | 320.0 | 20.3 | +427.3 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | -22.9 | 0.0 | 17.3 | - | - | - | - |
| SPOT AS THE GAME MOVES | 8.3 | +0.0 | 0.0 | 119.7 | 5.7 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | 0.3 | -8.6 | 0.0 | 17.3 | - | - | - | - |
| STANDS FOR A REASON | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 44.0 | +0.0 | 663.0 | 694.7 | 47.3 | +0.0 | 332.7 | 45.3 |
| STAY WORTH | 17.3 | -7.4 | 146.7 | 710.0 | 21.3 | +161.4 | 276.0 | 0.0 |
| STRIKE BY THE ODDS | 0.3 | +6.0 | 131.0 | 0.0 | - | - | - | - |
| STUCK PIVOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 1.3 | +47.8 | 0.0 | 17.3 | 3.7 | +223.9 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 1.3 | +47.8 | 0.0 | 17.3 | 3.7 | +223.9 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +2.7 | 0.0 | 11.3 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.7 | +1.5 | 0.0 | 18.3 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 4.3 | +0.0 | 0.0 | 28.3 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 3.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 18.3 |
| THE STEP BACK IS MADE | 1.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 18.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 42.7 | +0.0 | 0.0 | 496.3 | 47.7 | +0.0 | 0.0 | 201.7 |
| TIED UP BY THE SUM | - | - | - | - | 0.7 | +73.5 | 36.7 | 0.0 |
| TIME ON OUR SIDE | 7.7 | +131.7 | 0.0 | 0.0 | 64.0 | +505.8 | 0.0 | 68.0 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | - | - | - | - | 0.7 | +0.0 | 56.7 | 0.0 |
| WHO FIGHTS | 1.0 | +8.9 | 131.0 | 47.7 | 0.3 | +0.3 | 28.3 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +9.4 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 0.3 | -17.1 | 0.0 | 0.0 | 1.3 | -378.7 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | 0.3 | +26.0 | 131.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 6.0 | +300.8 | 0.0 | 0.0 | 2.3 | +182.4 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p50

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 388 | 384 | 118 | 39.33 | +1416 | +12.0 |
| SHOT RISK POINTS | 312 | 310 | 105 | 35.00 | +2989 | +28.5 |
| HIS SHOTS BY HIS RUN | 277 | 276 | 99 | 33.00 | +1586 | +16.0 |
| HOLDER ASSIGNMENT | 83 | 83 | 77 | 25.67 | +5167 | +67.1 |
| ARMY TABLE | 121 | 121 | 73 | 24.33 | +1354 | +18.5 |
| DEPLOY BY FIGURES | 54 | 54 | 36 | 12.00 | +491 | +13.6 |
| TIME ON OUR SIDE | 215 | 195 | 32 | 10.67 | +134 | +4.2 |
| FIVE ACTION | 585 | 578 | 29 | 9.67 | +1572 | +54.2 |
| HARD STAY DROPPED | 29 | 29 | 29 | 9.67 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 24 | 8.00 | +0 | +0.0 |
| QUARTER ODDS | 102 | 102 | 21 | 7.00 | +2068 | +98.5 |
| GOAL WALK | 63 | 60 | 16 | 5.33 | +908 | +56.7 |
| MEETS IN TIME | 19 | 19 | 13 | 4.33 | +889 | +68.4 |
| MOVE TO CHARGE COMPUTED | 22 | 18 | 13 | 4.33 | +531 | +40.9 |
| REDIRECT FOR A FRIEND IN REACH | 15 | 15 | 13 | 4.33 | +0 | +0.0 |
| OFF BEST | 12 | 12 | 12 | 4.00 | -260 | -21.7 |
| PROMISE BY ITS OWN SUM | 30 | 30 | 11 | 3.67 | -678 | -61.6 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 11 | 3.67 | +141 | +12.8 |
| MISSILES IN THE MOVE | 34 | 22 | 10 | 3.33 | +761 | +76.1 |
| MOVE ORDER | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| STAY WORTH | 116 | 101 | 10 | 3.33 | +162 | +16.2 |
| LEGAL CHARGES ONLY | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| CASTING BLOCK | 8 | 8 | 8 | 2.67 | +161 | +20.1 |
| SUPPORT ADDS | 15 | 15 | 7 | 2.33 | +147 | +21.1 |
| SUPPORT WORKED OUT | 15 | 15 | 7 | 2.33 | +147 | +21.1 |
| WOUNDS ON THE RANKS | 25 | 25 | 7 | 2.33 | +171 | +24.4 |
| CASTER AWAY FROM SCREEN | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| FEATURE BUFFS | 37 | 37 | 6 | 2.00 | +130 | +21.6 |
| FOUR ROUNDS | 10 | 10 | 6 | 2.00 | +282 | +47.0 |
| NEXT CHARGE BY LIST | 11 | 10 | 5 | 1.67 | +266 | +53.2 |
| CAST JOB | 8 | 8 | 4 | 1.33 | +8 | +2.0 |
| CHARGE LOSSES | 69 | 68 | 4 | 1.33 | +659 | +164.8 |
| FALLS SHORT | 80 | 60 | 4 | 1.33 | +155 | +38.7 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +350 | +87.5 |
| MARCH CHECK | 7 | 7 | 4 | 1.33 | +142 | +35.5 |
| SHOOTS FROM THE BEST SPOT | 11 | 11 | 4 | 1.33 | +46 | +11.6 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +162 | +53.9 |
| MAX FOR POSITIONING | 9 | 7 | 3 | 1.00 | +3 | +1.0 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 1.00 | +114 | +38.2 |
| ONE PROMISE A TARGET | 3 | 3 | 3 | 1.00 | -68 | -22.7 |
| REDIRECT WEIGHED | 3 | 3 | 3 | 1.00 | +38 | +12.8 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| ASSAILMENT BY POINTS | 2 | 2 | 2 | 0.67 | +1 | +0.3 |
| CANNON SIGHT KEPT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | -3 | -1.3 |
| COVER ONCE | 27 | 19 | 2 | 0.67 | +16 | +8.1 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +289 | +144.4 |
| HIS CHARGE DENIED | 2 | 2 | 2 | 0.67 | +28 | +14.1 |
| IDLE COST | 63 | 50 | 2 | 0.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | -319 | -159.3 |
| KEEP FALLS | 2 | 2 | 2 | 0.67 | +49 | +24.5 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +53 | +26.6 |
| MANOEUVRE | 12 | 12 | 2 | 0.67 | +28 | +14.1 |
| OGRE LOADER SECOND SHOT | 2 | 2 | 2 | 0.67 | +1 | +0.5 |
| OPENS UP | 2 | 2 | 2 | 0.67 | +61 | +30.6 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +13 | +6.4 |
| RISK BY ARC | 5 | 5 | 2 | 0.67 | +32 | +16.1 |
| SHOTS AFTER THE MOVES | 12 | 12 | 2 | 0.67 | +0 | +0.0 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 2 | 2 | 2 | 0.67 | +5 | +2.3 |
| TIED UP BY THE SUM | 2 | 2 | 2 | 0.67 | +44 | +22.0 |
| CANNON PLANNED TARGET | 14 | 14 | 1 | 0.33 | +0 | +0.2 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 8 | 8 | 1 | 0.33 | +3 | +2.9 |
| FALLBACK BY WORTH | 1 | 1 | 1 | 0.33 | +4 | +3.9 |
| FIGHT TO THE END | 1 | 1 | 1 | 0.33 | +4 | +4.5 |
| HIS MOVE AND SHOT | 24 | 23 | 1 | 0.33 | +0 | +0.0 |
| LOST AFTER ESCAPE | 5 | 5 | 1 | 0.33 | +4 | +4.5 |
| MISSILES NEXT TURN | 38 | 26 | 1 | 0.33 | +1 | +0.6 |
| NEARER NOT NEEDED | 45 | 41 | 1 | 0.33 | +22 | +22.3 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.33 | +2 | +1.6 |
| ONE OBJECTIVE FORMULA | 38 | 25 | 1 | 0.33 | +15 | +15.3 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -21 | -21.2 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +24 | +23.6 |
| SEARCH SPOT | 1 | 1 | 1 | 0.33 | +2 | +2.3 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +131 | +131.0 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SHOT REPLANNED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 81 | 62 | 1 | 0.33 | +3 | +2.9 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +28 | +28.2 |
| WHOLE FIGHT GAIN | 1 | 1 | 1 | 0.33 | +4 | +4.5 |
| BLOWS WHERE AIMED | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 8 | trace | - | - | - | - |
| CHAFF IN THE MOVE | 4 | 4 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 7 | 7 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 55 | 55 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 8 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 8 | 8 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 24 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 12 | 10 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 7 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 8 | 6 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 32 | 31 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 20 | 19 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 9 | 8 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 31 | 31 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 13 | 11 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 86 | 84 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 2 | 2 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HOLD ODDS | 165 | 165 | 0 | 0.00 | - | - |
| HONEST WORTH | 8 | 8 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 20 | 20 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 10 | 10 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 3 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 2 | trace | - | - | - | - |
| MOVE SPELL SPOT | 6 | not checked | - | - | - | - |
| NEAREST TO GOAL | 6 | 6 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 10 | 10 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 20 | 9 | 0 | 0.00 | - | - |
| ONE ROUTE | 10 | 10 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | not checked | - | - | - | - |
| OVERRUNS AWAY | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 261 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 4 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 10 | 10 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 9 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 9 | 9 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 8 | 8 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 1 | not checked | - | - | - | - |
| SET CREDITED ONCE | 5 | 5 | 0 | 0.00 | - | - |
| SET UP BY THE SET | 6 | 6 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 2 | 0 | 0.00 | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 38 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 42 | 39 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 7 | 7 | 0 | 0.00 | - | - |
| STANDS STILL | 274 | 274 | 0 | 0.00 | - | - |
| STRIKE BY THE ODDS | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 22 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 21 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 14 | not checked | - | - | - | - |
| THE TABLE BINDS | 271 | not checked | - | - | - | - |
| WAITS AGAIN | 7 | 7 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 4 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 5 | 5 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p50

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| ARMY TABLE | rule | 0.33 | 3.33 | 41.4 |
| JOB FIRST | gate | 2.33 | 1.33 | 19.0 |
| PROMISE BY ITS OWN SUM | rule | 1.67 | 2.00 | 61.6 |
| HOLDER ASSIGNMENT | rule | 0.67 | 2.33 | 32.2 |
| ONE PROMISE A TARGET | rule | 0.33 | 0.67 | 22.7 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.33 | - | 50.8 |
| CHAFF PASSED | rule | - | 0.33 | 2.5 |
| JOINT CHARGE NOW | rule | 0.33 | - | 323.0 |
| REFUSING RETIRES | rule | 0.33 | - | 21.2 |

### Plans: gs3-83c8646-p50

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.7 | 60% | 459 | 238 | 52% |
| Mine | move | 34.0 | 96% | 2122 | 0 | 0% |
| Mine | shoot | 7.3 | 55% | 516 | 247 | 48% |
| Opponent | charge | 1.0 | 67% | 94 | 52 | 56% |
| Opponent | move | 40.3 | 94% | 2280 | 0 | 0% |
| Opponent | shoot | 2.7 | 88% | 274 | 152 | 55% |

### Battle groups: gs3-83c8646-p50

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.3 | 25% | 0% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 1.7 | 20% | 100% | 100% | 100% | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p50

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | - | 0 (2) | - | 0 (2) | - |
| Mine | Character | 11 | 9 (11) | 9 | 0 | 0 | 55% | 1.6 | - | 4 (6) | 15 (5) | 9 (11) | - |
| Mine | Clean-up | 2 | 194 (2) | 0 | 194 | 49 | 50% | 5.0 | 316 (1) | - | 66 (1) | 194 (2) | - |
| Mine | Fast Hammer | 10 | 0 (10) | 0 | 0 | 60 | 80% | 5.0 | 0 (6) | 0 (1) | 0 (3) | 0 (7) | 0 (3) |
| Mine | Hammer | 9 | 95 (9) | 63 | 32 | 20 | 44% | 3.6 | 150 (2) | 78 (4) | 76 (3) | 95 (9) | - |
| Mine | Holder | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | - | 0 (1) | - | 0 (2) |
| Mine | War machine | 4 | 9 (4) | 9 | 0 | 81 | 0% | 1.2 | 9 (4) | - | - | - | 9 (4) |
| Mine | Wizard | 4 | 41 (4) | 41 | 0 | 0 | 25% | 4.0 | 92 (2) | 0 (1) | 0 (1) | 0 (2) | 92 (2) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 8 | 8 (8) | 0 | 8 | 36 | 88% | 5.0 | 16 (3) | 0 (4) | 0 (1) | 8 (7) | 0 (1) |
| Opponent | Character | 7 | 30 (7) | 30 | 0 | 28 | 0% | 2.3 | 66 (1) | 49 (3) | 0 (1) | 37 (3) | 35 (2) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 0 | 67% | 2.0 | - | 0 (3) | - | 0 (3) | - |
| Opponent | Fast Hammer | 1 | 0 (1) | 0 | 0 | 115 | 0% | 2.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Hammer | 10 | 72 (10) | 8 | 63 | 6 | 60% | 1.5 | 9 (5) | 148 (4) | 0 (1) | 10 (5) | 117 (5) |
| Opponent | Shooter | 4 | 161 (4) | 58 | 103 | 0 | 0% | 2.0 | 74 (1) | 181 (2) | 193 (1) | 120 (3) | 311 (1) |
| Opponent | Wizard | 2 | 29 (2) | 29 | 0 | 126 | 0% | 2.0 | - | 29 (2) | - | 29 (2) | - |

### Charged fights: gs3-83c8646-p50

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 80 | 0 | 1.0 | 1.0 | 0 | 85 | -85 | 1 of 2 | 1 of 2 | - | -85 |
| Mine | Chaos Dwarfs | 1 | 537 | 393 | 1.0 | 2.0 | 393 | 0 | +393 | 1 of 1 | 1 of 1 | +393 | - |
| **Mine** | all armies | 3 | 232 | 131 | 1.0 | 1.3 | 131 | 57 | +74 | 2 of 3 | 2 of 3 | +393 | -85 |
| Opponent | Ogre Kingdoms | 1 | 170 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Orc & Goblin Tribes | 1 | 110 | 450 | 3.0 | 1.0 | 150 | 87 | +63 | 1 of 3 | 2 of 2 | - | +63 |
| Opponent | Wood Elf Realms | 1 | 163 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 148 | 150 | 1.0 | 1.0 | 150 | 87 | +63 | 1 of 3 | 2 of 2 | - | +63 |

### Effective charges: gs3-83c8646-p50

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net -85) | 0 | 0% (0 of 2) |
| Mine | Chaos Dwarfs | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +393) | 0 | 0% (0 of 1) |

### Charged fights, damage counted: gs3-83c8646-p50

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 192 | 205 | +74 | 206 | 75 | +131 | +68.3 |
| Mine | All fights | 3 | 192 | 205 | +74 | 206 | 75 | +131 | +68.3 |
| Opponent | No odds | 3 | 348 | 187 | +63 | 150 | 87 | +63 | +18.1 |
| Opponent | All fights | 3 | 348 | 187 | +63 | 150 | 87 | +63 | +18.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p50 | move | 16 | 3 (19%) | 1 (6%) | 1 (6%) | 12 (75%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Elixir of Power | Opponent | L0319 |
| Fistful of Laurels | Opponent | L0218 |
| Ring of Doom | Mine | L0218, L0235 |

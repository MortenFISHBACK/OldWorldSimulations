# Doctrine scorecard: gs3-83c8646-p42

### Scorecard: gs3-83c8646-p42

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0926 | 2 | 1 | Mine | - | - | 3 | 1 | 2 | 0 | 0 | 0 | 45 |
| L0926 | 2 | 1 | Opponent | - | - | 4 | 1 | 4 | 0 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | yes | 9 | 2 | 5 | 0 | 0 | 0 | 0 | 330 |
| L1017 | 3 | 1 | Opponent | yes | 6 | 4 | 5 | 1 | 0 | 0 | 0 | 258 |
| L1034 | 2 | 1 | Mine | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 456 |
| L1034 | 2 | 1 | Opponent | - | - | 5 | 3 | 4 | 0 | 0 | 0 | 107 |
| **Average** | | | Mine | 100% | 9.0 | 2.3 | 2.3 | 1.0 | 0.0 | 0.0 | 0.0 | 277.0 |
| **Average** | | | Opponent | 100% | 6.0 | 4.3 | 3.0 | 3.0 | 0.0 | 0.0 | 0.0 | 121.7 |

### KPIs: gs3-83c8646-p42

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 40% (6 of 15) | 0% (0 of 16) | 19% (6 of 31) |
| Winner chose to follow up after the loser gave ground |  | 100% (3 of 3); on the table 100% | 80% (4 of 5); on the table 80% | 88% (7 of 8); on the table 88% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | 0% (0 of 1); on the table 0% | 50% (1 of 2); on the table 50% |
| Winner chose to pursue after the loser fled |  | 33% (1 of 3); on the table 67% | 75% (3 of 4); on the table 75% | 57% (4 of 7); on the table 71% |
| Winner chose to follow up or pursue (all three) |  | 71% (5 of 7); on the table 86% | 70% (7 of 10); on the table 70% | 71% (12 of 17); on the table 76% |
| Magic missiles tried each own turn | 50%+ | 38% (23 of 60) | 0% (0 of 6) | 35% (23 of 66) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 49% (23 of 47) | 0% (0 of 6) | 43% (23 of 53) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 52% (3106 of 5997) | 41% (2483 of 5998) | 47% (5589 of 11995) |
|   infantry points that never fought | lower | 100% (1052 of 1052) | 33% (453 of 1363) | 62% (1505 of 2415) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (18 of 32) | 65% (13 of 20) | 60% (31 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 4.3 uses a game | 0.0 uses a game | 100% (4 of 4); 2.2 uses a game |
| Bound items with another spell used |  | 50% (1 of 2); 1.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (2 of 2); 0.7 uses a game | 0% (0 of 1); 0.0 uses a game | 67% (2 of 3); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 51% (3001 of 5832) | 58% (2959 of 5116) | 54% (5960 of 10948) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 4.0 (32%) | 1.7 (83%) | 5.7 (40%) |
| MARCHED: its unit marched | 3.7 (30%) | 0.3 (17%) | 4.0 (28%) |
| CHARGED: its unit charged | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| IN COMBAT: engaged in combat | 3.0 (24%) | 0.0 (0%) | 3.0 (21%) |
| FLEEING: fleeing | 0.7 (5%) | 0.0 (0%) | 0.7 (5%) |
| OFF THE TABLE: off the table or not arrived | 0.7 (5%) | 0.0 (0%) | 0.7 (5%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 3.7 | 2.0 | 7.7 | 1.7 | 2.0 |
| not cast | 0.0 | 2.3 | 2.0 | 14.3 | 4.3 | 22.0 |
| NOT CHOSEN: could have been cast at a target | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | - | 2.3 (100%) | 0.0 (0%) | 5.7 (40%) | 1.7 (38%) | 0.0 (0%) |
| MARCHED: its unit marched | - | 0.0 (0%) | 0.0 (0%) | 4.0 (28%) | 1.0 (23%) | 0.0 (0%) |
| CHARGED: its unit charged | - | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | - | 0.0 (0%) | 0.7 (33%) | 3.0 (21%) | 0.7 (15%) | 0.0 (0%) |
| FLEEING: fleeing | - | 0.0 (0%) | 0.0 (0%) | 0.7 (5%) | 0.0 (0%) | 0.0 (0%) |
| OFF THE TABLE: off the table or not arrived | - | 0.0 (0%) | 0.0 (0%) | 0.7 (5%) | 0.3 (8%) | 1.0 (5%) |
| OTHER BAR: another bar (miscast, baggage ...) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (15%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | - | 0.0 (0%) | 1.3 (67%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 19.7 (89%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.0 a game | 0.0 a game | 1.0 a game |
| stood (cast and not dispelled) | 67% (4 of 6) | - | 67% (4 of 6) |
| the unit moved after it | 25% (1 of 4) | - | 25% (1 of 4) |
| it charged on its next turn | 0% (0 of 4) | - | 0% (0 of 4) |
| the enemy charged it first | 25% (1 of 4) | - | 25% (1 of 4) |
| it fought by the end of its next turn | 25% (1 of 4) | - | 25% (1 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 4) | - | 0% (0 of 4) |
| none of these (no charge, no fight, no charge escaped) | 75% (3 of 4) | - | 75% (3 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 62% (56 of 90) | 79% (45 of 57) | 69% (101 of 147) |
|   cavalry | - | 86% (6 of 7) | 86% (6 of 7) |
|   character | 100% (6 of 6) | 73% (8 of 11) | 82% (14 of 17) |
|   chariot | 62% (8 of 13) | - | 62% (8 of 13) |
|   infantry | 50% (12 of 24) | 88% (28 of 32) | 71% (40 of 56) |
|   monster | 20% (1 of 5) | 43% (3 of 7) | 33% (4 of 12) |
|   war machine | 69% (29 of 42) | - | 69% (29 of 42) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (24%) | 0.7 (17%) | 3.3 (22%) |
| CHARGED: it charged | 0.0 (0%) | 0.7 (17%) | 0.7 (4%) |
| IN COMBAT: it fought this turn or the last | 1.0 (9%) | 0.3 (8%) | 1.3 (9%) |
| MOVED: a war machine that moved | 2.0 (18%) | 0.0 (0%) | 2.0 (13%) |
| NO TARGET IN RANGE | 2.0 (18%) | 0.7 (17%) | 2.7 (17%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 0.3 (8%) | 0.7 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.3 (21%) | 1.3 (33%) | 3.7 (24%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR | 0.7 (6%) | 0.0 (0%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.0 | 0.3 | 92% | 1.6 pts | 6 pts |
| character | 4.7 | 0.7 | 86% | 2.5 pts | 12 pts |
| chariot | 2.7 | 1.3 | 62% | 13.1 pts | 35 pts |
| infantry | 20.3 | 6.7 | 75% | 9.9 pts | 201 pts |
| monster | 1.7 | 1.0 | 60% | 15.3 pts | 25 pts |
| war machine | 9.7 | 8.0 | 66% | 19.4 pts | 187 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 3.3 | 3.5 |
| Charges that made contact a game | 2.7 | 2.7 | 2.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.83 contact (6 units) | 0.00 declared, 0.00 contact (1 units) | 0.86 declared, 0.71 contact (7 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.67 declared, 0.67 contact (3 units) | 0.67 declared, 0.67 contact (3 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.31 declared, 0.19 contact (16 units) | 0.29 declared, 0.21 contact (28 units) | 0.30 declared, 0.20 contact (44 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 17% (1 of 6) | - | - | 17% (1 of 6) |
| Character in a unit | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Character on its own | 100% (3 of 3) | 75% (3 of 4) | 38% (3 of 8) | 60% (9 of 15) |
| Chariot | 100% (2 of 2) | 0% (0 of 1) | - | 67% (2 of 3) |
| Infantry | 33% (3 of 9) | 100% (1 of 1) | 0% (0 of 1) | 36% (4 of 11) |
| Monster | 100% (4 of 4) | - | - | 100% (4 of 4) |
| Monstrous | 100% (2 of 2) | 100% (2 of 2) | - | 100% (4 of 4) |
| War Machines | 71% (5 of 7) | - | - | 71% (5 of 7) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 1 | 100% (2 of 2); on the table 100% | 67% (8 of 12) | 75% | 75% (9 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 2 | 60% (3 of 5); on the table 80% | 31% (15 of 48) | 40% | 45% (9 of 20) | 100% (4 of 4); 6.5 uses a game | 50% (1 of 2); 1.5 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | 50% (2 of 4); on the table 50% | - | 16% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (3 of 3); on the table 100% | 0% (0 of 6) | 52% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 67% (2 of 3); on the table 67% | - | 56% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p42, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 57% (4) | 33% (1) | 50% (5) |
| ...free all their last turn and able to turn (per game) | 1.33 | 0.33 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.33 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p42

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 55% (6 of 11) | 22% (2 of 9) |
| Strategy | Shoot objectives carried out (shot that target) | 24% (12 of 49) | 23% (5 of 22) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 67% (4 of 6) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 4) | - |
| Strategy | Lone characters that fought | 67% (6 of 9) | 71% (5 of 7) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 1.0 | 3.0 |
| Movement | Points that never moved of their own | 277.0 | 121.7 |
| Movement | Fights charged into per game | 2.3 | 2.7 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 7, net +0 | 0 of 6 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 7, net +0 | 3 of 6, net +111 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 7, net +105 | 0 of 6 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 7, net +160 | 3 of 6, net +336 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.7 | 17.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 66% (19 of 29) | 50% (26 of 52) |
| Shooting | Points destroyed by shooting units | 0.0 | 142.7 |
| Shooting | War machine shots | 9.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (13 of 29) | - |
| Shooting | Points destroyed by war machines | 139.7 | 0.0 |
| Magic | Magic missiles cast | 4.3 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 31% (4 of 13) | - |
| Magic | Wounds caused by magic missiles | 17.7 | - |
| Magic | Wounds caused by other spells | 2.0 | - |
| Magic | Points destroyed by magic (all spells) | 189.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 2.0 / 0.7 / 0.3 | 3.0 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 73.3 | 131.3 |
| Combat | Points run down | 53.3 | 123.0 |
| Combat | Net points per charged fight, damage counted | +56 | +200 |
| Combat | Net per 100 charger points, damage counted | +19.3 | +63.0 |
| Combat | First round won (charged fights) | 71% | 88% |
| Combat | Net points per charged fight | +66 | +217 |
| Combat | Net points per supported fight / lone fight | +160 / +50 | - / +217 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 7 | 4 of 8 |
| Game | Points lost | 688.7 | 483.3 |
| Game | VP from objectives | 596.7 | 813.3 |
| Game | Lone holders (player turns) | 9.0 | 6.0 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -434 VP
- The side that went first won 0 of 3 games with a winner
- Points traded per game (both sides' losses): 1172
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: gs3-83c8646-p42

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH IN POINTS | - | - | - | - | 0.3 | +4.1 | 0.0 | 45.0 |
| AFTERMATH WITH FRIENDS | 0.3 | +10.6 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 20.0 | +302.3 | 0.0 | 174.0 | 19.7 | +454.8 | 0.0 | 328.3 |
| ARTILLERY RE-ROLL WEIGHED | 3.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ASSAILMENT BY POINTS | 0.7 | +3.5 | 0.0 | 267.7 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| BOUND ASSAILMENT | 0.3 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 9.7 | +413.1 | 234.3 | 110.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 7.7 | +163.3 | 205.0 | 144.7 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.3 | +0.0 | 0.0 | 123.0 | - | - | - | - |
| CATCH FLIERS | 0.3 | +3.5 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 2.3 | +48.0 | 0.0 | 27.0 |
| CHALLENGE BY POINTS | 0.7 | +4.5 | 0.0 | 131.3 | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 0.3 | -5.5 | 0.0 | 0.0 | 0.7 | -19.3 | 55.7 | 0.0 |
| CHARACTER GUNS | 5.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 11.7 | -689.2 | 0.0 | 426.7 | 31.0 | -1367.6 | 0.0 | 481.3 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 123.0 | 0.0 |
| CHARGE NOW FIRST | 4.3 | +0.0 | 290.7 | 144.7 | 2.0 | +0.0 | 124.0 | 0.0 |
| CHARGER SLAIN LOST | - | - | - | - | 0.3 | -8.6 | 55.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.0 | +0.0 | 0.0 | 0.0 | 9.7 | +0.0 | 0.0 | 30.0 |
| CONVEYANCE SEARCH | 2.0 | +148.4 | 123.0 | 123.0 | - | - | - | - |
| COVER ONCE | 10.7 | -317.2 | 0.0 | 45.0 | 12.3 | -776.5 | 0.0 | 222.7 |
| DENIED BY THE FIGHT | 1.7 | -34.0 | 106.7 | 68.3 | 0.3 | -1.8 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 7.7 | -56.5 | 0.0 | 0.0 | 9.0 | +31.7 | 0.0 | 94.0 |
| DUEL STOPS AT THE KILL | 0.7 | -4.1 | 27.7 | 68.3 | - | - | - | - |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +0.8 | 55.0 | 0.0 |
| EXACT ROUND | 2.0 | -5.7 | 227.0 | 0.0 | 2.0 | +41.4 | 303.3 | 0.0 |
| FALL BACK GOOD ORDER | 3.3 | +8.0 | 246.0 | 68.3 | 3.0 | +21.2 | 379.7 | 0.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 9.0 |
| FALLS SHORT | - | - | - | - | 26.3 | +221.4 | 0.0 | 251.3 |
| FEATURE BUFFS | 2.0 | +48.2 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | - | - | - | - | 1.7 | +8.4 | 131.3 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 42.0 | 0.0 |
| FIVE ACTION | 97.3 | +5972.1 | 1231.7 | 1731.7 | 87.3 | +3876.9 | 1122.7 | 947.7 |
| FLANK NOT WEIGHED | 8.3 | +0.0 | 0.0 | 409.0 | 7.7 | +0.0 | 0.0 | 111.0 |
| FOLLOW UP WEIGHED | 0.7 | +102.0 | 0.0 | 0.0 | 0.7 | +27.8 | 0.0 | 0.0 |
| FOOT FIRST | - | - | - | - | 23.3 | +0.0 | 0.0 | 295.7 |
| FOUR ROUNDS | 3.7 | +178.3 | 293.0 | 68.3 | 3.3 | +337.2 | 434.7 | 0.0 |
| FREED FROM HIS FIGHT | 4.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 72.7 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.7 | -83.8 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.3 | +7.6 | 0.0 | 0.0 | 0.3 | +25.2 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -4.5 | 0.0 | 68.3 | 0.3 | -6.7 | 57.0 | 0.0 |
| GOAL ROUTE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| GOAL WALK | 4.3 | +191.3 | 0.0 | 0.0 | 10.7 | +918.0 | 0.0 | 121.3 |
| GUN FIGURES | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| GUN MASK | 2.0 | +12.2 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 3.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 72.7 |
| HIS CHARGE BY HIS RUN | 10.7 | +0.0 | 0.0 | 426.7 | 22.3 | +0.0 | 0.0 | 481.3 |
| HIS CHARGE DENIED | - | - | - | - | 1.0 | +62.7 | 68.3 | 0.0 |
| HIS CHARGE LIST | 4.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 53.3 |
| HIS LEGAL MOVES | 6.3 | +0.0 | 0.0 | 144.7 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 1.3 | -15.3 | 0.0 | 114.0 | 11.7 | -141.2 | 0.0 | 224.3 |
| HIS ONE QUARTER | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 10.0 | +0.0 | 0.0 | 144.7 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 27.7 | +795.7 | 0.0 | 695.3 | 59.0 | +4720.6 | 0.0 | 661.3 |
| HIS SHOTS BY HIS RUN | 21.3 | +221.5 | 0.0 | 571.3 | 50.7 | +1750.3 | 0.0 | 547.3 |
| HIS TURN DENIED | 1.7 | +83.0 | 106.7 | 68.3 | 0.7 | +15.9 | 130.7 | 0.0 |
| HOLD ODDS | 18.7 | +0.0 | 0.0 | 0.0 | 10.3 | +0.0 | 0.0 | 151.7 |
| HOLDER ASSIGNMENT | 11.0 | +1200.2 | 0.0 | 0.0 | 8.3 | +596.0 | 0.0 | 151.7 |
| HONEST WORTH | 3.3 | -99.9 | 293.0 | 68.3 | 3.0 | -122.1 | 379.7 | 0.0 |
| IDLE COST | - | - | - | - | 21.7 | -405.3 | 0.0 | 226.7 |
| JOINT CHARGE NOW | 0.7 | +44.3 | 106.7 | 0.0 | 0.3 | -13.0 | 0.0 | 0.0 |
| KEEP FALLS | 0.3 | +8.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 45.0 |
| LANE BY FIGURES | 1.3 | +35.1 | 0.0 | 0.0 | 2.0 | +132.2 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.7 | +0.0 | 254.3 | 546.7 | 9.7 | +0.0 | 254.0 | 392.0 |
| LONE WIZARD KEPT IN | 0.7 | +22.6 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 2.3 | -0.8 | 250.3 | 68.3 | 3.3 | +11.5 | 434.7 | 0.0 |
| MANOEUVRE | 2.7 | -9.1 | 0.0 | 55.7 | 1.7 | -8.9 | 0.0 | 0.0 |
| MARCH BY THE SUM | 1.3 | +40.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 2.3 | +115.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 1.7 | +76.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 3.3 | +174.3 | 0.0 | 178.7 | - | - | - | - |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 8.0 | +177.4 | 0.0 | 323.3 | 1.7 | +12.5 | 0.0 | 0.0 |
| MEETS IN TIME | 3.7 | +90.7 | 0.0 | 0.0 | 1.3 | +48.3 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 12.0 | +261.9 | 0.0 | 323.3 | 0.3 | +1.5 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 15.7 | +246.7 | 0.0 | 379.0 | 1.7 | +4.1 | 0.0 | 0.0 |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 9.0 | 30.3 |
| MOVE SPELL SPOT | 1.3 | +0.0 | 0.0 | 123.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 5.0 | +499.5 | 0.0 | 0.0 | 2.7 | +376.6 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 9.3 | +487.2 | 0.0 | 75.7 | 6.3 | +274.7 | 0.0 | 35.7 |
| NEAREST TO GOAL | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 1.7 | +128.6 | 0.0 | 0.0 | 1.0 | +133.7 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -33.3 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 3.7 | -114.9 | 293.0 | 68.3 | 3.3 | -248.5 | 434.7 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 6.7 | -219.4 | 0.0 | 189.7 | 3.3 | -133.1 | 75.7 | 0.0 |
| OGRE LOADER SECOND SHOT | 4.0 | +12.5 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 7.0 | -144.6 | 0.0 | 323.3 | 4.7 | -98.0 | 0.0 | 89.7 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | -2.0 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 6.7 | +8.4 | 0.0 | 0.0 | 4.3 | -316.7 | 0.0 | 0.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 1.7 | +6.7 | 149.3 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.3 | +6.8 | 0.0 | 0.0 | 1.0 | +9.9 | 75.7 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +20.0 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -37.5 | 0.0 | 0.0 |
| PLAN RESULT | 43.0 | +694.3 | 636.3 | 1236.0 | 41.0 | +812.3 | 346.0 | 662.7 |
| PROMISE BY ITS OWN SUM | 9.0 | -337.9 | 0.0 | 144.7 | 5.7 | -360.4 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.7 | -4.9 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.3 | -41.9 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.3 | -2.6 | 36.3 | 0.0 | - | - | - | - |
| QUARTER ODDS | 8.0 | +684.6 | 180.0 | 1021.3 | 8.3 | +1547.6 | 541.7 | 90.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.3 | -33.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 1.0 | +113.5 | 0.0 | 27.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 3.0 | +0.3 | 0.0 | 33.0 |
| REFORMS TO MEET IT | 1.0 | -4.5 | 0.0 | 0.0 | 1.0 | -19.1 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RISK BY ARC | 2.7 | +101.4 | 171.3 | 68.3 | 2.7 | -164.9 | 256.7 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 2.3 | -96.3 | 324.0 | 0.0 |
| RUN DOWN | 2.3 | -9.4 | 181.3 | 68.3 | 3.3 | -35.4 | 434.7 | 0.0 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 4.0 | -347.1 | 0.0 | 18.0 |
| SEARCH SPOT | 1.3 | +7.6 | 0.0 | 0.0 | 1.0 | +86.2 | 0.0 | 62.3 |
| SECOND LOOK | - | - | - | - | 0.3 | +11.6 | 75.7 | 0.0 |
| SET CREDITED ONCE | 0.3 | -7.1 | 0.0 | 45.0 | 1.7 | -119.3 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.7 | -8.1 | 0.0 | 45.0 | 2.0 | +79.1 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 1.0 | +80.8 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.3 | +0.7 | 0.0 | 0.0 | 0.3 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 16.7 | +0.0 | 0.0 | 233.0 | 7.7 | +0.0 | 0.0 | 53.3 |
| SHOOTS FROM THE BEST SPOT | 3.3 | +93.5 | 206.7 | 246.0 | 3.3 | +127.0 | 111.3 | 116.7 |
| SHOT OR CHARGE | 1.0 | -31.0 | 124.3 | 0.0 | 0.3 | -0.7 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.3 | +0.0 | 58.3 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 11.7 | +50.0 | 0.0 | 465.7 | 42.3 | -303.3 | 0.0 | 489.7 |
| SHOTS AFTER THE MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 20.7 | +838.8 | 0.0 | 185.7 | 12.7 | +447.6 | 0.0 | 147.3 |
| SPELL SETS UP CHARGE | 1.0 | +80.8 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | - | - | - | - | 4.0 | +83.7 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.7 | +9.3 | 105.3 | 0.0 | 0.7 | +6.2 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 5.0 | +0.0 | 0.0 | 267.0 | 3.3 | +0.0 | 0.0 | 85.3 |
| STAND AND SHOOT | 1.0 | -13.5 | 58.3 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | - | - | - | - | 7.3 | +0.0 | 0.0 | 71.3 |
| STANDS STILL | 52.0 | +0.0 | 938.7 | 800.3 | 25.7 | +0.0 | 688.0 | 412.3 |
| STAY WORTH | 37.7 | +225.0 | 614.3 | 165.0 | 18.0 | +188.9 | 492.7 | 80.7 |
| STRIKE BY THE ODDS | 0.3 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| STUBBORN BY POINTS | 0.3 | +0.9 | 0.0 | 55.0 | 0.7 | +20.9 | 55.7 | 0.0 |
| SUPPORT ADDS | 4.0 | +146.0 | 0.0 | 90.0 | 2.7 | +34.3 | 0.0 | 0.0 |
| SUPPORT NARROWED | 2.0 | +0.0 | 115.0 | 0.0 | 0.7 | +0.0 | 55.7 | 0.0 |
| SUPPORT WORKED OUT | 4.0 | +146.0 | 0.0 | 90.0 | 2.7 | +34.3 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 1.0 | +9.0 | 0.0 | 0.0 | 0.7 | +2.8 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 62.3 |
| THE ROW IN ITS ORDER | 2.7 | +0.0 | 0.0 | 99.0 | 1.7 | +0.0 | 0.0 | 38.3 |
| THE ROW KEEPS ITS WAY | 0.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 41.7 | +0.0 | 0.0 | 831.7 | 42.3 | +0.0 | 0.0 | 347.0 |
| TIED UP BY THE SUM | 0.7 | +53.2 | 15.0 | 0.0 | 0.7 | +136.8 | 144.0 | 0.0 |
| TIME ON OUR SIDE | 42.7 | +596.4 | 42.7 | 873.0 | - | - | - | - |
| WAITS AGAIN | 3.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | 0.7 | +5.5 | 0.0 | 0.0 | 0.3 | -39.4 | 0.0 | 45.0 |
| WAR ENGINE JOBS | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.7 | -9.0 | 53.3 | 0.0 | 0.7 | -6.6 | 57.0 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +34.2 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.7 | -241.9 | 0.0 | 45.0 | 2.3 | -281.0 | 0.0 | 100.3 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +25.1 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 3.3 | +198.3 | 0.0 | 222.7 | 2.7 | +103.2 | 0.0 | 45.0 |

### Rule changes: gs3-83c8646-p42

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 260 | 244 | 84 | 28.00 | +2338 | +27.8 |
| ARMY TABLE | 119 | 119 | 78 | 26.00 | +1840 | +23.6 |
| HOLDER ASSIGNMENT | 58 | 58 | 56 | 18.67 | +4081 | +72.9 |
| LEGAL CHARGES ONLY | 43 | 43 | 43 | 14.33 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 216 | 201 | 34 | 11.33 | +524 | +15.4 |
| OFF BEST | 30 | 30 | 30 | 10.00 | -1057 | -35.2 |
| SHOT RISK POINTS | 162 | 156 | 28 | 9.33 | +1236 | +44.1 |
| DEPLOY BY FIGURES | 50 | 50 | 27 | 9.00 | +330 | +12.2 |
| GOAL WALK | 45 | 45 | 26 | 8.67 | +1156 | +44.5 |
| FIVE ACTION | 554 | 531 | 21 | 7.00 | +1172 | +55.8 |
| STAY WORTH | 167 | 155 | 21 | 7.00 | +346 | +16.5 |
| PROMISE BY ITS OWN SUM | 44 | 44 | 20 | 6.67 | -2095 | -104.7 |
| THE TABLE AGAIN | 36 | 36 | 19 | 6.33 | +0 | +0.0 |
| CAST JOB | 23 | 23 | 17 | 5.67 | +176 | +10.4 |
| TIME ON OUR SIDE | 128 | 108 | 15 | 5.00 | +51 | +3.4 |
| HARD STAY DROPPED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 23 | 14 | 13 | 4.33 | +591 | +45.5 |
| FOUR ROUNDS | 21 | 20 | 12 | 4.00 | +530 | +44.2 |
| IDLE COST | 65 | 44 | 12 | 4.00 | +229 | +19.1 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| OGRE LOADER SECOND SHOT | 12 | 12 | 12 | 4.00 | +38 | +3.1 |
| MEETS IN TIME | 15 | 15 | 11 | 3.67 | +475 | +43.2 |
| CHARGE LOSSES | 128 | 122 | 10 | 3.33 | +451 | +45.1 |
| LANE BY FIGURES | 10 | 10 | 10 | 3.33 | +502 | +50.2 |
| SHOOTS FROM THE BEST SPOT | 20 | 20 | 10 | 3.33 | +140 | +14.0 |
| ARTILLERY RE-ROLL WEIGHED | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| QUARTER ODDS | 49 | 49 | 9 | 3.00 | +788 | +87.5 |
| REDIRECT FOR A FRIEND IN REACH | 9 | 9 | 8 | 2.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 19 | 19 | 7 | 2.33 | -105 | -15.0 |
| MAX FOR POSITIONING | 29 | 24 | 7 | 2.33 | +44 | +6.4 |
| CHAFF IN THE MOVE | 7 | 7 | 6 | 2.00 | +0 | +0.0 |
| COVER ONCE | 69 | 49 | 6 | 2.00 | +118 | +19.7 |
| MARCH CHECK | 7 | 6 | 6 | 2.00 | +53 | +8.9 |
| MISSILES IN THE MOVE | 37 | 29 | 6 | 2.00 | +146 | +24.3 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| FALLS SHORT | 79 | 70 | 5 | 1.67 | +41 | +8.1 |
| MARCH OF THE TABLE | 5 | 5 | 5 | 1.67 | -229 | -45.8 |
| NEXT CHARGE BY LIST | 8 | 6 | 5 | 1.67 | +208 | +41.6 |
| RISK BY ARC | 16 | 15 | 5 | 1.67 | +65 | +13.0 |
| SEARCH SPOT | 7 | 7 | 5 | 1.67 | +284 | +56.8 |
| SHOTS IN THE MOVE | 100 | 81 | 5 | 1.67 | +250 | +50.0 |
| WOUNDS ON THE RANKS | 18 | 18 | 5 | 1.67 | +314 | +62.7 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +389 | +97.3 |
| MARCH BY THE SUM | 4 | 4 | 4 | 1.33 | +121 | +30.1 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FIRE IN ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HIS TURN DENIED | 7 | 6 | 3 | 1.00 | +65 | +21.5 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | +94 | +31.3 |
| SHOTS AFTER THE MOVES | 28 | 28 | 3 | 1.00 | +0 | +0.0 |
| STUBBORN BY POINTS | 3 | 3 | 3 | 1.00 | +66 | +21.8 |
| SUPPORT ADDS | 20 | 17 | 3 | 1.00 | +25 | +8.3 |
| SUPPORT NARROWED | 8 | 8 | 3 | 1.00 | -190 | -63.4 |
| SUPPORT WORKED OUT | 20 | 17 | 3 | 1.00 | +25 | +8.3 |
| TIED UP BY THE SUM | 4 | 3 | 3 | 1.00 | +148 | +49.3 |
| WALKS ON ITS ROUTE | 3 | 3 | 3 | 1.00 | -102 | -34.0 |
| ASSAILMENT BY POINTS | 2 | 2 | 2 | 0.67 | +10 | +5.2 |
| CANNON PLANNED TARGET | 29 | 29 | 2 | 0.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +14 | +6.8 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.67 | +98 | +49.2 |
| GOAL ROUTE | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +68 | +33.9 |
| MISSILES NEXT TURN | 52 | 40 | 2 | 0.67 | +3 | +1.7 |
| PROMISE KNOWS THE FIGHT | 5 | 4 | 2 | 0.67 | -15 | -7.3 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SET UP BY THE SET | 8 | 8 | 2 | 0.67 | -78 | -39.1 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +6 | +3.0 |
| SURE REACH TOGETHER | 5 | 5 | 2 | 0.67 | +0 | +0.0 |
| WAR ENGINE JOBS | 5 | 5 | 2 | 0.67 | -22 | -11.2 |
| WHOLE FIGHT DANGER | 15 | 15 | 2 | 0.67 | +82 | +41.1 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +12 | +12.3 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +32 | +31.9 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.33 | +0 | +0.2 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -336 | -336.3 |
| EXACT ROUND | 12 | 12 | 1 | 0.33 | +4 | +3.5 |
| FALL BACK GOOD ORDER | 19 | 18 | 1 | 0.33 | +6 | +5.8 |
| FEATURE BUFFS | 6 | 6 | 1 | 0.33 | +14 | +13.7 |
| HIS CHARGE DENIED | 3 | 3 | 1 | 0.33 | +126 | +125.6 |
| HONEST WORTH | 19 | 18 | 1 | 0.33 | +4 | +3.5 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +32 | +31.9 |
| NEARER NOT NEEDED | 47 | 46 | 1 | 0.33 | +61 | +61.2 |
| NO DOUBLE ROUNDS | 21 | 20 | 1 | 0.33 | +4 | +3.5 |
| ONE OBJECTIVE FORMULA | 33 | 30 | 1 | 0.33 | +393 | +392.6 |
| OVERRUNS AWAY | 4 | 3 | 1 | 0.33 | +13 | +13.0 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +60 | +60.0 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -113 | -112.6 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -8 | -7.8 |
| REFUSING RETIRES | 2 | 2 | 1 | 0.33 | -17 | -16.7 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +35 | +34.7 |
| SHOT REPLANNED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +2 | +1.5 |
| THE ROW IN ITS ORDER | 13 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +94 | +94.3 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 4 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 3 | 3 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 15 | 15 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 50 | 50 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 6 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 6 | 6 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 5 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 48 | not checked | - | - | - | - |
| FOOT FIRST | 70 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 29 | 27 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 2 | not checked | - | - | - | - |
| GUN MASK | 6 | 6 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 18 | 16 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 99 | 97 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 17 | 17 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 28 | 23 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 39 | 37 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 2 | 2 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 42 | 31 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 87 | 85 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 11 | 9 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 17 | 16 | 0 | 0.00 | - | - |
| MANOEUVRE | 13 | 13 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 10 | 10 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 2 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NEAREST TO GOAL | 4 | 4 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE FIGHT FORMULA | 35 | 23 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE ROUTE | 4 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS A LANE | 5 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 252 | trace | - | - | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 2 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 3 | 3 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 6 | 6 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | not checked | - | - | - | - |
| ROUNDS AFTER TERROR | 7 | 6 | 0 | 0.00 | - | - |
| RUN DOWN | 17 | 16 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 12 | 12 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 6 | 6 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 3 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 73 | not checked | - | - | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 3 | not checked | - | - | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 25 | 22 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 22 | 20 | 0 | 0.00 | - | - |
| STANDS STILL | 233 | 226 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 11 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 10 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 1 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 6 | not checked | - | - | - | - |
| THE TABLE BINDS | 252 | not checked | - | - | - | - |
| WAITS AGAIN | 13 | 7 | 0 | 0.00 | - | - |
| WHO FIGHTS | 4 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p42

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.67 | 2.33 | 28.3 |
| PROMISE BY ITS OWN SUM | rule | 4.33 | 2.33 | 104.7 |
| ARMY TABLE | rule | 1.33 | 2.00 | 31.6 |
| HOLDER ASSIGNMENT | rule | 2.00 | 0.67 | 15.9 |
| CHARGE NOW FIRST | rule | 1.33 | 0.67 | 17.5 |
| MARCH OF THE TABLE | rule | 1.67 | - | 45.8 |
| NO REASON | gate | - | 1.00 | 28.2 |
| RULE SWITCHED OFF | gate | 1.00 | - | 97.5 |
| SUPPORT NARROWED | rule | 0.67 | 0.33 | 63.4 |
| PROMISE KNOWS THE FIGHT | rule | 0.67 | - | 7.3 |
| WALKS ON ITS ROUTE | rule | 0.33 | 0.33 | 61.4 |
| WAR ENGINE JOBS | rule | 0.67 | - | 11.2 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 336.3 |
| JOINT CHARGE NOW | rule | - | 0.33 | 38.9 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 112.6 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 7.8 |
| REFUSING RETIRES | rule | - | 0.33 | 16.7 |
| SET UP BY THE SET | rule | 0.33 | - | 113.2 |

### Plans: gs3-83c8646-p42

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.7 | 62% | 144 | 157 | 108% |
| Mine | move | 26.3 | 96% | 1336 | 0 | 0% |
| Mine | shoot | 14.0 | 52% | 867 | 538 | 62% |
| Opponent | charge | 2.7 | 38% | 231 | 343 | 148% |
| Opponent | move | 30.7 | 91% | 1069 | 0 | 0% |
| Opponent | shoot | 5.7 | 59% | 579 | 469 | 81% |
| Opponent | support | 2.0 | 100% | 0 | 0 | - |

### Battle groups: gs3-83c8646-p42

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 1.0 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p42

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 11 | 27 (11) | 27 | 0 | 48 | 18% | 2.3 | 37 (3) | 0 (3) | 31 (4) | 28 (6) | 29 (4) |
| Mine | Clean-up | 1 | 88 (1) | 0 | 88 | 100 | 100% | - | 88 (1) | - | - | 88 (1) | - |
| Mine | Fast Hammer | 6 | 80 (6) | 21 | 58 | 51 | 0% | 1.5 | 52 (4) | 128 (2) | - | 144 (3) | 7 (3) |
| Mine | Hammer | 4 | 34 (4) | 12 | 22 | 26 | 50% | 2.5 | 0 (1) | 46 (3) | - | 45 (3) | 0 (1) |
| Mine | Holder | 1 | 175 (1) | 0 | 175 | 0 | 100% | - | - | 175 (1) | - | 175 (1) | - |
| Mine | Shooter | 3 | 32 (3) | 0 | 32 | 0 | 0% | 1.7 | 0 (2) | 96 (1) | - | 0 (1) | 48 (2) |
| Mine | War machine | 7 | 40 (7) | 40 | 0 | 16 | 0% | 1.4 | 72 (4) | 0 (3) | - | 94 (2) | 15 (5) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 4.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Chaff | 6 | 0 (6) | 0 | 0 | 61 | 67% | 3.0 | 0 (4) | 0 (1) | 0 (1) | 0 (3) | 0 (3) |
| Opponent | Character | 7 | 48 (7) | 48 | 0 | 5 | 0% | 2.6 | - | 48 (6) | 45 (1) | 15 (3) | 81 (4) |
| Opponent | Clean-up | 4 | 117 (4) | 0 | 117 | 16 | 50% | 5.5 | - | 117 (4) | - | 117 (4) | - |
| Opponent | Fast Hammer | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fragile | 5 | 52 (5) | 52 | 0 | 36 | 0% | 3.6 | 0 (1) | - | 63 (4) | 63 (4) | 0 (1) |
| Opponent | Hammer | 5 | 0 (5) | 0 | 0 | 51 | 80% | 2.0 | 0 (1) | 0 (4) | - | 0 (2) | 0 (3) |
| Opponent | Holder | 2 | 140 (2) | 0 | 140 | 50 | 0% | 1.0 | - | 140 (2) | - | - | 140 (2) |
| Opponent | Shooter | 5 | 191 (5) | 80 | 111 | 71 | 0% | 1.0 | 383 (2) | 0 (1) | 144 (2) | 300 (1) | 174 (4) |

### Charged fights: gs3-83c8646-p42

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 1 | 0 | 105 | 2.0 | 1.0 | 52 | 0 | +52 | 1 of 2 | 1 of 2 | - | +52 |
| Mine | Grand Cathay | 2 | 494 | 179 | 2.5 | 1.2 | 72 | 0 | +72 | 1 of 5 | 4 of 5 | +160 | +50 |
| **Mine** | all armies | 3 | 329 | 154 | 2.3 | 1.1 | 66 | 0 | +66 | 2 of 7 | 5 of 7 | +160 | +50 |
| Opponent | Lizardmen | 1 | 293 | 1344 | 5.0 | 1.0 | 269 | 0 | +269 | 2 of 5 | 4 of 5 | - | +269 |
| Opponent | Vampire Counts | 1 | 0 | 227 | 1.0 | 1.0 | 227 | 0 | +227 | 1 of 1 | 1 of 1 | - | +227 |
| Opponent | Wood Elf Realms | 1 | 135 | 167 | 2.0 | 1.0 | 84 | 0 | +84 | 1 of 2 | 2 of 2 | - | +84 |
| **Opponent** | all armies | 3 | 143 | 579 | 2.7 | 1.0 | 217 | 0 | +217 | 4 of 8 | 7 of 8 | - | +217 |

### Effective charges: gs3-83c8646-p42

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 1 (net +0) | 0 | 0 | 0 | 1 (net +105) | 0 | 0 | 0% (0 of 2) |
| Mine | Grand Cathay | 5 | 0 | 0 | 1 (net +0) | 3 (net +66) | 0 | 1 (net +160) | 0 | 20% (1 of 5) |
| Opponent | Lizardmen | 5 | 0 | 0 | 2 (net +82) | 0 | 0 | 2 (net +504) | 1 | 50% (2 of 4) |
| Opponent | Wood Elf Realms | 2 | 0 | 0 | 1 (net +167) | 0 | 0 | 1 (net +0) | 0 | 50% (1 of 2) |

### Charged fights, damage counted: gs3-83c8646-p42

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 265 | 357 | +0 | 29 | 0 | +29 | +10.8 |
| Mine | Effective (55-75%) | 1 | 369 | 175 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 76-89% | 3 | 260 | 113 | +66 | 71 | 37 | +34 | +12.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 367 | 160 | +160 | 160 | 0 | +160 | +43.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 265 | 45 | +105 | 105 | 0 | +105 | +39.6 |
| Mine | All fights | 7 | 292 | 154 | +66 | 72 | 16 | +56 | +19.3 |
| Opponent | Effective (55-75%) | 3 | 114 | 165 | +111 | 237 | 191 | +46 | +40.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 432 | 314 | +336 | 336 | 0 | +336 | +77.7 |
| Opponent | No odds | 2 | 452 | 181 | +199 | 228 | 0 | +228 | +50.4 |
| Opponent | All fights | 8 | 318 | 225 | +217 | 272 | 72 | +200 | +63.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p42 | move | 26 | 6 (23%) | 6 (23%) | 1 (4%) | 19 (73%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0926, L1034 |
| Ring of Jet | Mine | L1017, L1034 |
| Twice-Blessed Armour | Mine | L1017, L1034 |

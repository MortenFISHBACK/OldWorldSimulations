# Doctrine scorecard: gs3-83c8646-p81

### Scorecard: gs3-83c8646-p81

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1535 | 5 | 1 | Mine | yes | - | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 3 | 2 | 3 | 0 | 0 | 0 | 114 |
| L1633 | 1 | 1 | Mine | yes | 8 | 2 | 3 | 1 | 0 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 4 | 0 | 0 | 0 | 368 |
| L1731 | 3 | 1 | Mine | yes | 3 | 2 | 4 | 0 | 0 | 0 | 0 | 147 |
| L1731 | 3 | 1 | Opponent | no | 2 | 6 | 3 | 2 | 1 | 0 | 0 | 340 |
| **Average** | | | Mine | 100% | 5.5 | 2.0 | 3.3 | 0.3 | 0.3 | 0.0 | 0.0 | 115.7 |
| **Average** | | | Opponent | 33% | 1.0 | 3.7 | 2.3 | 3.0 | 0.3 | 0.0 | 0.0 | 274.0 |

### KPIs: gs3-83c8646-p81

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 16) | 19% (3 of 16) | 9% (3 of 32) |
| Winner chose to follow up after the loser gave ground |  | 83% (5 of 6); on the table 83% | 100% (3 of 3); on the table 100% | 89% (8 of 9); on the table 89% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | 100% (2 of 2); on the table 100% | 67% (2 of 3); on the table 67% |
| Winner chose to pursue after the loser fled |  | 33% (1 of 3); on the table 33% | 50% (2 of 4); on the table 50% | 43% (3 of 7); on the table 43% |
| Winner chose to follow up or pursue (all three) |  | 60% (6 of 10); on the table 60% | 78% (7 of 9); on the table 78% | 68% (13 of 19); on the table 68% |
| Magic missiles tried each own turn | 50%+ | 58% (7 of 12) | 33% (2 of 6) | 50% (9 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 64% (7 of 11) | 40% (2 of 5) | 56% (9 of 16) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 25% (2 of 8) | 25% (2 of 8) |
| Points that never fought | lower | 43% (2555 of 6000) | 32% (1939 of 6000) | 37% (4494 of 12000) |
|   infantry points that never fought | lower | 46% (609 of 1332) | 56% (849 of 1529) | 51% (1458 of 2861) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 65% (13 of 20) | 74% (25 of 34) | 70% (38 of 54) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 1.7 uses a game | 100% (4 of 4); 3.7 uses a game | 100% (6 of 6); 2.7 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 62% (3201 of 5135) | 68% (4038 of 5962) | 65% (7239 of 11097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (60%) | 0.0 (0%) | 1.0 (33%) |
| MARCHED: its unit marched | 0.3 (20%) | 1.0 (75%) | 1.3 (44%) |
| IN COMBAT: engaged in combat | 0.3 (20%) | 0.0 (0%) | 0.3 (11%) |
| GONE: slain | 0.0 (0%) | 0.3 (25%) | 0.3 (11%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.7 | 1.0 | 3.0 | 3.0 | 0.3 | 0.0 |
| not cast | 2.3 | 1.0 | 3.0 | 3.0 | 1.7 | 12.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.0 (100%) | 0.3 (11%) | 1.0 (33%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (44%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.3 (11%) | 0.3 (11%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 1.3 (44%) | 0.3 (11%) | 1.3 (80%) | 3.0 (25%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.7 (29%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (20%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (71%) | 0.0 (0%) | 1.0 (33%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 8.0 (67%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.0 a game | 1.0 a game | 1.5 a game |
| stood (cast and not dispelled) | - | 33% (1 of 3) | 33% (1 of 3) |
| the unit moved after it | - | 0% (0 of 1) | 0% (0 of 1) |
| it charged on its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| the enemy charged it first | - | 0% (0 of 1) | 0% (0 of 1) |
| it fought by the end of its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 1) | 0% (0 of 1) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (1 of 1) | 100% (1 of 1) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 57% (47 of 82) | 71% (42 of 59) | 63% (89 of 141) |
|   cavalry | 62% (5 of 8) | 72% (18 of 25) | 70% (23 of 33) |
|   character | 44% (4 of 9) | 77% (10 of 13) | 64% (14 of 22) |
|   chariot | 25% (1 of 4) | - | 25% (1 of 4) |
|   infantry | 66% (23 of 35) | 67% (14 of 21) | 66% (37 of 56) |
|   monster | 29% (5 of 17) | - | 29% (5 of 17) |
|   war machine | 100% (9 of 9) | - | 100% (9 of 9) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (17%) | 2.7 (47%) | 4.7 (27%) |
| CHARGED: it charged | 1.7 (14%) | 2.0 (35%) | 3.7 (21%) |
| FLEEING: it fled or was fleeing | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 1.3 (11%) | 0.7 (12%) | 2.0 (12%) |
| NO TARGET IN RANGE | 5.7 (49%) | 0.0 (0%) | 5.7 (33%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (6%) | 0.0 (0%) | 0.7 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 0.3 (6%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 9.3 | 1.7 | 82% | 2.9 pts | 27 pts |
| character | 5.7 | 1.3 | 76% | 3.4 pts | 19 pts |
| chariot | 0.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 20.0 | 6.0 | 77% | 11.8 pts | 235 pts |
| monster | 1.7 | 0.3 | 80% | 4.1 pts | 7 pts |
| war machine | 3.0 | 2.7 | 56% | 15.5 pts | 47 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.0 | 3.7 | 3.8 |
| Charges that made contact a game | 3.0 | 3.3 | 3.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.50 contact (2 units) | 0.00 declared, 0.00 contact (1 units) | 0.33 declared, 0.33 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.50 declared, 0.00 contact (2 units) | - | 0.50 declared, 0.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.50 declared, 0.40 contact (20 units) | 0.46 declared, 0.42 contact (24 units) | 0.48 declared, 0.41 contact (44 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 75% (6 of 8) | 0% (0 of 1) | 100% (1 of 1) | 70% (7 of 10) |
| Character in a unit | 100% (4 of 4) | 100% (1 of 1) | 100% (2 of 2) | 100% (7 of 7) |
| Character on its own | 67% (2 of 3) | 0% (0 of 3) | 50% (3 of 6) | 42% (5 of 12) |
| Chariot | 100% (1 of 1) | - | - | 100% (1 of 1) |
| Infantry | 82% (9 of 11) | 40% (2 of 5) | - | 69% (11 of 16) |
| Monster | 80% (4 of 5) | - | - | 80% (4 of 5) |
| Monstrous | 100% (3 of 3) | - | - | 100% (3 of 3) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 1 | 50% (1 of 2); on the table 50% | 33% (2 of 6) | 51% | 71% (5 of 7) | 100% (2 of 2); 5.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 67% (2 of 3); on the table 67% | - | 39% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | 60% (3 of 5); on the table 60% | 83% (5 of 6) | 37% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 83% (5 of 6); on the table 83% | 33% (2 of 6) | 24% | 83% (10 of 12) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 2 | 67% (2 of 3); on the table 67% | - | 36% | 68% (15 of 22) | 100% (3 of 3); 3.5 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p81, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 25% (1) | 75% (3) | 50% (4) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.67 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: gs3-83c8646-p81

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.0 | 2.3 |
| Strategy | Charge objectives carried out (made contact) | 55% (6 of 11) | 67% (4 of 6) |
| Strategy | Shoot objectives carried out (shot that target) | 67% (10 of 15) | 0% (0 of 12) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 100% (2 of 2) |
| Strategy | Joined characters whose unit fought | 0% (0 of 1) | 71% (5 of 7) |
| Strategy | Lone characters that fought | 75% (6 of 8) | 75% (3 of 4) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 0.3 | 3.0 |
| Movement | Points that never moved of their own | 115.7 | 274.0 |
| Movement | Fights charged into per game | 3.0 | 3.3 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 7, net -30 | 0 of 6 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 7 | 0 of 6 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 7, net +57 | 2 of 6, net +58 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 7, net +51 | 2 of 6, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 14.7 | 14.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 25% (11 of 44) | 56% (24 of 43) |
| Shooting | Points destroyed by shooting units | 65.0 | 92.0 |
| Shooting | War machine shots | 3.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 22% (2 of 9) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.3 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 4) | - |
| Magic | Wounds caused by magic missiles | 5.0 | 3.0 |
| Magic | Points destroyed by magic (all spells) | 46.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.0 / 0.0 / 0.0 | 3.3 / 0.7 / 0.0 / 0.3 |
| Combat | Points destroyed in combat | 241.3 | 146.7 |
| Combat | Points run down | 40.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +82 | +14 |
| Combat | Net per 100 charger points, damage counted | +24.2 | +6.4 |
| Combat | First round won (charged fights) | 67% | 60% |
| Combat | Net points per charged fight | +48 | +1 |
| Combat | Net points per supported fight / lone fight | - / +48 | - / +1 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 9 | 0 of 10 |
| Game | Points lost | 222.0 | 393.0 |
| Game | VP from objectives | 606.7 | 403.3 |
| Game | Lone holders (player turns) | 5.5 | 1.0 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +394 VP
- The side that went first won 0 of 3 games with a winner
- Points traded per game (both sides' losses): 615
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p81

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +27.0 | 0.0 | 61.7 | - | - | - | - |
| AFTERMATH WITH FRIENDS | 1.3 | +34.1 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 25.3 | +245.8 | 0.0 | 201.7 | 34.0 | +534.8 | 0.0 | 238.7 |
| BACKUP TARGETS | 0.7 | +5.9 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | 0.3 | +6.7 | 34.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | 0.7 | +7.0 | 0.0 | 20.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 2.7 | +5.4 | 0.0 | 33.3 | - | - | - | - |
| CANNON SIGHT KEPT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.3 | -6.2 | 40.0 | 0.0 | - | - | - | - |
| CAST JOB | - | - | - | - | 2.0 | +21.1 | 123.3 | 0.0 |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.0 | +10.7 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.7 | +44.0 | 0.0 | 58.7 | 0.3 | +11.9 | 0.0 | 0.0 |
| CHARACTER GUNS | - | - | - | - | 6.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 21.3 | -770.5 | 0.0 | 279.0 | 21.0 | -597.5 | 0.0 | 229.7 |
| CHARGE NOW FIRST | 2.7 | +0.0 | 78.0 | 0.0 | 2.3 | +0.0 | 220.3 | 40.0 |
| CLOSES ON WHAT IT BEATS | 10.3 | +0.0 | 0.0 | 53.3 | 7.0 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | - | - | - | - | 0.7 | +0.0 | 123.3 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 1.0 | +56.7 | 0.0 | 78.0 |
| COVER ONCE | 10.3 | -715.2 | 0.0 | 61.7 | 7.7 | -446.7 | 0.0 | 130.0 |
| DENIED BY THE FIGHT | 0.3 | -5.0 | 0.0 | 0.0 | 0.7 | -19.4 | 58.7 | 0.0 |
| DEPLOY BY FIGURES | 7.3 | -10.9 | 0.0 | 0.0 | 8.0 | -64.1 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.7 | -7.0 | 0.0 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.3 | +56.6 | 0.0 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | - | - | - | - | 1.7 | +196.8 | 58.7 | 46.7 |
| EXACT ROUND | 2.3 | +38.8 | 78.0 | 20.0 | 1.0 | +2.5 | 38.3 | 0.0 |
| FALL BACK GOOD ORDER | 2.7 | +10.1 | 78.0 | 0.0 | 2.0 | +0.3 | 97.0 | 40.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 6.0 | +80.1 | 0.0 | 26.7 | 14.7 | +193.5 | 0.0 | 149.7 |
| FEATURE BUFFS | 1.0 | +25.7 | 0.0 | 117.3 | 1.0 | +30.5 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +9.3 | 0.0 | 0.0 | 0.3 | -0.9 | 0.0 | 40.0 |
| FIVE ACTION | 89.7 | +7691.6 | 273.0 | 574.0 | 87.7 | +6426.1 | 279.0 | 794.7 |
| FLANK NOT WEIGHED | 9.3 | +0.0 | 0.0 | 81.7 | 6.3 | +0.0 | 0.0 | 99.0 |
| FOLLOW UP WEIGHED | 1.0 | +338.9 | 0.0 | 0.0 | 0.3 | +149.3 | 0.0 | 0.0 |
| FOOT FIRST | 20.7 | +0.0 | 0.0 | 118.7 | - | - | - | - |
| FOUR ROUNDS | 4.0 | +274.8 | 78.0 | 20.0 | 2.0 | +96.8 | 97.0 | 40.0 |
| FREED FROM HIS FIGHT | 3.7 | +0.0 | 0.0 | 76.7 | 9.7 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 2.0 | -13.1 | 0.0 | 0.0 | 0.7 | -6.7 | 0.0 | 0.0 |
| GOAL WALK | 10.7 | +1725.4 | 0.0 | 76.7 | 5.0 | +355.4 | 0.0 | 34.7 |
| HARD STAY DROPPED | 2.7 | +0.0 | 0.0 | 20.0 | 2.0 | +0.0 | 0.0 | 38.0 |
| HE REFORMS ONCE FREED | 1.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 14.3 | +0.0 | 0.0 | 279.0 | 14.0 | +0.0 | 0.0 | 195.0 |
| HIS CHARGE LIST | 2.7 | +0.0 | 0.0 | 0.0 | 11.7 | +0.0 | 0.0 | 102.7 |
| HIS LEGAL MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 7.0 | -94.1 | 0.0 | 170.7 | 5.7 | -116.0 | 0.0 | 130.0 |
| HIS ONE QUARTER | 6.7 | +0.0 | 0.0 | 0.0 | 8.7 | +0.0 | 0.0 | 130.0 |
| HIS OWN BEST MOVE | 11.7 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 164.7 |
| HIS RANDOM MOVE | 10.7 | +0.0 | 0.0 | 123.3 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.0 | +0.0 | 0.0 | 123.3 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 40.0 | +2034.7 | 0.0 | 364.0 | 49.0 | +2031.6 | 0.0 | 479.3 |
| HIS SHOTS BY HIS RUN | 45.0 | +939.0 | 0.0 | 449.0 | 47.0 | +1118.4 | 0.0 | 557.0 |
| HIS TURN DENIED | 1.3 | +47.8 | 38.0 | 20.0 | 1.3 | +81.7 | 97.0 | 0.0 |
| HOLD ODDS | 17.3 | +0.0 | 0.0 | 411.3 | 10.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 10.7 | +669.6 | 0.0 | 147.0 | 6.3 | +585.5 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.7 | -165.0 | 78.0 | 0.0 | 2.0 | -73.0 | 97.0 | 40.0 |
| HORN WORTH | - | - | - | - | 0.3 | +6.9 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.7 | +2.7 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | 1.3 | -30.7 | 0.0 | 0.0 | 13.0 | -123.6 | 0.0 | 34.0 |
| KEPT FROM ITS LAST STOP | 3.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.7 | +70.6 | 0.0 | 0.0 | 0.3 | +6.0 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 10.7 | +0.0 | 519.7 | 120.3 | 4.7 | +0.0 | 0.0 | 118.7 |
| LONE WIZARD KEPT IN | 0.3 | +16.9 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.7 | -0.7 | 0.0 | 40.0 |
| LOST AFTER ESCAPE | 2.3 | +6.4 | 40.0 | 20.0 | 1.7 | +1.6 | 58.7 | 40.0 |
| MAKE SURE TOGETHER | 1.0 | +16.7 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 2.0 | -36.2 | 0.0 | 0.0 | 3.3 | -7.2 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.7 | +8.9 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +75.0 | 0.0 | 0.0 | 0.3 | +1.5 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +27.6 | 0.0 | 0.0 | 0.7 | +44.5 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +15.5 | 0.0 | 65.0 |
| MARCH OVER CASTS | 0.7 | +118.7 | 0.0 | 0.0 | 1.3 | +127.9 | 0.0 | 130.0 |
| MAX FOR POSITIONING | 1.3 | +19.4 | 0.0 | 0.0 | 4.0 | +103.4 | 0.0 | 130.0 |
| MEETS IN TIME | 3.7 | +154.4 | 0.0 | 0.0 | 4.3 | +198.7 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.7 | +60.0 | 0.0 | 0.0 | 5.3 | +82.8 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 4.7 | +44.2 | 0.0 | 0.0 | 7.0 | +67.0 | 0.0 | 130.0 |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 26.7 | 3.3 | +0.0 | 0.0 | 46.7 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 0.7 | -12.7 | 0.0 | 78.0 |
| MOVE TO CHARGE COMPUTED | 10.7 | +885.8 | 0.0 | 0.0 | 5.3 | +395.0 | 0.0 | 164.7 |
| MOVES UNITS SPELL | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 6.7 | +305.9 | 0.0 | 58.7 | 6.0 | +241.2 | 0.0 | 38.0 |
| NEAREST TO GOAL | 2.0 | +0.0 | 0.0 | 76.7 | - | - | - | - |
| NEXT CHARGE BY LIST | 7.7 | +593.7 | 0.0 | 0.0 | 2.3 | +148.7 | 0.0 | 130.0 |
| NO DOUBLE ROUNDS | 3.7 | -213.1 | 38.0 | 20.0 | 2.0 | -78.0 | 97.0 | 40.0 |
| NO LATE CUT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | -2.7 | 0.0 | 0.0 |
| OFF BEST | 5.7 | -186.9 | 0.0 | 58.3 | 4.7 | -105.4 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 7.7 | -150.1 | 0.0 | 0.0 | 5.7 | -118.0 | 0.0 | 130.0 |
| ONE OBJECTIVE FORMULA | 4.7 | -28.7 | 0.0 | 147.0 | 3.0 | +45.2 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 1.0 | -16.9 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 1.0 | +58.7 | 38.0 | 0.0 | 0.3 | +12.6 | 38.3 | 0.0 |
| OVERRUNS AWAY | 2.7 | +20.9 | 78.0 | 0.0 | 0.3 | +2.0 | 0.0 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +4.9 | 0.0 | 0.0 |
| PLAN RESULT | 39.3 | +208.3 | 65.0 | 450.7 | 41.7 | +229.6 | 58.7 | 495.3 |
| PROMISE BY ITS OWN SUM | 11.0 | -130.7 | 0.0 | 38.3 | 6.7 | -254.1 | 0.0 | 34.7 |
| PROMISE IN STEPS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 1.7 | -1.9 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 1.3 | -7.8 | 0.0 | 0.0 | 0.7 | -6.7 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 1.0 | -1.2 | 195.0 | 0.0 | 0.7 | -0.3 | 0.0 | 0.0 |
| QUARTER ODDS | 27.7 | +3515.3 | 105.0 | 60.0 | 25.7 | +3699.5 | 0.0 | 170.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 2.7 | +18.0 | 0.0 | 113.3 |
| REDIRECT COUNTER | 1.3 | +12.9 | 0.0 | 26.7 | 0.7 | +54.8 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 2.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 2.0 | -92.4 | 0.0 | 0.0 | 1.7 | -37.5 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 1.0 | +25.5 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 3.3 | -81.4 | 78.0 | 0.0 | 2.0 | +45.6 | 97.0 | 40.0 |
| RISK ON THE WAY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | 1.7 | -28.2 | 78.0 | 0.0 | 1.0 | -6.7 | 97.0 | 0.0 |
| RUN DOWN | 3.3 | -72.5 | 78.0 | 20.0 | 1.7 | -11.9 | 58.7 | 40.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -14.5 | 0.0 | 0.0 |
| SEARCH SPOT | - | - | - | - | 0.3 | +2.5 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +2.3 | 40.0 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | 2.0 | +328.2 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 4.3 | -60.1 | 0.0 | 0.0 | 0.7 | -49.3 | 0.0 | 0.0 |
| SET UP BY THE SET | 5.7 | +65.5 | 0.0 | 0.0 | 1.0 | +49.9 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.0 | +16.7 | 0.0 | 0.0 | - | - | - | - |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.7 | -0.2 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 1.0 | +2.0 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 4.7 | +0.0 | 0.0 | 33.3 | 5.0 | +0.0 | 0.0 | 38.0 |
| SHOOTS FROM THE BEST SPOT | 2.0 | +13.0 | 0.0 | 0.0 | 1.3 | +56.8 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -1.6 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 31.3 | +168.8 | 0.0 | 293.3 | 32.0 | -178.7 | 0.0 | 99.7 |
| SHOTS AFTER THE MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 12.7 | +310.5 | 0.0 | 92.0 | 13.7 | +325.4 | 0.0 | 84.7 |
| SPELL WORTH | 1.7 | +8.3 | 0.0 | 0.0 | 4.0 | +31.2 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 5.7 | +0.0 | 0.0 | 26.7 | 8.3 | +0.0 | 0.0 | 173.7 |
| STAND AND SHOOT | 1.0 | -30.1 | 0.0 | 0.0 | 1.0 | -13.4 | 97.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 5.0 | +0.0 | 0.0 | 76.0 |
| STANDS STILL | 29.3 | +0.0 | 195.0 | 106.7 | 32.0 | +0.0 | 182.0 | 224.0 |
| STAY WORTH | 14.0 | +286.9 | 65.0 | 138.3 | 9.0 | +78.7 | 182.0 | 46.7 |
| STUBBORN BY POINTS | 0.3 | +7.4 | 0.0 | 0.0 | - | - | - | - |
| STUPIDITY NEXT TURN | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 3.0 | +72.5 | 0.0 | 0.0 | 5.7 | +677.8 | 0.0 | 34.7 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 3.0 | +72.5 | 0.0 | 0.0 | 5.7 | +677.8 | 0.0 | 34.7 |
| SURE REACH TOGETHER | 0.3 | +2.4 | 0.0 | 0.0 | 1.7 | +19.1 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 65.0 |
| THE ROW IN ITS ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 34.0 |
| THE ROW KEEPS ITS WAY | 2.7 | +0.0 | 0.0 | 58.7 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 58.7 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 41.3 | +0.0 | 0.0 | 277.0 | 42.3 | +0.0 | 0.0 | 283.3 |
| TIED UP BY THE SUM | 2.3 | +317.4 | 78.0 | 0.0 | 1.0 | +185.2 | 97.0 | 0.0 |
| TIME ON OUR SIDE | 29.7 | +373.3 | 0.0 | 197.0 | 17.3 | +175.7 | 0.0 | 69.3 |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 65.0 |
| WALKS ON ITS ROUTE | 0.3 | -12.0 | 0.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | 0.7 | -22.6 | 80.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.7 | -2.5 | 40.0 | 0.0 | 0.7 | +3.4 | 0.0 | 40.0 |
| WHO HITS BACK | 1.0 | +208.3 | 0.0 | 61.7 | 0.3 | +10.3 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.3 | +8.1 | 40.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 3.3 | -299.8 | 0.0 | 240.7 | 2.3 | -109.2 | 0.0 | 130.0 |
| WOUNDED STAYS OUT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 2.0 | +16.3 | 0.0 | 123.3 | 2.3 | +87.2 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p81

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 178 | 178 | 108 | 36.00 | +1842 | +17.1 |
| HIS SHOT LIST | 267 | 264 | 80 | 26.67 | +1043 | +13.0 |
| HIS SHOTS BY HIS RUN | 276 | 273 | 56 | 18.67 | +583 | +10.4 |
| HOLDER ASSIGNMENT | 51 | 51 | 47 | 15.67 | +3061 | +65.1 |
| LEGAL CHARGES ONLY | 46 | 46 | 46 | 15.33 | +0 | +0.0 |
| QUARTER ODDS | 160 | 156 | 36 | 12.00 | +2544 | +70.7 |
| FIVE ACTION | 532 | 518 | 32 | 10.67 | +1706 | +53.3 |
| DEPLOY BY FIGURES | 46 | 46 | 31 | 10.33 | +301 | +9.7 |
| OFF BEST | 31 | 31 | 31 | 10.33 | -877 | -28.3 |
| MOVE TO CHARGE COMPUTED | 48 | 43 | 27 | 9.00 | +1334 | +49.4 |
| THE TABLE AGAIN | 36 | 36 | 26 | 8.67 | +0 | +0.0 |
| SHOT RISK POINTS | 190 | 184 | 24 | 8.00 | +610 | +25.4 |
| GOAL WALK | 47 | 47 | 22 | 7.33 | +2056 | +93.5 |
| PROMISE BY ITS OWN SUM | 53 | 53 | 20 | 6.67 | -1154 | -57.7 |
| TIME ON OUR SIDE | 141 | 119 | 16 | 5.33 | +65 | +4.0 |
| HARD STAY DROPPED | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| MOVE ORDER | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 30 | 27 | 14 | 4.67 | +365 | +26.1 |
| REDIRECT FOR A FRIEND IN REACH | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| MEETS IN TIME | 24 | 24 | 9 | 3.00 | +788 | +87.5 |
| TIED UP BY THE SUM | 10 | 9 | 9 | 3.00 | +480 | +53.3 |
| FOUR ROUNDS | 18 | 17 | 8 | 2.67 | +208 | +26.0 |
| SHOOTS FROM THE BEST SPOT | 10 | 10 | 8 | 2.67 | +44 | +5.5 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CHARGE LOSSES | 127 | 124 | 6 | 2.00 | +317 | +52.8 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +230 | +38.3 |
| CHARGE NOW FIRST | 15 | 15 | 5 | 1.67 | -135 | -27.0 |
| PROMISE SHOT AWAY | 5 | 5 | 5 | 1.67 | -5 | -0.9 |
| SET UP BY THE SET | 20 | 20 | 5 | 1.67 | +80 | +16.0 |
| AFTERMATH WITH FRIENDS | 4 | 4 | 4 | 1.33 | +102 | +25.5 |
| COVER ONCE | 54 | 32 | 4 | 1.33 | +12 | +3.0 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +1464 | +366.1 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| IDLE COST | 43 | 32 | 4 | 1.33 | +5 | +1.2 |
| SHOOTERS IN TWO RANKS | 4 | 4 | 4 | 1.33 | +7 | +1.8 |
| SUPPORT ADDS | 26 | 26 | 4 | 1.33 | +246 | +61.5 |
| SUPPORT WORKED OUT | 26 | 26 | 4 | 1.33 | +246 | +61.5 |
| WHO HITS BACK | 4 | 4 | 4 | 1.33 | +259 | +64.8 |
| WHOLE FIGHT DANGER | 17 | 17 | 4 | 1.33 | +275 | +68.6 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +168 | +55.8 |
| EVASIVE BY THE ODDS | 5 | 5 | 3 | 1.00 | +113 | +37.8 |
| MARCH CHECK | 4 | 4 | 3 | 1.00 | +17 | +5.8 |
| MAX FOR POSITIONING | 16 | 14 | 3 | 1.00 | +56 | +18.6 |
| ONE PROMISE A TARGET | 3 | 3 | 3 | 1.00 | -51 | -16.9 |
| OPENS UP | 4 | 4 | 3 | 1.00 | +52 | +17.5 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +76 | +25.5 |
| CAST JOB | 6 | 6 | 2 | 0.67 | +9 | +4.7 |
| CHAFF IN THE MOVE | 3 | 2 | 2 | 0.67 | +0 | +0.0 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FEATURE BUFFS | 6 | 6 | 2 | 0.67 | +35 | +17.7 |
| HIS MOVE AND SHOT | 38 | 38 | 2 | 0.67 | +12 | +5.8 |
| HIS TURN DENIED | 8 | 8 | 2 | 0.67 | +30 | +15.0 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +230 | +114.9 |
| NEARER NOT NEEDED | 38 | 35 | 2 | 0.67 | +29 | +14.6 |
| NO DOUBLE ROUNDS | 17 | 17 | 2 | 0.67 | +90 | +44.8 |
| RANDOM MOVE BY FIGURES | 8 | 8 | 2 | 0.67 | +54 | +26.9 |
| RISK BY ARC | 16 | 15 | 2 | 0.67 | +31 | +15.7 |
| STAY WORTH | 69 | 59 | 2 | 0.67 | +16 | +7.8 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +81 | +80.9 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -5 | -5.4 |
| BLOWS WHERE AIMED | 2 | 2 | 1 | 0.33 | +1 | +1.2 |
| CANNON PLANNED TARGET | 8 | 8 | 1 | 0.33 | +0 | +0.0 |
| CANNON SIGHT KEPT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CARRIES OUT SET-UP | 1 | 1 | 1 | 0.33 | -18 | -18.5 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 10 | 9 | 1 | 0.33 | +1 | +1.2 |
| FALL BACK GOOD ORDER | 14 | 13 | 1 | 0.33 | +29 | +29.0 |
| FALLS SHORT | 62 | 50 | 1 | 0.33 | +8 | +8.2 |
| HONEST WORTH | 17 | 16 | 1 | 0.33 | +21 | +20.8 |
| HORN WORTH | 1 | 1 | 1 | 0.33 | +21 | +20.6 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +51 | +50.6 |
| MANOEUVRE | 16 | 16 | 1 | 0.33 | +36 | +36.2 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -46 | -46.5 |
| MISSILES IN THE MOVE | 27 | 16 | 1 | 0.33 | +2 | +1.9 |
| MISSILES NEXT TURN | 35 | 22 | 1 | 0.33 | +2 | +1.9 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| ONE OBJECTIVE FORMULA | 23 | 15 | 1 | 0.33 | +18 | +18.3 |
| OVERRUNS AWAY | 9 | 8 | 1 | 0.33 | +6 | +5.7 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +15 | +14.7 |
| PROMISE KNOWS THE FIGHT | 5 | 5 | 1 | 0.33 | -6 | -5.6 |
| PROMISE READS THE TABLE | 6 | 6 | 1 | 0.33 | +19 | +18.8 |
| REDIRECT COUNTER | 6 | 6 | 1 | 0.33 | +0 | +0.0 |
| SEARCH SPOT | 1 | 1 | 1 | 0.33 | +8 | +7.5 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +7 | +6.8 |
| SET CREDITED ONCE | 15 | 15 | 1 | 0.33 | +4 | +3.6 |
| SHOTS AFTER THE MOVES | 18 | 18 | 1 | 0.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 79 | 56 | 1 | 0.33 | +11 | +11.4 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +22 | +22.3 |
| SURE REACH TOGETHER | 6 | 4 | 1 | 0.33 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 13 | 1 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -36 | -36.0 |
| WHO FIGHTS | 4 | 3 | 1 | 0.33 | +6 | +6.2 |
| BACKUP TARGETS | 2 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 4 | trace | - | - | - | - |
| CHARACTER GUNS | 19 | 17 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 52 | 50 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 47 | not checked | - | - | - | - |
| FOOT FIRST | 62 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 40 | 39 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 8 | 8 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 12 | 12 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 85 | 83 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 43 | 42 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 21 | 21 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 46 | 43 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 50 | 45 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 32 | 31 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 6 | 6 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 83 | 82 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 14 | 13 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 12 | 11 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 3 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 6 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 2 | trace | - | - | - | - |
| NEAREST TO GOAL | 6 | 6 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 40 | 20 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 243 | trace | - | - | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 11 | 10 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 8 | 7 | 0 | 0.00 | - | - |
| RUN DOWN | 15 | 14 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET UP TOGETHER | 3 | 3 | 0 | 0.00 | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 29 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 17 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 42 | 37 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 6 | 6 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 15 | 14 | 0 | 0.00 | - | - |
| STANDS STILL | 184 | 181 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 5 | 5 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 11 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 17 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 13 | not checked | - | - | - | - |
| THE TABLE BINDS | 251 | not checked | - | - | - | - |
| WAITS AGAIN | 9 | 7 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | not checked | - | - | - | - |
| WHOLE FIGHT | 1 | not checked | - | - | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 13 | 13 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p81

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.33 | 4.33 | 27.9 |
| PROMISE BY ITS OWN SUM | rule | 3.33 | 3.33 | 57.7 |
| ARMY TABLE | rule | 3.33 | 2.67 | 38.7 |
| CHARGE NOW FIRST | rule | 1.00 | 0.67 | 27.0 |
| ONE PROMISE A TARGET | rule | 1.00 | - | 16.9 |
| PROMISE SHOT AWAY | rule | 1.00 | - | 1.2 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.33 | 25.8 |
| BEST PRIZE | rule | 0.33 | - | 5.4 |
| CARRIES OUT SET-UP | rule | 0.33 | - | 18.5 |
| MARCH OF THE TABLE | rule | - | 0.33 | 46.5 |
| NO REASON | gate | 0.33 | - | 61.4 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | - | 5.6 |
| TURN GATE | gate | - | 0.33 | 8.0 |
| WALKS ON ITS ROUTE | rule | 0.33 | - | 36.0 |

### Plans: gs3-83c8646-p81

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.0 | 33% | 499 | 135 | 27% |
| Mine | move | 32.7 | 97% | 2633 | 0 | 0% |
| Mine | shoot | 3.7 | 55% | 154 | 73 | 48% |
| Opponent | charge | 1.3 | 50% | 309 | 98 | 32% |
| Opponent | join | 1.7 | 100% | 97 | 0 | 0% |
| Opponent | move | 34.3 | 96% | 1675 | 0 | 0% |
| Opponent | shoot | 4.0 | 33% | 95 | 132 | 139% |
| Opponent | support | 0.3 | 100% | 0 | 0 | - |

### Battle groups: gs3-83c8646-p81

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.3 | 25% | 100% | 100% | 0% | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 0.7 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p81

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 94 (2) | 0 | 94 | 50 | 0% | 2.0 | 188 (1) | 0 (1) | - | 0 (1) | 188 (1) |
| Mine | Character | 8 | 29 (8) | 29 | 0 | 0 | 12% | 2.6 | 42 (4) | 20 (4) | - | 42 (6) | 0 (2) |
| Mine | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 0% | 6.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 3 | 0 (3) | 0 | 0 | 15 | 33% | 4.0 | 0 (3) | - | - | 0 (3) | - |
| Mine | Hammer | 4 | 17 (4) | 0 | 17 | 0 | 25% | 4.3 | 27 (3) | - | 0 (1) | 0 (3) | 70 (1) |
| Mine | Shooter | 7 | 74 (7) | 25 | 49 | 42 | 0% | 1.9 | 78 (3) | 66 (3) | 82 (1) | 78 (3) | 70 (4) |
| Mine | Support | 4 | 58 (4) | 58 | 0 | 0 | 0% | 2.8 | - | 0 (1) | 101 (3) | 58 (4) | - |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 50 | 0% | 1.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | - | 0 (1) | 0 (1) | - |
| Opponent | Chaff | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (2) | - | - | 0 (1) | 0 (1) |
| Opponent | Character | 10 | 6 (10) | 6 | 0 | 17 | 10% | 2.7 | 10 (5) | 0 (3) | 0 (1) | 0 (4) | 9 (5) |
| Opponent | Fast Hammer | 5 | 32 (5) | 14 | 17 | 15 | 0% | 2.0 | 21 (2) | 39 (3) | - | 20 (4) | 60 (1) |
| Opponent | Hammer | 10 | 14 (10) | 14 | 0 | 20 | 50% | 3.6 | 22 (6) | 0 (3) | 0 (1) | 24 (6) | 0 (4) |
| Opponent | Holder | 3 | 0 (3) | 0 | 0 | 29 | 67% | 4.0 | - | - | 0 (3) | 0 (1) | 0 (2) |
| Opponent | Shooter | 5 | 45 (5) | 34 | 11 | 31 | 0% | 1.4 | 77 (2) | 0 (2) | 48 (1) | 66 (3) | 0 (2) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | - | 0 (1) | - | 0 (1) |

### Charged fights: gs3-83c8646-p81

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 1 | 140 | 216 | 4.0 | 1.0 | 54 | 15 | +39 | 1 of 4 | 3 of 4 | - | +39 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 234 | 3.0 | 1.0 | 78 | 27 | +51 | 1 of 3 | 2 of 3 | - | +51 |
| Mine | Lizardmen | 1 | 195 | 120 | 2.0 | 1.0 | 60 | 0 | +60 | 1 of 2 | 1 of 2 | - | +60 |
| **Mine** | all armies | 3 | 112 | 190 | 3.0 | 1.0 | 63 | 16 | +48 | 3 of 9 | 6 of 9 | - | +48 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 4.0 | 1.0 | 0 | 0 | +0 | 0 of 4 | 2 of 4 | - | +0 |
| Opponent | Wood Elf Realms | 2 | 138 | 58 | 3.0 | 1.0 | 19 | 17 | +2 | 0 of 6 | 4 of 6 | - | +2 |
| **Opponent** | all armies | 3 | 92 | 38 | 3.3 | 1.0 | 12 | 10 | +1 | 0 of 10 | 6 of 10 | - | +1 |

### Effective charges: gs3-83c8646-p81

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 4 | 1 (net -60) | 0 | 0 | 0 | 2 (net +57) | 0 | 1 | 0% (0 of 3) |
| Mine | Kingdom of Bretonnia | 3 | 0 | 0 | 0 | 0 | 0 | 3 (net +51) | 0 | 0% (0 of 3) |
| Mine | Lizardmen | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Warriors of Chaos | 4 | 0 | 1 (net +0) | 0 | 1 (net +0) | 0 | 1 (net +0) | 1 | 0% (0 of 3) |
| Opponent | Wood Elf Realms | 6 | 0 | 0 | 0 | 0 | 2 (net +58) | 1 (net +0) | 3 | 0% (0 of 3) |

### Charged fights, damage counted: gs3-83c8646-p81

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 230 | 180 | -30 | 170 | 144 | +26 | +11.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 308 | 184 | +51 | 146 | 50 | +97 | +31.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 497 | 108 | +57 | 88 | 0 | +88 | +17.7 |
| Mine | No odds | 2 | 341 | 111 | +111 | 111 | 0 | +111 | +32.6 |
| Mine | All fights | 9 | 340 | 150 | +48 | 131 | 49 | +82 | +24.2 |
| Opponent | 50-54% | 1 | 120 | 141 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 76-89% | 1 | 116 | 49 | +0 | 24 | 0 | +24 | +21.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 308 | 124 | +0 | 24 | 39 | -15 | -4.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 499 | 120 | +58 | 102 | 0 | +102 | +20.5 |
| Opponent | No odds | 4 | 83 | 186 | -26 | 11 | 26 | -15 | -18.0 |
| Opponent | All fights | 10 | 218 | 142 | +1 | 32 | 18 | +14 | +6.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p81 | move | 28 | 6 (21%) | 6 (21%) | 4 (14%) | 18 (64%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Horn of the Wild Hunt | Opponent | L1633 |
| Ring of Doom | Mine | L1535 |
| Ring of Doom | Opponent | L1633, L1731 |

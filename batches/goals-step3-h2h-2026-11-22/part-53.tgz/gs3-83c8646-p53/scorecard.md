# Doctrine scorecard: gs3-83c8646-p53

### Scorecard: gs3-83c8646-p53

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0717 | 3 | 1 | Mine | no | 0 | 4 | 1 | 2 | 0 | 0 | 0 | 375 |
| L0717 | 3 | 1 | Opponent | yes | 13 | 5 | 0 | 2 | 0 | 0 | 0 | 141 |
| L0733 | 1 | 1 | Mine | no | 9 | 3 | 0 | 1 | 0 | 0 | 0 | 183 |
| L0733 | 1 | 1 | Opponent | no | 7 | 4 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 3 | 4 | 1 | 1 | 0 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 0 | 1 | 1 | 4 | 2 | 0 | 0 | 261 |
| **Average** | | | Mine | 0% | 4.0 | 3.7 | 0.7 | 1.3 | 0.0 | 0.0 | 0.0 | 357.7 |
| **Average** | | | Opponent | 33% | 6.7 | 3.3 | 1.0 | 3.0 | 0.7 | 0.0 | 0.0 | 134.0 |

### KPIs: gs3-83c8646-p53

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 88% (14 of 16) | 0% (0 of 12) | 50% (14 of 28) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | 100% (4 of 4); on the table 100% | 100% (6 of 6); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | 100% (1 of 1); on the table 100% | 50% (1 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 67% (2 of 3); on the table 67% | 100% (6 of 6); on the table 100% | 89% (8 of 9); on the table 89% |
| Magic missiles tried each own turn | 50%+ | 58% (7 of 12) | 33% (4 of 12) | 46% (11 of 24) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 64% (7 of 11) | 33% (4 of 12) | 48% (11 of 23) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 71% (4243 of 5998) | 72% (4292 of 6000) | 71% (8535 of 11998) |
|   infantry points that never fought | lower | 48% (344 of 715) | 94% (1335 of 1418) | 79% (1679 of 2133) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 63% (19 of 30) | 73% (16 of 22) | 67% (35 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (2 of 2); 3.0 uses a game | 100% (2 of 2); 1.5 uses a game |
| Bound items with another spell used |  | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 3); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 4); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 54% (2904 of 5389) | 69% (3454 of 5023) | 61% (6358 of 10412) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (75%) | 2.0 (46%) |
| MARCHED: its unit marched | 1.0 (60%) | 0.7 (25%) | 1.7 (38%) |
| CHARGED: its unit charged | 0.3 (20%) | 0.0 (0%) | 0.3 (8%) |
| GONE: slain | 0.3 (20%) | 0.0 (0%) | 0.3 (8%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 5.0 | 1.3 | 3.7 | 0.3 | 0.0 |
| not cast | 3.0 | 0.7 | 4.3 | 1.7 | 12.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (50%) | 2.0 (46%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.7 (38%) | 0.7 (40%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.3 (8%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.3 (50%) | 0.3 (8%) | 0.0 (0%) | 0.7 (6%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (60%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.0 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 11.3 (94%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 76% (73 of 96) | 74% (67 of 91) | 75% (140 of 187) |
|   cavalry | 80% (8 of 10) | 71% (10 of 14) | 75% (18 of 24) |
|   character | - | 62% (8 of 13) | 62% (8 of 13) |
|   chariot | 75% (3 of 4) | - | 75% (3 of 4) |
|   infantry | 58% (14 of 24) | 85% (47 of 55) | 77% (61 of 79) |
|   monster | - | 22% (2 of 9) | 22% (2 of 9) |
|   war machine | 83% (48 of 58) | - | 83% (48 of 58) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.3 (43%) | 0.7 (8%) | 4.0 (26%) |
| CHARGED: it charged | 0.0 (0%) | 1.3 (17%) | 1.3 (9%) |
| IN COMBAT: it fought this turn or the last | 0.3 (4%) | 0.3 (4%) | 0.7 (4%) |
| MOVED: a war machine that moved | 1.0 (13%) | 0.0 (0%) | 1.0 (6%) |
| NO TARGET IN RANGE | 0.3 (4%) | 3.3 (42%) | 3.7 (23%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (4%) | 1.7 (21%) | 2.0 (13%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (13%) | 0.7 (8%) | 1.7 (11%) |
| SHELTERED: the target was sheltered | 0.7 (9%) | 0.0 (0%) | 0.7 (4%) |
| OTHER BAR | 0.7 (9%) | 0.0 (0%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 8.0 | 5.0 | 62% | 14.6 pts | 117 pts |
| character | 2.7 | 0.7 | 75% | 5.2 pts | 14 pts |
| chariot | 1.0 | 0.3 | 67% | 16.3 pts | 16 pts |
| infantry | 30.0 | 8.0 | 78% | 8.1 pts | 244 pts |
| monster | 0.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 16.0 | 17.7 | 50% | 43.6 pts | 698 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.7 | 2.3 | 2.0 |
| Charges that made contact a game | 1.0 | 1.0 | 1.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.00 contact (2 units) | - | 0.50 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.17 declared, 0.13 contact (23 units) | 0.24 declared, 0.10 contact (29 units) | 0.21 declared, 0.12 contact (52 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (6 of 9) | 33% (1 of 3) | - | 58% (7 of 12) |
| Character in a unit | 100% (5 of 5) | - | 0% (0 of 1) | 83% (5 of 6) |
| Character on its own | 100% (4 of 4) | 100% (1 of 1) | 50% (3 of 6) | 73% (8 of 11) |
| Chariot | - | 0% (0 of 1) | - | 0% (0 of 1) |
| Infantry | 50% (1 of 2) | 33% (1 of 3) | 0% (0 of 1) | 33% (2 of 6) |
| Monster | 100% (5 of 5) | - | - | 100% (5 of 5) |
| Monstrous | 100% (1 of 1) | - | - | 100% (1 of 1) |
| War Machines | 70% (7 of 10) | - | - | 70% (7 of 10) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 3 | 67% (2 of 3); on the table 67% | 58% (7 of 12) | 71% | 63% (19 of 30) | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| Lizardmen | 1 | 100% (1 of 1); on the table 100% | - | 76% | 100% (7 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 65% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (4 of 4); on the table 100% | 67% (4 of 6) | 74% | 60% (6 of 10) | 100% (2 of 2); 9.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p53, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (2) | 0% (0) | 67% (2) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.00 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.00 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.33 | 0.67 |

### Quality by phase: gs3-83c8646-p53

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.3 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 50% (2 of 4) | 33% (1 of 3) |
| Strategy | Shoot objectives carried out (shot that target) | 24% (16 of 67) | 77% (10 of 13) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 33% (1 of 3) | - |
| Strategy | Joined characters whose unit fought | 50% (2 of 4) | 25% (1 of 4) |
| Strategy | Lone characters that fought | 11% (1 of 9) | 33% (2 of 6) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.3 | 3.0 |
| Movement | Points that never moved of their own | 357.7 | 134.0 |
| Movement | Fights charged into per game | 1.0 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 2 | 0 of 1 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 2, net -199 | 0 of 1 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 2, net +185 | 0 of 1 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.0 | 24.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 37% (10 of 27) | 48% (35 of 73) |
| Shooting | Points destroyed by shooting units | 310.0 | 0.0 |
| Shooting | War machine shots | 16.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 60% (29 of 48) | - |
| Shooting | Points destroyed by war machines | 336.3 | 0.0 |
| Magic | Magic missiles cast | 1.7 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 40% (2 of 5) | 0% (0 of 2) |
| Magic | Wounds caused by magic missiles | 4.3 | 2.7 |
| Magic | Points destroyed by magic (all spells) | 63.7 | 126.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.3 / 1.0 / 0.0 / 0.0 | 3.0 / 0.0 / 0.0 / 0.3 |
| Combat | Points destroyed in combat | 22.0 | 247.3 |
| Combat | Points run down | 110.7 | 0.0 |
| Combat | Net points per charged fight, damage counted | -20 | +182 |
| Combat | Net per 100 charger points, damage counted | -8.8 | +182.7 |
| Combat | First round won (charged fights) | 100% | 100% |
| Combat | Net points per charged fight | -5 | +257 |
| Combat | Net points per supported fight / lone fight | - / -5 | - / +257 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 3 | 3 of 3 |
| Game | Points lost | 497.0 | 765.7 |
| Game | VP from objectives | 760.0 | 980.0 |
| Game | Lone holders (player turns) | 4.0 | 6.7 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) +123 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 1263
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p53

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 36.0 |
| ARMY TABLE | 20.3 | +481.8 | 0.0 | 150.7 | 30.3 | +702.8 | 0.0 | 219.3 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 8.7 | +0.0 | 0.0 | 128.3 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +0.4 | 0.0 | 54.7 | - | - | - | - |
| CANNON PLAN MISSED | 3.3 | +0.0 | 1051.3 | 85.0 | - | - | - | - |
| CANNON PLANNED TARGET | 16.0 | +852.3 | 2971.7 | 170.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 3.0 | +251.6 | 127.3 | 126.7 | 0.3 | +5.9 | 63.0 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 0.3 | +0.5 | 0.0 | 22.0 |
| CHAFF PASSED | - | - | - | - | 0.3 | -4.0 | 0.0 | 0.0 |
| CHARACTER GUNS | - | - | - | - | 6.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 16.7 | -1144.5 | 0.0 | 428.0 | 23.7 | -1697.0 | 0.0 | 1128.0 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 27.7 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 6.0 | +0.0 | 0.0 | 0.0 | 18.3 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 88.3 | - | - | - | - |
| COVER ONCE | 12.7 | -752.7 | 0.0 | 150.7 | 8.7 | -527.7 | 0.0 | 306.7 |
| DENIED BY THE FIGHT | 0.3 | -5.7 | 27.7 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.7 | -71.5 | 0.0 | 0.0 | 8.7 | +28.7 | 0.0 | 101.0 |
| DUEL STOPS AT THE KILL | 0.3 | +1.9 | 61.7 | 0.0 | - | - | - | - |
| EXACT ROUND | 0.3 | +0.3 | 22.0 | 0.0 | 1.0 | +42.8 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.3 | +0.0 | 173.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| FALLBACK BY WORTH | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | - | - | - | - | 22.0 | +297.9 | 0.0 | 419.0 |
| FEATURE BUFFS | 0.7 | +9.1 | 0.0 | 192.0 | 0.3 | +0.2 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.7 | +11.2 | 0.0 | 0.0 |
| FIRE IN ORDER | 2.0 | +0.0 | 58.3 | 43.3 | - | - | - | - |
| FIVE ACTION | 113.7 | +9577.9 | 6880.3 | 1004.0 | 90.3 | +6275.7 | 607.0 | 1401.3 |
| FLANK NOT WEIGHED | 7.7 | +0.0 | 0.0 | 126.7 | 4.7 | +0.0 | 0.0 | 365.0 |
| FOLLOW UP WEIGHED | 0.3 | +18.9 | 0.0 | 0.0 | 0.3 | +88.7 | 0.0 | 0.0 |
| FOOT FIRST | 37.3 | +0.0 | 0.0 | 96.0 | - | - | - | - |
| FOUR ROUNDS | 1.7 | +60.8 | 173.0 | 0.0 | 1.0 | +86.3 | 0.0 | 0.0 |
| FREED FROM HIS FIGHT | 3.7 | +0.0 | 0.0 | 126.7 | 3.3 | +0.0 | 0.0 | 0.0 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -38.1 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -53.3 | 0.0 | 0.0 | 0.7 | -1.2 | 0.0 | 6.3 |
| FRIENDS SHOTS CHECKED | 0.3 | +11.3 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.3 | -3.8 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 8.3 | +618.1 | 0.0 | 0.0 | 17.7 | +1491.5 | 0.0 | 188.7 |
| GROUND FLIERS | 0.3 | +7.5 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| GUN MASK | 2.0 | +85.3 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 4.7 | +0.0 | 0.0 | 126.7 | 2.7 | +0.0 | 0.0 | 61.7 |
| HE REFORMS ONCE FREED | 0.3 | +0.0 | 0.0 | 126.7 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 12.0 | +0.0 | 0.0 | 192.0 | 14.3 | +0.0 | 0.0 | 939.3 |
| HIS CHARGE LIST | 5.7 | +0.0 | 0.0 | 54.7 | 7.0 | +0.0 | 0.0 | 12.7 |
| HIS LEGAL MOVES | 6.0 | +0.0 | 0.0 | 222.7 | 4.7 | +0.0 | 0.0 | 166.3 |
| HIS MOVE AND SHOT | 1.7 | -6.9 | 0.0 | 0.0 | 4.3 | -71.9 | 0.0 | 179.0 |
| HIS ONE QUARTER | 3.0 | +0.0 | 0.0 | 126.7 | 7.0 | +0.0 | 0.0 | 372.7 |
| HIS OWN BEST MOVE | 10.3 | +0.0 | 0.0 | 222.7 | 5.3 | +0.0 | 0.0 | 166.3 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 44.0 | +1879.1 | 0.0 | 428.0 | 66.0 | +3856.1 | 0.0 | 1139.3 |
| HIS SHOTS BY HIS RUN | 37.3 | +710.8 | 0.0 | 428.0 | 46.3 | +2264.2 | 0.0 | 1243.3 |
| HIS TURN DENIED | 0.3 | +7.7 | 27.7 | 0.0 | 0.3 | +2.5 | 0.0 | 0.0 |
| HOLD ODDS | 18.3 | +0.0 | 0.0 | 493.3 | 22.0 | +0.0 | 0.0 | 94.0 |
| HOLDER ASSIGNMENT | 12.7 | +1232.8 | 0.0 | 205.3 | 15.7 | +1338.3 | 0.0 | 94.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.7 | -39.8 | 173.0 | 0.0 | 0.7 | -23.9 | 0.0 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +3.0 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 14.7 | -213.6 | 0.0 | 215.7 |
| JOINT CHARGE NOW | 0.7 | -8.6 | 123.3 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 4.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +17.2 | 0.0 | 0.0 | 1.3 | +85.6 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.7 | +0.0 | 0.0 | 176.7 | 15.7 | +0.0 | 517.0 | 25.3 |
| LONE CHARACTER SAFE SPOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | 0.3 | +19.8 | 0.0 | 0.0 | 0.3 | +37.5 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.0 | +3.2 | 151.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| MANOEUVRE | 0.7 | +52.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +4.3 | 0.0 | 36.0 |
| MARCH BY THE SUM | 0.7 | +25.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | - | - | - | - | 1.3 | +61.2 | 0.0 | 36.0 |
| MARCH OF THE TABLE | 0.7 | +5.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | +34.1 | 0.0 | 0.0 | 0.7 | +31.5 | 0.0 | 36.0 |
| MAX FOR POSITIONING | 2.3 | +37.2 | 0.0 | 0.0 | 2.7 | +88.2 | 0.0 | 28.3 |
| MEETS IN TIME | 4.3 | +404.6 | 0.0 | 0.0 | 4.0 | +319.6 | 0.0 | 36.0 |
| MISSILES IN THE MOVE | 2.3 | +207.3 | 0.0 | 126.7 | 4.0 | +58.8 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 3.3 | +130.6 | 0.0 | 126.7 | 4.3 | +47.8 | 0.0 | 36.0 |
| MOVE ORDER | 3.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 12.7 | 0.0 |
| MOVE TO CHARGE COMPUTED | 4.7 | +485.5 | 0.0 | 0.0 | 2.3 | +307.6 | 0.0 | 166.3 |
| NEARER NOT NEEDED | 6.7 | +272.8 | 0.0 | 150.7 | 10.3 | +534.9 | 0.0 | 22.0 |
| NEAREST TO GOAL | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 3.7 | +252.5 | 0.0 | 0.0 | 2.0 | +201.2 | 0.0 | 166.3 |
| NEXT OBJECTIVE NEARER | 0.3 | -21.0 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 1.3 | -25.6 | 173.0 | 0.0 | 1.0 | -44.5 | 0.0 | 0.0 |
| NO LATE CUT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 3.0 | -1.1 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 5.3 | -238.4 | 0.0 | 54.7 | 6.0 | -157.2 | 0.0 | 179.0 |
| ONE FIGHT FORMULA | 4.3 | -127.4 | 0.0 | 0.0 | 4.0 | -103.2 | 0.0 | 346.3 |
| ONE OBJECTIVE FORMULA | 4.0 | -5.3 | 0.0 | 150.7 | 8.3 | -149.3 | 0.0 | 58.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 0.7 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 1.0 | +2.1 | 145.3 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 1.0 | -24.5 | 0.0 | 0.0 |
| PLAN RESULT | 52.7 | +2201.6 | 1564.3 | 876.0 | 41.0 | +199.1 | 181.3 | 1245.7 |
| PROMISE BELOW ZERO | - | - | - | - | 0.7 | +0.0 | 0.0 | 65.0 |
| PROMISE BY ITS OWN SUM | 5.3 | -75.7 | 0.0 | 0.0 | 7.0 | -182.1 | 0.0 | 166.3 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.3 | +0.0 | 0.0 | 166.3 |
| PROMISE READS THE TABLE | 0.7 | -53.3 | 0.0 | 0.0 | 0.7 | -1.2 | 0.0 | 6.3 |
| PROMISE SHOT AWAY | 0.7 | -45.0 | 72.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 30.7 | +2464.4 | 2649.7 | 426.7 | 20.7 | +2314.4 | 443.0 | 508.7 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | +67.7 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 2.0 | +54.8 | 0.0 | 28.3 |
| REDIRECT FOR A FRIEND IN REACH | 0.7 | +0.0 | 0.0 | 0.0 | 3.0 | +98.9 | 0.0 | 12.7 |
| REFORMS TO MEET IT | 0.7 | -16.9 | 0.0 | 0.0 | 0.3 | -0.6 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +6.1 | 0.0 | 0.0 |
| RISK BY ARC | 1.3 | +8.9 | 173.0 | 0.0 | 0.7 | -79.0 | 0.0 | 0.0 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | 0.3 | -7.2 | 61.7 | 0.0 | 0.3 | -3.2 | 0.0 | 0.0 |
| RUN DOWN | 1.3 | -10.3 | 151.0 | 0.0 | 0.3 | -5.3 | 0.0 | 0.0 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +1.8 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +10.0 | 0.0 | 0.0 | - | - | - | - |
| SECOND LOOK | 0.3 | +2.5 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.7 | -8.6 | 0.0 | 0.0 | 2.7 | -246.6 | 0.0 | 19.0 |
| SET UP BY THE SET | 0.7 | +0.8 | 0.0 | 0.0 | 3.3 | +172.2 | 0.0 | 185.3 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +3.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 26.3 | +0.0 | 0.0 | 351.3 | 5.7 | +0.0 | 0.0 | 83.7 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +15.9 | 0.0 | 0.0 | 1.3 | +88.8 | 0.0 | 123.3 |
| SHORT GUN FORWARD | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 33.7 | +8.4 | 0.0 | 428.0 | 38.3 | +588.6 | 0.0 | 898.0 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 26.3 | +1745.1 | 0.0 | 279.3 | 21.0 | +405.9 | 0.0 | 322.0 |
| SPELL WORTH | 1.0 | +6.8 | 0.0 | 0.0 | 4.0 | +95.6 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 76.3 |
| STAND AND SHOOT | 1.0 | -5.0 | 111.3 | 0.0 | 0.3 | -4.8 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 6.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 66.3 | +0.0 | 6707.3 | 576.0 | 21.7 | +0.0 | 607.0 | 275.3 |
| STAY WORTH | 56.3 | +614.8 | 4544.7 | 561.3 | 16.0 | +120.7 | 480.3 | 216.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.7 | +234.9 | 96.0 | 0.0 |
| SUPPORT ADDS | 6.7 | +680.7 | 0.0 | 109.3 | 4.3 | +622.1 | 0.0 | 28.3 |
| SUPPORT WORKED OUT | 6.7 | +680.7 | 0.0 | 109.3 | 4.3 | +622.1 | 0.0 | 28.3 |
| SURE REACH TOGETHER | 0.3 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2.3 | +0.0 | 0.0 | 54.7 | 2.0 | +0.0 | 0.0 | 36.0 |
| THE ROW IN ITS ORDER | 3.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 12.7 |
| THE ROW KEEPS ITS WAY | 2.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 58.3 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 58.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 57.3 | +0.0 | 0.0 | 502.0 | 43.3 | +0.0 | 0.0 | 700.7 |
| TIED UP BY THE SUM | 1.0 | +78.9 | 49.7 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 41.3 | +498.2 | 0.0 | 205.3 | - | - | - | - |
| WAITS AGAIN | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | - | - | - | - | 0.3 | +235.2 | 0.0 | 0.0 |
| WHO HITS BACK | 0.3 | +88.6 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 3.0 | -692.5 | 0.0 | 126.7 | 3.7 | -192.6 | 0.0 | 692.7 |
| WOUNDS ON THE RANKS | 6.7 | +142.9 | 0.0 | 192.0 | 2.7 | +110.5 | 0.0 | 72.0 |

### Rule changes: gs3-83c8646-p53

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 152 | 152 | 106 | 35.33 | +2637 | +24.9 |
| HIS SHOT LIST | 330 | 323 | 101 | 33.67 | +2844 | +28.2 |
| HOLDER ASSIGNMENT | 85 | 85 | 74 | 24.67 | +3957 | +53.5 |
| LEGAL CHARGES ONLY | 61 | 61 | 61 | 20.33 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 251 | 243 | 53 | 17.67 | +706 | +13.3 |
| SHOT RISK POINTS | 216 | 210 | 42 | 14.00 | +1810 | +43.1 |
| OFF BEST | 34 | 34 | 34 | 11.33 | -1187 | -34.9 |
| DEPLOY BY FIGURES | 52 | 52 | 33 | 11.00 | +478 | +14.5 |
| FIVE ACTION | 612 | 601 | 29 | 9.67 | +1758 | +60.6 |
| ARTILLERY RE-ROLL WEIGHED | 26 | 26 | 26 | 8.67 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 24 | 8.00 | +0 | +0.0 |
| MOVE ORDER | 23 | 23 | 23 | 7.67 | +0 | +0.0 |
| HARD STAY DROPPED | 22 | 22 | 22 | 7.33 | +0 | +0.0 |
| TIME ON OUR SIDE | 124 | 101 | 21 | 7.00 | +61 | +2.9 |
| GOAL WALK | 78 | 78 | 17 | 5.67 | +646 | +38.0 |
| SUPPORT ADDS | 33 | 33 | 15 | 5.00 | +798 | +53.2 |
| SUPPORT WORKED OUT | 33 | 33 | 15 | 5.00 | +798 | +53.2 |
| QUARTER ODDS | 154 | 153 | 14 | 4.67 | +996 | +71.1 |
| STAY WORTH | 217 | 195 | 13 | 4.33 | +327 | +25.1 |
| PROMISE BY ITS OWN SUM | 37 | 37 | 11 | 3.67 | -773 | -70.3 |
| REDIRECT FOR A FRIEND IN REACH | 11 | 11 | 11 | 3.67 | +239 | +21.8 |
| CAST JOB | 10 | 10 | 10 | 3.33 | +493 | +49.3 |
| MOVE TO CHARGE COMPUTED | 21 | 20 | 10 | 3.33 | +666 | +66.6 |
| CHARGE LOSSES | 121 | 118 | 9 | 3.00 | +74 | +8.3 |
| MEETS IN TIME | 25 | 25 | 9 | 3.00 | +266 | +29.5 |
| WOUNDS ON THE RANKS | 28 | 28 | 9 | 3.00 | +109 | +12.1 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| COVER ONCE | 64 | 42 | 6 | 2.00 | +106 | +17.7 |
| FIRE IN ORDER | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 17 | 16 | 6 | 2.00 | +149 | +24.8 |
| SHOOTS FROM THE BEST SPOT | 6 | 6 | 6 | 2.00 | +248 | +41.3 |
| SHOTS AFTER THE MOVES | 28 | 28 | 6 | 2.00 | +0 | +0.0 |
| CANNON PLANNED TARGET | 48 | 48 | 5 | 1.67 | -51 | -10.2 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +308 | +61.7 |
| MAX FOR POSITIONING | 15 | 14 | 5 | 1.67 | +57 | +11.5 |
| MISSILES IN THE MOVE | 19 | 13 | 4 | 1.33 | +241 | +60.2 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| IDLE COST | 44 | 23 | 3 | 1.00 | +25 | +8.4 |
| MARCH CHECK | 4 | 4 | 3 | 1.00 | +125 | +41.6 |
| PIVOT GUARDS FLANK | 3 | 3 | 3 | 1.00 | -73 | -24.5 |
| REDIRECT COUNTER | 6 | 4 | 3 | 1.00 | +63 | +20.9 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +323 | +161.4 |
| FOUR ROUNDS | 8 | 7 | 2 | 0.67 | +57 | +28.6 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | -26 | -12.8 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +172 | +86.0 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +77 | +38.6 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -16 | -8.2 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -135 | -67.5 |
| SEARCH SPOT | 2 | 2 | 2 | 0.67 | +30 | +15.0 |
| SET CREDITED ONCE | 10 | 10 | 2 | 0.67 | +40 | +20.2 |
| SET UP BY THE SET | 12 | 12 | 2 | 0.67 | +128 | +64.1 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +9 | +4.5 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +120 | +60.0 |
| THE ROW IN ITS ORDER | 22 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 20 | 20 | 2 | 0.67 | +332 | +166.2 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -12 | -11.9 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 4 | 4 | 1 | 0.33 | +19 | +18.6 |
| FEATURE BUFFS | 3 | 3 | 1 | 0.33 | +7 | +7.4 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +34 | +34.0 |
| GUN MASK | 6 | 6 | 1 | 0.33 | +44 | +44.0 |
| HOLDS AMBUSHERS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| MANOEUVRE | 2 | 2 | 1 | 0.33 | +157 | +156.6 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +18 | +18.3 |
| RISK BY ARC | 6 | 6 | 1 | 0.33 | +26 | +26.5 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +8 | +7.6 |
| SHORT GUN FORWARD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +2 | +1.8 |
| TIED UP BY THE SUM | 3 | 2 | 1 | 0.33 | +26 | +26.5 |
| WHO FIGHTS | 1 | 1 | 1 | 0.33 | +114 | +114.5 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +142 | +142.2 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 10 | 10 | 0 | 0.00 | - | - |
| CHAFF IN THE MOVE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 19 | 16 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 2 | 2 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 73 | 71 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 6 | 6 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 2 | 2 | 0 | 0.00 | - | - |
| FALLS SHORT | 66 | 60 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 37 | not checked | - | - | - | - |
| FOOT FIRST | 112 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 21 | 20 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP | 1 | not checked | - | - | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 3 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 79 | 77 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 38 | 38 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 32 | 31 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 18 | 17 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 30 | 29 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 47 | 45 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HOLD ODDS | 121 | 121 | 0 | 0.00 | - | - |
| HONEST WORTH | 7 | 6 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 20 | 20 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LOST AFTER ESCAPE | 4 | 4 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 23 | 17 | 0 | 0.00 | - | - |
| NEARER NOT NEEDED | 51 | 49 | 0 | 0.00 | - | - |
| NEAREST TO GOAL | 4 | 4 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 7 | 7 | 0 | 0.00 | - | - |
| NO LATE CUT | 5 | 5 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 9 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 25 | 14 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 37 | 29 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS A LANE | 2 | 2 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 4 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 281 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 4 | 4 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 3 | 3 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 5 | 4 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 96 | not checked | - | - | - | - |
| SHOTS IN THE MOVE | 142 | 102 | 0 | 0.00 | - | - |
| SPELL WORTH | 15 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 38 | 36 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 20 | 20 | 0 | 0.00 | - | - |
| STANDS STILL | 264 | 261 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 13 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 15 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 8 | not checked | - | - | - | - |
| THE TABLE BINDS | 302 | not checked | - | - | - | - |
| WAITS AGAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p53

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.67 | 6.00 | 35.8 |
| ARMY TABLE | rule | 2.33 | 3.00 | 25.5 |
| PROMISE BY ITS OWN SUM | rule | 1.33 | 2.33 | 70.3 |
| HOLDER ASSIGNMENT | rule | 0.67 | 1.00 | 15.6 |
| PIVOT GUARDS FLANK | rule | - | 1.00 | 24.5 |
| CANNON PLANNED TARGET | rule | 0.67 | - | 25.5 |
| MARCH OF THE TABLE | rule | 0.67 | - | 8.2 |
| PROMISE SHOT AWAY | rule | 0.67 | - | 67.5 |
| CHAFF PASSED | rule | - | 0.33 | 11.9 |
| FIGHT ORDER BAND | gate | 0.33 | - | 0.7 |
| JOINT CHARGE NOW | rule | 0.33 | - | 39.7 |
| NO REASON | gate | 0.33 | - | 41.7 |

### Plans: gs3-83c8646-p53

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 33% | 47 | 36 | 76% |
| Mine | join | 3.3 | 100% | 36 | 0 | 0% |
| Mine | move | 29.3 | 98% | 1858 | 0 | 0% |
| Mine | shoot | 19.0 | 82% | 1650 | 2166 | 131% |
| Opponent | charge | 0.7 | 0% | 67 | 29 | 44% |
| Opponent | join | 0.3 | 100% | 3 | 0 | 0% |
| Opponent | move | 36.0 | 91% | 2343 | 0 | 0% |
| Opponent | shoot | 3.7 | 64% | 262 | 170 | 65% |
| Opponent | support | 0.3 | 100% | 58 | 0 | 0% |

### Battle groups: gs3-83c8646-p53

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 2.0 | 50% | 67% | 0% | - | 33% | 0% | 0% | 67% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p53

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | Character | 12 | 28 (12) | 28 | 0 | 21 | 67% | 2.0 | 12 (7) | 74 (3) | 0 (2) | 9 (7) | 64 (5) |
| Mine | Clean-up | 1 | 55 (1) | 0 | 55 | 0 | 0% | 5.0 | - | 55 (1) | - | 55 (1) | - |
| Mine | Fast Hammer | 8 | 79 (8) | 48 | 31 | 31 | 50% | 3.0 | 127 (4) | 0 (3) | 76 (1) | 149 (4) | 0 (4) |
| Mine | Hammer | 2 | 25 (2) | 10 | 14 | 42 | 0% | 1.5 | - | 25 (1) | 24 (1) | 25 (2) | - |
| Mine | Shooter | 5 | 105 (5) | 41 | 64 | 35 | 0% | 1.6 | 78 (2) | 192 (1) | 39 (2) | 137 (3) | 39 (2) |
| Mine | War machine | 10 | 80 (10) | 80 | 0 | 20 | 0% | 1.5 | 2 (8) | 396 (2) | - | 0 (1) | 89 (9) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | - | 0 (1) | 0 (1) | - |
| Opponent | Chaff | 4 | 0 (4) | 0 | 0 | 61 | 25% | 1.7 | 0 (3) | 0 (1) | - | 0 (4) | - |
| Opponent | Character | 9 | 22 (9) | 22 | 0 | 44 | 33% | 1.8 | 0 (1) | 31 (5) | 19 (3) | 35 (5) | 0 (4) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | 0 (2) | 0 (1) | - | 0 (1) | 0 (2) |
| Opponent | Fast Hammer | 5 | 37 (5) | 37 | 0 | 63 | 60% | 3.5 | 0 (1) | 100 (2) | 0 (2) | 0 (3) | 100 (2) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 100 | 100% | - | - | - | - | - | - |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 61 | 67% | 1.0 | - | 0 (1) | 0 (2) | - | 0 (3) |
| Opponent | Holder | 3 | 234 (3) | 0 | 234 | 0 | 33% | 1.0 | 450 (1) | 136 (2) | - | 375 (2) | 0 (1) |
| Opponent | Shooter | 7 | 167 (7) | 38 | 129 | 27 | 0% | 1.1 | 69 (2) | 143 (3) | 286 (2) | 203 (3) | 126 (4) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | - | 0 (1) | - | 0 (1) |

### Charged fights: gs3-83c8646-p53

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 3 | 710 | 84 | 1.0 | 1.0 | 84 | 88 | -5 | 0 of 3 | 3 of 3 | - | -5 |
| Opponent | Lizardmen | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 294 | 1.0 | 1.0 | 294 | 0 | +294 | 1 of 1 | 1 of 1 | - | +294 |
| Opponent | Wood Elf Realms | 1 | 380 | 477 | 2.0 | 1.0 | 238 | 0 | +238 | 2 of 2 | 2 of 2 | - | +238 |
| **Opponent** | all armies | 3 | 127 | 257 | 1.0 | 1.0 | 257 | 0 | +257 | 3 of 3 | 3 of 3 | - | +257 |

### Effective charges: gs3-83c8646-p53

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 3 | 0 | 0 | 0 | 0 | 1 (net -199) | 1 (net +185) | 1 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 0 | 0 | 1 (net +294) | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: gs3-83c8646-p53

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 189 | 83 | +185 | 400 | 231 | +169 | +89.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 265 | 66 | -199 | 92 | 332 | -240 | -90.6 |
| Mine | No odds | 1 | 238 | 19 | +0 | 10 | 0 | +10 | +4.0 |
| Mine | All fights | 3 | 231 | 56 | -5 | 167 | 188 | -20 | -8.8 |
| Opponent | 76-89% | 1 | 195 | 371 | +294 | 480 | 358 | +121 | +62.1 |
| Opponent | No odds | 2 | 52 | 214 | +238 | 238 | 26 | +212 | +408.7 |
| Opponent | All fights | 3 | 100 | 266 | +257 | 319 | 137 | +182 | +182.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p53 | move | 13 | 1 (8%) | 1 (8%) | 0 (0%) | 12 (92%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Horn of the Wild Hunt | Opponent | L0733 |
| Ring of Doom | Opponent | L0733 |
| Twice-Blessed Armour | Mine | L0717, L0733 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |

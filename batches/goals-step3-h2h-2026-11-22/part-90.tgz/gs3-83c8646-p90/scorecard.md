# Doctrine scorecard: gs3-83c8646-p90

### Scorecard: gs3-83c8646-p90

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0926 | 2 | 1 | Mine | - | - | 3 | 3 | 1 | 0 | 0 | 0 | 45 |
| L0926 | 2 | 1 | Opponent | - | - | 4 | 2 | 5 | 0 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | no | 10 | 2 | 3 | 0 | 0 | 0 | 0 | 165 |
| L1017 | 3 | 1 | Opponent | no | 6 | 5 | 1 | 1 | 0 | 0 | 0 | 433 |
| L1034 | 2 | 1 | Mine | - | - | 3 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 3 | 4 | 5 | 0 | 0 | 0 | 107 |
| **Average** | | | Mine | 0% | 10.0 | 2.7 | 2.3 | 0.3 | 0.0 | 0.0 | 0.0 | 180.0 |
| **Average** | | | Opponent | 0% | 6.0 | 4.0 | 2.3 | 3.7 | 0.0 | 0.0 | 0.0 | 180.0 |

### KPIs: gs3-83c8646-p90

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 60% (9 of 15) | 0% (0 of 16) | 29% (9 of 31) |
| Winner chose to follow up after the loser gave ground |  | 100% (5 of 5); on the table 100% | 75% (3 of 4); on the table 75% | 89% (8 of 9); on the table 89% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | 100% (1 of 1); on the table 100% | 50% (1 of 2); on the table 50% |
| Winner chose to pursue after the loser fled |  | 75% (3 of 4); on the table 75% | - | 75% (3 of 4); on the table 75% |
| Winner chose to follow up or pursue (all three) |  | 80% (8 of 10); on the table 80% | 80% (4 of 5); on the table 80% | 80% (12 of 15); on the table 80% |
| Magic missiles tried each own turn | 50%+ | 37% (22 of 60) | 0% (0 of 6) | 33% (22 of 66) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 42% (22 of 53) | 0% (0 of 6) | 37% (22 of 59) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 36% (2157 of 5997) | 38% (2296 of 5998) | 37% (4453 of 11995) |
|   infantry points that never fought | lower | 30% (312 of 1052) | 38% (513 of 1363) | 34% (825 of 2415) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 50% (16 of 32) | 70% (14 of 20) | 58% (30 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 4.7 uses a game | 0.0 uses a game | 100% (4 of 4); 2.3 uses a game |
| Bound items with another spell used |  | 50% (1 of 2); 0.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (1 of 2); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 33% (1 of 3); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 44% (2561 of 5832) | 61% (3112 of 5116) | 52% (5673 of 10948) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 4.0 (32%) | 1.3 (67%) | 5.3 (36%) |
| MARCHED: its unit marched | 5.3 (42%) | 0.7 (33%) | 6.0 (41%) |
| IN COMBAT: engaged in combat | 2.3 (18%) | 0.0 (0%) | 2.3 (16%) |
| OTHER BAR: another bar (miscast, baggage ...) | 1.0 (8%) | 0.0 (0%) | 1.0 (7%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 3.7 | 3.0 | 7.3 | 1.7 | 2.0 |
| not cast | 0.0 | 2.3 | 1.0 | 14.7 | 4.3 | 22.0 |
| NOT CHOSEN: could have been cast at a target | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.7 (71%) | 0.0 (0%) | 5.3 (36%) | 1.3 (31%) | 0.0 (0%) |
| MARCHED: its unit marched | - | 0.0 (0%) | 0.0 (0%) | 6.0 (41%) | 2.0 (46%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | - | 0.3 (14%) | 0.3 (33%) | 2.3 (16%) | 0.7 (15%) | 0.0 (0%) |
| OFF THE TABLE: off the table or not arrived | - | 0.3 (14%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | - | 0.0 (0%) | 0.3 (33%) | 1.0 (7%) | 0.3 (8%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | - | 0.0 (0%) | 0.3 (33%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 21.0 (95%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 3.0 a game | 0.0 a game | 1.5 a game |
| stood (cast and not dispelled) | 89% (8 of 9) | - | 89% (8 of 9) |
| the unit moved after it | 50% (4 of 8) | - | 50% (4 of 8) |
| it charged on its next turn | 0% (0 of 8) | - | 0% (0 of 8) |
| the enemy charged it first | 38% (3 of 8) | - | 38% (3 of 8) |
| it fought by the end of its next turn | 0% (0 of 8) | - | 0% (0 of 8) |
| it moved out of a charge the enemy had planned (not charged first) | 12% (1 of 8) | - | 12% (1 of 8) |
| none of these (no charge, no fight, no charge escaped) | 50% (4 of 8) | - | 50% (4 of 8) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (57 of 94) | 70% (32 of 46) | 64% (89 of 140) |
|   cavalry | - | 57% (4 of 7) | 57% (4 of 7) |
|   character | 100% (5 of 5) | 70% (7 of 10) | 80% (12 of 15) |
|   chariot | 83% (15 of 18) | - | 83% (15 of 18) |
|   infantry | 32% (8 of 25) | 88% (21 of 24) | 59% (29 of 49) |
|   monster | 50% (2 of 4) | 0% (0 of 5) | 22% (2 of 9) |
|   war machine | 64% (27 of 42) | - | 64% (27 of 42) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.0 (24%) | 0.3 (7%) | 3.3 (20%) |
| CHARGED: it charged | 0.3 (3%) | 1.0 (21%) | 1.3 (8%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.3 (7%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.7 (5%) | 1.0 (21%) | 1.7 (10%) |
| MOVED: a war machine that moved | 2.0 (16%) | 0.0 (0%) | 2.0 (12%) |
| NO TARGET IN RANGE | 1.7 (14%) | 1.7 (36%) | 3.3 (20%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 3.7 (30%) | 0.3 (7%) | 4.0 (24%) |
| SHELTERED: the target was sheltered | 0.7 (5%) | 0.0 (0%) | 0.7 (4%) |
| OTHER BAR | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.3 | 0.7 | 80% | 3.9 pts | 13 pts |
| character | 4.0 | 1.7 | 58% | 9.4 pts | 37 pts |
| chariot | 5.0 | 1.0 | 80% | 3.1 pts | 16 pts |
| infantry | 14.3 | 4.0 | 84% | 6.0 pts | 86 pts |
| monster | 1.3 | 0.3 | 75% | 2.0 pts | 3 pts |
| war machine | 9.3 | 5.7 | 79% | 16.2 pts | 151 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 3.3 | 3.5 |
| Charges that made contact a game | 3.0 | 2.7 | 2.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.50 contact (6 units) | 0.00 declared, 0.00 contact (1 units) | 0.43 declared, 0.43 contact (7 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 1.00 contact (2 units) | 1.00 declared, 1.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.50 declared, 0.38 contact (16 units) | 0.28 declared, 0.21 contact (29 units) | 0.36 declared, 0.27 contact (45 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 17% (1 of 6) | - | - | 17% (1 of 6) |
| Character in a unit | 33% (1 of 3) | - | - | 33% (1 of 3) |
| Character on its own | 100% (2 of 2) | 50% (2 of 4) | 38% (3 of 8) | 50% (7 of 14) |
| Chariot | 100% (2 of 2) | 100% (1 of 1) | - | 100% (3 of 3) |
| Infantry | 56% (5 of 9) | 0% (0 of 1) | 0% (0 of 1) | 45% (5 of 11) |
| Monster | 100% (4 of 4) | - | - | 100% (4 of 4) |
| Monstrous | 100% (2 of 2) | 100% (2 of 2) | - | 100% (4 of 4) |
| War Machines | 71% (5 of 7) | - | - | 71% (5 of 7) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 1 | - | 50% (6 of 12) | 37% | 75% (9 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 2 | 80% (8 of 10); on the table 80% | 33% (16 of 48) | 36% | 35% (7 of 20) | 100% (4 of 4); 7.0 uses a game | 50% (1 of 2); 0.5 uses a game | 50% (1 of 2); 0.5 uses a game |
| Lizardmen | 1 | 100% (1 of 1); on the table 100% | - | 34% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 75% (3 of 4); on the table 75% | 0% (0 of 6) | 55% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | - | 25% | 75% (6 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p90, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 57% (4) | 33% (1) | 50% (5) |
| ...free all their last turn and able to turn (per game) | 1.33 | 0.33 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 1.33 | 0.33 | 1.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p90

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 73% (8 of 11) | 30% (3 of 10) |
| Strategy | Shoot objectives carried out (shot that target) | 13% (7 of 53) | 62% (5 of 8) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 38% (3 of 8) | - |
| Strategy | Joined characters whose unit fought | 100% (5 of 5) | - |
| Strategy | Lone characters that fought | 62% (5 of 8) | 86% (6 of 7) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 0.3 | 3.7 |
| Movement | Points that never moved of their own | 180.0 | 180.0 |
| Movement | Fights charged into per game | 3.0 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | 3 of 9, net +0 | 0 of 6 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 9 | 1 of 6, net -109 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 9, net +45 | 0 of 6 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 of 9, net +77 | 3 of 6, net +131 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.0 | 12.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 47% (14 of 30) | 41% (15 of 37) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 9.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 52% (14 of 27) | - |
| Shooting | Points destroyed by war machines | 116.7 | 0.0 |
| Magic | Magic missiles cast | 5.0 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 13% (2 of 15) | - |
| Magic | Wounds caused by magic missiles | 22.3 | 1.3 |
| Magic | Wounds caused by other spells | 5.0 | - |
| Magic | Points destroyed by magic (all spells) | 334.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 2.7 / 0.7 / 0.0 | 2.7 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 89.7 | 55.0 |
| Combat | Points run down | 202.7 | 75.7 |
| Combat | Net points per charged fight, damage counted | +64 | -44 |
| Combat | Net per 100 charger points, damage counted | +28.6 | -10.3 |
| Combat | First round won (charged fights) | 67% | 43% |
| Combat | Net points per charged fight | +48 | -31 |
| Combat | Net points per supported fight / lone fight | - / +48 | +0 / -36 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 9 | 5 of 7 |
| Game | Points lost | 228.3 | 763.3 |
| Game | VP from objectives | 836.7 | 443.3 |
| Game | Lone holders (player turns) | 10.0 | 6.0 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +942 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 992
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p90

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH IN POINTS | 0.3 | +87.7 | 0.0 | 0.0 | 0.3 | +20.4 | 0.0 | 0.0 |
| ARMY TABLE | 14.3 | +330.6 | 0.0 | 151.3 | 26.3 | +669.8 | 0.0 | 620.7 |
| ARTILLERY RE-ROLL WEIGHED | 5.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ASSAILMENT BY POINTS | 0.7 | +4.2 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +0.3 | 0.0 | 0.0 | 0.3 | +2.2 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -194.9 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 8.7 | +185.6 | 745.3 | 110.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 6.3 | +85.2 | 55.3 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CATCH FLIERS | 0.3 | +3.6 | 0.0 | 0.0 | 0.3 | +6.9 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.3 | +27.8 | 0.0 | 9.0 |
| CHALLENGE BY POINTS | 1.3 | +48.9 | 0.0 | 75.7 | 0.7 | +17.9 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | 0.3 | -0.6 | 0.0 | 0.0 | 1.0 | +18.5 | 0.0 | 72.7 |
| CHARACTER GUNS | 4.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 11.0 | -451.3 | 0.0 | 262.7 | 31.3 | -1494.3 | 0.0 | 886.0 |
| CHARGE NOW FIRST | 5.0 | +0.0 | 83.0 | 0.0 | 3.0 | +0.0 | 55.7 | 369.3 |
| CHARGER SLAIN LOST | 0.3 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 9.7 | +0.0 | 0.0 | 0.0 | 9.3 | +0.0 | 0.0 | 333.3 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 2.0 | +222.2 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 10.7 | -381.8 | 0.0 | 0.0 | 8.0 | -697.6 | 0.0 | 194.0 |
| DEFENSIVE FLOOR | 0.3 | -13.6 | 0.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | 1.3 | -15.5 | 27.7 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 7.7 | -56.5 | 0.0 | 0.0 | 9.0 | +31.7 | 0.0 | 94.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | +4.7 | 55.7 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| EXACT ROUND | 2.0 | -9.4 | 47.0 | 0.0 | 1.7 | -26.1 | 55.0 | 333.0 |
| FALL BACK GOOD ORDER | 3.0 | +2.8 | 42.7 | 0.0 | 2.3 | +12.4 | 75.7 | 239.3 |
| FALLS SHORT | - | - | - | - | 25.3 | +199.5 | 0.0 | 190.3 |
| FEATURE BUFFS | 2.0 | +59.3 | 0.0 | 111.3 | - | - | - | - |
| FIGHT TO THE END | 1.0 | +7.9 | 0.0 | 0.0 | 1.3 | +19.9 | 75.7 | 203.0 |
| FIVE ACTION | 101.7 | +6453.6 | 2163.0 | 634.0 | 85.0 | +2647.8 | 186.3 | 1819.0 |
| FLANK NOT WEIGHED | 8.0 | +0.0 | 0.0 | 131.3 | 6.3 | +0.0 | 0.0 | 213.3 |
| FOLLOW UP WEIGHED | 0.7 | +134.5 | 0.0 | 0.0 | 1.3 | +15.7 | 0.0 | 0.0 |
| FOOT FIRST | 18.3 | +0.0 | 0.0 | 165.7 | - | - | - | - |
| FOUR ROUNDS | 3.7 | +244.8 | 89.7 | 0.0 | 3.3 | +388.7 | 186.3 | 405.7 |
| FREED FROM HIS FIGHT | 2.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -19.6 | 0.0 | 166.7 |
| FRIENDS SHOTS CHECKED | 0.3 | +4.7 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.3 | -0.8 | 0.0 | 0.0 | 0.3 | -1.1 | 75.7 | 0.0 |
| GOAL WALK | 3.3 | +152.3 | 0.0 | 0.0 | 13.3 | +1113.8 | 0.0 | 0.0 |
| GUN FIGURES | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| GUN MASK | 3.7 | +58.0 | 0.0 | 151.3 | - | - | - | - |
| HARD STAY DROPPED | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 86.0 |
| HE REFORMS ONCE FREED | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 9.0 | +0.0 | 0.0 | 262.7 | 16.7 | +0.0 | 0.0 | 388.0 |
| HIS CHARGE LIST | 4.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 169.3 |
| HIS LEGAL MOVES | 5.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 332.7 |
| HIS MOVE AND SHOT | 2.0 | -6.7 | 0.0 | 0.0 | 13.0 | -217.8 | 0.0 | 389.7 |
| HIS ONE QUARTER | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS OWN BEST MOVE | 6.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 332.7 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 22.3 | +496.8 | 0.0 | 414.0 | 71.0 | +4824.2 | 0.0 | 1358.0 |
| HIS SHOTS BY HIS RUN | 22.7 | +275.0 | 0.0 | 111.3 | 56.7 | +1445.5 | 0.0 | 1165.3 |
| HIS TURN DENIED | 1.3 | +69.5 | 27.7 | 0.0 | 1.0 | +16.5 | 55.7 | 36.3 |
| HOLD ODDS | 20.0 | +0.0 | 0.0 | 222.7 | 6.7 | +0.0 | 0.0 | 55.3 |
| HOLDER ASSIGNMENT | 10.7 | +1104.7 | 0.0 | 55.7 | 5.0 | +367.3 | 0.0 | 27.7 |
| HONEST WORTH | 3.3 | -110.2 | 89.7 | 0.0 | 3.3 | -181.0 | 186.3 | 405.7 |
| HUNT IN PAIRS | 0.7 | +29.9 | 0.0 | 0.0 | 0.7 | +3.5 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 24.0 | -428.1 | 0.0 | 550.7 |
| JOINT CHARGE NOW | 0.7 | +19.7 | 0.0 | 0.0 | 0.3 | -20.3 | 0.0 | 36.3 |
| KEPT FROM ITS LAST STOP | 4.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +35.1 | 0.0 | 0.0 | 2.0 | +132.2 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 1.0 | +0.0 | 53.3 | 0.0 | 6.3 | +0.0 | 55.7 | 129.0 |
| LONE WIZARD KEPT IN | 0.7 | +22.6 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 0.7 | +6.4 | 15.0 | 0.0 | 0.7 | +1.7 | 0.0 | 36.3 |
| LOST AFTER ESCAPE | 1.7 | -4.3 | 74.7 | 0.0 | 2.7 | +20.0 | 131.3 | 405.7 |
| MAKE SURE TOGETHER | 0.3 | +0.7 | 0.0 | 0.0 | 0.3 | +1.0 | 0.0 | 0.0 |
| MANOEUVRE | 2.0 | +18.3 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 2.0 | +114.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 3.0 | +146.7 | 0.0 | 0.0 | 0.3 | +42.3 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 1.0 | +42.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 4.0 | +304.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 6.3 | +149.2 | 0.0 | 0.0 | 2.0 | +11.0 | 0.0 | 0.0 |
| MEETS IN TIME | 3.7 | +90.7 | 0.0 | 0.0 | 1.3 | +48.3 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 13.3 | +314.6 | 0.0 | 55.7 | 0.3 | +0.7 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 16.7 | +230.4 | 0.0 | 55.7 | 1.7 | +5.6 | 0.0 | 0.0 |
| MOVE ORDER | 2.3 | +0.0 | 75.7 | 0.0 | 3.3 | +0.0 | 36.7 | 47.0 |
| MOVE SPELL SPOT | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.0 | +175.6 | 0.0 | 0.0 | 4.7 | +272.0 | 0.0 | 333.3 |
| NEARER NOT NEEDED | 8.7 | +384.8 | 0.0 | 207.0 | 7.0 | +320.7 | 0.0 | 63.3 |
| NEAREST TO GOAL | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 0.7 | +87.2 | 0.0 | 0.0 | 4.7 | +265.9 | 0.0 | 333.3 |
| NO DOUBLE ROUNDS | 3.7 | -146.2 | 89.7 | 0.0 | 3.0 | -316.1 | 186.3 | 405.7 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 4.3 | -233.8 | 0.0 | 110.0 | 4.3 | -154.4 | 0.0 | 58.3 |
| OGRE LOADER SECOND SHOT | 7.7 | +31.7 | 0.0 | 0.0 | - | - | - | - |
| ONE CHALLENGE TEST | - | - | - | - | 1.3 | +8.3 | 0.0 | 72.7 |
| ONE FIGHT FORMULA | 5.3 | -108.2 | 0.0 | 0.0 | 6.0 | -146.0 | 0.0 | 333.0 |
| ONE OBJECTIVE FORMULA | 6.3 | -77.9 | 0.0 | 55.7 | 3.7 | -206.7 | 0.0 | 27.7 |
| ONE PROMISE A TARGET | - | - | - | - | 0.7 | -3.8 | 0.0 | 0.0 |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 1.3 | +25.8 | 74.7 | 0.0 | 2.0 | +17.1 | 75.7 | 369.3 |
| PATHS CROSS | 0.7 | -4.8 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 44.7 | +1320.3 | 1352.7 | 372.7 | 41.3 | +355.9 | 0.0 | 1182.3 |
| PROMISE BY ITS OWN SUM | 5.0 | -114.7 | 0.0 | 0.0 | 4.7 | -69.5 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.3 | -0.3 | 0.0 | 0.0 | - | - | - | - |
| PURSUES BIG PREY | - | - | - | - | 0.3 | -13.9 | 0.0 | 0.0 |
| QUARTER ODDS | 11.7 | +1222.6 | 428.7 | 220.0 | 3.7 | +762.6 | 55.0 | 48.0 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 1.0 | +93.4 | 0.0 | 18.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 3.7 | +0.0 | 0.0 | 46.3 |
| REFORMS TO MEET IT | - | - | - | - | 1.7 | -24.8 | 0.0 | 333.3 |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 230.7 |
| RESERVE FALL BACK | 0.3 | +8.0 | 0.0 | 0.0 | 0.7 | +5.5 | 0.0 | 0.0 |
| RISK BY ARC | 2.7 | +31.3 | 74.7 | 0.0 | 2.7 | -249.5 | 131.3 | 405.7 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 2.3 | -80.5 | 186.3 | 333.0 |
| RUN DOWN | 2.0 | -17.5 | 74.7 | 0.0 | 3.0 | -52.1 | 186.3 | 405.7 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.3 | -180.6 | 0.0 | 18.0 |
| SEARCH SPOT | 2.0 | +59.8 | 0.0 | 0.0 | 1.0 | +28.9 | 0.0 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 2.3 | -33.7 | 0.0 | 18.0 |
| SET UP BY THE SET | 1.0 | -28.2 | 0.0 | 0.0 | 2.7 | -35.3 | 0.0 | 18.0 |
| SET UP TOGETHER | 0.3 | +0.7 | 0.0 | 0.0 | 0.3 | +1.0 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 1.3 | +122.7 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.3 | +0.7 | 0.0 | 0.0 | 0.3 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 17.0 | +0.0 | 0.0 | 110.0 | 3.3 | +0.0 | 0.0 | 36.7 |
| SHOOTS FROM THE BEST SPOT | 3.3 | +176.9 | 131.7 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 0.3 | -0.3 | 15.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.3 | +0.0 | 58.3 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 12.3 | -86.9 | 0.0 | 111.3 | 48.0 | -40.5 | 0.0 | 1313.0 |
| SHOTS AFTER THE MOVES | 5.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 21.0 | +630.2 | 0.0 | 185.7 | 8.7 | +171.1 | 0.0 | 248.7 |
| SPELL SETS UP CHARGE | 1.3 | +122.7 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | - | - | - | - | 4.0 | +88.2 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | +1.0 | 47.0 | 0.0 | 0.7 | -8.6 | 0.0 | 166.3 |
| SPOT AS THE GAME MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 184.7 |
| STAND AND SHOOT | 1.0 | -18.7 | 27.7 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | - | - | - | - | 2.7 | +0.0 | 0.0 | 71.3 |
| STANDS STILL | 51.7 | +0.0 | 2073.3 | 220.0 | 17.3 | +0.0 | 0.0 | 267.7 |
| STAY WORTH | 40.0 | +104.9 | 1561.0 | 240.7 | 9.0 | +47.2 | 0.0 | 245.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +2.2 | 0.0 | 15.0 |
| SUPPORT ADDS | 4.0 | +372.1 | 0.0 | 0.0 | 8.7 | +545.0 | 0.0 | 26.7 |
| SUPPORT NARROWED | 3.0 | +0.0 | 83.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 4.0 | +372.1 | 0.0 | 0.0 | 8.7 | +545.0 | 0.0 | 26.7 |
| SURE REACH TOGETHER | 1.0 | +9.0 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 3.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 43.7 | +0.0 | 0.0 | 317.0 | 41.7 | +0.0 | 0.0 | 715.7 |
| TIED UP BY THE SUM | 1.3 | +133.8 | 74.7 | 0.0 | 0.3 | +76.1 | 75.7 | 0.0 |
| TIME ON OUR SIDE | 43.3 | +596.0 | 0.0 | 358.3 | - | - | - | - |
| WAITS AGAIN | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 4.7 | +0.0 | 332.7 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.3 | -12.2 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 2.3 | -248.4 | 0.0 | 151.3 | 5.7 | -545.2 | 0.0 | 0.0 |
| WOUNDED STAYS OUT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 3.3 | +44.9 | 0.0 | 111.3 | 2.3 | +0.2 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p90

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 122 | 122 | 82 | 27.33 | +2169 | +26.4 |
| HIS SHOT LIST | 280 | 270 | 74 | 24.67 | +1694 | +22.9 |
| HOLDER ASSIGNMENT | 47 | 47 | 45 | 15.00 | +2467 | +54.8 |
| HIS SHOTS BY HIS RUN | 238 | 225 | 40 | 13.33 | +349 | +8.7 |
| SHOT RISK POINTS | 181 | 173 | 34 | 11.33 | +986 | +29.0 |
| FIVE ACTION | 560 | 545 | 29 | 9.67 | +1228 | +42.3 |
| DEPLOY BY FIGURES | 50 | 50 | 27 | 9.00 | +330 | +12.2 |
| OFF BEST | 26 | 26 | 26 | 8.67 | -1164 | -44.8 |
| OGRE LOADER SECOND SHOT | 23 | 23 | 23 | 7.67 | +95 | +4.1 |
| LEGAL CHARGES ONLY | 22 | 22 | 22 | 7.33 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 19 | 6.33 | +0 | +0.0 |
| MOVE ORDER | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| STAY WORTH | 147 | 135 | 16 | 5.33 | +168 | +10.5 |
| CHARGE LOSSES | 127 | 118 | 14 | 4.67 | +1741 | +124.4 |
| FOUR ROUNDS | 21 | 21 | 14 | 4.67 | +503 | +35.9 |
| HARD STAY DROPPED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| TIME ON OUR SIDE | 130 | 116 | 13 | 4.33 | +39 | +3.0 |
| GOAL WALK | 50 | 49 | 12 | 4.00 | +549 | +45.7 |
| IDLE COST | 72 | 55 | 12 | 4.00 | +197 | +16.4 |
| CAST JOB | 19 | 19 | 11 | 3.67 | +42 | +3.8 |
| MEETS IN TIME | 15 | 15 | 11 | 3.67 | +475 | +43.2 |
| QUARTER ODDS | 46 | 43 | 11 | 3.67 | +1483 | +134.8 |
| REDIRECT FOR A FRIEND IN REACH | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| SUPPORT ADDS | 38 | 38 | 11 | 3.67 | +556 | +50.6 |
| SUPPORT WORKED OUT | 38 | 38 | 11 | 3.67 | +556 | +50.6 |
| LANE BY FIGURES | 10 | 10 | 10 | 3.33 | +502 | +50.2 |
| PROMISE BY ITS OWN SUM | 29 | 29 | 10 | 3.33 | -553 | -55.3 |
| MARCH CHECK | 10 | 9 | 9 | 3.00 | +187 | +20.8 |
| MOVE TO CHARGE COMPUTED | 20 | 16 | 9 | 3.00 | +245 | +27.2 |
| SUPPORT NARROWED | 9 | 9 | 9 | 3.00 | -1388 | -154.2 |
| WAR ENGINE JOBS | 14 | 14 | 8 | 2.67 | -354 | -44.3 |
| MAX FOR POSITIONING | 25 | 23 | 7 | 2.33 | +37 | +5.3 |
| SEARCH SPOT | 9 | 9 | 7 | 2.33 | +266 | +38.0 |
| CHALLENGE BY POINTS | 6 | 6 | 6 | 2.00 | +201 | +33.4 |
| CHARGE NOW FIRST | 24 | 24 | 6 | 2.00 | -124 | -20.7 |
| FOLLOW UP WEIGHED | 6 | 6 | 6 | 2.00 | +451 | +75.1 |
| MARCH BY THE SUM | 6 | 6 | 6 | 2.00 | +342 | +57.0 |
| MISSILES IN THE MOVE | 41 | 32 | 6 | 2.00 | +148 | +24.7 |
| SHOOTS FROM THE BEST SPOT | 10 | 10 | 6 | 2.00 | +98 | +16.3 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 19 | 19 | 5 | 1.67 | +0 | +0.0 |
| TIED UP BY THE SUM | 5 | 5 | 5 | 1.67 | +133 | +26.7 |
| COVER ONCE | 56 | 39 | 4 | 1.33 | +82 | +20.4 |
| GUN MASK | 11 | 11 | 4 | 1.33 | +28 | +6.9 |
| NEXT CHARGE BY LIST | 16 | 16 | 4 | 1.33 | +169 | +42.3 |
| WHOLE FIGHT DANGER | 24 | 23 | 4 | 1.33 | +32 | +8.0 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FALLS SHORT | 76 | 65 | 3 | 1.00 | +16 | +5.3 |
| FEATURE BUFFS | 6 | 6 | 3 | 1.00 | +30 | +10.0 |
| HIS TURN DENIED | 7 | 7 | 3 | 1.00 | +62 | +20.5 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | -2 | -0.7 |
| MARCH OF THE TABLE | 3 | 3 | 3 | 1.00 | -128 | -42.7 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +41 | +13.5 |
| SET UP BY THE SET | 11 | 11 | 3 | 1.00 | +514 | +171.3 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +324 | +162.1 |
| ASSAILMENT BY POINTS | 2 | 2 | 2 | 0.67 | +13 | +6.3 |
| CANNON PLANNED TARGET | 26 | 26 | 2 | 0.67 | +61 | +30.3 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +68 | +33.9 |
| ONE FIGHT FORMULA | 34 | 25 | 2 | 0.67 | +41 | +20.6 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -11 | -5.7 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | -15 | -7.3 |
| REFUSING RETIRES | 5 | 5 | 2 | 0.67 | -43 | -21.4 |
| RISK BY ARC | 16 | 16 | 2 | 0.67 | +53 | +26.3 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +6 | +3.0 |
| THE ROW IN ITS ORDER | 15 | 2 | 2 | 0.67 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| DUEL STOPS AT THE KILL | 1 | 1 | 1 | 0.33 | +14 | +13.5 |
| EVASIVE BY THE ODDS | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +14 | +14.2 |
| HIS MOVE AND SHOT | 45 | 43 | 1 | 0.33 | +7 | +7.0 |
| LONG SHOT | 4 | 4 | 1 | 0.33 | +6 | +6.5 |
| MANOEUVRE | 8 | 8 | 1 | 0.33 | +65 | +64.6 |
| MISSILES NEXT TURN | 55 | 44 | 1 | 0.33 | +4 | +4.5 |
| NO DOUBLE ROUNDS | 20 | 20 | 1 | 0.33 | +12 | +12.5 |
| OVERRUNS AWAY | 10 | 10 | 1 | 0.33 | +16 | +15.6 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -1 | -0.9 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.33 | -42 | -41.8 |
| ROUNDS AFTER TERROR | 7 | 7 | 1 | 0.33 | +9 | +9.0 |
| SET UP TOGETHER | 2 | 1 | 1 | 0.33 | +2 | +1.6 |
| SHOT REPLANNED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +7 | +6.6 |
| SURE REACH TOGETHER | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| BACKUP TARGETS | 2 | not checked | - | - | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 8 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHAFF IN THE MOVE | 4 | 4 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 4 | 4 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 12 | 12 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 57 | 56 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 6 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| EXACT ROUND | 11 | 11 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 16 | 16 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 7 | 7 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 43 | not checked | - | - | - | - |
| FOOT FIRST | 55 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 19 | 17 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 4 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 12 | 10 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 77 | 72 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 28 | 27 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 30 | 28 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 4 | 4 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 37 | 33 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 80 | 78 | 0 | 0.00 | - | - |
| HONEST WORTH | 20 | 20 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 4 | 3 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 14 | 12 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 13 | 13 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH OVER CASTS | 12 | 12 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 8 | not checked | - | - | - | - |
| NEARER NOT NEEDED | 47 | 43 | 0 | 0.00 | - | - |
| NEAREST TO GOAL | 2 | 2 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| ONE CHALLENGE TEST | 4 | 4 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 30 | 26 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 4 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 258 | trace | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 6 | 4 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 4 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 3 | 3 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 5 | 5 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 4 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 15 | 15 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 7 | 7 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 7 | 7 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 4 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 61 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SHOTS IN THE MOVE | 89 | 72 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 4 | not checked | - | - | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 33 | 25 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 207 | 202 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 12 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 19 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 15 | not checked | - | - | - | - |
| THE TABLE BINDS | 256 | not checked | - | - | - | - |
| WAITS AGAIN | 7 | 7 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 17 | 17 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p90

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.00 | 2.33 | 53.2 |
| ARMY TABLE | rule | 1.33 | 3.00 | 39.4 |
| PROMISE BY ITS OWN SUM | rule | 2.00 | 1.33 | 55.3 |
| SUPPORT NARROWED | rule | 3.00 | - | 154.2 |
| WAR ENGINE JOBS | rule | 2.67 | - | 44.3 |
| CHARGE NOW FIRST | rule | 1.33 | 0.67 | 20.7 |
| HOLDER ASSIGNMENT | rule | 1.33 | 0.33 | 30.5 |
| RULE SWITCHED OFF | gate | - | 1.67 | 27.4 |
| MARCH OF THE TABLE | rule | 1.00 | - | 42.7 |
| ONE PROMISE A TARGET | rule | - | 0.67 | 5.7 |
| REFUSING RETIRES | rule | 0.33 | 0.33 | 21.4 |
| AFTERMATH BAND | gate | - | 0.33 | 1.3 |
| FOLLOW UP WEIGHED | rule | - | 0.33 | 1.3 |
| JOINT CHARGE NOW | rule | - | 0.33 | 61.1 |
| NO REASON | gate | 0.33 | - | 15.7 |
| PATHS CROSS | rule | 0.33 | - | 20.1 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 0.9 |
| PURSUES BIG PREY | rule | - | 0.33 | 41.8 |

### Plans: gs3-83c8646-p90

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.0 | 78% | 206 | 198 | 96% |
| Mine | move | 25.7 | 97% | 1615 | 0 | 0% |
| Mine | shoot | 16.0 | 50% | 896 | 1122 | 125% |
| Opponent | charge | 2.0 | 33% | 150 | 219 | 146% |
| Opponent | move | 35.3 | 90% | 1312 | 0 | 0% |
| Opponent | shoot | 2.7 | 62% | 146 | 137 | 93% |
| Opponent | support | 1.3 | 100% | 0 | 0 | - |

### Battle groups: gs3-83c8646-p90

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 1.0 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p90

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 11 | 70 (11) | 70 | 0 | 5 | 18% | 2.1 | 71 (4) | 5 (3) | 95 (3) | 81 (6) | 66 (4) |
| Mine | Clean-up | 1 | 35 (1) | 0 | 35 | 0 | 0% | 6.0 | 35 (1) | - | - | 35 (1) | - |
| Mine | Fast Hammer | 6 | 92 (6) | 16 | 75 | 18 | 17% | 1.4 | 91 (4) | 94 (2) | - | 152 (3) | 24 (3) |
| Mine | Hammer | 4 | 25 (4) | 2 | 22 | 26 | 0% | 3.5 | 0 (1) | 33 (3) | - | 29 (3) | 11 (1) |
| Mine | Holder | 1 | 234 (1) | 0 | 234 | 0 | 0% | 4.0 | - | 234 (1) | - | 234 (1) | - |
| Mine | Shooter | 3 | 0 (3) | 0 | 0 | 0 | 33% | 2.0 | 0 (2) | 0 (1) | - | 0 (1) | 0 (2) |
| Mine | War machine | 7 | 34 (7) | 34 | 0 | 16 | 0% | 1.6 | 30 (4) | 38 (3) | - | 53 (2) | 25 (5) |
| Mine | Wizard | 2 | 40 (2) | 40 | 0 | 0 | 0% | 4.5 | - | 40 (2) | - | 67 (1) | 13 (1) |
| Opponent | Chaff | 6 | 116 (6) | 0 | 116 | 54 | 83% | 5.0 | 0 (4) | 500 (1) | 0 (1) | 227 (3) | 0 (3) |
| Opponent | Character | 7 | 23 (7) | 23 | 0 | 39 | 0% | 2.7 | - | 19 (6) | 45 (1) | 35 (3) | 11 (4) |
| Opponent | Clean-up | 4 | 88 (4) | 0 | 88 | 16 | 50% | 4.5 | - | 88 (4) | - | 88 (4) | - |
| Opponent | Fast Hammer | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fragile | 5 | 0 (5) | 0 | 0 | 18 | 0% | 4.8 | 0 (1) | - | 0 (4) | 0 (1) | 0 (4) |
| Opponent | Hammer | 5 | 0 (5) | 0 | 0 | 51 | 80% | 1.0 | 0 (1) | 0 (4) | - | 0 (2) | 0 (3) |
| Opponent | Holder | 2 | 47 (2) | 0 | 47 | 50 | 0% | 1.0 | - | 47 (2) | - | - | 47 (2) |
| Opponent | Shooter | 5 | 34 (5) | 0 | 34 | 75 | 0% | 1.0 | 77 (2) | 0 (1) | 20 (2) | 125 (1) | 20 (4) |

### Charged fights: gs3-83c8646-p90

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 1 | 40 | 45 | 3.0 | 1.0 | 15 | 0 | +15 | 2 of 3 | 1 of 3 | - | +15 |
| Mine | Grand Cathay | 2 | 656 | 192 | 3.0 | 1.0 | 64 | 0 | +64 | 1 of 6 | 5 of 6 | - | +64 |
| **Mine** | all armies | 3 | 451 | 143 | 3.0 | 1.0 | 48 | 0 | +48 | 3 of 9 | 6 of 9 | - | +48 |
| Opponent | Lizardmen | 1 | 0 | 165 | 2.0 | 1.0 | 82 | 250 | -167 | 1 of 2 | 1 of 2 | - | -167 |
| Opponent | Vampire Counts | 1 | 0 | 227 | 2.0 | 1.0 | 114 | 0 | +114 | 1 of 2 | 2 of 2 | - | +114 |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 3.0 | 1.3 | 0 | 36 | -36 | 3 of 3 | 0 of 3 | +0 | -54 |
| **Opponent** | all armies | 3 | 0 | 131 | 2.3 | 1.1 | 56 | 87 | -31 | 5 of 7 | 3 of 7 | +0 | -36 |

### Effective charges: gs3-83c8646-p90

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 3 | 2 (net +0) | 0 | 0 | 0 | 1 (net +45) | 0 | 0 | 0% (0 of 3) |
| Mine | Grand Cathay | 6 | 1 (net +0) | 0 | 0 | 0 | 0 | 5 (net +77) | 0 | 0% (0 of 6) |
| Opponent | Lizardmen | 2 | 0 | 0 | 0 | 1 (net -499) | 0 | 1 (net +165) | 0 | 0% (0 of 2) |
| Opponent | Vampire Counts | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +227) | 1 | 0% (0 of 1) |
| Opponent | Wood Elf Realms | 3 | 0 | 0 | 1 (net -109) | 1 (net +0) | 0 | 1 (net +0) | 0 | 33% (1 of 3) |

### Charged fights, damage counted: gs3-83c8646-p90

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 3 | 234 | 283 | +0 | 32 | 55 | -23 | -9.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 223 | 121 | +77 | 121 | 0 | +121 | +54.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 209 | 45 | +45 | 57 | 14 | +43 | +20.6 |
| Mine | All fights | 9 | 225 | 167 | +48 | 84 | 20 | +64 | +28.6 |
| Opponent | Effective (55-75%) | 1 | 109 | 369 | -109 | 143 | 386 | -243 | -223.0 |
| Opponent | 76-89% | 2 | 449 | 334 | -250 | 0 | 250 | -250 | -55.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 505 | 254 | +131 | 131 | 4 | +127 | +25.1 |
| Opponent | No odds | 1 | 500 | 189 | +0 | 52 | 0 | +52 | +10.4 |
| Opponent | All fights | 7 | 432 | 284 | -31 | 84 | 128 | -44 | -10.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p90 | move | 24 | 5 (21%) | 3 (12%) | 3 (12%) | 16 (67%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0926, L1034 |
| Ring of Jet | Mine | L1017, L1034 |
| Twice-Blessed Armour | Mine | L1017, L1034 |

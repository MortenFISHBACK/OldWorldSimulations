# Doctrine scorecard: gs3-83c8646-p64

### Scorecard: gs3-83c8646-p64

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0528 | 6 | 1 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 807 |
| L0528 | 6 | 1 | Opponent | no | 10 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | - | 3 | 3 | 0 | 0 | 0 | 798 |
| L0616 | 4 | 1 | Opponent | no | 0 | 6 | 2 | 0 | 0 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 3 | 2 | 1 | 0 | 0 | 0 | 495 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 0 | 3 | 1 | 0 | 0 | 139 |
| **Average** | | | Mine | 0% | 0.0 | 3.0 | 1.7 | 2.3 | 0.0 | 0.0 | 0.0 | 700.0 |
| **Average** | | | Opponent | 0% | 5.0 | 4.0 | 0.7 | 2.0 | 0.3 | 0.0 | 0.0 | 113.0 |

### KPIs: gs3-83c8646-p64

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 100% (12 of 12) | 0% (0 of 10) | 55% (12 of 22) |
| Winner chose to follow up after the loser gave ground |  | - | - | - |
| Winner chose to pursue after the loser fell back in good order |  | 50% (1 of 2); on the table 50% | 0% (0 of 1); on the table 0% | 33% (1 of 3); on the table 33% |
| Winner chose to pursue after the loser fled |  | - | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 50% (1 of 2); on the table 50% | 0% (0 of 2); on the table 0% | 25% (1 of 4); on the table 25% |
| Magic missiles tried each own turn | 50%+ | - | 17% (1 of 6) | 17% (1 of 6) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 17% (1 of 6) | 17% (1 of 6) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 67% (8 of 12) | 67% (8 of 12) |
| Points that never fought | lower | 86% (5177 of 6000) | 68% (4064 of 5999) | 77% (9241 of 11999) |
|   infantry points that never fought | lower | 92% (2049 of 2232) | 70% (506 of 720) | 87% (2555 of 2952) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 85% (23 of 27) | 71% (15 of 21) | 79% (38 of 48) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 82% (3486 of 4232) | 69% (3712 of 5415) | 75% (7198 of 9647) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.7 (100%) | 1.7 (100%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Assailments |
| --- | --- | --- | --- | --- |
| tried | 0.3 | 0.0 | 0.3 | 0.0 |
| not cast | 3.7 | 2.0 | 1.7 | 4.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (100%) | 1.7 (100%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 1.7 (45%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (55%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.0 (100%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 71% (125 of 177) | 48% (16 of 33) | 67% (141 of 210) |
|   cavalry | 50% (10 of 20) | 62% (8 of 13) | 55% (18 of 33) |
|   character | 70% (14 of 20) | 0% (0 of 10) | 47% (14 of 30) |
|   infantry | 51% (26 of 51) | 0% (0 of 2) | 49% (26 of 53) |
|   monster | 67% (8 of 12) | - | 67% (8 of 12) |
|   war machine | 91% (67 of 74) | 100% (8 of 8) | 91% (75 of 82) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 5.7 (33%) | 0.3 (6%) | 6.0 (26%) |
| CHARGED: it charged | 3.0 (17%) | 0.3 (6%) | 3.3 (14%) |
| NO TARGET IN RANGE | 3.0 (17%) | 3.3 (59%) | 6.3 (28%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 4.3 (25%) | 1.0 (18%) | 5.3 (23%) |
| SHELTERED: the target was sheltered | 0.7 (4%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR | 0.7 (4%) | 0.7 (12%) | 1.3 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.0 | 1.3 | 81% | 2.7 pts | 19 pts |
| character | 4.7 | 3.3 | 71% | 16.8 pts | 78 pts |
| infantry | 17.3 | 2.7 | 87% | 3.8 pts | 66 pts |
| monster | 2.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 25.0 | 17.3 | 67% | 14.7 pts | 367 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.3 | 1.7 | 3.0 |
| Charges that made contact a game | 2.0 | 1.0 | 1.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.62 declared, 0.29 contact (21 units) | 0.25 declared, 0.15 contact (20 units) | 0.44 declared, 0.22 contact (41 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 75% (3 of 4) | - | 50% (1 of 2) | 67% (4 of 6) |
| Character in a unit | 86% (6 of 7) | 100% (3 of 3) | 100% (1 of 1) | 91% (10 of 11) |
| Character on its own | - | 100% (2 of 2) | 67% (2 of 3) | 80% (4 of 5) |
| Infantry | 71% (5 of 7) | 50% (3 of 6) | - | 62% (8 of 13) |
| Monster | 75% (3 of 4) | - | - | 75% (3 of 4) |
| Monstrous | 100% (1 of 1) | - | - | 100% (1 of 1) |
| War Machines | 100% (8 of 8) | - | - | 100% (8 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dwarfen Mountain Holds | 3 | 50% (1 of 2); on the table 50% | - | 86% | 85% (23 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 0% (0 of 1); on the table 0% | - | 67% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 2 | 0% (0 of 1); on the table 0% | 17% (1 of 6) | 68% | 73% (11 of 15) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p64, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (1) | 50% (2) | 50% (3) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.67 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.67 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: gs3-83c8646-p64

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | 45% (5 of 11) | 40% (2 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 68% (65 of 96) | 75% (9 of 12) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 2) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 12) | 0% (0 of 5) |
| Strategy | Lone characters that fought | 0% (0 of 1) | 40% (2 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.3 | 2.0 |
| Movement | Points that never moved of their own | 700.0 | 113.0 |
| Movement | Fights charged into per game | 2.0 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 5 | 0 of 2 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 5, net +0 | 0 of 2 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 5 | 1 of 2, net +115 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 5, net +136 | 1 of 2, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 20.7 | 3.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 60% (37 of 62) | 0% (0 of 10) |
| Shooting | Points destroyed by shooting units | 93.7 | 0.0 |
| Shooting | War machine shots | 22.3 | 2.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 69% (46 of 67) | 75% (6 of 8) |
| Shooting | Points destroyed by war machines | 0.0 | 38.3 |
| Magic | Magic missiles cast | - | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 0% (0 of 1) |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 0.3 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 71.7 | 78.3 |
| Combat | Points run down | 91.3 | 0.0 |
| Combat | Net points per charged fight, damage counted | +110 | +31 |
| Combat | Net per 100 charger points, damage counted | +162.5 | +8.5 |
| Combat | First round won (charged fights) | 100% | 100% |
| Combat | Net points per charged fight | +110 | +38 |
| Combat | Net points per supported fight / lone fight | - / +110 | - / +38 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 6 | 1 of 3 |
| Game | Points lost | 318.3 | 346.3 |
| Game | VP from objectives | 606.7 | 400.0 |
| Game | Lone holders (player turns) | 0.0 | 5.0 |

- Mine won / drew / lost: 1 / 2 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +249 VP
- The side that went first won 0 of 1 games with a winner
- Points traded per game (both sides' losses): 665
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p64

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 6.7 | -28.8 | 0.0 | 0.0 | 17.7 | +93.0 | 0.0 | 326.0 |
| ARTILLERY RE-ROLL WEIGHED | 5.0 | +0.0 | 0.0 | 63.3 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +3.2 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | - | - | - | - | 0.7 | -127.9 | 38.3 | 0.0 |
| CANNON PLAN MISSED | 0.7 | +0.0 | 74.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 23.7 | +136.8 | 214.0 | 378.3 | 2.7 | +65.0 | 76.7 | 66.7 |
| CANNON SIGHT KEPT | 3.0 | +0.0 | 0.0 | 38.3 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 2.0 | +17.5 | 0.0 | 0.0 |
| CHAFF PASSED | 0.7 | -1.1 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +2.3 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 6.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 6.7 | -143.5 | 0.0 | 0.0 | 26.7 | -1334.7 | 0.0 | 535.3 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 163.7 | 0.0 | 0.7 | +0.0 | 38.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 9.7 | +0.0 | 0.0 | 0.0 | 9.7 | +0.0 | 0.0 | 0.0 |
| COVER ONCE | 6.0 | -868.3 | 0.0 | 141.7 | 4.0 | -158.7 | 0.0 | 182.7 |
| DEFENSIVE ARMY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 13.0 | -157.2 | 0.0 | 38.3 | 6.0 | +73.0 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.7 | +11.5 | 46.3 | 0.0 | - | - | - | - |
| EXACT ROUND | 4.0 | +35.9 | 255.0 | 0.0 | 1.3 | +13.3 | 106.7 | 0.0 |
| FALL BACK GOOD ORDER | 2.7 | +0.3 | 136.3 | 0.0 | 1.3 | +0.0 | 68.3 | 0.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 19.7 | +206.6 | 0.0 | 549.3 |
| FEATURE BUFFS | 0.7 | +3.9 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 1.7 | +1.2 | 91.3 | 0.0 | 0.3 | +0.2 | 0.0 | 0.0 |
| FIVE ACTION | 128.3 | +4951.2 | 1136.3 | 820.0 | 73.3 | +2353.5 | 260.0 | 1139.3 |
| FLANK NOT WEIGHED | 2.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 90.7 |
| FOOT FIRST | 10.7 | +0.0 | 0.0 | 33.3 | - | - | - | - |
| FOUR ROUNDS | 4.3 | +36.5 | 255.0 | 0.0 | 1.7 | +50.8 | 106.7 | 0.0 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -0.8 | 0.0 | 0.0 |
| GIVES UP | 1.3 | -4.6 | 45.7 | 0.0 | - | - | - | - |
| GOAL WALK | 4.0 | +146.2 | 0.0 | 0.0 | 14.3 | +1016.6 | 0.0 | 0.0 |
| GUN FIGURES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| GUN MASK | 2.3 | +76.5 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 5.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 4.0 | +0.0 | 0.0 | 0.0 | 13.3 | +0.0 | 0.0 | 274.0 |
| HIS CHARGE DENIED | 0.3 | +1.9 | 46.3 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 5.3 | +0.0 | 0.0 | 0.0 | 22.3 | +0.0 | 0.0 | 412.3 |
| HIS LEGAL MOVES | 1.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 91.3 |
| HIS MOVE AND SHOT | - | - | - | - | 8.0 | -76.4 | 0.0 | 110.0 |
| HIS ONE QUARTER | 2.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 3.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 91.3 |
| HIS RANDOM MOVE | 14.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 20.3 | +372.7 | 0.0 | 0.0 | 58.7 | +4546.4 | 0.0 | 952.7 |
| HIS SHOTS BY HIS RUN | 14.7 | +165.9 | 0.0 | 0.0 | 49.0 | +1223.1 | 0.0 | 770.0 |
| HIS TURN DENIED | 0.3 | +0.7 | 26.7 | 0.0 | 0.7 | +17.8 | 68.3 | 0.0 |
| HOLD ODDS | 13.0 | +0.0 | 0.0 | 0.0 | 15.0 | +0.0 | 0.0 | 348.0 |
| HOLDER ASSIGNMENT | 10.7 | +1343.4 | 0.0 | 0.0 | 9.0 | +950.8 | 0.0 | 174.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.3 | -12.9 | 73.0 | 0.0 | 1.7 | -64.7 | 106.7 | 0.0 |
| IDLE COST | - | - | - | - | 17.3 | -326.4 | 0.0 | 218.3 |
| JOINT CHARGE NOW | 1.3 | +52.2 | 91.3 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 5.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 91.3 |
| LANE BY FIGURES | - | - | - | - | 1.3 | +77.7 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.3 | +25.0 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +3.5 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 2.0 | +9.4 | 182.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.3 | +12.2 | 0.0 | 0.0 |
| MANOEUVRE | 1.0 | -16.1 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | - | - | - | - | 0.7 | +9.0 | 0.0 | 0.0 |
| MEETS IN TIME | 6.0 | +54.8 | 0.0 | 0.0 | 3.0 | +184.7 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | - | - | - | - | 0.3 | +2.0 | 0.0 | 0.0 |
| MISSILES NEXT TURN | - | - | - | - | 1.7 | +3.8 | 0.0 | 0.0 |
| MODEL FACING | 4.0 | +545.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 82.7 | 0.0 |
| MOVE TO CHARGE COMPUTED | 2.7 | +106.5 | 0.0 | 0.0 | 2.0 | +63.0 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.3 | +251.0 | 0.0 | 0.0 | 3.0 | +144.2 | 0.0 | 92.7 |
| NEAREST TO GOAL | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 1.0 | +25.1 | 0.0 | 0.0 | 2.0 | +63.0 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.7 | -52.2 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 3.7 | -51.9 | 228.3 | 0.0 | 1.3 | -35.7 | 71.7 | 0.0 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 6.3 | -179.7 | 0.0 | 71.7 | 2.0 | -86.4 | 0.0 | 79.7 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.0 | -21.0 | 0.0 | 0.0 | 3.7 | -96.7 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 0.7 | +5.6 | 46.3 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 3.0 | +50.0 | 0.0 | 0.0 | 3.3 | -99.6 | 0.0 | 82.7 |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 0.7 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.3 | +18.8 | 0.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 1.7 | +151.3 | 106.7 | 0.0 |
| PATHS CROSS | 0.3 | +0.1 | 0.0 | 0.0 | 0.3 | -10.6 | 0.0 | 0.0 |
| PLAN RESULT | 59.0 | +2281.9 | 303.7 | 525.0 | 35.0 | +233.5 | 0.0 | 519.7 |
| PROMISE BELOW ZERO | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 4.3 | -49.6 | 0.0 | 0.0 | 2.3 | -1.2 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -10.1 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 16.0 | +1124.1 | 53.3 | 0.0 | 9.3 | +909.3 | 0.0 | 53.3 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.0 | +151.3 | 0.0 | 113.3 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | - | - | - | - | 2.3 | +106.3 | 0.0 | 26.7 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | -127.9 | 38.3 | 0.0 |
| REFORMS TO MEET IT | 2.0 | -39.9 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 2.0 | +80.6 | 0.0 | 26.7 |
| RISK BY ARC | 3.7 | +105.3 | 209.3 | 0.0 | 1.7 | -234.5 | 106.7 | 0.0 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 1.0 | -4.9 | 106.7 | 0.0 |
| RUN DOWN | 4.0 | -29.6 | 228.3 | 0.0 | 0.7 | -17.6 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.3 | -90.8 | 0.0 | 0.0 |
| SEARCH SPOT | - | - | - | - | 0.3 | +14.6 | 0.0 | 0.0 |
| SECOND LOOK | 0.7 | +27.2 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 0.7 | +2.7 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.7 | +21.8 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 2.0 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 32.7 | +0.0 | 0.0 | 378.3 | 4.3 | +0.0 | 0.0 | 93.3 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +10.5 | 113.3 | 0.0 | - | - | - | - |
| SHORT GUN FORWARD | 2.0 | +0.0 | 0.0 | 38.3 | - | - | - | - |
| SHOT OR CHARGE | 1.0 | -6.8 | 118.0 | 0.0 | 0.3 | -0.9 | 0.0 | 0.0 |
| SHOT RISK POINTS | 11.3 | +121.8 | 0.0 | 0.0 | 43.3 | -1078.8 | 0.0 | 715.3 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 40.3 | +1100.2 | 0.0 | 410.0 | 6.0 | +216.3 | 0.0 | 120.0 |
| SPELL WORTH | - | - | - | - | 0.3 | +3.6 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 1.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 82.0 |
| STAND AND SHOOT | 1.0 | -0.5 | 26.7 | 0.0 | 0.3 | -2.9 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 92.7 | +0.0 | 881.3 | 820.0 | 21.3 | +0.0 | 153.3 | 453.7 |
| STAY WORTH | 75.7 | +169.2 | 541.3 | 485.0 | 8.0 | +223.1 | 153.3 | 200.0 |
| STUBBORN BY POINTS | 0.3 | +1.2 | 0.0 | 40.0 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 1.7 | +25.7 | 0.0 | 0.0 | 2.3 | +49.8 | 0.0 | 91.3 |
| SUPPORT NARROWED | 0.3 | +0.0 | 46.3 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 1.7 | +25.7 | 0.0 | 0.0 | 2.3 | +49.8 | 0.0 | 91.3 |
| SURE REACH TOGETHER | 0.3 | +0.2 | 0.0 | 0.0 | 0.3 | +4.5 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | -0.5 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 45.7 |
| THE PROMISE ADDS | 0.3 | -10.1 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 45.7 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 45.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 61.7 | +0.0 | 0.0 | 378.3 | 34.3 | +0.0 | 0.0 | 513.0 |
| TIED UP BY THE SUM | 1.3 | +39.5 | 90.7 | 0.0 | 1.0 | +122.4 | 106.7 | 0.0 |
| TIME ON OUR SIDE | 57.3 | +617.5 | 91.3 | 0.0 | - | - | - | - |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WEAPON BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 45.7 |
| WHO FIGHTS | 2.7 | -39.4 | 183.3 | 0.0 | - | - | - | - |
| WHO GETS IN | 0.7 | +28.0 | 91.3 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.3 | +10.3 | 0.0 | 0.0 | 0.3 | +14.6 | 0.0 | 56.7 |
| WHOLE FIGHT DANGER | 1.3 | -25.7 | 0.0 | 0.0 | 1.0 | -45.5 | 0.0 | 45.7 |
| WOUNDS ON THE RANKS | 1.3 | +41.7 | 0.0 | 0.0 | 7.3 | +614.9 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p64

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 237 | 236 | 86 | 28.67 | +2465 | +28.7 |
| HOLDER ASSIGNMENT | 59 | 59 | 56 | 18.67 | +3940 | +70.4 |
| ARMY TABLE | 73 | 73 | 53 | 17.67 | +34 | +0.6 |
| HIS SHOTS BY HIS RUN | 191 | 190 | 41 | 13.67 | +268 | +6.5 |
| DEPLOY BY FIGURES | 57 | 57 | 39 | 13.00 | +580 | +14.9 |
| SHOT RISK POINTS | 164 | 163 | 37 | 12.33 | +1415 | +38.3 |
| TIME ON OUR SIDE | 172 | 155 | 27 | 9.00 | +121 | +4.5 |
| OFF BEST | 25 | 25 | 25 | 8.33 | -798 | -31.9 |
| CANNON PLANNED TARGET | 79 | 79 | 21 | 7.00 | -36 | -1.7 |
| HARD STAY DROPPED | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| GOAL WALK | 55 | 55 | 15 | 5.00 | +772 | +51.5 |
| THE TABLE AGAIN | 36 | 36 | 14 | 4.67 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| MODEL FACING | 12 | 12 | 12 | 4.00 | +1635 | +136.3 |
| MOVE ORDER | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| CHARGE LOSSES | 100 | 100 | 8 | 2.67 | +389 | +48.6 |
| MOVE TO CHARGE COMPUTED | 14 | 13 | 8 | 2.67 | +228 | +28.6 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 8 | 2.67 | +454 | +56.7 |
| RISK BY ARC | 16 | 15 | 8 | 2.67 | +123 | +15.3 |
| FIVE ACTION | 605 | 602 | 7 | 2.33 | +75 | +10.7 |
| CHAFF IN THE MOVE | 6 | 6 | 6 | 2.00 | +15 | +2.5 |
| FOUR ROUNDS | 18 | 17 | 6 | 2.00 | +57 | +9.5 |
| GUN MASK | 7 | 7 | 6 | 2.00 | +206 | +34.3 |
| MEETS IN TIME | 27 | 27 | 6 | 2.00 | +34 | +5.6 |
| QUARTER ODDS | 76 | 76 | 6 | 2.00 | +211 | +35.2 |
| RESERVE FALL BACK | 6 | 6 | 6 | 2.00 | +242 | +40.3 |
| SHOOTERS IN TWO RANKS | 6 | 6 | 6 | 2.00 | +12 | +2.0 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SUPPORT ADDS | 12 | 12 | 6 | 2.00 | +94 | +15.7 |
| SUPPORT WORKED OUT | 12 | 12 | 6 | 2.00 | +94 | +15.7 |
| TIED UP BY THE SUM | 7 | 7 | 6 | 2.00 | +233 | +38.8 |
| IDLE COST | 52 | 42 | 5 | 1.67 | +59 | +11.8 |
| SHOTS IN THE MOVE | 139 | 110 | 5 | 1.67 | +155 | +31.1 |
| COVER ONCE | 30 | 23 | 4 | 1.33 | +11 | +2.8 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | +157 | +39.2 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +233 | +58.2 |
| NEXT CHARGE BY LIST | 9 | 8 | 4 | 1.33 | +168 | +42.1 |
| PROMISE BY ITS OWN SUM | 20 | 20 | 4 | 1.33 | -152 | -38.0 |
| REDIRECT FOR A FRIEND IN REACH | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 24 | 24 | 4 | 1.33 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 26 | 26 | 4 | 1.33 | +95 | +23.6 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| EXACT ROUND | 16 | 15 | 3 | 1.00 | +57 | +19.1 |
| FALLS SHORT | 59 | 50 | 3 | 1.00 | +138 | +46.1 |
| REDIRECT WEIGHED | 3 | 3 | 3 | 1.00 | +219 | +72.9 |
| STAY WORTH | 251 | 230 | 3 | 1.00 | +56 | +18.6 |
| BEST PRIZE | 2 | 2 | 2 | 0.67 | -384 | -191.9 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | -3 | -1.7 |
| CHARGE NOW FIRST | 8 | 8 | 2 | 0.67 | -44 | -21.9 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | -31 | -15.7 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +82 | +40.9 |
| SHOOTS FROM THE BEST SPOT | 4 | 4 | 2 | 0.67 | +0 | +0.0 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHO GETS IN | 2 | 2 | 2 | 0.67 | +84 | +42.0 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +62 | +31.1 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +7 | +7.0 |
| EDGE GIVE GROUND | 2 | 2 | 1 | 0.33 | +14 | +14.0 |
| HONEST WORTH | 12 | 11 | 1 | 0.33 | +13 | +13.2 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +75 | +75.0 |
| ONE OBJECTIVE FORMULA | 19 | 16 | 1 | 0.33 | +21 | +20.6 |
| OVERRUNS AWAY | 5 | 5 | 1 | 0.33 | +56 | +56.4 |
| REDIRECT COUNTER | 7 | 7 | 1 | 0.33 | +43 | +43.1 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -3 | -2.6 |
| SEARCH SPOT | 1 | 1 | 1 | 0.33 | +44 | +43.7 |
| SET UP BY THE SET | 3 | 3 | 1 | 0.33 | +65 | +64.6 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +3 | +3.4 |
| SURE REACH TOGETHER | 2 | 2 | 1 | 0.33 | +8 | +8.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | -1 | -1.3 |
| THE ROW IN ITS ORDER | 12 | 1 | 1 | 0.33 | +0 | +0.0 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 20 | 20 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 58 | 57 | 0 | 0.00 | - | - |
| DEFENSIVE ARMY | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 12 | 11 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 6 | 6 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 17 | not checked | - | - | - | - |
| FOOT FIRST | 32 | not checked | - | - | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 4 | 0 | 0.00 | - | - |
| GUN FIGURES | 1 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 52 | 52 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 83 | 83 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 16 | 16 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 24 | 24 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 20 | 20 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 23 | 23 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 43 | 42 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 4 | 4 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 3 | 3 | 0 | 0.00 | - | - |
| HOLD ODDS | 84 | 84 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 21 | 21 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 3 | 3 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | not checked | - | - | - | - |
| LOST AFTER ESCAPE | 7 | 7 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MANOEUVRE | 9 | 9 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MAX FOR POSITIONING | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 1 | 1 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 5 | 4 | 0 | 0.00 | - | - |
| NEARER NOT NEEDED | 25 | 24 | 0 | 0.00 | - | - |
| NEAREST TO GOAL | 2 | 2 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 15 | 15 | 0 | 0.00 | - | - |
| NO LATE CUT | 1 | 1 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 20 | 15 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 2 | 2 | 0 | 0.00 | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS A LANE | 2 | 2 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 282 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 6 | 6 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 14 | 13 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 7 | 7 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 111 | not checked | - | - | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL WORTH | 1 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 21 | 16 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 4 | 4 | 0 | 0.00 | - | - |
| STANDS STILL | 342 | 341 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 20 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 12 | not checked | - | - | - | - |
| THE TABLE BINDS | 288 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 4 | 0 | 0.00 | - | - |
| WHO FIGHTS | 8 | 8 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 7 | 7 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p64

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.33 | 2.00 | 33.6 |
| ARMY TABLE | rule | 2.00 | 4.33 | 23.8 |
| CANNON PLANNED TARGET | rule | 4.00 | - | 6.3 |
| PROMISE BY ITS OWN SUM | rule | 1.00 | 0.33 | 38.0 |
| BEST PRIZE | rule | - | 0.67 | 191.9 |
| CHAFF PASSED | rule | 0.67 | - | 1.7 |
| CHARGE NOW FIRST | rule | 0.67 | - | 21.9 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.33 | 14.3 |
| NO REASON | gate | 0.67 | - | 25.1 |
| DEPLOY BY FIGURES | rule | - | 0.33 | 5.8 |
| FALLBACK | gate | 0.33 | - | 7.6 |
| PATHS CROSS | rule | - | 0.33 | 31.8 |
| REDIRECT WEIGHED | rule | - | 0.33 | 71.9 |
| REFUSING RETIRES | rule | - | 0.33 | 2.6 |
| SWIFTSTRIDE BY POINTS | rule | - | 0.33 | 1.3 |

### Plans: gs3-83c8646-p64

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.7 | 55% | 215 | 225 | 104% |
| Mine | join | 2.7 | 100% | 75 | 0 | 0% |
| Mine | move | 25.7 | 100% | 972 | 0 | 0% |
| Mine | shoot | 27.0 | 52% | 937 | 2057 | 220% |
| Opponent | charge | 1.3 | 75% | 60 | 115 | 192% |
| Opponent | move | 29.3 | 94% | 1084 | 0 | 0% |
| Opponent | shoot | 3.3 | 60% | 198 | 118 | 60% |
| Opponent | support | 1.0 | 100% | 1 | 0 | 0% |

### Battle groups: gs3-83c8646-p64

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 2.3 | 57% | 75% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p64

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | Character | 13 | 7 (13) | 7 | 0 | 0 | 62% | 3.0 | 0 (3) | 12 (7) | 0 (3) | 10 (9) | 0 (4) |
| Mine | Clean-up | 3 | 74 (3) | 74 | 0 | 0 | 33% | 1.0 | 0 (1) | 453 (1) | 0 (1) | 227 (2) | 0 (1) |
| Mine | Hammer | 6 | 41 (6) | 0 | 41 | 0 | 83% | 1.0 | - | 61 (4) | 0 (2) | 56 (5) | 0 (1) |
| Mine | Shooter | 10 | 71 (10) | 25 | 46 | 0 | 0% | 1.9 | - | 90 (4) | 51 (6) | 118 (5) | 13 (5) |
| Mine | War machine | 17 | 10 (17) | 10 | 0 | 56 | 6% | 1.4 | 0 (9) | 0 (2) | 30 (6) | 0 (3) | 12 (14) |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 42 | 40% | 3.0 | 0 (4) | - | 0 (1) | 0 (4) | 0 (1) |
| Opponent | Character | 8 | 13 (8) | 13 | 0 | 0 | 75% | 5.0 | 0 (3) | 0 (1) | 28 (4) | 20 (5) | 0 (3) |
| Opponent | Clean-up | 3 | 44 (3) | 0 | 44 | 20 | 33% | 4.0 | 71 (1) | 17 (2) | - | 44 (3) | - |
| Opponent | Fast Hammer | 4 | 44 (4) | 0 | 44 | 24 | 75% | 6.0 | - | 79 (3) | 0 (1) | 61 (2) | 32 (2) |
| Opponent | Hammer | 3 | 30 (3) | 30 | 0 | 42 | 33% | 5.5 | 0 (1) | 35 (2) | - | 30 (3) | - |
| Opponent | Holder | 2 | 0 (2) | 0 | 0 | 100 | 50% | 4.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Opponent | War machine | 2 | 58 (2) | 58 | 0 | 50 | 0% | 1.0 | - | - | 58 (2) | - | 58 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 3.5 | 0 (1) | 0 (1) | - | 0 (2) | - |

### Charged fights: gs3-83c8646-p64

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 3 | 94 | 219 | 2.0 | 1.0 | 110 | 0 | +110 | 0 of 6 | 6 of 6 | - | +110 |
| Opponent | Kingdom of Bretonnia | 1 | 115 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 1 of 2 | 2 of 2 | - | +0 |
| Opponent | Warriors of Chaos | 2 | 0 | 58 | 0.5 | 1.0 | 115 | 0 | +115 | 0 of 1 | 1 of 1 | - | +115 |
| **Opponent** | all armies | 3 | 38 | 38 | 1.0 | 1.0 | 38 | 0 | +38 | 1 of 3 | 3 of 3 | - | +38 |

### Effective charges: gs3-83c8646-p64

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 6 | 0 | 1 (net +139) | 1 (net +0) | 1 (net +80) | 0 | 2 (net +136) | 1 | 20% (1 of 5) |
| Opponent | Kingdom of Bretonnia | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 1 | 0% (0 of 1) |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0 | 0 | 1 (net +115) | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: gs3-83c8646-p64

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 50-54% | 1 | 60 | 139 | +139 | 139 | 0 | +139 | +231.7 |
| Mine | Effective (55-75%) | 1 | 60 | 80 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 76-89% | 1 | 60 | 80 | +80 | 80 | 0 | +80 | +133.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 60 | 136 | +136 | 136 | 0 | +136 | +226.7 |
| Mine | No odds | 1 | 105 | 30 | +167 | 167 | 0 | +167 | +159.0 |
| Mine | All fights | 6 | 68 | 100 | +110 | 110 | 0 | +110 | +162.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 214 | 183 | +0 | 92 | 52 | +40 | +18.6 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 489 | 115 | +115 | 115 | 54 | +61 | +12.4 |
| Opponent | No odds | 1 | 371 | 120 | +0 | 60 | 69 | -9 | -2.4 |
| Opponent | All fights | 3 | 358 | 139 | +38 | 89 | 58 | +31 | +8.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p64 | move | 16 | 3 (19%) | 3 (19%) | 4 (25%) | 9 (56%) |

## Decision items and abilities without guidance

None: every decision item and ability on these lists has its guidance line.

# Doctrine scorecard: gs3-83c8646-p80

### Scorecard: gs3-83c8646-p80

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1327 | 1 | 1 | Mine | no | 2 | 2 | 4 | 0 | 1 | 0 | 0 | 70 |
| L1327 | 1 | 1 | Opponent | no | 6 | 2 | 5 | 4 | 0 | 0 | 0 | 190 |
| L1422 | 6 | 1 | Mine | no | 4 | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 1 | 2 | 3 | 1 | 0 | 0 | 0 | 72 |
| L1519 | 1 | 1 | Mine | no | 5 | 1 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Opponent | no | 3 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 3.7 | 1.7 | 5.3 | 0.0 | 0.3 | 0.0 | 0.0 | 23.3 |
| **Average** | | | Opponent | 0% | 3.3 | 2.0 | 3.3 | 2.7 | 0.0 | 0.0 | 0.0 | 87.3 |

### KPIs: gs3-83c8646-p80

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 7% (1 of 15) | 0% (0 of 12) | 4% (1 of 27) |
| Winner chose to follow up after the loser gave ground |  | 100% (10 of 10); on the table 100% | 71% (5 of 7); on the table 71% | 88% (15 of 17); on the table 88% |
| Winner chose to pursue after the loser fell back in good order |  | - | 33% (1 of 3); on the table 33% | 33% (1 of 3); on the table 33% |
| Winner chose to pursue after the loser fled |  | - | 50% (1 of 2); on the table 50% | 50% (1 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 100% (10 of 10); on the table 100% | 58% (7 of 12); on the table 58% | 77% (17 of 22); on the table 77% |
| Magic missiles tried each own turn | 50%+ | 33% (6 of 18) | 8% (1 of 12) | 23% (7 of 30) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 60% (6 of 10) | 14% (1 of 7) | 41% (7 of 17) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 21% (1254 of 6000) | 25% (1486 of 6000) | 23% (2740 of 12000) |
|   infantry points that never fought | lower | 61% (641 of 1048) | 54% (344 of 641) | 58% (985 of 1689) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 29% (7 of 24) | 58% (11 of 19) | 42% (18 of 43) |
| Bound items with a magic missile used (at least once a game) |  | 100% (3 of 3); 3.7 uses a game | 0.0 uses a game | 100% (3 of 3); 1.8 uses a game |
| Bound items with another spell used |  | 50% (4 of 8); 1.3 uses a game | 0.0 uses a game | 50% (4 of 8); 0.7 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 24% (1397 of 5800) | 53% (2546 of 4778) | 37% (3943 of 10578) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (17%) | 0.0 (0%) | 0.7 (9%) |
| MARCHED: its unit marched | 0.7 (17%) | 0.0 (0%) | 0.7 (9%) |
| IN COMBAT: engaged in combat | 2.0 (50%) | 0.0 (0%) | 2.0 (26%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 2.0 (55%) | 2.0 (26%) |
| FLEEING: fleeing | 0.7 (17%) | 0.0 (0%) | 0.7 (9%) |
| GONE: slain | 0.0 (0%) | 1.7 (45%) | 1.7 (22%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 1.0 | 2.7 | 2.3 | 0.3 | 3.7 |
| not cast | 4.0 | 1.0 | 7.3 | 7.7 | 3.7 | 32.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 3.7 (11%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (67%) | 0.0 (0%) | 0.7 (9%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (9%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.7 (17%) | 0.0 (0%) | 1.0 (14%) | 2.0 (26%) | 0.0 (0%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (0%) | 2.0 (27%) | 2.0 (26%) | 2.0 (55%) | 0.0 (0%) |
| FLEEING: fleeing | 0.7 (17%) | 0.0 (0%) | 0.7 (9%) | 0.7 (9%) | 0.0 (0%) | 1.3 (4%) |
| GONE: slain | 0.7 (17%) | 0.0 (0%) | 1.7 (23%) | 1.7 (22%) | 1.7 (45%) | 3.3 (10%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.3 (33%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.3 (8%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (42%) | 0.0 (0%) | 2.0 (27%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 23.7 (74%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.7 a game | 0.0 a game | 1.3 a game |
| stood (cast and not dispelled) | 86% (6 of 7) | - | 86% (6 of 7) |
| the unit moved after it | 100% (6 of 6) | - | 100% (6 of 6) |
| it charged on its next turn | 17% (1 of 6) | - | 17% (1 of 6) |
| the enemy charged it first | 0% (0 of 6) | - | 0% (0 of 6) |
| it fought by the end of its next turn | 0% (0 of 6) | - | 0% (0 of 6) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 6) | - | 0% (0 of 6) |
| none of these (no charge, no fight, no charge escaped) | 83% (5 of 6) | - | 83% (5 of 6) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 60% (49 of 81) | 67% (26 of 39) | 62% (75 of 120) |
|   cavalry | 73% (8 of 11) | 83% (5 of 6) | 76% (13 of 17) |
|   character | 22% (6 of 27) | 0% (0 of 10) | 16% (6 of 37) |
|   chariot | 50% (2 of 4) | 67% (2 of 3) | 57% (4 of 7) |
|   infantry | 81% (22 of 27) | 95% (19 of 20) | 87% (41 of 47) |
|   war machine | 92% (11 of 12) | - | 92% (11 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (16%) | 0.0 (0%) | 1.7 (11%) |
| CHARGED: it charged | 3.7 (34%) | 1.0 (23%) | 4.7 (31%) |
| IN COMBAT: it fought this turn or the last | 1.7 (16%) | 0.7 (15%) | 2.3 (16%) |
| MOVED: a war machine that moved | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 2.0 (19%) | 1.0 (23%) | 3.0 (20%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (6%) | 0.7 (15%) | 1.3 (9%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (6%) | 1.0 (23%) | 1.7 (11%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.7 | 1.0 | 87% | 3.6 pts | 27 pts |
| character | 3.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 1.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 23.0 | 6.0 | 83% | 6.0 pts | 139 pts |
| war machine | 3.7 | 1.0 | 73% | 2.2 pts | 8 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 7.0 | 3.7 | 5.3 |
| Charges that made contact a game | 5.0 | 3.0 | 4.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.33 declared, 1.33 contact (3 units) | 0.00 declared, 0.00 contact (1 units) | 1.00 declared, 1.00 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 1.00 contact (2 units) | 1.00 declared, 1.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.77 declared, 0.50 contact (22 units) | 0.35 declared, 0.27 contact (26 units) | 0.54 declared, 0.38 contact (48 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 27% (3 of 11) | 100% (1 of 1) | 50% (1 of 2) | 36% (5 of 14) |
| Character in a unit | 67% (2 of 3) | 100% (1 of 1) | - | 75% (3 of 4) |
| Character on its own | 50% (1 of 2) | 50% (1 of 2) | 22% (2 of 9) | 31% (4 of 13) |
| Chariot | 100% (1 of 1) | - | - | 100% (1 of 1) |
| Infantry | 67% (4 of 6) | 0% (0 of 1) | - | 57% (4 of 7) |
| Monster | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Monstrous | - | 0% (0 of 2) | - | 0% (0 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 3 | 100% (10 of 10); on the table 100% | 33% (6 of 18) | 21% | 29% (7 of 24) | 100% (3 of 3); 3.7 uses a game | 50% (4 of 8); 1.3 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 75% (3 of 4); on the table 75% | 0% (0 of 6) | 8% | 50% (4 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 50% (1 of 2); on the table 50% | - | 46% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 50% (3 of 6); on the table 50% | 17% (1 of 6) | 20% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p80, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 60% (3) | 62% (5) | 62% (8) |
| ...free all their last turn and able to turn (per game) | 0.67 | 1.00 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 1.00 | 1.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: gs3-83c8646-p80

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 76% (13 of 17) | 67% (6 of 9) |
| Strategy | Shoot objectives carried out (shot that target) | 55% (12 of 22) | 83% (5 of 6) |
| Strategy | Support requests answered (helper made contact too) | 100% (2 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 100% (1 of 1) | - |
| Strategy | Joined characters whose unit fought | - | 67% (4 of 6) |
| Strategy | Lone characters that fought | 100% (7 of 7) | 78% (7 of 9) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 0.0 | 2.7 |
| Movement | Points that never moved of their own | 23.3 | 87.3 |
| Movement | Fights charged into per game | 4.3 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 11, net +0 | 1 of 8, net -170 |
| Movement | Charges with odds: sweet spot (55-75%) | 3 of 11, net -38 | 2 of 8, net +200 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 11, net +85 | 1 of 8, net +123 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 of 11, net +79 | 1 of 8, net +177 |
| Shooting | Shots by shooting units (incl. breath weapons) | 15.0 | 9.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 53% (24 of 45) | 48% (14 of 29) |
| Shooting | Points destroyed by shooting units | 18.3 | 0.0 |
| Shooting | War machine shots | 3.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 36% (4 of 11) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.3 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 4) | 100% (1 of 1) |
| Magic | Wounds caused by magic missiles | 5.3 | - |
| Magic | Wounds caused by other spells | 4.0 | - |
| Magic | Points destroyed by magic (all spells) | 121.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 0.3 / 2.3 / 0.0 | 1.3 / 0.0 / 0.0 / 0.3 |
| Combat | Points destroyed in combat | 286.0 | 354.7 |
| Combat | Points run down | 116.7 | 133.3 |
| Combat | Net points per charged fight, damage counted | +59 | +78 |
| Combat | Net per 100 charger points, damage counted | +16.4 | +27.8 |
| Combat | First round won (charged fights) | 85% | 78% |
| Combat | Net points per charged fight | +35 | +84 |
| Combat | Net points per supported fight / lone fight | -58 / +52 | - / +84 |
| Combat | Charged fights on a top-3 enemy unit | 4 of 13 | 5 of 9 |
| Game | Points lost | 454.7 | 666.0 |
| Game | VP from objectives | 903.3 | 353.3 |
| Game | Lone holders (player turns) | 3.7 | 3.3 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +771 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 1121
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: gs3-83c8646-p80

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.3 | +126.4 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | 0.7 | +26.5 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 15.0 | +140.5 | 0.0 | 141.0 | 11.0 | +231.8 | 0.0 | 24.0 |
| ASSAILMENT BY POINTS | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.3 | -14.7 | 20.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 3.7 | +158.5 | 105.0 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.7 | -19.7 | 81.7 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.3 | +44.9 | 0.0 | 48.0 |
| CHAFF PASSED | 0.3 | -0.3 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 1.7 | +58.7 | 0.0 | 192.3 | 1.7 | +48.6 | 0.0 | 48.0 |
| CHAMPION KNOWS CHALLENGE | 0.7 | -20.5 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 9.3 | -109.1 | 0.0 | 384.0 | 19.3 | -980.5 | 0.0 | 635.7 |
| CHARGE NOW FIRST | 3.7 | +0.0 | 129.7 | 133.3 | 1.7 | +0.0 | 283.7 | 16.7 |
| CLOSES ON WHAT IT BEATS | 10.7 | +0.0 | 0.0 | 139.0 | 13.0 | +0.0 | 0.0 | 298.0 |
| COMBAT PIVOT | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 1.0 | +48.9 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 7.0 | -326.5 | 0.0 | 59.0 | 6.0 | -425.3 | 0.0 | 101.7 |
| DEPLOY BY FIGURES | 7.0 | -17.9 | 0.0 | 0.0 | 7.0 | +76.9 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | +15.8 | 0.0 | 0.0 | 0.3 | -20.2 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 3.3 | +24.9 | 243.7 | 171.7 | 2.3 | +43.1 | 275.0 | 57.3 |
| FALL BACK GOOD ORDER | 5.3 | +0.0 | 184.3 | 171.7 | 2.3 | +8.4 | 242.7 | 57.3 |
| FALLS SHORT | 10.3 | +67.1 | 0.0 | 493.3 | 10.3 | +128.4 | 0.0 | 225.3 |
| FEATURE BUFFS | 1.3 | +6.3 | 0.0 | 0.0 | 1.0 | +11.6 | 0.0 | 18.3 |
| FIGHT LIFT | 0.3 | +3.3 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 1.3 | +38.5 | 20.0 | 0.0 | 0.3 | +0.4 | 50.3 | 24.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 85.0 | +8669.7 | 799.0 | 1199.7 | 67.0 | +2376.7 | 434.7 | 1092.3 |
| FLANK NOT WEIGHED | 6.3 | +0.0 | 0.0 | 100.7 | 6.7 | +0.0 | 0.0 | 58.3 |
| FOCUS FIRE | 0.3 | +4.9 | 62.0 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 2.3 | +420.8 | 0.0 | 0.0 | 1.0 | +237.6 | 0.0 | 0.0 |
| FOOT FIRST | 32.0 | +0.0 | 0.0 | 342.3 | - | - | - | - |
| FOUR ROUNDS | 7.0 | +653.8 | 310.0 | 171.7 | 3.0 | +124.0 | 334.0 | 57.3 |
| FREED FROM HIS FIGHT | 5.3 | +0.0 | 0.0 | 100.7 | 6.0 | +0.0 | 0.0 | 40.0 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -6.8 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 1.0 | +52.5 | 0.0 | 115.7 | - | - | - | - |
| GIVES UP | 1.7 | -10.9 | 80.3 | 0.0 | 0.3 | -4.7 | 0.0 | 0.0 |
| GOAL ROUTE | 0.3 | +18.3 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 11.0 | +712.3 | 0.0 | 0.0 | 5.3 | +459.6 | 0.0 | 233.3 |
| GUN MASK | 3.0 | +278.7 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 3.3 | +0.0 | 0.0 | 100.7 | 5.0 | +0.0 | 0.0 | 40.0 |
| HIS CHARGE BY HIS RUN | 6.0 | +0.0 | 0.0 | 384.0 | 12.3 | +0.0 | 0.0 | 278.3 |
| HIS CHARGE LIST | 4.0 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 51.7 |
| HIS LEGAL MOVES | 2.3 | +0.0 | 0.0 | 133.3 | 4.7 | +0.0 | 0.0 | 24.0 |
| HIS MOVE AND SHOT | 0.7 | -7.2 | 0.0 | 0.0 | 4.7 | -39.1 | 0.0 | 55.0 |
| HIS ONE QUARTER | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 9.3 | +0.0 | 0.0 | 133.3 | 9.3 | +0.0 | 0.0 | 24.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 26.3 | +691.4 | 0.0 | 543.7 | 41.7 | +1419.8 | 0.0 | 577.3 |
| HIS SHOTS BY HIS RUN | 17.3 | +254.3 | 0.0 | 538.3 | 41.7 | +678.5 | 0.0 | 913.7 |
| HIS TURN DENIED | 1.0 | +22.0 | 36.7 | 0.0 | 0.7 | +7.2 | 100.0 | 0.0 |
| HOLD ODDS | 19.7 | +0.0 | 0.0 | 201.3 | 15.7 | +0.0 | 0.0 | 240.7 |
| HOLDER ASSIGNMENT | 13.7 | +1339.7 | 0.0 | 100.7 | 10.3 | +831.3 | 0.0 | 165.7 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 5.7 | -243.8 | 248.0 | 133.3 | 2.3 | -103.0 | 283.7 | 16.7 |
| IDLE COST | 6.0 | -134.7 | 0.0 | 132.3 | 8.7 | -117.8 | 0.0 | 277.0 |
| JOINT CHARGE NOW | 1.3 | +232.6 | 0.0 | 38.3 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +42.4 | 0.0 | 0.0 | 1.3 | +32.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 6.7 | +0.0 | 140.7 | 521.7 | 11.0 | +0.0 | 272.3 | 231.7 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.7 | +22.2 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.3 | +1.3 | 0.0 | 16.7 |
| LOST AFTER ESCAPE | 2.7 | +0.1 | 82.0 | 38.3 | 1.7 | +3.6 | 234.0 | 57.3 |
| LOST CHARGE | 0.3 | -0.9 | 24.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | - | - | - | - | 1.3 | +20.0 | 0.0 | 62.0 |
| MANOEUVRE | 1.0 | +0.0 | 0.0 | 50.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +1.1 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +17.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | - | - | - | - | 0.3 | +20.5 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.7 | +77.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | +2.5 | 0.0 | 0.0 | 0.3 | +56.4 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.0 | +10.5 | 0.0 | 133.3 | 0.7 | +11.4 | 0.0 | 0.0 |
| MEETS IN TIME | 4.0 | +361.7 | 0.0 | 0.0 | 4.3 | +352.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 5.0 | +162.3 | 0.0 | 133.3 | 0.7 | +3.4 | 0.0 | 63.3 |
| MISSILES NEXT TURN | 6.3 | +75.1 | 0.0 | 133.3 | 1.3 | +4.7 | 0.0 | 63.3 |
| MOVE ORDER | 2.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 18.3 | 116.7 |
| MOVE SPELL SPOT | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 12.3 | +1339.0 | 0.0 | 38.3 | 7.7 | +587.4 | 0.0 | 24.0 |
| MOVES UNITS SPELL | 0.3 | +2.4 | 0.0 | 0.0 | 0.3 | +1.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 4.3 | +189.5 | 0.0 | 50.3 | 6.7 | +200.4 | 0.0 | 86.3 |
| NEAREST TO GOAL | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 9.3 | +1006.5 | 0.0 | 38.3 | 5.0 | +440.9 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.7 | -12.3 | 0.0 | 24.0 |
| NO DOUBLE ROUNDS | 6.3 | -245.7 | 291.7 | 171.7 | 1.3 | -58.8 | 200.7 | 24.0 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.3 | -0.7 | 0.0 | 133.3 | - | - | - | - |
| OFF BEST | 3.0 | -163.6 | 0.0 | 0.0 | 3.0 | -89.1 | 0.0 | 134.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 7.7 | -185.3 | 0.0 | 171.7 | 3.7 | -68.3 | 0.0 | 24.0 |
| ONE JOINT FIGURE | 0.7 | +150.8 | 0.0 | 38.3 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 5.3 | +155.4 | 0.0 | 100.7 | 4.7 | -27.5 | 0.0 | 56.7 |
| ONE PROMISE A TARGET | 2.0 | -94.7 | 0.0 | 0.0 | 0.3 | -15.7 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 1.0 | +55.4 | 55.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 1.7 | +19.1 | 97.3 | 0.0 | 0.3 | +7.6 | 0.0 | 0.0 |
| PLAN RESULT | 40.3 | +711.0 | 206.0 | 860.3 | 33.7 | +424.5 | 275.3 | 912.3 |
| PROMISE BELOW ZERO | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 11.0 | -148.0 | 0.0 | 0.0 | 8.7 | -283.9 | 0.0 | 24.0 |
| PROMISE IN STEPS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 1.0 | -0.5 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -130.9 | 0.0 | 0.0 | 0.7 | -21.4 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | - | - | - | - | 0.7 | -2.3 | 0.0 | 0.0 |
| QUARTER ODDS | 13.0 | +1825.8 | 20.0 | 0.0 | 8.0 | +802.6 | 0.0 | 16.7 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | +9.9 | 0.0 | 48.0 |
| REDIRECT COUNTER | - | - | - | - | 2.3 | +45.4 | 0.0 | 69.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 2.0 | +17.3 | 0.0 | 105.3 |
| REFORMS TO MEET IT | 3.3 | -146.4 | 0.0 | 38.3 | 2.0 | -50.2 | 0.0 | 0.0 |
| REFUSING RETIRES | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 16.7 |
| RESERVE FALL BACK | - | - | - | - | 1.0 | +32.0 | 0.0 | 24.0 |
| RISK BY ARC | 6.3 | +191.5 | 291.7 | 171.7 | 2.3 | +21.6 | 293.0 | 57.3 |
| RISK ON THE WAY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.7 | -32.8 | 0.0 | 0.0 | 2.0 | -24.2 | 224.7 | 16.7 |
| RUN DOWN | 1.3 | -13.5 | 0.0 | 0.0 | 3.0 | -20.2 | 334.0 | 57.3 |
| SCOUT SPOT | - | - | - | - | 0.7 | +0.5 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 1.0 | +1.3 | 0.0 | 192.3 | 0.7 | +37.7 | 0.0 | 0.0 |
| SECOND LOOK | 0.7 | +31.7 | 25.0 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | 2.0 | +13.4 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 1.0 | -75.9 | 0.0 | 0.0 | 2.3 | -192.6 | 0.0 | 164.0 |
| SET UP BY THE SET | 3.0 | -90.7 | 0.0 | 0.0 | 3.7 | +285.0 | 0.0 | 188.0 |
| SET UP TOGETHER | - | - | - | - | 1.3 | +20.0 | 0.0 | 62.0 |
| SET-UP ANY TARGET | 0.3 | +58.3 | 0.0 | 0.0 | - | - | - | - |
| SET-UP MISSED | 0.3 | +66.8 | 133.3 | 133.3 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.7 | +0.7 | 0.0 | 0.0 | 0.3 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 7.3 | +0.0 | 0.0 | 192.3 | 2.3 | +0.0 | 0.0 | 105.7 |
| SHOOTS FROM THE BEST SPOT | 3.0 | +22.8 | 134.0 | 192.3 | 0.7 | +57.2 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.7 | -6.9 | 18.3 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 13.7 | +114.8 | 0.0 | 302.0 | 32.7 | -183.4 | 0.0 | 750.0 |
| SHOTS AFTER THE MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.3 | +625.3 | 0.0 | 271.7 | 9.0 | +138.8 | 0.0 | 151.0 |
| SPELL SETS UP CHARGE | 0.3 | +58.3 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 1.0 | +10.3 | 133.3 | 133.3 | 3.0 | +23.6 | 20.0 | 20.0 |
| SPELLS IN THE FIGHT | 1.3 | +20.6 | 87.0 | 133.3 | 1.3 | -68.2 | 234.0 | 40.7 |
| SPOT AS THE GAME MOVES | 6.3 | +0.0 | 0.0 | 141.7 | 7.3 | +0.0 | 0.0 | 250.7 |
| STAND AND SHOOT | 0.7 | -2.9 | 18.3 | 0.0 | 0.7 | -2.9 | 100.0 | 0.0 |
| STANDS FOR A REASON | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| STANDS STILL | 27.0 | +0.0 | 489.0 | 352.0 | 13.3 | +0.0 | 100.7 | 36.7 |
| STAY WORTH | 24.3 | +361.5 | 355.0 | 312.7 | 7.0 | +40.1 | 100.7 | 72.0 |
| STRIKE BY THE ODDS | 1.0 | +8.5 | 20.0 | 0.0 | 0.3 | +3.9 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.3 | +158.5 | 0.0 | 0.0 | 2.0 | +142.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 18.3 | 0.0 | 0.3 | +0.0 | 133.3 | 16.7 |
| SUPPORT WORKED OUT | 2.3 | +158.5 | 0.0 | 0.0 | 2.0 | +142.0 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.7 | +2.1 | 0.0 | 38.3 | 0.7 | +3.3 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +3.2 | 0.0 | 0.0 | 0.3 | +0.5 | 0.0 | 116.7 |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.7 | -134.9 | 0.0 | 0.0 | 0.7 | -25.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.7 | +0.0 | 0.0 | 50.3 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.7 | +0.0 | 0.0 | 100.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.7 | +0.0 | 0.0 | 88.7 | 3.3 | +0.0 | 0.0 | 43.3 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 25.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 38.7 | +0.0 | 0.0 | 514.0 | 31.0 | +0.0 | 0.0 | 504.0 |
| TIED UP BY THE SUM | 4.0 | +466.6 | 209.7 | 133.3 | 0.7 | +101.0 | 100.0 | 0.0 |
| TIME ON OUR SIDE | 20.0 | +336.4 | 0.0 | 171.7 | 18.3 | +202.1 | 100.7 | 163.7 |
| WAITS AGAIN | 3.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -0.9 | 0.0 | 0.0 |
| WEAPON BY POINTS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 0.7 | -71.2 | 0.0 | 0.0 | 2.3 | -47.8 | 266.7 | 50.0 |
| WHO FIGHTS | 0.7 | -10.9 | 20.0 | 38.3 | 0.7 | +0.2 | 50.3 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +139.0 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.3 | -0.6 | 0.0 | 0.0 | 1.3 | +35.2 | 133.3 | 33.3 |
| WHOLE FIGHT DANGER | 0.3 | -6.2 | 0.0 | 50.3 | 5.0 | -342.0 | 0.0 | 36.7 |
| WHOLE FIGHT GAIN | 0.3 | +21.4 | 0.0 | 0.0 | - | - | - | - |
| WOUNDED STAYS OUT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | - | - | - | - | 5.7 | +263.5 | 0.0 | 40.0 |

### Rule changes: gs3-83c8646-p80

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HOLDER ASSIGNMENT | 72 | 72 | 68 | 22.67 | +4327 | +63.6 |
| ARMY TABLE | 78 | 78 | 62 | 20.67 | +1014 | +16.3 |
| LEGAL CHARGES ONLY | 53 | 53 | 53 | 17.67 | +0 | +0.0 |
| FIVE ACTION | 456 | 444 | 40 | 13.33 | +1281 | +32.0 |
| HIS SHOT LIST | 204 | 197 | 37 | 12.33 | +771 | +20.8 |
| MOVE TO CHARGE COMPUTED | 60 | 57 | 37 | 12.33 | +1167 | +31.5 |
| HIS SHOTS BY HIS RUN | 177 | 170 | 26 | 8.67 | +387 | +14.9 |
| THE TABLE AGAIN | 36 | 36 | 26 | 8.67 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 43 | 43 | 25 | 8.33 | +1106 | +44.2 |
| SHOT RISK POINTS | 139 | 137 | 22 | 7.33 | +419 | +19.0 |
| DEPLOY BY FIGURES | 42 | 42 | 20 | 6.67 | +223 | +11.2 |
| PROMISE BY ITS OWN SUM | 59 | 59 | 20 | 6.67 | -1296 | -64.8 |
| FOUR ROUNDS | 30 | 28 | 18 | 6.00 | +711 | +39.5 |
| OFF BEST | 18 | 18 | 18 | 6.00 | -758 | -42.1 |
| RISK BY ARC | 26 | 25 | 13 | 4.33 | +228 | +17.5 |
| GOAL WALK | 49 | 49 | 12 | 4.00 | +758 | +63.2 |
| TIED UP BY THE SUM | 14 | 12 | 12 | 4.00 | +216 | +18.0 |
| MEETS IN TIME | 25 | 25 | 11 | 3.67 | +575 | +52.3 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 115 | 85 | 11 | 3.67 | +77 | +7.0 |
| CHALLENGE BY POINTS | 10 | 10 | 10 | 3.33 | +322 | +32.2 |
| CHARGE LOSSES | 86 | 85 | 10 | 3.33 | +953 | +95.3 |
| FOLLOW UP WEIGHED | 10 | 10 | 10 | 3.33 | +1975 | +197.5 |
| LANE BY FIGURES | 8 | 8 | 8 | 2.67 | +225 | +28.2 |
| STAY WORTH | 94 | 84 | 8 | 2.67 | +109 | +13.6 |
| IDLE COST | 44 | 31 | 7 | 2.33 | +16 | +2.3 |
| ONE PROMISE A TARGET | 7 | 7 | 7 | 2.33 | -331 | -47.3 |
| CHARGE NOW FIRST | 16 | 16 | 6 | 2.00 | -190 | -31.7 |
| EXACT ROUND | 17 | 16 | 6 | 2.00 | +79 | +13.2 |
| REDIRECT FOR A FRIEND IN REACH | 6 | 6 | 6 | 2.00 | +26 | +4.3 |
| SET UP BY THE SET | 20 | 20 | 6 | 2.00 | +820 | +136.7 |
| COMBAT PIVOT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| COVER ONCE | 39 | 17 | 4 | 1.33 | +48 | +12.1 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | +698 | +174.4 |
| QUARTER ODDS | 63 | 61 | 4 | 1.33 | +232 | +58.0 |
| REFUSING RETIRES | 8 | 8 | 4 | 1.33 | -29 | -7.1 |
| SHOOTS FROM THE BEST SPOT | 11 | 11 | 4 | 1.33 | +16 | +3.9 |
| SHOTS IN THE MOVE | 76 | 59 | 4 | 1.33 | +215 | +53.8 |
| STRIKE BY THE ODDS | 4 | 4 | 4 | 1.33 | +37 | +9.3 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FIRE IN ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 3 | 3 | 3 | 1.00 | +158 | +52.5 |
| HARD STAY DROPPED | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HIS TURN DENIED | 5 | 5 | 3 | 1.00 | +39 | +13.0 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +96 | +32.0 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +6 | +2.0 |
| SPELLS IN THE FIGHT | 8 | 8 | 3 | 1.00 | +24 | +7.9 |
| SUPPORT ADDS | 13 | 13 | 3 | 1.00 | +117 | +39.1 |
| SUPPORT WORKED OUT | 13 | 13 | 3 | 1.00 | +117 | +39.1 |
| WHOLE FIGHT | 5 | 5 | 3 | 1.00 | +60 | +19.9 |
| AFTERMATH WITH FRIENDS | 2 | 2 | 2 | 0.67 | +80 | +39.8 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 4 | 4 | 2 | 0.67 | +26 | +12.8 |
| GUN MASK | 9 | 9 | 2 | 0.67 | +154 | +76.9 |
| HIS MOVE AND SHOT | 16 | 16 | 2 | 0.67 | +10 | +5.0 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +67 | +33.4 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -231 | -115.7 |
| MOVES UNITS SPELL | 2 | 2 | 2 | 0.67 | +12 | +5.8 |
| NEARER NOT NEEDED | 33 | 30 | 2 | 0.67 | +68 | +34.0 |
| OVERRUNS AWAY | 6 | 6 | 2 | 0.67 | +44 | +21.8 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -7 | -3.4 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SEARCH SPOT | 5 | 5 | 2 | 0.67 | +117 | +58.5 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +95 | +47.6 |
| SHOTS AFTER THE MOVES | 15 | 15 | 2 | 0.67 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 2 | 2 | 2 | 0.67 | +11 | +5.6 |
| THE ROW IN ITS ORDER | 10 | 2 | 2 | 0.67 | +0 | +0.0 |
| WEAPON BY POINTS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +379 | +379.3 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +2 | +1.8 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.33 | +0 | +0.1 |
| CANNON PLANNED TARGET | 11 | 11 | 1 | 0.33 | +0 | +0.0 |
| CARRIES OUT SET-UP | 2 | 2 | 1 | 0.33 | -59 | -59.2 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -1 | -0.8 |
| FALLS SHORT | 62 | 49 | 1 | 0.33 | +6 | +5.6 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +15 | +14.8 |
| GOAL ROUTE | 1 | 1 | 1 | 0.33 | +55 | +55.0 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +54 | +53.8 |
| MAX FOR POSITIONING | 5 | 5 | 1 | 0.33 | +1 | +0.7 |
| MISSILES IN THE MOVE | 17 | 11 | 1 | 0.33 | +52 | +51.6 |
| ONE FIGHT FORMULA | 34 | 18 | 1 | 0.33 | +10 | +10.1 |
| ONE OBJECTIVE FORMULA | 30 | 21 | 1 | 0.33 | +44 | +43.9 |
| OPENS UP | 3 | 3 | 1 | 0.33 | +16 | +16.5 |
| PROMISE KNOWS THE FIGHT | 6 | 5 | 1 | 0.33 | -2 | -1.6 |
| PROMISE READS THE TABLE | 3 | 3 | 1 | 0.33 | +88 | +87.7 |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 1 | 0.33 | +5 | +4.8 |
| REDIRECT COUNTER | 7 | 6 | 1 | 0.33 | +28 | +27.7 |
| SET UP TOGETHER | 4 | 4 | 1 | 0.33 | +13 | +12.9 |
| SUPPORT NARROWED | 2 | 2 | 1 | 0.33 | -24 | -24.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -3 | -2.7 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +408 | +408.1 |
| WHOLE FIGHT DANGER | 16 | 16 | 1 | 0.33 | +212 | +211.5 |
| WOUNDS ON THE RANKS | 17 | 17 | 1 | 0.33 | +0 | +0.1 |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 6 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 71 | 71 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | not checked | - | - | - | - |
| FALL BACK GOOD ORDER | 23 | 22 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 7 | 7 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FIGHT TO THE END | 5 | 5 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 39 | not checked | - | - | - | - |
| FOOT FIRST | 96 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 34 | 32 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 6 | 5 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 25 | 23 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 55 | 54 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 36 | 34 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 21 | 21 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 10 | 10 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 56 | 55 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 106 | 106 | 0 | 0.00 | - | - |
| HONEST WORTH | 24 | 22 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 6 | 6 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 13 | 13 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 4 | not checked | - | - | - | - |
| MANOEUVRE | 7 | 7 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH CHECK | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 23 | 14 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 6 | not checked | - | - | - | - |
| NEAREST TO GOAL | 7 | 7 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 2 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 23 | 21 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 2 | 2 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 222 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 16 | 16 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 8 | 7 | 0 | 0.00 | - | - |
| RUN DOWN | 13 | 12 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 10 | 10 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 29 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 41 | 36 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 4 | 4 | 0 | 0.00 | - | - |
| STANDS STILL | 121 | 115 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 3 | 3 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 4 | 4 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE PROMISE ADDS | 4 | 3 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 18 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 9 | not checked | - | - | - | - |
| THE TABLE BINDS | 209 | not checked | - | - | - | - |
| WAITS AGAIN | 11 | 11 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 9 | 9 | 0 | 0.00 | - | - |
| WHO FIGHTS | 4 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p80

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 3.00 | 3.67 | 64.8 |
| JOB FIRST | gate | 2.33 | 2.33 | 28.6 |
| ARMY TABLE | rule | 1.67 | 1.67 | 28.9 |
| HOLDER ASSIGNMENT | rule | 1.00 | 1.33 | 27.6 |
| ONE PROMISE A TARGET | rule | 2.00 | 0.33 | 47.3 |
| CHARGE NOW FIRST | rule | 1.00 | 1.00 | 31.7 |
| REFUSING RETIRES | rule | 0.33 | 0.67 | 13.6 |
| MARCH OF THE TABLE | rule | 0.67 | - | 115.7 |
| NO REASON | gate | 0.67 | - | 174.9 |
| PROMISE SHOT AWAY | rule | - | 0.67 | 3.4 |
| AFTERMATH BAND | gate | - | 0.33 | 3.4 |
| CARRIES OUT SET-UP | rule | 0.33 | - | 59.2 |
| CHAFF PASSED | rule | 0.33 | - | 0.8 |
| FALLBACK | gate | - | 0.33 | 5.2 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | - | 1.6 |
| RESERVE FALL BACK | rule | - | 0.33 | 3.3 |
| SUPPORT NARROWED | rule | 0.33 | - | 24.0 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 2.7 |

### Plans: gs3-83c8646-p80

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 6.7 | 50% | 1019 | 462 | 45% |
| Mine | move | 27.7 | 96% | 2274 | 0 | 0% |
| Mine | shoot | 6.0 | 67% | 631 | 249 | 39% |
| Opponent | charge | 2.7 | 75% | 228 | 394 | 172% |
| Opponent | join | 1.0 | 67% | 31 | 0 | 0% |
| Opponent | move | 28.0 | 87% | 996 | 0 | 0% |
| Opponent | shoot | 1.7 | 40% | 59 | 31 | 53% |
| Opponent | support | 0.3 | 100% | 9 | 0 | 0% |

### Battle groups: gs3-83c8646-p80

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 2.3 | 29% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p80

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 7 | 40 (7) | 40 | 0 | 26 | 0% | 1.4 | 0 (1) | 55 (4) | 22 (2) | 53 (4) | 26 (3) |
| Mine | Clean-up | 2 | 124 (2) | 0 | 124 | 0 | 0% | 4.0 | 0 (1) | 157 (1) | - | 124 (2) | - |
| Mine | Fast Hammer | 11 | 54 (11) | 11 | 43 | 29 | 9% | 2.9 | 53 (3) | 52 (4) | 57 (4) | 33 (8) | 114 (3) |
| Mine | Shooter | 5 | 40 (5) | 29 | 11 | 22 | 0% | 1.2 | 0 (1) | 48 (4) | - | 40 (5) | - |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.5 | - | - | 0 (2) | - | 0 (2) |
| Opponent | Chaff | 9 | 96 (9) | 27 | 69 | 100 | 44% | 2.0 | 0 (4) | 140 (4) | 210 (1) | 96 (9) | - |
| Opponent | Character | 9 | 54 (9) | 54 | 0 | 23 | 11% | 3.0 | - | 77 (5) | 4 (3) | 59 (6) | 42 (2) |
| Opponent | Fast Hammer | 6 | 14 (6) | 10 | 4 | 13 | 33% | 3.8 | - | 0 (3) | 23 (3) | 16 (5) | 0 (1) |
| Opponent | Hammer | 4 | 17 (4) | 0 | 17 | 35 | 25% | 2.0 | 0 (1) | 24 (2) | 0 (1) | 22 (3) | 0 (1) |
| Opponent | Holder | 4 | 38 (4) | 0 | 38 | 100 | 0% | 1.2 | 0 (1) | 49 (3) | - | 82 (2) | 0 (2) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Wizard | 6 | 0 (6) | 0 | 0 | 32 | 33% | 2.5 | 0 (1) | 0 (1) | 0 (4) | 0 (4) | 0 (2) |

### Charged fights: gs3-83c8646-p80

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 3 | 140 | 190 | 4.3 | 1.2 | 44 | 9 | +35 | 4 of 13 | 11 of 13 | -58 | +52 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 350 | -350 | 1 of 1 | 1 of 1 | - | -350 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 602 | 4.0 | 1.0 | 150 | 18 | +132 | 1 of 4 | 4 of 4 | - | +132 |
| Opponent | Vampire Counts | 1 | 0 | 747 | 4.0 | 1.0 | 187 | 42 | +144 | 3 of 4 | 2 of 4 | - | +144 |
| **Opponent** | all armies | 3 | 0 | 450 | 3.0 | 1.0 | 150 | 66 | +84 | 5 of 9 | 7 of 9 | - | +84 |

### Effective charges: gs3-83c8646-p80

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 13 | 1 (net +0) | 0 | 3 (net -38) | 0 | 3 (net +85) | 4 (net +79) | 2 | 27% (3 of 11) |
| Opponent | Tomb Kings of Khemri | 4 | 0 | 0 | 0 | 2 (net +115) | 1 (net +123) | 1 (net +177) | 0 | 0% (0 of 4) |
| Opponent | Vampire Counts | 4 | 1 (net -170) | 0 | 2 (net +200) | 1 (net +347) | 0 | 0 | 0 | 50% (2 of 4) |

### Charged fights, damage counted: gs3-83c8646-p80

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 398 | 380 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 3 | 304 | 213 | -38 | 73 | 38 | +34 | +11.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 257 | 126 | +79 | 79 | 0 | +79 | +30.8 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 493 | 61 | +85 | 96 | 0 | +96 | +19.4 |
| Mine | No odds | 2 | 416 | 209 | +0 | 108 | 80 | +27 | +6.5 |
| Mine | All fights | 13 | 358 | 163 | +35 | 80 | 21 | +59 | +16.4 |
| Opponent | Long shot (under 50%) | 1 | 50 | 342 | -170 | 0 | 170 | -170 | -340.0 |
| Opponent | Effective (55-75%) | 2 | 260 | 315 | +200 | 205 | 0 | +205 | +78.5 |
| Opponent | 76-89% | 3 | 246 | 183 | +192 | 226 | 56 | +170 | +69.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 431 | 177 | +177 | 177 | 0 | +177 | +41.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 431 | 123 | +123 | 123 | 0 | +123 | +28.5 |
| Opponent | No odds | 1 | 350 | 497 | -350 | 0 | 350 | -350 | -100.0 |
| Opponent | All fights | 9 | 280 | 258 | +84 | 154 | 76 | +78 | +27.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p80 | move | 26 | 6 (23%) | 5 (19%) | 6 (23%) | 14 (54%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1327 |
| Elixir of Power | Opponent | L1519 |
| Invocation of Nehek | Opponent | L1327 |
| Opal Amulet | Mine | L1422 |
| Ring of Doom | Mine | L1519 |
| Standard of the Fell Warrior | Mine | L1327 |

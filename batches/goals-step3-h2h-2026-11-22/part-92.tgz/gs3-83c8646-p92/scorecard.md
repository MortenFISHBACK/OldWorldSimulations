# Doctrine scorecard: gs3-83c8646-p92

### Scorecard: gs3-83c8646-p92

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1331 | 5 | 1 | Mine | yes | - | 2 | 5 | 2 | 1 | 0 | 0 | 317 |
| L1331 | 5 | 1 | Opponent | yes | - | 4 | 1 | 4 | 0 | 0 | 0 | 170 |
| L1427 | 5 | 1 | Mine | yes | - | 3 | 6 | 1 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | no | - | - | 1 | 1 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | no | - | 6 | 1 | 1 | 1 | 0 | 0 | 60 |
| L1523 | 5 | 1 | Opponent | yes | - | 3 | 3 | 3 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 67% | - | 3.7 | 4.0 | 1.3 | 0.7 | 0.0 | 0.0 | 125.7 |
| **Average** | | | Opponent | 67% | - | 3.5 | 1.7 | 2.7 | 0.3 | 0.0 | 0.0 | 56.7 |

### KPIs: gs3-83c8646-p92

Rules off - Opponent only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 15) | 0% (0 of 17) | 0% (0 of 32) |
| Winner chose to follow up after the loser gave ground |  | 88% (7 of 8); on the table 88% | 100% (3 of 3); on the table 100% | 91% (10 of 11); on the table 91% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | 0% (0 of 4); on the table 25% | 20% (1 of 5); on the table 40% |
| Winner chose to follow up or pursue (all three) |  | 89% (8 of 9); on the table 89% | 43% (3 of 7); on the table 57% | 69% (11 of 16); on the table 75% |
| Magic missiles tried each own turn | 50%+ | 0% (0 of 6) | 33% (4 of 12) | 22% (4 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 0% (0 of 4) | 40% (4 of 10) | 29% (4 of 14) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 50% (4 of 8) | 50% (4 of 8) |
| Points that never fought | lower | 37% (2203 of 6000) | 38% (2253 of 6000) | 37% (4456 of 12000) |
|   infantry points that never fought | lower | 71% (746 of 1048) | 78% (613 of 787) | 74% (1359 of 1835) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 67% (16 of 24) | 83% (19 of 23) | 74% (35 of 47) |
| Bound items with a magic missile used (at least once a game) |  | 100% (3 of 3); 4.0 uses a game | 0% (0 of 1); 0.0 uses a game | 75% (3 of 4); 2.0 uses a game |
| Bound items with another spell used |  | 38% (3 of 8); 2.0 uses a game | 0.0 uses a game | 38% (3 of 8); 1.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 63% (3668 of 5800) | 76% (3784 of 4992) | 69% (7452 of 10792) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (17%) | 2.0 (75%) | 2.3 (50%) |
| MARCHED: its unit marched | 0.7 (33%) | 0.0 (0%) | 0.7 (14%) |
| CHARGED: its unit charged | 0.3 (17%) | 0.0 (0%) | 0.3 (7%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (25%) | 0.7 (14%) |
| FLEEING: fleeing | 0.7 (33%) | 0.0 (0%) | 0.7 (14%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 5.3 | 2.7 | 3.3 | 1.3 | 5.0 |
| not cast | 4.7 | 3.3 | 2.7 | 4.7 | 23.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (40%) | 0.3 (12%) | 2.3 (50%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (14%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (7%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 1.3 (40%) | 1.3 (50%) | 0.7 (14%) | 0.0 (0%) |
| FLEEING: fleeing | 0.7 (14%) | 0.0 (0%) | 0.7 (25%) | 0.7 (14%) | 2.0 (9%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.7 (20%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.0 (86%) | 0.0 (0%) | 0.3 (12%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 20.0 (87%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 3.3 a game | 0.0 a game | 1.7 a game |
| stood (cast and not dispelled) | 100% (4 of 4) | - | 100% (4 of 4) |
| the unit moved after it | 100% (4 of 4) | - | 100% (4 of 4) |
| it charged on its next turn | 25% (1 of 4) | - | 25% (1 of 4) |
| the enemy charged it first | 0% (0 of 4) | - | 0% (0 of 4) |
| it fought by the end of its next turn | 0% (0 of 4) | - | 0% (0 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 4) | - | 0% (0 of 4) |
| none of these (no charge, no fight, no charge escaped) | 75% (3 of 4) | - | 75% (3 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 72% (60 of 83) | 58% (22 of 38) | 68% (82 of 121) |
|   cavalry | 92% (11 of 12) | 100% (9 of 9) | 95% (20 of 21) |
|   character | 20% (5 of 25) | 0% (0 of 9) | 15% (5 of 34) |
|   chariot | 100% (6 of 6) | - | 100% (6 of 6) |
|   infantry | 93% (26 of 28) | 65% (13 of 20) | 81% (39 of 48) |
|   war machine | 100% (12 of 12) | - | 100% (12 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (22%) | 0.0 (0%) | 1.7 (13%) |
| CHARGED: it charged | 2.7 (35%) | 0.7 (12%) | 3.3 (26%) |
| FLEEING: it fled or was fleeing | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |
| NO TARGET IN RANGE | 2.3 (30%) | 2.3 (44%) | 4.7 (36%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (6%) | 0.3 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (9%) | 2.0 (38%) | 2.7 (21%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 10.3 | 1.3 | 87% | 1.8 pts | 19 pts |
| character | 3.0 | 0.7 | 89% | 5.2 pts | 16 pts |
| chariot | 2.0 | 0.7 | 83% | 10.8 pts | 22 pts |
| infantry | 22.7 | 11.3 | 65% | 10.1 pts | 229 pts |
| war machine | 4.0 | 1.7 | 75% | 10.5 pts | 42 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.7 | 2.0 | 3.3 |
| Charges that made contact a game | 4.0 | 1.3 | 2.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 1.00 contact (1 units) | 1.00 declared, 1.00 contact (1 units) | 1.00 declared, 1.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 1.00 contact (2 units) | 0.00 declared, 0.00 contact (1 units) | 0.67 declared, 0.67 contact (3 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.50 declared, 0.41 contact (22 units) | 0.20 declared, 0.12 contact (25 units) | 0.34 declared, 0.26 contact (47 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 77% (10 of 13) | 100% (1 of 1) | 100% (2 of 2) | 81% (13 of 16) |
| Character in a unit | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Character on its own | 100% (4 of 4) | 100% (2 of 2) | 44% (4 of 9) | 67% (10 of 15) |
| Chariot | 100% (1 of 1) | - | - | 100% (1 of 1) |
| Infantry | 75% (6 of 8) | 100% (1 of 1) | - | 78% (7 of 9) |
| Monster | 75% (3 of 4) | - | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 3 | 89% (8 of 9); on the table 89% | 0% (0 of 6) | 37% | 67% (16 of 24) | 100% (3 of 3); 4.0 uses a game | 38% (3 of 8); 2.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 67% (2 of 3); on the table 67% | - | 69% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 50% (1 of 2); on the table 50% | 33% (2 of 6) | 9% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 0% (0 of 2); on the table 50% | 33% (2 of 6) | 35% | 92% (11 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p92, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (1) | 18% (2) | 23% (3) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.67 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.67 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.33 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.67 | 0.67 |

### Quality by phase: gs3-83c8646-p92

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 4.7 |
| Strategy | Charge objectives carried out (made contact) | 57% (8 of 14) | 67% (4 of 6) |
| Strategy | Shoot objectives carried out (shot that target) | 44% (15 of 34) | 70% (7 of 10) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 100% (4 of 4) | - |
| Strategy | Joined characters whose unit fought | - | 67% (2 of 3) |
| Strategy | Lone characters that fought | 86% (6 of 7) | 73% (8 of 11) |
| Movement | Charges halted short of contact | 0.3 | 0.3 |
| Movement | Idle units | 1.3 | 2.7 |
| Movement | Points that never moved of their own | 125.7 | 56.7 |
| Movement | Fights charged into per game | 4.0 | 1.3 |
| Movement | Charges with odds: long shots (under 50%) | 7 of 12, net -86 | 1 of 4, net +482 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 12, net +186 | 0 of 4 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 12, net +0 | 1 of 4, net +126 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 12, net +98 | 1 of 4, net +151 |
| Shooting | Shots by shooting units (incl. breath weapons) | 18.3 | 8.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 29% (16 of 55) | 20% (5 of 25) |
| Shooting | Points destroyed by shooting units | 145.7 | 20.0 |
| Shooting | War machine shots | 4.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 12) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | - | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 50% (1 of 2) |
| Magic | Wounds caused by magic missiles | 3.0 | - |
| Magic | Wounds caused by other spells | 5.0 | - |
| Magic | Points destroyed by magic (all spells) | 140.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 2.3 / 3.7 / 0.0 | 2.3 / 0.0 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 147.0 | 276.3 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +29 | +250 |
| Combat | Net per 100 charger points, damage counted | +9.0 | +89.4 |
| Combat | First round won (charged fights) | 75% | 75% |
| Combat | Net points per charged fight | -14 | +234 |
| Combat | Net points per supported fight / lone fight | - / -14 | - / +234 |
| Combat | Charged fights on a top-3 enemy unit | 6 of 12 | 1 of 4 |
| Game | Points lost | 530.7 | 519.7 |
| Game | VP from objectives | 516.7 | 300.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +234 VP
- The side that went first won 2 of 2 games with a winner
- Points traded per game (both sides' losses): 1050
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p92

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +34.8 | 0.0 | 0.0 | 0.3 | +87.2 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +2.9 | 0.0 | 0.0 |
| ARMY TABLE | 23.3 | +284.0 | 0.0 | 40.0 | 18.0 | +85.4 | 0.0 | 279.0 |
| BACKUP TARGETS | - | - | - | - | 0.7 | +3.2 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 4.0 | +3.3 | 274.7 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 0.7 | +1.4 | 130.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 2.7 | +0.0 | 0.0 | 133.3 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.3 | +54.8 | 0.0 | 44.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.7 | +67.6 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | 0.7 | -13.7 | 0.0 | 50.3 | 0.3 | -3.7 | 0.0 | 0.0 |
| CHARGE LIST READ AGAIN | 0.3 | +26.8 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 10.0 | -330.5 | 0.0 | 117.3 | 16.0 | -775.7 | 0.0 | 280.0 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 66.7 | 50.3 | 1.0 | +0.0 | 100.7 | 65.0 |
| CHARGER SLAIN LOST | 0.3 | -14.3 | 0.0 | 115.7 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 9.0 | +0.0 | 0.0 | 0.0 | 10.7 | +0.0 | 0.0 | 113.3 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 160.7 | 0.0 |
| CONVEYANCE SEARCH | 1.0 | +37.4 | 133.3 | 133.3 | - | - | - | - |
| COVER ONCE | 10.7 | -417.2 | 0.0 | 212.0 | 9.7 | -874.3 | 0.0 | 85.3 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -9.1 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 7.3 | -40.0 | 0.0 | 0.0 | 6.3 | +17.3 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -65.3 | 0.0 | 0.0 | 0.7 | -88.1 | 160.7 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +26.6 | 0.0 | 50.3 | 0.7 | +19.6 | 109.0 | 65.0 |
| EXACT ROUND | 3.0 | -21.0 | 180.0 | 50.3 | 0.3 | +0.7 | 50.3 | 0.0 |
| FACES THE THREAT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.3 | +0.0 | 97.0 | 234.0 | 1.7 | +3.7 | 261.3 | 65.0 |
| FALLS SHORT | 8.3 | +73.2 | 0.0 | 118.7 | 14.0 | +198.2 | 0.0 | 130.0 |
| FEATURE BUFFS | 2.0 | +52.9 | 0.0 | 0.0 | 0.7 | +43.1 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +39.8 | 0.0 | 0.0 | 0.3 | +0.1 | 160.7 | 0.0 |
| FIVE ACTION | 87.3 | +6420.4 | 1038.3 | 889.3 | 87.7 | +4621.4 | 589.0 | 841.0 |
| FLANK NOT WEIGHED | 4.3 | +0.0 | 0.0 | 0.0 | 9.0 | +0.0 | 0.0 | 61.3 |
| FOLLOW UP WEIGHED | 1.7 | +175.5 | 0.0 | 276.3 | 1.0 | +168.5 | 0.0 | 65.0 |
| FOOT FIRST | 30.3 | +0.0 | 0.0 | 109.0 | - | - | - | - |
| FOUR ROUNDS | 4.7 | +1078.0 | 180.0 | 465.3 | 2.0 | +164.2 | 311.7 | 65.0 |
| FREED FROM HIS FIGHT | 2.7 | +0.0 | 0.0 | 133.3 | 11.7 | +0.0 | 0.0 | 91.0 |
| GIVES UP | 0.7 | -4.4 | 62.0 | 50.3 | - | - | - | - |
| GOAL WALK | 12.3 | +1012.8 | 0.0 | 0.0 | 5.3 | +528.0 | 0.0 | 0.0 |
| GUN MASK | 4.0 | +16.5 | 0.0 | 266.7 | - | - | - | - |
| HARD STAY DROPPED | 3.7 | +0.0 | 0.0 | 20.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 1.3 | +0.0 | 0.0 | 0.0 | 9.7 | +0.0 | 0.0 | 91.0 |
| HIS CHARGE BY HIS RUN | 5.0 | +0.0 | 0.0 | 117.3 | 8.7 | +0.0 | 0.0 | 103.3 |
| HIS CHARGE LIST | 1.3 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 155.3 |
| HIS LEGAL MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 124.0 |
| HIS MOVE AND SHOT | 2.3 | -19.9 | 0.0 | 0.0 | 6.3 | -47.1 | 0.0 | 266.7 |
| HIS ONE QUARTER | 4.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 145.0 |
| HIS OWN BEST MOVE | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 124.0 |
| HIS RANDOM MOVE | 10.7 | +0.0 | 0.0 | 266.7 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 24.7 | +586.3 | 0.0 | 290.7 | 56.0 | +2105.6 | 0.0 | 740.0 |
| HIS SHOTS BY HIS RUN | 18.0 | +215.0 | 0.0 | 250.7 | 50.0 | +847.6 | 0.0 | 518.0 |
| HIS TURN DENIED | 0.3 | +0.6 | 0.0 | 115.7 | 0.7 | +46.1 | 58.7 | 65.0 |
| HOLD ODDS | 9.3 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 44.0 |
| HOLDER ASSIGNMENT | 4.7 | +389.4 | 0.0 | 0.0 | 3.7 | +371.2 | 0.0 | 22.0 |
| HOLDS AMBUSHERS | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.0 | -164.3 | 180.0 | 216.3 | 1.7 | -86.6 | 311.7 | 65.0 |
| IDLE COST | 3.3 | -92.7 | 0.0 | 0.0 | 10.3 | -90.3 | 0.0 | 18.0 |
| KEPT FROM ITS LAST STOP | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +36.8 | 0.0 | 0.0 | 0.7 | +13.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 9.3 | +0.0 | 275.0 | 160.7 | 11.0 | +0.0 | 805.3 | 458.0 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.3 | +23.9 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.3 | -1.7 | 50.3 | 0.0 |
| LOST AFTER ESCAPE | 2.3 | -22.5 | 18.0 | 166.0 | 1.3 | +8.0 | 211.0 | 0.0 |
| MANOEUVRE | 1.3 | -16.7 | 0.0 | 58.7 | 2.0 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.3 | +23.6 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +1.8 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.7 | +36.6 | 0.0 | 0.0 | 0.7 | -1.6 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.7 | +11.9 | 0.0 | 0.0 | 1.0 | +9.8 | 0.0 | 0.0 |
| MEETS IN TIME | 2.7 | -24.5 | 0.0 | 0.0 | 3.0 | -46.8 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 5.7 | +71.5 | 0.0 | 133.3 | 2.7 | +43.7 | 0.0 | 67.0 |
| MISSILES NEXT TURN | 6.0 | +46.0 | 0.0 | 133.3 | 3.0 | +33.5 | 0.0 | 67.0 |
| MOVE ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 67.0 |
| MOVE SPELL SPOT | 1.3 | +0.0 | 0.0 | 133.3 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 3.3 | +191.1 | 0.0 | 0.0 | 4.0 | +262.5 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 8.7 | +334.7 | 0.0 | 0.0 | 9.0 | +374.9 | 0.0 | 84.0 |
| NEAREST TO GOAL | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NEXT CHARGE BY LIST | 0.3 | +10.2 | 0.0 | 0.0 | 3.3 | +189.2 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -1.3 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 4.0 | -129.2 | 180.0 | 332.0 | 1.7 | -56.5 | 151.0 | 65.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 3.3 | -58.3 | 0.0 | 20.0 | 3.3 | -90.0 | 0.0 | 59.0 |
| ONE CHECK AFTER THE LAST CHANGE | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 5.0 | -181.2 | 0.0 | 20.0 | 4.7 | -164.5 | 0.0 | 129.0 |
| ONE OBJECTIVE FORMULA | 3.7 | +51.1 | 0.0 | 0.0 | 2.3 | +55.8 | 0.0 | 22.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 0.7 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.7 | +6.1 | 77.0 | 0.0 | 0.7 | +1.4 | 109.0 | 65.0 |
| PATHS CROSS | 0.3 | +41.5 | 0.0 | 0.0 | 0.3 | -2.8 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -13.0 | 0.0 | 133.3 | - | - | - | - |
| PLAN RESULT | 40.0 | +607.0 | 598.0 | 938.7 | 42.0 | +282.4 | 321.3 | 804.0 |
| PROMISE BY ITS OWN SUM | 8.7 | -177.2 | 0.0 | 266.7 | 5.3 | -121.3 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 1.0 | -5.1 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | - | - | - | - | 0.7 | -2.1 | 0.0 | 0.0 |
| QUARTER ODDS | 21.7 | +2668.1 | 471.7 | 50.3 | 24.3 | +2714.5 | 151.0 | 359.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 2.7 | +21.8 | 0.0 | 56.7 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | +35.3 | 0.0 | 44.0 |
| REDIRECT COUNTER | - | - | - | - | 3.0 | +278.8 | 0.0 | 64.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 3.0 | +44.6 | 0.0 | 103.0 |
| REFORMS TO MEET IT | 0.7 | -18.8 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | 1.0 | +0.0 | 0.0 | 50.3 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +5.1 | 0.0 | 18.0 |
| RISK BY ARC | 4.0 | +15.2 | 97.0 | 465.3 | 1.7 | -10.7 | 311.7 | 65.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.0 | -23.9 | 261.3 | 65.0 |
| RUN DOWN | 1.3 | -5.6 | 0.0 | 364.7 | 2.0 | -26.3 | 311.7 | 65.0 |
| SCOUT SPOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | 2.0 | +537.5 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 3.0 | -131.7 | 0.0 | 15.0 |
| SET UP BY THE SET | 0.7 | +0.0 | 0.0 | 0.0 | 4.3 | +19.2 | 0.0 | 15.0 |
| SET UP TOGETHER | - | - | - | - | 0.7 | +1.6 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.3 | +11.6 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.7 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 10.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +2.7 | 48.0 | 0.0 | 1.3 | +5.7 | 0.0 | 0.0 |
| SHOT OR CHARGE | 1.3 | -234.1 | 0.0 | 249.0 | - | - | - | - |
| SHOT RISK POINTS | 11.7 | -46.5 | 0.0 | 424.0 | 35.7 | +1532.6 | 0.0 | 608.0 |
| SHOTS AFTER THE MOVES | 5.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 19.3 | +496.4 | 0.0 | 192.0 | 7.3 | +80.7 | 0.0 | 88.0 |
| SPELL SETS UP CHARGE | 0.3 | +11.6 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 1.0 | +54.2 | 266.7 | 266.7 | 2.0 | +32.3 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 1.3 | +30.2 | 100.0 | 50.3 | 0.3 | -2.9 | 50.3 | 0.0 |
| SPOT AS THE GAME MOVES | 5.0 | +0.0 | 0.0 | 133.3 | 10.3 | +0.0 | 0.0 | 314.0 |
| STAND AND SHOOT | - | - | - | - | 0.7 | -9.5 | 58.7 | 65.0 |
| STANDS FOR A REASON | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 39.7 | +0.0 | 858.3 | 40.0 | 28.7 | +0.0 | 277.3 | 108.3 |
| STAY WORTH | 25.0 | -28.5 | 510.3 | 133.3 | 6.3 | -21.3 | 197.3 | 44.0 |
| STRIKE BY THE ODDS | 0.3 | +2.6 | 0.0 | 0.0 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 7.7 | +238.1 | 0.0 | 0.0 | 6.0 | +603.0 | 0.0 | 15.0 |
| SUPPORT WORKED OUT | 7.7 | +238.1 | 0.0 | 0.0 | 6.0 | +603.0 | 0.0 | 15.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +3.5 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 65.0 |
| THE ROW KEEPS ITS WAY | 2.3 | +0.0 | 0.0 | 58.7 | 3.3 | +0.0 | 0.0 | 62.0 |
| THE STEP BACK IS MADE | 1.7 | +0.0 | 0.0 | 58.7 | 2.7 | +0.0 | 0.0 | 62.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 41.3 | +0.0 | 0.0 | 212.0 | 43.7 | +0.0 | 0.0 | 359.7 |
| TIED UP BY THE SUM | 0.3 | +13.4 | 18.0 | 0.0 | 0.3 | +46.6 | 42.0 | 0.0 |
| TIME ON OUR SIDE | 28.3 | +338.2 | 0.0 | 133.3 | 25.0 | +190.1 | 117.3 | 136.0 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.7 | -2.4 | 62.0 | 0.0 | 0.3 | -1.6 | 58.7 | 65.0 |
| WHOLE FIGHT DANGER | 3.7 | -207.0 | 0.0 | 117.3 | 2.0 | -462.5 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 1.3 | +8.5 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p92

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 124 | 124 | 95 | 31.67 | +1023 | +10.8 |
| LEGAL CHARGES ONLY | 61 | 61 | 61 | 20.33 | +0 | +0.0 |
| HIS SHOT LIST | 242 | 233 | 48 | 16.00 | +1380 | +28.7 |
| HIS SHOTS BY HIS RUN | 204 | 193 | 41 | 13.67 | +483 | +11.8 |
| FIVE ACTION | 525 | 510 | 38 | 12.67 | +2055 | +54.1 |
| QUARTER ODDS | 138 | 136 | 28 | 9.33 | +2629 | +93.9 |
| HOLDER ASSIGNMENT | 25 | 25 | 25 | 8.33 | +1599 | +64.0 |
| DEPLOY BY FIGURES | 41 | 41 | 22 | 7.33 | +143 | +6.5 |
| OFF BEST | 20 | 20 | 20 | 6.67 | -445 | -22.2 |
| THE TABLE AGAIN | 36 | 36 | 20 | 6.67 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 42 | 42 | 17 | 5.67 | -896 | -52.7 |
| SHOT RISK POINTS | 142 | 135 | 16 | 5.33 | +786 | +49.1 |
| HARD STAY DROPPED | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| MOVE ORDER | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 22 | 18 | 12 | 4.00 | +342 | +28.5 |
| TIME ON OUR SIDE | 160 | 140 | 12 | 4.00 | +66 | +5.5 |
| ADVANCE LANE KEPT | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| FOUR ROUNDS | 20 | 20 | 9 | 3.00 | +437 | +48.6 |
| REDIRECT FOR A FRIEND IN REACH | 9 | 9 | 9 | 3.00 | +115 | +12.7 |
| CHARGE LOSSES | 78 | 74 | 8 | 2.67 | +283 | +35.4 |
| COVER ONCE | 61 | 49 | 8 | 2.67 | +110 | +13.8 |
| FOLLOW UP WEIGHED | 8 | 8 | 8 | 2.67 | +1032 | +129.0 |
| GOAL WALK | 53 | 53 | 8 | 2.67 | +368 | +46.0 |
| MEETS IN TIME | 17 | 17 | 8 | 2.67 | +22 | +2.7 |
| STAY WORTH | 94 | 87 | 7 | 2.33 | +24 | +3.4 |
| SUPPORT ADDS | 41 | 37 | 7 | 2.33 | +309 | +44.2 |
| SUPPORT WORKED OUT | 41 | 37 | 7 | 2.33 | +309 | +44.2 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +149 | +24.9 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| IDLE COST | 41 | 30 | 4 | 1.33 | +8 | +2.1 |
| NEXT CHARGE BY LIST | 11 | 10 | 4 | 1.33 | +247 | +61.8 |
| RANDOM MOVE BY FIGURES | 8 | 8 | 4 | 1.33 | +66 | +16.4 |
| RISK BY ARC | 17 | 17 | 4 | 1.33 | +158 | +39.6 |
| SET UP BY THE SET | 15 | 15 | 4 | 1.33 | +249 | +62.2 |
| SHOTS AFTER THE MOVES | 19 | 19 | 4 | 1.33 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 7 | 7 | 3 | 1.00 | +2 | +0.5 |
| THE ROW IN ITS ORDER | 20 | 3 | 3 | 1.00 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 17 | 16 | 3 | 1.00 | +176 | +58.8 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +366 | +183.1 |
| CANNON SIGHT KEPT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CAST JOB | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +203 | +101.4 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FALLS SHORT | 67 | 65 | 2 | 0.67 | +55 | +27.4 |
| NEARER NOT NEEDED | 53 | 51 | 2 | 0.67 | +37 | +18.4 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +116 | +58.0 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -6 | -3.2 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +2 | +1.0 |
| SHOTS IN THE MOVE | 80 | 63 | 2 | 0.67 | +53 | +26.3 |
| SPELLS IN THE FIGHT | 5 | 5 | 2 | 0.67 | +4 | +2.1 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +9 | +8.7 |
| CANNON PLANNED TARGET | 12 | 12 | 1 | 0.33 | +0 | +0.0 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +80 | +80.5 |
| CHARGE NOW FIRST | 6 | 6 | 1 | 0.33 | -4 | -4.4 |
| EDGE GIVE GROUND | 3 | 3 | 1 | 0.33 | +76 | +76.4 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 12 | 12 | 1 | 0.33 | +2 | +1.7 |
| HONEST WORTH | 17 | 17 | 1 | 0.33 | +16 | +15.6 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +72 | +71.6 |
| LOST AFTER ESCAPE | 11 | 11 | 1 | 0.33 | +2 | +1.7 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +71 | +70.8 |
| MARCH CHECK | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -6 | -5.5 |
| MAX FOR POSITIONING | 8 | 8 | 1 | 0.33 | +7 | +7.3 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| OVERRUNS AWAY | 4 | 4 | 1 | 0.33 | +1 | +1.4 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -39 | -39.1 |
| PROMISE KNOWS THE FIGHT | 3 | 3 | 1 | 0.33 | -15 | -15.3 |
| REFUSING RETIRES | 3 | 3 | 1 | 0.33 | -14 | -13.6 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +15 | +15.3 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +8 | +7.8 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| TIED UP BY THE SUM | 2 | 2 | 1 | 0.33 | +110 | +110.1 |
| BACKUP TARGETS | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 8 | trace | - | - | - | - |
| CHAFF IN THE MOVE | 4 | 4 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 3 | 3 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 59 | 59 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 3 | 3 | 0 | 0.00 | - | - |
| EXACT ROUND | 10 | 10 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 8 | 8 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 40 | not checked | - | - | - | - |
| FOOT FIRST | 91 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 43 | 43 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN MASK | 12 | 11 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 33 | 33 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 41 | 37 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 24 | 23 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 30 | 27 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 26 | 26 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 24 | 24 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 36 | 32 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 32 | 30 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 7 | 7 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 3 | 3 | 0 | 0.00 | - | - |
| HOLD ODDS | 48 | 48 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 5 | 5 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| MANOEUVRE | 10 | 10 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 25 | 15 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 27 | 21 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NEAREST TO GOAL | 10 | 10 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 17 | 17 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 29 | 17 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 18 | 13 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| OPENS A LANE | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 246 | trace | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 9 | 9 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 10 | 10 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SEARCH SPOT | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 9 | 9 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 2 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 42 | not checked | - | - | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 9 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 46 | 41 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 3 | 3 | 0 | 0.00 | - | - |
| STANDS STILL | 205 | 200 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 17 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 13 | not checked | - | - | - | - |
| THE TABLE BINDS | 255 | not checked | - | - | - | - |
| WAITS AGAIN | 2 | not checked | - | - | - | - |
| WHO FIGHTS | 3 | 3 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 4 | 4 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p92

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| ARMY TABLE | rule | 3.33 | 3.00 | 89.1 |
| JOB FIRST | gate | 3.00 | 3.33 | 22.0 |
| PROMISE BY ITS OWN SUM | rule | 4.33 | 1.33 | 52.7 |
| PROMISE SHOT AWAY | rule | - | 0.67 | 3.2 |
| CHARGE NOW FIRST | rule | - | 0.33 | 4.4 |
| MARCH OF THE TABLE | rule | - | 0.33 | 5.5 |
| NO REASON | gate | 0.33 | - | 27.1 |
| PATHS CROSS | rule | - | 0.33 | 8.4 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 39.1 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.33 | 15.3 |
| REFUSING RETIRES | rule | 0.33 | - | 13.6 |

### Plans: gs3-83c8646-p92

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.3 | 40% | 330 | 159 | 48% |
| Mine | move | 27.7 | 98% | 1643 | 0 | 0% |
| Mine | shoot | 9.0 | 63% | 532 | 448 | 84% |
| Opponent | charge | 1.7 | 80% | 344 | 194 | 56% |
| Opponent | join | 2.3 | 100% | 72 | 0 | 0% |
| Opponent | move | 35.7 | 94% | 1565 | 0 | 0% |
| Opponent | shoot | 2.0 | 100% | 61 | 88 | 144% |
| Opponent | support | 0.3 | 0% | 22 | 0 | 0% |

### Battle groups: gs3-83c8646-p92

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 3.0 | 11% | 100% | 100% | 0% | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p92

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 7 | 24 (7) | 24 | 0 | 26 | 0% | 2.6 | 33 (5) | 0 (2) | - | 30 (6) | 0 (1) |
| Mine | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 11 | 8 (11) | 8 | 0 | 34 | 18% | 3.1 | 11 (8) | 0 (3) | - | 5 (6) | 14 (5) |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Shooter | 5 | 53 (5) | 53 | 0 | 37 | 0% | 1.0 | 22 (2) | 72 (3) | - | 68 (4) | 0 (1) |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | - | - | 0 (2) | - |
| Opponent | Chaff | 6 | 37 (6) | 37 | 0 | 64 | 17% | 3.4 | 0 (3) | 73 (3) | - | 24 (4) | 63 (2) |
| Opponent | Character | 10 | 53 (10) | 53 | 0 | 0 | 20% | 3.4 | 26 (8) | 169 (2) | - | 0 (7) | 97 (3) |
| Opponent | Clean-up | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | 0 (1) | 0 (1) | - | 0 (2) | - |
| Opponent | Fast Hammer | 6 | 13 (6) | 13 | 0 | 57 | 17% | 4.0 | 15 (5) | 0 (1) | - | 18 (4) | 0 (2) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 63 | 67% | 6.0 | 0 (2) | 0 (1) | - | 0 (3) | - |
| Opponent | Holder | 4 | 0 (4) | 0 | 0 | 30 | 100% | - | 0 (1) | 0 (1) | 0 (1) | 0 (1) | 0 (2) |
| Opponent | Shooter | 3 | 0 (3) | 0 | 0 | 0 | 0% | 1.0 | 0 (1) | 0 (2) | - | 0 (2) | 0 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | - | - | 0 (1) | - | 0 (1) |
| Opponent | Wizard | 4 | 14 (4) | 14 | 0 | 0 | 25% | 2.0 | 40 (1) | 0 (3) | - | - | 14 (4) |

### Charged fights: gs3-83c8646-p92

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 3 | 286 | 195 | 4.0 | 1.0 | 49 | 62 | -14 | 6 of 12 | 9 of 12 | - | -14 |
| Opponent | Tomb Kings of Khemri | 1 | 60 | 784 | 3.0 | 1.0 | 261 | 0 | +261 | 1 of 3 | 2 of 3 | - | +261 |
| Opponent | Vampire Counts | 1 | 0 | 151 | 1.0 | 1.0 | 151 | 0 | +151 | 0 of 1 | 1 of 1 | - | +151 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 20 | 312 | 1.3 | 1.0 | 234 | 0 | +234 | 1 of 4 | 3 of 4 | - | +234 |

### Effective charges: gs3-83c8646-p92

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 12 | 7 (net -86) | 0 | 1 (net +186) | 1 (net +60) | 1 (net +0) | 2 (net +98) | 0 | 8% (1 of 12) |
| Opponent | Tomb Kings of Khemri | 3 | 1 (net +482) | 0 | 0 | 1 (net +176) | 1 (net +126) | 0 | 0 | 0% (0 of 3) |
| Opponent | Vampire Counts | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +151) | 0 | 0% (0 of 1) |

### Charged fights, damage counted: gs3-83c8646-p92

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 7 | 339 | 249 | -86 | 144 | 170 | -27 | -7.9 |
| Mine | Effective (55-75%) | 1 | 500 | 186 | +186 | 248 | 0 | +248 | +49.6 |
| Mine | 76-89% | 1 | 151 | 60 | +60 | 60 | 0 | +60 | +39.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 320 | 124 | +98 | 111 | 0 | +111 | +34.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 143 | 45 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | All fights | 12 | 318 | 190 | -14 | 128 | 99 | +29 | +9.0 |
| Opponent | Long shot (under 50%) | 1 | 431 | 432 | +482 | 482 | 0 | +482 | +111.8 |
| Opponent | 76-89% | 1 | 195 | 176 | +176 | 176 | 0 | +176 | +90.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 60 | 151 | +151 | 176 | 18 | +158 | +262.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 431 | 126 | +126 | 184 | 0 | +184 | +42.6 |
| Opponent | All fights | 4 | 279 | 221 | +234 | 254 | 4 | +250 | +89.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p92 | move | 17 | 5 (29%) | 5 (29%) | 2 (12%) | 10 (59%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1427 |
| Invocation of Nehek | Opponent | L1427 |
| Opal Amulet | Mine | L1427 |
| Ring of Doom | Mine | L1523 |
| Ring of Doom | Opponent | L1331 |
| Standard of the Fell Warrior | Mine | L1331 |

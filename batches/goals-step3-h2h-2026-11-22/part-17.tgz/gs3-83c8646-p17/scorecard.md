# Doctrine scorecard: gs3-83c8646-p17

### Scorecard: gs3-83c8646-p17

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0721 | 1 | 1 | Mine | no | 4 | 4 | 5 | 0 | 0 | 0 | 0 | 263 |
| L0721 | 1 | 1 | Opponent | yes | 1 | - | 0 | 5 | 0 | 0 | 0 | 555 |
| L0810 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 480 |
| L0810 | 6 | 1 | Opponent | no | 12 | 6 | 0 | 0 | 0 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 161 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 3 | 6 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 2.0 | 4.0 | 1.7 | 1.3 | 0.0 | 0.0 | 0.0 | 301.3 |
| **Average** | | | Opponent | 67% | 6.5 | 4.0 | 1.0 | 3.7 | 0.0 | 0.0 | 0.0 | 295.0 |

### KPIs: gs3-83c8646-p17

Rules off - Mine only: GOAL ON TIME, NEAREST TO GOAL, GOAL ROUTE, FOOT FIRST.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 88% (14 of 16) | 0% (0 of 12) | 50% (14 of 28) |
| Winner chose to follow up after the loser gave ground |  | - | 100% (7 of 7); on the table 100% | 100% (7 of 7); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | 0% (0 of 1); on the table 100% | 50% (1 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | 33% (1 of 3); on the table 67% | 50% (2 of 4); on the table 75% |
| Winner chose to follow up or pursue (all three) |  | 100% (2 of 2); on the table 100% | 73% (8 of 11); on the table 91% | 77% (10 of 13); on the table 92% |
| Magic missiles tried each own turn | 50%+ | 83% (5 of 6) | 19% (7 of 36) | 29% (12 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 83% (5 of 6) | 23% (7 of 31) | 32% (12 of 37) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 58% (7 of 12) | 58% (7 of 12) |
| Points that never fought | lower | 69% (4119 of 5999) | 73% (4390 of 5998) | 71% (8509 of 11997) |
|   infantry points that never fought | lower | 92% (891 of 968) | 62% (687 of 1113) | 76% (1578 of 2081) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 67% (20 of 30) | 64% (16 of 25) | 65% (36 of 55) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 67% (2 of 3); 2.7 uses a game | 67% (2 of 3); 1.3 uses a game |
| Bound items with another spell used |  | 100% (1 of 1); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 67% (2 of 3); 0.7 uses a game | 50% (1 of 2); 0.3 uses a game | 60% (3 of 5); 0.5 uses a game |
|   their share of the points of units over 100 pts | lower | 66% (3523 of 5378) | 69% (3581 of 5181) | 67% (7104 of 10559) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (100%) | 6.7 (69%) | 7.0 (70%) |
| MARCHED: its unit marched | 0.0 (0%) | 1.3 (14%) | 1.3 (13%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (3%) | 0.3 (3%) |
| GONE: slain | 0.0 (0%) | 1.3 (14%) | 1.3 (13%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 7.0 | 1.0 | 4.7 | 4.0 | 0.7 | 1.0 |
| not cast | 3.0 | 1.0 | 1.3 | 10.0 | 3.3 | 27.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.0 (100%) | 0.0 (0%) | 7.0 (70%) | 2.7 (80%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (13%) | 0.7 (20%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| GONE: slain | 1.3 (44%) | 0.0 (0%) | 0.0 (0%) | 1.3 (13%) | 0.0 (0%) | 3.0 (11%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (56%) | 0.0 (0%) | 1.3 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 23.7 (88%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 4.7 a game | 2.3 a game |
| stood (cast and not dispelled) | - | 64% (9 of 14) | 64% (9 of 14) |
| the unit moved after it | - | 67% (6 of 9) | 67% (6 of 9) |
| it charged on its next turn | - | 0% (0 of 9) | 0% (0 of 9) |
| the enemy charged it first | - | 0% (0 of 9) | 0% (0 of 9) |
| it fought by the end of its next turn | - | 0% (0 of 9) | 0% (0 of 9) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 9) | 0% (0 of 9) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (9 of 9) | 100% (9 of 9) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 72% (68 of 94) | 54% (13 of 24) | 69% (81 of 118) |
|   cavalry | 85% (17 of 20) | - | 85% (17 of 20) |
|   chariot | 100% (8 of 8) | 50% (6 of 12) | 70% (14 of 20) |
|   infantry | 64% (7 of 11) | 29% (2 of 7) | 50% (9 of 18) |
|   war machine | 65% (36 of 55) | 100% (5 of 5) | 68% (41 of 60) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (23%) | 1.0 (27%) | 3.0 (24%) |
| MOVED: a war machine that moved | 2.0 (23%) | 0.0 (0%) | 2.0 (16%) |
| NO TARGET IN RANGE | 0.3 (4%) | 1.7 (45%) | 2.0 (16%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (9%) | 0.3 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 3.7 (42%) | 0.7 (18%) | 4.3 (35%) |
| OTHER BAR | 0.7 (8%) | 0.0 (0%) | 0.7 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 13.3 | 4.7 | 78% | 8.0 pts | 107 pts |
| chariot | 5.0 | 1.7 | 80% | 14.9 pts | 75 pts |
| infantry | 3.0 | 1.0 | 67% | 7.7 pts | 23 pts |
| war machine | 14.0 | 11.0 | 62% | 30.0 pts | 420 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.7 | 2.3 | 2.0 |
| Charges that made contact a game | 1.7 | 2.0 | 1.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.20 declared, 0.20 contact (5 units) | 0.17 declared, 0.17 contact (6 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.50 declared, 0.00 contact (2 units) | 0.50 declared, 0.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.25 declared, 0.25 contact (20 units) | 0.23 declared, 0.23 contact (22 units) | 0.24 declared, 0.24 contact (42 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 33% (3 of 9) | 33% (1 of 3) | 100% (1 of 1) | 38% (5 of 13) |
| Character in a unit | 100% (8 of 8) | - | - | 100% (8 of 8) |
| Character on its own | 67% (2 of 3) | 50% (1 of 2) | 100% (4 of 4) | 78% (7 of 9) |
| Chariot | 100% (3 of 3) | 100% (2 of 2) | - | 100% (5 of 5) |
| Infantry | 33% (1 of 3) | 0% (0 of 1) | 50% (1 of 2) | 33% (2 of 6) |
| Monster | - | 0% (0 of 1) | - | 0% (0 of 1) |
| War Machines | 69% (9 of 13) | - | - | 69% (9 of 13) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 3 | 100% (2 of 2); on the table 100% | 83% (5 of 6) | 69% | 67% (20 of 30) | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 67% (2 of 3); 0.7 uses a game |
| Grand Cathay | 1 | - | 25% (6 of 24) | 90% | 50% (5 of 10) | 50% (1 of 2); 6.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 25% (1 of 4); on the table 75% | 0% (0 of 6) | 48% | 67% (6 of 9) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 1 | 100% (7 of 7); on the table 100% | 17% (1 of 6) | 81% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gs3-83c8646-p17, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 50% (1) | 25% (1) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: gs3-83c8646-p17

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.0 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 50% (2 of 4) | 86% (6 of 7) |
| Strategy | Shoot objectives carried out (shot that target) | 26% (11 of 43) | 31% (4 of 13) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 100% (2 of 2) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 7) | 40% (2 of 5) |
| Strategy | Lone characters that fought | 43% (3 of 7) | 12% (1 of 8) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.3 | 3.7 |
| Movement | Points that never moved of their own | 301.3 | 295.0 |
| Movement | Fights charged into per game | 1.7 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 4 | 0 of 6 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 4 | 4 of 6, net +130 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 4 | 0 of 6 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 4, net +64 | 1 of 6, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 13.0 | 3.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 28% (11 of 39) | 33% (3 of 9) |
| Shooting | Points destroyed by shooting units | 48.3 | 0.0 |
| Shooting | War machine shots | 12.0 | 2.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (16 of 36) | 0% (0 of 6) |
| Shooting | Points destroyed by war machines | 310.7 | 43.3 |
| Magic | Magic missiles cast | 1.3 | 2.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 25% (1 of 4) | 33% (2 of 6) |
| Magic | Wounds caused by magic missiles | 1.3 | 6.7 |
| Magic | Wounds caused by other spells | - | 0.7 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 111.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.7 / 0.0 / 0.0 | 3.0 / 0.0 / 1.0 / 0.0 |
| Combat | Points destroyed in combat | 0.0 | 291.7 |
| Combat | Points run down | 68.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +84 | +133 |
| Combat | Net per 100 charger points, damage counted | +45.0 | +70.5 |
| Combat | First round won (charged fights) | 80% | 100% |
| Combat | Net points per charged fight | +54 | +109 |
| Combat | Net points per supported fight / lone fight | - / +54 | - / +109 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 5 | 3 of 6 |
| Game | Points lost | 506.7 | 566.3 |
| Game | VP from objectives | 640.0 | 676.7 |
| Game | Lone holders (player turns) | 2.0 | 6.5 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +95 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 1073
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gs3-83c8646-p17

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 14.3 | +32.8 | 0.0 | 238.7 | 16.3 | +131.1 | 0.0 | 295.0 |
| ARTILLERY RE-ROLL WEIGHED | 4.3 | +0.0 | 0.0 | 41.7 | 0.3 | +0.0 | 0.0 | 55.0 |
| BACKUP TARGETS | 0.3 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 43.3 | 0.0 |
| CANNON PLANNED TARGET | 11.0 | +372.1 | 1190.7 | 86.7 | 1.7 | +177.5 | 128.3 | 220.0 |
| CANNON SIGHT KEPT | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CAST JOB | - | - | - | - | 4.3 | +63.6 | 83.3 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.3 | +2.3 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 0.3 | +11.2 | 0.0 | 0.0 |
| CHAFF PASSED | 1.3 | +0.0 | 37.3 | 0.0 | - | - | - | - |
| CHARACTER GUNS | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 16.3 | -741.8 | 0.0 | 612.0 | 18.0 | -1169.3 | 0.0 | 1087.0 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 85.7 | 0.0 | 1.3 | +0.0 | 71.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.0 | +0.0 | 0.0 | 0.0 | 19.0 | +0.0 | 0.0 | 139.7 |
| CONVEYANCE SEARCH | - | - | - | - | 4.0 | +213.3 | 0.0 | 0.0 |
| COVER ONCE | 6.3 | -268.0 | 0.0 | 116.3 | 5.7 | -389.6 | 0.0 | 156.3 |
| DEFENSIVE ARMY | 0.7 | +0.0 | 0.0 | 51.3 | - | - | - | - |
| DENIED BY THE FIGHT | 0.3 | -4.6 | 0.0 | 0.0 | 0.3 | -3.0 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 7.0 | -106.9 | 0.0 | 0.0 | 7.3 | -20.3 | 0.0 | 48.3 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +54.3 | 67.3 | 0.0 |
| EXACT ROUND | 1.0 | +7.4 | 48.3 | 0.0 | 2.3 | +26.9 | 183.7 | 0.0 |
| FALL BACK GOOD ORDER | 1.3 | +26.7 | 68.0 | 0.0 | 2.0 | +0.6 | 116.3 | 0.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 26.7 | +334.9 | 0.0 | 359.7 |
| FEATURE BUFFS | 2.3 | +28.0 | 0.0 | 0.0 | 2.7 | +32.3 | 0.0 | 74.7 |
| FIGHT TO THE END | - | - | - | - | 0.7 | +91.0 | 0.0 | 0.0 |
| FIVE ACTION | 97.7 | +5471.2 | 3057.7 | 1080.7 | 96.3 | +4723.6 | 729.0 | 2040.3 |
| FLANK NOT WEIGHED | 3.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 119.0 |
| FOLLOW UP WEIGHED | 0.7 | +69.1 | 0.0 | 0.0 | 2.0 | +354.0 | 0.0 | 0.0 |
| FOOT FIRST | - | - | - | - | 18.3 | +0.0 | 0.0 | 328.0 |
| FOUR ROUNDS | 1.7 | +130.4 | 116.3 | 0.0 | 2.3 | +265.6 | 183.7 | 0.0 |
| FREED FROM HIS FIGHT | - | - | - | - | 0.7 | +0.0 | 0.0 | 61.3 |
| FRIEND CHARGES FIRST | 0.3 | -56.7 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.3 | +20.3 | 0.0 | 0.0 | - | - | - | - |
| GOAL ROUTE | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| GOAL WALK | 10.3 | +831.5 | 0.0 | 96.0 | 17.0 | +988.3 | 0.0 | 74.7 |
| GUN FIGURES | 2.7 | +109.8 | 0.0 | 0.0 | 0.7 | +2.0 | 0.0 | 0.0 |
| GUN MASK | 2.7 | +21.6 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 7.3 | +0.0 | 0.0 | 420.0 | 8.3 | +0.0 | 0.0 | 210.7 |
| HIS CHARGE LIST | 13.0 | +0.0 | 0.0 | 394.7 | 6.3 | +0.0 | 0.0 | 595.0 |
| HIS LEGAL MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.3 | -95.0 | 0.0 | 96.0 | 2.3 | -21.4 | 0.0 | 123.0 |
| HIS ONE QUARTER | 7.3 | +0.0 | 0.0 | 412.0 | 5.3 | +0.0 | 0.0 | 184.3 |
| HIS OWN BEST MOVE | 4.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 10.3 | +0.0 | 0.0 | 192.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 1.3 | +0.0 | 0.0 | 192.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 43.3 | +1233.6 | 0.0 | 586.7 | 63.3 | +4180.6 | 0.0 | 784.0 |
| HIS SHOTS BY HIS RUN | 24.7 | +412.6 | 0.0 | 96.0 | 49.7 | +1777.3 | 0.0 | 1233.3 |
| HIS TURN DENIED | 0.3 | +6.1 | 0.0 | 0.0 | 1.3 | +57.9 | 67.3 | 0.0 |
| HOLD ODDS | 16.7 | +0.0 | 0.0 | 326.7 | 19.7 | +0.0 | 0.0 | 176.7 |
| HOLDER ASSIGNMENT | 10.0 | +1052.1 | 0.0 | 163.3 | 11.0 | +867.8 | 0.0 | 51.0 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.7 | -28.5 | 116.3 | 0.0 | 2.3 | -89.8 | 183.7 | 0.0 |
| IDLE COST | - | - | - | - | 18.0 | -225.1 | 0.0 | 489.7 |
| KEEP FALLS | 0.3 | +4.5 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LANE BY FIGURES | 0.3 | +1.4 | 0.0 | 0.0 | 1.0 | +51.5 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 2.0 | +0.0 | 0.0 | 146.7 | 3.3 | +0.0 | 67.3 | 0.0 |
| LONE WIZARD KEPT IN | 0.7 | +46.6 | 0.0 | 0.0 | 0.3 | +58.3 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.0 | +1.4 | 68.0 | 0.0 | 0.7 | +0.4 | 45.0 | 0.0 |
| MAKE SURE TOGETHER | 0.7 | +2.7 | 0.0 | 0.0 | 0.3 | +0.2 | 0.0 | 0.0 |
| MANOEUVRE | 2.7 | -13.3 | 0.0 | 0.0 | 1.7 | -5.4 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 1.0 | +17.9 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +2.9 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 0.3 | +46.7 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.7 | +24.6 | 0.0 | 0.0 | 4.7 | +74.7 | 0.0 | 0.0 |
| MEETS IN TIME | 4.0 | +342.3 | 0.0 | 0.0 | 4.3 | +157.8 | 0.0 | 48.3 |
| MISSILES IN THE MOVE | 2.0 | +89.0 | 0.0 | 0.0 | 6.3 | +103.5 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 1.7 | +28.6 | 0.0 | 0.0 | 11.0 | +178.1 | 0.0 | 234.0 |
| MOVE ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 180.0 |
| MOVE SPELL SPOT | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 4.0 | +293.9 | 0.0 | 96.0 | 5.0 | +863.5 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 7.3 | +307.0 | 0.0 | 0.0 | 9.7 | +465.8 | 0.0 | 88.3 |
| NEAREST TO GOAL | - | - | - | - | 3.3 | +0.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 2.3 | +155.8 | 0.0 | 96.0 | 5.0 | +863.5 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.7 | -5.2 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 1.7 | -64.0 | 116.3 | 0.0 | 2.3 | -103.6 | 183.7 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT WORTH A CAST | 0.3 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 6.3 | -264.6 | 0.0 | 0.0 | 1.0 | -14.8 | 0.0 | 0.0 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 0.3 | +36.0 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.3 | -149.4 | 0.0 | 96.0 | 5.0 | -98.6 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 4.3 | +131.3 | 0.0 | 67.3 | 7.7 | +35.3 | 0.0 | 51.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.7 | -143.7 | 0.0 | 0.0 |
| ONE RUN A PLAN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 1.0 | +10.5 | 85.7 | 0.0 | - | - | - | - |
| PATHS CROSS | 0.7 | +45.8 | 0.0 | 0.0 | 1.3 | +20.5 | 0.0 | 0.0 |
| PERIAPT WORTH | - | - | - | - | 0.3 | +24.8 | 0.0 | 180.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -12.5 | 0.0 | 0.0 |
| PLAN RESULT | 44.0 | +1180.4 | 717.0 | 803.3 | 47.7 | +349.3 | 192.3 | 806.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 9.0 | -404.3 | 0.0 | 0.0 | 3.7 | -30.1 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | -2.1 | 0.0 | 96.0 | 1.7 | -3.6 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.7 | -1.1 | 96.7 | 0.0 | - | - | - | - |
| QUARTER ODDS | 21.0 | +1755.8 | 127.3 | 463.3 | 16.7 | +1496.0 | 138.7 | 245.7 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.0 | +162.8 | 0.0 | 145.0 |
| REDIRECT COUNTER | 0.3 | +10.1 | 0.0 | 0.0 | 0.3 | +70.9 | 0.0 | 13.7 |
| REDIRECT FOR A FRIEND IN REACH | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -21.8 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.3 | -23.4 | 85.7 | 0.0 | 1.7 | +0.7 | 116.3 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.0 | -12.5 | 138.7 | 0.0 |
| RUN DOWN | 1.7 | -10.5 | 116.3 | 0.0 | 1.3 | -20.1 | 112.3 | 0.0 |
| SCOUT SPOT | 0.7 | +4.7 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 3.0 | -207.1 | 0.0 | 55.0 |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +11.7 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +5.9 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 1.7 | -85.6 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 2.7 | +123.1 | 0.0 | 0.0 | - | - | - | - |
| SET UP TOGETHER | 0.7 | +2.7 | 0.0 | 0.0 | 0.3 | +0.2 | 0.0 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.7 | +44.6 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.3 | +33.9 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 14.0 | +0.0 | 0.0 | 112.3 | 4.7 | +0.0 | 0.0 | 220.0 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +71.5 | 48.3 | 0.0 | 0.7 | +24.5 | 109.3 | 0.0 |
| SHORT GUN FORWARD | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | - | - | - | - | 0.3 | +0.0 | 43.3 | 0.0 |
| SHOT RISK POINTS | 20.0 | +30.8 | 0.0 | 205.3 | 32.0 | -228.2 | 0.0 | 1199.0 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 22.0 | +1205.2 | 0.0 | 112.3 | 5.0 | +260.1 | 0.0 | 220.0 |
| SPELL SETS UP CHARGE | - | - | - | - | 1.3 | +139.3 | 0.0 | 0.0 |
| SPELL WORTH | 1.7 | +4.2 | 0.0 | 0.0 | 4.7 | +68.5 | 360.0 | 360.0 |
| SPELLS IN THE FIGHT | 0.3 | +9.0 | 48.3 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 5.3 | +0.0 | 0.0 | 138.7 | 7.3 | +0.0 | 0.0 | 134.0 |
| STANDS FOR A REASON | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 61.7 | +0.0 | 2941.3 | 334.0 | 31.0 | +0.0 | 545.3 | 652.7 |
| STAY WORTH | 34.3 | +122.1 | 2677.0 | 71.3 | 8.7 | +89.4 | 436.0 | 681.7 |
| SUPPORT ADDS | 4.0 | +70.0 | 0.0 | 0.0 | 2.3 | +170.0 | 0.0 | 102.0 |
| SUPPORT WORKED OUT | 4.0 | +70.0 | 0.0 | 0.0 | 2.3 | +170.0 | 0.0 | 102.0 |
| SURE REACH TOGETHER | 0.7 | +2.1 | 0.0 | 0.0 | 1.0 | +9.0 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | -1.2 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 145.3 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 41.0 | +0.0 | 0.0 | 540.3 | 46.3 | +0.0 | 0.0 | 879.7 |
| TIED UP BY THE SUM | 0.3 | +26.1 | 37.3 | 0.0 | 0.3 | +22.2 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 44.7 | +531.3 | 0.0 | 489.0 | - | - | - | - |
| WAITS AGAIN | 2.3 | +0.0 | 0.0 | 192.0 | - | - | - | - |
| WHO FIGHTS | - | - | - | - | 1.0 | +45.3 | 0.0 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +14.3 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 4.3 | -430.7 | 0.0 | 277.3 | 2.7 | -169.7 | 0.0 | 136.0 |
| WOUNDS ON THE RANKS | 4.0 | +67.8 | 0.0 | 96.0 | 3.3 | +103.1 | 0.0 | 0.0 |

### Rule changes: gs3-83c8646-p17

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 320 | 309 | 60 | 20.00 | +1691 | +28.2 |
| HOLDER ASSIGNMENT | 63 | 63 | 58 | 19.33 | +4511 | +77.8 |
| ARMY TABLE | 92 | 92 | 57 | 19.00 | +829 | +14.5 |
| HIS SHOTS BY HIS RUN | 223 | 217 | 51 | 17.00 | +1267 | +24.8 |
| GOAL WALK | 82 | 82 | 32 | 10.67 | +1765 | +55.1 |
| TIME ON OUR SIDE | 134 | 118 | 31 | 10.33 | +123 | +4.0 |
| FIVE ACTION | 582 | 569 | 29 | 9.67 | +1919 | +66.2 |
| DEPLOY BY FIGURES | 43 | 43 | 25 | 8.33 | +379 | +15.2 |
| OFF BEST | 22 | 22 | 22 | 7.33 | -838 | -38.1 |
| MOVE TO CHARGE COMPUTED | 27 | 24 | 19 | 6.33 | +1150 | +60.5 |
| MOVE ORDER | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| SHOT RISK POINTS | 156 | 154 | 17 | 5.67 | +737 | +43.4 |
| LEGAL CHARGES ONLY | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 16 | 5.33 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 22 | 19 | 15 | 5.00 | +1110 | +74.0 |
| ARTILLERY RE-ROLL WEIGHED | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 38 | 38 | 14 | 4.67 | -1304 | -93.1 |
| IDLE COST | 54 | 40 | 12 | 4.00 | +80 | +6.7 |
| MEETS IN TIME | 25 | 25 | 12 | 4.00 | +880 | +73.3 |
| QUARTER ODDS | 113 | 111 | 12 | 4.00 | +907 | +75.6 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| CAST JOB | 13 | 13 | 9 | 3.00 | +1 | +0.1 |
| CHARGE LOSSES | 103 | 101 | 9 | 3.00 | +202 | +22.4 |
| HARD STAY DROPPED | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| COVER ONCE | 36 | 28 | 8 | 2.67 | +251 | +31.4 |
| FOLLOW UP WEIGHED | 8 | 8 | 8 | 2.67 | +1269 | +158.7 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| CANNON PLANNED TARGET | 38 | 38 | 7 | 2.33 | +47 | +6.6 |
| FOUR ROUNDS | 12 | 11 | 7 | 2.33 | +417 | +59.5 |
| MAX FOR POSITIONING | 19 | 17 | 7 | 2.33 | +44 | +6.2 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 7 | 2.33 | +488 | +69.8 |
| WHOLE FIGHT DANGER | 21 | 20 | 7 | 2.33 | +88 | +12.5 |
| PATHS CROSS | 6 | 6 | 6 | 2.00 | +199 | +33.2 |
| PROMISE KNOWS THE FIGHT | 6 | 6 | 6 | 2.00 | -17 | -2.9 |
| CHAFF PASSED | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| GOAL ROUTE | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +159 | +39.7 |
| NEARER NOT NEEDED | 51 | 46 | 4 | 1.33 | +204 | +50.9 |
| SHOOTS FROM THE BEST SPOT | 5 | 5 | 4 | 1.33 | +8 | +1.9 |
| SUPPORT ADDS | 19 | 16 | 4 | 1.33 | +70 | +17.6 |
| SUPPORT WORKED OUT | 19 | 16 | 4 | 1.33 | +70 | +17.6 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +315 | +104.9 |
| MARCH CHECK | 3 | 3 | 3 | 1.00 | +33 | +11.1 |
| REDIRECT FOR A FRIEND IN REACH | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHARGE NOW FIRST | 8 | 8 | 2 | 0.67 | -24 | -11.9 |
| GUN MASK | 8 | 7 | 2 | 0.67 | +7 | +3.6 |
| MISSILES IN THE MOVE | 25 | 15 | 2 | 0.67 | +115 | +57.6 |
| ONE OBJECTIVE FORMULA | 36 | 27 | 2 | 0.67 | +48 | +24.0 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -431 | -215.6 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -3 | -1.6 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHORT GUN FORWARD | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHOTS IN THE MOVE | 81 | 59 | 2 | 0.67 | +253 | +126.7 |
| STAY WORTH | 129 | 116 | 2 | 0.67 | +30 | +15.1 |
| THE ROW IN ITS ORDER | 11 | 2 | 2 | 0.67 | +0 | +0.0 |
| TIED UP BY THE SUM | 2 | 2 | 2 | 0.67 | +50 | +24.8 |
| FEATURE BUFFS | 15 | 15 | 1 | 0.33 | +3 | +2.8 |
| FIGHT TO THE END | 2 | 2 | 1 | 0.33 | +109 | +108.7 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +61 | +60.9 |
| HIS MOVE AND SHOT | 14 | 13 | 1 | 0.33 | +34 | +33.8 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +120 | +119.5 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -9 | -8.7 |
| MISSILES NEXT TURN | 38 | 27 | 1 | 0.33 | +0 | +0.3 |
| OGRE LOADER SECOND SHOT | 1 | 1 | 1 | 0.33 | +108 | +108.0 |
| OVERRUNS AWAY | 3 | 3 | 1 | 0.33 | +16 | +16.1 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +74 | +74.4 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -38 | -37.6 |
| REDIRECT COUNTER | 2 | 2 | 1 | 0.33 | +4 | +3.5 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +89 | +88.9 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +35 | +35.0 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +18 | +17.8 |
| SHOT REPLANNED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 22 | 22 | 1 | 0.33 | +0 | +0.0 |
| SPELLS IN THE FIGHT | 1 | 1 | 1 | 0.33 | +16 | +16.1 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | -4 | -3.5 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +13 | +12.8 |
| WOUNDS ON THE RANKS | 22 | 22 | 1 | 0.33 | +3 | +2.8 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 8 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAFF IN THE MOVE | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 7 | 7 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 78 | 76 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 12 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 10 | 9 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 10 | 9 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FALLS SHORT | 80 | 61 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 18 | not checked | - | - | - | - |
| FOOT FIRST | 55 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 10 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 47 | 45 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 58 | 58 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 12 | 12 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 38 | 37 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 18 | 16 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 31 | 26 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 4 | 4 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 5 | 5 | 0 | 0.00 | - | - |
| HOLD ODDS | 109 | 109 | 0 | 0.00 | - | - |
| HONEST WORTH | 12 | 11 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 4 | 4 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 5 | 5 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 3 | not checked | - | - | - | - |
| MANOEUVRE | 13 | 13 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 6 | not checked | - | - | - | - |
| NEAREST TO GOAL | 10 | 10 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 12 | 11 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 36 | 36 | 0 | 0.00 | - | - |
| NO SECOND RUN | 36 | 36 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 31 | 20 | 0 | 0.00 | - | - |
| ONE RUN A PLAN | 36 | 36 | 0 | 0.00 | - | - |
| PLAN RESULT | 275 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 2 | 1 | 0 | 0.00 | - | - |
| RISK BY ARC | 9 | 8 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 9 | 8 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 9 | 9 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 5 | 4 | 0 | 0.00 | - | - |
| SET UP BY THE SET | 8 | 7 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 3 | 2 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 2 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 56 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 4 | not checked | - | - | - | - |
| SPELL WORTH | 19 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 38 | 36 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 8 | 0 | 0.00 | - | - |
| STANDS STILL | 278 | 271 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 5 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 14 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 6 | not checked | - | - | - | - |
| THE TABLE BINDS | 262 | not checked | - | - | - | - |
| WAITS AGAIN | 7 | 7 | 0 | 0.00 | - | - |
| WHO FIGHTS | 3 | 3 | 0 | 0.00 | - | - |

### Off best figure: gs3-83c8646-p17

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 6.00 | 1.00 | 39.8 |
| PROMISE BY ITS OWN SUM | rule | 4.33 | 0.33 | 93.1 |
| ARMY TABLE | rule | 2.00 | 1.33 | 54.6 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | 1.67 | 2.9 |
| CANNON PLANNED TARGET | rule | 0.67 | - | 77.1 |
| CHARGE NOW FIRST | rule | 0.33 | 0.33 | 11.9 |
| ONE PROMISE A TARGET | rule | - | 0.67 | 215.6 |
| PROMISE SHOT AWAY | rule | 0.67 | - | 1.6 |
| MARCH OF THE TABLE | rule | - | 0.33 | 8.7 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 37.6 |
| RULE SWITCHED OFF | gate | 0.33 | - | 3.0 |
| SWIFTSTRIDE BY POINTS | rule | 0.33 | - | 3.5 |

### Plans: gs3-83c8646-p17

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 50% | 225 | 95 | 42% |
| Mine | join | 1.0 | 100% | 14 | 0 | 0% |
| Mine | move | 30.0 | 97% | 1297 | 0 | 0% |
| Mine | shoot | 11.7 | 49% | 662 | 1086 | 164% |
| Opponent | charge | 1.3 | 50% | 300 | 122 | 41% |
| Opponent | join | 2.3 | 100% | 81 | 0 | 0% |
| Opponent | move | 38.7 | 94% | 1950 | 0 | 0% |
| Opponent | shoot | 3.7 | 55% | 190 | 227 | 120% |
| Opponent | support | 1.7 | 80% | 0 | 0 | - |

### Battle groups: gs3-83c8646-p17

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gs3-83c8646-p17

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |
| Mine | Character | 12 | 10 (12) | 10 | 0 | 26 | 67% | 3.8 | 0 (4) | 0 (3) | 18 (4) | 14 (7) | 0 (4) |
| Mine | Fast Hammer | 5 | 38 (5) | 22 | 16 | 53 | 20% | 3.0 | 54 (3) | 0 (1) | 38 (1) | 45 (3) | 29 (2) |
| Mine | Hammer | 4 | 28 (4) | 0 | 28 | 0 | 50% | 1.0 | 0 (1) | 40 (3) | - | 0 (3) | 97 (1) |
| Mine | Shooter | 5 | 30 (5) | 21 | 9 | 67 | 0% | 1.0 | 0 (1) | 12 (2) | 63 (2) | 30 (5) | - |
| Mine | War machine | 11 | 66 (11) | 66 | 0 | 28 | 9% | 1.9 | 95 (5) | 43 (6) | - | 0 (2) | 81 (9) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 3.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 19 | 100% | - | 0 (3) | 0 (2) | - | 0 (5) | - |
| Opponent | Character | 11 | 19 (11) | 19 | 0 | 22 | 36% | 2.1 | 0 (3) | 0 (5) | 52 (3) | 41 (7) | 0 (4) |
| Opponent | Clean-up | 1 | 73 (1) | 0 | 73 | 100 | 100% | - | - | 73 (1) | - | 73 (1) | - |
| Opponent | Fast Hammer | 6 | 70 (6) | 43 | 27 | 13 | 33% | 1.5 | 95 (3) | 31 (3) | - | 130 (4) | 0 (2) |
| Opponent | Fragile | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (1) | 0 (1) | - | 0 (2) |
| Opponent | Hammer | 4 | 89 (4) | 73 | 17 | 40 | 25% | 3.0 | 0 (2) | 250 (1) | 54 (1) | 105 (3) | 54 (1) |
| Opponent | Holder | 4 | 123 (4) | 0 | 123 | 65 | 50% | 5.0 | - | 13 (2) | 217 (2) | 123 (4) | - |
| Opponent | Shooter | 2 | 0 (2) | 0 | 0 | 50 | 50% | 4.0 | - | - | 0 (2) | 0 (1) | 0 (1) |
| Opponent | War machine | 2 | 39 (2) | 39 | 0 | 100 | 0% | 1.0 | - | 39 (2) | - | 79 (1) | 0 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | - | - | 0 (2) | - |

### Charged fights: gs3-83c8646-p17

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 3 | 359 | 116 | 1.7 | 1.0 | 70 | 15 | +54 | 2 of 5 | 4 of 5 | - | +54 |
| Opponent | Grand Cathay | 1 | 464 | 135 | 1.0 | 1.0 | 135 | 0 | +135 | 0 of 1 | 1 of 1 | - | +135 |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Vampire Counts | 1 | 0 | 518 | 5.0 | 1.0 | 104 | 0 | +104 | 3 of 5 | 5 of 5 | - | +104 |
| **Opponent** | all armies | 3 | 155 | 218 | 2.0 | 1.0 | 109 | 0 | +109 | 3 of 6 | 6 of 6 | - | +109 |

### Effective charges: gs3-83c8646-p17

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 5 | 0 | 0 | 0 | 2 (net +72) | 0 | 2 (net +64) | 1 | 0% (0 of 4) |
| Opponent | Grand Cathay | 1 | 0 | 0 | 0 | 1 (net +135) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Vampire Counts | 5 | 0 | 0 | 4 (net +130) | 0 | 0 | 1 (net +0) | 0 | 80% (4 of 5) |

### Charged fights, damage counted: gs3-83c8646-p17

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 2 | 185 | 184 | +72 | 128 | 47 | +81 | +43.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 189 | 102 | +64 | 190 | 59 | +130 | +68.9 |
| Mine | No odds | 1 | 189 | 222 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | All fights | 5 | 187 | 159 | +54 | 127 | 43 | +84 | +45.0 |
| Opponent | Effective (55-75%) | 4 | 186 | 224 | +130 | 156 | 0 | +156 | +83.9 |
| Opponent | 76-89% | 1 | 205 | 135 | +135 | 177 | 0 | +177 | +86.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 186 | 164 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | All fights | 6 | 189 | 199 | +109 | 133 | 0 | +133 | +70.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gs3-83c8646-p17 | move | 20 | 4 (20%) | 3 (15%) | 2 (10%) | 14 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0827 |
| Invocation of Nehek | Opponent | L0827 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Jet | Opponent | L0810 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721 |
| Twice-Blessed Armour | Opponent | L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |

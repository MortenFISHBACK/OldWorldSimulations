# Doctrine scorecard: co-opp-a57fba0-p3

### Scorecard: co-opp-a57fba0-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | 3 | 3 | 2 | 1 | 0 | 0 | 322 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 5 | 1 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 8 | - | 0 | 1 | 0 | 0 | 0 | 317 |
| L0126 | 6 | 1 | Opponent | no | 17 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 2 | 3 | 0 | 5 | 1 | 0 | 0 | 30 |
| L0210 | 6 | 1 | Opponent | no | 3 | 1 | 1 | 0 | 0 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | no | 0 | 3 | 3 | 4 | 1 | 0 | 0 | 442 |
| L0226 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | yes | - | - | 1 | 1 | 0 | 0 | 0 | 675 |
| L0311 | 5 | 1 | Opponent | yes | - | 2 | 4 | 1 | 0 | 0 | 0 | 427 |
| L0327 | 3 | 1 | Mine | yes | 5 | 3 | 4 | 0 | 0 | 0 | 0 | 675 |
| L0327 | 3 | 1 | Opponent | no | 2 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | yes | - | 3 | 1 | 1 | 0 | 0 | 0 | 317 |
| L0429 | 3 | 1 | Mine | yes | 2 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 3 | 6 | 2 | 1 | 0 | 0 | 0 | 881 |
| L0516 | 6 | 1 | Opponent | no | 5 | 2 | 3 | 1 | 0 | 0 | 0 | 200 |
| L0533 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 1193 |
| L0533 | 5 | 1 | Opponent | yes | - | 2 | 2 | 5 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | 4 | 4 | 0 | 0 | 0 | 0 | 798 |
| L0620 | 2 | 1 | Opponent | - | - | 4 | 1 | 2 | 0 | 0 | 0 | 210 |
| L0709 | 1 | 1 | Mine | yes | 7 | 3 | 1 | 0 | 1 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | no | 0 | - | 1 | 0 | 0 | 0 | 0 | 619 |
| L0725 | 5 | 1 | Mine | no | - | 4 | 2 | 1 | 0 | 0 | 0 | 375 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | 4 | 1 | 1 | 0 | 0 | 0 | 515 |
| L0815 | 5 | 1 | Opponent | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 115 |
| L0831 | 3 | 1 | Mine | no | 2 | 4 | 2 | 1 | 0 | 0 | 0 | 605 |
| L0831 | 3 | 1 | Opponent | no | 10 | 2 | 2 | 3 | 2 | 0 | 0 | 340 |
| L0922 | 4 | 1 | Mine | no | 0 | 5 | 1 | 0 | 0 | 0 | 0 | 841 |
| L0922 | 4 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 1 | 0 | 0 | 55 |
| L1013 | 5 | 1 | Mine | no | - | 2 | 3 | 0 | 1 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | no | - | 6 | 2 | 2 | 0 | 0 | 0 | 387 |
| L1030 | 4 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1030 | 4 | 1 | Opponent | no | 1 | 3 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 2 | 3 | 3 | 0 | 1 | 0 | 0 | 330 |
| L1122 | 6 | 1 | Opponent | no | 1 | 2 | 4 | 2 | 1 | 0 | 0 | 144 |
| L1216 | 4 | 1 | Mine | no | 2 | 2 | 5 | 0 | 1 | 0 | 0 | 330 |
| L1216 | 4 | 1 | Opponent | no | 4 | 2 | 3 | 1 | 0 | 0 | 0 | 414 |
| L1232 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 498 |
| L1232 | 2 | 1 | Opponent | - | - | 3 | 2 | 3 | 1 | 0 | 0 | 340 |
| L1327 | 1 | 1 | Mine | no | 5 | 4 | 2 | 0 | 0 | 0 | 0 | 302 |
| L1327 | 1 | 1 | Opponent | no | 3 | 2 | 3 | 4 | 1 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Mine | no | 7 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 242 |
| L1519 | 1 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 1 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | yes | - | 4 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 2 | 4 | 2 | 0 | 0 | 0 | 140 |
| L1633 | 1 | 1 | Mine | no | 12 | 3 | 3 | 1 | 0 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 0 | 1 | 1 | 3 | 0 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Mine | no | 3 | 2 | 5 | 0 | 0 | 0 | 0 | 147 |
| L1731 | 3 | 1 | Opponent | no | 1 | 4 | 3 | 2 | 0 | 0 | 0 | 340 |
| L1831 | 1 | 1 | Mine | no | 0 | 3 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 2 | - | 1 | 0 | 2 | 0 | 0 | 340 |
| L1932 | 6 | 1 | Mine | no | 1 | 2 | 3 | 0 | 0 | 0 | 0 | 565 |
| L1932 | 6 | 1 | Opponent | no | 2 | 2 | 5 | 0 | 1 | 0 | 0 | 340 |
| L2033 | 5 | 1 | Mine | no | - | 3 | 0 | 6 | 1 | 0 | 0 | 420 |
| L2033 | 5 | 1 | Opponent | yes | - | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Mine | no | 0 | 1 | 9 | 0 | 1 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Opponent | no | - | 2 | 4 | 1 | 1 | 0 | 0 | 60 |
| L2433 | 3 | 1 | Mine | no | 4 | 3 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 0 | 1 | 6 | 1 | 2 | 0 | 0 | 641 |
| L2630 | 2 | 1 | Mine | - | - | 3 | 6 | 0 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 3 | 2 | 3 | 0 | 2 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Opponent | no | 3 | 2 | 4 | 1 | 1 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Mine | no | 9 | 1 | 3 | 0 | 0 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Opponent | no | 6 | 6 | 2 | 0 | 0 | 0 | 0 | 144 |
| **Average** | | | Mine | 22% | 3.3 | 2.8 | 3.0 | 0.9 | 0.3 | 0.0 | 0.0 | 325.3 |
| **Average** | | | Opponent | 22% | 2.6 | 2.4 | 3.0 | 1.5 | 0.4 | 0.0 | 0.0 | 189.3 |

### KPIs: co-opp-a57fba0-p3

Rules off - Mine only: BREAK OUTCOMES, OVERRUN ON, STAND AND SHOOT, FLEES FROM CHARGE.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 23% (40 of 174) | 11% (20 of 174) | 17% (60 of 348) |
| Winner chose to follow up after the loser gave ground |  | 95% (69 of 73); on the table 95% | 100% (52 of 52); on the table 100% | 97% (121 of 125); on the table 97% |
| Winner chose to pursue after the loser fell back in good order |  | 71% (5 of 7); on the table 71% | 91% (10 of 11); on the table 91% | 83% (15 of 18); on the table 83% |
| Winner chose to pursue after the loser fled |  | 69% (18 of 26); on the table 69% | 68% (19 of 28); on the table 68% | 69% (37 of 54); on the table 69% |
| Winner chose to follow up or pursue (all three) |  | 87% (92 of 106); on the table 87% | 89% (81 of 91); on the table 89% | 88% (173 of 197); on the table 88% |
| Magic missiles tried each own turn | 50%+ | 27% (91 of 342) | 34% (65 of 192) | 29% (156 of 534) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 46% (91 of 196) | 45% (65 of 143) | 46% (156 of 339) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 36% (8 of 22) | 47% (21 of 45) | 43% (29 of 67) |
| Points that never fought | lower | 33% (22870 of 68801) | 38% (27091 of 71990) | 35% (49961 of 140791) |
|   infantry points that never fought | lower | 36% (5059 of 14174) | 50% (7127 of 14220) | 43% (12186 of 28394) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 54% (146 of 272) | 58% (164 of 285) | 56% (310 of 557) |
| Bound items with a magic missile used (at least once a game) |  | 96% (24 of 25); 1.7 uses a game | 88% (21 of 24); 2.2 uses a game | 92% (45 of 49); 2.0 uses a game |
| Bound items with another spell used |  | 21% (3 of 14); 0.2 uses a game | 33% (2 of 6); 0.2 uses a game | 25% (5 of 20); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (10 of 20); 0.3 uses a game | 43% (6 of 14); 0.2 uses a game | 47% (16 of 34); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 49% (29022 of 59391) | 51% (32889 of 64043) | 50% (61911 of 123434) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.1 (15%) | 0.9 (27%) | 2.0 (19%) |
| MARCHED: its unit marched | 1.3 (19%) | 0.8 (21%) | 2.1 (20%) |
| CHARGED: its unit charged | 0.2 (2%) | 0.3 (9%) | 0.5 (4%) |
| IN COMBAT: engaged in combat | 1.6 (23%) | 0.8 (22%) | 2.4 (22%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.2 (5%) | 0.2 (2%) |
| FLEEING: fleeing | 0.0 (0%) | 0.2 (7%) | 0.3 (3%) |
| GONE: slain | 2.1 (29%) | 0.2 (7%) | 2.3 (22%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (6%) | 0.1 (2%) | 0.5 (4%) |
| STUPIDITY: Stupidity | 0.2 (2%) | 0.0 (0%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.0 | 1.1 | 1.5 | 4.3 | 0.9 | 1.9 |
| not cast | 3.9 | 1.5 | 4.7 | 10.5 | 2.3 | 18.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) | 1.4 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 0.8 (51%) | 0.2 (4%) | 2.0 (19%) | 0.2 (7%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.1 (20%) | 0.4 (19%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (4%) | 0.1 (5%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (4%) | 0.2 (11%) | 0.8 (17%) | 2.4 (22%) | 0.4 (17%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.0 (0%) | 0.3 (7%) | 0.2 (2%) | 0.1 (6%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (2%) | 0.1 (7%) | 0.1 (2%) | 0.3 (3%) | 0.0 (0%) | 0.8 (4%) |
| GONE: slain | 1.1 (28%) | 0.2 (16%) | 1.5 (32%) | 2.3 (22%) | 0.5 (20%) | 3.1 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (4%) | 0.1 (4%) | 0.3 (7%) | 0.5 (4%) | 0.1 (5%) | 0.4 (2%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (0%) | 0.1 (2%) | 0.2 (2%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.1 (4%) | 0.0 (1%) | 0.1 (1%) | 0.5 (21%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (53%) | 0.1 (7%) | 1.3 (28%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.1 (70%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.9 a game | 0.6 a game | 0.8 a game |
| stood (cast and not dispelled) | 50% (12 of 24) | 59% (10 of 17) | 54% (22 of 41) |
| the unit moved after it | 58% (7 of 12) | 60% (6 of 10) | 59% (13 of 22) |
| it charged on its next turn | 0% (0 of 12) | 10% (1 of 10) | 5% (1 of 22) |
| the enemy charged it first | 42% (5 of 12) | 20% (2 of 10) | 32% (7 of 22) |
| it fought by the end of its next turn | 8% (1 of 12) | 0% (0 of 10) | 5% (1 of 22) |
| it moved out of a charge the enemy had planned (not charged first) | 25% (3 of 12) | 20% (2 of 10) | 23% (5 of 22) |
| none of these (no charge, no fight, no charge escaped) | 33% (4 of 12) | 50% (5 of 10) | 41% (9 of 22) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (480 of 755) | 59% (364 of 612) | 62% (844 of 1367) |
|   cavalry | 53% (35 of 66) | 63% (66 of 105) | 59% (101 of 171) |
|   character | 61% (60 of 98) | 27% (35 of 128) | 42% (95 of 226) |
|   chariot | 42% (42 of 99) | 76% (22 of 29) | 50% (64 of 128) |
|   infantry | 52% (106 of 204) | 65% (165 of 254) | 59% (271 of 458) |
|   monster | 45% (18 of 40) | 83% (5 of 6) | 50% (23 of 46) |
|   war machine | 88% (219 of 248) | 79% (71 of 90) | 86% (290 of 338) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (30%) | 1.4 (21%) | 3.7 (26%) |
| CHARGED: it charged | 1.4 (18%) | 1.5 (22%) | 2.9 (20%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.8 (11%) | 0.5 (7%) | 1.3 (9%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.1 (1%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.1 (15%) | 0.7 (10%) | 1.9 (13%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (4%) | 0.6 (8%) | 0.9 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.2 (16%) | 1.5 (21%) | 2.7 (19%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.2 (2%) | 0.2 (2%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| OTHER BAR | 0.3 (4%) | 0.3 (5%) | 0.6 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.4 | 1.1 | 79% | 5.5 pts | 24 pts |
| character | 3.2 | 1.0 | 77% | 8.7 pts | 28 pts |
| chariot | 1.8 | 0.9 | 69% | 14.9 pts | 26 pts |
| infantry | 12.1 | 3.8 | 78% | 8.6 pts | 104 pts |
| monster | 0.9 | 0.4 | 71% | 13.4 pts | 12 pts |
| war machine | 8.4 | 7.1 | 60% | 23.4 pts | 195 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.8 | 5.5 | 5.1 |
| Charges that made contact a game | 3.6 | 3.8 | 3.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.89 declared, 0.70 contact (27 units) | 1.00 declared, 0.63 contact (19 units) | 0.93 declared, 0.67 contact (46 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 1.00 contact (4 units) | 0.67 declared, 0.44 contact (9 units) | 0.77 declared, 0.62 contact (13 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.65 declared, 0.48 contact (219 units) | 0.65 declared, 0.45 contact (265 units) | 0.65 declared, 0.47 contact (484 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 49% (38 of 77) | 47% (7 of 15) | 20% (2 of 10) | 46% (47 of 102) |
| Character in a unit | 72% (26 of 36) | 69% (9 of 13) | 67% (4 of 6) | 71% (39 of 55) |
| Character on its own | 76% (31 of 41) | 49% (21 of 43) | 28% (19 of 69) | 46% (71 of 153) |
| Chariot | 73% (8 of 11) | 83% (10 of 12) | - | 78% (18 of 23) |
| Infantry | 59% (41 of 70) | 57% (24 of 42) | 0% (0 of 5) | 56% (65 of 117) |
| Monster | 62% (21 of 34) | 57% (4 of 7) | - | 61% (25 of 41) |
| Monstrous | 80% (8 of 10) | 64% (7 of 11) | - | 71% (15 of 21) |
| War Machines | 65% (28 of 43) | 100% (2 of 2) | - | 67% (30 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 94% (15 of 16); on the table 94% | 23% (22 of 96) | 34% | 82% (18 of 22) | 83% (5 of 6); 3.2 uses a game | 50% (1 of 2); 0.5 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 92% (11 of 12); on the table 92% | 31% (11 of 36) | 32% | 66% (21 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 3 | 50% (1 of 2); on the table 50% | - | 61% | 62% (15 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 64% (7 of 11); on the table 64% | 37% (11 of 30) | 33% | 61% (36 of 59) | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 8 | 90% (19 of 21); on the table 90% | 29% (55 of 192) | 48% | 53% (39 of 74) | 89% (16 of 18); 5.8 uses a game | 0% (0 of 4); 0.0 uses a game | 25% (2 of 8); 0.2 uses a game |
| High Elf Realms | 7 | 89% (16 of 18); on the table 89% | 36% (15 of 42) | 28% | 46% (25 of 54) | 100% (9 of 9); 4.0 uses a game | 33% (4 of 12); 1.7 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 100% (7 of 7); on the table 100% | - | 46% | 44% (8 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Lizardmen | 1 | 67% (2 of 3); on the table 67% | 33% (2 of 6) | 34% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 0% (0 of 1); on the table 0% | 0% (0 of 6) | 28% | 14% (1 of 7) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (4 of 4); on the table 100% | 33% (4 of 12) | 9% | 31% (5 of 16) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Skaven | 2 | 86% (6 of 7); on the table 86% | 8% (1 of 12) | 49% | 64% (9 of 14) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Tomb Kings of Khemri | 6 | 76% (13 of 17); on the table 76% | 17% (1 of 6) | 28% | 46% (12 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 100% (27 of 27); on the table 100% | 31% (17 of 54) | 30% | 39% (18 of 46) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 11 | 86% (37 of 43); on the table 86% | 43% (13 of 30) | 30% | 59% (57 of 96) | 100% (4 of 4); 1.7 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 6 | 100% (8 of 8); on the table 100% | 33% (4 of 12) | 45% | 69% (43 of 62) | 91% (10 of 11); 5.3 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (co-opp-a57fba0-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 39% (36) | 49% (43) | 44% (79) |
| ...free all their last turn and able to turn (per game) | 0.61 | 0.58 | 1.19 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.25 | 0.22 | 0.47 |
| ...with the charger already in that arc before they moved (per game) | 0.39 | 0.47 | 0.86 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.94 | 1.58 | 3.53 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.00 | 0.78 | 1.78 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.00 | 5.31 | 11.31 |

### Quality by phase: co-opp-a57fba0-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.2 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 52% (74 of 143) | 46% (71 of 153) |
| Strategy | Shoot objectives carried out (shot that target) | 49% (178 of 365) | 51% (128 of 251) |
| Strategy | Close-in objectives charged next turn | 18% (33 of 182) | 12% (31 of 259) |
| Strategy | Support requests answered (helper made contact too) | 33% (4 of 12) | 55% (11 of 20) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | 100% (3 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 62% (5 of 8) | 100% (3 of 3) |
| Strategy | Joined characters whose unit fought | 47% (17 of 36) | 52% (22 of 42) |
| Strategy | Lone characters that fought | 77% (76 of 99) | 70% (64 of 92) |
| Movement | Charges halted short of contact | 0.1 | 0.1 |
| Movement | Idle units | 0.9 | 1.5 |
| Movement | Points that never moved of their own | 325.3 | 189.3 |
| Movement | Fights charged into per game | 3.3 | 3.2 |
| Movement | Charges with odds: long shots (under 50%) | 14 of 106, net -52 | 34 of 104, net +108 |
| Movement | Charges with odds: sweet spot (55-75%) | 20 of 106, net +34 | 16 of 104, net +129 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 9 of 106, net +185 | 9 of 104, net +85 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 31 of 106, net +127 | 25 of 104, net +147 |
| Shooting | Shots by shooting units (incl. breath weapons) | 7.9 | 10.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (132 of 284) | 50% (179 of 359) |
| Shooting | Points destroyed by shooting units | 62.6 | 29.4 |
| Shooting | War machine shots | 6.1 | 2.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 55% (121 of 219) | 37% (30 of 82) |
| Shooting | Points destroyed by war machines | 41.9 | 35.5 |
| Magic | Magic missiles cast | 1.7 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 28% (17 of 60) | 43% (16 of 37) |
| Magic | Wounds caused by magic missiles | 3.2 | 2.1 |
| Magic | Wounds caused by other spells | 1.1 | 1.1 |
| Magic | Points destroyed by magic (all spells) | 79.8 | 69.9 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.4 / 0.2 / 0.6 / 0.1 | 2.0 / 0.2 / 0.5 / 0.4 |
| Combat | Points destroyed in combat | 326.0 | 418.5 |
| Combat | Points run down | 63.6 | 72.7 |
| Combat | Net points per charged fight, damage counted | +72 | +111 |
| Combat | Net per 100 charger points, damage counted | +26.0 | +38.2 |
| Combat | First round won (charged fights) | 70% | 66% |
| Combat | Net points per charged fight | +67 | +117 |
| Combat | Net points per supported fight / lone fight | +165 / +55 | +127 / +116 |
| Combat | Charged fights on a top-3 enemy unit | 37 of 119 | 53 of 116 |
| Game | Points lost | 757.2 | 655.4 |
| Game | VP from objectives | 519.2 | 544.2 |
| Game | Lone holders (player turns) | 3.3 | 2.6 |

- Mine won / drew / lost: 13 / 7 / 16 of 36 ended games (of 36); mean margin (Mine - Opponent) -128 VP
- The side that went first won 14 of 29 games with a winner
- Points traded per game (both sides' losses): 1413
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: co-opp-a57fba0-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 5.7 | -201.2 | 190.5 | 116.0 | 3.6 | -97.8 | 108.2 | 59.9 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.2 | 0.0 | 2.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.6 | +0.0 | 0.0 | 48.6 | 0.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.7 | +2.8 | 0.0 | 16.0 | 0.7 | +4.9 | 0.0 | 8.6 |
| BEST FACING | 0.4 | +13.3 | 0.0 | 18.9 | 0.4 | +18.5 | 0.0 | 13.4 |
| BEST FIRST | 1.4 | +51.4 | 46.0 | 24.4 | 0.9 | +54.6 | 15.9 | 27.2 |
| BEST OVERALL | 0.4 | +29.5 | 0.0 | 0.0 | 0.4 | +12.7 | 0.0 | 6.8 |
| BEST PREY | 0.5 | +36.0 | 6.2 | 30.5 | 0.7 | +33.5 | 28.6 | 23.1 |
| BEST PRIZE | 0.1 | -13.5 | 7.8 | 10.5 | 0.1 | +5.5 | 9.1 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | -1.6 | 0.0 | 0.0 | 0.2 | -1.0 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 4.7 | 0.0 | 0.1 | +0.0 | 16.2 | 0.0 |
| BLOCKED WHEEL | 0.4 | +21.1 | 0.0 | 0.0 | 0.4 | +1.1 | 0.0 | 1.4 |
| BLOWS WHERE AIMED | 0.3 | -31.0 | 18.4 | 10.8 | 0.2 | -35.6 | 30.1 | 5.4 |
| BREAK OUTCOMES | - | - | - | - | 2.4 | -4.3 | 254.5 | 67.1 |
| CANNON PLAN MISSED | 0.5 | +0.0 | 31.7 | 8.1 | 0.1 | +0.0 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 5.4 | +96.4 | 263.3 | 115.6 | 1.3 | +63.7 | 87.6 | 17.1 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 5.2 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 13.9 | 0.0 | 0.1 | +0.0 | 14.6 | 0.0 |
| CAST JOB | 0.9 | +25.9 | 58.1 | 26.5 | 0.9 | +16.2 | 36.9 | 15.0 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.1 | +12.0 | 0.0 | 0.0 | 0.1 | +1.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.5 | +0.0 | 0.0 | 30.9 | 0.4 | +0.0 | 0.0 | 31.7 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.0 | +54.3 | 0.0 | 16.6 | 1.6 | +82.6 | 0.0 | 35.8 |
| CHAFF PASSED | 0.3 | -0.1 | 0.0 | 4.8 | 0.2 | -0.6 | 16.2 | 5.7 |
| CHAMPION TAKES THE CHALLENGE | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE NOW FIRST | 2.5 | +0.0 | 201.2 | 59.7 | 2.4 | +0.0 | 279.9 | 53.2 |
| CHARGE NOW WEIGHED | 0.5 | -59.6 | 18.3 | 15.1 | 0.5 | -36.1 | 4.1 | 7.9 |
| CHARGER SLAIN LOST | 0.6 | -18.6 | 47.8 | 17.3 | 0.6 | -17.7 | 23.5 | 26.9 |
| CHARIOT WIZARD CAREFUL | 0.0 | -2.1 | 0.0 | 11.0 | 0.1 | -0.0 | 12.1 | 11.1 |
| CHEAP HELPER | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 3.0 |
| COMBAT PIVOT | 0.7 | +0.0 | 19.1 | 37.4 | 0.3 | +0.0 | 17.9 | 4.7 |
| CONVEYANCE SEARCH | 0.3 | +40.1 | 0.0 | 9.9 | 0.4 | +27.4 | 16.4 | 24.0 |
| COVER ONCE | 7.8 | -501.4 | 0.0 | 150.1 | 5.9 | -403.6 | 0.0 | 149.9 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 10.8 | 8.2 | 0.1 | +0.0 | 6.7 | 0.0 |
| DEFENSIVE FLOOR | 0.0 | +0.7 | 0.0 | 1.1 | 0.1 | +1.3 | 0.0 | 1.9 |
| EDGE GIVE GROUND | 0.2 | +1.2 | 13.4 | 0.0 | 0.2 | +5.7 | 17.2 | 3.5 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.9 | +142.5 | 0.0 | 97.6 | 1.6 | +89.3 | 0.0 | 49.2 |
| FALLBACK BY WORTH | 4.5 | +57.1 | 0.0 | 37.1 | 4.8 | +19.5 | 0.0 | 47.7 |
| FIGHT LIFT | 0.1 | +0.3 | 0.0 | 0.0 | 0.1 | +2.8 | 13.4 | 1.7 |
| FIRE AND FLEE | 0.0 | +0.4 | 2.9 | 2.2 | 0.0 | +0.1 | 0.0 | 3.2 |
| FLANK NOT WEIGHED | 5.4 | +0.0 | 0.0 | 127.9 | 5.3 | +0.0 | 0.0 | 112.7 |
| FLEES FROM CHARGE | - | - | - | - | 0.7 | +4.4 | 44.9 | 0.5 |
| FOLLOW UP WEIGHED | 1.1 | +180.8 | 0.0 | 33.6 | 1.1 | +141.9 | 0.0 | 41.6 |
| FRIENDS SHOTS CHECKED | 0.4 | +20.5 | 0.0 | 23.4 | 0.1 | +13.8 | 0.0 | 7.2 |
| GIVES UP | 0.1 | -0.3 | 0.0 | 3.2 | 0.1 | -0.7 | 7.6 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -0.1 | 4.5 | 0.0 |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 5.4 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 4.7 | 15.5 | 0.4 | +0.0 | 32.2 | 18.4 |
| HILL BY ITS CHANCE | 0.2 | -13.8 | 0.0 | 1.8 | 0.4 | -58.5 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 8.7 | -155.3 | 476.9 | 137.8 | 7.9 | -205.8 | 446.2 | 121.5 |
| HORN WORTH | - | - | - | - | 0.1 | +0.8 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +3.7 | 3.5 | 3.8 | 0.2 | +5.4 | 3.5 | 2.9 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 3.8 | 0.1 | +0.0 | 6.9 | 2.9 |
| HUNT IN PAIRS | 0.3 | +16.8 | 0.0 | 10.5 | 0.6 | +24.2 | 0.0 | 16.2 |
| HUNT KEPT | 0.2 | +5.4 | 3.5 | 0.0 | 0.2 | +2.5 | 6.9 | 3.4 |
| HUNT RESULT | 0.1 | +5.8 | 0.0 | 3.8 | 0.2 | +15.8 | 6.9 | 6.1 |
| HUNT THE GUNS | 0.1 | +43.0 | 3.5 | 3.8 | 0.3 | +89.6 | 8.9 | 0.5 |
| IDLE COST | 14.9 | -252.9 | 0.0 | 129.3 | 18.3 | -334.0 | 0.0 | 234.3 |
| INVITES THE FIGHT | 1.4 | +10.6 | 57.8 | 29.6 | 0.6 | +4.0 | 37.8 | 28.9 |
| JOINT CHARGE PLAN | 0.1 | +3.7 | 0.0 | 7.6 | 0.2 | +7.7 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -3.1 | 31.0 | 0.0 |
| KEEP FALLS | 0.1 | +2.7 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.0 | +0.3 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.9 | +55.8 | 138.2 | 46.0 | 2.2 | +65.0 | 178.4 | 27.0 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.6 | +90.6 | 141.0 | 14.9 | - | - | - | - |
| KILLS COUNT NEXT TURN | 5.1 | +202.8 | 237.7 | 41.8 | 7.4 | +267.5 | 322.1 | 158.3 |
| LONE CHARACTER SAFE SPOT | 0.3 | +16.1 | 8.6 | 0.0 | 0.3 | +5.7 | 5.6 | 4.6 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 8.0 | 10.6 |
| LONE WIZARD KEPT IN | 0.6 | +37.3 | 0.0 | 0.0 | 0.4 | +25.4 | 0.0 | 0.0 |
| LONG SHOT | 0.6 | +1.0 | 43.9 | 3.4 | 0.2 | -0.3 | 16.0 | 0.0 |
| LOST CHARGE | 2.9 | -41.0 | 130.3 | 90.2 | 2.2 | -35.7 | 53.3 | 98.8 |
| LURE BY WHAT IT DRAWS | 0.2 | -13.8 | 0.0 | 1.5 | 0.2 | -18.8 | 0.0 | 10.0 |
| MAKE SURE TOGETHER | 0.9 | +122.4 | 28.5 | 12.2 | 1.1 | +89.8 | 8.4 | 7.0 |
| MANOEUVRE | 0.2 | +1.3 | 0.0 | 8.6 | 0.2 | +6.3 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.4 | +12.4 | 0.0 | 13.8 | 0.7 | +26.5 | 0.0 | 18.8 |
| MARCH ODDS | 0.4 | +24.0 | 19.1 | 24.4 | 0.2 | +10.9 | 12.7 | 0.0 |
| MARCH OVER CASTS | 0.6 | +57.2 | 0.0 | 38.0 | 0.3 | +27.8 | 0.0 | 14.1 |
| MAX FOR POSITIONING | 6.1 | +89.8 | 0.0 | 185.2 | 6.7 | +90.3 | 0.0 | 159.5 |
| MISSILES IN THE MOVE | 3.6 | +94.2 | 0.0 | 143.9 | 4.2 | +76.0 | 0.0 | 93.6 |
| MISSILES NEXT TURN | 4.8 | +70.8 | 0.0 | 172.5 | 4.9 | +48.9 | 0.0 | 101.4 |
| MODEL FACING | 0.1 | +38.7 | 0.0 | 0.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 21.6 | 32.4 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.3 | +10.4 | 0.0 | 30.0 | 0.4 | +16.7 | 0.0 | 6.4 |
| MOVE SPELL IN RANGE | 0.3 | +9.3 | 0.0 | 21.1 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.4 | -12.1 | 1.8 | 37.9 | 0.1 | -2.4 | 0.0 | 21.7 |
| MOVE SPELL SPOT | 0.1 | +0.0 | 0.0 | 10.5 | 0.1 | +0.0 | 0.0 | 11.1 |
| MOVE TO CHARGE | 3.9 | +354.8 | 197.1 | 89.3 | 5.2 | +462.8 | 154.7 | 94.5 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +3.6 | 2.8 | 0.0 | - | - | - | - |
| NO RALLY LEFT | 0.0 | +2.4 | 0.0 | 13.9 | - | - | - | - |
| NOT NEEDED | 0.1 | -4.0 | 16.6 | 2.3 | 0.1 | -3.4 | 13.6 | 0.0 |
| NOT TURNED | 6.0 | +68.8 | 0.0 | 101.4 | 5.3 | +39.7 | 0.0 | 103.6 |
| NOT WORTH A CAST | 0.6 | -0.3 | 0.0 | 23.8 | 0.8 | -0.9 | 0.0 | 6.5 |
| OFF BEST | 16.2 | -644.6 | 8.9 | 308.3 | 15.6 | -740.8 | 0.0 | 305.8 |
| ONE FIGHT FORMULA | 9.1 | -156.3 | 42.8 | 191.7 | 8.0 | -185.9 | 17.8 | 219.7 |
| ONE OBJECTIVE FORMULA | 2.1 | -73.0 | 0.0 | 32.6 | 1.4 | -84.7 | 0.0 | 20.6 |
| OPENS A LANE | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +1.4 | 21.4 | 0.0 |
| OPENS UP | 0.2 | +16.9 | 8.0 | 10.5 | 0.1 | +5.4 | 4.0 | 0.0 |
| OVERRUN ON | - | - | - | - | 0.4 | +8.9 | 52.5 | 0.0 |
| OVERRUN THREAT | - | - | - | - | 0.0 | +0.3 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.4 | +19.6 | 49.3 | 10.5 | 0.5 | +4.2 | 44.2 | 17.5 |
| PATHS CROSS | 1.9 | +109.7 | 0.0 | 29.1 | 2.4 | +185.1 | 0.0 | 22.9 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +2.8 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.2 | -0.9 | 0.0 | 22.5 | 0.1 | -1.3 | 0.0 | 0.0 |
| PLAN RESULT | 36.2 | +1130.0 | 1066.0 | 936.7 | 36.5 | +1180.1 | 1511.1 | 910.4 |
| PURSUES BIG PREY | 0.0 | -0.8 | 0.0 | 0.0 | 0.1 | -3.8 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.1 | +11.5 | 0.0 | 1.5 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +4.9 | 0.0 | 0.0 | 0.1 | +3.5 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.6 | +4.2 | 0.0 | 14.2 | 1.2 | +16.5 | 0.0 | 56.7 |
| RANDOM MOVER NO PROMISE | 0.2 | -19.2 | 13.1 | 4.7 | 0.3 | -18.5 | 30.3 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.6 | -8.9 | 0.0 | 15.1 | 1.1 | -25.6 | 0.0 | 21.8 |
| REDIRECT COUNTER | 1.7 | +152.2 | 0.0 | 25.4 | 3.5 | +266.6 | 0.0 | 57.3 |
| REDIRECT WEIGHED | 0.2 | +2.8 | 4.9 | 0.0 | 0.3 | +2.5 | 3.5 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 14.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.4 | +18.6 | 0.0 | 4.9 | 1.2 | +58.1 | 0.0 | 21.5 |
| RESTRAINS TO SHOOT | 0.1 | +1.7 | 0.0 | 0.0 | 0.0 | +1.0 | 0.0 | 0.0 |
| RISK BY ARC | 2.5 | +95.9 | 197.4 | 59.3 | 2.1 | +42.8 | 202.6 | 41.2 |
| RISK ONCE | 4.5 | +138.6 | 43.1 | 163.0 | 4.6 | +162.9 | 52.0 | 264.7 |
| SAFE SURE CHARGE | 0.0 | -2.4 | 0.0 | 0.0 | 0.1 | -0.4 | 6.4 | 5.2 |
| SAFER THAN THE JOB | 1.0 | +72.5 | 0.0 | 21.2 | 0.8 | +45.9 | 0.0 | 16.9 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.0 | 0.3 | +1.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -2.2 | 0.0 | 0.0 | 0.5 | -30.4 | 0.0 | 4.1 |
| SEARCH SPOT | 2.0 | +84.2 | 0.0 | 8.1 | 2.2 | +118.4 | 0.0 | 41.4 |
| SELF MOVE SPELL | 0.4 | +50.0 | 0.0 | 11.0 | 0.2 | +57.7 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.3 | +154.7 | 65.1 | 60.1 | 2.3 | +225.4 | 20.7 | 48.1 |
| SET-UP ANY TARGET | 0.2 | +33.5 | 0.0 | 0.0 | 0.2 | +24.0 | 11.1 | 18.7 |
| SET-UP MISSED | 0.1 | +8.0 | 10.5 | 10.5 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.4 | +0.7 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.1 | +26.6 | 30.6 | 24.4 | 1.2 | +25.3 | 54.0 | 11.7 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.3 | +0.0 | 35.1 | 2.9 | 0.1 | +0.0 | 5.1 | 0.0 |
| SHOTS IN THE MOVE | 13.1 | +470.5 | 0.0 | 263.5 | 9.9 | +326.2 | 0.0 | 131.6 |
| SPELL SETS UP CHARGE | 0.2 | +40.8 | 0.0 | 0.0 | 0.2 | +24.0 | 11.1 | 18.7 |
| SPELL WORTH | 1.5 | +25.8 | 13.3 | 32.9 | 2.4 | +41.5 | 112.3 | 94.7 |
| SPELLS IN THE FIGHT | 0.5 | -3.4 | 86.1 | 22.4 | 0.4 | -8.0 | 49.3 | 4.9 |
| STABLE ROLE | 9.8 | +0.0 | 280.8 | 159.0 | 9.3 | +0.0 | 266.7 | 131.2 |
| STAND AND SHOOT | - | - | - | - | 0.1 | -2.2 | 6.0 | 0.0 |
| STANDS TO CAST | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| STOPS | 0.2 | +5.8 | 3.5 | 0.0 | 0.2 | +3.9 | 12.4 | 1.1 |
| STOPS SHORT OF THE FLANK | 0.4 | +17.9 | 0.0 | 7.5 | 0.6 | +28.6 | 0.0 | 15.7 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 6.2 | -59.4 | 238.6 | 132.1 | 5.6 | -43.8 | 311.1 | 91.4 |
| SUPPORTS | 4.1 | +68.8 | 95.5 | 76.0 | 4.0 | +48.1 | 166.1 | 49.2 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -1.8 | 13.5 | 0.0 | 0.2 | -7.2 | 27.4 | 0.0 |
| SURE REACH TOGETHER | 0.4 | +2.6 | 9.6 | 12.4 | 0.8 | -12.3 | 6.6 | 2.0 |
| THROUGH LINE OF FIRE | 0.3 | +26.3 | 0.0 | 6.6 | 0.2 | +12.7 | 0.0 | 6.2 |
| TURN WORTH | 0.3 | -19.1 | 36.0 | 0.0 | 0.2 | -15.6 | 14.3 | 5.4 |
| TWO OR MORE ARRIVE | 0.4 | +5.1 | 22.8 | 4.4 | 0.6 | +4.4 | 8.4 | 9.2 |
| WAIT AFTER COSTS | 7.6 | -357.1 | 332.8 | 128.3 | 7.4 | -384.5 | 260.8 | 128.1 |
| WALKS TO THE FIGHT | 1.8 | +15.7 | 40.7 | 8.0 | 0.9 | +3.5 | 24.8 | 3.5 |
| WAR ENGINE CHARGES | 0.1 | +12.8 | 5.4 | 17.2 | 0.0 | +4.9 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.8 | +0.0 | 50.4 | 24.7 | 0.2 | +0.0 | 0.0 | 0.0 |
| WEARS DOWN | 1.2 | +51.8 | 62.9 | 54.9 | 1.2 | +45.7 | 135.4 | 47.4 |
| WHO HITS BACK | 0.3 | +22.6 | 0.0 | 16.9 | 0.1 | +8.4 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.4 | +10.7 | 34.7 | 20.3 | 0.4 | +5.1 | 31.9 | 1.9 |
| WHOLE FIGHT GAIN | 0.3 | +17.1 | 13.8 | 2.3 | 0.4 | +28.8 | 48.0 | 3.5 |
| WIDER SPREAD | 2.7 | -13.5 | 203.3 | 57.2 | 2.2 | -4.9 | 230.9 | 37.5 |
| WOUNDED STAYS OUT | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |

### Rule changes: co-opp-a57fba0-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1142 | 1142 | 1142 | 31.72 | -49873 | -43.7 |
| MOVE TO CHARGE | 326 | 326 | 185 | 5.14 | +11893 | +64.3 |
| PATHS CROSS | 152 | 152 | 152 | 4.22 | +10612 | +69.8 |
| SEARCH SPOT | 152 | 152 | 149 | 4.14 | +7294 | +49.0 |
| KILLS COUNT NEXT TURN | 449 | 449 | 147 | 4.08 | +3745 | +25.5 |
| SUPPORTS | 291 | 291 | 130 | 3.61 | +1595 | +12.3 |
| FACES THE THREAT | 127 | 127 | 127 | 3.53 | +8345 | +65.7 |
| COVER ONCE | 491 | 264 | 92 | 2.56 | +1542 | +16.8 |
| WAIT AFTER COSTS | 541 | 541 | 87 | 2.42 | +1584 | +18.2 |
| SHOTS IN THE MOVE | 826 | 566 | 83 | 2.31 | +2685 | +32.3 |
| FOLLOW UP WEIGHED | 81 | 81 | 81 | 2.25 | +11619 | +143.4 |
| BEST FIRST | 80 | 80 | 80 | 2.22 | +3813 | +47.7 |
| ADVANCE WORTH | 334 | 334 | 66 | 1.83 | +1035 | +15.7 |
| ARTILLERY RE-ROLL WEIGHED | 66 | 66 | 66 | 1.83 | +0 | +0.0 |
| RISK ONCE | 327 | 236 | 65 | 1.81 | +1736 | +26.7 |
| FALLBACK BY WORTH | 336 | 336 | 64 | 1.78 | +2757 | +43.1 |
| SAFER THAN THE JOB | 64 | 64 | 64 | 1.78 | +4264 | +66.6 |
| MISSILES IN THE MOVE | 280 | 175 | 57 | 1.58 | +761 | +13.4 |
| RESERVE FALL BACK | 57 | 57 | 57 | 1.58 | +2762 | +48.5 |
| SET UP TOGETHER | 130 | 109 | 57 | 1.58 | +5532 | +97.1 |
| CANNON SIGHT KEPT | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| CANNON PLANNED TARGET | 244 | 244 | 49 | 1.36 | -493 | -10.1 |
| CHAFF IN THE MOVE | 93 | 91 | 49 | 1.36 | +1755 | +35.8 |
| REDIRECT COUNTER | 187 | 89 | 46 | 1.28 | +4601 | +100.0 |
| ONE FIGHT FORMULA | 614 | 351 | 45 | 1.25 | +214 | +4.8 |
| RISK BY ARC | 165 | 164 | 41 | 1.14 | +757 | +18.5 |
| WALKS TO THE FIGHT | 96 | 96 | 40 | 1.11 | +247 | +6.2 |
| HOLDS AMBUSHERS | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 37 | 37 | 37 | 1.03 | +3286 | +88.8 |
| COMBAT PIVOT | 37 | 37 | 37 | 1.03 | +0 | +0.0 |
| MARCH CHECK | 39 | 38 | 37 | 1.03 | +1351 | +36.5 |
| CHARGE NOW FIRST | 174 | 174 | 36 | 1.00 | -1961 | -54.5 |
| ADVANCE LANE KEPT | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 35 | 35 | 35 | 0.97 | +1675 | +47.8 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2259 | +68.5 |
| MAX FOR POSITIONING | 462 | 266 | 32 | 0.89 | +61 | +1.9 |
| IDLE COST | 1195 | 649 | 31 | 0.86 | +344 | +11.1 |
| BEST FACING | 30 | 30 | 30 | 0.83 | +1145 | +38.2 |
| BEST OVERALL | 30 | 30 | 30 | 0.83 | +1518 | +50.6 |
| HONEST WORTH | 598 | 598 | 30 | 0.83 | +189 | +6.3 |
| BLOCKED WHEEL | 29 | 29 | 29 | 0.81 | +798 | +27.5 |
| CAST JOB | 67 | 67 | 29 | 0.81 | +547 | +18.9 |
| RANDOM MOVE BY FIGURES | 67 | 67 | 29 | 0.81 | +748 | +25.8 |
| SHOOTS FROM THE BEST SPOT | 83 | 83 | 29 | 0.81 | +556 | +19.2 |
| MOVE AND CAST | 27 | 27 | 27 | 0.75 | +975 | +36.1 |
| KEEPS ITS TARGET | 145 | 145 | 26 | 0.72 | +469 | +18.0 |
| SCOUT WAITS | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| INVITES THE FIGHT | 70 | 70 | 24 | 0.67 | +159 | +6.6 |
| MARCH ODDS | 24 | 24 | 24 | 0.67 | +259 | +10.8 |
| WAR ENGINE JOBS | 33 | 33 | 24 | 0.67 | -1161 | -48.4 |
| KILLS COUNT | 59 | 58 | 21 | 0.58 | +719 | +34.2 |
| MAKE SURE TOGETHER | 70 | 48 | 21 | 0.58 | +2197 | +104.6 |
| THROUGH LINE OF FIRE | 21 | 21 | 21 | 0.58 | +1403 | +66.8 |
| REDIRECT WEIGHED | 20 | 20 | 20 | 0.56 | +261 | +13.0 |
| BEST PREY | 43 | 43 | 19 | 0.53 | +365 | +19.2 |
| FRIENDS SHOTS CHECKED | 18 | 18 | 18 | 0.50 | +1237 | +68.7 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +36 | +2.0 |
| CHAFF PASSED | 17 | 17 | 17 | 0.47 | -25 | -1.5 |
| WEARS DOWN | 89 | 89 | 16 | 0.44 | +367 | +22.9 |
| SURE CHARGE BEATS ADVANCE | 14 | 14 | 14 | 0.39 | -327 | -23.3 |
| WHO HITS BACK | 14 | 14 | 14 | 0.39 | +629 | +44.9 |
| WHOLE FIGHT GAIN | 26 | 25 | 14 | 0.39 | +557 | +39.8 |
| BIG CHARACTER SAFETY | 13 | 13 | 13 | 0.36 | -95 | -7.3 |
| MANOEUVRE | 16 | 16 | 13 | 0.36 | +274 | +21.0 |
| SHOT REPLANNED | 12 | 12 | 12 | 0.33 | +0 | +0.0 |
| MISSILES NEXT TURN | 349 | 208 | 10 | 0.28 | +80 | +8.0 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| LOST CHARGE | 184 | 184 | 9 | 0.25 | +199 | +22.2 |
| PIVOT GUARDS FLANK | 9 | 9 | 9 | 0.25 | -80 | -8.9 |
| REFUSING RETIRES | 23 | 23 | 9 | 0.25 | -1 | -0.1 |
| BEST PRIZE | 8 | 8 | 8 | 0.22 | -673 | -84.1 |
| HUNT IN PAIRS | 31 | 15 | 8 | 0.22 | +128 | +16.0 |
| OPENS UP | 12 | 12 | 8 | 0.22 | +249 | +31.1 |
| SUPPORT NARROWED | 424 | 424 | 8 | 0.22 | -65 | -8.1 |
| FLEES FROM CHARGE | 25 | 25 | 7 | 0.19 | +266 | +37.9 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +141 | +20.1 |
| CASTING BLOCK | 8 | 8 | 6 | 0.17 | +96 | +16.1 |
| KEEP FALLS | 6 | 6 | 6 | 0.17 | +190 | +31.7 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| STUCK PIVOT | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| WIDER SPREAD | 178 | 176 | 5 | 0.14 | +10 | +2.0 |
| BREAK OUTCOMES | 86 | 86 | 4 | 0.11 | +16 | +3.9 |
| MODEL FACING | 4 | 4 | 4 | 0.11 | +1392 | +347.9 |
| OVERRUNS AWAY | 33 | 33 | 4 | 0.11 | +48 | +12.0 |
| RAIDS THE BAGGAGE NEXT TURN | 4 | 4 | 4 | 0.11 | +101 | +25.3 |
| SURE REACH TOGETHER | 43 | 31 | 4 | 0.11 | +4 | +1.0 |
| BACKUP TARGETS | 50 | 31 | 3 | 0.08 | +6 | +1.9 |
| BLOCKED CHARGE SKIPPED | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| EDGE GIVE GROUND | 14 | 14 | 3 | 0.08 | +46 | +15.2 |
| HUNT ADVANCE | 10 | 10 | 3 | 0.08 | +132 | +43.9 |
| LONE WIZARD HOLDS BACK | 15 | 15 | 3 | 0.08 | -253 | -84.4 |
| LONG SHOT | 26 | 26 | 3 | 0.08 | +87 | +29.1 |
| PURSUES BIG PREY | 3 | 3 | 3 | 0.08 | -164 | -54.5 |
| RESTRAINS TO SHOOT | 3 | 3 | 3 | 0.08 | +97 | +32.2 |
| SAFE SURE CHARGE | 3 | 3 | 3 | 0.08 | -159 | -53.1 |
| STANDS TO CAST | 3 | 3 | 3 | 0.08 | -37 | -12.2 |
| WHOLE FIGHT | 27 | 27 | 3 | 0.08 | +65 | +21.6 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +17 | +8.6 |
| HORN WORTH | 2 | 2 | 2 | 0.06 | +27 | +13.7 |
| NEEDED THERE | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| OVERRUN ON | 14 | 14 | 2 | 0.06 | +78 | +39.0 |
| RAIDS THE BAGGAGE | 2 | 2 | 2 | 0.06 | +322 | +160.9 |
| SPELLS IN THE FIGHT | 31 | 30 | 2 | 0.06 | +28 | +13.8 |
| STOPS | 15 | 15 | 2 | 0.06 | +14 | +6.8 |
| WAR ENGINE CHARGES | 6 | 6 | 2 | 0.06 | +235 | +117.5 |
| WOUNDED STAYS OUT | 2 | 2 | 2 | 0.06 | -270 | -134.8 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -1 | -1.3 |
| DEFENSIVE ARMY | 11 | 11 | 1 | 0.03 | -3 | -3.0 |
| DEFENSIVE FLOOR | 4 | 4 | 1 | 0.03 | +19 | +18.7 |
| KEEPS ITS PREY | 3 | 3 | 1 | 0.03 | +8 | +8.4 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +13 | +13.4 |
| ONE OBJECTIVE FORMULA | 126 | 57 | 1 | 0.03 | +135 | +135.4 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +99 | +99.4 |
| REDIRECT BY WHAT IT STOPS | 61 | 61 | 1 | 0.03 | +27 | +26.6 |
| SCREEN BY WHAT IT SAVES | 22 | 22 | 1 | 0.03 | +5 | +4.6 |
| TWO OR MORE ARRIVE | 35 | 31 | 1 | 0.03 | +14 | +14.1 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 19 | 19 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 21 | 21 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 3 | 3 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 7 | 7 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 31 | trace | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 42 | 40 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 5 | 5 | 0 | 0.00 | - | - |
| CHEAP HELPER | 3 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 24 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 7 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 384 | not checked | - | - | - | - |
| GIVES UP | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 21 | 21 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 22 | 22 | 0 | 0.00 | - | - |
| HUNT DROPPED | 7 | trace | - | - | - | - |
| HUNT KEPT | 12 | trace | - | - | - | - |
| HUNT RESULT | 12 | trace | - | - | - | - |
| HUNT THE GUNS | 15 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 10 | 10 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 22 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 14 | 14 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 5 | trace | - | - | - | - |
| MARCH OVER CASTS | 31 | 31 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 13 | 13 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 10 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 19 | trace | - | - | - | - |
| MOVE SPELL SPOT | 8 | not checked | - | - | - | - |
| NOT NEEDED | 9 | 9 | 0 | 0.00 | - | - |
| NOT TURNED | 407 | 407 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 50 | not checked | - | - | - | - |
| OPENS A LANE | 7 | 2 | 0 | 0.00 | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 2619 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 17 | 17 | 0 | 0.00 | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 19 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 15 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SPELL SETS UP CHARGE | 16 | not checked | - | - | - | - |
| SPELL WORTH | 139 | not checked | - | - | - | - |
| STABLE ROLE | 686 | 686 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| TURN WORTH | 19 | 19 | 0 | 0.00 | - | - |

### Off best figure: co-opp-a57fba0-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.78 | 14.22 | 43.7 |
| FALLBACK | gate | 0.53 | 0.58 | 66.1 |
| CHARGE NOW FIRST | rule | 0.53 | 0.47 | 54.5 |
| TURN GATE | gate | 0.42 | 0.44 | 37.9 |
| WAR ENGINE JOBS | rule | 0.50 | 0.14 | 50.5 |
| SURE CHARGE BEATS ADVANCE | rule | 0.17 | 0.22 | 23.3 |
| CANNON PLANNED TARGET | rule | 0.28 | 0.03 | 52.1 |
| PIVOT GUARDS FLANK | rule | 0.17 | 0.08 | 8.9 |
| BIG CHARACTER SAFETY | rule | 0.11 | 0.11 | 14.0 |
| CHAFF PASSED | rule | 0.03 | 0.19 | 3.1 |
| SUPPORT NARROWED | rule | 0.11 | 0.11 | 8.1 |
| AFTERMATH BAND | gate | 0.14 | 0.06 | 2.2 |
| BEST PRIZE | rule | 0.11 | 0.08 | 96.1 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.11 | 0.03 | 25.6 |
| LONE CHARACTER SAFE SPOT | gate | 0.06 | 0.08 | 21.3 |
| FIGHT ORDER BAND | gate | 0.06 | 0.06 | 2.6 |
| PATHS CROSS | rule | 0.08 | 0.03 | 18.0 |
| SAFER THAN THE JOB | rule | 0.08 | 0.03 | 14.3 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.08 | 13.6 |
| LONE WIZARD HOLDS BACK | rule | 0.03 | 0.06 | 84.4 |
| MARCH ODDS | rule | 0.06 | 0.03 | 4.3 |
| PURSUES BIG PREY | rule | 0.03 | 0.06 | 54.5 |
| SAFE SURE CHARGE | rule | 0.03 | 0.06 | 53.1 |
| STANDS TO CAST | rule | 0.08 | - | 12.2 |
| SUPPORT REQUEST | gate | 0.06 | 0.03 | 68.5 |
| BLOCKED WHEEL | rule | 0.03 | 0.03 | 76.1 |
| CHARGE NOW WEIGHED | rule | 0.03 | 0.03 | 150.0 |
| NO REASON | gate | - | 0.06 | 6.7 |
| THROUGH LINE OF FIRE | rule | 0.03 | 0.03 | 40.5 |
| WOUNDED STAYS OUT | rule | 0.06 | - | 134.8 |
| CATCH ODDS | rule | 0.03 | - | 1.3 |
| DEFENSIVE ARMY | rule | 0.03 | - | 3.0 |
| REDIRECT WEIGHED | rule | 0.03 | - | 28.3 |
| RULE SWITCHED OFF | gate | 0.03 | - | 0.9 |
| WHO HITS BACK | rule | - | 0.03 | 5.0 |

### Plans: co-opp-a57fba0-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 9.7 | 17% | 131 | 192 | 147% |
| Mine | charge | 3.2 | 60% | 269 | 273 | 101% |
| Mine | close in | 5.0 | 30% | 360 | 170 | 47% |
| Mine | hold | 4.5 | 43% | 259 | 0 | 0% |
| Mine | join | 0.5 | 100% | 17 | 0 | 0% |
| Mine | shoot | 8.4 | 56% | 181 | 494 | 273% |
| Mine | support | 4.9 | 91% | 52 | 0 | 0% |
| Opponent | advance | 10.3 | 21% | 164 | 329 | 201% |
| Opponent | charge | 3.5 | 52% | 331 | 324 | 98% |
| Opponent | close in | 7.2 | 21% | 477 | 211 | 44% |
| Opponent | hold | 3.8 | 26% | 271 | 0 | 0% |
| Opponent | join | 0.8 | 93% | 44 | 0 | 0% |
| Opponent | shoot | 5.4 | 60% | 107 | 319 | 299% |
| Opponent | support | 5.5 | 85% | 36 | 0 | 0% |

### Packages: hunt the guns, co-opp-a57fba0-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 4 | 1 | 33% | 33% | 0% | 3.0 | 424 | 69 | 0% | 43 |
| Opponent | 0.3 | 11 | 2 | 22% | 33% | 0% | 2.0 | 309 | 63 | 33% | 54 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.8 | 3 | 1 | 0% | 0% | 0% | - | 448 | 0 | 0% | 56 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 56 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 95 |
| Empire of Man | 0.2 | 1 | 0 | 100% | 100% | 0% | 3.0 | 375 | 208 | 0% | 110 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 21 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 25 |
| Kingdom of Bretonnia | 0.3 | 1 | 0 | 0% | 0% | 0% | - | 450 | 0 | 0% | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 270 |
| Tomb Kings of Khemri | 0.3 | 2 | 0 | 0% | 0% | 0% | - | 315 | 0 | 0% | 44 |
| Vampire Counts | 0.4 | 3 | 1 | 100% | 100% | 0% | 2.0 | 174 | 155 | 100% | 21 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 100% | 0% | 2.0 | 304 | 259 | 100% | 50 |
| Wood Elf Realms | 0.7 | 4 | 1 | 0% | 0% | 0% | - | 348 | 0 | 0% | 42 |

### Battle groups: co-opp-a57fba0-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.7 | 31% | 84% | 5% | 0% | 28% | 0% | 17% | 56% | 0% |
| Opponent | REDIRECT COUNTER | 3.5 | 25% | 84% | 13% | 0% | 11% | 0% | 15% | 74% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: co-opp-a57fba0-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 34 | 74 (34) | 23 | 51 | 46 | 26% | 2.6 | 85 (21) | 0 (4) | 72 (9) | 107 (24) | 7 (10) |
| Mine | Character | 118 | 48 (118) | 48 | 0 | 40 | 15% | 2.5 | 66 (37) | 46 (57) | 29 (3) | 55 (55) | 52 (42) |
| Mine | Clean-up | 18 | 59 (18) | 21 | 38 | 41 | 39% | 2.4 | 59 (3) | 51 (13) | 157 (2) | 65 (12) | 49 (6) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 44 | 31 (44) | 17 | 14 | 31 | 27% | 2.8 | 26 (22) | 40 (14) | 25 (8) | 35 (30) | 23 (14) |
| Mine | Fragile | 3 | 0 (3) | 0 | 0 | 33 | 67% | 4.0 | 0 (3) | - | - | 0 (1) | 0 (2) |
| Mine | Hammer | 52 | 31 (52) | 21 | 10 | 39 | 8% | 2.7 | 31 (14) | 26 (35) | 79 (3) | 39 (36) | 13 (16) |
| Mine | Holder | 25 | 58 (25) | 19 | 39 | 26 | 36% | 3.4 | 44 (8) | 72 (11) | 43 (6) | 82 (15) | 23 (10) |
| Mine | Shooter | 37 | 55 (37) | 17 | 38 | 58 | 0% | 2.1 | 13 (6) | 66 (29) | 0 (2) | 60 (21) | 48 (16) |
| Mine | Support | 4 | 22 (4) | 22 | 0 | 42 | 0% | 2.5 | 0 (1) | 38 (3) | - | 22 (4) | - |
| Mine | War machine | 52 | 30 (52) | 30 | 0 | 49 | 2% | 1.1 | 26 (13) | 34 (36) | 0 (3) | 22 (13) | 33 (39) |
| Mine | Wizard | 17 | 26 (17) | 26 | 0 | 45 | 12% | 2.2 | 76 (4) | 26 (6) | 0 (1) | 34 (8) | 57 (3) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 68 | 38 (68) | 12 | 26 | 59 | 44% | 2.8 | 70 (29) | 13 (11) | 23 (28) | 36 (48) | 42 (20) |
| Opponent | Character | 102 | 59 (102) | 58 | 1 | 23 | 23% | 2.2 | 45 (36) | 75 (53) | 24 (6) | 63 (55) | 59 (40) |
| Opponent | Clean-up | 11 | 56 (11) | 15 | 41 | 22 | 18% | 3.4 | 28 (4) | 73 (6) | 56 (1) | 31 (6) | 80 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 60 | 50 (60) | 24 | 26 | 47 | 28% | 2.8 | 54 (30) | 53 (20) | 27 (10) | 60 (28) | 39 (32) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 67 | 0% | 2.3 | - | 0 (2) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Hammer | 50 | 39 (50) | 33 | 6 | 51 | 24% | 2.7 | 26 (17) | 42 (30) | 60 (3) | 47 (30) | 26 (20) |
| Opponent | Holder | 40 | 45 (40) | 5 | 40 | 39 | 30% | 3.0 | 39 (9) | 65 (19) | 18 (9) | 60 (27) | 23 (10) |
| Opponent | Shooter | 27 | 48 (27) | 27 | 21 | 33 | 7% | 1.3 | 84 (6) | 33 (19) | 87 (2) | 62 (16) | 28 (11) |
| Opponent | Support | 4 | 67 (4) | 67 | 0 | 0 | 75% | 3.0 | 0 (1) | 0 (2) | 203 (1) | 0 (1) | 81 (3) |
| Opponent | War machine | 17 | 76 (17) | 76 | 0 | 27 | 0% | 1.5 | 46 (3) | 60 (10) | 127 (4) | 28 (3) | 85 (14) |
| Opponent | Wizard | 32 | 12 (32) | 12 | 0 | 27 | 12% | 2.2 | 16 (14) | 7 (8) | 26 (3) | 21 (16) | 0 (9) |

### Charged fights: co-opp-a57fba0-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 44 | 56 | 1.2 | 1.2 | 44 | 6 | +38 | 0 of 5 | 4 of 5 | +162 | +8 |
| Mine | Chaos Dwarfs | 4 | 90 | 307 | 4.8 | 1.1 | 65 | 47 | +18 | 7 of 19 | 12 of 19 | +0 | +19 |
| Mine | Dwarfen Mountain Holds | 3 | 467 | 0 | 2.0 | 1.2 | 0 | 10 | -10 | 1 of 6 | 2 of 6 | +0 | -12 |
| Mine | Empire of Man | 5 | 308 | 222 | 1.2 | 1.2 | 185 | 0 | +185 | 0 of 6 | 6 of 6 | +663 | +89 |
| Mine | Grand Cathay | 5 | 239 | 458 | 4.0 | 1.0 | 115 | 20 | +94 | 8 of 20 | 17 of 20 | - | +94 |
| Mine | High Elf Realms | 4 | 245 | 335 | 3.8 | 1.2 | 89 | 25 | +64 | 8 of 15 | 11 of 15 | +219 | +26 |
| Mine | Kingdom of Bretonnia | 1 | 19 | 0 | 2.0 | 1.0 | 0 | 191 | -191 | 0 of 2 | 0 of 2 | - | -191 |
| Mine | Lizardmen | 1 | 170 | 144 | 3.0 | 1.7 | 48 | 0 | +48 | 1 of 3 | 2 of 3 | +144 | +0 |
| Mine | Ogre Kingdoms | 1 | 549 | 484 | 5.0 | 1.2 | 97 | 55 | +42 | 0 of 5 | 3 of 5 | +170 | +10 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 446 | 5.0 | 1.2 | 89 | 11 | +78 | 1 of 5 | 4 of 5 | +82 | +77 |
| Mine | Skaven | 1 | 0 | 19 | 1.0 | 2.0 | 19 | 0 | +19 | 0 of 1 | 1 of 1 | +19 | - |
| Mine | Tomb Kings of Khemri | 2 | 0 | 863 | 8.5 | 1.1 | 102 | 20 | +81 | 6 of 17 | 9 of 17 | +250 | +71 |
| Mine | Vampire Counts | 2 | 122 | 566 | 3.5 | 1.1 | 162 | 9 | +153 | 2 of 7 | 5 of 7 | +0 | +179 |
| Mine | Warriors of Chaos | 2 | 0 | 412 | 4.0 | 1.0 | 103 | 14 | +88 | 3 of 8 | 7 of 8 | - | +88 |
| **Mine** | all armies | 36 | 184 | 305 | 3.3 | 1.1 | 92 | 25 | +67 | 37 of 119 | 83 of 119 | +165 | +55 |
| Opponent | Empire of Man | 1 | 380 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| Opponent | Grand Cathay | 3 | 423 | 354 | 2.7 | 1.1 | 133 | 54 | +78 | 6 of 8 | 3 of 8 | +0 | +90 |
| Opponent | High Elf Realms | 3 | 382 | 213 | 2.3 | 1.1 | 91 | 69 | +22 | 3 of 7 | 6 of 7 | +0 | +26 |
| Opponent | Kingdom of Bretonnia | 2 | 334 | 680 | 2.5 | 1.0 | 272 | 0 | +272 | 4 of 5 | 3 of 5 | - | +272 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 571 | 4.0 | 1.2 | 143 | 26 | +117 | 2 of 4 | 3 of 4 | +0 | +156 |
| Opponent | Skaven | 1 | 235 | 186 | 2.0 | 1.5 | 93 | 50 | +43 | 1 of 2 | 1 of 2 | -100 | +186 |
| Opponent | Tomb Kings of Khemri | 4 | 72 | 726 | 4.0 | 1.1 | 182 | 37 | +145 | 8 of 16 | 10 of 16 | +95 | +148 |
| Opponent | Vampire Counts | 6 | 70 | 673 | 4.0 | 1.2 | 168 | 2 | +166 | 10 of 24 | 18 of 24 | +177 | +164 |
| Opponent | Warriors of Chaos | 9 | 0 | 550 | 3.6 | 1.1 | 155 | 31 | +124 | 15 of 32 | 21 of 32 | +330 | +102 |
| Opponent | Wood Elf Realms | 6 | 75 | 220 | 2.8 | 1.2 | 78 | 41 | +37 | 3 of 17 | 11 of 17 | +73 | +29 |
| **Opponent** | all armies | 36 | 135 | 473 | 3.2 | 1.1 | 147 | 30 | +117 | 53 of 116 | 77 of 116 | +127 | +116 |

### Effective charges: co-opp-a57fba0-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 1 (net -30) | 0 | 1 (net +60) | 2 (net +81) | 0 | 0 | 1 | 25% (1 of 4) |
| Mine | Chaos Dwarfs | 19 | 2 (net -32) | 0 | 3 (net -30) | 8 (net -2) | 0 | 4 (net +111) | 2 | 18% (3 of 17) |
| Mine | Dwarfen Mountain Holds | 6 | 2 (net +0) | 0 | 0 | 3 (net -20) | 0 | 1 (net +0) | 0 | 0% (0 of 6) |
| Mine | Empire of Man | 6 | 0 | 0 | 1 (net +125) | 0 | 2 (net +368) | 3 (net +83) | 0 | 17% (1 of 6) |
| Mine | Grand Cathay | 20 | 1 (net -205) | 4 (net +150) | 3 (net +98) | 1 (net +70) | 2 (net +64) | 8 (net +103) | 1 | 16% (3 of 19) |
| Mine | High Elf Realms | 15 | 1 (net -175) | 0 | 2 (net +0) | 3 (net -14) | 4 (net +164) | 3 (net +109) | 2 | 15% (2 of 13) |
| Mine | Kingdom of Bretonnia | 2 | 1 (net -275) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Mine | Lizardmen | 3 | 1 (net +0) | 0 | 0 | 1 (net +0) | 1 (net +144) | 0 | 0 | 0% (0 of 3) |
| Mine | Ogre Kingdoms | 5 | 1 (net -40) | 0 | 2 (net -32) | 0 | 0 | 2 (net +157) | 0 | 40% (2 of 5) |
| Mine | Orc & Goblin Tribes | 5 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +82) | 3 | 0% (0 of 2) |
| Mine | Skaven | 1 | 0 | 0 | 0 | 1 (net +19) | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 17 | 2 (net +19) | 0 | 5 (net +70) | 7 (net +122) | 0 | 3 (net +47) | 0 | 29% (5 of 17) |
| Mine | Vampire Counts | 7 | 0 | 1 (net -60) | 2 (net +0) | 0 | 0 | 4 (net +283) | 0 | 29% (2 of 7) |
| Mine | Warriors of Chaos | 8 | 1 (net +28) | 0 | 1 (net +0) | 1 (net +109) | 0 | 2 (net +203) | 3 | 20% (1 of 5) |
| Opponent | Grand Cathay | 8 | 2 (net -217) | 1 (net +0) | 2 (net +0) | 3 (net +354) | 0 | 0 | 0 | 25% (2 of 8) |
| Opponent | High Elf Realms | 7 | 1 (net +0) | 0 | 2 (net -181) | 0 | 1 (net +0) | 1 (net +0) | 2 | 40% (2 of 5) |
| Opponent | Kingdom of Bretonnia | 5 | 2 (net +59) | 0 | 1 (net +690) | 1 (net +173) | 0 | 1 (net +379) | 0 | 20% (1 of 5) |
| Opponent | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 0 | 0 | 2 (net +198) | 2 | 0% (0 of 2) |
| Opponent | Skaven | 2 | 0 | 0 | 0 | 2 (net +43) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 16 | 5 (net +152) | 0 | 2 (net +250) | 2 (net +0) | 4 (net +120) | 3 (net +193) | 0 | 12% (2 of 16) |
| Opponent | Vampire Counts | 24 | 10 (net +269) | 0 | 3 (net +126) | 5 (net +71) | 2 (net +81) | 4 (net +101) | 0 | 12% (3 of 24) |
| Opponent | Warriors of Chaos | 32 | 10 (net +93) | 0 | 5 (net +172) | 2 (net +118) | 1 (net +60) | 12 (net +138) | 2 | 17% (5 of 30) |
| Opponent | Wood Elf Realms | 17 | 4 (net -96) | 0 | 1 (net +0) | 4 (net +95) | 1 (net +60) | 2 (net +132) | 5 | 8% (1 of 12) |

### Charged fights, damage counted: co-opp-a57fba0-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 14 | 178 | 214 | -52 | 51 | 93 | -42 | -23.7 |
| Mine | 50-54% | 5 | 253 | 264 | +108 | 170 | 108 | +62 | +24.3 |
| Mine | Effective (55-75%) | 20 | 276 | 278 | +34 | 73 | 33 | +40 | +14.5 |
| Mine | 76-89% | 27 | 258 | 187 | +41 | 105 | 47 | +58 | +22.5 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 31 | 265 | 176 | +127 | 144 | 9 | +134 | +50.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 539 | 115 | +185 | 204 | 27 | +176 | +32.7 |
| Mine | No odds | 13 | 291 | 133 | +61 | 95 | 35 | +59 | +20.3 |
| Mine | All fights | 119 | 278 | 194 | +67 | 112 | 40 | +72 | +26.0 |
| Opponent | Long shot (under 50%) | 34 | 209 | 253 | +108 | 184 | 92 | +92 | +44.1 |
| Opponent | 50-54% | 1 | 369 | 91 | +0 | 4 | 184 | -180 | -48.8 |
| Opponent | Effective (55-75%) | 16 | 313 | 266 | +129 | 184 | 62 | +122 | +39.0 |
| Opponent | 76-89% | 19 | 314 | 225 | +121 | 144 | 36 | +108 | +34.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 25 | 375 | 236 | +147 | 194 | 43 | +151 | +40.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 436 | 101 | +85 | 101 | 18 | +83 | +19.1 |
| Opponent | No odds | 12 | 172 | 168 | +92 | 147 | 27 | +120 | +69.5 |
| Opponent | All fights | 116 | 292 | 225 | +117 | 168 | 56 | +111 | +38.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| co-opp-a57fba0-p3 | move | 403 | 81 (20%) | 60 (15%) | 59 (15%) | 263 (65%) |
| co-opp-a57fba0-p3 | objective | 441 | 63 (14%) | 45 (10%) | 61 (14%) | 317 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

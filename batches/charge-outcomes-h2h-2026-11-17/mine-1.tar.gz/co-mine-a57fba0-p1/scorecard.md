# Doctrine scorecard: co-mine-a57fba0-p1

### Scorecard: co-mine-a57fba0-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 12 | 3 | 1 | 1 | 0 | 0 | 0 | 77 |
| L0102 | 6 | 1 | Opponent | no | 7 | 1 | 4 | 4 | 0 | 0 | 0 | 170 |
| L0118 | 4 | 1 | Mine | no | 5 | 5 | 1 | 1 | 1 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 0 | 3 | 4 | 3 | 1 | 0 | 0 | 516 |
| L0135 | 3 | 1 | Mine | no | 3 | 4 | 2 | 2 | 0 | 0 | 0 | 442 |
| L0135 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 3 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Opponent | - | - | 6 | 0 | 3 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 1 | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Opponent | no | 0 | 4 | 1 | 3 | 0 | 0 | 0 | 250 |
| L0319 | 1 | 1 | Mine | no | 7 | 3 | 2 | 0 | 1 | 0 | 0 | 675 |
| L0319 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 255 |
| L0405 | 3 | 1 | Mine | yes | 5 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 2 | - | 2 | 1 | 0 | 0 | 0 | 1193 |
| L0421 | 1 | 1 | Mine | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 0 | 3 | 1 | 0 | 0 | 420 |
| L0508 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 548 |
| L0508 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 769 |
| L0524 | 2 | 1 | Mine | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 548 |
| L0524 | 2 | 1 | Opponent | - | - | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 0 | - | 2 | 2 | 0 | 0 | 0 | 743 |
| L0612 | 6 | 1 | Opponent | no | 3 | 3 | 1 | 0 | 1 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | 4 | 2 | 2 | 0 | 0 | 0 | 981 |
| L0628 | 4 | 1 | Opponent | no | 1 | 3 | 2 | 0 | 0 | 0 | 0 | 238 |
| L0717 | 3 | 1 | Mine | no | 9 | 2 | 5 | 0 | 0 | 0 | 0 | 420 |
| L0717 | 3 | 1 | Opponent | yes | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 322 |
| L0733 | 1 | 1 | Mine | no | 6 | 1 | 3 | 1 | 1 | 0 | 0 | 250 |
| L0733 | 1 | 1 | Opponent | no | 0 | 4 | 0 | 4 | 0 | 0 | 0 | 144 |
| L0823 | 1 | 1 | Mine | no | 2 | 4 | 1 | 1 | 0 | 0 | 0 | 679 |
| L0823 | 1 | 1 | Opponent | no | 2 | 2 | 5 | 1 | 1 | 0 | 0 | 315 |
| L0913 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 524 |
| L0913 | 1 | 1 | Opponent | no | 2 | 2 | 5 | 1 | 0 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 2 | 6 | 1 | 1 | 0 | 0 | 0 | 733 |
| L0930 | 6 | 1 | Opponent | no | 2 | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 1 | - | 0 | 5 | 0 | 0 | 0 | 355 |
| L1114 | 4 | 1 | Mine | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 427 |
| L1114 | 4 | 1 | Opponent | no | 0 | 4 | 1 | 3 | 0 | 0 | 0 | 500 |
| L1131 | 3 | 1 | Mine | no | 3 | - | 3 | 0 | 1 | 0 | 0 | 676 |
| L1131 | 3 | 1 | Opponent | no | 0 | 5 | 3 | 1 | 2 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 7 | 2 | 2 | 1 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 2 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | yes | - | 3 | 2 | 0 | 0 | 0 | 0 | 140 |
| L1319 | 5 | 1 | Opponent | no | - | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 6 | 2 | 3 | 0 | 1 | 0 | 0 | 317 |
| L1335 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 0 | 0 | 0 | 236 |
| L1431 | 3 | 1 | Mine | no | 4 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 2 | 3 | 1 | 0 | 2 | 0 | 0 | 340 |
| L1527 | 3 | 1 | Mine | yes | 14 | 6 | 1 | 1 | 2 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 0 | 3 | 6 | 2 | 1 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | yes | - | 2 | 2 | 2 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | yes | - | 2 | 6 | 2 | 1 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | no | 1 | 3 | 4 | 0 | 0 | 0 | 0 | 207 |
| L1723 | 1 | 1 | Opponent | yes | 10 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | yes | - | - | 4 | 1 | 2 | 0 | 0 | 234 |
| L1823 | 5 | 1 | Opponent | yes | - | 1 | 3 | 1 | 2 | 0 | 0 | 72 |
| L1923 | 3 | 1 | Mine | no | 2 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | no | 0 | 2 | 1 | 1 | 1 | 0 | 0 | 66 |
| L2025 | 3 | 1 | Mine | yes | 4 | - | 1 | 2 | 2 | 0 | 0 | 860 |
| L2025 | 3 | 1 | Opponent | no | 9 | 2 | 6 | 2 | 0 | 0 | 0 | 211 |
| L2127 | 3 | 1 | Mine | no | 4 | - | 0 | 4 | 0 | 0 | 0 | 355 |
| L2127 | 3 | 1 | Opponent | no | 7 | 2 | 9 | 3 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 1 | 4 | 4 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | no | - | - | 1 | 0 | 1 | 0 | 0 | 801 |
| L2335 | 1 | 1 | Mine | no | 1 | 2 | 2 | 1 | 1 | 0 | 0 | 245 |
| L2335 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | 4 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | no | - | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Mine | no | 1 | 1 | 5 | 2 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 3 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 1 | 4 | 3 | 2 | 0 | 0 | 0 | 170 |
| L2934 | 6 | 1 | Opponent | no | 0 | 1 | 4 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 24% | 3.4 | 2.8 | 2.3 | 1.3 | 0.3 | 0.0 | 0.0 | 308.6 |
| **Average** | | | Opponent | 12% | 1.8 | 2.5 | 2.8 | 1.8 | 0.4 | 0.0 | 0.0 | 217.0 |

### KPIs: co-mine-a57fba0-p1

Rules off - Opponent only: BREAK OUTCOMES, OVERRUN ON, STAND AND SHOOT, FLEES FROM CHARGE.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 26% (45 of 175) | 3% (5 of 174) | 14% (50 of 349) |
| Winner chose to follow up after the loser gave ground |  | 100% (44 of 44); on the table 100% | 98% (54 of 55); on the table 98% | 99% (98 of 99); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (7 of 7); on the table 100% | 79% (15 of 19); on the table 84% | 85% (22 of 26); on the table 88% |
| Winner chose to pursue after the loser fled |  | 78% (21 of 27); on the table 78% | 84% (36 of 43); on the table 84% | 81% (57 of 70); on the table 81% |
| Winner chose to follow up or pursue (all three) |  | 92% (72 of 78); on the table 92% | 90% (105 of 117); on the table 91% | 91% (177 of 195); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 29% (97 of 330) | 27% (56 of 210) | 28% (153 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 41% (97 of 239) | 37% (56 of 150) | 39% (153 of 389) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 62% (20 of 32) | 47% (26 of 55) | 53% (46 of 87) |
| Points that never fought | lower | 40% (28721 of 71484) | 42% (29969 of 71889) | 41% (58690 of 143373) |
|   infantry points that never fought | lower | 45% (7664 of 16863) | 59% (7925 of 13348) | 52% (15589 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (157 of 279) | 61% (180 of 295) | 59% (337 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 86% (19 of 22); 1.6 uses a game | 65% (13 of 20); 1.1 uses a game | 76% (32 of 42); 1.3 uses a game |
| Bound items with another spell used |  | 81% (13 of 16); 0.7 uses a game | 12% (1 of 8); 0.1 uses a game | 58% (14 of 24); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 53% (10 of 19); 0.3 uses a game | 50% (6 of 12); 0.2 uses a game | 52% (16 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 52% (31138 of 59666) | 57% (35714 of 62699) | 55% (66852 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.6 (39%) | 1.5 (36%) | 4.1 (38%) |
| MARCHED: its unit marched | 0.9 (13%) | 0.6 (14%) | 1.4 (13%) |
| CHARGED: its unit charged | 0.4 (7%) | 0.1 (1%) | 0.5 (5%) |
| IN COMBAT: engaged in combat | 1.2 (19%) | 0.6 (14%) | 1.8 (17%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.4 (10%) | 0.4 (4%) |
| FLEEING: fleeing | 0.2 (3%) | 0.0 (1%) | 0.2 (2%) |
| GONE: slain | 1.1 (16%) | 0.9 (21%) | 1.9 (18%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (1%) | 0.2 (4%) | 0.2 (2%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.2 | 1.3 | 1.4 | 4.2 | 0.6 | 2.0 |
| not cast | 3.8 | 3.0 | 3.2 | 10.8 | 1.8 | 22.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.4 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (44%) | 0.3 (9%) | 4.1 (38%) | 0.3 (19%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (13%) | 0.1 (6%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (5%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (5%) | 0.2 (6%) | 0.3 (9%) | 1.8 (17%) | 0.3 (16%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (1%) | 0.2 (6%) | 0.3 (9%) | 0.4 (4%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (2%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (4%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.4 (2%) |
| GONE: slain | 1.0 (26%) | 0.7 (22%) | 1.0 (30%) | 1.9 (18%) | 0.1 (8%) | 3.9 (18%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (4%) | 0.2 (7%) | 0.2 (5%) | 0.2 (2%) | 0.0 (0%) | 0.6 (3%) |
| STUPIDITY: Stupidity | 0.0 (1%) | 0.1 (2%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.2 (8%) | 0.0 (0%) | 0.0 (0%) | 0.8 (46%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.2 (58%) | 0.2 (6%) | 1.2 (36%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.4 (70%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.1 a game | 0.5 a game | 0.8 a game |
| stood (cast and not dispelled) | 64% (23 of 36) | 75% (12 of 16) | 67% (35 of 52) |
| the unit moved after it | 48% (11 of 23) | 75% (9 of 12) | 57% (20 of 35) |
| it charged on its next turn | 4% (1 of 23) | 0% (0 of 12) | 3% (1 of 35) |
| the enemy charged it first | 13% (3 of 23) | 0% (0 of 12) | 9% (3 of 35) |
| it fought by the end of its next turn | 13% (3 of 23) | 0% (0 of 12) | 9% (3 of 35) |
| it moved out of a charge the enemy had planned (not charged first) | 13% (3 of 23) | 0% (0 of 12) | 9% (3 of 35) |
| none of these (no charge, no fight, no charge escaped) | 74% (17 of 23) | 100% (12 of 12) | 83% (29 of 35) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (544 of 893) | 60% (363 of 600) | 61% (907 of 1493) |
|   cavalry | 55% (41 of 75) | 70% (86 of 123) | 64% (127 of 198) |
|   character | 54% (67 of 123) | 33% (36 of 110) | 44% (103 of 233) |
|   chariot | 49% (46 of 94) | 62% (25 of 40) | 53% (71 of 134) |
|   infantry | 50% (153 of 305) | 60% (144 of 239) | 55% (297 of 544) |
|   monster | 59% (23 of 39) | 45% (10 of 22) | 54% (33 of 61) |
|   war machine | 83% (214 of 257) | 94% (62 of 66) | 85% (276 of 323) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.4 (25%) | 1.6 (24%) | 4.0 (25%) |
| CHARGED: it charged | 0.9 (9%) | 1.4 (22%) | 2.3 (14%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.9 (10%) | 0.4 (7%) | 1.4 (9%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD FIRE: a target, but it held its fire | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 2.0 (20%) | 1.5 (23%) | 3.5 (22%) |
| ONLY IN COMBAT: the only targets were in combat | 1.1 (11%) | 0.6 (9%) | 1.7 (10%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.6 (17%) | 0.9 (14%) | 2.5 (15%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| OTHER BAR | 0.4 (4%) | 0.0 (0%) | 0.4 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.1 | 1.2 | 80% | 4.9 pts | 25 pts |
| character | 3.4 | 1.1 | 80% | 6.2 pts | 21 pts |
| chariot | 2.0 | 1.6 | 64% | 16.2 pts | 32 pts |
| infantry | 12.4 | 4.4 | 74% | 8.6 pts | 107 pts |
| monster | 1.2 | 0.2 | 88% | 3.0 pts | 3 pts |
| war machine | 7.7 | 4.8 | 67% | 21.7 pts | 166 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.8 | 5.6 | 4.7 |
| Charges that made contact a game | 2.8 | 3.8 | 3.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.80 declared, 0.65 contact (20 units) | 0.29 declared, 0.29 contact (14 units) | 0.59 declared, 0.50 contact (34 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.17 declared, 1.00 contact (6 units) | 1.78 declared, 1.22 contact (9 units) | 1.53 declared, 1.13 contact (15 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.47 declared, 0.34 contact (247 units) | 0.65 declared, 0.43 contact (277 units) | 0.56 declared, 0.39 contact (524 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 53% (37 of 70) | 52% (11 of 21) | 38% (3 of 8) | 52% (51 of 99) |
| Character in a unit | 89% (31 of 35) | 64% (14 of 22) | 75% (3 of 4) | 79% (48 of 61) |
| Character on its own | 81% (42 of 52) | 53% (20 of 38) | 40% (25 of 62) | 57% (87 of 152) |
| Chariot | 50% (8 of 16) | 50% (5 of 10) | - | 50% (13 of 26) |
| Infantry | 61% (54 of 89) | 39% (14 of 36) | 50% (1 of 2) | 54% (69 of 127) |
| Monster | 56% (18 of 32) | 70% (7 of 10) | - | 60% (25 of 42) |
| Monstrous | 45% (5 of 11) | 79% (11 of 14) | - | 64% (16 of 25) |
| War Machines | 66% (27 of 41) | 100% (1 of 1) | - | 67% (28 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 83% (15 of 18); on the table 83% | 21% (29 of 138) | 42% | 58% (19 of 33) | 78% (7 of 9); 2.8 uses a game | 100% (3 of 3); 1.2 uses a game | 89% (8 of 9); 1.3 uses a game |
| Chaos Dwarfs | 3 | 100% (7 of 7); on the table 100% | 42% (10 of 24) | 26% | 33% (8 of 24) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Dwarfen Mountain Holds | 5 | 100% (13 of 13); on the table 100% | - | 54% | 66% (27 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 100% (8 of 8); on the table 100% | 39% (14 of 36) | 51% | 56% (36 of 64) | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 5 | 100% (11 of 11); on the table 100% | 30% (32 of 108) | 48% | 41% (18 of 44) | 92% (11 of 12); 7.2 uses a game | 0% (0 of 1); 0.0 uses a game | 60% (3 of 5); 0.6 uses a game |
| High Elf Realms | 6 | 92% (12 of 13); on the table 92% | 23% (7 of 30) | 45% | 63% (31 of 49) | 100% (5 of 5); 3.3 uses a game | 50% (9 of 18); 2.5 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (3 of 3); on the table 100% | - | 40% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 83% (5 of 6); on the table 83% | - | 32% | 57% (8 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 80% (4 of 5); on the table 80% | 8% (1 of 12) | 68% | 76% (16 of 21) | 0% (0 of 3); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (6 of 6); on the table 100% | 6% (2 of 36) | 16% | 75% (18 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 4 | 88% (7 of 8); on the table 100% | 37% (11 of 30) | 35% | 65% (22 of 34) | 100% (3 of 3); 1.0 uses a game | 0.0 uses a game | 0% (0 of 4); 0.0 uses a game |
| Tomb Kings of Khemri | 6 | 79% (19 of 24); on the table 79% | 17% (2 of 12) | 32% | 50% (15 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 93% (26 of 28); on the table 93% | 44% (24 of 54) | 41% | 58% (29 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 87% (20 of 23); on the table 87% | 33% (10 of 30) | 35% | 68% (50 of 74) | 100% (4 of 4); 1.4 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 95% (21 of 22); on the table 95% | 37% (11 of 30) | 40% | 55% (36 of 66) | 33% (2 of 6); 1.5 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (co-mine-a57fba0-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 38% (26) | 47% (29) | 42% (55) |
| ...free all their last turn and able to turn (per game) | 0.42 | 0.61 | 1.03 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.11 | 0.06 | 0.17 |
| ...with the charger already in that arc before they moved (per game) | 0.25 | 0.50 | 0.75 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.83 | 0.81 | 2.64 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.89 | 0.78 | 1.67 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.00 | 4.58 | 9.58 |

### Quality by phase: co-mine-a57fba0-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 52% (59 of 113) | 41% (66 of 162) |
| Strategy | Shoot objectives carried out (shot that target) | 44% (182 of 415) | 58% (131 of 224) |
| Strategy | Close-in objectives charged next turn | 11% (18 of 166) | 17% (41 of 236) |
| Strategy | Support requests answered (helper made contact too) | 46% (6 of 13) | 48% (13 of 27) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 100% (5 of 5) |
| Strategy | Hexes on a unit its side charged or shot that turn | 62% (8 of 13) | 58% (7 of 12) |
| Strategy | Joined characters whose unit fought | 31% (17 of 54) | 38% (16 of 42) |
| Strategy | Lone characters that fought | 72% (66 of 92) | 69% (65 of 94) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 1.3 | 1.8 |
| Movement | Points that never moved of their own | 308.6 | 217.0 |
| Movement | Fights charged into per game | 2.5 | 3.1 |
| Movement | Charges with odds: long shots (under 50%) | 11 of 71, net +76 | 11 of 93, net +106 |
| Movement | Charges with odds: sweet spot (55-75%) | 5 of 71, net +157 | 27 of 93, net +149 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 12 of 71, net +98 | 4 of 93, net +61 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 16 of 71, net +138 | 26 of 93, net +179 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.1 | 9.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (161 of 362) | 41% (139 of 342) |
| Shooting | Points destroyed by shooting units | 83.9 | 30.4 |
| Shooting | War machine shots | 5.9 | 1.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 49% (105 of 214) | 35% (22 of 62) |
| Shooting | Points destroyed by war machines | 91.1 | 21.9 |
| Magic | Magic missiles cast | 1.7 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 30% (18 of 60) | 30% (10 of 33) |
| Magic | Wounds caused by magic missiles | 4.4 | 1.2 |
| Magic | Wounds caused by other spells | 1.4 | 0.4 |
| Magic | Points destroyed by magic (all spells) | 98.2 | 29.4 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.6 / 0.4 / 0.9 / 0.2 | 1.5 / 0.5 / 0.4 / 0.1 |
| Combat | Points destroyed in combat | 311.8 | 391.8 |
| Combat | Points run down | 93.2 | 212.8 |
| Combat | Net points per charged fight, damage counted | +99 | +121 |
| Combat | Net per 100 charger points, damage counted | +33.7 | +43.3 |
| Combat | First round won (charged fights) | 74% | 80% |
| Combat | Net points per charged fight | +100 | +131 |
| Combat | Net points per supported fight / lone fight | +151 / +93 | +250 / +108 |
| Combat | Charged fights on a top-3 enemy unit | 30 of 90 | 55 of 111 |
| Game | Points lost | 738.8 | 756.4 |
| Game | VP from objectives | 646.7 | 630.8 |
| Game | Lone holders (player turns) | 3.4 | 1.8 |

- Mine won / drew / lost: 13 / 9 / 14 of 36 ended games (of 36); mean margin (Mine - Opponent) -7 VP
- The side that went first won 10 of 27 games with a winner
- Points traded per game (both sides' losses): 1495
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: co-mine-a57fba0-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 5.2 | -174.2 | 241.6 | 132.9 | 4.6 | -156.6 | 146.6 | 56.7 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 3.6 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.1 | +0.0 | 0.0 | 19.7 | 0.3 | +0.0 | 0.0 | 2.6 |
| BACKUP TARGETS | 0.3 | +0.8 | 0.0 | 13.1 | 0.6 | +3.2 | 0.0 | 18.5 |
| BEST FACING | 0.4 | +6.9 | 0.0 | 8.3 | 0.1 | +2.7 | 0.0 | 13.7 |
| BEST FIRST | 1.2 | +51.4 | 38.2 | 31.1 | 0.9 | +40.4 | 13.4 | 27.2 |
| BEST OVERALL | 0.3 | +14.0 | 0.0 | 6.5 | 0.2 | +11.6 | 0.0 | 0.0 |
| BEST PREY | 0.5 | +20.8 | 18.6 | 15.3 | 0.5 | +24.7 | 14.1 | 7.9 |
| BEST PRIZE | 0.2 | -7.0 | 13.4 | 12.9 | 0.1 | -4.6 | 2.9 | 0.0 |
| BIG CHARACTER SAFETY | 0.1 | -0.3 | 0.0 | 15.0 | 0.2 | -1.1 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 4.1 | 0.0 | 0.1 | +0.0 | 2.6 | 5.4 |
| BLOCKED WHEEL | 0.3 | +6.9 | 0.0 | 0.0 | 0.2 | +8.8 | 0.0 | 9.3 |
| BLOWS WHERE AIMED | 0.2 | -38.7 | 27.4 | 19.6 | 0.4 | -27.5 | 95.9 | 2.5 |
| BOMBING RUN | 0.0 | +1.3 | 4.2 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 4.2 | - | - | - | - |
| BREAK OUTCOMES | 2.2 | +20.1 | 234.0 | 80.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.8 | +0.0 | 122.2 | 9.2 | 0.2 | +0.0 | 25.9 | 3.6 |
| CANNON PLANNED TARGET | 4.8 | +178.0 | 461.4 | 103.9 | 1.4 | +21.3 | 48.0 | 19.3 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 12.8 | 0.0 | 0.1 | +0.0 | 3.3 | 3.5 |
| CAST JOB | 0.9 | +29.3 | 63.8 | 38.5 | 0.6 | +25.5 | 26.4 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +32.1 | 34.6 | 10.9 | 0.2 | +7.7 | 1.5 | 4.4 |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 32.1 | 0.3 | +0.0 | 0.0 | 18.7 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.0 | +51.9 | 0.0 | 27.4 | 1.5 | +77.8 | 0.0 | 41.3 |
| CHAFF PASSED | 0.2 | -0.2 | 0.0 | 8.3 | 0.1 | -0.1 | 0.0 | 8.6 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 201.4 | 68.9 | 2.9 | +0.0 | 332.4 | 87.7 |
| CHARGE NOW WEIGHED | 0.3 | -21.1 | 26.7 | 16.9 | 0.4 | -23.2 | 4.7 | 22.8 |
| CHARGER SLAIN LOST | 0.3 | -12.6 | 22.5 | 19.8 | 0.6 | -17.4 | 49.6 | 19.4 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 1.1 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -6.5 | 0.0 | 0.0 | 0.0 | -1.0 | 0.0 | 0.0 |
| CHEAP HELPER | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 6.4 | 2.5 |
| COMBAT PIVOT | 0.4 | +0.0 | 39.8 | 1.9 | 0.4 | +0.0 | 23.7 | 10.1 |
| CONVEYANCE SEARCH | 0.6 | +46.0 | 0.0 | 24.7 | 0.3 | +104.3 | 3.2 | 15.2 |
| COVER ONCE | 7.5 | -609.6 | 0.0 | 192.1 | 5.4 | -336.7 | 0.0 | 121.9 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 36.0 | 5.2 | - | - | - | - |
| DEFENSIVE FLOOR | - | - | - | - | 0.1 | +2.5 | 14.2 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.1 | +2.6 | 13.2 | 0.9 |
| ELIXIR WORTH | 0.0 | +0.3 | 0.0 | 8.2 | 0.1 | +2.3 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.8 | +91.4 | 0.0 | 47.3 | 0.8 | +47.0 | 0.0 | 27.6 |
| FALLBACK BY WORTH | 3.6 | +39.3 | 0.0 | 65.4 | 5.5 | +60.1 | 0.0 | 72.0 |
| FIGHT LIFT | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| FIRE AND FLEE | 0.0 | +0.5 | 2.5 | 2.4 | 0.1 | +1.0 | 0.0 | 3.2 |
| FLANK NOT WEIGHED | 4.9 | +0.0 | 0.0 | 127.4 | 4.0 | +0.0 | 0.0 | 71.3 |
| FLEES FROM CHARGE | 0.4 | +14.3 | 28.4 | 14.4 | - | - | - | - |
| FOCUS FIRE | 0.1 | +3.3 | 3.5 | 0.0 | 0.0 | +0.8 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 1.0 | +139.6 | 0.0 | 44.7 | 1.0 | +141.6 | 0.0 | 53.7 |
| FRIENDS SHOTS CHECKED | 0.1 | +16.0 | 0.0 | 0.0 | 0.2 | +13.3 | 0.0 | 11.5 |
| GIVES UP | 0.1 | -2.1 | 0.0 | 4.0 | 0.2 | -1.6 | 11.5 | 22.0 |
| GIVES UP ITS SCREEN | 0.0 | -0.1 | 3.1 | 0.0 | - | - | - | - |
| GROUND FLIERS | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 3.2 | 0.0 | 0.1 | +0.0 | 11.7 | 1.9 |
| HELPER UNSEEN | 0.1 | +0.0 | 18.0 | 0.0 | 0.5 | +0.0 | 26.3 | 26.0 |
| HILL BY ITS CHANCE | - | - | - | - | 0.2 | -16.0 | 0.0 | 2.2 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 6.9 | -116.8 | 462.9 | 164.7 | 10.0 | -191.7 | 577.3 | 206.1 |
| HORN WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.0 | +0.2 | 0.0 | 0.0 | 0.1 | +5.1 | 3.5 | 2.9 |
| HUNT DROPPED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.3 | +17.7 | 0.0 | 5.4 | 0.6 | +39.3 | 0.0 | 6.0 |
| HUNT KEPT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| HUNT RESULT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +8.3 | 3.5 | 1.9 |
| HUNT THE GUNS | 0.0 | +12.5 | 0.0 | 0.0 | 0.1 | +40.6 | 3.5 | 2.9 |
| IDLE COST | 15.3 | -255.6 | 0.0 | 224.7 | 18.1 | -280.6 | 0.0 | 205.5 |
| INVITES THE FIGHT | 1.4 | +12.9 | 79.8 | 35.8 | 1.0 | +4.7 | 38.4 | 15.2 |
| JOINT CHARGE PLAN | 0.3 | +15.0 | 3.1 | 23.1 | 0.3 | +15.7 | 0.0 | 6.0 |
| JOINT KNOWS CHALLENGE | 0.0 | -0.2 | 0.0 | 0.0 | 0.1 | -4.3 | 23.4 | 0.0 |
| KEEP FALLS | 0.0 | +0.2 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 6.9 |
| KEEPS ITS TARGET | 1.3 | +39.2 | 131.5 | 39.7 | 2.2 | +65.8 | 187.5 | 45.1 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | - | - | - | - | 2.1 | +126.9 | 208.5 | 50.4 |
| KILLS COUNT NEXT TURN | 4.5 | +146.3 | 231.2 | 116.3 | 6.9 | +239.8 | 257.7 | 147.9 |
| LONE CHARACTER SAFE SPOT | 0.4 | +11.8 | 51.8 | 18.8 | 0.4 | +10.8 | 0.0 | 5.0 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.7 | +49.1 | 0.0 | 0.0 | 0.2 | +24.5 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | -1.9 | 29.4 | 8.0 | 0.7 | +1.2 | 45.9 | 16.2 |
| LOST CHARGE | 2.8 | -40.0 | 125.6 | 113.5 | 2.9 | -44.2 | 61.0 | 98.2 |
| LURE BY WHAT IT DRAWS | 0.2 | -16.8 | 0.0 | 5.1 | 0.2 | -13.9 | 0.0 | 15.9 |
| MAKE SURE TOGETHER | 0.6 | +20.2 | 17.4 | 25.1 | 1.3 | +88.7 | 14.3 | 48.3 |
| MANOEUVRE | 0.2 | +0.9 | 0.0 | 0.0 | 0.2 | +1.4 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.0 | +0.4 | 0.0 | 0.0 | 0.1 | +2.4 | 0.0 | 0.0 |
| MARCH CHECK | 0.5 | +10.4 | 0.0 | 13.2 | 0.3 | +18.2 | 0.0 | 3.2 |
| MARCH ODDS | 0.1 | +9.4 | 15.2 | 0.0 | 0.1 | +13.5 | 11.5 | 0.0 |
| MARCH OVER CASTS | 0.6 | +40.7 | 0.0 | 25.6 | 0.3 | +26.4 | 0.0 | 13.1 |
| MAX FOR POSITIONING | 4.9 | +75.0 | 0.0 | 126.2 | 6.6 | +90.8 | 0.0 | 163.3 |
| MISSILES IN THE MOVE | 4.1 | +141.2 | 0.0 | 62.7 | 3.4 | +61.4 | 0.0 | 64.6 |
| MISSILES NEXT TURN | 4.9 | +102.9 | 0.0 | 125.7 | 3.9 | +41.9 | 0.0 | 88.8 |
| MODEL FACING | 0.4 | +117.4 | 0.0 | 3.3 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 22.1 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.4 | +15.2 | 0.0 | 2.2 | 0.3 | +19.7 | 0.0 | 11.1 |
| MOVE SPELL IN RANGE | 0.2 | +7.4 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.4 | -73.9 | 0.0 | 26.9 | 0.1 | -0.2 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 11.1 |
| MOVE TO CHARGE | 3.3 | +270.6 | 166.4 | 106.6 | 5.4 | +316.6 | 188.2 | 137.1 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.1 | +9.8 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 3.1 |
| NOT NEEDED | 0.3 | -7.7 | 32.3 | 6.2 | 0.2 | -11.7 | 55.2 | 1.9 |
| NOT TURNED | 5.0 | +103.7 | 0.0 | 128.3 | 4.6 | +28.1 | 0.0 | 75.3 |
| NOT WORTH A CAST | 0.9 | -0.6 | 0.0 | 59.4 | 0.4 | -0.4 | 0.0 | 0.0 |
| OFF BEST | 16.3 | -681.2 | 0.0 | 292.6 | 16.5 | -752.8 | 24.7 | 232.1 |
| ONE FIGHT FORMULA | 7.6 | -128.8 | 62.4 | 222.8 | 8.2 | -158.1 | 21.8 | 218.8 |
| ONE OBJECTIVE FORMULA | 2.5 | -80.4 | 0.0 | 36.7 | 2.1 | -28.9 | 0.0 | 43.1 |
| OPENS UP | 0.3 | +17.8 | 12.9 | 12.9 | 0.2 | +13.0 | 9.6 | 17.6 |
| OVERRUN ON | 0.2 | +9.1 | 14.8 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.3 | +2.1 | 17.9 | 13.2 | 0.4 | +8.5 | 30.4 | 12.8 |
| PATHS CROSS | 2.0 | +141.2 | 0.0 | 51.5 | 2.8 | +196.3 | 0.0 | 54.3 |
| PIVOT GUARDS FLANK | 0.1 | -2.1 | 0.0 | 0.0 | 0.2 | -4.2 | 0.0 | 7.9 |
| PLAN RESULT | 37.2 | +1566.4 | 1434.1 | 934.1 | 38.0 | +1110.1 | 1406.7 | 915.7 |
| PURSUES BIG PREY | 0.1 | -4.3 | 0.0 | 0.0 | 0.1 | -5.6 | 0.0 | 0.0 |
| PURSUES ON | - | - | - | - | 0.0 | +0.5 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +3.3 | 0.0 | 0.0 | 0.1 | +3.3 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.9 | +12.0 | 0.0 | 22.6 | 1.5 | +36.2 | 0.0 | 29.2 |
| RANDOM MOVER NO PROMISE | 0.1 | -11.0 | 1.1 | 0.0 | 0.4 | -15.1 | 5.6 | 4.7 |
| REDIRECT BY WHAT IT STOPS | 0.6 | -11.3 | 0.0 | 18.2 | 1.1 | -41.3 | 0.0 | 22.9 |
| REDIRECT COUNTER | 1.6 | +82.4 | 0.0 | 43.7 | 3.3 | +275.1 | 0.0 | 76.7 |
| REDIRECT WEIGHED | 0.4 | -2.0 | 16.9 | 16.7 | 0.3 | +4.6 | 7.8 | 10.7 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 6.2 |
| RESERVE FALL BACK | 0.5 | +10.8 | 0.0 | 4.6 | 0.8 | +20.6 | 0.0 | 17.2 |
| RESTRAINS TO SHOOT | 0.1 | +1.8 | 0.0 | 6.5 | 0.1 | +2.0 | 0.0 | 0.0 |
| RISK BY ARC | 1.6 | +65.2 | 144.5 | 80.0 | 2.5 | +55.4 | 233.8 | 95.8 |
| RISK ONCE | 2.4 | +31.6 | 13.4 | 81.2 | 5.5 | +352.4 | 36.2 | 219.6 |
| SAFE SURE CHARGE | 0.1 | -0.8 | 3.2 | 0.0 | - | - | - | - |
| SAFER THAN THE JOB | 0.9 | +45.3 | 0.0 | 8.9 | 0.8 | +44.5 | 0.0 | 28.0 |
| SCOUT SPOT | 0.4 | +0.7 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.9 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.9 |
| SCREEN BY WHAT IT SAVES | 0.1 | -7.4 | 0.0 | 3.2 | 0.4 | -13.8 | 0.0 | 2.5 |
| SEARCH SPOT | 1.6 | +57.6 | 0.0 | 38.1 | 2.3 | +101.9 | 0.0 | 59.9 |
| SELF MOVE SPELL | 0.2 | +19.4 | 0.0 | 40.1 | 0.2 | -0.2 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.2 | +135.4 | 28.3 | 42.9 | 2.4 | +162.8 | 16.7 | 63.4 |
| SET-UP ANY TARGET | 0.2 | +27.9 | 0.0 | 0.0 | 0.1 | +13.9 | 3.2 | 7.6 |
| SET-UP MISSED | 0.0 | +2.6 | 0.0 | 0.0 | 0.0 | +3.9 | 3.5 | 7.6 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.1 | -0.6 | 0.0 | 1.7 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.1 | +81.7 | 121.2 | 3.9 | 1.0 | +26.4 | 47.6 | 21.7 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.6 | +0.0 | 143.7 | 18.9 | 0.1 | +0.0 | 16.3 | 0.0 |
| SHOTS IN THE MOVE | 13.6 | +576.2 | 0.0 | 212.9 | 9.1 | +179.8 | 0.0 | 115.9 |
| SPELL SETS UP CHARGE | 0.3 | +43.8 | 0.0 | 0.0 | 0.2 | +65.4 | 3.2 | 7.6 |
| SPELL WORTH | 1.1 | +12.9 | 93.1 | 99.2 | 1.6 | +30.0 | 66.4 | 76.3 |
| SPELLS IN THE FIGHT | 0.2 | +2.9 | 28.2 | 15.1 | 0.7 | -13.5 | 72.4 | 26.9 |
| STABLE ROLE | 11.2 | +0.0 | 438.8 | 156.3 | 11.2 | +0.0 | 385.0 | 217.7 |
| STAND AND SHOOT | 0.3 | -5.4 | 27.0 | 13.5 | - | - | - | - |
| STANDS TO CAST | 0.0 | +1.0 | 0.0 | 10.9 | 0.1 | +1.8 | 0.0 | 0.0 |
| STAY WEIGHED | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| STOPS | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.3 | +20.0 | 0.0 | 11.1 | 0.5 | +14.4 | 0.0 | 3.2 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 4.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 4.6 | -51.3 | 303.7 | 74.6 | 7.3 | -53.7 | 446.2 | 110.3 |
| SUPPORTS | 3.3 | +53.1 | 180.8 | 43.9 | 4.8 | +55.8 | 227.6 | 76.7 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -4.1 | 11.0 | 0.0 | 0.1 | -3.3 | 17.9 | 0.0 |
| SURE REACH TOGETHER | 0.6 | -12.2 | 45.0 | 20.6 | 0.8 | +1.5 | 3.8 | 23.9 |
| THROUGH LINE OF FIRE | 0.5 | +20.2 | 0.0 | 6.3 | 0.3 | +12.6 | 0.0 | 11.5 |
| TURN WORTH | 0.3 | -15.7 | 30.9 | 1.4 | 0.3 | -22.7 | 32.3 | 0.0 |
| TWO OR MORE ARRIVE | 0.4 | +3.1 | 17.4 | 8.4 | 0.6 | +3.2 | 2.6 | 4.8 |
| WAIT AFTER COSTS | 6.8 | -354.7 | 372.6 | 170.8 | 8.6 | -408.2 | 335.3 | 183.4 |
| WALKS TO THE FIGHT | 1.7 | +14.4 | 76.1 | 23.4 | 1.1 | +9.1 | 56.9 | 3.5 |
| WAR ENGINE CHARGES | 0.1 | +4.8 | 10.7 | 0.0 | 0.1 | +2.7 | 7.5 | 0.0 |
| WAR ENGINE JOBS | 0.6 | +0.0 | 37.7 | 9.4 | 0.5 | +0.0 | 10.6 | 9.2 |
| WEARS DOWN | 0.9 | +61.0 | 118.7 | 42.3 | 1.3 | +38.5 | 166.1 | 53.7 |
| WHO HITS BACK | 0.1 | +2.8 | 0.0 | 10.3 | 0.2 | +9.2 | 0.0 | 5.1 |
| WHOLE FIGHT | 0.2 | +9.2 | 14.9 | 0.0 | 0.2 | +5.1 | 19.7 | 0.0 |
| WHOLE FIGHT GAIN | 0.3 | +26.7 | 29.0 | 9.1 | 0.7 | +37.0 | 72.1 | 13.6 |
| WIDER SPREAD | 1.8 | -3.7 | 199.1 | 62.6 | 3.4 | -9.9 | 352.7 | 96.6 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |

### Rule changes: co-mine-a57fba0-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1183 | 1183 | 1183 | 32.86 | -51627 | -43.6 |
| PATHS CROSS | 171 | 171 | 171 | 4.75 | +12151 | +71.1 |
| MOVE TO CHARGE | 314 | 314 | 154 | 4.28 | +7820 | +50.8 |
| SEARCH SPOT | 143 | 143 | 139 | 3.86 | +5741 | +41.3 |
| SUPPORTS | 294 | 294 | 134 | 3.72 | +1404 | +10.5 |
| KILLS COUNT NEXT TURN | 410 | 410 | 130 | 3.61 | +3822 | +29.4 |
| WAIT AFTER COSTS | 556 | 556 | 101 | 2.81 | +1729 | +17.1 |
| FACES THE THREAT | 95 | 95 | 95 | 2.64 | +4983 | +52.5 |
| BEST FIRST | 78 | 78 | 78 | 2.17 | +3304 | +42.4 |
| RISK ONCE | 282 | 209 | 77 | 2.14 | +2627 | +34.1 |
| COVER ONCE | 465 | 252 | 75 | 2.08 | +1151 | +15.3 |
| FALLBACK BY WORTH | 328 | 328 | 74 | 2.06 | +3578 | +48.4 |
| SHOTS IN THE MOVE | 817 | 548 | 74 | 2.06 | +1859 | +25.1 |
| FOLLOW UP WEIGHED | 71 | 71 | 71 | 1.97 | +10121 | +142.6 |
| CHAFF IN THE MOVE | 89 | 87 | 60 | 1.67 | +1811 | +30.2 |
| SAFER THAN THE JOB | 60 | 60 | 60 | 1.67 | +3233 | +53.9 |
| SET UP TOGETHER | 129 | 115 | 60 | 1.67 | +3406 | +56.8 |
| ONE FIGHT FORMULA | 566 | 352 | 57 | 1.58 | +192 | +3.4 |
| ADVANCE WORTH | 355 | 355 | 55 | 1.53 | +774 | +14.1 |
| ARTILLERY RE-ROLL WEIGHED | 51 | 51 | 51 | 1.42 | +0 | +0.0 |
| CANNON SIGHT KEPT | 51 | 51 | 51 | 1.42 | +0 | +0.0 |
| CANNON PLANNED TARGET | 225 | 225 | 48 | 1.33 | -350 | -7.3 |
| ADVANCE LANE KEPT | 46 | 46 | 46 | 1.28 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 87 | 87 | 46 | 1.28 | +1735 | +37.7 |
| MISSILES IN THE MOVE | 271 | 163 | 45 | 1.25 | +1339 | +29.7 |
| RESERVE FALL BACK | 45 | 45 | 45 | 1.25 | +1130 | +25.1 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 111 | 111 | 44 | 1.22 | +1387 | +31.5 |
| INVITES THE FIGHT | 88 | 88 | 42 | 1.17 | +267 | +6.4 |
| REDIRECT COUNTER | 176 | 91 | 42 | 1.17 | +3505 | +83.4 |
| WALKS TO THE FIGHT | 101 | 101 | 42 | 1.17 | +270 | +6.4 |
| LONE WIZARD KEPT IN | 34 | 34 | 34 | 0.94 | +2648 | +77.9 |
| MAX FOR POSITIONING | 412 | 252 | 33 | 0.92 | +84 | +2.5 |
| COMBAT PIVOT | 31 | 31 | 31 | 0.86 | +0 | +0.0 |
| IDLE COST | 1200 | 666 | 31 | 0.86 | +254 | +8.2 |
| STOPS SHORT OF THE FLANK | 31 | 31 | 31 | 0.86 | +1237 | +39.9 |
| CHARGE NOW FIRST | 174 | 174 | 30 | 0.83 | -1641 | -54.7 |
| THROUGH LINE OF FIRE | 30 | 30 | 30 | 0.83 | +1182 | +39.4 |
| CAST JOB | 56 | 56 | 28 | 0.78 | +653 | +23.3 |
| HONEST WORTH | 608 | 606 | 28 | 0.78 | +198 | +7.1 |
| SHOT REPLANNED | 28 | 28 | 28 | 0.78 | +0 | +0.0 |
| MARCH CHECK | 29 | 27 | 27 | 0.75 | +1213 | +44.9 |
| RISK BY ARC | 148 | 146 | 27 | 0.75 | +1056 | +39.1 |
| CASTER AWAY FROM SCREEN | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| REDIRECT WEIGHED | 26 | 26 | 26 | 0.72 | +804 | +30.9 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 25 | 25 | 25 | 0.69 | +1527 | +61.1 |
| MOVE AND CAST | 24 | 24 | 24 | 0.67 | +1257 | +52.4 |
| SHOOTERS IN TWO RANKS | 24 | 24 | 24 | 0.67 | +58 | +2.4 |
| MAKE SURE TOGETHER | 67 | 49 | 23 | 0.64 | +1217 | +52.9 |
| BEST OVERALL | 21 | 21 | 21 | 0.58 | +923 | +44.0 |
| BLOCKED WHEEL | 19 | 19 | 19 | 0.53 | +565 | +29.7 |
| KILLS COUNT | 74 | 73 | 19 | 0.53 | +1459 | +76.8 |
| BEST FACING | 18 | 18 | 18 | 0.50 | +344 | +19.1 |
| WAR ENGINE JOBS | 39 | 39 | 17 | 0.47 | -895 | -52.6 |
| BEST PREY | 37 | 37 | 15 | 0.42 | +275 | +18.3 |
| CASTING BLOCK | 23 | 23 | 15 | 0.42 | +641 | +42.7 |
| LOST CHARGE | 203 | 202 | 15 | 0.42 | +662 | +44.1 |
| MODEL FACING | 15 | 15 | 15 | 0.42 | +4227 | +281.8 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| KEEPS ITS TARGET | 126 | 126 | 14 | 0.39 | +233 | +16.6 |
| FRIENDS SHOTS CHECKED | 13 | 13 | 13 | 0.36 | +1055 | +81.2 |
| BIG CHARACTER SAFETY | 12 | 12 | 12 | 0.33 | -50 | -4.2 |
| WHO HITS BACK | 12 | 12 | 12 | 0.33 | +281 | +23.4 |
| BEST PRIZE | 11 | 11 | 11 | 0.31 | -448 | -40.7 |
| CHAFF PASSED | 11 | 11 | 11 | 0.31 | -10 | -0.9 |
| WHOLE FIGHT GAIN | 35 | 33 | 11 | 0.31 | +661 | +60.1 |
| MANOEUVRE | 15 | 15 | 10 | 0.28 | +84 | +8.4 |
| OPENS UP | 19 | 19 | 10 | 0.28 | +300 | +30.0 |
| STUCK PIVOT | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| MARCH ODDS | 9 | 9 | 9 | 0.25 | +80 | +8.9 |
| PIVOT GUARDS FLANK | 9 | 9 | 9 | 0.25 | -227 | -25.2 |
| SUPPORT NARROWED | 428 | 428 | 9 | 0.25 | -112 | -12.4 |
| SURE CHARGE BEATS ADVANCE | 9 | 9 | 9 | 0.25 | -267 | -29.6 |
| WEARS DOWN | 77 | 74 | 9 | 0.25 | +422 | +46.9 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| BLOCKED CHARGE SKIPPED | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| BREAK OUTCOMES | 80 | 79 | 7 | 0.19 | +150 | +21.4 |
| HUNT IN PAIRS | 33 | 21 | 7 | 0.19 | +318 | +45.4 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| RESTRAINS TO SHOOT | 7 | 7 | 7 | 0.19 | +137 | +19.6 |
| SURE REACH TOGETHER | 51 | 44 | 7 | 0.19 | +19 | +2.7 |
| MISSILES NEXT TURN | 318 | 182 | 6 | 0.17 | +12 | +2.1 |
| PURSUES BIG PREY | 6 | 6 | 6 | 0.17 | -358 | -59.8 |
| REFUSING RETIRES | 20 | 20 | 6 | 0.17 | -1 | -0.2 |
| WHOLE FIGHT | 14 | 14 | 6 | 0.17 | +166 | +27.7 |
| FLEES FROM CHARGE | 16 | 16 | 5 | 0.14 | +211 | +42.2 |
| ONE OBJECTIVE FORMULA | 167 | 78 | 5 | 0.14 | +156 | +31.2 |
| BACKUP TARGETS | 32 | 15 | 3 | 0.08 | -0 | -0.0 |
| ELIXIR WORTH | 3 | 3 | 3 | 0.08 | +95 | +31.8 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.08 | +53 | +17.6 |
| FOCUS FIRE | 3 | 3 | 3 | 0.08 | +146 | +48.7 |
| HUNT ADVANCE | 5 | 5 | 3 | 0.08 | +75 | +25.1 |
| JOINT CHARGE PLAN | 24 | 24 | 3 | 0.08 | +238 | +79.2 |
| NO RALLY LEFT | 3 | 3 | 3 | 0.08 | +285 | +95.0 |
| OVERRUN ON | 7 | 7 | 3 | 0.08 | +131 | +43.5 |
| STANDS TO CAST | 3 | 3 | 3 | 0.08 | -5 | -1.8 |
| KEEP FALLS | 2 | 2 | 2 | 0.06 | +9 | +4.6 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| OVERRUNS AWAY | 25 | 25 | 2 | 0.06 | +17 | +8.5 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 2 | 0.06 | +106 | +53.2 |
| SAFE SURE CHARGE | 2 | 2 | 2 | 0.06 | -28 | -14.1 |
| SPELLS IN THE FIGHT | 33 | 31 | 2 | 0.06 | +22 | +11.0 |
| BLOWS WHERE AIMED | 24 | 23 | 1 | 0.03 | +23 | +22.9 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +47 | +47.0 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.1 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +3 | +2.7 |
| MOVE SPELL IN RANGE | 7 | 4 | 1 | 0.03 | +28 | +28.2 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +16 | +16.4 |
| REDIRECT BY WHAT IT STOPS | 64 | 64 | 1 | 0.03 | +32 | +32.5 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +3 | +3.0 |
| TURN WORTH | 20 | 20 | 1 | 0.03 | +3 | +3.1 |
| TWO OR MORE ARRIVE | 36 | 30 | 1 | 0.03 | +1 | +1.0 |
| WAR ENGINE CHARGES | 4 | 4 | 1 | 0.03 | +27 | +27.1 |
| WIDER SPREAD | 188 | 182 | 1 | 0.03 | +1 | +1.2 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.03 | -20 | -20.3 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 35 | 35 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 8 | 8 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 33 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARGER SLAIN LOST | 33 | 31 | 0 | 0.00 | - | - |
| CHARIOT NO STATIC JOB | 2 | 2 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 4 | 4 | 0 | 0.00 | - | - |
| CHEAP HELPER | 9 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 32 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 9 | 9 | 0 | 0.00 | - | - |
| DEFENSIVE FLOOR | 2 | 2 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 5 | 5 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 318 | not checked | - | - | - | - |
| GIVES UP | 8 | 7 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 21 | 19 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 6 | 6 | 0 | 0.00 | - | - |
| HUNT DROPPED | 1 | trace | - | - | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT RESULT | 5 | trace | - | - | - | - |
| HUNT THE GUNS | 6 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 5 | 5 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 6 | 6 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 30 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 14 | 14 | 0 | 0.00 | - | - |
| LONG SHOT | 34 | 32 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 14 | 14 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 4 | trace | - | - | - | - |
| MARCH OVER CASTS | 31 | 31 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 10 | 10 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 17 | trace | - | - | - | - |
| MOVE SPELL SPOT | 10 | not checked | - | - | - | - |
| NOT NEEDED | 19 | 19 | 0 | 0.00 | - | - |
| NOT TURNED | 345 | 345 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 46 | not checked | - | - | - | - |
| PLAN RESULT | 2707 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 19 | 19 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 19 | 19 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 14 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 12 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 16 | not checked | - | - | - | - |
| SPELL WORTH | 97 | not checked | - | - | - | - |
| STABLE ROLE | 810 | 808 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 10 | 10 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: co-mine-a57fba0-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 15.39 | 14.42 | 44.7 |
| FALLBACK | gate | 0.25 | 1.06 | 48.2 |
| CHARGE NOW FIRST | rule | 0.36 | 0.47 | 54.7 |
| TURN GATE | gate | 0.31 | 0.42 | 22.1 |
| WAR ENGINE JOBS | rule | 0.39 | 0.08 | 52.6 |
| BEST PRIZE | rule | 0.17 | 0.14 | 40.7 |
| CANNON PLANNED TARGET | rule | 0.25 | - | 53.2 |
| PIVOT GUARDS FLANK | rule | 0.08 | 0.17 | 25.2 |
| SUPPORT NARROWED | rule | 0.11 | 0.14 | 12.4 |
| SURE CHARGE BEATS ADVANCE | rule | 0.14 | 0.11 | 29.6 |
| AFTERMATH BAND | gate | 0.11 | 0.11 | 1.7 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.11 | 0.11 | 23.3 |
| SUPPORT REQUEST | gate | 0.03 | 0.17 | 78.8 |
| FIGHT ORDER BAND | gate | 0.03 | 0.14 | 1.7 |
| PURSUES BIG PREY | rule | 0.11 | 0.06 | 59.8 |
| BIG CHARACTER SAFETY | rule | 0.06 | 0.08 | 13.5 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.06 | 42.6 |
| LONE CHARACTER SAFE SPOT | gate | 0.06 | 0.06 | 10.1 |
| CHAFF PASSED | rule | 0.03 | 0.06 | 3.3 |
| THROUGH LINE OF FIRE | rule | 0.06 | 0.03 | 11.8 |
| FACES THE THREAT | rule | 0.06 | - | 9.2 |
| NO REASON | gate | 0.06 | - | 19.2 |
| PATHS CROSS | rule | - | 0.06 | 1.5 |
| REDIRECT WEIGHED | rule | 0.06 | - | 46.3 |
| RULE SWITCHED OFF | gate | - | 0.06 | 14.4 |
| SAFE SURE CHARGE | rule | 0.06 | - | 14.1 |
| SAFER THAN THE JOB | rule | - | 0.06 | 20.9 |
| BLOCKED WHEEL | rule | - | 0.03 | 8.4 |
| FOLLOW UP WEIGHED | rule | - | 0.03 | 2.1 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | - | 0.7 |
| MARCH ODDS | rule | 0.03 | - | 1.5 |
| STANDS TO CAST | rule | - | 0.03 | 10.0 |
| STOPS SHORT OF THE FLANK | rule | - | 0.03 | 7.4 |
| WOUNDED STAYS OUT | rule | - | 0.03 | 20.3 |

### Plans: co-mine-a57fba0-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 9.7 | 19% | 181 | 299 | 165% |
| Mine | charge | 2.6 | 65% | 248 | 222 | 90% |
| Mine | close in | 4.6 | 32% | 298 | 235 | 79% |
| Mine | hold | 5.7 | 37% | 348 | 0 | 0% |
| Mine | join | 0.6 | 95% | 18 | 0 | 0% |
| Mine | shoot | 9.7 | 61% | 360 | 811 | 226% |
| Mine | support | 4.2 | 84% | 42 | 0 | 0% |
| Opponent | advance | 10.4 | 21% | 128 | 266 | 208% |
| Opponent | charge | 4.1 | 64% | 323 | 419 | 130% |
| Opponent | close in | 6.6 | 26% | 396 | 181 | 46% |
| Opponent | hold | 4.6 | 45% | 312 | 0 | 0% |
| Opponent | join | 1.1 | 97% | 48 | 0 | 0% |
| Opponent | shoot | 5.1 | 57% | 107 | 244 | 228% |
| Opponent | support | 6.2 | 88% | 50 | 0 | 0% |

### Packages: hunt the guns, co-mine-a57fba0-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 0% | 0% | 0% | - | 450 | 0 | 0% | 25 |
| Opponent | 0.1 | 5 | 1 | 0% | 25% | 0% | 2.0 | 302 | 75 | 25% | 91 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 450 | 0 | 0% | 130 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 70 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 43 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 158 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 175 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 70 |
| Skaven | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 238 | 0 | 0% | 36 |
| Tomb Kings of Khemri | 0.2 | 1 | 0 | 0% | 100% | 0% | 2.0 | 342 | 298 | 100% | 12 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 22 |
| Warriors of Chaos | 0.2 | 2 | 1 | 0% | 0% | 0% | - | 299 | 0 | 0% | 62 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 329 | 0 | 0% | 83 |

### Battle groups: co-mine-a57fba0-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.6 | 41% | 52% | 13% | 33% | 25% | 0% | 5% | 65% | 5% |
| Opponent | REDIRECT COUNTER | 3.3 | 27% | 78% | 22% | 29% | 20% | 4% | 12% | 52% | 12% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: co-mine-a57fba0-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 37 | 67% | 4.0 | 0 (1) | 0 (2) | - | - | 0 (3) |
| Mine | Chaff | 37 | 14 (37) | 8 | 6 | 48 | 46% | 2.1 | 26 (16) | 5 (9) | 7 (12) | 17 (24) | 10 (13) |
| Mine | Character | 123 | 52 (123) | 52 | 0 | 38 | 24% | 2.2 | 79 (35) | 50 (56) | 6 (9) | 83 (54) | 32 (46) |
| Mine | Clean-up | 24 | 51 (24) | 20 | 31 | 25 | 50% | 2.8 | 50 (9) | 62 (11) | 8 (4) | 79 (14) | 16 (10) |
| Mine | Fast | 4 | 30 (4) | 30 | 0 | 34 | 0% | 1.5 | 57 (1) | 0 (2) | 0 (1) | 30 (4) | - |
| Mine | Fast Hammer | 41 | 42 (41) | 27 | 15 | 56 | 34% | 2.9 | 40 (18) | 32 (12) | 54 (11) | 45 (28) | 37 (13) |
| Mine | Fragile | 5 | 14 (5) | 14 | 0 | 40 | 0% | 1.8 | - | 17 (4) | 0 (1) | 0 (1) | 17 (4) |
| Mine | Hammer | 58 | 43 (58) | 27 | 16 | 40 | 16% | 2.5 | 18 (10) | 50 (38) | 39 (10) | 46 (34) | 40 (24) |
| Mine | Holder | 25 | 89 (25) | 9 | 80 | 22 | 52% | 3.2 | 94 (6) | 71 (13) | 152 (5) | 126 (10) | 67 (14) |
| Mine | Shooter | 44 | 93 (44) | 28 | 65 | 47 | 5% | 1.8 | 61 (5) | 116 (31) | 39 (8) | 113 (25) | 67 (19) |
| Mine | Support | 5 | 0 (5) | 0 | 0 | 58 | 0% | 3.6 | - | 0 (2) | - | 0 (2) | - |
| Mine | War machine | 56 | 50 (56) | 50 | 0 | 46 | 5% | 1.2 | 53 (13) | 57 (37) | 0 (6) | 27 (11) | 56 (45) |
| Mine | Wizard | 23 | 23 (23) | 23 | 0 | 35 | 22% | 2.8 | 0 (6) | 52 (11) | 30 (2) | 113 (3) | 5 (16) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 66 | 61 (66) | 18 | 43 | 44 | 42% | 2.9 | 88 (28) | 33 (16) | 50 (22) | 74 (48) | 24 (18) |
| Opponent | Character | 114 | 47 (114) | 47 | 0 | 35 | 27% | 2.2 | 54 (41) | 50 (55) | 5 (5) | 46 (67) | 59 (34) |
| Opponent | Clean-up | 16 | 59 (16) | 59 | 0 | 39 | 31% | 3.0 | 93 (5) | 15 (8) | 85 (3) | 92 (8) | 33 (8) |
| Opponent | Early | 1 | 1058 (1) | 1058 | 0 | 100 | 0% | 5.0 | - | 1058 (1) | - | 1058 (1) | - |
| Opponent | Fast Hammer | 58 | 59 (58) | 42 | 17 | 46 | 28% | 2.5 | 55 (25) | 51 (19) | 80 (14) | 59 (42) | 59 (16) |
| Opponent | Fragile | 10 | 0 (10) | 0 | 0 | 62 | 30% | 1.9 | 0 (3) | 0 (4) | 0 (3) | 0 (9) | 0 (1) |
| Opponent | Hammer | 65 | 34 (65) | 28 | 6 | 48 | 28% | 2.7 | 31 (16) | 37 (42) | 24 (7) | 31 (40) | 41 (25) |
| Opponent | Holder | 40 | 71 (40) | 10 | 61 | 36 | 32% | 3.7 | 49 (8) | 113 (19) | 23 (10) | 120 (18) | 42 (19) |
| Opponent | Shooter | 30 | 65 (30) | 17 | 49 | 39 | 3% | 1.3 | 38 (7) | 75 (18) | 62 (5) | 62 (16) | 70 (14) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | - | 0 (2) |
| Opponent | War machine | 13 | 62 (13) | 62 | 0 | 46 | 0% | 1.2 | 0 (5) | 59 (5) | 179 (3) | 95 (3) | 52 (10) |
| Opponent | Wizard | 22 | 4 (22) | 4 | 0 | 27 | 9% | 1.9 | 0 (11) | 17 (6) | 0 (3) | 7 (11) | 0 (9) |

### Charged fights: co-mine-a57fba0-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 173 | 14 | 1.0 | 1.0 | 14 | 16 | -3 | 1 of 5 | 3 of 5 | - | -3 |
| Mine | Chaos Dwarfs | 3 | 262 | 851 | 4.0 | 1.3 | 213 | 0 | +213 | 6 of 12 | 9 of 12 | +204 | +215 |
| Mine | Dwarfen Mountain Holds | 4 | 384 | 53 | 1.5 | 1.2 | 35 | 10 | +25 | 1 of 6 | 6 of 6 | -60 | +42 |
| Mine | Empire of Man | 5 | 474 | 176 | 1.8 | 1.0 | 98 | 42 | +55 | 1 of 9 | 8 of 9 | - | +55 |
| Mine | Grand Cathay | 4 | 766 | 410 | 2.5 | 1.3 | 164 | 0 | +164 | 6 of 10 | 7 of 10 | +322 | +96 |
| Mine | High Elf Realms | 4 | 214 | 513 | 3.5 | 1.1 | 147 | 34 | +113 | 4 of 14 | 10 of 14 | +0 | +132 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 113 | 3.0 | 1.3 | 38 | 0 | +38 | 1 of 3 | 2 of 3 | +45 | +34 |
| Mine | Lizardmen | 1 | 70 | 186 | 4.0 | 1.0 | 46 | 79 | -32 | 1 of 4 | 2 of 4 | - | -32 |
| Mine | Ogre Kingdoms | 1 | 195 | 195 | 4.0 | 1.0 | 49 | 81 | -32 | 3 of 4 | 1 of 4 | - | -32 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 0 | 3.0 | 1.0 | 0 | 37 | -37 | 2 of 3 | 0 of 2 | - | -37 |
| Mine | Skaven | 2 | 48 | 127 | 0.5 | 1.0 | 254 | 0 | +254 | 1 of 1 | 1 of 1 | - | +254 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 1118 | 5.0 | 1.0 | 224 | 6 | +218 | 2 of 10 | 9 of 10 | - | +218 |
| Mine | Vampire Counts | 2 | 0 | 229 | 3.5 | 1.1 | 65 | 0 | +65 | 1 of 7 | 6 of 7 | +98 | +60 |
| Mine | Warriors of Chaos | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 0 of 2 | 2 of 2 | - | +0 |
| **Mine** | all armies | 36 | 273 | 301 | 2.5 | 1.1 | 120 | 20 | +100 | 30 of 90 | 66 of 89 | +151 | +93 |
| Opponent | Beastmen Brayherds | 1 | 0 | 272 | 4.0 | 1.0 | 68 | 0 | +68 | 1 of 4 | 4 of 4 | - | +68 |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 112 | 2.0 | 1.0 | 56 | 0 | +56 | 0 of 2 | 1 of 2 | - | +56 |
| Opponent | Empire of Man | 1 | 255 | 0 | 2.0 | 1.0 | 0 | 132 | -132 | 1 of 2 | 1 of 2 | - | -132 |
| Opponent | Grand Cathay | 1 | 555 | 718 | 4.0 | 1.8 | 180 | 0 | +180 | 3 of 4 | 3 of 4 | +306 | +52 |
| Opponent | High Elf Realms | 2 | 177 | 166 | 2.0 | 1.0 | 83 | 0 | +83 | 1 of 4 | 3 of 4 | - | +83 |
| Opponent | Lizardmen | 1 | 170 | 715 | 3.0 | 2.3 | 238 | 0 | +238 | 2 of 3 | 3 of 3 | +358 | +0 |
| Opponent | Ogre Kingdoms | 2 | 68 | 541 | 3.5 | 1.0 | 155 | 56 | +99 | 3 of 7 | 4 of 7 | - | +99 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 816 | 4.5 | 1.1 | 181 | 0 | +181 | 4 of 9 | 8 of 9 | +310 | +165 |
| Opponent | Skaven | 2 | 0 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 65 | 1223 | 4.2 | 1.5 | 288 | 36 | +252 | 7 of 17 | 14 of 17 | +409 | +166 |
| Opponent | Vampire Counts | 6 | 9 | 624 | 4.5 | 1.0 | 139 | 43 | +96 | 15 of 27 | 22 of 27 | +20 | +99 |
| Opponent | Warriors of Chaos | 7 | 0 | 374 | 1.7 | 1.0 | 218 | 0 | +218 | 10 of 12 | 10 of 12 | - | +218 |
| Opponent | Wood Elf Realms | 6 | 192 | 314 | 3.2 | 1.4 | 99 | 53 | +47 | 8 of 19 | 16 of 19 | +64 | +39 |
| **Opponent** | all armies | 36 | 82 | 500 | 3.1 | 1.2 | 162 | 31 | +131 | 55 of 111 | 89 of 111 | +250 | +108 |

### Effective charges: co-mine-a57fba0-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 0 | 0 | 0 | 2 (net -24) | 0 | 1 (net +0) | 2 | 0% (0 of 3) |
| Mine | Chaos Dwarfs | 12 | 1 (net +506) | 0 | 0 | 5 (net +132) | 3 (net +173) | 2 (net +148) | 1 | 0% (0 of 11) |
| Mine | Dwarfen Mountain Holds | 6 | 2 (net -30) | 0 | 0 | 2 (net +76) | 0 | 1 (net +60) | 1 | 0% (0 of 5) |
| Mine | Empire of Man | 9 | 1 (net -380) | 0 | 0 | 3 (net +101) | 2 (net +35) | 3 (net +168) | 0 | 0% (0 of 9) |
| Mine | Grand Cathay | 10 | 1 (net +0) | 0 | 2 (net +291) | 5 (net +114) | 0 | 1 (net +393) | 1 | 22% (2 of 9) |
| Mine | High Elf Realms | 14 | 2 (net -44) | 1 (net +0) | 1 (net +116) | 5 (net +44) | 2 (net +95) | 1 (net -143) | 2 | 8% (1 of 12) |
| Mine | Kingdom of Bretonnia | 3 | 1 (net +0) | 0 | 0 | 0 | 2 (net +56) | 0 | 0 | 0% (0 of 3) |
| Mine | Lizardmen | 4 | 0 | 0 | 0 | 1 (net -175) | 0 | 0 | 3 | 0% (0 of 1) |
| Mine | Ogre Kingdoms | 4 | 0 | 0 | 1 (net -39) | 0 | 0 | 0 | 3 | 100% (1 of 1) |
| Mine | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +254) | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 10 | 1 (net +863) | 0 | 1 (net +125) | 2 (net +143) | 0 | 5 (net +167) | 1 | 11% (1 of 9) |
| Mine | Vampire Counts | 7 | 1 (net +0) | 0 | 0 | 1 (net +0) | 3 (net +96) | 1 (net +0) | 1 | 0% (0 of 6) |
| Mine | Warriors of Chaos | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Beastmen Brayherds | 4 | 0 | 0 | 3 (net +47) | 1 (net +130) | 0 | 0 | 0 | 75% (3 of 4) |
| Opponent | Dwarfen Mountain Holds | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +112) | 0 | 0% (0 of 2) |
| Opponent | Empire of Man | 2 | 0 | 0 | 1 (net -265) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Opponent | Grand Cathay | 4 | 1 (net +0) | 0 | 1 (net +128) | 1 (net +105) | 0 | 1 (net +485) | 0 | 25% (1 of 4) |
| Opponent | High Elf Realms | 4 | 0 | 0 | 1 (net +227) | 0 | 0 | 1 (net +104) | 2 | 50% (1 of 2) |
| Opponent | Lizardmen | 3 | 0 | 0 | 1 (net +526) | 0 | 1 (net +189) | 1 (net +0) | 0 | 33% (1 of 3) |
| Opponent | Ogre Kingdoms | 7 | 0 | 0 | 3 (net +317) | 1 (net -301) | 0 | 1 (net +65) | 2 | 60% (3 of 5) |
| Opponent | Orc & Goblin Tribes | 9 | 1 (net +219) | 0 | 0 | 0 | 0 | 0 | 8 | 0% (0 of 1) |
| Opponent | Skaven | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 17 | 0 | 1 (net -540) | 5 (net +152) | 4 (net +514) | 0 | 6 (net +335) | 1 | 31% (5 of 16) |
| Opponent | Vampire Counts | 27 | 3 (net +144) | 2 (net +202) | 7 (net +71) | 6 (net +73) | 1 (net +0) | 7 (net +103) | 1 | 27% (7 of 26) |
| Opponent | Warriors of Chaos | 12 | 1 (net +663) | 0 | 1 (net +708) | 3 (net +189) | 1 (net +54) | 3 (net +208) | 3 | 11% (1 of 9) |
| Opponent | Wood Elf Realms | 19 | 3 (net -49) | 1 (net +70) | 4 (net +87) | 5 (net +18) | 1 (net +0) | 5 (net +106) | 0 | 21% (4 of 19) |

### Charged fights, damage counted: co-mine-a57fba0-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 11 | 239 | 249 | +76 | 181 | 75 | +106 | +44.6 |
| Mine | 50-54% | 1 | 489 | 201 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 5 | 351 | 204 | +157 | 204 | 47 | +157 | +44.7 |
| Mine | 76-89% | 26 | 285 | 158 | +76 | 103 | 36 | +68 | +23.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 16 | 187 | 159 | +138 | 153 | 29 | +124 | +66.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 12 | 497 | 99 | +98 | 112 | 18 | +94 | +19.0 |
| Mine | No odds | 19 | 281 | 179 | +109 | 152 | 41 | +111 | +39.6 |
| Mine | All fights | 90 | 295 | 169 | +100 | 138 | 38 | +99 | +33.7 |
| Opponent | Long shot (under 50%) | 11 | 249 | 362 | +106 | 144 | 22 | +122 | +48.9 |
| Opponent | 50-54% | 4 | 302 | 267 | -16 | 225 | 254 | -29 | -9.6 |
| Opponent | Effective (55-75%) | 27 | 270 | 219 | +149 | 192 | 62 | +129 | +47.9 |
| Opponent | 76-89% | 21 | 230 | 157 | +147 | 192 | 41 | +151 | +65.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 26 | 357 | 207 | +179 | 235 | 63 | +172 | +48.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 534 | 111 | +61 | 65 | 0 | +65 | +12.1 |
| Opponent | No odds | 18 | 203 | 240 | +82 | 93 | 46 | +47 | +23.1 |
| Opponent | All fights | 111 | 280 | 220 | +131 | 178 | 56 | +121 | +43.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| co-mine-a57fba0-p1 | move | 364 | 82 (23%) | 59 (16%) | 49 (13%) | 233 (64%) |
| co-mine-a57fba0-p1 | objective | 402 | 59 (15%) | 43 (11%) | 54 (13%) | 289 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

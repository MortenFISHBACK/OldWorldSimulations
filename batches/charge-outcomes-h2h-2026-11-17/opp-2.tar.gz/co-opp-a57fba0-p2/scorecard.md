# Doctrine scorecard: co-opp-a57fba0-p2

### Scorecard: co-opp-a57fba0-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 4 | 5 | 1 | 3 | 0 | 0 | 0 | 322 |
| L0106 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 981 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 2 | 1 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | - | 1 | 6 | 0 | 0 | 0 | 52 |
| L0206 | 2 | 1 | Opponent | - | - | 3 | 1 | 0 | 0 | 0 | 0 | 615 |
| L0222 | 6 | 1 | Mine | no | 8 | 2 | 3 | 2 | 0 | 0 | 0 | 200 |
| L0222 | 6 | 1 | Opponent | no | 5 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | yes | 2 | 3 | 2 | 2 | 0 | 0 | 0 | 675 |
| L0307 | 1 | 1 | Opponent | yes | 5 | 2 | 0 | 0 | 0 | 0 | 0 | 420 |
| L0323 | 5 | 1 | Mine | no | - | 4 | 2 | 2 | 0 | 0 | 0 | 590 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 4 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 1 | 6 | 0 | 0 | 0 | 0 | 0 | 596 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | yes | - | 6 | 5 | 1 | 1 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 966 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 0 | 3 | 1 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 1 | 4 | 1 | 1 | 0 | 0 | 0 | 475 |
| L0528 | 6 | 1 | Opponent | no | 7 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 2 | 2 | 2 | 1 | 0 | 0 | 0 | 615 |
| L0616 | 4 | 1 | Opponent | no | 0 | 3 | 1 | 0 | 1 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 743 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0721 | 1 | 1 | Mine | yes | 3 | 2 | 2 | 0 | 1 | 0 | 0 | 558 |
| L0721 | 1 | 1 | Opponent | yes | 3 | - | 1 | 3 | 1 | 0 | 0 | 145 |
| L0810 | 6 | 1 | Mine | no | 0 | 3 | 1 | 3 | 0 | 0 | 0 | 864 |
| L0810 | 6 | 1 | Opponent | no | 5 | 2 | 1 | 0 | 1 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | 6 | 1 | 1 | 0 | 0 | 0 | 769 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 7 | 5 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 1 | 2 | 0 | 0 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 14 | 2 | 9 | 1 | 0 | 0 | 0 | 419 |
| L0934 | 4 | 1 | Mine | no | 0 | 3 | 0 | 0 | 0 | 0 | 0 | 723 |
| L0934 | 4 | 1 | Opponent | no | 0 | 2 | 5 | 3 | 0 | 0 | 0 | 160 |
| L1026 | 6 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 3 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 1 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 5 | 3 | 3 | 1 | 0 | 0 | 225 |
| L1135 | 1 | 1 | Mine | yes | 1 | 5 | 1 | 0 | 1 | 0 | 0 | 501 |
| L1135 | 1 | 1 | Opponent | yes | 0 | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 4 | 4 | 2 | 1 | 0 | 0 | 0 | 330 |
| L1228 | 4 | 1 | Opponent | no | 3 | 2 | 3 | 1 | 0 | 0 | 0 | 111 |
| L1323 | 3 | 1 | Mine | no | 6 | - | 0 | 1 | 1 | 0 | 0 | 317 |
| L1323 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Mine | no | 3 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 1 | 5 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 1 | 0 | 0 | 460 |
| L1629 | 3 | 1 | Mine | no | 4 | 1 | 3 | 1 | 1 | 0 | 0 | 536 |
| L1629 | 3 | 1 | Opponent | no | 1 | - | 1 | 1 | 1 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | yes | - | 4 | 2 | 1 | 0 | 0 | 0 | 98 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 0 | 6 | 2 | 1 | 1 | 0 | 0 | 370 |
| L1827 | 3 | 1 | Opponent | no | 8 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 1 | 1 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Opponent | no | 2 | 2 | 2 | 1 | 1 | 0 | 0 | 190 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 2 | 2 | 2 | 0 | 0 | 420 |
| L2029 | 1 | 1 | Opponent | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2131 | 1 | 1 | Mine | yes | 2 | 6 | 2 | 3 | 0 | 0 | 0 | 355 |
| L2131 | 1 | 1 | Opponent | no | 2 | 4 | 1 | 1 | 1 | 0 | 0 | 562 |
| L2235 | 3 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 1 | 0 | 0 | 126 |
| L2429 | 5 | 1 | Mine | no | - | 5 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 4 | 3 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Mine | no | 6 | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 0 | 1 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | yes | - | 4 | 1 | 6 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | no | - | 3 | 1 | 3 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 3 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 4 | 1 | 6 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 27% | 2.3 | 3.2 | 1.8 | 1.4 | 0.2 | 0.0 | 0.0 | 321.1 |
| **Average** | | | Opponent | 27% | 2.6 | 2.5 | 2.9 | 1.6 | 0.3 | 0.0 | 0.0 | 167.8 |

### KPIs: co-opp-a57fba0-p2

Rules off - Mine only: BREAK OUTCOMES, OVERRUN ON, STAND AND SHOOT, FLEES FROM CHARGE.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 27% (45 of 166) | 18% (32 of 176) | 23% (77 of 342) |
| Winner chose to follow up after the loser gave ground |  | 98% (60 of 61); on the table 98% | 96% (52 of 54); on the table 96% | 97% (112 of 115); on the table 97% |
| Winner chose to pursue after the loser fell back in good order |  | 80% (8 of 10); on the table 80% | 94% (16 of 17); on the table 94% | 89% (24 of 27); on the table 89% |
| Winner chose to pursue after the loser fled |  | 60% (12 of 20); on the table 75% | 81% (22 of 27); on the table 93% | 72% (34 of 47); on the table 85% |
| Winner chose to follow up or pursue (all three) |  | 88% (80 of 91); on the table 91% | 92% (90 of 98); on the table 95% | 90% (170 of 189); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 33% (112 of 342) | 39% (61 of 156) | 35% (173 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 48% (112 of 235) | 52% (61 of 117) | 49% (173 of 352) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 57% (12 of 21) | 66% (33 of 50) | 63% (45 of 71) |
| Points that never fought | lower | 38% (27506 of 71583) | 43% (30703 of 71989) | 41% (58209 of 143572) |
|   infantry points that never fought | lower | 44% (7258 of 16324) | 60% (8487 of 14029) | 52% (15745 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 59% (168 of 284) | 61% (180 of 297) | 60% (348 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 90% (18 of 20); 1.7 uses a game | 67% (12 of 18); 1.2 uses a game | 79% (30 of 38); 1.4 uses a game |
| Bound items with another spell used |  | 39% (7 of 18); 0.3 uses a game | 0% (0 of 2); 0.0 uses a game | 35% (7 of 20); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 60% (12 of 20); 0.3 uses a game | 29% (2 of 7); 0.1 uses a game | 52% (14 of 27); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 54% (32716 of 60231) | 56% (35447 of 63281) | 55% (68163 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.6 (25%) | 0.7 (26%) | 2.3 (26%) |
| MARCHED: its unit marched | 1.3 (20%) | 0.4 (16%) | 1.7 (19%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.1 (3%) | 0.2 (3%) |
| IN COMBAT: engaged in combat | 1.4 (21%) | 0.4 (16%) | 1.8 (20%) |
| REAR RANK: in a rear rank | 0.2 (3%) | 0.1 (5%) | 0.3 (4%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (0%) | 0.1 (2%) |
| GONE: slain | 1.1 (17%) | 0.6 (23%) | 1.7 (19%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (6%) | 0.1 (2%) | 0.4 (5%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.1 (2%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.2 (8%) | 0.2 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 1.5 | 1.2 | 4.8 | 0.4 | 1.5 |
| not cast | 3.8 | 3.4 | 3.8 | 9.0 | 1.9 | 20.2 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 1.3 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (39%) | 0.2 (7%) | 2.3 (26%) | 0.4 (22%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (19%) | 0.3 (14%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (3%) | 0.0 (1%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (7%) | 0.3 (10%) | 0.7 (18%) | 1.8 (20%) | 0.2 (9%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (8%) | 0.3 (10%) | 0.3 (9%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (7%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.1 (2%) | 0.1 (4%) | 0.2 (1%) |
| GONE: slain | 0.9 (23%) | 0.8 (25%) | 0.7 (18%) | 1.7 (19%) | 0.4 (19%) | 3.8 (19%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.1 (2%) | 0.1 (3%) | 0.4 (5%) | 0.1 (4%) | 0.3 (1%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (1%) | 0.0 (1%) | 0.1 (2%) | 0.0 (0%) | 0.4 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.2 (7%) | 0.0 (0%) | 0.0 (0%) | 0.4 (19%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (55%) | 0.1 (3%) | 1.6 (43%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.2 (70%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.7 a game | 0.6 a game | 0.7 a game |
| stood (cast and not dispelled) | 71% (15 of 21) | 43% (10 of 23) | 57% (25 of 44) |
| the unit moved after it | 80% (12 of 15) | 60% (6 of 10) | 72% (18 of 25) |
| it charged on its next turn | 13% (2 of 15) | 0% (0 of 10) | 8% (2 of 25) |
| the enemy charged it first | 7% (1 of 15) | 0% (0 of 10) | 4% (1 of 25) |
| it fought by the end of its next turn | 0% (0 of 15) | 0% (0 of 10) | 0% (0 of 25) |
| it moved out of a charge the enemy had planned (not charged first) | 27% (4 of 15) | 10% (1 of 10) | 20% (5 of 25) |
| none of these (no charge, no fight, no charge escaped) | 53% (8 of 15) | 90% (9 of 10) | 68% (17 of 25) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (556 of 838) | 54% (432 of 797) | 60% (988 of 1635) |
|   cavalry | 60% (44 of 73) | 64% (110 of 171) | 63% (154 of 244) |
|   character | 55% (56 of 101) | 30% (29 of 97) | 43% (85 of 198) |
|   chariot | 52% (55 of 105) | 52% (25 of 48) | 52% (80 of 153) |
|   infantry | 59% (153 of 259) | 54% (168 of 312) | 56% (321 of 571) |
|   monster | 40% (17 of 42) | 50% (17 of 34) | 45% (34 of 76) |
|   war machine | 90% (231 of 258) | 61% (83 of 135) | 80% (314 of 393) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (29%) | 2.2 (22%) | 4.5 (25%) |
| CHARGED: it charged | 1.2 (16%) | 1.7 (16%) | 2.9 (16%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 0.7 (9%) | 0.5 (5%) | 1.2 (7%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 1.5 (20%) | 2.1 (20%) | 3.6 (20%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (7%) | 0.7 (7%) | 1.3 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.1 (14%) | 1.8 (18%) | 2.9 (16%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.5 (5%) | 0.7 (4%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.1 (2%) | 0.5 (5%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.2 | 1.6 | 80% | 4.2 pts | 26 pts |
| character | 2.5 | 0.9 | 74% | 9.6 pts | 24 pts |
| chariot | 2.2 | 1.0 | 73% | 11.8 pts | 27 pts |
| infantry | 12.2 | 5.4 | 69% | 10.4 pts | 127 pts |
| monster | 1.1 | 0.2 | 82% | 5.6 pts | 6 pts |
| war machine | 8.7 | 6.6 | 61% | 24.7 pts | 215 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.2 | 5.2 | 4.7 |
| Charges that made contact a game | 3.0 | 3.8 | 3.4 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.64 declared, 0.52 contact (25 units) | 0.67 declared, 0.58 contact (12 units) | 0.65 declared, 0.54 contact (37 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.86 declared, 0.57 contact (7 units) | 1.20 declared, 0.90 contact (10 units) | 1.06 declared, 0.76 contact (17 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.52 declared, 0.37 contact (246 units) | 0.58 declared, 0.42 contact (289 units) | 0.56 declared, 0.40 contact (535 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 56% (41 of 73) | 61% (11 of 18) | 58% (7 of 12) | 57% (59 of 103) |
| Character in a unit | 86% (30 of 35) | 65% (13 of 20) | 75% (3 of 4) | 78% (46 of 59) |
| Character on its own | 78% (29 of 37) | 59% (20 of 34) | 31% (19 of 62) | 51% (68 of 133) |
| Chariot | 71% (12 of 17) | 77% (10 of 13) | - | 73% (22 of 30) |
| Infantry | 50% (47 of 94) | 59% (20 of 34) | 33% (1 of 3) | 52% (68 of 131) |
| Monster | 55% (16 of 29) | 78% (7 of 9) | - | 61% (23 of 38) |
| Monstrous | 71% (10 of 14) | 64% (9 of 14) | - | 68% (19 of 28) |
| War Machines | 72% (41 of 57) | 100% (2 of 2) | - | 73% (43 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (16 of 16); on the table 100% | 33% (34 of 102) | 52% | 68% (15 of 22) | 83% (5 of 6); 3.5 uses a game | 100% (2 of 2); 1.0 uses a game | 100% (6 of 6); 1.5 uses a game |
| Chaos Dwarfs | 4 | 75% (6 of 8); on the table 75% | 50% (18 of 36) | 41% | 66% (21 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 6 | 79% (11 of 14); on the table 86% | - | 73% | 69% (37 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 88% (14 of 16); on the table 94% | 27% (13 of 48) | 36% | 64% (49 of 76) | 0.0 uses a game | 50% (1 of 2); 0.4 uses a game | 0% (0 of 4); 0.0 uses a game |
| Grand Cathay | 6 | 100% (7 of 7); on the table 100% | 38% (52 of 138) | 46% | 50% (27 of 54) | 79% (11 of 14); 7.3 uses a game | 0% (0 of 2); 0.0 uses a game | 17% (1 of 6); 0.2 uses a game |
| High Elf Realms | 4 | 100% (5 of 5); on the table 100% | 22% (4 of 18) | 36% | 52% (17 of 33) | 100% (3 of 3); 2.0 uses a game | 29% (4 of 14); 1.2 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 82% (9 of 11); on the table 82% | - | 30% | 58% (7 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | 100% (4 of 4); on the table 100% | - | 26% | 14% (1 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 100% (13 of 13); on the table 100% | 6% (1 of 18) | 39% | 75% (21 of 28) | 100% (4 of 4); 2.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | - | 0% (0 of 12) | 0% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 3 | 29% (2 of 7); on the table 71% | 22% (4 of 18) | 24% | 52% (13 of 25) | 100% (2 of 2); 2.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Tomb Kings of Khemri | 5 | 90% (9 of 10); on the table 90% | - | 46% | 24% (6 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 95% (38 of 40); on the table 95% | 36% (24 of 66) | 28% | 63% (34 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 100% (16 of 16); on the table 100% | 39% (7 of 18) | 34% | 59% (43 of 73) | 100% (2 of 2); 0.9 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 91% (20 of 22); on the table 95% | 67% (16 of 24) | 49% | 69% (54 of 78) | 43% (3 of 7); 1.7 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (co-opp-a57fba0-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 49% (42) | 47% (35) | 48% (77) |
| ...free all their last turn and able to turn (per game) | 0.78 | 0.64 | 1.42 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.22 | 0.11 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.53 | 0.44 | 0.97 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.81 | 1.28 | 3.08 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.06 | 0.56 | 1.61 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.19 | 5.56 | 10.75 |

### Quality by phase: co-opp-a57fba0-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 47% (62 of 132) | 46% (84 of 184) |
| Strategy | Shoot objectives carried out (shot that target) | 39% (145 of 376) | 50% (129 of 260) |
| Strategy | Close-in objectives charged next turn | 14% (20 of 143) | 16% (40 of 255) |
| Strategy | Support requests answered (helper made contact too) | 91% (10 of 11) | 41% (12 of 29) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 75% (3 of 4) | 33% (1 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 60% (12 of 20) | 73% (11 of 15) |
| Strategy | Joined characters whose unit fought | 41% (23 of 56) | 27% (12 of 44) |
| Strategy | Lone characters that fought | 75% (67 of 89) | 78% (62 of 79) |
| Movement | Charges halted short of contact | 0.2 | 0.2 |
| Movement | Idle units | 1.4 | 1.6 |
| Movement | Points that never moved of their own | 321.1 | 167.8 |
| Movement | Fights charged into per game | 2.6 | 3.4 |
| Movement | Charges with odds: long shots (under 50%) | 11 of 87, net +39 | 25 of 105, net +88 |
| Movement | Charges with odds: sweet spot (55-75%) | 20 of 87, net +2 | 23 of 105, net +175 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 11 of 87, net +94 | 4 of 105, net +74 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 24 of 87, net +107 | 25 of 105, net +43 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.9 | 10.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 38% (135 of 358) | 48% (181 of 381) |
| Shooting | Points destroyed by shooting units | 132.2 | 56.3 |
| Shooting | War machine shots | 6.4 | 2.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 55% (127 of 231) | 49% (41 of 83) |
| Shooting | Points destroyed by war machines | 58.2 | 29.1 |
| Magic | Magic missiles cast | 1.8 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 31% (20 of 65) | 37% (14 of 38) |
| Magic | Wounds caused by magic missiles | 3.2 | 1.8 |
| Magic | Wounds caused by other spells | 1.4 | 1.0 |
| Magic | Points destroyed by magic (all spells) | 58.6 | 30.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.1 / 0.7 / 0.6 / 0.1 | 2.2 / 0.4 / 0.3 / 0.2 |
| Combat | Points destroyed in combat | 319.6 | 339.8 |
| Combat | Points run down | 42.4 | 175.6 |
| Combat | Net points per charged fight, damage counted | +63 | +101 |
| Combat | Net per 100 charger points, damage counted | +23.4 | +41.2 |
| Combat | First round won (charged fights) | 76% | 70% |
| Combat | Net points per charged fight | +55 | +104 |
| Combat | Net points per supported fight / lone fight | +49 / +56 | +262 / +85 |
| Combat | Charged fights on a top-3 enemy unit | 33 of 92 | 48 of 122 |
| Game | Points lost | 782.4 | 678.9 |
| Game | VP from objectives | 520.3 | 659.7 |
| Game | Lone holders (player turns) | 2.3 | 2.6 |

- Mine won / drew / lost: 12 / 8 / 16 of 36 ended games (of 36); mean margin (Mine - Opponent) -251 VP
- The side that went first won 18 of 28 games with a winner
- Points traded per game (both sides' losses): 1461
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: co-opp-a57fba0-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 5.3 | -129.2 | 245.4 | 90.2 | 4.5 | -184.4 | 186.4 | 60.1 |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +4.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.2 | +0.0 | 0.0 | 46.7 | 0.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.7 | +3.8 | 0.0 | 24.0 | 0.5 | +4.0 | 0.0 | 24.3 |
| BEST FACING | 0.4 | +20.1 | 0.0 | 21.9 | 0.2 | +11.2 | 0.0 | 33.6 |
| BEST FIRST | 1.4 | +72.2 | 24.9 | 27.4 | 0.9 | +38.9 | 27.3 | 16.6 |
| BEST OVERALL | 0.4 | +17.3 | 0.0 | 12.9 | 0.2 | +18.8 | 0.0 | 16.0 |
| BEST PREY | 0.7 | +49.7 | 50.2 | 36.2 | 0.8 | +39.2 | 13.7 | 23.2 |
| BEST PRIZE | - | - | - | - | 0.0 | -2.1 | 8.6 | 0.0 |
| BIG CHARACTER SAFETY | 0.1 | +0.4 | 0.0 | 21.4 | 0.1 | +0.0 | 0.0 | 12.9 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 1.1 | 0.2 | +0.0 | 17.4 | 6.5 |
| BLOCKED WHEEL | 0.3 | +1.7 | 0.0 | 0.0 | 0.5 | +12.9 | 0.0 | 16.6 |
| BLOWS WHERE AIMED | 0.1 | -8.1 | 22.5 | 15.0 | 0.3 | -41.4 | 44.9 | 1.9 |
| BOMBING RUN | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 6.8 | - | - | - | - |
| BREAK OUTCOMES | - | - | - | - | 3.6 | +3.7 | 344.4 | 110.8 |
| CANNON PLAN MISSED | 0.8 | +0.0 | 130.4 | 19.3 | 0.2 | +0.0 | 11.1 | 0.0 |
| CANNON PLANNED TARGET | 5.0 | +205.3 | 480.3 | 127.1 | 1.9 | +63.8 | 61.2 | 6.9 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 2.5 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.0 | +0.0 | 5.8 | 0.0 | 0.2 | +0.0 | 50.0 | 5.6 |
| CAST JOB | 0.7 | +17.5 | 23.5 | 5.5 | 0.4 | +10.6 | 33.8 | 25.4 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.6 | +37.9 | 23.8 | 0.0 | 0.3 | +11.8 | 11.5 | 0.0 |
| CASTS AFTER FRIENDS | 0.5 | +0.0 | 0.0 | 2.6 | 0.3 | +0.0 | 0.0 | 16.5 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +2.3 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | - | - | - | - | 0.0 | +0.4 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.8 | +44.4 | 0.0 | 16.7 | 1.9 | +91.9 | 0.0 | 53.6 |
| CHAFF PASSED | 0.1 | -0.1 | 0.0 | 11.0 | 0.4 | -0.5 | 0.0 | 14.0 |
| CHAMPION TAKES THE CHALLENGE | 0.0 | +0.3 | 5.6 | 15.0 | - | - | - | - |
| CHARGE NOW FIRST | 2.5 | +0.0 | 192.5 | 66.3 | 2.5 | +0.0 | 303.2 | 79.8 |
| CHARGE NOW WEIGHED | 0.5 | -21.9 | 21.0 | 11.7 | 0.6 | -87.6 | 35.4 | 36.4 |
| CHARGER SLAIN LOST | 0.4 | -5.5 | 53.2 | 34.9 | 0.5 | -7.2 | 32.4 | 18.7 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHEAP HELPER | 0.0 | +0.0 | 0.0 | 1.7 | 0.1 | +0.0 | 6.1 | 0.0 |
| COMBAT PIVOT | 0.4 | +0.0 | 30.6 | 17.2 | 0.3 | +0.0 | 9.7 | 26.2 |
| CONVEYANCE SEARCH | 0.4 | +55.9 | 0.0 | 12.5 | 0.4 | +42.2 | 22.8 | 29.4 |
| COVER ONCE | 8.8 | -678.3 | 0.0 | 198.1 | 6.4 | -528.5 | 0.0 | 169.5 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 3.1 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.0 | +0.8 | 0.0 | 5.2 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +1.7 | 11.1 | 0.0 | 0.5 | +11.3 | 43.2 | 7.1 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.8 | +104.8 | 0.0 | 50.7 | 1.3 | +127.0 | 0.0 | 49.2 |
| FALLBACK BY WORTH | 4.3 | +43.7 | 0.0 | 61.1 | 4.9 | +41.7 | 0.0 | 85.3 |
| FIGHT LIFT | 0.1 | +0.2 | 2.9 | 0.0 | 0.1 | +3.7 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.0 | +3.0 | 0.0 | 0.0 | 0.1 | +0.8 | 4.2 | 2.2 |
| FLANK NOT WEIGHED | 5.2 | +0.0 | 0.0 | 90.9 | 4.9 | +0.0 | 0.0 | 206.2 |
| FLEES FROM CHARGE | - | - | - | - | 0.4 | +4.0 | 18.8 | 12.0 |
| FOCUS FIRE | 0.1 | +4.9 | 3.1 | 0.0 | 0.0 | +0.4 | 1.5 | 0.0 |
| FOLLOW UP WEIGHED | 1.1 | +123.5 | 0.0 | 57.0 | 1.0 | +149.7 | 0.0 | 18.6 |
| FRIENDS SHOTS CHECKED | 0.2 | +8.1 | 0.0 | 6.5 | 0.1 | +9.0 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -0.9 | 7.0 | 7.9 | 0.2 | -1.6 | 27.6 | 0.8 |
| GIVES UP ITS SCREEN | 0.0 | -0.2 | 5.4 | 0.0 | 0.0 | -0.0 | 3.4 | 0.0 |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 3.1 | 6.8 | 0.1 | +0.0 | 8.4 | 2.8 |
| HELPER UNSEEN | 0.2 | +0.0 | 8.9 | 8.6 | 0.6 | +0.0 | 48.0 | 14.5 |
| HILL BY ITS CHANCE | 0.3 | -37.8 | 0.0 | 6.5 | 0.5 | -51.9 | 0.0 | 3.8 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.4 | -113.6 | 287.9 | 147.4 | 10.0 | -204.7 | 711.5 | 303.8 |
| HORN WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.0 | +0.2 | 0.0 | 0.0 | 0.5 | +5.2 | 24.7 | 0.0 |
| HUNT DROPPED | - | - | - | - | 0.2 | +0.0 | 17.8 | 0.0 |
| HUNT IN PAIRS | 0.3 | +21.8 | 0.0 | 0.0 | 0.7 | +44.7 | 0.0 | 59.7 |
| HUNT KEPT | 0.1 | +0.5 | 10.8 | 0.0 | 0.4 | +5.3 | 27.4 | 0.0 |
| HUNT RESULT | 0.0 | +5.9 | 0.0 | 0.0 | 0.4 | +75.7 | 26.9 | 2.8 |
| HUNT THE GUNS | 0.0 | +6.5 | 0.0 | 0.0 | 0.5 | +147.9 | 26.9 | 1.8 |
| IDLE COST | 14.4 | -231.7 | 0.0 | 144.9 | 19.4 | -309.4 | 0.0 | 244.5 |
| INVITES THE FIGHT | 1.1 | +8.6 | 64.8 | 21.4 | 0.8 | +5.4 | 56.8 | 9.7 |
| JOINT CHARGE PLAN | 0.0 | +1.3 | 0.0 | 0.0 | 0.1 | +2.9 | 0.0 | 7.7 |
| JOINT KNOWS CHALLENGE | 0.1 | -4.0 | 8.9 | 21.8 | 0.1 | -1.2 | 11.1 | 12.1 |
| KEEP FALLS | 0.1 | +1.5 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | - | - | - | - | 0.1 | +0.4 | 5.9 | 0.0 |
| KEEPS ITS TARGET | 1.4 | +41.7 | 112.1 | 53.4 | 2.3 | +70.0 | 181.4 | 88.8 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 1.9 | +89.8 | 106.5 | 39.8 | - | - | - | - |
| KILLS COUNT NEXT TURN | 5.1 | +208.0 | 170.7 | 89.9 | 7.0 | +265.2 | 386.4 | 223.9 |
| LONE CHARACTER SAFE SPOT | 0.3 | +24.7 | 20.7 | 0.0 | 0.3 | +18.8 | 16.4 | 21.8 |
| LONE WIZARD HOLDS BACK | 0.2 | +0.0 | 0.0 | 2.4 | 0.2 | +0.0 | 1.7 | 16.6 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +23.5 | 0.0 | 0.0 |
| LONG SHOT | 0.8 | -0.9 | 37.6 | 24.2 | 0.6 | +1.5 | 34.3 | 12.4 |
| LOST CHARGE | 2.7 | -53.1 | 54.4 | 118.6 | 2.1 | -36.4 | 48.6 | 106.5 |
| LURE BY WHAT IT DRAWS | 0.2 | -14.7 | 0.0 | 4.0 | 0.4 | -37.0 | 0.0 | 15.4 |
| MAKE SURE TOGETHER | 0.3 | +9.8 | 1.8 | 18.2 | 0.6 | +48.6 | 45.7 | 5.9 |
| MANOEUVRE | 0.3 | +12.0 | 0.0 | 1.0 | 0.2 | +4.0 | 0.0 | 2.8 |
| MARCH AT ESCAPER | - | - | - | - | 0.1 | +0.1 | 0.0 | 0.0 |
| MARCH CHECK | 0.5 | +11.3 | 0.0 | 15.0 | 0.4 | +12.5 | 0.0 | 0.0 |
| MARCH ODDS | 0.3 | +30.5 | 6.3 | 0.0 | 0.1 | +9.6 | 10.2 | 5.7 |
| MARCH OVER CASTS | 0.4 | +49.5 | 0.0 | 24.2 | 0.1 | +11.5 | 0.0 | 12.1 |
| MAX FOR POSITIONING | 6.3 | +90.7 | 0.0 | 156.1 | 6.2 | +88.1 | 0.0 | 175.1 |
| MISSILES IN THE MOVE | 4.1 | +104.7 | 0.0 | 88.9 | 3.2 | +63.6 | 0.0 | 69.1 |
| MISSILES NEXT TURN | 4.7 | +73.2 | 0.0 | 124.2 | 3.6 | +42.1 | 0.0 | 97.6 |
| MODEL FACING | 0.2 | +54.5 | 0.0 | 3.3 | 0.2 | +79.9 | 0.0 | 3.3 |
| MONSTER WIZARD ROAMS | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 19.9 | 0.0 |
| MOVE AND CAST | 0.3 | +7.5 | 0.0 | 4.5 | 0.3 | +13.8 | 0.0 | 16.2 |
| MOVE SPELL IN RANGE | 0.1 | +5.5 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -14.1 | 6.9 | 11.2 | 0.3 | -4.7 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 2.7 | +139.3 | 78.8 | 96.0 | 5.5 | +366.5 | 311.0 | 197.6 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +11.7 | 0.0 | 0.0 |
| NOT NEEDED | 0.3 | -7.9 | 21.9 | 4.2 | 0.3 | -14.2 | 44.8 | 4.6 |
| NOT TURNED | 5.2 | +82.6 | 0.0 | 84.9 | 5.6 | +97.5 | 0.0 | 169.9 |
| NOT WORTH A CAST | 0.4 | -0.3 | 0.0 | 15.0 | 0.7 | -0.5 | 0.0 | 0.0 |
| OFF BEST | 15.8 | -637.1 | 0.0 | 278.1 | 17.0 | -800.2 | 6.7 | 278.6 |
| ONE FIGHT FORMULA | 9.0 | -142.3 | 63.5 | 213.7 | 8.7 | -189.5 | 56.8 | 271.7 |
| ONE OBJECTIVE FORMULA | 1.7 | -97.5 | 0.0 | 24.4 | 2.2 | -145.8 | 0.0 | 32.3 |
| OPENS A LANE | 0.3 | +1.8 | 23.2 | 3.5 | 0.1 | +0.1 | 0.0 | 0.0 |
| OPENS UP | 0.1 | +6.0 | 6.8 | 7.9 | 0.2 | +9.1 | 12.3 | 12.0 |
| OVERRUN ON | - | - | - | - | 0.6 | +15.7 | 47.3 | 28.2 |
| OVERRUN THREAT | - | - | - | - | 0.0 | +0.5 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.4 | +9.5 | 18.9 | 12.1 | 0.5 | +3.9 | 33.7 | 22.9 |
| PATHS CROSS | 2.0 | +121.7 | 0.0 | 23.7 | 2.9 | +175.2 | 0.0 | 105.1 |
| PERIAPT WORTH | 0.1 | +3.4 | 0.0 | 0.0 | 0.0 | +2.0 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.9 | 0.0 | 2.7 | 0.1 | -0.3 | 0.0 | 0.0 |
| PLAN RESULT | 36.8 | +1566.7 | 1503.3 | 1038.5 | 41.2 | +1159.0 | 1591.7 | 941.1 |
| PURSUES BIG PREY | 0.0 | -2.9 | 0.0 | 0.0 | 0.1 | -9.8 | 0.0 | 13.9 |
| PURSUES ON | - | - | - | - | 0.0 | +0.5 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +5.0 | 0.0 | 3.4 | 0.0 | +2.4 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.6 | +8.8 | 0.0 | 25.1 | 1.4 | +34.5 | 0.0 | 46.2 |
| RANDOM MOVER NO PROMISE | 0.1 | -2.4 | 4.0 | 9.4 | 0.1 | -1.6 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.4 | -11.2 | 0.0 | 11.4 | 1.0 | -33.9 | 0.0 | 30.8 |
| REDIRECT COUNTER | 2.3 | +144.6 | 0.0 | 33.6 | 3.6 | +289.0 | 0.0 | 68.9 |
| REDIRECT WEIGHED | 0.1 | +0.2 | 0.0 | 0.0 | 0.3 | +14.0 | 14.7 | 20.3 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 21.7 |
| RESERVE FALL BACK | 0.3 | +7.9 | 0.0 | 0.0 | 0.9 | +18.4 | 0.0 | 27.6 |
| RESTRAINS TO SHOOT | 0.1 | +4.8 | 0.0 | 0.0 | 0.0 | +0.9 | 0.0 | 0.0 |
| RISK BY ARC | 2.3 | +86.7 | 169.9 | 81.8 | 3.0 | +62.6 | 271.3 | 91.9 |
| RISK ONCE | 4.1 | +75.4 | 34.2 | 142.0 | 4.0 | +166.4 | 79.0 | 266.0 |
| SAFE SURE CHARGE | - | - | - | - | 0.0 | -1.0 | 0.0 | 0.0 |
| SAFER THAN THE JOB | 1.1 | +38.7 | 0.0 | 33.4 | 0.6 | +38.6 | 0.0 | 19.5 |
| SCOUT SPOT | 0.3 | +0.9 | 0.0 | 0.0 | 0.5 | +2.4 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | -5.0 | 0.0 | 1.2 | 0.6 | -39.0 | 0.0 | 6.8 |
| SEARCH SPOT | 2.1 | +113.5 | 0.0 | 33.9 | 2.5 | +94.6 | 0.0 | 73.3 |
| SECOND HUNTER | - | - | - | - | 0.2 | -0.7 | 11.9 | 1.8 |
| SELF MOVE SPELL | 0.2 | +10.0 | 0.0 | 0.0 | - | - | - | - |
| SET UP TOGETHER | 0.5 | +11.7 | 1.8 | 27.5 | 2.1 | +153.4 | 72.2 | 98.9 |
| SET-UP ANY TARGET | 0.2 | +32.6 | 0.0 | 0.0 | 0.2 | +14.5 | 7.9 | 11.2 |
| SET-UP MISSED | - | - | - | - | 0.0 | +5.6 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.1 | -0.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.2 | +42.0 | 45.8 | 1.8 | 0.8 | +21.3 | 31.5 | 5.7 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.9 | +0.0 | 182.4 | 22.3 | 0.3 | +0.0 | 18.7 | 1.7 |
| SHOTS IN THE MOVE | 13.3 | +603.0 | 0.0 | 280.7 | 11.7 | +328.2 | 0.0 | 158.9 |
| SPELL SETS UP CHARGE | 0.2 | +48.2 | 0.0 | 0.0 | 0.2 | +22.0 | 7.9 | 11.2 |
| SPELL WORTH | 0.9 | +19.1 | 91.4 | 92.9 | 1.6 | +32.3 | 52.7 | 52.7 |
| SPELLS IN THE FIGHT | 0.5 | +5.6 | 72.2 | 36.7 | 0.6 | -8.7 | 81.9 | 11.5 |
| STABLE ROLE | 10.9 | +0.0 | 461.4 | 141.3 | 11.8 | +0.0 | 386.4 | 141.6 |
| STAND AND SHOOT | - | - | - | - | 0.5 | -11.3 | 17.5 | 17.0 |
| STANDS TO CAST | 0.1 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| STAY WEIGHED | - | - | - | - | 0.1 | +2.4 | 0.0 | 0.0 |
| STOPS | 0.0 | +0.5 | 5.4 | 0.0 | 0.2 | +10.3 | 20.3 | 1.8 |
| STOPS SHORT OF THE FLANK | 0.4 | +17.9 | 0.0 | 26.9 | 0.2 | +10.1 | 0.0 | 16.3 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 14.6 |
| SUPPORT NARROWED | 7.0 | -67.9 | 353.0 | 143.4 | 8.7 | -84.2 | 446.8 | 118.9 |
| SUPPORTS | 4.7 | +75.9 | 201.2 | 75.7 | 6.2 | +88.5 | 201.0 | 60.8 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -1.2 | 4.4 | 0.0 | 0.2 | -3.1 | 14.0 | 0.0 |
| SURE REACH TOGETHER | 0.4 | +0.2 | 2.2 | 11.9 | 0.8 | -1.2 | 7.8 | 7.7 |
| THROUGH LINE OF FIRE | 0.2 | +3.3 | 0.0 | 0.0 | 0.3 | +17.2 | 0.0 | 12.0 |
| TURN WORTH | 0.3 | -21.3 | 22.9 | 5.6 | 0.2 | -9.5 | 16.2 | 2.9 |
| TWO OR MORE ARRIVE | 0.1 | +1.9 | 0.0 | 7.9 | 0.3 | +1.3 | 11.7 | 4.2 |
| WAIT AFTER COSTS | 5.9 | -287.7 | 182.0 | 129.1 | 8.5 | -414.2 | 473.2 | 263.2 |
| WALKS TO THE FIGHT | 1.6 | +14.4 | 41.7 | 8.5 | 1.3 | +7.1 | 39.1 | 27.2 |
| WAR ENGINE CHARGES | 0.1 | +14.1 | 7.1 | 0.0 | 0.1 | +6.7 | 0.0 | 5.1 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 43.4 | 19.7 | 0.5 | +0.0 | 43.3 | 14.3 |
| WEARS DOWN | 1.0 | +38.2 | 82.6 | 39.5 | 1.6 | +49.9 | 160.4 | 65.7 |
| WHO HITS BACK | 0.2 | +6.7 | 0.0 | 24.6 | 0.2 | +14.9 | 0.0 | 17.6 |
| WHOLE FIGHT | 0.3 | +11.2 | 38.1 | 18.3 | 0.2 | +13.5 | 49.5 | 7.9 |
| WHOLE FIGHT GAIN | 0.3 | +21.5 | 28.4 | 13.2 | 0.7 | +62.2 | 50.1 | 12.9 |
| WIDER SPREAD | 2.2 | -8.5 | 172.9 | 82.2 | 3.2 | -4.4 | 317.8 | 70.1 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |

### Rule changes: co-opp-a57fba0-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1181 | 1181 | 1181 | 32.81 | -51740 | -43.8 |
| PATHS CROSS | 176 | 176 | 176 | 4.89 | +10687 | +60.7 |
| SEARCH SPOT | 166 | 166 | 160 | 4.44 | +7503 | +46.9 |
| SUPPORTS | 391 | 391 | 156 | 4.33 | +2150 | +13.8 |
| MOVE TO CHARGE | 293 | 293 | 154 | 4.28 | +5951 | +38.6 |
| KILLS COUNT NEXT TURN | 435 | 435 | 150 | 4.17 | +5011 | +33.4 |
| FACES THE THREAT | 111 | 111 | 111 | 3.08 | +8344 | +75.2 |
| SHOTS IN THE MOVE | 900 | 609 | 96 | 2.67 | +2424 | +25.2 |
| BEST FIRST | 83 | 83 | 83 | 2.31 | +3999 | +48.2 |
| WAIT AFTER COSTS | 520 | 520 | 83 | 2.31 | +1623 | +19.6 |
| COVER ONCE | 546 | 314 | 76 | 2.11 | +1203 | +15.8 |
| FOLLOW UP WEIGHED | 75 | 75 | 75 | 2.08 | +9836 | +131.1 |
| FALLBACK BY WORTH | 332 | 332 | 74 | 2.06 | +3075 | +41.6 |
| CANNON SIGHT KEPT | 70 | 70 | 70 | 1.94 | +0 | +0.0 |
| ADVANCE WORTH | 352 | 352 | 62 | 1.72 | +1263 | +20.4 |
| CHAFF IN THE MOVE | 98 | 90 | 61 | 1.69 | +1542 | +25.3 |
| SAFER THAN THE JOB | 58 | 58 | 58 | 1.61 | +2783 | +48.0 |
| RISK ONCE | 291 | 194 | 55 | 1.53 | +2244 | +40.8 |
| ARTILLERY RE-ROLL WEIGHED | 51 | 51 | 51 | 1.42 | +0 | +0.0 |
| IDLE COST | 1219 | 707 | 48 | 1.33 | +563 | +11.7 |
| MISSILES IN THE MOVE | 262 | 161 | 48 | 1.33 | +1129 | +23.5 |
| WALKS TO THE FIGHT | 104 | 104 | 47 | 1.31 | +270 | +5.7 |
| RESERVE FALL BACK | 46 | 46 | 46 | 1.28 | +949 | +20.6 |
| ONE FIGHT FORMULA | 639 | 372 | 45 | 1.25 | +142 | +3.2 |
| RANDOM MOVE BY FIGURES | 71 | 71 | 45 | 1.25 | +1558 | +34.6 |
| REDIRECT COUNTER | 211 | 102 | 45 | 1.25 | +3379 | +75.1 |
| ADVANCE LANE KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| CANNON PLANNED TARGET | 248 | 248 | 42 | 1.17 | -166 | -4.0 |
| SET UP TOGETHER | 93 | 79 | 41 | 1.14 | +2308 | +56.3 |
| SHOT REPLANNED | 41 | 41 | 41 | 1.14 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 40 | 40 | 40 | 1.11 | +4206 | +105.2 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| HONEST WORTH | 625 | 624 | 37 | 1.03 | +352 | +9.5 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2266 | +68.7 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| MARCH CHECK | 32 | 32 | 31 | 0.86 | +1361 | +43.9 |
| RISK BY ARC | 193 | 190 | 31 | 0.86 | +783 | +25.3 |
| CHARGE NOW FIRST | 180 | 180 | 30 | 0.83 | -1129 | -37.6 |
| BLOCKED WHEEL | 27 | 27 | 27 | 0.75 | +523 | +19.4 |
| COMBAT PIVOT | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| BEST FACING | 25 | 25 | 25 | 0.69 | +1127 | +45.1 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +50 | +2.0 |
| SHOOTS FROM THE BEST SPOT | 72 | 72 | 25 | 0.69 | +794 | +31.7 |
| BEST OVERALL | 23 | 23 | 23 | 0.64 | +1300 | +56.5 |
| MAX FOR POSITIONING | 451 | 270 | 23 | 0.64 | +51 | +2.2 |
| WHOLE FIGHT GAIN | 36 | 35 | 23 | 0.64 | +828 | +36.0 |
| INVITES THE FIGHT | 69 | 69 | 22 | 0.61 | +175 | +7.9 |
| STOPS SHORT OF THE FLANK | 22 | 22 | 22 | 0.61 | +1006 | +45.7 |
| MOVE AND CAST | 21 | 21 | 21 | 0.58 | +766 | +36.5 |
| BEST PREY | 51 | 51 | 20 | 0.56 | +1082 | +54.1 |
| CASTING BLOCK | 33 | 33 | 20 | 0.56 | +841 | +42.1 |
| MODEL FACING | 18 | 18 | 18 | 0.50 | +4839 | +268.8 |
| CHAFF PASSED | 17 | 17 | 17 | 0.47 | -22 | -1.3 |
| KILLS COUNT | 67 | 67 | 17 | 0.47 | +938 | +55.2 |
| MARCH ODDS | 17 | 17 | 17 | 0.47 | +362 | +21.3 |
| WAR ENGINE JOBS | 41 | 41 | 17 | 0.47 | -923 | -54.3 |
| CAST JOB | 40 | 40 | 16 | 0.44 | +249 | +15.6 |
| CASTER AWAY FROM SCREEN | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 16 | 16 | 16 | 0.44 | +739 | +46.2 |
| WEARS DOWN | 93 | 93 | 16 | 0.44 | +509 | +31.8 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| REDIRECT WEIGHED | 14 | 14 | 14 | 0.39 | +1034 | +73.8 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| KEEPS ITS TARGET | 134 | 134 | 13 | 0.36 | +220 | +17.0 |
| MANOEUVRE | 17 | 17 | 13 | 0.36 | +573 | +44.1 |
| WHO HITS BACK | 13 | 13 | 13 | 0.36 | +484 | +37.3 |
| STUCK PIVOT | 12 | 12 | 12 | 0.33 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 11 | 11 | 11 | 0.31 | +613 | +55.8 |
| HUNT IN PAIRS | 36 | 25 | 11 | 0.31 | +547 | +49.7 |
| BLOCKED CHARGE SKIPPED | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| SUPPORT NARROWED | 565 | 565 | 10 | 0.28 | -96 | -9.6 |
| REFUSING RETIRES | 26 | 26 | 9 | 0.25 | -3 | -0.4 |
| LOST CHARGE | 172 | 172 | 8 | 0.22 | +153 | +19.1 |
| MISSILES NEXT TURN | 298 | 174 | 8 | 0.22 | +36 | +4.5 |
| SURE CHARGE BEATS ADVANCE | 8 | 8 | 8 | 0.22 | -153 | -19.1 |
| BIG CHARACTER SAFETY | 5 | 5 | 5 | 0.14 | +14 | +2.9 |
| BREAK OUTCOMES | 130 | 129 | 5 | 0.14 | +82 | +16.5 |
| MAKE SURE TOGETHER | 34 | 20 | 5 | 0.14 | +401 | +80.3 |
| ONE OBJECTIVE FORMULA | 140 | 76 | 5 | 0.14 | +84 | +16.9 |
| OPENS UP | 9 | 9 | 5 | 0.14 | +91 | +18.1 |
| PIVOT GUARDS FLANK | 5 | 5 | 5 | 0.14 | -81 | -16.3 |
| RESTRAINS TO SHOOT | 5 | 5 | 5 | 0.14 | +207 | +41.3 |
| WIDER SPREAD | 198 | 193 | 5 | 0.14 | +23 | +4.7 |
| DEFENSIVE ARMY | 8 | 8 | 4 | 0.11 | -151 | -37.8 |
| FLEES FROM CHARGE | 13 | 13 | 4 | 0.11 | +94 | +23.5 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| OVERRUNS AWAY | 32 | 32 | 4 | 0.11 | +61 | +15.3 |
| PURSUES BIG PREY | 4 | 4 | 4 | 0.11 | -456 | -114.1 |
| BOMBING RUN | 3 | 3 | 3 | 0.08 | +122 | +40.8 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.08 | +136 | +45.4 |
| FOCUS FIRE | 3 | 3 | 3 | 0.08 | +189 | +63.0 |
| LONG SHOT | 53 | 52 | 3 | 0.08 | +120 | +40.1 |
| NEEDED THERE | 4 | 4 | 3 | 0.08 | +0 | +0.0 |
| OVERRUN ON | 22 | 21 | 3 | 0.08 | +133 | +44.2 |
| PERIAPT WORTH | 3 | 3 | 3 | 0.08 | +194 | +64.7 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 3 | 0.08 | +214 | +71.4 |
| WHOLE FIGHT | 21 | 21 | 3 | 0.08 | +196 | +65.3 |
| BLOWS WHERE AIMED | 17 | 17 | 2 | 0.06 | +66 | +33.2 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.06 | +0 | +0.2 |
| CHARIOT NO STATIC JOB | 2 | 2 | 2 | 0.06 | -274 | -137.2 |
| HUNT ADVANCE | 20 | 20 | 2 | 0.06 | +16 | +8.0 |
| KEEP FALLS | 2 | 2 | 2 | 0.06 | +111 | +55.6 |
| LONE WIZARD HOLDS BACK | 17 | 17 | 2 | 0.06 | +0 | +0.0 |
| SPELLS IN THE FIGHT | 37 | 36 | 2 | 0.06 | +49 | +24.4 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| STAY WEIGHED | 2 | 2 | 2 | 0.06 | +87 | +43.7 |
| SURE REACH TOGETHER | 42 | 29 | 2 | 0.06 | +0 | +0.0 |
| BACKUP TARGETS | 43 | 26 | 1 | 0.03 | +1 | +0.7 |
| BEST PRIZE | 1 | 1 | 1 | 0.03 | -74 | -74.5 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -5 | -4.7 |
| EDGE GIVE GROUND | 24 | 23 | 1 | 0.03 | +1 | +1.3 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +3 | +3.0 |
| JOINT CHARGE PLAN | 6 | 6 | 1 | 0.03 | +62 | +61.6 |
| KEEPS ITS PREY | 3 | 3 | 1 | 0.03 | +0 | +0.0 |
| MOVE SPELL IN RANGE | 4 | 2 | 1 | 0.03 | +1 | +1.1 |
| OPENS A LANE | 12 | 7 | 1 | 0.03 | +11 | +11.3 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +18 | +18.5 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -28 | -27.5 |
| STOPS | 10 | 9 | 1 | 0.03 | +10 | +10.4 |
| TWO OR MORE ARRIVE | 15 | 15 | 1 | 0.03 | +10 | +10.5 |
| WAR ENGINE CHARGES | 7 | 7 | 1 | 0.03 | +1 | +1.2 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.03 | -136 | -135.9 |
| ARRIVAL HUNT | 4 | 4 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 38 | 38 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 2 | 2 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 10 | 10 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 27 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 35 | 34 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 2 | 2 | 0 | 0.00 | - | - |
| CHEAP HELPER | 6 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 32 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 363 | not checked | - | - | - | - |
| GIVES UP | 9 | 8 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 6 | not checked | - | - | - | - |
| HELPER UNSEEN | 26 | 24 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 31 | 31 | 0 | 0.00 | - | - |
| HUNT DROPPED | 7 | trace | - | - | - | - |
| HUNT KEPT | 15 | trace | - | - | - | - |
| HUNT RESULT | 17 | trace | - | - | - | - |
| HUNT THE GUNS | 20 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 8 | 8 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 21 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 22 | 22 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 19 | 19 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 5 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 22 | trace | - | - | - | - |
| MOVE SPELL SPOT | 10 | not checked | - | - | - | - |
| NOT NEEDED | 22 | 22 | 0 | 0.00 | - | - |
| NOT TURNED | 387 | 387 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 40 | not checked | - | - | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 2809 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 4 | 4 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 53 | 53 | 0 | 0.00 | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 26 | 26 | 0 | 0.00 | - | - |
| SECOND HUNTER | 6 | 6 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 7 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 13 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 15 | not checked | - | - | - | - |
| SPELL WORTH | 90 | not checked | - | - | - | - |
| STABLE ROLE | 819 | 818 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 18 | 18 | 0 | 0.00 | - | - |
| TURN WORTH | 18 | 18 | 0 | 0.00 | - | - |

### Off best figure: co-opp-a57fba0-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.11 | 15.86 | 44.1 |
| FALLBACK | gate | 0.67 | 0.53 | 41.5 |
| CHARGE NOW FIRST | rule | 0.39 | 0.44 | 37.6 |
| TURN GATE | gate | 0.44 | 0.28 | 44.9 |
| WAR ENGINE JOBS | rule | 0.25 | 0.22 | 54.3 |
| CANNON PLANNED TARGET | rule | 0.31 | 0.03 | 18.4 |
| AFTERMATH BAND | gate | 0.25 | 0.06 | 2.5 |
| SUPPORT NARROWED | rule | 0.22 | 0.06 | 9.6 |
| FIGHT ORDER BAND | gate | 0.19 | 0.06 | 1.9 |
| SURE CHARGE BEATS ADVANCE | rule | 0.06 | 0.17 | 19.1 |
| CHAFF PASSED | rule | 0.03 | 0.17 | 3.1 |
| LONE CHARACTER SAFE SPOT | gate | 0.06 | 0.11 | 30.0 |
| PIVOT GUARDS FLANK | rule | 0.08 | 0.06 | 16.3 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.06 | 88.1 |
| DEFENSIVE ARMY | rule | 0.03 | 0.08 | 37.8 |
| PURSUES BIG PREY | rule | 0.03 | 0.08 | 114.1 |
| SUPPORT REQUEST | gate | - | 0.11 | 128.9 |
| BLOCKED WHEEL | rule | 0.03 | 0.06 | 38.8 |
| PATHS CROSS | rule | 0.03 | 0.06 | 38.8 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | - | 81.1 |
| CHARIOT NO STATIC JOB | rule | 0.06 | - | 137.2 |
| FRIENDS SHOTS CHECKED | rule | 0.06 | - | 3.1 |
| REFUSING RETIRES | rule | 0.06 | - | 0.8 |
| THROUGH LINE OF FIRE | rule | 0.03 | 0.03 | 2.9 |
| BEST PRIZE | rule | - | 0.03 | 74.5 |
| BIG CHARACTER SAFETY | rule | 0.03 | - | 0.7 |
| CATCH ODDS | rule | - | 0.03 | 4.7 |
| FOLLOW UP WEIGHED | rule | 0.03 | - | 1.2 |
| MARCH ODDS | rule | - | 0.03 | 2.7 |
| MOVE AND CAST | rule | - | 0.03 | 4.6 |
| RULE SWITCHED OFF | gate | 0.03 | - | 316.2 |
| SAFE SURE CHARGE | rule | - | 0.03 | 27.5 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | - | 0.7 |
| WOUNDED STAYS OUT | rule | - | 0.03 | 135.9 |

### Plans: co-opp-a57fba0-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 10.0 | 18% | 249 | 362 | 146% |
| Mine | charge | 3.1 | 57% | 215 | 248 | 115% |
| Mine | close in | 4.0 | 20% | 195 | 120 | 62% |
| Mine | hold | 4.9 | 29% | 331 | 0 | 0% |
| Mine | join | 0.6 | 91% | 21 | 0 | 0% |
| Mine | shoot | 8.7 | 67% | 306 | 836 | 273% |
| Mine | support | 5.4 | 89% | 55 | 0 | 0% |
| Opponent | advance | 11.1 | 15% | 133 | 256 | 192% |
| Opponent | charge | 4.4 | 54% | 410 | 423 | 103% |
| Opponent | close in | 7.1 | 25% | 435 | 203 | 47% |
| Opponent | hold | 4.4 | 47% | 304 | 0 | 0% |
| Opponent | join | 0.9 | 97% | 41 | 0 | 0% |
| Opponent | shoot | 5.6 | 51% | 154 | 276 | 179% |
| Opponent | support | 7.7 | 91% | 74 | 0 | 0% |

### Packages: hunt the guns, co-opp-a57fba0-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 100% | 100% | 0% | 4.0 | 233 | 214 | 100% | 31 |
| Opponent | 0.5 | 19 | 3 | 38% | 56% | 0% | 2.3 | 297 | 170 | 56% | 87 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 34 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 92 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 78 |
| Empire of Man | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 142 | 0 | 0% | 58 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 143 |
| High Elf Realms | 0.2 | 1 | 0 | 100% | 100% | 0% | 4.0 | 233 | 214 | 100% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 236 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.2 | 5 | 0 | 80% | 80% | 0% | 2.5 | 489 | 341 | 80% | 160 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 48 |
| Tomb Kings of Khemri | 1.8 | 9 | 2 | 14% | 57% | 0% | 2.2 | 128 | 60 | 57% | 0 |
| Vampire Counts | 0.1 | 1 | 1 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 15 |
| Wood Elf Realms | 0.4 | 3 | 0 | 33% | 33% | 0% | 2.0 | 423 | 200 | 33% | 87 |

### Battle groups: co-opp-a57fba0-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.3 | 19% | 62% | 0% | - | 25% | 0% | 12% | 62% | 0% |
| Opponent | REDIRECT COUNTER | 3.6 | 22% | 68% | 7% | 0% | 23% | 4% | 12% | 54% | 8% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: co-opp-a57fba0-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 49 (5) | 49 | 0 | 84 | 0% | 3.8 | 0 (1) | 49 (3) | - | 64 (3) | 0 (1) |
| Mine | Chaff | 34 | 84 (34) | 50 | 34 | 56 | 44% | 2.6 | 75 (19) | 202 (7) | 5 (8) | 119 (23) | 5 (11) |
| Mine | Character | 123 | 52 (123) | 52 | 0 | 35 | 20% | 2.6 | 54 (38) | 62 (54) | 3 (15) | 62 (52) | 46 (55) |
| Mine | Clean-up | 21 | 39 (21) | 7 | 32 | 30 | 57% | 2.7 | 29 (5) | 43 (13) | 47 (3) | 74 (13) | 3 (8) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 48 | 44 (48) | 20 | 24 | 43 | 23% | 2.7 | 31 (23) | 71 (16) | 38 (9) | 48 (29) | 38 (19) |
| Mine | Fragile | 5 | 105 (5) | 105 | 0 | 40 | 20% | 1.8 | - | 87 (3) | 131 (2) | 105 (5) | - |
| Mine | Hammer | 57 | 26 (57) | 14 | 12 | 47 | 16% | 2.5 | 9 (18) | 38 (29) | 22 (10) | 24 (38) | 30 (19) |
| Mine | Holder | 28 | 62 (28) | 4 | 58 | 41 | 39% | 2.9 | 55 (10) | 108 (9) | 9 (9) | 84 (19) | 16 (9) |
| Mine | Shooter | 41 | 97 (41) | 52 | 45 | 47 | 2% | 1.4 | 96 (5) | 105 (30) | 60 (6) | 127 (25) | 50 (16) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 34 | 100% | - | - | 0 (2) | - | - | 0 (2) |
| Mine | War machine | 59 | 44 (59) | 44 | 0 | 57 | 2% | 1.2 | 0 (10) | 54 (37) | 42 (12) | 0 (10) | 52 (49) |
| Mine | Wizard | 22 | 15 (22) | 15 | 0 | 44 | 0% | 2.9 | 0 (5) | 63 (7) | 0 (5) | 0 (5) | 26 (12) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 38 | 0% | 5.5 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Chaff | 76 | 54 (76) | 20 | 34 | 54 | 42% | 2.5 | 76 (32) | 35 (19) | 44 (25) | 72 (54) | 13 (22) |
| Opponent | Character | 97 | 64 (97) | 64 | 0 | 35 | 24% | 2.6 | 76 (42) | 61 (43) | 0 (6) | 61 (63) | 73 (28) |
| Opponent | Clean-up | 19 | 21 (19) | 12 | 9 | 40 | 37% | 3.0 | 14 (9) | 33 (10) | - | 29 (14) | 0 (5) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 50 | 0% | 5.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 48 | 43 (48) | 33 | 10 | 28 | 21% | 2.6 | 43 (22) | 35 (16) | 59 (10) | 35 (28) | 59 (20) |
| Opponent | Fragile | 5 | 193 (5) | 193 | 0 | 39 | 20% | 4.5 | - | 250 (4) | 0 (1) | 229 (4) | 0 (1) |
| Opponent | Hammer | 70 | 23 (70) | 19 | 4 | 47 | 27% | 3.0 | 5 (17) | 25 (42) | 38 (11) | 25 (43) | 18 (27) |
| Opponent | Holder | 35 | 117 (35) | 15 | 102 | 13 | 40% | 3.1 | 105 (7) | 139 (22) | 57 (4) | 141 (22) | 82 (11) |
| Opponent | Shooter | 33 | 72 (33) | 20 | 52 | 29 | 3% | 1.8 | 79 (8) | 81 (19) | 34 (6) | 107 (22) | 18 (11) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 25 | 33% | 5.5 | 0 (1) | 0 (1) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | War machine | 24 | 39 (24) | 39 | 0 | 13 | 8% | 1.6 | 22 (6) | 47 (14) | 33 (4) | 38 (3) | 39 (21) |
| Opponent | Wizard | 26 | 0 (26) | 0 | 0 | 55 | 8% | 1.7 | 0 (10) | 0 (6) | 0 (6) | 0 (8) | 0 (14) |

### Charged fights: co-opp-a57fba0-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 118 | 62 | 1.2 | 1.2 | 49 | 21 | +29 | 0 of 5 | 4 of 5 | +120 | +6 |
| Mine | Chaos Dwarfs | 4 | 252 | 128 | 3.2 | 1.1 | 39 | 55 | -16 | 10 of 13 | 8 of 13 | +0 | -17 |
| Mine | Dwarfen Mountain Holds | 4 | 664 | 146 | 1.8 | 1.3 | 84 | 0 | +84 | 1 of 7 | 6 of 7 | +0 | +117 |
| Mine | Empire of Man | 5 | 440 | 98 | 1.6 | 1.1 | 62 | 71 | -10 | 3 of 8 | 6 of 8 | +210 | -41 |
| Mine | Grand Cathay | 4 | 332 | 139 | 1.8 | 1.1 | 79 | 33 | +46 | 3 of 7 | 4 of 7 | +0 | +54 |
| Mine | High Elf Realms | 4 | 71 | 493 | 2.5 | 1.3 | 197 | 29 | +169 | 4 of 10 | 9 of 10 | +266 | +127 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 670 | 6.0 | 1.2 | 112 | 46 | +66 | 3 of 6 | 5 of 6 | -72 | +93 |
| Mine | Lizardmen | 1 | 45 | 967 | 4.0 | 1.0 | 242 | 83 | +159 | 2 of 4 | 4 of 4 | - | +159 |
| Mine | Ogre Kingdoms | 1 | 0 | 186 | 5.0 | 1.6 | 37 | 25 | +12 | 1 of 5 | 3 of 5 | +51 | -45 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 349 | 5.0 | 1.2 | 70 | 11 | +59 | 1 of 5 | 4 of 5 | +45 | +62 |
| Mine | Skaven | 2 | 368 | 100 | 3.5 | 1.1 | 29 | 135 | -106 | 2 of 7 | 5 of 7 | -540 | -34 |
| Mine | Tomb Kings of Khemri | 1 | 110 | 909 | 5.0 | 1.0 | 182 | 24 | +157 | 1 of 5 | 5 of 5 | - | +157 |
| Mine | Vampire Counts | 3 | 37 | 321 | 2.7 | 1.2 | 120 | 8 | +113 | 1 of 8 | 6 of 8 | +57 | +132 |
| Mine | Warriors of Chaos | 1 | 19 | 426 | 2.0 | 1.0 | 213 | 86 | +126 | 1 of 2 | 1 of 2 | - | +126 |
| **Mine** | all armies | 36 | 249 | 251 | 2.6 | 1.2 | 98 | 43 | +55 | 33 of 92 | 70 of 92 | +49 | +56 |
| Opponent | Dwarfen Mountain Holds | 2 | 236 | 74 | 3.5 | 1.3 | 21 | 15 | +6 | 0 of 7 | 5 of 7 | +32 | -4 |
| Opponent | Empire of Man | 2 | 185 | 100 | 1.5 | 1.0 | 67 | 88 | -21 | 1 of 3 | 3 of 3 | - | -21 |
| Opponent | Grand Cathay | 2 | 613 | 758 | 3.0 | 1.2 | 253 | 0 | +253 | 4 of 6 | 6 of 6 | +562 | +191 |
| Opponent | Kingdom of Bretonnia | 1 | 285 | 120 | 2.0 | 1.0 | 60 | 0 | +60 | 0 of 2 | 2 of 2 | - | +60 |
| Opponent | Ogre Kingdoms | 3 | 0 | 284 | 6.0 | 1.1 | 47 | 24 | +24 | 5 of 18 | 10 of 18 | +0 | +25 |
| Opponent | Skaven | 1 | 425 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 180 | 752 | 4.0 | 1.1 | 188 | 93 | +95 | 7 of 16 | 11 of 16 | +280 | +82 |
| Opponent | Vampire Counts | 6 | 0 | 970 | 4.7 | 1.2 | 208 | 35 | +173 | 14 of 28 | 19 of 28 | +418 | +120 |
| Opponent | Warriors of Chaos | 8 | 0 | 260 | 2.1 | 1.0 | 123 | 0 | +123 | 7 of 17 | 14 of 17 | - | +123 |
| Opponent | Wood Elf Realms | 7 | 94 | 376 | 3.4 | 1.2 | 110 | 18 | +92 | 9 of 24 | 15 of 24 | +138 | +85 |
| **Opponent** | all armies | 36 | 116 | 455 | 3.4 | 1.1 | 134 | 30 | +104 | 48 of 122 | 85 of 122 | +262 | +85 |

### Effective charges: co-opp-a57fba0-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 0 | 0 | 0 | 4 (net +31) | 0 | 1 (net +20) | 0 | 0% (0 of 5) |
| Mine | Chaos Dwarfs | 13 | 1 (net +0) | 0 | 4 (net -180) | 4 (net +64) | 0 | 4 (net +64) | 0 | 31% (4 of 13) |
| Mine | Dwarfen Mountain Holds | 7 | 0 | 1 (net +0) | 1 (net +137) | 2 (net +32) | 0 | 3 (net +129) | 0 | 14% (1 of 7) |
| Mine | Empire of Man | 8 | 1 (net +0) | 0 | 3 (net -45) | 0 | 1 (net -288) | 3 (net +116) | 0 | 38% (3 of 8) |
| Mine | Grand Cathay | 7 | 3 (net -2) | 0 | 1 (net +329) | 0 | 1 (net +0) | 2 (net +0) | 0 | 14% (1 of 7) |
| Mine | High Elf Realms | 10 | 0 | 0 | 3 (net +17) | 1 (net +301) | 3 (net +217) | 2 (net +290) | 1 | 33% (3 of 9) |
| Mine | Kingdom of Bretonnia | 6 | 1 (net +0) | 0 | 2 (net +0) | 3 (net +131) | 0 | 0 | 0 | 33% (2 of 6) |
| Mine | Lizardmen | 4 | 2 (net +332) | 0 | 1 (net -278) | 0 | 1 (net +250) | 0 | 0 | 25% (1 of 4) |
| Mine | Ogre Kingdoms | 5 | 0 | 0 | 0 | 2 (net +93) | 1 (net +0) | 1 (net -34) | 1 | 0% (0 of 4) |
| Mine | Orc & Goblin Tribes | 5 | 0 | 0 | 1 (net +45) | 0 | 1 (net +54) | 1 (net +190) | 2 | 33% (1 of 3) |
| Mine | Skaven | 7 | 2 (net -116) | 0 | 1 (net +0) | 1 (net -540) | 0 | 3 (net +10) | 0 | 14% (1 of 7) |
| Mine | Tomb Kings of Khemri | 5 | 0 | 0 | 1 (net +3) | 1 (net +102) | 1 (net +125) | 2 (net +278) | 0 | 20% (1 of 5) |
| Mine | Vampire Counts | 8 | 1 (net +0) | 0 | 2 (net +300) | 2 (net +32) | 2 (net +120) | 1 (net +0) | 0 | 25% (2 of 8) |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +236) | 1 | 0% (0 of 1) |
| Opponent | Dwarfen Mountain Holds | 7 | 2 (net +0) | 0 | 1 (net +84) | 2 (net +32) | 0 | 1 (net +0) | 1 | 17% (1 of 6) |
| Opponent | Empire of Man | 3 | 0 | 1 (net +110) | 0 | 0 | 0 | 1 (net -265) | 1 | 0% (0 of 2) |
| Opponent | Grand Cathay | 6 | 0 | 0 | 2 (net +626) | 3 (net +88) | 0 | 1 (net +0) | 0 | 33% (2 of 6) |
| Opponent | Kingdom of Bretonnia | 2 | 0 | 0 | 0 | 1 (net +120) | 1 (net +0) | 0 | 0 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 18 | 4 (net +114) | 0 | 6 (net -45) | 1 (net +45) | 0 | 3 (net +106) | 4 | 43% (6 of 14) |
| Opponent | Skaven | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 16 | 5 (net -52) | 0 | 3 (net +418) | 3 (net +34) | 1 (net +30) | 0 | 4 | 25% (3 of 12) |
| Opponent | Vampire Counts | 28 | 6 (net +160) | 1 (net +185) | 6 (net +204) | 8 (net +175) | 1 (net +162) | 4 (net +70) | 2 | 23% (6 of 26) |
| Opponent | Warriors of Chaos | 17 | 1 (net +0) | 1 (net +563) | 2 (net +96) | 2 (net +350) | 0 | 7 (net +35) | 4 | 15% (2 of 13) |
| Opponent | Wood Elf Realms | 24 | 6 (net +176) | 2 (net +114) | 3 (net +97) | 3 (net +41) | 1 (net +104) | 8 (net +63) | 1 | 13% (3 of 23) |

### Charged fights, damage counted: co-opp-a57fba0-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 11 | 250 | 335 | +39 | 133 | 84 | +48 | +19.4 |
| Mine | 50-54% | 1 | 110 | 396 | +0 | 29 | 30 | -1 | -0.7 |
| Mine | Effective (55-75%) | 20 | 236 | 247 | +2 | 122 | 90 | +32 | +13.7 |
| Mine | 76-89% | 20 | 272 | 196 | +47 | 102 | 55 | +47 | +17.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 24 | 227 | 159 | +107 | 124 | 14 | +110 | +48.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 452 | 102 | +94 | 142 | 54 | +88 | +19.5 |
| Mine | No odds | 5 | 234 | 186 | +7 | 70 | 64 | +7 | +2.9 |
| Mine | All fights | 92 | 268 | 204 | +55 | 118 | 56 | +63 | +23.4 |
| Opponent | Long shot (under 50%) | 25 | 211 | 256 | +88 | 157 | 68 | +89 | +42.1 |
| Opponent | 50-54% | 5 | 320 | 205 | +217 | 225 | 74 | +151 | +47.3 |
| Opponent | Effective (55-75%) | 23 | 235 | 230 | +175 | 221 | 56 | +165 | +70.1 |
| Opponent | 76-89% | 23 | 294 | 185 | +122 | 158 | 43 | +116 | +39.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 25 | 214 | 179 | +43 | 83 | 29 | +54 | +25.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 391 | 86 | +74 | 74 | 0 | +74 | +18.9 |
| Opponent | No odds | 17 | 235 | 219 | +69 | 123 | 49 | +74 | +31.6 |
| Opponent | All fights | 122 | 245 | 209 | +104 | 149 | 48 | +101 | +41.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| co-opp-a57fba0-p2 | move | 388 | 74 (19%) | 55 (14%) | 44 (11%) | 270 (70%) |
| co-opp-a57fba0-p2 | objective | 398 | 60 (15%) | 45 (11%) | 48 (12%) | 290 (73%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

# Doctrine scorecard: co-mine-a57fba0-p4

### Scorecard: co-mine-a57fba0-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 4 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 8 | 1 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | no | 5 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Opponent | no | 8 | 1 | 6 | 2 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | yes | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 30 |
| L0214 | 4 | 1 | Opponent | no | 1 | 1 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 1 | 5 | 4 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | no | 1 | 2 | 2 | 1 | 0 | 0 | 0 | 565 |
| L0315 | 3 | 1 | Opponent | yes | 11 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | 6 | 0 | 1 | 0 | 0 | 0 | 590 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 3 | 5 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | yes | 5 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 1 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Mine | - | - | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 1416 |
| L0520 | 4 | 1 | Opponent | no | 7 | - | 1 | 3 | 1 | 0 | 0 | 210 |
| L0608 | 2 | 1 | Mine | - | - | - | 1 | 3 | 0 | 0 | 0 | 984 |
| L0608 | 2 | 1 | Opponent | - | - | - | 0 | 3 | 0 | 0 | 0 | 769 |
| L0624 | 6 | 1 | Mine | no | 0 | - | 3 | 2 | 0 | 0 | 0 | 984 |
| L0624 | 6 | 1 | Opponent | no | 6 | 3 | 0 | 0 | 0 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | yes | - | 1 | 3 | 1 | 2 | 0 | 0 | 295 |
| L0713 | 5 | 1 | Opponent | no | - | 5 | 2 | 2 | 0 | 0 | 0 | 479 |
| L0729 | 3 | 1 | Mine | yes | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 375 |
| L0729 | 3 | 1 | Opponent | no | 2 | 2 | 4 | 0 | 2 | 0 | 0 | 0 |
| L0819 | 3 | 1 | Mine | no | 0 | - | 0 | 0 | 1 | 0 | 0 | 1007 |
| L0819 | 3 | 1 | Opponent | no | 8 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 0 | 3 | 1 | 3 | 0 | 0 | 0 | 114 |
| L0926 | 2 | 1 | Mine | - | - | 6 | 1 | 1 | 0 | 0 | 0 | 537 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 4 | 4 | 0 | 0 | 0 | 40 |
| L1017 | 3 | 1 | Mine | no | 4 | 2 | 4 | 0 | 1 | 0 | 0 | 330 |
| L1017 | 3 | 1 | Opponent | yes | 7 | 2 | 3 | 1 | 3 | 0 | 0 | 0 |
| L1034 | 2 | 1 | Mine | - | - | 3 | 0 | 0 | 0 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 3 | 2 | 1 | 0 | 0 | 0 | 556 |
| L1126 | 4 | 1 | Mine | no | 0 | 5 | 2 | 0 | 0 | 0 | 0 | 427 |
| L1126 | 4 | 1 | Opponent | no | 6 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 1 | 4 | 0 | 0 | 0 | 0 |
| L1314 | 6 | 1 | Mine | no | 0 | 3 | 0 | 0 | 0 | 0 | 0 | 140 |
| L1314 | 6 | 1 | Opponent | no | 24 | 2 | 2 | 1 | 1 | 0 | 0 | 300 |
| L1331 | 5 | 1 | Mine | no | - | - | 1 | 3 | 0 | 0 | 0 | 140 |
| L1331 | 5 | 1 | Opponent | yes | - | 1 | 3 | 3 | 1 | 0 | 0 | 170 |
| L1427 | 5 | 1 | Mine | yes | - | 5 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | yes | - | 3 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | no | - | 1 | 6 | 0 | 1 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 2 | 6 | 0 | 1 | 0 | 0 | 471 |
| L1621 | 1 | 1 | Mine | no | 4 | 2 | 5 | 1 | 1 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 0 | - | 3 | 1 | 0 | 0 | 0 | 565 |
| L1719 | 3 | 1 | Mine | no | 0 | 2 | 3 | 0 | 1 | 0 | 0 | 49 |
| L1719 | 3 | 1 | Opponent | yes | 2 | 2 | 9 | 0 | 0 | 0 | 0 | 317 |
| L1819 | 1 | 1 | Mine | no | 2 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 0 | 2 | 7 | 1 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | yes | - | 2 | 0 | 2 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | no | - | 1 | 1 | 3 | 0 | 0 | 0 | 110 |
| L2021 | 5 | 1 | Mine | yes | - | 2 | 3 | 4 | 0 | 0 | 0 | 210 |
| L2021 | 5 | 1 | Opponent | no | - | - | 1 | 2 | 0 | 0 | 0 | 355 |
| L2123 | 5 | 1 | Mine | no | - | - | 2 | 3 | 0 | 0 | 0 | 940 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 6 | 0 | 1 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | yes | 1 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | yes | 0 | 1 | 5 | 1 | 0 | 0 | 0 | 190 |
| L2331 | 3 | 1 | Mine | no | 0 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Opponent | yes | 8 | 5 | 3 | 1 | 1 | 0 | 0 | 170 |
| L2527 | 1 | 1 | Mine | no | 0 | 3 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 0 | 1 | 1 | 6 | 0 | 0 | 0 | 190 |
| L2634 | 6 | 1 | Mine | no | 5 | 1 | 4 | 1 | 1 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 13 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Mine | - | - | 2 | 7 | 1 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 2 | 1 | 2 | 1 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 5 | 2 | 4 | 2 | 1 | 0 | 0 | 170 |
| L3234 | 6 | 1 | Opponent | no | 4 | 2 | 6 | 3 | 0 | 0 | 0 | 56 |
| **Average** | | | Mine | 29% | 1.7 | 2.5 | 2.5 | 1.2 | 0.3 | 0.0 | 0.0 | 293.4 |
| **Average** | | | Opponent | 36% | 5.5 | 2.1 | 2.9 | 1.8 | 0.4 | 0.0 | 0.0 | 140.6 |

### KPIs: co-mine-a57fba0-p4

Rules off - Opponent only: BREAK OUTCOMES, OVERRUN ON, STAND AND SHOOT, FLEES FROM CHARGE.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 23% (39 of 167) | 1% (2 of 181) | 12% (41 of 348) |
| Winner chose to follow up after the loser gave ground |  | 96% (53 of 55); on the table 96% | 100% (51 of 51); on the table 100% | 98% (104 of 106); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 92% (12 of 13); on the table 92% | 100% (14 of 14); on the table 100% | 96% (26 of 27); on the table 96% |
| Winner chose to pursue after the loser fled |  | 60% (25 of 42); on the table 69% | 84% (27 of 32); on the table 88% | 70% (52 of 74); on the table 77% |
| Winner chose to follow up or pursue (all three) |  | 82% (90 of 110); on the table 85% | 95% (92 of 97); on the table 96% | 88% (182 of 207); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 26% (69 of 269) | 34% (59 of 172) | 29% (128 of 441) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 37% (69 of 186) | 48% (59 of 123) | 41% (128 of 309) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 61% (28 of 46) | 62% (41 of 66) | 62% (69 of 112) |
| Points that never fought | lower | 36% (24762 of 67942) | 36% (26156 of 71984) | 36% (50918 of 139926) |
|   infantry points that never fought | lower | 44% (6731 of 15347) | 56% (7719 of 13804) | 50% (14450 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% (166 of 270) | 53% (149 of 280) | 57% (315 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 86% (19 of 22); 1.5 uses a game | 78% (7 of 9); 0.5 uses a game | 84% (26 of 31); 1.0 uses a game |
| Bound items with another spell used |  | 25% (4 of 16); 0.2 uses a game | 25% (5 of 20); 0.1 uses a game | 25% (9 of 36); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 58% (11 of 19); 0.3 uses a game | 87% (13 of 15); 0.4 uses a game | 71% (24 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 56% (32534 of 57750) | 46% (29343 of 63347) | 51% (61877 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.6 (28%) | 0.9 (27%) | 2.4 (28%) |
| MARCHED: its unit marched | 1.1 (20%) | 0.4 (14%) | 1.6 (18%) |
| CHARGED: its unit charged | 0.5 (10%) | 0.2 (6%) | 0.7 (8%) |
| IN COMBAT: engaged in combat | 1.0 (18%) | 0.7 (22%) | 1.7 (19%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (8%) | 0.2 (3%) |
| FLEEING: fleeing | 0.1 (2%) | 0.1 (2%) | 0.1 (2%) |
| GONE: slain | 1.0 (18%) | 0.6 (19%) | 1.6 (19%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (4%) | 0.0 (0%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.2 | 1.4 | 1.8 | 3.6 | 0.5 | 2.3 |
| not cast | 3.0 | 2.4 | 3.0 | 8.7 | 1.5 | 20.6 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.2 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (53%) | 0.4 (12%) | 2.4 (28%) | 0.2 (11%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.6 (18%) | 0.4 (28%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (8%) | 0.1 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.1 (2%) | 0.6 (19%) | 1.7 (19%) | 0.3 (19%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (6%) | 0.2 (7%) | 0.3 (11%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (4%) | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.4 (2%) |
| GONE: slain | 0.9 (30%) | 0.4 (18%) | 0.7 (23%) | 1.6 (19%) | 0.1 (9%) | 4.0 (19%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (8%) | 0.1 (5%) | 0.1 (2%) | 0.2 (2%) | 0.0 (0%) | 0.7 (3%) |
| STUPIDITY: Stupidity | 0.1 (4%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.2 (10%) | 0.0 (0%) | 0.0 (0%) | 0.4 (28%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.4 (47%) | 0.1 (5%) | 1.0 (33%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.1 (69%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.6 a game | 0.9 a game |
| stood (cast and not dispelled) | 58% (23 of 40) | 64% (7 of 11) | 59% (30 of 51) |
| the unit moved after it | 70% (16 of 23) | 71% (5 of 7) | 70% (21 of 30) |
| it charged on its next turn | 13% (3 of 23) | 0% (0 of 7) | 10% (3 of 30) |
| the enemy charged it first | 26% (6 of 23) | 14% (1 of 7) | 23% (7 of 30) |
| it fought by the end of its next turn | 13% (3 of 23) | 29% (2 of 7) | 17% (5 of 30) |
| it moved out of a charge the enemy had planned (not charged first) | 17% (4 of 23) | 14% (1 of 7) | 17% (5 of 30) |
| none of these (no charge, no fight, no charge escaped) | 57% (13 of 23) | 57% (4 of 7) | 57% (17 of 30) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (581 of 920) | 55% (283 of 518) | 60% (864 of 1438) |
|   cavalry | 54% (43 of 80) | 71% (75 of 106) | 63% (118 of 186) |
|   character | 44% (48 of 108) | 20% (25 of 124) | 31% (73 of 232) |
|   chariot | 50% (56 of 112) | 68% (13 of 19) | 53% (69 of 131) |
|   infantry | 63% (178 of 283) | 64% (139 of 217) | 63% (317 of 500) |
|   monster | 43% (23 of 54) | 20% (5 of 25) | 35% (28 of 79) |
|   war machine | 82% (233 of 283) | 96% (26 of 27) | 84% (259 of 310) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (22%) | 1.3 (20%) | 3.4 (21%) |
| CHARGED: it charged | 1.3 (14%) | 1.6 (24%) | 2.9 (18%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (2%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.9 (10%) | 0.4 (6%) | 1.4 (9%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| HELD FIRE: a target, but it held its fire | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 2.2 (24%) | 1.2 (19%) | 3.4 (22%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (6%) | 0.4 (7%) | 1.1 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.6 (17%) | 1.4 (21%) | 2.9 (18%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.4 | 1.3 | 83% | 5.2 pts | 28 pts |
| character | 2.1 | 0.9 | 77% | 8.2 pts | 18 pts |
| chariot | 1.9 | 1.0 | 66% | 13.0 pts | 25 pts |
| infantry | 13.2 | 5.5 | 73% | 10.6 pts | 140 pts |
| monster | 0.9 | 0.1 | 88% | 2.9 pts | 3 pts |
| war machine | 7.2 | 5.8 | 67% | 29.8 pts | 214 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.2 | 6.6 | 5.4 |
| Charges that made contact a game | 3.1 | 4.6 | 3.9 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.76 declared, 0.59 contact (17 units) | 0.69 declared, 0.44 contact (16 units) | 0.73 declared, 0.52 contact (33 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.11 declared, 1.00 contact (9 units) | 1.42 declared, 1.00 contact (12 units) | 1.29 declared, 1.00 contact (21 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.53 declared, 0.37 contact (247 units) | 0.71 declared, 0.50 contact (295 units) | 0.63 declared, 0.44 contact (542 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 54% (44 of 81) | 31% (5 of 16) | 33% (2 of 6) | 50% (51 of 103) |
| Character in a unit | 78% (21 of 27) | 53% (9 of 17) | 100% (1 of 1) | 69% (31 of 45) |
| Character on its own | 95% (36 of 38) | 64% (16 of 25) | 31% (24 of 77) | 54% (76 of 140) |
| Chariot | 53% (8 of 15) | 67% (8 of 12) | - | 59% (16 of 27) |
| Infantry | 55% (46 of 83) | 44% (11 of 25) | 33% (2 of 6) | 52% (59 of 114) |
| Monster | 53% (18 of 34) | 79% (11 of 14) | - | 60% (29 of 48) |
| Monstrous | 71% (10 of 14) | 57% (8 of 14) | - | 64% (18 of 28) |
| War Machines | 77% (33 of 43) | 100% (2 of 2) | - | 78% (35 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 92% (12 of 13); on the table 92% | 25% (26 of 102) | 17% | 59% (13 of 22) | 67% (4 of 6); 2.5 uses a game | 50% (1 of 2); 0.8 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 67% (4 of 6); on the table 83% | 38% (9 of 24) | 36% | 75% (24 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (4 of 4); on the table 100% | - | 72% | 70% (19 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 94% (16 of 17); on the table 94% | 56% (10 of 18) | 51% | 73% (45 of 62) | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game | 80% (4 of 5); 0.7 uses a game |
| Grand Cathay | 4 | 87% (13 of 15); on the table 87% | 25% (21 of 84) | 45% | 38% (14 of 37) | 100% (9 of 9); 6.5 uses a game | 0% (0 of 2); 0.0 uses a game | 50% (2 of 4); 0.5 uses a game |
| High Elf Realms | 9 | 91% (10 of 11); on the table 91% | 14% (5 of 36) | 32% | 47% (33 of 70) | 100% (7 of 7); 2.7 uses a game | 23% (7 of 30); 0.8 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (3 of 3); on the table 100% | - | 49% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 52% (12 of 23); on the table 65% | 67% (4 of 6) | 27% | 52% (11 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 100% (8 of 8); on the table 100% | 33% (2 of 6) | 31% | 79% (11 of 14) | 50% (1 of 2); 1.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (9 of 9); on the table 100% | 29% (12 of 42) | 13% | 33% (8 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 6 | 90% (18 of 20); on the table 95% | 22% (9 of 40) | 42% | 69% (31 of 45) | 100% (3 of 3); 0.8 uses a game | 0.0 uses a game | 67% (4 of 6); 0.8 uses a game |
| Tomb Kings of Khemri | 4 | 75% (6 of 8); on the table 75% | 0% (0 of 6) | 27% | 40% (8 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 94% (16 of 17); on the table 94% | 36% (21 of 59) | 35% | 57% (24 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 100% (30 of 30); on the table 100% | 33% (4 of 12) | 26% | 53% (38 of 72) | 50% (1 of 2); 0.2 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 91% (21 of 23); on the table 91% | 83% (5 of 6) | 52% | 59% (33 of 56) | 50% (1 of 2); 0.2 uses a game | 0.0 uses a game | 75% (3 of 4); 0.5 uses a game |

Flank and rear charges a unit could have turned to face (co-mine-a57fba0-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 56% (54) | 44% (31) | 51% (85) |
| ...free all their last turn and able to turn (per game) | 0.58 | 0.61 | 1.19 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.42 | 0.08 | 0.50 |
| ...with the charger already in that arc before they moved (per game) | 0.22 | 0.53 | 0.75 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.69 | 1.03 | 2.72 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.94 | 0.44 | 1.39 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 4.69 | 5.22 | 9.92 |

### Quality by phase: co-mine-a57fba0-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 51% (70 of 137) | 43% (85 of 196) |
| Strategy | Shoot objectives carried out (shot that target) | 43% (187 of 431) | 49% (93 of 189) |
| Strategy | Close-in objectives charged next turn | 12% (22 of 176) | 16% (35 of 221) |
| Strategy | Support requests answered (helper made contact too) | 62% (8 of 13) | 37% (11 of 30) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 53% (8 of 15) | 89% (8 of 9) |
| Strategy | Joined characters whose unit fought | 54% (20 of 37) | 50% (15 of 30) |
| Strategy | Lone characters that fought | 69% (59 of 86) | 76% (65 of 86) |
| Movement | Charges halted short of contact | 0.1 | 0.4 |
| Movement | Idle units | 1.2 | 1.8 |
| Movement | Points that never moved of their own | 293.4 | 140.6 |
| Movement | Fights charged into per game | 2.9 | 4.0 |
| Movement | Charges with odds: long shots (under 50%) | 18 of 96, net +56 | 25 of 125, net -16 |
| Movement | Charges with odds: sweet spot (55-75%) | 12 of 96, net -16 | 28 of 125, net +75 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 14 of 96, net +53 | 14 of 125, net +92 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 26 of 96, net +80 | 29 of 125, net +117 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.6 | 8.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (191 of 380) | 35% (110 of 314) |
| Shooting | Points destroyed by shooting units | 60.8 | 59.3 |
| Shooting | War machine shots | 6.5 | 0.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 64% (148 of 233) | 12% (3 of 26) |
| Shooting | Points destroyed by war machines | 106.0 | 4.9 |
| Magic | Magic missiles cast | 1.2 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (14 of 43) | 20% (8 of 41) |
| Magic | Wounds caused by magic missiles | 3.2 | 1.8 |
| Magic | Wounds caused by other spells | 1.4 | 1.1 |
| Magic | Points destroyed by magic (all spells) | 87.2 | 30.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.1 / 0.5 / 0.9 / 0.2 | 2.0 / 0.5 / 0.8 / 0.1 |
| Combat | Points destroyed in combat | 285.5 | 404.7 |
| Combat | Points run down | 89.9 | 126.3 |
| Combat | Net points per charged fight, damage counted | +73 | +86 |
| Combat | Net per 100 charger points, damage counted | +25.3 | +30.4 |
| Combat | First round won (charged fights) | 75% | 66% |
| Combat | Net points per charged fight | +60 | +87 |
| Combat | Net points per supported fight / lone fight | +97 / +53 | +160 / +78 |
| Combat | Charged fights on a top-3 enemy unit | 33 of 103 | 61 of 144 |
| Game | Points lost | 769.1 | 708.7 |
| Game | VP from objectives | 547.8 | 510.0 |
| Game | Lone holders (player turns) | 1.7 | 5.5 |

- Mine won / drew / lost: 15 / 2 / 19 of 36 ended games (of 36); mean margin (Mine - Opponent) -56 VP
- The side that went first won 16 of 34 games with a winner
- Points traded per game (both sides' losses): 1478
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: co-mine-a57fba0-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 4.0 |
| ADVANCE WORTH | 5.9 | -136.0 | 233.0 | 103.0 | 4.2 | -131.4 | 164.1 | 66.7 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.5 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.2 | +0.0 | 0.0 | 6.5 | 0.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.6 | +2.9 | 0.0 | 20.4 | 0.4 | +2.2 | 0.0 | 5.4 |
| BEST FACING | 0.5 | +11.2 | 0.0 | 19.8 | 0.2 | +4.2 | 0.0 | 0.0 |
| BEST FIRST | 1.1 | +45.1 | 50.7 | 29.8 | 0.9 | +39.6 | 37.1 | 21.8 |
| BEST OVERALL | 0.3 | +17.2 | 0.0 | 0.0 | 0.1 | +4.8 | 0.0 | 20.0 |
| BEST PREY | 0.5 | +27.0 | 19.7 | 13.4 | 0.5 | +16.3 | 9.5 | 0.0 |
| BEST PRIZE | 0.1 | +0.8 | 3.1 | 5.1 | 0.1 | +0.6 | 5.2 | 0.0 |
| BIG CHARACTER SAFETY | 0.1 | -0.7 | 0.0 | 0.0 | 0.2 | -1.7 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 4.7 | 0.0 | 0.1 | +0.0 | 10.1 | 0.0 |
| BLOCKED WHEEL | 0.3 | +6.5 | 0.0 | 0.0 | 0.4 | +10.9 | 0.0 | 17.3 |
| BLOWS WHERE AIMED | 0.2 | -15.3 | 35.4 | 4.6 | 0.4 | -50.6 | 72.5 | 11.1 |
| BOMBING RUN | 0.0 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| BREAK OUTCOMES | 2.6 | +12.4 | 241.1 | 137.2 | - | - | - | - |
| CANNON PLAN MISSED | 0.5 | +0.0 | 72.1 | 12.2 | 0.1 | +0.0 | 15.6 | 0.0 |
| CANNON PLANNED TARGET | 5.3 | +242.1 | 422.5 | 90.1 | 0.7 | +30.7 | 44.4 | 3.5 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 10.9 | 12.1 | 0.2 | +0.0 | 29.2 | 4.0 |
| CAST JOB | 0.9 | +24.1 | 53.9 | 23.4 | 0.4 | +6.1 | 9.6 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +24.1 | 10.3 | 8.9 | 0.1 | +4.3 | 6.5 | 10.9 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 31.6 | 0.3 | +0.0 | 0.0 | 9.1 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +0.7 | 0.0 | 6.1 | - | - | - | - |
| CATCH ODDS | - | - | - | - | 0.0 | +0.5 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.7 | +39.2 | 0.0 | 13.8 | 2.1 | +117.3 | 0.0 | 34.2 |
| CHAFF PASSED | 0.1 | -1.2 | 11.9 | 3.5 | 0.1 | +0.0 | 0.0 | 0.0 |
| CHAMPION TAKES THE CHALLENGE | - | - | - | - | 0.0 | +0.5 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 2.5 | +0.0 | 217.8 | 99.8 | 2.8 | +0.0 | 308.8 | 92.3 |
| CHARGE NOW WEIGHED | 0.5 | -42.6 | 15.1 | 8.6 | 0.5 | -39.6 | 19.1 | 9.5 |
| CHARGER SLAIN LOST | 0.4 | -13.1 | 47.1 | 25.7 | 0.8 | -22.4 | 36.4 | 17.2 |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.6 | 6.5 | 11.1 | 0.1 | -0.1 | 7.7 | 15.0 |
| CHEAP HELPER | 0.1 | +0.0 | 1.5 | 3.8 | 0.1 | +0.0 | 6.4 | 4.9 |
| COMBAT PIVOT | 0.4 | +0.0 | 37.6 | 31.9 | 0.5 | +0.0 | 25.7 | 56.9 |
| CONTINUE AHEAD WEIGHED | 0.1 | +0.0 | 1.8 | 7.1 | - | - | - | - |
| CONVEYANCE SEARCH | 0.6 | +47.8 | 2.5 | 0.0 | 0.2 | +40.9 | 20.5 | 0.0 |
| COVER ONCE | 7.8 | -433.1 | 0.0 | 186.1 | 6.1 | -444.6 | 0.0 | 123.7 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 0.0 | 1.0 | - | - | - | - |
| DEFENSIVE FLOOR | - | - | - | - | 0.0 | +2.0 | 3.1 | 0.0 |
| EDGE GIVE GROUND | 0.0 | +0.5 | 0.0 | 0.0 | 0.3 | +6.4 | 12.8 | 5.2 |
| ELIXIR WORTH | 0.0 | +0.2 | 0.0 | 0.0 | 0.1 | +0.7 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.7 | +141.8 | 0.0 | 38.1 | 1.0 | +87.0 | 0.0 | 22.9 |
| FALLBACK BY WORTH | 5.2 | +63.4 | 0.0 | 82.7 | 5.5 | +52.7 | 0.0 | 93.4 |
| FIGHT LIFT | 0.1 | +1.0 | 5.8 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| FIRE AND FLEE | - | - | - | - | 0.1 | +0.4 | 1.8 | 3.0 |
| FLANK NOT WEIGHED | 4.6 | +0.0 | 0.0 | 128.6 | 4.7 | +0.0 | 0.0 | 81.0 |
| FLEES FROM CHARGE | 0.7 | -16.0 | 34.3 | 18.3 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.9 | +112.2 | 0.0 | 80.3 | 0.9 | +92.9 | 0.0 | 37.1 |
| FRIENDS SHOTS CHECKED | 0.1 | +2.7 | 0.0 | 9.0 | 0.2 | +12.4 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -0.4 | 5.2 | 4.1 | 0.1 | -1.5 | 8.0 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -0.7 | 5.2 | 1.2 |
| GROUND FLIERS | 0.0 | +0.1 | 0.0 | 0.0 | 0.1 | +2.3 | 0.0 | 3.2 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HELPER UNSEEN | 0.2 | +0.0 | 5.4 | 17.4 | 0.7 | +0.0 | 40.4 | 26.0 |
| HILL BY ITS CHANCE | 0.6 | -72.1 | 0.0 | 3.4 | 0.5 | -42.4 | 0.0 | 13.7 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.1 | -124.2 | 428.2 | 164.7 | 9.3 | -218.1 | 616.0 | 158.8 |
| HUNT ADVANCE | - | - | - | - | 0.1 | +2.5 | 2.4 | 0.0 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 4.6 | 0.0 |
| HUNT IN PAIRS | 0.3 | +5.4 | 0.0 | 0.0 | 0.5 | +28.4 | 0.0 | 0.0 |
| HUNT KEPT | - | - | - | - | 0.1 | +0.8 | 6.9 | 1.2 |
| HUNT RESULT | - | - | - | - | 0.2 | +9.6 | 13.1 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.2 | +62.5 | 6.9 | 1.2 |
| IDLE COST | 17.1 | -273.8 | 0.0 | 177.2 | 19.5 | -322.3 | 0.0 | 200.3 |
| INVITES THE FIGHT | 1.3 | +8.4 | 72.3 | 4.6 | 1.0 | +7.0 | 51.5 | 29.2 |
| JOINT CHARGE PLAN | 0.1 | +0.3 | 0.0 | 0.0 | 0.1 | +2.2 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -3.1 | 6.0 | 2.6 |
| KEEP FALLS | 0.1 | +1.7 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.4 | +43.3 | 94.7 | 58.1 | 1.9 | +58.3 | 204.6 | 24.5 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | - | - | - | - | 1.6 | +97.3 | 136.1 | 18.9 |
| KILLS COUNT NEXT TURN | 5.4 | +196.1 | 238.0 | 99.4 | 6.2 | +268.5 | 245.2 | 114.4 |
| LONE CHARACTER SAFE SPOT | 0.3 | +3.5 | 0.0 | 2.5 | 0.2 | +12.1 | 7.7 | 0.0 |
| LONE WIZARD HOLDS BACK | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 5.2 | 10.7 |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | +1.2 | 24.8 | 18.1 | 0.6 | -1.5 | 28.6 | 6.1 |
| LOST CHARGE | 2.8 | -32.8 | 108.9 | 64.3 | 1.7 | -27.8 | 58.5 | 54.0 |
| LURE BY WHAT IT DRAWS | 0.1 | -5.1 | 0.0 | 0.0 | 0.1 | -17.5 | 0.0 | 9.1 |
| MAKE SURE TOGETHER | 0.8 | +47.7 | 5.3 | 38.2 | 0.8 | +45.2 | 14.2 | 13.2 |
| MANOEUVRE | 0.3 | +12.6 | 0.0 | 15.6 | 0.0 | +0.3 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.4 | 0.0 | 0.0 | 0.1 | +0.2 | 0.0 | 5.4 |
| MARCH CHECK | 0.4 | +13.0 | 0.0 | 0.0 | 0.4 | +10.4 | 0.0 | 3.2 |
| MARCH ODDS | 0.3 | +21.9 | 11.0 | 10.2 | 0.3 | +16.3 | 8.9 | 0.0 |
| MARCH OVER CASTS | 0.5 | +29.2 | 0.0 | 8.2 | 0.4 | +19.9 | 0.0 | 5.4 |
| MAX FOR POSITIONING | 5.4 | +87.4 | 0.0 | 107.0 | 6.2 | +82.8 | 0.0 | 125.8 |
| MISSILES IN THE MOVE | 3.4 | +130.3 | 0.0 | 94.9 | 2.1 | +41.2 | 0.0 | 51.4 |
| MISSILES NEXT TURN | 4.2 | +85.5 | 0.0 | 122.3 | 2.9 | +25.1 | 0.0 | 51.4 |
| MODEL FACING | 0.2 | +32.5 | 0.0 | 5.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 17.3 | 5.7 | 0.1 | +0.0 | 10.5 | 0.0 |
| MOVE AND CAST | 0.2 | +4.5 | 0.0 | 4.5 | 0.2 | +5.5 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.2 | +4.3 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL NOT WORTH | - | - | - | - | 0.0 | -0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.5 | -33.6 | 33.5 | 42.8 | 0.0 | -0.2 | 0.0 | 2.6 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 20.5 | 0.1 | +0.0 | 0.0 | 20.5 |
| MOVE TO CHARGE | 2.9 | +143.8 | 125.9 | 62.1 | 4.6 | +330.8 | 260.9 | 81.2 |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +1.8 | 1.7 | 0.0 | 0.1 | +6.1 | 10.5 | 0.0 |
| NO RALLY LEFT | 0.1 | +1.7 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.4 | -22.3 | 24.4 | 20.3 | 0.3 | -18.5 | 24.6 | 0.0 |
| NOT TURNED | 4.7 | +48.6 | 0.0 | 90.3 | 5.2 | +49.6 | 0.0 | 104.4 |
| NOT WORTH A CAST | 0.5 | -0.4 | 0.0 | 33.9 | 0.4 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 15.7 | -684.6 | 26.2 | 250.8 | 14.7 | -715.4 | 27.8 | 225.9 |
| ONE FIGHT FORMULA | 8.2 | -125.1 | 44.7 | 161.2 | 8.5 | -172.0 | 49.9 | 194.6 |
| ONE OBJECTIVE FORMULA | 2.6 | -138.4 | 0.0 | 29.7 | 1.9 | -158.6 | 0.0 | 52.6 |
| OPENS A LANE | 0.1 | +0.1 | 12.7 | 10.2 | - | - | - | - |
| OPENS UP | 0.5 | +33.9 | 25.8 | 6.5 | 0.2 | +31.5 | 10.2 | 5.4 |
| OVERRUN ON | 0.6 | +23.9 | 62.4 | 24.6 | - | - | - | - |
| OVERRUNS AWAY | 0.5 | +16.4 | 57.6 | 20.7 | 0.6 | +12.1 | 60.1 | 11.2 |
| PATHS CROSS | 2.1 | +145.1 | 0.0 | 40.6 | 3.1 | +233.5 | 0.0 | 36.6 |
| PERIAPT WORTH | 0.0 | +3.4 | 0.0 | 0.0 | 0.1 | +7.7 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.1 | 0.0 | 0.0 | 0.1 | -3.4 | 0.0 | 0.0 |
| PLAN RESULT | 39.2 | +1670.8 | 1512.3 | 1060.2 | 38.2 | +1076.6 | 1574.9 | 1056.1 |
| PURSUES BIG PREY | 0.2 | -8.4 | 0.0 | 0.0 | 0.0 | -0.7 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +7.2 | 0.0 | 2.2 | 0.1 | +5.7 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 1.3 | +18.8 | 0.0 | 27.4 | 1.8 | +16.7 | 0.0 | 48.9 |
| RANDOM MOVER NO PROMISE | 0.3 | -12.4 | 19.8 | 8.8 | 0.3 | -9.0 | 6.7 | 10.6 |
| REDIRECT BY WHAT IT STOPS | 0.6 | -9.4 | 0.0 | 13.8 | 1.8 | -54.5 | 0.0 | 19.4 |
| REDIRECT COUNTER | 2.0 | +112.6 | 0.0 | 17.4 | 3.8 | +218.1 | 0.0 | 64.6 |
| REDIRECT WEIGHED | 0.2 | +0.6 | 0.0 | 0.0 | 0.4 | +32.1 | 31.0 | 5.2 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 4.6 | 0.3 | +0.0 | 0.0 | 41.4 |
| RESERVE FALL BACK | 0.4 | +16.3 | 0.0 | 12.3 | 0.5 | +22.6 | 0.0 | 9.6 |
| RESTRAINS TO SHOOT | 0.2 | +4.2 | 0.0 | 5.5 | 0.1 | +2.8 | 0.0 | 0.0 |
| RISK BY ARC | 2.2 | +68.1 | 236.4 | 125.1 | 2.9 | +78.8 | 289.6 | 76.8 |
| RISK ONCE | 2.1 | +36.3 | 25.4 | 95.3 | 3.9 | +127.7 | 75.5 | 210.9 |
| SAFE SURE CHARGE | - | - | - | - | 0.0 | -0.1 | 1.7 | 0.0 |
| SAFER THAN THE JOB | 0.9 | +55.6 | 0.0 | 10.2 | 0.4 | +17.6 | 0.0 | 24.8 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.9 | 0.1 | +0.0 | 0.0 | 3.7 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.9 | 0.1 | +0.0 | 0.0 | 3.7 |
| SCREEN BY WHAT IT SAVES | 0.2 | -12.8 | 0.0 | 0.0 | 0.6 | -41.1 | 0.0 | 4.5 |
| SEARCH SPOT | 2.2 | +93.6 | 0.0 | 37.8 | 2.6 | +100.7 | 0.0 | 48.9 |
| SELF MOVE SPELL | 0.2 | +33.8 | 0.0 | 0.0 | 0.5 | +31.3 | 0.0 | 18.1 |
| SET UP TOGETHER | 1.1 | +63.9 | 17.3 | 38.2 | 1.4 | +93.3 | 45.1 | 16.1 |
| SET-UP ANY TARGET | 0.4 | +56.3 | 2.5 | 0.0 | 0.1 | +15.2 | 20.5 | 0.0 |
| SET-UP MISSED | 0.0 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.6 | +76.4 | 103.8 | 5.4 | 1.3 | +37.4 | 54.7 | 44.3 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 3.8 |
| SHOT REPLANNED | 0.6 | +0.0 | 98.9 | 13.7 | 0.2 | +0.0 | 36.4 | 0.0 |
| SHOTS IN THE MOVE | 14.9 | +652.1 | 0.0 | 235.8 | 7.1 | +209.9 | 0.0 | 73.8 |
| SPELL CATCH ODDS | 0.1 | -0.9 | 0.0 | 0.0 | 0.0 | -0.3 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.4 | +56.3 | 2.5 | 0.0 | 0.2 | +39.4 | 20.5 | 0.0 |
| SPELL WORTH | 1.2 | +17.0 | 73.6 | 69.4 | 2.3 | +41.5 | 30.0 | 32.6 |
| SPELLS IN THE FIGHT | 0.4 | -1.2 | 73.7 | 53.2 | 0.9 | -10.6 | 90.3 | 15.8 |
| STABLE ROLE | 11.1 | +0.0 | 456.2 | 251.4 | 9.5 | +0.0 | 309.0 | 178.5 |
| STAND AND SHOOT | 0.2 | -3.1 | 23.4 | 7.4 | - | - | - | - |
| STANDS TO CAST | - | - | - | - | 0.0 | +0.8 | 0.0 | 0.0 |
| STAY WEIGHED | 0.2 | +15.6 | 0.0 | 0.0 | - | - | - | - |
| STOPS | - | - | - | - | 0.2 | +6.0 | 6.9 | 1.2 |
| STOPS SHORT OF THE FLANK | 0.4 | +28.7 | 0.0 | 0.0 | 0.3 | +8.5 | 0.0 | 4.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 4.7 |
| SUPPORT NARROWED | 6.2 | -61.7 | 376.2 | 154.1 | 7.8 | -68.3 | 329.5 | 147.6 |
| SUPPORTS | 4.4 | +66.3 | 214.9 | 75.1 | 5.4 | +68.6 | 136.1 | 61.8 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -5.6 | 23.4 | 6.3 | 0.0 | -0.7 | 5.8 | 0.0 |
| SURE REACH TOGETHER | 0.4 | +1.6 | 0.0 | 9.7 | 0.5 | +0.2 | 10.1 | 36.9 |
| THROUGH LINE OF FIRE | 0.2 | +19.6 | 0.0 | 13.7 | 0.2 | +4.0 | 0.0 | 2.6 |
| TURN WORTH | 0.5 | -40.0 | 35.4 | 0.0 | 0.1 | -11.2 | 4.0 | 5.4 |
| TWO OR MORE ARRIVE | 0.2 | +0.5 | 11.9 | 0.0 | 0.6 | +3.1 | 0.0 | 5.2 |
| WAIT AFTER COSTS | 6.3 | -255.5 | 256.9 | 95.0 | 7.1 | -383.3 | 359.0 | 131.0 |
| WALKS TO THE FIGHT | 1.7 | +10.3 | 36.2 | 28.9 | 0.6 | +3.4 | 17.0 | 0.0 |
| WAR ENGINE CHARGES | 0.2 | +20.1 | 2.5 | 10.3 | - | - | - | - |
| WAR ENGINE JOBS | 0.9 | +0.0 | 61.9 | 13.8 | 0.1 | +0.0 | 7.4 | 0.0 |
| WEARS DOWN | 1.2 | +38.8 | 168.4 | 76.0 | 1.7 | +55.3 | 184.1 | 66.6 |
| WHO HITS BACK | 0.3 | +22.7 | 0.0 | 29.2 | 0.3 | +16.1 | 0.0 | 18.0 |
| WHOLE FIGHT | 0.1 | +18.9 | 26.7 | 0.0 | 0.8 | +69.3 | 129.7 | 14.1 |
| WHOLE FIGHT GAIN | 0.2 | +15.3 | 15.1 | 4.6 | 0.7 | +49.0 | 37.9 | 19.1 |
| WIDER SPREAD | 2.0 | -5.2 | 194.3 | 101.2 | 3.5 | -5.3 | 264.7 | 82.6 |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 0.0 | 3.9 | 0.1 | +0.0 | 0.0 | 13.7 |

### Rule changes: co-mine-a57fba0-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1093 | 1093 | 1093 | 30.36 | -50403 | -46.1 |
| PATHS CROSS | 185 | 185 | 185 | 5.14 | +13629 | +73.7 |
| SEARCH SPOT | 174 | 174 | 171 | 4.75 | +7019 | +41.0 |
| MOVE TO CHARGE | 271 | 271 | 152 | 4.22 | +5628 | +37.0 |
| SUPPORTS | 352 | 352 | 147 | 4.08 | +1637 | +11.1 |
| KILLS COUNT NEXT TURN | 421 | 421 | 141 | 3.92 | +4662 | +33.1 |
| FACES THE THREAT | 98 | 98 | 98 | 2.72 | +8237 | +84.1 |
| WAIT AFTER COSTS | 483 | 483 | 90 | 2.50 | +1295 | +14.4 |
| SHOTS IN THE MOVE | 789 | 559 | 87 | 2.42 | +1842 | +21.2 |
| COVER ONCE | 502 | 293 | 81 | 2.25 | +1511 | +18.7 |
| BEST FIRST | 73 | 73 | 73 | 2.03 | +3052 | +41.8 |
| FALLBACK BY WORTH | 384 | 384 | 73 | 2.03 | +4180 | +57.3 |
| RANDOM MOVE BY FIGURES | 112 | 112 | 69 | 1.92 | +1279 | +18.5 |
| CHAFF IN THE MOVE | 99 | 98 | 66 | 1.83 | +1797 | +27.2 |
| FOLLOW UP WEIGHED | 65 | 65 | 65 | 1.81 | +7386 | +113.6 |
| ONE FIGHT FORMULA | 599 | 369 | 61 | 1.69 | +188 | +3.1 |
| ADVANCE WORTH | 364 | 364 | 60 | 1.67 | +2387 | +39.8 |
| ADVANCE LANE KEPT | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| SAFER THAN THE JOB | 50 | 50 | 50 | 1.39 | +2635 | +52.7 |
| CHARGE NOW FIRST | 191 | 191 | 48 | 1.33 | -2006 | -41.8 |
| IDLE COST | 1315 | 761 | 48 | 1.33 | +616 | +12.8 |
| REDIRECT COUNTER | 208 | 105 | 48 | 1.33 | +3033 | +63.2 |
| ARTILLERY RE-ROLL WEIGHED | 46 | 46 | 46 | 1.28 | +0 | +0.0 |
| CANNON SIGHT KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| RISK ONCE | 217 | 164 | 40 | 1.11 | +1558 | +39.0 |
| SET UP TOGETHER | 89 | 76 | 40 | 1.11 | +2039 | +51.0 |
| SHOOTS FROM THE BEST SPOT | 107 | 107 | 40 | 1.11 | +1404 | +35.1 |
| CHARGE NOW WEIGHED | 38 | 38 | 38 | 1.06 | +2540 | +66.8 |
| MISSILES IN THE MOVE | 196 | 139 | 36 | 1.00 | +1182 | +32.8 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| HONEST WORTH | 590 | 586 | 35 | 0.97 | +303 | +8.7 |
| RESERVE FALL BACK | 34 | 34 | 34 | 0.94 | +1403 | +41.3 |
| COMBAT PIVOT | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| WALKS TO THE FIGHT | 80 | 80 | 31 | 0.86 | +132 | +4.3 |
| CANNON PLANNED TARGET | 217 | 217 | 30 | 0.83 | -412 | -13.7 |
| MAX FOR POSITIONING | 417 | 256 | 30 | 0.83 | +157 | +5.2 |
| INVITES THE FIGHT | 82 | 82 | 28 | 0.78 | +113 | +4.1 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| RISK BY ARC | 181 | 174 | 27 | 0.75 | +550 | +20.4 |
| SHOT REPLANNED | 27 | 27 | 27 | 0.75 | +0 | +0.0 |
| BLOCKED WHEEL | 26 | 26 | 26 | 0.72 | +630 | +24.2 |
| MARCH CHECK | 26 | 26 | 25 | 0.69 | +1212 | +48.5 |
| STOPS SHORT OF THE FLANK | 25 | 25 | 25 | 0.69 | +1341 | +53.6 |
| BEST FACING | 24 | 24 | 24 | 0.67 | +556 | +23.2 |
| KEEPS ITS TARGET | 122 | 122 | 24 | 0.67 | +474 | +19.7 |
| MARCH ODDS | 23 | 23 | 23 | 0.64 | +214 | +9.3 |
| REDIRECT WEIGHED | 23 | 23 | 23 | 0.64 | +1669 | +72.5 |
| CAST JOB | 45 | 45 | 22 | 0.61 | +367 | +16.7 |
| WHO HITS BACK | 22 | 22 | 22 | 0.61 | +1034 | +47.0 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +41 | +2.3 |
| STUCK PIVOT | 18 | 18 | 18 | 0.50 | +0 | +0.0 |
| WAR ENGINE JOBS | 36 | 36 | 18 | 0.50 | -527 | -29.3 |
| CASTER AWAY FROM SCREEN | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| KILLS COUNT | 59 | 58 | 17 | 0.47 | +880 | +51.8 |
| OPENS UP | 25 | 25 | 17 | 0.47 | +464 | +27.3 |
| THROUGH LINE OF FIRE | 17 | 17 | 17 | 0.47 | +849 | +49.9 |
| WEARS DOWN | 105 | 96 | 16 | 0.44 | +479 | +29.9 |
| BEST OVERALL | 15 | 15 | 15 | 0.42 | +790 | +52.6 |
| MOVE AND CAST | 15 | 15 | 15 | 0.42 | +359 | +23.9 |
| MAKE SURE TOGETHER | 55 | 34 | 14 | 0.39 | +753 | +53.8 |
| SUPPORT NARROWED | 505 | 505 | 14 | 0.39 | -278 | -19.8 |
| WHOLE FIGHT GAIN | 34 | 30 | 14 | 0.39 | +666 | +47.6 |
| WHOLE FIGHT | 31 | 31 | 13 | 0.36 | +1745 | +134.2 |
| FRIENDS SHOTS CHECKED | 11 | 11 | 11 | 0.31 | +542 | +49.3 |
| BIG CHARACTER SAFETY | 10 | 10 | 10 | 0.28 | -88 | -8.8 |
| MANOEUVRE | 11 | 11 | 10 | 0.28 | +463 | +46.3 |
| MISSILES NEXT TURN | 258 | 172 | 10 | 0.28 | +21 | +2.1 |
| BREAK OUTCOMES | 93 | 89 | 9 | 0.25 | +285 | +31.7 |
| CASTING BLOCK | 14 | 14 | 9 | 0.25 | +202 | +22.4 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| BLOCKED CHARGE SKIPPED | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| LOST CHARGE | 160 | 158 | 8 | 0.22 | +198 | +24.8 |
| OVERRUN ON | 20 | 20 | 8 | 0.22 | +191 | +23.9 |
| RESTRAINS TO SHOOT | 8 | 8 | 8 | 0.22 | +254 | +31.7 |
| CHAFF PASSED | 7 | 7 | 7 | 0.19 | -44 | -6.4 |
| HUNT IN PAIRS | 28 | 13 | 7 | 0.19 | +195 | +27.8 |
| MODEL FACING | 7 | 7 | 7 | 0.19 | +1171 | +167.3 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| PURSUES BIG PREY | 7 | 7 | 7 | 0.19 | -329 | -47.0 |
| SURE CHARGE BEATS ADVANCE | 7 | 7 | 7 | 0.19 | -228 | -32.6 |
| PIVOT GUARDS FLANK | 6 | 6 | 6 | 0.17 | -164 | -27.3 |
| REFUSING RETIRES | 19 | 19 | 6 | 0.17 | -1 | -0.1 |
| STAY WEIGHED | 6 | 6 | 6 | 0.17 | +560 | +93.3 |
| BEST PREY | 35 | 35 | 5 | 0.14 | +86 | +17.2 |
| BEST PRIZE | 5 | 5 | 5 | 0.14 | -262 | -52.4 |
| EDGE GIVE GROUND | 11 | 10 | 5 | 0.14 | +120 | +24.1 |
| ONE OBJECTIVE FORMULA | 163 | 74 | 5 | 0.14 | +140 | +27.9 |
| PERIAPT WORTH | 5 | 5 | 5 | 0.14 | +399 | +79.8 |
| RAIDS THE BAGGAGE NEXT TURN | 5 | 5 | 5 | 0.14 | +247 | +49.3 |
| WIDER SPREAD | 198 | 190 | 5 | 0.14 | +16 | +3.3 |
| KEEP FALLS | 4 | 4 | 4 | 0.11 | +104 | +26.1 |
| LONG SHOT | 35 | 34 | 4 | 0.11 | -8 | -2.1 |
| OVERRUNS AWAY | 38 | 37 | 4 | 0.11 | +60 | +15.1 |
| SURE REACH TOGETHER | 34 | 24 | 4 | 0.11 | +5 | +1.2 |
| WAR ENGINE CHARGES | 8 | 8 | 4 | 0.11 | +339 | +84.8 |
| ELIXIR WORTH | 3 | 3 | 3 | 0.08 | +33 | +11.0 |
| FLEES FROM CHARGE | 25 | 25 | 3 | 0.08 | +42 | +14.0 |
| NEEDED THERE | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| SPELLS IN THE FIGHT | 47 | 44 | 3 | 0.08 | +60 | +20.2 |
| STOPS | 6 | 6 | 3 | 0.08 | +10 | +3.3 |
| WOUNDED STAYS OUT | 3 | 3 | 3 | 0.08 | -514 | -171.5 |
| BACKUP TARGETS | 37 | 15 | 2 | 0.06 | +6 | +2.9 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +14 | +7.1 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +51 | +25.6 |
| BLOWS WHERE AIMED | 23 | 21 | 1 | 0.03 | +6 | +6.0 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +37 | +37.4 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -9 | -8.7 |
| CHARGER SLAIN LOST | 43 | 38 | 1 | 0.03 | +4 | +4.3 |
| DEFENSIVE FLOOR | 1 | 1 | 1 | 0.03 | +14 | +13.5 |
| HUNT ADVANCE | 4 | 4 | 1 | 0.03 | +29 | +29.1 |
| JOINT CHARGE PLAN | 6 | 6 | 1 | 0.03 | +22 | +21.5 |
| LONE WIZARD HOLDS BACK | 9 | 9 | 1 | 0.03 | -119 | -119.3 |
| MOVE SPELL IN RANGE | 6 | 2 | 1 | 0.03 | +4 | +4.1 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -4 | -3.6 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | +5 | +5.1 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 21 | 21 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 9 | 9 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 36 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 6 | 6 | 0 | 0.00 | - | - |
| CHEAP HELPER | 7 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 32 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 6 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 337 | not checked | - | - | - | - |
| GIVES UP | 6 | 5 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 4 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 32 | 30 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 40 | 40 | 0 | 0.00 | - | - |
| HUNT DROPPED | 4 | trace | - | - | - | - |
| HUNT KEPT | 3 | trace | - | - | - | - |
| HUNT RESULT | 8 | trace | - | - | - | - |
| HUNT THE GUNS | 8 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 5 | 5 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 16 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 6 | trace | - | - | - | - |
| MARCH OVER CASTS | 33 | 33 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 13 | 13 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 18 | trace | - | - | - | - |
| MOVE SPELL SPOT | 19 | not checked | - | - | - | - |
| NOT NEEDED | 26 | 26 | 0 | 0.00 | - | - |
| NOT TURNED | 357 | 357 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 31 | not checked | - | - | - | - |
| OPENS A LANE | 3 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 2787 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 22 | 22 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 87 | 87 | 0 | 0.00 | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 26 | 26 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 23 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 17 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SPELL CATCH ODDS | 3 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 20 | not checked | - | - | - | - |
| SPELL WORTH | 128 | not checked | - | - | - | - |
| STABLE ROLE | 743 | 740 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 9 | 8 | 0 | 0.00 | - | - |
| TURN WORTH | 22 | 22 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 26 | 24 | 0 | 0.00 | - | - |

### Off best figure: co-mine-a57fba0-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.14 | 12.97 | 47.7 |
| FALLBACK | gate | 0.64 | 0.78 | 32.2 |
| CHARGE NOW FIRST | rule | 0.69 | 0.64 | 41.8 |
| TURN GATE | gate | 0.44 | 0.58 | 37.1 |
| WAR ENGINE JOBS | rule | 0.39 | 0.08 | 31.0 |
| SUPPORT NARROWED | rule | 0.19 | 0.19 | 19.8 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 47.7 |
| SUPPORT REQUEST | gate | 0.17 | 0.17 | 43.5 |
| BIG CHARACTER SAFETY | rule | 0.08 | 0.14 | 11.0 |
| FIGHT ORDER BAND | gate | 0.08 | 0.14 | 1.6 |
| PATHS CROSS | rule | 0.06 | 0.14 | 21.4 |
| PURSUES BIG PREY | rule | 0.17 | 0.03 | 47.0 |
| SURE CHARGE BEATS ADVANCE | rule | 0.17 | 0.03 | 32.6 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.06 | 27.3 |
| AFTERMATH BAND | gate | 0.08 | 0.06 | 3.2 |
| BEST PRIZE | rule | 0.08 | 0.06 | 52.4 |
| CHAFF PASSED | rule | 0.08 | - | 14.8 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.03 | 35.7 |
| FACES THE THREAT | rule | - | 0.08 | 18.2 |
| MARCH ODDS | rule | 0.06 | 0.03 | 41.6 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.06 | 3.6 |
| WOUNDED STAYS OUT | rule | 0.03 | 0.06 | 171.5 |
| NO REASON | gate | 0.06 | - | 30.8 |
| SAFER THAN THE JOB | rule | 0.06 | - | 11.2 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | - | 12.4 |
| CATCH ODDS | rule | - | 0.03 | 8.7 |
| LONE CHARACTER SAFE SPOT | gate | 0.03 | - | 216.2 |
| LONE WIZARD HOLDS BACK | rule | - | 0.03 | 119.3 |
| LONG SHOT | rule | - | 0.03 | 36.7 |
| SAFE SURE CHARGE | rule | - | 0.03 | 3.6 |
| THROUGH LINE OF FIRE | rule | - | 0.03 | 0.6 |
| WHO HITS BACK | rule | 0.03 | - | 1.9 |

### Plans: co-mine-a57fba0-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 10.3 | 20% | 182 | 346 | 189% |
| Mine | charge | 3.3 | 66% | 258 | 292 | 113% |
| Mine | close in | 4.9 | 30% | 208 | 165 | 79% |
| Mine | hold | 5.1 | 32% | 314 | 0 | 0% |
| Mine | join | 0.5 | 95% | 9 | 0 | 0% |
| Mine | shoot | 10.0 | 65% | 425 | 869 | 204% |
| Mine | support | 5.1 | 93% | 52 | 0 | 0% |
| Opponent | advance | 10.8 | 15% | 160 | 259 | 162% |
| Opponent | charge | 4.6 | 51% | 409 | 397 | 97% |
| Opponent | close in | 6.1 | 26% | 357 | 230 | 64% |
| Opponent | hold | 4.3 | 31% | 309 | 0 | 0% |
| Opponent | join | 0.6 | 90% | 24 | 0 | 0% |
| Opponent | shoot | 4.2 | 56% | 85 | 199 | 233% |
| Opponent | support | 7.6 | 90% | 55 | 0 | 0% |

### Packages: hunt the guns, co-mine-a57fba0-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 5 |
| Opponent | 0.2 | 8 | 0 | 38% | 25% | 0% | 2.5 | 281 | 43 | 25% | 113 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 58 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 67 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.1 | 1 | 0 | 100% | 100% | 0% | 3.0 | 109 | 97 | 100% | 33 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 434 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 195 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 160 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.8 | 6 | 0 | 33% | 17% | 0% | 2.0 | 319 | 41 | 17% | 6 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 228 | 0 | 0% | 55 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: co-mine-a57fba0-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.0 | 40% | 59% | 24% | 14% | 27% | 0% | 9% | 55% | 9% |
| Opponent | REDIRECT COUNTER | 3.8 | 25% | 74% | 26% | 33% | 4% | 4% | 12% | 80% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: co-mine-a57fba0-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 0 (4) | 0 | 0 | 21 | 25% | 2.0 | 0 (3) | 0 (1) | - | 0 (3) | 0 (1) |
| Mine | Chaff | 34 | 45 (34) | 15 | 30 | 55 | 32% | 2.3 | 17 (14) | 0 (7) | 91 (13) | 21 (22) | 89 (12) |
| Mine | Character | 106 | 34 (106) | 34 | 0 | 41 | 17% | 2.4 | 40 (30) | 33 (53) | 0 (6) | 36 (41) | 32 (48) |
| Mine | Clean-up | 22 | 91 (22) | 59 | 32 | 49 | 23% | 3.0 | 0 (2) | 110 (16) | 78 (4) | 102 (10) | 85 (12) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast | 4 | 148 (4) | 148 | 0 | 100 | 0% | 3.2 | 0 (2) | 295 (2) | - | 113 (3) | 243 (1) |
| Mine | Fast Hammer | 41 | 67 (41) | 52 | 15 | 42 | 15% | 2.6 | 65 (27) | 78 (9) | 63 (5) | 65 (25) | 72 (16) |
| Mine | Fragile | 4 | 0 (4) | 0 | 0 | 73 | 25% | 3.3 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |
| Mine | Hammer | 65 | 23 (65) | 14 | 9 | 44 | 23% | 2.4 | 20 (13) | 24 (45) | 21 (7) | 20 (40) | 26 (25) |
| Mine | Holder | 31 | 74 (31) | 10 | 64 | 35 | 29% | 3.2 | 49 (7) | 113 (17) | 4 (7) | 109 (18) | 34 (13) |
| Mine | Shooter | 34 | 60 (34) | 31 | 30 | 39 | 3% | 1.6 | 68 (8) | 62 (21) | 39 (5) | 62 (25) | 53 (9) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | War machine | 56 | 60 (56) | 60 | 0 | 44 | 4% | 1.3 | 87 (16) | 50 (30) | 35 (10) | 29 (9) | 65 (47) |
| Mine | Wizard | 17 | 39 (17) | 39 | 0 | 39 | 0% | 2.1 | 156 (5) | 0 (8) | 0 (1) | 113 (7) | 0 (7) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Chaff | 75 | 54 (75) | 32 | 22 | 51 | 37% | 3.0 | 33 (31) | 36 (17) | 91 (27) | 58 (56) | 40 (19) |
| Opponent | Character | 97 | 49 (97) | 49 | 0 | 25 | 23% | 2.3 | 50 (44) | 44 (39) | 80 (7) | 41 (53) | 62 (37) |
| Opponent | Clean-up | 11 | 67 (11) | 41 | 27 | 21 | 18% | 2.8 | 12 (3) | 69 (6) | 99 (2) | 85 (6) | 57 (5) |
| Opponent | Fast | 1 | 142 (1) | 142 | 0 | 0 | 0% | 4.0 | - | 142 (1) | - | 142 (1) | - |
| Opponent | Fast Hammer | 60 | 52 (60) | 31 | 21 | 49 | 30% | 2.9 | 60 (26) | 43 (25) | 52 (9) | 49 (39) | 59 (21) |
| Opponent | Fragile | 17 | 48 (17) | 48 | 0 | 57 | 24% | 2.3 | 79 (5) | 55 (8) | 0 (4) | 58 (14) | 0 (3) |
| Opponent | Hammer | 65 | 45 (65) | 27 | 18 | 41 | 34% | 3.1 | 26 (20) | 52 (38) | 39 (7) | 54 (41) | 32 (24) |
| Opponent | Holder | 29 | 37 (29) | 13 | 24 | 42 | 41% | 3.8 | 0 (6) | 33 (17) | 102 (6) | 46 (16) | 27 (13) |
| Opponent | Shooter | 33 | 88 (33) | 47 | 41 | 51 | 0% | 1.4 | 49 (9) | 88 (21) | 230 (3) | 83 (18) | 93 (15) |
| Opponent | Support | 6 | 0 (6) | 0 | 0 | 67 | 33% | 3.0 | 0 (2) | 0 (1) | - | - | 0 (3) |
| Opponent | War machine | 6 | 27 (6) | 27 | 0 | 40 | 17% | 1.0 | 30 (3) | 22 (3) | - | 30 (3) | 22 (3) |
| Opponent | Wizard | 19 | 9 (19) | 9 | 0 | 51 | 0% | 2.1 | 11 (11) | 21 (3) | 0 (2) | 0 (9) | 32 (7) |

### Charged fights: co-mine-a57fba0-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 245 | 144 | 2.0 | 1.2 | 72 | 13 | +59 | 1 of 8 | 7 of 8 | +24 | +71 |
| Mine | Chaos Dwarfs | 4 | 214 | 106 | 2.0 | 1.1 | 53 | 24 | +29 | 1 of 8 | 5 of 8 | +0 | +33 |
| Mine | Dwarfen Mountain Holds | 3 | 462 | 209 | 1.7 | 1.0 | 126 | 12 | +114 | 2 of 5 | 3 of 5 | - | +114 |
| Mine | Empire of Man | 5 | 311 | 139 | 1.4 | 1.3 | 100 | 54 | +46 | 1 of 7 | 6 of 7 | +0 | +64 |
| Mine | Grand Cathay | 4 | 487 | 342 | 3.8 | 1.1 | 91 | 39 | +52 | 4 of 15 | 12 of 15 | +107 | +48 |
| Mine | High Elf Realms | 4 | 173 | 356 | 3.2 | 1.2 | 109 | 0 | +109 | 5 of 13 | 9 of 13 | +193 | +94 |
| Mine | Kingdom of Bretonnia | 1 | 420 | 377 | 6.0 | 1.0 | 63 | 46 | +17 | 4 of 6 | 4 of 6 | - | +17 |
| Mine | Lizardmen | 1 | 55 | 974 | 6.0 | 1.3 | 162 | 24 | +139 | 4 of 6 | 4 of 6 | +360 | +28 |
| Mine | Ogre Kingdoms | 2 | 118 | 0 | 2.5 | 1.2 | 0 | 0 | +0 | 1 of 5 | 3 of 5 | +0 | +0 |
| Mine | Skaven | 2 | 158 | 194 | 2.5 | 1.0 | 78 | 0 | +78 | 1 of 5 | 5 of 5 | - | +78 |
| Mine | Tomb Kings of Khemri | 2 | 158 | 504 | 4.0 | 1.2 | 126 | 33 | +93 | 2 of 8 | 7 of 8 | +99 | +91 |
| Mine | Vampire Counts | 2 | 192 | 220 | 3.5 | 1.0 | 63 | 58 | +5 | 3 of 7 | 5 of 7 | - | +5 |
| Mine | Warriors of Chaos | 2 | 0 | 242 | 5.0 | 1.2 | 48 | 23 | +25 | 4 of 10 | 7 of 10 | +0 | +32 |
| **Mine** | all armies | 36 | 254 | 244 | 2.9 | 1.1 | 85 | 26 | +60 | 33 of 103 | 77 of 103 | +97 | +53 |
| Opponent | Empire of Man | 1 | 235 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 5 | 256 | 485 | 3.8 | 1.3 | 128 | 8 | +120 | 13 of 19 | 11 of 19 | +235 | +67 |
| Opponent | Lizardmen | 2 | 0 | 641 | 4.5 | 1.0 | 142 | 16 | +127 | 4 of 9 | 7 of 9 | - | +127 |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 885 | 6.0 | 1.0 | 148 | 35 | +112 | 4 of 18 | 14 of 18 | - | +112 |
| Opponent | Skaven | 4 | 140 | 148 | 2.0 | 1.0 | 74 | 102 | -28 | 3 of 8 | 4 of 8 | - | -28 |
| Opponent | Tomb Kings of Khemri | 2 | 92 | 642 | 4.5 | 1.1 | 143 | 75 | +68 | 2 of 9 | 6 of 9 | +25 | +73 |
| Opponent | Vampire Counts | 6 | 12 | 361 | 4.5 | 1.1 | 80 | 12 | +68 | 13 of 27 | 19 of 27 | +116 | +60 |
| Opponent | Warriors of Chaos | 7 | 0 | 686 | 3.9 | 1.1 | 178 | 22 | +156 | 13 of 27 | 18 of 27 | +324 | +142 |
| Opponent | Wood Elf Realms | 6 | 178 | 322 | 4.5 | 1.1 | 71 | 49 | +23 | 9 of 27 | 16 of 27 | +4 | +25 |
| **Opponent** | all armies | 36 | 94 | 476 | 4.0 | 1.1 | 119 | 32 | +87 | 61 of 144 | 95 of 144 | +160 | +78 |

### Effective charges: co-mine-a57fba0-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 8 | 1 (net -104) | 1 (net +178) | 0 | 1 (net +0) | 0 | 4 (net +62) | 1 | 0% (0 of 7) |
| Mine | Chaos Dwarfs | 8 | 0 | 1 (net -189) | 2 (net +46) | 1 (net +0) | 1 (net +0) | 3 (net +110) | 0 | 25% (2 of 8) |
| Mine | Dwarfen Mountain Holds | 5 | 3 (net +169) | 0 | 0 | 1 (net +60) | 0 | 1 (net +0) | 0 | 0% (0 of 5) |
| Mine | Empire of Man | 7 | 2 (net +117) | 0 | 1 (net +0) | 2 (net +42) | 0 | 2 (net +0) | 0 | 14% (1 of 7) |
| Mine | Grand Cathay | 15 | 2 (net -102) | 0 | 0 | 7 (net +79) | 2 (net +54) | 3 (net +110) | 1 | 0% (0 of 14) |
| Mine | High Elf Realms | 13 | 2 (net +332) | 0 | 1 (net +0) | 6 (net +76) | 1 (net +0) | 3 (net +101) | 0 | 8% (1 of 13) |
| Mine | Kingdom of Bretonnia | 6 | 2 (net -32) | 0 | 0 | 0 | 0 | 2 (net +28) | 2 | 0% (0 of 4) |
| Mine | Lizardmen | 6 | 3 (net -47) | 0 | 1 (net +0) | 1 (net +719) | 0 | 1 (net +255) | 0 | 17% (1 of 6) |
| Mine | Ogre Kingdoms | 5 | 1 (net +0) | 1 (net +0) | 2 (net +0) | 0 | 0 | 1 (net +0) | 0 | 40% (2 of 5) |
| Mine | Skaven | 5 | 0 | 0 | 0 | 0 | 0 | 4 (net +97) | 1 | 0% (0 of 4) |
| Mine | Tomb Kings of Khemri | 8 | 0 | 0 | 1 (net +100) | 2 (net +132) | 4 (net +94) | 0 | 1 | 14% (1 of 7) |
| Mine | Vampire Counts | 7 | 0 | 0 | 1 (net -407) | 2 (net +95) | 4 (net +63) | 0 | 0 | 14% (1 of 7) |
| Mine | Warriors of Chaos | 10 | 2 (net +58) | 0 | 3 (net +9) | 0 | 2 (net +0) | 2 (net +86) | 1 | 33% (3 of 9) |
| Opponent | High Elf Realms | 19 | 1 (net +0) | 0 | 7 (net +88) | 6 (net +165) | 0 | 2 (net +270) | 3 | 44% (7 of 16) |
| Opponent | Lizardmen | 9 | 0 | 0 | 2 (net +155) | 1 (net +369) | 1 (net +310) | 3 (net +0) | 2 | 29% (2 of 7) |
| Opponent | Orc & Goblin Tribes | 18 | 2 (net +148) | 3 (net +156) | 0 | 3 (net +73) | 1 (net +83) | 1 (net -110) | 8 | 0% (0 of 10) |
| Opponent | Skaven | 8 | 1 (net -322) | 1 (net -41) | 1 (net +0) | 2 (net +217) | 0 | 3 (net -98) | 0 | 12% (1 of 8) |
| Opponent | Tomb Kings of Khemri | 9 | 2 (net -68) | 0 | 1 (net +92) | 1 (net +210) | 3 (net -15) | 1 (net +4) | 1 | 12% (1 of 8) |
| Opponent | Vampire Counts | 27 | 7 (net +87) | 0 | 3 (net +40) | 4 (net +8) | 5 (net +73) | 7 (net +61) | 1 | 12% (3 of 26) |
| Opponent | Warriors of Chaos | 27 | 5 (net -29) | 1 (net +526) | 7 (net +115) | 3 (net +263) | 3 (net +219) | 5 (net +338) | 3 | 29% (7 of 24) |
| Opponent | Wood Elf Realms | 27 | 7 (net -99) | 0 | 7 (net +23) | 4 (net -20) | 1 (net -79) | 7 (net +160) | 1 | 27% (7 of 26) |

### Charged fights, damage counted: co-mine-a57fba0-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 18 | 232 | 326 | +56 | 171 | 84 | +87 | +37.2 |
| Mine | 50-54% | 3 | 75 | 178 | -4 | 68 | 63 | +6 | +7.3 |
| Mine | Effective (55-75%) | 12 | 283 | 229 | -16 | 77 | 75 | +3 | +0.9 |
| Mine | 76-89% | 23 | 328 | 191 | +101 | 136 | 27 | +109 | +33.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 26 | 206 | 142 | +80 | 99 | 12 | +87 | +42.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 14 | 466 | 104 | +53 | 62 | 2 | +60 | +12.9 |
| Mine | No odds | 7 | 367 | 201 | +29 | 69 | 28 | +42 | +11.3 |
| Mine | All fights | 103 | 289 | 195 | +60 | 109 | 36 | +73 | +25.3 |
| Opponent | Long shot (under 50%) | 25 | 193 | 270 | -16 | 77 | 109 | -32 | -16.4 |
| Opponent | 50-54% | 5 | 367 | 166 | +191 | 220 | 28 | +192 | +52.2 |
| Opponent | Effective (55-75%) | 28 | 252 | 231 | +75 | 96 | 38 | +57 | +22.8 |
| Opponent | 76-89% | 24 | 270 | 215 | +124 | 169 | 34 | +135 | +49.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 29 | 303 | 187 | +117 | 164 | 30 | +133 | +44.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 14 | 393 | 90 | +92 | 134 | 38 | +96 | +24.6 |
| Opponent | No odds | 19 | 321 | 191 | +116 | 161 | 49 | +112 | +34.8 |
| Opponent | All fights | 144 | 282 | 205 | +87 | 135 | 49 | +86 | +30.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| co-mine-a57fba0-p4 | move | 343 | 87 (25%) | 63 (18%) | 53 (15%) | 203 (59%) |
| co-mine-a57fba0-p4 | objective | 397 | 57 (14%) | 47 (12%) | 49 (12%) | 291 (73%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

# Doctrine scorecard: co-opp-a57fba0-p4

### Scorecard: co-opp-a57fba0-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 11 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 15 | 1 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | no | 5 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Opponent | no | 8 | 1 | 6 | 2 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | yes | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 30 |
| L0214 | 4 | 1 | Opponent | no | 1 | 1 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 1 | 5 | 4 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | no | 1 | 2 | 2 | 1 | 0 | 0 | 0 | 565 |
| L0315 | 3 | 1 | Opponent | yes | 12 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | 6 | 1 | 1 | 0 | 0 | 0 | 590 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 4 | 5 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | no | 6 | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 3 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Mine | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 1193 |
| L0520 | 4 | 1 | Opponent | no | 7 | - | 2 | 2 | 1 | 0 | 0 | 210 |
| L0608 | 2 | 1 | Mine | - | - | - | 1 | 3 | 0 | 0 | 0 | 984 |
| L0608 | 2 | 1 | Opponent | - | - | - | 0 | 3 | 0 | 0 | 0 | 769 |
| L0624 | 6 | 1 | Mine | no | 0 | 4 | 4 | 1 | 0 | 0 | 0 | 984 |
| L0624 | 6 | 1 | Opponent | no | 6 | 3 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | yes | - | 2 | 1 | 3 | 1 | 0 | 0 | 420 |
| L0713 | 5 | 1 | Opponent | yes | - | 2 | 4 | 1 | 0 | 0 | 0 | 302 |
| L0729 | 3 | 1 | Mine | yes | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 375 |
| L0729 | 3 | 1 | Opponent | no | 2 | 2 | 4 | 0 | 2 | 0 | 0 | 0 |
| L0819 | 3 | 1 | Mine | no | 0 | - | 0 | 0 | 1 | 0 | 0 | 1007 |
| L0819 | 3 | 1 | Opponent | no | 8 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 0 | 5 | 0 | 3 | 0 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | 6 | 1 | 1 | 0 | 0 | 0 | 537 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 4 | 4 | 0 | 0 | 0 | 40 |
| L1017 | 3 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1017 | 3 | 1 | Opponent | yes | 9 | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| L1034 | 2 | 1 | Mine | - | - | 3 | 0 | 1 | 0 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 3 | 0 | 2 | 0 | 0 | 0 | 500 |
| L1126 | 4 | 1 | Mine | no | 1 | - | 0 | 0 | 0 | 0 | 0 | 330 |
| L1126 | 4 | 1 | Opponent | no | 4 | 3 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 1 | 4 | 0 | 0 | 0 | 0 |
| L1314 | 6 | 1 | Mine | no | 3 | 3 | 1 | 1 | 0 | 0 | 0 | 140 |
| L1314 | 6 | 1 | Opponent | no | 11 | 2 | 3 | 1 | 0 | 0 | 0 | 123 |
| L1331 | 5 | 1 | Mine | yes | - | 5 | 3 | 3 | 1 | 0 | 0 | 302 |
| L1331 | 5 | 1 | Opponent | yes | - | 1 | 1 | 3 | 1 | 0 | 0 | 170 |
| L1427 | 5 | 1 | Mine | yes | - | 5 | 5 | 2 | 0 | 0 | 0 | 177 |
| L1427 | 5 | 1 | Opponent | yes | - | 3 | 2 | 3 | 1 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | yes | - | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 2 | 6 | 1 | 0 | 0 | 0 | 245 |
| L1621 | 1 | 1 | Mine | no | 3 | 2 | 4 | 1 | 0 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 0 | - | 4 | 2 | 0 | 0 | 0 | 565 |
| L1719 | 3 | 1 | Mine | no | 1 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Opponent | yes | 2 | 2 | 8 | 0 | 1 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Mine | no | 2 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 0 | 2 | 7 | 1 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | yes | - | 2 | 2 | 2 | 1 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | yes | - | 1 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2021 | 5 | 1 | Mine | yes | - | 6 | 4 | 2 | 1 | 0 | 0 | 210 |
| L2021 | 5 | 1 | Opponent | no | - | 5 | 3 | 3 | 0 | 0 | 0 | 355 |
| L2123 | 5 | 1 | Mine | no | - | - | 2 | 3 | 0 | 0 | 0 | 940 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 6 | 0 | 1 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | yes | 1 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | yes | 0 | 1 | 4 | 1 | 0 | 0 | 0 | 190 |
| L2331 | 3 | 1 | Mine | no | 0 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Opponent | yes | 8 | 5 | 3 | 1 | 1 | 0 | 0 | 170 |
| L2527 | 1 | 1 | Mine | no | 0 | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 0 | 1 | 3 | 4 | 0 | 0 | 0 | 190 |
| L2634 | 6 | 1 | Mine | no | 3 | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 6 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Mine | - | - | 2 | 7 | 2 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 1 | 2 | 4 | 3 | 0 | 0 | 0 | 170 |
| L3234 | 6 | 1 | Opponent | no | 1 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 32% | 1.8 | 2.8 | 2.5 | 1.2 | 0.2 | 0.0 | 0.0 | 296.1 |
| **Average** | | | Opponent | 43% | 4.9 | 2.2 | 3.0 | 1.8 | 0.3 | 0.0 | 0.0 | 106.4 |

### KPIs: co-opp-a57fba0-p4

Rules off - Mine only: BREAK OUTCOMES, OVERRUN ON, STAND AND SHOOT, FLEES FROM CHARGE.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 26% (45 of 171) | 1% (2 of 182) | 13% (47 of 353) |
| Winner chose to follow up after the loser gave ground |  | 96% (51 of 53); on the table 96% | 100% (61 of 61); on the table 100% | 98% (112 of 114); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 75% (6 of 8); on the table 88% | 92% (11 of 12); on the table 92% | 85% (17 of 20); on the table 90% |
| Winner chose to pursue after the loser fled |  | 76% (25 of 33); on the table 76% | 80% (24 of 30); on the table 83% | 78% (49 of 63); on the table 79% |
| Winner chose to follow up or pursue (all three) |  | 87% (82 of 94); on the table 88% | 93% (96 of 103); on the table 94% | 90% (178 of 197); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 26% (70 of 266) | 31% (54 of 175) | 28% (124 of 441) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 39% (70 of 181) | 46% (54 of 118) | 41% (124 of 299) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 60% (27 of 45) | 60% (42 of 70) | 60% (69 of 115) |
| Points that never fought | lower | 36% (24351 of 67942) | 33% (23835 of 71984) | 34% (48186 of 139926) |
|   infantry points that never fought | lower | 46% (7083 of 15347) | 56% (7696 of 13804) | 51% (14779 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 65% (175 of 270) | 52% (147 of 280) | 59% (322 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 86% (19 of 22); 1.5 uses a game | 89% (8 of 9); 0.4 uses a game | 87% (27 of 31); 1.0 uses a game |
| Bound items with another spell used |  | 31% (5 of 16); 0.3 uses a game | 25% (5 of 20); 0.1 uses a game | 28% (10 of 36); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 63% (12 of 19); 0.3 uses a game | 80% (12 of 15); 0.4 uses a game | 71% (24 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 60% (34627 of 57750) | 44% (28167 of 63347) | 52% (62794 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (23%) | 0.9 (26%) | 2.1 (24%) |
| MARCHED: its unit marched | 1.2 (23%) | 0.4 (11%) | 1.6 (18%) |
| CHARGED: its unit charged | 0.6 (10%) | 0.3 (8%) | 0.8 (9%) |
| IN COMBAT: engaged in combat | 1.1 (19%) | 0.8 (24%) | 1.9 (21%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (7%) | 0.2 (3%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (1%) | 0.1 (1%) |
| GONE: slain | 1.0 (18%) | 0.6 (17%) | 1.6 (18%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (4%) | 0.2 (5%) | 0.4 (4%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.1 | 1.4 | 2.0 | 3.4 | 0.4 | 2.2 |
| not cast | 3.1 | 2.5 | 2.9 | 8.8 | 1.6 | 20.6 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (54%) | 0.3 (12%) | 2.1 (24%) | 0.2 (12%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.6 (18%) | 0.3 (21%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.8 (9%) | 0.1 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.1 (3%) | 0.6 (19%) | 1.9 (21%) | 0.4 (25%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (5%) | 0.2 (7%) | 0.3 (12%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (5%) | 0.1 (2%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.5 (3%) |
| GONE: slain | 0.9 (29%) | 0.3 (13%) | 0.7 (24%) | 1.6 (18%) | 0.2 (12%) | 3.7 (18%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (11%) | 0.1 (6%) | 0.1 (3%) | 0.4 (4%) | 0.0 (2%) | 0.9 (4%) |
| STUPIDITY: Stupidity | 0.1 (4%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.2 (9%) | 0.0 (0%) | 0.0 (0%) | 0.4 (25%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.4 (44%) | 0.1 (6%) | 0.8 (29%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.0 (68%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.4 a game | 0.7 a game | 1.0 a game |
| stood (cast and not dispelled) | 56% (25 of 45) | 54% (7 of 13) | 55% (32 of 58) |
| the unit moved after it | 68% (17 of 25) | 71% (5 of 7) | 69% (22 of 32) |
| it charged on its next turn | 12% (3 of 25) | 14% (1 of 7) | 12% (4 of 32) |
| the enemy charged it first | 24% (6 of 25) | 14% (1 of 7) | 22% (7 of 32) |
| it fought by the end of its next turn | 12% (3 of 25) | 14% (1 of 7) | 12% (4 of 32) |
| it moved out of a charge the enemy had planned (not charged first) | 8% (2 of 25) | 14% (1 of 7) | 9% (3 of 32) |
| none of these (no charge, no fight, no charge escaped) | 68% (17 of 25) | 43% (3 of 7) | 62% (20 of 32) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (576 of 903) | 49% (260 of 527) | 58% (836 of 1430) |
|   cavalry | 54% (42 of 78) | 68% (67 of 99) | 62% (109 of 177) |
|   character | 47% (49 of 105) | 19% (24 of 129) | 31% (73 of 234) |
|   chariot | 54% (56 of 104) | 67% (10 of 15) | 55% (66 of 119) |
|   infantry | 62% (174 of 280) | 56% (130 of 231) | 59% (304 of 511) |
|   monster | 39% (21 of 54) | 21% (6 of 29) | 33% (27 of 83) |
|   war machine | 83% (234 of 282) | 96% (23 of 24) | 84% (257 of 306) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.8 (19%) | 1.8 (24%) | 3.5 (21%) |
| CHARGED: it charged | 1.3 (14%) | 1.7 (23%) | 3.0 (18%) |
| FLEEING: it fled or was fleeing | 0.1 (2%) | 0.1 (1%) | 0.2 (2%) |
| IN COMBAT: it fought this turn or the last | 0.8 (9%) | 0.6 (7%) | 1.3 (8%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD FIRE: a target, but it held its fire | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 2.4 (26%) | 1.2 (16%) | 3.6 (22%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (6%) | 0.6 (8%) | 1.1 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.6 (18%) | 1.5 (20%) | 3.1 (19%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR | 0.3 (4%) | 0.0 (0%) | 0.4 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.0 | 1.2 | 84% | 4.7 pts | 23 pts |
| character | 2.4 | 0.9 | 75% | 7.4 pts | 18 pts |
| chariot | 1.9 | 1.0 | 66% | 13.8 pts | 26 pts |
| infantry | 12.4 | 4.4 | 74% | 9.5 pts | 117 pts |
| monster | 0.9 | 0.1 | 91% | 2.4 pts | 2 pts |
| war machine | 7.1 | 5.9 | 65% | 28.9 pts | 206 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.0 | 6.8 | 5.4 |
| Charges that made contact a game | 2.9 | 4.8 | 3.9 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.82 declared, 0.53 contact (17 units) | 0.88 declared, 0.62 contact (16 units) | 0.85 declared, 0.58 contact (33 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.56 declared, 0.56 contact (9 units) | 1.30 declared, 0.80 contact (10 units) | 0.95 declared, 0.68 contact (19 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.50 declared, 0.36 contact (250 units) | 0.73 declared, 0.53 contact (294 units) | 0.62 declared, 0.45 contact (544 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 58% (47 of 81) | 38% (6 of 16) | 17% (1 of 6) | 52% (54 of 103) |
| Character in a unit | 77% (20 of 26) | 40% (6 of 15) | 100% (1 of 1) | 64% (27 of 42) |
| Character on its own | 90% (35 of 39) | 63% (17 of 27) | 31% (24 of 77) | 53% (76 of 143) |
| Chariot | 67% (10 of 15) | 75% (9 of 12) | - | 70% (19 of 27) |
| Infantry | 59% (49 of 83) | 48% (12 of 25) | 33% (2 of 6) | 55% (63 of 114) |
| Monster | 59% (20 of 34) | 86% (12 of 14) | - | 67% (32 of 48) |
| Monstrous | 57% (8 of 14) | 57% (8 of 14) | - | 57% (16 of 28) |
| War Machines | 77% (33 of 43) | 100% (2 of 2) | - | 78% (35 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 92% (12 of 13); on the table 92% | 27% (28 of 102) | 16% | 59% (13 of 22) | 67% (4 of 6); 2.5 uses a game | 50% (1 of 2); 1.0 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 67% (4 of 6); on the table 67% | 42% (10 of 24) | 27% | 78% (25 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (2 of 2); on the table 100% | - | 71% | 70% (19 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 79% (11 of 14); on the table 79% | 50% (9 of 18) | 53% | 69% (43 of 62) | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game | 80% (4 of 5); 0.7 uses a game |
| Grand Cathay | 4 | 92% (11 of 12); on the table 92% | 23% (19 of 84) | 36% | 57% (21 of 37) | 100% (9 of 9); 5.8 uses a game | 0% (0 of 2); 0.0 uses a game | 75% (3 of 4); 0.8 uses a game |
| High Elf Realms | 9 | 88% (14 of 16); on the table 88% | 14% (5 of 35) | 36% | 51% (36 of 70) | 100% (7 of 7); 2.8 uses a game | 23% (7 of 30); 0.8 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (5 of 5); on the table 100% | - | 35% | 17% (1 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 94% (16 of 17); on the table 94% | 67% (4 of 6) | 28% | 52% (11 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 100% (8 of 8); on the table 100% | 33% (2 of 6) | 44% | 93% (13 of 14) | 50% (1 of 2); 1.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (8 of 8); on the table 100% | 29% (12 of 42) | 13% | 33% (8 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 6 | 80% (12 of 15); on the table 93% | 24% (10 of 41) | 39% | 69% (31 of 45) | 100% (3 of 3); 0.8 uses a game | 0.0 uses a game | 67% (4 of 6); 0.8 uses a game |
| Tomb Kings of Khemri | 4 | 83% (5 of 6); on the table 83% | 0% (0 of 6) | 31% | 45% (9 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 97% (30 of 31); on the table 97% | 32% (19 of 59) | 27% | 50% (21 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 92% (24 of 26); on the table 92% | 33% (4 of 12) | 21% | 51% (37 of 72) | 100% (2 of 2); 0.3 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 89% (16 of 18); on the table 89% | 33% (2 of 6) | 48% | 61% (34 of 56) | 50% (1 of 2); 0.2 uses a game | 0.0 uses a game | 50% (2 of 4); 0.3 uses a game |

Flank and rear charges a unit could have turned to face (co-opp-a57fba0-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (53) | 40% (25) | 46% (78) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.44 | 1.11 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.39 | 0.11 | 0.50 |
| ...with the charger already in that arc before they moved (per game) | 0.36 | 0.33 | 0.69 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.83 | 1.22 | 3.06 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.92 | 0.42 | 1.33 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.47 | 5.81 | 11.28 |

### Quality by phase: co-opp-a57fba0-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 54% (73 of 135) | 43% (88 of 203) |
| Strategy | Shoot objectives carried out (shot that target) | 44% (187 of 427) | 44% (78 of 179) |
| Strategy | Close-in objectives charged next turn | 12% (20 of 173) | 16% (36 of 228) |
| Strategy | Support requests answered (helper made contact too) | 53% (8 of 15) | 42% (15 of 36) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 57% (8 of 14) | 80% (8 of 10) |
| Strategy | Joined characters whose unit fought | 57% (21 of 37) | 69% (18 of 26) |
| Strategy | Lone characters that fought | 76% (65 of 86) | 77% (69 of 90) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 1.2 | 1.8 |
| Movement | Points that never moved of their own | 296.1 | 106.4 |
| Movement | Fights charged into per game | 2.8 | 3.9 |
| Movement | Charges with odds: long shots (under 50%) | 16 of 89, net +35 | 25 of 120, net +29 |
| Movement | Charges with odds: sweet spot (55-75%) | 13 of 89, net +0 | 28 of 120, net +111 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 8 of 89, net +105 | 16 of 120, net +128 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 22 of 89, net +84 | 23 of 120, net +127 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.4 | 8.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 51% (190 of 375) | 38% (112 of 294) |
| Shooting | Points destroyed by shooting units | 53.9 | 30.4 |
| Shooting | War machine shots | 6.5 | 0.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 63% (148 of 234) | 30% (7 of 23) |
| Shooting | Points destroyed by war machines | 86.0 | 4.9 |
| Magic | Magic missiles cast | 1.3 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 38% (18 of 47) | 19% (7 of 37) |
| Magic | Wounds caused by magic missiles | 3.6 | 1.0 |
| Magic | Wounds caused by other spells | 1.2 | 1.7 |
| Magic | Points destroyed by magic (all spells) | 104.9 | 23.5 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.4 / 0.8 / 0.2 | 1.9 / 0.5 / 0.7 / 0.1 |
| Combat | Points destroyed in combat | 240.9 | 454.4 |
| Combat | Points run down | 71.8 | 110.6 |
| Combat | Net points per charged fight, damage counted | +67 | +99 |
| Combat | Net per 100 charger points, damage counted | +25.0 | +31.1 |
| Combat | First round won (charged fights) | 72% | 69% |
| Combat | Net points per charged fight | +52 | +104 |
| Combat | Net points per supported fight / lone fight | +48 / +52 | +142 / +95 |
| Combat | Charged fights on a top-3 enemy unit | 36 of 100 | 69 of 140 |
| Game | Points lost | 747.2 | 672.4 |
| Game | VP from objectives | 483.3 | 520.8 |
| Game | Lone holders (player turns) | 1.8 | 4.9 |

- Mine won / drew / lost: 14 / 5 / 17 of 36 ended games (of 36); mean margin (Mine - Opponent) -114 VP
- The side that went first won 17 of 31 games with a winner
- Points traded per game (both sides' losses): 1420
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: co-opp-a57fba0-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 4.0 |
| ADVANCE WORTH | 5.7 | -121.5 | 164.8 | 94.9 | 4.3 | -111.0 | 178.4 | 72.4 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.5 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 12.9 | 0.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.6 | +2.4 | 0.0 | 13.4 | 0.4 | +2.2 | 0.0 | 5.4 |
| BEST FACING | 0.5 | +9.3 | 0.0 | 16.4 | 0.2 | +6.0 | 0.0 | 15.0 |
| BEST FIRST | 1.1 | +53.3 | 26.8 | 24.4 | 0.8 | +39.6 | 22.1 | 20.4 |
| BEST OVERALL | 0.3 | +15.6 | 0.0 | 0.0 | 0.1 | +3.0 | 0.0 | 6.2 |
| BEST PREY | 0.3 | +14.5 | 10.1 | 10.1 | 0.5 | +15.7 | 11.4 | 1.7 |
| BEST PRIZE | 0.2 | -10.6 | 1.8 | 22.1 | 0.1 | +0.4 | 11.3 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | -0.6 | 0.0 | 0.0 | 0.2 | -1.3 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 4.7 | 0.0 | 0.1 | +0.0 | 10.1 | 0.0 |
| BLOCKED WHEEL | 0.3 | +8.2 | 0.0 | 3.8 | 0.4 | +6.8 | 0.0 | 17.3 |
| BLOWS WHERE AIMED | 0.1 | -10.2 | 8.7 | 1.4 | 0.4 | -45.4 | 64.1 | 14.2 |
| BOMBING RUN | 0.1 | +3.2 | 0.0 | 2.9 | - | - | - | - |
| BREAK OUTCOMES | - | - | - | - | 3.3 | +13.1 | 320.6 | 62.2 |
| CANNON PLAN MISSED | 0.6 | +0.0 | 42.5 | 13.3 | 0.0 | +0.0 | 10.6 | 0.0 |
| CANNON PLANNED TARGET | 5.2 | +213.1 | 379.2 | 92.4 | 0.6 | +25.7 | 37.8 | 7.4 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | -0.2 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | -0.7 | 0.0 | 17.3 | 0.1 | +0.0 | 47.6 | 0.0 |
| CAST JOB | 0.8 | +22.0 | 46.8 | 24.9 | 0.5 | +8.9 | 41.2 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +25.4 | 13.7 | 8.9 | 0.1 | +3.2 | 6.5 | 0.0 |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 31.6 | 0.4 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +0.7 | 0.0 | 6.1 | - | - | - | - |
| CHAFF IN THE MOVE | 0.8 | +46.8 | 0.0 | 23.0 | 2.2 | +126.8 | 0.0 | 38.8 |
| CHAFF PASSED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | -0.3 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 2.4 | +0.0 | 215.9 | 125.0 | 2.8 | +0.0 | 306.6 | 73.8 |
| CHARGE NOW WEIGHED | 0.7 | -68.1 | 13.6 | 4.9 | 0.5 | -23.9 | 17.4 | 13.4 |
| CHARGER SLAIN LOST | 0.4 | -12.1 | 33.6 | 12.8 | 0.9 | -21.7 | 83.9 | 19.2 |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.5 | 0.0 | 11.1 | 0.1 | +0.0 | 0.0 | 30.0 |
| CHEAP HELPER | 0.1 | +0.0 | 2.8 | 3.8 | 0.1 | +0.0 | 20.3 | 10.4 |
| COMBAT PIVOT | 0.4 | +0.0 | 25.1 | 36.6 | 0.4 | +0.0 | 26.6 | 49.0 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 1.8 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.8 | +61.1 | 27.7 | 38.3 | 0.2 | +24.8 | 0.0 | 0.0 |
| COVER ONCE | 8.4 | -440.4 | 0.0 | 197.9 | 6.6 | -496.6 | 0.0 | 135.6 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 0.0 | 1.0 | - | - | - | - |
| DEFENSIVE FLOOR | - | - | - | - | 0.1 | +9.5 | 17.0 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +0.5 | 3.0 | 0.0 | 0.3 | +7.4 | 19.2 | 4.4 |
| ELIXIR WORTH | 0.0 | +0.4 | 0.0 | 0.0 | 0.1 | +0.7 | 0.0 | 9.7 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.8 | +126.8 | 0.0 | 57.8 | 1.2 | +88.7 | 0.0 | 30.8 |
| FALLBACK BY WORTH | 5.4 | +74.8 | 0.0 | 106.1 | 5.9 | +61.8 | 0.0 | 83.3 |
| FIGHT LIFT | 0.1 | +1.1 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| FIRE AND FLEE | - | - | - | - | 0.1 | +0.7 | 1.8 | 5.9 |
| FLANK NOT WEIGHED | 5.2 | +0.0 | 0.0 | 131.6 | 5.1 | +0.0 | 0.0 | 92.9 |
| FLEES FROM CHARGE | - | - | - | - | 0.5 | +16.8 | 27.8 | 5.4 |
| FOLLOW UP WEIGHED | 0.9 | +138.5 | 0.0 | 85.8 | 1.1 | +105.9 | 0.0 | 14.9 |
| FRIENDS SHOTS CHECKED | 0.1 | +13.1 | 0.0 | 1.0 | 0.2 | +6.0 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.1 | -1.2 | 16.3 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -0.7 | 5.2 | 1.2 |
| GROUND FLIERS | 0.1 | +1.3 | 0.0 | 0.0 | 0.1 | +1.3 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | - | - | - | - | 0.0 | +0.0 | 6.1 | 3.1 |
| HELPER UNSEEN | 0.2 | +0.0 | 20.4 | 2.0 | 0.5 | +0.0 | 38.3 | 20.1 |
| HILL BY ITS CHANCE | 0.6 | -67.4 | 0.0 | 3.4 | 0.4 | -40.6 | 0.0 | 13.5 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 8.0 | -147.3 | 458.7 | 209.0 | 8.8 | -201.0 | 612.1 | 134.1 |
| HUNT ADVANCE | - | - | - | - | 0.1 | +2.5 | 2.4 | 0.0 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.3 | +7.8 | 0.0 | 0.0 | 0.4 | +29.0 | 0.0 | 15.0 |
| HUNT KEPT | - | - | - | - | 0.1 | +0.8 | 6.9 | 1.2 |
| HUNT RESULT | - | - | - | - | 0.2 | +10.8 | 3.9 | 1.2 |
| HUNT THE GUNS | - | - | - | - | 0.2 | +54.5 | 6.9 | 0.0 |
| IDLE COST | 17.6 | -282.4 | 0.0 | 184.5 | 20.2 | -328.0 | 0.0 | 206.3 |
| INVITES THE FIGHT | 1.3 | +8.7 | 38.2 | 14.9 | 1.0 | +6.1 | 41.8 | 41.9 |
| JOINT CHARGE PLAN | 0.0 | +0.1 | 0.0 | 0.0 | 0.1 | +5.5 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.2 | -6.2 | 14.3 | 4.4 |
| KEEP FALLS | 0.1 | +1.7 | 0.0 | 6.6 | 0.0 | +0.1 | 0.0 | 3.2 |
| KEEPS ITS PREY | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.6 | +48.3 | 127.5 | 60.6 | 2.1 | +64.2 | 244.0 | 34.4 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.2 | +46.5 | 83.7 | 44.8 | - | - | - | - |
| KILLS COUNT NEXT TURN | 5.7 | +201.8 | 280.9 | 101.7 | 6.5 | +287.6 | 275.1 | 119.5 |
| LONE CHARACTER SAFE SPOT | 0.3 | +8.5 | 4.4 | 2.5 | 0.1 | +8.1 | 0.0 | 3.2 |
| LONE WIZARD HOLDS BACK | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 5.2 | 10.7 |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | +0.3 | 10.1 | 8.9 | 0.4 | +0.1 | 8.0 | 3.1 |
| LOST CHARGE | 2.7 | -26.3 | 76.5 | 88.7 | 1.6 | -29.7 | 52.2 | 72.0 |
| LURE BY WHAT IT DRAWS | 0.1 | -14.5 | 0.0 | 1.1 | 0.2 | -23.8 | 0.0 | 7.2 |
| MAKE SURE TOGETHER | 0.7 | +51.2 | 5.3 | 14.0 | 0.8 | +51.9 | 8.6 | 5.2 |
| MANOEUVRE | 0.3 | +8.6 | 0.0 | 16.6 | 0.1 | +4.6 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +1.1 | 0.0 | 0.0 | 0.1 | +0.2 | 0.0 | 5.4 |
| MARCH CHECK | 0.4 | +7.7 | 0.0 | 4.5 | 0.2 | +5.0 | 0.0 | 3.2 |
| MARCH ODDS | 0.4 | +26.0 | 16.9 | 10.2 | 0.2 | +16.9 | 16.6 | 0.0 |
| MARCH OVER CASTS | 0.5 | +33.6 | 0.0 | 18.8 | 0.3 | +17.5 | 0.0 | 5.4 |
| MAX FOR POSITIONING | 6.2 | +99.9 | 0.0 | 131.9 | 6.9 | +94.6 | 0.0 | 125.4 |
| MISSILES IN THE MOVE | 3.6 | +127.0 | 0.0 | 86.8 | 1.9 | +27.6 | 0.0 | 92.6 |
| MISSILES NEXT TURN | 4.5 | +83.6 | 0.0 | 142.9 | 2.6 | +20.1 | 0.0 | 92.6 |
| MODEL FACING | 0.2 | +45.1 | 0.0 | 5.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 5.3 | 19.6 | 0.1 | +0.0 | 10.5 | 0.0 |
| MOVE AND CAST | 0.3 | +4.7 | 0.0 | 9.0 | 0.2 | +6.5 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.2 | +4.3 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL NOT WORTH | 0.0 | -0.0 | 0.0 | 9.9 | 0.0 | -0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.5 | -31.9 | 30.6 | 71.1 | 0.1 | -4.5 | 0.0 | 2.6 |
| MOVE SPELL SPOT | 0.5 | +0.0 | 0.0 | 20.5 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 3.3 | +166.2 | 169.7 | 59.2 | 4.6 | +317.3 | 267.3 | 70.0 |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +1.3 | 0.0 | 0.0 | 0.0 | +3.1 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.0 | +0.3 | 0.0 | 1.1 | - | - | - | - |
| NOT NEEDED | 0.2 | -10.8 | 23.9 | 12.1 | 0.4 | -21.5 | 45.0 | 3.1 |
| NOT TURNED | 5.5 | +41.8 | 0.0 | 144.4 | 5.8 | +77.9 | 0.0 | 135.7 |
| NOT WORTH A CAST | 0.5 | -0.4 | 0.0 | 24.0 | 0.3 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 15.2 | -656.3 | 13.6 | 212.0 | 16.0 | -699.9 | 28.4 | 223.6 |
| ONE FIGHT FORMULA | 8.8 | -147.7 | 21.5 | 166.9 | 8.8 | -177.2 | 40.2 | 183.8 |
| ONE OBJECTIVE FORMULA | 2.2 | -125.1 | 0.0 | 15.7 | 2.1 | -129.4 | 0.0 | 46.4 |
| OPENS A LANE | 0.3 | +2.7 | 41.4 | 35.3 | - | - | - | - |
| OPENS UP | 0.5 | +30.5 | 30.7 | 6.5 | 0.2 | +34.7 | 4.1 | 9.7 |
| OVERRUN ON | - | - | - | - | 0.6 | +13.3 | 48.0 | 10.1 |
| OVERRUN THREAT | - | - | - | - | 0.0 | +0.5 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.6 | +22.5 | 49.2 | 31.9 | 0.5 | +13.8 | 81.4 | 29.6 |
| PATHS CROSS | 2.4 | +182.0 | 0.0 | 45.2 | 3.0 | +228.5 | 0.0 | 40.1 |
| PERIAPT WORTH | 0.0 | +3.4 | 0.0 | 0.0 | 0.1 | +9.5 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -2.6 | 0.0 | 0.0 | 0.2 | -5.1 | 0.0 | 15.0 |
| PLAN RESULT | 39.4 | +1596.6 | 1617.4 | 1065.6 | 39.2 | +1158.0 | 1772.7 | 971.5 |
| PURSUES BIG PREY | 0.0 | -2.1 | 0.0 | 0.0 | 0.1 | -1.6 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +9.6 | 0.0 | 2.2 | 0.1 | +8.2 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 1.2 | +21.3 | 0.0 | 22.6 | 1.9 | +16.3 | 0.0 | 48.9 |
| RANDOM MOVER NO PROMISE | 0.4 | -18.2 | 31.4 | 4.0 | 0.4 | -13.0 | 6.7 | 12.8 |
| REDIRECT BY WHAT IT STOPS | 0.6 | -9.5 | 0.0 | 21.9 | 1.9 | -48.8 | 0.0 | 26.6 |
| REDIRECT COUNTER | 2.3 | +128.6 | 0.0 | 51.8 | 4.3 | +321.8 | 0.0 | 68.7 |
| REDIRECT WEIGHED | 0.3 | -6.8 | 1.8 | 15.9 | 0.4 | +12.9 | 28.3 | 5.9 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 4.6 | 0.3 | +0.0 | 0.0 | 19.1 |
| RESERVE FALL BACK | 0.4 | +16.5 | 0.0 | 6.2 | 0.6 | +15.8 | 0.0 | 14.4 |
| RESTRAINS TO SHOOT | 0.2 | +7.3 | 0.0 | 10.9 | 0.1 | +2.6 | 0.0 | 0.0 |
| RISK BY ARC | 2.9 | +138.9 | 220.3 | 136.9 | 2.4 | +31.4 | 261.5 | 66.8 |
| RISK ONCE | 1.6 | +17.8 | 11.6 | 48.9 | 4.2 | +124.5 | 50.9 | 198.6 |
| SAFER THAN THE JOB | 0.9 | +57.5 | 0.0 | 0.0 | 0.4 | +15.7 | 0.0 | 11.9 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.9 | 0.1 | +0.0 | 0.0 | 1.8 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.9 | 0.1 | +0.0 | 0.0 | 1.8 |
| SCREEN BY WHAT IT SAVES | 0.2 | -16.5 | 0.0 | 0.0 | 0.5 | -34.0 | 0.0 | 0.8 |
| SEARCH SPOT | 2.4 | +104.2 | 0.0 | 45.7 | 2.9 | +103.4 | 0.0 | 38.4 |
| SELF MOVE SPELL | 0.2 | +41.5 | 0.0 | 0.0 | 0.5 | +31.4 | 0.0 | 9.1 |
| SET UP TOGETHER | 1.0 | +74.0 | 24.4 | 31.8 | 1.5 | +99.5 | 39.5 | 13.6 |
| SET-UP ANY TARGET | 0.4 | +62.4 | 16.4 | 13.9 | 0.1 | +11.3 | 0.0 | 0.0 |
| SET-UP MISSED | 0.0 | +4.0 | 0.0 | 0.0 | 0.0 | +7.2 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.0 | -0.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.6 | +54.5 | 49.4 | 14.2 | 1.4 | +33.5 | 16.0 | 52.3 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 3.8 |
| SHOT REPLANNED | 0.5 | +0.0 | 93.6 | 10.3 | 0.1 | +0.0 | 17.0 | 0.0 |
| SHOTS IN THE MOVE | 14.9 | +607.5 | 0.0 | 226.8 | 6.8 | +148.6 | 0.0 | 125.7 |
| SPELL CATCH ODDS | 0.1 | -1.0 | 8.9 | 0.0 | - | - | - | - |
| SPELL OFF EDGE | 0.0 | +1.5 | 4.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.4 | +62.4 | 16.4 | 13.9 | 0.2 | +31.9 | 0.0 | 0.0 |
| SPELL WORTH | 1.3 | +24.3 | 92.8 | 121.3 | 2.2 | +46.0 | 89.8 | 92.5 |
| SPELLS IN THE FIGHT | 0.7 | +5.7 | 73.1 | 39.1 | 1.0 | -14.7 | 130.4 | 15.8 |
| STABLE ROLE | 11.1 | +0.0 | 454.1 | 229.6 | 9.8 | +0.0 | 328.1 | 160.6 |
| STAND AND SHOOT | - | - | - | - | 0.4 | -2.2 | 26.8 | 23.6 |
| STANDS TO CAST | 0.0 | +1.4 | 3.4 | 8.9 | 0.0 | +0.8 | 0.0 | 0.0 |
| STAY WEIGHED | 0.1 | +6.5 | 0.0 | 0.0 | - | - | - | - |
| STOPS | - | - | - | - | 0.1 | +2.7 | 6.9 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.5 | +38.1 | 0.0 | 0.0 | 0.2 | +4.7 | 0.0 | 11.1 |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 8.8 |
| SUPPORT NARROWED | 6.4 | -61.4 | 348.8 | 113.4 | 8.4 | -72.0 | 428.1 | 104.4 |
| SUPPORTS | 4.7 | +65.4 | 223.9 | 60.2 | 6.0 | +78.9 | 199.5 | 39.9 |
| SURE CHARGE BEATS ADVANCE | 0.0 | -0.5 | 0.0 | 1.4 | 0.1 | -4.2 | 17.8 | 0.0 |
| SURE REACH TOGETHER | 0.5 | -1.0 | 19.1 | 13.6 | 0.6 | -0.3 | 10.1 | 20.3 |
| THROUGH LINE OF FIRE | 0.3 | +21.8 | 0.0 | 15.7 | 0.4 | +8.8 | 0.0 | 1.9 |
| TURN WORTH | 0.4 | -29.6 | 29.8 | 6.5 | 0.2 | -15.5 | 5.6 | 9.7 |
| TWO OR MORE ARRIVE | 0.2 | +0.7 | 0.0 | 13.9 | 0.5 | +3.0 | 0.0 | 1.8 |
| WAIT AFTER COSTS | 6.8 | -289.4 | 294.7 | 103.9 | 7.2 | -365.0 | 356.7 | 128.4 |
| WALKS TO THE FIGHT | 1.9 | +12.2 | 52.8 | 48.1 | 0.8 | +5.5 | 20.0 | 0.0 |
| WAR ENGINE CHARGES | 0.2 | +11.8 | 7.0 | 14.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.8 | +0.0 | 37.6 | 34.7 | 0.1 | +0.0 | 12.6 | 4.0 |
| WEARS DOWN | 1.4 | +48.4 | 116.9 | 79.1 | 1.6 | +53.0 | 177.8 | 40.1 |
| WHO HITS BACK | 0.2 | +22.9 | 0.0 | 0.0 | 0.2 | +14.5 | 0.0 | 7.4 |
| WHOLE FIGHT | 0.1 | +5.9 | 6.7 | 5.2 | 0.8 | +53.4 | 123.1 | 3.4 |
| WHOLE FIGHT GAIN | 0.4 | +15.9 | 14.9 | 6.6 | 0.7 | +48.8 | 46.9 | 16.0 |
| WIDER SPREAD | 2.6 | -9.0 | 215.4 | 102.3 | 3.4 | -3.0 | 338.5 | 47.3 |
| WOUNDED STAYS OUT | - | - | - | - | 0.1 | +0.0 | 2.0 | 13.7 |

### Rule changes: co-opp-a57fba0-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1125 | 1125 | 1125 | 31.25 | -48823 | -43.4 |
| PATHS CROSS | 192 | 192 | 192 | 5.33 | +14777 | +77.0 |
| SEARCH SPOT | 193 | 193 | 188 | 5.22 | +7500 | +39.9 |
| MOVE TO CHARGE | 286 | 286 | 167 | 4.64 | +5982 | +35.8 |
| SUPPORTS | 385 | 385 | 149 | 4.14 | +1699 | +11.4 |
| KILLS COUNT NEXT TURN | 441 | 441 | 148 | 4.11 | +4845 | +32.7 |
| FACES THE THREAT | 110 | 110 | 110 | 3.06 | +7758 | +70.5 |
| WAIT AFTER COSTS | 506 | 506 | 89 | 2.47 | +1354 | +15.2 |
| COVER ONCE | 540 | 315 | 83 | 2.31 | +1300 | +15.7 |
| FALLBACK BY WORTH | 406 | 406 | 83 | 2.31 | +4918 | +59.3 |
| SHOTS IN THE MOVE | 780 | 556 | 77 | 2.14 | +1771 | +23.0 |
| FOLLOW UP WEIGHED | 71 | 71 | 71 | 1.97 | +8799 | +123.9 |
| RANDOM MOVE BY FIGURES | 115 | 115 | 69 | 1.92 | +1352 | +19.6 |
| BEST FIRST | 68 | 68 | 68 | 1.89 | +3344 | +49.2 |
| CHAFF IN THE MOVE | 108 | 104 | 67 | 1.86 | +2655 | +39.6 |
| ADVANCE WORTH | 360 | 360 | 66 | 1.83 | +2469 | +37.4 |
| REDIRECT COUNTER | 240 | 127 | 66 | 1.83 | +5224 | +79.2 |
| ONE FIGHT FORMULA | 633 | 393 | 64 | 1.78 | +262 | +4.1 |
| ADVANCE LANE KEPT | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 50 | 50 | 50 | 1.39 | +0 | +0.0 |
| IDLE COST | 1360 | 774 | 50 | 1.39 | +582 | +11.6 |
| SHOOTS FROM THE BEST SPOT | 106 | 106 | 49 | 1.36 | +939 | +19.2 |
| CHARGE NOW FIRST | 187 | 187 | 48 | 1.33 | -1867 | -38.9 |
| SAFER THAN THE JOB | 48 | 48 | 48 | 1.33 | +2634 | +54.9 |
| RISK BY ARC | 190 | 182 | 45 | 1.25 | +1258 | +28.0 |
| CHARGE NOW WEIGHED | 44 | 44 | 44 | 1.22 | +3172 | +72.1 |
| CANNON SIGHT KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| MISSILES IN THE MOVE | 197 | 131 | 42 | 1.17 | +944 | +22.5 |
| WALKS TO THE FIGHT | 95 | 95 | 42 | 1.17 | +178 | +4.2 |
| HONEST WORTH | 605 | 600 | 41 | 1.14 | +410 | +10.0 |
| SET UP TOGETHER | 90 | 75 | 39 | 1.08 | +2025 | +51.9 |
| RESERVE FALL BACK | 36 | 36 | 36 | 1.00 | +1163 | +32.3 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| RISK ONCE | 209 | 152 | 33 | 0.92 | +1203 | +36.4 |
| CANNON PLANNED TARGET | 208 | 208 | 31 | 0.86 | -393 | -12.7 |
| MAX FOR POSITIONING | 470 | 295 | 30 | 0.83 | +173 | +5.8 |
| COMBAT PIVOT | 29 | 29 | 29 | 0.81 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| REDIRECT WEIGHED | 28 | 28 | 28 | 0.78 | +828 | +29.6 |
| INVITES THE FIGHT | 82 | 82 | 27 | 0.75 | +80 | +3.0 |
| STOPS SHORT OF THE FLANK | 26 | 26 | 26 | 0.72 | +1541 | +59.3 |
| BEST FACING | 25 | 25 | 25 | 0.69 | +550 | +22.0 |
| BLOCKED WHEEL | 25 | 25 | 25 | 0.69 | +540 | +21.6 |
| MARCH ODDS | 25 | 25 | 25 | 0.69 | +265 | +10.6 |
| SHOT REPLANNED | 24 | 24 | 24 | 0.67 | +0 | +0.0 |
| CAST JOB | 45 | 45 | 23 | 0.64 | +433 | +18.8 |
| THROUGH LINE OF FIRE | 23 | 23 | 23 | 0.64 | +1103 | +47.9 |
| MOVE AND CAST | 21 | 21 | 21 | 0.58 | +404 | +19.3 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 38 | 36 | 21 | 0.58 | +1005 | +47.9 |
| MARCH CHECK | 21 | 20 | 19 | 0.53 | +348 | +18.3 |
| STUCK PIVOT | 19 | 19 | 19 | 0.53 | +0 | +0.0 |
| WAR ENGINE JOBS | 35 | 35 | 19 | 0.53 | -655 | -34.5 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +41 | +2.3 |
| CASTER AWAY FROM SCREEN | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| KEEPS ITS TARGET | 135 | 135 | 17 | 0.47 | +365 | +21.5 |
| WHO HITS BACK | 16 | 16 | 16 | 0.44 | +1011 | +63.2 |
| BEST OVERALL | 14 | 14 | 14 | 0.39 | +672 | +48.0 |
| MAKE SURE TOGETHER | 51 | 33 | 14 | 0.39 | +891 | +63.7 |
| WEARS DOWN | 106 | 100 | 14 | 0.39 | +362 | +25.8 |
| MANOEUVRE | 16 | 16 | 13 | 0.36 | +472 | +36.3 |
| OPENS UP | 25 | 25 | 13 | 0.36 | +497 | +38.2 |
| BEST PRIZE | 12 | 12 | 12 | 0.33 | -728 | -60.7 |
| BIG CHARACTER SAFETY | 12 | 12 | 12 | 0.33 | -68 | -5.7 |
| FRIENDS SHOTS CHECKED | 11 | 11 | 11 | 0.31 | +685 | +62.3 |
| KILLS COUNT | 44 | 41 | 11 | 0.31 | +712 | +64.7 |
| PIVOT GUARDS FLANK | 11 | 11 | 11 | 0.31 | -278 | -25.3 |
| BREAK OUTCOMES | 120 | 119 | 10 | 0.28 | +251 | +25.1 |
| WHOLE FIGHT | 32 | 31 | 10 | 0.28 | +889 | +88.9 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| BLOCKED CHARGE SKIPPED | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| CASTING BLOCK | 13 | 13 | 8 | 0.22 | +238 | +29.7 |
| MISSILES NEXT TURN | 256 | 169 | 8 | 0.22 | +5 | +0.6 |
| MODEL FACING | 8 | 8 | 8 | 0.22 | +1622 | +202.7 |
| RESTRAINS TO SHOOT | 8 | 8 | 8 | 0.22 | +358 | +44.7 |
| BEST PREY | 29 | 29 | 7 | 0.19 | +171 | +24.4 |
| CHAFF PASSED | 7 | 7 | 7 | 0.19 | -12 | -1.8 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| SUPPORT NARROWED | 533 | 533 | 7 | 0.19 | -42 | -6.0 |
| LOST CHARGE | 154 | 153 | 6 | 0.17 | +123 | +20.5 |
| RAIDS THE BAGGAGE NEXT TURN | 7 | 7 | 6 | 0.17 | +327 | +54.6 |
| WIDER SPREAD | 215 | 204 | 6 | 0.17 | +14 | +2.3 |
| FLEES FROM CHARGE | 19 | 19 | 5 | 0.14 | +66 | +13.2 |
| LONG SHOT | 24 | 23 | 5 | 0.14 | -11 | -2.3 |
| ONE OBJECTIVE FORMULA | 156 | 72 | 5 | 0.14 | +84 | +16.9 |
| OVERRUNS AWAY | 40 | 38 | 5 | 0.14 | +130 | +25.9 |
| PERIAPT WORTH | 5 | 5 | 5 | 0.14 | +462 | +92.5 |
| REFUSING RETIRES | 20 | 20 | 5 | 0.14 | -1 | -0.2 |
| HUNT IN PAIRS | 27 | 12 | 4 | 0.11 | +68 | +17.1 |
| KEEP FALLS | 4 | 4 | 4 | 0.11 | +104 | +26.1 |
| SPELLS IN THE FIGHT | 60 | 56 | 4 | 0.11 | +95 | +23.7 |
| STAY WEIGHED | 4 | 4 | 4 | 0.11 | +236 | +58.9 |
| SURE CHARGE BEATS ADVANCE | 4 | 4 | 4 | 0.11 | -169 | -42.2 |
| WOUNDED STAYS OUT | 4 | 4 | 4 | 0.11 | -260 | -64.9 |
| BACKUP TARGETS | 37 | 16 | 3 | 0.08 | +16 | +5.2 |
| BOMBING RUN | 3 | 3 | 3 | 0.08 | +114 | +38.2 |
| CHARGER SLAIN LOST | 46 | 41 | 3 | 0.08 | +179 | +59.7 |
| EDGE GIVE GROUND | 13 | 13 | 3 | 0.08 | +12 | +3.8 |
| ELIXIR WORTH | 3 | 3 | 3 | 0.08 | +41 | +13.8 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.08 | +25 | +8.5 |
| OVERRUN ON | 20 | 19 | 3 | 0.08 | +103 | +34.2 |
| PURSUES BIG PREY | 3 | 3 | 3 | 0.08 | -132 | -44.1 |
| STOPS | 5 | 5 | 3 | 0.08 | +12 | +3.8 |
| SURE REACH TOGETHER | 39 | 27 | 3 | 0.08 | +5 | +1.6 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| NEEDED THERE | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | +22 | +11.1 |
| WAR ENGINE CHARGES | 6 | 6 | 2 | 0.06 | +146 | +73.0 |
| CARRIES OUT COUNTER | 3 | 3 | 1 | 0.03 | -8 | -8.4 |
| CARRIES OUT SET-UP | 8 | 8 | 1 | 0.03 | -24 | -24.5 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| DEFENSIVE FLOOR | 2 | 2 | 1 | 0.03 | +13 | +12.8 |
| HUNT ADVANCE | 4 | 4 | 1 | 0.03 | +29 | +29.1 |
| JOINT CHARGE PLAN | 6 | 6 | 1 | 0.03 | +22 | +21.5 |
| KEEPS ITS PREY | 2 | 2 | 1 | 0.03 | +0 | +0.5 |
| LONE WIZARD HOLDS BACK | 9 | 9 | 1 | 0.03 | -119 | -119.3 |
| MOVE SPELL IN RANGE | 6 | 2 | 1 | 0.03 | +4 | +4.1 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +7 | +6.9 |
| OPENS A LANE | 12 | 3 | 1 | 0.03 | +11 | +10.8 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 18 | 17 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 24 | 24 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 41 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 6 | 6 | 0 | 0.00 | - | - |
| CHEAP HELPER | 9 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 36 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 7 | 7 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 5 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 369 | not checked | - | - | - | - |
| GIVES UP | 5 | 4 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 4 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 27 | 25 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 37 | 37 | 0 | 0.00 | - | - |
| HUNT DROPPED | 4 | trace | - | - | - | - |
| HUNT KEPT | 3 | trace | - | - | - | - |
| HUNT RESULT | 7 | trace | - | - | - | - |
| HUNT THE GUNS | 7 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 8 | 8 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 16 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 11 | 11 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 6 | trace | - | - | - | - |
| MARCH OVER CASTS | 30 | 30 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 11 | 11 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 2 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 19 | trace | - | - | - | - |
| MOVE SPELL SPOT | 21 | not checked | - | - | - | - |
| NOT NEEDED | 23 | 23 | 0 | 0.00 | - | - |
| NOT TURNED | 406 | 406 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 31 | not checked | - | - | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 2828 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 27 | 27 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 90 | 90 | 0 | 0.00 | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 24 | 24 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 23 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 19 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 3 | not checked | - | - | - | - |
| SPELL OFF EDGE | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 21 | not checked | - | - | - | - |
| SPELL WORTH | 126 | not checked | - | - | - | - |
| STABLE ROLE | 749 | 748 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 13 | 13 | 0 | 0.00 | - | - |
| TURN WORTH | 20 | 20 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 25 | 25 | 0 | 0.00 | - | - |

### Off best figure: co-opp-a57fba0-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.75 | 14.03 | 45.6 |
| FALLBACK | gate | 0.69 | 0.94 | 27.5 |
| CHARGE NOW FIRST | rule | 0.61 | 0.69 | 39.7 |
| TURN GATE | gate | 0.42 | 0.42 | 29.1 |
| WAR ENGINE JOBS | rule | 0.42 | 0.11 | 34.5 |
| CANNON PLANNED TARGET | rule | 0.36 | - | 42.6 |
| SUPPORT REQUEST | gate | 0.17 | 0.17 | 46.8 |
| AFTERMATH BAND | gate | 0.08 | 0.22 | 2.5 |
| BEST PRIZE | rule | 0.17 | 0.14 | 66.2 |
| PIVOT GUARDS FLANK | rule | 0.14 | 0.17 | 25.3 |
| BIG CHARACTER SAFETY | rule | 0.11 | 0.11 | 9.7 |
| FIGHT ORDER BAND | gate | 0.06 | 0.17 | 2.3 |
| PATHS CROSS | rule | 0.08 | 0.08 | 15.5 |
| REDIRECT WEIGHED | rule | 0.08 | 0.06 | 62.7 |
| STOPS SHORT OF THE FLANK | rule | 0.08 | 0.06 | 4.5 |
| SUPPORT NARROWED | rule | 0.03 | 0.11 | 8.3 |
| MARCH ODDS | rule | 0.08 | 0.03 | 32.2 |
| SURE CHARGE BEATS ADVANCE | rule | 0.03 | 0.08 | 42.2 |
| WOUNDED STAYS OUT | rule | - | 0.11 | 64.9 |
| CHAFF PASSED | rule | - | 0.08 | 4.1 |
| PURSUES BIG PREY | rule | 0.03 | 0.06 | 44.1 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | 0.03 | 11.8 |
| CHARGE NOW WEIGHED | rule | 0.06 | - | 2.7 |
| FACES THE THREAT | rule | - | 0.06 | 20.7 |
| LONE CHARACTER SAFE SPOT | gate | 0.03 | 0.03 | 19.8 |
| CARRIES OUT COUNTER | rule | 0.03 | - | 8.4 |
| CARRIES OUT SET-UP | rule | 0.03 | - | 24.5 |
| FRIENDS SHOTS CHECKED | rule | - | 0.03 | 3.6 |
| LONE WIZARD HOLDS BACK | rule | - | 0.03 | 119.3 |
| LONG SHOT | rule | - | 0.03 | 36.7 |
| RULE SWITCHED OFF | gate | 0.03 | - | 51.7 |
| SAFER THAN THE JOB | rule | 0.03 | - | 13.9 |
| THROUGH LINE OF FIRE | rule | 0.03 | - | 2.6 |
| WHO HITS BACK | rule | 0.03 | - | 0.9 |

### Plans: co-opp-a57fba0-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 10.6 | 20% | 182 | 361 | 198% |
| Mine | charge | 3.2 | 56% | 223 | 256 | 115% |
| Mine | close in | 4.8 | 28% | 218 | 188 | 86% |
| Mine | hold | 5.0 | 32% | 314 | 0 | 0% |
| Mine | join | 0.6 | 95% | 10 | 0 | 0% |
| Mine | shoot | 10.0 | 60% | 382 | 792 | 208% |
| Mine | support | 5.3 | 93% | 53 | 0 | 0% |
| Opponent | advance | 10.9 | 14% | 176 | 279 | 158% |
| Opponent | charge | 4.6 | 49% | 423 | 433 | 102% |
| Opponent | close in | 6.3 | 29% | 362 | 251 | 69% |
| Opponent | hold | 4.4 | 32% | 300 | 0 | 0% |
| Opponent | join | 0.6 | 91% | 26 | 0 | 0% |
| Opponent | shoot | 4.0 | 53% | 76 | 204 | 269% |
| Opponent | support | 8.2 | 91% | 60 | 0 | 0% |

### Packages: hunt the guns, co-opp-a57fba0-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 5 |
| Opponent | 0.2 | 7 | 0 | 29% | 29% | 0% | 3.0 | 280 | 55 | 29% | 96 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 58 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 67 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.1 | 1 | 0 | 100% | 100% | 0% | 3.0 | 109 | 97 | 100% | 26 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 28 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 195 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 149 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.6 | 5 | 0 | 20% | 20% | 0% | 3.0 | 325 | 58 | 20% | 0 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 228 | 0 | 0% | 55 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 126 |

### Battle groups: co-opp-a57fba0-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.3 | 40% | 68% | 9% | 33% | 16% | 0% | 23% | 52% | 10% |
| Opponent | REDIRECT COUNTER | 4.3 | 24% | 86% | 24% | 56% | 0% | 4% | 21% | 71% | 4% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: co-opp-a57fba0-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 148 (4) | 148 | 0 | 0 | 25% | 2.0 | 0 (1) | 186 (3) | - | 238 (3) | 0 (1) |
| Mine | Chaff | 34 | 35 (34) | 6 | 30 | 56 | 32% | 2.3 | 13 (14) | 0 (7) | 73 (13) | 14 (22) | 75 (12) |
| Mine | Character | 106 | 32 (106) | 32 | 0 | 39 | 14% | 2.5 | 33 (28) | 31 (54) | 49 (6) | 39 (41) | 28 (47) |
| Mine | Clean-up | 22 | 76 (22) | 59 | 17 | 36 | 32% | 2.8 | 0 (2) | 96 (16) | 54 (4) | 100 (10) | 64 (12) |
| Mine | Early | 1 | 156 (1) | 156 | 0 | 0 | 0% | 6.0 | - | - | 156 (1) | 156 (1) | - |
| Mine | Fast | 4 | 148 (4) | 148 | 0 | 100 | 0% | 3.2 | 0 (2) | 295 (2) | - | 113 (3) | 243 (1) |
| Mine | Fast Hammer | 41 | 63 (41) | 43 | 20 | 41 | 15% | 3.0 | 50 (27) | 103 (9) | 60 (5) | 73 (25) | 49 (16) |
| Mine | Fragile | 4 | 0 (4) | 0 | 0 | 73 | 25% | 2.7 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |
| Mine | Hammer | 65 | 23 (65) | 13 | 10 | 49 | 20% | 2.5 | 24 (13) | 24 (45) | 16 (7) | 25 (40) | 22 (25) |
| Mine | Holder | 31 | 66 (31) | 11 | 55 | 29 | 35% | 2.9 | 40 (7) | 100 (17) | 11 (7) | 102 (18) | 26 (13) |
| Mine | Shooter | 34 | 58 (34) | 32 | 26 | 42 | 3% | 1.6 | 56 (8) | 64 (21) | 39 (5) | 60 (25) | 53 (9) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | War machine | 56 | 50 (56) | 50 | 0 | 43 | 5% | 1.3 | 65 (16) | 46 (30) | 35 (10) | 22 (9) | 55 (47) |
| Mine | Wizard | 17 | 39 (17) | 39 | 0 | 50 | 0% | 2.1 | 156 (5) | 0 (7) | 0 (1) | 136 (6) | 0 (7) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Chaff | 75 | 55 (75) | 39 | 15 | 53 | 39% | 3.2 | 44 (31) | 12 (17) | 98 (27) | 64 (56) | 22 (19) |
| Opponent | Character | 97 | 50 (97) | 50 | 0 | 25 | 18% | 2.5 | 48 (42) | 63 (37) | 31 (7) | 38 (49) | 70 (37) |
| Opponent | Clean-up | 11 | 42 (11) | 14 | 28 | 30 | 18% | 3.0 | 0 (3) | 44 (6) | 66 (2) | 25 (6) | 52 (5) |
| Opponent | Fast | 1 | 142 (1) | 142 | 0 | 0 | 0% | 4.0 | - | 142 (1) | - | 142 (1) | - |
| Opponent | Fast Hammer | 60 | 55 (60) | 34 | 21 | 43 | 25% | 3.1 | 60 (26) | 48 (25) | 54 (9) | 41 (39) | 79 (21) |
| Opponent | Fragile | 17 | 0 (17) | 0 | 0 | 51 | 35% | 1.9 | 0 (5) | 0 (8) | 0 (4) | 0 (14) | 0 (3) |
| Opponent | Hammer | 65 | 47 (65) | 30 | 18 | 34 | 37% | 3.1 | 40 (20) | 50 (38) | 45 (7) | 51 (41) | 42 (24) |
| Opponent | Holder | 29 | 28 (29) | 3 | 25 | 35 | 48% | 4.1 | 0 (8) | 23 (17) | 141 (4) | 36 (16) | 18 (13) |
| Opponent | Shooter | 33 | 65 (33) | 27 | 38 | 47 | 0% | 1.4 | 99 (9) | 46 (21) | 99 (3) | 65 (18) | 65 (15) |
| Opponent | Support | 6 | 5 (6) | 5 | 0 | 18 | 33% | 3.0 | 8 (4) | 0 (2) | - | 11 (3) | 0 (3) |
| Opponent | War machine | 6 | 27 (6) | 27 | 0 | 50 | 17% | 1.0 | 30 (3) | 22 (3) | - | 30 (3) | 22 (3) |
| Opponent | Wizard | 19 | 3 (19) | 3 | 0 | 63 | 5% | 2.0 | 8 (9) | 0 (1) | 0 (2) | 0 (7) | 17 (5) |

### Charged fights: co-opp-a57fba0-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 209 | 107 | 2.0 | 1.2 | 53 | 13 | +40 | 2 of 8 | 6 of 8 | +24 | +46 |
| Mine | Chaos Dwarfs | 4 | 226 | 65 | 2.5 | 1.1 | 26 | 56 | -30 | 2 of 10 | 3 of 10 | -189 | -13 |
| Mine | Dwarfen Mountain Holds | 3 | 462 | 189 | 1.7 | 1.0 | 114 | 12 | +102 | 2 of 5 | 3 of 5 | - | +102 |
| Mine | Empire of Man | 5 | 530 | 76 | 1.2 | 1.2 | 64 | 32 | +32 | 1 of 6 | 6 of 6 | +0 | +38 |
| Mine | Grand Cathay | 4 | 182 | 337 | 3.0 | 1.1 | 112 | 43 | +70 | 4 of 12 | 9 of 12 | +160 | +61 |
| Mine | High Elf Realms | 4 | 167 | 496 | 3.2 | 1.1 | 153 | 65 | +87 | 5 of 13 | 11 of 13 | +151 | +82 |
| Mine | Kingdom of Bretonnia | 1 | 355 | 750 | 5.0 | 1.0 | 150 | 0 | +150 | 4 of 5 | 4 of 5 | - | +150 |
| Mine | Lizardmen | 1 | 55 | 359 | 5.0 | 1.2 | 72 | 28 | +44 | 3 of 5 | 2 of 5 | +104 | +28 |
| Mine | Ogre Kingdoms | 2 | 62 | 70 | 3.0 | 1.2 | 23 | 39 | -16 | 1 of 6 | 4 of 6 | +0 | -19 |
| Mine | Skaven | 2 | 245 | 33 | 3.0 | 1.0 | 11 | 0 | +11 | 2 of 6 | 4 of 6 | - | +11 |
| Mine | Tomb Kings of Khemri | 2 | 158 | 526 | 4.0 | 1.2 | 132 | 33 | +98 | 2 of 8 | 7 of 8 | +129 | +88 |
| Mine | Vampire Counts | 2 | 150 | 95 | 3.5 | 1.1 | 27 | 61 | -33 | 5 of 7 | 5 of 7 | +0 | -39 |
| Mine | Warriors of Chaos | 2 | 0 | 518 | 4.5 | 1.0 | 115 | 3 | +112 | 3 of 9 | 8 of 9 | - | +112 |
| **Mine** | all armies | 36 | 245 | 238 | 2.8 | 1.1 | 86 | 34 | +52 | 36 of 100 | 72 of 100 | +48 | +52 |
| Opponent | Empire of Man | 1 | 235 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 5 | 221 | 558 | 4.0 | 1.2 | 140 | 7 | +132 | 10 of 20 | 14 of 20 | +297 | +77 |
| Opponent | Lizardmen | 2 | 56 | 764 | 3.5 | 1.3 | 218 | 20 | +198 | 4 of 7 | 6 of 7 | +280 | +165 |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 869 | 5.7 | 1.0 | 153 | 58 | +96 | 4 of 17 | 14 of 17 | - | +96 |
| Opponent | Skaven | 4 | 71 | 177 | 3.0 | 1.1 | 59 | 74 | -14 | 9 of 12 | 6 of 12 | -362 | +17 |
| Opponent | Tomb Kings of Khemri | 2 | 150 | 151 | 3.0 | 1.0 | 50 | 106 | -56 | 3 of 6 | 2 of 6 | - | -56 |
| Opponent | Vampire Counts | 6 | 0 | 478 | 4.7 | 1.4 | 102 | 7 | +96 | 15 of 28 | 20 of 28 | +148 | +67 |
| Opponent | Warriors of Chaos | 7 | 0 | 740 | 3.6 | 1.1 | 207 | 5 | +203 | 12 of 25 | 18 of 25 | +324 | +192 |
| Opponent | Wood Elf Realms | 6 | 13 | 336 | 4.2 | 1.2 | 81 | 13 | +67 | 12 of 25 | 16 of 25 | -18 | +94 |
| **Opponent** | all armies | 36 | 59 | 500 | 3.9 | 1.2 | 129 | 24 | +104 | 69 of 140 | 96 of 140 | +142 | +95 |

### Effective charges: co-opp-a57fba0-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 8 | 1 (net -104) | 1 (net +178) | 0 | 1 (net +0) | 0 | 4 (net +62) | 1 | 0% (0 of 7) |
| Mine | Chaos Dwarfs | 10 | 1 (net -65) | 0 | 3 (net -103) | 2 (net -94) | 1 (net +0) | 2 (net +130) | 1 | 33% (3 of 9) |
| Mine | Dwarfen Mountain Holds | 5 | 3 (net +169) | 0 | 0 | 0 | 0 | 2 (net +0) | 0 | 0% (0 of 5) |
| Mine | Empire of Man | 6 | 1 (net -19) | 0 | 2 (net +0) | 3 (net +70) | 0 | 0 | 0 | 33% (2 of 6) |
| Mine | Grand Cathay | 12 | 0 | 0 | 0 | 8 (net +73) | 1 (net +160) | 2 (net +46) | 1 | 0% (0 of 11) |
| Mine | High Elf Realms | 13 | 2 (net -134) | 1 (net +0) | 1 (net +540) | 5 (net +123) | 0 | 3 (net +199) | 1 | 8% (1 of 12) |
| Mine | Kingdom of Bretonnia | 5 | 1 (net +210) | 0 | 0 | 0 | 0 | 1 (net +0) | 3 | 0% (0 of 2) |
| Mine | Lizardmen | 5 | 2 (net +52) | 0 | 2 (net -70) | 0 | 0 | 1 (net +255) | 0 | 40% (2 of 5) |
| Mine | Ogre Kingdoms | 6 | 1 (net +0) | 1 (net +0) | 3 (net +47) | 0 | 0 | 0 | 1 | 60% (3 of 5) |
| Mine | Skaven | 6 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 4 (net +16) | 0 | 0% (0 of 6) |
| Mine | Tomb Kings of Khemri | 8 | 0 | 0 | 1 (net +100) | 2 (net +132) | 3 (net +126) | 0 | 2 | 17% (1 of 6) |
| Mine | Vampire Counts | 7 | 2 (net -48) | 0 | 1 (net -329) | 4 (net +48) | 0 | 0 | 0 | 14% (1 of 7) |
| Mine | Warriors of Chaos | 9 | 1 (net +285) | 0 | 0 | 1 (net +115) | 3 (net +101) | 3 (net +111) | 1 | 0% (0 of 8) |
| Opponent | High Elf Realms | 20 | 3 (net +128) | 0 | 8 (net +190) | 4 (net +62) | 2 (net +0) | 1 (net +364) | 2 | 44% (8 of 18) |
| Opponent | Lizardmen | 7 | 0 | 0 | 2 (net +220) | 1 (net +369) | 1 (net +120) | 0 | 3 | 50% (2 of 4) |
| Opponent | Orc & Goblin Tribes | 17 | 2 (net +148) | 2 (net +34) | 0 | 2 (net +110) | 1 (net +83) | 1 (net -110) | 9 | 0% (0 of 8) |
| Opponent | Skaven | 12 | 4 (net -120) | 1 (net -41) | 3 (net +0) | 2 (net +322) | 0 | 2 (net -148) | 0 | 25% (3 of 12) |
| Opponent | Tomb Kings of Khemri | 6 | 4 (net -160) | 0 | 1 (net +92) | 1 (net +210) | 0 | 0 | 0 | 17% (1 of 6) |
| Opponent | Vampire Counts | 28 | 5 (net +108) | 0 | 4 (net +64) | 6 (net +84) | 6 (net +140) | 6 (net +42) | 1 | 15% (4 of 27) |
| Opponent | Warriors of Chaos | 25 | 4 (net +84) | 1 (net +526) | 4 (net +115) | 3 (net +344) | 4 (net +207) | 6 (net +334) | 3 | 18% (4 of 22) |
| Opponent | Wood Elf Realms | 25 | 3 (net +94) | 2 (net +0) | 6 (net +59) | 3 (net +12) | 2 (net +90) | 7 (net +101) | 2 | 26% (6 of 23) |

### Charged fights, damage counted: co-opp-a57fba0-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 16 | 196 | 267 | +35 | 153 | 74 | +79 | +40.2 |
| Mine | 50-54% | 3 | 111 | 212 | +59 | 131 | 41 | +90 | +80.9 |
| Mine | Effective (55-75%) | 13 | 260 | 256 | +0 | 93 | 80 | +13 | +4.8 |
| Mine | 76-89% | 27 | 303 | 200 | +66 | 115 | 30 | +85 | +28.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 22 | 208 | 144 | +84 | 107 | 15 | +91 | +43.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 526 | 108 | +105 | 113 | 0 | +113 | +21.4 |
| Mine | No odds | 11 | 286 | 223 | -2 | 73 | 88 | -15 | -5.1 |
| Mine | All fights | 100 | 270 | 201 | +52 | 112 | 45 | +67 | +25.0 |
| Opponent | Long shot (under 50%) | 25 | 189 | 313 | +29 | 110 | 81 | +30 | +15.7 |
| Opponent | 50-54% | 6 | 354 | 278 | +92 | 200 | 95 | +105 | +29.5 |
| Opponent | Effective (55-75%) | 28 | 332 | 273 | +111 | 131 | 50 | +81 | +24.3 |
| Opponent | 76-89% | 22 | 250 | 187 | +148 | 171 | 28 | +143 | +57.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 23 | 349 | 208 | +127 | 158 | 28 | +130 | +37.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 16 | 564 | 114 | +128 | 132 | 12 | +119 | +21.2 |
| Opponent | No odds | 20 | 300 | 176 | +98 | 157 | 46 | +111 | +37.2 |
| Opponent | All fights | 140 | 319 | 224 | +104 | 145 | 45 | +99 | +31.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| co-opp-a57fba0-p4 | move | 376 | 98 (26%) | 75 (20%) | 54 (14%) | 224 (60%) |
| co-opp-a57fba0-p4 | objective | 401 | 56 (14%) | 45 (11%) | 50 (12%) | 295 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

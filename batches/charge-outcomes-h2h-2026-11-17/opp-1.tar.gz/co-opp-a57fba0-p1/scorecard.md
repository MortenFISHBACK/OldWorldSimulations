# Doctrine scorecard: co-opp-a57fba0-p1

### Scorecard: co-opp-a57fba0-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 12 | 3 | 1 | 1 | 0 | 0 | 0 | 77 |
| L0102 | 6 | 1 | Opponent | no | 6 | 1 | 5 | 4 | 0 | 0 | 0 | 170 |
| L0118 | 4 | 1 | Mine | no | 7 | - | 0 | 1 | 0 | 0 | 0 | 322 |
| L0118 | 4 | 1 | Opponent | no | 0 | 3 | 3 | 3 | 1 | 0 | 0 | 516 |
| L0135 | 3 | 1 | Mine | no | 8 | 2 | 0 | 2 | 1 | 0 | 0 | 55 |
| L0135 | 3 | 1 | Opponent | no | 1 | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 84 |
| L0218 | 2 | 1 | Opponent | - | - | - | 2 | 2 | 1 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 1 | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Opponent | no | 0 | 4 | 1 | 3 | 0 | 0 | 0 | 250 |
| L0319 | 1 | 1 | Mine | no | 10 | 3 | 1 | 1 | 1 | 0 | 0 | 590 |
| L0319 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 255 |
| L0405 | 3 | 1 | Mine | yes | 5 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 1 | - | 2 | 1 | 0 | 0 | 0 | 1193 |
| L0421 | 1 | 1 | Mine | no | 0 | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | 5 | 2 | 4 | 1 | 0 | 0 | 420 |
| L0508 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 548 |
| L0508 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 769 |
| L0524 | 2 | 1 | Mine | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 1258 |
| L0524 | 2 | 1 | Opponent | - | - | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 0 | 4 | 1 | 2 | 0 | 0 | 0 | 1011 |
| L0612 | 6 | 1 | Opponent | no | 3 | 2 | 2 | 0 | 1 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | 6 | 2 | 1 | 0 | 0 | 0 | 1167 |
| L0628 | 4 | 1 | Opponent | no | 0 | - | 1 | 1 | 0 | 0 | 0 | 0 |
| L0717 | 3 | 1 | Mine | yes | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 420 |
| L0717 | 3 | 1 | Opponent | yes | 4 | 2 | 6 | 1 | 1 | 0 | 0 | 175 |
| L0733 | 1 | 1 | Mine | no | 1 | 1 | 0 | 0 | 2 | 0 | 0 | 375 |
| L0733 | 1 | 1 | Opponent | no | 4 | 4 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 3 | 2 | 1 | 1 | 1 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 3 | 1 | 0 | 0 | 315 |
| L0913 | 1 | 1 | Mine | no | 3 | 3 | 1 | 0 | 0 | 0 | 0 | 537 |
| L0913 | 1 | 1 | Opponent | no | 5 | 2 | 4 | 0 | 1 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 2 | 6 | 1 | 1 | 0 | 0 | 0 | 733 |
| L0930 | 6 | 1 | Opponent | no | 2 | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 0 | 3 | 3 | 3 | 1 | 0 | 0 | 355 |
| L1114 | 4 | 1 | Mine | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 427 |
| L1114 | 4 | 1 | Opponent | no | 0 | 4 | 1 | 3 | 0 | 0 | 0 | 500 |
| L1131 | 3 | 1 | Mine | no | 3 | - | 4 | 0 | 1 | 0 | 0 | 676 |
| L1131 | 3 | 1 | Opponent | no | 0 | 5 | 1 | 1 | 3 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 1 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 8 | 6 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | no | - | 3 | 2 | 0 | 0 | 0 | 0 | 140 |
| L1319 | 5 | 1 | Opponent | no | - | 2 | 2 | 0 | 1 | 0 | 0 | 226 |
| L1335 | 3 | 1 | Mine | no | 5 | 2 | 2 | 0 | 0 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 4 | 0 | 0 | 0 | 236 |
| L1431 | 3 | 1 | Mine | no | 6 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 3 | 3 | 2 | 0 | 2 | 0 | 0 | 732 |
| L1527 | 3 | 1 | Mine | yes | 10 | 5 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 0 | 3 | 2 | 2 | 1 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | yes | - | 3 | 2 | 2 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | no | - | 4 | 0 | 2 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | no | 3 | 3 | 3 | 0 | 1 | 0 | 0 | 135 |
| L1723 | 1 | 1 | Opponent | yes | 5 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | no | - | - | 4 | 1 | 2 | 0 | 0 | 234 |
| L1823 | 5 | 1 | Opponent | yes | - | 1 | 5 | 1 | 1 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Mine | no | 1 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | no | 0 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2025 | 3 | 1 | Mine | yes | 4 | - | 1 | 2 | 2 | 0 | 0 | 860 |
| L2025 | 3 | 1 | Opponent | no | 9 | 2 | 6 | 2 | 0 | 0 | 0 | 211 |
| L2127 | 3 | 1 | Mine | no | 4 | - | 1 | 2 | 0 | 0 | 0 | 500 |
| L2127 | 3 | 1 | Opponent | no | 6 | 2 | 9 | 3 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 1 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | no | - | - | 0 | 2 | 1 | 0 | 0 | 657 |
| L2335 | 1 | 1 | Mine | no | 2 | 2 | 3 | 1 | 2 | 0 | 0 | 185 |
| L2335 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | 4 | 2 | 3 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | no | - | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Mine | no | 0 | 1 | 5 | 4 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 6 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 1 | 2 | 4 | 0 | 0 | 0 | 0 | 170 |
| L2934 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 21% | 3.2 | 2.6 | 2.1 | 1.0 | 0.4 | 0.0 | 0.0 | 333.9 |
| **Average** | | | Opponent | 9% | 2.2 | 2.7 | 2.6 | 1.8 | 0.5 | 0.0 | 0.0 | 211.7 |

### KPIs: co-opp-a57fba0-p1

Rules off - Mine only: BREAK OUTCOMES, OVERRUN ON, STAND AND SHOOT, FLEES FROM CHARGE.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 27% (47 of 171) | 2% (4 of 171) | 15% (51 of 342) |
| Winner chose to follow up after the loser gave ground |  | 100% (57 of 57); on the table 100% | 96% (47 of 49); on the table 96% | 98% (104 of 106); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 89% (8 of 9); on the table 89% | 86% (18 of 21); on the table 90% | 87% (26 of 30); on the table 90% |
| Winner chose to pursue after the loser fled |  | 78% (14 of 18); on the table 78% | 89% (40 of 45); on the table 91% | 86% (54 of 63); on the table 87% |
| Winner chose to follow up or pursue (all three) |  | 94% (79 of 84); on the table 94% | 91% (105 of 115); on the table 93% | 92% (184 of 199); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 29% (95 of 330) | 29% (61 of 210) | 29% (156 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 38% (95 of 247) | 34% (55 of 160) | 37% (150 of 407) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (18 of 27) | 51% (28 of 55) | 56% (46 of 82) |
| Points that never fought | lower | 39% (27569 of 71484) | 41% (29484 of 71889) | 40% (57053 of 143373) |
|   infantry points that never fought | lower | 48% (8162 of 16863) | 67% (8899 of 13348) | 56% (17061 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (155 of 279) | 59% (174 of 295) | 57% (329 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 95% (21 of 22); 1.9 uses a game | 70% (14 of 20); 1.2 uses a game | 83% (35 of 42); 1.5 uses a game |
| Bound items with another spell used |  | 81% (13 of 16); 0.8 uses a game | 12% (1 of 8); 0.0 uses a game | 58% (14 of 24); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 53% (10 of 19); 0.3 uses a game | 58% (7 of 12); 0.2 uses a game | 55% (17 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 50% (30024 of 59666) | 53% (33108 of 62699) | 52% (63132 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.8 (43%) | 1.4 (35%) | 4.2 (40%) |
| MARCHED: its unit marched | 0.9 (14%) | 0.6 (15%) | 1.5 (14%) |
| CHARGED: its unit charged | 0.3 (5%) | 0.3 (8%) | 0.7 (6%) |
| IN COMBAT: engaged in combat | 0.9 (14%) | 0.5 (12%) | 1.4 (13%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.5 (12%) | 0.5 (5%) |
| FLEEING: fleeing | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |
| GONE: slain | 0.9 (14%) | 0.6 (13%) | 1.4 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (7%) | 0.1 (3%) | 0.6 (5%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (1%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.4 | 1.3 | 1.3 | 4.3 | 0.6 | 1.2 |
| not cast | 3.6 | 3.0 | 3.3 | 10.7 | 1.8 | 22.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.4 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.4 (46%) | 0.3 (10%) | 4.2 (40%) | 0.5 (30%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.5 (14%) | 0.1 (6%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (6%) | 0.2 (12%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.2 (7%) | 0.3 (8%) | 1.4 (13%) | 0.2 (9%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (6%) | 0.3 (10%) | 0.5 (5%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.4 (2%) |
| GONE: slain | 0.7 (19%) | 0.4 (15%) | 0.8 (22%) | 1.4 (14%) | 0.1 (3%) | 2.8 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (9%) | 0.3 (11%) | 0.3 (8%) | 0.6 (5%) | 0.1 (5%) | 1.2 (5%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (1%) | 0.1 (2%) | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.2 (7%) | 0.0 (0%) | 0.0 (0%) | 0.6 (34%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.4 (66%) | 0.2 (7%) | 1.3 (38%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.8 (74%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.1 a game | 0.5 a game | 0.8 a game |
| stood (cast and not dispelled) | 59% (19 of 32) | 82% (14 of 17) | 67% (33 of 49) |
| the unit moved after it | 53% (10 of 19) | 79% (11 of 14) | 64% (21 of 33) |
| it charged on its next turn | 0% (0 of 19) | 0% (0 of 14) | 0% (0 of 33) |
| the enemy charged it first | 16% (3 of 19) | 7% (1 of 14) | 12% (4 of 33) |
| it fought by the end of its next turn | 16% (3 of 19) | 7% (1 of 14) | 12% (4 of 33) |
| it moved out of a charge the enemy had planned (not charged first) | 5% (1 of 19) | 0% (0 of 14) | 3% (1 of 33) |
| none of these (no charge, no fight, no charge escaped) | 79% (15 of 19) | 93% (13 of 14) | 85% (28 of 33) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (594 of 948) | 59% (349 of 592) | 61% (943 of 1540) |
|   cavalry | 54% (49 of 90) | 70% (95 of 136) | 64% (144 of 226) |
|   character | 53% (65 of 123) | 32% (34 of 106) | 43% (99 of 229) |
|   chariot | 53% (48 of 90) | 71% (27 of 38) | 59% (75 of 128) |
|   infantry | 58% (188 of 323) | 55% (125 of 227) | 57% (313 of 550) |
|   monster | 51% (23 of 45) | 45% (10 of 22) | 49% (33 of 67) |
|   war machine | 80% (221 of 277) | 92% (58 of 63) | 82% (279 of 340) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.5 (26%) | 1.6 (23%) | 4.1 (25%) |
| CHARGED: it charged | 1.1 (11%) | 1.2 (19%) | 2.3 (14%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.5 (5%) | 0.4 (6%) | 0.9 (5%) |
| FREE: none of these - no target in range or sight, or held its fire | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 1.9 (19%) | 1.9 (28%) | 3.8 (23%) |
| ONLY IN COMBAT: the only targets were in combat | 1.0 (10%) | 0.6 (9%) | 1.6 (10%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.9 (19%) | 0.8 (12%) | 2.7 (16%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| OTHER BAR | 0.4 (4%) | 0.1 (1%) | 0.5 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.8 | 1.3 | 82% | 4.4 pts | 26 pts |
| character | 3.2 | 0.7 | 86% | 3.6 pts | 11 pts |
| chariot | 2.1 | 1.3 | 68% | 13.7 pts | 29 pts |
| infantry | 12.6 | 4.4 | 75% | 7.5 pts | 95 pts |
| monster | 1.1 | 0.4 | 82% | 4.0 pts | 4 pts |
| war machine | 7.8 | 5.4 | 65% | 24.6 pts | 191 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.9 | 5.1 | 4.5 |
| Charges that made contact a game | 3.1 | 3.4 | 3.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.90 declared, 0.57 contact (21 units) | 0.57 declared, 0.14 contact (14 units) | 0.77 declared, 0.40 contact (35 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.60 declared, 0.60 contact (5 units) | 1.33 declared, 0.78 contact (9 units) | 1.07 declared, 0.71 contact (14 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.49 declared, 0.39 contact (247 units) | 0.58 declared, 0.41 contact (277 units) | 0.54 declared, 0.40 contact (524 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 56% (39 of 70) | 52% (11 of 21) | 50% (4 of 8) | 55% (54 of 99) |
| Character in a unit | 69% (24 of 35) | 76% (19 of 25) | 50% (2 of 4) | 70% (45 of 64) |
| Character on its own | 85% (44 of 52) | 54% (19 of 35) | 24% (15 of 62) | 52% (78 of 149) |
| Chariot | 50% (8 of 16) | 70% (7 of 10) | - | 58% (15 of 26) |
| Infantry | 56% (50 of 89) | 36% (13 of 36) | 50% (1 of 2) | 50% (64 of 127) |
| Monster | 62% (20 of 32) | 80% (8 of 10) | - | 67% (28 of 42) |
| Monstrous | 64% (7 of 11) | 43% (6 of 14) | - | 52% (13 of 25) |
| War Machines | 76% (31 of 41) | 100% (1 of 1) | - | 76% (32 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 87% (13 of 15); on the table 93% | 23% (32 of 138) | 46% | 55% (18 of 33) | 100% (9 of 9); 4.2 uses a game | 100% (3 of 3); 1.2 uses a game | 89% (8 of 9); 1.3 uses a game |
| Chaos Dwarfs | 3 | 100% (3 of 3); on the table 100% | 42% (10 of 24) | 28% | 38% (9 of 24) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Dwarfen Mountain Holds | 5 | 100% (6 of 6); on the table 100% | - | 59% | 63% (26 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 88% (14 of 16); on the table 88% | 47% (17 of 36) | 50% | 59% (38 of 64) | 0.0 uses a game | 100% (2 of 2); 1.3 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 5 | 100% (15 of 15); on the table 100% | 27% (29 of 108) | 51% | 50% (22 of 44) | 100% (12 of 12); 7.8 uses a game | 100% (1 of 1); 0.2 uses a game | 60% (3 of 5); 0.6 uses a game |
| High Elf Realms | 6 | 95% (18 of 19); on the table 95% | 13% (4 of 30) | 36% | 53% (26 of 49) | 100% (5 of 5); 3.0 uses a game | 44% (8 of 18); 2.2 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (3 of 3); on the table 100% | - | 43% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 100% (4 of 4); on the table 100% | - | 22% | 64% (9 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 90% (9 of 10); on the table 90% | 8% (1 of 12) | 52% | 76% (16 of 21) | 0% (0 of 3); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (10 of 10); on the table 100% | 3% (1 of 36) | 9% | 62% (15 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 4 | 92% (11 of 12); on the table 92% | 50% (15 of 30) | 33% | 59% (20 of 34) | 100% (3 of 3); 1.8 uses a game | 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| Tomb Kings of Khemri | 6 | 83% (15 of 18); on the table 83% | 0% (0 of 12) | 37% | 50% (15 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 90% (26 of 29); on the table 93% | 46% (25 of 54) | 33% | 52% (26 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 91% (21 of 23); on the table 91% | 40% (12 of 30) | 37% | 68% (50 of 74) | 100% (4 of 4); 1.8 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 100% (16 of 16); on the table 100% | 33% (10 of 30) | 42% | 56% (37 of 66) | 33% (2 of 6); 1.3 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (co-opp-a57fba0-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 42% (31) | 47% (34) | 45% (65) |
| ...free all their last turn and able to turn (per game) | 0.50 | 0.53 | 1.03 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.11 | 0.19 | 0.31 |
| ...with the charger already in that arc before they moved (per game) | 0.36 | 0.39 | 0.75 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.97 | 1.06 | 3.03 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.89 | 0.72 | 1.61 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 4.72 | 5.28 | 10.00 |

### Quality by phase: co-opp-a57fba0-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 56% (65 of 116) | 40% (65 of 162) |
| Strategy | Shoot objectives carried out (shot that target) | 44% (204 of 464) | 50% (112 of 222) |
| Strategy | Close-in objectives charged next turn | 11% (18 of 165) | 12% (29 of 251) |
| Strategy | Support requests answered (helper made contact too) | 33% (4 of 12) | 43% (10 of 23) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 67% (2 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 67% (10 of 15) | 50% (8 of 16) |
| Strategy | Joined characters whose unit fought | 28% (15 of 54) | 44% (20 of 45) |
| Strategy | Lone characters that fought | 79% (73 of 92) | 73% (66 of 91) |
| Movement | Charges halted short of contact | 0.1 | 0.1 |
| Movement | Idle units | 1.0 | 1.8 |
| Movement | Points that never moved of their own | 333.9 | 211.7 |
| Movement | Fights charged into per game | 2.8 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 16 of 84, net +28 | 16 of 94, net -100 |
| Movement | Charges with odds: sweet spot (55-75%) | 10 of 84, net +195 | 27 of 94, net +99 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 16 of 84, net +84 | 2 of 94, net +83 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 20 of 84, net +89 | 26 of 94, net +249 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.2 | 9.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (186 of 402) | 40% (132 of 334) |
| Shooting | Points destroyed by shooting units | 88.2 | 21.7 |
| Shooting | War machine shots | 6.1 | 1.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (110 of 221) | 40% (23 of 58) |
| Shooting | Points destroyed by war machines | 67.0 | 14.2 |
| Magic | Magic missiles cast | 1.7 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 30% (18 of 60) | 37% (16 of 43) |
| Magic | Wounds caused by magic missiles | 4.5 | 1.4 |
| Magic | Wounds caused by other spells | 1.1 | 0.8 |
| Magic | Points destroyed by magic (all spells) | 80.7 | 45.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.5 / 0.5 / 0.3 | 1.7 / 0.6 / 0.2 / 0.1 |
| Combat | Points destroyed in combat | 339.9 | 381.4 |
| Combat | Points run down | 55.1 | 131.8 |
| Combat | Net points per charged fight, damage counted | +67 | +106 |
| Combat | Net per 100 charger points, damage counted | +23.1 | +42.4 |
| Combat | First round won (charged fights) | 67% | 73% |
| Combat | Net points per charged fight | +69 | +106 |
| Combat | Net points per supported fight / lone fight | +97 / +66 | -46 / +125 |
| Combat | Charged fights on a top-3 enemy unit | 38 of 99 | 48 of 109 |
| Game | Points lost | 759.8 | 720.6 |
| Game | VP from objectives | 640.3 | 661.1 |
| Game | Lone holders (player turns) | 3.2 | 2.2 |

- Mine won / drew / lost: 14 / 7 / 15 of 36 ended games (of 36); mean margin (Mine - Opponent) -61 VP
- The side that went first won 14 of 29 games with a winner
- Points traded per game (both sides' losses): 1480
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: co-opp-a57fba0-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 5.1 | -160.9 | 175.9 | 84.5 | 4.2 | -153.0 | 115.3 | 57.2 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 3.6 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.1 | +0.0 | 0.0 | 6.5 | 0.3 | +0.0 | 0.0 | 4.6 |
| BACKUP TARGETS | 0.4 | +0.9 | 0.0 | 10.5 | 0.6 | +2.7 | 0.0 | 3.5 |
| BEST FACING | 0.5 | +20.2 | 0.0 | 17.9 | 0.2 | +4.9 | 0.0 | 3.5 |
| BEST FIRST | 1.0 | +50.4 | 26.0 | 11.4 | 0.8 | +35.3 | 12.2 | 19.2 |
| BEST OVERALL | 0.5 | +33.3 | 0.0 | 33.0 | 0.2 | +11.1 | 0.0 | 5.7 |
| BEST PREY | 0.5 | +24.8 | 16.7 | 28.4 | 0.7 | +32.8 | 43.9 | 22.3 |
| BEST PRIZE | 0.1 | -1.6 | 6.5 | 0.0 | 0.1 | -3.6 | 4.7 | 0.0 |
| BIG CHARACTER SAFETY | 0.1 | -0.9 | 0.0 | 15.0 | 0.1 | -0.9 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 4.1 | 10.5 | 0.1 | +0.0 | 2.6 | 4.0 |
| BLOCKED WHEEL | 0.3 | +6.5 | 0.0 | 9.0 | 0.2 | +12.4 | 0.0 | 7.9 |
| BLOWS WHERE AIMED | 0.3 | -35.5 | 44.8 | 6.5 | 0.2 | -14.0 | 26.4 | 30.3 |
| BOMBING RUN | 0.0 | +1.3 | 4.2 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 4.2 | - | - | - | - |
| BREAK OUTCOMES | - | - | - | - | 2.8 | -31.1 | 246.8 | 82.1 |
| CANNON PLAN MISSED | 0.7 | +0.0 | 74.3 | 12.6 | 0.2 | +0.0 | 20.1 | 3.6 |
| CANNON PLANNED TARGET | 5.0 | +163.3 | 335.1 | 75.8 | 1.4 | +28.0 | 37.8 | 18.6 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 0.0 | 9.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.0 | +0.0 | 0.0 | 4.2 | 0.1 | -0.6 | 1.5 | 0.0 |
| CAST JOB | 1.1 | +38.8 | 34.8 | 55.9 | 0.9 | +13.5 | 49.5 | 7.0 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +36.8 | 25.6 | 10.9 | 0.2 | +8.4 | 9.3 | 4.4 |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 49.3 | 0.4 | +0.0 | 0.0 | 29.8 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.1 | +57.7 | 0.0 | 29.0 | 1.6 | +95.3 | 0.0 | 37.9 |
| CHAFF PASSED | 0.2 | -0.2 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 7.2 |
| CHARGE NOW FIRST | 2.1 | +0.0 | 188.6 | 57.3 | 2.6 | +0.0 | 201.4 | 106.2 |
| CHARGE NOW WEIGHED | 0.4 | -26.7 | 44.0 | 3.1 | 0.3 | -12.0 | 10.2 | 3.2 |
| CHARGER SLAIN LOST | 0.4 | -17.7 | 35.4 | 32.5 | 0.8 | -15.2 | 52.2 | 35.7 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -3.4 | 10.9 | 0.0 | 0.0 | -1.2 | 16.1 | 0.0 |
| CHEAP HELPER | - | - | - | - | 0.2 | +0.0 | 3.2 | 2.3 |
| COMBAT PIVOT | 0.4 | +0.0 | 53.6 | 22.3 | 0.5 | +0.0 | 14.9 | 23.5 |
| CONVEYANCE SEARCH | 0.5 | +40.4 | 8.9 | 23.3 | 0.3 | +111.8 | 0.0 | 26.3 |
| COVER ONCE | 7.4 | -563.9 | 0.0 | 169.2 | 6.0 | -433.5 | 0.0 | 149.8 |
| DEFENSIVE ARMY | 0.3 | +0.0 | 63.1 | 0.0 | - | - | - | - |
| DEFENSIVE FLOOR | - | - | - | - | 0.0 | +3.9 | 11.9 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +1.5 | 9.0 | 2.9 | 0.1 | +3.9 | 7.7 | 0.0 |
| ELIXIR WORTH | 0.0 | +0.3 | 0.0 | 8.2 | 0.1 | +1.5 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 2.0 | +126.2 | 0.0 | 58.6 | 1.1 | +64.2 | 0.0 | 70.3 |
| FALLBACK BY WORTH | 3.6 | +46.7 | 0.0 | 63.2 | 4.8 | +46.1 | 0.0 | 40.3 |
| FIGHT LIFT | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| FIRE AND FLEE | - | - | - | - | 0.1 | +1.0 | 0.0 | 6.1 |
| FLANK NOT WEIGHED | 4.8 | +0.0 | 0.0 | 148.7 | 4.6 | +0.0 | 0.0 | 144.3 |
| FLEES FROM CHARGE | - | - | - | - | 0.7 | +18.9 | 38.0 | 31.5 |
| FOLLOW UP WEIGHED | 1.0 | +140.9 | 0.0 | 27.8 | 0.8 | +102.1 | 0.0 | 48.7 |
| FRIENDS SHOTS CHECKED | 0.3 | +20.7 | 0.0 | 0.0 | 0.2 | +16.6 | 0.0 | 13.4 |
| GIVES UP | 0.1 | -0.2 | 7.0 | 4.0 | 0.1 | -2.3 | 9.1 | 0.0 |
| GROUND FLIERS | 0.0 | +0.4 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 3.2 | 0.0 | 0.0 | +0.0 | 12.0 | 1.4 |
| HELPER UNSEEN | 0.3 | +0.0 | 22.4 | 25.4 | 0.4 | +0.0 | 20.9 | 16.9 |
| HILL BY ITS CHANCE | - | - | - | - | 0.1 | -9.9 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 7.7 | -141.6 | 371.6 | 162.8 | 9.6 | -165.2 | 414.9 | 197.8 |
| HUNT ADVANCE | 0.0 | +0.2 | 0.0 | 0.0 | 0.2 | +6.7 | 0.0 | 6.1 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.4 | +23.4 | 0.0 | 33.7 | 0.6 | +34.5 | 0.0 | 0.0 |
| HUNT KEPT | - | - | - | - | 0.0 | +0.5 | 0.0 | 0.0 |
| HUNT RESULT | 0.1 | +8.8 | 0.0 | 2.9 | 0.1 | +0.0 | 0.0 | 3.2 |
| HUNT THE GUNS | 0.1 | +23.5 | 4.6 | 2.9 | 0.1 | +40.7 | 0.0 | 6.1 |
| IDLE COST | 14.7 | -248.5 | 0.0 | 207.7 | 18.8 | -300.0 | 0.0 | 221.7 |
| INVITES THE FIGHT | 1.3 | +11.2 | 66.7 | 26.4 | 1.1 | +7.9 | 48.9 | 10.0 |
| JOINT CHARGE PLAN | 0.2 | +13.1 | 0.0 | 20.2 | 0.3 | +16.0 | 9.2 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -3.4 | 11.7 | 0.0 |
| KEEP FALLS | 0.0 | +0.2 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| KEEPS ITS PREY | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.5 | +44.2 | 102.4 | 32.1 | 2.0 | +60.0 | 143.6 | 20.2 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.4 | +59.1 | 88.5 | 58.8 | - | - | - | - |
| KILLS COUNT NEXT TURN | 4.2 | +152.2 | 128.3 | 164.3 | 6.6 | +260.3 | 252.6 | 120.9 |
| LONE CHARACTER SAFE SPOT | 0.4 | +12.3 | 9.4 | 0.0 | 0.4 | +9.7 | 4.6 | 0.0 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 13.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.7 | +49.1 | 0.0 | 0.0 | 0.2 | +24.5 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | -3.6 | 35.1 | 13.2 | 0.5 | +6.2 | 32.3 | 19.4 |
| LOST CHARGE | 2.9 | -37.1 | 104.4 | 118.7 | 2.6 | -40.9 | 75.1 | 96.0 |
| LURE BY WHAT IT DRAWS | 0.2 | -7.8 | 0.0 | 8.2 | 0.2 | -20.1 | 0.0 | 14.2 |
| MAKE SURE TOGETHER | 0.7 | +41.3 | 8.0 | 56.2 | 1.3 | +102.8 | 16.0 | 30.1 |
| MANOEUVRE | 0.2 | +2.8 | 0.0 | 15.7 | 0.2 | +3.7 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.0 | +0.4 | 0.0 | 0.0 | 0.1 | +2.4 | 0.0 | 0.0 |
| MARCH CHECK | 0.6 | +10.0 | 0.0 | 47.6 | 0.3 | +19.2 | 0.0 | 0.0 |
| MARCH ODDS | 0.2 | +11.3 | 2.9 | 0.0 | 0.2 | +24.8 | 0.0 | 7.0 |
| MARCH OVER CASTS | 0.6 | +59.3 | 0.0 | 10.6 | 0.3 | +32.5 | 0.0 | 11.1 |
| MAX FOR POSITIONING | 5.2 | +88.0 | 0.0 | 219.1 | 7.3 | +103.1 | 0.0 | 142.2 |
| MISSILES IN THE MOVE | 4.2 | +172.9 | 0.0 | 185.1 | 3.7 | +68.5 | 0.0 | 36.5 |
| MISSILES NEXT TURN | 5.1 | +119.6 | 0.0 | 187.4 | 4.2 | +43.7 | 0.0 | 44.4 |
| MODEL FACING | 0.3 | +71.1 | 0.0 | 1.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.0 | +0.0 | 8.0 | 0.0 | 0.2 | +0.0 | 0.0 | 5.7 |
| MOVE AND CAST | 0.3 | +19.3 | 0.0 | 21.9 | 0.4 | +22.6 | 0.0 | 21.3 |
| MOVE SPELL IN RANGE | 0.2 | +8.7 | 0.0 | 16.1 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.4 | -71.8 | 0.0 | 38.2 | 0.1 | -0.2 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 11.1 |
| MOVE TO CHARGE | 3.4 | +302.1 | 88.3 | 122.3 | 5.7 | +350.3 | 166.4 | 139.5 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +1.3 | 0.0 | 0.0 | 0.0 | +0.2 | 5.1 | 0.0 |
| NO RALLY LEFT | 0.1 | +13.9 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.3 | -10.6 | 31.4 | 6.2 | 0.1 | -2.2 | 4.1 | 0.0 |
| NOT TURNED | 4.7 | +97.0 | 0.0 | 160.0 | 5.3 | +61.8 | 0.0 | 122.8 |
| NOT WORTH A CAST | 0.9 | -0.7 | 0.0 | 80.7 | 0.3 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 17.5 | -698.9 | 6.5 | 332.8 | 17.6 | -756.5 | 1.8 | 272.8 |
| ONE FIGHT FORMULA | 7.8 | -151.4 | 49.3 | 256.2 | 9.0 | -176.0 | 42.9 | 203.9 |
| ONE OBJECTIVE FORMULA | 2.4 | -64.5 | 0.0 | 25.6 | 1.8 | -20.9 | 0.0 | 31.2 |
| OPENS A LANE | 0.2 | +7.2 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | 0.2 | +11.3 | 9.1 | 0.0 | 0.2 | +10.7 | 5.0 | 13.6 |
| OVERRUN ON | - | - | - | - | 0.6 | +29.4 | 37.5 | 14.8 |
| OVERRUNS AWAY | 0.4 | +4.6 | 19.8 | 8.8 | 0.4 | +17.5 | 8.7 | 10.8 |
| PATHS CROSS | 2.0 | +135.7 | 0.0 | 29.6 | 2.4 | +151.4 | 0.0 | 31.9 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +2.8 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.0 | -1.0 | 0.0 | 0.0 | 0.1 | -2.8 | 0.0 | 7.9 |
| PLAN RESULT | 37.3 | +1546.0 | 1287.4 | 1001.9 | 38.1 | +943.5 | 1193.2 | 893.4 |
| PURSUES BIG PREY | 0.1 | -5.3 | 0.0 | 4.9 | 0.2 | -18.8 | 0.0 | 0.0 |
| PURSUES ON | - | - | - | - | 0.0 | +0.5 | 0.0 | 7.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +3.3 | 0.0 | 0.0 | 0.0 | +2.4 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.8 | +12.9 | 0.0 | 22.2 | 1.5 | +25.7 | 0.0 | 27.8 |
| RANDOM MOVER NO PROMISE | 0.0 | -2.0 | 4.4 | 4.7 | 0.2 | -8.2 | 5.6 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.8 | -13.0 | 0.0 | 18.2 | 1.1 | -44.9 | 0.0 | 20.6 |
| REDIRECT COUNTER | 1.5 | +77.7 | 0.0 | 47.2 | 3.5 | +292.9 | 0.0 | 46.9 |
| REDIRECT WEIGHED | 0.3 | +0.6 | 13.1 | 1.4 | 0.5 | +16.1 | 26.1 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 8.2 | 0.4 | +0.0 | 0.0 | 12.7 |
| RESERVE FALL BACK | 0.6 | +18.4 | 0.0 | 4.9 | 0.7 | +19.4 | 0.0 | 7.6 |
| RESTRAINS TO SHOOT | 0.1 | +7.8 | 0.0 | 11.6 | 0.1 | +4.7 | 0.0 | 0.0 |
| RISK BY ARC | 1.9 | +79.8 | 125.1 | 89.8 | 2.2 | +37.9 | 195.6 | 66.2 |
| RISK ONCE | 2.6 | +47.8 | 11.5 | 130.0 | 5.9 | +363.9 | 96.5 | 357.0 |
| SAFE SURE CHARGE | - | - | - | - | 0.0 | -1.9 | 8.0 | 0.0 |
| SAFER THAN THE JOB | 0.9 | +45.4 | 0.0 | 29.9 | 0.7 | +34.7 | 0.0 | 20.1 |
| SCOUT SPOT | 0.4 | +0.7 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.9 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.9 |
| SCREEN BY WHAT IT SAVES | 0.2 | -7.6 | 0.0 | 1.8 | 0.4 | -24.5 | 0.0 | 3.0 |
| SEARCH SPOT | 1.7 | +74.0 | 0.0 | 59.6 | 2.2 | +86.7 | 0.0 | 21.3 |
| SELF MOVE SPELL | 0.2 | +52.4 | 0.0 | 18.1 | 0.1 | -0.2 | 0.0 | 18.1 |
| SET UP TOGETHER | 1.2 | +112.8 | 18.9 | 76.8 | 2.4 | +186.8 | 31.6 | 55.1 |
| SET-UP ANY TARGET | 0.2 | +30.9 | 0.0 | 0.0 | 0.1 | +13.9 | 0.0 | 7.6 |
| SET-UP MISSED | 0.0 | +2.7 | 0.0 | 0.0 | 0.0 | +3.9 | 3.5 | 7.6 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.1 | -0.3 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.0 | +91.7 | 132.5 | 41.9 | 0.9 | +25.8 | 68.3 | 19.2 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.7 | +0.0 | 128.2 | 22.4 | 0.1 | +0.0 | 4.3 | 5.1 |
| SHOTS IN THE MOVE | 14.9 | +629.9 | 0.0 | 209.9 | 8.9 | +171.6 | 0.0 | 149.1 |
| SPELL SETS UP CHARGE | 0.3 | +46.8 | 8.9 | 9.9 | 0.2 | +76.7 | 0.0 | 18.7 |
| SPELL WORTH | 1.2 | +18.7 | 85.1 | 96.2 | 1.9 | +45.2 | 25.2 | 22.2 |
| SPELLS IN THE FIGHT | 0.6 | +0.2 | 33.2 | 37.8 | 0.5 | -6.2 | 49.0 | 44.4 |
| STABLE ROLE | 10.9 | +0.0 | 405.7 | 193.6 | 11.0 | +0.0 | 310.3 | 215.9 |
| STAND AND SHOOT | - | - | - | - | 0.4 | -4.5 | 32.6 | 13.9 |
| STANDS TO CAST | 0.0 | +1.0 | 0.0 | 10.9 | 0.0 | +1.0 | 7.0 | 0.0 |
| STAY WEIGHED | 0.1 | +1.6 | 0.0 | 0.0 | 0.0 | +0.4 | 0.0 | 0.0 |
| STOPS | 0.0 | +3.4 | 4.6 | 2.9 | - | - | - | - |
| STOPS SHORT OF THE FLANK | 0.4 | +26.1 | 0.0 | 23.1 | 0.4 | +17.6 | 0.0 | 8.9 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 4.5 | -44.1 | 308.8 | 112.5 | 7.4 | -67.9 | 338.0 | 91.5 |
| SUPPORTS | 3.1 | +46.3 | 195.4 | 72.1 | 5.3 | +69.3 | 194.6 | 43.5 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -1.3 | 3.3 | 0.0 | 0.1 | -5.1 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.6 | -7.9 | 0.0 | 20.8 | 0.8 | -2.2 | 5.9 | 18.1 |
| THROUGH LINE OF FIRE | 0.4 | +17.4 | 0.0 | 3.1 | 0.3 | +13.7 | 0.0 | 4.2 |
| TURN WORTH | 0.3 | -23.7 | 32.1 | 1.4 | 0.1 | -7.6 | 19.0 | 0.0 |
| TWO OR MORE ARRIVE | 0.2 | +1.4 | 8.0 | 11.4 | 0.7 | +3.7 | 9.2 | 8.9 |
| WAIT AFTER COSTS | 6.9 | -364.9 | 243.2 | 177.8 | 8.9 | -471.5 | 279.6 | 172.9 |
| WALKS TO THE FIGHT | 1.8 | +16.3 | 57.6 | 22.2 | 1.0 | +8.9 | 29.8 | 4.9 |
| WAR ENGINE CHARGES | 0.1 | +3.7 | 10.7 | 0.0 | 0.0 | +1.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.5 | +0.0 | 23.2 | 10.6 | 0.3 | +0.0 | 9.9 | 10.3 |
| WEARS DOWN | 0.8 | +56.1 | 80.8 | 26.7 | 1.0 | +36.8 | 93.4 | 64.8 |
| WHO HITS BACK | 0.1 | +4.6 | 0.0 | 0.0 | 0.1 | +6.2 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.1 | +4.8 | 18.8 | 2.1 | 0.4 | +11.4 | 67.8 | 17.1 |
| WHOLE FIGHT GAIN | 0.3 | +27.9 | 31.2 | 16.6 | 0.5 | +28.2 | 61.6 | 6.6 |
| WIDER SPREAD | 2.1 | -7.9 | 199.3 | 88.2 | 2.8 | -5.5 | 220.1 | 103.1 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |

### Rule changes: co-opp-a57fba0-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1264 | 1264 | 1264 | 35.11 | -52392 | -41.4 |
| MOVE TO CHARGE | 329 | 329 | 178 | 4.94 | +8856 | +49.8 |
| PATHS CROSS | 157 | 157 | 157 | 4.36 | +10334 | +65.8 |
| KILLS COUNT NEXT TURN | 387 | 387 | 137 | 3.81 | +4917 | +35.9 |
| SEARCH SPOT | 139 | 139 | 137 | 3.81 | +5782 | +42.2 |
| SUPPORTS | 303 | 303 | 135 | 3.75 | +1564 | +11.6 |
| WAIT AFTER COSTS | 569 | 569 | 114 | 3.17 | +2203 | +19.3 |
| FACES THE THREAT | 109 | 109 | 109 | 3.03 | +6855 | +62.9 |
| RISK ONCE | 307 | 223 | 81 | 2.25 | +2663 | +32.9 |
| FALLBACK BY WORTH | 299 | 299 | 75 | 2.08 | +3341 | +44.6 |
| COVER ONCE | 482 | 243 | 68 | 1.89 | +829 | +12.2 |
| SHOTS IN THE MOVE | 858 | 566 | 68 | 1.89 | +2057 | +30.2 |
| BEST FIRST | 67 | 67 | 67 | 1.86 | +3085 | +46.1 |
| SET UP TOGETHER | 128 | 112 | 67 | 1.86 | +4393 | +65.6 |
| CHAFF IN THE MOVE | 96 | 93 | 64 | 1.78 | +2360 | +36.9 |
| FOLLOW UP WEIGHED | 64 | 64 | 64 | 1.78 | +8750 | +136.7 |
| ADVANCE WORTH | 335 | 335 | 60 | 1.67 | +760 | +12.7 |
| SAFER THAN THE JOB | 58 | 58 | 58 | 1.61 | +2886 | +49.8 |
| CANNON PLANNED TARGET | 229 | 229 | 57 | 1.58 | -311 | -5.5 |
| ONE FIGHT FORMULA | 604 | 346 | 56 | 1.56 | +171 | +3.0 |
| ARTILLERY RE-ROLL WEIGHED | 51 | 51 | 51 | 1.42 | +0 | +0.0 |
| CANNON SIGHT KEPT | 51 | 51 | 51 | 1.42 | +0 | +0.0 |
| REDIRECT COUNTER | 180 | 91 | 48 | 1.33 | +3939 | +82.1 |
| ADVANCE LANE KEPT | 46 | 46 | 46 | 1.28 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 82 | 82 | 46 | 1.28 | +1389 | +30.2 |
| RESERVE FALL BACK | 46 | 46 | 46 | 1.28 | +1363 | +29.6 |
| SHOOTS FROM THE BEST SPOT | 107 | 107 | 45 | 1.25 | +1666 | +37.0 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| MISSILES IN THE MOVE | 285 | 161 | 43 | 1.19 | +1427 | +33.2 |
| WALKS TO THE FIGHT | 98 | 98 | 43 | 1.19 | +296 | +6.9 |
| INVITES THE FIGHT | 89 | 89 | 40 | 1.11 | +259 | +6.5 |
| CAST JOB | 70 | 70 | 37 | 1.03 | +835 | +22.6 |
| MAX FOR POSITIONING | 451 | 274 | 36 | 1.00 | +186 | +5.2 |
| RISK BY ARC | 148 | 142 | 36 | 1.00 | +1234 | +34.3 |
| CHARGE NOW FIRST | 169 | 169 | 35 | 0.97 | -1573 | -44.9 |
| LONE WIZARD KEPT IN | 34 | 34 | 34 | 0.94 | +2648 | +77.9 |
| HONEST WORTH | 622 | 619 | 33 | 0.92 | +291 | +8.8 |
| COMBAT PIVOT | 31 | 31 | 31 | 0.86 | +0 | +0.0 |
| IDLE COST | 1203 | 663 | 30 | 0.83 | +331 | +11.0 |
| MARCH CHECK | 32 | 29 | 29 | 0.81 | +1227 | +42.3 |
| REDIRECT WEIGHED | 28 | 28 | 28 | 0.78 | +878 | +31.4 |
| SHOT REPLANNED | 28 | 28 | 28 | 0.78 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 28 | 28 | 28 | 0.78 | +1571 | +56.1 |
| THROUGH LINE OF FIRE | 28 | 28 | 28 | 0.78 | +1121 | +40.0 |
| BEST FACING | 27 | 27 | 27 | 0.75 | +902 | +33.4 |
| MOVE AND CAST | 27 | 27 | 27 | 0.75 | +1507 | +55.8 |
| BEST OVERALL | 26 | 26 | 26 | 0.72 | +1598 | +61.5 |
| CASTER AWAY FROM SCREEN | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| MAKE SURE TOGETHER | 71 | 50 | 25 | 0.69 | +2022 | +80.9 |
| CHARGE NOW WEIGHED | 24 | 24 | 24 | 0.67 | +1306 | +54.4 |
| SHOOTERS IN TWO RANKS | 24 | 24 | 24 | 0.67 | +58 | +2.4 |
| BLOCKED WHEEL | 20 | 20 | 20 | 0.56 | +683 | +34.1 |
| WAR ENGINE JOBS | 31 | 31 | 19 | 0.53 | -824 | -43.4 |
| FRIENDS SHOTS CHECKED | 17 | 17 | 17 | 0.47 | +1344 | +79.0 |
| KILLS COUNT | 51 | 50 | 17 | 0.47 | +426 | +25.1 |
| MARCH ODDS | 16 | 16 | 16 | 0.44 | +126 | +7.9 |
| CASTING BLOCK | 24 | 24 | 15 | 0.42 | +475 | +31.7 |
| WEARS DOWN | 66 | 65 | 15 | 0.42 | +568 | +37.9 |
| BEST PREY | 44 | 44 | 14 | 0.39 | +401 | +28.7 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| REFUSING RETIRES | 26 | 26 | 14 | 0.39 | -3 | -0.2 |
| WHOLE FIGHT GAIN | 31 | 29 | 14 | 0.39 | +616 | +44.0 |
| KEEPS ITS TARGET | 125 | 125 | 13 | 0.36 | +239 | +18.4 |
| LOST CHARGE | 197 | 196 | 13 | 0.36 | +597 | +45.9 |
| MODEL FACING | 12 | 12 | 12 | 0.33 | +2559 | +213.2 |
| MANOEUVRE | 15 | 15 | 11 | 0.31 | +235 | +21.3 |
| STUCK PIVOT | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| CHAFF PASSED | 10 | 10 | 10 | 0.28 | -8 | -0.8 |
| SUPPORT NARROWED | 428 | 428 | 10 | 0.28 | -47 | -4.7 |
| BIG CHARACTER SAFETY | 9 | 9 | 9 | 0.25 | -62 | -6.9 |
| FLEES FROM CHARGE | 25 | 25 | 9 | 0.25 | +237 | +26.3 |
| PURSUES BIG PREY | 9 | 9 | 9 | 0.25 | -869 | -96.6 |
| RESTRAINS TO SHOOT | 9 | 9 | 9 | 0.25 | +447 | +49.7 |
| WHOLE FIGHT | 21 | 21 | 9 | 0.25 | +504 | +56.0 |
| HUNT IN PAIRS | 38 | 22 | 8 | 0.22 | +352 | +44.0 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| BEST PRIZE | 6 | 6 | 6 | 0.17 | -409 | -68.2 |
| BLOCKED CHARGE SKIPPED | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| MISSILES NEXT TURN | 334 | 180 | 6 | 0.17 | +12 | +2.1 |
| WHO HITS BACK | 6 | 6 | 6 | 0.17 | +257 | +42.8 |
| BREAK OUTCOMES | 99 | 97 | 5 | 0.14 | +76 | +15.2 |
| OPENS UP | 12 | 12 | 5 | 0.14 | +210 | +41.9 |
| SURE CHARGE BEATS ADVANCE | 5 | 5 | 5 | 0.14 | -231 | -46.2 |
| BACKUP TARGETS | 37 | 15 | 4 | 0.11 | +1 | +0.3 |
| ONE OBJECTIVE FORMULA | 152 | 70 | 4 | 0.11 | +142 | +35.5 |
| OVERRUNS AWAY | 31 | 31 | 4 | 0.11 | +119 | +29.6 |
| PIVOT GUARDS FLANK | 4 | 4 | 4 | 0.11 | -137 | -34.2 |
| SURE REACH TOGETHER | 51 | 42 | 4 | 0.11 | +7 | +1.8 |
| WIDER SPREAD | 175 | 168 | 4 | 0.11 | +16 | +3.9 |
| ELIXIR WORTH | 3 | 3 | 3 | 0.08 | +64 | +21.5 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.08 | +38 | +12.6 |
| HUNT ADVANCE | 7 | 7 | 3 | 0.08 | +75 | +25.1 |
| JOINT CHARGE PLAN | 18 | 18 | 3 | 0.08 | +194 | +64.7 |
| SPELLS IN THE FIGHT | 37 | 33 | 3 | 0.08 | +25 | +8.3 |
| STAY WEIGHED | 3 | 3 | 3 | 0.08 | +70 | +23.4 |
| DEFENSIVE ARMY | 12 | 12 | 2 | 0.06 | -18 | -9.2 |
| KEEP FALLS | 2 | 2 | 2 | 0.06 | +9 | +4.6 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| LONG SHOT | 35 | 35 | 2 | 0.06 | -40 | -19.8 |
| NEEDED THERE | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +356 | +177.9 |
| RAIDS THE BAGGAGE NEXT TURN | 2 | 2 | 2 | 0.06 | +91 | +45.3 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | +5 | +2.3 |
| WAR ENGINE CHARGES | 3 | 3 | 2 | 0.06 | +55 | +27.5 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +47 | +47.0 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.1 |
| CARRIES OUT SET-UP | 3 | 3 | 1 | 0.03 | -22 | -22.1 |
| EDGE GIVE GROUND | 8 | 7 | 1 | 0.03 | +16 | +16.1 |
| MOVE SPELL IN RANGE | 8 | 5 | 1 | 0.03 | +28 | +28.2 |
| OVERRUN ON | 20 | 20 | 1 | 0.03 | +97 | +97.1 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +101 | +101.3 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +16 | +16.4 |
| REDIRECT BY WHAT IT STOPS | 66 | 66 | 1 | 0.03 | +32 | +32.5 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -467 | -467.1 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.03 | -20 | -20.3 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 17 | 17 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 32 | 32 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 33 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARGER SLAIN LOST | 42 | 39 | 0 | 0.00 | - | - |
| CHARIOT NO STATIC JOB | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 3 | 3 | 0 | 0.00 | - | - |
| CHEAP HELPER | 7 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 30 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 338 | not checked | - | - | - | - |
| GIVES UP | 7 | 6 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 26 | 21 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 4 | 4 | 0 | 0.00 | - | - |
| HUNT DROPPED | 3 | trace | - | - | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT RESULT | 7 | trace | - | - | - | - |
| HUNT THE GUNS | 7 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 2 | 1 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 29 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 18 | 18 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 13 | 13 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 4 | trace | - | - | - | - |
| MARCH OVER CASTS | 35 | 35 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 9 | 9 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 15 | trace | - | - | - | - |
| MOVE SPELL SPOT | 11 | not checked | - | - | - | - |
| NOT NEEDED | 14 | 14 | 0 | 0.00 | - | - |
| NOT TURNED | 360 | 360 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 44 | not checked | - | - | - | - |
| OPENS A LANE | 6 | 6 | 0 | 0.00 | - | - |
| PLAN RESULT | 2714 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 8 | 8 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 22 | 22 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 13 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 13 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 19 | not checked | - | - | - | - |
| SPELL WORTH | 112 | not checked | - | - | - | - |
| STABLE ROLE | 788 | 787 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 16 | 16 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| TURN WORTH | 15 | 15 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 31 | 25 | 0 | 0.00 | - | - |

### Off best figure: co-opp-a57fba0-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 16.25 | 15.81 | 43.2 |
| FALLBACK | gate | 0.44 | 0.89 | 30.0 |
| CHARGE NOW FIRST | rule | 0.50 | 0.44 | 46.3 |
| TURN GATE | gate | 0.33 | 0.42 | 11.7 |
| WAR ENGINE JOBS | rule | 0.42 | 0.11 | 43.4 |
| CANNON PLANNED TARGET | rule | 0.31 | - | 38.9 |
| SUPPORT NARROWED | rule | 0.08 | 0.19 | 4.7 |
| PURSUES BIG PREY | rule | 0.08 | 0.17 | 96.6 |
| SUPPORT REQUEST | gate | 0.11 | 0.14 | 38.0 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.14 | 0.06 | 11.9 |
| AFTERMATH BAND | gate | 0.06 | 0.11 | 3.0 |
| BEST PRIZE | rule | 0.06 | 0.11 | 68.2 |
| PATHS CROSS | rule | 0.06 | 0.11 | 51.7 |
| BIG CHARACTER SAFETY | rule | 0.08 | 0.06 | 15.0 |
| CHARGE NOW WEIGHED | rule | 0.08 | 0.06 | 29.5 |
| SURE CHARGE BEATS ADVANCE | rule | 0.08 | 0.06 | 46.2 |
| FIGHT ORDER BAND | gate | 0.08 | 0.03 | 2.5 |
| MARCH ODDS | rule | 0.08 | 0.03 | 4.1 |
| NO REASON | gate | - | 0.11 | 18.9 |
| PIVOT GUARDS FLANK | rule | 0.03 | 0.08 | 34.2 |
| LONE CHARACTER SAFE SPOT | gate | 0.03 | 0.06 | 66.3 |
| SAFER THAN THE JOB | rule | 0.03 | 0.06 | 17.0 |
| DEFENSIVE ARMY | rule | 0.06 | - | 9.2 |
| FACES THE THREAT | rule | 0.06 | - | 11.9 |
| REDIRECT WEIGHED | rule | 0.03 | 0.03 | 155.3 |
| RULE SWITCHED OFF | gate | 0.06 | - | 19.8 |
| BLOCKED WHEEL | rule | - | 0.03 | 8.4 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 22.1 |
| CHAFF PASSED | rule | 0.03 | - | 7.8 |
| FOLLOW UP WEIGHED | rule | - | 0.03 | 3.6 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | - | 4.6 |
| LONG SHOT | rule | - | 0.03 | 58.0 |
| REFUSING RETIRES | rule | 0.03 | - | 0.8 |
| SAFE SURE CHARGE | rule | - | 0.03 | 467.1 |
| WOUNDED STAYS OUT | rule | - | 0.03 | 20.3 |

### Plans: co-opp-a57fba0-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 9.0 | 20% | 175 | 293 | 167% |
| Mine | charge | 2.6 | 60% | 227 | 205 | 90% |
| Mine | close in | 4.6 | 29% | 298 | 173 | 58% |
| Mine | hold | 5.6 | 38% | 338 | 0 | 0% |
| Mine | join | 0.7 | 100% | 20 | 0 | 0% |
| Mine | shoot | 10.7 | 58% | 437 | 875 | 200% |
| Mine | support | 4.2 | 82% | 39 | 0 | 0% |
| Opponent | advance | 9.9 | 18% | 156 | 243 | 156% |
| Opponent | charge | 3.8 | 63% | 280 | 344 | 123% |
| Opponent | close in | 7.0 | 21% | 429 | 157 | 37% |
| Opponent | hold | 4.6 | 41% | 304 | 0 | 0% |
| Opponent | join | 1.2 | 98% | 53 | 0 | 0% |
| Opponent | shoot | 4.8 | 57% | 78 | 199 | 256% |
| Opponent | support | 6.7 | 92% | 64 | 0 | 0% |

### Packages: hunt the guns, co-opp-a57fba0-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 2 | 0 | 50% | 50% | 0% | 2.0 | 422 | 159 | 50% | 15 |
| Opponent | 0.1 | 5 | 0 | 0% | 0% | 0% | - | 293 | 0 | 0% | 84 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.4 | 2 | 0 | 50% | 50% | 0% | 2.0 | 422 | 159 | 50% | 85 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 49 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 249 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 175 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.3 | 2 | 0 | 0% | 0% | 0% | - | 292 | 0 | 0% | 44 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.2 | 2 | 0 | 0% | 0% | 0% | - | 277 | 0 | 0% | 63 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 329 | 0 | 0% | 41 |

### Battle groups: co-opp-a57fba0-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.5 | 42% | 52% | 9% | 0% | 14% | 0% | 5% | 76% | 5% |
| Opponent | REDIRECT COUNTER | 3.5 | 22% | 74% | 11% | 33% | 33% | 0% | 17% | 42% | 8% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: co-opp-a57fba0-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 56 | 33% | 4.5 | 0 (1) | 0 (2) | - | - | 0 (3) |
| Mine | Chaff | 37 | 18 (37) | 5 | 13 | 53 | 43% | 2.1 | 0 (16) | 25 (9) | 34 (12) | 25 (24) | 6 (13) |
| Mine | Character | 123 | 52 (123) | 52 | 0 | 38 | 20% | 2.3 | 89 (34) | 39 (61) | 40 (9) | 67 (55) | 46 (49) |
| Mine | Clean-up | 24 | 51 (24) | 23 | 28 | 35 | 38% | 2.8 | 56 (9) | 50 (11) | 32 (4) | 92 (14) | 2 (10) |
| Mine | Fast | 4 | 110 (4) | 110 | 0 | 34 | 0% | 1.5 | 57 (1) | 100 (2) | 362 (1) | 110 (4) | - |
| Mine | Fast Hammer | 41 | 45 (41) | 23 | 22 | 58 | 22% | 3.0 | 46 (18) | 52 (12) | 37 (11) | 53 (28) | 30 (13) |
| Mine | Fragile | 5 | 14 (5) | 14 | 0 | 40 | 0% | 1.8 | - | 17 (4) | 0 (1) | 0 (1) | 17 (4) |
| Mine | Hammer | 58 | 39 (58) | 24 | 15 | 51 | 12% | 2.4 | 68 (10) | 33 (38) | 36 (10) | 49 (34) | 28 (24) |
| Mine | Holder | 25 | 84 (25) | 11 | 73 | 28 | 40% | 3.9 | 142 (6) | 59 (15) | 104 (3) | 135 (9) | 57 (15) |
| Mine | Shooter | 44 | 104 (44) | 30 | 74 | 32 | 0% | 2.0 | 21 (5) | 125 (32) | 92 (7) | 155 (23) | 53 (21) |
| Mine | Support | 5 | 0 (5) | 0 | 0 | 58 | 0% | 3.6 | - | 0 (2) | - | 0 (2) | - |
| Mine | War machine | 56 | 46 (56) | 46 | 0 | 39 | 5% | 1.2 | 74 (13) | 44 (37) | 0 (6) | 25 (11) | 52 (45) |
| Mine | Wizard | 23 | 12 (23) | 12 | 0 | 32 | 22% | 2.7 | 0 (6) | 24 (11) | 30 (2) | 51 (3) | 5 (16) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | 0 (1) | - | - | - | 0 (1) |
| Opponent | Chaff | 66 | 64 (66) | 21 | 43 | 44 | 38% | 2.9 | 98 (28) | 27 (16) | 52 (22) | 82 (48) | 13 (18) |
| Opponent | Character | 114 | 51 (114) | 51 | 0 | 30 | 25% | 2.6 | 64 (43) | 50 (55) | 10 (7) | 45 (70) | 73 (35) |
| Opponent | Clean-up | 16 | 59 (16) | 56 | 4 | 37 | 38% | 2.8 | 85 (5) | 49 (8) | 37 (3) | 109 (8) | 22 (8) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 58 | 37 (58) | 20 | 16 | 52 | 28% | 2.9 | 44 (25) | 29 (19) | 29 (14) | 32 (42) | 49 (16) |
| Opponent | Fragile | 10 | 0 (10) | 0 | 0 | 54 | 30% | 2.0 | 0 (3) | 0 (4) | 0 (3) | 0 (9) | 0 (1) |
| Opponent | Hammer | 65 | 50 (65) | 43 | 7 | 50 | 26% | 2.4 | 43 (16) | 53 (42) | 36 (7) | 51 (40) | 48 (25) |
| Opponent | Holder | 40 | 79 (40) | 15 | 64 | 17 | 58% | 3.2 | 51 (9) | 109 (21) | 41 (8) | 156 (14) | 51 (24) |
| Opponent | Shooter | 30 | 63 (30) | 17 | 46 | 45 | 3% | 1.3 | 61 (7) | 59 (18) | 82 (5) | 78 (16) | 42 (14) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | - | 0 (2) |
| Opponent | War machine | 13 | 38 (13) | 38 | 0 | 51 | 0% | 1.2 | 0 (5) | 31 (5) | 118 (3) | 95 (3) | 21 (10) |
| Opponent | Wizard | 22 | 8 (22) | 8 | 0 | 33 | 9% | 2.2 | 5 (12) | 31 (4) | 0 (3) | 13 (11) | 0 (8) |

### Charged fights: co-opp-a57fba0-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 292 | 47 | 1.4 | 1.0 | 34 | 0 | +34 | 0 of 7 | 4 of 7 | - | +34 |
| Mine | Chaos Dwarfs | 3 | 59 | 673 | 3.7 | 1.3 | 184 | 28 | +155 | 6 of 11 | 7 of 11 | +250 | +134 |
| Mine | Dwarfen Mountain Holds | 4 | 423 | 66 | 1.5 | 1.2 | 44 | 10 | +34 | 2 of 6 | 4 of 6 | -60 | +53 |
| Mine | Empire of Man | 5 | 418 | 52 | 1.6 | 1.0 | 33 | 0 | +33 | 1 of 8 | 7 of 8 | - | +33 |
| Mine | Grand Cathay | 4 | 549 | 168 | 2.2 | 1.1 | 75 | 26 | +49 | 5 of 9 | 6 of 9 | +0 | +55 |
| Mine | High Elf Realms | 4 | 137 | 371 | 3.5 | 1.2 | 106 | 49 | +57 | 4 of 14 | 9 of 14 | +118 | +47 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 1039 | 5.0 | 1.2 | 208 | 0 | +208 | 2 of 5 | 5 of 5 | +85 | +238 |
| Mine | Lizardmen | 1 | 0 | 775 | 4.0 | 1.2 | 194 | 79 | +115 | 3 of 4 | 3 of 4 | +150 | +103 |
| Mine | Ogre Kingdoms | 1 | 0 | 0 | 4.0 | 1.0 | 0 | 0 | +0 | 3 of 4 | 1 of 4 | - | +0 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 0 | 4.0 | 1.0 | 0 | 360 | -360 | 4 of 4 | 1 of 4 | - | -360 |
| Mine | Skaven | 2 | 48 | 220 | 1.0 | 1.0 | 220 | 0 | +220 | 1 of 2 | 2 of 2 | - | +220 |
| Mine | Tomb Kings of Khemri | 2 | 120 | 1130 | 5.0 | 1.2 | 226 | 26 | +199 | 2 of 10 | 7 of 10 | +28 | +242 |
| Mine | Vampire Counts | 2 | 0 | 206 | 3.5 | 1.0 | 59 | 0 | +59 | 2 of 7 | 5 of 7 | - | +59 |
| Mine | Warriors of Chaos | 1 | 0 | 584 | 8.0 | 1.0 | 73 | 40 | +33 | 3 of 8 | 5 of 8 | - | +33 |
| **Mine** | all armies | 36 | 236 | 290 | 2.8 | 1.1 | 106 | 37 | +69 | 38 of 99 | 66 of 99 | +97 | +66 |
| Opponent | Beastmen Brayherds | 1 | 0 | 337 | 5.0 | 1.0 | 67 | 23 | +44 | 1 of 5 | 5 of 5 | - | +44 |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 112 | 2.0 | 1.0 | 56 | 0 | +56 | 0 of 2 | 1 of 2 | - | +56 |
| Opponent | Empire of Man | 1 | 255 | 0 | 2.0 | 1.0 | 0 | 132 | -132 | 1 of 2 | 1 of 2 | - | -132 |
| Opponent | Grand Cathay | 1 | 340 | 485 | 4.0 | 1.2 | 121 | 51 | +70 | 3 of 4 | 3 of 4 | +0 | +93 |
| Opponent | High Elf Realms | 2 | 176 | 304 | 2.5 | 1.0 | 121 | 90 | +32 | 2 of 5 | 2 of 5 | - | +32 |
| Opponent | Lizardmen | 1 | 0 | 618 | 4.0 | 1.0 | 154 | 35 | +119 | 4 of 4 | 2 of 4 | - | +119 |
| Opponent | Ogre Kingdoms | 2 | 68 | 498 | 4.0 | 1.1 | 125 | 11 | +113 | 1 of 8 | 4 of 8 | +30 | +125 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 1080 | 4.5 | 1.1 | 240 | 114 | +126 | 4 of 9 | 7 of 9 | -974 | +263 |
| Opponent | Skaven | 2 | 82 | 81 | 1.0 | 1.0 | 81 | 105 | -24 | 1 of 2 | 1 of 2 | - | -24 |
| Opponent | Tomb Kings of Khemri | 4 | 26 | 891 | 4.5 | 1.1 | 198 | 32 | +166 | 7 of 18 | 13 of 18 | +235 | +161 |
| Opponent | Vampire Counts | 6 | 135 | 508 | 3.8 | 1.2 | 133 | 35 | +97 | 10 of 23 | 20 of 23 | -132 | +146 |
| Opponent | Warriors of Chaos | 7 | 25 | 286 | 1.1 | 1.0 | 250 | 0 | +250 | 5 of 8 | 7 of 8 | - | +250 |
| Opponent | Wood Elf Realms | 6 | 95 | 341 | 3.2 | 1.2 | 108 | 37 | +70 | 9 of 19 | 14 of 19 | +171 | +44 |
| **Opponent** | all armies | 36 | 81 | 448 | 3.0 | 1.1 | 148 | 42 | +106 | 48 of 109 | 80 of 109 | -46 | +125 |

### Effective charges: co-opp-a57fba0-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 7 | 1 (net +0) | 0 | 0 | 0 | 1 (net +0) | 4 (net +28) | 1 | 0% (0 of 6) |
| Mine | Chaos Dwarfs | 11 | 1 (net +506) | 1 (net +0) | 0 | 4 (net +167) | 1 (net +406) | 4 (net +33) | 0 | 0% (0 of 11) |
| Mine | Dwarfen Mountain Holds | 6 | 3 (net +55) | 0 | 0 | 1 (net +41) | 0 | 1 (net +60) | 1 | 0% (0 of 5) |
| Mine | Empire of Man | 8 | 1 (net +0) | 1 (net +109) | 0 | 2 (net +42) | 2 (net +35) | 2 (net +0) | 0 | 0% (0 of 8) |
| Mine | Grand Cathay | 9 | 3 (net -78) | 0 | 1 (net +0) | 2 (net +196) | 1 (net +41) | 0 | 2 | 14% (1 of 7) |
| Mine | High Elf Realms | 14 | 2 (net +6) | 0 | 5 (net +153) | 3 (net -70) | 3 (net +78) | 0 | 1 | 38% (5 of 13) |
| Mine | Kingdom of Bretonnia | 5 | 0 | 0 | 1 (net +85) | 1 (net +580) | 1 (net +45) | 2 (net +164) | 0 | 20% (1 of 5) |
| Mine | Lizardmen | 4 | 0 | 0 | 0 | 1 (net +430) | 1 (net +150) | 1 (net +20) | 1 | 0% (0 of 3) |
| Mine | Ogre Kingdoms | 4 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 3 | 100% (1 of 1) |
| Mine | Skaven | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +220) | 0 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 10 | 1 (net +0) | 0 | 1 (net +925) | 3 (net +137) | 3 (net +18) | 2 (net +301) | 0 | 10% (1 of 10) |
| Mine | Vampire Counts | 7 | 2 (net +0) | 0 | 1 (net +173) | 1 (net +0) | 1 (net +70) | 1 (net +0) | 1 | 17% (1 of 6) |
| Mine | Warriors of Chaos | 8 | 2 (net +0) | 0 | 0 | 2 (net -107) | 2 (net +138) | 1 (net +91) | 1 | 0% (0 of 7) |
| Opponent | Beastmen Brayherds | 5 | 0 | 0 | 3 (net +47) | 1 (net +15) | 0 | 1 (net +65) | 0 | 60% (3 of 5) |
| Opponent | Dwarfen Mountain Holds | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +112) | 0 | 0% (0 of 2) |
| Opponent | Empire of Man | 2 | 0 | 0 | 1 (net -265) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Opponent | Grand Cathay | 4 | 1 (net +0) | 0 | 3 (net +93) | 0 | 0 | 0 | 0 | 75% (3 of 4) |
| Opponent | High Elf Realms | 5 | 2 (net -40) | 0 | 2 (net +120) | 0 | 0 | 0 | 1 | 50% (2 of 4) |
| Opponent | Lizardmen | 4 | 2 (net +48) | 0 | 0 | 0 | 0 | 0 | 2 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 8 | 0 | 0 | 3 (net +0) | 3 (net +311) | 0 | 1 (net +65) | 1 | 43% (3 of 7) |
| Opponent | Orc & Goblin Tribes | 9 | 1 (net -974) | 0 | 0 | 3 (net +233) | 0 | 1 (net +893) | 4 | 0% (0 of 5) |
| Opponent | Skaven | 2 | 1 (net -210) | 0 | 1 (net +162) | 0 | 0 | 0 | 0 | 50% (1 of 2) |
| Opponent | Tomb Kings of Khemri | 18 | 1 (net +0) | 0 | 6 (net +47) | 3 (net +73) | 0 | 7 (net +337) | 1 | 35% (6 of 17) |
| Opponent | Vampire Counts | 23 | 2 (net -358) | 1 (net +195) | 4 (net +142) | 6 (net +38) | 1 (net +112) | 7 (net +245) | 2 | 19% (4 of 21) |
| Opponent | Warriors of Chaos | 8 | 1 (net +663) | 0 | 1 (net +708) | 3 (net +62) | 1 (net +54) | 1 (net +265) | 1 | 14% (1 of 7) |
| Opponent | Wood Elf Realms | 19 | 4 (net -94) | 0 | 3 (net +190) | 3 (net +28) | 0 | 7 (net +141) | 2 | 18% (3 of 17) |

### Charged fights, damage counted: co-opp-a57fba0-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 16 | 217 | 250 | +28 | 77 | 37 | +41 | +18.7 |
| Mine | 50-54% | 2 | 164 | 110 | +54 | 57 | 6 | +52 | +31.4 |
| Mine | Effective (55-75%) | 10 | 372 | 213 | +195 | 255 | 74 | +181 | +48.7 |
| Mine | 76-89% | 20 | 261 | 191 | +109 | 145 | 63 | +82 | +31.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 20 | 208 | 166 | +89 | 129 | 39 | +90 | +43.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 16 | 504 | 114 | +84 | 105 | 36 | +68 | +13.6 |
| Mine | No odds | 15 | 254 | 234 | -67 | 80 | 110 | -30 | -11.9 |
| Mine | All fights | 99 | 291 | 190 | +69 | 124 | 57 | +67 | +23.1 |
| Opponent | Long shot (under 50%) | 16 | 223 | 300 | -100 | 106 | 223 | -117 | -52.5 |
| Opponent | 50-54% | 1 | 480 | 197 | +195 | 294 | 240 | +54 | +11.1 |
| Opponent | Effective (55-75%) | 27 | 178 | 153 | +99 | 130 | 26 | +103 | +58.0 |
| Opponent | 76-89% | 22 | 231 | 172 | +108 | 153 | 27 | +126 | +54.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 26 | 327 | 221 | +249 | 280 | 38 | +242 | +73.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 332 | 83 | +83 | 83 | 0 | +83 | +25.0 |
| Opponent | No odds | 15 | 274 | 155 | +83 | 118 | 30 | +88 | +32.3 |
| Opponent | All fights | 109 | 250 | 194 | +106 | 166 | 60 | +106 | +42.4 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| co-opp-a57fba0-p1 | move | 394 | 85 (22%) | 62 (16%) | 49 (12%) | 260 (66%) |
| co-opp-a57fba0-p1 | objective | 416 | 47 (11%) | 35 (8%) | 57 (14%) | 312 (75%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

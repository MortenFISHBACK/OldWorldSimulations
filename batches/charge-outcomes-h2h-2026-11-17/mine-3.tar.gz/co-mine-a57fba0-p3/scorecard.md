# Doctrine scorecard: co-mine-a57fba0-p3

### Scorecard: co-mine-a57fba0-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | 3 | 3 | 2 | 1 | 0 | 0 | 322 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 5 | 1 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 8 | - | 0 | 1 | 0 | 0 | 0 | 317 |
| L0126 | 6 | 1 | Opponent | no | 18 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 2 | 2 | 0 | 4 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Opponent | no | 10 | 2 | 1 | 0 | 0 | 0 | 0 | 501 |
| L0226 | 4 | 1 | Mine | no | 7 | 3 | 3 | 2 | 1 | 0 | 0 | 442 |
| L0226 | 4 | 1 | Opponent | no | 2 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | no | - | 3 | 0 | 1 | 0 | 0 | 0 | 590 |
| L0311 | 5 | 1 | Opponent | yes | - | 3 | 1 | 1 | 0 | 0 | 0 | 427 |
| L0327 | 3 | 1 | Mine | yes | 2 | 3 | 4 | 0 | 0 | 0 | 0 | 685 |
| L0327 | 3 | 1 | Opponent | no | 4 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | yes | - | 3 | 4 | 1 | 1 | 0 | 0 | 140 |
| L0429 | 3 | 1 | Mine | yes | 5 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 4 | 3 | 5 | 0 | 0 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 2 | 4 | 1 | 1 | 0 | 0 | 0 | 666 |
| L0516 | 6 | 1 | Opponent | no | 5 | 2 | 3 | 1 | 1 | 0 | 0 | 200 |
| L0533 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 1193 |
| L0533 | 5 | 1 | Opponent | yes | - | 2 | 2 | 5 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | 6 | 3 | 0 | 0 | 0 | 0 | 801 |
| L0620 | 2 | 1 | Opponent | - | - | - | 0 | 2 | 1 | 0 | 0 | 210 |
| L0709 | 1 | 1 | Mine | yes | 7 | 3 | 1 | 0 | 1 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 925 |
| L0725 | 5 | 1 | Mine | yes | - | 6 | 1 | 3 | 0 | 0 | 0 | 420 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 5 | 3 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | 6 | 1 | 1 | 0 | 0 | 0 | 515 |
| L0815 | 5 | 1 | Opponent | no | - | 2 | 2 | 2 | 0 | 0 | 0 | 115 |
| L0831 | 3 | 1 | Mine | no | 2 | 4 | 2 | 1 | 0 | 0 | 0 | 605 |
| L0831 | 3 | 1 | Opponent | no | 10 | 2 | 2 | 3 | 2 | 0 | 0 | 340 |
| L0922 | 4 | 1 | Mine | no | 0 | 5 | 1 | 0 | 0 | 0 | 0 | 841 |
| L0922 | 4 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 1 | 0 | 0 | 55 |
| L1013 | 5 | 1 | Mine | yes | - | 2 | 2 | 1 | 1 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | yes | - | - | 0 | 3 | 0 | 0 | 0 | 549 |
| L1030 | 4 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1030 | 4 | 1 | Opponent | no | 1 | 3 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 3 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1122 | 6 | 1 | Opponent | no | 8 | 2 | 3 | 1 | 1 | 0 | 0 | 72 |
| L1216 | 4 | 1 | Mine | no | 4 | 2 | 4 | 0 | 0 | 0 | 0 | 524 |
| L1216 | 4 | 1 | Opponent | no | 7 | 2 | 5 | 1 | 0 | 0 | 0 | 414 |
| L1232 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 3 | 3 | 4 | 1 | 0 | 0 | 340 |
| L1327 | 1 | 1 | Mine | no | 7 | 4 | 3 | 0 | 0 | 0 | 0 | 302 |
| L1327 | 1 | 1 | Opponent | no | 6 | 2 | 4 | 2 | 1 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Mine | no | 4 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 3 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 1 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | yes | - | 4 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 2 | 2 | 3 | 0 | 0 | 0 | 414 |
| L1633 | 1 | 1 | Mine | no | 10 | 2 | 1 | 0 | 1 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 0 | 1 | 4 | 2 | 0 | 0 | 0 | 405 |
| L1731 | 3 | 1 | Mine | yes | 7 | 3 | 6 | 0 | 1 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Opponent | no | 1 | 2 | 2 | 0 | 1 | 0 | 0 | 340 |
| L1831 | 1 | 1 | Mine | no | 3 | 4 | 0 | 1 | 0 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 4 | 2 | 2 | 1 | 1 | 0 | 0 | 170 |
| L1932 | 6 | 1 | Mine | no | 1 | 2 | 4 | 0 | 1 | 0 | 0 | 339 |
| L1932 | 6 | 1 | Opponent | no | 2 | 2 | 4 | 0 | 1 | 0 | 0 | 340 |
| L2033 | 5 | 1 | Mine | no | - | 3 | 0 | 6 | 1 | 0 | 0 | 420 |
| L2033 | 5 | 1 | Opponent | yes | - | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Mine | no | 1 | 1 | 7 | 0 | 2 | 0 | 0 | 225 |
| L2223 | 3 | 1 | Opponent | no | 5 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Opponent | no | - | 2 | 4 | 0 | 0 | 0 | 0 | 60 |
| L2433 | 3 | 1 | Mine | no | 4 | 3 | 6 | 1 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 0 | 1 | 5 | 1 | 2 | 0 | 0 | 641 |
| L2630 | 2 | 1 | Mine | - | - | 3 | 8 | 0 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 1 | - | 0 | 2 | 1 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L3133 | 1 | 1 | Mine | no | 2 | 1 | 5 | 1 | 2 | 0 | 0 | 340 |
| L3133 | 1 | 1 | Opponent | no | 8 | 3 | 2 | 1 | 0 | 0 | 0 | 380 |
| **Average** | | | Mine | 28% | 3.6 | 3.0 | 2.6 | 0.9 | 0.4 | 0.0 | 0.0 | 319.1 |
| **Average** | | | Opponent | 22% | 4.3 | 2.2 | 3.1 | 1.5 | 0.4 | 0.0 | 0.0 | 209.4 |

### KPIs: co-mine-a57fba0-p3

Rules off - Opponent only: BREAK OUTCOMES, OVERRUN ON, STAND AND SHOOT, FLEES FROM CHARGE.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 25% (43 of 171) | 10% (16 of 168) | 17% (59 of 339) |
| Winner chose to follow up after the loser gave ground |  | 100% (66 of 66); on the table 100% | 100% (45 of 45); on the table 100% | 100% (111 of 111); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 85% (11 of 13); on the table 85% | 71% (10 of 14); on the table 71% | 78% (21 of 27); on the table 78% |
| Winner chose to pursue after the loser fled |  | 91% (20 of 22); on the table 91% | 69% (22 of 32); on the table 72% | 78% (42 of 54); on the table 80% |
| Winner chose to follow up or pursue (all three) |  | 96% (97 of 101); on the table 96% | 85% (77 of 91); on the table 86% | 91% (174 of 192); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 30% (102 of 342) | 34% (65 of 192) | 31% (167 of 534) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 49% (102 of 210) | 45% (65 of 145) | 47% (167 of 355) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 57% (8 of 14) | 51% (26 of 51) | 52% (34 of 65) |
| Points that never fought | lower | 36% (24768 of 68801) | 34% (24622 of 71990) | 35% (49390 of 140791) |
|   infantry points that never fought | lower | 36% (5112 of 14174) | 53% (7584 of 14220) | 45% (12696 of 28394) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (152 of 272) | 59% (169 of 285) | 58% (321 of 557) |
| Bound items with a magic missile used (at least once a game) |  | 96% (24 of 25); 1.6 uses a game | 83% (20 of 24); 2.1 uses a game | 90% (44 of 49); 1.8 uses a game |
| Bound items with another spell used |  | 36% (5 of 14); 0.2 uses a game | 33% (2 of 6); 0.1 uses a game | 35% (7 of 20); 0.1 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 45% (9 of 20); 0.2 uses a game | 43% (6 of 14); 0.2 uses a game | 44% (15 of 34); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 51% (30411 of 59391) | 53% (34090 of 64043) | 52% (64501 of 123434) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (20%) | 1.1 (32%) | 2.4 (24%) |
| MARCHED: its unit marched | 1.2 (18%) | 0.8 (21%) | 1.9 (19%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.1 (4%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.6 (23%) | 0.7 (20%) | 2.3 (22%) |
| REAR RANK: in a rear rank | 0.1 (2%) | 0.2 (5%) | 0.3 (3%) |
| FLEEING: fleeing | 0.1 (2%) | 0.2 (5%) | 0.3 (3%) |
| GONE: slain | 1.5 (22%) | 0.4 (12%) | 1.9 (19%) |
| OFF THE TABLE: off the table or not arrived | 0.5 (8%) | 0.0 (0%) | 0.5 (5%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.9 | 1.2 | 1.6 | 4.6 | 0.9 | 1.7 |
| not cast | 3.9 | 1.4 | 4.6 | 10.2 | 2.3 | 19.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.6 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 0.7 (50%) | 0.3 (7%) | 2.4 (24%) | 0.3 (14%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.9 (19%) | 0.4 (17%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.1 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.1 (10%) | 0.7 (16%) | 2.3 (22%) | 0.4 (15%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.0 (0%) | 0.3 (7%) | 0.3 (3%) | 0.1 (6%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (1%) | 0.1 (10%) | 0.1 (1%) | 0.3 (3%) | 0.1 (2%) | 0.5 (3%) |
| GONE: slain | 1.1 (28%) | 0.2 (12%) | 1.3 (28%) | 1.9 (19%) | 0.3 (13%) | 2.5 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (4%) | 0.1 (10%) | 0.3 (6%) | 0.5 (5%) | 0.1 (5%) | 0.3 (1%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (4%) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) | 0.6 (25%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (54%) | 0.1 (8%) | 1.5 (32%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.1 (74%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 0.6 a game | 0.8 a game |
| stood (cast and not dispelled) | 50% (15 of 30) | 69% (11 of 16) | 57% (26 of 46) |
| the unit moved after it | 67% (10 of 15) | 64% (7 of 11) | 65% (17 of 26) |
| it charged on its next turn | 0% (0 of 15) | 9% (1 of 11) | 4% (1 of 26) |
| the enemy charged it first | 33% (5 of 15) | 18% (2 of 11) | 27% (7 of 26) |
| it fought by the end of its next turn | 13% (2 of 15) | 0% (0 of 11) | 8% (2 of 26) |
| it moved out of a charge the enemy had planned (not charged first) | 13% (2 of 15) | 18% (2 of 11) | 15% (4 of 26) |
| none of these (no charge, no fight, no charge escaped) | 53% (8 of 15) | 55% (6 of 11) | 54% (14 of 26) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (507 of 791) | 61% (379 of 617) | 63% (886 of 1408) |
|   cavalry | 59% (42 of 71) | 66% (74 of 112) | 63% (116 of 183) |
|   character | 62% (68 of 110) | 29% (34 of 119) | 45% (102 of 229) |
|   chariot | 42% (43 of 102) | 71% (22 of 31) | 49% (65 of 133) |
|   infantry | 51% (106 of 208) | 67% (177 of 264) | 60% (283 of 472) |
|   monster | 50% (18 of 36) | 80% (4 of 5) | 54% (22 of 41) |
|   war machine | 87% (230 of 264) | 79% (68 of 86) | 85% (298 of 350) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (29%) | 1.5 (22%) | 3.8 (26%) |
| CHARGED: it charged | 1.2 (15%) | 1.4 (21%) | 2.6 (18%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.8 (11%) | 0.6 (9%) | 1.4 (10%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.1 (1%) | 0.1 (1%) |
| NO TARGET IN RANGE | 0.9 (12%) | 1.0 (16%) | 1.9 (13%) |
| ONLY IN COMBAT: the only targets were in combat | 0.5 (6%) | 0.3 (5%) | 0.8 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.6 (20%) | 1.2 (19%) | 2.8 (20%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.1 (2%) | 0.2 (1%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| OTHER BAR | 0.3 (4%) | 0.3 (5%) | 0.6 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.0 | 1.0 | 83% | 5.4 pts | 27 pts |
| character | 3.3 | 1.1 | 78% | 6.6 pts | 22 pts |
| chariot | 1.8 | 0.6 | 79% | 11.6 pts | 21 pts |
| infantry | 12.5 | 4.5 | 75% | 9.7 pts | 121 pts |
| monster | 0.8 | 0.3 | 72% | 13.3 pts | 11 pts |
| war machine | 8.6 | 7.5 | 59% | 25.6 pts | 221 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.5 | 5.4 | 4.9 |
| Charges that made contact a game | 3.2 | 3.8 | 3.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.81 declared, 0.63 contact (27 units) | 0.85 declared, 0.70 contact (20 units) | 0.83 declared, 0.66 contact (47 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.50 declared, 0.50 contact (4 units) | 1.12 declared, 0.62 contact (8 units) | 0.92 declared, 0.58 contact (12 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.61 declared, 0.43 contact (223 units) | 0.63 declared, 0.44 contact (267 units) | 0.62 declared, 0.43 contact (490 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 58% (45 of 77) | 47% (7 of 15) | 70% (7 of 10) | 58% (59 of 102) |
| Character in a unit | 73% (24 of 33) | 73% (8 of 11) | 33% (1 of 3) | 70% (33 of 47) |
| Character on its own | 75% (33 of 44) | 47% (21 of 45) | 32% (23 of 72) | 48% (77 of 161) |
| Chariot | 82% (9 of 11) | 67% (8 of 12) | - | 74% (17 of 23) |
| Infantry | 61% (43 of 70) | 52% (22 of 42) | 40% (2 of 5) | 57% (67 of 117) |
| Monster | 65% (22 of 34) | 43% (3 of 7) | - | 61% (25 of 41) |
| Monstrous | 60% (6 of 10) | 45% (5 of 11) | - | 52% (11 of 21) |
| War Machines | 70% (30 of 43) | 100% (2 of 2) | - | 71% (32 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (17 of 17); on the table 100% | 21% (20 of 96) | 33% | 73% (16 of 22) | 83% (5 of 6); 3.2 uses a game | 50% (1 of 2); 0.5 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 93% (14 of 15); on the table 93% | 47% (17 of 36) | 42% | 59% (19 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 50% (1 of 2); on the table 50% | - | 56% | 71% (17 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 78% (7 of 9); on the table 78% | 33% (10 of 30) | 41% | 61% (36 of 59) | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 8 | 100% (15 of 15); on the table 100% | 34% (65 of 192) | 46% | 57% (42 of 74) | 89% (16 of 18); 5.6 uses a game | 0% (0 of 4); 0.0 uses a game | 38% (3 of 8); 0.4 uses a game |
| High Elf Realms | 7 | 100% (11 of 11); on the table 100% | 31% (13 of 42) | 41% | 59% (32 of 54) | 89% (8 of 9); 3.3 uses a game | 50% (6 of 12); 1.1 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 100% (5 of 5); on the table 100% | - | 39% | 39% (7 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Lizardmen | 1 | 100% (4 of 4); on the table 100% | 50% (3 of 6) | 20% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 0% (0 of 1); on the table 0% | 0% (0 of 6) | 22% | 14% (1 of 7) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (6 of 6); on the table 100% | 25% (3 of 12) | 9% | 25% (4 of 16) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Skaven | 2 | 100% (2 of 2); on the table 100% | 17% (2 of 12) | 58% | 64% (9 of 14) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Tomb Kings of Khemri | 6 | 88% (21 of 24); on the table 88% | 0% (0 of 6) | 21% | 31% (8 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 91% (30 of 33); on the table 91% | 26% (14 of 54) | 21% | 43% (20 of 46) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 11 | 85% (33 of 39); on the table 87% | 50% (15 of 30) | 33% | 67% (64 of 96) | 100% (4 of 4); 1.2 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 6 | 89% (8 of 9); on the table 89% | 42% (5 of 12) | 32% | 68% (42 of 62) | 91% (10 of 11); 6.3 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (co-mine-a57fba0-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 41% (32) | 55% (43) | 48% (75) |
| ...free all their last turn and able to turn (per game) | 0.58 | 0.61 | 1.19 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.14 | 0.28 | 0.42 |
| ...with the charger already in that arc before they moved (per game) | 0.44 | 0.39 | 0.83 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.89 | 1.44 | 3.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.83 | 0.67 | 1.50 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 4.83 | 4.69 | 9.53 |

### Quality by phase: co-mine-a57fba0-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.2 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 52% (72 of 138) | 48% (71 of 149) |
| Strategy | Shoot objectives carried out (shot that target) | 47% (174 of 372) | 50% (130 of 261) |
| Strategy | Close-in objectives charged next turn | 14% (30 of 208) | 15% (34 of 231) |
| Strategy | Support requests answered (helper made contact too) | 50% (5 of 10) | 48% (10 of 21) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 46% (6 of 13) | 60% (3 of 5) |
| Strategy | Joined characters whose unit fought | 49% (17 of 35) | 47% (18 of 38) |
| Strategy | Lone characters that fought | 76% (76 of 100) | 74% (71 of 96) |
| Movement | Charges halted short of contact | 0.2 | 0.2 |
| Movement | Idle units | 0.9 | 1.5 |
| Movement | Points that never moved of their own | 319.1 | 209.4 |
| Movement | Fights charged into per game | 3.0 | 3.1 |
| Movement | Charges with odds: long shots (under 50%) | 9 of 97, net +66 | 28 of 96, net +103 |
| Movement | Charges with odds: sweet spot (55-75%) | 21 of 97, net +84 | 11 of 96, net +96 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 14 of 97, net +149 | 10 of 96, net +106 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 16 of 97, net +123 | 24 of 96, net +88 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.1 | 10.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (131 of 292) | 46% (175 of 378) |
| Shooting | Points destroyed by shooting units | 46.9 | 34.8 |
| Shooting | War machine shots | 6.4 | 2.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 52% (120 of 230) | 31% (25 of 80) |
| Shooting | Points destroyed by war machines | 91.2 | 19.2 |
| Magic | Magic missiles cast | 1.9 | 1.4 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 38% (26 of 68) | 31% (15 of 49) |
| Magic | Wounds caused by magic missiles | 2.7 | 2.6 |
| Magic | Wounds caused by other spells | 1.9 | 0.6 |
| Magic | Points destroyed by magic (all spells) | 97.4 | 68.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.4 / 0.8 / 0.1 | 2.1 / 0.2 / 0.3 / 0.5 |
| Combat | Points destroyed in combat | 363.2 | 341.0 |
| Combat | Points run down | 63.7 | 132.4 |
| Combat | Net points per charged fight, damage counted | +88 | +101 |
| Combat | Net per 100 charger points, damage counted | +31.5 | +33.6 |
| Combat | First round won (charged fights) | 79% | 65% |
| Combat | Net points per charged fight | +85 | +105 |
| Combat | Net points per supported fight / lone fight | +62 / +87 | +184 / +90 |
| Combat | Charged fights on a top-3 enemy unit | 31 of 108 | 51 of 110 |
| Game | Points lost | 751.4 | 755.3 |
| Game | VP from objectives | 485.3 | 577.2 |
| Game | Lone holders (player turns) | 3.6 | 4.3 |

- Mine won / drew / lost: 15 / 9 / 12 of 36 ended games (of 36); mean margin (Mine - Opponent) -89 VP
- The side that went first won 14 of 27 games with a winner
- Points traded per game (both sides' losses): 1507
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: co-mine-a57fba0-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 4.8 | -172.2 | 140.0 | 69.5 | 3.6 | -108.7 | 137.7 | 55.6 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.8 | +0.0 | 0.0 | 32.1 | 0.1 | +0.0 | 0.0 | 4.6 |
| BACKUP TARGETS | 0.7 | +3.2 | 0.0 | 13.8 | 0.5 | +3.0 | 0.0 | 13.8 |
| BEST FACING | 0.5 | +28.9 | 0.0 | 28.0 | 0.4 | +20.6 | 0.0 | 22.0 |
| BEST FIRST | 1.5 | +65.3 | 42.5 | 29.1 | 1.0 | +71.9 | 25.2 | 21.9 |
| BEST OVERALL | 0.5 | +44.2 | 0.0 | 0.0 | 0.2 | +5.7 | 0.0 | 5.2 |
| BEST PREY | 0.4 | +22.5 | 6.0 | 0.0 | 0.6 | +32.8 | 11.5 | 19.5 |
| BEST PRIZE | 0.1 | +1.3 | 0.0 | 0.0 | 0.1 | -2.2 | 0.0 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | -1.5 | 0.0 | 10.5 | 0.2 | -1.4 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 5.3 | 0.0 |
| BLOCKED WHEEL | 0.4 | +29.6 | 0.0 | 3.1 | 0.2 | +1.6 | 0.0 | 1.4 |
| BLOWS WHERE AIMED | 0.2 | -10.4 | 7.7 | 5.4 | 0.3 | -59.8 | 32.5 | 0.0 |
| BOMBING RUN | 0.1 | +1.0 | 0.0 | 8.3 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 4.2 |
| BREAK OUTCOMES | 2.5 | -31.6 | 153.5 | 55.1 | - | - | - | - |
| CANNON PLAN MISSED | 0.5 | +0.0 | 39.9 | 10.7 | 0.2 | +0.0 | 19.8 | 0.0 |
| CANNON PLANNED TARGET | 5.7 | +136.5 | 417.8 | 96.5 | 1.3 | +68.0 | 72.4 | 33.5 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 20.4 | 6.0 | 0.1 | +0.0 | 13.1 | 6.6 |
| CAST JOB | 0.8 | +23.4 | 74.6 | 4.7 | 0.8 | +22.8 | 44.5 | 5.3 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +28.7 | 9.2 | 0.0 | 0.1 | +0.4 | 4.7 | 0.0 |
| CASTS AFTER FRIENDS | 0.4 | +0.0 | 0.0 | 31.4 | 0.4 | +0.0 | 0.0 | 6.5 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.8 | +44.3 | 0.0 | 21.1 | 1.6 | +84.5 | 0.0 | 36.1 |
| CHAFF PASSED | 0.1 | -0.0 | 0.0 | 0.0 | 0.2 | -0.6 | 16.2 | 5.7 |
| CHARGE NOW FIRST | 2.5 | +0.0 | 232.6 | 84.1 | 2.6 | +0.0 | 224.2 | 60.1 |
| CHARGE NOW WEIGHED | 0.7 | -63.7 | 28.7 | 52.4 | 0.3 | -35.4 | 4.1 | 0.0 |
| CHARGER SLAIN LOST | 0.4 | -14.3 | 33.1 | 8.1 | 0.6 | -25.2 | 63.8 | 2.2 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 2.4 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.0 | -2.1 | 0.0 | 11.0 | 0.1 | +0.0 | 0.0 | 15.0 |
| CHEAP HELPER | 0.1 | +0.0 | 1.8 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.7 | +0.0 | 26.7 | 24.3 | 0.5 | +0.0 | 48.8 | 16.6 |
| CONVEYANCE SEARCH | 0.5 | +65.3 | 0.0 | 20.4 | 0.2 | +21.2 | 4.4 | 7.6 |
| COVER ONCE | 7.6 | -531.4 | 0.0 | 158.6 | 5.6 | -387.4 | 0.0 | 160.0 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 6.7 | 0.0 |
| DEFENSIVE FLOOR | 0.0 | +1.5 | 3.2 | 0.0 | 0.0 | +0.9 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.2 | +3.1 | 10.5 | 0.0 | 0.2 | +3.2 | 19.9 | 1.2 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.9 | +129.6 | 0.0 | 56.9 | 1.4 | +104.9 | 0.0 | 61.5 |
| FALLBACK BY WORTH | 4.0 | +42.5 | 0.0 | 51.2 | 4.8 | +33.0 | 0.0 | 37.9 |
| FIGHT LIFT | 0.1 | +2.9 | 0.0 | 0.0 | 0.1 | +3.5 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.0 | +0.4 | 2.9 | 2.2 | - | - | - | - |
| FLANK NOT WEIGHED | 5.1 | +0.0 | 0.0 | 133.5 | 4.8 | +0.0 | 0.0 | 108.7 |
| FLEES FROM CHARGE | 0.6 | +21.0 | 33.7 | 31.7 | - | - | - | - |
| FOLLOW UP WEIGHED | 1.2 | +218.2 | 0.0 | 107.2 | 0.9 | +137.3 | 0.0 | 27.6 |
| FRIENDS SHOTS CHECKED | 0.3 | +24.6 | 0.0 | 16.0 | 0.1 | +6.5 | 0.0 | 7.2 |
| GIVES UP | 0.1 | -0.6 | 3.9 | 3.2 | 0.1 | -0.5 | 2.4 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -0.1 | 12.3 | 0.0 |
| GROUND FLIERS | 0.0 | +2.9 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 1.5 | 0.0 | 0.1 | +0.0 | 1.8 | 1.1 |
| HELPER UNSEEN | 0.3 | +0.0 | 25.9 | 0.0 | 0.4 | +0.0 | 47.1 | 12.8 |
| HILL BY ITS CHANCE | 0.2 | -21.7 | 0.0 | 1.8 | 0.4 | -62.9 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 8.3 | -152.9 | 410.6 | 154.7 | 8.4 | -204.9 | 382.6 | 177.5 |
| HORN WORTH | - | - | - | - | 0.1 | +0.5 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +6.6 | 12.6 | 0.0 | 0.1 | +4.9 | 3.5 | 5.8 |
| HUNT DROPPED | 0.0 | +0.0 | 4.6 | 0.0 | 0.2 | +0.0 | 6.9 | 5.8 |
| HUNT IN PAIRS | 0.3 | +13.8 | 0.0 | 15.9 | 0.5 | +25.1 | 0.0 | 24.6 |
| HUNT KEPT | 0.2 | +8.1 | 12.6 | 0.0 | 0.1 | +1.7 | 0.0 | 3.4 |
| HUNT RESULT | 0.1 | +13.5 | 4.6 | 0.0 | 0.2 | +9.3 | 6.9 | 9.0 |
| HUNT THE GUNS | 0.1 | +39.8 | 8.1 | 0.0 | 0.2 | +88.0 | 5.4 | 3.4 |
| IDLE COST | 15.1 | -255.5 | 0.0 | 164.7 | 17.9 | -319.4 | 0.0 | 249.5 |
| INVITES THE FIGHT | 1.1 | +6.7 | 28.0 | 7.9 | 0.6 | +3.6 | 22.8 | 20.8 |
| JOINT CHARGE PLAN | 0.1 | +0.5 | 0.0 | 0.0 | 0.2 | +9.8 | 0.0 | 5.2 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -5.5 | 41.3 | 0.0 |
| KEEP FALLS | 0.1 | +2.7 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.1 | +0.3 | 0.0 | 1.4 | 0.1 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.9 | +57.5 | 123.2 | 68.5 | 1.9 | +56.7 | 134.7 | 4.9 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | - | - | - | - | 1.7 | +89.9 | 102.1 | 23.4 |
| KILLS COUNT NEXT TURN | 5.0 | +197.4 | 243.2 | 85.8 | 7.3 | +250.2 | 203.5 | 193.1 |
| LONE CHARACTER SAFE SPOT | 0.2 | +16.6 | 7.5 | 3.2 | 0.3 | +12.4 | 0.0 | 19.6 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 6.6 | 0.0 | 0.4 | +0.0 | 4.0 | 16.0 |
| LONE WIZARD KEPT IN | 0.6 | +37.3 | 0.0 | 0.0 | 0.4 | +25.4 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | -1.7 | 38.1 | 7.0 | 0.3 | +3.0 | 31.5 | 1.4 |
| LOST CHARGE | 2.9 | -47.7 | 88.1 | 96.4 | 2.0 | -28.3 | 52.0 | 103.3 |
| LURE BY WHAT IT DRAWS | 0.1 | -14.9 | 0.0 | 7.6 | 0.2 | -13.1 | 0.0 | 3.7 |
| MAKE SURE TOGETHER | 1.0 | +126.2 | 28.5 | 28.8 | 1.1 | +108.3 | 0.0 | 44.3 |
| MANOEUVRE | 0.3 | +4.2 | 0.0 | 0.0 | 0.2 | +6.3 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.2 | +0.7 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 4.5 |
| MARCH CHECK | 0.5 | +18.4 | 0.0 | 15.0 | 0.6 | +26.3 | 0.0 | 18.2 |
| MARCH ODDS | 0.4 | +18.3 | 30.6 | 6.5 | 0.2 | +7.4 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.6 | +23.2 | 0.0 | 10.5 | 0.4 | +29.4 | 0.0 | 9.0 |
| MAX FOR POSITIONING | 6.4 | +91.6 | 0.0 | 152.0 | 6.6 | +98.4 | 0.0 | 149.8 |
| MISSILES IN THE MOVE | 4.0 | +127.5 | 0.0 | 103.9 | 4.0 | +79.6 | 0.0 | 93.9 |
| MISSILES NEXT TURN | 5.0 | +83.9 | 0.0 | 137.5 | 5.1 | +54.4 | 0.0 | 98.4 |
| MODEL FACING | 0.1 | +21.1 | 0.0 | 1.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 24.9 | 21.1 | 0.2 | +0.0 | 6.4 | 0.0 |
| MOVE AND CAST | 0.4 | +27.5 | 0.0 | 2.4 | 0.5 | +15.6 | 0.0 | 22.8 |
| MOVE SPELL IN RANGE | 0.3 | +11.0 | 0.0 | 10.6 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.6 | -25.2 | 1.8 | 30.6 | 0.2 | -4.0 | 0.0 | 14.1 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 4.1 | +405.1 | 155.7 | 96.5 | 4.8 | +392.9 | 122.1 | 126.5 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.0 | +2.1 | 4.0 | 0.0 |
| NOT NEEDED | 0.2 | -4.7 | 14.4 | 0.0 | 0.2 | -15.9 | 43.6 | 0.0 |
| NOT TURNED | 4.8 | +55.3 | 0.0 | 92.6 | 4.7 | +49.1 | 0.0 | 115.1 |
| NOT WORTH A CAST | 0.6 | -0.3 | 0.0 | 34.7 | 0.8 | -0.9 | 0.0 | 19.4 |
| OFF BEST | 15.8 | -700.2 | 1.8 | 304.9 | 16.2 | -805.4 | 0.0 | 272.1 |
| ONE FIGHT FORMULA | 8.8 | -159.3 | 28.0 | 182.1 | 7.9 | -180.2 | 22.8 | 187.3 |
| ONE OBJECTIVE FORMULA | 2.3 | -74.1 | 0.0 | 40.8 | 2.2 | -114.6 | 0.0 | 10.1 |
| OPENS A LANE | 0.0 | +0.0 | 0.0 | 0.0 | 0.3 | +2.0 | 57.8 | 5.4 |
| OPENS UP | 0.4 | +33.1 | 20.1 | 16.4 | 0.2 | +10.7 | 8.2 | 0.0 |
| OVERRUN ON | 0.6 | +18.8 | 45.6 | 37.1 | - | - | - | - |
| OVERRUNS AWAY | 0.3 | +7.4 | 26.2 | 16.4 | 0.5 | +9.0 | 47.4 | 26.3 |
| PATHS CROSS | 1.9 | +130.8 | 0.0 | 29.8 | 2.2 | +149.9 | 0.0 | 48.3 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +1.5 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.0 | 0.0 | 0.0 | 0.1 | -3.1 | 0.0 | 11.1 |
| PLAN RESULT | 36.1 | +1299.4 | 1236.6 | 886.2 | 36.4 | +1118.0 | 1246.2 | 944.6 |
| PURSUES BIG PREY | 0.1 | -3.4 | 0.0 | 0.0 | 0.1 | -3.9 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.1 | +24.7 | 0.0 | 1.5 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +4.9 | 0.0 | 0.0 | 0.1 | +5.9 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.4 | +6.8 | 0.0 | 9.4 | 1.4 | +23.9 | 0.0 | 56.7 |
| RANDOM MOVER NO PROMISE | 0.1 | -6.9 | 0.0 | 4.7 | 0.4 | -23.1 | 23.0 | 18.9 |
| REDIRECT BY WHAT IT STOPS | 0.6 | -9.3 | 0.0 | 13.5 | 1.3 | -27.9 | 0.0 | 28.3 |
| REDIRECT COUNTER | 1.9 | +167.2 | 0.0 | 30.5 | 2.9 | +230.1 | 0.0 | 46.1 |
| REDIRECT WEIGHED | 0.2 | +4.4 | 0.0 | 0.0 | 0.5 | +3.0 | 10.2 | 3.5 |
| REFUSING RETIRES | 0.1 | +0.0 | 0.0 | 5.3 | 0.4 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.4 | +20.2 | 0.0 | 8.3 | 1.1 | +46.2 | 0.0 | 16.6 |
| RESTRAINS TO SHOOT | 0.1 | +9.2 | 0.0 | 1.8 | 0.1 | +1.7 | 0.0 | 0.0 |
| RISK BY ARC | 2.0 | +70.7 | 152.5 | 54.3 | 2.6 | +67.5 | 188.3 | 43.6 |
| RISK ONCE | 4.8 | +174.9 | 32.4 | 133.4 | 4.4 | +196.6 | 69.3 | 280.2 |
| SAFE SURE CHARGE | 0.0 | -0.3 | 3.5 | 0.0 | - | - | - | - |
| SAFER THAN THE JOB | 0.8 | +81.4 | 0.0 | 25.9 | 0.7 | +36.6 | 0.0 | 20.0 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.0 | 0.3 | +1.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -0.8 | 0.0 | 0.0 | 0.3 | -26.2 | 0.0 | 3.2 |
| SEARCH SPOT | 2.2 | +87.0 | 0.0 | 30.7 | 2.1 | +94.4 | 0.0 | 36.7 |
| SECOND HUNTER | 0.0 | -0.9 | 4.6 | 0.0 | 0.0 | -0.1 | 0.0 | 0.0 |
| SELF MOVE SPELL | 0.3 | +43.5 | 0.0 | 51.0 | 0.2 | +65.6 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.5 | +163.8 | 48.7 | 34.0 | 1.9 | +177.7 | 26.0 | 53.9 |
| SET-UP ANY TARGET | 0.3 | +47.5 | 0.0 | 10.5 | 0.1 | +14.1 | 4.4 | 7.6 |
| SET-UP MISSED | 0.1 | +11.3 | 10.5 | 10.5 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.4 | +0.7 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.1 | +32.5 | 45.5 | 5.7 | 1.2 | +32.4 | 19.9 | 6.4 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.5 | +0.0 | 128.9 | 5.5 | 0.2 | +0.0 | 30.2 | 0.0 |
| SHOTS IN THE MOVE | 13.3 | +573.3 | 0.0 | 254.5 | 9.9 | +388.6 | 0.0 | 140.4 |
| SPELL SETS UP CHARGE | 0.4 | +63.6 | 0.0 | 10.5 | 0.1 | +21.9 | 4.4 | 7.6 |
| SPELL WORTH | 1.4 | +26.6 | 43.6 | 63.2 | 2.4 | +39.9 | 63.3 | 70.3 |
| SPELLS IN THE FIGHT | 0.5 | -1.2 | 59.6 | 9.6 | 0.7 | -8.2 | 64.3 | 21.5 |
| STABLE ROLE | 9.8 | +0.0 | 243.9 | 138.4 | 9.0 | +0.0 | 277.6 | 106.3 |
| STAND AND SHOOT | 0.2 | -1.5 | 6.3 | 21.8 | - | - | - | - |
| STAY WEIGHED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| STOPS | 0.2 | +7.4 | 8.1 | 0.0 | 0.2 | +2.8 | 1.9 | 1.1 |
| STOPS SHORT OF THE FLANK | 0.5 | +22.9 | 0.0 | 15.0 | 0.5 | +22.2 | 0.0 | 7.1 |
| STUCK PIVOT | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 4.7 |
| SUPPORT NARROWED | 6.1 | -60.9 | 251.6 | 152.8 | 6.2 | -49.6 | 292.2 | 86.4 |
| SUPPORTS | 4.3 | +71.5 | 88.3 | 90.8 | 4.1 | +50.2 | 152.0 | 46.2 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -7.5 | 13.3 | 0.0 | 0.2 | -6.3 | 24.8 | 0.0 |
| SURE REACH TOGETHER | 0.5 | -1.2 | 32.5 | 24.0 | 0.6 | -9.5 | 0.0 | 2.0 |
| THROUGH LINE OF FIRE | 0.4 | +20.4 | 0.0 | 0.0 | 0.2 | +10.2 | 0.0 | 8.2 |
| TURN WORTH | 0.2 | -17.9 | 14.4 | 24.3 | 0.3 | -18.6 | 16.2 | 5.4 |
| TWO OR MORE ARRIVE | 0.3 | +5.0 | 13.9 | 6.5 | 0.7 | +4.3 | 12.3 | 37.9 |
| WAIT AFTER COSTS | 7.3 | -346.1 | 269.1 | 121.3 | 7.2 | -334.4 | 220.8 | 160.3 |
| WALKS TO THE FIGHT | 1.5 | +14.0 | 40.6 | 12.7 | 1.1 | +5.3 | 47.9 | 6.7 |
| WAR ENGINE CHARGES | 0.1 | +10.1 | 10.4 | 0.0 | 0.1 | +4.2 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 11.5 | 7.5 | 0.1 | +0.0 | 0.0 | 0.0 |
| WEARS DOWN | 0.9 | +33.2 | 55.0 | 18.9 | 1.0 | +37.2 | 138.1 | 31.2 |
| WHO HITS BACK | 0.2 | +19.5 | 0.0 | 0.0 | 0.1 | +10.4 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.2 | +15.2 | 59.5 | 0.0 | 0.4 | +47.6 | 63.4 | 0.5 |
| WHOLE FIGHT GAIN | 0.1 | +4.6 | 8.9 | 0.0 | 0.5 | +29.5 | 86.9 | 1.1 |
| WIDER SPREAD | 2.1 | -7.6 | 176.3 | 24.3 | 2.6 | -4.9 | 230.5 | 36.3 |

### Rule changes: co-mine-a57fba0-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1153 | 1153 | 1153 | 32.03 | -54198 | -47.0 |
| MOVE TO CHARGE | 318 | 318 | 180 | 5.00 | +11479 | +63.8 |
| PATHS CROSS | 148 | 148 | 148 | 4.11 | +10106 | +68.3 |
| SEARCH SPOT | 153 | 153 | 148 | 4.11 | +6537 | +44.2 |
| KILLS COUNT NEXT TURN | 443 | 443 | 147 | 4.08 | +3877 | +26.4 |
| SUPPORTS | 302 | 302 | 130 | 3.61 | +1457 | +11.2 |
| FACES THE THREAT | 120 | 120 | 120 | 3.33 | +8443 | +70.4 |
| SHOTS IN THE MOVE | 837 | 563 | 93 | 2.58 | +2125 | +22.8 |
| BEST FIRST | 91 | 91 | 91 | 2.53 | +4942 | +54.3 |
| WAIT AFTER COSTS | 522 | 522 | 87 | 2.42 | +1531 | +17.6 |
| FOLLOW UP WEIGHED | 77 | 77 | 77 | 2.14 | +12798 | +166.2 |
| ARTILLERY RE-ROLL WEIGHED | 69 | 69 | 69 | 1.92 | +0 | +0.0 |
| FALLBACK BY WORTH | 314 | 314 | 68 | 1.89 | +2719 | +40.0 |
| COVER ONCE | 476 | 245 | 64 | 1.78 | +1240 | +19.4 |
| ADVANCE WORTH | 299 | 299 | 61 | 1.69 | +936 | +15.3 |
| CANNON PLANNED TARGET | 250 | 250 | 56 | 1.56 | -883 | -15.8 |
| CANNON SIGHT KEPT | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| RISK ONCE | 329 | 228 | 56 | 1.56 | +1925 | +34.4 |
| CHAFF IN THE MOVE | 87 | 84 | 54 | 1.50 | +1964 | +36.4 |
| SAFER THAN THE JOB | 54 | 54 | 54 | 1.50 | +4250 | +78.7 |
| SET UP TOGETHER | 125 | 102 | 53 | 1.47 | +4429 | +83.6 |
| RESERVE FALL BACK | 52 | 52 | 52 | 1.44 | +2391 | +46.0 |
| MISSILES IN THE MOVE | 287 | 164 | 51 | 1.42 | +866 | +17.0 |
| REDIRECT COUNTER | 174 | 87 | 48 | 1.33 | +4400 | +91.7 |
| COMBAT PIVOT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| RISK BY ARC | 165 | 163 | 41 | 1.14 | +872 | +21.3 |
| HOLDS AMBUSHERS | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 38 | 38 | 38 | 1.06 | +1624 | +42.7 |
| MARCH CHECK | 41 | 40 | 37 | 1.03 | +1288 | +34.8 |
| CHARGE NOW WEIGHED | 36 | 36 | 36 | 1.00 | +3410 | +94.7 |
| ADVANCE LANE KEPT | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| BEST FACING | 34 | 34 | 34 | 0.94 | +1782 | +52.4 |
| ONE FIGHT FORMULA | 602 | 333 | 34 | 0.94 | +179 | +5.3 |
| RANDOM MOVE BY FIGURES | 65 | 65 | 34 | 0.94 | +1104 | +32.5 |
| WALKS TO THE FIGHT | 96 | 96 | 34 | 0.94 | +215 | +6.3 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2259 | +68.5 |
| MOVE AND CAST | 32 | 32 | 32 | 0.89 | +1549 | +48.4 |
| CHARGE NOW FIRST | 183 | 183 | 31 | 0.86 | -1637 | -52.8 |
| IDLE COST | 1190 | 646 | 31 | 0.86 | +372 | +12.0 |
| SHOOTS FROM THE BEST SPOT | 83 | 83 | 31 | 0.86 | +817 | +26.4 |
| MAX FOR POSITIONING | 468 | 257 | 30 | 0.83 | +142 | +4.7 |
| CAST JOB | 59 | 59 | 29 | 0.81 | +564 | +19.5 |
| HONEST WORTH | 603 | 603 | 28 | 0.78 | +207 | +7.4 |
| BEST OVERALL | 26 | 26 | 26 | 0.72 | +1796 | +69.1 |
| KEEPS ITS TARGET | 137 | 137 | 26 | 0.72 | +418 | +16.1 |
| REDIRECT WEIGHED | 26 | 26 | 26 | 0.72 | +437 | +16.8 |
| MAKE SURE TOGETHER | 76 | 50 | 25 | 0.69 | +2617 | +104.7 |
| SCOUT WAITS | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| SHOT REPLANNED | 24 | 24 | 24 | 0.67 | +0 | +0.0 |
| BLOCKED WHEEL | 22 | 22 | 22 | 0.61 | +1122 | +51.0 |
| THROUGH LINE OF FIRE | 22 | 22 | 22 | 0.61 | +1104 | +50.2 |
| MARCH ODDS | 22 | 22 | 20 | 0.56 | +209 | +10.4 |
| WAR ENGINE JOBS | 29 | 29 | 19 | 0.53 | -794 | -41.8 |
| KILLS COUNT | 60 | 59 | 18 | 0.50 | +836 | +46.5 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +36 | +2.0 |
| INVITES THE FIGHT | 58 | 58 | 17 | 0.47 | +108 | +6.4 |
| BIG CHARACTER SAFETY | 16 | 16 | 16 | 0.44 | -106 | -6.6 |
| SURE CHARGE BEATS ADVANCE | 15 | 15 | 15 | 0.42 | -497 | -33.2 |
| FRIENDS SHOTS CHECKED | 14 | 14 | 14 | 0.39 | +1121 | +80.1 |
| BEST PREY | 34 | 34 | 13 | 0.36 | +753 | +57.9 |
| LOST CHARGE | 177 | 177 | 13 | 0.36 | +272 | +21.0 |
| MANOEUVRE | 18 | 18 | 13 | 0.36 | +378 | +29.1 |
| OPENS UP | 20 | 20 | 13 | 0.36 | +569 | +43.8 |
| CHAFF PASSED | 12 | 12 | 12 | 0.33 | -23 | -1.9 |
| SUPPORT NARROWED | 445 | 445 | 12 | 0.33 | -122 | -10.2 |
| WHO HITS BACK | 12 | 12 | 12 | 0.33 | +654 | +54.5 |
| HUNT IN PAIRS | 31 | 17 | 10 | 0.28 | +177 | +17.7 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTING BLOCK | 11 | 11 | 9 | 0.25 | +427 | +47.4 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| WEARS DOWN | 67 | 67 | 9 | 0.25 | +212 | +23.5 |
| WHOLE FIGHT | 24 | 24 | 9 | 0.25 | +616 | +68.4 |
| WHOLE FIGHT GAIN | 24 | 22 | 9 | 0.25 | +301 | +33.5 |
| LONE WIZARD HOLDS BACK | 19 | 19 | 8 | 0.22 | -305 | -38.1 |
| PIVOT GUARDS FLANK | 8 | 8 | 8 | 0.22 | -147 | -18.4 |
| HUNT ADVANCE | 9 | 9 | 7 | 0.19 | +275 | +39.3 |
| MISSILES NEXT TURN | 365 | 202 | 7 | 0.19 | +25 | +3.6 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +141 | +20.1 |
| REFUSING RETIRES | 21 | 21 | 7 | 0.19 | -1 | -0.1 |
| STUCK PIVOT | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 162 | 76 | 6 | 0.17 | +202 | +33.7 |
| BEST PRIZE | 5 | 5 | 5 | 0.14 | -126 | -25.1 |
| FLEES FROM CHARGE | 21 | 20 | 5 | 0.14 | +366 | +73.2 |
| KEEP FALLS | 5 | 5 | 5 | 0.14 | +131 | +26.1 |
| MODEL FACING | 5 | 5 | 5 | 0.14 | +761 | +152.2 |
| OVERRUN ON | 20 | 20 | 5 | 0.14 | +196 | +39.3 |
| RAIDS THE BAGGAGE NEXT TURN | 5 | 5 | 5 | 0.14 | +161 | +32.1 |
| RESTRAINS TO SHOOT | 5 | 5 | 5 | 0.14 | +393 | +78.6 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| BLOCKED CHARGE SKIPPED | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| BREAK OUTCOMES | 90 | 89 | 4 | 0.11 | +37 | +9.2 |
| EDGE GIVE GROUND | 15 | 15 | 4 | 0.11 | +12 | +2.9 |
| OVERRUNS AWAY | 28 | 28 | 4 | 0.11 | +133 | +33.1 |
| PURSUES BIG PREY | 4 | 4 | 4 | 0.11 | -262 | -65.5 |
| SURE REACH TOGETHER | 40 | 32 | 4 | 0.11 | +7 | +1.7 |
| RAIDS THE BAGGAGE | 4 | 4 | 3 | 0.08 | +595 | +198.4 |
| SPELLS IN THE FIGHT | 43 | 42 | 3 | 0.08 | +178 | +59.4 |
| TWO OR MORE ARRIVE | 37 | 32 | 3 | 0.08 | +28 | +9.3 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +36 | +18.1 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.06 | +0 | +0.1 |
| DEFENSIVE ARMY | 10 | 10 | 2 | 0.06 | -25 | -12.6 |
| HORN WORTH | 2 | 2 | 2 | 0.06 | +18 | +9.1 |
| LONG SHOT | 27 | 27 | 2 | 0.06 | +11 | +5.6 |
| WIDER SPREAD | 172 | 171 | 2 | 0.06 | +15 | +7.6 |
| BACKUP TARGETS | 44 | 22 | 1 | 0.03 | +0 | +0.0 |
| BLOWS WHERE AIMED | 20 | 20 | 1 | 0.03 | +13 | +12.9 |
| DEFENSIVE FLOOR | 2 | 2 | 1 | 0.03 | +48 | +47.6 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +15 | +15.1 |
| JOINT CHARGE PLAN | 10 | 10 | 1 | 0.03 | +26 | +26.2 |
| KEEPS ITS PREY | 4 | 4 | 1 | 0.03 | +8 | +8.4 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| NEEDED THERE | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +54 | +54.4 |
| REDIRECT BY WHAT IT STOPS | 67 | 67 | 1 | 0.03 | +109 | +108.6 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -11 | -10.9 |
| SCREEN BY WHAT IT SAVES | 16 | 16 | 1 | 0.03 | +5 | +4.6 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.2 |
| STOPS | 14 | 14 | 1 | 0.03 | +5 | +5.0 |
| WAR ENGINE CHARGES | 5 | 5 | 1 | 0.03 | +95 | +95.1 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 24 | 24 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 2 | 2 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 10 | 10 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 30 | trace | - | - | - | - |
| CHARGER SLAIN LOST | 37 | 36 | 0 | 0.00 | - | - |
| CHARIOT NO STATIC JOB | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 5 | 5 | 0 | 0.00 | - | - |
| CHEAP HELPER | 3 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 26 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 7 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 354 | not checked | - | - | - | - |
| GIVES UP | 6 | 6 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 25 | 25 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 23 | 23 | 0 | 0.00 | - | - |
| HUNT DROPPED | 7 | trace | - | - | - | - |
| HUNT KEPT | 11 | trace | - | - | - | - |
| HUNT RESULT | 12 | trace | - | - | - | - |
| HUNT THE GUNS | 13 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 5 | 5 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 20 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 10 | 10 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 7 | trace | - | - | - | - |
| MARCH OVER CASTS | 35 | 35 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 16 | 16 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 12 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 27 | trace | - | - | - | - |
| MOVE SPELL SPOT | 11 | not checked | - | - | - | - |
| NOT NEEDED | 15 | 15 | 0 | 0.00 | - | - |
| NOT TURNED | 343 | 343 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 51 | not checked | - | - | - | - |
| OPENS A LANE | 13 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 2610 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 17 | 17 | 0 | 0.00 | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SECOND HUNTER | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 17 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 15 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SPELL SETS UP CHARGE | 19 | not checked | - | - | - | - |
| SPELL WORTH | 137 | not checked | - | - | - | - |
| STABLE ROLE | 679 | 678 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 7 | 7 | 0 | 0.00 | - | - |
| TURN WORTH | 20 | 20 | 0 | 0.00 | - | - |

### Off best figure: co-mine-a57fba0-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.31 | 14.92 | 47.8 |
| FALLBACK | gate | 0.58 | 0.67 | 43.3 |
| CHARGE NOW FIRST | rule | 0.36 | 0.44 | 56.4 |
| TURN GATE | gate | 0.50 | 0.31 | 47.0 |
| CANNON PLANNED TARGET | rule | 0.36 | 0.14 | 58.2 |
| WAR ENGINE JOBS | rule | 0.42 | 0.08 | 44.1 |
| SURE CHARGE BEATS ADVANCE | rule | 0.17 | 0.25 | 33.2 |
| SUPPORT NARROWED | rule | 0.08 | 0.25 | 10.2 |
| BIG CHARACTER SAFETY | rule | 0.17 | 0.14 | 10.4 |
| AFTERMATH BAND | gate | 0.17 | 0.08 | 2.3 |
| CHAFF PASSED | rule | - | 0.22 | 2.9 |
| LONE WIZARD HOLDS BACK | rule | 0.08 | 0.14 | 38.1 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.11 | 18.4 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | 0.06 | 40.5 |
| BEST PRIZE | rule | 0.06 | 0.06 | 31.4 |
| FACES THE THREAT | rule | 0.08 | 0.03 | 10.0 |
| FIGHT ORDER BAND | gate | 0.03 | 0.08 | 3.0 |
| LONE CHARACTER SAFE SPOT | gate | 0.03 | 0.08 | 80.0 |
| PATHS CROSS | rule | 0.08 | 0.03 | 22.5 |
| PURSUES BIG PREY | rule | 0.06 | 0.06 | 65.5 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.08 | 11.1 |
| CHARGE NOW WEIGHED | rule | 0.08 | - | 89.4 |
| SAFER THAN THE JOB | rule | 0.06 | 0.03 | 10.1 |
| DEFENSIVE ARMY | rule | 0.06 | - | 12.6 |
| MARCH ODDS | rule | 0.03 | 0.03 | 3.0 |
| NO REASON | gate | 0.06 | - | 8.7 |
| REDIRECT WEIGHED | rule | 0.03 | 0.03 | 31.8 |
| RULE SWITCHED OFF | gate | - | 0.06 | 11.8 |
| SUPPORT REQUEST | gate | 0.06 | - | 6.8 |
| BLOCKED WHEEL | rule | 0.03 | - | 11.2 |
| FRIENDS SHOTS CHECKED | rule | - | 0.03 | 1.8 |
| REFUSING RETIRES | rule | - | 0.03 | 0.7 |
| SAFE SURE CHARGE | rule | 0.03 | - | 10.9 |
| THROUGH LINE OF FIRE | rule | 0.03 | - | 2.5 |
| WHO HITS BACK | rule | 0.03 | - | 4.7 |

### Plans: co-mine-a57fba0-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 8.9 | 16% | 131 | 224 | 171% |
| Mine | charge | 3.0 | 59% | 257 | 264 | 103% |
| Mine | close in | 5.8 | 24% | 392 | 203 | 52% |
| Mine | hold | 4.6 | 35% | 262 | 0 | 0% |
| Mine | join | 0.4 | 100% | 21 | 0 | 0% |
| Mine | shoot | 8.5 | 62% | 221 | 608 | 275% |
| Mine | support | 4.9 | 89% | 53 | 0 | 0% |
| Opponent | advance | 10.2 | 18% | 161 | 281 | 175% |
| Opponent | charge | 3.8 | 57% | 319 | 338 | 106% |
| Opponent | close in | 6.4 | 23% | 375 | 176 | 47% |
| Opponent | hold | 3.8 | 34% | 276 | 0 | 0% |
| Opponent | join | 0.6 | 91% | 32 | 0 | 0% |
| Opponent | shoot | 5.9 | 58% | 154 | 326 | 211% |
| Opponent | support | 5.6 | 86% | 35 | 0 | 0% |

### Packages: hunt the guns, co-mine-a57fba0-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 4 | 1 | 67% | 67% | 0% | 3.5 | 386 | 162 | 0% | 27 |
| Opponent | 0.2 | 9 | 0 | 11% | 22% | 0% | 2.0 | 352 | 37 | 22% | 82 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.8 | 3 | 1 | 50% | 50% | 0% | 4.0 | 392 | 139 | 0% | 13 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 32 |
| Empire of Man | 0.2 | 1 | 0 | 100% | 100% | 0% | 3.0 | 375 | 208 | 0% | 110 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 21 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 163 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 190 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.7 | 4 | 0 | 0% | 0% | 0% | - | 436 | 0 | 0% | 44 |
| Vampire Counts | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 78 | 76 | 100% | 21 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 100% | 0% | 2.0 | 304 | 259 | 100% | 50 |
| Wood Elf Realms | 0.5 | 3 | 0 | 0% | 0% | 0% | - | 348 | 0 | 0% | 42 |

### Battle groups: co-mine-a57fba0-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.9 | 34% | 87% | 13% | 33% | 45% | 0% | 5% | 50% | 0% |
| Opponent | REDIRECT COUNTER | 2.9 | 26% | 82% | 21% | 17% | 23% | 0% | 14% | 64% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: co-mine-a57fba0-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | Chaff | 34 | 57 (34) | 10 | 46 | 44 | 32% | 2.4 | 63 (21) | 0 (4) | 60 (9) | 84 (24) | 0 (10) |
| Mine | Character | 118 | 50 (118) | 50 | 0 | 35 | 18% | 2.5 | 65 (38) | 55 (56) | 20 (3) | 54 (55) | 62 (42) |
| Mine | Clean-up | 18 | 87 (18) | 46 | 42 | 52 | 33% | 2.8 | 79 (3) | 74 (13) | 273 (2) | 124 (12) | 31 (6) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 44 | 32 (44) | 19 | 12 | 49 | 32% | 2.9 | 38 (22) | 28 (14) | 22 (8) | 40 (30) | 17 (14) |
| Mine | Fragile | 3 | 0 (3) | 0 | 0 | 33 | 67% | 4.0 | 0 (3) | - | - | 0 (1) | 0 (2) |
| Mine | Hammer | 52 | 43 (52) | 33 | 10 | 35 | 8% | 2.8 | 18 (14) | 50 (35) | 79 (3) | 50 (36) | 29 (16) |
| Mine | Holder | 25 | 50 (25) | 25 | 25 | 34 | 40% | 2.8 | 41 (7) | 53 (11) | 69 (6) | 64 (14) | 38 (10) |
| Mine | Shooter | 37 | 57 (37) | 16 | 41 | 47 | 5% | 1.8 | 37 (6) | 64 (29) | 0 (2) | 73 (22) | 31 (15) |
| Mine | Support | 4 | 0 (4) | 0 | 0 | 58 | 0% | 2.5 | 0 (1) | - | - | 0 (1) | - |
| Mine | War machine | 52 | 45 (52) | 45 | 0 | 40 | 2% | 1.0 | 85 (13) | 23 (36) | 133 (3) | 81 (13) | 33 (39) |
| Mine | Wizard | 17 | 30 (17) | 30 | 0 | 62 | 6% | 2.4 | 66 (3) | 47 (5) | 63 (1) | 47 (6) | 74 (3) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 68 | 38 (68) | 12 | 26 | 50 | 43% | 2.9 | 54 (29) | 20 (11) | 35 (28) | 36 (48) | 44 (20) |
| Opponent | Character | 102 | 54 (102) | 54 | 0 | 38 | 17% | 2.2 | 44 (34) | 68 (52) | 23 (4) | 62 (51) | 52 (39) |
| Opponent | Clean-up | 11 | 65 (11) | 20 | 45 | 13 | 45% | 3.2 | 9 (4) | 87 (6) | 130 (1) | 47 (6) | 81 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 60 | 54 (60) | 35 | 19 | 55 | 17% | 2.8 | 37 (30) | 54 (20) | 111 (10) | 58 (28) | 49 (32) |
| Opponent | Fragile | 3 | 31 (3) | 31 | 0 | 100 | 0% | 2.3 | - | 46 (2) | 0 (1) | 46 (2) | 0 (1) |
| Opponent | Hammer | 50 | 32 (50) | 24 | 9 | 44 | 26% | 2.9 | 26 (17) | 36 (30) | 6 (3) | 25 (30) | 43 (20) |
| Opponent | Holder | 40 | 56 (40) | 10 | 46 | 27 | 32% | 3.1 | 6 (9) | 81 (21) | 70 (8) | 71 (27) | 36 (11) |
| Opponent | Shooter | 27 | 58 (27) | 29 | 29 | 30 | 7% | 1.3 | 148 (6) | 27 (19) | 87 (2) | 44 (16) | 75 (11) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 34 | 25% | 6.0 | - | 0 (3) | 0 (1) | 0 (2) | 0 (2) |
| Opponent | War machine | 17 | 48 (17) | 48 | 0 | 55 | 0% | 1.5 | 0 (3) | 58 (10) | 51 (4) | 0 (3) | 56 (14) |
| Opponent | Wizard | 32 | 22 (32) | 22 | 0 | 33 | 16% | 2.1 | 11 (15) | 48 (9) | 0 (3) | 30 (15) | 0 (12) |

### Charged fights: co-mine-a57fba0-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 41 | 66 | 1.8 | 1.0 | 38 | 24 | +14 | 0 of 7 | 5 of 7 | - | +14 |
| Mine | Chaos Dwarfs | 4 | 88 | 324 | 3.5 | 1.1 | 93 | 22 | +70 | 6 of 14 | 12 of 14 | +162 | +63 |
| Mine | Dwarfen Mountain Holds | 3 | 587 | 22 | 2.0 | 1.2 | 11 | 10 | +1 | 2 of 6 | 4 of 6 | -60 | +13 |
| Mine | Empire of Man | 5 | 437 | 201 | 1.4 | 1.1 | 143 | 0 | +143 | 1 of 7 | 7 of 7 | +663 | +57 |
| Mine | Grand Cathay | 5 | 573 | 186 | 3.2 | 1.0 | 58 | 15 | +44 | 7 of 16 | 12 of 16 | - | +44 |
| Mine | High Elf Realms | 4 | 95 | 309 | 2.8 | 1.1 | 112 | 34 | +78 | 5 of 11 | 9 of 11 | +54 | +81 |
| Mine | Kingdom of Bretonnia | 1 | 19 | 741 | 3.0 | 1.0 | 247 | 0 | +247 | 1 of 3 | 2 of 3 | - | +247 |
| Mine | Lizardmen | 1 | 0 | 1127 | 5.0 | 1.0 | 225 | 0 | +225 | 1 of 5 | 5 of 5 | - | +225 |
| Mine | Ogre Kingdoms | 1 | 427 | 170 | 1.0 | 1.0 | 170 | 0 | +170 | 0 of 1 | 0 of 1 | - | +170 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 309 | 5.0 | 1.0 | 62 | 0 | +62 | 1 of 5 | 4 of 5 | - | +62 |
| Mine | Skaven | 1 | 0 | 19 | 1.0 | 2.0 | 19 | 0 | +19 | 0 of 1 | 1 of 1 | +19 | - |
| Mine | Tomb Kings of Khemri | 2 | 33 | 932 | 7.5 | 1.3 | 124 | 54 | +70 | 4 of 15 | 11 of 15 | -44 | +111 |
| Mine | Vampire Counts | 2 | 122 | 871 | 5.0 | 1.0 | 174 | 6 | +168 | 2 of 10 | 8 of 9 | - | +168 |
| Mine | Warriors of Chaos | 2 | 10 | 412 | 3.5 | 1.3 | 118 | 58 | +60 | 1 of 7 | 4 of 7 | +10 | +80 |
| **Mine** | all armies | 36 | 236 | 322 | 3.0 | 1.1 | 107 | 22 | +85 | 31 of 108 | 84 of 107 | +62 | +87 |
| Opponent | Empire of Man | 1 | 569 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 3 | 403 | 354 | 2.3 | 1.3 | 152 | 62 | +90 | 5 of 7 | 2 of 7 | +55 | +104 |
| Opponent | High Elf Realms | 3 | 197 | 81 | 1.7 | 1.0 | 49 | 109 | -60 | 2 of 5 | 4 of 5 | - | -60 |
| Opponent | Kingdom of Bretonnia | 2 | 130 | 632 | 3.5 | 1.1 | 181 | 70 | +111 | 5 of 7 | 4 of 7 | +379 | +66 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 571 | 4.0 | 1.2 | 143 | 26 | +117 | 2 of 4 | 3 of 4 | +0 | +156 |
| Opponent | Skaven | 1 | 60 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 113 | 876 | 4.0 | 1.2 | 219 | 12 | +207 | 7 of 16 | 11 of 16 | +153 | +219 |
| Opponent | Vampire Counts | 6 | 33 | 692 | 4.2 | 1.4 | 166 | 48 | +118 | 13 of 25 | 16 of 25 | +187 | +92 |
| Opponent | Warriors of Chaos | 9 | 28 | 338 | 3.3 | 1.1 | 101 | 8 | +94 | 13 of 30 | 22 of 30 | +401 | +72 |
| Opponent | Wood Elf Realms | 6 | 136 | 240 | 2.5 | 1.1 | 96 | 35 | +61 | 4 of 15 | 10 of 15 | +130 | +50 |
| **Opponent** | all armies | 36 | 122 | 424 | 3.1 | 1.2 | 139 | 34 | +105 | 51 of 110 | 72 of 110 | +184 | +90 |

### Effective charges: co-mine-a57fba0-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 7 | 1 (net -30) | 0 | 2 (net +40) | 2 (net +30) | 0 | 1 (net -12) | 1 | 33% (2 of 6) |
| Mine | Chaos Dwarfs | 14 | 1 (net +494) | 0 | 3 (net +74) | 6 (net +11) | 1 (net +162) | 2 (net +22) | 1 | 23% (3 of 13) |
| Mine | Dwarfen Mountain Holds | 6 | 2 (net -30) | 0 | 0 | 4 (net +16) | 0 | 0 | 0 | 0% (0 of 6) |
| Mine | Empire of Man | 7 | 0 | 0 | 1 (net +125) | 1 (net +0) | 2 (net +368) | 2 (net +72) | 1 | 17% (1 of 6) |
| Mine | Grand Cathay | 16 | 1 (net +0) | 2 (net +35) | 3 (net +92) | 5 (net +68) | 2 (net -44) | 1 (net +98) | 2 | 21% (3 of 14) |
| Mine | High Elf Realms | 11 | 1 (net -175) | 0 | 0 | 3 (net -3) | 5 (net +158) | 2 (net +128) | 0 | 0% (0 of 11) |
| Mine | Kingdom of Bretonnia | 3 | 1 (net +505) | 0 | 1 (net +0) | 0 | 0 | 1 (net +236) | 0 | 33% (1 of 3) |
| Mine | Lizardmen | 5 | 0 | 0 | 1 (net +0) | 2 (net +72) | 0 | 0 | 2 | 33% (1 of 3) |
| Mine | Ogre Kingdoms | 1 | 0 | 0 | 0 | 1 (net +170) | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Orc & Goblin Tribes | 5 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 0 | 3 | 0% (0 of 2) |
| Mine | Skaven | 1 | 0 | 0 | 0 | 1 (net +19) | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 15 | 0 | 0 | 5 (net +45) | 6 (net +84) | 3 (net +83) | 1 (net +66) | 0 | 33% (5 of 15) |
| Mine | Vampire Counts | 10 | 0 | 1 (net -60) | 3 (net +203) | 0 | 0 | 6 (net +189) | 0 | 30% (3 of 10) |
| Mine | Warriors of Chaos | 7 | 1 (net -142) | 1 (net +190) | 2 (net +118) | 1 (net +19) | 1 (net +234) | 0 | 1 | 33% (2 of 6) |
| Opponent | Grand Cathay | 7 | 2 (net -217) | 0 | 1 (net +0) | 4 (net +266) | 0 | 0 | 0 | 14% (1 of 7) |
| Opponent | High Elf Realms | 5 | 1 (net +0) | 0 | 2 (net -40) | 0 | 0 | 2 (net -112) | 0 | 40% (2 of 5) |
| Opponent | Kingdom of Bretonnia | 7 | 3 (net -52) | 0 | 0 | 2 (net +248) | 0 | 1 (net +0) | 1 | 0% (0 of 6) |
| Opponent | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 0 | 0 | 2 (net +198) | 2 | 0% (0 of 2) |
| Opponent | Skaven | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 16 | 5 (net +428) | 0 | 1 (net +0) | 3 (net +50) | 3 (net +105) | 4 (net +176) | 0 | 6% (1 of 16) |
| Opponent | Vampire Counts | 25 | 6 (net +192) | 1 (net +492) | 2 (net -106) | 5 (net +122) | 5 (net +97) | 6 (net +72) | 0 | 8% (2 of 25) |
| Opponent | Warriors of Chaos | 30 | 7 (net +23) | 1 (net +0) | 4 (net +306) | 4 (net +115) | 0 | 9 (net +90) | 5 | 16% (4 of 25) |
| Opponent | Wood Elf Realms | 15 | 3 (net +6) | 0 | 1 (net +116) | 3 (net +211) | 2 (net +130) | 0 | 6 | 11% (1 of 9) |

### Charged fights, damage counted: co-mine-a57fba0-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 9 | 161 | 235 | +66 | 128 | 81 | +47 | +29.2 |
| Mine | 50-54% | 4 | 248 | 240 | +50 | 105 | 58 | +47 | +19.0 |
| Mine | Effective (55-75%) | 21 | 280 | 192 | +84 | 144 | 55 | +89 | +31.8 |
| Mine | 76-89% | 33 | 264 | 184 | +42 | 83 | 41 | +42 | +15.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 16 | 227 | 145 | +123 | 134 | 8 | +126 | +55.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 14 | 433 | 93 | +149 | 178 | 30 | +148 | +34.3 |
| Mine | No odds | 11 | 306 | 188 | +107 | 150 | 11 | +139 | +45.5 |
| Mine | All fights | 108 | 279 | 174 | +85 | 126 | 38 | +88 | +31.5 |
| Opponent | Long shot (under 50%) | 28 | 221 | 254 | +103 | 177 | 87 | +90 | +40.7 |
| Opponent | 50-54% | 2 | 499 | 314 | +246 | 335 | 31 | +304 | +60.9 |
| Opponent | Effective (55-75%) | 11 | 282 | 265 | +96 | 199 | 70 | +129 | +45.8 |
| Opponent | 76-89% | 21 | 384 | 232 | +162 | 182 | 40 | +142 | +37.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 24 | 289 | 193 | +88 | 139 | 74 | +65 | +22.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 10 | 535 | 131 | +106 | 137 | 28 | +109 | +20.3 |
| Opponent | No odds | 14 | 177 | 201 | +39 | 125 | 57 | +68 | +38.5 |
| Opponent | All fights | 110 | 301 | 221 | +105 | 164 | 63 | +101 | +33.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| co-mine-a57fba0-p3 | move | 394 | 78 (20%) | 58 (15%) | 53 (13%) | 263 (67%) |
| co-mine-a57fba0-p3 | objective | 439 | 62 (14%) | 46 (10%) | 68 (15%) | 309 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

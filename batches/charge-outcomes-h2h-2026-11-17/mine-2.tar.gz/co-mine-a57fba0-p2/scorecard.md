# Doctrine scorecard: co-mine-a57fba0-p2

### Scorecard: co-mine-a57fba0-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 2 | - | 0 | 4 | 0 | 0 | 0 | 65 |
| L0106 | 4 | 1 | Opponent | no | 2 | 2 | 1 | 0 | 1 | 0 | 0 | 981 |
| L0122 | 2 | 1 | Mine | - | - | 5 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | 5 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 4 | 0 | 1 | 0 | 0 | 0 | 615 |
| L0222 | 6 | 1 | Mine | no | 5 | 2 | 3 | 2 | 1 | 0 | 0 | 281 |
| L0222 | 6 | 1 | Opponent | no | 5 | 3 | 3 | 0 | 0 | 0 | 0 | 55 |
| L0307 | 1 | 1 | Mine | yes | 2 | 3 | 2 | 1 | 0 | 0 | 0 | 675 |
| L0307 | 1 | 1 | Opponent | yes | 3 | 2 | 1 | 0 | 0 | 0 | 0 | 420 |
| L0323 | 5 | 1 | Mine | no | - | - | 0 | 3 | 0 | 0 | 0 | 675 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 9 | 2 | 5 | 1 | 1 | 0 | 0 | 124 |
| L0409 | 1 | 1 | Opponent | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 769 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | yes | - | 6 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 966 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 0 | 3 | 1 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 2 | 3 | 1 | 1 | 0 | 0 | 0 | 475 |
| L0528 | 6 | 1 | Opponent | no | 6 | 3 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 615 |
| L0616 | 4 | 1 | Opponent | no | 5 | 3 | 1 | 1 | 1 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 3 | 5 | 0 | 0 | 0 | 0 | 926 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 6 | 3 | 0 | 0 | 0 | 0 |
| L0721 | 1 | 1 | Mine | yes | 4 | 2 | 2 | 0 | 2 | 0 | 0 | 420 |
| L0721 | 1 | 1 | Opponent | yes | 3 | - | 1 | 3 | 1 | 0 | 0 | 145 |
| L0810 | 6 | 1 | Mine | no | 0 | 3 | 1 | 3 | 0 | 0 | 0 | 864 |
| L0810 | 6 | 1 | Opponent | no | 5 | 2 | 1 | 0 | 1 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | 6 | 1 | 1 | 0 | 0 | 0 | 769 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 7 | 5 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 5 | - | 4 | 2 | 0 | 0 | 0 | 234 |
| L0934 | 4 | 1 | Mine | no | 0 | 3 | 0 | 0 | 0 | 0 | 0 | 768 |
| L0934 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 160 |
| L1026 | 6 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 2 | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 1 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 5 | 3 | 3 | 1 | 0 | 0 | 225 |
| L1135 | 1 | 1 | Mine | yes | 1 | 3 | 2 | 0 | 1 | 0 | 0 | 501 |
| L1135 | 1 | 1 | Opponent | yes | 0 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 4 | 4 | 2 | 1 | 0 | 0 | 0 | 330 |
| L1228 | 4 | 1 | Opponent | no | 3 | 2 | 3 | 1 | 0 | 0 | 0 | 111 |
| L1323 | 3 | 1 | Mine | no | 4 | 4 | 1 | 1 | 1 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | no | 4 | 2 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 3 | 4 | 1 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 4 | 3 | 2 | 1 | 0 | 0 | 305 |
| L1435 | 1 | 1 | Mine | no | 3 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 3 | 3 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 2 | 2 | 4 | 1 | 0 | 0 | 0 | 170 |
| L1629 | 3 | 1 | Mine | no | 9 | 2 | 5 | 0 | 0 | 0 | 0 | 200 |
| L1629 | 3 | 1 | Opponent | no | 0 | 4 | 4 | 0 | 1 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | yes | - | 3 | 1 | 0 | 0 | 0 | 0 | 49 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 0 | - | 1 | 0 | 1 | 0 | 0 | 413 |
| L1827 | 3 | 1 | Opponent | no | 6 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 1 | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Opponent | no | 2 | 2 | 1 | 1 | 1 | 0 | 0 | 190 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 1 | 1 | 1 | 0 | 0 | 210 |
| L2029 | 1 | 1 | Opponent | no | 0 | 3 | 6 | 0 | 1 | 0 | 0 | 170 |
| L2131 | 1 | 1 | Mine | yes | 6 | 4 | 1 | 4 | 0 | 0 | 0 | 145 |
| L2131 | 1 | 1 | Opponent | no | 0 | 5 | 2 | 3 | 1 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 0 | 1 | 0 | 0 | 126 |
| L2429 | 5 | 1 | Mine | yes | - | 5 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Mine | no | 6 | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 0 | 1 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | yes | - | 5 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 6 | 4 | 3 | 0 | 1 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 0 | 1 | 8 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 30% | 2.8 | 3.1 | 2.1 | 1.3 | 0.3 | 0.0 | 0.0 | 297.0 |
| **Average** | | | Opponent | 30% | 2.2 | 2.6 | 2.9 | 1.6 | 0.4 | 0.0 | 0.0 | 163.2 |

### KPIs: co-mine-a57fba0-p2

Rules off - Opponent only: BREAK OUTCOMES, OVERRUN ON, STAND AND SHOOT, FLEES FROM CHARGE.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 25% (44 of 174) | 17% (30 of 178) | 21% (74 of 352) |
| Winner chose to follow up after the loser gave ground |  | 98% (60 of 61); on the table 100% | 98% (80 of 82); on the table 98% | 98% (140 of 143); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 90% (9 of 10); on the table 90% | 72% (13 of 18); on the table 72% | 79% (22 of 28); on the table 79% |
| Winner chose to pursue after the loser fled |  | 74% (14 of 19); on the table 79% | 95% (35 of 37); on the table 95% | 88% (49 of 56); on the table 89% |
| Winner chose to follow up or pursue (all three) |  | 92% (83 of 90); on the table 94% | 93% (128 of 137); on the table 93% | 93% (211 of 227); on the table 94% |
| Magic missiles tried each own turn | 50%+ | 32% (109 of 342) | 40% (62 of 156) | 34% (171 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 47% (109 of 232) | 50% (56 of 113) | 48% (165 of 345) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 54% (14 of 26) | 54% (25 of 46) | 54% (39 of 72) |
| Points that never fought | lower | 39% (27616 of 71583) | 41% (29484 of 71989) | 40% (57100 of 143572) |
|   infantry points that never fought | lower | 41% (6671 of 16324) | 60% (8457 of 14029) | 50% (15128 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 62% (175 of 284) | 59% (174 of 297) | 60% (349 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 90% (18 of 20); 1.6 uses a game | 67% (12 of 18); 1.1 uses a game | 79% (30 of 38); 1.3 uses a game |
| Bound items with another spell used |  | 28% (5 of 18); 0.2 uses a game | 0% (0 of 2); 0.0 uses a game | 25% (5 of 20); 0.1 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 45% (9 of 20); 0.2 uses a game | 29% (2 of 7); 0.1 uses a game | 41% (11 of 27); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 58% (35034 of 60231) | 54% (34331 of 63281) | 56% (69365 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.8 (28%) | 0.8 (30%) | 2.6 (29%) |
| MARCHED: its unit marched | 1.0 (16%) | 0.4 (14%) | 1.4 (15%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.1 (3%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.4 (21%) | 0.4 (17%) | 1.8 (20%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.1 (5%) | 0.2 (2%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (1%) | 0.2 (2%) |
| GONE: slain | 1.1 (17%) | 0.6 (21%) | 1.6 (18%) |
| OFF THE TABLE: off the table or not arrived | 0.5 (7%) | 0.0 (0%) | 0.5 (5%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (2%) | 0.2 (7%) | 0.3 (4%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.9 | 1.4 | 1.1 | 4.8 | 0.4 | 1.4 |
| not cast | 3.9 | 3.5 | 3.9 | 9.1 | 1.9 | 20.2 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 1.0 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (36%) | 0.3 (8%) | 2.6 (29%) | 0.5 (28%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (15%) | 0.2 (12%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (1%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (1%) | 0.4 (10%) | 0.6 (16%) | 1.8 (20%) | 0.2 (13%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (8%) | 0.3 (9%) | 0.3 (9%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (4%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (2%) | 0.2 (5%) | 0.1 (3%) | 0.2 (2%) | 0.1 (6%) | 0.5 (2%) |
| GONE: slain | 0.8 (21%) | 0.8 (24%) | 0.6 (16%) | 1.6 (18%) | 0.4 (20%) | 4.3 (21%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (5%) | 0.1 (2%) | 0.0 (1%) | 0.5 (5%) | 0.0 (0%) | 0.4 (2%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.1 (2%) | 0.1 (1%) | 0.1 (1%) | 0.0 (0%) | 0.3 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (3%) | 0.3 (8%) | 0.0 (1%) | 0.1 (1%) | 0.3 (16%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.2 (57%) | 0.1 (4%) | 1.7 (44%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.8 (68%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.6 a game | 0.5 a game | 0.6 a game |
| stood (cast and not dispelled) | 62% (10 of 16) | 47% (9 of 19) | 54% (19 of 35) |
| the unit moved after it | 100% (10 of 10) | 56% (5 of 9) | 79% (15 of 19) |
| it charged on its next turn | 30% (3 of 10) | 0% (0 of 9) | 16% (3 of 19) |
| the enemy charged it first | 20% (2 of 10) | 11% (1 of 9) | 16% (3 of 19) |
| it fought by the end of its next turn | 10% (1 of 10) | 11% (1 of 9) | 11% (2 of 19) |
| it moved out of a charge the enemy had planned (not charged first) | 20% (2 of 10) | 0% (0 of 9) | 11% (2 of 19) |
| none of these (no charge, no fight, no charge escaped) | 40% (4 of 10) | 89% (8 of 9) | 63% (12 of 19) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (555 of 860) | 55% (430 of 780) | 60% (985 of 1640) |
|   cavalry | 58% (45 of 77) | 61% (104 of 171) | 60% (149 of 248) |
|   character | 49% (44 of 90) | 29% (29 of 100) | 38% (73 of 190) |
|   chariot | 56% (58 of 103) | 60% (28 of 47) | 57% (86 of 150) |
|   infantry | 55% (149 of 272) | 52% (160 of 306) | 53% (309 of 578) |
|   monster | 42% (21 of 50) | 61% (19 of 31) | 49% (40 of 81) |
|   war machine | 89% (238 of 268) | 72% (90 of 125) | 83% (328 of 393) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.1 (25%) | 2.3 (24%) | 4.4 (24%) |
| CHARGED: it charged | 1.2 (14%) | 1.6 (17%) | 2.8 (15%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.1 (1%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.9 (11%) | 0.5 (5%) | 1.4 (8%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 1.2 (15%) | 1.5 (15%) | 2.7 (15%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (8%) | 0.5 (5%) | 1.2 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.8 (21%) | 2.4 (24%) | 4.2 (23%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.3 (3%) | 0.4 (2%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.2 (2%) | 0.5 (5%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.9 | 1.3 | 83% | 4.6 pts | 27 pts |
| character | 2.1 | 0.9 | 72% | 12.1 pts | 25 pts |
| chariot | 2.4 | 1.5 | 64% | 17.4 pts | 42 pts |
| infantry | 11.7 | 5.4 | 71% | 11.2 pts | 131 pts |
| monster | 1.2 | 0.2 | 84% | 5.5 pts | 7 pts |
| war machine | 9.1 | 7.4 | 59% | 26.8 pts | 244 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.1 | 5.2 | 4.7 |
| Charges that made contact a game | 3.0 | 3.9 | 3.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.64 declared, 0.52 contact (25 units) | 0.70 declared, 0.70 contact (10 units) | 0.66 declared, 0.57 contact (35 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 0.88 contact (8 units) | 1.00 declared, 0.80 contact (10 units) | 1.00 declared, 0.83 contact (18 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.50 declared, 0.35 contact (246 units) | 0.59 declared, 0.43 contact (292 units) | 0.55 declared, 0.40 contact (538 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 64% (47 of 73) | 50% (9 of 18) | 58% (7 of 12) | 61% (63 of 103) |
| Character in a unit | 82% (31 of 38) | 72% (13 of 18) | 67% (2 of 3) | 78% (46 of 59) |
| Character on its own | 74% (25 of 34) | 58% (21 of 36) | 37% (23 of 63) | 52% (69 of 133) |
| Chariot | 76% (13 of 17) | 54% (7 of 13) | - | 67% (20 of 30) |
| Infantry | 51% (48 of 94) | 62% (21 of 34) | 33% (1 of 3) | 53% (70 of 131) |
| Monster | 52% (15 of 29) | 67% (6 of 9) | - | 55% (21 of 38) |
| Monstrous | 50% (7 of 14) | 79% (11 of 14) | - | 64% (18 of 28) |
| War Machines | 70% (40 of 57) | 100% (2 of 2) | - | 71% (42 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (13 of 13); on the table 100% | 34% (35 of 102) | 36% | 55% (12 of 22) | 83% (5 of 6); 2.8 uses a game | 50% (1 of 2); 0.2 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 100% (12 of 12); on the table 100% | 53% (19 of 36) | 57% | 69% (22 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 6 | 88% (15 of 17); on the table 88% | - | 65% | 70% (38 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 75% (6 of 8); on the table 88% | 25% (12 of 48) | 47% | 62% (47 of 76) | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game | 0% (0 of 4); 0.0 uses a game |
| Grand Cathay | 6 | 90% (9 of 10); on the table 100% | 36% (49 of 138) | 47% | 50% (27 of 54) | 79% (11 of 14); 7.0 uses a game | 0% (0 of 2); 0.0 uses a game | 17% (1 of 6); 0.2 uses a game |
| High Elf Realms | 4 | 100% (8 of 8); on the table 100% | 17% (3 of 18) | 27% | 55% (18 of 33) | 100% (3 of 3); 1.8 uses a game | 21% (3 of 14); 1.2 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 100% (15 of 15); on the table 100% | - | 31% | 42% (5 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | 100% (4 of 4); on the table 100% | - | 33% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 100% (8 of 8); on the table 100% | 6% (1 of 18) | 52% | 79% (22 of 28) | 100% (4 of 4); 3.2 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | - | 0% (0 of 12) | 3% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 3 | 86% (6 of 7); on the table 86% | 28% (5 of 18) | 28% | 60% (15 of 25) | 100% (2 of 2); 2.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Tomb Kings of Khemri | 5 | 92% (11 of 12); on the table 92% | - | 39% | 20% (5 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 93% (40 of 43); on the table 93% | 33% (22 of 66) | 32% | 65% (35 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 88% (38 of 43); on the table 88% | 50% (9 of 18) | 25% | 60% (44 of 73) | 100% (2 of 2); 0.9 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 96% (26 of 27); on the table 96% | 67% (16 of 24) | 40% | 68% (53 of 78) | 43% (3 of 7); 1.3 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (co-mine-a57fba0-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 57% (50) | 46% (35) | 52% (85) |
| ...free all their last turn and able to turn (per game) | 0.83 | 0.69 | 1.53 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.22 | 0.06 | 0.28 |
| ...with the charger already in that arc before they moved (per game) | 0.58 | 0.42 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.94 | 1.25 | 3.19 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.86 | 0.53 | 1.39 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.75 | 6.17 | 11.92 |

### Quality by phase: co-mine-a57fba0-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 54% (64 of 118) | 47% (89 of 190) |
| Strategy | Shoot objectives carried out (shot that target) | 43% (162 of 373) | 45% (120 of 269) |
| Strategy | Close-in objectives charged next turn | 13% (21 of 157) | 16% (41 of 254) |
| Strategy | Support requests answered (helper made contact too) | 62% (8 of 13) | 43% (12 of 28) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | 0% (0 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 71% (12 of 17) | 71% (10 of 14) |
| Strategy | Joined characters whose unit fought | 47% (27 of 58) | 33% (13 of 39) |
| Strategy | Lone characters that fought | 75% (65 of 87) | 73% (61 of 84) |
| Movement | Charges halted short of contact | 0.2 | 0.0 |
| Movement | Idle units | 1.3 | 1.6 |
| Movement | Points that never moved of their own | 297.0 | 163.2 |
| Movement | Fights charged into per game | 2.7 | 3.4 |
| Movement | Charges with odds: long shots (under 50%) | 10 of 88, net +39 | 20 of 113, net +71 |
| Movement | Charges with odds: sweet spot (55-75%) | 17 of 88, net +59 | 21 of 113, net +141 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 9 of 88, net +110 | 5 of 113, net +86 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 38 of 88, net +60 | 35 of 113, net +129 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.6 | 10.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 38% (130 of 346) | 50% (184 of 370) |
| Shooting | Points destroyed by shooting units | 122.4 | 69.2 |
| Shooting | War machine shots | 6.6 | 2.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 61% (145 of 238) | 49% (44 of 90) |
| Shooting | Points destroyed by war machines | 84.6 | 39.6 |
| Magic | Magic missiles cast | 1.9 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 26% (18 of 69) | 34% (14 of 41) |
| Magic | Wounds caused by magic missiles | 3.3 | 1.7 |
| Magic | Wounds caused by other spells | 1.1 | 0.9 |
| Magic | Points destroyed by magic (all spells) | 62.6 | 32.2 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.9 / 0.6 / 0.4 / 0.1 | 1.8 / 0.4 / 0.4 / 0.2 |
| Combat | Points destroyed in combat | 260.1 | 315.7 |
| Combat | Points run down | 54.3 | 153.5 |
| Combat | Net points per charged fight, damage counted | +64 | +115 |
| Combat | Net per 100 charger points, damage counted | +24.4 | +43.8 |
| Combat | First round won (charged fights) | 76% | 74% |
| Combat | Net points per charged fight | +64 | +115 |
| Combat | Net points per supported fight / lone fight | +88 / +61 | +226 / +99 |
| Combat | Charged fights on a top-3 enemy unit | 28 of 97 | 54 of 124 |
| Game | Points lost | 741.6 | 669.5 |
| Game | VP from objectives | 510.3 | 640.0 |
| Game | Lone holders (player turns) | 2.8 | 2.2 |

- Mine won / drew / lost: 11 / 5 / 20 of 36 ended games (of 36); mean margin (Mine - Opponent) -195 VP
- The side that went first won 16 of 31 games with a winner
- Points traded per game (both sides' losses): 1411
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: co-mine-a57fba0-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| ADVANCE WORTH | 5.8 | -159.5 | 278.4 | 67.9 | 4.4 | -190.4 | 143.4 | 64.4 |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +4.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.2 | +0.0 | 0.0 | 31.2 | 0.3 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.8 | +4.1 | 0.0 | 28.2 | 0.6 | +3.8 | 0.0 | 15.0 |
| BEST FACING | 0.6 | +29.4 | 0.0 | 43.9 | 0.2 | +5.4 | 0.0 | 33.6 |
| BEST FIRST | 1.5 | +78.8 | 63.9 | 9.2 | 1.1 | +29.5 | 12.8 | 31.8 |
| BEST OVERALL | 0.5 | +21.5 | 0.0 | 18.0 | 0.3 | +17.2 | 0.0 | 25.4 |
| BEST PREY | 0.8 | +55.5 | 32.3 | 26.7 | 0.8 | +36.6 | 20.3 | 12.1 |
| BEST PRIZE | 0.0 | -0.0 | 0.9 | 0.0 | - | - | - | - |
| BIG CHARACTER SAFETY | 0.1 | +0.8 | 0.0 | 32.5 | 0.1 | -0.0 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 5.8 | 0.0 | 0.1 | +0.0 | 13.8 | 6.5 |
| BLOCKED WHEEL | 0.5 | +16.8 | 0.0 | 0.0 | 0.4 | +7.3 | 0.0 | 20.0 |
| BLOWS WHERE AIMED | 0.2 | +0.4 | 19.7 | 0.0 | 0.3 | -51.3 | 34.6 | 6.0 |
| BOMBING RUN | 0.1 | +2.1 | 0.8 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 6.8 | - | - | - | - |
| BREAK OUTCOMES | 2.4 | -14.9 | 165.1 | 71.8 | - | - | - | - |
| CANNON PLAN MISSED | 0.9 | +0.0 | 120.2 | 20.8 | 0.2 | +0.0 | 1.4 | 0.0 |
| CANNON PLANNED TARGET | 5.1 | +220.2 | 476.0 | 109.2 | 2.0 | +77.5 | 102.4 | 18.3 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 2.5 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 5.8 | 0.0 | 0.2 | +0.0 | 47.7 | 12.1 |
| CAST JOB | 0.7 | +17.2 | 26.3 | 19.7 | 0.7 | +22.0 | 92.0 | 35.4 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.6 | +31.0 | 25.6 | 0.0 | 0.3 | +11.6 | 5.2 | 0.0 |
| CASTS AFTER FRIENDS | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 16.5 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +2.3 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.9 | +47.3 | 0.0 | 23.6 | 1.8 | +87.5 | 0.0 | 46.6 |
| CHAFF PASSED | 0.2 | -0.2 | 0.0 | 7.9 | 0.3 | -0.4 | 0.0 | 13.2 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 172.2 | 73.6 | 2.6 | +0.0 | 330.4 | 43.3 |
| CHARGE NOW WEIGHED | 0.6 | -26.5 | 29.2 | 13.5 | 0.6 | -33.8 | 17.1 | 20.1 |
| CHARGER SLAIN LOST | 0.4 | -6.9 | 18.9 | 17.9 | 0.7 | -33.2 | 49.8 | 7.9 |
| CHARIOT WIZARD CAREFUL | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHEAP HELPER | 0.1 | +0.0 | 3.8 | 0.0 | 0.2 | +0.0 | 19.6 | 1.7 |
| COMBAT PIVOT | 0.4 | +0.0 | 1.7 | 23.3 | 0.6 | +0.0 | 33.2 | 0.0 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.3 | +28.5 | 13.9 | 13.9 | 0.4 | +28.4 | 24.6 | 29.4 |
| COVER ONCE | 8.8 | -672.2 | 0.0 | 237.8 | 6.3 | -491.8 | 0.0 | 174.6 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 3.1 | 0.0 | 0.2 | +0.0 | 24.0 | 0.0 |
| DEFENSIVE FLOOR | 0.0 | +2.7 | 0.0 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +1.5 | 12.5 | 0.0 | 0.5 | +10.5 | 31.2 | 7.1 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.9 | +123.9 | 0.0 | 80.1 | 1.2 | +113.2 | 0.0 | 54.9 |
| FALLBACK BY WORTH | 4.5 | +51.0 | 0.0 | 48.6 | 5.3 | +42.0 | 0.0 | 107.6 |
| FIGHT LIFT | 0.0 | +1.1 | 0.0 | 0.0 | 0.0 | +0.5 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.0 | +3.0 | 0.0 | 0.0 | 0.1 | +2.2 | 0.0 | 0.0 |
| FLANK NOT WEIGHED | 5.8 | +0.0 | 0.0 | 126.6 | 5.4 | +0.0 | 0.0 | 184.1 |
| FLEES FROM CHARGE | 0.4 | +4.9 | 14.7 | 2.5 | - | - | - | - |
| FOCUS FIRE | 0.0 | +2.4 | 0.0 | 0.0 | 0.0 | +0.4 | 1.5 | 0.0 |
| FOLLOW UP WEIGHED | 1.1 | +170.1 | 0.0 | 46.1 | 1.4 | +171.9 | 0.0 | 24.7 |
| FRIENDS SHOTS CHECKED | 0.1 | +5.4 | 0.0 | 0.0 | 0.1 | +13.1 | 0.0 | 0.0 |
| GIVES UP | 0.0 | -0.1 | 0.0 | 1.4 | 0.1 | -1.2 | 14.9 | 0.0 |
| GIVES UP ITS SCREEN | 0.0 | -0.2 | 0.0 | 3.2 | 0.1 | -1.0 | 7.9 | 0.0 |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 2.8 | 6.8 | 0.1 | +0.0 | 6.3 | 0.8 |
| HELPER UNSEEN | 0.3 | +0.0 | 19.3 | 10.5 | 0.4 | +0.0 | 30.8 | 5.1 |
| HILL BY ITS CHANCE | 0.4 | -46.2 | 0.0 | 0.0 | 0.6 | -46.4 | 0.0 | 3.8 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 6.8 | -101.4 | 275.3 | 145.4 | 10.3 | -211.2 | 709.3 | 221.9 |
| HORN WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.0 | +0.2 | 0.0 | 0.0 | 0.5 | +4.5 | 10.8 | 0.0 |
| HUNT DROPPED | - | - | - | - | 0.2 | +0.0 | 5.8 | 0.0 |
| HUNT IN PAIRS | 0.4 | +20.3 | 0.0 | 0.0 | 0.8 | +49.2 | 0.0 | 72.6 |
| HUNT KEPT | 0.1 | +0.5 | 0.0 | 6.4 | 0.4 | +5.1 | 16.2 | 0.0 |
| HUNT RESULT | 0.0 | +0.0 | 0.0 | 0.0 | 0.4 | +75.1 | 15.0 | 2.8 |
| HUNT THE GUNS | 0.0 | +6.5 | 0.0 | 0.0 | 0.5 | +158.9 | 24.9 | 1.8 |
| IDLE COST | 14.9 | -246.0 | 0.0 | 123.1 | 19.5 | -305.2 | 0.0 | 239.2 |
| INVITES THE FIGHT | 1.3 | +10.3 | 82.0 | 16.0 | 0.6 | +4.6 | 36.3 | 9.9 |
| JOINT CHARGE PLAN | 0.0 | +1.3 | 0.0 | 0.0 | 0.2 | +11.3 | 8.2 | 7.7 |
| JOINT KNOWS CHALLENGE | 0.1 | -2.4 | 0.0 | 6.8 | 0.2 | -3.3 | 24.5 | 23.2 |
| KEEP FALLS | 0.0 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | - | - | - | - | 0.1 | +0.0 | 5.4 | 0.0 |
| KEEPS ITS TARGET | 1.5 | +45.0 | 108.9 | 61.4 | 2.2 | +66.7 | 191.5 | 29.3 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | - | - | - | - | 2.1 | +84.1 | 185.7 | 22.1 |
| KILLS COUNT NEXT TURN | 4.9 | +204.3 | 142.9 | 92.0 | 7.2 | +255.2 | 376.1 | 198.1 |
| LONE CHARACTER SAFE SPOT | 0.2 | +6.3 | 4.1 | 0.0 | 0.2 | +14.5 | 7.6 | 21.8 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 28.4 | 10.7 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +23.5 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | -0.4 | 16.7 | 11.8 | 0.5 | -1.3 | 18.7 | 7.9 |
| LOST CHARGE | 2.8 | -55.3 | 70.2 | 146.8 | 2.1 | -38.6 | 67.5 | 97.5 |
| LURE BY WHAT IT DRAWS | 0.2 | -19.4 | 0.0 | 4.7 | 0.3 | -34.5 | 0.0 | 8.2 |
| MAKE SURE TOGETHER | 0.2 | +14.2 | 5.8 | 15.8 | 0.8 | +61.2 | 51.4 | 12.2 |
| MANOEUVRE | 0.2 | +12.2 | 0.0 | 1.0 | 0.2 | +3.0 | 0.0 | 2.1 |
| MARCH AT ESCAPER | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| MARCH CHECK | 0.4 | +6.9 | 0.0 | 2.2 | 0.4 | +17.9 | 0.0 | 0.0 |
| MARCH ODDS | 0.3 | +22.3 | 3.2 | 0.0 | 0.1 | +6.9 | 0.0 | 15.6 |
| MARCH OVER CASTS | 0.4 | +40.5 | 0.0 | 24.2 | 0.1 | +8.3 | 0.0 | 12.1 |
| MAX FOR POSITIONING | 6.2 | +87.8 | 0.0 | 207.9 | 6.8 | +101.0 | 0.0 | 185.1 |
| MISSILES IN THE MOVE | 3.9 | +104.5 | 0.0 | 165.4 | 3.3 | +78.5 | 0.0 | 99.1 |
| MISSILES NEXT TURN | 4.5 | +74.8 | 0.0 | 187.2 | 3.5 | +46.8 | 0.0 | 127.6 |
| MODEL FACING | 0.3 | +47.7 | 0.0 | 1.7 | 0.2 | +90.5 | 0.0 | 6.7 |
| MONSTER WIZARD ROAMS | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 19.9 | 0.0 |
| MOVE AND CAST | 0.3 | +24.0 | 0.0 | 39.1 | 0.4 | +21.2 | 0.0 | 16.2 |
| MOVE SPELL IN RANGE | 0.2 | +9.1 | 0.0 | 32.2 | 0.0 | +0.6 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.3 | -9.9 | 0.0 | 16.1 | 0.3 | -8.3 | 3.5 | 0.0 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 2.8 | +146.4 | 93.0 | 97.2 | 5.2 | +335.1 | 300.7 | 142.5 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.0 | +0.6 | 2.8 | 0.0 | 0.1 | +15.8 | 8.7 | 0.0 |
| NO RALLY LEFT | - | - | - | - | 0.0 | +1.5 | 0.0 | 0.0 |
| NOT NEEDED | 0.2 | -2.0 | 16.7 | 7.9 | 0.4 | -25.6 | 56.0 | 15.5 |
| NOT TURNED | 5.8 | +94.6 | 0.0 | 135.3 | 6.2 | +81.2 | 0.0 | 134.2 |
| NOT WORTH A CAST | 0.5 | -0.3 | 0.0 | 0.0 | 0.8 | -0.6 | 0.0 | 0.0 |
| OFF BEST | 16.2 | -670.9 | 2.8 | 227.9 | 17.7 | -890.6 | 13.3 | 277.5 |
| ONE FIGHT FORMULA | 9.5 | -148.7 | 78.7 | 247.3 | 8.8 | -179.8 | 34.8 | 285.5 |
| ONE OBJECTIVE FORMULA | 1.8 | -114.7 | 0.0 | 25.5 | 2.2 | -147.5 | 0.0 | 23.5 |
| OPENS A LANE | 0.3 | +1.7 | 35.4 | 3.5 | 0.1 | +1.1 | 2.7 | 0.0 |
| OPENS UP | 0.1 | +6.2 | 6.2 | 0.0 | 0.1 | +4.8 | 5.4 | 0.0 |
| OVERRUN ON | 0.2 | +4.7 | 33.4 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.2 | +1.3 | 25.3 | 0.0 | 0.4 | +14.9 | 20.6 | 0.0 |
| PATHS CROSS | 2.1 | +118.8 | 0.0 | 12.6 | 2.8 | +162.2 | 0.0 | 86.3 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +2.0 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.2 | -2.5 | 0.0 | 27.7 | - | - | - | - |
| PLAN RESULT | 37.0 | +1606.7 | 1458.4 | 1040.7 | 41.4 | +1389.9 | 1701.2 | 873.3 |
| PURSUES BIG PREY | 0.0 | -0.7 | 0.0 | 0.0 | 0.2 | -5.8 | 0.0 | 13.9 |
| PURSUES ON | - | - | - | - | 0.0 | +0.5 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +1.7 | 0.0 | 3.4 | 0.0 | +2.4 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.7 | +13.2 | 0.0 | 4.0 | 1.3 | +32.6 | 0.0 | 51.4 |
| RANDOM MOVER NO PROMISE | 0.1 | -2.7 | 4.0 | 0.0 | 0.0 | -0.3 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.4 | -13.1 | 0.0 | 17.7 | 1.1 | -32.2 | 0.0 | 31.9 |
| REDIRECT COUNTER | 2.3 | +131.0 | 0.0 | 44.7 | 3.8 | +267.0 | 0.0 | 58.6 |
| REDIRECT WEIGHED | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +2.1 | 7.6 | 0.9 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 12.1 |
| RESERVE FALL BACK | 0.5 | +8.9 | 0.0 | 4.4 | 1.1 | +33.4 | 0.0 | 31.2 |
| RESTRAINS TO SHOOT | 0.1 | +5.8 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.9 | +72.6 | 137.5 | 90.6 | 3.3 | +75.8 | 313.5 | 49.5 |
| RISK ONCE | 4.4 | +120.4 | 28.4 | 206.0 | 3.8 | +149.6 | 52.8 | 243.6 |
| SAFE SURE CHARGE | 0.0 | -2.3 | 0.0 | 0.0 | - | - | - | - |
| SAFER THAN THE JOB | 0.9 | +32.0 | 0.0 | 17.4 | 0.5 | +36.8 | 0.0 | 16.0 |
| SCOUT SPOT | 0.3 | +0.9 | 0.0 | 0.0 | 0.5 | +2.4 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.3 | -12.3 | 0.0 | 1.2 | 0.4 | -32.2 | 0.0 | 5.9 |
| SEARCH SPOT | 2.1 | +112.3 | 0.0 | 35.1 | 2.5 | +88.9 | 0.0 | 76.8 |
| SECOND HUNTER | - | - | - | - | 0.1 | -0.7 | 7.6 | 1.8 |
| SELF MOVE SPELL | 0.2 | +7.0 | 0.0 | 0.0 | - | - | - | - |
| SET UP TOGETHER | 0.4 | +15.8 | 5.8 | 36.1 | 2.1 | +144.7 | 82.7 | 67.6 |
| SET-UP ANY TARGET | 0.1 | +24.7 | 0.0 | 0.0 | 0.1 | +5.8 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.0 | +5.6 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.1 | -0.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.2 | +54.7 | 61.9 | 48.5 | 1.1 | +43.2 | 52.8 | 11.5 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.7 | +0.0 | 151.4 | 19.4 | 0.1 | +0.0 | 5.2 | 0.0 |
| SHOTS IN THE MOVE | 13.9 | +633.1 | 0.0 | 252.5 | 11.3 | +374.5 | 0.0 | 151.7 |
| SPELL SETS UP CHARGE | 0.2 | +31.4 | 0.0 | 0.0 | 0.1 | +13.2 | 0.0 | 0.0 |
| SPELL WORTH | 0.8 | +16.8 | 63.8 | 58.3 | 1.5 | +27.7 | 43.8 | 43.8 |
| SPELLS IN THE FIGHT | 0.4 | -1.1 | 38.4 | 15.2 | 0.6 | -12.7 | 97.7 | 20.6 |
| STABLE ROLE | 11.1 | +0.0 | 375.9 | 145.5 | 12.3 | +0.0 | 368.9 | 164.6 |
| STAND AND SHOOT | 0.1 | -0.9 | 12.2 | 1.4 | - | - | - | - |
| STANDS TO CAST | 0.1 | +1.9 | 0.0 | 11.1 | - | - | - | - |
| STOPS | 0.0 | +0.5 | 0.0 | 3.2 | 0.3 | +9.6 | 27.9 | 1.8 |
| STOPS SHORT OF THE FLANK | 0.4 | +19.4 | 0.0 | 34.6 | 0.2 | +7.4 | 0.0 | 12.2 |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 9.9 |
| SUPPORT NARROWED | 7.0 | -70.5 | 289.3 | 126.5 | 9.0 | -91.1 | 544.7 | 114.8 |
| SUPPORTS | 4.8 | +78.3 | 157.3 | 58.6 | 6.3 | +94.4 | 264.0 | 82.6 |
| SURE CHARGE BEATS ADVANCE | 0.0 | -3.0 | 0.0 | 12.1 | 0.2 | -5.2 | 15.4 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +1.5 | 0.0 | 24.1 | 0.8 | -0.0 | 8.2 | 7.7 |
| THROUGH LINE OF FIRE | 0.2 | +4.8 | 0.0 | 0.0 | 0.3 | +10.3 | 0.0 | 18.3 |
| TURN WORTH | 0.2 | -22.3 | 24.8 | 4.8 | 0.2 | -11.5 | 10.9 | 0.0 |
| TWO OR MORE ARRIVE | 0.1 | +0.4 | 5.8 | 0.0 | 0.3 | +1.3 | 16.8 | 4.2 |
| WAIT AFTER COSTS | 5.9 | -304.5 | 226.8 | 123.2 | 8.3 | -375.1 | 418.6 | 201.6 |
| WALKS TO THE FIGHT | 1.5 | +14.9 | 53.5 | 8.5 | 1.4 | +7.3 | 23.8 | 17.0 |
| WAR ENGINE CHARGES | 0.1 | +10.4 | 0.0 | 0.0 | 0.0 | +5.2 | 0.0 | 5.1 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 43.3 | 6.9 | 0.4 | +0.0 | 42.7 | 14.3 |
| WEARS DOWN | 1.0 | +39.5 | 74.1 | 37.8 | 1.5 | +41.1 | 178.4 | 47.2 |
| WHO HITS BACK | 0.1 | +11.1 | 0.0 | 4.0 | 0.2 | +13.5 | 0.0 | 18.5 |
| WHOLE FIGHT | 0.2 | +7.5 | 27.5 | 13.1 | 0.7 | +38.9 | 97.9 | 0.0 |
| WHOLE FIGHT GAIN | 0.3 | +26.5 | 33.1 | 18.9 | 0.7 | +52.6 | 62.8 | 7.7 |
| WIDER SPREAD | 1.9 | -6.4 | 133.9 | 80.9 | 3.4 | -6.8 | 358.8 | 28.9 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |

### Rule changes: co-mine-a57fba0-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1220 | 1220 | 1220 | 33.89 | -56214 | -46.1 |
| SUPPORTS | 400 | 400 | 178 | 4.94 | +2336 | +13.1 |
| PATHS CROSS | 174 | 174 | 174 | 4.83 | +10116 | +58.1 |
| SEARCH SPOT | 165 | 165 | 160 | 4.44 | +7242 | +45.3 |
| KILLS COUNT NEXT TURN | 437 | 437 | 152 | 4.22 | +5078 | +33.4 |
| MOVE TO CHARGE | 288 | 288 | 151 | 4.19 | +5752 | +38.1 |
| FACES THE THREAT | 115 | 115 | 115 | 3.19 | +8534 | +74.2 |
| SHOTS IN THE MOVE | 907 | 611 | 94 | 2.61 | +3596 | +38.3 |
| BEST FIRST | 92 | 92 | 92 | 2.56 | +3898 | +42.4 |
| FOLLOW UP WEIGHED | 92 | 92 | 92 | 2.56 | +12309 | +133.8 |
| WAIT AFTER COSTS | 513 | 513 | 89 | 2.47 | +2055 | +23.1 |
| FALLBACK BY WORTH | 353 | 353 | 81 | 2.25 | +3348 | +41.3 |
| COVER ONCE | 545 | 315 | 78 | 2.17 | +1361 | +17.4 |
| CANNON SIGHT KEPT | 70 | 70 | 70 | 1.94 | +0 | +0.0 |
| ADVANCE WORTH | 365 | 365 | 61 | 1.69 | +919 | +15.1 |
| RESERVE FALL BACK | 58 | 58 | 58 | 1.61 | +1521 | +26.2 |
| RISK ONCE | 293 | 202 | 56 | 1.56 | +2252 | +40.2 |
| ARTILLERY RE-ROLL WEIGHED | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| CHAFF IN THE MOVE | 97 | 91 | 54 | 1.50 | +1690 | +31.3 |
| SAFER THAN THE JOB | 50 | 50 | 50 | 1.39 | +2475 | +49.5 |
| MISSILES IN THE MOVE | 257 | 160 | 49 | 1.36 | +1243 | +25.4 |
| CANNON PLANNED TARGET | 253 | 253 | 46 | 1.28 | -469 | -10.2 |
| IDLE COST | 1240 | 717 | 44 | 1.22 | +500 | +11.4 |
| ONE FIGHT FORMULA | 656 | 383 | 44 | 1.22 | +189 | +4.3 |
| RISK BY ARC | 187 | 183 | 44 | 1.22 | +1017 | +23.1 |
| CHARGE NOW WEIGHED | 43 | 43 | 43 | 1.19 | +2027 | +47.1 |
| ADVANCE LANE KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| SET UP TOGETHER | 90 | 74 | 41 | 1.14 | +2054 | +50.1 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| WALKS TO THE FIGHT | 104 | 104 | 40 | 1.11 | +246 | +6.1 |
| RANDOM MOVE BY FIGURES | 72 | 72 | 39 | 1.08 | +1650 | +42.3 |
| REDIRECT COUNTER | 218 | 98 | 38 | 1.06 | +2787 | +73.3 |
| HONEST WORTH | 618 | 617 | 37 | 1.03 | +324 | +8.7 |
| CHARGE NOW FIRST | 177 | 177 | 36 | 1.00 | -1783 | -49.5 |
| COMBAT PIVOT | 36 | 36 | 36 | 1.00 | +0 | +0.0 |
| BLOCKED WHEEL | 34 | 34 | 34 | 0.94 | +867 | +25.5 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2266 | +68.7 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| BEST FACING | 31 | 31 | 31 | 0.86 | +1252 | +40.4 |
| MARCH CHECK | 32 | 32 | 31 | 0.86 | +1637 | +52.8 |
| MAX FOR POSITIONING | 467 | 274 | 28 | 0.78 | +61 | +2.2 |
| MOVE AND CAST | 28 | 28 | 28 | 0.78 | +1625 | +58.0 |
| SHOT REPLANNED | 28 | 28 | 28 | 0.78 | +0 | +0.0 |
| BEST OVERALL | 27 | 27 | 27 | 0.75 | +1395 | +51.7 |
| INVITES THE FIGHT | 69 | 69 | 27 | 0.75 | +194 | +7.2 |
| SHOOTS FROM THE BEST SPOT | 83 | 83 | 26 | 0.72 | +1032 | +39.7 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +50 | +2.0 |
| WHOLE FIGHT GAIN | 36 | 34 | 25 | 0.69 | +914 | +36.5 |
| STOPS SHORT OF THE FLANK | 24 | 24 | 24 | 0.67 | +965 | +40.2 |
| CASTING BLOCK | 32 | 32 | 20 | 0.56 | +685 | +34.3 |
| KILLS COUNT | 74 | 73 | 20 | 0.56 | +636 | +31.8 |
| CHAFF PASSED | 19 | 19 | 19 | 0.53 | -23 | -1.2 |
| MODEL FACING | 19 | 19 | 19 | 0.53 | +4974 | +261.8 |
| BEST PREY | 59 | 59 | 18 | 0.50 | +582 | +32.3 |
| CASTER AWAY FROM SCREEN | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 16 | 16 | 16 | 0.44 | +542 | +33.9 |
| CAST JOB | 48 | 48 | 15 | 0.42 | +262 | +17.5 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| MANOEUVRE | 18 | 18 | 15 | 0.42 | +547 | +36.5 |
| WAR ENGINE JOBS | 38 | 38 | 15 | 0.42 | -746 | -49.7 |
| MARCH ODDS | 14 | 14 | 14 | 0.39 | +109 | +7.8 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| REDIRECT WEIGHED | 13 | 13 | 13 | 0.36 | +657 | +50.6 |
| REFUSING RETIRES | 27 | 27 | 13 | 0.36 | -2 | -0.1 |
| STUCK PIVOT | 13 | 13 | 13 | 0.36 | +0 | +0.0 |
| WEARS DOWN | 89 | 88 | 13 | 0.36 | +418 | +32.1 |
| KEEPS ITS TARGET | 134 | 134 | 12 | 0.33 | +262 | +21.8 |
| HUNT IN PAIRS | 40 | 25 | 11 | 0.31 | +585 | +53.2 |
| MAKE SURE TOGETHER | 36 | 24 | 10 | 0.28 | +560 | +56.0 |
| WHO HITS BACK | 9 | 9 | 9 | 0.25 | +718 | +79.8 |
| LOST CHARGE | 177 | 177 | 8 | 0.22 | +139 | +17.4 |
| MISSILES NEXT TURN | 289 | 169 | 8 | 0.22 | +4 | +0.5 |
| BIG CHARACTER SAFETY | 7 | 7 | 7 | 0.19 | +28 | +3.9 |
| FRIENDS SHOTS CHECKED | 7 | 7 | 7 | 0.19 | +667 | +95.3 |
| PURSUES BIG PREY | 7 | 7 | 7 | 0.19 | -235 | -33.6 |
| SUPPORT NARROWED | 574 | 574 | 7 | 0.19 | -238 | -33.9 |
| SURE CHARGE BEATS ADVANCE | 7 | 7 | 7 | 0.19 | -295 | -42.1 |
| BLOCKED CHARGE SKIPPED | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| BREAK OUTCOMES | 87 | 85 | 6 | 0.17 | +95 | +15.8 |
| PIVOT GUARDS FLANK | 6 | 6 | 6 | 0.17 | -91 | -15.1 |
| LONE WIZARD HOLDS BACK | 15 | 15 | 5 | 0.14 | -121 | -24.2 |
| ONE OBJECTIVE FORMULA | 144 | 67 | 5 | 0.14 | +73 | +14.6 |
| WHOLE FIGHT | 33 | 33 | 5 | 0.14 | +676 | +135.3 |
| WIDER SPREAD | 190 | 184 | 5 | 0.14 | +6 | +1.2 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| NEEDED THERE | 5 | 5 | 4 | 0.11 | +0 | +0.0 |
| OPENS UP | 8 | 8 | 4 | 0.11 | +130 | +32.6 |
| SURE REACH TOGETHER | 39 | 30 | 4 | 0.11 | +3 | +0.7 |
| BOMBING RUN | 3 | 3 | 3 | 0.08 | +75 | +25.0 |
| DEFENSIVE ARMY | 9 | 9 | 3 | 0.08 | -107 | -35.6 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.08 | +188 | +62.7 |
| LONG SHOT | 38 | 38 | 3 | 0.08 | +45 | +15.1 |
| OVERRUNS AWAY | 22 | 22 | 3 | 0.08 | +65 | +21.7 |
| RESTRAINS TO SHOOT | 3 | 3 | 3 | 0.08 | +210 | +70.1 |
| STANDS TO CAST | 3 | 3 | 3 | 0.08 | -45 | -14.9 |
| BLOWS WHERE AIMED | 17 | 16 | 2 | 0.06 | +81 | +40.3 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.06 | +0 | +0.2 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| EDGE GIVE GROUND | 20 | 19 | 2 | 0.06 | +38 | +18.9 |
| FLEES FROM CHARGE | 14 | 14 | 2 | 0.06 | +93 | +46.3 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +100 | +49.8 |
| JOINT CHARGE PLAN | 8 | 8 | 2 | 0.06 | +114 | +57.2 |
| MOVE SPELL IN RANGE | 8 | 6 | 2 | 0.06 | +22 | +10.8 |
| RAIDS THE BAGGAGE NEXT TURN | 2 | 2 | 2 | 0.06 | +97 | +48.6 |
| BACKUP TARGETS | 51 | 31 | 1 | 0.03 | +1 | +0.7 |
| BEST PRIZE | 1 | 1 | 1 | 0.03 | -1 | -0.9 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +3 | +3.0 |
| HUNT ADVANCE | 19 | 19 | 1 | 0.03 | +9 | +9.3 |
| KEEP FALLS | 1 | 1 | 1 | 0.03 | +44 | +44.3 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +13 | +12.6 |
| OPENS A LANE | 13 | 7 | 1 | 0.03 | +11 | +11.3 |
| OVERRUN ON | 8 | 8 | 1 | 0.03 | +4 | +3.9 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +73 | +73.3 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +18 | +18.5 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -82 | -82.4 |
| SPELLS IN THE FIGHT | 37 | 36 | 1 | 0.03 | +1 | +0.6 |
| TWO OR MORE ARRIVE | 15 | 15 | 1 | 0.03 | +10 | +10.5 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.03 | -55 | -54.7 |
| ARRIVAL HUNT | 4 | 4 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 38 | 38 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 10 | 10 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 22 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARGER SLAIN LOST | 38 | 35 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 1 | 1 | 0 | 0.00 | - | - |
| CHEAP HELPER | 11 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 26 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 403 | not checked | - | - | - | - |
| GIVES UP | 4 | 3 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 4 | 4 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 4 | not checked | - | - | - | - |
| HELPER UNSEEN | 26 | 24 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 36 | 36 | 0 | 0.00 | - | - |
| HUNT DROPPED | 8 | trace | - | - | - | - |
| HUNT KEPT | 15 | trace | - | - | - | - |
| HUNT RESULT | 17 | trace | - | - | - | - |
| HUNT THE GUNS | 19 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 9 | 8 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 16 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 20 | 20 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 18 | 18 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 5 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 21 | trace | - | - | - | - |
| MOVE SPELL SPOT | 8 | not checked | - | - | - | - |
| NOT NEEDED | 21 | 21 | 0 | 0.00 | - | - |
| NOT TURNED | 429 | 429 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 45 | not checked | - | - | - | - |
| PLAN RESULT | 2823 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 4 | 4 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 54 | 54 | 0 | 0.00 | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 25 | 25 | 0 | 0.00 | - | - |
| SECOND HUNTER | 5 | 5 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 7 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 7 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 9 | not checked | - | - | - | - |
| SPELL WORTH | 84 | not checked | - | - | - | - |
| STABLE ROLE | 842 | 842 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STOPS | 11 | 10 | 0 | 0.00 | - | - |
| TURN WORTH | 17 | 17 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 5 | 5 | 0 | 0.00 | - | - |

### Off best figure: co-mine-a57fba0-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.81 | 15.75 | 47.4 |
| FALLBACK | gate | 0.58 | 0.86 | 40.9 |
| CHARGE NOW FIRST | rule | 0.53 | 0.44 | 50.9 |
| TURN GATE | gate | 0.42 | 0.56 | 29.1 |
| WAR ENGINE JOBS | rule | 0.28 | 0.14 | 49.7 |
| AFTERMATH BAND | gate | 0.14 | 0.22 | 2.4 |
| CANNON PLANNED TARGET | rule | 0.22 | 0.03 | 64.7 |
| CHAFF PASSED | rule | 0.06 | 0.14 | 3.3 |
| PURSUES BIG PREY | rule | 0.03 | 0.17 | 33.6 |
| SUPPORT REQUEST | gate | 0.06 | 0.14 | 110.8 |
| SURE CHARGE BEATS ADVANCE | rule | 0.03 | 0.17 | 42.1 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.11 | 30.6 |
| FIGHT ORDER BAND | gate | 0.11 | 0.06 | 1.7 |
| PATHS CROSS | rule | 0.08 | 0.08 | 38.5 |
| PIVOT GUARDS FLANK | rule | 0.17 | - | 15.1 |
| SUPPORT NARROWED | rule | 0.08 | 0.08 | 39.6 |
| LONE CHARACTER SAFE SPOT | gate | 0.06 | 0.06 | 25.6 |
| DEFENSIVE ARMY | rule | 0.03 | 0.06 | 35.6 |
| BLOCKED WHEEL | rule | - | 0.06 | 19.4 |
| LONE WIZARD HOLDS BACK | rule | - | 0.06 | 60.5 |
| RULE SWITCHED OFF | gate | - | 0.06 | 10.6 |
| THROUGH LINE OF FIRE | rule | 0.03 | 0.03 | 18.4 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.03 | 30.3 |
| BEST PRIZE | rule | 0.03 | - | 0.9 |
| BIG CHARACTER SAFETY | rule | 0.03 | - | 0.7 |
| FOLLOW UP WEIGHED | rule | - | 0.03 | 3.7 |
| MARCH ODDS | rule | 0.03 | - | 8.6 |
| MOVE AND CAST | rule | - | 0.03 | 4.6 |
| REFUSING RETIRES | rule | 0.03 | - | 0.9 |
| SAFE SURE CHARGE | rule | 0.03 | - | 82.4 |
| STANDS TO CAST | rule | 0.03 | - | 44.8 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | - | 0.7 |
| WOUNDED STAYS OUT | rule | - | 0.03 | 54.7 |

### Plans: co-mine-a57fba0-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 10.0 | 19% | 254 | 345 | 136% |
| Mine | charge | 2.8 | 63% | 206 | 240 | 117% |
| Mine | close in | 4.3 | 24% | 217 | 150 | 69% |
| Mine | hold | 4.9 | 28% | 314 | 0 | 0% |
| Mine | join | 0.6 | 95% | 20 | 0 | 0% |
| Mine | shoot | 8.8 | 68% | 312 | 871 | 279% |
| Mine | support | 5.7 | 90% | 57 | 0 | 0% |
| Opponent | advance | 11.3 | 16% | 136 | 277 | 204% |
| Opponent | charge | 4.4 | 62% | 397 | 477 | 120% |
| Opponent | close in | 7.1 | 26% | 393 | 230 | 59% |
| Opponent | hold | 4.1 | 41% | 292 | 0 | 0% |
| Opponent | join | 0.8 | 93% | 33 | 0 | 0% |
| Opponent | shoot | 6.0 | 52% | 220 | 406 | 185% |
| Opponent | support | 7.8 | 90% | 77 | 0 | 0% |

### Packages: hunt the guns, co-mine-a57fba0-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 100% | 0% | 0% | - | 233 | 0 | 0% | 41 |
| Opponent | 0.5 | 18 | 2 | 38% | 50% | 0% | 2.2 | 346 | 169 | 50% | 86 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 16 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 265 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 40 |
| Empire of Man | 0.1 | 1 | 0 | 0% | 100% | 0% | 2.0 | 142 | 110 | 100% | 24 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 143 |
| High Elf Realms | 0.2 | 1 | 0 | 100% | 0% | 0% | - | 233 | 0 | 0% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 40 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.8 | 3 | 0 | 100% | 100% | 0% | 2.7 | 555 | 425 | 100% | 160 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 48 |
| Tomb Kings of Khemri | 1.6 | 8 | 2 | 33% | 50% | 0% | 2.0 | 201 | 120 | 50% | 0 |
| Vampire Counts | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 374 | 0 | 0% | 0 |
| Warriors of Chaos | 0.2 | 2 | 0 | 0% | 0% | 0% | - | 443 | 0 | 0% | 55 |
| Wood Elf Realms | 0.4 | 3 | 0 | 33% | 33% | 0% | 2.0 | 423 | 200 | 33% | 117 |

### Battle groups: co-mine-a57fba0-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.3 | 25% | 62% | 10% | 0% | 0% | 0% | 16% | 84% | 0% |
| Opponent | REDIRECT COUNTER | 3.8 | 19% | 69% | 15% | 0% | 18% | 0% | 14% | 64% | 5% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: co-mine-a57fba0-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 0 (5) | 0 | 0 | 32 | 20% | 3.2 | 0 (1) | 0 (4) | - | 0 (1) | 0 (4) |
| Mine | Chaff | 34 | 84 (34) | 37 | 47 | 57 | 38% | 2.8 | 69 (19) | 202 (7) | 16 (8) | 115 (23) | 14 (11) |
| Mine | Character | 123 | 40 (123) | 40 | 0 | 36 | 21% | 2.5 | 52 (42) | 36 (51) | 8 (17) | 55 (52) | 25 (58) |
| Mine | Clean-up | 21 | 44 (21) | 3 | 41 | 43 | 38% | 3.5 | 9 (5) | 54 (13) | 95 (3) | 71 (13) | 16 (8) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 0 | 0% | 4.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 48 | 35 (48) | 17 | 18 | 42 | 25% | 2.9 | 40 (23) | 38 (16) | 7 (9) | 43 (29) | 24 (19) |
| Mine | Fragile | 5 | 125 (5) | 125 | 0 | 40 | 0% | 1.4 | - | 121 (3) | 131 (2) | 125 (5) | - |
| Mine | Hammer | 57 | 39 (57) | 30 | 9 | 36 | 16% | 2.7 | 10 (18) | 57 (29) | 39 (10) | 47 (38) | 26 (19) |
| Mine | Holder | 28 | 50 (28) | 0 | 50 | 38 | 43% | 2.7 | 28 (9) | 91 (11) | 15 (7) | 84 (16) | 0 (11) |
| Mine | Shooter | 41 | 83 (41) | 47 | 36 | 47 | 2% | 1.4 | 121 (5) | 83 (30) | 62 (6) | 112 (25) | 40 (16) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 50% | 4.0 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | War machine | 59 | 43 (59) | 43 | 0 | 48 | 2% | 1.2 | 44 (10) | 45 (37) | 34 (12) | 40 (10) | 43 (49) |
| Mine | Wizard | 22 | 22 (22) | 22 | 0 | 57 | 9% | 2.6 | 0 (5) | 64 (8) | 18 (5) | 22 (6) | 31 (12) |
| Opponent | Blocker | 2 | 85 (2) | 85 | 0 | 38 | 0% | 5.0 | 137 (1) | 0 (1) | - | 137 (1) | 0 (1) |
| Opponent | Chaff | 76 | 56 (76) | 25 | 32 | 51 | 42% | 2.5 | 74 (32) | 37 (19) | 52 (25) | 67 (54) | 31 (22) |
| Opponent | Character | 97 | 55 (97) | 55 | 0 | 34 | 20% | 2.5 | 63 (42) | 59 (38) | 21 (5) | 54 (58) | 68 (27) |
| Opponent | Clean-up | 19 | 32 (19) | 22 | 10 | 31 | 42% | 2.9 | 17 (9) | 58 (10) | - | 35 (14) | 25 (5) |
| Opponent | Early | 2 | 58 (2) | 58 | 0 | 50 | 0% | 4.5 | - | 58 (2) | - | 116 (1) | 0 (1) |
| Opponent | Fast Hammer | 48 | 43 (48) | 32 | 11 | 30 | 15% | 2.9 | 41 (22) | 32 (16) | 68 (10) | 34 (28) | 59 (20) |
| Opponent | Fragile | 5 | 193 (5) | 193 | 0 | 61 | 20% | 4.5 | - | 250 (4) | 0 (1) | 229 (4) | 0 (1) |
| Opponent | Hammer | 70 | 28 (70) | 24 | 4 | 47 | 21% | 3.1 | 23 (17) | 26 (42) | 51 (11) | 31 (43) | 24 (27) |
| Opponent | Holder | 35 | 108 (35) | 11 | 97 | 18 | 37% | 2.8 | 76 (8) | 126 (21) | 98 (5) | 127 (24) | 68 (10) |
| Opponent | Shooter | 33 | 91 (33) | 23 | 67 | 32 | 0% | 1.9 | 71 (8) | 113 (19) | 38 (6) | 131 (22) | 28 (11) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 25 | 67% | 5.0 | 0 (1) | 0 (1) | 0 (1) | 0 (1) | 0 (2) |
| Opponent | War machine | 24 | 53 (24) | 53 | 0 | 24 | 8% | 1.5 | 0 (6) | 79 (14) | 33 (4) | 38 (3) | 55 (21) |
| Opponent | Wizard | 26 | 3 (26) | 3 | 0 | 39 | 8% | 1.8 | 0 (10) | 0 (7) | 8 (7) | 7 (8) | 0 (16) |

### Charged fights: co-mine-a57fba0-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 214 | 62 | 1.0 | 1.2 | 62 | 26 | +36 | 0 of 4 | 4 of 4 | +120 | +8 |
| Mine | Chaos Dwarfs | 4 | 300 | 264 | 3.0 | 1.0 | 88 | 42 | +47 | 6 of 12 | 7 of 12 | - | +47 |
| Mine | Dwarfen Mountain Holds | 4 | 479 | 34 | 2.5 | 1.1 | 14 | 0 | +14 | 0 of 10 | 8 of 9 | +137 | +0 |
| Mine | Empire of Man | 5 | 549 | 111 | 1.4 | 1.1 | 80 | 0 | +80 | 3 of 7 | 5 of 7 | +275 | +47 |
| Mine | Grand Cathay | 4 | 332 | 150 | 2.8 | 1.1 | 55 | 21 | +34 | 3 of 11 | 8 of 11 | +0 | +37 |
| Mine | High Elf Realms | 4 | 74 | 624 | 3.0 | 1.1 | 208 | 22 | +187 | 7 of 12 | 10 of 12 | -18 | +205 |
| Mine | Kingdom of Bretonnia | 1 | 465 | 170 | 6.0 | 1.0 | 28 | 122 | -94 | 3 of 6 | 4 of 6 | - | -94 |
| Mine | Lizardmen | 1 | 45 | 1162 | 5.0 | 1.2 | 232 | 0 | +232 | 1 of 5 | 4 of 5 | +120 | +260 |
| Mine | Ogre Kingdoms | 1 | 261 | 45 | 4.0 | 1.2 | 11 | 31 | -20 | 1 of 4 | 2 of 4 | -34 | -15 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 349 | 5.0 | 1.2 | 70 | 11 | +59 | 1 of 5 | 4 of 5 | +45 | +62 |
| Mine | Skaven | 2 | 300 | 85 | 1.0 | 1.0 | 85 | 124 | -39 | 0 of 2 | 1 of 2 | - | -39 |
| Mine | Tomb Kings of Khemri | 1 | 0 | 909 | 6.0 | 1.2 | 152 | 20 | +131 | 1 of 6 | 6 of 6 | +125 | +132 |
| Mine | Vampire Counts | 3 | 0 | 220 | 3.7 | 1.1 | 60 | 0 | +60 | 2 of 11 | 8 of 11 | +114 | +54 |
| Mine | Warriors of Chaos | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 0 of 2 | 2 of 2 | - | +0 |
| **Mine** | all armies | 36 | 270 | 238 | 2.7 | 1.1 | 88 | 25 | +64 | 28 of 97 | 73 of 96 | +88 | +61 |
| Opponent | Dwarfen Mountain Holds | 2 | 100 | 116 | 3.5 | 1.7 | 33 | 0 | +33 | 1 of 7 | 4 of 7 | +38 | +27 |
| Opponent | Empire of Man | 2 | 530 | 88 | 1.0 | 1.0 | 88 | 0 | +88 | 0 of 2 | 2 of 2 | - | +88 |
| Opponent | Grand Cathay | 2 | 613 | 758 | 3.0 | 1.2 | 253 | 0 | +253 | 4 of 6 | 6 of 6 | +562 | +191 |
| Opponent | Kingdom of Bretonnia | 1 | 120 | 366 | 3.0 | 1.0 | 122 | 0 | +122 | 1 of 3 | 3 of 3 | - | +122 |
| Opponent | Ogre Kingdoms | 3 | 208 | 186 | 3.3 | 1.0 | 56 | 35 | +20 | 4 of 10 | 3 of 10 | - | +20 |
| Opponent | Skaven | 1 | 706 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 172 | 584 | 4.2 | 1.1 | 138 | 51 | +87 | 8 of 17 | 12 of 17 | +110 | +85 |
| Opponent | Vampire Counts | 6 | 0 | 777 | 3.7 | 1.1 | 212 | 33 | +179 | 12 of 22 | 19 of 22 | +643 | +105 |
| Opponent | Warriors of Chaos | 8 | 0 | 456 | 3.6 | 1.1 | 126 | 17 | +109 | 14 of 29 | 21 of 29 | +114 | +108 |
| Opponent | Wood Elf Realms | 7 | 65 | 478 | 3.9 | 1.1 | 124 | 4 | +120 | 9 of 27 | 22 of 27 | +138 | +118 |
| **Opponent** | all armies | 36 | 141 | 468 | 3.4 | 1.1 | 136 | 20 | +115 | 54 of 124 | 92 of 124 | +226 | +99 |

### Effective charges: co-mine-a57fba0-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 0 | 0 | 0 | 3 (net +41) | 0 | 1 (net +20) | 0 | 0% (0 of 4) |
| Mine | Chaos Dwarfs | 12 | 1 (net +0) | 1 (net +217) | 2 (net -94) | 1 (net +268) | 0 | 6 (net +23) | 1 | 18% (2 of 11) |
| Mine | Dwarfen Mountain Holds | 10 | 2 (net +0) | 0 | 3 (net +0) | 1 (net +0) | 0 | 4 (net +34) | 0 | 30% (3 of 10) |
| Mine | Empire of Man | 7 | 1 (net +0) | 0 | 2 (net +72) | 0 | 0 | 3 (net +137) | 1 | 33% (2 of 6) |
| Mine | Grand Cathay | 11 | 3 (net -2) | 0 | 1 (net +0) | 0 | 1 (net +0) | 5 (net +50) | 1 | 10% (1 of 10) |
| Mine | High Elf Realms | 12 | 0 | 2 (net +246) | 2 (net +318) | 1 (net +301) | 3 (net +158) | 3 (net +78) | 1 | 18% (2 of 11) |
| Mine | Kingdom of Bretonnia | 6 | 1 (net -264) | 0 | 1 (net +0) | 2 (net -236) | 0 | 1 (net +170) | 1 | 20% (1 of 5) |
| Mine | Lizardmen | 5 | 1 (net +663) | 0 | 2 (net +185) | 1 (net +54) | 0 | 1 (net +75) | 0 | 40% (2 of 5) |
| Mine | Ogre Kingdoms | 4 | 0 | 0 | 1 (net +0) | 0 | 0 | 2 (net +6) | 1 | 33% (1 of 3) |
| Mine | Orc & Goblin Tribes | 5 | 0 | 0 | 1 (net +45) | 0 | 1 (net +54) | 1 (net +190) | 2 | 33% (1 of 3) |
| Mine | Skaven | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net -39) | 0 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 6 | 0 | 0 | 0 | 0 | 3 (net +117) | 3 (net +145) | 0 | 0% (0 of 6) |
| Mine | Vampire Counts | 11 | 1 (net +0) | 0 | 2 (net +0) | 1 (net +125) | 1 (net +114) | 5 (net +56) | 1 | 20% (2 of 10) |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 0 | 1 (net +0) | 0 | 1 (net +0) | 0 | 0% (0 of 2) |
| Opponent | Dwarfen Mountain Holds | 7 | 3 (net +0) | 0 | 2 (net +40) | 2 (net +75) | 0 | 0 | 0 | 29% (2 of 7) |
| Opponent | Empire of Man | 2 | 0 | 0 | 1 (net +85) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Opponent | Grand Cathay | 6 | 0 | 0 | 2 (net +626) | 3 (net +88) | 0 | 1 (net +0) | 0 | 33% (2 of 6) |
| Opponent | Kingdom of Bretonnia | 3 | 0 | 0 | 0 | 2 (net +153) | 1 (net +60) | 0 | 0 | 0% (0 of 3) |
| Opponent | Ogre Kingdoms | 10 | 2 (net +165) | 0 | 3 (net -76) | 0 | 0 | 0 | 5 | 60% (3 of 5) |
| Opponent | Skaven | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 17 | 5 (net -6) | 0 | 3 (net +197) | 3 (net +93) | 0 | 5 (net +95) | 1 | 19% (3 of 16) |
| Opponent | Vampire Counts | 22 | 1 (net +270) | 2 (net +355) | 4 (net +374) | 8 (net +87) | 2 (net +92) | 4 (net +91) | 1 | 19% (4 of 21) |
| Opponent | Warriors of Chaos | 29 | 4 (net +42) | 1 (net +378) | 3 (net -155) | 4 (net +142) | 2 (net +92) | 13 (net +157) | 2 | 11% (3 of 27) |
| Opponent | Wood Elf Realms | 27 | 4 (net +169) | 2 (net +141) | 3 (net +48) | 5 (net +85) | 0 | 12 (net +138) | 1 | 12% (3 of 26) |

### Charged fights, damage counted: co-mine-a57fba0-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 10 | 240 | 286 | +39 | 120 | 67 | +53 | +22.3 |
| Mine | 50-54% | 3 | 299 | 178 | +236 | 250 | 13 | +237 | +79.3 |
| Mine | Effective (55-75%) | 17 | 235 | 238 | +59 | 99 | 32 | +67 | +28.5 |
| Mine | 76-89% | 11 | 235 | 206 | +36 | 86 | 70 | +15 | +6.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 38 | 222 | 144 | +60 | 99 | 36 | +63 | +28.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 511 | 108 | +110 | 126 | 53 | +73 | +14.3 |
| Mine | No odds | 9 | 267 | 141 | +45 | 82 | 18 | +64 | +24.0 |
| Mine | All fights | 97 | 261 | 180 | +64 | 105 | 42 | +64 | +24.4 |
| Opponent | Long shot (under 50%) | 20 | 206 | 241 | +71 | 140 | 70 | +71 | +34.3 |
| Opponent | 50-54% | 5 | 379 | 216 | +274 | 274 | 44 | +230 | +60.6 |
| Opponent | Effective (55-75%) | 21 | 252 | 230 | +141 | 193 | 61 | +132 | +52.3 |
| Opponent | 76-89% | 27 | 307 | 199 | +100 | 159 | 47 | +112 | +36.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 35 | 242 | 186 | +129 | 146 | 18 | +128 | +52.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 451 | 124 | +86 | 95 | 0 | +95 | +21.1 |
| Opponent | No odds | 11 | 203 | 161 | +84 | 115 | 27 | +88 | +43.6 |
| Opponent | All fights | 124 | 262 | 202 | +115 | 156 | 41 | +115 | +43.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| co-mine-a57fba0-p2 | move | 403 | 92 (23%) | 68 (17%) | 44 (11%) | 267 (66%) |
| co-mine-a57fba0-p2 | objective | 411 | 62 (15%) | 52 (13%) | 49 (12%) | 300 (73%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

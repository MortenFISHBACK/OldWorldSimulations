# Doctrine scorecard: gf-h2h-opp-0533c46-p4

### Scorecard: gf-h2h-opp-0533c46-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0122 | 2 | 1 | Mine | - | - | 4 | 1 | 1 | 0 | 0 | 0 | 322 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 2 | 2 | 2 | 0 | 0 | 0 |
| L0208 | 4 | 1 | Mine | no | 0 | - | 1 | 3 | 0 | 0 | 0 | 0 |
| L0208 | 4 | 1 | Opponent | no | 0 | 5 | 1 | 1 | 0 | 0 | 0 | 679 |
| L0304 | 4 | 1 | Mine | no | 0 | 5 | 0 | 1 | 0 | 0 | 0 | 675 |
| L0304 | 4 | 1 | Opponent | no | 0 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0305 | 5 | 1 | Mine | no | - | 6 | 0 | 3 | 0 | 0 | 0 | 675 |
| L0305 | 5 | 1 | Opponent | no | - | - | 0 | 4 | 0 | 0 | 0 | 548 |
| L0306 | 6 | 1 | Mine | no | 6 | - | 0 | 0 | 0 | 0 | 0 | 675 |
| L0306 | 6 | 1 | Opponent | no | 2 | - | 0 | 1 | 1 | 0 | 0 | 801 |
| L0309 | 3 | 1 | Mine | yes | 3 | - | 1 | 2 | 0 | 0 | 0 | 590 |
| L0309 | 3 | 1 | Opponent | no | 2 | 4 | 1 | 2 | 0 | 0 | 0 | 420 |
| L0318 | 6 | 1 | Mine | no | 0 | 3 | 3 | 0 | 0 | 0 | 0 | 590 |
| L0318 | 6 | 1 | Opponent | no | 11 | - | 2 | 1 | 1 | 0 | 0 | 185 |
| L0329 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 760 |
| L0329 | 5 | 1 | Opponent | yes | - | 2 | 2 | 5 | 0 | 0 | 0 | 0 |
| L0335 | 5 | 1 | Mine | yes | - | - | 0 | 2 | 0 | 0 | 0 | 675 |
| L0335 | 5 | 1 | Opponent | no | - | 6 | 1 | 5 | 0 | 0 | 0 | 140 |
| L0415 | 1 | 1 | Mine | no | 2 | 4 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0415 | 1 | 1 | Opponent | no | 4 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0515 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 548 |
| L0515 | 5 | 1 | Opponent | yes | - | 4 | 2 | 2 | 1 | 0 | 0 | 0 |
| L0517 | 1 | 1 | Mine | no | 1 | 5 | 2 | 1 | 0 | 0 | 0 | 698 |
| L0517 | 1 | 1 | Opponent | no | 3 | 2 | 3 | 1 | 2 | 0 | 0 | 0 |
| L0519 | 3 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 771 |
| L0519 | 3 | 1 | Opponent | no | 3 | 2 | 1 | 3 | 1 | 0 | 0 | 55 |
| L0521 | 5 | 1 | Mine | no | - | 4 | 0 | 0 | 0 | 0 | 0 | 613 |
| L0521 | 5 | 1 | Opponent | yes | - | - | 1 | 6 | 0 | 0 | 0 | 355 |
| L0525 | 3 | 1 | Mine | no | 5 | - | 0 | 1 | 0 | 0 | 0 | 686 |
| L0525 | 3 | 1 | Opponent | no | 5 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0533 | 5 | 1 | Mine | yes | - | - | 0 | 2 | 0 | 0 | 0 | 1193 |
| L0533 | 5 | 1 | Opponent | yes | - | 2 | 3 | 5 | 0 | 0 | 0 | 0 |
| L0607 | 1 | 1 | Mine | no | 0 | 6 | 1 | 1 | 1 | 0 | 0 | 615 |
| L0607 | 1 | 1 | Opponent | no | 1 | 2 | 3 | 0 | 0 | 0 | 0 | 420 |
| L0610 | 4 | 1 | Mine | no | 0 | 4 | 0 | 2 | 0 | 0 | 0 | 861 |
| L0610 | 4 | 1 | Opponent | no | 6 | - | 2 | 0 | 0 | 0 | 0 | 330 |
| L0629 | 5 | 1 | Mine | no | - | - | 1 | 1 | 0 | 0 | 0 | 615 |
| L0629 | 5 | 1 | Opponent | yes | - | 2 | 2 | 3 | 1 | 0 | 0 | 0 |
| L0633 | 3 | 1 | Mine | no | 4 | 4 | 2 | 1 | 1 | 0 | 0 | 615 |
| L0633 | 3 | 1 | Opponent | no | 0 | 1 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0635 | 5 | 1 | Mine | yes | - | - | 1 | 3 | 1 | 0 | 0 | 615 |
| L0635 | 5 | 1 | Opponent | yes | - | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0709 | 1 | 1 | Mine | yes | 10 | 2 | 2 | 1 | 2 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | yes | 0 | 2 | 1 | 2 | 0 | 0 | 0 | 524 |
| L0723 | 3 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 562 |
| L0723 | 3 | 1 | Opponent | no | 4 | 2 | 3 | 3 | 2 | 0 | 0 | 0 |
| L0728 | 2 | 1 | Mine | - | - | 2 | 2 | 5 | 0 | 0 | 0 | 420 |
| L0728 | 2 | 1 | Opponent | - | - | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0732 | 6 | 1 | Mine | no | 3 | 2 | 2 | 1 | 0 | 0 | 0 | 375 |
| L0732 | 6 | 1 | Opponent | no | 1 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0917 | 5 | 1 | Mine | no | - | 6 | 1 | 1 | 0 | 0 | 0 | 492 |
| L0917 | 5 | 1 | Opponent | yes | - | 2 | 5 | 3 | 0 | 0 | 0 | 147 |
| L0918 | 6 | 1 | Mine | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 726 |
| L0918 | 6 | 1 | Opponent | no | 5 | 4 | 3 | 0 | 1 | 0 | 0 | 234 |
| L0928 | 4 | 1 | Mine | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 1134 |
| L0928 | 4 | 1 | Opponent | no | 5 | 4 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0930 | 6 | 1 | Mine | no | 1 | 5 | 2 | 1 | 0 | 0 | 0 | 629 |
| L0930 | 6 | 1 | Opponent | no | 6 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1018 | 4 | 1 | Mine | no | 2 | 3 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1018 | 4 | 1 | Opponent | no | 0 | 6 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1322 | 2 | 1 | Mine | - | - | 4 | 3 | 1 | 1 | 0 | 0 | 140 |
| L1322 | 2 | 1 | Opponent | - | - | 2 | 5 | 0 | 0 | 0 | 0 | 145 |
| L1418 | 2 | 1 | Mine | - | - | 1 | 7 | 1 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | - | 5 | 1 | 1 | 0 | 0 | 185 |
| L1522 | 4 | 1 | Mine | no | 10 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L1522 | 4 | 1 | Opponent | no | 0 | 1 | 3 | 0 | 0 | 0 | 0 | 55 |
| L1525 | 1 | 1 | Mine | no | 1 | 1 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1525 | 1 | 1 | Opponent | no | 3 | 4 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1526 | 2 | 1 | Mine | - | - | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| L1526 | 2 | 1 | Opponent | - | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L1820 | 2 | 1 | Mine | - | - | 2 | 5 | 4 | 0 | 0 | 0 | 0 |
| L1820 | 2 | 1 | Opponent | - | - | - | 1 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 17% | 2.3 | 3.3 | 1.5 | 1.3 | 0.2 | 0.0 | 0.0 | 500.6 |
| **Average** | | | Opponent | 27% | 2.9 | 2.7 | 2.1 | 1.9 | 0.4 | 0.0 | 0.0 | 145.1 |

### KPIs: gf-h2h-opp-0533c46-p4

Rules off - Mine only: GUN FIGURES, GUN MASK, GUN VIEW, GUN THREAT, STAY WORTH, BEST MOVE FOR SHOOTERS, FACE THE CAST, WIZARD FRONT RANK, FIRE PLAN, FIRE IN ORDER, KEEPS THE TARGET, MISSILES IN THE FIRE PLAN, THREAT AT FULL SIZE, SHOOTERS ARE THREATS, SHOOTERS TO THE PRIMARY, EVERY WOUND COUNTS, HONEST THREAT, ONE YARDSTICK.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 45% (75 of 165) | 10% (16 of 168) | 27% (91 of 333) |
| Winner chose to follow up after the loser gave ground |  | 97% (34 of 35); on the table 97% | 95% (42 of 44); on the table 95% | 96% (76 of 79); on the table 96% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (7 of 7); on the table 100% | 100% (13 of 13); on the table 100% | 100% (20 of 20); on the table 100% |
| Winner chose to pursue after the loser fled |  | 63% (12 of 19); on the table 68% | 83% (24 of 29); on the table 86% | 75% (36 of 48); on the table 79% |
| Winner chose to follow up or pursue (all three) |  | 87% (53 of 61); on the table 89% | 92% (79 of 86); on the table 93% | 90% (132 of 147); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 36% (85 of 234) | 38% (59 of 156) | 37% (144 of 390) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 50% (85 of 171) | 46% (59 of 128) | 48% (144 of 299) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 33% (24 of 72) | 29% (23 of 78) | 31% (47 of 150) |
|     round 1 |  | 67% (8 of 12) | 15% (2 of 13) | 40% (10 of 25) |
|     rounds 2+ |  | 27% (16 of 60) | 32% (21 of 65) | 30% (37 of 125) |
|   other wizards | 50%+ | 38% (61 of 162) | 46% (36 of 78) | 40% (97 of 240) |
|     round 1 |  | 44% (12 of 27) | 46% (6 of 13) | 45% (18 of 40) |
|     rounds 2+ |  | 36% (49 of 135) | 46% (30 of 65) | 40% (79 of 200) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (4 of 6) | 55% (22 of 40) | 57% (26 of 46) |
| Points that never fought | lower | 52% (36245 of 70083) | 53% (38395 of 71988) | 53% (74640 of 142071) |
|   infantry points that never fought | lower | 46% (8181 of 17810) | 76% (10731 of 14065) | 59% (18912 of 31875) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 66% (199 of 303) | 64% (180 of 282) | 65% (379 of 585) |
| Bound items with a magic missile used (at least once a game) |  | 100% (13 of 13); 1.1 uses a game | 76% (13 of 17); 1.2 uses a game | 87% (26 of 30); 1.2 uses a game |
| Bound items with another spell used |  | 50% (7 of 14); 0.6 uses a game | 50% (1 of 2); 0.1 uses a game | 50% (8 of 16); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 13% (2 of 15); 0.1 uses a game | 44% (4 of 9); 0.1 uses a game | 25% (6 of 24); 0.1 uses a game |
|   their share of the points of units over 100 pts | lower | 60% (34475 of 57540) | 59% (37180 of 62687) | 60% (71655 of 120227) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.6 (40%) | 0.9 (33%) | 2.5 (37%) |
| MARCHED: its unit marched | 0.4 (9%) | 0.6 (21%) | 0.9 (14%) |
| CHARGED: its unit charged | 0.2 (4%) | 0.1 (3%) | 0.2 (4%) |
| IN COMBAT: engaged in combat | 0.8 (20%) | 0.6 (21%) | 1.4 (20%) |
| REAR RANK: in a rear rank | 0.1 (2%) | 0.1 (5%) | 0.2 (3%) |
| FLEEING: fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 0.6 (15%) | 0.2 (8%) | 0.8 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (6%) | 0.0 (0%) | 0.2 (4%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.0 (1%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (2%) | 0.2 (7%) | 0.3 (4%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 2.5 | 1.1 | 1.7 | 4.0 | 0.3 | 1.3 |
| not cast | 3.5 | 2.3 | 2.6 | 6.8 | 1.0 | 14.4 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.1 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.5 (21%) | 0.1 (2%) | 2.5 (37%) | 0.3 (33%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.9 (14%) | 0.1 (11%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (4%) | 0.1 (6%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (4%) | 0.1 (5%) | 0.3 (11%) | 1.4 (20%) | 0.1 (11%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.6 (16%) | 0.9 (39%) | 0.4 (15%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (6%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 0.6 (18%) | 0.3 (12%) | 0.6 (24%) | 0.8 (12%) | 0.1 (14%) | 1.5 (11%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.1 (2%) | 0.1 (5%) | 0.2 (4%) | 0.0 (0%) | 0.1 (1%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.1 (4%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (12%) | 0.0 (1%) | 0.1 (1%) | 0.2 (19%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (60%) | 0.1 (5%) | 1.1 (40%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 11.5 (80%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.8 a game | 0.9 a game | 0.9 a game |
| stood (cast and not dispelled) | 50% (9 of 18) | 62% (13 of 21) | 56% (22 of 39) |
| the unit moved after it | 67% (6 of 9) | 54% (7 of 13) | 59% (13 of 22) |
| it charged on its next turn | 11% (1 of 9) | 0% (0 of 13) | 5% (1 of 22) |
| the enemy charged it first | 22% (2 of 9) | 8% (1 of 13) | 14% (3 of 22) |
| it fought by the end of its next turn | 0% (0 of 9) | 0% (0 of 13) | 0% (0 of 22) |
| it moved out of a charge the enemy had planned (not charged first) | 11% (1 of 9) | 0% (0 of 13) | 5% (1 of 22) |
| none of these (no charge, no fight, no charge escaped) | 56% (5 of 9) | 92% (12 of 13) | 77% (17 of 22) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 70% (958 of 1377) | 57% (531 of 926) | 65% (1489 of 2303) |
|   cavalry | 53% (27 of 51) | 62% (80 of 128) | 60% (107 of 179) |
|   character | 75% (152 of 203) | 43% (58 of 134) | 62% (210 of 337) |
|   chariot | 54% (55 of 102) | 66% (52 of 79) | 59% (107 of 181) |
|   infantry | 53% (187 of 354) | 53% (212 of 399) | 53% (399 of 753) |
|   monster | 54% (29 of 54) | 55% (36 of 66) | 54% (65 of 120) |
|   war machine | 83% (508 of 613) | 78% (93 of 120) | 82% (601 of 733) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.4 (29%) | 2.6 (24%) | 6.0 (27%) |
| CHARGED: it charged | 1.3 (11%) | 1.5 (13%) | 2.8 (12%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.8 (7%) | 0.7 (6%) | 1.5 (7%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 2.4 (20%) | 3.4 (31%) | 5.8 (25%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (4%) | 0.6 (5%) | 1.0 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.0 (17%) | 1.6 (14%) | 3.6 (16%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.3 (3%) | 0.6 (3%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.8 (6%) | 0.3 (3%) | 1.1 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.3 | 1.2 | 74% | 5.7 pts | 25 pts |
| character | 6.3 | 2.1 | 78% | 6.6 pts | 42 pts |
| chariot | 3.0 | 2.3 | 66% | 17.8 pts | 53 pts |
| infantry | 16.8 | 4.7 | 78% | 7.1 pts | 119 pts |
| monster | 2.3 | 0.9 | 75% | 8.2 pts | 19 pts |
| war machine | 17.0 | 15.5 | 65% | 29.0 pts | 494 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.9 | 4.7 | 3.8 |
| Charges that made contact a game | 1.9 | 3.0 | 2.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.65 declared, 0.41 contact (17 units) | 1.00 declared, 0.89 contact (9 units) | 0.77 declared, 0.58 contact (26 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.00 declared, 0.00 contact (4 units) | 0.67 declared, 0.50 contact (6 units) | 0.40 declared, 0.30 contact (10 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.42 declared, 0.27 contact (226 units) | 0.54 declared, 0.34 contact (287 units) | 0.49 declared, 0.31 contact (513 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 65% (33 of 51) | 47% (7 of 15) | 56% (5 of 9) | 60% (45 of 75) |
| Character in a unit | 84% (47 of 56) | 64% (16 of 25) | 75% (3 of 4) | 78% (66 of 85) |
| Character on its own | 86% (24 of 28) | 65% (11 of 17) | 30% (15 of 50) | 53% (50 of 95) |
| Chariot | 68% (13 of 19) | 74% (17 of 23) | - | 71% (30 of 42) |
| Infantry | 63% (56 of 89) | 63% (29 of 46) | 50% (1 of 2) | 63% (86 of 137) |
| Monster | 58% (15 of 26) | 67% (6 of 9) | - | 60% (21 of 35) |
| Monstrous | 71% (5 of 7) | 58% (11 of 19) | - | 62% (16 of 26) |
| War Machines | 75% (62 of 83) | 43% (3 of 7) | - | 72% (65 of 90) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 2 | 100% (4 of 4); on the table 100% | 35% (19 of 54) | 38% | 55% (6 of 11) | 100% (3 of 3); 4.5 uses a game | 0% (0 of 1); 0.0 uses a game | 67% (2 of 3); 1.0 uses a game |
| Chaos Dwarfs | 9 | 71% (5 of 7); on the table 71% | 39% (28 of 72) | 61% | 63% (44 of 70) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 7); 0.0 uses a game |
| Dwarfen Mountain Holds | 13 | 83% (10 of 12); on the table 83% | - | 68% | 72% (79 of 109) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 12 | 86% (12 of 14); on the table 86% | 43% (41 of 96) | 55% | 69% (87 of 127) | 0.0 uses a game | 60% (3 of 5); 0.9 uses a game | 17% (1 of 6); 0.1 uses a game |
| Grand Cathay | 2 | 80% (4 of 5); on the table 100% | 35% (19 of 54) | 48% | 55% (11 of 20) | 100% (4 of 4); 4.0 uses a game | 50% (1 of 2); 0.5 uses a game | 0% (0 of 2); 0.0 uses a game |
| High Elf Realms | 7 | 97% (33 of 34); on the table 97% | 39% (7 of 18) | 37% | 46% (24 of 52) | 91% (10 of 11); 5.1 uses a game | 50% (4 of 8); 1.6 uses a game | 0.0 uses a game |
| Lizardmen | 2 | 50% (1 of 2); on the table 50% | - | 51% | 57% (8 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 5 | 100% (19 of 19); on the table 100% | 0% (0 of 18) | 47% | 69% (24 of 35) | 100% (5 of 5); 2.8 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (3 of 3); on the table 100% | 33% (2 of 6) | 8% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 2 | 100% (2 of 2); on the table 100% | 25% (3 of 12) | 44% | 69% (11 of 16) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Tomb Kings of Khemri | 4 | 92% (11 of 12); on the table 100% | 33% (2 of 6) | 46% | 40% (8 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 3 | 90% (9 of 10); on the table 90% | 42% (10 of 24) | 14% | 65% (11 of 17) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 6 | 92% (12 of 13); on the table 92% | 75% (9 of 12) | 47% | 52% (22 of 42) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
| Wood Elf Realms | 4 | 70% (7 of 10); on the table 70% | 22% (4 of 18) | 79% | 89% (39 of 44) | 50% (3 of 6); 3.5 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gf-h2h-opp-0533c46-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 53% (28) | 37% (13) | 47% (41) |
| ...free all their last turn and able to turn (per game) | 0.47 | 0.28 | 0.75 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.14 | 0.00 | 0.14 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.22 | 0.56 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.92 | 0.92 | 2.83 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.94 | 0.97 | 1.92 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.14 | 3.94 | 9.08 |

### Quality by phase: gf-h2h-opp-0533c46-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.1 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 51% (47 of 93) | 40% (58 of 144) |
| Strategy | Shoot objectives carried out (shot that target) | 56% (366 of 648) | 46% (139 of 301) |
| Strategy | Close-in objectives charged next turn | 18% (23 of 126) | 17% (36 of 218) |
| Strategy | Support requests answered (helper made contact too) | 39% (7 of 18) | 53% (17 of 32) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | 100% (3 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 50% (4 of 8) | 0% (0 of 4) |
| Strategy | Joined characters whose unit fought | 43% (28 of 65) | 33% (17 of 51) |
| Strategy | Lone characters that fought | 57% (44 of 77) | 59% (41 of 69) |
| Movement | Charges halted short of contact | 0.1 | 0.1 |
| Movement | Idle units | 1.3 | 1.9 |
| Movement | Points that never moved of their own | 500.6 | 145.1 |
| Movement | Fights charged into per game | 1.7 | 2.5 |
| Movement | Charges with odds: long shots (under 50%) | 9 of 57, net -60 | 18 of 74, net +65 |
| Movement | Charges with odds: sweet spot (55-75%) | 13 of 57, net +70 | 16 of 74, net +158 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 6 of 57, net +47 | 6 of 74, net +103 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 11 of 57, net +131 | 18 of 74, net +112 |
| Shooting | Shots by shooting units (incl. breath weapons) | 13.2 | 13.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (210 of 476) | 37% (177 of 478) |
| Shooting | Points destroyed by shooting units | 75.9 | 58.2 |
| Shooting | War machine shots | 14.1 | 2.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 42% (213 of 508) | 42% (44 of 104) |
| Shooting | Points destroyed by war machines | 142.2 | 31.1 |
| Magic | Magic missiles cast | 1.3 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 42% (20 of 48) | 33% (12 of 36) |
| Magic | Wounds caused by magic missiles | 3.4 | 1.1 |
| Magic | Wounds caused by other spells | 1.6 | 0.7 |
| Magic | Points destroyed by magic (all spells) | 43.5 | 22.9 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.2 / 0.4 / 0.4 / 0.1 | 1.4 / 0.2 / 0.5 / 0.1 |
| Combat | Points destroyed in combat | 188.5 | 255.2 |
| Combat | Points run down | 17.3 | 98.8 |
| Combat | Net points per charged fight, damage counted | +89 | +125 |
| Combat | Net per 100 charger points, damage counted | +36.6 | +47.5 |
| Combat | First round won (charged fights) | 63% | 66% |
| Combat | Net points per charged fight | +82 | +125 |
| Combat | Net points per supported fight / lone fight | +86 / +81 | +78 / +136 |
| Combat | Charged fights on a top-3 enemy unit | 21 of 62 | 43 of 89 |
| Game | Points lost | 639.3 | 533.6 |
| Game | VP from objectives | 460.0 | 652.8 |
| Game | Lone holders (player turns) | 2.3 | 2.9 |

- Mine won / drew / lost: 7 / 13 / 16 of 36 ended games (of 36); mean margin (Mine - Opponent) -303 VP
- The side that went first won 10 of 23 games with a winner
- Points traded per game (both sides' losses): 1173
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gf-h2h-opp-0533c46-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.4 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| ARRIVAL HUNT | 0.0 | +2.3 | 0.0 | 0.0 | 0.1 | +4.6 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 3.0 | +0.0 | 0.0 | 6.1 | 0.6 | +0.0 | 0.0 | 3.5 |
| BACKUP TARGETS | 0.5 | +5.1 | 0.0 | 29.2 | 0.8 | +7.0 | 0.0 | 5.5 |
| BEST FACING | 0.9 | +35.5 | 0.0 | 15.1 | 0.4 | +28.6 | 0.0 | 26.1 |
| BEST FIRST | 4.9 | +230.4 | 108.7 | 54.4 | 4.9 | +184.6 | 180.6 | 48.4 |
| BEST MOVE FOR SHOOTERS | - | - | - | - | 1.2 | +72.6 | 0.0 | 26.1 |
| BEST OVERALL | 0.8 | +41.6 | 0.0 | 15.0 | 0.5 | +39.8 | 0.0 | 24.8 |
| BEST PREY | 0.8 | +51.9 | 18.3 | 26.8 | 0.8 | +37.3 | 7.0 | 2.9 |
| BEST PRIZE | 0.0 | -3.3 | 0.0 | 7.8 | 0.1 | -8.4 | 2.4 | 2.5 |
| BIG CHARACTER SAFETY | 0.1 | +0.1 | 0.0 | 10.6 | 0.1 | +0.8 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.5 | +1.3 | 0.0 | 12.0 | 0.4 | +3.2 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.2 | -11.8 | 12.0 | 12.0 | 0.2 | -62.8 | 8.9 | 8.8 |
| BOMBING RUN | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 1.5 | +0.0 | 162.4 | 15.8 | - | - | - | - |
| CANNON PLANNED TARGET | 11.8 | +350.4 | 620.0 | 78.8 | - | - | - | - |
| CANNON SIGHT KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 2.6 |
| CARRIES OUT COUNTER | - | - | - | - | 0.0 | +0.0 | 2.5 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 0.0 | 8.6 | 0.2 | -3.5 | 27.6 | 3.4 |
| CAST JOB | 1.0 | +18.4 | 34.3 | 7.1 | 0.2 | +3.4 | 29.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +14.6 | 19.6 | 0.0 | 0.0 | -0.8 | 0.0 | 3.0 |
| CASTS AFTER FRIENDS | 0.5 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.6 | 0.0 | 0.0 | 0.1 | +1.9 | 0.0 | 0.0 |
| CATCH ODDS | 0.0 | +0.3 | 0.0 | 0.0 | 0.0 | +0.4 | 0.0 | 0.0 |
| CHAFF PASSED | 0.4 | -2.6 | 2.9 | 9.0 | - | - | - | - |
| CHARGE BAND | 0.1 | +0.0 | 22.8 | 1.8 | 0.1 | +0.0 | 1.5 | 1.2 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 115.1 | 62.2 | 1.9 | +0.0 | 191.4 | 39.3 |
| CHARGE NOW WEIGHED | 0.8 | -73.7 | 31.5 | 16.2 | 0.4 | -64.2 | 2.2 | 13.4 |
| CHARGER SLAIN LOST | 0.4 | -10.0 | 30.5 | 10.4 | 0.6 | -13.7 | 47.4 | 20.3 |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.3 | 6.1 | 0.0 | 0.2 | -1.4 | 8.0 | 11.0 |
| CHEAP HELPER | 0.0 | +0.0 | 1.9 | 0.0 | 0.2 | +0.0 | 4.3 | 2.6 |
| COMBAT PIVOT | 0.1 | +0.0 | 13.9 | 16.0 | 0.4 | +0.0 | 24.6 | 18.6 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.1 | +0.0 | 1.8 | 3.2 |
| CONVEYANCE SEARCH | 0.4 | +62.9 | 10.6 | 23.5 | 0.4 | +49.2 | 0.0 | 0.0 |
| COUNTER-CHARGE COVER | 11.1 | +989.4 | 0.0 | 198.8 | 6.6 | +616.8 | 0.0 | 162.7 |
| DEFENSIVE ARMY | 0.3 | +0.0 | 18.7 | 15.5 | 0.2 | +0.0 | 20.5 | 2.9 |
| EDGE GIVE GROUND | 0.1 | +2.2 | 9.8 | 1.7 | 0.3 | +2.4 | 27.1 | 1.9 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +0.4 | 0.0 | 9.7 |
| ENGINEER BY LORE | 0.4 | +0.0 | 0.0 | 2.4 | - | - | - | - |
| EVERY WOUND COUNTS | - | - | - | - | 10.5 | +0.0 | 507.5 | 168.6 |
| FACE THE CAST | - | - | - | - | 0.1 | +1.6 | 0.0 | 0.0 |
| FACES THE THREAT | 1.9 | +163.8 | 0.0 | 64.5 | 0.9 | +72.1 | 0.0 | 26.1 |
| FALLBACK BY WORTH | 4.6 | +71.5 | 0.0 | 57.5 | 5.9 | +75.1 | 0.0 | 67.4 |
| FIGHT LIFT | 0.1 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| FIRE AND FLEE | 0.1 | +0.6 | 0.0 | 3.3 | - | - | - | - |
| FIRE IN ORDER | - | - | - | - | 0.6 | +0.0 | 9.9 | 24.0 |
| FIRE PLAN | - | - | - | - | 15.5 | +26.3 | 700.6 | 285.4 |
| FLANK NOT WEIGHED | 5.9 | +0.0 | 0.0 | 123.1 | 4.0 | +0.0 | 0.0 | 88.9 |
| FOLLOW UP WEIGHED | 0.6 | +66.5 | 0.0 | 21.7 | 0.9 | +107.9 | 0.0 | 6.3 |
| FRIENDS SHOTS CHECKED | 0.2 | +6.5 | 0.0 | 4.7 | 0.3 | +11.2 | 0.0 | 2.1 |
| GIVES UP | 0.1 | -1.5 | 10.9 | 0.0 | 0.2 | -1.2 | 4.7 | 7.9 |
| GUN FIGURES | - | - | - | - | 1.9 | +55.6 | 126.6 | 48.6 |
| GUN MASK | - | - | - | - | 0.3 | +6.0 | 0.0 | 7.4 |
| GUN THREAT | - | - | - | - | 0.6 | +89.3 | 88.4 | 18.9 |
| GUN VIEW | - | - | - | - | 0.8 | +21.3 | 0.0 | 10.4 |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 2.1 | 0.0 | 0.1 | +0.0 | 5.2 | 0.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 0.0 | 13.8 | 0.1 | +0.0 | 0.0 | 1.4 |
| HILL BY ITS CHANCE | 0.5 | -69.3 | 0.0 | 1.8 | 0.5 | -40.2 | 0.0 | 3.1 |
| HOLDS AMBUSHERS | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| HONEST THREAT | - | - | - | - | 10.5 | +1455.2 | 507.5 | 168.6 |
| HONEST WORTH | 6.5 | -94.5 | 256.1 | 206.8 | 9.7 | -190.2 | 470.1 | 178.0 |
| HORN WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +4.9 | 0.0 | 0.0 | 0.1 | +3.0 | 2.4 | 3.8 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 2.4 | 6.1 |
| HUNT IN PAIRS | 0.1 | +10.3 | 0.0 | 0.0 | 0.6 | +39.6 | 0.0 | 29.7 |
| HUNT KEPT | 0.1 | +2.6 | 0.0 | 0.0 | 0.1 | +3.4 | 0.0 | 2.9 |
| HUNT RESULT | 0.1 | +20.3 | 0.0 | 0.0 | 0.4 | +33.0 | 2.4 | 12.8 |
| HUNT THE GUNS | 0.2 | +61.5 | 6.9 | 1.7 | 0.4 | +89.6 | 17.6 | 7.3 |
| INVITES THE FIGHT | 1.2 | +36.4 | 48.2 | 35.3 | 1.1 | +15.4 | 38.9 | 36.0 |
| JOINT CHARGE PLAN | 0.0 | +1.3 | 0.0 | 0.0 | 0.4 | +24.1 | 0.0 | 18.3 |
| JOINT KNOWS CHALLENGE | 0.0 | -0.3 | 6.5 | 0.0 | 0.1 | -0.3 | 6.5 | 3.1 |
| KEEP FALLS | 0.1 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.0 | +0.0 | 0.0 | 1.8 | 0.1 | +0.3 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.7 | +50.0 | 97.7 | 32.2 | 2.4 | +71.7 | 170.4 | 19.9 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| KEEPS THE TARGET | - | - | - | - | 1.4 | -50.6 | 175.0 | 17.5 |
| KILLS COUNT | 1.0 | +39.8 | 78.7 | 9.9 | 1.8 | +94.0 | 141.6 | 28.1 |
| KILLS COUNT NEXT TURN | 4.5 | +143.7 | 147.7 | 110.1 | 6.4 | +217.4 | 191.3 | 81.9 |
| LONE CHARACTER SAFE SPOT | 0.4 | +10.2 | 14.2 | 10.6 | 0.4 | +3.9 | 13.2 | 11.0 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.4 | +15.3 | 0.0 | 0.0 | 0.4 | +31.2 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | -7.6 | 25.9 | 15.3 | 0.5 | -0.9 | 21.5 | 1.1 |
| LOST CHARGE | 2.4 | -50.7 | 107.4 | 58.0 | 2.1 | -46.6 | 32.6 | 26.9 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.0 | -2.1 | 0.0 | 1.2 |
| MAKE SURE TOGETHER | 0.8 | +71.5 | 8.4 | 18.9 | 1.1 | +144.2 | 25.8 | 16.6 |
| MANOEUVRE | 0.1 | +4.5 | 0.0 | 0.0 | 0.2 | +2.1 | 0.0 | 19.0 |
| MARCH CHECK | 0.5 | +21.7 | 0.0 | 10.6 | 0.2 | +9.8 | 0.0 | 0.0 |
| MARCH ODDS | 0.2 | +8.0 | 0.0 | 0.0 | 0.3 | +19.4 | 8.4 | 0.0 |
| MARCH OVER CASTS | 0.4 | +25.1 | 0.0 | 0.0 | 0.6 | +53.6 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.8 | +100.6 | 0.0 | 102.7 | 4.2 | +184.5 | 0.0 | 91.8 |
| MISSILES IN THE FIRE PLAN | - | - | - | - | 0.9 | +3.9 | 27.0 | 11.0 |
| MISSILES IN THE MOVE | 3.6 | +76.1 | 0.0 | 50.8 | 3.2 | +43.9 | 0.0 | 19.2 |
| MISSILES NEXT TURN | 3.9 | +47.0 | 0.0 | 50.8 | 3.9 | +40.1 | 0.0 | 22.2 |
| MODEL FACING | 0.6 | +123.0 | 0.0 | 6.7 | 0.1 | +28.4 | 0.0 | 0.0 |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 0.0 | 10.6 | 0.6 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.4 | +14.6 | 0.0 | 4.7 | 0.2 | +12.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.3 | +7.1 | 0.0 | 23.5 | - | - | - | - |
| MOVE SPELL NOT WORTH | - | - | - | - | 0.0 | -0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.3 | -6.7 | 5.2 | 21.1 | 0.2 | -4.1 | 0.0 | 9.1 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 2.6 | +182.0 | 99.2 | 87.4 | 5.9 | +398.0 | 186.1 | 109.3 |
| MOVES UNITS SPELL | 0.1 | +2.1 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.1 | +8.8 | 2.9 | 0.0 |
| NO RALLY LEFT | 0.0 | +0.8 | 0.0 | 4.2 | 0.1 | +2.1 | 0.0 | 7.5 |
| NOT NEEDED | 0.1 | -5.9 | 3.8 | 0.0 | 0.2 | -14.3 | 30.4 | 1.2 |
| NOT TURNED | 5.1 | +58.1 | 0.0 | 127.2 | 3.9 | +57.4 | 0.0 | 84.8 |
| NOT WORTH A CAST | 0.1 | -0.1 | 0.0 | 21.1 | 0.4 | -0.3 | 0.0 | 0.0 |
| OFF BEST | 16.7 | -685.2 | 0.0 | 222.8 | 14.3 | -790.2 | 5.7 | 158.5 |
| ONE YARDSTICK | - | - | - | - | 13.3 | -460.6 | 308.2 | 187.5 |
| OPENS A LANE | 0.0 | +0.0 | 5.2 | 0.0 | 0.1 | +0.5 | 5.8 | 0.0 |
| OPENS UP | 0.1 | +2.7 | 2.1 | 0.0 | 0.1 | +11.4 | 4.3 | 7.9 |
| OVERRUNS AWAY | 0.3 | +12.0 | 20.3 | 4.0 | 0.4 | +4.7 | 15.4 | 13.2 |
| PATHS CROSS | 1.5 | +57.2 | 0.0 | 37.8 | 2.8 | +143.4 | 0.0 | 43.6 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +1.5 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.2 | -5.8 | 0.0 | 8.6 | 0.1 | -2.6 | 0.0 | 0.0 |
| PLAN RESULT | 40.4 | +1571.6 | 1260.0 | 821.0 | 39.3 | +1070.7 | 1281.0 | 798.5 |
| PURSUES BIG PREY | 0.0 | -1.5 | 0.0 | 0.0 | 0.0 | -0.8 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | 0.0 | +4.9 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +3.3 | 0.0 | 0.0 | - | - | - | - |
| RANDOM MOVE BY FIGURES | 0.2 | +0.4 | 0.0 | 0.0 | 1.1 | +14.1 | 0.0 | 9.9 |
| RANDOM MOVER NO PROMISE | 0.1 | -2.7 | 0.0 | 0.0 | 0.2 | -18.3 | 5.2 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -2.5 | 0.0 | 0.9 | 0.2 | -9.6 | 0.0 | 3.9 |
| REDIRECT COUNTER | 1.3 | +157.2 | 0.0 | 22.3 | 2.2 | +176.5 | 0.0 | 36.5 |
| REDIRECT WEIGHED | 0.3 | -3.1 | 5.1 | 7.8 | 0.4 | -0.3 | 11.1 | 1.2 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 8.0 | 0.3 | +0.0 | 0.0 | 1.4 |
| RESERVE FALL BACK | 0.1 | +0.9 | 0.0 | 0.0 | 0.9 | +19.5 | 0.0 | 13.3 |
| RESTRAINS TO SHOOT | 0.2 | +7.2 | 0.0 | 8.6 | 0.1 | +2.4 | 0.0 | 0.0 |
| RISK BY ARC | 1.8 | +79.4 | 128.4 | 65.4 | 2.6 | +37.6 | 215.6 | 63.9 |
| SAFER THAN THE JOB | 0.9 | +68.8 | 0.0 | 6.8 | 1.0 | +59.3 | 0.0 | 27.0 |
| SCOUT SPOT | 0.4 | +0.8 | 0.0 | 0.0 | 0.6 | +2.5 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.0 | -1.2 | 0.0 | 0.0 | 0.2 | -19.1 | 0.0 | 1.4 |
| SEARCH SPOT | 1.6 | +80.3 | 0.0 | 26.0 | 3.1 | +115.5 | 0.0 | 49.8 |
| SECOND HUNTER | - | - | - | - | 0.1 | -0.5 | 3.1 | 0.9 |
| SELF MOVE SPELL | 0.5 | +79.2 | 0.0 | 0.0 | 0.4 | +86.5 | 0.0 | 11.0 |
| SET UP TOGETHER | 1.0 | +91.9 | 24.9 | 38.3 | 2.8 | +352.4 | 25.8 | 53.6 |
| SET-UP ANY TARGET | 0.3 | +61.4 | 10.6 | 21.1 | 0.2 | +36.5 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.0 | +6.6 | 0.0 | 0.0 |
| SHOOTERS ARE THREATS | - | - | - | - | 5.0 | +347.5 | 264.4 | 64.9 |
| SHOOTERS IN TWO RANKS | 0.8 | +1.4 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTERS TO THE PRIMARY | - | - | - | - | 1.5 | +24.7 | 0.0 | 1.5 |
| SHOOTS FROM THE BEST SPOT | 0.8 | +15.8 | 21.1 | 6.7 | 1.1 | +37.7 | 34.7 | 14.6 |
| SHORT GUN FORWARD | 0.4 | +0.0 | 0.0 | 3.3 | 0.1 | +0.0 | 0.0 | 0.0 |
| SHOT OPTIONS | 25.2 | +0.0 | 1076.4 | 318.4 | 14.8 | +0.0 | 627.9 | 266.7 |
| SHOT REPLANNED | 1.2 | +0.0 | 172.1 | 18.2 | - | - | - | - |
| SHOTS IN THE MOVE | 24.2 | +873.2 | 0.0 | 290.2 | 13.6 | +562.1 | 0.0 | 244.6 |
| SPELL CATCH ODDS | - | - | - | - | 0.0 | -0.7 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.3 | +65.7 | 10.6 | 21.1 | 0.2 | +36.5 | 0.0 | 0.0 |
| SPELL WORTH | 0.3 | +6.1 | 27.6 | 32.1 | 1.2 | +20.5 | 2.9 | 0.0 |
| SPELLS IN THE FIGHT | 0.5 | +1.4 | 37.2 | 20.8 | 0.3 | -10.6 | 24.9 | 18.2 |
| STABLE ROLE | 12.8 | +0.0 | 271.4 | 225.2 | 9.8 | +0.0 | 270.1 | 178.4 |
| STANDS TO CAST | 0.1 | +4.2 | 2.4 | 0.0 | - | - | - | - |
| STAY WEIGHED | 0.1 | +2.3 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| STAY WORTH | - | - | - | - | 17.9 | +246.7 | 353.3 | 275.8 |
| STOPS | 0.1 | +4.8 | 6.9 | 1.7 | 0.3 | +12.0 | 15.3 | 6.4 |
| STOPS SHORT OF THE FLANK | 0.4 | +12.0 | 0.0 | 34.3 | 0.2 | +13.8 | 0.0 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT JOB KEPT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT NARROWED | 3.7 | -30.7 | 178.8 | 72.5 | 5.2 | -28.0 | 266.2 | 81.2 |
| SUPPORTS | 2.4 | +33.0 | 100.1 | 42.6 | 3.3 | +28.0 | 112.4 | 40.3 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -5.7 | 10.3 | 9.5 | 0.1 | -2.2 | 2.9 | 3.2 |
| SURE REACH TOGETHER | 0.8 | +7.7 | 0.0 | 8.9 | 0.7 | -1.5 | 1.8 | 3.6 |
| THROUGH LINE OF FIRE | 0.8 | +15.2 | 0.0 | 8.1 | 0.2 | +2.9 | 0.0 | 0.0 |
| TURN WORTH | 0.2 | -10.9 | 19.8 | 3.2 | 0.2 | -17.9 | 22.8 | 5.4 |
| TWO OR MORE ARRIVE | 0.4 | +7.3 | 24.9 | 3.3 | 0.9 | +13.0 | 12.0 | 10.3 |
| WAIT AFTER COSTS | 5.9 | -316.6 | 204.5 | 170.6 | 8.9 | -478.1 | 273.6 | 171.9 |
| WALKS TO THE FIGHT | 1.9 | +33.6 | 37.5 | 51.5 | 1.3 | +19.9 | 33.9 | 14.9 |
| WAR ENGINE CHARGES | 0.1 | +18.1 | 8.6 | 8.6 | 0.0 | +0.7 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.8 | +0.0 | 18.6 | 48.8 | 0.4 | +0.0 | 6.5 | 12.9 |
| WEARS DOWN | 1.0 | +38.8 | 35.9 | 58.8 | 0.9 | +35.7 | 77.8 | 26.2 |
| WHO HITS BACK | 0.2 | +12.5 | 0.0 | 9.8 | 0.1 | +7.3 | 0.0 | 6.1 |
| WHOLE FIGHT | 0.2 | +15.2 | 29.2 | 3.2 | 0.2 | +15.3 | 33.9 | 6.6 |
| WHOLE FIGHT GAIN | 0.4 | +24.2 | 14.5 | 11.9 | 0.6 | +64.3 | 47.6 | 18.4 |
| WIDER SPREAD | 1.7 | +1.3 | 123.6 | 47.6 | 2.6 | -0.9 | 187.6 | 46.9 |

### Rule changes: gf-h2h-opp-0533c46-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1114 | 1114 | 1114 | 30.94 | -53116 | -47.7 |
| BEST FIRST | 353 | 353 | 353 | 9.81 | +14942 | +42.3 |
| COUNTER-CHARGE COVER | 634 | 343 | 170 | 4.72 | +10140 | +59.6 |
| SEARCH SPOT | 169 | 169 | 166 | 4.61 | +7051 | +42.5 |
| MOVE TO CHARGE | 308 | 308 | 154 | 4.28 | +7071 | +45.9 |
| PATHS CROSS | 154 | 154 | 154 | 4.28 | +7219 | +46.9 |
| ARTILLERY RE-ROLL WEIGHED | 130 | 130 | 130 | 3.61 | +0 | +0.0 |
| KILLS COUNT NEXT TURN | 394 | 394 | 129 | 3.58 | +3322 | +25.7 |
| SHOTS IN THE MOVE | 1359 | 954 | 125 | 3.47 | +4192 | +33.5 |
| FIRE PLAN | 557 | 557 | 116 | 3.22 | +199 | +1.7 |
| FACES THE THREAT | 102 | 102 | 102 | 2.83 | +8494 | +83.3 |
| FALLBACK BY WORTH | 378 | 378 | 91 | 2.53 | +5279 | +58.0 |
| CANNON SIGHT KEPT | 86 | 86 | 86 | 2.39 | +0 | +0.0 |
| EVERY WOUND COUNTS | 379 | 379 | 84 | 2.33 | +0 | +0.0 |
| SET UP TOGETHER | 137 | 121 | 73 | 2.03 | +7387 | +101.2 |
| SAFER THAN THE JOB | 69 | 69 | 69 | 1.92 | +4611 | +66.8 |
| SUPPORTS | 205 | 205 | 68 | 1.89 | +643 | +9.5 |
| CANNON PLANNED TARGET | 424 | 424 | 66 | 1.83 | -465 | -7.0 |
| WALKS TO THE FIGHT | 115 | 115 | 62 | 1.72 | +665 | +10.7 |
| WAIT AFTER COSTS | 534 | 534 | 59 | 1.64 | +964 | +16.3 |
| FOLLOW UP WEIGHED | 53 | 53 | 53 | 1.47 | +6279 | +118.5 |
| STAY WORTH | 645 | 530 | 50 | 1.39 | +921 | +18.4 |
| BEST FACING | 48 | 48 | 48 | 1.33 | +2311 | +48.1 |
| BEST OVERALL | 46 | 46 | 46 | 1.28 | +2933 | +63.8 |
| SHOT REPLANNED | 43 | 43 | 43 | 1.19 | +0 | +0.0 |
| BEST MOVE FOR SHOOTERS | 42 | 42 | 42 | 1.17 | +2616 | +62.3 |
| CHARGE NOW WEIGHED | 42 | 42 | 42 | 1.17 | +4029 | +95.9 |
| SHOOTERS IN TWO RANKS | 41 | 41 | 41 | 1.14 | +74 | +1.8 |
| MAX FOR POSITIONING | 288 | 169 | 40 | 1.11 | +690 | +17.2 |
| SCOUT WAITS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| HONEST THREAT | 379 | 379 | 39 | 1.08 | +0 | +0.0 |
| RESERVE FALL BACK | 36 | 36 | 36 | 1.00 | +733 | +20.4 |
| THROUGH LINE OF FIRE | 36 | 36 | 36 | 1.00 | +649 | +18.0 |
| RISK BY ARC | 160 | 151 | 35 | 0.97 | +1291 | +36.9 |
| MISSILES IN THE MOVE | 248 | 164 | 34 | 0.94 | +497 | +14.6 |
| ADVANCE LANE KEPT | 33 | 33 | 33 | 0.92 | +0 | +0.0 |
| HONEST WORTH | 581 | 573 | 33 | 0.92 | +260 | +7.9 |
| MAKE SURE TOGETHER | 68 | 54 | 32 | 0.89 | +3161 | +98.8 |
| BLOCKED WHEEL | 31 | 31 | 31 | 0.86 | +161 | +5.2 |
| REDIRECT COUNTER | 126 | 67 | 28 | 0.78 | +3327 | +118.8 |
| LONE WIZARD KEPT IN | 27 | 27 | 27 | 0.75 | +1675 | +62.0 |
| MARCH CHECK | 27 | 27 | 27 | 0.75 | +1229 | +45.5 |
| REDIRECT WEIGHED | 27 | 27 | 27 | 0.75 | +939 | +34.8 |
| RANDOM MOVE BY FIGURES | 46 | 46 | 26 | 0.72 | +520 | +20.0 |
| MODEL FACING | 25 | 25 | 25 | 0.69 | +5450 | +218.0 |
| KEEPS ITS TARGET | 146 | 145 | 24 | 0.67 | +390 | +16.2 |
| MOVE AND CAST | 24 | 24 | 24 | 0.67 | +960 | +40.0 |
| BEST PREY | 54 | 54 | 23 | 0.64 | +1228 | +53.4 |
| KILLS COUNT | 100 | 98 | 23 | 0.64 | +1436 | +62.5 |
| SHOOTS FROM THE BEST SPOT | 70 | 70 | 23 | 0.64 | +432 | +18.8 |
| FIRE IN ORDER | 22 | 22 | 22 | 0.61 | +0 | +0.0 |
| COMBAT PIVOT | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| KEEPS THE TARGET | 52 | 52 | 21 | 0.58 | -2033 | -96.8 |
| ONE YARDSTICK | 479 | 185 | 21 | 0.58 | +310 | +14.8 |
| SHOOTERS ARE THREATS | 180 | 180 | 21 | 0.58 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 20 | 20 | 20 | 0.56 | +929 | +46.4 |
| CHARGE NOW FIRST | 117 | 117 | 19 | 0.53 | -993 | -52.3 |
| FRIENDS SHOTS CHECKED | 19 | 19 | 19 | 0.53 | +637 | +33.5 |
| HOLDS AMBUSHERS | 19 | 19 | 19 | 0.53 | +0 | +0.0 |
| SHORT GUN FORWARD | 19 | 19 | 19 | 0.53 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| CHAFF PASSED | 16 | 16 | 16 | 0.44 | -94 | -5.9 |
| GUN VIEW | 29 | 29 | 16 | 0.44 | +755 | +47.2 |
| MARCH ODDS | 16 | 16 | 16 | 0.44 | +69 | +4.3 |
| WAR ENGINE JOBS | 41 | 41 | 16 | 0.44 | -810 | -50.6 |
| WHOLE FIGHT GAIN | 36 | 34 | 16 | 0.44 | +520 | +32.5 |
| CAST JOB | 44 | 44 | 15 | 0.42 | +188 | +12.5 |
| INVITES THE FIGHT | 83 | 83 | 14 | 0.39 | +213 | +15.2 |
| MANOEUVRE | 13 | 13 | 12 | 0.33 | +236 | +19.7 |
| WEARS DOWN | 68 | 63 | 12 | 0.33 | +481 | +40.1 |
| WHO HITS BACK | 12 | 12 | 12 | 0.33 | +602 | +50.2 |
| PIVOT GUARDS FLANK | 11 | 11 | 11 | 0.31 | -302 | -27.4 |
| STUCK PIVOT | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| CHARGE BAND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| LOST CHARGE | 163 | 163 | 9 | 0.25 | +86 | +9.5 |
| RESTRAINS TO SHOOT | 9 | 9 | 9 | 0.25 | +346 | +38.5 |
| SURE CHARGE BEATS ADVANCE | 9 | 9 | 9 | 0.25 | -283 | -31.5 |
| HUNT IN PAIRS | 24 | 18 | 8 | 0.22 | +733 | +91.6 |
| BACKUP TARGETS | 47 | 26 | 7 | 0.19 | +48 | +6.9 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +96 | +13.7 |
| BIG CHARACTER SAFETY | 6 | 6 | 6 | 0.17 | +32 | +5.4 |
| KEEPS SCOUTS OR AMBUSH | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| SUPPORT NARROWED | 322 | 322 | 6 | 0.17 | -71 | -11.8 |
| WHOLE FIGHT | 17 | 17 | 6 | 0.17 | +231 | +38.5 |
| BEST PRIZE | 5 | 5 | 5 | 0.14 | -422 | -84.3 |
| BLOCKED CHARGE SKIPPED | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| OPENS UP | 7 | 7 | 5 | 0.14 | +123 | +24.6 |
| CASTING BLOCK | 7 | 7 | 4 | 0.11 | +312 | +78.1 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| FACE THE CAST | 4 | 4 | 4 | 0.11 | +58 | +14.4 |
| REFUSING RETIRES | 19 | 19 | 4 | 0.11 | -1 | -0.3 |
| SHOOTERS TO THE PRIMARY | 54 | 37 | 4 | 0.11 | +6 | +1.4 |
| STANDS TO CAST | 4 | 4 | 4 | 0.11 | +18 | +4.6 |
| STOPS | 16 | 16 | 4 | 0.11 | +188 | +47.0 |
| SURE REACH TOGETHER | 54 | 38 | 4 | 0.11 | +59 | +14.8 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.08 | +23 | +7.6 |
| NO RALLY LEFT | 3 | 3 | 3 | 0.08 | +69 | +23.1 |
| STAY WEIGHED | 3 | 3 | 3 | 0.08 | +91 | +30.2 |
| TWO OR MORE ARRIVE | 47 | 44 | 3 | 0.08 | +28 | +9.3 |
| WAR ENGINE CHARGES | 5 | 5 | 3 | 0.08 | +164 | +54.8 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -5 | -2.3 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| GUN THREAT | 22 | 22 | 2 | 0.06 | +0 | +0.0 |
| JOINT CHARGE PLAN | 14 | 14 | 2 | 0.06 | +234 | +116.8 |
| KEEP FALLS | 2 | 2 | 2 | 0.06 | +58 | +28.8 |
| LONG SHOT | 34 | 31 | 2 | 0.06 | +21 | +10.3 |
| MISSILES NEXT TURN | 282 | 175 | 2 | 0.06 | +10 | +5.0 |
| NEEDED THERE | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| OVERRUNS AWAY | 23 | 22 | 2 | 0.06 | +33 | +16.6 |
| PURSUES BIG PREY | 2 | 2 | 2 | 0.06 | -86 | -42.8 |
| WIDER SPREAD | 155 | 146 | 2 | 0.06 | +34 | +16.8 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +23 | +23.1 |
| CARRIES OUT SET-UP | 10 | 10 | 1 | 0.03 | -125 | -125.5 |
| CHARGER SLAIN LOST | 37 | 36 | 1 | 0.03 | +49 | +48.8 |
| DEFENSIVE ARMY | 17 | 17 | 1 | 0.03 | -8 | -8.2 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +16 | +15.5 |
| GUN MASK | 12 | 7 | 1 | 0.03 | +38 | +38.3 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +3 | +3.4 |
| HUNT ADVANCE | 8 | 8 | 1 | 0.03 | +48 | +48.1 |
| LONE WIZARD HOLDS BACK | 3 | 3 | 1 | 0.03 | +0 | +0.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +54 | +54.0 |
| RAIDS THE BAGGAGE | 1 | 1 | 1 | 0.03 | +4 | +4.0 |
| RAIDS THE BAGGAGE NEXT TURN | 1 | 1 | 1 | 0.03 | +111 | +110.9 |
| SUPPORT JOB KEPT | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| ARRIVAL HUNT | 5 | 5 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 17 | 16 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 53 | 53 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 37 | trace | - | - | - | - |
| CATCH FLIERS | 3 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 11 | 11 | 0 | 0.00 | - | - |
| CHEAP HELPER | 7 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 30 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 15 | 14 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 14 | 14 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 357 | not checked | - | - | - | - |
| GIVES UP | 9 | 8 | 0 | 0.00 | - | - |
| GUN FIGURES | 68 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 5 | not checked | - | - | - | - |
| HELPER UNSEEN | 10 | 10 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 37 | 37 | 0 | 0.00 | - | - |
| HUNT DROPPED | 10 | trace | - | - | - | - |
| HUNT KEPT | 4 | trace | - | - | - | - |
| HUNT RESULT | 19 | trace | - | - | - | - |
| HUNT THE GUNS | 20 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 3 | 3 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 29 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 34 | 34 | 0 | 0.00 | - | - |
| MISSILES IN THE FIRE PLAN | 32 | not checked | - | - | - | - |
| MONSTER WIZARD ROAMS | 29 | 29 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 12 | 8 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 19 | trace | - | - | - | - |
| MOVE SPELL SPOT | 10 | not checked | - | - | - | - |
| NOT NEEDED | 11 | 11 | 0 | 0.00 | - | - |
| NOT TURNED | 327 | 327 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 19 | not checked | - | - | - | - |
| OPENS A LANE | 4 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 2870 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 11 | 11 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 12 | 12 | 0 | 0.00 | - | - |
| SCOUT SPOT | 35 | 35 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 10 | 10 | 0 | 0.00 | - | - |
| SECOND HUNTER | 3 | 3 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 33 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 17 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOT OPTIONS | 1440 | 1440 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 18 | not checked | - | - | - | - |
| SPELL WORTH | 54 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 30 | 29 | 0 | 0.00 | - | - |
| STABLE ROLE | 812 | 810 | 0 | 0.00 | - | - |
| TURN WORTH | 14 | 14 | 0 | 0.00 | - | - |

### Off best figure: gf-h2h-opp-0533c46-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 15.00 | 12.97 | 49.6 |
| FALLBACK | gate | 0.81 | 0.56 | 29.1 |
| TURN GATE | gate | 0.47 | 0.31 | 27.0 |
| CHARGE NOW FIRST | rule | 0.22 | 0.31 | 52.3 |
| KEEPS THE TARGET | rule | - | 0.47 | 122.4 |
| FIRE PLAN | rule | - | 0.42 | 108.2 |
| WAR ENGINE JOBS | rule | 0.39 | 0.03 | 54.0 |
| PATHS CROSS | rule | 0.28 | 0.06 | 49.6 |
| CANNON PLANNED TARGET | rule | 0.31 | - | 52.3 |
| PIVOT GUARDS FLANK | rule | 0.22 | 0.06 | 30.1 |
| THROUGH LINE OF FIRE | rule | 0.22 | 0.06 | 25.8 |
| CHAFF PASSED | rule | 0.25 | - | 10.5 |
| LONE CHARACTER SAFE SPOT | gate | 0.11 | 0.14 | 47.5 |
| SURE CHARGE BEATS ADVANCE | rule | 0.17 | 0.08 | 31.5 |
| SUPPORT REQUEST | gate | 0.06 | 0.17 | 62.5 |
| CHARGE NOW WEIGHED | rule | 0.17 | 0.03 | 14.9 |
| MARCH ODDS | rule | 0.08 | 0.11 | 25.2 |
| AFTERMATH BAND | gate | 0.11 | 0.06 | 3.2 |
| BLOCKED WHEEL | rule | 0.14 | 0.03 | 21.9 |
| BEST PRIZE | rule | 0.03 | 0.11 | 84.3 |
| FIGHT ORDER BAND | gate | 0.06 | 0.08 | 2.4 |
| SUPPORT NARROWED | rule | 0.11 | 0.03 | 14.1 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | - | 23.7 |
| CATCH ODDS | rule | 0.03 | 0.03 | 2.3 |
| PURSUES BIG PREY | rule | 0.03 | 0.03 | 42.8 |
| REDIRECT WEIGHED | rule | - | 0.06 | 33.4 |
| BIG CHARACTER SAFETY | rule | - | 0.03 | 2.8 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 125.5 |
| DEFENSIVE ARMY | rule | - | 0.03 | 8.2 |
| FACES THE THREAT | rule | - | 0.03 | 2.8 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | - | 2.8 |
| STANDS TO CAST | rule | 0.03 | - | 11.7 |

### Plans: gf-h2h-opp-0533c46-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.4 | 16% | 367 | 320 | 87% |
| Mine | charge | 2.2 | 48% | 142 | 152 | 107% |
| Mine | close in | 3.5 | 30% | 229 | 128 | 56% |
| Mine | hold | 5.1 | 29% | 372 | 0 | 0% |
| Mine | join | 0.6 | 95% | 15 | 0 | 0% |
| Mine | shoot | 15.1 | 60% | 314 | 974 | 310% |
| Mine | support | 2.5 | 90% | 11 | 0 | 0% |
| Opponent | advance | 14.0 | 14% | 409 | 331 | 81% |
| Opponent | charge | 3.5 | 54% | 269 | 280 | 104% |
| Opponent | close in | 6.0 | 20% | 496 | 116 | 23% |
| Opponent | hold | 4.8 | 49% | 349 | 0 | 0% |
| Opponent | join | 0.4 | 100% | 15 | 0 | 0% |
| Opponent | shoot | 6.8 | 48% | 334 | 348 | 104% |
| Opponent | support | 3.7 | 89% | 18 | 0 | 0% |

### Packages: hunt the guns, gf-h2h-opp-0533c46-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.2 | 6 | 1 | 40% | 40% | 0% | 2.0 | 402 | 146 | 40% | 32 |
| Opponent | 0.4 | 14 | 0 | 29% | 29% | 0% | 2.0 | 230 | 85 | 29% | 153 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 83 |
| Chaos Dwarfs | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 431 | 0 | 0% | 113 |
| Dwarfen Mountain Holds | 0.4 | 5 | 1 | 50% | 50% | 0% | 2.0 | 305 | 182 | 50% | 63 |
| Empire of Man | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 458 | 0 | 0% | 25 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 150 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 81 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 338 |
| Ogre Kingdoms | 1.4 | 7 | 0 | 57% | 57% | 0% | 2.0 | 238 | 170 | 57% | 91 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 488 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 72 |
| Tomb Kings of Khemri | 1.2 | 5 | 0 | 0% | 0% | 0% | - | 232 | 0 | 0% | 66 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 140 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 299 | 0 | 0% | 157 |

### Battle groups: gf-h2h-opp-0533c46-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 11.1 | 19% | 45% | 7% | 40% | 26% | 13% | 9% | 52% | 0% |
| Mine | REDIRECT COUNTER | 1.3 | 33% | 67% | 0% | - | 60% | 0% | 0% | 40% | 0% |
| Opponent | COUNTER-CHARGE COVER | 6.6 | 19% | 60% | 13% | 50% | 33% | 10% | 10% | 46% | 0% |
| Opponent | REDIRECT COUNTER | 2.2 | 22% | 78% | 22% | 0% | 29% | 7% | 7% | 57% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gf-h2h-opp-0533c46-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | Chaff | 13 | 17 (13) | 5 | 12 | 54 | 46% | 3.7 | 33 (6) | 0 (4) | 0 (3) | 25 (9) | 0 (4) |
| Mine | Character | 123 | 31 (123) | 31 | 0 | 29 | 23% | 2.5 | 32 (48) | 32 (54) | 49 (8) | 33 (74) | 33 (36) |
| Mine | Clean-up | 22 | 35 (22) | 3 | 31 | 67 | 41% | 2.8 | 43 (6) | 19 (10) | 40 (6) | 46 (16) | 14 (6) |
| Mine | Fast | 6 | 62 (6) | 62 | 0 | 44 | 17% | 1.6 | - | 36 (5) | 208 (1) | 72 (5) | 0 (1) |
| Mine | Fast Hammer | 36 | 28 (36) | 14 | 13 | 49 | 31% | 2.6 | 12 (15) | 45 (15) | 21 (6) | 28 (30) | 25 (6) |
| Mine | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | Hammer | 69 | 28 (69) | 18 | 10 | 34 | 23% | 2.6 | 21 (14) | 32 (47) | 17 (8) | 35 (46) | 16 (23) |
| Mine | Holder | 12 | 89 (12) | 0 | 89 | 22 | 67% | 5.0 | 0 (4) | 105 (6) | 214 (2) | 184 (5) | 13 (7) |
| Mine | Shooter | 52 | 62 (52) | 13 | 48 | 45 | 6% | 1.9 | 33 (12) | 78 (28) | 46 (12) | 88 (28) | 30 (24) |
| Mine | War machine | 113 | 42 (113) | 42 | 0 | 23 | 4% | 1.2 | 38 (34) | 46 (70) | 26 (9) | 34 (30) | 45 (83) |
| Mine | Wizard | 19 | 12 (19) | 12 | 0 | 31 | 37% | 2.2 | 37 (5) | 4 (11) | 0 (1) | 47 (4) | 3 (13) |
| Opponent | Blocker | 1 | 159 (1) | 159 | 0 | 100 | 0% | 3.0 | - | 159 (1) | - | - | 159 (1) |
| Opponent | Chaff | 72 | 80 (72) | 29 | 51 | 51 | 43% | 2.4 | 71 (30) | 102 (13) | 75 (29) | 119 (48) | 11 (24) |
| Opponent | Character | 93 | 38 (93) | 38 | 0 | 16 | 24% | 2.5 | 43 (38) | 36 (40) | 32 (11) | 41 (52) | 37 (37) |
| Opponent | Clean-up | 32 | 35 (32) | 19 | 17 | 20 | 34% | 2.5 | 34 (12) | 36 (17) | 39 (3) | 43 (23) | 17 (9) |
| Opponent | Early | 3 | 0 (3) | 0 | 0 | 67 | 0% | 5.3 | - | 0 (2) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Fast | 5 | 37 (5) | 37 | 0 | 83 | 20% | 2.0 | - | 14 (4) | 142 (1) | 70 (3) | 0 (2) |
| Opponent | Fast Hammer | 40 | 51 (40) | 31 | 19 | 25 | 32% | 3.2 | 29 (15) | 42 (16) | 105 (9) | 46 (28) | 62 (12) |
| Opponent | Fragile | 9 | 0 (9) | 0 | 0 | 14 | 67% | 6.0 | 0 (3) | 0 (3) | 0 (3) | 0 (4) | 0 (5) |
| Opponent | Hammer | 58 | 29 (58) | 27 | 2 | 45 | 34% | 2.3 | 27 (15) | 31 (38) | 24 (5) | 31 (32) | 27 (26) |
| Opponent | Holder | 30 | 112 (30) | 14 | 99 | 16 | 37% | 2.7 | 71 (6) | 126 (18) | 109 (6) | 126 (15) | 96 (15) |
| Opponent | Shooter | 36 | 69 (36) | 14 | 55 | 31 | 6% | 1.6 | 5 (8) | 85 (22) | 114 (6) | 65 (24) | 75 (12) |
| Opponent | War machine | 26 | 38 (26) | 38 | 0 | 39 | 12% | 1.1 | 40 (10) | 41 (12) | 24 (4) | 9 (6) | 46 (20) |
| Opponent | Wizard | 28 | 7 (28) | 7 | 0 | 30 | 11% | 2.6 | 0 (8) | 21 (10) | 0 (4) | 11 (8) | 7 (14) |

### Charged fights: gf-h2h-opp-0533c46-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 230 | 18 | 0.5 | 1.0 | 36 | 0 | +36 | 0 of 1 | 1 of 1 | - | +36 |
| Mine | Chaos Dwarfs | 8 | 254 | 88 | 0.9 | 1.0 | 100 | 27 | +73 | 4 of 7 | 2 of 7 | - | +73 |
| Mine | Dwarfen Mountain Holds | 11 | 373 | 32 | 1.3 | 1.1 | 25 | 13 | +12 | 6 of 14 | 7 of 14 | -65 | +18 |
| Mine | Empire of Man | 8 | 275 | 135 | 2.0 | 1.0 | 67 | 54 | +13 | 3 of 16 | 11 of 16 | - | +13 |
| Mine | Grand Cathay | 1 | 228 | 301 | 3.0 | 2.0 | 100 | 0 | +100 | 2 of 3 | 3 of 3 | +150 | +0 |
| Mine | High Elf Realms | 5 | 66 | 697 | 3.4 | 1.3 | 205 | 7 | +198 | 5 of 17 | 14 of 17 | +90 | +243 |
| Mine | Ogre Kingdoms | 1 | 65 | 497 | 4.0 | 1.0 | 124 | 0 | +124 | 1 of 4 | 1 of 4 | - | +124 |
| **Mine** | all armies | 36 | 262 | 179 | 1.7 | 1.1 | 104 | 22 | +82 | 21 of 62 | 39 of 62 | +86 | +81 |
| Opponent | Chaos Dwarfs | 1 | 314 | 0 | 3.0 | 1.3 | 0 | 0 | +0 | 3 of 3 | 3 of 3 | +0 | +0 |
| Opponent | Dwarfen Mountain Holds | 2 | 550 | 0 | 0.5 | 2.0 | 0 | 60 | -60 | 1 of 1 | 0 of 1 | -60 | - |
| Opponent | Empire of Man | 4 | 344 | 134 | 1.5 | 1.2 | 90 | 47 | +43 | 4 of 6 | 3 of 6 | +233 | +5 |
| Opponent | Grand Cathay | 1 | 180 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | High Elf Realms | 2 | 32 | 464 | 3.5 | 1.1 | 133 | 0 | +133 | 4 of 7 | 6 of 7 | +0 | +155 |
| Opponent | Lizardmen | 2 | 62 | 704 | 3.0 | 1.0 | 235 | 0 | +235 | 4 of 6 | 4 of 6 | - | +235 |
| Opponent | Ogre Kingdoms | 4 | 118 | 321 | 4.5 | 1.2 | 71 | 23 | +48 | 4 of 18 | 9 of 18 | +118 | +35 |
| Opponent | Orc & Goblin Tribes | 1 | 138 | 751 | 3.0 | 1.3 | 250 | 0 | +250 | 1 of 3 | 3 of 3 | +474 | +138 |
| Opponent | Skaven | 2 | 0 | 214 | 1.5 | 1.3 | 142 | 0 | +142 | 3 of 3 | 1 of 3 | +0 | +214 |
| Opponent | Tomb Kings of Khemri | 4 | 26 | 791 | 3.2 | 1.1 | 243 | 30 | +214 | 5 of 13 | 10 of 13 | +255 | +210 |
| Opponent | Vampire Counts | 3 | 0 | 199 | 3.7 | 1.4 | 54 | 21 | +33 | 4 of 11 | 7 of 11 | -4 | +54 |
| Opponent | Warriors of Chaos | 6 | 0 | 482 | 1.8 | 1.1 | 263 | 0 | +263 | 7 of 11 | 8 of 11 | +0 | +289 |
| Opponent | Wood Elf Realms | 4 | 41 | 146 | 1.5 | 1.3 | 97 | 17 | +80 | 2 of 6 | 5 of 6 | +41 | +100 |
| **Opponent** | all armies | 36 | 112 | 349 | 2.5 | 1.2 | 141 | 17 | +125 | 43 of 89 | 59 of 89 | +78 | +136 |

### Effective charges: gf-h2h-opp-0533c46-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 1 (net +36) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Chaos Dwarfs | 7 | 0 | 0 | 3 (net +40) | 2 (net +150) | 0 | 0 | 2 | 60% (3 of 5) |
| Mine | Dwarfen Mountain Holds | 14 | 5 (net +59) | 1 (net +0) | 1 (net -60) | 4 (net -16) | 0 | 2 (net +0) | 1 | 8% (1 of 13) |
| Mine | Empire of Man | 16 | 3 (net -291) | 0 | 3 (net +102) | 3 (net +99) | 3 (net +43) | 3 (net +116) | 1 | 20% (3 of 15) |
| Mine | Grand Cathay | 3 | 0 | 0 | 1 (net +0) | 0 | 1 (net +0) | 1 (net +301) | 0 | 33% (1 of 3) |
| Mine | High Elf Realms | 17 | 0 | 0 | 5 (net +109) | 5 (net +337) | 2 (net +76) | 4 (net +200) | 1 | 31% (5 of 16) |
| Mine | Ogre Kingdoms | 4 | 0 | 1 (net +287) | 0 | 2 (net +105) | 0 | 1 (net +0) | 0 | 0% (0 of 4) |
| Opponent | Chaos Dwarfs | 3 | 0 | 0 | 1 (net +0) | 1 (net +0) | 0 | 1 (net +0) | 0 | 33% (1 of 3) |
| Opponent | Dwarfen Mountain Holds | 1 | 1 (net -60) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Empire of Man | 6 | 3 (net -51) | 0 | 1 (net +91) | 2 (net +159) | 0 | 0 | 0 | 17% (1 of 6) |
| Opponent | Grand Cathay | 1 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | High Elf Realms | 7 | 0 | 0 | 1 (net +0) | 2 (net +370) | 2 (net +94) | 2 (net +0) | 0 | 14% (1 of 7) |
| Opponent | Lizardmen | 6 | 1 (net +138) | 0 | 1 (net +217) | 0 | 1 (net +240) | 2 (net +212) | 1 | 20% (1 of 5) |
| Opponent | Ogre Kingdoms | 18 | 5 (net +68) | 0 | 3 (net +34) | 3 (net +138) | 0 | 3 (net -26) | 4 | 21% (3 of 14) |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 0 | 0 | 0 | 1 (net +65) | 1 (net +474) | 1 | 0% (0 of 2) |
| Opponent | Skaven | 3 | 2 (net +0) | 0 | 1 (net +427) | 0 | 0 | 0 | 0 | 33% (1 of 3) |
| Opponent | Tomb Kings of Khemri | 13 | 1 (net +255) | 0 | 1 (net +158) | 2 (net +368) | 0 | 6 (net +134) | 3 | 10% (1 of 10) |
| Opponent | Vampire Counts | 11 | 2 (net -72) | 0 | 2 (net +84) | 3 (net +44) | 1 (net +126) | 1 (net +0) | 2 | 22% (2 of 9) |
| Opponent | Warriors of Chaos | 11 | 3 (net +263) | 0 | 4 (net +342) | 1 (net +230) | 0 | 2 (net +199) | 1 | 40% (4 of 10) |
| Opponent | Wood Elf Realms | 6 | 0 | 0 | 0 | 2 (net +82) | 1 (net +0) | 0 | 3 | 0% (0 of 3) |

### Charged fights, damage counted: gf-h2h-opp-0533c46-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 9 | 175 | 250 | -60 | 101 | 127 | -25 | -14.6 |
| Mine | 50-54% | 2 | 170 | 214 | +144 | 144 | 78 | +66 | +38.6 |
| Mine | Effective (55-75%) | 13 | 273 | 193 | +70 | 109 | 35 | +74 | +27.1 |
| Mine | 76-89% | 16 | 218 | 194 | +152 | 192 | 42 | +150 | +68.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 11 | 296 | 163 | +131 | 160 | 10 | +149 | +50.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 286 | 63 | +47 | 50 | 5 | +46 | +16.0 |
| Mine | No odds | 5 | 232 | 201 | +55 | 67 | 0 | +67 | +28.9 |
| Mine | All fights | 62 | 243 | 185 | +82 | 130 | 41 | +89 | +36.6 |
| Opponent | Long shot (under 50%) | 18 | 189 | 224 | +65 | 135 | 88 | +48 | +25.4 |
| Opponent | Effective (55-75%) | 16 | 248 | 208 | +158 | 184 | 31 | +153 | +61.8 |
| Opponent | 76-89% | 16 | 336 | 185 | +171 | 221 | 40 | +181 | +53.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 18 | 297 | 203 | +112 | 142 | 18 | +124 | +41.6 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 432 | 108 | +103 | 131 | 0 | +131 | +30.4 |
| Opponent | No odds | 15 | 189 | 190 | +135 | 153 | 24 | +129 | +68.6 |
| Opponent | All fights | 89 | 264 | 196 | +125 | 164 | 38 | +125 | +47.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gf-h2h-opp-0533c46-p4 | move | 417 | 85 (20%) | 50 (12%) | 43 (10%) | 289 (69%) |
| gf-h2h-opp-0533c46-p4 | objective | 344 | 59 (17%) | 40 (12%) | 38 (11%) | 247 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0122 |
| Charmed Shield | Opponent | L0525, L1525, L1526 |
| Elixir of Power | Opponent | L0519 |
| Fistful of Laurels | Mine | L1820 |
| Fistful of Laurels | Opponent | L0318, L0918, L1018, L1418 |
| Horn of the Wild Hunt | Opponent | L0533, L0633 |
| Invocation of Nehek | Opponent | L0525, L1525 |
| Opal Amulet | Mine | L1418 |
| Periapt of Soul Exchange | Opponent | L0521, L1820 |
| Ring of Doom | Mine | L0208, L1522, L1525, L1526 |
| Ring of Doom | Opponent | L0415, L0515, L0533, L0633 |
| Ring of Jet | Mine | L1018 |
| Ring of Jet | Opponent | L0610 |
| Standard of the Fell Warrior | Mine | L1322 |
| Storm Daemon (Renegade 2.0) | Opponent | L0521 |
| Twice-Blessed Armour | Mine | L0709, L0723, L0728, L0732, L1018 |
| Twice-Blessed Armour | Opponent | L0607, L0610 |
| Witch Hunter's Ward | Mine | L0709, L0723, L0728, L0732 |
| Witch Hunter's Ward | Opponent | L0208, L0607 |

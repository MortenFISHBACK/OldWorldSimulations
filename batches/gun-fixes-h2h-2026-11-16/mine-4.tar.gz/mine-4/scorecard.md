# Doctrine scorecard: gf-h2h-mine-0533c46-p4

### Scorecard: gf-h2h-mine-0533c46-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0208 | 4 | 1 | Mine | no | 0 | 4 | 2 | 1 | 0 | 0 | 0 | 30 |
| L0208 | 4 | 1 | Opponent | no | 0 | 2 | 1 | 0 | 0 | 0 | 0 | 560 |
| L0304 | 4 | 1 | Mine | no | 0 | 4 | 2 | 2 | 0 | 0 | 0 | 675 |
| L0304 | 4 | 1 | Opponent | no | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 124 |
| L0305 | 5 | 1 | Mine | no | - | - | 0 | 3 | 0 | 0 | 0 | 985 |
| L0305 | 5 | 1 | Opponent | no | - | - | 0 | 3 | 0 | 0 | 0 | 548 |
| L0306 | 6 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 675 |
| L0306 | 6 | 1 | Opponent | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 798 |
| L0309 | 3 | 1 | Mine | no | 7 | - | 1 | 1 | 0 | 0 | 0 | 770 |
| L0309 | 3 | 1 | Opponent | no | 7 | - | 0 | 3 | 0 | 0 | 0 | 420 |
| L0318 | 6 | 1 | Mine | no | 0 | 3 | 1 | 0 | 0 | 0 | 0 | 675 |
| L0318 | 6 | 1 | Opponent | no | 19 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0329 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 985 |
| L0329 | 5 | 1 | Opponent | yes | - | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L0335 | 5 | 1 | Mine | yes | - | - | 0 | 3 | 0 | 0 | 0 | 675 |
| L0335 | 5 | 1 | Opponent | yes | - | 3 | 1 | 5 | 0 | 0 | 0 | 140 |
| L0415 | 1 | 1 | Mine | no | 3 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0415 | 1 | 1 | Opponent | no | 1 | 2 | 2 | 1 | 2 | 0 | 0 | 0 |
| L0515 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 475 |
| L0515 | 5 | 1 | Opponent | yes | - | 2 | 1 | 0 | 1 | 0 | 0 | 0 |
| L0517 | 1 | 1 | Mine | no | 1 | - | 0 | 1 | 0 | 0 | 0 | 771 |
| L0517 | 1 | 1 | Opponent | no | 3 | 3 | 2 | 0 | 2 | 0 | 0 | 83 |
| L0519 | 3 | 1 | Mine | yes | 5 | 2 | 3 | 1 | 0 | 0 | 0 | 771 |
| L0519 | 3 | 1 | Opponent | yes | 2 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0521 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 548 |
| L0521 | 5 | 1 | Opponent | yes | - | - | 0 | 10 | 0 | 0 | 0 | 565 |
| L0525 | 3 | 1 | Mine | no | 0 | - | 1 | 1 | 0 | 0 | 0 | 1019 |
| L0525 | 3 | 1 | Opponent | no | 5 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0533 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 1120 |
| L0533 | 5 | 1 | Opponent | yes | - | 3 | 1 | 6 | 0 | 0 | 0 | 0 |
| L0607 | 1 | 1 | Mine | no | 0 | 6 | 2 | 1 | 0 | 0 | 0 | 615 |
| L0607 | 1 | 1 | Opponent | no | 0 | 5 | 1 | 1 | 0 | 0 | 0 | 420 |
| L0610 | 4 | 1 | Mine | no | 0 | - | 4 | 4 | 0 | 0 | 0 | 956 |
| L0610 | 4 | 1 | Opponent | no | 0 | 3 | 1 | 1 | 1 | 0 | 0 | 501 |
| L0629 | 5 | 1 | Mine | no | - | - | 1 | 2 | 0 | 0 | 0 | 798 |
| L0629 | 5 | 1 | Opponent | yes | - | 4 | 2 | 4 | 2 | 0 | 0 | 170 |
| L0633 | 3 | 1 | Mine | no | 0 | - | 1 | 2 | 1 | 0 | 0 | 801 |
| L0633 | 3 | 1 | Opponent | no | 0 | 3 | 3 | 4 | 0 | 0 | 0 | 236 |
| L0635 | 5 | 1 | Mine | no | - | 2 | 2 | 1 | 1 | 0 | 0 | 743 |
| L0635 | 5 | 1 | Opponent | yes | - | 3 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0709 | 1 | 1 | Mine | yes | 8 | 2 | 2 | 0 | 1 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | no | 0 | 2 | 0 | 1 | 0 | 0 | 0 | 726 |
| L0723 | 3 | 1 | Mine | yes | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 375 |
| L0723 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0728 | 2 | 1 | Mine | - | - | 3 | 1 | 2 | 0 | 0 | 0 | 375 |
| L0728 | 2 | 1 | Opponent | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0732 | 6 | 1 | Mine | no | 4 | 2 | 2 | 0 | 1 | 0 | 0 | 375 |
| L0732 | 6 | 1 | Opponent | no | 4 | 2 | 4 | 1 | 0 | 0 | 0 | 170 |
| L0917 | 5 | 1 | Mine | no | - | 4 | 1 | 0 | 0 | 0 | 0 | 515 |
| L0917 | 5 | 1 | Opponent | yes | - | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 16 | 5 | 3 | 1 | 0 | 0 | 0 | 370 |
| L0928 | 4 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 1212 |
| L0928 | 4 | 1 | Opponent | no | 8 | 3 | 3 | 1 | 0 | 0 | 0 | 111 |
| L0930 | 6 | 1 | Mine | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 950 |
| L0930 | 6 | 1 | Opponent | no | 10 | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1018 | 4 | 1 | Mine | no | 8 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1018 | 4 | 1 | Opponent | no | 0 | 3 | 6 | 0 | 2 | 0 | 0 | 228 |
| L1322 | 2 | 1 | Mine | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 302 |
| L1322 | 2 | 1 | Opponent | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | - | 6 | 1 | 0 | 0 | 0 | 0 |
| L1522 | 4 | 1 | Mine | no | 8 | 2 | 1 | 0 | 1 | 0 | 0 | 126 |
| L1522 | 4 | 1 | Opponent | no | 1 | 1 | 4 | 2 | 1 | 0 | 0 | 242 |
| L1525 | 1 | 1 | Mine | no | 1 | 1 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1525 | 1 | 1 | Opponent | no | 2 | 5 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1526 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1526 | 2 | 1 | Opponent | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1820 | 2 | 1 | Mine | - | - | 3 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1820 | 2 | 1 | Opponent | - | - | - | 2 | 3 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 13% | 2.1 | 2.7 | 1.8 | 1.1 | 0.1 | 0.0 | 0.0 | 541.3 |
| **Average** | | | Opponent | 30% | 3.7 | 2.6 | 2.4 | 2.1 | 0.4 | 0.0 | 0.0 | 178.1 |

### KPIs: gf-h2h-mine-0533c46-p4

Rules off - Opponent only: GUN FIGURES, GUN MASK, GUN VIEW, GUN THREAT, STAY WORTH, BEST MOVE FOR SHOOTERS, FACE THE CAST, WIZARD FRONT RANK, FIRE PLAN, FIRE IN ORDER, KEEPS THE TARGET, MISSILES IN THE FIRE PLAN, THREAT AT FULL SIZE, SHOOTERS ARE THREATS, SHOOTERS TO THE PRIMARY, EVERY WOUND COUNTS, HONEST THREAT, ONE YARDSTICK.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 51% (82 of 162) | 7% (12 of 162) | 29% (94 of 324) |
| Winner chose to follow up after the loser gave ground |  | 96% (53 of 55); on the table 96% | 100% (33 of 33); on the table 100% | 98% (86 of 88); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 60% (6 of 10); on the table 70% | 100% (11 of 11); on the table 100% | 81% (17 of 21); on the table 86% |
| Winner chose to pursue after the loser fled |  | 55% (6 of 11); on the table 82% | 62% (13 of 21); on the table 67% | 59% (19 of 32); on the table 72% |
| Winner chose to follow up or pursue (all three) |  | 86% (65 of 76); on the table 91% | 88% (57 of 65); on the table 89% | 87% (122 of 141); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 32% (75 of 234) | 40% (62 of 156) | 35% (137 of 390) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 52% (75 of 145) | 45% (56 of 125) | 49% (131 of 270) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 25% (18 of 72) | 26% (20 of 78) | 25% (38 of 150) |
|     round 1 |  | 33% (4 of 12) | 8% (1 of 13) | 20% (5 of 25) |
|     rounds 2+ |  | 23% (14 of 60) | 29% (19 of 65) | 26% (33 of 125) |
|   other wizards | 50%+ | 35% (57 of 162) | 50% (36 of 72) | 40% (93 of 234) |
|     round 1 |  | 52% (14 of 27) | 33% (4 of 12) | 46% (18 of 39) |
|     rounds 2+ |  | 32% (43 of 135) | 53% (32 of 60) | 38% (75 of 195) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 60% (3 of 5) | 57% (20 of 35) | 58% (23 of 40) |
| Points that never fought | lower | 50% (34962 of 70083) | 49% (35146 of 71988) | 49% (70108 of 142071) |
|   infantry points that never fought | lower | 56% (10035 of 17810) | 74% (10388 of 14065) | 64% (20423 of 31875) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 65% (196 of 303) | 62% (175 of 282) | 63% (371 of 585) |
| Bound items with a magic missile used (at least once a game) |  | 100% (13 of 13); 1.1 uses a game | 88% (15 of 17); 1.4 uses a game | 93% (28 of 30); 1.2 uses a game |
| Bound items with another spell used |  | 57% (8 of 14); 0.4 uses a game | 50% (1 of 2); 0.1 uses a game | 56% (9 of 16); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 27% (4 of 15); 0.1 uses a game | 33% (3 of 9); 0.1 uses a game | 29% (7 of 24); 0.1 uses a game |
|   their share of the points of units over 100 pts | lower | 58% (33216 of 57540) | 54% (33725 of 62687) | 56% (66941 of 120227) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.4 (32%) | 0.8 (31%) | 2.2 (32%) |
| MARCHED: its unit marched | 0.3 (8%) | 0.6 (23%) | 0.9 (13%) |
| CHARGED: its unit charged | 0.0 (1%) | 0.1 (4%) | 0.1 (2%) |
| IN COMBAT: engaged in combat | 1.1 (24%) | 0.5 (19%) | 1.6 (22%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.1 (5%) | 0.2 (3%) |
| FLEEING: fleeing | 0.3 (8%) | 0.0 (1%) | 0.4 (5%) |
| GONE: slain | 1.0 (23%) | 0.2 (6%) | 1.2 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.1 (3%) | 0.2 (9%) | 0.3 (5%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 2.8 | 1.2 | 1.8 | 3.8 | 0.4 | 1.3 |
| not cast | 3.2 | 2.2 | 2.6 | 7.0 | 1.0 | 14.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.5 (23%) | 0.1 (2%) | 2.2 (32%) | 0.3 (29%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.9 (13%) | 0.1 (14%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (10%) | 0.0 (1%) | 0.3 (11%) | 1.6 (22%) | 0.2 (17%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.5 (16%) | 0.6 (28%) | 0.2 (10%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.1 (3%) | 0.4 (5%) | 0.0 (0%) | 0.3 (2%) |
| GONE: slain | 0.7 (21%) | 0.5 (23%) | 0.6 (24%) | 1.2 (17%) | 0.0 (0%) | 2.1 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (3%) | 0.2 (9%) | 0.2 (9%) | 0.1 (1%) | 0.0 (0%) | 0.3 (2%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.2 (8%) | 0.0 (0%) | 0.0 (0%) | 0.4 (40%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (5%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.6 (51%) | 0.1 (5%) | 1.1 (42%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 10.6 (74%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.9 a game | 0.9 a game | 0.9 a game |
| stood (cast and not dispelled) | 62% (13 of 21) | 62% (13 of 21) | 62% (26 of 42) |
| the unit moved after it | 54% (7 of 13) | 38% (5 of 13) | 46% (12 of 26) |
| it charged on its next turn | 8% (1 of 13) | 8% (1 of 13) | 8% (2 of 26) |
| the enemy charged it first | 31% (4 of 13) | 8% (1 of 13) | 19% (5 of 26) |
| it fought by the end of its next turn | 8% (1 of 13) | 8% (1 of 13) | 8% (2 of 26) |
| it moved out of a charge the enemy had planned (not charged first) | 23% (3 of 13) | 8% (1 of 13) | 15% (4 of 26) |
| none of these (no charge, no fight, no charge escaped) | 38% (5 of 13) | 77% (10 of 13) | 58% (15 of 26) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 72% (967 of 1334) | 54% (502 of 922) | 65% (1469 of 2256) |
|   cavalry | 56% (28 of 50) | 55% (64 of 117) | 55% (92 of 167) |
|   character | 75% (163 of 217) | 40% (53 of 132) | 62% (216 of 349) |
|   chariot | 70% (84 of 120) | 53% (44 of 83) | 63% (128 of 203) |
|   infantry | 58% (200 of 345) | 52% (201 of 388) | 55% (401 of 733) |
|   monster | 63% (29 of 46) | 54% (32 of 59) | 58% (61 of 105) |
|   war machine | 83% (463 of 556) | 76% (108 of 143) | 82% (571 of 699) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.4 (23%) | 2.5 (21%) | 4.8 (22%) |
| CHARGED: it charged | 1.2 (12%) | 1.9 (16%) | 3.1 (14%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.2 (1%) | 0.4 (2%) |
| IN COMBAT: it fought this turn or the last | 0.7 (7%) | 0.6 (5%) | 1.3 (6%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 2.2 (21%) | 3.5 (30%) | 5.7 (26%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (4%) | 0.2 (2%) | 0.7 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.8 (17%) | 2.1 (18%) | 3.9 (18%) |
| SHELTERED: the target was sheltered | 0.4 (4%) | 0.3 (2%) | 0.7 (3%) |
| STUPIDITY | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR | 0.7 (7%) | 0.4 (3%) | 1.1 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.6 | 1.1 | 77% | 5.4 pts | 20 pts |
| character | 6.4 | 2.4 | 73% | 8.1 pts | 52 pts |
| chariot | 3.6 | 4.8 | 48% | 25.1 pts | 91 pts |
| infantry | 17.0 | 5.8 | 76% | 7.6 pts | 128 pts |
| monster | 2.2 | 0.6 | 82% | 6.8 pts | 15 pts |
| war machine | 16.3 | 12.6 | 62% | 21.1 pts | 343 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.1 | 5.1 | 4.1 |
| Charges that made contact a game | 2.4 | 3.3 | 2.9 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.38 declared, 0.31 contact (16 units) | 0.78 declared, 0.56 contact (9 units) | 0.52 declared, 0.40 contact (25 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 0.80 contact (5 units) | 0.71 declared, 0.71 contact (7 units) | 0.83 declared, 0.75 contact (12 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.46 declared, 0.35 contact (222 units) | 0.60 declared, 0.38 contact (287 units) | 0.54 declared, 0.37 contact (509 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 59% (30 of 51) | 40% (6 of 15) | 67% (6 of 9) | 56% (42 of 75) |
| Character in a unit | 89% (50 of 56) | 71% (15 of 21) | 0% (0 of 3) | 81% (65 of 80) |
| Character on its own | 86% (24 of 28) | 52% (11 of 21) | 18% (9 of 51) | 44% (44 of 100) |
| Chariot | 74% (14 of 19) | 48% (11 of 23) | - | 60% (25 of 42) |
| Infantry | 56% (50 of 89) | 67% (31 of 46) | 0% (0 of 2) | 59% (81 of 137) |
| Monster | 73% (19 of 26) | 67% (6 of 9) | - | 71% (25 of 35) |
| Monstrous | 100% (7 of 7) | 58% (11 of 19) | - | 69% (18 of 26) |
| War Machines | 78% (65 of 83) | 86% (6 of 7) | - | 79% (71 of 90) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 2 | 60% (3 of 5); on the table 80% | 37% (20 of 54) | 26% | 36% (4 of 11) | 100% (3 of 3); 5.0 uses a game | 100% (1 of 1); 0.5 uses a game | 67% (2 of 3); 1.0 uses a game |
| Chaos Dwarfs | 9 | 89% (8 of 9); on the table 100% | 36% (26 of 72) | 66% | 63% (44 of 70) | 0.0 uses a game | 0.0 uses a game | 29% (2 of 7); 0.2 uses a game |
| Dwarfen Mountain Holds | 13 | 80% (12 of 15); on the table 80% | - | 71% | 77% (84 of 109) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 12 | 64% (7 of 11); on the table 64% | 42% (40 of 96) | 48% | 67% (85 of 127) | 0.0 uses a game | 60% (3 of 5); 0.8 uses a game | 0% (0 of 6); 0.0 uses a game |
| Grand Cathay | 2 | 82% (9 of 11); on the table 100% | 33% (18 of 54) | 40% | 50% (10 of 20) | 100% (4 of 4); 9.0 uses a game | 50% (1 of 2); 0.5 uses a game | 0% (0 of 2); 0.0 uses a game |
| High Elf Realms | 7 | 96% (27 of 28); on the table 96% | 17% (3 of 18) | 25% | 48% (25 of 52) | 100% (11 of 11); 3.3 uses a game | 50% (4 of 8); 1.0 uses a game | 0.0 uses a game |
| Lizardmen | 2 | 100% (4 of 4); on the table 100% | - | 52% | 64% (9 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 5 | 100% (13 of 13); on the table 100% | 0% (0 of 18) | 35% | 71% (25 of 35) | 100% (5 of 5); 3.2 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (4 of 4); on the table 100% | 17% (1 of 6) | 16% | 25% (2 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 2 | - | 33% (4 of 12) | 61% | 62% (10 of 16) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Tomb Kings of Khemri | 4 | 80% (4 of 5); on the table 80% | 0% (0 of 6) | 39% | 40% (8 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 3 | 100% (8 of 8); on the table 100% | 42% (10 of 24) | 20% | 53% (9 of 17) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 6 | 74% (14 of 19); on the table 79% | 58% (7 of 12) | 43% | 52% (22 of 42) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
| Wood Elf Realms | 4 | 100% (9 of 9); on the table 100% | 44% (8 of 18) | 67% | 77% (34 of 44) | 67% (4 of 6); 4.2 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gf-h2h-mine-0533c46-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 44% (29) | 43% (20) | 44% (49) |
| ...free all their last turn and able to turn (per game) | 0.61 | 0.31 | 0.92 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.14 | 0.14 | 0.28 |
| ...with the charger already in that arc before they moved (per game) | 0.50 | 0.25 | 0.75 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.81 | 1.00 | 2.81 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.61 | 1.08 | 1.69 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 4.58 | 4.11 | 8.69 |

### Quality by phase: gf-h2h-mine-0533c46-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.1 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 57% (56 of 98) | 42% (67 of 161) |
| Strategy | Shoot objectives carried out (shot that target) | 41% (295 of 716) | 49% (136 of 275) |
| Strategy | Close-in objectives charged next turn | 20% (25 of 125) | 13% (25 of 189) |
| Strategy | Support requests answered (helper made contact too) | 67% (10 of 15) | 50% (15 of 30) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | 100% (5 of 5) |
| Strategy | Hexes on a unit its side charged or shot that turn | 25% (1 of 4) | 88% (7 of 8) |
| Strategy | Joined characters whose unit fought | 30% (19 of 64) | 24% (12 of 49) |
| Strategy | Lone characters that fought | 72% (56 of 78) | 76% (54 of 71) |
| Movement | Charges halted short of contact | 0.1 | 0.1 |
| Movement | Idle units | 1.1 | 2.1 |
| Movement | Points that never moved of their own | 541.3 | 178.1 |
| Movement | Fights charged into per game | 2.0 | 2.8 |
| Movement | Charges with odds: long shots (under 50%) | 10 of 67, net -18 | 20 of 78, net +108 |
| Movement | Charges with odds: sweet spot (55-75%) | 14 of 67, net +130 | 13 of 78, net +52 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 8 of 67, net +77 | 10 of 78, net +116 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 18 of 67, net +15 | 12 of 78, net +174 |
| Shooting | Shots by shooting units (incl. breath weapons) | 14.8 | 12.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (229 of 533) | 44% (194 of 440) |
| Shooting | Points destroyed by shooting units | 157.2 | 30.9 |
| Shooting | War machine shots | 12.9 | 3.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 47% (219 of 463) | 44% (54 of 123) |
| Shooting | Points destroyed by war machines | 81.5 | 56.2 |
| Magic | Magic missiles cast | 1.1 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 40% (16 of 40) | 43% (16 of 37) |
| Magic | Wounds caused by magic missiles | 2.2 | 1.3 |
| Magic | Wounds caused by other spells | 1.1 | 0.8 |
| Magic | Points destroyed by magic (all spells) | 36.5 | 14.8 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.2 / 0.2 / 0.6 / 0.1 | 1.8 / 0.3 / 0.3 / 0.1 |
| Combat | Points destroyed in combat | 247.3 | 303.6 |
| Combat | Points run down | 17.0 | 157.1 |
| Combat | Net points per charged fight, damage counted | +79 | +118 |
| Combat | Net per 100 charger points, damage counted | +30.4 | +39.0 |
| Combat | First round won (charged fights) | 75% | 64% |
| Combat | Net points per charged fight | +75 | +118 |
| Combat | Net points per supported fight / lone fight | +99 / +70 | +133 / +115 |
| Combat | Charged fights on a top-3 enemy unit | 27 of 72 | 51 of 101 |
| Game | Points lost | 682.9 | 589.9 |
| Game | VP from objectives | 455.0 | 667.2 |
| Game | Lone holders (player turns) | 2.1 | 3.7 |

- Mine won / drew / lost: 11 / 4 / 21 of 36 ended games (of 36); mean margin (Mine - Opponent) -330 VP
- The side that went first won 16 of 32 games with a winner
- Points traded per game (both sides' losses): 1273
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gf-h2h-mine-0533c46-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| ARRIVAL HUNT | 0.0 | +3.0 | 0.0 | 0.0 | 0.1 | +4.4 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 3.2 | +0.0 | 0.0 | 52.4 | 0.7 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.7 | +5.0 | 0.0 | 15.3 | 0.7 | +5.6 | 0.0 | 7.9 |
| BEST FACING | 0.8 | +43.4 | 0.0 | 30.2 | 0.6 | +22.2 | 0.0 | 23.2 |
| BEST FIRST | 4.2 | +194.8 | 201.5 | 76.4 | 4.7 | +172.0 | 108.6 | 69.6 |
| BEST MOVE FOR SHOOTERS | 0.9 | +42.1 | 0.0 | 27.3 | - | - | - | - |
| BEST OVERALL | 0.7 | +62.0 | 0.0 | 23.9 | 0.6 | +41.0 | 0.0 | 18.8 |
| BEST PREY | 0.3 | +11.5 | 10.1 | 9.7 | 0.7 | +22.0 | 10.7 | 0.0 |
| BEST PRIZE | 0.0 | -1.0 | 0.0 | 0.0 | 0.1 | -1.2 | 2.6 | 0.0 |
| BIG CHARACTER SAFETY | 0.0 | +0.1 | 0.0 | 0.0 | 0.2 | -0.9 | 0.0 | 24.7 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 3.8 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.4 | +0.1 | 0.0 | 1.8 | 0.4 | +8.2 | 0.0 | 7.0 |
| BLOWS WHERE AIMED | 0.2 | -12.2 | 22.4 | 9.3 | 0.3 | -57.0 | 28.5 | 30.2 |
| BOMBING RUN | 0.1 | +0.9 | 0.5 | 1.7 | - | - | - | - |
| CANNON PLAN MISSED | - | - | - | - | 0.2 | +0.0 | 50.6 | 2.6 |
| CANNON PLANNED TARGET | - | - | - | - | 2.4 | +169.5 | 187.7 | 23.1 |
| CANNON SIGHT KEPT | 2.3 | +0.0 | 0.0 | 5.4 | 0.4 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.2 | +0.0 | 13.0 | 0.0 | 0.2 | -4.0 | 6.5 | 15.4 |
| CAST JOB | 0.8 | +19.4 | 17.3 | 20.0 | 0.4 | +5.9 | 7.5 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +8.9 | 21.7 | 0.0 | 0.2 | +4.2 | 1.7 | 0.0 |
| CASTS AFTER FRIENDS | 0.5 | +0.0 | 0.0 | 33.9 | 0.6 | +0.0 | 0.0 | 11.2 |
| CASTS FROM BEHIND | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | - | - | - | - | 0.1 | +1.1 | 0.0 | 0.0 |
| CATCH ODDS | 0.0 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 0.2 | -0.2 | 3.5 | 0.0 |
| CHARGE BAND | 0.1 | +0.0 | 10.6 | 9.5 | 0.1 | +0.0 | 3.4 | 0.0 |
| CHARGE NOW FIRST | 1.5 | +0.0 | 152.2 | 37.5 | 2.4 | +0.0 | 233.1 | 27.0 |
| CHARGE NOW WEIGHED | 0.4 | -43.3 | 6.4 | 0.0 | 0.4 | -22.2 | 0.0 | 17.2 |
| CHARGER SLAIN LOST | 0.5 | -13.0 | 36.8 | 9.7 | 0.8 | -25.8 | 63.8 | 17.6 |
| CHARIOT WIZARD CAREFUL | 0.0 | -0.3 | 5.4 | 0.0 | 0.2 | -3.8 | 0.0 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 1.4 | 0.2 | +0.0 | 17.9 | 0.0 |
| COMBAT PIVOT | 0.2 | +0.0 | 16.6 | 40.6 | 0.3 | +0.0 | 10.4 | 12.8 |
| CONVEYANCE SEARCH | 0.4 | +47.6 | 0.0 | 20.4 | 0.5 | +40.1 | 22.3 | 22.5 |
| COUNTER-CHARGE COVER | 11.0 | +885.7 | 0.0 | 217.7 | 6.2 | +513.7 | 0.0 | 165.4 |
| DEFENSIVE ARMY | 0.5 | +0.0 | 106.1 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.2 | +1.7 | 6.9 | 5.6 | 0.4 | +5.1 | 30.2 | 0.0 |
| ENGINEER BY LORE | 0.4 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EVERY WOUND COUNTS | 19.0 | +0.0 | 907.8 | 366.1 | - | - | - | - |
| FACE THE CAST | 0.1 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.8 | +222.0 | 0.0 | 71.0 | 1.0 | +61.5 | 0.0 | 55.2 |
| FALLBACK BY WORTH | 4.0 | +58.8 | 0.0 | 30.8 | 6.0 | +47.1 | 0.0 | 83.5 |
| FIGHT LIFT | 0.1 | +0.1 | 1.7 | 0.0 | 0.1 | +0.9 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.1 | +0.3 | 0.0 | 1.7 | - | - | - | - |
| FIRE IN ORDER | 1.6 | +0.0 | 93.0 | 38.1 | - | - | - | - |
| FIRE PLAN | 30.1 | +176.2 | 1302.2 | 461.2 | - | - | - | - |
| FLANK NOT WEIGHED | 4.9 | +0.0 | 0.0 | 111.8 | 3.8 | +0.0 | 0.0 | 122.5 |
| FOCUS FIRE | - | - | - | - | 0.0 | +0.4 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.9 | +104.4 | 0.0 | 8.0 | 0.6 | +70.8 | 0.0 | 17.4 |
| FRIENDS SHOTS CHECKED | 0.3 | +21.4 | 0.0 | 8.0 | 0.1 | +6.5 | 0.0 | 0.0 |
| GIVES UP | 0.0 | -0.9 | 7.1 | 0.0 | 0.2 | -1.5 | 25.3 | 0.0 |
| GROUND FLIERS | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 4.5 | +84.6 | 288.2 | 47.8 | - | - | - | - |
| GUN MASK | 0.8 | +7.8 | 0.0 | 27.9 | - | - | - | - |
| GUN THREAT | 2.9 | +360.8 | 211.2 | 62.4 | - | - | - | - |
| GUN VIEW | 1.7 | +7.9 | 0.0 | 2.8 | - | - | - | - |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 0.0 | 1.7 | 0.0 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | 0.3 | +0.0 | 39.4 | 6.9 | 0.5 | +0.0 | 43.3 | 2.0 |
| HILL BY ITS CHANCE | 0.3 | -27.6 | 0.0 | 0.0 | 0.4 | -57.2 | 0.0 | 1.5 |
| HOLDS AMBUSHERS | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| HONEST THREAT | 19.0 | +2613.1 | 907.8 | 366.1 | - | - | - | - |
| HONEST WORTH | 6.4 | -88.4 | 224.0 | 117.0 | 9.3 | -220.3 | 456.2 | 202.0 |
| HUNT ADVANCE | 0.1 | +6.6 | 3.8 | 2.9 | 0.2 | +7.4 | 21.7 | 0.9 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 2.9 | 0.2 | +0.0 | 24.3 | 2.0 |
| HUNT IN PAIRS | 0.1 | +5.6 | 0.0 | 0.0 | 0.8 | +45.8 | 0.0 | 7.1 |
| HUNT KEPT | 0.0 | +2.1 | 3.8 | 0.0 | 0.2 | +2.7 | 20.1 | 5.9 |
| HUNT RESULT | 0.2 | +4.8 | 0.0 | 5.2 | 0.6 | +72.7 | 40.4 | 8.1 |
| HUNT THE GUNS | 0.2 | +54.8 | 3.8 | 5.2 | 0.6 | +196.1 | 48.5 | 3.9 |
| INVITES THE FIGHT | 1.5 | +35.5 | 57.8 | 37.6 | 1.2 | +21.5 | 39.4 | 13.2 |
| JOINT CHARGE PLAN | 0.2 | +21.0 | 6.5 | 0.0 | 0.3 | +15.2 | 0.0 | 9.5 |
| JOINT KNOWS CHALLENGE | 0.1 | -5.6 | 0.0 | 5.2 | 0.1 | -2.1 | 16.0 | 0.0 |
| KEEP FALLS | 0.0 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.0 | +0.2 | 0.0 | 0.0 | 0.1 | +1.2 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.4 | +41.7 | 121.1 | 31.9 | 1.8 | +54.2 | 201.7 | 41.2 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| KEEPS THE TARGET | 1.7 | -81.2 | 104.2 | 47.2 | - | - | - | - |
| KILLS COUNT | 0.8 | +41.6 | 73.5 | 15.0 | 2.4 | +107.8 | 220.0 | 22.0 |
| KILLS COUNT NEXT TURN | 4.1 | +132.7 | 123.0 | 82.3 | 5.9 | +204.3 | 180.8 | 161.8 |
| LONE CHARACTER SAFE SPOT | 0.3 | +13.1 | 0.0 | 3.3 | 0.2 | +5.3 | 1.0 | 2.5 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.4 | +15.3 | 0.0 | 0.0 | 0.4 | +31.2 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | +0.3 | 20.1 | 9.2 | 0.5 | -6.1 | 18.8 | 1.4 |
| LOST CHARGE | 2.6 | -40.1 | 102.8 | 74.6 | 2.3 | -33.7 | 69.5 | 41.1 |
| LURE BY WHAT IT DRAWS | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 0.8 | +50.4 | 6.5 | 20.2 | 0.6 | +54.3 | 0.0 | 5.8 |
| MANOEUVRE | 0.4 | +19.2 | 0.0 | 2.9 | 0.2 | +9.9 | 0.0 | 12.5 |
| MARCH AT ESCAPER | 0.1 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.3 | +18.1 | 0.0 | 0.0 | 0.5 | +13.0 | 0.0 | 16.5 |
| MARCH ODDS | 0.2 | +9.5 | 5.4 | 0.0 | 0.2 | +7.8 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.4 | +41.5 | 0.0 | 11.1 | 0.3 | +0.8 | 0.0 | 8.2 |
| MAX FOR POSITIONING | 3.9 | +101.7 | 0.0 | 66.6 | 4.6 | +182.0 | 0.0 | 132.6 |
| MISSILES IN THE FIRE PLAN | 1.4 | +7.2 | 74.2 | 29.9 | - | - | - | - |
| MISSILES IN THE MOVE | 3.3 | +69.5 | 0.0 | 70.1 | 3.2 | +50.3 | 0.0 | 68.8 |
| MISSILES NEXT TURN | 3.8 | +44.0 | 0.0 | 88.6 | 3.9 | +36.6 | 0.0 | 68.8 |
| MODEL FACING | 0.7 | +172.0 | 0.0 | 11.7 | 0.0 | +7.6 | 0.0 | 1.7 |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 8.2 | 10.6 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.4 | +8.4 | 0.0 | 10.6 | 0.4 | +7.5 | 0.0 | 4.4 |
| MOVE SPELL IN RANGE | 0.3 | +6.1 | 0.0 | 12.9 | 0.0 | +0.5 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.3 | -11.1 | 16.0 | 12.9 | 0.4 | -10.3 | 0.0 | 2.6 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 11.1 | 0.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 2.8 | +184.0 | 74.9 | 54.2 | 5.0 | +317.1 | 148.0 | 127.9 |
| MOVES UNITS SPELL | 0.1 | +2.1 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +19.3 | 7.6 | 0.0 | 0.1 | +1.1 | 4.5 | 0.0 |
| NO RALLY LEFT | 0.0 | +13.4 | 0.0 | 0.0 | 0.0 | +4.2 | 0.0 | 0.0 |
| NOT NEEDED | 0.1 | -2.7 | 0.0 | 0.0 | 0.2 | -14.6 | 49.3 | 1.2 |
| NOT TURNED | 4.6 | +80.7 | 0.0 | 103.5 | 4.1 | +60.9 | 0.0 | 156.5 |
| NOT WORTH A CAST | 0.1 | -0.1 | 0.0 | 21.1 | 0.3 | -0.3 | 0.0 | 13.2 |
| OFF BEST | 15.7 | -711.7 | 4.7 | 278.7 | 14.6 | -798.5 | 9.4 | 237.2 |
| ONE YARDSTICK | 29.4 | -1387.2 | 767.5 | 476.8 | - | - | - | - |
| OPENS A LANE | 0.1 | +0.2 | 0.0 | 0.0 | 0.1 | +0.9 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.2 | +17.0 | 14.1 | 13.3 |
| OVERRUN THREAT | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.2 | +1.0 | 18.4 | 6.3 | 0.4 | +4.0 | 14.4 | 1.4 |
| PATHS CROSS | 1.1 | +50.9 | 0.0 | 10.6 | 3.0 | +160.5 | 0.0 | 67.3 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +4.9 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -3.8 | 0.0 | 2.4 | 0.1 | -1.6 | 0.0 | 15.4 |
| PLAN RESULT | 41.2 | +1831.4 | 1325.9 | 934.2 | 38.5 | +1027.3 | 1177.8 | 826.7 |
| PURSUES BIG PREY | 0.0 | -7.7 | 0.0 | 0.0 | 0.1 | -4.6 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.1 | +0.9 | 0.0 | 0.0 | 1.0 | +5.2 | 0.0 | 17.9 |
| RANDOM MOVER NO PROMISE | 0.1 | -4.5 | 0.0 | 0.0 | 0.2 | -5.9 | 8.6 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.4 | -3.7 | 0.0 | 8.8 |
| REDIRECT COUNTER | 1.1 | +86.1 | 0.0 | 17.5 | 2.3 | +236.2 | 0.0 | 31.6 |
| REDIRECT WEIGHED | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +7.2 | 14.0 | 0.0 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 30.3 |
| RESERVE FALL BACK | 0.0 | +0.9 | 0.0 | 0.0 | 0.8 | +14.4 | 0.0 | 5.1 |
| RESTRAINS TO SHOOT | 0.1 | +6.4 | 0.0 | 0.0 | 0.2 | +7.7 | 0.0 | 4.0 |
| RISK BY ARC | 1.8 | +65.8 | 129.9 | 45.7 | 2.6 | +54.9 | 201.9 | 26.1 |
| SAFER THAN THE JOB | 0.6 | +23.8 | 0.0 | 13.5 | 1.1 | +60.2 | 0.0 | 15.6 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.0 | 0.6 | +2.4 | 0.0 | 0.9 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.9 |
| SCREEN BY WHAT IT SAVES | 0.1 | -1.8 | 0.0 | 0.0 | 0.4 | -26.9 | 0.0 | 4.6 |
| SEARCH SPOT | 1.9 | +83.5 | 0.0 | 22.4 | 2.4 | +119.7 | 0.0 | 58.4 |
| SECOND HUNTER | 0.0 | -0.8 | 0.0 | 1.4 | 0.1 | -1.0 | 10.4 | 0.9 |
| SELF MOVE SPELL | 0.5 | +64.8 | 0.0 | 0.0 | 0.4 | +53.2 | 0.0 | 21.9 |
| SET UP TOGETHER | 1.2 | +83.3 | 14.8 | 37.5 | 2.3 | +219.3 | 0.0 | 51.5 |
| SET-UP ANY TARGET | 0.2 | +33.3 | 0.0 | 10.6 | 0.2 | +29.8 | 14.8 | 22.5 |
| SET-UP MISSED | 0.1 | +12.1 | 0.0 | 0.0 | 0.1 | +11.3 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.1 | -0.2 | 0.0 | 0.0 |
| SHOOTERS ARE THREATS | 5.0 | +274.4 | 231.2 | 116.4 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.8 | +1.4 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTERS TO THE PRIMARY | 4.3 | +78.0 | 0.0 | 40.0 | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 1.0 | +40.6 | 35.3 | 5.7 | 1.2 | +20.5 | 39.4 | 13.6 |
| SHORT GUN FORWARD | 0.4 | +0.0 | 0.0 | 3.3 | 0.1 | +0.0 | 0.0 | 0.0 |
| SHOT OPTIONS | 24.9 | +0.0 | 1026.1 | 431.4 | 14.1 | +0.0 | 368.0 | 317.1 |
| SHOT REPLANNED | - | - | - | - | 0.6 | +0.0 | 92.1 | 6.7 |
| SHOTS IN THE MOVE | 24.2 | +1030.3 | 0.0 | 373.8 | 12.5 | +489.1 | 0.0 | 234.0 |
| SPELL CATCH ODDS | 0.1 | -0.3 | 0.0 | 9.9 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.2 | +33.3 | 0.0 | 10.6 | 0.2 | +29.8 | 14.8 | 22.5 |
| SPELL WORTH | 0.3 | +4.1 | 29.3 | 32.1 | 1.4 | +22.8 | 29.0 | 25.1 |
| SPELLS IN THE FIGHT | 0.4 | -3.5 | 58.6 | 0.0 | 0.8 | -15.1 | 50.3 | 40.4 |
| STABLE ROLE | 12.4 | +0.0 | 450.1 | 146.1 | 10.4 | +0.0 | 268.6 | 182.8 |
| STANDS TO CAST | 0.1 | +5.6 | 0.0 | 0.0 | - | - | - | - |
| STAY WEIGHED | 0.0 | +0.7 | 0.0 | 0.0 | 0.0 | +14.7 | 0.0 | 0.0 |
| STAY WORTH | 31.1 | +130.2 | 634.6 | 366.9 | - | - | - | - |
| STOPS | 0.1 | +7.6 | 3.8 | 2.4 | 0.4 | +10.2 | 40.0 | 3.9 |
| STOPS SHORT OF THE FLANK | 0.3 | +17.4 | 0.0 | 6.9 | 0.4 | +12.3 | 0.0 | 5.1 |
| STUCK PIVOT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 3.6 | -30.8 | 208.1 | 37.2 | 5.4 | -31.5 | 283.4 | 89.4 |
| SUPPORTS | 2.3 | +37.7 | 96.8 | 20.8 | 3.3 | +31.5 | 131.4 | 60.4 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -0.8 | 1.7 | 0.0 | 0.1 | -2.3 | 0.0 | 12.0 |
| SURE REACH TOGETHER | 0.8 | +0.8 | 6.5 | 7.5 | 0.5 | +5.3 | 0.0 | 6.6 |
| THROUGH LINE OF FIRE | 0.6 | +18.3 | 0.0 | 21.3 | 0.2 | +7.5 | 0.0 | 6.3 |
| TURN WORTH | 0.1 | -4.7 | 10.2 | 0.0 | 0.2 | -24.1 | 33.1 | 0.0 |
| TWO OR MORE ARRIVE | 0.2 | +4.6 | 6.5 | 5.2 | 0.8 | +6.4 | 0.0 | 6.1 |
| WAIT AFTER COSTS | 6.3 | -296.0 | 158.2 | 114.9 | 7.8 | -421.0 | 191.0 | 190.5 |
| WALKS TO THE FIGHT | 1.7 | +28.9 | 26.1 | 17.5 | 1.1 | +14.9 | 1.8 | 26.7 |
| WAR ENGINE CHARGES | 0.1 | +10.6 | 13.2 | 0.0 | 0.0 | +0.7 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 1.1 | +0.0 | 80.2 | 27.8 | 0.4 | +0.0 | 15.2 | 23.5 |
| WEARS DOWN | 1.2 | +47.9 | 94.2 | 26.5 | 0.9 | +43.6 | 78.3 | 38.7 |
| WHO HITS BACK | 0.2 | +10.5 | 0.0 | 15.4 | 0.1 | +8.9 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.2 | +9.4 | 23.7 | 2.9 | 0.2 | +10.8 | 31.6 | 3.4 |
| WHOLE FIGHT GAIN | 0.4 | +21.6 | 24.9 | 7.3 | 0.7 | +46.8 | 55.5 | 7.8 |
| WIDER SPREAD | 1.8 | -3.8 | 159.1 | 35.7 | 3.2 | -3.6 | 287.8 | 46.2 |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |

### Rule changes: gf-h2h-mine-0533c46-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1089 | 1089 | 1089 | 30.25 | -54366 | -49.9 |
| BEST FIRST | 322 | 322 | 322 | 8.94 | +13208 | +41.0 |
| FIRE PLAN | 1084 | 1084 | 273 | 7.58 | +3082 | +11.3 |
| EVERY WOUND COUNTS | 685 | 685 | 182 | 5.06 | +0 | +0.0 |
| SHOTS IN THE MOVE | 1323 | 928 | 162 | 4.50 | +5028 | +31.0 |
| SEARCH SPOT | 154 | 154 | 154 | 4.28 | +7317 | +47.5 |
| MOVE TO CHARGE | 282 | 282 | 149 | 4.14 | +6891 | +46.2 |
| COUNTER-CHARGE COVER | 620 | 360 | 148 | 4.11 | +8494 | +57.4 |
| PATHS CROSS | 148 | 148 | 148 | 4.11 | +7611 | +51.4 |
| ARTILLERY RE-ROLL WEIGHED | 140 | 140 | 140 | 3.89 | +0 | +0.0 |
| KILLS COUNT NEXT TURN | 362 | 362 | 125 | 3.47 | +3560 | +28.5 |
| ONE YARDSTICK | 1057 | 535 | 124 | 3.44 | +1158 | +9.3 |
| FACES THE THREAT | 101 | 101 | 101 | 2.81 | +10209 | +101.1 |
| CANNON SIGHT KEPT | 99 | 99 | 99 | 2.75 | +0 | +0.0 |
| SUPPORTS | 203 | 203 | 74 | 2.06 | +792 | +10.7 |
| FALLBACK BY WORTH | 359 | 359 | 73 | 2.03 | +3812 | +52.2 |
| WAIT AFTER COSTS | 508 | 508 | 64 | 1.78 | +1205 | +18.8 |
| SET UP TOGETHER | 128 | 112 | 63 | 1.75 | +4491 | +71.3 |
| SAFER THAN THE JOB | 61 | 61 | 61 | 1.69 | +3023 | +49.6 |
| FIRE IN ORDER | 57 | 57 | 57 | 1.58 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 54 | 54 | 54 | 1.50 | +6309 | +116.8 |
| WALKS TO THE FIGHT | 100 | 100 | 53 | 1.47 | +684 | +12.9 |
| HONEST THREAT | 685 | 685 | 51 | 1.42 | +0 | +0.0 |
| BEST OVERALL | 48 | 48 | 48 | 1.33 | +3710 | +77.3 |
| BEST FACING | 47 | 47 | 47 | 1.31 | +2361 | +50.2 |
| SCOUT WAITS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 40 | 40 | 40 | 1.11 | +72 | +1.8 |
| STAY WORTH | 1118 | 954 | 35 | 0.97 | +467 | +13.3 |
| MAX FOR POSITIONING | 309 | 188 | 33 | 0.92 | +543 | +16.4 |
| SHOOTS FROM THE BEST SPOT | 78 | 78 | 33 | 0.92 | +765 | +23.2 |
| BEST MOVE FOR SHOOTERS | 32 | 32 | 32 | 0.89 | +1514 | +47.3 |
| CHARGE NOW WEIGHED | 31 | 31 | 31 | 0.86 | +2040 | +65.8 |
| CHARGE NOW FIRST | 141 | 141 | 29 | 0.81 | -1309 | -45.1 |
| MISSILES IN THE MOVE | 236 | 146 | 29 | 0.81 | +436 | +15.0 |
| MOVE AND CAST | 29 | 29 | 29 | 0.81 | +572 | +19.7 |
| REDIRECT COUNTER | 123 | 66 | 29 | 0.81 | +2742 | +94.6 |
| RESERVE FALL BACK | 29 | 29 | 29 | 0.81 | +553 | +19.1 |
| ADVANCE LANE KEPT | 28 | 28 | 28 | 0.78 | +0 | +0.0 |
| BLOCKED WHEEL | 28 | 28 | 28 | 0.78 | +298 | +10.7 |
| MARCH CHECK | 30 | 29 | 28 | 0.78 | +872 | +31.1 |
| LONE WIZARD KEPT IN | 27 | 27 | 27 | 0.75 | +1675 | +62.0 |
| THROUGH LINE OF FIRE | 27 | 27 | 27 | 0.75 | +930 | +34.5 |
| KEEPS THE TARGET | 62 | 62 | 26 | 0.72 | -3264 | -125.5 |
| MODEL FACING | 26 | 26 | 26 | 0.72 | +6463 | +248.6 |
| KILLS COUNT | 114 | 108 | 24 | 0.67 | +1321 | +55.0 |
| RISK BY ARC | 159 | 147 | 24 | 0.67 | +908 | +37.8 |
| STOPS SHORT OF THE FLANK | 24 | 24 | 24 | 0.67 | +1070 | +44.6 |
| MAKE SURE TOGETHER | 50 | 39 | 23 | 0.64 | +1618 | +70.3 |
| RANDOM MOVE BY FIGURES | 40 | 40 | 23 | 0.64 | +220 | +9.6 |
| MANOEUVRE | 23 | 23 | 22 | 0.61 | +1048 | +47.7 |
| HONEST WORTH | 566 | 557 | 21 | 0.58 | +170 | +8.1 |
| COMBAT PIVOT | 20 | 20 | 20 | 0.56 | +0 | +0.0 |
| SHOT REPLANNED | 20 | 20 | 20 | 0.56 | +0 | +0.0 |
| GUN VIEW | 60 | 60 | 19 | 0.53 | +285 | +15.0 |
| HOLDS AMBUSHERS | 19 | 19 | 19 | 0.53 | +0 | +0.0 |
| SHORT GUN FORWARD | 19 | 19 | 19 | 0.53 | +0 | +0.0 |
| INVITES THE FIGHT | 97 | 97 | 18 | 0.50 | +291 | +16.2 |
| KEEPS ITS TARGET | 115 | 113 | 18 | 0.50 | +307 | +17.1 |
| SHOOTERS ARE THREATS | 181 | 181 | 17 | 0.47 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 16 | 16 | 16 | 0.44 | +1006 | +62.9 |
| MARCH ODDS | 16 | 16 | 16 | 0.44 | +208 | +13.0 |
| REDIRECT WEIGHED | 14 | 14 | 14 | 0.39 | +1016 | +72.5 |
| CAST JOB | 42 | 42 | 13 | 0.36 | +142 | +11.0 |
| WAR ENGINE JOBS | 53 | 53 | 13 | 0.36 | -555 | -42.7 |
| WEARS DOWN | 75 | 70 | 13 | 0.36 | +526 | +40.5 |
| WHOLE FIGHT GAIN | 40 | 30 | 12 | 0.33 | +500 | +41.6 |
| REFUSING RETIRES | 29 | 29 | 11 | 0.31 | -2 | -0.2 |
| WHO HITS BACK | 11 | 11 | 11 | 0.31 | +437 | +39.7 |
| BEST PREY | 35 | 35 | 10 | 0.28 | +186 | +18.6 |
| CANNON PLANNED TARGET | 88 | 88 | 9 | 0.25 | -478 | -53.1 |
| CHAFF PASSED | 9 | 9 | 9 | 0.25 | -7 | -0.8 |
| GUN THREAT | 105 | 105 | 9 | 0.25 | +0 | +0.0 |
| RESTRAINS TO SHOOT | 9 | 9 | 9 | 0.25 | +507 | +56.4 |
| CASTING BLOCK | 14 | 14 | 8 | 0.22 | +111 | +13.9 |
| HUNT IN PAIRS | 29 | 20 | 8 | 0.22 | +908 | +113.5 |
| MISSILES NEXT TURN | 277 | 162 | 8 | 0.22 | +15 | +1.9 |
| PIVOT GUARDS FLANK | 8 | 8 | 8 | 0.22 | -194 | -24.3 |
| BIG CHARACTER SAFETY | 7 | 7 | 7 | 0.19 | -31 | -4.5 |
| CHARGE BAND | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| JOINT CHARGE PLAN | 18 | 18 | 7 | 0.19 | +394 | +56.3 |
| LOST CHARGE | 178 | 178 | 7 | 0.19 | +80 | +11.5 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +96 | +13.7 |
| SURE REACH TOGETHER | 46 | 33 | 7 | 0.19 | +69 | +9.8 |
| KEEPS SCOUTS OR AMBUSH | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| OPENS UP | 7 | 7 | 6 | 0.17 | +177 | +29.4 |
| SHOOTERS TO THE PRIMARY | 154 | 116 | 6 | 0.17 | +74 | +12.4 |
| STUCK PIVOT | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| WHOLE FIGHT | 15 | 14 | 6 | 0.17 | +211 | +35.2 |
| DEFENSIVE ARMY | 18 | 18 | 5 | 0.14 | -164 | -32.9 |
| HUNT ADVANCE | 14 | 14 | 5 | 0.14 | +129 | +25.8 |
| PURSUES BIG PREY | 5 | 5 | 5 | 0.14 | -441 | -88.2 |
| STOPS | 17 | 16 | 5 | 0.14 | +351 | +70.2 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 6 | 6 | 4 | 0.11 | -10 | -2.6 |
| STANDS TO CAST | 4 | 4 | 4 | 0.11 | +20 | +4.9 |
| SUPPORT NARROWED | 326 | 326 | 4 | 0.11 | -61 | -15.3 |
| SURE CHARGE BEATS ADVANCE | 4 | 4 | 4 | 0.11 | -110 | -27.6 |
| BEST PRIZE | 3 | 3 | 3 | 0.08 | -83 | -27.5 |
| BLOCKED CHARGE SKIPPED | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| CARRIES OUT SET-UP | 12 | 12 | 3 | 0.08 | -143 | -47.6 |
| EDGE GIVE GROUND | 21 | 19 | 3 | 0.08 | +16 | +5.2 |
| NEEDED THERE | 4 | 4 | 3 | 0.08 | +0 | +0.0 |
| SPELLS IN THE FIGHT | 42 | 36 | 3 | 0.08 | +35 | +11.6 |
| TWO OR MORE ARRIVE | 38 | 35 | 3 | 0.08 | +9 | +3.1 |
| BACKUP TARGETS | 50 | 25 | 2 | 0.06 | +4 | +1.9 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +34 | +16.9 |
| FACE THE CAST | 2 | 2 | 2 | 0.06 | +37 | +18.5 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +12 | +5.9 |
| GUN MASK | 28 | 15 | 2 | 0.06 | +28 | +14.2 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +579 | +289.7 |
| OVERRUNS AWAY | 20 | 18 | 2 | 0.06 | +10 | +5.2 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +176 | +88.0 |
| REDIRECT BY WHAT IT STOPS | 15 | 15 | 2 | 0.06 | +71 | +35.4 |
| STAY WEIGHED | 2 | 2 | 2 | 0.06 | +555 | +277.4 |
| WAR ENGINE CHARGES | 6 | 6 | 2 | 0.06 | +204 | +101.9 |
| WIDER SPREAD | 183 | 170 | 2 | 0.06 | +2 | +1.0 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -25 | -24.6 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +14 | +13.7 |
| KEEP FALLS | 1 | 1 | 1 | 0.03 | +43 | +43.1 |
| LONG SHOT | 29 | 26 | 1 | 0.03 | +32 | +31.8 |
| MISSILES IN THE FIRE PLAN | 49 | 5 | 1 | 0.03 | +15 | +14.8 |
| ARRIVAL HUNT | 5 | 5 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 21 | 18 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 9 | 9 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 37 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARGER SLAIN LOST | 44 | 39 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 10 | 10 | 0 | 0.00 | - | - |
| CHEAP HELPER | 9 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 32 | not checked | - | - | - | - |
| ENGINEER BY LORE | 14 | 14 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 313 | not checked | - | - | - | - |
| GIVES UP | 8 | 7 | 0 | 0.00 | - | - |
| GROUND FLIERS | 3 | not checked | - | - | - | - |
| GUN FIGURES | 162 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 30 | 25 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 28 | 28 | 0 | 0.00 | - | - |
| HUNT DROPPED | 10 | trace | - | - | - | - |
| HUNT KEPT | 10 | trace | - | - | - | - |
| HUNT RESULT | 26 | trace | - | - | - | - |
| HUNT THE GUNS | 26 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 7 | 4 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 19 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 25 | 25 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 14 | 14 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 12 | 7 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 25 | trace | - | - | - | - |
| MOVE SPELL SPOT | 7 | not checked | - | - | - | - |
| NOT NEEDED | 11 | 11 | 0 | 0.00 | - | - |
| NOT TURNED | 313 | 313 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 15 | not checked | - | - | - | - |
| OPENS A LANE | 6 | 2 | 0 | 0.00 | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 2870 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 8 | 8 | 0 | 0.00 | - | - |
| SCOUT SPOT | 35 | 35 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 17 | 17 | 0 | 0.00 | - | - |
| SECOND HUNTER | 5 | 5 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 30 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 16 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOT OPTIONS | 1404 | 1404 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 2 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 16 | not checked | - | - | - | - |
| SPELL WORTH | 59 | not checked | - | - | - | - |
| STABLE ROLE | 820 | 818 | 0 | 0.00 | - | - |
| TURN WORTH | 12 | 12 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: gf-h2h-mine-0533c46-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.36 | 12.78 | 51.2 |
| FALLBACK | gate | 0.50 | 0.94 | 41.2 |
| CHARGE NOW FIRST | rule | 0.22 | 0.58 | 45.1 |
| TURN GATE | gate | 0.31 | 0.33 | 51.5 |
| FIRE PLAN | rule | 0.61 | - | 103.0 |
| KEEPS THE TARGET | rule | 0.56 | - | 204.7 |
| SUPPORT REQUEST | gate | 0.14 | 0.22 | 45.2 |
| WAR ENGINE JOBS | rule | 0.17 | 0.17 | 46.2 |
| LONE CHARACTER SAFE SPOT | gate | 0.17 | 0.11 | 22.0 |
| CHARGE NOW WEIGHED | rule | 0.08 | 0.14 | 45.6 |
| PIVOT GUARDS FLANK | rule | 0.08 | 0.14 | 24.3 |
| AFTERMATH BAND | gate | 0.08 | 0.08 | 3.0 |
| BIG CHARACTER SAFETY | rule | - | 0.14 | 13.7 |
| CANNON PLANNED TARGET | rule | - | 0.14 | 99.5 |
| DEFENSIVE ARMY | rule | 0.14 | - | 32.9 |
| PURSUES BIG PREY | rule | 0.03 | 0.11 | 88.2 |
| BLOCKED WHEEL | rule | 0.08 | 0.03 | 11.6 |
| CHAFF PASSED | rule | - | 0.11 | 1.7 |
| MARCH ODDS | rule | 0.03 | 0.08 | 6.7 |
| SUPPORT NARROWED | rule | - | 0.11 | 15.3 |
| SURE CHARGE BEATS ADVANCE | rule | 0.06 | 0.06 | 27.6 |
| BEST PRIZE | rule | 0.03 | 0.06 | 27.5 |
| CARRIES OUT SET-UP | rule | - | 0.08 | 47.6 |
| FIGHT ORDER BAND | gate | 0.06 | 0.03 | 2.3 |
| PATHS CROSS | rule | 0.03 | 0.06 | 11.6 |
| THROUGH LINE OF FIRE | rule | 0.08 | - | 14.5 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | 0.03 | 78.9 |
| FACES THE THREAT | rule | - | 0.06 | 11.5 |
| RULE SWITCHED OFF | gate | - | 0.06 | 17.5 |
| STANDS TO CAST | rule | 0.06 | - | 20.1 |
| STOPS SHORT OF THE FLANK | rule | - | 0.06 | 18.2 |
| CATCH ODDS | rule | 0.03 | - | 24.6 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | - | 4.9 |
| LONE WIZARD HOLDS BACK | rule | - | 0.03 | 10.3 |
| MOVE AND CAST | rule | - | 0.03 | 1.9 |
| NO REASON | gate | 0.03 | - | 10.1 |
| SAFER THAN THE JOB | rule | - | 0.03 | 9.1 |

### Plans: gf-h2h-mine-0533c46-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 10.7 | 18% | 392 | 375 | 96% |
| Mine | charge | 2.2 | 49% | 209 | 173 | 83% |
| Mine | close in | 3.5 | 23% | 211 | 105 | 50% |
| Mine | hold | 4.5 | 39% | 299 | 0 | 0% |
| Mine | join | 0.7 | 92% | 17 | 0 | 0% |
| Mine | shoot | 17.2 | 62% | 505 | 1179 | 234% |
| Mine | support | 2.4 | 91% | 22 | 0 | 0% |
| Opponent | advance | 13.2 | 13% | 379 | 236 | 62% |
| Opponent | charge | 4.1 | 56% | 288 | 385 | 134% |
| Opponent | close in | 5.2 | 21% | 343 | 120 | 35% |
| Opponent | hold | 5.1 | 48% | 391 | 0 | 0% |
| Opponent | join | 0.4 | 92% | 9 | 0 | 0% |
| Opponent | shoot | 6.2 | 56% | 205 | 301 | 147% |
| Opponent | support | 3.9 | 89% | 24 | 0 | 0% |

### Packages: hunt the guns, gf-h2h-mine-0533c46-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.2 | 6 | 0 | 17% | 17% | 0% | 3.0 | 329 | 29 | 17% | 54 |
| Opponent | 0.6 | 20 | 0 | 35% | 45% | 0% | 2.8 | 353 | 131 | 35% | 118 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 2.5 | 5 | 0 | 20% | 20% | 0% | 3.0 | 319 | 34 | 20% | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 75 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 72 |
| Empire of Man | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 375 | 0 | 0% | 72 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 130 |
| High Elf Realms | 0.3 | 2 | 0 | 0% | 0% | 0% | - | 371 | 0 | 0% | 30 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 175 |
| Ogre Kingdoms | 1.4 | 7 | 0 | 71% | 57% | 0% | 2.5 | 362 | 175 | 57% | 94 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 693 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 72 |
| Tomb Kings of Khemri | 2.2 | 9 | 0 | 0% | 33% | 0% | 3.7 | 327 | 71 | 11% | 18 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.3 | 2 | 0 | 100% | 100% | 0% | 2.0 | 420 | 378 | 100% | 210 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 60 |

### Battle groups: gf-h2h-mine-0533c46-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 11.0 | 23% | 60% | 13% | 50% | 35% | 6% | 10% | 48% | 0% |
| Mine | REDIRECT COUNTER | 1.1 | 29% | 92% | 8% | 100% | 27% | 0% | 27% | 45% | 0% |
| Opponent | COUNTER-CHARGE COVER | 6.2 | 23% | 54% | 10% | 20% | 43% | 17% | 4% | 36% | 0% |
| Opponent | REDIRECT COUNTER | 2.3 | 17% | 79% | 21% | 67% | 27% | 0% | 0% | 64% | 9% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gf-h2h-mine-0533c46-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 2 | 0 (2) | 0 | 0 | 0 | 0% | 5.0 | - | 0 (2) | - | - | 0 (2) |
| Mine | Chaff | 13 | 103 (13) | 87 | 16 | 61 | 46% | 2.4 | 146 (6) | 56 (4) | 68 (3) | 136 (10) | 0 (3) |
| Mine | Character | 123 | 38 (123) | 38 | 0 | 34 | 21% | 2.4 | 40 (45) | 44 (55) | 17 (11) | 41 (69) | 38 (42) |
| Mine | Clean-up | 22 | 71 (22) | 23 | 48 | 37 | 32% | 2.9 | 94 (5) | 73 (11) | 51 (6) | 94 (17) | 6 (5) |
| Mine | Fast | 6 | 0 (6) | 0 | 0 | 70 | 17% | 1.2 | - | 0 (5) | 0 (1) | 0 (5) | 0 (1) |
| Mine | Fast Hammer | 36 | 33 (36) | 25 | 9 | 46 | 17% | 2.5 | 14 (15) | 54 (15) | 26 (6) | 37 (30) | 19 (6) |
| Mine | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Hammer | 69 | 39 (69) | 26 | 13 | 31 | 26% | 2.1 | 12 (15) | 47 (45) | 46 (9) | 51 (43) | 21 (26) |
| Mine | Holder | 12 | 91 (12) | 0 | 91 | 13 | 67% | 4.2 | 0 (4) | 98 (7) | 396 (1) | 154 (7) | 6 (5) |
| Mine | Shooter | 52 | 68 (52) | 20 | 48 | 45 | 2% | 1.8 | 58 (11) | 64 (30) | 95 (11) | 73 (30) | 60 (22) |
| Mine | War machine | 113 | 32 (113) | 32 | 0 | 37 | 4% | 1.2 | 42 (40) | 30 (64) | 6 (9) | 41 (33) | 28 (80) |
| Mine | Wizard | 19 | 9 (19) | 9 | 0 | 43 | 37% | 3.3 | 24 (5) | 5 (10) | 0 (3) | 31 (4) | 3 (14) |
| Opponent | Blocker | 2 | 177 (2) | 177 | 0 | 0 | 50% | 5.0 | 177 (2) | - | - | 177 (2) | - |
| Opponent | Chaff | 72 | 66 (72) | 16 | 51 | 45 | 44% | 2.6 | 63 (30) | 64 (13) | 72 (29) | 85 (48) | 33 (24) |
| Opponent | Character | 93 | 59 (93) | 58 | 1 | 20 | 22% | 2.5 | 54 (37) | 66 (45) | 53 (7) | 56 (54) | 65 (35) |
| Opponent | Clean-up | 33 | 18 (33) | 4 | 15 | 16 | 36% | 3.0 | 16 (13) | 17 (17) | 39 (3) | 15 (24) | 27 (9) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 50 | 0% | 4.5 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Fast | 5 | 0 (5) | 0 | 0 | 100 | 60% | 2.0 | - | 0 (4) | 0 (1) | 0 (3) | 0 (2) |
| Opponent | Fast Hammer | 39 | 46 (39) | 27 | 19 | 39 | 44% | 3.1 | 35 (15) | 70 (15) | 24 (9) | 49 (28) | 38 (11) |
| Opponent | Fragile | 12 | 0 (12) | 0 | 0 | 29 | 92% | 5.0 | 0 (3) | 0 (7) | 0 (2) | 0 (3) | 0 (9) |
| Opponent | Hammer | 58 | 23 (58) | 16 | 7 | 50 | 36% | 2.0 | 0 (13) | 29 (40) | 16 (5) | 18 (30) | 28 (28) |
| Opponent | Holder | 30 | 85 (30) | 14 | 71 | 14 | 37% | 2.5 | 137 (5) | 90 (18) | 33 (7) | 125 (15) | 37 (15) |
| Opponent | Shooter | 33 | 76 (33) | 26 | 50 | 23 | 12% | 1.4 | 14 (8) | 93 (21) | 123 (4) | 69 (22) | 85 (11) |
| Opponent | War machine | 26 | 63 (26) | 63 | 0 | 30 | 8% | 1.5 | 19 (6) | 85 (18) | 0 (2) | 110 (6) | 49 (20) |
| Opponent | Wizard | 28 | 8 (28) | 8 | 0 | 43 | 7% | 1.9 | 0 (8) | 6 (9) | 41 (4) | 22 (9) | 0 (12) |

### Charged fights: gf-h2h-mine-0533c46-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 22 | 246 | 3.5 | 1.3 | 70 | 39 | +31 | 5 of 7 | 4 of 7 | -17 | +51 |
| Mine | Chaos Dwarfs | 8 | 283 | 180 | 0.8 | 1.2 | 240 | 16 | +224 | 3 of 6 | 4 of 6 | +176 | +233 |
| Mine | Dwarfen Mountain Holds | 11 | 366 | 8 | 0.9 | 1.2 | 8 | 12 | -4 | 4 of 10 | 5 of 10 | -30 | +3 |
| Mine | Empire of Man | 8 | 291 | 125 | 1.5 | 1.2 | 83 | 96 | -13 | 5 of 12 | 7 of 12 | +0 | -15 |
| Mine | Grand Cathay | 1 | 537 | 974 | 6.0 | 1.3 | 162 | 0 | +162 | 3 of 6 | 5 of 6 | +487 | +0 |
| Mine | High Elf Realms | 5 | 115 | 711 | 5.2 | 1.1 | 137 | 14 | +122 | 5 of 26 | 25 of 26 | +217 | +114 |
| Mine | Ogre Kingdoms | 1 | 130 | 535 | 5.0 | 2.0 | 107 | 129 | -22 | 2 of 5 | 4 of 5 | -102 | +30 |
| **Mine** | all armies | 36 | 275 | 224 | 2.0 | 1.2 | 112 | 37 | +75 | 27 of 72 | 54 of 72 | +99 | +70 |
| Opponent | Chaos Dwarfs | 1 | 85 | 219 | 2.0 | 1.5 | 110 | 0 | +110 | 2 of 2 | 2 of 2 | +219 | +0 |
| Opponent | Dwarfen Mountain Holds | 2 | 338 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 4 | 280 | 105 | 1.0 | 1.5 | 105 | 129 | -24 | 3 of 4 | 3 of 4 | +233 | -110 |
| Opponent | Grand Cathay | 1 | 505 | 286 | 1.0 | 1.0 | 286 | 0 | +286 | 1 of 1 | 1 of 1 | - | +286 |
| Opponent | High Elf Realms | 2 | 184 | 80 | 3.0 | 1.0 | 27 | 0 | +27 | 2 of 6 | 4 of 6 | - | +27 |
| Opponent | Lizardmen | 2 | 0 | 940 | 4.5 | 1.1 | 209 | 16 | +193 | 5 of 9 | 7 of 9 | +0 | +218 |
| Opponent | Ogre Kingdoms | 4 | 28 | 158 | 5.0 | 1.2 | 32 | 14 | +17 | 6 of 20 | 8 of 20 | -11 | +24 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 612 | 2.0 | 2.0 | 306 | 0 | +306 | 2 of 2 | 1 of 2 | +612 | +0 |
| Opponent | Skaven | 2 | 48 | 0 | 1.0 | 1.0 | 0 | 18 | -18 | 0 of 2 | 0 of 2 | - | -18 |
| Opponent | Tomb Kings of Khemri | 4 | 26 | 697 | 3.8 | 1.1 | 186 | 63 | +123 | 8 of 15 | 11 of 15 | +112 | +125 |
| Opponent | Vampire Counts | 3 | 0 | 783 | 3.7 | 1.3 | 213 | 9 | +205 | 4 of 11 | 7 of 11 | +164 | +220 |
| Opponent | Warriors of Chaos | 6 | 14 | 644 | 3.3 | 1.1 | 193 | 15 | +179 | 11 of 20 | 15 of 20 | +132 | +184 |
| Opponent | Wood Elf Realms | 4 | 131 | 257 | 2.2 | 1.0 | 114 | 0 | +114 | 7 of 9 | 6 of 9 | - | +114 |
| **Opponent** | all armies | 36 | 102 | 396 | 2.8 | 1.2 | 141 | 23 | +118 | 51 of 101 | 65 of 101 | +133 | +115 |

### Effective charges: gf-h2h-mine-0533c46-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 7 | 3 (net -91) | 0 | 2 (net +195) | 1 (net +102) | 0 | 1 (net +0) | 0 | 29% (2 of 7) |
| Mine | Chaos Dwarfs | 6 | 1 (net +0) | 0 | 1 (net +0) | 1 (net +1029) | 1 (net +176) | 1 (net -61) | 1 | 20% (1 of 5) |
| Mine | Dwarfen Mountain Holds | 10 | 4 (net -30) | 0 | 0 | 1 (net +0) | 0 | 5 (net +17) | 0 | 0% (0 of 10) |
| Mine | Empire of Man | 12 | 2 (net +108) | 0 | 3 (net +88) | 4 (net -55) | 1 (net +60) | 2 (net -238) | 0 | 25% (3 of 12) |
| Mine | Grand Cathay | 6 | 0 | 1 (net +0) | 2 (net +117) | 2 (net +370) | 0 | 0 | 1 | 40% (2 of 5) |
| Mine | High Elf Realms | 26 | 0 | 1 (net +185) | 5 (net +178) | 5 (net +88) | 6 (net +63) | 6 (net +146) | 3 | 22% (5 of 23) |
| Mine | Ogre Kingdoms | 5 | 0 | 0 | 1 (net +38) | 1 (net +0) | 0 | 3 (net -50) | 0 | 20% (1 of 5) |
| Opponent | Chaos Dwarfs | 2 | 0 | 0 | 2 (net +110) | 0 | 0 | 0 | 0 | 100% (2 of 2) |
| Opponent | Empire of Man | 4 | 1 (net -479) | 0 | 1 (net +186) | 1 (net -36) | 1 (net +233) | 0 | 0 | 25% (1 of 4) |
| Opponent | Grand Cathay | 1 | 0 | 0 | 0 | 1 (net +286) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | High Elf Realms | 6 | 1 (net +0) | 0 | 0 | 2 (net +32) | 1 (net +0) | 0 | 2 | 0% (0 of 4) |
| Opponent | Lizardmen | 9 | 2 (net +328) | 1 (net +259) | 0 | 1 (net +95) | 1 (net +229) | 2 (net +298) | 2 | 0% (0 of 7) |
| Opponent | Ogre Kingdoms | 20 | 3 (net +44) | 1 (net +0) | 4 (net +13) | 4 (net +0) | 1 (net +0) | 1 (net +0) | 6 | 29% (4 of 14) |
| Opponent | Orc & Goblin Tribes | 2 | 1 (net +0) | 0 | 0 | 1 (net +612) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Skaven | 2 | 1 (net -35) | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 50% (1 of 2) |
| Opponent | Tomb Kings of Khemri | 15 | 3 (net +52) | 1 (net +0) | 0 | 3 (net +157) | 1 (net +65) | 3 (net +246) | 4 | 0% (0 of 11) |
| Opponent | Vampire Counts | 11 | 3 (net +266) | 0 | 1 (net +95) | 1 (net +199) | 3 (net +124) | 2 (net +0) | 1 | 10% (1 of 10) |
| Opponent | Warriors of Chaos | 20 | 4 (net +200) | 0 | 3 (net +42) | 4 (net +329) | 2 (net +132) | 4 (net +188) | 3 | 18% (3 of 17) |
| Opponent | Wood Elf Realms | 9 | 1 (net +128) | 0 | 1 (net +0) | 2 (net +310) | 0 | 0 | 5 | 25% (1 of 4) |

### Charged fights, damage counted: gf-h2h-mine-0533c46-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 10 | 142 | 308 | -18 | 47 | 72 | -25 | -17.2 |
| Mine | 50-54% | 2 | 174 | 241 | +92 | 92 | 0 | +92 | +53.2 |
| Mine | Effective (55-75%) | 14 | 265 | 211 | +130 | 160 | 20 | +141 | +53.2 |
| Mine | 76-89% | 15 | 220 | 205 | +139 | 206 | 81 | +125 | +57.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 18 | 249 | 213 | +15 | 128 | 98 | +29 | +11.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 442 | 99 | +77 | 103 | 14 | +89 | +20.2 |
| Mine | No odds | 5 | 380 | 132 | +122 | 132 | 0 | +132 | +34.7 |
| Mine | All fights | 72 | 260 | 206 | +75 | 136 | 57 | +79 | +30.4 |
| Opponent | Long shot (under 50%) | 20 | 290 | 230 | +108 | 219 | 93 | +125 | +43.2 |
| Opponent | 50-54% | 3 | 302 | 325 | +86 | 86 | 0 | +86 | +28.6 |
| Opponent | Effective (55-75%) | 13 | 204 | 167 | +52 | 72 | 34 | +38 | +18.6 |
| Opponent | 76-89% | 20 | 353 | 218 | +181 | 200 | 36 | +163 | +46.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 12 | 396 | 239 | +174 | 196 | 20 | +176 | +44.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 10 | 486 | 113 | +116 | 140 | 18 | +122 | +25.1 |
| Opponent | No odds | 23 | 201 | 167 | +85 | 111 | 20 | +91 | +45.4 |
| Opponent | All fights | 101 | 304 | 197 | +118 | 157 | 39 | +118 | +39.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gf-h2h-mine-0533c46-p4 | move | 405 | 91 (22%) | 64 (16%) | 48 (12%) | 266 (66%) |
| gf-h2h-mine-0533c46-p4 | objective | 314 | 50 (16%) | 40 (13%) | 44 (14%) | 220 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0122 |
| Charmed Shield | Opponent | L0525, L1525, L1526 |
| Elixir of Power | Opponent | L0519 |
| Fistful of Laurels | Mine | L1820 |
| Fistful of Laurels | Opponent | L0318, L0918, L1018, L1418 |
| Horn of the Wild Hunt | Opponent | L0533, L0633 |
| Invocation of Nehek | Opponent | L0525, L1525 |
| Opal Amulet | Mine | L1418 |
| Periapt of Soul Exchange | Opponent | L0521, L1820 |
| Ring of Doom | Mine | L0208, L1522, L1525, L1526 |
| Ring of Doom | Opponent | L0415, L0515, L0533, L0633 |
| Ring of Jet | Mine | L1018 |
| Ring of Jet | Opponent | L0610 |
| Standard of the Fell Warrior | Mine | L1322 |
| Storm Daemon (Renegade 2.0) | Opponent | L0521 |
| Twice-Blessed Armour | Mine | L0709, L0723, L0728, L0732, L1018 |
| Twice-Blessed Armour | Opponent | L0607, L0610 |
| Witch Hunter's Ward | Mine | L0709, L0723, L0728, L0732 |
| Witch Hunter's Ward | Opponent | L0208, L0607 |

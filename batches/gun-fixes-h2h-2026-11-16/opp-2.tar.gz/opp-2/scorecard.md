# Doctrine scorecard: gf-h2h-opp-0533c46-p2

### Scorecard: gf-h2h-opp-0533c46-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0312 | 6 | 1 | Mine | no | 2 | 4 | 2 | 0 | 0 | 0 | 0 | 675 |
| L0312 | 6 | 1 | Opponent | no | 10 | 3 | 0 | 1 | 0 | 0 | 0 | 330 |
| L0314 | 2 | 1 | Mine | - | - | 2 | 3 | 1 | 0 | 0 | 0 | 590 |
| L0314 | 2 | 1 | Opponent | - | - | 1 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0334 | 4 | 1 | Mine | no | 0 | - | 1 | 0 | 0 | 0 | 0 | 590 |
| L0334 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 4 | 0 | 0 | 0 | 216 |
| L0407 | 5 | 1 | Mine | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0407 | 5 | 1 | Opponent | no | - | 5 | 1 | 2 | 1 | 0 | 0 | 893 |
| L0518 | 2 | 1 | Mine | - | - | 2 | 0 | 0 | 0 | 0 | 0 | 836 |
| L0518 | 2 | 1 | Opponent | - | - | 4 | 1 | 2 | 0 | 0 | 0 | 413 |
| L0520 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 1258 |
| L0520 | 4 | 1 | Opponent | no | 0 | - | 2 | 4 | 1 | 0 | 0 | 210 |
| L0524 | 2 | 1 | Mine | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 799 |
| L0524 | 2 | 1 | Opponent | - | - | 4 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0527 | 5 | 1 | Mine | no | - | 3 | 0 | 0 | 0 | 0 | 0 | 698 |
| L0527 | 5 | 1 | Opponent | yes | - | 2 | 1 | 5 | 0 | 0 | 0 | 208 |
| L0531 | 3 | 1 | Mine | no | 2 | - | 0 | 0 | 0 | 0 | 0 | 1128 |
| L0531 | 3 | 1 | Opponent | yes | 6 | - | 1 | 2 | 2 | 0 | 0 | 340 |
| L0609 | 3 | 1 | Mine | no | 0 | 4 | 0 | 2 | 1 | 0 | 0 | 615 |
| L0609 | 3 | 1 | Opponent | no | 0 | 2 | 1 | 2 | 0 | 0 | 0 | 420 |
| L0618 | 6 | 1 | Mine | no | 0 | 6 | 0 | 2 | 1 | 0 | 0 | 615 |
| L0618 | 6 | 1 | Opponent | no | 0 | - | 1 | 1 | 0 | 0 | 0 | 234 |
| L0622 | 4 | 1 | Mine | no | 0 | - | 2 | 1 | 0 | 0 | 0 | 1197 |
| L0622 | 4 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 1 | 0 | 0 | 55 |
| L0626 | 2 | 1 | Mine | - | - | 3 | 3 | 0 | 0 | 0 | 0 | 615 |
| L0626 | 2 | 1 | Opponent | - | - | 2 | 4 | 5 | 0 | 0 | 0 | 0 |
| L0630 | 6 | 1 | Mine | no | 0 | - | 1 | 1 | 0 | 0 | 0 | 981 |
| L0630 | 6 | 1 | Opponent | no | 7 | 5 | 0 | 2 | 1 | 0 | 0 | 0 |
| L0715 | 1 | 1 | Mine | no | 8 | 2 | 3 | 1 | 0 | 0 | 0 | 375 |
| L0715 | 1 | 1 | Opponent | no | 5 | 1 | 3 | 1 | 0 | 0 | 0 | 115 |
| L0718 | 4 | 1 | Mine | no | 0 | 3 | 3 | 0 | 0 | 0 | 0 | 420 |
| L0718 | 4 | 1 | Opponent | no | 0 | 4 | 2 | 2 | 1 | 0 | 0 | 0 |
| L0720 | 6 | 1 | Mine | yes | 0 | 1 | 4 | 0 | 0 | 0 | 0 | 375 |
| L0720 | 6 | 1 | Opponent | no | 1 | - | 2 | 1 | 0 | 0 | 0 | 420 |
| L0724 | 4 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 530 |
| L0724 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0809 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 807 |
| L0809 | 5 | 1 | Opponent | no | - | - | 0 | 2 | 0 | 0 | 0 | 420 |
| L0818 | 2 | 1 | Mine | - | - | 6 | 0 | 1 | 0 | 0 | 0 | 769 |
| L0818 | 2 | 1 | Opponent | - | - | 1 | 3 | 2 | 2 | 0 | 0 | 370 |
| L0823 | 1 | 1 | Mine | no | 1 | 2 | 2 | 0 | 1 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 1 | 0 | 0 | 70 |
| L0913 | 1 | 1 | Mine | no | 6 | 1 | 2 | 1 | 0 | 0 | 0 | 704 |
| L0913 | 1 | 1 | Opponent | no | 12 | 2 | 2 | 1 | 0 | 0 | 0 | 140 |
| L0915 | 3 | 1 | Mine | no | 0 | 2 | 1 | 0 | 0 | 0 | 0 | 647 |
| L0915 | 3 | 1 | Opponent | yes | 8 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0916 | 4 | 1 | Mine | no | 0 | 3 | 3 | 0 | 0 | 0 | 0 | 934 |
| L0916 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 1 | 0 | 0 | 200 |
| L0925 | 1 | 1 | Mine | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 420 |
| L0925 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0934 | 4 | 1 | Mine | no | 1 | 1 | 2 | 1 | 0 | 0 | 0 | 828 |
| L0934 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 5 | 1 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 3 | 1 | 0 | 1 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | - | 1 | 2 | 0 | 0 | 0 | 0 |
| L1215 | 3 | 1 | Mine | no | 1 | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1215 | 3 | 1 | Opponent | yes | 5 | 1 | 2 | 0 | 1 | 0 | 0 | 176 |
| L1222 | 4 | 1 | Mine | no | 5 | 2 | 5 | 0 | 0 | 0 | 0 | 524 |
| L1222 | 4 | 1 | Opponent | no | 3 | 2 | 8 | 2 | 0 | 0 | 0 | 127 |
| L1533 | 3 | 1 | Mine | no | 5 | 2 | 3 | 1 | 0 | 0 | 0 | 126 |
| L1533 | 3 | 1 | Opponent | no | 0 | 1 | 5 | 1 | 0 | 0 | 0 | 144 |
| L1535 | 5 | 1 | Mine | yes | - | 2 | 0 | 0 | 1 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 3 | 3 | 0 | 0 | 0 | 0 | 110 |
| L1722 | 6 | 1 | Mine | no | 2 | 6 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1722 | 6 | 1 | Opponent | no | 1 | 2 | 8 | 0 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Mine | no | 2 | 4 | 3 | 0 | 1 | 0 | 0 | 185 |
| L1819 | 1 | 1 | Opponent | no | 4 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1832 | 2 | 1 | Mine | - | - | 1 | 3 | 0 | 0 | 0 | 0 | 251 |
| L1832 | 2 | 1 | Opponent | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 170 |
| L2122 | 4 | 1 | Mine | yes | 4 | 3 | 1 | 6 | 1 | 0 | 0 | 200 |
| L2122 | 4 | 1 | Opponent | no | 3 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L2226 | 6 | 1 | Mine | no | 1 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2226 | 6 | 1 | Opponent | no | 4 | 3 | 5 | 0 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 14% | 1.6 | 2.7 | 1.9 | 0.8 | 0.2 | 0.0 | 0.0 | 551.9 |
| **Average** | | | Opponent | 17% | 2.8 | 2.3 | 2.7 | 1.8 | 0.4 | 0.0 | 0.0 | 160.6 |

### KPIs: gf-h2h-opp-0533c46-p2

Rules off - Mine only: GUN FIGURES, GUN MASK, GUN VIEW, GUN THREAT, STAY WORTH, BEST MOVE FOR SHOOTERS, FACE THE CAST, WIZARD FRONT RANK, FIRE PLAN, FIRE IN ORDER, KEEPS THE TARGET, MISSILES IN THE FIRE PLAN, THREAT AT FULL SIZE, SHOOTERS ARE THREATS, SHOOTERS TO THE PRIMARY, EVERY WOUND COUNTS, HONEST THREAT, ONE YARDSTICK.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 55% (102 of 185) | 0% (0 of 187) | 27% (102 of 372) |
| Winner chose to follow up after the loser gave ground |  | 97% (60 of 62); on the table 98% | 100% (50 of 50); on the table 100% | 98% (110 of 112); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 60% (3 of 5); on the table 80% | 88% (15 of 17); on the table 88% | 82% (18 of 22); on the table 86% |
| Winner chose to pursue after the loser fled |  | 73% (16 of 22); on the table 77% | 74% (26 of 35); on the table 77% | 74% (42 of 57); on the table 77% |
| Winner chose to follow up or pursue (all three) |  | 89% (79 of 89); on the table 92% | 89% (91 of 102); on the table 90% | 89% (170 of 191); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 40% (89 of 222) | 31% (56 of 180) | 36% (145 of 402) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 54% (89 of 165) | 41% (56 of 135) | 48% (145 of 300) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 35% (42 of 120) | 24% (27 of 114) | 29% (69 of 234) |
|     round 1 |  | 5% (1 of 20) | 11% (2 of 19) | 8% (3 of 39) |
|     rounds 2+ |  | 41% (41 of 100) | 26% (25 of 95) | 34% (66 of 195) |
|   other wizards | 50%+ | 46% (47 of 102) | 44% (29 of 66) | 45% (76 of 168) |
|     round 1 |  | 35% (6 of 17) | 27% (3 of 11) | 32% (9 of 28) |
|     rounds 2+ |  | 48% (41 of 85) | 47% (26 of 55) | 48% (67 of 140) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 73% (8 of 11) | 64% (21 of 33) | 66% (29 of 44) |
| Points that never fought | lower | 45% (31985 of 71134) | 43% (31206 of 71985) | 44% (63191 of 143119) |
|   infantry points that never fought | lower | 44% (7637 of 17321) | 65% (8990 of 13831) | 53% (16627 of 31152) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 62% (197 of 317) | 55% (147 of 269) | 59% (344 of 586) |
| Bound items with a magic missile used (at least once a game) |  | 87% (13 of 15); 1.0 uses a game | 74% (14 of 19); 1.2 uses a game | 79% (27 of 34); 1.1 uses a game |
| Bound items with another spell used |  | 50% (2 of 4); 0.2 uses a game | 44% (4 of 9); 0.1 uses a game | 46% (6 of 13); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 21% (3 of 14); 0.1 uses a game | 50% (5 of 10); 0.1 uses a game | 33% (8 of 24); 0.1 uses a game |
|   their share of the points of units over 100 pts | lower | 58% (34464 of 59205) | 48% (29972 of 62613) | 53% (64436 of 121818) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.2 (32%) | 0.9 (27%) | 2.1 (30%) |
| MARCHED: its unit marched | 0.8 (20%) | 0.7 (20%) | 1.4 (20%) |
| CHARGED: its unit charged | 0.1 (3%) | 0.1 (2%) | 0.2 (3%) |
| IN COMBAT: engaged in combat | 0.7 (18%) | 0.7 (21%) | 1.4 (19%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (7%) | 0.2 (4%) |
| GONE: slain | 0.6 (15%) | 0.4 (10%) | 0.9 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (10%) | 0.2 (5%) | 0.5 (7%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.1 (2%) | 0.2 (6%) | 0.3 (4%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.6 | 1.0 | 1.7 | 4.0 | 0.3 | 1.3 |
| not cast | 2.6 | 2.2 | 2.2 | 7.1 | 0.9 | 14.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.1 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (30%) | 0.2 (10%) | 2.1 (30%) | 0.4 (42%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (20%) | 0.2 (19%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (3%) | 0.0 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (6%) | 0.1 (2%) | 0.5 (23%) | 1.4 (19%) | 0.1 (13%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (9%) | 0.7 (31%) | 0.4 (21%) | 0.2 (4%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (9%) | 0.1 (5%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (2%) |
| GONE: slain | 0.6 (24%) | 0.2 (9%) | 0.4 (19%) | 0.9 (13%) | 0.1 (10%) | 1.7 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (6%) | 0.2 (8%) | 0.1 (5%) | 0.5 (7%) | 0.1 (6%) | 0.5 (3%) |
| STUPIDITY: Stupidity | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.3 (15%) | 0.0 (0%) | 0.0 (0%) | 0.1 (6%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.1 (44%) | 0.0 (0%) | 0.5 (22%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 11.0 (75%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.4 a game | 1.2 a game | 0.8 a game |
| stood (cast and not dispelled) | 86% (6 of 7) | 65% (15 of 23) | 70% (21 of 30) |
| the unit moved after it | 67% (4 of 6) | 53% (8 of 15) | 57% (12 of 21) |
| it charged on its next turn | 0% (0 of 6) | 0% (0 of 15) | 0% (0 of 21) |
| the enemy charged it first | 0% (0 of 6) | 0% (0 of 15) | 0% (0 of 21) |
| it fought by the end of its next turn | 0% (0 of 6) | 0% (0 of 15) | 0% (0 of 21) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 6) | 27% (4 of 15) | 19% (4 of 21) |
| none of these (no charge, no fight, no charge escaped) | 100% (6 of 6) | 73% (11 of 15) | 81% (17 of 21) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 69% (943 of 1371) | 58% (489 of 850) | 64% (1432 of 2221) |
|   cavalry | 56% (44 of 78) | 74% (86 of 116) | 67% (130 of 194) |
|   character | 75% (115 of 153) | 31% (50 of 163) | 52% (165 of 316) |
|   chariot | 60% (74 of 123) | 65% (41 of 63) | 62% (115 of 186) |
|   infantry | 52% (210 of 402) | 55% (210 of 384) | 53% (420 of 786) |
|   monster | 50% (37 of 74) | 68% (34 of 50) | 57% (71 of 124) |
|   war machine | 86% (463 of 541) | 92% (68 of 74) | 86% (531 of 615) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.7 (31%) | 2.6 (26%) | 6.3 (29%) |
| CHARGED: it charged | 1.1 (9%) | 2.0 (20%) | 3.1 (14%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 1.3 (11%) | 0.7 (7%) | 2.0 (9%) |
| NO TARGET IN RANGE | 1.9 (16%) | 2.2 (22%) | 4.1 (19%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (3%) | 0.6 (6%) | 1.0 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.4 (20%) | 1.5 (15%) | 3.9 (18%) |
| SHELTERED: the target was sheltered | 0.4 (4%) | 0.1 (1%) | 0.6 (3%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR | 0.5 (4%) | 0.2 (2%) | 0.8 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.2 | 1.6 | 82% | 4.6 pts | 29 pts |
| character | 5.0 | 1.7 | 76% | 9.3 pts | 47 pts |
| chariot | 3.3 | 2.1 | 65% | 23.2 pts | 77 pts |
| infantry | 16.2 | 7.1 | 72% | 9.8 pts | 158 pts |
| monster | 2.2 | 0.8 | 70% | 11.0 pts | 24 pts |
| war machine | 15.1 | 15.7 | 57% | 32.7 pts | 493 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.3 | 5.8 | 4.6 |
| Charges that made contact a game | 2.4 | 4.2 | 3.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.53 declared, 0.37 contact (19 units) | 0.69 declared, 0.62 contact (13 units) | 0.59 declared, 0.47 contact (32 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.50 declared, 0.50 contact (2 units) | 1.22 declared, 0.78 contact (9 units) | 1.09 declared, 0.73 contact (11 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.44 declared, 0.31 contact (245 units) | 0.65 declared, 0.47 contact (291 units) | 0.55 declared, 0.40 contact (536 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 56% (32 of 57) | 43% (6 of 14) | 71% (5 of 7) | 55% (43 of 78) |
| Character in a unit | 79% (31 of 39) | 71% (10 of 14) | 0% (0 of 1) | 76% (41 of 54) |
| Character on its own | 79% (30 of 38) | 39% (11 of 28) | 31% (18 of 59) | 47% (59 of 125) |
| Chariot | 68% (15 of 22) | 65% (11 of 17) | - | 67% (26 of 39) |
| Infantry | 51% (47 of 92) | 56% (20 of 36) | 20% (1 of 5) | 51% (68 of 133) |
| Monster | 65% (17 of 26) | 85% (11 of 13) | - | 72% (28 of 39) |
| Monstrous | 62% (5 of 8) | 52% (13 of 25) | - | 55% (18 of 33) |
| War Machines | 72% (59 of 82) | 67% (2 of 3) | - | 72% (61 of 85) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 4 | 100% (8 of 8); on the table 100% | 50% (18 of 36) | 43% | 62% (20 of 32) | 0.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.2 uses a game |
| Dwarfen Mountain Holds | 10 | 73% (11 of 15); on the table 80% | - | 58% | 69% (59 of 85) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 15 | 85% (22 of 26); on the table 85% | 40% (46 of 114) | 52% | 69% (109 of 159) | 0.0 uses a game | 40% (2 of 5); 0.6 uses a game | 12% (1 of 8); 0.1 uses a game |
| Grand Cathay | 4 | 92% (12 of 13); on the table 100% | 40% (38 of 96) | 43% | 43% (15 of 35) | 82% (9 of 11); 5.8 uses a game | 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| High Elf Realms | 7 | 80% (8 of 10); on the table 80% | 25% (6 of 24) | 36% | 40% (21 of 52) | 73% (8 of 11); 3.6 uses a game | 50% (4 of 8); 0.7 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (5 of 5); on the table 100% | - | 53% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | 100% (7 of 7); on the table 100% | - | 18% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 7 | 94% (16 of 17); on the table 100% | 14% (5 of 36) | 50% | 63% (31 of 49) | 71% (5 of 7); 1.6 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (4 of 4); on the table 100% | 42% (5 of 12) | 0% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 3 | 80% (8 of 10); on the table 80% | 39% (7 of 18) | 43% | 43% (10 of 23) | 100% (1 of 1); 1.7 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Tomb Kings of Khemri | 6 | 89% (24 of 27); on the table 93% | 17% (1 of 6) | 34% | 37% (11 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 6 | 92% (24 of 26); on the table 92% | 31% (15 of 48) | 35% | 53% (19 of 36) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 3 | 100% (9 of 9); on the table 100% | 33% (2 of 6) | 41% | 54% (14 of 26) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |
| Wood Elf Realms | 4 | 86% (12 of 14); on the table 86% | 33% (2 of 6) | 34% | 61% (23 of 38) | 100% (3 of 3); 2.8 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gf-h2h-opp-0533c46-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 53% (48) | 43% (20) | 50% (68) |
| ...free all their last turn and able to turn (per game) | 0.75 | 0.22 | 0.97 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.28 | 0.14 | 0.42 |
| ...with the charger already in that arc before they moved (per game) | 0.58 | 0.11 | 0.69 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.94 | 1.31 | 3.25 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.53 | 0.86 | 2.39 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.06 | 5.25 | 10.31 |

### Quality by phase: gf-h2h-opp-0533c46-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.3 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 58% (49 of 85) | 47% (84 of 179) |
| Strategy | Shoot objectives carried out (shot that target) | 51% (302 of 597) | 38% (97 of 255) |
| Strategy | Close-in objectives charged next turn | 12% (16 of 130) | 14% (38 of 268) |
| Strategy | Support requests answered (helper made contact too) | 82% (9 of 11) | 37% (13 of 35) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 60% (3 of 5) | 62% (5 of 8) |
| Strategy | Joined characters whose unit fought | 39% (20 of 51) | 44% (17 of 39) |
| Strategy | Lone characters that fought | 57% (54 of 95) | 73% (56 of 77) |
| Movement | Charges halted short of contact | 0.2 | 0.3 |
| Movement | Idle units | 0.8 | 1.8 |
| Movement | Points that never moved of their own | 551.9 | 160.6 |
| Movement | Fights charged into per game | 2.1 | 3.7 |
| Movement | Charges with odds: long shots (under 50%) | 7 of 66, net -77 | 22 of 113, net +100 |
| Movement | Charges with odds: sweet spot (55-75%) | 13 of 66, net +89 | 22 of 113, net +126 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 6 of 66, net +65 | 8 of 113, net +82 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 18 of 66, net +28 | 28 of 113, net +128 |
| Shooting | Shots by shooting units (incl. breath weapons) | 14.1 | 12.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 51% (261 of 508) | 44% (204 of 463) |
| Shooting | Points destroyed by shooting units | 154.0 | 65.1 |
| Shooting | War machine shots | 12.9 | 2.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 52% (241 of 463) | 23% (18 of 79) |
| Shooting | Points destroyed by war machines | 174.4 | 51.6 |
| Magic | Magic missiles cast | 1.5 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 47% (26 of 55) | 25% (8 of 32) |
| Magic | Wounds caused by magic missiles | 2.8 | 1.4 |
| Magic | Wounds caused by other spells | 0.7 | 0.9 |
| Magic | Points destroyed by magic (all spells) | 33.5 | 43.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.9 / 0.1 / 0.3 / 0.0 | 2.7 / 0.4 / 0.5 / 0.2 |
| Combat | Points destroyed in combat | 189.9 | 378.9 |
| Combat | Points run down | 36.8 | 147.8 |
| Combat | Net points per charged fight, damage counted | +45 | +110 |
| Combat | Net per 100 charger points, damage counted | +19.0 | +40.2 |
| Combat | First round won (charged fights) | 70% | 72% |
| Combat | Net points per charged fight | +38 | +111 |
| Combat | Net points per supported fight / lone fight | +26 / +40 | +135 / +107 |
| Combat | Charged fights on a top-3 enemy unit | 26 of 74 | 58 of 134 |
| Game | Points lost | 831.1 | 650.4 |
| Game | VP from objectives | 447.2 | 664.4 |
| Game | Lone holders (player turns) | 1.6 | 2.8 |

- Mine won / drew / lost: 6 / 8 / 22 of 36 ended games (of 36); mean margin (Mine - Opponent) -425 VP
- The side that went first won 14 of 28 games with a winner
- Points traded per game (both sides' losses): 1481
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gf-h2h-opp-0533c46-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 5.1 |
| ARRIVAL HUNT | - | - | - | - | 0.2 | +5.9 | 0.0 | 2.0 |
| ARTILLERY RE-ROLL WEIGHED | 3.6 | +0.0 | 0.0 | 80.6 | 0.3 | +0.0 | 0.0 | 6.9 |
| BACKUP TARGETS | 0.8 | +8.4 | 0.0 | 33.5 | 1.1 | +9.3 | 0.0 | 23.6 |
| BEST FACING | 0.7 | +33.5 | 0.0 | 24.7 | 0.4 | +6.9 | 0.0 | 9.4 |
| BEST FIRST | 4.8 | +191.4 | 167.8 | 89.9 | 4.9 | +196.1 | 173.3 | 80.1 |
| BEST MOVE FOR SHOOTERS | - | - | - | - | 1.1 | +74.0 | 0.0 | 25.0 |
| BEST OVERALL | 0.9 | +53.4 | 0.0 | 31.5 | 0.6 | +26.3 | 0.0 | 4.4 |
| BEST PREY | 0.6 | +28.7 | 7.5 | 26.8 | 0.8 | +30.8 | 54.4 | 15.0 |
| BEST PRIZE | 0.1 | -0.2 | 0.0 | 0.0 | 0.2 | -7.5 | 18.1 | 3.2 |
| BIG CHARACTER SAFETY | 0.2 | -0.5 | 0.0 | 15.0 | 0.2 | -0.0 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 7.1 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.2 | +0.6 | 0.0 | 0.0 | 0.5 | +8.4 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.2 | -10.3 | 5.4 | 0.0 | 0.2 | -36.0 | 47.8 | 0.0 |
| BOMBING RUN | 0.1 | +0.6 | 0.9 | 3.3 | - | - | - | - |
| CANNON PLAN MISSED | 1.6 | +0.0 | 223.2 | 34.4 | - | - | - | - |
| CANNON PLANNED TARGET | 10.5 | +386.9 | 800.6 | 191.9 | - | - | - | - |
| CANNON SIGHT KEPT | 2.2 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 1.8 | 1.1 | 0.0 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 10.9 | 0.0 | 0.2 | -0.4 | 27.8 | 15.5 |
| CAST JOB | 0.9 | +30.0 | 67.7 | 17.3 | 0.2 | +2.8 | 16.2 | 3.2 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.1 | +1.3 | 0.0 | 9.6 | 0.1 | +3.4 | 10.6 | 0.0 |
| CASTS AFTER FRIENDS | 0.2 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | 0.0 | +0.7 | 0.0 | 0.0 | 0.1 | +4.0 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | -1.2 | 5.1 | 8.8 | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | - | - | - | - | 0.0 | +0.3 | 0.0 | 0.0 |
| CHARGE BAND | 0.1 | +0.0 | 11.9 | 0.0 | 0.1 | +0.0 | 20.9 | 13.1 |
| CHARGE NOW FIRST | 1.5 | +0.0 | 184.2 | 47.7 | 2.8 | +0.0 | 246.4 | 63.6 |
| CHARGE NOW WEIGHED | 0.4 | -23.8 | 7.9 | 0.0 | 0.7 | -106.7 | 26.1 | 22.0 |
| CHARGER SLAIN LOST | 0.4 | -28.2 | 10.8 | 23.4 | 0.9 | -9.6 | 71.2 | 19.0 |
| CHARIOT WIZARD CAREFUL | - | - | - | - | 0.2 | -1.6 | 14.7 | 13.1 |
| CHEAP HELPER | 0.0 | +0.0 | 0.0 | 1.8 | 0.1 | +0.0 | 4.6 | 2.2 |
| COMBAT PIVOT | 0.4 | +0.0 | 3.4 | 24.1 | 0.5 | +0.0 | 40.7 | 21.5 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.1 | +7.1 | 0.0 | 0.0 | 0.5 | +54.7 | 6.5 | 6.5 |
| COUNTER-CHARGE COVER | 11.8 | +1050.8 | 0.0 | 273.1 | 7.3 | +656.3 | 0.0 | 189.9 |
| DEFENSIVE ARMY | 0.7 | +0.0 | 93.1 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.0 | +0.4 | 3.2 | 0.0 | 0.5 | +9.5 | 38.2 | 5.5 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +2.2 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EVERY WOUND COUNTS | - | - | - | - | 10.1 | +0.0 | 411.2 | 144.2 |
| FACE THE CAST | - | - | - | - | 0.0 | +0.3 | 0.0 | 0.0 |
| FACES THE THREAT | 1.9 | +153.9 | 0.0 | 60.5 | 1.3 | +76.3 | 0.0 | 44.5 |
| FALLBACK BY WORTH | 3.9 | +40.6 | 0.0 | 63.9 | 6.3 | +76.7 | 0.0 | 50.2 |
| FIGHT LIFT | 0.1 | +0.3 | 1.7 | 11.0 | 0.1 | +1.9 | 13.1 | 0.0 |
| FIRE AND FLEE | - | - | - | - | 0.0 | +0.4 | 0.0 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 0.9 | +0.0 | 63.5 | 17.6 |
| FIRE PLAN | - | - | - | - | 14.0 | +57.8 | 558.5 | 182.0 |
| FLANK NOT WEIGHED | 5.4 | +0.0 | 0.0 | 156.5 | 5.1 | +0.0 | 0.0 | 97.1 |
| FOCUS FIRE | 0.1 | +0.8 | 0.5 | 5.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.8 | +111.5 | 0.0 | 45.6 | 1.0 | +136.1 | 0.0 | 14.9 |
| FRIENDS SHOTS CHECKED | 0.3 | +18.1 | 0.0 | 29.6 | 0.3 | +19.1 | 0.0 | 0.0 |
| GIVES UP | 0.0 | -0.1 | 0.0 | 0.0 | 0.1 | -5.1 | 9.6 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -3.7 | 2.9 | 2.1 |
| GROUND FLIERS | 0.0 | +3.1 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | - | - | - | - | 1.2 | +42.6 | 63.3 | 29.7 |
| GUN MASK | - | - | - | - | 0.1 | +0.8 | 0.0 | 0.0 |
| GUN THREAT | - | - | - | - | 0.9 | +189.8 | 31.4 | 38.3 |
| GUN VIEW | - | - | - | - | 0.6 | +17.7 | 0.0 | 8.6 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 6.4 | 2.9 |
| HELPER UNSEEN | 0.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 32.8 | 7.7 |
| HILL BY ITS CHANCE | 0.3 | -12.2 | 0.0 | 2.6 | 0.3 | -26.8 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.2 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| HONEST THREAT | - | - | - | - | 10.1 | +1362.5 | 411.2 | 144.2 |
| HONEST WORTH | 6.1 | -88.6 | 252.6 | 114.5 | 10.2 | -210.3 | 594.5 | 225.4 |
| HUNT ADVANCE | 0.1 | +0.6 | 6.5 | 0.0 | 0.4 | +18.2 | 7.9 | 15.3 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 5.1 |
| HUNT IN PAIRS | 0.4 | +13.9 | 0.0 | 5.7 | 0.6 | +26.3 | 0.0 | 24.7 |
| HUNT KEPT | - | - | - | - | 0.4 | +19.9 | 20.4 | 8.9 |
| HUNT RESULT | 0.1 | +18.9 | 0.0 | 0.0 | 0.5 | +61.0 | 13.8 | 14.4 |
| HUNT THE GUNS | 0.1 | +52.7 | 10.0 | 1.7 | 0.6 | +199.5 | 15.6 | 13.5 |
| INVITES THE FIGHT | 1.7 | +26.8 | 26.4 | 41.8 | 1.0 | +13.7 | 42.3 | 0.0 |
| JOINT CHARGE PLAN | 0.0 | +3.6 | 0.0 | 0.0 | 0.2 | +4.2 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | 0.0 | -0.1 | 0.0 | 1.7 | 0.3 | -17.2 | 0.0 | 6.9 |
| KEEP FALLS | 0.1 | +0.9 | 0.0 | 6.1 | - | - | - | - |
| KEEPS ITS PREY | 0.0 | +0.1 | 2.0 | 0.0 | - | - | - | - |
| KEEPS ITS TARGET | 1.3 | +40.0 | 90.5 | 18.9 | 2.1 | +62.5 | 193.9 | 48.4 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS THE TARGET | - | - | - | - | 1.3 | -25.0 | 109.1 | 15.0 |
| KILLS COUNT | 1.1 | +62.7 | 78.9 | 21.6 | 1.9 | +109.4 | 177.3 | 31.3 |
| KILLS COUNT NEXT TURN | 4.4 | +109.4 | 84.2 | 115.4 | 8.4 | +286.1 | 352.7 | 217.1 |
| LONE CHARACTER SAFE SPOT | 0.6 | +28.2 | 27.8 | 15.4 | 0.5 | +16.4 | 28.5 | 35.6 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.5 | +24.3 | 0.0 | 0.0 | 0.4 | +32.7 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | -4.5 | 31.7 | 7.4 | 0.4 | -2.6 | 10.9 | 3.8 |
| LOST CHARGE | 2.8 | -57.1 | 108.1 | 111.4 | 2.2 | -30.5 | 69.0 | 54.9 |
| LURE BY WHAT IT DRAWS | 0.1 | -19.7 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.3 | +17.8 | 0.0 | 3.3 | 1.4 | +180.1 | 81.4 | 104.8 |
| MANOEUVRE | 0.3 | +12.5 | 0.0 | 11.2 | 0.3 | +3.6 | 0.0 | 15.5 |
| MARCH AT ESCAPER | 0.1 | +1.8 | 0.0 | 4.8 | 0.0 | +0.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.6 | +29.8 | 0.0 | 7.2 | 0.5 | +21.7 | 0.0 | 13.1 |
| MARCH ODDS | 0.2 | +11.9 | 6.6 | 9.6 | 0.4 | +25.1 | 13.4 | 0.0 |
| MARCH OVER CASTS | 0.5 | +26.6 | 0.0 | 15.4 | 0.6 | +36.9 | 0.0 | 15.0 |
| MAX FOR POSITIONING | 4.7 | +141.4 | 0.0 | 101.9 | 4.8 | +197.6 | 0.0 | 170.1 |
| MISSILES IN THE FIRE PLAN | - | - | - | - | 0.5 | +2.5 | 31.1 | 0.0 |
| MISSILES IN THE MOVE | 3.4 | +93.7 | 0.0 | 84.5 | 3.1 | +53.5 | 0.0 | 83.6 |
| MISSILES NEXT TURN | 3.9 | +61.4 | 0.0 | 90.5 | 4.0 | +46.7 | 0.0 | 83.6 |
| MODEL FACING | 0.7 | +245.9 | 0.0 | 15.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 5.4 | 21.1 | 0.2 | +0.0 | 16.7 | 0.0 |
| MOVE AND CAST | 0.3 | +7.9 | 0.0 | 2.4 | 0.3 | +12.7 | 0.0 | 12.9 |
| MOVE SPELL IN RANGE | 0.1 | +4.5 | 0.0 | 0.0 | 0.0 | +0.3 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.1 | -11.0 | 5.2 | 0.0 | 0.2 | -9.7 | 3.5 | 17.1 |
| MOVE SPELL SPOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 2.5 | +155.2 | 57.6 | 48.9 | 5.9 | +355.2 | 228.6 | 171.5 |
| MOVES UNITS SPELL | 0.1 | +0.4 | 0.0 | 0.0 | 0.1 | +0.7 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.0 | +7.5 | 2.9 | 0.0 |
| NO RALLY LEFT | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| NOT NEEDED | 0.1 | -3.3 | 3.5 | 0.0 | 0.2 | -14.0 | 48.5 | 6.2 |
| NOT TURNED | 5.1 | +89.7 | 0.0 | 113.8 | 5.2 | +85.0 | 0.0 | 97.1 |
| NOT WORTH A CAST | 0.3 | -0.1 | 0.0 | 31.7 | 0.1 | -2.5 | 0.0 | 0.0 |
| OFF BEST | 16.8 | -848.9 | 6.4 | 252.3 | 16.2 | -788.2 | 23.1 | 260.9 |
| ONE YARDSTICK | - | - | - | - | 12.8 | -617.2 | 251.2 | 166.0 |
| OPENS A LANE | 0.2 | +1.4 | 83.3 | 13.7 | 0.1 | +0.4 | 8.7 | 0.0 |
| OPENS UP | 0.0 | +4.6 | 1.2 | 0.0 | 0.2 | +14.9 | 13.5 | 6.0 |
| OVERRUNS AWAY | 0.4 | +5.3 | 69.4 | 19.6 | 0.5 | +8.0 | 39.8 | 13.7 |
| PATHS CROSS | 1.4 | +87.2 | 0.0 | 37.7 | 3.1 | +163.5 | 0.0 | 63.7 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +5.1 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -0.8 | 0.0 | 0.0 | 0.1 | -1.7 | 0.0 | 0.0 |
| PLAN RESULT | 39.7 | +1848.6 | 1611.8 | 1094.2 | 40.2 | +1304.9 | 1515.7 | 1013.8 |
| PURSUES BIG PREY | 0.1 | -7.0 | 0.0 | 0.0 | 0.1 | -15.2 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +3.3 | 0.0 | 0.0 | 0.0 | +3.3 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.3 | +1.4 | 0.0 | 8.1 | 0.9 | +7.8 | 0.0 | 31.7 |
| RANDOM MOVER NO PROMISE | 0.0 | -0.4 | 0.0 | 0.0 | 0.1 | -5.6 | 14.5 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -3.8 | 0.0 | 0.9 | 0.6 | -12.3 | 0.0 | 5.6 |
| REDIRECT COUNTER | 1.2 | +48.8 | 0.0 | 21.4 | 2.9 | +201.5 | 0.0 | 29.2 |
| REDIRECT WEIGHED | 0.1 | -0.1 | 0.0 | 0.0 | 0.4 | +0.2 | 21.5 | 1.7 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 8.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.1 | +3.2 | 0.0 | 2.0 | 1.0 | +29.7 | 0.0 | 8.3 |
| RESTRAINS TO SHOOT | 0.2 | +8.9 | 0.0 | 13.1 | 0.1 | +5.4 | 0.0 | 0.0 |
| RISK BY ARC | 1.6 | +66.2 | 129.1 | 69.9 | 3.0 | +49.8 | 260.7 | 76.8 |
| SAFER THAN THE JOB | 1.5 | +100.2 | 0.0 | 55.6 | 0.9 | +69.3 | 0.0 | 36.8 |
| SCOUT SPOT | 0.6 | +0.5 | 0.0 | 0.9 | 0.7 | +3.9 | 0.0 | 0.0 |
| SCOUT WAITS | 0.6 | +0.0 | 0.0 | 0.9 | 0.8 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.0 | -0.2 | 0.0 | 0.0 | 0.6 | -24.5 | 0.0 | 5.7 |
| SEARCH SPOT | 2.2 | +97.4 | 0.0 | 69.1 | 3.5 | +152.5 | 0.0 | 61.0 |
| SECOND HUNTER | - | - | - | - | 0.1 | -0.9 | 4.6 | 3.2 |
| SELF MOVE SPELL | 0.2 | +70.9 | 0.0 | 21.9 | 0.7 | +164.3 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.7 | +35.0 | 0.0 | 18.0 | 2.7 | +294.8 | 108.6 | 124.2 |
| SET-UP ANY TARGET | 0.1 | +17.1 | 0.0 | 0.0 | 0.3 | +46.1 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +11.4 | 0.0 | 0.0 | 0.1 | +5.3 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.0 | -0.2 | 0.0 | 0.0 | 0.0 | -0.0 | 0.0 | 0.0 |
| SHOOTERS ARE THREATS | - | - | - | - | 4.6 | +405.7 | 176.3 | 96.6 |
| SHOOTERS IN TWO RANKS | 0.8 | +1.5 | 0.0 | 0.0 | 0.3 | +0.4 | 0.0 | 0.0 |
| SHOOTERS TO THE PRIMARY | - | - | - | - | 2.2 | +33.1 | 0.0 | 15.4 |
| SHOOTS FROM THE BEST SPOT | 0.9 | +47.4 | 31.4 | 4.6 | 1.2 | +27.9 | 64.3 | 20.8 |
| SHORT GUN FORWARD | 0.5 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OPTIONS | 25.5 | +0.0 | 1556.0 | 445.5 | 13.9 | +0.0 | 502.6 | 229.5 |
| SHOT REPLANNED | 1.5 | +0.0 | 306.2 | 21.8 | - | - | - | - |
| SHOTS IN THE MOVE | 22.8 | +1218.8 | 0.0 | 396.7 | 13.5 | +502.6 | 0.0 | 232.6 |
| SPELL CATCH ODDS | - | - | - | - | 0.0 | -0.2 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.1 | +17.1 | 0.0 | 0.0 | 0.3 | +60.6 | 0.0 | 0.0 |
| SPELL WORTH | 0.7 | +14.3 | 45.5 | 54.8 | 2.4 | +61.2 | 67.2 | 54.2 |
| SPELLS IN THE FIGHT | 0.5 | -5.7 | 45.7 | 45.5 | 0.8 | +4.2 | 130.2 | 9.4 |
| STABLE ROLE | 11.9 | +0.0 | 340.9 | 210.0 | 9.8 | +0.0 | 373.7 | 170.1 |
| STAY WEIGHED | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| STAY WORTH | - | - | - | - | 15.8 | +213.8 | 309.3 | 188.9 |
| STOPS | 0.1 | +3.8 | 3.5 | 1.7 | 0.5 | +24.7 | 28.1 | 7.1 |
| STOPS SHORT OF THE FLANK | 0.4 | +23.2 | 0.0 | 7.8 | 0.3 | +9.0 | 0.0 | 13.1 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 4.5 | -48.5 | 207.7 | 94.2 | 5.4 | -29.8 | 276.9 | 67.7 |
| SUPPORTS | 3.2 | +55.5 | 113.9 | 68.7 | 3.1 | +31.6 | 98.8 | 36.6 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -1.5 | 0.0 | 0.0 | 0.2 | -5.1 | 17.6 | 7.0 |
| SURE REACH TOGETHER | 0.3 | -7.0 | 0.0 | 10.9 | 1.1 | +14.8 | 0.0 | 19.7 |
| THROUGH LINE OF FIRE | 0.3 | +13.7 | 0.0 | 4.6 | 0.4 | +25.9 | 0.0 | 7.3 |
| TURN WORTH | 0.1 | -10.3 | 12.9 | 16.6 | 0.2 | -15.1 | 9.0 | 0.0 |
| TWO OR MORE ARRIVE | 0.2 | +1.1 | 0.0 | 9.7 | 0.9 | +14.8 | 13.6 | 28.7 |
| WAIT AFTER COSTS | 6.1 | -260.3 | 120.2 | 129.6 | 9.3 | -459.6 | 397.4 | 240.6 |
| WALKS TO THE FIGHT | 1.5 | +30.7 | 25.9 | 12.5 | 1.2 | +19.4 | 55.4 | 50.6 |
| WAR ENGINE CHARGES | 0.0 | +7.4 | 13.9 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.7 | +0.0 | 0.0 | 14.0 | 0.2 | +0.0 | 24.1 | 15.4 |
| WEARS DOWN | 0.8 | +36.2 | 78.9 | 28.9 | 1.2 | +47.4 | 124.1 | 17.2 |
| WHO HITS BACK | 0.4 | +37.1 | 0.0 | 17.7 | 0.2 | +14.3 | 0.0 | 13.9 |
| WHOLE FIGHT | 0.2 | +5.4 | 18.9 | 1.1 | 0.5 | +3.6 | 47.8 | 3.8 |
| WHOLE FIGHT GAIN | 0.2 | +18.4 | 15.6 | 3.3 | 0.7 | +75.2 | 41.5 | 11.1 |
| WIDER SPREAD | 1.8 | -6.9 | 148.1 | 52.1 | 3.4 | -9.1 | 307.8 | 53.6 |
| WOUNDED STAYS OUT | - | - | - | - | 0.1 | +0.0 | 12.1 | 0.0 |

### Rule changes: gf-h2h-opp-0533c46-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1188 | 1188 | 1188 | 33.00 | -58935 | -49.6 |
| BEST FIRST | 349 | 349 | 349 | 9.69 | +13950 | +40.0 |
| SEARCH SPOT | 205 | 205 | 205 | 5.69 | +8997 | +43.9 |
| PATHS CROSS | 164 | 164 | 164 | 4.56 | +9024 | +55.0 |
| KILLS COUNT NEXT TURN | 459 | 459 | 158 | 4.39 | +3837 | +24.3 |
| MOVE TO CHARGE | 302 | 302 | 156 | 4.33 | +5993 | +38.4 |
| COUNTER-CHARGE COVER | 688 | 374 | 146 | 4.06 | +8755 | +60.0 |
| SHOTS IN THE MOVE | 1307 | 902 | 143 | 3.97 | +4625 | +32.3 |
| ARTILLERY RE-ROLL WEIGHED | 140 | 140 | 140 | 3.89 | +0 | +0.0 |
| FACES THE THREAT | 117 | 117 | 117 | 3.25 | +8287 | +70.8 |
| FIRE PLAN | 505 | 505 | 113 | 3.14 | +1428 | +12.6 |
| CANNON SIGHT KEPT | 94 | 94 | 94 | 2.61 | +0 | +0.0 |
| EVERY WOUND COUNTS | 364 | 364 | 94 | 2.61 | +0 | +0.0 |
| SAFER THAN THE JOB | 86 | 86 | 86 | 2.39 | +6104 | +71.0 |
| FALLBACK BY WORTH | 369 | 369 | 83 | 2.31 | +4224 | +50.9 |
| SUPPORTS | 229 | 229 | 78 | 2.17 | +933 | +12.0 |
| WAIT AFTER COSTS | 555 | 555 | 76 | 2.11 | +1394 | +18.3 |
| CANNON PLANNED TARGET | 377 | 377 | 73 | 2.03 | -650 | -8.9 |
| SET UP TOGETHER | 122 | 104 | 68 | 1.89 | +5144 | +75.6 |
| FOLLOW UP WEIGHED | 65 | 65 | 65 | 1.81 | +8911 | +137.1 |
| SHOT REPLANNED | 53 | 53 | 53 | 1.47 | +0 | +0.0 |
| BEST OVERALL | 52 | 52 | 52 | 1.44 | +2868 | +55.2 |
| HONEST THREAT | 364 | 364 | 50 | 1.39 | +0 | +0.0 |
| SCOUT WAITS | 50 | 50 | 50 | 1.39 | +0 | +0.0 |
| WALKS TO THE FIGHT | 99 | 99 | 50 | 1.39 | +543 | +10.9 |
| BEST FACING | 42 | 42 | 42 | 1.17 | +1454 | +34.6 |
| CHARGE NOW WEIGHED | 41 | 41 | 41 | 1.14 | +3607 | +88.0 |
| RESERVE FALL BACK | 41 | 41 | 41 | 1.14 | +1186 | +28.9 |
| BEST MOVE FOR SHOOTERS | 40 | 40 | 40 | 1.11 | +2662 | +66.6 |
| REDIRECT COUNTER | 145 | 81 | 40 | 1.11 | +2131 | +53.3 |
| ADVANCE LANE KEPT | 38 | 38 | 38 | 1.06 | +0 | +0.0 |
| CHARGE NOW FIRST | 154 | 154 | 38 | 1.06 | -2459 | -64.7 |
| SHOOTERS IN TWO RANKS | 38 | 38 | 38 | 1.06 | +70 | +1.8 |
| SHOOTS FROM THE BEST SPOT | 74 | 74 | 37 | 1.03 | +932 | +25.2 |
| MAX FOR POSITIONING | 343 | 192 | 35 | 0.97 | +457 | +13.1 |
| COMBAT PIVOT | 34 | 34 | 34 | 0.94 | +0 | +0.0 |
| MISSILES IN THE MOVE | 234 | 125 | 34 | 0.94 | +732 | +21.5 |
| FIRE IN ORDER | 33 | 33 | 33 | 0.92 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2051 | +62.2 |
| MAKE SURE TOGETHER | 61 | 50 | 32 | 0.89 | +2864 | +89.5 |
| MARCH CHECK | 37 | 33 | 31 | 0.86 | +1603 | +51.7 |
| RISK BY ARC | 165 | 159 | 30 | 0.83 | +1197 | +39.9 |
| RANDOM MOVE BY FIGURES | 44 | 44 | 29 | 0.81 | +331 | +11.4 |
| STAY WORTH | 570 | 441 | 29 | 0.81 | +351 | +12.1 |
| HOLDS AMBUSHERS | 28 | 28 | 28 | 0.78 | +0 | +0.0 |
| BLOCKED WHEEL | 27 | 27 | 27 | 0.75 | +326 | +12.1 |
| HONEST WORTH | 587 | 582 | 27 | 0.75 | +263 | +9.7 |
| THROUGH LINE OF FIRE | 27 | 27 | 27 | 0.75 | +1425 | +52.8 |
| STOPS SHORT OF THE FLANK | 26 | 26 | 26 | 0.72 | +1159 | +44.6 |
| KILLS COUNT | 109 | 106 | 25 | 0.69 | +1138 | +45.5 |
| MODEL FACING | 25 | 25 | 25 | 0.69 | +8852 | +354.1 |
| KEEPS ITS TARGET | 123 | 122 | 23 | 0.64 | +436 | +19.0 |
| MARCH ODDS | 23 | 23 | 23 | 0.64 | +135 | +5.9 |
| ONE YARDSTICK | 461 | 152 | 23 | 0.64 | +222 | +9.7 |
| FRIENDS SHOTS CHECKED | 22 | 22 | 22 | 0.61 | +1340 | +60.9 |
| SHOOTERS ARE THREATS | 167 | 167 | 22 | 0.61 | +0 | +0.0 |
| MOVE AND CAST | 21 | 21 | 21 | 0.58 | +741 | +35.3 |
| WHO HITS BACK | 20 | 20 | 20 | 0.56 | +1172 | +58.6 |
| MANOEUVRE | 24 | 24 | 19 | 0.53 | +578 | +30.4 |
| BEST PREY | 53 | 53 | 18 | 0.50 | +440 | +24.4 |
| REDIRECT WEIGHED | 18 | 18 | 18 | 0.50 | +586 | +32.6 |
| SHORT GUN FORWARD | 18 | 18 | 18 | 0.50 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 33 | 29 | 17 | 0.47 | +1028 | +60.5 |
| CAST JOB | 41 | 41 | 16 | 0.44 | +344 | +21.5 |
| KEEPS THE TARGET | 47 | 47 | 16 | 0.44 | -1303 | -81.4 |
| CASTER AWAY FROM SCREEN | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| BIG CHARACTER SAFETY | 13 | 13 | 13 | 0.36 | -21 | -1.6 |
| CHAFF PASSED | 12 | 12 | 12 | 0.33 | -43 | -3.6 |
| HUNT IN PAIRS | 37 | 25 | 11 | 0.31 | +223 | +20.3 |
| INVITES THE FIGHT | 98 | 98 | 11 | 0.31 | +163 | +14.8 |
| LOST CHARGE | 180 | 180 | 11 | 0.31 | +500 | +45.5 |
| WEARS DOWN | 71 | 67 | 11 | 0.31 | +569 | +51.8 |
| BEST PRIZE | 10 | 10 | 10 | 0.28 | -523 | -52.3 |
| RESTRAINS TO SHOOT | 10 | 10 | 10 | 0.28 | +513 | +51.3 |
| SURE CHARGE BEATS ADVANCE | 10 | 10 | 10 | 0.28 | -237 | -23.7 |
| GUN VIEW | 21 | 21 | 9 | 0.25 | +603 | +67.0 |
| WAR ENGINE JOBS | 35 | 35 | 8 | 0.22 | -240 | -29.9 |
| CHARGE BAND | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| BACKUP TARGETS | 70 | 43 | 6 | 0.17 | +15 | +2.5 |
| CASTS FROM BEHIND | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| HUNT ADVANCE | 17 | 17 | 6 | 0.17 | +189 | +31.5 |
| MISSILES NEXT TURN | 286 | 146 | 6 | 0.17 | +13 | +2.2 |
| MOVES UNITS SPELL | 6 | 6 | 6 | 0.17 | +41 | +6.8 |
| PURSUES BIG PREY | 6 | 6 | 6 | 0.17 | -800 | -133.3 |
| REFUSING RETIRES | 20 | 20 | 6 | 0.17 | -2 | -0.4 |
| STUCK PIVOT | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| SUPPORT NARROWED | 357 | 357 | 6 | 0.17 | -129 | -21.5 |
| GUN THREAT | 31 | 31 | 5 | 0.14 | +0 | +0.0 |
| KEEPS SCOUTS OR AMBUSH | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| PIVOT GUARDS FLANK | 5 | 5 | 5 | 0.14 | -90 | -17.9 |
| DEFENSIVE ARMY | 25 | 25 | 4 | 0.11 | -27 | -6.6 |
| EDGE GIVE GROUND | 20 | 20 | 4 | 0.11 | +88 | +22.0 |
| LONG SHOT | 32 | 30 | 4 | 0.11 | +0 | +0.1 |
| OPENS UP | 10 | 10 | 4 | 0.11 | +153 | +38.3 |
| SHOOTERS TO THE PRIMARY | 80 | 49 | 4 | 0.11 | +9 | +2.2 |
| WHOLE FIGHT | 23 | 22 | 4 | 0.11 | +217 | +54.4 |
| WIDER SPREAD | 186 | 177 | 4 | 0.11 | +22 | +5.5 |
| CASTING BLOCK | 6 | 6 | 3 | 0.08 | +74 | +24.5 |
| CATCH ODDS | 3 | 3 | 3 | 0.08 | -114 | -37.9 |
| OVERRUNS AWAY | 33 | 32 | 3 | 0.08 | +55 | +18.3 |
| SPELLS IN THE FIGHT | 46 | 42 | 3 | 0.08 | +55 | +18.2 |
| STOPS | 20 | 19 | 3 | 0.08 | +276 | +91.9 |
| BLOCKED CHARGE SKIPPED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +23 | +11.7 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +28 | +14.1 |
| JOINT CHARGE PLAN | 8 | 8 | 2 | 0.06 | +68 | +34.0 |
| KEEP FALLS | 2 | 2 | 2 | 0.06 | +54 | +26.9 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +185 | +92.7 |
| RAIDS THE BAGGAGE NEXT TURN | 2 | 2 | 2 | 0.06 | +168 | +83.9 |
| SURE REACH TOGETHER | 50 | 40 | 2 | 0.06 | +54 | +27.0 |
| CARRIES OUT SET-UP | 11 | 11 | 1 | 0.03 | -15 | -14.8 |
| CHARGER SLAIN LOST | 48 | 44 | 1 | 0.03 | +11 | +11.1 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +81 | +80.7 |
| FACE THE CAST | 1 | 1 | 1 | 0.03 | +10 | +10.2 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +13 | +12.9 |
| HILL BY ITS CHANCE | 21 | 21 | 1 | 0.03 | +5 | +5.4 |
| MOVE SPELL IN RANGE | 5 | 4 | 1 | 0.03 | +4 | +4.3 |
| NEEDED THERE | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +2 | +1.6 |
| REDIRECT BY WHAT IT STOPS | 27 | 27 | 1 | 0.03 | +14 | +14.5 |
| SCREEN BY WHAT IT SAVES | 21 | 21 | 1 | 0.03 | +1 | +1.4 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +6 | +6.3 |
| TWO OR MORE ARRIVE | 40 | 35 | 1 | 0.03 | +1 | +1.1 |
| WOUNDED STAYS OUT | 2 | 2 | 1 | 0.03 | -92 | -92.2 |
| ARRIVAL HUNT | 6 | 6 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 15 | 14 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 59 | 59 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 3 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 35 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 7 | 7 | 0 | 0.00 | - | - |
| CHEAP HELPER | 6 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 22 | not checked | - | - | - | - |
| ENGINEER BY LORE | 6 | 6 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 378 | not checked | - | - | - | - |
| GIVES UP | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 45 | not checked | - | - | - | - |
| GUN MASK | 5 | 4 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 4 | not checked | - | - | - | - |
| HELPER UNSEEN | 13 | 12 | 0 | 0.00 | - | - |
| HUNT DROPPED | 6 | trace | - | - | - | - |
| HUNT KEPT | 13 | trace | - | - | - | - |
| HUNT RESULT | 22 | trace | - | - | - | - |
| HUNT THE GUNS | 24 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 11 | 10 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 40 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 3 | 3 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 6 | trace | - | - | - | - |
| MARCH OVER CASTS | 40 | 40 | 0 | 0.00 | - | - |
| MISSILES IN THE FIRE PLAN | 19 | 1 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 14 | 14 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 14 | trace | - | - | - | - |
| MOVE SPELL SPOT | 11 | not checked | - | - | - | - |
| NOT NEEDED | 10 | 10 | 0 | 0.00 | - | - |
| NOT TURNED | 371 | 371 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 16 | not checked | - | - | - | - |
| OPENS A LANE | 10 | 9 | 0 | 0.00 | - | - |
| PLAN RESULT | 2875 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 5 | 5 | 0 | 0.00 | - | - |
| SCOUT SPOT | 44 | 44 | 0 | 0.00 | - | - |
| SECOND HUNTER | 3 | 3 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 33 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 15 | not checked | - | - | - | - |
| SET-UP MISSED | 5 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOT OPTIONS | 1420 | 1420 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 17 | not checked | - | - | - | - |
| SPELL WORTH | 113 | not checked | - | - | - | - |
| STABLE ROLE | 781 | 779 | 0 | 0.00 | - | - |
| TURN WORTH | 12 | 12 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: gf-h2h-opp-0533c46-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.94 | 14.25 | 51.1 |
| FALLBACK | gate | 0.67 | 0.61 | 34.7 |
| CHARGE NOW FIRST | rule | 0.33 | 0.72 | 64.7 |
| TURN GATE | gate | 0.64 | 0.39 | 35.2 |
| LONE CHARACTER SAFE SPOT | gate | 0.28 | 0.36 | 52.3 |
| CANNON PLANNED TARGET | rule | 0.44 | - | 62.0 |
| FIRE PLAN | rule | - | 0.39 | 95.0 |
| KEEPS THE TARGET | rule | - | 0.36 | 118.0 |
| PATHS CROSS | rule | 0.19 | 0.17 | 27.7 |
| BEST PRIZE | rule | 0.06 | 0.22 | 52.3 |
| SUPPORT REQUEST | gate | 0.06 | 0.22 | 72.6 |
| SURE CHARGE BEATS ADVANCE | rule | 0.08 | 0.19 | 23.7 |
| AFTERMATH BAND | gate | 0.06 | 0.17 | 2.3 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | 0.19 | 28.4 |
| WAR ENGINE JOBS | rule | 0.22 | - | 29.9 |
| CHAFF PASSED | rule | 0.17 | - | 7.1 |
| MARCH ODDS | rule | 0.03 | 0.14 | 25.7 |
| PURSUES BIG PREY | rule | 0.06 | 0.11 | 133.3 |
| SUPPORT NARROWED | rule | 0.11 | 0.06 | 21.5 |
| BIG CHARACTER SAFETY | rule | 0.06 | 0.08 | 8.0 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.08 | 39.3 |
| PIVOT GUARDS FLANK | rule | 0.06 | 0.08 | 17.9 |
| BLOCKED WHEEL | rule | 0.03 | 0.06 | 65.1 |
| CATCH ODDS | rule | 0.03 | 0.06 | 37.9 |
| DEFENSIVE ARMY | rule | 0.08 | - | 8.8 |
| FIGHT ORDER BAND | gate | 0.06 | 0.03 | 1.7 |
| REDIRECT WEIGHED | rule | - | 0.08 | 55.2 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.06 | 7.1 |
| FRIENDS SHOTS CHECKED | rule | - | 0.06 | 1.1 |
| LONG SHOT | rule | - | 0.06 | 4.8 |
| REFUSING RETIRES | rule | 0.06 | - | 0.9 |
| RULE SWITCHED OFF | gate | 0.06 | - | 64.6 |
| THROUGH LINE OF FIRE | rule | 0.06 | - | 36.8 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 14.8 |
| FACES THE THREAT | rule | - | 0.03 | 3.9 |
| FOLLOW UP WEIGHED | rule | - | 0.03 | 3.4 |
| SAFER THAN THE JOB | rule | 0.03 | - | 14.7 |
| WOUNDED STAYS OUT | rule | - | 0.03 | 92.2 |

### Plans: gf-h2h-opp-0533c46-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 10.7 | 18% | 401 | 327 | 81% |
| Mine | charge | 1.9 | 59% | 148 | 159 | 108% |
| Mine | close in | 3.6 | 22% | 167 | 113 | 67% |
| Mine | hold | 5.1 | 29% | 258 | 0 | 0% |
| Mine | join | 0.8 | 89% | 24 | 0 | 0% |
| Mine | shoot | 14.2 | 70% | 477 | 1250 | 262% |
| Mine | support | 3.4 | 93% | 33 | 0 | 0% |
| Opponent | advance | 13.8 | 17% | 407 | 398 | 98% |
| Opponent | charge | 4.3 | 58% | 382 | 400 | 105% |
| Opponent | close in | 7.4 | 25% | 529 | 206 | 39% |
| Opponent | hold | 4.1 | 39% | 309 | 0 | 0% |
| Opponent | join | 0.4 | 93% | 15 | 0 | 0% |
| Opponent | shoot | 5.9 | 50% | 281 | 311 | 111% |
| Opponent | support | 4.1 | 88% | 23 | 0 | 0% |

### Packages: hunt the guns, gf-h2h-opp-0533c46-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 4 | 1 | 33% | 67% | 0% | 2.0 | 430 | 227 | 67% | 38 |
| Opponent | 0.6 | 20 | 1 | 32% | 32% | 5% | 2.3 | 371 | 115 | 32% | 173 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 509 | 432 | 100% | 78 |
| Dwarfen Mountain Holds | 0.1 | 1 | 1 | - | - | - | - | - | - | - | 30 |
| Empire of Man | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 516 | 0 | 0% | 67 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 54 |
| High Elf Realms | 0.7 | 5 | 0 | 20% | 40% | 0% | 2.0 | 426 | 110 | 40% | 70 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.9 | 6 | 0 | 67% | 67% | 0% | 2.5 | 422 | 274 | 67% | 300 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 293 |
| Tomb Kings of Khemri | 0.8 | 5 | 1 | 25% | 25% | 0% | 2.0 | 302 | 48 | 25% | 109 |
| Vampire Counts | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 211 | 0 | 0% | 87 |
| Warriors of Chaos | 0.7 | 2 | 0 | 0% | 0% | 0% | - | 274 | 0 | 0% | 152 |
| Wood Elf Realms | 0.5 | 2 | 0 | 0% | 0% | 50% | - | 341 | 28 | 0% | 168 |

### Battle groups: gf-h2h-opp-0533c46-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 11.8 | 23% | 54% | 6% | 50% | 38% | 10% | 10% | 42% | 0% |
| Mine | REDIRECT COUNTER | 1.2 | 29% | 67% | 0% | - | 17% | 0% | 17% | 67% | 0% |
| Opponent | COUNTER-CHARGE COVER | 7.3 | 14% | 61% | 29% | 18% | 41% | 11% | 4% | 44% | 0% |
| Opponent | REDIRECT COUNTER | 2.9 | 20% | 57% | 14% | 67% | 17% | 0% | 17% | 67% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gf-h2h-opp-0533c46-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 2 | 0 (2) | 0 | 0 | 100 | 0% | 4.5 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | Chaff | 22 | 36 (22) | 29 | 7 | 65 | 23% | 2.6 | 53 (9) | 0 (6) | 53 (7) | 42 (18) | 13 (4) |
| Mine | Character | 132 | 25 (132) | 25 | 0 | 46 | 24% | 2.5 | 24 (35) | 30 (71) | 16 (13) | 20 (67) | 35 (52) |
| Mine | Clean-up | 17 | 24 (17) | 0 | 24 | 51 | 35% | 2.0 | 0 (2) | 27 (14) | 0 (1) | 27 (14) | 0 (3) |
| Mine | Fast | 2 | 0 (2) | 0 | 0 | 50 | 0% | 1.5 | - | 0 (1) | 0 (1) | 0 (2) | - |
| Mine | Fast Hammer | 30 | 47 (30) | 31 | 16 | 36 | 10% | 3.0 | 45 (10) | 44 (16) | 63 (4) | 58 (19) | 29 (11) |
| Mine | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Hammer | 72 | 47 (72) | 30 | 17 | 45 | 17% | 2.2 | 12 (15) | 56 (49) | 59 (8) | 50 (48) | 42 (24) |
| Mine | Holder | 11 | 70 (11) | 0 | 70 | 43 | 27% | 3.0 | 0 (2) | 104 (6) | 33 (3) | 111 (7) | 6 (4) |
| Mine | Shooter | 70 | 74 (70) | 27 | 47 | 43 | 3% | 1.8 | 57 (13) | 79 (40) | 73 (17) | 95 (41) | 47 (29) |
| Mine | Support | 3 | 0 (3) | 0 | 0 | 100 | 0% | 3.0 | - | - | - | - | - |
| Mine | War machine | 109 | 49 (109) | 49 | 0 | 45 | 4% | 1.2 | 33 (22) | 64 (70) | 10 (17) | 70 (25) | 43 (84) |
| Mine | Wizard | 14 | 4 (14) | 4 | 0 | 54 | 29% | 2.3 | 0 (4) | 0 (5) | 0 (1) | 0 (1) | 0 (9) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Chaff | 85 | 54 (85) | 28 | 26 | 47 | 35% | 2.3 | 45 (43) | 90 (13) | 49 (29) | 55 (67) | 49 (18) |
| Opponent | Character | 92 | 61 (92) | 61 | 0 | 25 | 18% | 2.1 | 78 (32) | 53 (53) | 51 (5) | 62 (57) | 63 (33) |
| Opponent | Clean-up | 22 | 49 (22) | 27 | 21 | 33 | 45% | 3.3 | 3 (6) | 39 (12) | 175 (4) | 74 (13) | 22 (9) |
| Opponent | Early | 3 | 0 (3) | 0 | 0 | 0 | 67% | 6.0 | - | 0 (3) | - | 0 (1) | 0 (2) |
| Opponent | Fast | 3 | 114 (3) | 114 | 0 | 67 | 100% | - | - | 114 (3) | - | 114 (3) | - |
| Opponent | Fast Hammer | 41 | 42 (41) | 20 | 22 | 49 | 27% | 3.0 | 12 (19) | 89 (10) | 64 (12) | 39 (25) | 45 (16) |
| Opponent | Fragile | 7 | 58 (7) | 58 | 0 | 25 | 29% | 1.4 | - | 66 (6) | 0 (1) | 0 (5) | 138 (2) |
| Opponent | Hammer | 62 | 38 (62) | 28 | 10 | 46 | 26% | 2.5 | 51 (13) | 33 (40) | 49 (9) | 35 (39) | 43 (23) |
| Opponent | Holder | 36 | 98 (36) | 12 | 86 | 17 | 33% | 2.5 | 91 (8) | 123 (21) | 35 (6) | 124 (23) | 71 (12) |
| Opponent | Shooter | 31 | 55 (31) | 22 | 33 | 36 | 3% | 1.7 | 0 (5) | 75 (22) | 10 (4) | 60 (19) | 49 (12) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | War machine | 15 | 76 (15) | 76 | 0 | 42 | 7% | 1.0 | 91 (5) | 54 (7) | 114 (3) | 112 (5) | 60 (10) |
| Opponent | Wizard | 24 | 28 (24) | 28 | 0 | 18 | 17% | 2.1 | 49 (9) | 20 (7) | 0 (5) | 61 (9) | 9 (12) |

### Charged fights: gf-h2h-opp-0533c46-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 4 | 202 | 425 | 2.2 | 1.1 | 189 | 45 | +144 | 7 of 9 | 6 of 9 | +250 | +131 |
| Mine | Dwarfen Mountain Holds | 10 | 586 | 8 | 1.2 | 1.2 | 7 | 15 | -9 | 5 of 12 | 7 of 12 | -42 | +2 |
| Mine | Empire of Man | 12 | 416 | 73 | 1.8 | 1.1 | 40 | 46 | -6 | 10 of 22 | 14 of 22 | +0 | -7 |
| Mine | Grand Cathay | 3 | 261 | 156 | 2.7 | 1.1 | 58 | 0 | +58 | 1 of 8 | 7 of 8 | +126 | +49 |
| Mine | High Elf Realms | 2 | 120 | 302 | 2.5 | 1.6 | 121 | 12 | +109 | 0 of 5 | 4 of 5 | +25 | +165 |
| Mine | Lizardmen | 1 | 0 | 182 | 3.0 | 1.0 | 61 | 0 | +61 | 0 of 3 | 3 of 3 | - | +61 |
| Mine | Ogre Kingdoms | 2 | 55 | 312 | 5.0 | 1.1 | 62 | 74 | -12 | 3 of 10 | 6 of 10 | -40 | -9 |
| Mine | Skaven | 1 | 195 | 127 | 1.0 | 1.0 | 127 | 0 | +127 | 0 of 1 | 1 of 1 | - | +127 |
| Mine | Tomb Kings of Khemri | 1 | 40 | 559 | 4.0 | 1.0 | 140 | 0 | +140 | 0 of 4 | 4 of 4 | - | +140 |
| **Mine** | all armies | 36 | 362 | 145 | 2.1 | 1.1 | 70 | 32 | +38 | 26 of 74 | 52 of 74 | +26 | +40 |
| Opponent | Empire of Man | 3 | 203 | 63 | 1.0 | 1.0 | 63 | 0 | +63 | 1 of 3 | 3 of 3 | - | +63 |
| Opponent | Grand Cathay | 1 | 395 | 480 | 3.0 | 1.0 | 160 | 0 | +160 | 0 of 3 | 3 of 3 | - | +160 |
| Opponent | High Elf Realms | 5 | 242 | 492 | 3.0 | 1.1 | 164 | 45 | +119 | 7 of 15 | 11 of 15 | +280 | +94 |
| Opponent | Kingdom of Bretonnia | 1 | 170 | 444 | 3.0 | 1.0 | 148 | 0 | +148 | 1 of 3 | 1 of 3 | - | +148 |
| Opponent | Ogre Kingdoms | 5 | 409 | 175 | 3.4 | 1.1 | 51 | 50 | +2 | 9 of 17 | 7 of 17 | -17 | +4 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 411 | 4.0 | 1.0 | 103 | 0 | +103 | 1 of 4 | 3 of 4 | - | +103 |
| Opponent | Skaven | 2 | 292 | 372 | 3.0 | 1.0 | 124 | 35 | +89 | 2 of 6 | 4 of 6 | - | +89 |
| Opponent | Tomb Kings of Khemri | 5 | 86 | 842 | 5.4 | 1.1 | 156 | 23 | +133 | 14 of 27 | 23 of 27 | +82 | +142 |
| Opponent | Vampire Counts | 6 | 12 | 476 | 4.8 | 1.3 | 99 | 6 | +93 | 14 of 29 | 23 of 29 | +94 | +93 |
| Opponent | Warriors of Chaos | 3 | 0 | 476 | 2.7 | 1.1 | 178 | 0 | +178 | 3 of 8 | 5 of 8 | +424 | +143 |
| Opponent | Wood Elf Realms | 4 | 65 | 868 | 4.8 | 1.1 | 183 | 12 | +171 | 6 of 19 | 13 of 19 | +250 | +162 |
| **Opponent** | all armies | 36 | 160 | 488 | 3.7 | 1.1 | 131 | 21 | +111 | 58 of 134 | 96 of 134 | +135 | +107 |

### Effective charges: gf-h2h-opp-0533c46-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 9 | 2 (net -48) | 0 | 1 (net +380) | 3 (net +425) | 1 (net +45) | 1 (net +0) | 1 | 12% (1 of 8) |
| Mine | Dwarfen Mountain Holds | 12 | 2 (net -32) | 0 | 3 (net -20) | 2 (net -30) | 0 | 5 (net +16) | 0 | 25% (3 of 12) |
| Mine | Empire of Man | 22 | 3 (net -127) | 2 (net +0) | 6 (net +89) | 4 (net +15) | 0 | 7 (net -51) | 0 | 27% (6 of 22) |
| Mine | Grand Cathay | 8 | 0 | 0 | 0 | 4 (net +58) | 3 (net +37) | 1 (net +126) | 0 | 0% (0 of 8) |
| Mine | High Elf Realms | 5 | 0 | 0 | 1 (net +236) | 1 (net -60) | 1 (net +110) | 1 (net +258) | 1 | 25% (1 of 4) |
| Mine | Lizardmen | 3 | 0 | 0 | 0 | 1 (net +55) | 0 | 0 | 2 | 0% (0 of 1) |
| Mine | Ogre Kingdoms | 10 | 0 | 0 | 0 | 4 (net -6) | 0 | 2 (net +32) | 4 | 0% (0 of 6) |
| Mine | Skaven | 1 | 0 | 0 | 0 | 0 | 1 (net +127) | 0 | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 4 | 0 | 0 | 2 (net +30) | 1 (net +170) | 0 | 1 (net +329) | 0 | 50% (2 of 4) |
| Opponent | Empire of Man | 3 | 0 | 0 | 1 (net +189) | 0 | 0 | 2 (net +0) | 0 | 33% (1 of 3) |
| Opponent | Grand Cathay | 3 | 0 | 0 | 1 (net +230) | 2 (net +125) | 0 | 0 | 0 | 33% (1 of 3) |
| Opponent | High Elf Realms | 15 | 1 (net +0) | 0 | 5 (net +132) | 3 (net +121) | 1 (net +0) | 2 (net +332) | 3 | 42% (5 of 12) |
| Opponent | Kingdom of Bretonnia | 3 | 1 (net +217) | 0 | 1 (net +227) | 0 | 0 | 0 | 1 | 50% (1 of 2) |
| Opponent | Ogre Kingdoms | 17 | 8 (net +35) | 0 | 1 (net -34) | 1 (net -251) | 0 | 3 (net +20) | 4 | 8% (1 of 13) |
| Opponent | Orc & Goblin Tribes | 4 | 1 (net +297) | 0 | 0 | 0 | 0 | 0 | 3 | 0% (0 of 1) |
| Opponent | Skaven | 6 | 2 (net +56) | 0 | 1 (net +0) | 1 (net +0) | 0 | 2 (net +210) | 0 | 17% (1 of 6) |
| Opponent | Tomb Kings of Khemri | 27 | 2 (net +88) | 0 | 7 (net +125) | 8 (net +152) | 0 | 9 (net +136) | 1 | 27% (7 of 26) |
| Opponent | Vampire Counts | 29 | 3 (net +132) | 1 (net -60) | 4 (net +153) | 10 (net +63) | 5 (net +85) | 5 (net +101) | 1 | 14% (4 of 28) |
| Opponent | Warriors of Chaos | 8 | 0 | 0 | 1 (net +0) | 1 (net +190) | 0 | 2 (net +174) | 4 | 25% (1 of 4) |
| Opponent | Wood Elf Realms | 19 | 4 (net +180) | 0 | 0 | 6 (net +276) | 2 (net +115) | 3 (net +119) | 4 | 0% (0 of 15) |

### Charged fights, damage counted: gf-h2h-opp-0533c46-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 7 | 189 | 312 | -77 | 16 | 85 | -69 | -36.5 |
| Mine | 50-54% | 2 | 227 | 312 | +0 | 37 | 53 | -16 | -7.3 |
| Mine | Effective (55-75%) | 13 | 246 | 230 | +89 | 122 | 31 | +91 | +36.9 |
| Mine | 76-89% | 20 | 275 | 178 | +82 | 152 | 56 | +96 | +34.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 18 | 194 | 192 | +28 | 87 | 53 | +34 | +17.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 407 | 65 | +65 | 65 | 1 | +64 | +15.8 |
| Mine | No odds | 8 | 152 | 202 | -43 | 30 | 58 | -29 | -18.9 |
| Mine | All fights | 74 | 238 | 200 | +38 | 94 | 49 | +45 | +19.0 |
| Opponent | Long shot (under 50%) | 22 | 154 | 180 | +100 | 136 | 28 | +108 | +70.3 |
| Opponent | 50-54% | 1 | 50 | 50 | -60 | 0 | 93 | -93 | -186.7 |
| Opponent | Effective (55-75%) | 22 | 307 | 226 | +126 | 181 | 67 | +114 | +37.0 |
| Opponent | 76-89% | 32 | 379 | 204 | +127 | 176 | 38 | +138 | +36.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 28 | 253 | 188 | +128 | 168 | 36 | +132 | +52.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 480 | 82 | +82 | 93 | 46 | +47 | +9.9 |
| Opponent | No odds | 21 | 159 | 157 | +78 | 106 | 39 | +67 | +42.3 |
| Opponent | All fights | 134 | 273 | 185 | +111 | 151 | 42 | +110 | +40.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gf-h2h-opp-0533c46-p2 | move | 459 | 94 (20%) | 64 (14%) | 41 (9%) | 324 (71%) |
| gf-h2h-opp-0533c46-p2 | objective | 398 | 54 (14%) | 40 (10%) | 44 (11%) | 300 (75%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0334, L0524, L0527, L0626, L0724, L0925, L0934, L2226 |
| Clockwork Compass | Mine | L1215, L1222 |
| Clockwork Compass | Opponent | L0312 |
| Elixir of Power | Mine | L1118 |
| Elixir of Power | Opponent | L1819 |
| Fistful of Laurels | Mine | L1819, L1832 |
| Fistful of Laurels | Opponent | L0518, L0618, L0718, L0818, L1118 |
| Horn of the Wild Hunt | Opponent | L1533 |
| Invocation of Nehek | Opponent | L0524, L0527, L0724, L0925 |
| Opal Amulet | Opponent | L0314 |
| Periapt of Soul Exchange | Mine | L2122 |
| Periapt of Soul Exchange | Opponent | L0520, L0720 |
| Ring of Doom | Mine | L1118, L1215, L1222, L1533, L1535 |
| Ring of Doom | Opponent | L0312, L0531, L0715, L0915, L1215, L1533 |
| Ring of Jet | Mine | L1118, L1215, L1222 |
| Ring of Jet | Opponent | L0312 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2122 |
| Twice-Blessed Armour | Mine | L0715, L0718, L0720, L0724 |
| Twice-Blessed Armour | Opponent | L0407 |
| Witch Hunter's Ward | Mine | L0715, L0718, L0720, L0724, L0809, L0818, L0823 |
| Witch Hunter's Ward | Opponent | L0407 |

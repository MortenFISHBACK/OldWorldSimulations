# Doctrine scorecard: gf-h2h-mine-0533c46-p2

### Scorecard: gf-h2h-mine-0533c46-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0312 | 6 | 1 | Mine | no | 0 | 5 | 0 | 1 | 0 | 0 | 0 | 445 |
| L0312 | 6 | 1 | Opponent | no | 6 | 5 | 1 | 1 | 1 | 0 | 0 | 330 |
| L0314 | 2 | 1 | Mine | - | - | - | 0 | 2 | 1 | 0 | 0 | 794 |
| L0314 | 2 | 1 | Opponent | - | - | 1 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0334 | 4 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 760 |
| L0334 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 0 | 0 | 0 | 56 |
| L0407 | 5 | 1 | Mine | yes | - | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0407 | 5 | 1 | Opponent | yes | - | 4 | 2 | 1 | 0 | 0 | 0 | 420 |
| L0518 | 2 | 1 | Mine | - | - | 6 | 1 | 0 | 0 | 0 | 0 | 836 |
| L0518 | 2 | 1 | Opponent | - | - | 2 | 0 | 3 | 0 | 0 | 0 | 185 |
| L0520 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 1120 |
| L0520 | 4 | 1 | Opponent | no | 1 | 2 | 2 | 3 | 0 | 0 | 0 | 210 |
| L0524 | 2 | 1 | Mine | - | - | 3 | 1 | 1 | 0 | 0 | 0 | 548 |
| L0524 | 2 | 1 | Opponent | - | - | 2 | 0 | 3 | 0 | 0 | 0 | 0 |
| L0527 | 5 | 1 | Mine | no | - | 3 | 4 | 1 | 0 | 0 | 0 | 475 |
| L0527 | 5 | 1 | Opponent | yes | - | - | 1 | 4 | 0 | 0 | 0 | 0 |
| L0531 | 3 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 475 |
| L0531 | 3 | 1 | Opponent | no | 1 | - | 2 | 2 | 1 | 0 | 0 | 340 |
| L0609 | 3 | 1 | Mine | no | 0 | 6 | 0 | 1 | 0 | 0 | 0 | 801 |
| L0609 | 3 | 1 | Opponent | no | 2 | - | 0 | 3 | 0 | 0 | 0 | 524 |
| L0618 | 6 | 1 | Mine | no | 0 | 5 | 1 | 2 | 0 | 0 | 0 | 801 |
| L0618 | 6 | 1 | Opponent | no | 0 | 5 | 4 | 0 | 1 | 0 | 0 | 0 |
| L0622 | 4 | 1 | Mine | no | 0 | 4 | 3 | 0 | 0 | 0 | 0 | 1014 |
| L0622 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 1 | 0 | 0 | 55 |
| L0626 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 743 |
| L0626 | 2 | 1 | Opponent | - | - | 2 | 1 | 4 | 1 | 0 | 0 | 0 |
| L0630 | 6 | 1 | Mine | no | 0 | - | 2 | 1 | 0 | 0 | 0 | 798 |
| L0630 | 6 | 1 | Opponent | no | 2 | 5 | 2 | 0 | 1 | 0 | 0 | 0 |
| L0715 | 1 | 1 | Mine | no | 2 | 2 | 4 | 1 | 0 | 0 | 0 | 375 |
| L0715 | 1 | 1 | Opponent | no | 4 | 1 | 5 | 0 | 1 | 0 | 0 | 0 |
| L0718 | 4 | 1 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 420 |
| L0718 | 4 | 1 | Opponent | no | 1 | 4 | 3 | 3 | 0 | 0 | 0 | 234 |
| L0720 | 6 | 1 | Mine | no | 0 | 1 | 2 | 0 | 0 | 0 | 0 | 452 |
| L0720 | 6 | 1 | Opponent | no | 2 | - | 3 | 1 | 1 | 0 | 0 | 0 |
| L0724 | 4 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 530 |
| L0724 | 4 | 1 | Opponent | no | 0 | 3 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0809 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 807 |
| L0809 | 5 | 1 | Opponent | no | - | - | 0 | 3 | 0 | 0 | 0 | 420 |
| L0818 | 2 | 1 | Mine | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 605 |
| L0818 | 2 | 1 | Opponent | - | - | 3 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 0 | 2 | 1 | 0 | 1 | 0 | 0 | 605 |
| L0823 | 1 | 1 | Opponent | no | 1 | 2 | 3 | 4 | 2 | 0 | 0 | 136 |
| L0913 | 1 | 1 | Mine | no | 0 | 1 | 1 | 1 | 1 | 0 | 0 | 913 |
| L0913 | 1 | 1 | Opponent | no | 9 | 2 | 3 | 1 | 2 | 0 | 0 | 140 |
| L0915 | 3 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 1057 |
| L0915 | 3 | 1 | Opponent | yes | 8 | 2 | 7 | 1 | 1 | 0 | 0 | 0 |
| L0916 | 4 | 1 | Mine | no | 0 | 4 | 5 | 1 | 0 | 0 | 0 | 537 |
| L0916 | 4 | 1 | Opponent | no | 2 | 2 | 5 | 1 | 1 | 0 | 0 | 200 |
| L0925 | 1 | 1 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 751 |
| L0925 | 1 | 1 | Opponent | no | 0 | - | 4 | 3 | 0 | 0 | 0 | 0 |
| L0934 | 4 | 1 | Mine | no | 0 | 5 | 0 | 0 | 0 | 0 | 0 | 1228 |
| L0934 | 4 | 1 | Opponent | no | 0 | 2 | 5 | 3 | 0 | 0 | 0 | 160 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 5 | 1 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 4 | 3 | 2 | 1 | 0 | 0 | 370 |
| L1215 | 3 | 1 | Mine | no | 5 | 3 | 3 | 1 | 0 | 0 | 0 | 330 |
| L1215 | 3 | 1 | Opponent | yes | 2 | 2 | 1 | 0 | 0 | 0 | 0 | 395 |
| L1222 | 4 | 1 | Mine | no | 0 | 5 | 1 | 0 | 1 | 0 | 0 | 330 |
| L1222 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1533 | 3 | 1 | Mine | no | 2 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1533 | 3 | 1 | Opponent | no | 0 | 1 | 5 | 1 | 0 | 0 | 0 | 352 |
| L1535 | 5 | 1 | Mine | yes | - | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 3 | 2 | 4 | 0 | 0 | 0 | 0 |
| L1722 | 6 | 1 | Mine | no | 1 | 3 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1722 | 6 | 1 | Opponent | no | 3 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Mine | no | 0 | 5 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 0 | 2 | 7 | 2 | 0 | 0 | 0 | 0 |
| L1832 | 2 | 1 | Mine | - | - | 1 | 5 | 0 | 1 | 0 | 0 | 251 |
| L1832 | 2 | 1 | Opponent | - | - | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L2122 | 4 | 1 | Mine | no | 0 | - | 0 | 3 | 1 | 0 | 0 | 355 |
| L2122 | 4 | 1 | Opponent | no | 0 | 2 | 7 | 1 | 0 | 0 | 0 | 55 |
| L2226 | 6 | 1 | Mine | no | 2 | 2 | 2 | 0 | 1 | 0 | 0 | 170 |
| L2226 | 6 | 1 | Opponent | no | 8 | 3 | 7 | 0 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 7% | 0.5 | 3.2 | 1.7 | 0.8 | 0.2 | 0.0 | 0.0 | 546.0 |
| **Average** | | | Opponent | 17% | 2.1 | 2.5 | 3.1 | 1.9 | 0.5 | 0.0 | 0.0 | 127.3 |

### KPIs: gf-h2h-mine-0533c46-p2

Rules off - Opponent only: GUN FIGURES, GUN MASK, GUN VIEW, GUN THREAT, STAY WORTH, BEST MOVE FOR SHOOTERS, FACE THE CAST, WIZARD FRONT RANK, FIRE PLAN, FIRE IN ORDER, KEEPS THE TARGET, MISSILES IN THE FIRE PLAN, THREAT AT FULL SIZE, SHOOTERS ARE THREATS, SHOOTERS TO THE PRIMARY, EVERY WOUND COUNTS, HONEST THREAT, ONE YARDSTICK.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 54% (96 of 178) | 2% (4 of 178) | 28% (100 of 356) |
| Winner chose to follow up after the loser gave ground |  | 94% (45 of 48); on the table 96% | 98% (59 of 60); on the table 100% | 96% (104 of 108); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 67% (6 of 9); on the table 78% | 94% (16 of 17); on the table 94% | 85% (22 of 26); on the table 88% |
| Winner chose to pursue after the loser fled |  | 56% (19 of 34); on the table 71% | 61% (27 of 44); on the table 70% | 59% (46 of 78); on the table 71% |
| Winner chose to follow up or pursue (all three) |  | 77% (70 of 91); on the table 85% | 84% (102 of 121); on the table 88% | 81% (172 of 212); on the table 87% |
| Magic missiles tried each own turn | 50%+ | 35% (77 of 222) | 33% (60 of 180) | 34% (137 of 402) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 50% (77 of 153) | 36% (54 of 148) | 44% (131 of 301) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 23% (28 of 120) | 23% (25 of 108) | 23% (53 of 228) |
|     round 1 |  | 15% (3 of 20) | 6% (1 of 18) | 11% (4 of 38) |
|     rounds 2+ |  | 25% (25 of 100) | 27% (24 of 90) | 26% (49 of 190) |
|   other wizards | 50%+ | 48% (49 of 102) | 44% (29 of 66) | 46% (78 of 168) |
|     round 1 |  | 41% (7 of 17) | 27% (3 of 11) | 36% (10 of 28) |
|     rounds 2+ |  | 49% (42 of 85) | 47% (26 of 55) | 49% (68 of 140) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 54% (7 of 13) | 68% (23 of 34) | 64% (30 of 47) |
| Points that never fought | lower | 46% (32787 of 71134) | 49% (34932 of 71985) | 47% (67719 of 143119) |
|   infantry points that never fought | lower | 45% (7740 of 17321) | 69% (9519 of 13831) | 55% (17259 of 31152) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 63% (199 of 317) | 61% (164 of 269) | 62% (363 of 586) |
| Bound items with a magic missile used (at least once a game) |  | 80% (12 of 15); 1.0 uses a game | 79% (15 of 19); 1.4 uses a game | 79% (27 of 34); 1.2 uses a game |
| Bound items with another spell used |  | 75% (3 of 4); 0.2 uses a game | 22% (2 of 9); 0.1 uses a game | 38% (5 of 13); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 29% (4 of 14); 0.1 uses a game | 50% (5 of 10); 0.1 uses a game | 38% (9 of 24); 0.1 uses a game |
|   their share of the points of units over 100 pts | lower | 61% (36050 of 59205) | 55% (34709 of 62613) | 58% (70759 of 121818) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.1 (28%) | 0.8 (25%) | 2.0 (27%) |
| MARCHED: its unit marched | 0.8 (19%) | 0.8 (25%) | 1.6 (22%) |
| CHARGED: its unit charged | 0.1 (3%) | 0.3 (8%) | 0.4 (6%) |
| IN COMBAT: engaged in combat | 0.8 (19%) | 0.4 (13%) | 1.2 (17%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.1 (2%) | 0.1 (2%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 0.9 (22%) | 0.2 (8%) | 1.1 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (4%) | 0.0 (1%) | 0.2 (3%) |
| NOT OFFERED: not in the cast list | 0.0 (1%) | 0.6 (18%) | 0.6 (8%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.1 | 0.7 | 1.4 | 3.8 | 0.2 | 1.2 |
| not cast | 3.1 | 2.5 | 2.4 | 7.4 | 0.9 | 14.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.9 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.5 (20%) | 0.2 (8%) | 2.0 (27%) | 0.2 (26%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.6 (22%) | 0.2 (18%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (6%) | 0.0 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.2 (7%) | 0.4 (16%) | 1.2 (17%) | 0.1 (9%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (10%) | 0.9 (35%) | 0.5 (19%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (3%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (5%) | 0.1 (5%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.4 (3%) |
| GONE: slain | 1.1 (35%) | 0.4 (18%) | 0.5 (20%) | 1.1 (15%) | 0.1 (6%) | 2.5 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (11%) | 0.2 (8%) | 0.2 (9%) | 0.2 (3%) | 0.0 (3%) | 0.6 (4%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.2 (8%) | 0.0 (0%) | 0.0 (0%) | 0.3 (32%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.6 (8%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.0 (32%) | 0.0 (0%) | 0.5 (22%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 10.3 (70%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.4 a game | 1.0 a game | 0.7 a game |
| stood (cast and not dispelled) | 83% (5 of 6) | 76% (16 of 21) | 78% (21 of 27) |
| the unit moved after it | 40% (2 of 5) | 69% (11 of 16) | 62% (13 of 21) |
| it charged on its next turn | 20% (1 of 5) | 0% (0 of 16) | 5% (1 of 21) |
| the enemy charged it first | 0% (0 of 5) | 12% (2 of 16) | 10% (2 of 21) |
| it fought by the end of its next turn | 0% (0 of 5) | 0% (0 of 16) | 0% (0 of 21) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 5) | 25% (4 of 16) | 19% (4 of 21) |
| none of these (no charge, no fight, no charge escaped) | 80% (4 of 5) | 62% (10 of 16) | 67% (14 of 21) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 73% (1018 of 1403) | 55% (475 of 864) | 66% (1493 of 2267) |
|   cavalry | 64% (49 of 76) | 70% (69 of 98) | 68% (118 of 174) |
|   character | 76% (143 of 187) | 26% (40 of 156) | 53% (183 of 343) |
|   chariot | 67% (78 of 116) | 68% (46 of 68) | 67% (124 of 184) |
|   infantry | 59% (245 of 414) | 53% (217 of 407) | 56% (462 of 821) |
|   monster | 64% (43 of 67) | 57% (32 of 56) | 61% (75 of 123) |
|   war machine | 85% (460 of 543) | 90% (71 of 79) | 85% (531 of 622) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.8 (26%) | 3.5 (32%) | 6.3 (29%) |
| CHARGED: it charged | 1.1 (11%) | 2.4 (22%) | 3.6 (17%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| IN COMBAT: it fought this turn or the last | 1.6 (15%) | 0.6 (5%) | 2.2 (10%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.9 (18%) | 1.6 (15%) | 3.5 (16%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (6%) | 0.5 (5%) | 1.2 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.5 (14%) | 2.0 (18%) | 3.5 (16%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.0 (0%) | 0.4 (2%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.6 (5%) | 0.2 (2%) | 0.7 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.6 | 1.3 | 81% | 4.2 pts | 24 pts |
| character | 5.3 | 2.1 | 73% | 8.5 pts | 45 pts |
| chariot | 3.5 | 2.3 | 65% | 13.9 pts | 49 pts |
| infantry | 18.2 | 6.8 | 73% | 9.7 pts | 177 pts |
| monster | 2.4 | 0.9 | 81% | 8.8 pts | 22 pts |
| war machine | 15.0 | 13.3 | 59% | 23.2 pts | 347 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.4 | 5.7 | 4.5 |
| Charges that made contact a game | 2.2 | 4.1 | 3.1 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.63 declared, 0.47 contact (19 units) | 0.92 declared, 0.46 contact (13 units) | 0.75 declared, 0.47 contact (32 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.33 declared, 0.00 contact (3 units) | 0.57 declared, 0.43 contact (7 units) | 0.50 declared, 0.30 contact (10 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.44 declared, 0.28 contact (248 units) | 0.65 declared, 0.48 contact (290 units) | 0.55 declared, 0.39 contact (538 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 61% (35 of 57) | 36% (5 of 14) | 71% (5 of 7) | 58% (45 of 78) |
| Character in a unit | 76% (34 of 45) | 80% (12 of 15) | 100% (2 of 2) | 77% (48 of 62) |
| Character on its own | 81% (26 of 32) | 52% (14 of 27) | 38% (22 of 58) | 53% (62 of 117) |
| Chariot | 73% (16 of 22) | 82% (14 of 17) | - | 77% (30 of 39) |
| Infantry | 51% (47 of 92) | 50% (18 of 36) | 60% (3 of 5) | 51% (68 of 133) |
| Monster | 77% (20 of 26) | 69% (9 of 13) | - | 74% (29 of 39) |
| Monstrous | 100% (8 of 8) | 64% (16 of 25) | - | 73% (24 of 33) |
| War Machines | 66% (54 of 82) | 100% (3 of 3) | - | 67% (57 of 85) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 4 | 88% (7 of 8); on the table 100% | 44% (16 of 36) | 49% | 81% (26 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 0.8 uses a game |
| Dwarfen Mountain Holds | 10 | 47% (8 of 17); on the table 65% | - | 60% | 64% (54 of 85) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 15 | 79% (22 of 28); on the table 89% | 41% (47 of 114) | 51% | 63% (100 of 159) | 0.0 uses a game | 60% (3 of 5); 0.6 uses a game | 0% (0 of 8); 0.0 uses a game |
| Grand Cathay | 4 | 100% (8 of 8); on the table 100% | 31% (30 of 96) | 56% | 60% (21 of 35) | 73% (8 of 11); 7.2 uses a game | 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| High Elf Realms | 7 | 74% (23 of 31); on the table 74% | 8% (2 of 24) | 28% | 42% (22 of 52) | 82% (9 of 11); 3.1 uses a game | 25% (2 of 8); 0.6 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (2 of 2); on the table 100% | - | 53% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | 100% (1 of 1); on the table 100% | - | 11% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 7 | 80% (20 of 25); on the table 84% | 17% (6 of 36) | 57% | 71% (35 of 49) | 71% (5 of 7); 3.1 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (2 of 2); on the table 100% | 25% (3 of 12) | 18% | 12% (1 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 3 | 71% (10 of 14); on the table 86% | 44% (8 of 18) | 31% | 48% (11 of 23) | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Tomb Kings of Khemri | 6 | 85% (22 of 26); on the table 85% | 0% (0 of 6) | 43% | 60% (18 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 6 | 91% (21 of 23); on the table 96% | 40% (19 of 48) | 53% | 61% (22 of 36) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 3 | 100% (15 of 15); on the table 100% | 33% (2 of 6) | 42% | 69% (18 of 26) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |
| Wood Elf Realms | 4 | 92% (11 of 12); on the table 100% | 67% (4 of 6) | 35% | 71% (27 of 38) | 100% (3 of 3); 2.0 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gf-h2h-mine-0533c46-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 44% (35) | 49% (24) | 46% (59) |
| ...free all their last turn and able to turn (per game) | 0.64 | 0.50 | 1.14 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.19 | 0.03 | 0.22 |
| ...with the charger already in that arc before they moved (per game) | 0.42 | 0.33 | 0.75 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.67 | 1.36 | 3.03 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.81 | 1.11 | 1.92 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.69 | 6.31 | 12.00 |

### Quality by phase: gf-h2h-mine-0533c46-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.3 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 51% (53 of 104) | 46% (86 of 186) |
| Strategy | Shoot objectives carried out (shot that target) | 35% (248 of 716) | 55% (135 of 247) |
| Strategy | Close-in objectives charged next turn | 11% (13 of 123) | 15% (40 of 259) |
| Strategy | Support requests answered (helper made contact too) | 59% (10 of 17) | 34% (12 of 35) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 20% (1 of 5) | 67% (2 of 3) |
| Strategy | Joined characters whose unit fought | 42% (25 of 59) | 28% (12 of 43) |
| Strategy | Lone characters that fought | 62% (54 of 87) | 67% (49 of 73) |
| Movement | Charges halted short of contact | 0.4 | 0.2 |
| Movement | Idle units | 0.8 | 1.9 |
| Movement | Points that never moved of their own | 546.0 | 127.3 |
| Movement | Fights charged into per game | 1.9 | 3.7 |
| Movement | Charges with odds: long shots (under 50%) | 8 of 64, net +67 | 21 of 109, net +108 |
| Movement | Charges with odds: sweet spot (55-75%) | 11 of 64, net +116 | 24 of 109, net +188 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 6 of 64, net +78 | 7 of 109, net +67 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 15 of 64, net +64 | 35 of 109, net +129 |
| Shooting | Shots by shooting units (incl. breath weapons) | 16.3 | 12.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (270 of 588) | 39% (174 of 446) |
| Shooting | Points destroyed by shooting units | 127.2 | 63.2 |
| Shooting | War machine shots | 12.8 | 2.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (232 of 460) | 42% (33 of 78) |
| Shooting | Points destroyed by war machines | 165.4 | 24.3 |
| Magic | Magic missiles cast | 1.0 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 50% (18 of 36) | 46% (19 of 41) |
| Magic | Wounds caused by magic missiles | 2.2 | 1.5 |
| Magic | Wounds caused by other spells | 0.6 | 1.1 |
| Magic | Points destroyed by magic (all spells) | 35.7 | 33.4 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.5 / 0.1 / 0.3 / 0.0 | 2.3 / 0.1 / 0.5 / 0.1 |
| Combat | Points destroyed in combat | 173.7 | 353.6 |
| Combat | Points run down | 59.8 | 63.6 |
| Combat | Net points per charged fight, damage counted | +98 | +125 |
| Combat | Net per 100 charger points, damage counted | +39.4 | +45.6 |
| Combat | First round won (charged fights) | 81% | 72% |
| Combat | Net points per charged fight | +97 | +120 |
| Combat | Net points per supported fight / lone fight | +165 / +82 | +126 / +119 |
| Combat | Charged fights on a top-3 enemy unit | 22 of 67 | 56 of 133 |
| Game | Points lost | 729.5 | 645.5 |
| Game | VP from objectives | 493.3 | 621.9 |
| Game | Lone holders (player turns) | 0.5 | 2.1 |

- Mine won / drew / lost: 12 / 7 / 17 of 36 ended games (of 36); mean margin (Mine - Opponent) -211 VP
- The side that went first won 14 of 29 games with a winner
- Points traded per game (both sides' losses): 1375
- Games not ended: 0; findings 0, warnings 1

### Opponent rules: gf-h2h-mine-0533c46-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.5 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 5.1 |
| ARRIVAL HUNT | - | - | - | - | 0.2 | +6.7 | 0.0 | 2.5 |
| ARTILLERY RE-ROLL WEIGHED | 2.8 | +0.0 | 0.0 | 67.4 | 0.3 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.9 | +6.8 | 0.0 | 40.3 | 1.1 | +8.3 | 0.0 | 30.3 |
| BEST FACING | 0.8 | +33.0 | 0.0 | 34.1 | 0.7 | +30.0 | 0.0 | 22.5 |
| BEST FIRST | 4.4 | +175.0 | 129.2 | 91.0 | 4.9 | +187.3 | 134.9 | 81.2 |
| BEST MOVE FOR SHOOTERS | 1.2 | +154.7 | 0.0 | 16.7 | - | - | - | - |
| BEST OVERALL | 0.9 | +83.8 | 0.0 | 2.4 | 0.7 | +37.7 | 0.0 | 22.3 |
| BEST PREY | 0.7 | +39.5 | 37.9 | 16.7 | 0.7 | +24.9 | 8.4 | 0.0 |
| BEST PRIZE | 0.1 | -2.0 | 1.8 | 7.8 | 0.2 | -21.8 | 8.7 | 3.2 |
| BIG CHARACTER SAFETY | 0.1 | -0.3 | 0.0 | 27.1 | 0.2 | -0.8 | 0.0 | 41.6 |
| BLOCKED CHARGE SKIPPED | - | - | - | - | 0.0 | +0.0 | 4.9 | 0.0 |
| BLOCKED WHEEL | 0.2 | +4.0 | 0.0 | 2.6 | 0.6 | +3.2 | 0.0 | 7.2 |
| BLOWS WHERE AIMED | 0.1 | +0.5 | 24.4 | 0.0 | 0.3 | -39.4 | 31.8 | 6.5 |
| BOMBING RUN | 0.0 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | - | - | - | - | 0.2 | +0.0 | 22.9 | 0.0 |
| CANNON PLANNED TARGET | - | - | - | - | 1.5 | +56.3 | 61.0 | 16.1 |
| CANNON SIGHT KEPT | 2.1 | +0.0 | 0.0 | 6.5 | 0.5 | +0.0 | 0.0 | 13.1 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | -3.3 | 6.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 15.3 | 0.0 | 0.2 | -1.5 | 12.8 | 8.7 |
| CAST JOB | 1.1 | +32.5 | 32.2 | 30.6 | 0.4 | +2.8 | 3.5 | 20.0 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | - | - | - | - | 0.3 | +13.5 | 12.8 | 0.0 |
| CASTS AFTER FRIENDS | 0.2 | +0.0 | 0.0 | 11.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +5.3 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | 0.0 | +0.3 | 0.0 | 0.0 | 0.0 | +2.4 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 0.2 | -0.2 | 0.0 | 5.8 |
| CHAMPION TAKES THE CHALLENGE | - | - | - | - | 0.0 | +0.3 | 5.1 | 0.0 |
| CHARGE BAND | 0.1 | +0.0 | 12.8 | 0.0 | 0.2 | +0.0 | 16.6 | 0.0 |
| CHARGE NOW FIRST | 1.9 | +0.0 | 217.3 | 54.4 | 2.7 | +0.0 | 290.4 | 73.5 |
| CHARGE NOW WEIGHED | 0.6 | -42.1 | 19.6 | 1.7 | 1.1 | -127.6 | 22.2 | 55.1 |
| CHARGER SLAIN LOST | 0.4 | -21.5 | 64.9 | 13.7 | 0.7 | -5.4 | 71.5 | 19.4 |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.9 | 7.6 | 11.0 | 0.2 | -0.9 | 5.2 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 20.0 | 0.0 | 0.3 | +0.0 | 18.9 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 3.8 | 51.9 | 0.3 | +0.0 | 25.2 | 25.0 |
| CONVEYANCE SEARCH | 0.1 | +11.5 | 0.0 | 0.0 | 0.5 | +72.7 | 10.6 | 18.2 |
| COUNTER-CHARGE COVER | 13.8 | +1445.5 | 0.0 | 223.4 | 8.1 | +775.7 | 0.0 | 237.2 |
| DEFENSIVE ARMY | 0.5 | +0.0 | 35.9 | 10.1 | 0.0 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | - | - | - | - | 0.0 | +0.2 | 0.0 | 1.5 |
| EDGE GIVE GROUND | 0.1 | +1.1 | 2.0 | 0.0 | 0.5 | +5.7 | 53.6 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +0.8 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.2 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EVERY WOUND COUNTS | 19.2 | +0.0 | 1092.9 | 260.7 | - | - | - | - |
| FACE THE CAST | 0.1 | +3.8 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.7 | +159.0 | 0.0 | 42.1 | 1.4 | +110.0 | 0.0 | 67.6 |
| FALLBACK BY WORTH | 4.5 | +66.6 | 0.0 | 70.6 | 6.0 | +56.7 | 0.0 | 55.8 |
| FIGHT LIFT | 0.1 | +0.1 | 0.0 | 0.0 | 0.1 | +1.7 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.0 | +1.9 | 0.0 | 0.0 | - | - | - | - |
| FIRE IN ORDER | 1.6 | +0.0 | 87.1 | 21.7 | - | - | - | - |
| FIRE PLAN | 30.6 | +159.1 | 1757.7 | 436.1 | - | - | - | - |
| FLANK NOT WEIGHED | 5.9 | +0.0 | 0.0 | 119.4 | 5.8 | +0.0 | 0.0 | 145.9 |
| FOLLOW UP WEIGHED | 0.5 | +57.3 | 0.0 | 16.3 | 1.1 | +179.6 | 0.0 | 6.5 |
| FRIENDS SHOTS CHECKED | 0.3 | +22.0 | 0.0 | 38.4 | 0.3 | +17.5 | 0.0 | 11.1 |
| GIVES UP | 0.1 | -0.2 | 11.6 | 0.0 | 0.1 | -0.3 | 4.7 | 0.0 |
| GUN FIGURES | 4.5 | +95.2 | 298.2 | 69.4 | - | - | - | - |
| GUN MASK | 0.6 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| GUN THREAT | 3.8 | +636.0 | 260.6 | 81.0 | - | - | - | - |
| GUN VIEW | 2.0 | +19.7 | 0.0 | 10.4 | - | - | - | - |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 12.3 | 1.7 | 0.1 | +0.0 | 19.4 | 2.8 |
| HELPER UNSEEN | 0.1 | +0.0 | 0.0 | 5.2 | 0.5 | +0.0 | 36.6 | 17.6 |
| HILL BY ITS CHANCE | 0.2 | -14.3 | 0.0 | 0.0 | 0.4 | -32.9 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.2 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| HONEST THREAT | 19.2 | +2858.8 | 1092.9 | 260.7 | - | - | - | - |
| HONEST WORTH | 6.4 | -93.1 | 282.1 | 132.9 | 10.1 | -232.3 | 491.5 | 234.6 |
| HUNT ADVANCE | 0.0 | +0.3 | 0.0 | 0.0 | 0.4 | +21.9 | 20.3 | 14.8 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 3.5 | 0.0 |
| HUNT IN PAIRS | 0.3 | +5.6 | 0.0 | 12.1 | 0.6 | +27.1 | 0.0 | 18.8 |
| HUNT KEPT | - | - | - | - | 0.3 | +16.3 | 24.9 | 6.4 |
| HUNT RESULT | 0.1 | +12.0 | 0.0 | 0.0 | 0.6 | +94.4 | 20.3 | 7.8 |
| HUNT THE GUNS | 0.1 | +40.9 | 16.5 | 0.0 | 0.6 | +228.2 | 44.1 | 12.6 |
| INVITES THE FIGHT | 2.1 | +37.5 | 60.5 | 8.0 | 1.2 | +13.9 | 22.8 | 12.2 |
| JOINT CHARGE PLAN | 0.1 | +0.1 | 2.9 | 7.7 | 0.3 | +8.6 | 5.2 | 3.1 |
| JOINT KNOWS CHALLENGE | 0.1 | -1.4 | 26.1 | 0.0 | 0.1 | -4.5 | 17.5 | 0.0 |
| KEEP FALLS | 0.1 | +3.6 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.1 | +0.5 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.3 | +38.3 | 112.6 | 39.4 | 2.5 | +74.2 | 171.1 | 33.8 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS THE TARGET | 2.0 | -305.2 | 206.9 | 34.0 | - | - | - | - |
| KILLS COUNT | 1.1 | +54.6 | 90.4 | 33.4 | 2.9 | +136.5 | 229.8 | 53.8 |
| KILLS COUNT NEXT TURN | 4.2 | +114.2 | 133.7 | 85.4 | 8.0 | +273.3 | 243.3 | 209.4 |
| LONE CHARACTER SAFE SPOT | 0.3 | +10.4 | 2.0 | 0.0 | 0.2 | +11.7 | 0.0 | 12.3 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.1 | +0.0 | 1.8 | 0.0 |
| LONE WIZARD KEPT IN | 0.5 | +24.3 | 0.0 | 0.0 | 0.4 | +32.7 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | -3.4 | 57.3 | 7.4 | 0.5 | -2.8 | 23.2 | 3.3 |
| LOST CHARGE | 3.0 | -57.7 | 130.2 | 83.1 | 2.8 | -41.4 | 42.2 | 92.7 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.0 | -1.3 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.6 | +17.9 | 23.9 | 38.6 | 1.9 | +173.5 | 27.4 | 103.9 |
| MANOEUVRE | 0.4 | +12.3 | 0.0 | 2.9 | 0.2 | +14.7 | 0.0 | 4.3 |
| MARCH AT ESCAPER | 0.0 | +0.3 | 0.0 | 2.4 | 0.1 | +0.4 | 0.0 | 0.0 |
| MARCH CHECK | 0.4 | +28.8 | 0.0 | 2.4 | 0.4 | +14.5 | 0.0 | 7.0 |
| MARCH ODDS | 0.1 | +2.9 | 5.4 | 8.2 | 0.2 | +21.5 | 2.9 | 19.0 |
| MARCH OVER CASTS | 0.4 | +36.9 | 0.0 | 50.9 | 0.4 | +7.4 | 0.0 | 12.1 |
| MAX FOR POSITIONING | 4.9 | +152.8 | 0.0 | 106.1 | 5.0 | +218.2 | 0.0 | 170.6 |
| MISSILES IN THE FIRE PLAN | 0.9 | +3.2 | 15.4 | 36.8 | - | - | - | - |
| MISSILES IN THE MOVE | 3.4 | +100.3 | 0.0 | 74.7 | 3.2 | +52.0 | 0.0 | 112.5 |
| MISSILES NEXT TURN | 3.8 | +71.1 | 0.0 | 126.2 | 4.0 | +37.9 | 0.0 | 124.5 |
| MODEL FACING | 0.8 | +249.7 | 0.0 | 13.3 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 0.0 | 21.1 | 0.2 | +0.0 | 8.6 | 10.6 |
| MOVE AND CAST | 0.4 | +17.6 | 0.0 | 10.6 | 0.3 | +9.6 | 0.0 | 14.1 |
| MOVE SPELL IN RANGE | 0.1 | +4.6 | 0.0 | 0.0 | 0.1 | +0.7 | 0.0 | 10.6 |
| MOVE SPELL OUT OF RANGE | 0.1 | -9.8 | 0.0 | 0.0 | 0.2 | -9.2 | 7.6 | 21.1 |
| MOVE SPELL SPOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 2.5 | +139.7 | 82.7 | 61.6 | 6.1 | +329.7 | 162.0 | 168.4 |
| MOVES UNITS SPELL | 0.1 | +0.4 | 0.0 | 0.0 | 0.1 | +0.7 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.0 | +14.9 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.1 | +2.2 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 3.2 |
| NOT NEEDED | 0.2 | -16.8 | 18.6 | 0.0 | 0.2 | -6.3 | 11.9 | 2.4 |
| NOT TURNED | 5.7 | +177.5 | 0.0 | 115.0 | 6.3 | +65.2 | 0.0 | 117.4 |
| NOT WORTH A CAST | 0.3 | -0.1 | 0.0 | 44.6 | 0.2 | -2.6 | 0.0 | 11.0 |
| OFF BEST | 16.5 | -842.7 | 15.0 | 249.4 | 15.9 | -777.8 | 13.1 | 307.2 |
| ONE YARDSTICK | 30.1 | -2081.0 | 975.4 | 476.1 | - | - | - | - |
| OPENS A LANE | 0.3 | +2.2 | 10.8 | 6.9 | 0.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.0 | +0.6 | 0.0 | 0.0 | 0.2 | +20.9 | 10.7 | 9.7 |
| OVERRUNS AWAY | 0.4 | +13.1 | 44.2 | 6.3 | 0.4 | +9.1 | 47.1 | 16.9 |
| PATHS CROSS | 1.4 | +97.0 | 0.0 | 40.4 | 3.0 | +186.2 | 0.0 | 40.3 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +4.6 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -2.1 | 0.0 | 4.9 | 0.2 | -3.2 | 0.0 | 10.6 |
| PLAN RESULT | 41.5 | +1945.9 | 1625.1 | 900.8 | 41.4 | +1155.8 | 1402.8 | 1021.5 |
| PURSUES BIG PREY | 0.1 | -1.8 | 0.0 | 0.0 | 0.2 | -9.1 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.0 | +2.4 | 0.0 | 2.7 |
| RANDOM MOVE BY FIGURES | 0.4 | +3.2 | 0.0 | 13.9 | 0.9 | +16.2 | 0.0 | 36.4 |
| RANDOM MOVER NO PROMISE | 0.0 | -0.5 | 0.0 | 0.0 | 0.1 | -10.3 | 3.5 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.1 | +0.5 | 0.0 | 0.0 | 0.2 | -4.7 | 0.0 | 7.1 |
| REDIRECT COUNTER | 1.1 | +62.9 | 0.0 | 16.3 | 3.3 | +296.3 | 0.0 | 45.6 |
| REDIRECT WEIGHED | 0.2 | +1.7 | 1.8 | 7.8 | 0.4 | -4.7 | 20.8 | 11.8 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 26.0 | 0.1 | +0.0 | 0.0 | 6.3 |
| RESERVE FALL BACK | 0.2 | +3.9 | 0.0 | 0.0 | 0.9 | +25.2 | 0.0 | 14.9 |
| RESTRAINS TO SHOOT | 0.2 | +6.1 | 0.0 | 3.4 | 0.1 | +4.1 | 0.0 | 0.0 |
| RISK BY ARC | 1.7 | +68.5 | 218.9 | 54.2 | 3.3 | +68.5 | 273.2 | 88.2 |
| SAFER THAN THE JOB | 0.8 | +68.5 | 0.0 | 24.4 | 1.1 | +70.3 | 0.0 | 57.9 |
| SCOUT SPOT | 0.6 | +0.6 | 0.0 | 0.9 | 0.7 | +3.7 | 0.0 | 1.8 |
| SCOUT WAITS | 0.6 | +0.0 | 0.0 | 0.9 | 0.8 | +0.0 | 0.0 | 1.8 |
| SCREEN BY WHAT IT SAVES | 0.0 | -0.4 | 0.0 | 0.0 | 0.5 | -22.7 | 0.0 | 0.9 |
| SEARCH SPOT | 2.8 | +121.8 | 0.0 | 31.3 | 3.1 | +151.5 | 0.0 | 30.5 |
| SECOND HUNTER | - | - | - | - | 0.1 | -1.0 | 11.8 | 3.2 |
| SELF MOVE SPELL | 0.2 | +77.7 | 0.0 | 21.9 | 0.5 | +131.6 | 0.0 | 21.9 |
| SET UP TOGETHER | 0.9 | +42.2 | 23.9 | 53.0 | 3.2 | +291.7 | 51.5 | 133.8 |
| SET-UP ANY TARGET | 0.1 | +33.9 | 0.0 | 0.0 | 0.3 | +57.2 | 10.6 | 18.2 |
| SET-UP MISSED | 0.1 | +11.2 | 0.0 | 0.0 | 0.1 | +7.7 | 0.0 | 10.6 |
| SHOOTER COUNTED ONCE | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ARE THREATS | 5.9 | +318.7 | 319.4 | 99.6 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.8 | +1.6 | 0.0 | 0.0 | 0.3 | +0.4 | 0.0 | 2.9 |
| SHOOTERS TO THE PRIMARY | 3.8 | +64.0 | 0.0 | 68.3 | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 1.0 | +36.2 | 41.0 | 14.4 | 1.2 | +29.5 | 31.0 | 12.1 |
| SHORT GUN FORWARD | 0.5 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OPTIONS | 26.6 | +0.0 | 1329.8 | 401.3 | 13.6 | +0.0 | 491.1 | 220.6 |
| SHOT REPLANNED | - | - | - | - | 0.4 | +0.0 | 55.6 | 5.1 |
| SHOTS IN THE MOVE | 24.9 | +1281.9 | 0.0 | 371.4 | 12.8 | +356.7 | 0.0 | 211.8 |
| SPELL SETS UP CHARGE | 0.1 | +33.9 | 0.0 | 0.0 | 0.3 | +60.5 | 10.6 | 18.2 |
| SPELL WORTH | 0.5 | +12.0 | 65.6 | 65.6 | 2.2 | +49.3 | 125.9 | 123.2 |
| SPELLS IN THE FIGHT | 0.4 | -1.9 | 99.6 | 29.6 | 0.8 | +0.2 | 126.7 | 17.0 |
| STABLE ROLE | 12.3 | +0.0 | 366.2 | 149.5 | 10.1 | +0.0 | 298.4 | 161.5 |
| STANDS TO CAST | 0.0 | +0.2 | 0.0 | 0.0 | 0.0 | +1.0 | 0.0 | 0.0 |
| STAY WEIGHED | 0.0 | +4.4 | 0.0 | 0.0 | - | - | - | - |
| STAY WORTH | 28.4 | +252.2 | 927.9 | 380.8 | - | - | - | - |
| STOPS | 0.1 | +0.8 | 16.5 | 0.0 | 0.5 | +21.0 | 48.7 | 4.2 |
| STOPS SHORT OF THE FLANK | 0.4 | +14.1 | 0.0 | 15.0 | 0.4 | +20.0 | 0.0 | 25.1 |
| STUCK PIVOT | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 4.3 | -43.2 | 209.0 | 72.8 | 6.8 | -43.0 | 422.2 | 114.9 |
| SUPPORTS | 2.9 | +49.4 | 91.5 | 41.6 | 4.4 | +46.2 | 189.3 | 82.3 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -4.9 | 7.8 | 6.0 | 0.1 | -3.0 | 5.5 | 0.0 |
| SURE REACH TOGETHER | 0.4 | -4.3 | 15.2 | 2.9 | 1.2 | +14.2 | 8.0 | 59.0 |
| THROUGH LINE OF FIRE | 0.7 | +27.6 | 0.0 | 11.2 | 0.4 | +11.1 | 0.0 | 4.2 |
| TURN WORTH | 0.1 | -4.6 | 3.2 | 0.0 | 0.2 | -12.0 | 9.9 | 9.7 |
| TWO OR MORE ARRIVE | 0.3 | +1.1 | 7.6 | 9.4 | 1.1 | +13.6 | 0.0 | 25.9 |
| WAIT AFTER COSTS | 6.6 | -286.4 | 198.2 | 110.7 | 9.0 | -420.6 | 232.5 | 222.3 |
| WALKS TO THE FIGHT | 1.8 | +32.7 | 40.5 | 18.0 | 0.9 | +17.8 | 13.8 | 29.7 |
| WAR ENGINE CHARGES | 0.1 | +10.6 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.5 | +0.0 | 23.4 | 3.6 | 0.1 | +0.0 | 5.1 | 15.4 |
| WEARS DOWN | 1.0 | +34.1 | 139.2 | 26.1 | 0.9 | +34.1 | 103.4 | 21.3 |
| WHO HITS BACK | 0.2 | +27.2 | 0.0 | 7.8 | 0.2 | +15.9 | 0.0 | 12.4 |
| WHOLE FIGHT | 0.2 | +14.4 | 17.9 | 3.8 | 0.4 | +28.7 | 65.9 | 3.4 |
| WHOLE FIGHT GAIN | 0.4 | +16.1 | 62.8 | 1.7 | 0.7 | +50.5 | 43.0 | 17.7 |
| WIDER SPREAD | 2.2 | -9.0 | 231.2 | 54.1 | 3.7 | -11.2 | 351.0 | 41.5 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |

### Rule changes: gf-h2h-mine-0533c46-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1169 | 1169 | 1169 | 32.47 | -58337 | -49.9 |
| BEST FIRST | 332 | 332 | 332 | 9.22 | +13044 | +39.3 |
| FIRE PLAN | 1102 | 1102 | 233 | 6.47 | +2208 | +9.5 |
| SEARCH SPOT | 212 | 212 | 212 | 5.89 | +9838 | +46.4 |
| COUNTER-CHARGE COVER | 787 | 455 | 199 | 5.53 | +15096 | +75.9 |
| SHOTS IN THE MOVE | 1356 | 908 | 169 | 4.69 | +4678 | +27.7 |
| PATHS CROSS | 160 | 160 | 160 | 4.44 | +10193 | +63.7 |
| KILLS COUNT NEXT TURN | 439 | 439 | 154 | 4.28 | +3633 | +23.6 |
| MOVE TO CHARGE | 309 | 309 | 151 | 4.19 | +5353 | +35.4 |
| EVERY WOUND COUNTS | 692 | 692 | 129 | 3.58 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 112 | 112 | 112 | 3.11 | +0 | +0.0 |
| FACES THE THREAT | 109 | 109 | 109 | 3.03 | +9682 | +88.8 |
| ONE YARDSTICK | 1084 | 559 | 108 | 3.00 | +1568 | +14.5 |
| CANNON SIGHT KEPT | 94 | 94 | 94 | 2.61 | +0 | +0.0 |
| SUPPORTS | 264 | 264 | 91 | 2.53 | +872 | +9.6 |
| FALLBACK BY WORTH | 377 | 377 | 78 | 2.17 | +4441 | +56.9 |
| SET UP TOGETHER | 147 | 126 | 72 | 2.00 | +5109 | +71.0 |
| SAFER THAN THE JOB | 69 | 69 | 69 | 1.92 | +4999 | +72.5 |
| WAIT AFTER COSTS | 562 | 562 | 68 | 1.89 | +1459 | +21.5 |
| CHARGE NOW WEIGHED | 59 | 59 | 59 | 1.64 | +4221 | +71.5 |
| FIRE IN ORDER | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 56 | 56 | 56 | 1.56 | +8531 | +152.3 |
| BEST OVERALL | 55 | 55 | 55 | 1.53 | +4374 | +79.5 |
| BEST FACING | 53 | 53 | 53 | 1.47 | +2268 | +42.8 |
| SCOUT WAITS | 50 | 50 | 50 | 1.39 | +0 | +0.0 |
| WALKS TO THE FIGHT | 97 | 97 | 48 | 1.33 | +578 | +12.0 |
| REDIRECT COUNTER | 160 | 100 | 44 | 1.22 | +4082 | +92.8 |
| ADVANCE LANE KEPT | 43 | 43 | 43 | 1.19 | +0 | +0.0 |
| BEST MOVE FOR SHOOTERS | 43 | 43 | 43 | 1.19 | +5571 | +129.5 |
| RISK BY ARC | 180 | 178 | 42 | 1.17 | +1454 | +34.6 |
| HONEST THREAT | 692 | 692 | 41 | 1.14 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 77 | 77 | 41 | 1.14 | +955 | +23.3 |
| KILLS COUNT | 142 | 141 | 40 | 1.11 | +1840 | +46.0 |
| MAX FOR POSITIONING | 356 | 216 | 39 | 1.08 | +811 | +20.8 |
| RESERVE FALL BACK | 39 | 39 | 39 | 1.08 | +1049 | +26.9 |
| SHOOTERS IN TWO RANKS | 39 | 39 | 39 | 1.08 | +72 | +1.8 |
| THROUGH LINE OF FIRE | 39 | 39 | 39 | 1.08 | +1392 | +35.7 |
| CHARGE NOW FIRST | 164 | 164 | 33 | 0.92 | -2993 | -90.7 |
| GUN VIEW | 73 | 73 | 33 | 0.92 | +709 | +21.5 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2051 | +62.2 |
| MISSILES IN THE MOVE | 239 | 138 | 31 | 0.86 | +576 | +18.6 |
| RANDOM MOVE BY FIGURES | 47 | 47 | 30 | 0.83 | +699 | +23.3 |
| STOPS SHORT OF THE FLANK | 29 | 29 | 29 | 0.81 | +1228 | +42.3 |
| HOLDS AMBUSHERS | 28 | 28 | 28 | 0.78 | +0 | +0.0 |
| MODEL FACING | 28 | 28 | 28 | 0.78 | +8988 | +321.0 |
| STAY WORTH | 1024 | 854 | 28 | 0.78 | +383 | +13.7 |
| BLOCKED WHEEL | 27 | 27 | 27 | 0.75 | +261 | +9.7 |
| MAKE SURE TOGETHER | 88 | 60 | 27 | 0.75 | +2215 | +82.1 |
| MARCH CHECK | 29 | 28 | 26 | 0.72 | +1108 | +42.6 |
| KEEPS ITS TARGET | 135 | 134 | 25 | 0.69 | +408 | +16.3 |
| KEEPS THE TARGET | 71 | 71 | 25 | 0.69 | -11708 | -468.3 |
| CAST JOB | 52 | 52 | 24 | 0.67 | +360 | +15.0 |
| COMBAT PIVOT | 24 | 24 | 24 | 0.67 | +0 | +0.0 |
| HONEST WORTH | 597 | 594 | 24 | 0.67 | +306 | +12.8 |
| FRIENDS SHOTS CHECKED | 23 | 23 | 23 | 0.64 | +1422 | +61.8 |
| MOVE AND CAST | 23 | 23 | 23 | 0.64 | +980 | +42.6 |
| MANOEUVRE | 24 | 24 | 22 | 0.61 | +975 | +44.3 |
| INVITES THE FIGHT | 120 | 120 | 21 | 0.58 | +233 | +11.1 |
| REDIRECT WEIGHED | 21 | 21 | 21 | 0.58 | +522 | +24.9 |
| WHOLE FIGHT GAIN | 39 | 38 | 20 | 0.56 | +567 | +28.3 |
| SHORT GUN FORWARD | 18 | 18 | 18 | 0.50 | +0 | +0.0 |
| BEST PREY | 49 | 49 | 17 | 0.47 | +548 | +32.3 |
| WHO HITS BACK | 17 | 17 | 17 | 0.47 | +1034 | +60.8 |
| SHOT REPLANNED | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| CANNON PLANNED TARGET | 54 | 54 | 13 | 0.36 | +140 | +10.8 |
| WEARS DOWN | 71 | 70 | 13 | 0.36 | +405 | +31.1 |
| BEST PRIZE | 11 | 11 | 11 | 0.31 | -1048 | -95.3 |
| MARCH ODDS | 11 | 11 | 11 | 0.31 | +83 | +7.5 |
| RESTRAINS TO SHOOT | 11 | 11 | 11 | 0.31 | +368 | +33.4 |
| BIG CHARACTER SAFETY | 10 | 10 | 10 | 0.28 | -40 | -4.0 |
| CHARGE BAND | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| SHOOTERS ARE THREATS | 212 | 212 | 10 | 0.28 | +0 | +0.0 |
| WHOLE FIGHT | 21 | 18 | 10 | 0.28 | +658 | +65.8 |
| CASTING BLOCK | 11 | 11 | 9 | 0.25 | +340 | +37.7 |
| PIVOT GUARDS FLANK | 9 | 9 | 9 | 0.25 | -190 | -21.1 |
| SURE CHARGE BEATS ADVANCE | 9 | 9 | 9 | 0.25 | -283 | -31.5 |
| LOST CHARGE | 208 | 207 | 8 | 0.22 | +241 | +30.1 |
| PURSUES BIG PREY | 8 | 8 | 8 | 0.22 | -393 | -49.1 |
| STOPS | 19 | 19 | 8 | 0.22 | +236 | +29.6 |
| HUNT IN PAIRS | 34 | 21 | 7 | 0.19 | +221 | +31.5 |
| REFUSING RETIRES | 20 | 20 | 7 | 0.19 | -1 | -0.2 |
| STUCK PIVOT | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| SURE REACH TOGETHER | 58 | 44 | 7 | 0.19 | +213 | +30.5 |
| CASTS FROM BEHIND | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| CHAFF PASSED | 6 | 6 | 6 | 0.17 | -9 | -1.5 |
| GUN THREAT | 136 | 136 | 6 | 0.17 | +0 | +0.0 |
| MOVES UNITS SPELL | 6 | 6 | 6 | 0.17 | +41 | +6.8 |
| OPENS UP | 10 | 10 | 6 | 0.17 | +149 | +24.8 |
| WAR ENGINE JOBS | 23 | 23 | 6 | 0.17 | -320 | -53.3 |
| HUNT ADVANCE | 14 | 14 | 5 | 0.14 | +89 | +17.9 |
| KEEP FALLS | 5 | 5 | 5 | 0.14 | +352 | +70.5 |
| KEEPS SCOUTS OR AMBUSH | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| FACE THE CAST | 4 | 4 | 4 | 0.11 | +138 | +34.5 |
| SHOOTERS TO THE PRIMARY | 138 | 94 | 4 | 0.11 | +31 | +7.6 |
| SUPPORT NARROWED | 402 | 402 | 4 | 0.11 | -76 | -19.1 |
| MISSILES NEXT TURN | 282 | 145 | 3 | 0.08 | +6 | +2.1 |
| NO RALLY LEFT | 3 | 3 | 3 | 0.08 | +73 | +24.3 |
| BACKUP TARGETS | 73 | 44 | 2 | 0.06 | +0 | +0.1 |
| CARRIES OUT SET-UP | 11 | 11 | 2 | 0.06 | -54 | -26.9 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -45 | -22.6 |
| CHARGER SLAIN LOST | 41 | 39 | 2 | 0.06 | +72 | +36.0 |
| DEFENSIVE ARMY | 20 | 20 | 2 | 0.06 | -25 | -12.6 |
| EDGE GIVE GROUND | 20 | 20 | 2 | 0.06 | +12 | +5.8 |
| JOINT CHARGE PLAN | 12 | 12 | 2 | 0.06 | +149 | +74.3 |
| LONE WIZARD HOLDS BACK | 3 | 3 | 2 | 0.06 | -71 | -35.6 |
| LONG SHOT | 32 | 32 | 2 | 0.06 | +20 | +9.9 |
| OVERRUNS AWAY | 30 | 30 | 2 | 0.06 | +49 | +24.3 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +165 | +82.5 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | -6 | -3.0 |
| WAR ENGINE CHARGES | 2 | 2 | 2 | 0.06 | +129 | +64.3 |
| WIDER SPREAD | 213 | 207 | 2 | 0.06 | +8 | +4.1 |
| BLOCKED CHARGE SKIPPED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +32 | +32.5 |
| CARRIES OUT COUNTER | 2 | 2 | 1 | 0.03 | -120 | -120.3 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +28 | +28.1 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +70 | +69.7 |
| GUN MASK | 23 | 13 | 1 | 0.03 | +49 | +48.9 |
| KEEPS ITS PREY | 4 | 4 | 1 | 0.03 | +2 | +2.4 |
| NEEDED THERE | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| OPENS A LANE | 12 | 11 | 1 | 0.03 | +3 | +2.7 |
| RAIDS THE BAGGAGE NEXT TURN | 1 | 1 | 1 | 0.03 | +2 | +2.0 |
| STAY WEIGHED | 1 | 1 | 1 | 0.03 | +158 | +158.4 |
| TWO OR MORE ARRIVE | 50 | 36 | 1 | 0.03 | +0 | +0.1 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.03 | -19 | -18.6 |
| ARRIVAL HUNT | 7 | 7 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 14 | 14 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 7 | 7 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 31 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 9 | 9 | 0 | 0.00 | - | - |
| CHEAP HELPER | 13 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 22 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 6 | 6 | 0 | 0.00 | - | - |
| FIGHT LIFT | 6 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 420 | not checked | - | - | - | - |
| GIVES UP | 6 | 6 | 0 | 0.00 | - | - |
| GUN FIGURES | 162 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 7 | not checked | - | - | - | - |
| HELPER UNSEEN | 19 | 18 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 20 | 20 | 0 | 0.00 | - | - |
| HUNT DROPPED | 6 | trace | - | - | - | - |
| HUNT KEPT | 10 | trace | - | - | - | - |
| HUNT RESULT | 23 | trace | - | - | - | - |
| HUNT THE GUNS | 24 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 9 | 8 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 19 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 31 | 31 | 0 | 0.00 | - | - |
| MISSILES IN THE FIRE PLAN | 33 | 7 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 11 | 11 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 7 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 14 | trace | - | - | - | - |
| MOVE SPELL SPOT | 10 | not checked | - | - | - | - |
| NOT NEEDED | 16 | 15 | 0 | 0.00 | - | - |
| NOT TURNED | 432 | 432 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 19 | not checked | - | - | - | - |
| PLAN RESULT | 2985 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 6 | 6 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 12 | 12 | 0 | 0.00 | - | - |
| SCOUT SPOT | 44 | 44 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 20 | 20 | 0 | 0.00 | - | - |
| SECOND HUNTER | 4 | 4 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 26 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 16 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOT OPTIONS | 1448 | 1448 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 17 | not checked | - | - | - | - |
| SPELL WORTH | 99 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 42 | 38 | 0 | 0.00 | - | - |
| STABLE ROLE | 808 | 808 | 0 | 0.00 | - | - |
| TURN WORTH | 9 | 9 | 0 | 0.00 | - | - |

### Off best figure: gf-h2h-mine-0533c46-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.72 | 14.11 | 50.7 |
| TURN GATE | gate | 0.56 | 0.72 | 36.1 |
| FALLBACK | gate | 0.69 | 0.50 | 46.0 |
| CHARGE NOW FIRST | rule | 0.44 | 0.47 | 90.7 |
| FIRE PLAN | rule | 0.69 | - | 129.4 |
| KEEPS THE TARGET | rule | 0.61 | - | 535.3 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.28 | 0.06 | 47.1 |
| BEST PRIZE | rule | 0.08 | 0.22 | 95.3 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.25 | 33.6 |
| LONE CHARACTER SAFE SPOT | gate | 0.11 | 0.17 | 77.0 |
| PATHS CROSS | rule | 0.08 | 0.19 | 30.8 |
| PIVOT GUARDS FLANK | rule | 0.08 | 0.17 | 21.1 |
| SURE CHARGE BEATS ADVANCE | rule | 0.17 | 0.08 | 31.5 |
| PURSUES BIG PREY | rule | 0.06 | 0.17 | 49.1 |
| AFTERMATH BAND | gate | 0.06 | 0.11 | 2.7 |
| BIG CHARACTER SAFETY | rule | 0.06 | 0.08 | 11.1 |
| SUPPORT REQUEST | gate | 0.06 | 0.08 | 97.5 |
| THROUGH LINE OF FIRE | rule | 0.08 | 0.06 | 29.3 |
| WAR ENGINE JOBS | rule | 0.08 | 0.06 | 63.8 |
| FIGHT ORDER BAND | gate | 0.03 | 0.08 | 2.3 |
| REDIRECT WEIGHED | rule | 0.03 | 0.08 | 93.8 |
| RULE SWITCHED OFF | gate | - | 0.11 | 41.5 |
| SUPPORT NARROWED | rule | 0.08 | 0.03 | 19.1 |
| BLOCKED WHEEL | rule | 0.03 | 0.06 | 59.5 |
| CANNON PLANNED TARGET | rule | - | 0.08 | 60.3 |
| CHAFF PASSED | rule | - | 0.08 | 2.8 |
| FACES THE THREAT | rule | 0.03 | 0.06 | 12.2 |
| CARRIES OUT SET-UP | rule | - | 0.06 | 26.9 |
| CATCH ODDS | rule | 0.03 | 0.03 | 22.6 |
| DEFENSIVE ARMY | rule | 0.06 | - | 12.6 |
| FRIENDS SHOTS CHECKED | rule | - | 0.06 | 2.8 |
| LONE WIZARD HOLDS BACK | rule | - | 0.06 | 35.6 |
| MARCH ODDS | rule | - | 0.06 | 23.5 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | 0.03 | 9.4 |
| CARRIES OUT COUNTER | rule | - | 0.03 | 120.3 |
| FALLBACK BY WORTH | rule | 0.03 | - | 15.4 |
| FOLLOW UP WEIGHED | rule | 0.03 | - | 1.4 |
| NO REASON | gate | 0.03 | - | 26.2 |
| STANDS TO CAST | rule | - | 0.03 | 7.9 |
| WOUNDED STAYS OUT | rule | - | 0.03 | 18.6 |

### Plans: gf-h2h-mine-0533c46-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 10.2 | 14% | 473 | 247 | 52% |
| Mine | charge | 2.4 | 57% | 194 | 249 | 128% |
| Mine | close in | 3.4 | 26% | 165 | 106 | 65% |
| Mine | hold | 4.9 | 30% | 279 | 0 | 0% |
| Mine | join | 0.7 | 100% | 29 | 0 | 0% |
| Mine | shoot | 17.0 | 65% | 622 | 1344 | 216% |
| Mine | support | 3.0 | 93% | 27 | 0 | 0% |
| Opponent | advance | 13.6 | 13% | 343 | 293 | 85% |
| Opponent | charge | 4.7 | 57% | 385 | 401 | 104% |
| Opponent | close in | 7.0 | 25% | 444 | 138 | 31% |
| Opponent | hold | 4.7 | 44% | 321 | 0 | 0% |
| Opponent | join | 0.5 | 100% | 32 | 0 | 0% |
| Opponent | shoot | 5.7 | 53% | 147 | 332 | 225% |
| Opponent | support | 5.1 | 88% | 25 | 0 | 0% |

### Packages: hunt the guns, gf-h2h-mine-0533c46-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 3 | 1 | 50% | 50% | 0% | 2.0 | 497 | 216 | 50% | 33 |
| Opponent | 0.6 | 21 | 0 | 38% | 48% | 5% | 2.5 | 391 | 162 | 48% | 178 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 509 | 432 | 100% | 126 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 6 |
| Empire of Man | 0.1 | 2 | 1 | 0% | 0% | 0% | - | 486 | 0 | 0% | 58 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 54 |
| High Elf Realms | 0.9 | 6 | 0 | 33% | 67% | 0% | 2.0 | 478 | 288 | 67% | 135 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 471 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.9 | 6 | 0 | 50% | 50% | 17% | 2.7 | 390 | 185 | 50% | 279 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 92 |
| Tomb Kings of Khemri | 0.7 | 4 | 0 | 0% | 0% | 0% | - | 381 | 0 | 0% | 188 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 120 |
| Warriors of Chaos | 0.7 | 2 | 0 | 50% | 50% | 0% | 3.0 | 274 | 107 | 50% | 128 |
| Wood Elf Realms | 0.8 | 3 | 0 | 67% | 67% | 0% | 3.0 | 312 | 117 | 67% | 23 |

### Battle groups: gf-h2h-mine-0533c46-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 13.8 | 23% | 56% | 10% | 18% | 45% | 9% | 4% | 42% | 0% |
| Mine | REDIRECT COUNTER | 1.1 | 44% | 72% | 11% | 100% | 12% | 0% | 12% | 69% | 6% |
| Opponent | COUNTER-CHARGE COVER | 8.1 | 12% | 58% | 36% | 23% | 22% | 17% | 22% | 39% | 0% |
| Opponent | REDIRECT COUNTER | 3.3 | 18% | 86% | 9% | 0% | 20% | 0% | 15% | 55% | 10% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gf-h2h-mine-0533c46-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 2 | 76 (2) | 76 | 0 | 0 | 50% | 6.0 | 0 (1) | 152 (1) | - | 76 (2) | - |
| Mine | Chaff | 22 | 44 (22) | 17 | 27 | 59 | 18% | 2.3 | 54 (8) | 20 (7) | 66 (7) | 57 (16) | 9 (6) |
| Mine | Character | 132 | 35 (132) | 35 | 0 | 42 | 22% | 2.6 | 45 (30) | 37 (81) | 0 (10) | 42 (66) | 30 (55) |
| Mine | Clean-up | 17 | 89 (17) | 61 | 28 | 37 | 24% | 2.2 | 71 (2) | 94 (14) | 0 (1) | 60 (14) | 316 (3) |
| Mine | Fast | 2 | 67 (2) | 67 | 0 | 50 | 50% | 1.0 | - | 0 (1) | 133 (1) | 67 (2) | - |
| Mine | Fast Hammer | 30 | 38 (30) | 14 | 25 | 29 | 13% | 2.9 | 14 (10) | 50 (16) | 54 (4) | 44 (19) | 28 (11) |
| Mine | Fragile | 3 | 0 (3) | 0 | 0 | 100 | 33% | 1.0 | - | 0 (1) | 0 (2) | 0 (3) | - |
| Mine | Hammer | 73 | 24 (73) | 14 | 10 | 41 | 16% | 2.2 | 9 (12) | 27 (53) | 26 (8) | 24 (46) | 23 (27) |
| Mine | Holder | 11 | 75 (11) | 16 | 59 | 28 | 45% | 3.3 | 0 (2) | 76 (8) | 264 (1) | 119 (7) | 6 (4) |
| Mine | Shooter | 67 | 84 (67) | 29 | 55 | 28 | 4% | 1.6 | 34 (13) | 110 (39) | 46 (15) | 125 (37) | 39 (30) |
| Mine | Support | 3 | 0 (3) | 0 | 0 | 100 | 0% | 3.0 | - | - | - | - | - |
| Mine | War machine | 109 | 50 (109) | 50 | 0 | 38 | 3% | 1.3 | 46 (32) | 52 (61) | 54 (16) | 34 (22) | 54 (87) |
| Mine | Wizard | 14 | 30 (14) | 30 | 0 | 79 | 29% | 2.4 | 156 (2) | 24 (7) | - | 0 (1) | 62 (8) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | - | - | - | - |
| Opponent | Chaff | 85 | 83 (85) | 35 | 48 | 46 | 32% | 2.8 | 90 (42) | 45 (10) | 88 (33) | 80 (67) | 91 (18) |
| Opponent | Character | 92 | 53 (92) | 53 | 0 | 30 | 21% | 2.1 | 58 (31) | 48 (55) | 74 (5) | 45 (59) | 66 (32) |
| Opponent | Clean-up | 20 | 64 (20) | 43 | 20 | 33 | 50% | 3.4 | 61 (5) | 39 (13) | 326 (2) | 62 (12) | 65 (8) |
| Opponent | Early | 3 | 0 (3) | 0 | 0 | 33 | 33% | 5.5 | - | 0 (3) | - | - | 0 (3) |
| Opponent | Fast | 4 | 0 (4) | 0 | 0 | 84 | 50% | 4.0 | - | 0 (4) | - | 0 (3) | 0 (1) |
| Opponent | Fast Hammer | 42 | 41 (42) | 24 | 17 | 40 | 33% | 2.8 | 33 (19) | 80 (11) | 22 (12) | 50 (26) | 30 (16) |
| Opponent | Fragile | 7 | 37 (7) | 37 | 0 | 34 | 29% | 3.0 | - | 17 (6) | 192 (1) | 38 (5) | 35 (2) |
| Opponent | Hammer | 62 | 24 (62) | 11 | 13 | 43 | 34% | 2.7 | 0 (12) | 28 (42) | 23 (8) | 26 (39) | 18 (23) |
| Opponent | Holder | 36 | 92 (36) | 6 | 86 | 20 | 31% | 2.1 | 84 (5) | 109 (25) | 24 (5) | 144 (23) | 25 (12) |
| Opponent | Shooter | 31 | 54 (31) | 13 | 41 | 26 | 6% | 1.8 | 0 (5) | 73 (22) | 10 (4) | 63 (19) | 43 (12) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | War machine | 15 | 67 (15) | 67 | 0 | 30 | 0% | 1.0 | 12 (4) | 65 (7) | 141 (4) | 69 (5) | 66 (10) |
| Opponent | Wizard | 24 | 4 (24) | 4 | 0 | 11 | 25% | 1.8 | 8 (11) | 0 (6) | 0 (5) | 9 (11) | 0 (11) |

### Charged fights: gf-h2h-mine-0533c46-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 4 | 170 | 226 | 1.2 | 1.4 | 180 | 0 | +180 | 3 of 5 | 4 of 5 | +206 | +163 |
| Mine | Dwarfen Mountain Holds | 10 | 474 | 132 | 1.4 | 1.2 | 94 | 15 | +79 | 2 of 14 | 9 of 14 | +149 | +60 |
| Mine | Empire of Man | 12 | 427 | 230 | 1.7 | 1.1 | 138 | 32 | +106 | 10 of 20 | 17 of 20 | +207 | +94 |
| Mine | Grand Cathay | 3 | 360 | 120 | 2.3 | 1.1 | 52 | 0 | +52 | 2 of 7 | 7 of 7 | +195 | +28 |
| Mine | High Elf Realms | 2 | 0 | 548 | 2.5 | 1.2 | 219 | 0 | +219 | 1 of 5 | 5 of 5 | +158 | +234 |
| Mine | Lizardmen | 1 | 0 | 127 | 3.0 | 1.0 | 42 | 0 | +42 | 0 of 3 | 3 of 3 | - | +42 |
| Mine | Ogre Kingdoms | 2 | 0 | 396 | 5.5 | 1.2 | 72 | 3 | +69 | 3 of 11 | 8 of 11 | +175 | +45 |
| Mine | Skaven | 1 | 195 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 1 | 0 | 0 | 2.0 | 1.5 | 0 | 0 | +0 | 1 of 2 | 1 of 2 | +0 | +0 |
| **Mine** | all armies | 36 | 328 | 204 | 1.9 | 1.2 | 110 | 13 | +97 | 22 of 67 | 54 of 67 | +165 | +82 |
| Opponent | Empire of Man | 3 | 178 | 22 | 0.7 | 1.0 | 32 | 0 | +32 | 0 of 2 | 2 of 2 | - | +32 |
| Opponent | Grand Cathay | 1 | 195 | 0 | 1.0 | 1.0 | 0 | 205 | -205 | 0 of 1 | 0 of 1 | - | -205 |
| Opponent | High Elf Realms | 5 | 89 | 844 | 5.2 | 1.2 | 162 | 0 | +162 | 14 of 26 | 21 of 26 | +277 | +135 |
| Opponent | Kingdom of Bretonnia | 1 | 250 | 444 | 4.0 | 1.0 | 111 | 0 | +111 | 1 of 4 | 4 of 4 | - | +111 |
| Opponent | Ogre Kingdoms | 5 | 100 | 256 | 4.2 | 1.1 | 61 | 15 | +46 | 12 of 21 | 10 of 21 | -114 | +63 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 74 | 3.0 | 1.0 | 25 | 0 | +25 | 0 of 3 | 2 of 2 | - | +25 |
| Opponent | Skaven | 2 | 0 | 376 | 4.0 | 1.1 | 94 | 4 | +90 | 1 of 8 | 8 of 8 | +125 | +84 |
| Opponent | Tomb Kings of Khemri | 5 | 157 | 978 | 4.4 | 1.0 | 222 | 3 | +219 | 16 of 22 | 15 of 22 | - | +219 |
| Opponent | Vampire Counts | 6 | 59 | 450 | 2.8 | 1.1 | 159 | 15 | +144 | 4 of 17 | 13 of 17 | +61 | +155 |
| Opponent | Warriors of Chaos | 3 | 0 | 271 | 3.3 | 1.0 | 81 | 32 | +50 | 3 of 10 | 7 of 10 | - | +50 |
| Opponent | Wood Elf Realms | 4 | 324 | 517 | 4.8 | 1.2 | 109 | 7 | +102 | 5 of 19 | 13 of 19 | +56 | +107 |
| **Opponent** | all armies | 36 | 121 | 481 | 3.7 | 1.1 | 130 | 10 | +120 | 56 of 133 | 95 of 132 | +126 | +119 |

### Effective charges: gf-h2h-mine-0533c46-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 5 | 0 | 0 | 3 (net +223) | 1 (net +125) | 0 | 1 (net +109) | 0 | 60% (3 of 5) |
| Mine | Dwarfen Mountain Holds | 14 | 3 (net +179) | 0 | 2 (net -58) | 5 (net +79) | 0 | 4 (net +73) | 0 | 14% (2 of 14) |
| Mine | Empire of Man | 20 | 4 (net +0) | 0 | 3 (net +88) | 7 (net +211) | 0 | 5 (net +62) | 1 | 16% (3 of 19) |
| Mine | Grand Cathay | 7 | 1 (net +0) | 0 | 1 (net +0) | 3 (net +107) | 1 (net +40) | 1 (net +0) | 0 | 14% (1 of 7) |
| Mine | High Elf Realms | 5 | 0 | 0 | 1 (net +464) | 0 | 3 (net +125) | 1 (net +258) | 0 | 20% (1 of 5) |
| Mine | Lizardmen | 3 | 0 | 0 | 0 | 0 | 2 (net +28) | 0 | 1 | 0% (0 of 2) |
| Mine | Ogre Kingdoms | 11 | 0 | 1 (net -34) | 1 (net +0) | 6 (net +127) | 0 | 2 (net +0) | 1 | 10% (1 of 10) |
| Mine | Tomb Kings of Khemri | 2 | 0 | 0 | 0 | 1 (net +0) | 0 | 1 (net +0) | 0 | 0% (0 of 2) |
| Opponent | Empire of Man | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +32) | 0 | 0% (0 of 2) |
| Opponent | Grand Cathay | 1 | 0 | 0 | 0 | 1 (net -205) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | High Elf Realms | 26 | 2 (net +120) | 0 | 9 (net +236) | 5 (net +114) | 4 (net +99) | 3 (net +173) | 3 | 39% (9 of 23) |
| Opponent | Kingdom of Bretonnia | 4 | 1 (net +217) | 0 | 1 (net +227) | 0 | 1 (net +0) | 0 | 1 | 33% (1 of 3) |
| Opponent | Ogre Kingdoms | 21 | 8 (net +56) | 1 (net +0) | 1 (net +369) | 0 | 0 | 4 (net +26) | 7 | 7% (1 of 14) |
| Opponent | Skaven | 8 | 1 (net +0) | 2 (net +123) | 0 | 1 (net +0) | 0 | 4 (net +118) | 0 | 0% (0 of 8) |
| Opponent | Tomb Kings of Khemri | 22 | 3 (net +322) | 1 (net -72) | 3 (net +363) | 2 (net +0) | 0 | 13 (net +218) | 0 | 14% (3 of 22) |
| Opponent | Vampire Counts | 17 | 4 (net +44) | 1 (net +310) | 4 (net +102) | 4 (net +308) | 2 (net +36) | 2 (net +128) | 0 | 24% (4 of 17) |
| Opponent | Warriors of Chaos | 10 | 0 | 0 | 4 (net +49) | 0 | 0 | 2 (net +20) | 4 | 67% (4 of 6) |
| Opponent | Wood Elf Realms | 19 | 2 (net +110) | 0 | 2 (net +51) | 4 (net +267) | 0 | 5 (net +45) | 6 | 15% (2 of 13) |

### Charged fights, damage counted: gf-h2h-mine-0533c46-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 8 | 165 | 333 | +67 | 79 | 25 | +54 | +32.7 |
| Mine | 50-54% | 1 | 34 | 55 | -34 | 0 | 34 | -34 | -100.0 |
| Mine | Effective (55-75%) | 11 | 282 | 213 | +116 | 166 | 43 | +122 | +43.3 |
| Mine | 76-89% | 23 | 247 | 189 | +134 | 147 | 18 | +129 | +52.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 15 | 206 | 165 | +64 | 118 | 40 | +78 | +38.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 455 | 87 | +78 | 83 | 4 | +80 | +17.5 |
| Mine | No odds | 3 | 205 | 56 | +56 | 56 | 0 | +56 | +27.2 |
| Mine | All fights | 67 | 247 | 188 | +97 | 123 | 26 | +98 | +39.4 |
| Opponent | Long shot (under 50%) | 21 | 192 | 191 | +108 | 133 | 24 | +109 | +56.5 |
| Opponent | 50-54% | 5 | 174 | 133 | +97 | 142 | 25 | +116 | +66.9 |
| Opponent | Effective (55-75%) | 24 | 290 | 215 | +188 | 237 | 49 | +188 | +64.7 |
| Opponent | 76-89% | 17 | 341 | 177 | +157 | 199 | 46 | +153 | +44.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 35 | 290 | 184 | +129 | 150 | 20 | +130 | +44.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 502 | 111 | +67 | 84 | 24 | +60 | +12.0 |
| Opponent | No odds | 24 | 210 | 174 | +44 | 81 | 13 | +68 | +32.3 |
| Opponent | All fights | 133 | 273 | 182 | +120 | 153 | 28 | +125 | +45.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gf-h2h-mine-0533c46-p2 | move | 468 | 89 (19%) | 58 (12%) | 49 (10%) | 330 (71%) |
| gf-h2h-mine-0533c46-p2 | objective | 382 | 53 (14%) | 40 (10%) | 48 (13%) | 281 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0334, L0524, L0527, L0626, L0724, L0925, L0934, L2226 |
| Clockwork Compass | Mine | L1215, L1222 |
| Clockwork Compass | Opponent | L0312 |
| Elixir of Power | Mine | L1118 |
| Elixir of Power | Opponent | L1819 |
| Fistful of Laurels | Mine | L1819, L1832 |
| Fistful of Laurels | Opponent | L0518, L0618, L0718, L0818, L1118 |
| Horn of the Wild Hunt | Opponent | L1533 |
| Invocation of Nehek | Opponent | L0524, L0527, L0724, L0925 |
| Opal Amulet | Opponent | L0314 |
| Periapt of Soul Exchange | Mine | L2122 |
| Periapt of Soul Exchange | Opponent | L0520, L0720 |
| Ring of Doom | Mine | L1118, L1215, L1222, L1533, L1535 |
| Ring of Doom | Opponent | L0312, L0531, L0715, L0915, L1215, L1533 |
| Ring of Jet | Mine | L1118, L1215, L1222 |
| Ring of Jet | Opponent | L0312 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2122 |
| Twice-Blessed Armour | Mine | L0715, L0718, L0720, L0724 |
| Twice-Blessed Armour | Opponent | L0407 |
| Witch Hunter's Ward | Mine | L0715, L0718, L0720, L0724, L0809, L0818, L0823 |
| Witch Hunter's Ward | Opponent | L0407 |

import json,glob,os,re,collections,csv,statistics as st,math
S=collections.defaultdict(collections.Counter); ngames=collections.Counter()
lost=collections.defaultdict(collections.Counter)
for part in ('/root/an/all/mine-all','/root/an/all/opp-all'):
  plan='Mine' if 'mine' in part else 'Opponent'
  who=lambda s:'plan' if s==plan else 'main'
  for l in open(part+'/units.jsonl'):
    d=json.loads(l)
    if d['troopType'].startswith('War Machine'):
      k=who(d['side']); lost[k]['wm']+=1; lost[k]['wmpts']+=d['points']
      if d['gone']: lost[k]['gone']+=1; lost[k]['cause:'+str(d['goneCause'])]+=1; lost[k]['by:'+str(d['goneByKind'])]+=1; lost[k]['gonepts']+=d['points']
  for lf in glob.glob(part+'/game-*.log.jsonl'):
    for s in ('plan','main'): ngames[s]+=1
    pts={}
    for l in open(lf):
      r=json.loads(l)
      if r.get('kind')=='board':
        for u in r['units']: pts[u['id']]=u['lk'].get('p') or u['lk'].get('pts')
      if r.get('kind')!='action' or r.get('type')!='WarMachineShot': continue
      s=r.get('summary') or ''
      if 'cannot shoot' in s: continue
      k=who(r['side']); S[k]['shots']+=1
      m=re.search(r'(\d+) (?:killed|wound)',s); S[k]['kills']+=int(m[1]) if m else 0
      if 'destroyed' in s: S[k]['destroyed']+=1
for k in ('plan','main'):
  g=ngames[k]/2
  print(k,'WM shots/game %.1f'%(S[k]['shots']/ (ngames[k]/2*1) ), 'casualties/shot %.2f'%(S[k]['kills']/S[k]['shots']), 'units destroyed by WM shot/game %.2f'%(S[k]['destroyed']/ (ngames[k]/2)))
  print('  own WM',dict(lost[k]))
print(ngames)

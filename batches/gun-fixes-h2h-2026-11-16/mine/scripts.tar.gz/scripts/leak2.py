import json,glob,os,collections
c=collections.Counter(); n=collections.Counter(); ch=collections.Counter()
for part in ('/root/an/all/mine-all','/root/an/all/opp-all'):
  plan='Mine' if 'mine' in part else 'Opponent'
  for f in glob.glob(part+'/game-*.log.jsonl'):
    n[plan]+=1
    for l in open(f):
      if '"OpponentRule"' not in l: continue
      d=json.loads(l); s=d['summary'].split(':')[0].strip()
      who='plan' if d['side']==plan else 'main'
      c[(who,s)]+=1
      if 'CHANGED' in d['summary']: ch[(who,s)]+=1
for k,v in sorted(c.items()): print(k,v,'changed',ch[k])
print(n)

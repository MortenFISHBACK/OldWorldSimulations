import csv,glob,statistics as st,math,collections
def load(D,globs):
  by=collections.defaultdict(dict)
  for arm,pat in globs:
    for f in glob.glob(D+'/'+pat+'/games.csv'):
      for r in csv.DictReader(open(f)):
        if r['ended']!='yes': continue
        m,o=map(int,r['vp_mine_opponent'].split('-'))
        by[r['pair']][arm]=(m-o) if arm=='mine' else (o-m)
  return {p:(v['mine']+v['opp'])/2 for p,v in by.items() if len(v)==2}
S='/mnt/project-files/shooting-fixes-h2h-2026-11-16'
am=load(S,[('mine','mine-[1-4]'),('opp','opp-[1-4]'),('opp','opp-1b')])
pm=load('/root/an/all',[('mine','mine-all'),('opp','opp-all')])
band=lambda xs:1.96*st.stdev(xs)/math.sqrt(len(xs))
print('morning',len(am),'%+.0f ±%.0f'%(st.mean(am.values()),band(list(am.values()))))
print('today',len(pm),'%+.0f ±%.0f'%(st.mean(pm.values()),band(list(pm.values()))))
common=[p for p in pm if p in am]; d=[pm[p]-am[p] for p in common]
print('paired diff today-morning',len(common),'%+.0f ±%.0f'%(st.mean(d),band(d)),'better/worse',sum(x>0 for x in d),sum(x<0 for x in d))
r=st.correlation([pm[p] for p in common],[am[p] for p in common]); print('corr',round(r,2))

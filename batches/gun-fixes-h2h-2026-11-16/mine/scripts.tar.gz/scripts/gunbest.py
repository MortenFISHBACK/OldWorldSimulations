import json,glob,re,csv,collections,sys
T=collections.defaultdict(dict)  # (gun_list,gun) -> {(target_list,target):evp}
for r in csv.DictReader(open('/root/an/gun-table.tsv'),delimiter='\t'):
    T[(r['gun_list'],r['gun'])][(r['target_list'],r['target'])]=min(1.0,float(r['wounds'])/max(1,int(r['target_wounds'])))*int(r['target_points'])
RX=re.compile(r'(\d+)\) (.+?) (\d+) pts ([\d.]+)": in range (yes|no), in a fight (yes|no), in sight (yes|no)(?: \(blocked by (.*?)\))?(?=; \d+\)|$)')
S=collections.defaultdict(collections.Counter); miss=collections.Counter(); lost=collections.defaultdict(list)
for part in ('/root/an/all/mine-all','/root/an/all/opp-all'):
  plan='Mine' if 'mine' in part else 'Opponent'
  for lf in glob.glob(part+'/game-*.log.jsonl'):
    pair=re.search(r'game-L(\d\d)(\d\d)-',lf); lst={'Mine':pair[1],'Opponent':pair[2]}
    sight={}
    for l in open(lf):
      if '"GunSight"' not in l and '"WarMachineShot"' not in l: continue
      r=json.loads(l)
      if r.get('kind')!='action': continue
      if r['type']=='GunSight':
        s=r['summary']; m=re.match(r'GUN SIGHT: (.+?) \(\d+"\): (.*)$',s)
        if m: sight[(r['side'],r['turn'],m[1])]=[dict(n=x[1],pts=int(x[2]),rng=x[4]=='yes',fight=x[5]=='yes',see=x[6]=='yes',blk=x[7] or '') for x in RX.findall(m[2])]
        continue
      s=r.get('summary') or ''
      if 'cannot shoot' in s: continue
      side=r['side']; who='plan' if side==plan else 'main'; enemy='Opponent' if side=='Mine' else 'Mine'
      c=S[who]; c['shots']+=1
      row=sight.get((side,r['turn'],r['actor']))
      tab=T.get((lst[side],r['actor']))
      if tab is None: miss['no table '+r['actor']]+=1; continue
      if row is None: c['no sight row']+=1; continue
      c['with row']+=1
      cands=[x for x in row if (lst[enemy],x['n']) in tab]
      if not cands: c['no candidate']+=1; continue
      for x in cands: x['evp']=tab[(lst[enemy],x['n'])]
      best=max(cands,key=lambda x:x['evp'])
      open_=[x for x in cands if x['rng'] and not x['fight'] and x['see']]
      if best in open_:
        c['best open']+=1
        if r['target']==best['n']: c['best open shot']+=1
      else:
        why='out of range' if not best['rng'] else 'in a fight' if best['fight'] else ('own unit' if best['blk'].startswith('own') else 'enemy unit' if best['blk'].startswith('enemy') else 'terrain/other')
        c['best not open: '+why]+=1
      if open_:
        bo=max(open_,key=lambda x:x['evp']); c['some open']+=1
        shot=[x for x in cands if x['n']==r['target']]
        if r['target']==bo['n']: c['shot best open']+=1
        if shot: lost[who].append(bo['evp']-shot[0]['evp']); c['shot evp']+=0
        c['best open evp x100']+=int(100*bo['evp'])
        if shot: c['shot evp x100']+=int(100*shot[0]['evp'])
for k in ('plan','main'):
  c=S[k]; print(k,dict(c))
  L=lost[k]; print('  evp given up v best open target: mean %.1f, zero %d%% of %d'%(sum(L)/len(L),100*sum(1 for x in L if x<=0.01)/len(L),len(L)))
print(miss.most_common(10))

import json,glob,os,collections,csv,statistics as st
R='/root/an/all'
C=collections.defaultdict(collections.Counter); games=collections.Counter()
for arm in ('mine','opp'):
    plan='Mine' if arm=='mine' else 'Opponent'
    for lf in glob.glob(f'{R}/{arm}-all/game-*.log.jsonl'):
        for k in ('plan','main'): games[k]+=1
        for l in open(lf):
            if '"ShotNotTaken"' in l or '"ArmyStance"' in l or '"MissileNotTried"' in l:
                d=json.loads(l); k='plan' if d['side']==plan else 'main'
                s=d.get('summary') or ''
                if d['type']=='ShotNotTaken' and 'MARCHED' in s: C[k]['volleys lost to marching']+=1
                if d['type']=='MissileNotTried' and 'march' in s.lower(): C[k]['missiles lost to marching']+=1
                if d['type']=='ArmyStance': C[k]['stance turns']+=1; C[k]['defensive turns']+='defensive' in s.lower()[:60]
    for l in open(f'{R}/{arm}-all/units.jsonl'):
        u=json.loads(l); k='plan' if u['side']==plan else 'main'
        if u['isCharacter'] and not u.get('joinedTo'):
            C[k]['lone chars']+=1; C[k]['lone chars fought']+=bool(u['fought'])
        if u['isCharacter'] and u.get('joinedTo'):
            C[k]['joined chars']+=1; C[k]['joined chars fought']+=bool(u['fought'])
for k in ('plan','main'):
    c=C[k]; g=games[k]
    print(k, 'volleys lost to marching/game %.2f'%(c['volleys lost to marching']/g), 'missiles lost to marching/game %.2f'%(c['missiles lost to marching']/g),
      'defensive turns %.0f%%'%(100*c['defensive turns']/max(1,c['stance turns'])),
      'lone chars fought %.0f%% of %d'%(100*c['lone chars fought']/c['lone chars'],c['lone chars']),
      'joined chars fought %.0f%%'%(100*c['joined chars fought']/c['joined chars']))

# Doctrine scorecard: gf-h2h-mine-0533c46-p1

### Scorecard: gf-h2h-mine-0533c46-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0103 | 1 | 1 | Mine | no | 3 | 6 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0103 | 1 | 1 | Opponent | no | 0 | 4 | 2 | 0 | 0 | 0 | 0 | 760 |
| L0108 | 6 | 1 | Mine | no | 4 | - | 0 | 1 | 1 | 0 | 0 | 120 |
| L0108 | 6 | 1 | Opponent | no | 0 | 3 | 4 | 2 | 0 | 0 | 0 | 605 |
| L0109 | 1 | 1 | Mine | no | 4 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0109 | 1 | 1 | Opponent | no | 0 | 4 | 4 | 1 | 0 | 0 | 0 | 420 |
| L0315 | 3 | 1 | Mine | no | 1 | - | 1 | 1 | 0 | 0 | 0 | 590 |
| L0315 | 3 | 1 | Opponent | yes | 3 | 2 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0316 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 675 |
| L0316 | 4 | 1 | Opponent | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 200 |
| L0322 | 4 | 1 | Mine | no | 2 | - | 3 | 0 | 0 | 0 | 0 | 590 |
| L0322 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 55 |
| L0323 | 5 | 1 | Mine | yes | - | 5 | 2 | 2 | 0 | 0 | 0 | 675 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 3 | 2 | 2 | 0 | 0 | 0 |
| L0506 | 2 | 1 | Mine | - | - | - | 1 | 1 | 0 | 0 | 0 | 548 |
| L0506 | 2 | 1 | Opponent | - | - | - | 0 | 3 | 0 | 0 | 0 | 929 |
| L0507 | 3 | 1 | Mine | no | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 730 |
| L0507 | 3 | 1 | Opponent | yes | 7 | 2 | 2 | 0 | 1 | 0 | 0 | 420 |
| L0508 | 4 | 1 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 1193 |
| L0508 | 4 | 1 | Opponent | no | 0 | 3 | 1 | 2 | 0 | 0 | 0 | 475 |
| L0509 | 5 | 1 | Mine | no | - | 3 | 1 | 1 | 0 | 0 | 0 | 1038 |
| L0509 | 5 | 1 | Opponent | no | - | - | 0 | 2 | 0 | 0 | 0 | 420 |
| L0510 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 686 |
| L0510 | 6 | 1 | Opponent | no | 11 | 5 | 0 | 1 | 0 | 0 | 0 | 330 |
| L0511 | 1 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 686 |
| L0511 | 1 | 1 | Opponent | no | 0 | 5 | 1 | 2 | 0 | 0 | 0 | 688 |
| L0522 | 6 | 1 | Mine | no | 1 | - | 0 | 3 | 0 | 0 | 0 | 548 |
| L0522 | 6 | 1 | Opponent | no | 1 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0614 | 2 | 1 | Mine | - | - | 3 | 1 | 0 | 0 | 0 | 0 | 893 |
| L0614 | 2 | 1 | Opponent | - | - | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0615 | 3 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 929 |
| L0615 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0619 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 615 |
| L0619 | 1 | 1 | Opponent | yes | 0 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0627 | 3 | 1 | Mine | no | 0 | 6 | 1 | 1 | 0 | 0 | 0 | 1112 |
| L0627 | 3 | 1 | Opponent | no | 8 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0708 | 6 | 1 | Mine | no | 1 | 1 | 2 | 1 | 1 | 0 | 0 | 420 |
| L0708 | 6 | 1 | Opponent | no | 6 | 2 | 1 | 1 | 0 | 0 | 0 | 605 |
| L0712 | 4 | 1 | Mine | no | 1 | 3 | 2 | 1 | 0 | 0 | 0 | 497 |
| L0712 | 4 | 1 | Opponent | no | 2 | 2 | 3 | 1 | 1 | 0 | 0 | 330 |
| L0716 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 375 |
| L0716 | 2 | 1 | Opponent | - | - | 1 | 3 | 1 | 0 | 0 | 0 | 307 |
| L0725 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 375 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0730 | 4 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 452 |
| L0730 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0731 | 5 | 1 | Mine | no | - | 3 | 1 | 1 | 0 | 0 | 0 | 420 |
| L0731 | 5 | 1 | Opponent | yes | - | 5 | 1 | 2 | 0 | 0 | 0 | 170 |
| L0810 | 6 | 1 | Mine | no | 1 | 5 | 1 | 2 | 0 | 0 | 0 | 605 |
| L0810 | 6 | 1 | Opponent | no | 14 | 2 | 3 | 1 | 1 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | 4 | 2 | 1 | 0 | 0 | 0 | 769 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 2 | 7 | 0 | 0 | 0 | 0 |
| L0832 | 4 | 1 | Mine | no | 2 | 5 | 1 | 0 | 0 | 0 | 0 | 515 |
| L0832 | 4 | 1 | Opponent | no | 4 | 2 | 1 | 1 | 0 | 0 | 0 | 170 |
| L0833 | 5 | 1 | Mine | no | - | - | 1 | 0 | 0 | 0 | 0 | 515 |
| L0833 | 5 | 1 | Opponent | yes | - | 2 | 2 | 3 | 0 | 0 | 0 | 549 |
| L0835 | 1 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 0 | 4 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1318 | 4 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 140 |
| L1318 | 4 | 1 | Opponent | no | 0 | 3 | 6 | 1 | 1 | 0 | 0 | 0 |
| L1516 | 4 | 1 | Mine | no | 1 | 2 | 0 | 1 | 0 | 0 | 0 | 314 |
| L1516 | 4 | 1 | Opponent | no | 6 | 2 | 4 | 0 | 0 | 0 | 0 | 200 |
| L1822 | 4 | 1 | Mine | no | 2 | - | 2 | 1 | 0 | 0 | 0 | 0 |
| L1822 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Mine | no | 3 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 6 | 6 | 1 | 0 | 3 | 0 | 0 | 340 |
| L2224 | 4 | 1 | Mine | no | 1 | 2 | 2 | 0 | 0 | 0 | 0 | 55 |
| L2224 | 4 | 1 | Opponent | no | 0 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2228 | 2 | 1 | Mine | - | - | 1 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2228 | 2 | 1 | Opponent | - | - | 4 | 1 | 1 | 1 | 0 | 0 | 0 |
| L2230 | 4 | 1 | Mine | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2230 | 4 | 1 | Opponent | no | 0 | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 3% | 1.0 | 3.1 | 1.4 | 1.0 | 0.1 | 0.0 | 0.0 | 488.8 |
| **Average** | | | Opponent | 25% | 2.6 | 2.8 | 2.2 | 1.4 | 0.3 | 0.0 | 0.0 | 230.6 |

### KPIs: gf-h2h-mine-0533c46-p1

Rules off - Opponent only: GUN FIGURES, GUN MASK, GUN VIEW, GUN THREAT, STAY WORTH, BEST MOVE FOR SHOOTERS, FACE THE CAST, WIZARD FRONT RANK, FIRE PLAN, FIRE IN ORDER, KEEPS THE TARGET, MISSILES IN THE FIRE PLAN, THREAT AT FULL SIZE, SHOOTERS ARE THREATS, SHOOTERS TO THE PRIMARY, EVERY WOUND COUNTS, HONEST THREAT, ONE YARDSTICK.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 54% (93 of 171) | 5% (9 of 170) | 30% (102 of 341) |
| Winner chose to follow up after the loser gave ground |  | 95% (41 of 43); on the table 95% | 98% (43 of 44); on the table 98% | 97% (84 of 87); on the table 97% |
| Winner chose to pursue after the loser fell back in good order |  | 67% (2 of 3); on the table 67% | 92% (12 of 13); on the table 92% | 88% (14 of 16); on the table 88% |
| Winner chose to pursue after the loser fled |  | 68% (13 of 19); on the table 74% | 77% (17 of 22); on the table 86% | 73% (30 of 41); on the table 80% |
| Winner chose to follow up or pursue (all three) |  | 86% (56 of 65); on the table 88% | 91% (72 of 79); on the table 94% | 89% (128 of 144); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 40% (70 of 174) | 38% (77 of 204) | 39% (147 of 378) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 50% (58 of 117) | 47% (77 of 164) | 48% (135 of 281) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 39% (14 of 36) | 38% (48 of 126) | 38% (62 of 162) |
|     round 1 |  | 83% (5 of 6) | 19% (4 of 21) | 33% (9 of 27) |
|     rounds 2+ |  | 30% (9 of 30) | 42% (44 of 105) | 39% (53 of 135) |
|   other wizards | 50%+ | 35% (44 of 126) | 37% (29 of 78) | 36% (73 of 204) |
|     round 1 |  | 10% (2 of 21) | 15% (2 of 13) | 12% (4 of 34) |
|     rounds 2+ |  | 40% (42 of 105) | 42% (27 of 65) | 41% (69 of 170) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 30% (7 of 23) | 30% (7 of 23) |
| Points that never fought | lower | 55% (38987 of 70291) | 52% (37111 of 71989) | 53% (76098 of 142280) |
|   infantry points that never fought | lower | 52% (8684 of 16644) | 77% (10078 of 13123) | 63% (18762 of 29767) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 67% (190 of 282) | 53% (156 of 293) | 60% (346 of 575) |
| Bound items with a magic missile used (at least once a game) |  | 75% (6 of 8); 0.5 uses a game | 95% (18 of 19); 1.3 uses a game | 89% (24 of 27); 0.9 uses a game |
| Bound items with another spell used |  | 45% (5 of 11); 0.4 uses a game | 56% (5 of 9); 0.3 uses a game | 50% (10 of 20); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 56% (10 of 18); 0.3 uses a game | 62% (10 of 16); 0.3 uses a game | 59% (20 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 65% (36136 of 55230) | 47% (29502 of 63193) | 55% (65638 of 118423) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (35%) | 1.3 (37%) | 2.3 (36%) |
| MARCHED: its unit marched | 0.4 (14%) | 0.9 (24%) | 1.3 (20%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| IN COMBAT: engaged in combat | 0.2 (9%) | 0.5 (15%) | 0.8 (12%) |
| REAR RANK: in a rear rank | 0.1 (4%) | 0.2 (5%) | 0.3 (4%) |
| GONE: slain | 0.9 (30%) | 0.6 (17%) | 1.4 (23%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (5%) | 0.0 (0%) | 0.1 (2%) |
| STUPIDITY: Stupidity | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.0 (1%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.5 | 1.2 | 1.9 | 4.1 | 0.3 | 0.9 |
| not cast | 3.4 | 1.7 | 2.6 | 6.4 | 1.5 | 14.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.9 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.6 (36%) | 0.1 (2%) | 2.3 (36%) | 0.5 (33%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (20%) | 0.3 (19%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.1 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.1 (3%) | 0.3 (11%) | 0.8 (12%) | 0.2 (11%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (10%) | 0.3 (20%) | 0.5 (19%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (6%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| GONE: slain | 0.9 (26%) | 0.3 (16%) | 0.4 (17%) | 1.4 (23%) | 0.3 (19%) | 2.0 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (7%) | 0.0 (0%) | 0.1 (4%) | 0.1 (2%) | 0.0 (0%) | 0.2 (2%) |
| STUPIDITY: Stupidity | 0.0 (1%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.2 (13%) | 0.0 (0%) | 0.1 (1%) | 0.1 (9%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (51%) | 0.2 (11%) | 1.1 (44%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 11.5 (77%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.7 a game | 1.0 a game |
| stood (cast and not dispelled) | 58% (23 of 40) | 57% (8 of 14) | 57% (31 of 54) |
| the unit moved after it | 30% (7 of 23) | 62% (5 of 8) | 39% (12 of 31) |
| it charged on its next turn | 4% (1 of 23) | 25% (2 of 8) | 10% (3 of 31) |
| the enemy charged it first | 13% (3 of 23) | 12% (1 of 8) | 13% (4 of 31) |
| it fought by the end of its next turn | 0% (0 of 23) | 12% (1 of 8) | 3% (1 of 31) |
| it moved out of a charge the enemy had planned (not charged first) | 17% (4 of 23) | 12% (1 of 8) | 16% (5 of 31) |
| none of these (no charge, no fight, no charge escaped) | 65% (15 of 23) | 50% (4 of 8) | 61% (19 of 31) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 73% (1012 of 1395) | 59% (464 of 784) | 68% (1476 of 2179) |
|   cavalry | 69% (81 of 118) | 62% (77 of 125) | 65% (158 of 243) |
|   character | 73% (158 of 217) | 26% (25 of 97) | 58% (183 of 314) |
|   chariot | 66% (69 of 105) | 66% (47 of 71) | 66% (116 of 176) |
|   infantry | 56% (200 of 360) | 62% (172 of 279) | 58% (372 of 639) |
|   monster | 66% (25 of 38) | 35% (8 of 23) | 54% (33 of 61) |
|   war machine | 86% (479 of 557) | 71% (135 of 189) | 82% (614 of 746) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.4 (23%) | 2.5 (28%) | 4.9 (25%) |
| CHARGED: it charged | 1.0 (10%) | 1.8 (20%) | 2.8 (14%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.0 (0%) | 0.3 (1%) |
| IN COMBAT: it fought this turn or the last | 0.8 (7%) | 0.3 (4%) | 1.1 (6%) |
| MOVED: a war machine that moved | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| NO TARGET IN RANGE | 2.2 (20%) | 1.8 (20%) | 4.0 (20%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (6%) | 0.3 (3%) | 0.9 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.2 (20%) | 1.3 (15%) | 3.5 (18%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.4 (5%) | 0.7 (4%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.7 (6%) | 0.4 (5%) | 1.1 (6%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.4 | 2.5 | 76% | 6.6 pts | 49 pts |
| character | 5.5 | 1.8 | 78% | 7.6 pts | 41 pts |
| chariot | 3.2 | 1.9 | 68% | 15.9 pts | 52 pts |
| infantry | 15.4 | 5.7 | 73% | 7.6 pts | 117 pts |
| monster | 1.0 | 0.2 | 81% | 5.2 pts | 5 pts |
| war machine | 17.2 | 14.8 | 59% | 24.0 pts | 414 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.9 | 5.4 | 4.1 |
| Charges that made contact a game | 2.0 | 3.4 | 2.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.08 declared, 0.08 contact (12 units) | 0.47 declared, 0.33 contact (15 units) | 0.30 declared, 0.22 contact (27 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.25 declared, 0.25 contact (4 units) | 1.10 declared, 0.30 contact (10 units) | 1.14 declared, 0.29 contact (14 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.41 declared, 0.30 contact (235 units) | 0.75 declared, 0.48 contact (235 units) | 0.58 declared, 0.39 contact (470 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 39% (26 of 66) | 67% (14 of 21) | 75% (6 of 8) | 48% (46 of 95) |
| Character in a unit | 90% (43 of 48) | 90% (18 of 20) | 67% (2 of 3) | 89% (63 of 71) |
| Character on its own | 87% (41 of 47) | 35% (9 of 26) | 33% (16 of 48) | 55% (66 of 121) |
| Chariot | 92% (11 of 12) | 75% (15 of 20) | - | 81% (26 of 32) |
| Infantry | 57% (33 of 58) | 38% (16 of 42) | 38% (3 of 8) | 48% (52 of 108) |
| Monster | 48% (12 of 25) | 80% (4 of 5) | - | 53% (16 of 30) |
| Monstrous | 50% (2 of 4) | 30% (3 of 10) | - | 36% (5 of 14) |
| War Machines | 68% (67 of 99) | 100% (5 of 5) | - | 69% (72 of 104) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 3 | 100% (4 of 4); on the table 100% | 24% (23 of 96) | 59% | 73% (11 of 15) | 67% (2 of 3); 2.0 uses a game | 33% (1 of 3); 1.3 uses a game | 100% (3 of 3); 1.0 uses a game |
| Chaos Dwarfs | 5 | 75% (3 of 4); on the table 75% | 69% (37 of 54) | 61% | 72% (29 of 40) | 0.0 uses a game | 0.0 uses a game | 80% (4 of 5); 0.8 uses a game |
| Dwarfen Mountain Holds | 12 | 79% (11 of 14); on the table 79% | - | 72% | 78% (74 of 95) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 17 | 89% (24 of 27); on the table 93% | 43% (23 of 54) | 59% | 62% (106 of 170) | 0.0 uses a game | 57% (4 of 7); 0.5 uses a game | 40% (6 of 15); 0.4 uses a game |
| Grand Cathay | 4 | 100% (3 of 3); on the table 100% | 42% (38 of 90) | 67% | 46% (17 of 37) | 89% (8 of 9); 6.0 uses a game | 0% (0 of 2); 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| High Elf Realms | 5 | 83% (15 of 18); on the table 83% | 17% (3 of 18) | 25% | 42% (16 of 38) | 100% (7 of 7); 4.0 uses a game | 62% (5 of 8); 2.2 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 78% (7 of 9); on the table 89% | - | 60% | 33% (6 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Ogre Kingdoms | 3 | 91% (10 of 11); on the table 91% | 42% (5 of 12) | 45% | 67% (14 of 21) | 67% (2 of 3); 1.3 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (4 of 4); on the table 100% | 0% (0 of 6) | 18% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 7 | 95% (20 of 21); on the table 100% | - | 40% | 57% (20 of 35) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 4 | 100% (11 of 11); on the table 100% | 38% (9 of 24) | 59% | 52% (13 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 6 | 88% (14 of 16); on the table 88% | 44% (8 of 18) | 21% | 49% (25 of 51) | 100% (2 of 2); 0.3 uses a game | 0.0 uses a game | 100% (2 of 2); 0.3 uses a game |
| Wood Elf Realms | 2 | 100% (2 of 2); on the table 100% | 17% (1 of 6) | 73% | 55% (12 of 22) | 100% (3 of 3); 4.5 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gf-h2h-mine-0533c46-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 46% (31) | 42% (20) | 44% (51) |
| ...free all their last turn and able to turn (per game) | 0.50 | 0.31 | 0.81 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.25 | 0.08 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.22 | 0.22 | 0.44 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.89 | 0.94 | 2.83 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.89 | 0.94 | 1.83 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.28 | 5.39 | 10.67 |

### Quality by phase: gf-h2h-mine-0533c46-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.2 | 3.1 |
| Strategy | Charge objectives carried out (made contact) | 55% (51 of 92) | 38% (67 of 175) |
| Strategy | Shoot objectives carried out (shot that target) | 43% (303 of 705) | 58% (159 of 274) |
| Strategy | Close-in objectives charged next turn | 9% (12 of 131) | 16% (39 of 237) |
| Strategy | Support requests answered (helper made contact too) | 57% (13 of 23) | 35% (11 of 31) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 50% (3 of 6) | 43% (3 of 7) |
| Strategy | Joined characters whose unit fought | 30% (20 of 67) | 29% (14 of 49) |
| Strategy | Lone characters that fought | 46% (41 of 90) | 58% (53 of 91) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 1.0 | 1.4 |
| Movement | Points that never moved of their own | 488.8 | 230.6 |
| Movement | Fights charged into per game | 1.7 | 2.9 |
| Movement | Charges with odds: long shots (under 50%) | 8 of 56, net +18 | 12 of 87, net +157 |
| Movement | Charges with odds: sweet spot (55-75%) | 11 of 56, net -27 | 16 of 87, net +86 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 56, net -30 | 7 of 87, net +80 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 20 of 56, net +136 | 18 of 87, net +178 |
| Shooting | Shots by shooting units (incl. breath weapons) | 15.6 | 10.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 52% (293 of 561) | 36% (133 of 367) |
| Shooting | Points destroyed by shooting units | 162.5 | 39.3 |
| Shooting | War machine shots | 13.3 | 3.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 47% (225 of 479) | 43% (60 of 141) |
| Shooting | Points destroyed by war machines | 181.4 | 47.3 |
| Magic | Magic missiles cast | 1.0 | 1.4 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 51% (19 of 37) | 48% (24 of 50) |
| Magic | Wounds caused by magic missiles | 2.1 | 2.2 |
| Magic | Wounds caused by other spells | 0.4 | 0.5 |
| Magic | Points destroyed by magic (all spells) | 15.3 | 32.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.2 / 0.2 / 0.0 | 2.0 / 0.4 / 0.2 / 0.1 |
| Combat | Points destroyed in combat | 166.1 | 313.2 |
| Combat | Points run down | 49.4 | 106.2 |
| Combat | Net points per charged fight, damage counted | +65 | +89 |
| Combat | Net per 100 charger points, damage counted | +29.5 | +30.3 |
| Combat | First round won (charged fights) | 76% | 76% |
| Combat | Net points per charged fight | +64 | +97 |
| Combat | Net points per supported fight / lone fight | +124 / +48 | +138 / +90 |
| Combat | Charged fights on a top-3 enemy unit | 21 of 62 | 43 of 104 |
| Game | Points lost | 625.9 | 652.6 |
| Game | VP from objectives | 467.8 | 712.5 |
| Game | Lone holders (player turns) | 1.0 | 2.6 |

- Mine won / drew / lost: 9 / 10 / 17 of 36 ended games (of 36); mean margin (Mine - Opponent) -240 VP
- The side that went first won 16 of 26 games with a winner
- Points traded per game (both sides' losses): 1278
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gf-h2h-mine-0533c46-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.5 | +0.0 | 0.0 | 1.8 | 0.6 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | 0.1 | +1.0 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 3.4 | +0.0 | 0.0 | 57.5 | 0.9 | +0.0 | 0.0 | 30.3 |
| BACKUP TARGETS | 0.8 | +6.8 | 0.0 | 0.0 | 1.2 | +9.8 | 0.0 | 10.6 |
| BEST FACING | 0.8 | +55.7 | 0.0 | 21.4 | 0.5 | +15.1 | 0.0 | 18.8 |
| BEST FIRST | 3.9 | +166.8 | 140.6 | 108.3 | 4.2 | +139.2 | 128.8 | 54.4 |
| BEST MOVE FOR SHOOTERS | 0.9 | +67.0 | 0.0 | 8.6 | - | - | - | - |
| BEST OVERALL | 0.7 | +57.2 | 0.0 | 26.3 | 0.5 | +36.5 | 0.0 | 15.3 |
| BEST PREY | 0.7 | +30.7 | 11.8 | 0.0 | 0.7 | +22.2 | 11.1 | 8.6 |
| BEST PRIZE | 0.0 | -0.4 | 0.0 | 0.0 | 0.2 | +3.3 | 14.2 | 5.4 |
| BIG CHARACTER SAFETY | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.9 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 4.7 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.3 | +4.2 | 0.0 | 0.0 | 0.7 | +2.0 | 0.0 | 5.1 |
| BLOWS WHERE AIMED | 0.1 | -9.5 | 0.0 | 0.0 | 0.5 | -113.1 | 69.8 | 35.6 |
| CANNON PLAN MISSED | - | - | - | - | 0.5 | +0.0 | 31.0 | 10.1 |
| CANNON PLANNED TARGET | - | - | - | - | 2.8 | +116.5 | 105.3 | 68.3 |
| CANNON SIGHT KEPT | 2.1 | +0.0 | 0.0 | 10.3 | 1.4 | +0.0 | 0.0 | 19.3 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 13.1 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | -0.9 | 23.7 | 0.0 | 0.2 | -3.0 | 21.4 | 0.0 |
| CAST JOB | 0.7 | +15.5 | 32.3 | 16.1 | 0.7 | +13.5 | 45.2 | 5.4 |
| CASTER AWAY FROM SCREEN | 0.1 | +0.0 | 0.0 | 2.6 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +10.4 | 4.7 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 20.7 |
| CASTS FROM BEHIND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +0.9 | 0.0 | 7.5 | 0.1 | +0.7 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 0.2 | -0.3 | 2.9 | 5.4 |
| CHARGE BAND | 0.3 | +0.0 | 30.2 | 0.0 | 0.4 | +0.0 | 55.5 | 13.6 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 123.1 | 34.5 | 2.7 | +0.0 | 301.5 | 130.5 |
| CHARGE NOW WEIGHED | 0.6 | -65.3 | 17.5 | 14.9 | 0.8 | -78.1 | 30.6 | 16.3 |
| CHARGER SLAIN LOST | 0.3 | -9.3 | 36.2 | 3.3 | 0.3 | -4.0 | 29.8 | 21.7 |
| CHARIOT WIZARD CAREFUL | 0.0 | -0.6 | 0.0 | 0.0 | - | - | - | - |
| CHEAP HELPER | 0.1 | +0.0 | 14.9 | 0.0 | - | - | - | - |
| COMBAT PIVOT | 0.3 | +0.0 | 27.0 | 40.6 | 0.4 | +0.0 | 8.2 | 24.4 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.9 | +184.0 | 0.0 | 10.6 | 0.3 | +39.2 | 10.2 | 17.9 |
| COUNTER-CHARGE COVER | 11.8 | +1366.7 | 0.0 | 218.2 | 7.0 | +611.2 | 0.0 | 162.4 |
| DEFENSIVE ARMY | 0.6 | +0.0 | 11.8 | 10.8 | - | - | - | - |
| DEFENSIVE FLOOR | 0.1 | +6.4 | 16.3 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.0 | +0.0 | 3.6 | 0.0 | 0.2 | +13.8 | 26.6 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +0.4 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| EVERY WOUND COUNTS | 21.0 | +0.0 | 1109.9 | 262.1 | - | - | - | - |
| FACES THE THREAT | 1.9 | +197.5 | 0.0 | 52.4 | 0.9 | +64.3 | 0.0 | 34.7 |
| FALLBACK BY WORTH | 4.8 | +68.8 | 0.0 | 69.6 | 4.9 | +55.9 | 0.0 | 61.2 |
| FIGHT LIFT | - | - | - | - | 0.0 | +1.0 | 14.2 | 0.0 |
| FIRE AND FLEE | 0.0 | +2.6 | 3.5 | 0.0 | 0.1 | +0.4 | 0.0 | 9.2 |
| FIRE IN ORDER | 1.6 | +0.0 | 121.2 | 14.8 | - | - | - | - |
| FIRE PLAN | 30.4 | +163.4 | 1568.2 | 379.7 | - | - | - | - |
| FLANK NOT WEIGHED | 6.1 | +0.0 | 0.0 | 143.1 | 5.2 | +0.0 | 0.0 | 113.1 |
| FOCUS FIRE | - | - | - | - | 0.0 | +0.9 | 1.5 | 0.0 |
| FOLLOW UP WEIGHED | 0.6 | +70.5 | 0.0 | 7.8 | 0.8 | +118.5 | 0.0 | 68.3 |
| FRIENDS SHOTS CHECKED | 0.3 | +22.1 | 0.0 | 2.9 | 0.2 | +18.5 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -0.5 | 12.1 | 0.0 | 0.1 | -1.2 | 2.6 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -0.3 | 2.1 | 0.0 |
| GROUND FLIERS | 0.0 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 4.2 | +114.2 | 315.6 | 31.4 | - | - | - | - |
| GUN MASK | 0.6 | +17.3 | 0.0 | 17.1 | - | - | - | - |
| GUN THREAT | 4.4 | +620.6 | 416.1 | 78.2 | - | - | - | - |
| GUN VIEW | 1.3 | +21.1 | 0.0 | 5.3 | - | - | - | - |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 11.5 | 1.8 |
| HELPER UNSEEN | 0.1 | +0.0 | 8.5 | 10.5 | 0.4 | +0.0 | 32.0 | 0.0 |
| HILL BY ITS CHANCE | 0.1 | -11.0 | 0.0 | 0.0 | 0.2 | -22.6 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST THREAT | 21.0 | +3145.0 | 1109.9 | 262.1 | - | - | - | - |
| HONEST WORTH | 6.0 | -77.2 | 356.5 | 63.1 | 10.0 | -216.0 | 500.3 | 372.1 |
| HORN WORTH | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.0 | +4.0 | 0.0 | 3.2 | 0.4 | +2.4 | 13.8 | 7.6 |
| HUNT DROPPED | - | - | - | - | 0.2 | +0.0 | 2.4 | 1.9 |
| HUNT IN PAIRS | 0.3 | +8.5 | 0.0 | 0.0 | 1.1 | +60.0 | 0.0 | 5.4 |
| HUNT KEPT | - | - | - | - | 0.1 | +0.2 | 0.0 | 5.6 |
| HUNT RESULT | 0.1 | +19.4 | 0.0 | 3.2 | 0.4 | +20.3 | 6.2 | 5.9 |
| HUNT THE GUNS | 0.1 | +35.3 | 18.5 | 4.1 | 0.4 | +87.3 | 16.4 | 5.6 |
| INVITES THE FIGHT | 2.0 | +38.8 | 38.0 | 14.2 | 1.5 | +26.6 | 29.1 | 16.7 |
| JOINT CHARGE PLAN | 0.2 | +13.1 | 21.4 | 0.0 | 0.2 | +6.1 | 0.0 | 13.1 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -0.6 | 15.2 | 0.0 |
| KEEP FALLS | 0.2 | +4.2 | 0.0 | 18.8 | 0.1 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.0 | +0.2 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.1 | +32.5 | 135.1 | 1.7 | 2.1 | +63.3 | 119.5 | 40.2 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| KEEPS THE TARGET | 2.4 | -158.7 | 205.2 | 31.2 | - | - | - | - |
| KILLS COUNT | 1.1 | +42.8 | 84.1 | 20.0 | 2.2 | +125.4 | 209.7 | 97.3 |
| KILLS COUNT NEXT TURN | 3.7 | +97.7 | 128.7 | 34.1 | 6.3 | +175.5 | 162.4 | 180.6 |
| LONE CHARACTER SAFE SPOT | 0.7 | +21.7 | 5.7 | 4.4 | 0.4 | +21.6 | 6.4 | 0.0 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 3.5 | 0.0 | 0.3 | +0.0 | 1.5 | 10.8 |
| LONE WIZARD KEPT IN | 0.6 | +41.6 | 0.0 | 6.2 | 0.5 | +37.5 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | +1.1 | 44.3 | 1.0 | 0.4 | +2.7 | 23.2 | 10.0 |
| LOST CHARGE | 2.6 | -63.5 | 68.1 | 42.8 | 2.2 | -47.8 | 53.8 | 116.2 |
| LURE BY WHAT IT DRAWS | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | -1.1 | 0.0 | 1.1 |
| MAKE SURE TOGETHER | 0.7 | +48.6 | 14.2 | 13.6 | 1.4 | +152.0 | 34.1 | 65.9 |
| MANOEUVRE | 0.3 | +8.5 | 0.0 | 8.6 | 0.1 | +1.2 | 0.0 | 0.9 |
| MARCH AT ESCAPER | 0.0 | +0.6 | 0.0 | 0.0 | 0.0 | +2.0 | 0.0 | 0.0 |
| MARCH CHECK | 0.2 | +45.0 | 0.0 | 0.0 | 0.4 | +19.7 | 0.0 | 0.0 |
| MARCH ODDS | 0.1 | +14.7 | 10.9 | 0.0 | 0.3 | +23.3 | 32.2 | 10.2 |
| MARCH OVER CASTS | 0.3 | +27.1 | 0.0 | 10.6 | 0.4 | +16.9 | 0.0 | 7.6 |
| MAX FOR POSITIONING | 3.8 | +122.6 | 0.0 | 70.6 | 5.8 | +260.3 | 0.0 | 145.5 |
| MISSILES IN THE FIRE PLAN | 1.1 | +11.3 | 24.1 | 18.4 | - | - | - | - |
| MISSILES IN THE MOVE | 2.1 | +70.3 | 0.0 | 23.2 | 3.7 | +53.9 | 0.0 | 75.7 |
| MISSILES NEXT TURN | 2.3 | +51.6 | 0.0 | 33.7 | 4.4 | +51.4 | 0.0 | 119.1 |
| MODEL FACING | 0.6 | +170.4 | 0.0 | 1.7 | 0.1 | +29.0 | 0.0 | 1.7 |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 12.6 | 10.6 | 0.6 | +0.0 | 12.9 | 38.3 |
| MOVE AND CAST | 0.3 | +13.1 | 0.0 | 2.4 | 0.3 | +13.5 | 0.0 | 16.5 |
| MOVE SPELL IN RANGE | 0.5 | +18.4 | 0.0 | 10.6 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.7 | -35.7 | 0.0 | 9.9 | - | - | - | - |
| MOVE SPELL SPOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 13.1 |
| MOVE TO CHARGE | 3.1 | +121.5 | 127.7 | 20.9 | 5.6 | +416.0 | 154.4 | 210.2 |
| MOVES UNITS SPELL | 0.0 | +0.2 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.0 | +6.4 | 0.0 | 0.0 |
| NO RALLY LEFT | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| NOT NEEDED | 0.1 | -4.6 | 0.0 | 0.0 | 0.2 | -6.6 | 19.4 | 0.0 |
| NOT TURNED | 5.3 | +115.1 | 0.0 | 107.2 | 5.4 | +101.2 | 0.0 | 144.5 |
| NOT WORTH A CAST | 0.7 | -0.4 | 0.0 | 10.6 | 0.4 | -0.2 | 0.0 | 21.1 |
| OFF BEST | 15.8 | -788.8 | 5.4 | 209.8 | 16.1 | -755.6 | 8.7 | 290.8 |
| ONE YARDSTICK | 30.6 | -1760.7 | 995.1 | 403.6 | - | - | - | - |
| OPENS A LANE | 0.2 | +8.8 | 31.1 | 3.5 | 0.1 | +1.1 | 17.8 | 16.8 |
| OPENS UP | 0.1 | +3.6 | 2.8 | 0.0 | 0.4 | +37.6 | 29.4 | 30.1 |
| OVERRUNS AWAY | 0.3 | +13.4 | 26.8 | 1.0 | 0.6 | +9.1 | 64.8 | 38.6 |
| PATHS CROSS | 1.7 | +112.7 | 0.0 | 33.3 | 2.5 | +137.3 | 0.0 | 47.8 |
| PIVOT GUARDS FLANK | 0.1 | -0.7 | 0.0 | 0.0 | 0.2 | -3.1 | 0.0 | 7.9 |
| PLAN RESULT | 41.8 | +2089.7 | 1823.7 | 789.1 | 37.7 | +1034.7 | 1164.5 | 893.5 |
| PURSUES BIG PREY | 0.1 | -1.3 | 0.0 | 0.0 | 0.1 | -26.4 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +3.3 | 0.0 | 0.0 | 0.1 | +12.3 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 0.6 | +4.2 | 0.0 | 14.2 |
| RANDOM MOVER NO PROMISE | - | - | - | - | 0.1 | -3.3 | 3.8 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -1.5 | 0.0 | 1.0 | 0.2 | +3.3 | 0.0 | 3.7 |
| REDIRECT COUNTER | 1.6 | +156.1 | 0.0 | 21.1 | 2.8 | +267.9 | 0.0 | 57.0 |
| REDIRECT WEIGHED | 0.2 | +0.9 | 0.0 | 4.9 | 0.6 | +11.5 | 18.1 | 17.2 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 8.3 | 0.2 | +0.0 | 0.0 | 16.6 |
| RESERVE FALL BACK | 0.3 | +7.1 | 0.0 | 5.4 | 0.8 | +21.8 | 0.0 | 6.0 |
| RESTRAINS TO SHOOT | 0.2 | +6.2 | 0.0 | 20.2 | 0.1 | +2.3 | 0.0 | 5.4 |
| RISK BY ARC | 1.7 | +75.9 | 158.8 | 33.8 | 2.9 | +33.1 | 292.7 | 155.8 |
| SAFE SURE CHARGE | 0.0 | -1.1 | 0.0 | 0.0 | - | - | - | - |
| SAFER THAN THE JOB | 0.9 | +64.5 | 0.0 | 16.2 | 0.9 | +47.9 | 0.0 | 24.2 |
| SCOUT SPOT | 0.6 | +1.8 | 0.0 | 2.5 | 0.4 | +0.7 | 0.0 | 0.0 |
| SCOUT WAITS | 0.6 | +0.0 | 0.0 | 2.5 | 0.5 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | -13.1 | 0.0 | 1.5 | 0.2 | -15.2 | 0.0 | 1.8 |
| SEARCH SPOT | 2.9 | +139.5 | 0.0 | 27.2 | 2.6 | +142.2 | 0.0 | 42.9 |
| SELF MOVE SPELL | 0.2 | +26.0 | 0.0 | 0.0 | 0.3 | +71.8 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.5 | +118.0 | 22.1 | 13.6 | 3.8 | +520.5 | 95.3 | 122.7 |
| SET-UP ANY TARGET | 0.3 | +52.2 | 0.0 | 0.0 | 0.1 | +15.6 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +6.1 | 6.5 | 0.0 | 0.0 | +9.8 | 16.6 | 0.0 |
| SHOOTERS ARE THREATS | 6.1 | +340.9 | 458.4 | 91.1 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.7 | +1.4 | 0.0 | 0.0 | 0.2 | +0.4 | 0.0 | 0.0 |
| SHOOTERS TO THE PRIMARY | 3.4 | +45.2 | 0.0 | 16.9 | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 1.0 | +37.3 | 85.9 | 4.7 | 1.0 | +19.7 | 7.7 | 25.2 |
| SHORT GUN FORWARD | 0.5 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 3.2 |
| SHOT OPTIONS | 25.9 | +0.0 | 1293.5 | 330.3 | 13.2 | +0.0 | 284.8 | 211.7 |
| SHOT REPLANNED | - | - | - | - | 0.2 | +0.0 | 23.2 | 3.5 |
| SHOTS IN THE MOVE | 26.1 | +1173.3 | 0.0 | 323.4 | 12.4 | +427.9 | 0.0 | 174.3 |
| SPELL SETS UP CHARGE | 0.6 | +150.6 | 0.0 | 10.6 | 0.1 | +43.0 | 10.2 | 17.9 |
| SPELL WORTH | 0.7 | +8.1 | 19.7 | 18.2 | 1.8 | +24.6 | 76.1 | 48.8 |
| SPELLS IN THE FIGHT | 0.3 | -6.3 | 17.8 | 14.4 | 0.5 | -4.2 | 80.2 | 26.5 |
| STABLE ROLE | 9.6 | +0.0 | 262.5 | 122.8 | 10.3 | +0.0 | 304.0 | 137.6 |
| STANDS TO CAST | - | - | - | - | 0.0 | +3.9 | 0.0 | 0.0 |
| STAY WEIGHED | 0.1 | +3.9 | 0.0 | 0.0 | - | - | - | - |
| STAY WORTH | 31.3 | +227.2 | 1024.5 | 268.0 | - | - | - | - |
| STOPS | 0.1 | +0.7 | 18.5 | 0.9 | 0.1 | +0.7 | 2.6 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.4 | +37.5 | 0.0 | 14.3 | 0.4 | +19.3 | 0.0 | 35.6 |
| STUCK PIVOT | - | - | - | - | 0.1 | +0.0 | 0.0 | 4.7 |
| SUPPORT NARROWED | 4.8 | -29.2 | 213.0 | 44.2 | 6.0 | -43.5 | 306.0 | 89.3 |
| SUPPORTS | 3.4 | +39.7 | 80.1 | 29.2 | 3.7 | +48.5 | 139.0 | 31.4 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -0.5 | 2.7 | 0.0 | 0.1 | -3.2 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.4 | -7.0 | 12.6 | 0.0 | 0.9 | +11.9 | 11.7 | 40.0 |
| THROUGH LINE OF FIRE | 0.8 | +56.5 | 0.0 | 27.5 | 0.6 | +19.5 | 0.0 | 9.3 |
| TURN WORTH | 0.1 | -8.3 | 4.4 | 0.0 | 0.1 | -17.3 | 25.6 | 0.0 |
| TWO OR MORE ARRIVE | 0.5 | +3.9 | 0.0 | 0.0 | 1.3 | +13.9 | 18.0 | 21.2 |
| WAIT AFTER COSTS | 6.9 | -360.5 | 260.1 | 50.3 | 8.9 | -493.3 | 228.9 | 261.4 |
| WALKS TO THE FIGHT | 1.4 | +27.1 | 47.8 | 15.2 | 0.9 | +19.0 | 38.9 | 0.0 |
| WAR ENGINE CHARGES | 0.0 | +0.2 | 0.0 | 0.0 | 0.1 | +8.4 | 6.4 | 0.0 |
| WAR ENGINE JOBS | 0.6 | +0.0 | 30.9 | 10.4 | 0.2 | +0.0 | 1.7 | 0.0 |
| WEARS DOWN | 0.8 | +33.5 | 88.3 | 13.0 | 1.4 | +57.4 | 152.1 | 63.1 |
| WHO HITS BACK | 0.1 | +16.7 | 0.0 | 18.7 | 0.2 | +19.3 | 0.0 | 5.4 |
| WHOLE FIGHT | 0.1 | +9.0 | 46.1 | 0.0 | 0.1 | +13.1 | 18.9 | 0.0 |
| WHOLE FIGHT GAIN | 0.5 | +18.9 | 75.6 | 2.6 | 0.8 | +46.4 | 65.5 | 7.9 |
| WIDER SPREAD | 1.9 | -4.2 | 202.6 | 31.5 | 3.7 | -18.0 | 362.6 | 138.2 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 6.5 | 4.0 |

### Rule changes: gf-h2h-mine-0533c46-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1146 | 1146 | 1146 | 31.83 | -55601 | -48.5 |
| FIRE PLAN | 1093 | 1093 | 324 | 9.00 | +3534 | +10.9 |
| BEST FIRST | 294 | 294 | 294 | 8.17 | +11014 | +37.5 |
| SEARCH SPOT | 196 | 196 | 193 | 5.36 | +10190 | +52.8 |
| EVERY WOUND COUNTS | 757 | 757 | 182 | 5.06 | +0 | +0.0 |
| COUNTER-CHARGE COVER | 679 | 371 | 178 | 4.94 | +13648 | +76.7 |
| ARTILLERY RE-ROLL WEIGHED | 154 | 154 | 154 | 4.28 | +0 | +0.0 |
| PATHS CROSS | 152 | 152 | 152 | 4.22 | +9003 | +59.2 |
| MOVE TO CHARGE | 313 | 313 | 148 | 4.11 | +6040 | +40.8 |
| ONE YARDSTICK | 1100 | 545 | 146 | 4.06 | +1648 | +11.3 |
| SHOTS IN THE MOVE | 1386 | 957 | 141 | 3.92 | +3174 | +22.5 |
| CANNON SIGHT KEPT | 125 | 125 | 125 | 3.47 | +0 | +0.0 |
| FACES THE THREAT | 102 | 102 | 102 | 2.83 | +9425 | +92.4 |
| SET UP TOGETHER | 191 | 163 | 102 | 2.83 | +9508 | +93.2 |
| KILLS COUNT NEXT TURN | 361 | 361 | 100 | 2.78 | +2332 | +23.3 |
| SUPPORTS | 255 | 255 | 91 | 2.53 | +1023 | +11.2 |
| FALLBACK BY WORTH | 351 | 351 | 72 | 2.00 | +4489 | +62.3 |
| WAIT AFTER COSTS | 572 | 572 | 67 | 1.86 | +1309 | +19.5 |
| SAFER THAN THE JOB | 66 | 66 | 66 | 1.83 | +4044 | +61.3 |
| HONEST THREAT | 757 | 757 | 60 | 1.67 | +0 | +0.0 |
| FIRE IN ORDER | 59 | 59 | 59 | 1.64 | +0 | +0.0 |
| STAY WORTH | 1128 | 965 | 51 | 1.42 | +596 | +11.7 |
| FOLLOW UP WEIGHED | 50 | 50 | 50 | 1.39 | +6805 | +136.1 |
| THROUGH LINE OF FIRE | 50 | 50 | 50 | 1.39 | +2738 | +54.8 |
| WALKS TO THE FIGHT | 85 | 85 | 48 | 1.33 | +738 | +15.4 |
| BEST FACING | 47 | 47 | 47 | 1.31 | +2548 | +54.2 |
| CHARGE NOW WEIGHED | 47 | 47 | 47 | 1.31 | +7169 | +152.5 |
| BEST OVERALL | 43 | 43 | 43 | 1.19 | +3373 | +78.5 |
| KEEPS THE TARGET | 85 | 85 | 42 | 1.17 | -6675 | -158.9 |
| RESERVE FALL BACK | 42 | 42 | 42 | 1.17 | +1042 | +24.8 |
| SCOUT WAITS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 38 | 38 | 38 | 1.06 | +2846 | +74.9 |
| ADVANCE LANE KEPT | 37 | 37 | 37 | 1.03 | +0 | +0.0 |
| MAX FOR POSITIONING | 342 | 190 | 37 | 1.03 | +634 | +17.1 |
| BLOCKED WHEEL | 36 | 36 | 36 | 1.00 | +221 | +6.1 |
| CHARGE NOW FIRST | 143 | 143 | 35 | 0.97 | -2756 | -78.7 |
| REDIRECT COUNTER | 156 | 87 | 35 | 0.97 | +2788 | +79.6 |
| RISK BY ARC | 164 | 155 | 34 | 0.94 | +1291 | +38.0 |
| SHOOTERS IN TWO RANKS | 34 | 34 | 34 | 0.94 | +63 | +1.9 |
| HONEST WORTH | 577 | 571 | 32 | 0.89 | +174 | +5.4 |
| BEST MOVE FOR SHOOTERS | 31 | 31 | 31 | 0.86 | +2412 | +77.8 |
| HOLDS AMBUSHERS | 31 | 31 | 31 | 0.86 | +0 | +0.0 |
| KILLS COUNT | 120 | 117 | 29 | 0.81 | +1472 | +50.8 |
| REDIRECT WEIGHED | 29 | 29 | 29 | 0.81 | +1724 | +59.4 |
| STOPS SHORT OF THE FLANK | 29 | 29 | 29 | 0.81 | +2046 | +70.6 |
| SHOOTS FROM THE BEST SPOT | 71 | 71 | 28 | 0.78 | +898 | +32.1 |
| COMBAT PIVOT | 27 | 27 | 27 | 0.75 | +0 | +0.0 |
| MAKE SURE TOGETHER | 75 | 50 | 27 | 0.75 | +1932 | +71.6 |
| INVITES THE FIGHT | 126 | 126 | 26 | 0.72 | +304 | +11.7 |
| MISSILES IN THE MOVE | 209 | 114 | 25 | 0.69 | +604 | +24.2 |
| MODEL FACING | 24 | 24 | 24 | 0.67 | +7179 | +299.1 |
| CHARGE BAND | 23 | 23 | 23 | 0.64 | +0 | +0.0 |
| SHORT GUN FORWARD | 23 | 23 | 23 | 0.64 | +0 | +0.0 |
| MOVE AND CAST | 22 | 22 | 22 | 0.61 | +959 | +43.6 |
| CANNON PLANNED TARGET | 102 | 102 | 20 | 0.56 | -182 | -9.1 |
| CAST JOB | 49 | 49 | 20 | 0.56 | +244 | +12.2 |
| WHOLE FIGHT GAIN | 46 | 42 | 20 | 0.56 | +544 | +27.2 |
| GUN VIEW | 47 | 47 | 19 | 0.53 | +760 | +40.0 |
| KEEPS ITS TARGET | 115 | 114 | 19 | 0.53 | +300 | +15.8 |
| FRIENDS SHOTS CHECKED | 18 | 18 | 18 | 0.50 | +1461 | +81.1 |
| GUN THREAT | 157 | 157 | 18 | 0.50 | +0 | +0.0 |
| MARCH CHECK | 25 | 24 | 18 | 0.50 | +1410 | +78.4 |
| BEST PREY | 51 | 51 | 17 | 0.47 | +263 | +15.5 |
| SHOOTERS ARE THREATS | 218 | 218 | 16 | 0.44 | +0 | +0.0 |
| MARCH ODDS | 14 | 14 | 14 | 0.39 | +255 | +18.2 |
| OPENS UP | 18 | 18 | 14 | 0.39 | +522 | +37.3 |
| WHO HITS BACK | 11 | 11 | 11 | 0.31 | +1012 | +92.0 |
| BEST PRIZE | 10 | 10 | 10 | 0.28 | -706 | -70.6 |
| MANOEUVRE | 12 | 12 | 10 | 0.28 | +348 | +34.9 |
| OVERRUNS AWAY | 33 | 32 | 10 | 0.28 | +129 | +12.9 |
| REFUSING RETIRES | 20 | 20 | 10 | 0.28 | -4 | -0.4 |
| RESTRAINS TO SHOOT | 10 | 10 | 10 | 0.28 | +305 | +30.5 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| LOST CHARGE | 174 | 173 | 9 | 0.25 | +212 | +23.5 |
| SHOT REPLANNED | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| WEARS DOWN | 78 | 72 | 9 | 0.25 | +375 | +41.7 |
| CHAFF PASSED | 8 | 8 | 8 | 0.22 | -9 | -1.2 |
| HUNT IN PAIRS | 48 | 25 | 8 | 0.22 | +434 | +54.2 |
| KEEP FALLS | 8 | 8 | 8 | 0.22 | +566 | +70.7 |
| PIVOT GUARDS FLANK | 8 | 8 | 8 | 0.22 | -137 | -17.1 |
| SUPPORT NARROWED | 387 | 387 | 8 | 0.22 | -75 | -9.3 |
| BIG CHARACTER SAFETY | 7 | 7 | 7 | 0.19 | +33 | +4.8 |
| CASTS FROM BEHIND | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| MISSILES NEXT TURN | 241 | 128 | 7 | 0.19 | +67 | +9.6 |
| RANDOM MOVE BY FIGURES | 23 | 23 | 7 | 0.19 | +153 | +21.8 |
| BLOCKED CHARGE SKIPPED | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| PURSUES BIG PREY | 6 | 6 | 6 | 0.17 | -996 | -166.1 |
| SURE CHARGE BEATS ADVANCE | 6 | 6 | 6 | 0.17 | -131 | -21.8 |
| WAR ENGINE JOBS | 28 | 28 | 6 | 0.17 | -273 | -45.6 |
| DEFENSIVE ARMY | 20 | 20 | 5 | 0.14 | -65 | -13.0 |
| KEEPS SCOUTS OR AMBUSH | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 17 | 17 | 5 | 0.14 | -59 | -11.8 |
| SURE REACH TOGETHER | 49 | 36 | 5 | 0.14 | +53 | +10.5 |
| BACKUP TARGETS | 71 | 39 | 4 | 0.11 | +29 | +7.2 |
| GUN MASK | 22 | 18 | 4 | 0.11 | +51 | +12.8 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +26 | +6.5 |
| RAIDS THE BAGGAGE NEXT TURN | 5 | 5 | 4 | 0.11 | +188 | +46.9 |
| STAY WEIGHED | 4 | 4 | 4 | 0.11 | +140 | +35.0 |
| CARRIES OUT SET-UP | 11 | 11 | 3 | 0.08 | -140 | -46.8 |
| CASTING BLOCK | 8 | 8 | 3 | 0.08 | +105 | +35.0 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.08 | +106 | +35.4 |
| JOINT CHARGE PLAN | 18 | 18 | 3 | 0.08 | +240 | +80.1 |
| OPENS A LANE | 11 | 8 | 3 | 0.08 | +26 | +8.8 |
| SHOOTERS TO THE PRIMARY | 123 | 83 | 3 | 0.08 | +20 | +6.5 |
| DEFENSIVE FLOOR | 2 | 2 | 2 | 0.06 | +216 | +107.9 |
| EDGE GIVE GROUND | 10 | 10 | 2 | 0.06 | +53 | +26.6 |
| LONG SHOT | 28 | 27 | 2 | 0.06 | +7 | +3.7 |
| MISSILES IN THE FIRE PLAN | 38 | 6 | 2 | 0.06 | +2 | +1.2 |
| REDIRECT BY WHAT IT STOPS | 13 | 13 | 2 | 0.06 | +177 | +88.3 |
| STUCK PIVOT | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| WHOLE FIGHT | 6 | 6 | 2 | 0.06 | +269 | +134.6 |
| BLOWS WHERE AIMED | 22 | 21 | 1 | 0.03 | +44 | +44.3 |
| CHARGER SLAIN LOST | 23 | 19 | 1 | 0.03 | +6 | +5.6 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +13 | +12.7 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +31 | +31.0 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +6 | +6.5 |
| HUNT ADVANCE | 15 | 15 | 1 | 0.03 | +3 | +3.3 |
| MOVE SPELL IN RANGE | 17 | 10 | 1 | 0.03 | +52 | +52.3 |
| NEEDED THERE | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +1 | +1.4 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -112 | -112.3 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | -10 | -9.8 |
| STOPS | 5 | 5 | 1 | 0.03 | +2 | +1.9 |
| TWO OR MORE ARRIVE | 65 | 55 | 1 | 0.03 | +14 | +14.1 |
| WAR ENGINE CHARGES | 5 | 5 | 1 | 0.03 | +302 | +302.3 |
| WIDER SPREAD | 200 | 190 | 1 | 0.03 | +1 | +0.6 |
| ALREADY CARRIED | 3 | not checked | - | - | - | - |
| ARRIVAL HUNT | 4 | 4 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 18 | 18 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 3 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 39 | trace | - | - | - | - |
| CATCH FLIERS | 4 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 1 | 1 | 0 | 0.00 | - | - |
| CHEAP HELPER | 3 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 43 | not checked | - | - | - | - |
| ENGINEER BY LORE | 10 | 10 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 408 | not checked | - | - | - | - |
| GIVES UP | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 150 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 6 | not checked | - | - | - | - |
| HELPER UNSEEN | 18 | 18 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 13 | 13 | 0 | 0.00 | - | - |
| HUNT DROPPED | 6 | trace | - | - | - | - |
| HUNT KEPT | 5 | trace | - | - | - | - |
| HUNT RESULT | 16 | trace | - | - | - | - |
| HUNT THE GUNS | 17 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 3 | 2 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 37 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 25 | 25 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 29 | 29 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 26 | trace | - | - | - | - |
| MOVE SPELL SPOT | 9 | not checked | - | - | - | - |
| NOT NEEDED | 11 | 11 | 0 | 0.00 | - | - |
| NOT TURNED | 384 | 384 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 41 | not checked | - | - | - | - |
| PLAN RESULT | 2862 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 3 | 3 | 0 | 0.00 | - | - |
| SCOUT SPOT | 37 | 37 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 14 | 14 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 18 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 15 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SHOT OPTIONS | 1410 | 1410 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 27 | not checked | - | - | - | - |
| SPELL WORTH | 87 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 29 | 27 | 0 | 0.00 | - | - |
| STABLE ROLE | 715 | 711 | 0 | 0.00 | - | - |
| TURN WORTH | 10 | 9 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: gf-h2h-mine-0533c46-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.28 | 14.11 | 49.8 |
| FALLBACK | gate | 0.58 | 0.86 | 37.1 |
| CHARGE NOW FIRST | rule | 0.33 | 0.64 | 78.7 |
| TURN GATE | gate | 0.36 | 0.50 | 23.6 |
| KEEPS THE TARGET | rule | 0.83 | - | 249.0 |
| FIRE PLAN | rule | 0.72 | - | 88.4 |
| LONE CHARACTER SAFE SPOT | gate | 0.14 | 0.22 | 112.7 |
| PATHS CROSS | rule | 0.11 | 0.25 | 15.7 |
| AFTERMATH BAND | gate | 0.14 | 0.11 | 1.3 |
| BEST PRIZE | rule | 0.03 | 0.22 | 78.4 |
| BLOCKED WHEEL | rule | 0.08 | 0.17 | 19.3 |
| PIVOT GUARDS FLANK | rule | 0.06 | 0.17 | 17.1 |
| SUPPORT NARROWED | rule | 0.03 | 0.19 | 9.3 |
| SUPPORT REQUEST | gate | 0.17 | 0.06 | 34.0 |
| CANNON PLANNED TARGET | rule | - | 0.19 | 33.2 |
| PURSUES BIG PREY | rule | 0.06 | 0.11 | 166.1 |
| SURE CHARGE BEATS ADVANCE | rule | 0.06 | 0.11 | 21.8 |
| WAR ENGINE JOBS | rule | 0.11 | 0.06 | 45.6 |
| RULE SWITCHED OFF | gate | - | 0.14 | 6.6 |
| CHARGE NOW WEIGHED | rule | 0.03 | 0.08 | 48.2 |
| DEFENSIVE ARMY | rule | 0.11 | - | 16.1 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | 0.06 | 58.4 |
| CARRIES OUT SET-UP | rule | 0.03 | 0.06 | 46.8 |
| CHAFF PASSED | rule | - | 0.08 | 3.1 |
| NO REASON | gate | 0.08 | - | 44.9 |
| REDIRECT WEIGHED | rule | - | 0.08 | 18.7 |
| REFUSING RETIRES | rule | 0.08 | - | 0.9 |
| THROUGH LINE OF FIRE | rule | - | 0.08 | 2.0 |
| LONE WIZARD HOLDS BACK | rule | - | 0.06 | 29.5 |
| MARCH ODDS | rule | - | 0.03 | 8.5 |
| SAFE SURE CHARGE | rule | 0.03 | - | 112.3 |
| STANDS TO CAST | rule | - | 0.03 | 9.8 |

### Plans: gf-h2h-mine-0533c46-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.2 | 19% | 450 | 416 | 93% |
| Mine | charge | 2.2 | 57% | 124 | 226 | 183% |
| Mine | close in | 3.6 | 25% | 190 | 145 | 76% |
| Mine | hold | 3.2 | 42% | 224 | 0 | 0% |
| Mine | join | 1.1 | 92% | 25 | 0 | 0% |
| Mine | shoot | 16.8 | 60% | 588 | 1304 | 222% |
| Mine | support | 3.6 | 91% | 31 | 0 | 0% |
| Opponent | advance | 10.8 | 14% | 361 | 253 | 70% |
| Opponent | charge | 4.2 | 58% | 352 | 420 | 119% |
| Opponent | close in | 6.6 | 17% | 574 | 88 | 15% |
| Opponent | hold | 4.6 | 45% | 323 | 0 | 0% |
| Opponent | join | 0.7 | 100% | 27 | 0 | 0% |
| Opponent | shoot | 6.5 | 52% | 161 | 283 | 175% |
| Opponent | support | 4.1 | 92% | 45 | 0 | 0% |

### Packages: hunt the guns, gf-h2h-mine-0533c46-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 3 | 0 | 67% | 67% | 0% | 2.0 | 423 | 233 | 67% | 62 |
| Opponent | 0.4 | 14 | 1 | 8% | 23% | 0% | 2.0 | 232 | 56 | 15% | 247 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 44 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 22 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 88 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 162 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 546 |
| High Elf Realms | 0.6 | 3 | 0 | 0% | 0% | 0% | - | 354 | 0 | 0% | 176 |
| Kingdom of Bretonnia | 0.7 | 2 | 1 | 0% | 0% | 0% | - | 124 | 0 | 0% | 126 |
| Ogre Kingdoms | 0.7 | 2 | 0 | 50% | 100% | 0% | 2.0 | 356 | 342 | 100% | 151 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 350 |
| Tomb Kings of Khemri | 1.3 | 9 | 0 | 22% | 33% | 0% | 2.0 | 243 | 83 | 22% | 20 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 30 |
| Warriors of Chaos | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 201 | 0 | 0% | 201 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 687 |

### Battle groups: gf-h2h-mine-0533c46-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 11.8 | 24% | 58% | 14% | 29% | 22% | 12% | 9% | 57% | 0% |
| Mine | REDIRECT COUNTER | 1.6 | 14% | 62% | 12% | 100% | 43% | 0% | 0% | 57% | 0% |
| Opponent | COUNTER-CHARGE COVER | 7.0 | 11% | 55% | 14% | 50% | 36% | 8% | 8% | 48% | 0% |
| Opponent | REDIRECT COUNTER | 2.8 | 22% | 95% | 14% | 0% | 26% | 0% | 32% | 42% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gf-h2h-mine-0533c46-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 2 | 80 (2) | 80 | 0 | 50 | 0% | 4.0 | - | 80 (2) | - | 160 (1) | 0 (1) |
| Mine | Chaff | 34 | 66 (34) | 38 | 28 | 47 | 44% | 2.1 | 77 (20) | 43 (9) | 58 (5) | 84 (27) | 0 (7) |
| Mine | Character | 139 | 18 (139) | 18 | 0 | 36 | 31% | 2.4 | 29 (43) | 16 (68) | 0 (7) | 17 (70) | 22 (48) |
| Mine | Clean-up | 16 | 41 (16) | 17 | 24 | 33 | 56% | 2.6 | 0 (4) | 67 (11) | 0 (1) | 55 (8) | 29 (8) |
| Mine | Fast | 2 | 102 (2) | 102 | 0 | 100 | 0% | 1.0 | - | 102 (2) | - | 102 (2) | - |
| Mine | Fast Hammer | 35 | 44 (35) | 39 | 5 | 30 | 20% | 3.1 | 26 (13) | 55 (16) | 58 (6) | 34 (21) | 57 (14) |
| Mine | Fragile | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Mine | Hammer | 62 | 36 (62) | 21 | 15 | 25 | 16% | 2.4 | 32 (17) | 41 (38) | 25 (7) | 34 (39) | 40 (23) |
| Mine | Holder | 25 | 149 (25) | 45 | 104 | 24 | 12% | 2.2 | 75 (1) | 165 (20) | 88 (4) | 187 (18) | 57 (7) |
| Mine | Shooter | 41 | 51 (41) | 22 | 28 | 53 | 2% | 1.6 | 85 (12) | 44 (24) | 18 (5) | 61 (25) | 37 (16) |
| Mine | War machine | 112 | 70 (112) | 70 | 0 | 38 | 4% | 1.2 | 76 (40) | 65 (62) | 72 (10) | 71 (29) | 69 (83) |
| Mine | Wizard | 18 | 9 (18) | 9 | 0 | 21 | 22% | 2.5 | 13 (6) | 16 (5) | 0 (3) | 0 (6) | 20 (8) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Opponent | Chaff | 59 | 55 (59) | 12 | 43 | 39 | 41% | 2.4 | 53 (29) | 96 (15) | 13 (15) | 70 (44) | 0 (15) |
| Opponent | Character | 108 | 47 (108) | 47 | 0 | 32 | 32% | 2.5 | 64 (36) | 42 (50) | 13 (12) | 40 (60) | 57 (38) |
| Opponent | Clean-up | 23 | 75 (23) | 37 | 37 | 20 | 48% | 3.7 | 20 (7) | 105 (13) | 66 (3) | 54 (12) | 93 (11) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 5.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast | 5 | 19 (5) | 19 | 0 | 100 | 20% | 2.0 | 0 (1) | 23 (4) | - | 19 (5) | - |
| Opponent | Fast Hammer | 49 | 28 (49) | 14 | 15 | 49 | 29% | 2.8 | 11 (18) | 40 (19) | 40 (12) | 23 (36) | 45 (13) |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Hammer | 41 | 44 (41) | 29 | 14 | 38 | 29% | 2.4 | 26 (13) | 55 (25) | 27 (3) | 47 (30) | 35 (11) |
| Opponent | Holder | 38 | 103 (38) | 9 | 94 | 11 | 26% | 2.4 | 5 (6) | 111 (26) | 174 (5) | 120 (26) | 59 (11) |
| Opponent | Shooter | 21 | 67 (21) | 18 | 49 | 24 | 0% | 1.8 | 14 (5) | 91 (14) | 11 (2) | 74 (12) | 59 (9) |
| Opponent | Support | 3 | 22 (3) | 22 | 0 | 40 | 0% | 5.0 | - | 37 (2) | 0 (1) | - | 22 (3) |
| Opponent | War machine | 45 | 39 (45) | 39 | 0 | 50 | 13% | 1.3 | 56 (9) | 21 (29) | 93 (7) | 22 (12) | 44 (33) |
| Opponent | Wizard | 32 | 7 (32) | 7 | 0 | 18 | 19% | 1.8 | 0 (18) | 18 (8) | 0 (2) | 6 (18) | 12 (10) |

### Charged fights: gf-h2h-mine-0533c46-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 35 | 0 | 0.3 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Mine | Chaos Dwarfs | 4 | 144 | 176 | 1.2 | 1.0 | 141 | 44 | +97 | 1 of 5 | 5 of 5 | - | +97 |
| Mine | Dwarfen Mountain Holds | 11 | 464 | 38 | 1.1 | 1.3 | 35 | 32 | +2 | 2 of 12 | 8 of 12 | +0 | +4 |
| Mine | Empire of Man | 11 | 478 | 216 | 1.7 | 1.1 | 125 | 63 | +62 | 6 of 19 | 14 of 19 | +218 | +44 |
| Mine | High Elf Realms | 2 | 284 | 348 | 2.0 | 1.8 | 174 | 0 | +174 | 4 of 4 | 4 of 4 | +232 | +0 |
| Mine | Ogre Kingdoms | 2 | 340 | 260 | 4.0 | 1.4 | 65 | 20 | +45 | 2 of 8 | 6 of 8 | +31 | +54 |
| Mine | Tomb Kings of Khemri | 3 | 211 | 643 | 4.3 | 1.1 | 148 | 54 | +94 | 6 of 13 | 9 of 13 | +393 | +69 |
| **Mine** | all armies | 36 | 359 | 185 | 1.7 | 1.2 | 107 | 43 | +64 | 21 of 62 | 47 of 62 | +124 | +48 |
| Opponent | Chaos Dwarfs | 1 | 132 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Dwarfen Mountain Holds | 1 | 95 | 0 | 1.0 | 2.0 | 0 | 105 | -105 | 0 of 1 | 0 of 1 | -105 | - |
| Opponent | Empire of Man | 6 | 218 | 171 | 1.3 | 1.1 | 128 | 44 | +84 | 6 of 8 | 4 of 8 | -102 | +110 |
| Opponent | Grand Cathay | 4 | 296 | 166 | 2.0 | 1.1 | 83 | 0 | +83 | 3 of 8 | 8 of 8 | +138 | +75 |
| Opponent | High Elf Realms | 3 | 157 | 596 | 5.3 | 1.2 | 112 | 11 | +101 | 10 of 16 | 11 of 16 | +202 | +77 |
| Opponent | Kingdom of Bretonnia | 3 | 117 | 489 | 3.3 | 1.1 | 147 | 0 | +147 | 2 of 10 | 9 of 10 | +238 | +137 |
| Opponent | Ogre Kingdoms | 1 | 0 | 0 | 8.0 | 1.1 | 0 | 11 | -11 | 1 of 8 | 4 of 8 | +0 | -13 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 673 | 4.0 | 1.0 | 168 | 14 | +154 | 3 of 4 | 3 of 4 | - | +154 |
| Opponent | Tomb Kings of Khemri | 4 | 71 | 462 | 4.0 | 1.2 | 115 | 34 | +82 | 6 of 16 | 14 of 16 | +110 | +75 |
| Opponent | Vampire Counts | 4 | 0 | 370 | 3.2 | 1.1 | 114 | 19 | +95 | 5 of 13 | 10 of 13 | +55 | +98 |
| Opponent | Warriors of Chaos | 6 | 0 | 317 | 2.2 | 1.2 | 146 | 9 | +137 | 4 of 13 | 11 of 13 | +388 | +92 |
| Opponent | Wood Elf Realms | 2 | 237 | 448 | 3.5 | 1.0 | 128 | 0 | +128 | 3 of 7 | 5 of 7 | - | +128 |
| **Opponent** | all armies | 36 | 119 | 326 | 2.9 | 1.1 | 113 | 16 | +97 | 43 of 104 | 79 of 104 | +138 | +90 |

### Effective charges: gf-h2h-mine-0533c46-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0% (0 of 1) |
| Mine | Chaos Dwarfs | 5 | 0 | 0 | 0 | 0 | 2 (net -44) | 3 (net +192) | 0 | 0% (0 of 5) |
| Mine | Dwarfen Mountain Holds | 12 | 2 (net +32) | 0 | 3 (net +0) | 2 (net +0) | 0 | 3 (net +50) | 2 | 30% (3 of 10) |
| Mine | Empire of Man | 19 | 2 (net +8) | 0 | 4 (net -74) | 4 (net +100) | 0 | 8 (net +119) | 1 | 22% (4 of 18) |
| Mine | High Elf Realms | 4 | 0 | 0 | 0 | 1 (net +0) | 0 | 3 (net +232) | 0 | 0% (0 of 4) |
| Mine | Ogre Kingdoms | 8 | 1 (net +161) | 0 | 2 (net +0) | 2 (net +46) | 0 | 1 (net +55) | 2 | 33% (2 of 6) |
| Mine | Tomb Kings of Khemri | 13 | 3 (net -31) | 0 | 2 (net +0) | 5 (net +206) | 0 | 2 (net +142) | 1 | 17% (2 of 12) |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 1 (net -105) | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Empire of Man | 8 | 1 (net +138) | 0 | 2 (net +0) | 4 (net -72) | 0 | 1 (net +822) | 0 | 25% (2 of 8) |
| Opponent | Grand Cathay | 8 | 1 (net +138) | 0 | 0 | 3 (net +149) | 0 | 4 (net +19) | 0 | 0% (0 of 8) |
| Opponent | High Elf Realms | 16 | 0 | 0 | 5 (net +11) | 7 (net +136) | 3 (net +140) | 1 (net +186) | 0 | 31% (5 of 16) |
| Opponent | Kingdom of Bretonnia | 10 | 1 (net +91) | 0 | 2 (net +234) | 3 (net +141) | 0 | 3 (net +119) | 1 | 22% (2 of 9) |
| Opponent | Ogre Kingdoms | 8 | 2 (net +0) | 0 | 0 | 1 (net +0) | 0 | 2 (net +0) | 3 | 0% (0 of 5) |
| Opponent | Orc & Goblin Tribes | 4 | 1 (net +313) | 0 | 0 | 0 | 0 | 0 | 3 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 16 | 2 (net +422) | 0 | 1 (net +0) | 7 (net -3) | 0 | 1 (net +0) | 5 | 9% (1 of 11) |
| Opponent | Vampire Counts | 13 | 3 (net +0) | 1 (net +0) | 3 (net +237) | 3 (net +61) | 2 (net +88) | 0 | 1 | 25% (3 of 12) |
| Opponent | Warriors of Chaos | 13 | 1 (net +365) | 0 | 1 (net +0) | 2 (net +128) | 2 (net -20) | 5 (net +208) | 2 | 9% (1 of 11) |
| Opponent | Wood Elf Realms | 7 | 0 | 0 | 2 (net +68) | 2 (net +18) | 0 | 1 (net +726) | 2 | 40% (2 of 5) |

### Charged fights, damage counted: gf-h2h-mine-0533c46-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 8 | 195 | 311 | +18 | 168 | 139 | +29 | +14.7 |
| Mine | Effective (55-75%) | 11 | 168 | 195 | -27 | 29 | 42 | -12 | -7.2 |
| Mine | 76-89% | 14 | 227 | 176 | +109 | 120 | 35 | +86 | +37.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 20 | 239 | 174 | +136 | 183 | 44 | +139 | +58.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 488 | 75 | -30 | 59 | 94 | -35 | -7.2 |
| Mine | No odds | 6 | 130 | 308 | -4 | 145 | 139 | +7 | +5.2 |
| Mine | All fights | 62 | 219 | 204 | +64 | 130 | 65 | +65 | +29.5 |
| Opponent | Long shot (under 50%) | 12 | 227 | 202 | +157 | 163 | 45 | +117 | +51.8 |
| Opponent | 50-54% | 2 | 163 | 263 | -52 | 72 | 101 | -29 | -17.8 |
| Opponent | Effective (55-75%) | 16 | 297 | 214 | +86 | 116 | 26 | +90 | +30.3 |
| Opponent | 76-89% | 32 | 293 | 171 | +62 | 100 | 57 | +43 | +14.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 18 | 361 | 219 | +178 | 204 | 24 | +180 | +49.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 494 | 96 | +80 | 105 | 24 | +81 | +16.3 |
| Opponent | No odds | 17 | 204 | 181 | +68 | 119 | 43 | +77 | +37.6 |
| Opponent | All fights | 104 | 294 | 188 | +97 | 131 | 41 | +89 | +30.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gf-h2h-mine-0533c46-p1 | move | 408 | 74 (18%) | 37 (9%) | 34 (8%) | 300 (74%) |
| gf-h2h-mine-0533c46-p1 | objective | 368 | 51 (14%) | 30 (8%) | 42 (11%) | 275 (75%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0103, L0108, L0109 |
| Charmed Shield | Opponent | L0627, L0725, L0827, L2224 |
| Clockwork Compass | Opponent | L0712 |
| Elixir of Power | Opponent | L0511, L0619 |
| Fistful of Laurels | Mine | L1822, L1831 |
| Fistful of Laurels | Opponent | L1318 |
| Horn of the Wild Hunt | Opponent | L0833 |
| Invocation of Nehek | Opponent | L0627, L0725, L0827, L2224 |
| Opal Amulet | Opponent | L0614 |
| Ring of Doom | Mine | L1516 |
| Ring of Doom | Opponent | L0315, L0511, L0615, L0712, L0731, L0833, L1831 |
| Ring of Jet | Opponent | L0510, L0511, L0712, L0810 |
| Standard of the Fell Warrior | Mine | L1318 |
| Twice-Blessed Armour | Mine | L0708, L0712, L0716, L0725, L0730, L0731 |
| Twice-Blessed Armour | Opponent | L0507, L0510, L0810 |
| Witch Hunter's Ward | Mine | L0708, L0712, L0716, L0725, L0730, L0731, L0810, L0827, L0832, L0833, L0835 |
| Witch Hunter's Ward | Opponent | L0108, L0507, L0508, L0708 |

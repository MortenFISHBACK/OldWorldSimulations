# Doctrine scorecard: gf-h2h-mine-0533c46-p3

### Scorecard: gf-h2h-mine-0533c46-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0203 | 5 | 1 | Mine | yes | - | - | 0 | 7 | 1 | 0 | 0 | 170 |
| L0203 | 5 | 1 | Opponent | no | - | 6 | 1 | 2 | 0 | 0 | 0 | 675 |
| L0215 | 5 | 1 | Mine | yes | - | 2 | 5 | 1 | 0 | 0 | 0 | 170 |
| L0215 | 5 | 1 | Opponent | yes | - | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 2 | 4 | 4 | 1 | 0 | 0 | 170 |
| L0218 | 2 | 1 | Opponent | - | - | 4 | 1 | 2 | 1 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | yes | 1 | - | 0 | 1 | 0 | 0 | 0 | 675 |
| L0307 | 1 | 1 | Opponent | yes | 1 | 2 | 0 | 2 | 0 | 0 | 0 | 420 |
| L0308 | 2 | 1 | Mine | - | - | 2 | 3 | 3 | 0 | 0 | 0 | 675 |
| L0308 | 2 | 1 | Opponent | - | - | 5 | 1 | 2 | 1 | 0 | 0 | 560 |
| L0313 | 1 | 1 | Mine | yes | 1 | - | 0 | 0 | 0 | 0 | 0 | 675 |
| L0313 | 1 | 1 | Opponent | no | 0 | 3 | 1 | 2 | 1 | 0 | 0 | 140 |
| L0332 | 2 | 1 | Mine | - | - | 4 | 1 | 0 | 1 | 0 | 0 | 590 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 6 | 3 | 1 | 0 | 0 | 170 |
| L0409 | 1 | 1 | Mine | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 7 | 5 | 1 | 1 | 0 | 0 | 0 | 537 |
| L0528 | 6 | 1 | Mine | no | 0 | 5 | 2 | 0 | 0 | 0 | 0 | 475 |
| L0528 | 6 | 1 | Opponent | no | 7 | - | 0 | 1 | 0 | 0 | 0 | 111 |
| L0608 | 2 | 1 | Mine | - | - | - | 1 | 3 | 1 | 0 | 0 | 798 |
| L0608 | 2 | 1 | Opponent | - | - | - | 0 | 2 | 0 | 0 | 0 | 605 |
| L0613 | 1 | 1 | Mine | no | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 615 |
| L0613 | 1 | 1 | Opponent | no | 0 | 2 | 0 | 0 | 0 | 0 | 0 | 140 |
| L0617 | 5 | 1 | Mine | yes | - | 6 | 3 | 2 | 0 | 0 | 0 | 801 |
| L0617 | 5 | 1 | Opponent | yes | - | 3 | 3 | 0 | 2 | 0 | 0 | 141 |
| L0621 | 3 | 1 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 798 |
| L0621 | 3 | 1 | Opponent | yes | 13 | - | 2 | 2 | 0 | 0 | 0 | 290 |
| L0711 | 3 | 1 | Mine | no | 8 | 4 | 1 | 1 | 0 | 0 | 0 | 375 |
| L0711 | 3 | 1 | Opponent | no | 0 | 3 | 3 | 0 | 1 | 0 | 0 | 330 |
| L0722 | 2 | 1 | Mine | - | - | 2 | 1 | 2 | 0 | 0 | 0 | 375 |
| L0722 | 2 | 1 | Opponent | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 55 |
| L0815 | 5 | 1 | Mine | no | - | - | 1 | 0 | 0 | 0 | 0 | 515 |
| L0815 | 5 | 1 | Opponent | yes | - | 2 | 4 | 2 | 0 | 0 | 0 | 115 |
| L0819 | 3 | 1 | Mine | no | 12 | 4 | 1 | 0 | 0 | 0 | 0 | 724 |
| L0819 | 3 | 1 | Opponent | no | 8 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L0822 | 6 | 1 | Mine | no | 4 | 6 | 1 | 2 | 1 | 0 | 0 | 560 |
| L0822 | 6 | 1 | Opponent | no | 2 | 2 | 2 | 2 | 2 | 0 | 0 | 0 |
| L0826 | 4 | 1 | Mine | no | 1 | - | 1 | 0 | 0 | 0 | 0 | 515 |
| L0826 | 4 | 1 | Opponent | no | 2 | 2 | 5 | 2 | 1 | 0 | 0 | 0 |
| L0829 | 1 | 1 | Mine | no | 0 | 3 | 0 | 0 | 0 | 0 | 0 | 560 |
| L0829 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 3 | 0 | 0 | 0 | 170 |
| L0834 | 6 | 1 | Mine | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 515 |
| L0834 | 6 | 1 | Opponent | no | 0 | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0920 | 2 | 1 | Mine | - | - | 4 | 1 | 2 | 0 | 0 | 0 | 420 |
| L0920 | 2 | 1 | Opponent | - | - | - | 0 | 5 | 0 | 0 | 0 | 420 |
| L0921 | 3 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 726 |
| L0921 | 3 | 1 | Opponent | yes | 10 | 2 | 2 | 3 | 1 | 0 | 0 | 290 |
| L0922 | 4 | 1 | Mine | no | 0 | 5 | 1 | 1 | 0 | 0 | 0 | 632 |
| L0922 | 4 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 1 | 0 | 0 | 55 |
| L0931 | 1 | 1 | Mine | no | 0 | 4 | 1 | 0 | 1 | 0 | 0 | 620 |
| L0931 | 1 | 1 | Opponent | no | 2 | 3 | 1 | 1 | 1 | 0 | 0 | 170 |
| L1022 | 2 | 1 | Mine | - | - | 1 | 5 | 0 | 0 | 0 | 0 | 330 |
| L1022 | 2 | 1 | Opponent | - | - | 2 | 1 | 0 | 1 | 0 | 0 | 0 |
| L1115 | 5 | 1 | Mine | yes | - | 3 | 1 | 0 | 1 | 0 | 0 | 688 |
| L1115 | 5 | 1 | Opponent | yes | - | 2 | 1 | 3 | 0 | 0 | 0 | 60 |
| L1415 | 5 | 1 | Mine | yes | - | 3 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1415 | 5 | 1 | Opponent | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 375 |
| L1422 | 6 | 1 | Mine | no | 9 | 3 | 3 | 1 | 0 | 0 | 0 | 177 |
| L1422 | 6 | 1 | Opponent | no | 0 | 2 | 5 | 0 | 1 | 0 | 0 | 242 |
| L1518 | 6 | 1 | Mine | no | 3 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1518 | 6 | 1 | Opponent | no | 3 | - | 1 | 1 | 1 | 0 | 0 | 482 |
| L1524 | 6 | 1 | Mine | no | 1 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1524 | 6 | 1 | Opponent | no | 6 | 2 | 5 | 0 | 2 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Mine | yes | 3 | 3 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | yes | - | 4 | 4 | 2 | 0 | 0 | 0 | 419 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 3 | 1 | 2 | 0 | 0 | 0 |
| L1829 | 5 | 1 | Mine | no | - | - | 2 | 1 | 0 | 0 | 0 | 0 |
| L1829 | 5 | 1 | Opponent | yes | - | 3 | 3 | 2 | 0 | 0 | 0 | 170 |
| L1834 | 4 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 234 |
| L1834 | 4 | 1 | Opponent | no | 3 | 2 | 5 | 1 | 0 | 0 | 0 | 660 |
| L2227 | 1 | 1 | Mine | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | yes | 0 | 1 | 5 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 31% | 2.1 | 3.2 | 1.8 | 1.2 | 0.2 | 0.0 | 0.0 | 416.6 |
| **Average** | | | Opponent | 38% | 3.0 | 2.5 | 2.3 | 1.6 | 0.6 | 0.0 | 0.0 | 205.1 |

### KPIs: gf-h2h-mine-0533c46-p3

Rules off - Opponent only: GUN FIGURES, GUN MASK, GUN VIEW, GUN THREAT, STAY WORTH, BEST MOVE FOR SHOOTERS, FACE THE CAST, WIZARD FRONT RANK, FIRE PLAN, FIRE IN ORDER, KEEPS THE TARGET, MISSILES IN THE FIRE PLAN, THREAT AT FULL SIZE, SHOOTERS ARE THREATS, SHOOTERS TO THE PRIMARY, EVERY WOUND COUNTS, HONEST THREAT, ONE YARDSTICK.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 53% (94 of 176) | 9% (17 of 185) | 31% (111 of 361) |
| Winner chose to follow up after the loser gave ground |  | 97% (57 of 59); on the table 97% | 98% (62 of 63); on the table 98% | 98% (119 of 122); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 80% (8 of 10); on the table 80% | 89% (8 of 9); on the table 89% | 84% (16 of 19); on the table 84% |
| Winner chose to pursue after the loser fled |  | 77% (10 of 13); on the table 85% | 76% (22 of 29); on the table 83% | 76% (32 of 42); on the table 83% |
| Winner chose to follow up or pursue (all three) |  | 91% (75 of 82); on the table 93% | 91% (92 of 101); on the table 93% | 91% (167 of 183); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 29% (60 of 209) | 29% (50 of 175) | 29% (110 of 384) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 40% (60 of 150) | 39% (50 of 129) | 39% (110 of 279) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 15% (11 of 71) | 26% (25 of 96) | 22% (36 of 167) |
|     round 1 |  | 0% (0 of 12) | 12% (2 of 16) | 7% (2 of 28) |
|     rounds 2+ |  | 19% (11 of 59) | 29% (23 of 80) | 24% (34 of 139) |
|   other wizards | 50%+ | 36% (49 of 138) | 31% (24 of 78) | 34% (73 of 216) |
|     round 1 |  | 13% (3 of 23) | 31% (4 of 13) | 19% (7 of 36) |
|     rounds 2+ |  | 40% (46 of 115) | 31% (20 of 65) | 37% (66 of 180) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 44% (4 of 9) | 65% (39 of 60) | 62% (43 of 69) |
| Points that never fought | lower | 50% (35262 of 70695) | 46% (33302 of 71984) | 48% (68564 of 142679) |
|   infantry points that never fought | lower | 58% (9174 of 15862) | 71% (9848 of 13803) | 64% (19022 of 29665) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 63% (198 of 314) | 57% (151 of 267) | 60% (349 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 84% (16 of 19); 1.4 uses a game | 94% (16 of 17); 1.3 uses a game | 89% (32 of 36); 1.4 uses a game |
| Bound items with another spell used |  | 27% (4 of 15); 0.2 uses a game | 40% (2 of 5); 0.1 uses a game | 30% (6 of 20); 0.1 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 45% (9 of 20); 0.2 uses a game | 36% (4 of 11); 0.1 uses a game | 42% (13 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 60% (36287 of 60076) | 50% (31115 of 62051) | 55% (67402 of 122127) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.9 (47%) | 1.2 (34%) | 3.1 (41%) |
| MARCHED: its unit marched | 0.4 (9%) | 0.5 (14%) | 0.9 (12%) |
| CHARGED: its unit charged | 0.0 (1%) | 0.1 (2%) | 0.1 (1%) |
| IN COMBAT: engaged in combat | 0.6 (14%) | 0.5 (14%) | 1.1 (14%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.4 (11%) | 0.4 (5%) |
| FLEEING: fleeing | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |
| GONE: slain | 0.9 (21%) | 0.7 (19%) | 1.6 (20%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (3%) | 0.1 (3%) | 0.2 (3%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.1 (2%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.6 | 1.1 | 1.9 | 3.1 | 0.2 | 1.3 |
| not cast | 2.9 | 2.1 | 2.6 | 7.6 | 0.8 | 16.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.5 (9%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 0.6 (26%) | 0.1 (3%) | 3.1 (41%) | 0.2 (26%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.9 (12%) | 0.1 (11%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (5%) | 0.1 (5%) | 0.2 (10%) | 1.1 (14%) | 0.1 (19%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (7%) | 0.4 (17%) | 0.5 (18%) | 0.4 (5%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 0.8 (27%) | 0.4 (17%) | 0.5 (18%) | 1.6 (20%) | 0.2 (26%) | 2.8 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (7%) | 0.1 (7%) | 0.2 (9%) | 0.2 (3%) | 0.0 (0%) | 0.9 (5%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.1 (3%) | 0.1 (4%) | 0.2 (2%) | 0.0 (0%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.5 (22%) | 0.0 (0%) | 0.0 (0%) | 0.1 (15%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.5 (52%) | 0.0 (1%) | 1.0 (38%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 11.1 (66%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.4 a game | 0.5 a game | 0.9 a game |
| stood (cast and not dispelled) | 67% (22 of 33) | 100% (3 of 3) | 69% (25 of 36) |
| the unit moved after it | 50% (11 of 22) | 100% (3 of 3) | 56% (14 of 25) |
| it charged on its next turn | 5% (1 of 22) | 0% (0 of 3) | 4% (1 of 25) |
| the enemy charged it first | 18% (4 of 22) | 0% (0 of 3) | 16% (4 of 25) |
| it fought by the end of its next turn | 14% (3 of 22) | 0% (0 of 3) | 12% (3 of 25) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 22) | 33% (1 of 3) | 4% (1 of 25) |
| none of these (no charge, no fight, no charge escaped) | 77% (17 of 22) | 67% (2 of 3) | 76% (19 of 25) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 68% (825 of 1216) | 60% (507 of 850) | 64% (1332 of 2066) |
|   cavalry | 60% (65 of 109) | 72% (78 of 108) | 66% (143 of 217) |
|   character | 59% (63 of 107) | 22% (32 of 145) | 38% (95 of 252) |
|   chariot | 61% (93 of 153) | 60% (56 of 93) | 61% (149 of 246) |
|   infantry | 57% (190 of 333) | 66% (234 of 357) | 61% (424 of 690) |
|   monster | 53% (27 of 51) | 48% (16 of 33) | 51% (43 of 84) |
|   war machine | 84% (387 of 463) | 80% (91 of 114) | 83% (478 of 577) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.4 (22%) | 2.2 (23%) | 4.6 (22%) |
| CHARGED: it charged | 1.1 (10%) | 1.8 (19%) | 2.9 (14%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 1.2 (11%) | 0.8 (8%) | 2.0 (10%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 2.2 (20%) | 2.0 (21%) | 4.2 (20%) |
| ONLY IN COMBAT: the only targets were in combat | 0.8 (8%) | 0.7 (8%) | 1.6 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.8 (17%) | 1.7 (17%) | 3.5 (17%) |
| SHELTERED: the target was sheltered | 0.4 (4%) | 0.2 (2%) | 0.6 (3%) |
| OTHER BAR | 0.6 (5%) | 0.2 (2%) | 0.8 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.6 | 2.5 | 77% | 6.3 pts | 48 pts |
| character | 3.1 | 1.1 | 75% | 6.7 pts | 20 pts |
| chariot | 4.2 | 3.1 | 60% | 19.5 pts | 82 pts |
| infantry | 16.3 | 4.9 | 77% | 6.4 pts | 105 pts |
| monster | 1.6 | 0.5 | 77% | 9.3 pts | 15 pts |
| war machine | 13.3 | 11.6 | 59% | 26.8 pts | 356 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.1 | 5.2 | 4.1 |
| Charges that made contact a game | 2.4 | 3.7 | 3.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.64 declared, 0.57 contact (14 units) | 0.67 declared, 0.52 contact (21 units) | 0.66 declared, 0.54 contact (35 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.50 declared, 0.50 contact (6 units) | 1.50 declared, 1.38 contact (8 units) | 1.07 declared, 1.00 contact (14 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.38 declared, 0.29 contact (260 units) | 0.56 declared, 0.39 contact (285 units) | 0.47 declared, 0.34 contact (545 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 53% (31 of 58) | 28% (5 of 18) | 69% (9 of 13) | 51% (45 of 89) |
| Character in a unit | 92% (35 of 38) | 70% (7 of 10) | 100% (1 of 1) | 88% (43 of 49) |
| Character on its own | 86% (30 of 35) | 55% (11 of 20) | 33% (20 of 61) | 53% (61 of 116) |
| Chariot | 71% (17 of 24) | 56% (14 of 25) | - | 63% (31 of 49) |
| Infantry | 49% (40 of 81) | 48% (13 of 27) | 56% (5 of 9) | 50% (58 of 117) |
| Monster | 71% (22 of 31) | 78% (7 of 9) | - | 72% (29 of 40) |
| Monstrous | 100% (5 of 5) | 50% (9 of 18) | - | 61% (14 of 23) |
| War Machines | 69% (64 of 93) | 80% (4 of 5) | - | 69% (68 of 98) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 3 | 88% (7 of 8); on the table 88% | 40% (17 of 42) | 75% | 89% (16 of 18) | 100% (6 of 6); 6.0 uses a game | 0.0 uses a game | 50% (3 of 6); 1.0 uses a game |
| Chaos Dwarfs | 6 | 95% (18 of 19); on the table 95% | 26% (14 of 54) | 65% | 62% (30 of 48) | 0.0 uses a game | 0.0 uses a game | 60% (3 of 5); 0.5 uses a game |
| Dwarfen Mountain Holds | 5 | 83% (5 of 6); on the table 100% | - | 86% | 68% (32 of 47) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 16 | 92% (23 of 25); on the table 92% | 32% (25 of 78) | 52% | 63% (107 of 170) | 0.0 uses a game | 33% (1 of 3); 0.1 uses a game | 45% (5 of 11); 0.3 uses a game |
| Grand Cathay | 3 | 100% (5 of 5); on the table 100% | 32% (21 of 66) | 37% | 62% (16 of 26) | 100% (6 of 6); 6.0 uses a game | 100% (1 of 1); 0.3 uses a game | 0% (0 of 3); 0.0 uses a game |
| High Elf Realms | 11 | 92% (22 of 24); on the table 92% | 21% (9 of 42) | 35% | 53% (43 of 81) | 88% (14 of 16); 4.5 uses a game | 25% (4 of 16); 0.5 uses a game | 0.0 uses a game |
| Lizardmen | 1 | - | - | 49% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 5 | 96% (22 of 23); on the table 100% | 8% (1 of 12) | 29% | 66% (23 of 35) | 60% (3 of 5); 1.2 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (1 of 1); on the table 100% | 25% (3 of 12) | 8% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 3 | 86% (6 of 7); on the table 86% | 28% (5 of 18) | 67% | 60% (15 of 25) | 100% (2 of 2); 1.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Tomb Kings of Khemri | 7 | 94% (16 of 17); on the table 94% | 8% (1 of 12) | 36% | 51% (18 of 35) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 4 | 88% (21 of 24); on the table 88% | 33% (12 of 36) | 24% | 50% (12 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 5 | 94% (15 of 16); on the table 100% | 17% (2 of 12) | 48% | 46% (19 of 41) | 100% (1 of 1); 0.6 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 2 | 75% (6 of 8); on the table 75% | - | 46% | 50% (8 of 16) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gf-h2h-mine-0533c46-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 44% (31) | 48% (25) | 46% (56) |
| ...free all their last turn and able to turn (per game) | 0.47 | 0.33 | 0.81 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.19 | 0.36 |
| ...with the charger already in that arc before they moved (per game) | 0.28 | 0.25 | 0.53 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.72 | 1.06 | 2.78 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.86 | 0.81 | 1.67 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.58 | 5.50 | 11.08 |

### Quality by phase: gf-h2h-mine-0533c46-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.7 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 63% (57 of 91) | 53% (83 of 157) |
| Strategy | Shoot objectives carried out (shot that target) | 34% (207 of 609) | 54% (150 of 279) |
| Strategy | Close-in objectives charged next turn | 13% (16 of 121) | 19% (37 of 193) |
| Strategy | Support requests answered (helper made contact too) | 60% (6 of 10) | 44% (11 of 25) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 55% (6 of 11) | 100% (2 of 2) |
| Strategy | Joined characters whose unit fought | 12% (7 of 57) | 21% (6 of 28) |
| Strategy | Lone characters that fought | 55% (43 of 78) | 69% (64 of 93) |
| Movement | Charges halted short of contact | 0.0 | 0.1 |
| Movement | Idle units | 1.2 | 1.6 |
| Movement | Points that never moved of their own | 416.6 | 205.1 |
| Movement | Fights charged into per game | 2.2 | 3.1 |
| Movement | Charges with odds: long shots (under 50%) | 10 of 68, net +32 | 13 of 99, net +51 |
| Movement | Charges with odds: sweet spot (55-75%) | 16 of 68, net +55 | 15 of 99, net +125 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 9 of 68, net +79 | 6 of 99, net -15 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 19 of 68, net +131 | 38 of 99, net +174 |
| Shooting | Shots by shooting units (incl. breath weapons) | 13.0 | 13.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (212 of 468) | 29% (138 of 468) |
| Shooting | Points destroyed by shooting units | 143.6 | 38.6 |
| Shooting | War machine shots | 10.8 | 2.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 55% (214 of 387) | 44% (40 of 91) |
| Shooting | Points destroyed by war machines | 172.6 | 50.8 |
| Magic | Magic missiles cast | 1.0 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 46% (16 of 35) | 22% (7 of 32) |
| Magic | Wounds caused by magic missiles | 2.1 | 1.4 |
| Magic | Wounds caused by other spells | 0.8 | 0.4 |
| Magic | Points destroyed by magic (all spells) | 35.7 | 18.5 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 0.4 / 0.4 / 0.1 | 1.7 / 0.1 / 0.3 / 0.1 |
| Combat | Points destroyed in combat | 229.9 | 385.0 |
| Combat | Points run down | 39.6 | 121.9 |
| Combat | Net points per charged fight, damage counted | +84 | +125 |
| Combat | Net per 100 charger points, damage counted | +39.3 | +37.8 |
| Combat | First round won (charged fights) | 77% | 81% |
| Combat | Net points per charged fight | +81 | +125 |
| Combat | Net points per supported fight / lone fight | +66 / +83 | +128 / +124 |
| Combat | Charged fights on a top-3 enemy unit | 24 of 78 | 52 of 110 |
| Game | Points lost | 766.9 | 711.7 |
| Game | VP from objectives | 486.1 | 743.1 |
| Game | Lone holders (player turns) | 2.1 | 3.0 |

- Mine won / drew / lost: 9 / 9 / 18 of 36 ended games (of 36); mean margin (Mine - Opponent) -344 VP
- The side that went first won 9 of 27 games with a winner
- Points traded per game (both sides' losses): 1479
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gf-h2h-mine-0533c46-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.5 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.6 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 3.1 | +0.0 | 0.0 | 48.2 | 0.7 | +0.0 | 0.0 | 8.5 |
| BACKUP TARGETS | 0.9 | +6.6 | 0.0 | 22.9 | 1.1 | +7.4 | 0.0 | 11.5 |
| BEST FACING | 0.8 | +19.4 | 0.0 | 46.9 | 0.4 | +13.9 | 0.0 | 22.5 |
| BEST FIRST | 4.0 | +214.3 | 148.0 | 54.7 | 5.1 | +167.8 | 108.1 | 62.9 |
| BEST MOVE FOR SHOOTERS | 1.3 | +125.4 | 0.0 | 24.7 | - | - | - | - |
| BEST OVERALL | 0.6 | +47.1 | 0.0 | 18.9 | 0.6 | +40.2 | 0.0 | 10.2 |
| BEST PREY | 0.5 | +24.4 | 22.6 | 6.3 | 1.1 | +36.7 | 21.1 | 13.5 |
| BEST PRIZE | 0.1 | -2.7 | 4.2 | 0.0 | 0.2 | +3.8 | 4.4 | 8.6 |
| BIG CHARACTER SAFETY | 0.0 | -0.4 | 0.0 | 0.0 | 0.2 | -1.3 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 1.1 | 0.0 | 0.1 | +0.0 | 2.6 | 0.0 |
| BLOCKED WHEEL | 0.3 | +1.7 | 0.0 | 0.0 | 0.5 | +9.9 | 0.0 | 2.6 |
| BLOWS WHERE AIMED | 0.1 | -4.5 | 5.4 | 6.6 | 0.4 | -14.4 | 92.8 | 19.3 |
| BOMBING RUN | 0.1 | +2.4 | 11.0 | 0.0 | 0.0 | +0.7 | 0.0 | 0.0 |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 3.5 | - | - | - | - |
| CANNON PLAN MISSED | - | - | - | - | 0.3 | +0.0 | 52.0 | 8.1 |
| CANNON PLANNED TARGET | - | - | - | - | 2.0 | +52.3 | 182.3 | 19.3 |
| CANNON SIGHT KEPT | 1.5 | +0.0 | 0.0 | 13.4 | 0.4 | +0.0 | 0.0 | 6.9 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 5.2 | 0.0 | 0.0 | -1.9 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 19.4 | 0.0 | 0.0 | +0.0 | 8.0 | 0.0 |
| CAST JOB | 0.6 | +14.8 | 44.1 | 2.4 | 0.7 | +14.1 | 43.5 | 35.8 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +35.2 | 18.5 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 13.6 | 0.2 | +0.0 | 0.0 | 22.2 |
| CASTS FROM BEHIND | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +6.6 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 0.2 | -1.0 | 6.2 | 3.8 |
| CHARGE BAND | 0.2 | +0.0 | 9.8 | 0.0 | 0.1 | +0.0 | 14.9 | 0.0 |
| CHARGE NOW FIRST | 1.6 | +0.0 | 126.7 | 15.7 | 2.6 | +0.0 | 258.0 | 45.9 |
| CHARGE NOW WEIGHED | 0.4 | -26.9 | 2.0 | 2.9 | 0.6 | -74.2 | 0.9 | 57.8 |
| CHARGER SLAIN LOST | 0.6 | -11.9 | 73.7 | 23.0 | 0.6 | -11.2 | 30.7 | 24.7 |
| CHARIOT NO STATIC JOB | - | - | - | - | 0.0 | +0.0 | 0.8 | 0.0 |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.0 | 0.0 | 0.0 | 0.1 | -0.3 | 0.0 | 11.0 |
| CHEAP HELPER | 0.1 | +0.0 | 4.2 | 2.6 | - | - | - | - |
| COMBAT PIVOT | 0.6 | +0.0 | 16.5 | 55.2 | 0.4 | +0.0 | 30.1 | 21.7 |
| CONVEYANCE SEARCH | 0.9 | +81.3 | 3.2 | 24.9 | 0.0 | +5.6 | 11.1 | 11.1 |
| COUNTER-CHARGE COVER | 9.5 | +1015.6 | 0.0 | 211.7 | 8.4 | +725.6 | 0.0 | 172.6 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 22.7 | 3.6 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +5.1 | 10.0 | 0.0 | 0.2 | +4.4 | 15.9 | 3.2 |
| ENGINEER BY LORE | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| EVERY WOUND COUNTS | 16.2 | +0.0 | 1340.7 | 337.5 | - | - | - | - |
| FACE THE CAST | 0.1 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.7 | +116.9 | 0.0 | 66.9 | 1.1 | +55.4 | 0.0 | 33.4 |
| FALLBACK BY WORTH | 4.8 | +87.1 | 0.0 | 97.7 | 5.9 | +59.9 | 0.0 | 38.1 |
| FIGHT LIFT | 0.0 | +0.2 | 1.7 | 0.0 | 0.1 | +0.8 | 0.0 | 0.0 |
| FIRE AND FLEE | - | - | - | - | 0.0 | +0.5 | 0.0 | 0.0 |
| FIRE IN ORDER | 1.3 | +0.0 | 102.9 | 15.4 | - | - | - | - |
| FIRE PLAN | 26.6 | +170.7 | 1913.0 | 510.2 | - | - | - | - |
| FLANK NOT WEIGHED | 5.2 | +0.0 | 0.0 | 137.0 | 5.6 | +0.0 | 0.0 | 161.2 |
| FOCUS FIRE | - | - | - | - | 0.0 | +0.2 | 1.2 | 0.0 |
| FOLLOW UP WEIGHED | 0.9 | +177.5 | 0.0 | 26.3 | 1.2 | +175.2 | 0.0 | 28.1 |
| FRIENDS SHOTS CHECKED | 0.4 | +31.6 | 0.0 | 13.4 | 0.2 | +15.6 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -1.2 | 10.0 | 0.0 | 0.0 | -0.5 | 4.9 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -0.1 | 3.5 | 0.0 |
| GROUND FLIERS | 0.0 | +1.7 | 0.0 | 0.0 | 0.1 | +2.5 | 0.0 | 0.0 |
| GUN FIGURES | 4.2 | +106.5 | 257.1 | 75.6 | - | - | - | - |
| GUN MASK | 0.6 | +19.7 | 0.0 | 17.7 | - | - | - | - |
| GUN THREAT | 2.7 | +462.5 | 204.1 | 117.5 | - | - | - | - |
| GUN VIEW | 1.5 | +19.8 | 0.0 | 3.2 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 9.4 | 2.0 |
| HELPER UNSEEN | 0.1 | +0.0 | 12.9 | 0.0 | 0.4 | +0.0 | 29.3 | 22.9 |
| HILL BY ITS CHANCE | 0.3 | -32.2 | 0.0 | 0.0 | 0.6 | -27.0 | 0.0 | 10.2 |
| HOLDS AMBUSHERS | 0.2 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST THREAT | 16.2 | +2576.3 | 1340.7 | 337.5 | - | - | - | - |
| HONEST WORTH | 7.0 | -89.9 | 338.2 | 153.4 | 9.0 | -191.7 | 559.7 | 181.3 |
| HUNT ADVANCE | 0.4 | +4.1 | 11.4 | 5.2 | 0.3 | +17.6 | 6.5 | 8.2 |
| HUNT DROPPED | 0.1 | +0.0 | 7.6 | 1.4 | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 0.5 | +22.5 | 0.0 | 5.4 |
| HUNT KEPT | 0.2 | +1.2 | 16.0 | 1.4 | 0.2 | +7.0 | 3.5 | 2.0 |
| HUNT RESULT | 0.3 | +4.3 | 23.8 | 5.8 | 0.2 | +9.6 | 0.0 | 8.2 |
| HUNT THE GUNS | 0.3 | +95.7 | 24.4 | 8.4 | 0.2 | +99.2 | 6.5 | 8.2 |
| INVITES THE FIGHT | 2.0 | +40.7 | 196.1 | 41.2 | 1.5 | +20.5 | 62.8 | 19.0 |
| JOINT CHARGE PLAN | 0.1 | +0.1 | 5.1 | 0.0 | 0.1 | +4.8 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.1 | -2.1 | 20.8 | 5.4 |
| KEEP FALLS | 0.1 | +0.7 | 0.0 | 7.5 | - | - | - | - |
| KEEPS ITS PREY | 0.1 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS TARGET | 1.3 | +38.3 | 76.3 | 5.8 | 1.7 | +51.7 | 164.9 | 29.2 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS THE TARGET | 2.8 | -88.0 | 500.9 | 76.8 | - | - | - | - |
| KILLS COUNT | 1.1 | +37.2 | 84.3 | 12.6 | 1.6 | +72.0 | 167.1 | 5.9 |
| KILLS COUNT NEXT TURN | 4.3 | +120.1 | 159.7 | 107.4 | 6.6 | +228.7 | 226.9 | 165.9 |
| LONE CHARACTER SAFE SPOT | 0.6 | +23.4 | 25.2 | 15.6 | 0.3 | +2.9 | 1.7 | 11.1 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.2 | +0.0 | 0.0 | 10.7 |
| LONE WIZARD KEPT IN | 0.6 | +33.8 | 0.0 | 0.0 | 0.5 | +45.6 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | +2.8 | 7.4 | 0.0 | 0.4 | -2.7 | 24.1 | 1.1 |
| LOST CHARGE | 2.8 | -45.7 | 172.0 | 83.4 | 1.9 | -21.4 | 39.9 | 36.6 |
| LURE BY WHAT IT DRAWS | 0.1 | -7.0 | 0.0 | 3.4 | 0.1 | -6.0 | 0.0 | 2.0 |
| MAKE SURE TOGETHER | 0.8 | +20.1 | 52.3 | 17.2 | 0.3 | +22.0 | 0.0 | 31.6 |
| MANOEUVRE | 0.3 | +7.7 | 0.0 | 0.9 | 0.2 | +8.9 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.2 | +0.6 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +28.3 | 0.0 | 12.7 | 0.4 | +15.4 | 0.0 | 17.1 |
| MARCH ODDS | 0.1 | +3.1 | 0.0 | 0.0 | 0.2 | +10.1 | 10.0 | 5.4 |
| MARCH OVER CASTS | 0.3 | +36.1 | 0.0 | 26.6 | 0.4 | +9.7 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.2 | +117.2 | 0.0 | 74.6 | 5.0 | +177.6 | 0.0 | 124.5 |
| MISSILES IN THE FIRE PLAN | 1.4 | +15.1 | 138.9 | 22.5 | - | - | - | - |
| MISSILES IN THE MOVE | 3.4 | +121.5 | 0.0 | 58.8 | 2.9 | +46.7 | 0.0 | 143.5 |
| MISSILES NEXT TURN | 3.7 | +78.1 | 0.0 | 101.6 | 3.8 | +37.5 | 0.0 | 160.8 |
| MODEL FACING | 0.4 | +106.6 | 0.0 | 5.0 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 10.2 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.2 | +14.4 | 0.0 | 7.2 | 0.3 | +6.1 | 0.0 | 25.6 |
| MOVE SPELL IN RANGE | 0.2 | +4.9 | 0.0 | 32.2 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.2 | -6.1 | 5.3 | 0.0 | 0.0 | -0.1 | 0.0 | 11.2 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 2.2 | 0.1 | +0.0 | 0.0 | 22.2 |
| MOVE TO CHARGE | 3.1 | +120.0 | 151.2 | 103.0 | 4.2 | +280.3 | 129.1 | 130.0 |
| MOVES UNITS SPELL | 0.2 | +5.2 | 0.0 | 0.0 | 0.1 | +0.9 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +21.0 | 15.2 | 13.9 | - | - | - | - |
| NO RALLY LEFT | 0.0 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.2 | -4.9 | 18.4 | 0.0 | 0.1 | -5.9 | 17.2 | 0.0 |
| NOT TURNED | 5.6 | +136.8 | 0.0 | 113.8 | 5.5 | +29.7 | 0.0 | 153.5 |
| NOT WORTH A CAST | 0.4 | -0.3 | 0.0 | 0.0 | 0.2 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 16.4 | -826.6 | 1.5 | 294.4 | 15.4 | -818.6 | 23.4 | 343.0 |
| ONE YARDSTICK | 24.7 | -1411.8 | 882.8 | 519.7 | - | - | - | - |
| OPENS A LANE | 0.2 | +5.5 | 6.5 | 3.5 | 0.1 | +0.6 | 4.0 | 0.0 |
| OPENS UP | 0.1 | +8.4 | 1.5 | 0.0 | 0.2 | +17.3 | 7.5 | 12.3 |
| OVERRUNS AWAY | 0.5 | +12.4 | 44.5 | 2.6 | 0.3 | +10.0 | 20.3 | 17.5 |
| PATHS CROSS | 1.6 | +98.3 | 0.0 | 51.7 | 2.8 | +192.1 | 0.0 | 44.6 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +5.6 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -3.5 | 0.0 | 2.9 | 0.1 | -3.7 | 0.0 | 0.0 |
| PLAN RESULT | 40.1 | +1834.5 | 1573.8 | 1072.3 | 40.2 | +1395.6 | 1612.4 | 970.1 |
| PURSUES BIG PREY | 0.0 | -0.3 | 0.0 | 0.0 | 0.1 | -9.2 | 0.0 | 13.1 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.0 | +6.6 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +4.9 | 0.0 | 2.3 | 0.1 | +4.9 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.2 | +1.3 | 0.0 | 14.2 | 1.7 | +23.7 | 0.0 | 45.3 |
| RANDOM MOVER NO PROMISE | - | - | - | - | 0.2 | -14.1 | 11.2 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -2.3 | 0.0 | 7.8 | 0.3 | -9.9 | 0.0 | 6.9 |
| REDIRECT COUNTER | 2.0 | +79.4 | 0.0 | 51.9 | 3.2 | +259.5 | 0.0 | 28.4 |
| REDIRECT WEIGHED | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +3.1 | 12.1 | 20.8 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 21.3 | 0.4 | +0.0 | 0.0 | 23.0 |
| RESERVE FALL BACK | 0.2 | +11.5 | 0.0 | 5.8 | 1.0 | +28.6 | 0.0 | 13.0 |
| RESTRAINS TO SHOOT | 0.2 | +6.6 | 0.0 | 5.9 | 0.2 | +8.7 | 0.0 | 12.6 |
| RISK BY ARC | 1.9 | +70.2 | 174.6 | 35.6 | 2.3 | +46.3 | 216.1 | 66.7 |
| SAFER THAN THE JOB | 0.9 | +69.9 | 0.0 | 14.8 | 0.8 | +65.5 | 0.0 | 10.0 |
| SCOUT SPOT | 0.5 | +1.7 | 0.0 | 0.0 | 0.6 | +1.9 | 0.0 | 0.0 |
| SCOUT WAITS | 0.6 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -10.4 | 0.0 | 0.8 | 0.2 | -13.1 | 0.0 | 1.5 |
| SEARCH SPOT | 3.3 | +167.5 | 0.0 | 74.6 | 2.8 | +141.4 | 0.0 | 11.2 |
| SECOND HUNTER | 0.1 | -0.4 | 6.1 | 1.4 | - | - | - | - |
| SELF MOVE SPELL | 0.5 | +91.9 | 0.0 | 0.0 | 0.6 | +112.6 | 0.0 | 21.9 |
| SET UP TOGETHER | 1.3 | +28.7 | 52.3 | 27.3 | 1.0 | +83.9 | 0.0 | 54.3 |
| SET-UP ANY TARGET | 0.4 | +33.2 | 3.2 | 11.2 | 0.0 | +4.4 | 11.1 | 11.1 |
| SET-UP MISSED | 0.1 | +13.0 | 14.4 | 13.6 | 0.0 | +4.8 | 0.0 | 11.1 |
| SHOOTERS ARE THREATS | 4.0 | +237.7 | 282.9 | 102.9 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.6 | +1.0 | 0.0 | 0.0 | 0.3 | +0.4 | 0.0 | 0.0 |
| SHOOTERS TO THE PRIMARY | 3.5 | +53.7 | 0.0 | 71.2 | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 1.1 | +85.6 | 75.8 | 16.4 | 1.1 | +21.9 | 35.2 | 17.5 |
| SHORT GUN FORWARD | 0.5 | +0.0 | 0.0 | 3.2 | 0.1 | +0.0 | 0.0 | 0.0 |
| SHOT OPTIONS | 23.1 | +0.0 | 1481.1 | 468.4 | 15.0 | +0.0 | 558.1 | 238.9 |
| SHOT REPLANNED | - | - | - | - | 0.7 | +0.0 | 136.8 | 24.9 |
| SHOTS IN THE MOVE | 22.3 | +1287.3 | 0.0 | 438.8 | 13.9 | +334.0 | 0.0 | 184.2 |
| SPELL SETS UP CHARGE | 0.4 | +50.8 | 3.2 | 11.2 | 0.0 | +4.4 | 11.1 | 11.1 |
| SPELL WORTH | 0.8 | +12.0 | 49.6 | 47.9 | 1.6 | +33.0 | 110.8 | 110.8 |
| SPELLS IN THE FIGHT | 0.4 | -5.6 | 76.0 | 21.2 | 0.6 | -6.3 | 86.8 | 19.6 |
| STABLE ROLE | 11.4 | +0.0 | 489.2 | 172.9 | 9.8 | +0.0 | 280.8 | 108.5 |
| STANDS TO CAST | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| STAY WEIGHED | 0.0 | +1.5 | 0.0 | 0.0 | 0.0 | +4.4 | 0.0 | 0.0 |
| STAY WORTH | 28.2 | +228.4 | 810.0 | 377.6 | - | - | - | - |
| STOPS | 0.1 | +0.7 | 16.1 | 3.1 | 0.1 | +1.3 | 3.5 | 2.0 |
| STOPS SHORT OF THE FLANK | 0.2 | +21.6 | 0.0 | 8.7 | 0.4 | +20.4 | 0.0 | 6.5 |
| STUCK PIVOT | - | - | - | - | 0.2 | +0.0 | 0.0 | 5.8 |
| SUPPORT NARROWED | 3.9 | -28.5 | 254.7 | 64.6 | 6.7 | -42.1 | 288.2 | 81.9 |
| SUPPORTS | 2.9 | +34.0 | 172.5 | 57.9 | 4.5 | +50.2 | 143.0 | 47.0 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -3.5 | 11.4 | 2.5 | 0.0 | -0.4 | 0.0 | 2.0 |
| SURE REACH TOGETHER | 0.6 | +2.1 | 11.9 | 19.0 | 0.6 | -4.8 | 7.0 | 35.7 |
| THROUGH LINE OF FIRE | 0.5 | +49.4 | 0.0 | 38.9 | 0.4 | +18.3 | 0.0 | 0.0 |
| TURN WORTH | 0.3 | -12.4 | 14.9 | 2.4 | 0.2 | -13.0 | 22.2 | 0.0 |
| TWO OR MORE ARRIVE | 0.1 | +0.1 | 0.0 | 2.9 | 0.3 | +1.1 | 0.0 | 15.0 |
| WAIT AFTER COSTS | 7.0 | -320.2 | 372.9 | 169.4 | 7.5 | -355.5 | 242.6 | 197.9 |
| WALKS TO THE FIGHT | 1.7 | +21.7 | 9.1 | 27.1 | 0.9 | +10.3 | 26.4 | 0.0 |
| WAR ENGINE CHARGES | 0.1 | +17.7 | 16.0 | 0.0 | 0.0 | +0.9 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.6 | +0.0 | 57.2 | 22.4 | 0.4 | +0.0 | 12.5 | 20.4 |
| WEARS DOWN | 0.8 | +34.4 | 58.8 | 6.6 | 1.0 | +41.1 | 117.2 | 58.9 |
| WHO HITS BACK | 0.2 | +13.8 | 0.0 | 11.6 | 0.2 | +10.8 | 0.0 | 4.9 |
| WHOLE FIGHT | 0.2 | +14.4 | 33.9 | 16.4 | 0.5 | +28.6 | 71.3 | 14.5 |
| WHOLE FIGHT GAIN | 0.2 | +7.1 | 8.7 | 0.9 | 0.5 | +48.7 | 39.0 | 6.8 |
| WIDER SPREAD | 1.8 | -5.9 | 149.4 | 21.7 | 3.1 | -7.0 | 310.7 | 93.1 |

### Rule changes: gf-h2h-mine-0533c46-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1146 | 1146 | 1146 | 31.83 | -59227 | -51.7 |
| BEST FIRST | 325 | 325 | 325 | 9.03 | +13757 | +42.3 |
| FIRE PLAN | 959 | 959 | 270 | 7.50 | +2501 | +9.3 |
| SEARCH SPOT | 219 | 219 | 218 | 6.06 | +11123 | +51.0 |
| COUNTER-CHARGE COVER | 646 | 370 | 169 | 4.69 | +11278 | +66.7 |
| SHOTS IN THE MOVE | 1303 | 897 | 160 | 4.44 | +4685 | +29.3 |
| PATHS CROSS | 157 | 157 | 157 | 4.36 | +10454 | +66.6 |
| MOVE TO CHARGE | 262 | 262 | 138 | 3.83 | +4636 | +33.6 |
| ARTILLERY RE-ROLL WEIGHED | 137 | 137 | 137 | 3.81 | +0 | +0.0 |
| EVERY WOUND COUNTS | 585 | 585 | 136 | 3.78 | +0 | +0.0 |
| KILLS COUNT NEXT TURN | 393 | 393 | 107 | 2.97 | +3191 | +29.8 |
| FACES THE THREAT | 100 | 100 | 100 | 2.78 | +6204 | +62.0 |
| FALLBACK BY WORTH | 382 | 382 | 89 | 2.47 | +5292 | +59.5 |
| ONE YARDSTICK | 888 | 423 | 88 | 2.44 | +1354 | +15.4 |
| SUPPORTS | 266 | 266 | 83 | 2.31 | +954 | +11.5 |
| FOLLOW UP WEIGHED | 77 | 77 | 77 | 2.14 | +12697 | +164.9 |
| CANNON SIGHT KEPT | 67 | 67 | 67 | 1.86 | +0 | +0.0 |
| WAIT AFTER COSTS | 520 | 520 | 66 | 1.83 | +1158 | +17.5 |
| SAFER THAN THE JOB | 60 | 60 | 60 | 1.67 | +4876 | +81.3 |
| BEST MOVE FOR SHOOTERS | 47 | 47 | 47 | 1.31 | +4513 | +96.0 |
| STAY WORTH | 1017 | 859 | 47 | 1.31 | +796 | +16.9 |
| FIRE IN ORDER | 46 | 46 | 46 | 1.28 | +0 | +0.0 |
| KEEPS THE TARGET | 102 | 102 | 44 | 1.22 | -4203 | -95.5 |
| RESERVE FALL BACK | 44 | 44 | 44 | 1.22 | +1443 | +32.8 |
| BEST FACING | 43 | 43 | 43 | 1.19 | +1199 | +27.9 |
| BEST OVERALL | 43 | 43 | 43 | 1.19 | +3141 | +73.1 |
| MAX FOR POSITIONING | 332 | 197 | 43 | 1.19 | +481 | +11.2 |
| RANDOM MOVE BY FIGURES | 69 | 69 | 43 | 1.19 | +900 | +20.9 |
| SHOOTS FROM THE BEST SPOT | 81 | 81 | 43 | 1.19 | +1196 | +27.8 |
| LONE WIZARD KEPT IN | 42 | 42 | 42 | 1.17 | +2858 | +68.0 |
| SCOUT WAITS | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| WALKS TO THE FIGHT | 91 | 91 | 41 | 1.14 | +392 | +9.6 |
| ADVANCE LANE KEPT | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| COMBAT PIVOT | 38 | 38 | 38 | 1.06 | +0 | +0.0 |
| HONEST THREAT | 585 | 585 | 38 | 1.06 | +0 | +0.0 |
| REDIRECT COUNTER | 185 | 102 | 36 | 1.00 | +2678 | +74.4 |
| CHARGE NOW WEIGHED | 34 | 34 | 34 | 0.94 | +1827 | +53.7 |
| THROUGH LINE OF FIRE | 32 | 32 | 32 | 0.89 | +2438 | +76.2 |
| SET UP TOGETHER | 82 | 70 | 31 | 0.86 | +1470 | +47.4 |
| SHOOTERS IN TWO RANKS | 30 | 30 | 30 | 0.83 | +50 | +1.7 |
| HONEST WORTH | 577 | 575 | 29 | 0.81 | +177 | +6.1 |
| MISSILES IN THE MOVE | 227 | 118 | 29 | 0.81 | +972 | +33.5 |
| CHARGE NOW FIRST | 149 | 149 | 28 | 0.78 | -1868 | -66.7 |
| GUN VIEW | 54 | 54 | 28 | 0.78 | +682 | +24.4 |
| HOLDS AMBUSHERS | 28 | 28 | 28 | 0.78 | +0 | +0.0 |
| RISK BY ARC | 150 | 148 | 28 | 0.78 | +883 | +31.5 |
| BLOCKED WHEEL | 27 | 27 | 27 | 0.75 | +418 | +15.5 |
| SHOT REPLANNED | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 23 | 23 | 23 | 0.64 | +1700 | +73.9 |
| KEEPS ITS TARGET | 108 | 108 | 23 | 0.64 | +485 | +21.1 |
| KILLS COUNT | 96 | 95 | 23 | 0.64 | +1057 | +46.0 |
| STOPS SHORT OF THE FLANK | 23 | 23 | 23 | 0.64 | +1512 | +65.7 |
| MARCH CHECK | 27 | 24 | 22 | 0.61 | +979 | +44.5 |
| SHORT GUN FORWARD | 20 | 20 | 20 | 0.56 | +0 | +0.0 |
| CAST JOB | 47 | 47 | 19 | 0.53 | +316 | +16.7 |
| CASTER AWAY FROM SCREEN | 19 | 19 | 19 | 0.53 | +0 | +0.0 |
| INVITES THE FIGHT | 126 | 126 | 19 | 0.53 | +360 | +18.9 |
| REDIRECT WEIGHED | 19 | 19 | 19 | 0.53 | +2251 | +118.5 |
| MOVE AND CAST | 18 | 18 | 18 | 0.50 | +736 | +40.9 |
| SHOOTERS ARE THREATS | 145 | 145 | 18 | 0.50 | +0 | +0.0 |
| WHO HITS BACK | 17 | 17 | 17 | 0.47 | +568 | +33.4 |
| MODEL FACING | 16 | 16 | 16 | 0.44 | +3839 | +240.0 |
| MANOEUVRE | 16 | 16 | 15 | 0.42 | +598 | +39.9 |
| RESTRAINS TO SHOOT | 15 | 15 | 15 | 0.42 | +549 | +36.6 |
| MAKE SURE TOGETHER | 39 | 26 | 14 | 0.39 | +507 | +36.2 |
| GUN THREAT | 98 | 98 | 13 | 0.36 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 25 | 24 | 13 | 0.36 | +665 | +51.2 |
| BEST PREY | 58 | 58 | 11 | 0.31 | +439 | +39.9 |
| CHARGE BAND | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| MOVES UNITS SPELL | 11 | 11 | 11 | 0.31 | +221 | +20.1 |
| WAR ENGINE JOBS | 37 | 37 | 11 | 0.31 | -1613 | -146.6 |
| WHOLE FIGHT | 28 | 28 | 11 | 0.31 | +431 | +39.2 |
| BIG CHARACTER SAFETY | 10 | 10 | 10 | 0.28 | -64 | -6.4 |
| CANNON PLANNED TARGET | 73 | 73 | 10 | 0.28 | +75 | +7.5 |
| MARCH ODDS | 11 | 11 | 10 | 0.28 | +92 | +9.2 |
| REFUSING RETIRES | 29 | 29 | 10 | 0.28 | -3 | -0.3 |
| SUPPORT NARROWED | 382 | 382 | 10 | 0.28 | -81 | -8.1 |
| BEST PRIZE | 9 | 9 | 9 | 0.25 | -203 | -22.6 |
| CHAFF PASSED | 9 | 9 | 9 | 0.25 | -36 | -4.0 |
| HUNT ADVANCE | 24 | 24 | 9 | 0.25 | +319 | +35.5 |
| WEARS DOWN | 66 | 64 | 9 | 0.25 | +270 | +30.0 |
| CASTING BLOCK | 13 | 13 | 8 | 0.22 | +613 | +76.6 |
| PIVOT GUARDS FLANK | 8 | 8 | 8 | 0.22 | -258 | -32.2 |
| STUCK PIVOT | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| BLOCKED CHARGE SKIPPED | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| CASTS FROM BEHIND | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| LOST CHARGE | 171 | 171 | 5 | 0.14 | +125 | +25.1 |
| OVERRUNS AWAY | 30 | 30 | 5 | 0.14 | +40 | +8.0 |
| BACKUP TARGETS | 69 | 35 | 4 | 0.11 | +17 | +4.3 |
| HUNT IN PAIRS | 17 | 10 | 4 | 0.11 | +111 | +27.7 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 9 | 9 | 4 | 0.11 | -51 | -12.8 |
| OPENS UP | 9 | 9 | 4 | 0.11 | +293 | +73.2 |
| PURSUES BIG PREY | 4 | 4 | 4 | 0.11 | -343 | -85.6 |
| SURE CHARGE BEATS ADVANCE | 4 | 4 | 4 | 0.11 | -142 | -35.6 |
| BOMBING RUN | 3 | 3 | 3 | 0.08 | +114 | +38.2 |
| MISSILES NEXT TURN | 270 | 143 | 3 | 0.08 | +34 | +11.3 |
| NEEDED THERE | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 4 | 4 | 3 | 0.08 | +199 | +66.3 |
| SHOOTERS TO THE PRIMARY | 126 | 86 | 3 | 0.08 | +24 | +8.1 |
| DEFENSIVE ARMY | 7 | 7 | 2 | 0.06 | -31 | -15.4 |
| EDGE GIVE GROUND | 10 | 10 | 2 | 0.06 | +164 | +81.8 |
| FACE THE CAST | 2 | 2 | 2 | 0.06 | +19 | +9.4 |
| JOINT CHARGE PLAN | 4 | 4 | 2 | 0.06 | +129 | +64.4 |
| KEEP FALLS | 2 | 2 | 2 | 0.06 | +102 | +51.2 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +203 | +101.3 |
| STAY WEIGHED | 2 | 2 | 2 | 0.06 | +212 | +105.8 |
| SURE REACH TOGETHER | 43 | 30 | 2 | 0.06 | +6 | +3.1 |
| WAR ENGINE CHARGES | 6 | 6 | 2 | 0.06 | +289 | +144.5 |
| BLOWS WHERE AIMED | 18 | 15 | 1 | 0.03 | +79 | +79.2 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.1 |
| CARRIES OUT COUNTER | 2 | 2 | 1 | 0.03 | -68 | -68.1 |
| CHARIOT NO STATIC JOB | 1 | 1 | 1 | 0.03 | -109 | -108.9 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +18 | +17.5 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +7 | +7.2 |
| GUN MASK | 20 | 9 | 1 | 0.03 | +40 | +40.5 |
| HILL BY ITS CHANCE | 32 | 32 | 1 | 0.03 | +38 | +37.9 |
| LONG SHOT | 21 | 21 | 1 | 0.03 | +2 | +2.0 |
| MOVE SPELL IN RANGE | 6 | 3 | 1 | 0.03 | +1 | +1.1 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +40 | +40.1 |
| RAIDS THE BAGGAGE | 1 | 1 | 1 | 0.03 | +198 | +197.6 |
| REDIRECT BY WHAT IT STOPS | 18 | 18 | 1 | 0.03 | +36 | +36.1 |
| SCREEN BY WHAT IT SAVES | 10 | 10 | 1 | 0.03 | +16 | +16.4 |
| SPELLS IN THE FIGHT | 34 | 32 | 1 | 0.03 | +0 | +0.0 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | +3 | +3.2 |
| WIDER SPREAD | 174 | 169 | 1 | 0.03 | +6 | +5.6 |
| ARRIVAL HUNT | 3 | 3 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 10 | 10 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 5 | 5 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 39 | trace | - | - | - | - |
| CATCH FLIERS | 4 | not checked | - | - | - | - |
| CHARGER SLAIN LOST | 41 | 37 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 7 | 7 | 0 | 0.00 | - | - |
| CHEAP HELPER | 2 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 32 | not checked | - | - | - | - |
| ENGINEER BY LORE | 10 | 10 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 388 | not checked | - | - | - | - |
| GIVES UP | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 3 | not checked | - | - | - | - |
| GUN FIGURES | 150 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 19 | 18 | 0 | 0.00 | - | - |
| HUNT DROPPED | 8 | trace | - | - | - | - |
| HUNT KEPT | 14 | trace | - | - | - | - |
| HUNT RESULT | 18 | trace | - | - | - | - |
| HUNT THE GUNS | 21 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 5 | 4 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 32 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 7 | trace | - | - | - | - |
| MARCH OVER CASTS | 25 | 25 | 0 | 0.00 | - | - |
| MISSILES IN THE FIRE PLAN | 52 | 9 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 9 | 9 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 7 | trace | - | - | - | - |
| MOVE SPELL SPOT | 12 | not checked | - | - | - | - |
| NOT NEEDED | 11 | 11 | 0 | 0.00 | - | - |
| NOT TURNED | 399 | 399 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 22 | not checked | - | - | - | - |
| OPENS A LANE | 9 | 8 | 0 | 0.00 | - | - |
| PLAN RESULT | 2893 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 8 | 8 | 0 | 0.00 | - | - |
| SCOUT SPOT | 38 | 38 | 0 | 0.00 | - | - |
| SECOND HUNTER | 3 | 3 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 39 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 14 | not checked | - | - | - | - |
| SET-UP MISSED | 6 | trace | - | - | - | - |
| SHOT OPTIONS | 1374 | 1374 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 16 | not checked | - | - | - | - |
| SPELL WORTH | 86 | not checked | - | - | - | - |
| STABLE ROLE | 763 | 763 | 0 | 0.00 | - | - |
| STOPS | 5 | 5 | 0 | 0.00 | - | - |
| TURN WORTH | 18 | 18 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 13 | 13 | 0 | 0.00 | - | - |

### Off best figure: gf-h2h-mine-0533c46-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.97 | 13.69 | 52.6 |
| FIRE PLAN | rule | 1.25 | - | 55.8 |
| TURN GATE | gate | 0.56 | 0.64 | 47.2 |
| FALLBACK | gate | 0.53 | 0.64 | 43.2 |
| KEEPS THE TARGET | rule | 0.94 | - | 148.9 |
| CHARGE NOW FIRST | rule | 0.22 | 0.56 | 66.7 |
| LONE CHARACTER SAFE SPOT | gate | 0.17 | 0.17 | 51.2 |
| WAR ENGINE JOBS | rule | 0.17 | 0.14 | 146.6 |
| SUPPORT NARROWED | rule | 0.06 | 0.22 | 8.1 |
| BEST PRIZE | rule | 0.08 | 0.17 | 22.6 |
| BIG CHARACTER SAFETY | rule | 0.03 | 0.19 | 10.4 |
| CHAFF PASSED | rule | - | 0.22 | 4.5 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.17 | 11.5 |
| PIVOT GUARDS FLANK | rule | 0.14 | 0.08 | 32.2 |
| PATHS CROSS | rule | 0.06 | 0.08 | 25.8 |
| SUPPORT REQUEST | gate | 0.03 | 0.11 | 50.4 |
| AFTERMATH BAND | gate | 0.06 | 0.06 | 2.4 |
| BLOCKED WHEEL | rule | 0.06 | 0.06 | 22.7 |
| PURSUES BIG PREY | rule | 0.03 | 0.08 | 85.7 |
| STOPS SHORT OF THE FLANK | rule | - | 0.11 | 9.3 |
| SURE CHARGE BEATS ADVANCE | rule | 0.08 | 0.03 | 35.6 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | 0.03 | 38.1 |
| FACES THE THREAT | rule | 0.03 | 0.06 | 9.1 |
| FIGHT ORDER BAND | gate | 0.06 | 0.03 | 3.1 |
| THROUGH LINE OF FIRE | rule | 0.03 | 0.06 | 28.0 |
| DEFENSIVE ARMY | rule | 0.06 | - | 15.4 |
| LONE WIZARD HOLDS BACK | rule | - | 0.06 | 25.6 |
| MARCH ODDS | rule | 0.03 | 0.03 | 15.5 |
| REFUSING RETIRES | rule | 0.06 | - | 0.9 |
| CARRIES OUT COUNTER | rule | - | 0.03 | 68.1 |
| CHARIOT NO STATIC JOB | rule | - | 0.03 | 108.9 |
| NO REASON | gate | 0.03 | - | 16.4 |
| RULE SWITCHED OFF | gate | - | 0.03 | 39.4 |
| SAFER THAN THE JOB | rule | - | 0.03 | 18.8 |
| WHO HITS BACK | rule | - | 0.03 | 1.9 |

### Plans: gf-h2h-mine-0533c46-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.9 | 11% | 557 | 359 | 64% |
| Mine | charge | 2.0 | 63% | 160 | 193 | 121% |
| Mine | close in | 3.4 | 29% | 132 | 114 | 86% |
| Mine | hold | 4.5 | 32% | 282 | 0 | 0% |
| Mine | join | 0.8 | 86% | 11 | 0 | 0% |
| Mine | shoot | 14.4 | 58% | 762 | 1169 | 153% |
| Mine | support | 3.1 | 87% | 21 | 0 | 0% |
| Opponent | advance | 13.6 | 17% | 396 | 374 | 94% |
| Opponent | charge | 3.7 | 70% | 337 | 421 | 125% |
| Opponent | close in | 5.3 | 25% | 287 | 112 | 39% |
| Opponent | hold | 5.7 | 38% | 406 | 0 | 0% |
| Opponent | join | 0.3 | 100% | 11 | 0 | 0% |
| Opponent | shoot | 6.7 | 60% | 167 | 489 | 293% |
| Opponent | support | 4.9 | 91% | 30 | 0 | 0% |

### Packages: hunt the guns, gf-h2h-mine-0533c46-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.3 | 12 | 2 | 10% | 10% | 0% | 4.0 | 312 | 15 | 10% | 59 |
| Opponent | 0.2 | 9 | 1 | 12% | 25% | 0% | 2.5 | 366 | 43 | 25% | 171 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 2.7 | 8 | 0 | 12% | 12% | 0% | 4.0 | 263 | 19 | 12% | 103 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 129 |
| Dwarfen Mountain Holds | 0.2 | 1 | 1 | - | - | - | - | - | - | - | 155 |
| Empire of Man | 0.1 | 2 | 0 | 0% | 50% | 0% | 2.0 | 322 | 67 | 50% | 25 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 160 |
| High Elf Realms | 0.2 | 2 | 0 | 0% | 0% | 0% | - | 567 | 0 | 0% | 62 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 141 |
| Ogre Kingdoms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 452 | 0 | 0% | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 797 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 313 |
| Tomb Kings of Khemri | 0.6 | 4 | 1 | 33% | 33% | 0% | 3.0 | 355 | 71 | 33% | 104 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 38 |
| Warriors of Chaos | 0.2 | 1 | 1 | - | - | - | - | - | - | - | 418 |
| Wood Elf Realms | 1.0 | 2 | 0 | 0% | 0% | 0% | - | 324 | 0 | 0% | 0 |

### Battle groups: gf-h2h-mine-0533c46-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.5 | 20% | 33% | 13% | 11% | 14% | 14% | 14% | 59% | 0% |
| Mine | REDIRECT COUNTER | 2.0 | 42% | 57% | 3% | 100% | 24% | 0% | 14% | 59% | 3% |
| Opponent | COUNTER-CHARGE COVER | 8.4 | 13% | 62% | 10% | 25% | 31% | 11% | 6% | 51% | 0% |
| Opponent | REDIRECT COUNTER | 3.2 | 15% | 94% | 18% | 0% | 21% | 0% | 7% | 71% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gf-h2h-mine-0533c46-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 33 | 0% | 3.7 | - | 0 (3) | - | 0 (1) | 0 (2) |
| Mine | Chaff | 28 | 28 (28) | 28 | 0 | 53 | 21% | 3.0 | 18 (13) | 23 (6) | 44 (9) | 21 (16) | 37 (12) |
| Mine | Character | 107 | 46 (107) | 46 | 0 | 32 | 38% | 2.5 | 74 (31) | 43 (51) | 36 (10) | 47 (49) | 55 (43) |
| Mine | Clean-up | 15 | 79 (15) | 35 | 43 | 44 | 27% | 2.4 | 80 (6) | 42 (8) | 250 (1) | 123 (10) | 0 (5) |
| Mine | Fast | 4 | 0 (4) | 0 | 0 | 100 | 0% | 2.0 | 0 (1) | 0 (2) | 0 (1) | 0 (4) | - |
| Mine | Fast Hammer | 54 | 53 (54) | 34 | 20 | 51 | 22% | 2.7 | 69 (21) | 38 (22) | 59 (11) | 80 (34) | 20 (20) |
| Mine | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Hammer | 77 | 35 (77) | 22 | 13 | 45 | 21% | 2.3 | 28 (18) | 42 (53) | 0 (6) | 47 (48) | 15 (29) |
| Mine | Holder | 24 | 78 (24) | 7 | 71 | 56 | 29% | 2.1 | 70 (6) | 94 (12) | 58 (6) | 103 (16) | 38 (8) |
| Mine | Shooter | 40 | 67 (40) | 29 | 38 | 37 | 2% | 1.6 | 33 (16) | 100 (20) | 6 (4) | 82 (29) | 25 (11) |
| Mine | War machine | 91 | 54 (91) | 54 | 0 | 41 | 4% | 1.1 | 65 (43) | 55 (35) | 17 (13) | 39 (21) | 59 (70) |
| Mine | Wizard | 28 | 13 (28) | 13 | 0 | 39 | 21% | 2.7 | 32 (8) | 6 (13) | 13 (3) | 0 (7) | 22 (17) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Chaff | 68 | 75 (68) | 19 | 56 | 43 | 28% | 2.4 | 120 (30) | 79 (14) | 16 (24) | 70 (55) | 96 (13) |
| Opponent | Character | 96 | 63 (96) | 62 | 1 | 34 | 27% | 2.0 | 74 (38) | 64 (45) | 7 (7) | 63 (50) | 67 (40) |
| Opponent | Clean-up | 13 | 68 (13) | 12 | 56 | 36 | 69% | 2.8 | 43 (3) | 73 (8) | 52 (2) | 104 (9) | 22 (4) |
| Opponent | Fast | 3 | 0 (3) | 0 | 0 | 67 | 67% | 2.0 | - | 0 (3) | - | 0 (3) | - |
| Opponent | Fast Hammer | 51 | 30 (51) | 21 | 9 | 48 | 37% | 3.2 | 20 (24) | 41 (17) | 47 (10) | 29 (27) | 32 (24) |
| Opponent | Fragile | 14 | 7 (14) | 7 | 0 | 38 | 21% | 3.4 | - | 12 (9) | 0 (5) | 0 (5) | 12 (9) |
| Opponent | Hammer | 55 | 20 (55) | 16 | 4 | 42 | 29% | 2.3 | 10 (19) | 26 (32) | 0 (4) | 20 (38) | 19 (17) |
| Opponent | Holder | 43 | 120 (43) | 5 | 115 | 17 | 40% | 2.3 | 175 (12) | 111 (23) | 83 (7) | 162 (29) | 70 (13) |
| Opponent | Shooter | 32 | 62 (32) | 17 | 45 | 36 | 3% | 1.6 | 16 (9) | 75 (21) | 118 (2) | 79 (21) | 29 (11) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (2) | - | - | 0 (1) | 0 (1) |
| Opponent | War machine | 24 | 72 (24) | 72 | 0 | 37 | 4% | 1.3 | 78 (7) | 65 (15) | 114 (2) | 90 (8) | 62 (16) |
| Opponent | Wizard | 25 | 4 (25) | 4 | 0 | 44 | 12% | 2.1 | 6 (11) | 16 (4) | 0 (3) | 10 (9) | 0 (9) |

### Charged fights: gf-h2h-mine-0533c46-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 285 | 79 | 3.3 | 1.0 | 24 | 44 | -20 | 3 of 10 | 7 of 10 | - | -20 |
| Mine | Chaos Dwarfs | 5 | 372 | 305 | 1.6 | 1.0 | 190 | 0 | +190 | 3 of 8 | 6 of 8 | - | +190 |
| Mine | Dwarfen Mountain Holds | 5 | 649 | 96 | 1.6 | 1.4 | 60 | 0 | +60 | 0 of 8 | 7 of 8 | +36 | +68 |
| Mine | Empire of Man | 12 | 442 | 70 | 1.0 | 1.1 | 70 | 22 | +48 | 4 of 12 | 9 of 12 | +369 | +19 |
| Mine | Grand Cathay | 2 | 376 | 496 | 4.0 | 1.1 | 124 | 46 | +78 | 3 of 8 | 6 of 8 | +126 | +71 |
| Mine | High Elf Realms | 5 | 34 | 828 | 3.8 | 1.1 | 218 | 37 | +180 | 7 of 19 | 17 of 19 | +0 | +190 |
| Mine | Ogre Kingdoms | 3 | 136 | 39 | 3.7 | 1.2 | 11 | 39 | -28 | 3 of 11 | 6 of 11 | -19 | -30 |
| Mine | Tomb Kings of Khemri | 1 | 75 | 190 | 2.0 | 1.5 | 95 | 0 | +95 | 1 of 2 | 2 of 2 | +0 | +190 |
| **Mine** | all armies | 36 | 352 | 237 | 2.2 | 1.1 | 109 | 28 | +81 | 24 of 78 | 60 of 78 | +66 | +83 |
| Opponent | Chaos Dwarfs | 1 | 134 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 4 | 556 | 39 | 1.0 | 1.2 | 39 | 0 | +39 | 1 of 4 | 3 of 4 | +91 | +22 |
| Opponent | Grand Cathay | 1 | 281 | 526 | 1.0 | 1.0 | 526 | 0 | +526 | 1 of 1 | 0 of 1 | - | +526 |
| Opponent | High Elf Realms | 6 | 139 | 260 | 2.5 | 1.3 | 104 | 44 | +60 | 5 of 15 | 13 of 15 | +95 | +51 |
| Opponent | Lizardmen | 1 | 0 | 419 | 2.0 | 1.0 | 210 | 0 | +210 | 2 of 2 | 2 of 2 | - | +210 |
| Opponent | Ogre Kingdoms | 2 | 82 | 104 | 3.0 | 1.2 | 34 | 7 | +28 | 0 of 6 | 4 of 6 | +0 | +33 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 436 | 3.0 | 1.0 | 145 | 85 | +60 | 1 of 3 | 2 of 3 | - | +60 |
| Opponent | Skaven | 3 | 20 | 110 | 1.0 | 1.0 | 110 | 0 | +110 | 2 of 3 | 3 of 3 | - | +110 |
| Opponent | Tomb Kings of Khemri | 6 | 23 | 921 | 4.2 | 1.2 | 221 | 24 | +197 | 13 of 25 | 20 of 25 | +291 | +174 |
| Opponent | Vampire Counts | 4 | 0 | 612 | 6.5 | 1.3 | 94 | 30 | +64 | 12 of 26 | 20 of 26 | -54 | +108 |
| Opponent | Warriors of Chaos | 5 | 0 | 750 | 3.6 | 1.1 | 208 | 11 | +197 | 11 of 18 | 16 of 18 | +762 | +164 |
| Opponent | Wood Elf Realms | 2 | 22 | 434 | 3.5 | 1.1 | 124 | 0 | +124 | 4 of 7 | 6 of 7 | +214 | +109 |
| **Opponent** | all armies | 36 | 108 | 451 | 3.1 | 1.2 | 148 | 23 | +125 | 52 of 110 | 89 of 110 | +128 | +124 |

### Effective charges: gf-h2h-mine-0533c46-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 10 | 3 (net -84) | 0 | 1 (net +58) | 0 | 0 | 4 (net -3) | 2 | 12% (1 of 8) |
| Mine | Chaos Dwarfs | 8 | 2 (net +233) | 0 | 2 (net +0) | 1 (net +0) | 0 | 3 (net +352) | 0 | 25% (2 of 8) |
| Mine | Dwarfen Mountain Holds | 8 | 2 (net +88) | 1 (net +0) | 2 (net +56) | 1 (net +83) | 1 (net +72) | 1 (net +41) | 0 | 25% (2 of 8) |
| Mine | Empire of Man | 12 | 2 (net +0) | 1 (net +369) | 3 (net -88) | 2 (net +118) | 2 (net +91) | 2 (net +30) | 0 | 25% (3 of 12) |
| Mine | Grand Cathay | 8 | 0 | 0 | 1 (net +145) | 2 (net +195) | 4 (net +114) | 0 | 1 | 14% (1 of 7) |
| Mine | High Elf Realms | 19 | 0 | 1 (net +233) | 6 (net +139) | 4 (net +279) | 1 (net +0) | 6 (net +178) | 1 | 33% (6 of 18) |
| Mine | Ogre Kingdoms | 11 | 1 (net -68) | 0 | 1 (net +0) | 1 (net +0) | 0 | 2 (net +45) | 6 | 20% (1 of 5) |
| Mine | Tomb Kings of Khemri | 2 | 0 | 0 | 0 | 0 | 1 (net +0) | 1 (net +190) | 0 | 0% (0 of 2) |
| Opponent | Empire of Man | 4 | 1 (net +0) | 0 | 0 | 1 (net +0) | 1 (net +91) | 1 (net +65) | 0 | 0% (0 of 4) |
| Opponent | Grand Cathay | 1 | 1 (net +526) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | High Elf Realms | 15 | 1 (net +0) | 0 | 0 | 5 (net +89) | 3 (net -124) | 4 (net +152) | 2 | 0% (0 of 13) |
| Opponent | Lizardmen | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 1 | 0% (0 of 1) |
| Opponent | Ogre Kingdoms | 6 | 0 | 0 | 2 (net +0) | 1 (net +126) | 0 | 2 (net +20) | 1 | 40% (2 of 5) |
| Opponent | Orc & Goblin Tribes | 3 | 1 (net -255) | 0 | 0 | 0 | 0 | 1 (net +400) | 1 | 0% (0 of 2) |
| Opponent | Skaven | 3 | 0 | 0 | 0 | 0 | 0 | 3 (net +110) | 0 | 0% (0 of 3) |
| Opponent | Tomb Kings of Khemri | 25 | 3 (net -6) | 1 (net +0) | 1 (net +261) | 7 (net +103) | 1 (net +135) | 9 (net +351) | 3 | 5% (1 of 22) |
| Opponent | Vampire Counts | 26 | 5 (net +39) | 1 (net +0) | 4 (net +15) | 5 (net +130) | 1 (net +55) | 8 (net +85) | 2 | 17% (4 of 24) |
| Opponent | Warriors of Chaos | 18 | 0 | 1 (net +85) | 7 (net +221) | 4 (net +304) | 0 | 5 (net +140) | 1 | 41% (7 of 17) |
| Opponent | Wood Elf Realms | 7 | 1 (net +214) | 0 | 1 (net +0) | 1 (net +34) | 0 | 4 (net +155) | 0 | 14% (1 of 7) |

### Charged fights, damage counted: gf-h2h-mine-0533c46-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 10 | 130 | 243 | +32 | 107 | 50 | +58 | +44.3 |
| Mine | 50-54% | 3 | 392 | 300 | +201 | 226 | 33 | +192 | +49.1 |
| Mine | Effective (55-75%) | 16 | 238 | 251 | +55 | 144 | 83 | +61 | +25.5 |
| Mine | 76-89% | 11 | 288 | 175 | +166 | 180 | 21 | +159 | +55.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 19 | 157 | 133 | +131 | 155 | 32 | +123 | +78.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 307 | 66 | +79 | 84 | 0 | +84 | +27.5 |
| Mine | No odds | 10 | 156 | 230 | -52 | 39 | 76 | -38 | -24.2 |
| Mine | All fights | 78 | 215 | 188 | +81 | 130 | 45 | +84 | +39.3 |
| Opponent | Long shot (under 50%) | 13 | 250 | 298 | +51 | 130 | 50 | +80 | +32.0 |
| Opponent | 50-54% | 3 | 314 | 288 | +28 | 28 | 17 | +11 | +3.5 |
| Opponent | Effective (55-75%) | 15 | 302 | 215 | +125 | 182 | 66 | +116 | +38.3 |
| Opponent | 76-89% | 24 | 314 | 183 | +133 | 154 | 23 | +131 | +41.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 38 | 346 | 217 | +174 | 209 | 31 | +178 | +51.4 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 545 | 80 | -15 | 94 | 121 | -27 | -4.9 |
| Opponent | No odds | 11 | 336 | 120 | +125 | 130 | 21 | +110 | +32.6 |
| Opponent | All fights | 110 | 330 | 204 | +125 | 165 | 40 | +125 | +37.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gf-h2h-mine-0533c46-p3 | move | 449 | 99 (22%) | 76 (17%) | 52 (12%) | 298 (66%) |
| gf-h2h-mine-0533c46-p3 | objective | 314 | 53 (17%) | 41 (13%) | 40 (13%) | 221 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0826, L0834, L1524, L1527, L1834, L2227 |
| Elixir of Power | Mine | L1115 |
| Elixir of Power | Opponent | L0711, L0819 |
| Fistful of Laurels | Mine | L1823, L1829, L1834 |
| Fistful of Laurels | Opponent | L0218, L1518 |
| Invocation of Nehek | Opponent | L1524, L1527, L2227 |
| Opal Amulet | Mine | L1415, L1422 |
| Periapt of Soul Exchange | Opponent | L0621, L0920, L0921 |
| Ring of Doom | Mine | L0203, L0215, L0218, L1115, L1518, L1524, L1527 |
| Ring of Doom | Opponent | L0215, L0711, L0815, L0931, L1115, L1415 |
| Ring of Jet | Mine | L1022, L1115 |
| Ring of Jet | Opponent | L0711 |
| Standard of the Fell Warrior | Opponent | L0313, L0613 |
| Storm Daemon (Renegade 2.0) | Opponent | L0621, L0921 |
| Twice-Blessed Armour | Mine | L0711, L0722, L1022 |
| Twice-Blessed Armour | Opponent | L0307 |
| Witch Hunter's Ward | Mine | L0711, L0722, L0815, L0819, L0822, L0826, L0829, L0834 |
| Witch Hunter's Ward | Opponent | L0307, L0308, L0608 |

# Doctrine scorecard: gf-h2h-opp-0533c46-p3

### Scorecard: gf-h2h-opp-0533c46-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0203 | 5 | 1 | Mine | yes | - | 4 | 0 | 5 | 0 | 0 | 0 | 170 |
| L0203 | 5 | 1 | Opponent | no | - | 3 | 0 | 0 | 0 | 0 | 0 | 760 |
| L0215 | 5 | 1 | Mine | yes | - | 2 | 2 | 4 | 1 | 0 | 0 | 0 |
| L0215 | 5 | 1 | Opponent | yes | - | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 1 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Opponent | - | - | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 675 |
| L0307 | 1 | 1 | Opponent | yes | 5 | 2 | 1 | 0 | 0 | 0 | 0 | 420 |
| L0308 | 2 | 1 | Mine | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 760 |
| L0308 | 2 | 1 | Opponent | - | - | - | 1 | 2 | 0 | 0 | 0 | 870 |
| L0313 | 1 | 1 | Mine | no | 7 | - | 1 | 0 | 0 | 0 | 0 | 675 |
| L0313 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 2 | 0 | 0 | 140 |
| L0332 | 2 | 1 | Mine | - | - | - | 1 | 0 | 1 | 0 | 0 | 360 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 1 | 5 | 1 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 4 | 2 | 7 | 1 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 3 | - | 0 | 1 | 0 | 0 | 0 | 886 |
| L0528 | 6 | 1 | Mine | no | 1 | 4 | 1 | 1 | 0 | 0 | 0 | 475 |
| L0528 | 6 | 1 | Opponent | no | 9 | 5 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0608 | 2 | 1 | Mine | - | - | 2 | 3 | 2 | 1 | 0 | 0 | 801 |
| L0608 | 2 | 1 | Opponent | - | - | 4 | 2 | 2 | 0 | 0 | 0 | 560 |
| L0613 | 1 | 1 | Mine | no | 0 | - | 1 | 2 | 0 | 0 | 0 | 720 |
| L0613 | 1 | 1 | Opponent | no | 0 | 3 | 1 | 1 | 1 | 0 | 0 | 302 |
| L0617 | 5 | 1 | Mine | no | - | 6 | 3 | 0 | 0 | 0 | 0 | 615 |
| L0617 | 5 | 1 | Opponent | yes | - | 4 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0621 | 3 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 1179 |
| L0621 | 3 | 1 | Opponent | yes | 8 | 2 | 1 | 4 | 1 | 0 | 0 | 555 |
| L0711 | 3 | 1 | Mine | yes | 3 | 2 | 2 | 0 | 0 | 0 | 0 | 420 |
| L0711 | 3 | 1 | Opponent | no | 0 | 2 | 0 | 0 | 1 | 0 | 0 | 330 |
| L0722 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 375 |
| L0722 | 2 | 1 | Opponent | - | - | 2 | 1 | 0 | 2 | 0 | 0 | 55 |
| L0815 | 5 | 1 | Mine | no | - | - | 0 | 0 | 0 | 0 | 0 | 515 |
| L0815 | 5 | 1 | Opponent | yes | - | 2 | 3 | 1 | 1 | 0 | 0 | 115 |
| L0819 | 3 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 805 |
| L0819 | 3 | 1 | Opponent | no | 2 | 2 | 1 | 2 | 2 | 0 | 0 | 0 |
| L0822 | 6 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 560 |
| L0822 | 6 | 1 | Opponent | no | 0 | 2 | 0 | 2 | 2 | 0 | 0 | 72 |
| L0826 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 762 |
| L0826 | 4 | 1 | Opponent | no | 4 | 2 | 2 | 5 | 1 | 0 | 0 | 0 |
| L0829 | 1 | 1 | Mine | no | 3 | - | 0 | 1 | 0 | 0 | 0 | 717 |
| L0829 | 1 | 1 | Opponent | no | 5 | 2 | 2 | 2 | 0 | 0 | 0 | 170 |
| L0834 | 6 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 515 |
| L0834 | 6 | 1 | Opponent | no | 2 | 2 | 4 | 3 | 1 | 0 | 0 | 0 |
| L0920 | 2 | 1 | Mine | - | - | 3 | 1 | 0 | 0 | 0 | 0 | 420 |
| L0920 | 2 | 1 | Opponent | - | - | - | 1 | 4 | 3 | 0 | 0 | 420 |
| L0921 | 3 | 1 | Mine | no | 3 | 6 | 1 | 2 | 0 | 0 | 0 | 420 |
| L0921 | 3 | 1 | Opponent | no | 1 | 5 | 2 | 5 | 0 | 0 | 0 | 290 |
| L0922 | 4 | 1 | Mine | no | 1 | 6 | 1 | 0 | 0 | 0 | 0 | 817 |
| L0922 | 4 | 1 | Opponent | no | 0 | 2 | 5 | 3 | 1 | 0 | 0 | 0 |
| L0931 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 420 |
| L0931 | 1 | 1 | Opponent | no | 0 | 6 | 2 | 0 | 3 | 0 | 0 | 170 |
| L1022 | 2 | 1 | Mine | - | - | 3 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1022 | 2 | 1 | Opponent | - | - | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1115 | 5 | 1 | Mine | yes | - | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1115 | 5 | 1 | Opponent | yes | - | 4 | 1 | 2 | 1 | 0 | 0 | 0 |
| L1415 | 5 | 1 | Mine | yes | - | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| L1415 | 5 | 1 | Opponent | no | - | 4 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Mine | no | 4 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 297 |
| L1518 | 6 | 1 | Mine | no | 9 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1518 | 6 | 1 | Opponent | no | 8 | 2 | 4 | 0 | 1 | 0 | 0 | 185 |
| L1524 | 6 | 1 | Mine | no | 4 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1524 | 6 | 1 | Opponent | no | 0 | 3 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Mine | yes | 4 | 3 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | yes | - | 5 | 3 | 3 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 1 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1829 | 5 | 1 | Mine | yes | - | 4 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1829 | 5 | 1 | Opponent | yes | - | 3 | 2 | 1 | 0 | 0 | 0 | 170 |
| L1834 | 4 | 1 | Mine | no | 0 | 2 | 2 | 0 | 1 | 0 | 0 | 185 |
| L1834 | 4 | 1 | Opponent | no | 3 | 2 | 2 | 1 | 0 | 0 | 0 | 500 |
| L2227 | 1 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | yes | 1 | 1 | 4 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 28% | 2.0 | 3.0 | 1.8 | 1.1 | 0.2 | 0.0 | 0.0 | 389.5 |
| **Average** | | | Opponent | 31% | 2.4 | 2.7 | 1.9 | 1.6 | 0.8 | 0.0 | 0.0 | 201.9 |

### KPIs: gf-h2h-opp-0533c46-p3

Rules off - Mine only: GUN FIGURES, GUN MASK, GUN VIEW, GUN THREAT, STAY WORTH, BEST MOVE FOR SHOOTERS, FACE THE CAST, WIZARD FRONT RANK, FIRE PLAN, FIRE IN ORDER, KEEPS THE TARGET, MISSILES IN THE FIRE PLAN, THREAT AT FULL SIZE, SHOOTERS ARE THREATS, SHOOTERS TO THE PRIMARY, EVERY WOUND COUNTS, HONEST THREAT, ONE YARDSTICK.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 45% (78 of 174) | 4% (7 of 180) | 24% (85 of 354) |
| Winner chose to follow up after the loser gave ground |  | 96% (55 of 57); on the table 98% | 100% (38 of 38); on the table 100% | 98% (93 of 95); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 83% (5 of 6); on the table 83% | 82% (9 of 11); on the table 82% | 82% (14 of 17); on the table 82% |
| Winner chose to pursue after the loser fled |  | 89% (16 of 18); on the table 94% | 81% (30 of 37); on the table 86% | 84% (46 of 55); on the table 89% |
| Winner chose to follow up or pursue (all three) |  | 94% (76 of 81); on the table 96% | 90% (77 of 86); on the table 92% | 92% (153 of 167); on the table 94% |
| Magic missiles tried each own turn | 50%+ | 30% (62 of 209) | 32% (56 of 175) | 31% (118 of 384) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 40% (62 of 156) | 44% (56 of 127) | 42% (118 of 283) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 21% (15 of 71) | 22% (21 of 96) | 22% (36 of 167) |
|     round 1 |  | 0% (0 of 12) | 12% (2 of 16) | 7% (2 of 28) |
|     rounds 2+ |  | 25% (15 of 59) | 24% (19 of 80) | 24% (34 of 139) |
|   other wizards | 50%+ | 34% (47 of 138) | 44% (34 of 78) | 38% (81 of 216) |
|     round 1 |  | 9% (2 of 23) | 31% (4 of 13) | 17% (6 of 36) |
|     rounds 2+ |  | 39% (45 of 115) | 46% (30 of 65) | 42% (75 of 180) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 44% (7 of 16) | 54% (32 of 59) | 52% (39 of 75) |
| Points that never fought | lower | 48% (33594 of 70695) | 48% (34284 of 71984) | 48% (67878 of 142679) |
|   infantry points that never fought | lower | 50% (7955 of 15862) | 62% (8539 of 13803) | 56% (16494 of 29665) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% (190 of 314) | 58% (154 of 267) | 59% (344 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 89% (17 of 19); 1.3 uses a game | 88% (15 of 17); 1.2 uses a game | 89% (32 of 36); 1.2 uses a game |
| Bound items with another spell used |  | 40% (6 of 15); 0.5 uses a game | 40% (2 of 5); 0.2 uses a game | 40% (8 of 20); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (10 of 20); 0.3 uses a game | 36% (4 of 11); 0.1 uses a game | 45% (14 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 57% (34240 of 60076) | 54% (33810 of 62051) | 56% (68050 of 122127) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.7 (41%) | 1.0 (29%) | 2.6 (36%) |
| MARCHED: its unit marched | 0.9 (22%) | 0.6 (19%) | 1.6 (21%) |
| CHARGED: its unit charged | 0.0 (1%) | 0.1 (2%) | 0.1 (1%) |
| IN COMBAT: engaged in combat | 1.2 (29%) | 0.4 (13%) | 1.6 (22%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (6%) | 0.2 (3%) |
| GONE: slain | 0.3 (7%) | 0.8 (25%) | 1.1 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.5 | 1.2 | 2.1 | 3.3 | 0.2 | 1.4 |
| not cast | 3.0 | 1.9 | 2.4 | 7.4 | 0.8 | 16.6 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.6 (30%) | 0.2 (9%) | 2.6 (36%) | 0.2 (25%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.6 (21%) | 0.2 (25%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (5%) | 0.1 (6%) | 0.5 (22%) | 1.6 (22%) | 0.2 (21%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (6%) | 0.4 (19%) | 0.4 (17%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.8 (27%) | 0.3 (17%) | 0.4 (15%) | 1.1 (15%) | 0.2 (25%) | 2.5 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (4%) | 0.1 (4%) | 0.1 (2%) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.4 (20%) | 0.0 (1%) | 0.0 (0%) | 0.0 (4%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (56%) | 0.1 (4%) | 0.8 (34%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.4 (75%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.8 a game | 1.0 a game |
| stood (cast and not dispelled) | 72% (23 of 32) | 60% (6 of 10) | 69% (29 of 42) |
| the unit moved after it | 65% (15 of 23) | 100% (6 of 6) | 72% (21 of 29) |
| it charged on its next turn | 4% (1 of 23) | 17% (1 of 6) | 7% (2 of 29) |
| the enemy charged it first | 9% (2 of 23) | 0% (0 of 6) | 7% (2 of 29) |
| it fought by the end of its next turn | 4% (1 of 23) | 0% (0 of 6) | 3% (1 of 29) |
| it moved out of a charge the enemy had planned (not charged first) | 13% (3 of 23) | 17% (1 of 6) | 14% (4 of 29) |
| none of these (no charge, no fight, no charge escaped) | 74% (17 of 23) | 67% (4 of 6) | 72% (21 of 29) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 67% (812 of 1217) | 63% (532 of 851) | 65% (1344 of 2068) |
|   cavalry | 68% (69 of 102) | 72% (75 of 104) | 70% (144 of 206) |
|   character | 57% (62 of 108) | 25% (35 of 142) | 39% (97 of 250) |
|   chariot | 57% (86 of 152) | 62% (54 of 87) | 59% (140 of 239) |
|   infantry | 51% (168 of 330) | 66% (244 of 367) | 59% (412 of 697) |
|   monster | 59% (41 of 70) | 71% (27 of 38) | 63% (68 of 108) |
|   war machine | 85% (386 of 455) | 86% (97 of 113) | 85% (483 of 568) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.7 (33%) | 1.6 (18%) | 5.3 (26%) |
| CHARGED: it charged | 1.0 (9%) | 1.8 (21%) | 2.9 (14%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.1 (2%) | 0.4 (2%) |
| IN COMBAT: it fought this turn or the last | 0.8 (7%) | 0.9 (10%) | 1.6 (8%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 2.1 (19%) | 1.7 (19%) | 3.8 (19%) |
| ONLY IN COMBAT: the only targets were in combat | 0.8 (7%) | 0.9 (10%) | 1.7 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.9 (17%) | 1.5 (17%) | 3.4 (17%) |
| SHELTERED: the target was sheltered | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.5 (4%) | 0.2 (3%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.5 | 2.1 | 79% | 6.4 pts | 48 pts |
| character | 3.2 | 0.8 | 81% | 5.6 pts | 18 pts |
| chariot | 3.9 | 3.0 | 58% | 20.6 pts | 81 pts |
| infantry | 15.6 | 6.6 | 70% | 9.7 pts | 152 pts |
| monster | 2.2 | 1.2 | 70% | 11.3 pts | 25 pts |
| war machine | 13.4 | 11.8 | 60% | 29.2 pts | 392 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.4 | 5.0 | 4.2 |
| Charges that made contact a game | 2.6 | 3.3 | 3.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.69 declared, 0.69 contact (13 units) | 0.50 declared, 0.35 contact (20 units) | 0.58 declared, 0.48 contact (33 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.83 declared, 0.67 contact (6 units) | 1.00 declared, 1.00 contact (6 units) | 0.92 declared, 0.83 contact (12 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.41 declared, 0.31 contact (261 units) | 0.59 declared, 0.38 contact (279 units) | 0.50 declared, 0.35 contact (540 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 41% (24 of 58) | 56% (10 of 18) | 38% (5 of 13) | 44% (39 of 89) |
| Character in a unit | 90% (38 of 42) | 70% (7 of 10) | 50% (1 of 2) | 85% (46 of 54) |
| Character on its own | 84% (26 of 31) | 40% (8 of 20) | 45% (27 of 60) | 55% (61 of 111) |
| Chariot | 75% (18 of 24) | 68% (17 of 25) | - | 71% (35 of 49) |
| Infantry | 53% (43 of 81) | 44% (12 of 27) | 56% (5 of 9) | 51% (60 of 117) |
| Monster | 55% (17 of 31) | 67% (6 of 9) | - | 58% (23 of 40) |
| Monstrous | 100% (5 of 5) | 61% (11 of 18) | - | 70% (16 of 23) |
| War Machines | 65% (60 of 93) | 80% (4 of 5) | - | 65% (64 of 98) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 3 | 100% (13 of 13); on the table 100% | 21% (9 of 42) | 35% | 83% (15 of 18) | 83% (5 of 6); 3.7 uses a game | 0.0 uses a game | 50% (3 of 6); 1.0 uses a game |
| Chaos Dwarfs | 6 | 100% (12 of 12); on the table 100% | 37% (20 of 54) | 56% | 69% (33 of 48) | 0.0 uses a game | 0.0 uses a game | 40% (2 of 5); 0.3 uses a game |
| Dwarfen Mountain Holds | 5 | 100% (4 of 4); on the table 100% | - | 75% | 64% (30 of 47) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 16 | 91% (21 of 23); on the table 96% | 45% (35 of 78) | 46% | 59% (100 of 170) | 0.0 uses a game | 100% (3 of 3); 0.6 uses a game | 55% (6 of 11); 0.4 uses a game |
| Grand Cathay | 3 | 82% (9 of 11); on the table 82% | 24% (16 of 66) | 47% | 65% (17 of 26) | 100% (6 of 6); 5.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| High Elf Realms | 11 | 96% (24 of 25); on the table 96% | 19% (8 of 42) | 38% | 53% (43 of 81) | 88% (14 of 16); 4.0 uses a game | 31% (5 of 16); 1.4 uses a game | 0.0 uses a game |
| Lizardmen | 1 | 100% (3 of 3); on the table 100% | - | 57% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 5 | 93% (13 of 14); on the table 93% | 8% (1 of 12) | 41% | 63% (22 of 35) | 80% (4 of 5); 1.4 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (5 of 5); on the table 100% | 0% (0 of 12) | 30% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 3 | 100% (5 of 5); on the table 100% | 33% (6 of 18) | 70% | 48% (12 of 25) | 100% (2 of 2); 2.7 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Tomb Kings of Khemri | 7 | 90% (19 of 21); on the table 95% | 33% (4 of 12) | 41% | 49% (17 of 35) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 4 | 72% (13 of 18); on the table 78% | 33% (12 of 36) | 32% | 58% (14 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 5 | 89% (8 of 9); on the table 100% | 58% (7 of 12) | 52% | 56% (23 of 41) | 100% (1 of 1); 0.8 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 2 | 100% (4 of 4); on the table 100% | - | 63% | 56% (9 of 16) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gf-h2h-opp-0533c46-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 46% (30) | 39% (16) | 43% (46) |
| ...free all their last turn and able to turn (per game) | 0.42 | 0.22 | 0.64 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.28 | 0.08 | 0.36 |
| ...with the charger already in that arc before they moved (per game) | 0.39 | 0.22 | 0.61 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.00 | 1.08 | 3.08 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.25 | 0.67 | 1.92 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.28 | 5.75 | 11.03 |

### Quality by phase: gf-h2h-opp-0533c46-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.7 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 56% (60 of 107) | 46% (67 of 145) |
| Strategy | Shoot objectives carried out (shot that target) | 47% (239 of 513) | 39% (129 of 330) |
| Strategy | Close-in objectives charged next turn | 15% (19 of 126) | 15% (36 of 233) |
| Strategy | Support requests answered (helper made contact too) | 61% (14 of 23) | 30% (11 of 37) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | 75% (3 of 4) |
| Strategy | Hexes on a unit its side charged or shot that turn | 82% (9 of 11) | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 46% (28 of 61) | 32% (10 of 31) |
| Strategy | Lone characters that fought | 54% (40 of 74) | 64% (58 of 90) |
| Movement | Charges halted short of contact | 0.0 | 0.2 |
| Movement | Idle units | 1.1 | 1.6 |
| Movement | Points that never moved of their own | 389.5 | 201.9 |
| Movement | Fights charged into per game | 2.2 | 2.8 |
| Movement | Charges with odds: long shots (under 50%) | 8 of 71, net +136 | 12 of 85, net +75 |
| Movement | Charges with odds: sweet spot (55-75%) | 6 of 71, net +111 | 18 of 85, net +86 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 11 of 71, net +95 | 6 of 85, net +63 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 26 of 71, net +58 | 26 of 85, net +194 |
| Shooting | Shots by shooting units (incl. breath weapons) | 12.6 | 14.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 49% (225 of 455) | 34% (172 of 504) |
| Shooting | Points destroyed by shooting units | 196.0 | 48.4 |
| Shooting | War machine shots | 10.7 | 2.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 60% (233 of 386) | 43% (42 of 97) |
| Shooting | Points destroyed by war machines | 156.6 | 42.9 |
| Magic | Magic missiles cast | 0.9 | 0.8 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 39% (12 of 31) | 33% (10 of 30) |
| Magic | Wounds caused by magic missiles | 2.5 | 0.7 |
| Magic | Wounds caused by other spells | 1.5 | 0.6 |
| Magic | Points destroyed by magic (all spells) | 43.1 | 16.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.9 / 0.5 / 0.7 / 0.1 | 1.8 / 0.1 / 0.4 / 0.0 |
| Combat | Points destroyed in combat | 212.9 | 287.0 |
| Combat | Points run down | 59.3 | 76.1 |
| Combat | Net points per charged fight, damage counted | +78 | +89 |
| Combat | Net per 100 charger points, damage counted | +30.8 | +30.0 |
| Combat | First round won (charged fights) | 79% | 74% |
| Combat | Net points per charged fight | +78 | +101 |
| Combat | Net points per supported fight / lone fight | +64 / +81 | +119 / +97 |
| Combat | Charged fights on a top-3 enemy unit | 16 of 80 | 49 of 102 |
| Game | Points lost | 622.5 | 764.8 |
| Game | VP from objectives | 605.0 | 550.0 |
| Game | Lone holders (player turns) | 2.0 | 2.4 |

- Mine won / drew / lost: 17 / 7 / 12 of 36 ended games (of 36); mean margin (Mine - Opponent) +215 VP
- The side that went first won 12 of 29 games with a winner
- Points traded per game (both sides' losses): 1387
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: gf-h2h-opp-0533c46-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ARRIVAL HUNT | - | - | - | - | 0.2 | +1.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.8 | +0.0 | 0.0 | 35.0 | 0.6 | +0.0 | 0.0 | 10.4 |
| BACKUP TARGETS | 0.9 | +6.0 | 0.0 | 13.9 | 1.2 | +10.1 | 0.0 | 52.5 |
| BEST FACING | 0.9 | +46.6 | 0.0 | 31.8 | 0.6 | +20.1 | 0.0 | 32.5 |
| BEST FIRST | 4.3 | +163.1 | 193.7 | 66.1 | 4.3 | +151.9 | 74.7 | 49.9 |
| BEST MOVE FOR SHOOTERS | - | - | - | - | 0.9 | +63.5 | 0.0 | 13.1 |
| BEST OVERALL | 0.9 | +71.4 | 0.0 | 20.2 | 0.7 | +47.9 | 0.0 | 17.4 |
| BEST PREY | 0.8 | +23.9 | 28.6 | 14.0 | 1.0 | +50.8 | 37.5 | 8.1 |
| BEST PRIZE | 0.1 | -1.8 | 0.0 | 0.0 | 0.2 | -23.6 | 16.6 | 17.6 |
| BIG CHARACTER SAFETY | 0.1 | +0.1 | 0.0 | 0.0 | 0.2 | -0.8 | 0.0 | 27.3 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 1.1 |
| BLOCKED WHEEL | 0.4 | +5.4 | 0.0 | 8.3 | 0.5 | +14.2 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.2 | -12.9 | 16.4 | 0.0 | 0.2 | -2.1 | 29.9 | 15.6 |
| BOMBING RUN | - | - | - | - | 0.0 | +0.7 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.9 | +0.0 | 123.7 | 22.6 | - | - | - | - |
| CANNON PLANNED TARGET | 8.2 | +328.8 | 772.1 | 176.7 | - | - | - | - |
| CANNON SIGHT KEPT | 1.4 | +0.0 | 0.0 | 6.4 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | -5.2 | 2.9 | 0.0 |
| CARRIES OUT SET-UP | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | -8.4 | 15.8 | 1.7 |
| CAST JOB | 0.9 | +26.9 | 45.8 | 4.7 | 0.7 | +12.1 | 11.5 | 22.1 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +15.8 | 5.4 | 0.0 | 0.1 | +2.6 | 4.3 | 0.0 |
| CASTS AFTER FRIENDS | 0.9 | +0.0 | 0.0 | 29.6 | 0.4 | +0.0 | 0.0 | 9.1 |
| CASTS FROM BEHIND | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +3.2 | 0.0 | 7.5 | 0.0 | +0.7 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -1.3 | 11.0 | 0.0 | - | - | - | - |
| CHARGE BAND | 0.2 | +0.0 | 31.8 | 0.0 | 0.3 | +0.0 | 20.4 | 10.2 |
| CHARGE NOW FIRST | 1.5 | +0.0 | 149.4 | 30.3 | 2.2 | +0.0 | 193.8 | 51.7 |
| CHARGE NOW WEIGHED | 0.5 | -34.3 | 15.8 | 15.0 | 0.6 | -75.2 | 18.7 | 34.2 |
| CHARGER SLAIN LOST | 0.4 | -10.3 | 21.3 | 14.4 | 0.7 | -10.6 | 85.9 | 6.5 |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.2 | 0.0 | 0.0 | 0.2 | -4.4 | 0.0 | 15.0 |
| CHEAP HELPER | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.4 | +0.0 | 4.2 | 13.8 | 0.8 | +0.0 | 33.4 | 59.7 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.9 | +114.0 | 10.6 | 16.0 | 0.1 | +8.9 | 34.5 | 22.2 |
| COUNTER-CHARGE COVER | 10.7 | +1212.6 | 0.0 | 271.5 | 9.0 | +822.4 | 0.0 | 193.3 |
| DEFENSIVE ARMY | 0.3 | +0.0 | 45.6 | 2.9 | - | - | - | - |
| EDGE GIVE GROUND | - | - | - | - | 0.1 | +3.5 | 7.6 | 0.0 |
| ENGINEER BY LORE | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| EVERY WOUND COUNTS | - | - | - | - | 11.1 | +0.0 | 315.9 | 186.2 |
| FACE THE CAST | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| FACES THE THREAT | 2.0 | +162.4 | 0.0 | 77.3 | 1.1 | +82.1 | 0.0 | 53.6 |
| FALLBACK BY WORTH | 5.3 | +78.6 | 0.0 | 81.2 | 6.2 | +69.5 | 0.0 | 35.4 |
| FIGHT LIFT | 0.1 | +0.3 | 7.2 | 0.0 | 0.1 | +0.7 | 1.7 | 0.0 |
| FIRE AND FLEE | 0.0 | +0.1 | 0.0 | 0.0 | 0.1 | +2.5 | 0.0 | 2.9 |
| FIRE IN ORDER | - | - | - | - | 0.8 | +0.0 | 46.0 | 0.0 |
| FIRE PLAN | - | - | - | - | 16.6 | +108.4 | 479.0 | 338.1 |
| FLANK NOT WEIGHED | 5.5 | +0.0 | 0.0 | 132.8 | 5.8 | +0.0 | 0.0 | 125.7 |
| FOLLOW UP WEIGHED | 1.0 | +137.0 | 0.0 | 0.0 | 0.7 | +99.8 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.3 | +12.7 | 0.0 | 14.8 | 0.3 | +17.0 | 0.0 | 14.6 |
| GIVES UP | - | - | - | - | 0.1 | -1.0 | 0.0 | 0.0 |
| GIVES UP ITS SCREEN | 0.0 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| GROUND FLIERS | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | - | - | - | - | 2.4 | +28.6 | 67.9 | 32.4 |
| GUN MASK | - | - | - | - | 0.3 | +3.0 | 0.0 | 5.9 |
| GUN THREAT | - | - | - | - | 0.8 | +82.0 | 50.0 | 26.8 |
| GUN VIEW | - | - | - | - | 0.6 | +5.0 | 0.0 | 5.1 |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 4.2 | 1.7 | 0.1 | +0.0 | 21.6 | 0.0 |
| HELPER UNSEEN | 0.1 | +0.0 | 6.6 | 3.8 | 0.5 | +0.0 | 9.3 | 16.5 |
| HILL BY ITS CHANCE | 0.3 | -45.5 | 0.0 | 2.9 | 0.4 | -34.3 | 0.0 | 3.1 |
| HOLDS AMBUSHERS | 0.2 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST THREAT | - | - | - | - | 11.1 | +1751.7 | 315.9 | 186.2 |
| HONEST WORTH | 6.9 | -118.5 | 340.4 | 136.4 | 8.7 | -181.9 | 329.9 | 164.8 |
| HUNT ADVANCE | 0.2 | +1.7 | 9.2 | 2.9 | 0.4 | +24.1 | 4.6 | 16.9 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 1.4 | 0.1 | +0.0 | 3.5 | 3.2 |
| HUNT IN PAIRS | 0.1 | +3.1 | 0.0 | 0.0 | 0.8 | +21.2 | 0.0 | 22.1 |
| HUNT KEPT | 0.1 | +0.0 | 3.1 | 2.4 | 0.2 | +9.7 | 4.6 | 7.9 |
| HUNT RESULT | 0.2 | +21.8 | 0.0 | 8.1 | 0.3 | +35.0 | 12.6 | 19.4 |
| HUNT THE GUNS | 0.2 | +52.1 | 15.3 | 4.3 | 0.3 | +140.2 | 17.4 | 12.0 |
| INVITES THE FIGHT | 2.1 | +34.9 | 104.5 | 32.2 | 1.4 | +17.3 | 29.0 | 0.0 |
| JOINT CHARGE PLAN | 0.1 | +2.9 | 9.6 | 1.7 | 0.1 | +4.5 | 7.4 | 7.4 |
| JOINT KNOWS CHALLENGE | 0.1 | -0.9 | 19.9 | 0.0 | 0.1 | -3.6 | 0.0 | 0.0 |
| KEEP FALLS | 0.1 | +3.6 | 0.0 | 7.5 | - | - | - | - |
| KEEPS ITS PREY | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.5 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.4 | +43.3 | 136.9 | 20.9 | 1.7 | +51.7 | 118.5 | 72.5 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS THE TARGET | - | - | - | - | 1.2 | -28.3 | 48.4 | 38.6 |
| KILLS COUNT | 1.4 | +47.6 | 82.5 | 25.7 | 1.5 | +69.0 | 103.8 | 47.1 |
| KILLS COUNT NEXT TURN | 4.4 | +98.4 | 159.8 | 59.4 | 7.1 | +267.2 | 211.3 | 231.2 |
| LONE CHARACTER SAFE SPOT | 0.7 | +16.2 | 10.3 | 4.9 | 0.3 | +17.6 | 21.2 | 29.8 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.1 | +0.0 | 11.0 | 5.4 |
| LONE WIZARD KEPT IN | 0.6 | +33.8 | 0.0 | 0.0 | 0.5 | +44.3 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | -0.3 | 26.1 | 8.5 | 0.6 | -9.2 | 28.6 | 3.1 |
| LOST CHARGE | 3.3 | -62.7 | 110.8 | 102.1 | 1.7 | -28.2 | 29.7 | 84.0 |
| LURE BY WHAT IT DRAWS | 0.0 | +0.0 | 0.0 | 1.1 | 0.1 | -1.5 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.5 | +34.4 | 22.8 | 12.3 | 0.8 | +36.5 | 14.7 | 39.8 |
| MANOEUVRE | 0.2 | +6.4 | 0.0 | 3.2 | 0.3 | +11.7 | 0.0 | 3.2 |
| MARCH AT ESCAPER | 0.2 | +1.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.6 | +37.6 | 0.0 | 6.9 | 0.4 | +12.6 | 0.0 | 0.0 |
| MARCH ODDS | 0.3 | +14.0 | 20.3 | 6.9 | 0.3 | +14.0 | 5.1 | 26.1 |
| MARCH OVER CASTS | 0.5 | +44.7 | 0.0 | 25.2 | 0.5 | +50.3 | 0.0 | 11.0 |
| MAX FOR POSITIONING | 4.5 | +173.4 | 0.0 | 138.6 | 5.3 | +227.1 | 0.0 | 139.6 |
| MISSILES IN THE FIRE PLAN | - | - | - | - | 0.9 | +4.6 | 27.2 | 38.3 |
| MISSILES IN THE MOVE | 3.3 | +89.0 | 0.0 | 51.2 | 3.2 | +50.0 | 0.0 | 131.9 |
| MISSILES NEXT TURN | 3.9 | +70.1 | 0.0 | 81.0 | 4.0 | +36.8 | 0.0 | 116.7 |
| MODEL FACING | 0.3 | +98.2 | 0.0 | 11.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.3 | +11.4 | 0.0 | 0.0 | 0.3 | +9.4 | 0.0 | 23.9 |
| MOVE SPELL IN RANGE | 0.2 | +5.5 | 0.0 | 2.4 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.5 | -20.1 | 0.0 | 13.6 | - | - | - | - |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 16.2 | 0.1 | +0.0 | 0.0 | 12.3 |
| MOVE TO CHARGE | 2.8 | +138.3 | 87.9 | 51.7 | 4.6 | +402.4 | 70.5 | 130.5 |
| MOVES UNITS SPELL | 0.2 | +5.2 | 0.0 | 0.0 | 0.1 | +0.9 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO RALLY LEFT | 0.1 | +1.5 | 0.0 | 0.0 | 0.1 | -0.0 | 0.0 | 3.5 |
| NOT NEEDED | 0.3 | -20.0 | 32.5 | 6.2 | 0.2 | -8.8 | 40.8 | 0.0 |
| NOT TURNED | 5.3 | +87.5 | 0.0 | 101.8 | 5.8 | +79.2 | 0.0 | 135.3 |
| NOT WORTH A CAST | 0.6 | -0.5 | 0.0 | 0.0 | 0.1 | -0.2 | 0.0 | 11.0 |
| OFF BEST | 16.1 | -809.5 | 11.4 | 301.1 | 15.3 | -757.4 | 8.0 | 305.0 |
| ONE YARDSTICK | - | - | - | - | 16.4 | -553.5 | 247.9 | 354.1 |
| OPENS A LANE | 0.2 | +1.1 | 20.9 | 0.0 | 0.0 | +0.0 | 2.4 | 0.0 |
| OPENS UP | 0.2 | +10.6 | 5.1 | 0.0 | 0.1 | +5.5 | 3.1 | 0.0 |
| OVERRUNS AWAY | 0.4 | +12.0 | 43.3 | 17.1 | 0.5 | +5.1 | 36.3 | 17.3 |
| PATHS CROSS | 1.8 | +116.5 | 0.0 | 33.3 | 2.8 | +231.8 | 0.0 | 19.2 |
| PERIAPT WORTH | - | - | - | - | 0.1 | +8.4 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.1 | -2.9 | 0.0 | 5.4 |
| PLAN RESULT | 39.7 | +1746.3 | 1830.2 | 880.6 | 40.2 | +1020.7 | 1267.1 | 1217.1 |
| PURSUES BIG PREY | - | - | - | - | 0.1 | -7.3 | 0.0 | 16.6 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.0 | +2.4 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.4 | +5.1 | 0.0 | 4.7 | 1.6 | +16.6 | 0.0 | 70.8 |
| RANDOM MOVER NO PROMISE | 0.1 | -1.4 | 3.5 | 0.0 | 0.3 | -15.5 | 10.6 | 4.0 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -6.4 | 0.0 | 1.9 | 0.3 | -5.5 | 0.0 | 1.7 |
| REDIRECT COUNTER | 2.2 | +139.5 | 0.0 | 32.0 | 3.1 | +263.3 | 0.0 | 48.2 |
| REDIRECT WEIGHED | 0.2 | +0.6 | 0.0 | 5.8 | 0.4 | -7.9 | 25.5 | 2.7 |
| REFUSING RETIRES | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 11.9 |
| RESERVE FALL BACK | 0.4 | +19.8 | 0.0 | 5.8 | 1.0 | +20.5 | 0.0 | 8.9 |
| RESTRAINS TO SHOOT | 0.1 | +3.4 | 0.0 | 11.0 | 0.1 | +3.9 | 0.0 | 4.0 |
| RISK BY ARC | 1.9 | +66.9 | 167.0 | 44.0 | 2.2 | +51.9 | 166.9 | 41.2 |
| SAFE SURE CHARGE | 0.0 | -1.7 | 1.1 | 0.0 | 0.0 | -8.3 | 0.0 | 0.0 |
| SAFER THAN THE JOB | 1.2 | +88.4 | 0.0 | 40.5 | 0.7 | +37.0 | 0.0 | 50.1 |
| SCOUT SPOT | 0.5 | +1.7 | 0.0 | 0.0 | 0.6 | +2.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.6 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -7.7 | 0.0 | 0.0 | 0.4 | -21.6 | 0.0 | 5.7 |
| SEARCH SPOT | 2.6 | +162.3 | 0.0 | 44.1 | 3.0 | +134.4 | 0.0 | 6.9 |
| SECOND HUNTER | 0.1 | -0.7 | 9.2 | 2.9 | - | - | - | - |
| SELF MOVE SPELL | 0.5 | +93.9 | 0.0 | 21.9 | 0.6 | +124.3 | 0.0 | 29.1 |
| SET UP TOGETHER | 0.9 | +52.4 | 22.8 | 12.3 | 1.9 | +183.2 | 14.7 | 79.8 |
| SET-UP ANY TARGET | 0.2 | +43.0 | 2.4 | 2.4 | 0.1 | +5.3 | 11.1 | 11.1 |
| SET-UP MISSED | 0.0 | +0.4 | 2.4 | 2.4 | - | - | - | - |
| SHOOTER COUNTED ONCE | 0.0 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ARE THREATS | - | - | - | - | 6.0 | +378.5 | 166.0 | 81.6 |
| SHOOTERS IN TWO RANKS | 0.5 | +0.9 | 0.0 | 0.0 | 0.3 | +0.4 | 0.0 | 0.0 |
| SHOOTERS TO THE PRIMARY | - | - | - | - | 3.0 | +47.8 | 0.0 | 51.0 |
| SHOOTS FROM THE BEST SPOT | 0.9 | +40.9 | 60.7 | 11.5 | 1.3 | +47.4 | 32.1 | 50.4 |
| SHORT GUN FORWARD | 0.5 | +0.0 | 0.0 | 3.3 | 0.1 | +0.0 | 0.0 | 0.0 |
| SHOT OPTIONS | 22.8 | +0.0 | 1681.7 | 463.5 | 15.9 | +0.0 | 403.2 | 301.6 |
| SHOT REPLANNED | 1.3 | +0.0 | 272.8 | 19.6 | - | - | - | - |
| SHOTS IN THE MOVE | 20.3 | +963.2 | 0.0 | 407.1 | 14.7 | +496.8 | 0.0 | 253.9 |
| SPELL CATCH ODDS | 0.1 | -1.3 | 0.0 | 2.4 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.3 | +49.8 | 2.4 | 2.4 | 0.1 | +5.3 | 11.1 | 11.1 |
| SPELL WORTH | 0.7 | +12.4 | 34.4 | 27.2 | 1.7 | +47.0 | 121.6 | 120.0 |
| SPELLS IN THE FIGHT | 0.3 | +2.5 | 39.7 | 4.2 | 0.3 | -1.0 | 35.5 | 1.7 |
| STABLE ROLE | 12.2 | +0.0 | 476.6 | 208.4 | 9.9 | +0.0 | 182.1 | 140.2 |
| STANDS TO CAST | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| STAY WORTH | - | - | - | - | 16.2 | +129.8 | 157.6 | 219.0 |
| STOPS | 0.1 | +0.8 | 6.1 | 1.4 | 0.1 | +3.2 | 17.4 | 1.5 |
| STOPS SHORT OF THE FLANK | 0.5 | +25.0 | 0.0 | 16.0 | 0.3 | +15.8 | 0.0 | 12.6 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 5.8 |
| SUPPORT NARROWED | 4.4 | -37.1 | 216.4 | 99.6 | 5.8 | -29.2 | 231.1 | 79.9 |
| SUPPORTS | 3.3 | +41.9 | 119.4 | 68.8 | 3.5 | +29.2 | 100.7 | 43.3 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -2.1 | 7.3 | 4.0 | 0.1 | -10.4 | 2.9 | 0.0 |
| SURE REACH TOGETHER | 0.6 | +1.3 | 19.7 | 9.2 | 0.7 | +0.1 | 5.6 | 20.6 |
| THROUGH LINE OF FIRE | 0.7 | +28.0 | 0.0 | 12.3 | 0.4 | +9.8 | 0.0 | 5.9 |
| TURN WORTH | 0.2 | -14.1 | 11.1 | 7.9 | 0.2 | -6.8 | 17.7 | 1.7 |
| TWO OR MORE ARRIVE | 0.3 | +2.3 | 19.3 | 4.9 | 0.7 | +3.8 | 0.0 | 33.9 |
| WAIT AFTER COSTS | 6.8 | -294.7 | 286.2 | 118.8 | 7.9 | -426.3 | 151.7 | 181.3 |
| WALKS TO THE FIGHT | 1.5 | +20.2 | 54.9 | 35.2 | 0.7 | +12.1 | 14.1 | 0.0 |
| WAR ENGINE CHARGES | 0.1 | +4.0 | 3.5 | 5.1 | - | - | - | - |
| WAR ENGINE JOBS | 0.6 | +0.0 | 26.3 | 31.2 | 0.3 | +0.0 | 0.0 | 9.3 |
| WEARS DOWN | 0.8 | +24.0 | 97.4 | 29.5 | 1.0 | +31.7 | 92.5 | 5.3 |
| WHO HITS BACK | 0.2 | +29.3 | 0.0 | 4.2 | 0.1 | +5.5 | 0.0 | 1.7 |
| WHOLE FIGHT | 0.1 | +6.0 | 21.6 | 0.0 | 0.5 | +35.9 | 49.1 | 4.0 |
| WHOLE FIGHT GAIN | 0.5 | +34.5 | 49.2 | 15.5 | 0.9 | +57.3 | 72.9 | 6.4 |
| WIDER SPREAD | 1.8 | -6.5 | 138.4 | 49.1 | 2.8 | -5.2 | 239.3 | 43.5 |
| WIZARD FRONT RANK | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |

### Rule changes: gf-h2h-opp-0533c46-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1131 | 1131 | 1131 | 31.42 | -56409 | -49.9 |
| BEST FIRST | 311 | 311 | 311 | 8.64 | +11336 | +36.5 |
| SEARCH SPOT | 202 | 202 | 198 | 5.50 | +10689 | +54.0 |
| COUNTER-CHARGE COVER | 708 | 411 | 186 | 5.17 | +14604 | +78.5 |
| FIRE PLAN | 597 | 597 | 171 | 4.75 | +2712 | +15.9 |
| PATHS CROSS | 165 | 165 | 165 | 4.58 | +12541 | +76.0 |
| MOVE TO CHARGE | 264 | 264 | 138 | 3.83 | +6073 | +44.0 |
| KILLS COUNT NEXT TURN | 411 | 411 | 133 | 3.69 | +3357 | +25.2 |
| SHOTS IN THE MOVE | 1262 | 876 | 125 | 3.47 | +3488 | +27.9 |
| EVERY WOUND COUNTS | 399 | 399 | 124 | 3.44 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 122 | 122 | 122 | 3.39 | +0 | +0.0 |
| FACES THE THREAT | 111 | 111 | 111 | 3.08 | +8803 | +79.3 |
| FALLBACK BY WORTH | 412 | 412 | 97 | 2.69 | +5329 | +54.9 |
| SUPPORTS | 246 | 246 | 76 | 2.11 | +582 | +7.7 |
| SAFER THAN THE JOB | 69 | 69 | 69 | 1.92 | +4514 | +65.4 |
| WAIT AFTER COSTS | 526 | 526 | 65 | 1.81 | +1447 | +22.3 |
| CANNON SIGHT KEPT | 62 | 62 | 62 | 1.72 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 60 | 60 | 60 | 1.67 | +8522 | +142.0 |
| BEST OVERALL | 59 | 59 | 59 | 1.64 | +4293 | +72.8 |
| BEST FACING | 56 | 56 | 56 | 1.56 | +2401 | +42.9 |
| REDIRECT COUNTER | 192 | 115 | 55 | 1.53 | +5022 | +91.3 |
| RESERVE FALL BACK | 50 | 50 | 50 | 1.39 | +1451 | +29.0 |
| SET UP TOGETHER | 102 | 87 | 50 | 1.39 | +3236 | +64.7 |
| MAX FOR POSITIONING | 352 | 214 | 49 | 1.36 | +859 | +17.5 |
| HONEST THREAT | 399 | 399 | 48 | 1.33 | +0 | +0.0 |
| SHOT REPLANNED | 48 | 48 | 48 | 1.33 | +0 | +0.0 |
| WALKS TO THE FIGHT | 77 | 77 | 48 | 1.33 | +587 | +12.2 |
| ONE YARDSTICK | 590 | 226 | 47 | 1.31 | +541 | +11.5 |
| SCOUT WAITS | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| ADVANCE LANE KEPT | 41 | 41 | 41 | 1.14 | +0 | +0.0 |
| COMBAT PIVOT | 41 | 41 | 41 | 1.14 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 41 | 41 | 41 | 1.14 | +2813 | +68.6 |
| RANDOM MOVE BY FIGURES | 75 | 75 | 39 | 1.08 | +779 | +20.0 |
| THROUGH LINE OF FIRE | 39 | 39 | 39 | 1.08 | +1360 | +34.9 |
| CHARGE NOW WEIGHED | 37 | 37 | 37 | 1.03 | +2766 | +74.8 |
| SHOOTS FROM THE BEST SPOT | 79 | 79 | 37 | 1.03 | +1020 | +27.6 |
| BLOCKED WHEEL | 34 | 34 | 34 | 0.94 | +704 | +20.7 |
| CANNON PLANNED TARGET | 295 | 295 | 34 | 0.94 | -547 | -16.1 |
| SHOOTERS ARE THREATS | 215 | 215 | 33 | 0.92 | +0 | +0.0 |
| BEST MOVE FOR SHOOTERS | 31 | 31 | 31 | 0.86 | +2286 | +73.7 |
| CAST JOB | 59 | 59 | 31 | 0.86 | +481 | +15.5 |
| HONEST WORTH | 560 | 551 | 31 | 0.86 | +283 | +9.1 |
| FIRE IN ORDER | 30 | 30 | 30 | 0.83 | +0 | +0.0 |
| MISSILES IN THE MOVE | 234 | 150 | 30 | 0.83 | +729 | +24.3 |
| MARCH CHECK | 36 | 32 | 29 | 0.81 | +1892 | +65.2 |
| SHOOTERS IN TWO RANKS | 29 | 29 | 29 | 0.81 | +48 | +1.7 |
| STOPS SHORT OF THE FLANK | 29 | 29 | 29 | 0.81 | +1471 | +50.7 |
| HOLDS AMBUSHERS | 28 | 28 | 28 | 0.78 | +0 | +0.0 |
| KILLS COUNT | 104 | 99 | 26 | 0.72 | +1177 | +45.3 |
| CHARGE NOW FIRST | 132 | 132 | 24 | 0.67 | -1112 | -46.3 |
| FRIENDS SHOTS CHECKED | 24 | 24 | 24 | 0.67 | +1070 | +44.6 |
| RISK BY ARC | 147 | 139 | 24 | 0.67 | +884 | +36.8 |
| STAY WORTH | 584 | 453 | 23 | 0.64 | +284 | +12.4 |
| WHOLE FIGHT GAIN | 50 | 48 | 21 | 0.58 | +734 | +34.9 |
| MARCH ODDS | 20 | 20 | 20 | 0.56 | +140 | +7.0 |
| MOVE AND CAST | 20 | 20 | 20 | 0.56 | +749 | +37.5 |
| REDIRECT WEIGHED | 20 | 20 | 20 | 0.56 | +746 | +37.3 |
| SHORT GUN FORWARD | 20 | 20 | 20 | 0.56 | +0 | +0.0 |
| BEST PREY | 64 | 64 | 19 | 0.53 | +704 | +37.0 |
| CHARGE BAND | 19 | 19 | 19 | 0.53 | +0 | +0.0 |
| MAKE SURE TOGETHER | 48 | 35 | 19 | 0.53 | +933 | +49.1 |
| INVITES THE FIGHT | 128 | 128 | 18 | 0.50 | +225 | +12.5 |
| KEEPS THE TARGET | 44 | 44 | 18 | 0.50 | -1652 | -91.8 |
| KEEPS ITS TARGET | 114 | 109 | 16 | 0.44 | +255 | +16.0 |
| MANOEUVRE | 21 | 21 | 16 | 0.44 | +649 | +40.5 |
| CASTER AWAY FROM SCREEN | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| LOST CHARGE | 180 | 179 | 12 | 0.33 | +384 | +32.0 |
| MODEL FACING | 12 | 12 | 12 | 0.33 | +3534 | +294.5 |
| BIG CHARACTER SAFETY | 11 | 11 | 11 | 0.31 | -27 | -2.5 |
| GUN VIEW | 20 | 20 | 11 | 0.31 | +156 | +14.2 |
| MOVES UNITS SPELL | 11 | 11 | 11 | 0.31 | +221 | +20.1 |
| WHO HITS BACK | 10 | 10 | 10 | 0.28 | +911 | +91.1 |
| BEST PRIZE | 9 | 9 | 9 | 0.25 | -933 | -103.7 |
| CASTING BLOCK | 13 | 13 | 9 | 0.25 | +292 | +32.4 |
| WAR ENGINE JOBS | 31 | 31 | 9 | 0.25 | -660 | -73.3 |
| WEARS DOWN | 65 | 61 | 9 | 0.25 | +353 | +39.2 |
| CHAFF PASSED | 8 | 8 | 8 | 0.22 | -47 | -5.9 |
| RESTRAINS TO SHOOT | 8 | 8 | 8 | 0.22 | +262 | +32.7 |
| SUPPORT NARROWED | 366 | 366 | 8 | 0.22 | -48 | -6.1 |
| REFUSING RETIRES | 23 | 23 | 7 | 0.19 | -4 | -0.6 |
| STUCK PIVOT | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| BLOCKED CHARGE SKIPPED | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| SURE REACH TOGETHER | 46 | 35 | 6 | 0.17 | +45 | +7.5 |
| CARRIES OUT SET-UP | 8 | 8 | 5 | 0.14 | -304 | -60.8 |
| CASTS FROM BEHIND | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| HUNT ADVANCE | 21 | 21 | 5 | 0.14 | +244 | +48.8 |
| OPENS UP | 10 | 10 | 5 | 0.14 | +105 | +20.9 |
| SHOOTERS TO THE PRIMARY | 109 | 76 | 5 | 0.14 | +23 | +4.7 |
| SURE CHARGE BEATS ADVANCE | 5 | 5 | 5 | 0.14 | -450 | -90.0 |
| KEEP FALLS | 4 | 4 | 4 | 0.11 | +243 | +60.7 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| NO RALLY LEFT | 4 | 4 | 4 | 0.11 | +43 | +10.8 |
| PIVOT GUARDS FLANK | 4 | 4 | 4 | 0.11 | -105 | -26.3 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.08 | +93 | +31.0 |
| GUN THREAT | 28 | 28 | 3 | 0.08 | +0 | +0.0 |
| HUNT IN PAIRS | 29 | 18 | 3 | 0.08 | +128 | +42.6 |
| JOINT CHARGE PLAN | 9 | 9 | 3 | 0.08 | +157 | +52.3 |
| LONG SHOT | 35 | 33 | 3 | 0.08 | +60 | +20.2 |
| MISSILES NEXT TURN | 286 | 178 | 3 | 0.08 | +15 | +5.0 |
| PERIAPT WORTH | 3 | 3 | 3 | 0.08 | +302 | +100.7 |
| PURSUES BIG PREY | 3 | 3 | 3 | 0.08 | -264 | -88.1 |
| TWO OR MORE ARRIVE | 36 | 31 | 3 | 0.08 | +13 | +4.4 |
| WHOLE FIGHT | 22 | 19 | 3 | 0.08 | +318 | +105.9 |
| BACKUP TARGETS | 73 | 32 | 2 | 0.06 | +3 | +1.5 |
| CARRIES OUT COUNTER | 3 | 3 | 2 | 0.06 | -187 | -93.6 |
| MISSILES IN THE FIRE PLAN | 32 | 5 | 2 | 0.06 | +4 | +1.8 |
| OVERRUNS AWAY | 33 | 32 | 2 | 0.06 | +60 | +30.1 |
| SAFE SURE CHARGE | 2 | 2 | 2 | 0.06 | -436 | -217.8 |
| SPELLS IN THE FIGHT | 24 | 21 | 2 | 0.06 | +12 | +6.2 |
| WAR ENGINE CHARGES | 2 | 2 | 2 | 0.06 | +37 | +18.6 |
| BLOWS WHERE AIMED | 14 | 11 | 1 | 0.03 | +66 | +66.4 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +27 | +26.8 |
| CHARGER SLAIN LOST | 41 | 39 | 1 | 0.03 | +0 | +0.1 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| DEFENSIVE ARMY | 11 | 11 | 1 | 0.03 | -6 | -6.5 |
| FACE THE CAST | 1 | 1 | 1 | 0.03 | +2 | +2.1 |
| LONE WIZARD HOLDS BACK | 3 | 3 | 1 | 0.03 | -27 | -27.4 |
| MOVE SPELL IN RANGE | 7 | 4 | 1 | 0.03 | +1 | +1.0 |
| RAIDS THE BAGGAGE NEXT TURN | 1 | 1 | 1 | 0.03 | +75 | +74.9 |
| REDIRECT BY WHAT IT STOPS | 17 | 17 | 1 | 0.03 | +43 | +43.2 |
| SCREEN BY WHAT IT SAVES | 16 | 16 | 1 | 0.03 | +16 | +16.4 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | -3 | -2.8 |
| STOPS | 6 | 6 | 1 | 0.03 | +21 | +21.1 |
| WIDER SPREAD | 164 | 150 | 1 | 0.03 | +10 | +10.2 |
| WIZARD FRONT RANK | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| ARRIVAL HUNT | 6 | 6 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 34 | 34 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 49 | trace | - | - | - | - |
| CATCH FLIERS | 4 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 12 | 12 | 0 | 0.00 | - | - |
| CHEAP HELPER | 3 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 38 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 5 | 5 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 10 | 10 | 0 | 0.00 | - | - |
| FIGHT LIFT | 5 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 404 | not checked | - | - | - | - |
| GIVES UP | 3 | 2 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 86 | not checked | - | - | - | - |
| GUN MASK | 12 | 5 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 8 | not checked | - | - | - | - |
| HELPER UNSEEN | 22 | 19 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 25 | 25 | 0 | 0.00 | - | - |
| HUNT DROPPED | 4 | trace | - | - | - | - |
| HUNT KEPT | 10 | trace | - | - | - | - |
| HUNT RESULT | 19 | trace | - | - | - | - |
| HUNT THE GUNS | 21 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 4 | 3 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 36 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 8 | trace | - | - | - | - |
| MARCH OVER CASTS | 36 | 36 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 6 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 19 | trace | - | - | - | - |
| MOVE SPELL SPOT | 21 | not checked | - | - | - | - |
| NEEDED THERE | 2 | 2 | 0 | 0.00 | - | - |
| NOT NEEDED | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 397 | 397 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 26 | not checked | - | - | - | - |
| OPENS A LANE | 10 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 2875 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 12 | 12 | 0 | 0.00 | - | - |
| SCOUT SPOT | 38 | 38 | 0 | 0.00 | - | - |
| SECOND HUNTER | 4 | 4 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 41 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 11 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOT OPTIONS | 1395 | 1395 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 3 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 12 | not checked | - | - | - | - |
| SPELL WORTH | 85 | not checked | - | - | - | - |
| STABLE ROLE | 796 | 791 | 0 | 0.00 | - | - |
| TURN WORTH | 14 | 13 | 0 | 0.00 | - | - |

### Off best figure: gf-h2h-opp-0533c46-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.00 | 13.67 | 50.2 |
| FALLBACK | gate | 0.72 | 0.69 | 38.1 |
| TURN GATE | gate | 0.83 | 0.50 | 53.5 |
| CHARGE NOW FIRST | rule | 0.22 | 0.44 | 46.3 |
| FIRE PLAN | rule | - | 0.50 | 45.1 |
| KEEPS THE TARGET | rule | - | 0.39 | 130.6 |
| LONE CHARACTER SAFE SPOT | gate | 0.25 | 0.11 | 56.7 |
| THROUGH LINE OF FIRE | rule | 0.19 | 0.17 | 30.6 |
| CANNON PLANNED TARGET | rule | 0.28 | - | 71.3 |
| SUPPORT REQUEST | gate | 0.08 | 0.17 | 100.4 |
| WAR ENGINE JOBS | rule | 0.14 | 0.11 | 73.3 |
| BEST PRIZE | rule | 0.06 | 0.17 | 116.7 |
| CHARGE NOW WEIGHED | rule | 0.03 | 0.19 | 39.8 |
| SUPPORT NARROWED | rule | 0.08 | 0.14 | 6.1 |
| BIG CHARACTER SAFETY | rule | 0.06 | 0.14 | 7.6 |
| AFTERMATH BAND | gate | 0.08 | 0.08 | 1.9 |
| MARCH ODDS | rule | 0.06 | 0.11 | 5.3 |
| CARRIES OUT SET-UP | rule | - | 0.14 | 60.8 |
| SURE CHARGE BEATS ADVANCE | rule | 0.06 | 0.08 | 90.0 |
| BLOCKED WHEEL | rule | 0.03 | 0.08 | 10.2 |
| CHAFF PASSED | rule | 0.11 | - | 11.7 |
| PATHS CROSS | rule | 0.08 | 0.03 | 11.5 |
| PIVOT GUARDS FLANK | rule | - | 0.11 | 26.3 |
| STOPS SHORT OF THE FLANK | rule | 0.06 | 0.06 | 3.4 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | 0.03 | 65.5 |
| PURSUES BIG PREY | rule | - | 0.08 | 88.1 |
| REFUSING RETIRES | rule | 0.03 | 0.06 | 0.9 |
| SAFER THAN THE JOB | rule | - | 0.08 | 13.1 |
| CARRIES OUT COUNTER | rule | - | 0.06 | 93.6 |
| FIGHT ORDER BAND | gate | 0.03 | 0.03 | 3.3 |
| FRIENDS SHOTS CHECKED | rule | 0.06 | - | 2.2 |
| RULE SWITCHED OFF | gate | 0.06 | - | 19.5 |
| SAFE SURE CHARGE | rule | 0.03 | 0.03 | 217.8 |
| DEFENSIVE ARMY | rule | 0.03 | - | 6.5 |
| LONE WIZARD HOLDS BACK | rule | - | 0.03 | 27.4 |
| LONG SHOT | rule | - | 0.03 | 2.3 |
| NO REASON | gate | - | 0.03 | 15.5 |
| REDIRECT WEIGHED | rule | - | 0.03 | 18.1 |
| STANDS TO CAST | rule | 0.03 | - | 2.8 |

### Plans: gf-h2h-opp-0533c46-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.8 | 14% | 483 | 339 | 70% |
| Mine | charge | 2.3 | 60% | 167 | 180 | 108% |
| Mine | close in | 3.5 | 27% | 129 | 100 | 77% |
| Mine | hold | 4.5 | 29% | 268 | 0 | 0% |
| Mine | join | 0.9 | 97% | 14 | 0 | 0% |
| Mine | shoot | 12.1 | 66% | 481 | 1128 | 234% |
| Mine | support | 3.5 | 91% | 26 | 0 | 0% |
| Opponent | advance | 12.7 | 12% | 404 | 277 | 68% |
| Opponent | charge | 3.8 | 63% | 313 | 337 | 107% |
| Opponent | close in | 6.3 | 23% | 430 | 128 | 30% |
| Opponent | hold | 5.2 | 30% | 366 | 0 | 0% |
| Opponent | join | 0.4 | 86% | 15 | 0 | 0% |
| Opponent | shoot | 7.8 | 51% | 274 | 280 | 102% |
| Opponent | support | 4.0 | 88% | 26 | 0 | 0% |

### Packages: hunt the guns, gf-h2h-opp-0533c46-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.2 | 9 | 1 | 38% | 62% | 0% | 2.2 | 221 | 98 | 62% | 32 |
| Opponent | 0.3 | 12 | 1 | 27% | 27% | 0% | 2.3 | 441 | 115 | 27% | 221 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 3.0 | 9 | 1 | 38% | 62% | 0% | 2.2 | 221 | 98 | 62% | 17 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 84 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 97 |
| Empire of Man | 0.1 | 1 | 1 | - | - | - | - | - | - | - | 27 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 201 |
| High Elf Realms | 0.3 | 3 | 0 | 33% | 33% | 0% | 2.0 | 528 | 142 | 33% | 166 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 224 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 1.0 | 1 | 0 | 100% | 0% | 0% | - | 257 | 0 | 0% | 405 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 298 |
| Tomb Kings of Khemri | 0.4 | 3 | 0 | 33% | 67% | 0% | 2.5 | 440 | 278 | 67% | 132 |
| Vampire Counts | 0.5 | 2 | 0 | 0% | 0% | 0% | - | 270 | 0 | 0% | 384 |
| Warriors of Chaos | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 645 | 0 | 0% | 123 |
| Wood Elf Realms | 0.5 | 1 | 0 | 0% | 0% | 0% | - | 510 | 0 | 0% | 300 |

### Battle groups: gf-h2h-opp-0533c46-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 10.7 | 24% | 51% | 3% | 0% | 27% | 10% | 3% | 60% | 0% |
| Mine | REDIRECT COUNTER | 2.2 | 25% | 75% | 5% | 0% | 11% | 5% | 11% | 74% | 0% |
| Opponent | COUNTER-CHARGE COVER | 9.0 | 14% | 66% | 20% | 44% | 31% | 0% | 14% | 54% | 0% |
| Opponent | REDIRECT COUNTER | 3.1 | 20% | 73% | 18% | 0% | 17% | 6% | 17% | 56% | 6% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gf-h2h-opp-0533c46-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 33 | 67% | 4.0 | 0 (1) | 0 (1) | 0 (1) | 0 (1) | 0 (2) |
| Mine | Chaff | 28 | 47 (28) | 47 | 0 | 45 | 32% | 2.5 | 84 (14) | 0 (6) | 21 (8) | 48 (17) | 45 (11) |
| Mine | Character | 108 | 40 (108) | 40 | 0 | 27 | 31% | 2.9 | 53 (34) | 44 (50) | 19 (7) | 35 (53) | 57 (38) |
| Mine | Clean-up | 14 | 67 (14) | 35 | 32 | 69 | 36% | 2.6 | 33 (6) | 48 (7) | 300 (1) | 81 (9) | 48 (5) |
| Mine | Fast | 4 | 0 (4) | 0 | 0 | 100 | 25% | 1.0 | 0 (1) | 0 (2) | 0 (1) | 0 (4) | - |
| Mine | Fast Hammer | 53 | 48 (53) | 33 | 15 | 43 | 21% | 2.8 | 42 (21) | 56 (22) | 39 (10) | 35 (33) | 63 (20) |
| Mine | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Hammer | 75 | 31 (75) | 21 | 10 | 29 | 13% | 2.7 | 16 (18) | 37 (50) | 29 (7) | 43 (46) | 12 (29) |
| Mine | Holder | 24 | 94 (24) | 22 | 72 | 21 | 33% | 2.6 | 115 (6) | 87 (14) | 91 (4) | 145 (17) | 3 (7) |
| Mine | Shooter | 44 | 88 (44) | 33 | 55 | 41 | 0% | 1.7 | 72 (16) | 107 (22) | 50 (6) | 99 (32) | 55 (12) |
| Mine | War machine | 91 | 70 (91) | 70 | 0 | 39 | 3% | 1.2 | 37 (36) | 84 (45) | 134 (10) | 55 (22) | 75 (69) |
| Mine | Wizard | 27 | 8 (27) | 8 | 0 | 31 | 30% | 2.4 | 0 (9) | 0 (13) | 95 (3) | 0 (7) | 13 (18) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 100 | 0% | 4.5 | - | 0 (2) | - | 0 (2) | - |
| Opponent | Chaff | 68 | 50 (68) | 18 | 32 | 56 | 34% | 2.2 | 57 (28) | 50 (14) | 43 (26) | 46 (56) | 68 (12) |
| Opponent | Character | 96 | 47 (96) | 47 | 0 | 38 | 21% | 2.3 | 53 (38) | 45 (44) | 32 (7) | 42 (44) | 52 (45) |
| Opponent | Clean-up | 13 | 51 (13) | 10 | 41 | 36 | 54% | 2.5 | 0 (3) | 51 (8) | 80 (2) | 64 (9) | 34 (4) |
| Opponent | Fast | 3 | 93 (3) | 93 | 0 | 67 | 33% | 3.5 | - | 93 (3) | - | 93 (3) | - |
| Opponent | Fast Hammer | 51 | 35 (51) | 22 | 13 | 48 | 41% | 3.4 | 19 (24) | 38 (17) | 77 (10) | 50 (26) | 20 (25) |
| Opponent | Fragile | 10 | 56 (10) | 56 | 0 | 21 | 30% | 2.6 | - | 90 (6) | 0 (3) | 74 (5) | 41 (4) |
| Opponent | Hammer | 55 | 29 (55) | 16 | 12 | 38 | 31% | 2.5 | 4 (16) | 39 (33) | 24 (6) | 27 (35) | 31 (20) |
| Opponent | Holder | 43 | 80 (43) | 4 | 76 | 14 | 33% | 2.6 | 64 (11) | 85 (26) | 86 (6) | 106 (28) | 45 (15) |
| Opponent | Shooter | 36 | 30 (36) | 14 | 16 | 46 | 3% | 1.6 | 19 (8) | 33 (24) | 38 (4) | 32 (20) | 27 (16) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (2) | - | - | 0 (1) | 0 (1) |
| Opponent | War machine | 24 | 39 (24) | 39 | 0 | 53 | 0% | 1.2 | 21 (8) | 50 (11) | 48 (5) | 37 (9) | 40 (15) |
| Opponent | Wizard | 25 | 18 (25) | 18 | 0 | 46 | 20% | 2.2 | 17 (11) | 0 (6) | 57 (2) | 39 (9) | 6 (10) |

### Charged fights: gf-h2h-opp-0533c46-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 179 | 218 | 3.3 | 1.3 | 65 | 10 | +55 | 1 of 10 | 8 of 10 | +108 | +32 |
| Mine | Chaos Dwarfs | 5 | 288 | 347 | 2.8 | 1.0 | 124 | 0 | +124 | 4 of 14 | 11 of 14 | - | +124 |
| Mine | Dwarfen Mountain Holds | 5 | 776 | 130 | 1.4 | 1.1 | 93 | 24 | +69 | 2 of 7 | 6 of 7 | -105 | +98 |
| Mine | Empire of Man | 12 | 593 | 108 | 1.0 | 1.2 | 108 | 22 | +86 | 1 of 12 | 9 of 12 | +150 | +80 |
| Mine | Grand Cathay | 2 | 242 | 262 | 2.5 | 1.6 | 105 | 0 | +105 | 0 of 5 | 5 of 5 | +72 | +127 |
| Mine | High Elf Realms | 5 | 42 | 265 | 3.2 | 1.2 | 83 | 18 | +64 | 3 of 16 | 12 of 16 | +27 | +77 |
| Mine | Ogre Kingdoms | 3 | 193 | 74 | 3.7 | 1.2 | 20 | 6 | +14 | 3 of 11 | 8 of 11 | +15 | +14 |
| Mine | Tomb Kings of Khemri | 1 | 0 | 744 | 5.0 | 1.2 | 149 | 0 | +149 | 2 of 5 | 4 of 5 | +250 | +124 |
| **Mine** | all armies | 36 | 396 | 199 | 2.2 | 1.2 | 89 | 11 | +78 | 16 of 80 | 63 of 80 | +64 | +81 |
| Opponent | Chaos Dwarfs | 1 | 189 | 0 | 2.0 | 1.5 | 0 | 0 | +0 | 1 of 2 | 1 of 2 | +0 | +0 |
| Opponent | Empire of Man | 4 | 370 | 85 | 1.5 | 1.3 | 57 | 0 | +57 | 1 of 6 | 5 of 6 | +115 | +28 |
| Opponent | Grand Cathay | 1 | 125 | 77 | 1.0 | 2.0 | 77 | 0 | +77 | 0 of 1 | 1 of 1 | +77 | - |
| Opponent | High Elf Realms | 6 | 81 | 290 | 2.3 | 1.1 | 124 | 0 | +124 | 8 of 14 | 11 of 14 | +88 | +130 |
| Opponent | Lizardmen | 1 | 0 | 186 | 1.0 | 1.0 | 186 | 0 | +186 | 1 of 1 | 1 of 1 | - | +186 |
| Opponent | Ogre Kingdoms | 2 | 98 | 231 | 5.0 | 1.0 | 46 | 84 | -38 | 3 of 10 | 4 of 10 | - | -38 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 36 | 3.0 | 1.0 | 12 | 109 | -97 | 1 of 3 | 2 of 3 | - | -97 |
| Opponent | Skaven | 3 | 53 | 35 | 1.0 | 1.0 | 35 | 0 | +35 | 1 of 3 | 2 of 3 | - | +35 |
| Opponent | Tomb Kings of Khemri | 6 | 115 | 777 | 3.7 | 1.1 | 212 | 12 | +200 | 13 of 22 | 18 of 22 | +220 | +197 |
| Opponent | Vampire Counts | 4 | 33 | 352 | 5.0 | 1.2 | 70 | 81 | -11 | 10 of 20 | 15 of 20 | +11 | -18 |
| Opponent | Warriors of Chaos | 5 | 37 | 499 | 2.0 | 1.1 | 250 | 0 | +250 | 7 of 10 | 8 of 10 | +310 | +243 |
| Opponent | Wood Elf Realms | 2 | 114 | 926 | 5.0 | 1.1 | 185 | 3 | +182 | 3 of 10 | 7 of 10 | +400 | +158 |
| **Opponent** | all armies | 36 | 107 | 371 | 2.8 | 1.2 | 131 | 30 | +101 | 49 of 102 | 75 of 102 | +119 | +97 |

### Effective charges: gf-h2h-opp-0533c46-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 10 | 1 (net +0) | 1 (net -52) | 1 (net +110) | 2 (net +99) | 0 | 5 (net +59) | 0 | 10% (1 of 10) |
| Mine | Chaos Dwarfs | 14 | 2 (net +228) | 1 (net +0) | 1 (net +347) | 2 (net +68) | 0 | 6 (net +74) | 2 | 8% (1 of 12) |
| Mine | Dwarfen Mountain Holds | 7 | 1 (net -60) | 0 | 1 (net +214) | 1 (net +72) | 0 | 4 (net +64) | 0 | 14% (1 of 7) |
| Mine | Empire of Man | 12 | 2 (net +230) | 0 | 1 (net -70) | 4 (net +59) | 4 (net +101) | 1 (net +0) | 0 | 8% (1 of 12) |
| Mine | Grand Cathay | 5 | 0 | 0 | 0 | 1 (net +325) | 3 (net +67) | 0 | 1 | 0% (0 of 4) |
| Mine | High Elf Realms | 16 | 1 (net +0) | 0 | 1 (net +0) | 5 (net +85) | 1 (net +60) | 6 (net +50) | 2 | 7% (1 of 14) |
| Mine | Ogre Kingdoms | 11 | 0 | 1 (net +0) | 1 (net +66) | 1 (net +0) | 2 (net +63) | 2 (net +15) | 4 | 14% (1 of 7) |
| Mine | Tomb Kings of Khemri | 5 | 1 (net +233) | 0 | 0 | 1 (net +75) | 1 (net +250) | 2 (net +93) | 0 | 0% (0 of 5) |
| Opponent | Chaos Dwarfs | 2 | 0 | 0 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 50% (1 of 2) |
| Opponent | Empire of Man | 6 | 0 | 0 | 1 (net +0) | 2 (net +170) | 1 (net +0) | 1 (net +0) | 1 | 20% (1 of 5) |
| Opponent | High Elf Realms | 14 | 2 (net +327) | 0 | 5 (net +51) | 4 (net +123) | 1 (net +52) | 2 (net +142) | 0 | 36% (5 of 14) |
| Opponent | Ogre Kingdoms | 10 | 1 (net +0) | 0 | 0 | 2 (net +68) | 0 | 1 (net +325) | 6 | 0% (0 of 4) |
| Opponent | Orc & Goblin Tribes | 3 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 2 | 0% (0 of 1) |
| Opponent | Skaven | 3 | 1 (net +0) | 0 | 0 | 0 | 0 | 2 (net +52) | 0 | 0% (0 of 3) |
| Opponent | Tomb Kings of Khemri | 22 | 3 (net +155) | 1 (net +526) | 6 (net +212) | 7 (net +208) | 0 | 4 (net +169) | 1 | 29% (6 of 21) |
| Opponent | Vampire Counts | 20 | 3 (net -164) | 0 | 3 (net +9) | 4 (net -32) | 3 (net +37) | 5 (net +91) | 2 | 17% (3 of 18) |
| Opponent | Warriors of Chaos | 10 | 0 | 0 | 1 (net +0) | 1 (net +140) | 0 | 7 (net +337) | 1 | 11% (1 of 9) |
| Opponent | Wood Elf Realms | 10 | 1 (net +270) | 0 | 1 (net +0) | 2 (net +262) | 1 (net +214) | 3 (net +281) | 2 | 12% (1 of 8) |

### Charged fights, damage counted: gf-h2h-opp-0533c46-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 8 | 325 | 252 | +136 | 144 | 37 | +106 | +32.7 |
| Mine | 50-54% | 3 | 135 | 182 | -17 | 20 | 19 | +2 | +1.2 |
| Mine | Effective (55-75%) | 6 | 158 | 165 | +111 | 172 | 91 | +81 | +51.1 |
| Mine | 76-89% | 17 | 220 | 123 | +86 | 104 | 6 | +97 | +44.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 26 | 226 | 170 | +58 | 95 | 35 | +61 | +26.8 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 437 | 78 | +95 | 108 | 0 | +108 | +24.7 |
| Mine | No odds | 9 | 221 | 257 | +59 | 81 | 23 | +58 | +26.1 |
| Mine | All fights | 80 | 255 | 165 | +78 | 105 | 27 | +78 | +30.8 |
| Opponent | Long shot (under 50%) | 12 | 254 | 280 | +75 | 143 | 109 | +33 | +13.1 |
| Opponent | 50-54% | 1 | 626 | 238 | +526 | 526 | 65 | +461 | +73.6 |
| Opponent | Effective (55-75%) | 18 | 275 | 197 | +86 | 137 | 69 | +68 | +24.7 |
| Opponent | 76-89% | 22 | 364 | 191 | +135 | 183 | 45 | +138 | +37.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 26 | 288 | 206 | +194 | 200 | 21 | +178 | +62.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 392 | 90 | +63 | 79 | 17 | +62 | +15.9 |
| Opponent | No odds | 17 | 224 | 215 | -64 | 47 | 108 | -60 | -26.9 |
| Opponent | All fights | 102 | 297 | 205 | +101 | 149 | 60 | +89 | +30.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gf-h2h-opp-0533c46-p3 | move | 440 | 100 (23%) | 71 (16%) | 42 (10%) | 298 (68%) |
| gf-h2h-opp-0533c46-p3 | objective | 359 | 55 (15%) | 35 (10%) | 37 (10%) | 267 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0826, L0834, L1524, L1527, L1834, L2227 |
| Elixir of Power | Mine | L1115 |
| Elixir of Power | Opponent | L0711, L0819 |
| Fistful of Laurels | Mine | L1823, L1829, L1834 |
| Fistful of Laurels | Opponent | L0218, L1518 |
| Invocation of Nehek | Opponent | L1524, L1527, L2227 |
| Opal Amulet | Mine | L1415, L1422 |
| Periapt of Soul Exchange | Opponent | L0621, L0920, L0921 |
| Ring of Doom | Mine | L0203, L0215, L0218, L1115, L1518, L1524, L1527 |
| Ring of Doom | Opponent | L0215, L0711, L0815, L0931, L1115, L1415 |
| Ring of Jet | Mine | L1022, L1115 |
| Ring of Jet | Opponent | L0711 |
| Standard of the Fell Warrior | Opponent | L0313, L0613 |
| Storm Daemon (Renegade 2.0) | Opponent | L0621, L0921 |
| Twice-Blessed Armour | Mine | L0711, L0722, L1022 |
| Twice-Blessed Armour | Opponent | L0307 |
| Witch Hunter's Ward | Mine | L0711, L0722, L0815, L0819, L0822, L0826, L0829, L0834 |
| Witch Hunter's Ward | Opponent | L0307, L0308, L0608 |

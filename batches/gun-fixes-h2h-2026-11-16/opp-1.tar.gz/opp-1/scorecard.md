# Doctrine scorecard: gf-h2h-opp-0533c46-p1

### Scorecard: gf-h2h-opp-0533c46-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0103 | 1 | 1 | Mine | no | 10 | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0103 | 1 | 1 | Opponent | no | 2 | 5 | 1 | 2 | 0 | 0 | 0 | 590 |
| L0108 | 6 | 1 | Mine | no | 6 | - | 0 | 2 | 0 | 0 | 0 | 65 |
| L0108 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 560 |
| L0109 | 1 | 1 | Mine | no | 2 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0109 | 1 | 1 | Opponent | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 375 |
| L0315 | 3 | 1 | Mine | no | 0 | 4 | 1 | 1 | 1 | 0 | 0 | 985 |
| L0315 | 3 | 1 | Opponent | yes | 11 | 2 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0316 | 4 | 1 | Mine | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 590 |
| L0316 | 4 | 1 | Opponent | no | 0 | 5 | 0 | 1 | 1 | 0 | 0 | 200 |
| L0322 | 4 | 1 | Mine | no | 3 | - | 1 | 1 | 0 | 0 | 0 | 590 |
| L0322 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 127 |
| L0323 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 675 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0506 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 548 |
| L0506 | 2 | 1 | Opponent | - | - | - | 3 | 4 | 1 | 0 | 0 | 984 |
| L0507 | 3 | 1 | Mine | no | 1 | 2 | 2 | 2 | 0 | 0 | 0 | 751 |
| L0507 | 3 | 1 | Opponent | yes | 4 | 3 | 2 | 0 | 1 | 0 | 0 | 420 |
| L0508 | 4 | 1 | Mine | no | 7 | - | 0 | 2 | 0 | 0 | 0 | 686 |
| L0508 | 4 | 1 | Opponent | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 605 |
| L0509 | 5 | 1 | Mine | no | - | - | 0 | 3 | 0 | 0 | 0 | 548 |
| L0509 | 5 | 1 | Opponent | yes | - | - | 0 | 2 | 0 | 0 | 0 | 609 |
| L0510 | 6 | 1 | Mine | no | 0 | 4 | 1 | 2 | 0 | 0 | 0 | 698 |
| L0510 | 6 | 1 | Opponent | no | 0 | 3 | 0 | 1 | 0 | 0 | 0 | 330 |
| L0511 | 1 | 1 | Mine | no | 5 | - | 0 | 2 | 0 | 0 | 0 | 954 |
| L0511 | 1 | 1 | Opponent | no | 7 | 4 | 1 | 2 | 1 | 0 | 0 | 330 |
| L0522 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 1343 |
| L0522 | 6 | 1 | Opponent | no | 4 | 2 | 2 | 2 | 1 | 0 | 0 | 72 |
| L0614 | 2 | 1 | Mine | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 926 |
| L0614 | 2 | 1 | Opponent | - | - | 2 | 2 | 2 | 2 | 0 | 0 | 0 |
| L0615 | 3 | 1 | Mine | no | 4 | - | 2 | 2 | 0 | 0 | 0 | 801 |
| L0615 | 3 | 1 | Opponent | no | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0619 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 801 |
| L0619 | 1 | 1 | Opponent | yes | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0627 | 3 | 1 | Mine | no | 0 | - | 1 | 2 | 0 | 0 | 0 | 801 |
| L0627 | 3 | 1 | Opponent | no | 10 | - | 2 | 2 | 0 | 0 | 0 | 0 |
| L0708 | 6 | 1 | Mine | no | 2 | 2 | 3 | 0 | 0 | 0 | 0 | 420 |
| L0708 | 6 | 1 | Opponent | no | 5 | 3 | 1 | 1 | 0 | 0 | 0 | 605 |
| L0712 | 4 | 1 | Mine | no | 0 | 3 | 0 | 2 | 0 | 0 | 0 | 327 |
| L0712 | 4 | 1 | Opponent | no | 2 | 2 | 2 | 1 | 0 | 0 | 0 | 330 |
| L0716 | 2 | 1 | Mine | - | - | 2 | 1 | 0 | 0 | 0 | 0 | 375 |
| L0716 | 2 | 1 | Opponent | - | - | 1 | 4 | 1 | 1 | 0 | 0 | 200 |
| L0725 | 5 | 1 | Mine | yes | - | 3 | 3 | 1 | 0 | 0 | 0 | 613 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0730 | 4 | 1 | Mine | no | 0 | 4 | 2 | 2 | 0 | 0 | 0 | 375 |
| L0730 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0731 | 5 | 1 | Mine | yes | - | 2 | 3 | 2 | 1 | 0 | 0 | 420 |
| L0731 | 5 | 1 | Opponent | yes | - | - | 0 | 3 | 1 | 0 | 0 | 340 |
| L0810 | 6 | 1 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 589 |
| L0810 | 6 | 1 | Opponent | no | 13 | 3 | 3 | 1 | 0 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | 3 | 1 | 1 | 0 | 0 | 0 | 807 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 2 | 5 | 0 | 0 | 0 | 0 |
| L0832 | 4 | 1 | Mine | no | 0 | 5 | 1 | 1 | 0 | 0 | 0 | 560 |
| L0832 | 4 | 1 | Opponent | no | 3 | 2 | 3 | 1 | 1 | 0 | 0 | 170 |
| L0833 | 5 | 1 | Mine | yes | - | 5 | 1 | 0 | 0 | 0 | 0 | 560 |
| L0833 | 5 | 1 | Opponent | yes | - | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 0 | 6 | 1 | 4 | 0 | 0 | 0 | 0 |
| L1318 | 4 | 1 | Mine | no | 0 | 2 | 3 | 0 | 1 | 0 | 0 | 140 |
| L1318 | 4 | 1 | Opponent | no | 0 | 3 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1516 | 4 | 1 | Mine | no | 7 | 2 | 2 | 1 | 0 | 0 | 0 | 199 |
| L1516 | 4 | 1 | Opponent | no | 3 | 2 | 4 | 0 | 0 | 0 | 0 | 200 |
| L1822 | 4 | 1 | Mine | no | 2 | 2 | 6 | 0 | 1 | 0 | 0 | 0 |
| L1822 | 4 | 1 | Opponent | no | 1 | 2 | 4 | 0 | 0 | 0 | 0 | 55 |
| L1831 | 1 | 1 | Mine | no | 2 | 3 | 5 | 1 | 1 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 2 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| L2224 | 4 | 1 | Mine | no | 3 | 2 | 2 | 0 | 0 | 0 | 0 | 110 |
| L2224 | 4 | 1 | Opponent | no | 0 | 3 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2228 | 2 | 1 | Mine | - | - | 1 | 4 | 4 | 0 | 0 | 0 | 0 |
| L2228 | 2 | 1 | Opponent | - | - | - | 0 | 1 | 3 | 0 | 0 | 0 |
| L2230 | 4 | 1 | Mine | no | 0 | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L2230 | 4 | 1 | Opponent | no | 2 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 9% | 2.1 | 2.7 | 1.6 | 1.5 | 0.1 | 0.0 | 0.0 | 493.7 |
| **Average** | | | Opponent | 28% | 2.7 | 2.6 | 2.1 | 1.4 | 0.4 | 0.0 | 0.0 | 206.4 |

### KPIs: gf-h2h-opp-0533c46-p1

Rules off - Mine only: GUN FIGURES, GUN MASK, GUN VIEW, GUN THREAT, STAY WORTH, BEST MOVE FOR SHOOTERS, FACE THE CAST, WIZARD FRONT RANK, FIRE PLAN, FIRE IN ORDER, KEEPS THE TARGET, MISSILES IN THE FIRE PLAN, THREAT AT FULL SIZE, SHOOTERS ARE THREATS, SHOOTERS TO THE PRIMARY, EVERY WOUND COUNTS, HONEST THREAT, ONE YARDSTICK.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 41% (63 of 154) | 10% (16 of 167) | 25% (79 of 321) |
| Winner chose to follow up after the loser gave ground |  | 91% (40 of 44); on the table 91% | 100% (43 of 43); on the table 100% | 95% (83 of 87); on the table 95% |
| Winner chose to pursue after the loser fell back in good order |  | 50% (2 of 4); on the table 50% | 100% (9 of 9); on the table 100% | 85% (11 of 13); on the table 85% |
| Winner chose to pursue after the loser fled |  | 50% (5 of 10); on the table 60% | 83% (25 of 30); on the table 87% | 75% (30 of 40); on the table 80% |
| Winner chose to follow up or pursue (all three) |  | 81% (47 of 58); on the table 83% | 94% (77 of 82); on the table 95% | 89% (124 of 140); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 38% (66 of 174) | 38% (78 of 204) | 38% (144 of 378) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 45% (60 of 132) | 53% (78 of 148) | 49% (138 of 280) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 31% (11 of 36) | 37% (46 of 126) | 35% (57 of 162) |
|     round 1 |  | 33% (2 of 6) | 24% (5 of 21) | 26% (7 of 27) |
|     rounds 2+ |  | 30% (9 of 30) | 39% (41 of 105) | 37% (50 of 135) |
|   other wizards | 50%+ | 37% (49 of 132) | 41% (32 of 78) | 39% (81 of 210) |
|     round 1 |  | 14% (3 of 22) | 15% (2 of 13) | 14% (5 of 35) |
|     rounds 2+ |  | 42% (46 of 110) | 46% (30 of 65) | 43% (76 of 175) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 48% (14 of 29) | 48% (14 of 29) |
| Points that never fought | lower | 53% (37391 of 70291) | 51% (36529 of 71989) | 52% (73920 of 142280) |
|   infantry points that never fought | lower | 59% (9808 of 16644) | 74% (9666 of 13123) | 65% (19474 of 29767) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 66% (187 of 282) | 53% (155 of 293) | 59% (342 of 575) |
| Bound items with a magic missile used (at least once a game) |  | 75% (6 of 8); 0.5 uses a game | 79% (15 of 19); 1.4 uses a game | 78% (21 of 27); 1.0 uses a game |
| Bound items with another spell used |  | 64% (7 of 11); 0.4 uses a game | 22% (2 of 9); 0.1 uses a game | 45% (9 of 20); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 56% (10 of 18); 0.3 uses a game | 69% (11 of 16); 0.3 uses a game | 62% (21 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 61% (33853 of 55230) | 47% (29574 of 63193) | 54% (63427 of 118423) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.1 (37%) | 1.0 (28%) | 2.1 (32%) |
| MARCHED: its unit marched | 0.6 (19%) | 0.8 (23%) | 1.4 (21%) |
| CHARGED: its unit charged | 0.1 (2%) | 0.1 (3%) | 0.2 (3%) |
| IN COMBAT: engaged in combat | 0.5 (17%) | 0.7 (19%) | 1.2 (18%) |
| REAR RANK: in a rear rank | 0.1 (4%) | 0.0 (0%) | 0.1 (2%) |
| FLEEING: fleeing | 0.0 (1%) | 0.0 (1%) | 0.1 (1%) |
| GONE: slain | 0.2 (8%) | 0.8 (24%) | 1.1 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (7%) | 0.0 (1%) | 0.2 (4%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.1 (2%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (5%) | 0.0 (0%) | 0.1 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.8 | 0.7 | 1.8 | 4.0 | 0.5 | 0.9 |
| not cast | 3.0 | 2.1 | 2.7 | 6.5 | 1.4 | 14.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.5 (3%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 0.5 (24%) | 0.1 (2%) | 2.1 (32%) | 0.2 (16%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (21%) | 0.3 (20%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (3%) | 0.0 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (5%) | 0.2 (8%) | 0.5 (19%) | 1.2 (18%) | 0.2 (12%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (9%) | 0.1 (7%) | 0.3 (10%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (8%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| GONE: slain | 0.5 (17%) | 0.4 (19%) | 0.2 (9%) | 1.1 (17%) | 0.3 (20%) | 2.0 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (5%) | 0.4 (21%) | 0.4 (13%) | 0.2 (4%) | 0.0 (0%) | 0.9 (6%) |
| STUPIDITY: Stupidity | 0.1 (4%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (4%) | 0.3 (15%) | 0.0 (0%) | 0.1 (1%) | 0.3 (20%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (56%) | 0.1 (7%) | 1.1 (42%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 11.2 (76%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.2 a game | 0.8 a game | 1.0 a game |
| stood (cast and not dispelled) | 53% (19 of 36) | 56% (10 of 18) | 54% (29 of 54) |
| the unit moved after it | 47% (9 of 19) | 80% (8 of 10) | 59% (17 of 29) |
| it charged on its next turn | 0% (0 of 19) | 10% (1 of 10) | 3% (1 of 29) |
| the enemy charged it first | 16% (3 of 19) | 0% (0 of 10) | 10% (3 of 29) |
| it fought by the end of its next turn | 11% (2 of 19) | 0% (0 of 10) | 7% (2 of 29) |
| it moved out of a charge the enemy had planned (not charged first) | 32% (6 of 19) | 10% (1 of 10) | 24% (7 of 29) |
| none of these (no charge, no fight, no charge escaped) | 53% (10 of 19) | 80% (8 of 10) | 62% (18 of 29) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 68% (900 of 1316) | 63% (496 of 793) | 66% (1396 of 2109) |
|   cavalry | 58% (62 of 107) | 70% (105 of 149) | 65% (167 of 256) |
|   character | 61% (106 of 173) | 23% (18 of 79) | 49% (124 of 252) |
|   chariot | 58% (61 of 105) | 69% (42 of 61) | 62% (103 of 166) |
|   infantry | 55% (198 of 362) | 62% (178 of 289) | 58% (376 of 651) |
|   monster | 64% (21 of 33) | 35% (8 of 23) | 52% (29 of 56) |
|   war machine | 84% (452 of 536) | 76% (145 of 192) | 82% (597 of 728) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.6 (22%) | 2.1 (26%) | 4.7 (24%) |
| CHARGED: it charged | 1.1 (10%) | 1.8 (21%) | 2.9 (14%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.8 (7%) | 0.3 (3%) | 1.1 (5%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| HELD FIRE: a target, but it held its fire | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 3.2 (28%) | 1.4 (18%) | 4.7 (24%) |
| ONLY IN COMBAT: the only targets were in combat | 1.1 (9%) | 0.5 (6%) | 1.5 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (14%) | 1.4 (16%) | 3.0 (15%) |
| SHELTERED: the target was sheltered | 0.2 (1%) | 0.3 (4%) | 0.5 (2%) |
| STUPIDITY | 0.1 (0%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR | 0.6 (6%) | 0.4 (5%) | 1.0 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 8.1 | 3.1 | 75% | 8.0 pts | 64 pts |
| character | 3.8 | 1.1 | 76% | 7.6 pts | 29 pts |
| chariot | 2.9 | 2.7 | 58% | 19.8 pts | 57 pts |
| infantry | 14.9 | 5.4 | 75% | 9.2 pts | 137 pts |
| monster | 0.9 | 0.4 | 76% | 17.5 pts | 16 pts |
| war machine | 16.8 | 15.0 | 58% | 25.7 pts | 431 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.3 | 5.4 | 3.8 |
| Charges that made contact a game | 1.6 | 3.8 | 2.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.36 declared, 0.36 contact (11 units) | 0.69 declared, 0.46 contact (13 units) | 0.54 declared, 0.42 contact (24 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.75 declared, 0.75 contact (4 units) | 0.60 declared, 0.40 contact (10 units) | 0.64 declared, 0.50 contact (14 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.33 declared, 0.21 contact (234 units) | 0.79 declared, 0.56 contact (225 units) | 0.56 declared, 0.39 contact (459 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 48% (32 of 66) | 48% (10 of 21) | 50% (4 of 8) | 48% (46 of 95) |
| Character in a unit | 83% (40 of 48) | 59% (10 of 17) | 67% (2 of 3) | 76% (52 of 68) |
| Character on its own | 89% (42 of 47) | 62% (18 of 29) | 21% (10 of 48) | 56% (70 of 124) |
| Chariot | 83% (10 of 12) | 55% (11 of 20) | - | 66% (21 of 32) |
| Infantry | 64% (37 of 58) | 43% (18 of 42) | 75% (6 of 8) | 56% (61 of 108) |
| Monster | 44% (11 of 25) | 100% (5 of 5) | - | 53% (16 of 30) |
| Monstrous | 25% (1 of 4) | 30% (3 of 10) | - | 29% (4 of 14) |
| War Machines | 68% (67 of 99) | 100% (5 of 5) | - | 69% (72 of 104) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 3 | 100% (3 of 3); on the table 100% | 28% (27 of 96) | 56% | 47% (7 of 15) | 67% (2 of 3); 1.7 uses a game | 100% (3 of 3); 2.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Chaos Dwarfs | 5 | 100% (2 of 2); on the table 100% | 70% (38 of 54) | 64% | 70% (28 of 40) | 0.0 uses a game | 0.0 uses a game | 80% (4 of 5); 0.8 uses a game |
| Dwarfen Mountain Holds | 12 | 60% (6 of 10); on the table 60% | - | 66% | 74% (70 of 95) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 17 | 96% (23 of 24); on the table 96% | 33% (18 of 54) | 55% | 65% (110 of 170) | 0.0 uses a game | 29% (2 of 7); 0.3 uses a game | 40% (6 of 15); 0.4 uses a game |
| Grand Cathay | 4 | 89% (8 of 9); on the table 89% | 38% (34 of 90) | 49% | 41% (15 of 37) | 67% (6 of 9); 5.0 uses a game | 0% (0 of 2); 0.0 uses a game | 50% (2 of 4); 0.5 uses a game |
| High Elf Realms | 5 | 78% (14 of 18); on the table 83% | 28% (5 of 18) | 32% | 34% (13 of 38) | 100% (7 of 7); 4.6 uses a game | 50% (4 of 8); 0.8 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 100% (5 of 5); on the table 100% | - | 57% | 44% (8 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Ogre Kingdoms | 3 | 100% (6 of 6); on the table 100% | 0% (0 of 12) | 51% | 67% (14 of 21) | 33% (1 of 3); 1.7 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 67% (2 of 3); on the table 100% | 17% (1 of 6) | 50% | 50% (4 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 7 | 83% (15 of 18); on the table 83% | - | 37% | 37% (13 of 35) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 4 | 100% (13 of 13); on the table 100% | 33% (8 of 24) | 36% | 56% (14 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 6 | 91% (20 of 22); on the table 91% | 61% (11 of 18) | 43% | 63% (32 of 51) | 100% (2 of 2); 0.8 uses a game | 0.0 uses a game | 100% (2 of 2); 0.3 uses a game |
| Wood Elf Realms | 2 | 100% (7 of 7); on the table 100% | 33% (2 of 6) | 71% | 64% (14 of 22) | 100% (3 of 3); 5.5 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (gf-h2h-opp-0533c46-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (34) | 65% (20) | 55% (54) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.42 | 1.08 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.06 | 0.22 |
| ...with the charger already in that arc before they moved (per game) | 0.42 | 0.28 | 0.69 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 2.28 | 1.08 | 3.36 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.47 | 0.78 | 2.25 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.53 | 4.11 | 9.64 |

### Quality by phase: gf-h2h-opp-0533c46-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.2 | 3.1 |
| Strategy | Charge objectives carried out (made contact) | 42% (33 of 78) | 44% (68 of 155) |
| Strategy | Shoot objectives carried out (shot that target) | 56% (348 of 619) | 51% (150 of 296) |
| Strategy | Close-in objectives charged next turn | 8% (10 of 120) | 14% (33 of 229) |
| Strategy | Support requests answered (helper made contact too) | 28% (5 of 18) | 43% (16 of 37) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 1) | 20% (1 of 5) |
| Strategy | Joined characters whose unit fought | 28% (17 of 60) | 22% (11 of 51) |
| Strategy | Lone characters that fought | 59% (57 of 97) | 63% (56 of 89) |
| Movement | Charges halted short of contact | 0.0 | 0.2 |
| Movement | Idle units | 1.5 | 1.4 |
| Movement | Points that never moved of their own | 493.7 | 206.4 |
| Movement | Fights charged into per game | 1.4 | 2.9 |
| Movement | Charges with odds: long shots (under 50%) | 12 of 44, net +165 | 18 of 87, net +89 |
| Movement | Charges with odds: sweet spot (55-75%) | 5 of 44, net -136 | 16 of 87, net +128 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 4 of 44, net +72 | 12 of 87, net +41 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 8 of 44, net +115 | 12 of 87, net +147 |
| Shooting | Shots by shooting units (incl. breath weapons) | 13.2 | 10.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 53% (255 of 477) | 39% (154 of 390) |
| Shooting | Points destroyed by shooting units | 141.6 | 44.3 |
| Shooting | War machine shots | 12.6 | 4.1 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 54% (246 of 452) | 39% (58 of 149) |
| Shooting | Points destroyed by war machines | 185.9 | 73.4 |
| Magic | Magic missiles cast | 1.2 | 1.6 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 16% (7 of 43) | 48% (27 of 56) |
| Magic | Wounds caused by magic missiles | 2.6 | 2.3 |
| Magic | Wounds caused by other spells | 1.1 | 0.2 |
| Magic | Points destroyed by magic (all spells) | 25.3 | 28.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.7 / 0.1 / 0.5 / 0.0 | 2.1 / 0.2 / 0.1 / 0.3 |
| Combat | Points destroyed in combat | 169.3 | 345.0 |
| Combat | Points run down | 50.8 | 140.1 |
| Combat | Net points per charged fight, damage counted | +59 | +105 |
| Combat | Net per 100 charger points, damage counted | +23.3 | +31.0 |
| Combat | First round won (charged fights) | 69% | 75% |
| Combat | Net points per charged fight | +55 | +118 |
| Combat | Net points per supported fight / lone fight | +20 / +58 | +160 / +104 |
| Combat | Charged fights on a top-3 enemy unit | 22 of 52 | 55 of 105 |
| Game | Points lost | 803.4 | 647.7 |
| Game | VP from objectives | 527.8 | 713.9 |
| Game | Lone holders (player turns) | 2.1 | 2.7 |

- Mine won / drew / lost: 8 / 7 / 21 of 36 ended games (of 36); mean margin (Mine - Opponent) -348 VP
- The side that went first won 11 of 29 games with a winner
- Points traded per game (both sides' losses): 1451
- Games not ended: 0; findings 0, warnings 1

### Opponent rules: gf-h2h-opp-0533c46-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.5 | +0.0 | 0.0 | 1.8 | 0.6 | +0.0 | 0.0 | 8.2 |
| ALREADY CARRIED | 0.1 | +0.0 | 8.9 | 2.6 | - | - | - | - |
| ARRIVAL HUNT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.8 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.8 | +0.0 | 0.0 | 41.5 | 1.1 | +0.0 | 0.0 | 36.5 |
| BACKUP TARGETS | 0.7 | +4.1 | 0.0 | 38.1 | 0.8 | +7.6 | 0.0 | 51.3 |
| BEST FACING | 1.2 | +49.6 | 0.0 | 44.0 | 0.4 | +7.0 | 0.0 | 27.3 |
| BEST FIRST | 4.2 | +144.8 | 163.7 | 102.2 | 3.8 | +124.8 | 163.3 | 51.2 |
| BEST MOVE FOR SHOOTERS | - | - | - | - | 1.0 | +51.7 | 0.0 | 22.4 |
| BEST OVERALL | 0.9 | +81.8 | 0.0 | 27.9 | 0.2 | +15.3 | 0.0 | 17.6 |
| BEST PREY | 0.7 | +31.3 | 19.3 | 0.0 | 0.9 | +32.9 | 32.1 | 0.0 |
| BEST PRIZE | 0.0 | -5.6 | 1.1 | 0.0 | 0.2 | -14.9 | 16.0 | 13.6 |
| BIG CHARACTER SAFETY | 0.1 | -0.4 | 0.0 | 0.0 | 0.4 | -3.2 | 0.0 | 49.5 |
| BLOCKED CHARGE SKIPPED | - | - | - | - | 0.1 | +0.0 | 10.3 | 0.0 |
| BLOCKED WHEEL | 0.2 | +7.5 | 0.0 | 2.9 | 0.5 | +11.4 | 0.0 | 2.7 |
| BLOWS WHERE AIMED | 0.2 | -20.4 | 17.6 | 2.9 | 0.4 | -33.8 | 73.0 | 12.4 |
| BOMBING RUN | - | - | - | - | 0.0 | +1.6 | 0.0 | 2.9 |
| CANNON PLAN MISSED | 1.6 | +0.0 | 248.2 | 19.3 | - | - | - | - |
| CANNON PLANNED TARGET | 10.5 | +317.5 | 822.8 | 170.1 | - | - | - | - |
| CANNON SIGHT KEPT | 2.1 | +0.0 | 0.0 | 7.2 | 1.1 | +0.0 | 0.0 | 13.8 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | -1.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | -9.3 | 8.2 | 5.2 | 0.2 | -2.0 | 27.8 | 5.2 |
| CAST JOB | 0.8 | +24.6 | 40.8 | 7.1 | 0.8 | +15.4 | 36.4 | 9.5 |
| CASTER AWAY FROM SCREEN | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +34.5 | 17.4 | 8.2 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 30.3 | 0.4 | +0.0 | 0.0 | 7.6 |
| CASTS FROM BEHIND | - | - | - | - | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +1.1 | 0.0 | 0.0 | 0.1 | +0.7 | 0.0 | 0.0 |
| CATCH ODDS | - | - | - | - | 0.0 | +0.5 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | -0.6 | 6.4 | 12.9 | - | - | - | - |
| CHARGE BAND | 0.1 | +0.0 | 4.6 | 5.2 | 0.3 | +0.0 | 50.1 | 13.6 |
| CHARGE NOW FIRST | 1.4 | +0.0 | 133.4 | 75.5 | 2.6 | +0.0 | 262.1 | 45.3 |
| CHARGE NOW WEIGHED | 0.6 | -67.3 | 14.3 | 10.1 | 1.0 | -114.8 | 93.8 | 33.1 |
| CHARGER SLAIN LOST | 0.4 | -19.4 | 56.6 | 6.5 | 0.6 | -13.4 | 72.8 | 35.7 |
| CHARIOT WIZARD CAREFUL | 0.1 | -2.0 | 8.2 | 0.0 | - | - | - | - |
| CHEAP HELPER | 0.1 | +0.0 | 17.5 | 1.7 | 0.0 | +0.0 | 5.1 | 1.7 |
| COMBAT PIVOT | 0.2 | +0.0 | 13.3 | 29.6 | 0.2 | +0.0 | 6.6 | 13.8 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 3.2 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.7 | +124.0 | 28.8 | 31.0 | 0.5 | +43.9 | 8.8 | 15.2 |
| COUNTER-CHARGE COVER | 12.5 | +1171.9 | 0.0 | 314.2 | 6.4 | +522.0 | 0.0 | 150.0 |
| DEFENSIVE ARMY | 0.4 | +0.0 | 27.5 | 1.0 | 0.1 | +0.0 | 0.0 | 2.9 |
| EDGE GIVE GROUND | 0.1 | +2.8 | 2.8 | 6.1 | 0.1 | +4.4 | 19.1 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +0.6 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| EVERY WOUND COUNTS | - | - | - | - | 10.6 | +0.0 | 332.0 | 164.7 |
| FACE THE CAST | - | - | - | - | 0.1 | +0.7 | 0.0 | 0.0 |
| FACES THE THREAT | 2.3 | +208.6 | 0.0 | 68.4 | 1.1 | +46.4 | 0.0 | 45.5 |
| FALLBACK BY WORTH | 4.2 | +39.4 | 0.0 | 69.0 | 4.7 | +44.2 | 0.0 | 49.2 |
| FIGHT LIFT | - | - | - | - | 0.1 | +2.9 | 0.0 | 1.7 |
| FIRE AND FLEE | - | - | - | - | 0.1 | +0.8 | 3.5 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 0.5 | +0.0 | 14.6 | 15.4 |
| FIRE PLAN | - | - | - | - | 14.9 | +89.0 | 455.6 | 225.2 |
| FLANK NOT WEIGHED | 6.5 | +0.0 | 0.0 | 170.8 | 4.1 | +0.0 | 0.0 | 97.5 |
| FOCUS FIRE | 0.0 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.7 | +88.7 | 0.0 | 21.4 | 0.9 | +140.5 | 0.0 | 38.3 |
| FRIENDS SHOTS CHECKED | 0.1 | +7.8 | 0.0 | 0.0 | 0.2 | +25.3 | 0.0 | 10.5 |
| GIVES UP | - | - | - | - | 0.0 | -0.7 | 1.2 | 0.0 |
| GIVES UP ITS SCREEN | 0.0 | -0.2 | 1.5 | 0.0 | - | - | - | - |
| GROUND FLIERS | 0.1 | +1.6 | 0.0 | 0.0 | 0.0 | +0.3 | 0.0 | 0.0 |
| GUN FIGURES | - | - | - | - | 1.4 | +28.6 | 40.2 | 37.4 |
| GUN MASK | - | - | - | - | 0.5 | +0.4 | 0.0 | 3.1 |
| GUN THREAT | - | - | - | - | 0.9 | +138.8 | 32.8 | 33.6 |
| GUN VIEW | - | - | - | - | 1.0 | +5.6 | 0.0 | 18.3 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 2.7 | 0.0 | 0.1 | +0.0 | 8.0 | 0.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 28.2 | 0.0 | 0.3 | +0.0 | 45.1 | 1.7 |
| HILL BY ITS CHANCE | 0.2 | -13.4 | 0.0 | 0.0 | 0.1 | -7.8 | 0.0 | 5.6 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HONEST THREAT | - | - | - | - | 10.6 | +1474.1 | 332.0 | 164.7 |
| HONEST WORTH | 5.2 | -65.9 | 206.2 | 109.2 | 9.1 | -186.5 | 602.1 | 275.6 |
| HORN WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +5.7 | 2.8 | 0.0 | 0.3 | +3.3 | 19.4 | 3.2 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 3.1 | 0.1 | +0.0 | 6.9 | 2.2 |
| HUNT IN PAIRS | 0.2 | +2.5 | 0.0 | 0.0 | 0.7 | +40.3 | 0.0 | 41.6 |
| HUNT KEPT | 0.1 | +3.4 | 2.8 | 3.2 | 0.1 | +0.2 | 10.1 | 0.0 |
| HUNT RESULT | 0.1 | +23.6 | 0.0 | 6.2 | 0.4 | +34.2 | 6.9 | 6.2 |
| HUNT THE GUNS | 0.1 | +55.7 | 13.8 | 0.0 | 0.4 | +87.0 | 36.4 | 5.4 |
| INVITES THE FIGHT | 1.8 | +26.7 | 53.4 | 56.6 | 1.6 | +29.7 | 34.8 | 19.4 |
| JOINT CHARGE PLAN | 0.1 | +1.7 | 8.2 | 0.0 | 0.4 | +12.2 | 53.2 | 11.3 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.3 | -12.1 | 67.3 | 15.7 |
| KEEP FALLS | 0.1 | +2.7 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.0 | +0.1 | 0.0 | 1.5 | 0.0 | +0.0 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 0.8 | +22.5 | 52.1 | 41.2 | 2.0 | +60.0 | 222.8 | 30.6 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| KEEPS THE TARGET | - | - | - | - | 1.2 | -28.8 | 74.4 | 25.7 |
| KILLS COUNT | 1.0 | +41.8 | 82.9 | 48.2 | 1.6 | +74.3 | 126.0 | 5.6 |
| KILLS COUNT NEXT TURN | 3.5 | +108.2 | 110.8 | 62.6 | 7.1 | +227.2 | 403.0 | 168.8 |
| LONE CHARACTER SAFE SPOT | 0.5 | +10.7 | 47.9 | 5.8 | 0.5 | +13.5 | 15.1 | 15.3 |
| LONE WIZARD HOLDS BACK | - | - | - | - | 0.4 | +0.0 | 3.5 | 0.0 |
| LONE WIZARD KEPT IN | 0.6 | +41.6 | 0.0 | 0.0 | 0.5 | +37.5 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | +5.1 | 35.1 | 16.4 | 0.3 | -5.2 | 2.7 | 0.0 |
| LOST CHARGE | 2.7 | -53.6 | 98.1 | 74.3 | 2.2 | -47.3 | 91.8 | 36.2 |
| LURE BY WHAT IT DRAWS | 0.0 | -5.8 | 0.0 | 1.0 | - | - | - | - |
| MAKE SURE TOGETHER | 0.5 | +23.3 | 8.2 | 23.4 | 2.2 | +318.5 | 171.5 | 156.4 |
| MANOEUVRE | 0.1 | +1.1 | 0.0 | 0.0 | 0.1 | +6.6 | 0.0 | 5.1 |
| MARCH AT ESCAPER | - | - | - | - | 0.0 | +0.9 | 0.0 | 8.2 |
| MARCH CHECK | 0.2 | +15.7 | 0.0 | 0.0 | 0.4 | +35.0 | 0.0 | 10.2 |
| MARCH ODDS | 0.1 | +10.0 | 13.3 | 0.0 | 0.1 | +10.8 | 4.6 | 0.0 |
| MARCH OVER CASTS | 0.3 | +2.9 | 0.0 | 0.0 | 0.3 | +8.2 | 0.0 | 21.6 |
| MAX FOR POSITIONING | 4.5 | +121.4 | 0.0 | 129.0 | 5.1 | +205.8 | 0.0 | 206.3 |
| MISSILES IN THE FIRE PLAN | - | - | - | - | 1.2 | +6.2 | 78.2 | 21.5 |
| MISSILES IN THE MOVE | 2.1 | +96.1 | 0.0 | 51.7 | 3.7 | +56.9 | 0.0 | 78.8 |
| MISSILES NEXT TURN | 2.4 | +62.4 | 0.0 | 51.7 | 4.4 | +49.0 | 0.0 | 134.6 |
| MODEL FACING | 0.5 | +182.0 | 0.0 | 10.0 | 0.1 | +18.2 | 0.0 | 1.7 |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 0.0 | 10.6 | 0.6 | +0.0 | 73.6 | 55.5 |
| MOVE AND CAST | 0.2 | +4.1 | 0.0 | 7.1 | 0.4 | +13.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.3 | +9.6 | 0.0 | 10.6 | - | - | - | - |
| MOVE SPELL NOT WORTH | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.7 | -38.7 | 16.0 | 23.1 | 0.1 | -4.2 | 0.0 | 15.2 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 1.5 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 2.3 | +100.4 | 97.8 | 39.0 | 5.8 | +422.8 | 366.6 | 222.8 |
| MOVES UNITS SPELL | 0.0 | +0.2 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +8.3 | 0.0 | 0.0 | 0.0 | +2.2 | 5.2 | 0.0 |
| NOT NEEDED | 0.1 | -4.1 | 7.6 | 5.2 | 0.2 | -25.6 | 6.6 | 0.0 |
| NOT TURNED | 5.5 | +104.0 | 0.0 | 127.0 | 4.1 | +50.3 | 0.0 | 61.4 |
| NOT WORTH A CAST | 0.8 | -0.5 | 0.0 | 42.2 | 0.3 | -0.1 | 0.0 | 21.1 |
| OFF BEST | 16.6 | -784.5 | 1.1 | 299.7 | 16.3 | -769.9 | 10.1 | 274.1 |
| ONE YARDSTICK | - | - | - | - | 15.1 | -589.7 | 369.5 | 275.4 |
| OPENS A LANE | 0.1 | +1.7 | 24.1 | 0.0 | 0.2 | +0.5 | 8.6 | 0.0 |
| OPENS UP | 0.0 | +3.1 | 2.2 | 10.6 | 0.3 | +24.3 | 11.4 | 5.4 |
| OVERRUNS AWAY | 0.2 | +10.2 | 41.0 | 10.6 | 0.4 | +12.2 | 54.0 | 37.9 |
| PATHS CROSS | 1.6 | +103.5 | 0.0 | 21.4 | 2.5 | +143.2 | 0.0 | 30.6 |
| PIVOT GUARDS FLANK | 0.1 | -0.7 | 0.0 | 10.3 | 0.1 | -1.8 | 0.0 | 11.0 |
| PLAN RESULT | 39.1 | +1992.4 | 1781.5 | 1010.5 | 38.2 | +1208.8 | 1447.9 | 901.3 |
| PURSUES BIG PREY | 0.0 | -0.9 | 0.0 | 0.0 | 0.1 | -3.1 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.0 | +3.3 | 0.0 | 0.0 | 0.0 | +3.3 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 0.8 | +9.7 | 0.0 | 4.7 |
| RANDOM MOVER NO PROMISE | - | - | - | - | 0.2 | -6.8 | 14.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -3.3 | 0.0 | 2.0 | 0.2 | +3.6 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.5 | +116.3 | 0.0 | 21.2 | 2.5 | +225.2 | 0.0 | 44.8 |
| REDIRECT WEIGHED | 0.2 | +0.8 | 0.0 | 6.8 | 0.5 | -0.5 | 16.4 | 5.9 |
| REFUSING RETIRES | 0.2 | +0.0 | 0.0 | 17.5 | 0.1 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +8.3 | 0.0 | 12.3 | 0.9 | +14.4 | 0.0 | 16.6 |
| RESTRAINS TO SHOOT | 0.2 | +12.0 | 0.0 | 5.1 | 0.1 | +5.7 | 0.0 | 7.4 |
| RISK BY ARC | 1.6 | +44.6 | 181.3 | 78.7 | 2.6 | +21.1 | 227.1 | 74.2 |
| SAFE SURE CHARGE | - | - | - | - | 0.0 | -0.2 | 1.5 | 0.0 |
| SAFER THAN THE JOB | 1.5 | +133.8 | 0.0 | 39.4 | 0.8 | +26.4 | 0.0 | 56.9 |
| SCOUT SPOT | 0.6 | +1.1 | 0.0 | 0.9 | 0.4 | +0.8 | 0.0 | 0.0 |
| SCOUT WAITS | 0.6 | +0.0 | 0.0 | 0.9 | 0.5 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.2 | -12.1 | 0.0 | 3.5 | 0.3 | -11.9 | 0.0 | 1.0 |
| SEARCH SPOT | 2.4 | +128.5 | 0.0 | 62.1 | 2.2 | +101.1 | 0.0 | 16.8 |
| SECOND HUNTER | 0.0 | -0.0 | 0.0 | 0.0 | 0.0 | -0.0 | 2.4 | 0.0 |
| SELF MOVE SPELL | 0.2 | +32.8 | 0.0 | 0.0 | 0.4 | +49.0 | 0.0 | 11.0 |
| SET UP TOGETHER | 1.0 | +72.4 | 41.2 | 25.0 | 4.4 | +575.4 | 270.4 | 235.1 |
| SET-UP ANY TARGET | 0.4 | +58.6 | 9.3 | 10.6 | 0.2 | +21.1 | 0.0 | 0.0 |
| SET-UP MISSED | 0.0 | +4.3 | 10.6 | 10.6 | - | - | - | - |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.1 | -0.7 | 0.0 | 0.0 |
| SHOOTERS ARE THREATS | - | - | - | - | 4.9 | +452.3 | 169.9 | 67.2 |
| SHOOTERS IN TWO RANKS | 0.6 | +1.3 | 0.0 | 0.0 | 0.2 | +0.4 | 0.0 | 0.0 |
| SHOOTERS TO THE PRIMARY | - | - | - | - | 1.4 | +26.5 | 0.0 | 27.2 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +30.0 | 34.0 | 11.3 | 0.9 | +18.3 | 18.2 | 25.9 |
| SHORT GUN FORWARD | 0.5 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 3.3 |
| SHOT OPTIONS | 24.2 | +0.0 | 1172.6 | 458.6 | 14.3 | +0.0 | 411.3 | 245.3 |
| SHOT REPLANNED | 1.4 | +0.0 | 323.8 | 33.3 | - | - | - | - |
| SHOTS IN THE MOVE | 23.0 | +1078.1 | 0.0 | 403.9 | 14.0 | +497.8 | 0.0 | 228.9 |
| SPELL CATCH ODDS | - | - | - | - | 0.0 | -0.3 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.6 | +108.5 | 9.3 | 10.6 | 0.3 | +44.8 | 8.8 | 15.2 |
| SPELL WORTH | 0.8 | +11.5 | 28.9 | 29.2 | 2.0 | +30.3 | 57.6 | 50.8 |
| SPELLS IN THE FIGHT | 0.3 | -8.0 | 59.7 | 20.0 | 0.4 | -4.3 | 9.1 | 0.0 |
| STABLE ROLE | 9.4 | +0.0 | 412.6 | 103.2 | 11.1 | +0.0 | 429.6 | 194.8 |
| STANDS TO CAST | - | - | - | - | 0.0 | +1.9 | 0.0 | 0.0 |
| STAY WEIGHED | 0.1 | +13.4 | 0.0 | 8.2 | - | - | - | - |
| STAY WORTH | - | - | - | - | 18.4 | +247.2 | 318.7 | 369.1 |
| STOPS | 0.1 | +3.4 | 13.8 | 3.2 | 0.2 | +3.6 | 20.0 | 2.2 |
| STOPS SHORT OF THE FLANK | 0.3 | +27.8 | 0.0 | 12.6 | 0.2 | +4.3 | 0.0 | 22.6 |
| STUCK PIVOT | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| SUPPORT JOB KEPT | - | - | - | - | 0.0 | +0.0 | 5.1 | 0.0 |
| SUPPORT NARROWED | 4.6 | -48.9 | 246.7 | 123.2 | 5.2 | -36.2 | 282.3 | 90.9 |
| SUPPORTS | 3.4 | +60.7 | 141.1 | 79.1 | 3.2 | +36.2 | 105.1 | 37.9 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -1.6 | 2.7 | 0.0 | 0.1 | -2.2 | 7.3 | 0.0 |
| SURE REACH TOGETHER | 0.2 | +2.4 | 0.0 | 18.4 | 0.8 | -4.1 | 23.4 | 10.6 |
| THROUGH LINE OF FIRE | 0.9 | +58.5 | 0.0 | 15.0 | 0.4 | +21.9 | 0.0 | 1.8 |
| TURN WORTH | 0.1 | -9.8 | 18.6 | 15.8 | 0.0 | -2.4 | 2.0 | 0.0 |
| TWO OR MORE ARRIVE | 0.2 | +6.8 | 41.2 | 0.0 | 1.2 | +9.7 | 68.6 | 75.9 |
| WAIT AFTER COSTS | 6.0 | -271.9 | 205.4 | 118.4 | 9.2 | -477.2 | 493.3 | 256.1 |
| WALKS TO THE FIGHT | 1.7 | +32.2 | 41.9 | 12.1 | 1.0 | +15.9 | 39.4 | 14.0 |
| WAR ENGINE CHARGES | 0.0 | +2.2 | 0.0 | 0.0 | 0.1 | +6.7 | 5.6 | 3.8 |
| WAR ENGINE JOBS | 0.5 | +0.0 | 35.4 | 15.4 | 0.1 | +0.0 | 1.5 | 3.8 |
| WEARS DOWN | 0.6 | +31.8 | 69.8 | 16.8 | 1.4 | +45.3 | 178.8 | 45.8 |
| WHO HITS BACK | 0.2 | +19.2 | 0.0 | 8.0 | 0.1 | +7.6 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.1 | +9.0 | 20.3 | 0.0 | 0.2 | +14.6 | 13.2 | 0.0 |
| WHOLE FIGHT GAIN | 0.5 | +27.8 | 61.3 | 13.9 | 1.1 | +118.2 | 125.4 | 55.9 |
| WIDER SPREAD | 1.4 | -2.4 | 133.1 | 62.9 | 3.0 | -3.6 | 259.5 | 34.4 |
| WIZARD FRONT RANK | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |

### Rule changes: gf-h2h-opp-0533c46-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1184 | 1184 | 1184 | 32.89 | -55957 | -47.3 |
| BEST FIRST | 290 | 290 | 290 | 8.06 | +9707 | +33.5 |
| COUNTER-CHARGE COVER | 681 | 368 | 164 | 4.56 | +12593 | +76.8 |
| SEARCH SPOT | 163 | 163 | 162 | 4.50 | +8264 | +51.0 |
| PATHS CROSS | 148 | 148 | 148 | 4.11 | +8880 | +60.0 |
| ARTILLERY RE-ROLL WEIGHED | 142 | 142 | 142 | 3.94 | +0 | +0.0 |
| FIRE PLAN | 536 | 536 | 126 | 3.50 | +2122 | +16.8 |
| MOVE TO CHARGE | 291 | 291 | 124 | 3.44 | +5368 | +43.3 |
| FACES THE THREAT | 121 | 121 | 121 | 3.36 | +9180 | +75.9 |
| SHOTS IN THE MOVE | 1332 | 914 | 121 | 3.36 | +4195 | +34.7 |
| CANNON SIGHT KEPT | 118 | 118 | 118 | 3.28 | +0 | +0.0 |
| KILLS COUNT NEXT TURN | 380 | 380 | 107 | 2.97 | +2983 | +27.9 |
| SUPPORTS | 238 | 238 | 99 | 2.75 | +1166 | +11.8 |
| EVERY WOUND COUNTS | 381 | 381 | 94 | 2.61 | +0 | +0.0 |
| SET UP TOGETHER | 192 | 158 | 92 | 2.56 | +8789 | +95.5 |
| SAFER THAN THE JOB | 81 | 81 | 81 | 2.25 | +5770 | +71.2 |
| CANNON PLANNED TARGET | 378 | 378 | 71 | 1.97 | -542 | -7.6 |
| WAIT AFTER COSTS | 548 | 548 | 60 | 1.67 | +1202 | +20.0 |
| CHARGE NOW WEIGHED | 59 | 59 | 59 | 1.64 | +7008 | +118.8 |
| FOLLOW UP WEIGHED | 59 | 59 | 59 | 1.64 | +8253 | +139.9 |
| BEST FACING | 58 | 58 | 58 | 1.61 | +2038 | +35.1 |
| FALLBACK BY WORTH | 322 | 322 | 55 | 1.53 | +3011 | +54.8 |
| SHOT REPLANNED | 50 | 50 | 50 | 1.39 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 47 | 47 | 47 | 1.31 | +2895 | +61.6 |
| WALKS TO THE FIGHT | 98 | 98 | 47 | 1.31 | +653 | +13.9 |
| HONEST THREAT | 381 | 381 | 45 | 1.25 | +0 | +0.0 |
| RESERVE FALL BACK | 43 | 43 | 43 | 1.19 | +818 | +19.0 |
| BEST OVERALL | 42 | 42 | 42 | 1.17 | +3496 | +83.2 |
| SCOUT WAITS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| ADVANCE LANE KEPT | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| MAX FOR POSITIONING | 344 | 180 | 39 | 1.08 | +437 | +11.2 |
| LONE WIZARD KEPT IN | 38 | 38 | 38 | 1.06 | +2846 | +74.9 |
| MAKE SURE TOGETHER | 98 | 70 | 38 | 1.06 | +4258 | +112.1 |
| BEST MOVE FOR SHOOTERS | 36 | 36 | 36 | 1.00 | +1862 | +51.7 |
| CHARGE NOW FIRST | 143 | 143 | 35 | 0.97 | -2070 | -59.1 |
| MISSILES IN THE MOVE | 209 | 111 | 32 | 0.89 | +628 | +19.6 |
| SHOOTERS IN TWO RANKS | 32 | 32 | 32 | 0.89 | +59 | +1.8 |
| HOLDS AMBUSHERS | 31 | 31 | 31 | 0.86 | +0 | +0.0 |
| STAY WORTH | 662 | 502 | 31 | 0.86 | +265 | +8.5 |
| REDIRECT COUNTER | 146 | 78 | 30 | 0.83 | +2279 | +76.0 |
| SHOOTERS ARE THREATS | 178 | 178 | 30 | 0.83 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 58 | 54 | 30 | 0.83 | +1704 | +56.8 |
| RISK BY ARC | 152 | 144 | 29 | 0.81 | +923 | +31.8 |
| REDIRECT WEIGHED | 26 | 26 | 26 | 0.72 | +982 | +37.8 |
| BLOCKED WHEEL | 25 | 25 | 25 | 0.69 | +679 | +27.2 |
| SHOOTS FROM THE BEST SPOT | 58 | 58 | 25 | 0.69 | +952 | +38.1 |
| INVITES THE FIGHT | 122 | 122 | 24 | 0.67 | +342 | +14.2 |
| ONE YARDSTICK | 543 | 205 | 24 | 0.67 | +290 | +12.1 |
| HONEST WORTH | 515 | 509 | 23 | 0.64 | +182 | +7.9 |
| KILLS COUNT | 95 | 92 | 23 | 0.64 | +1050 | +45.7 |
| SHORT GUN FORWARD | 23 | 23 | 23 | 0.64 | +0 | +0.0 |
| MOVE AND CAST | 22 | 22 | 22 | 0.61 | +614 | +27.9 |
| BEST PREY | 56 | 56 | 21 | 0.58 | +883 | +42.0 |
| KEEPS ITS TARGET | 99 | 97 | 21 | 0.58 | +294 | +14.0 |
| STOPS SHORT OF THE FLANK | 21 | 21 | 21 | 0.58 | +1156 | +55.0 |
| MODEL FACING | 20 | 20 | 20 | 0.56 | +7208 | +360.4 |
| COMBAT PIVOT | 18 | 18 | 18 | 0.50 | +0 | +0.0 |
| KEEPS THE TARGET | 45 | 45 | 18 | 0.50 | -1212 | -67.3 |
| FIRE IN ORDER | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| MARCH CHECK | 22 | 19 | 17 | 0.47 | +1179 | +69.4 |
| WEARS DOWN | 70 | 68 | 17 | 0.47 | +594 | +34.9 |
| CAST JOB | 54 | 54 | 16 | 0.44 | +385 | +24.1 |
| BIG CHARACTER SAFETY | 15 | 15 | 15 | 0.42 | -131 | -8.7 |
| CHARGE BAND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| GUN VIEW | 36 | 36 | 14 | 0.39 | +203 | +14.5 |
| LOST CHARGE | 176 | 176 | 14 | 0.39 | +609 | +43.5 |
| RANDOM MOVE BY FIGURES | 29 | 29 | 14 | 0.39 | +350 | +25.0 |
| FRIENDS SHOTS CHECKED | 12 | 12 | 12 | 0.33 | +1192 | +99.3 |
| MISSILES NEXT TURN | 243 | 129 | 12 | 0.33 | +76 | +6.3 |
| CHAFF PASSED | 11 | 11 | 11 | 0.31 | -20 | -1.8 |
| BEST PRIZE | 10 | 10 | 10 | 0.28 | -772 | -77.2 |
| CASTING BLOCK | 12 | 12 | 10 | 0.28 | +541 | +54.1 |
| WHO HITS BACK | 10 | 10 | 10 | 0.28 | +692 | +69.2 |
| RESTRAINS TO SHOOT | 9 | 9 | 9 | 0.25 | +639 | +71.0 |
| CASTER AWAY FROM SCREEN | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| MANOEUVRE | 9 | 9 | 8 | 0.22 | +277 | +34.6 |
| OPENS UP | 12 | 11 | 8 | 0.22 | +279 | +34.9 |
| CASTS FROM BEHIND | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| MARCH ODDS | 7 | 7 | 7 | 0.19 | +189 | +27.0 |
| KEEP FALLS | 6 | 6 | 6 | 0.17 | +292 | +48.7 |
| LONE WIZARD HOLDS BACK | 16 | 16 | 6 | 0.17 | -355 | -59.1 |
| PIVOT GUARDS FLANK | 6 | 6 | 6 | 0.17 | -90 | -15.0 |
| SUPPORT NARROWED | 353 | 353 | 6 | 0.17 | -78 | -12.9 |
| CARRIES OUT SET-UP | 10 | 10 | 5 | 0.14 | -407 | -81.5 |
| HUNT IN PAIRS | 34 | 15 | 5 | 0.14 | +296 | +59.2 |
| KEEPS SCOUTS OR AMBUSH | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| SURE CHARGE BEATS ADVANCE | 5 | 5 | 5 | 0.14 | -137 | -27.4 |
| FACE THE CAST | 4 | 4 | 4 | 0.11 | +24 | +5.9 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +26 | +6.5 |
| OVERRUNS AWAY | 23 | 22 | 4 | 0.11 | +57 | +14.2 |
| PURSUES BIG PREY | 4 | 4 | 4 | 0.11 | -144 | -35.9 |
| SHOOTERS TO THE PRIMARY | 51 | 33 | 4 | 0.11 | +23 | +5.8 |
| STAY WEIGHED | 4 | 4 | 4 | 0.11 | +482 | +120.6 |
| WAR ENGINE JOBS | 24 | 24 | 4 | 0.11 | -358 | -89.4 |
| BACKUP TARGETS | 55 | 25 | 3 | 0.08 | +32 | +10.8 |
| DEFENSIVE ARMY | 16 | 16 | 3 | 0.08 | -36 | -11.9 |
| EDGE GIVE GROUND | 7 | 7 | 3 | 0.08 | +116 | +38.6 |
| GUN THREAT | 31 | 31 | 3 | 0.08 | +0 | +0.0 |
| LONG SHOT | 24 | 24 | 3 | 0.08 | +59 | +19.7 |
| SPELLS IN THE FIGHT | 25 | 23 | 3 | 0.08 | +52 | +17.3 |
| STUCK PIVOT | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| WIDER SPREAD | 158 | 149 | 3 | 0.08 | +7 | +2.4 |
| BLOCKED CHARGE SKIPPED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +23 | +11.5 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +29 | +14.7 |
| GUN MASK | 18 | 6 | 2 | 0.06 | +15 | +7.6 |
| HUNT ADVANCE | 15 | 15 | 2 | 0.06 | +115 | +57.5 |
| MISSILES IN THE FIRE PLAN | 42 | 7 | 2 | 0.06 | +3 | +1.4 |
| MOVE SPELL IN RANGE | 12 | 8 | 2 | 0.06 | +0 | +0.0 |
| NEEDED THERE | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| REDIRECT BY WHAT IT STOPS | 10 | 10 | 2 | 0.06 | +26 | +13.0 |
| REFUSING RETIRES | 10 | 10 | 2 | 0.06 | -1 | -0.7 |
| SURE REACH TOGETHER | 36 | 24 | 2 | 0.06 | +9 | +4.3 |
| WHOLE FIGHT | 10 | 10 | 2 | 0.06 | +168 | +84.0 |
| BLOWS WHERE AIMED | 20 | 17 | 1 | 0.03 | +33 | +33.2 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +58 | +58.5 |
| CARRIES OUT COUNTER | 4 | 4 | 1 | 0.03 | -35 | -35.0 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -8 | -7.5 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +34 | +33.9 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +4 | +4.4 |
| JOINT CHARGE PLAN | 21 | 21 | 1 | 0.03 | +155 | +154.6 |
| OPENS A LANE | 10 | 8 | 1 | 0.03 | +5 | +4.7 |
| RAIDS THE BAGGAGE NEXT TURN | 2 | 2 | 1 | 0.03 | +67 | +67.4 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -29 | -29.3 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | -11 | -11.2 |
| STOPS | 8 | 8 | 1 | 0.03 | +100 | +100.1 |
| SUPPORT JOB KEPT | 1 | 1 | 1 | 0.03 | +4 | +3.8 |
| WAR ENGINE CHARGES | 5 | 5 | 1 | 0.03 | +26 | +26.4 |
| WIZARD FRONT RANK | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| ALREADY CARRIED | 4 | not checked | - | - | - | - |
| ARRIVAL HUNT | 4 | 4 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 56 | 56 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 38 | trace | - | - | - | - |
| CATCH FLIERS | 3 | not checked | - | - | - | - |
| CHARGER SLAIN LOST | 35 | 32 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 2 | 2 | 0 | 0.00 | - | - |
| CHEAP HELPER | 5 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 43 | not checked | - | - | - | - |
| ENGINEER BY LORE | 10 | 10 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 381 | not checked | - | - | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 3 | not checked | - | - | - | - |
| GUN FIGURES | 49 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 4 | not checked | - | - | - | - |
| HELPER UNSEEN | 19 | 18 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 10 | 10 | 0 | 0.00 | - | - |
| HUNT DROPPED | 8 | trace | - | - | - | - |
| HUNT KEPT | 6 | trace | - | - | - | - |
| HUNT RESULT | 18 | trace | - | - | - | - |
| HUNT THE GUNS | 21 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 11 | 9 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 36 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 24 | 24 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 29 | 29 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 27 | trace | - | - | - | - |
| MOVE SPELL SPOT | 11 | not checked | - | - | - | - |
| NOT NEEDED | 13 | 12 | 0 | 0.00 | - | - |
| NOT TURNED | 347 | 347 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 38 | not checked | - | - | - | - |
| PLAN RESULT | 2781 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 6 | 6 | 0 | 0.00 | - | - |
| SCOUT SPOT | 37 | 37 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 18 | 18 | 0 | 0.00 | - | - |
| SECOND HUNTER | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 20 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 23 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOT OPTIONS | 1386 | 1386 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 31 | not checked | - | - | - | - |
| SPELL WORTH | 101 | not checked | - | - | - | - |
| STABLE ROLE | 738 | 737 | 0 | 0.00 | - | - |
| TURN WORTH | 6 | 6 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 52 | 39 | 0 | 0.00 | - | - |

### Off best figure: gf-h2h-opp-0533c46-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 15.00 | 15.00 | 47.9 |
| FALLBACK | gate | 0.50 | 0.56 | 25.2 |
| CHARGE NOW FIRST | rule | 0.22 | 0.75 | 59.1 |
| TURN GATE | gate | 0.56 | 0.33 | 56.0 |
| LONE CHARACTER SAFE SPOT | gate | 0.25 | 0.25 | 60.3 |
| CHARGE NOW WEIGHED | rule | 0.19 | 0.22 | 41.5 |
| FIRE PLAN | rule | - | 0.33 | 35.3 |
| KEEPS THE TARGET | rule | - | 0.31 | 128.8 |
| BEST PRIZE | rule | 0.03 | 0.25 | 77.2 |
| BIG CHARACTER SAFETY | rule | 0.03 | 0.25 | 15.6 |
| PATHS CROSS | rule | 0.17 | 0.08 | 12.9 |
| CANNON PLANNED TARGET | rule | 0.22 | - | 81.8 |
| PIVOT GUARDS FLANK | rule | 0.08 | 0.08 | 15.0 |
| SUPPORT NARROWED | rule | 0.06 | 0.11 | 12.9 |
| THROUGH LINE OF FIRE | rule | 0.08 | 0.08 | 26.5 |
| CARRIES OUT SET-UP | rule | 0.06 | 0.08 | 81.5 |
| LONE WIZARD HOLDS BACK | rule | - | 0.14 | 70.9 |
| SAFER THAN THE JOB | rule | 0.03 | 0.11 | 23.1 |
| STOPS SHORT OF THE FLANK | rule | - | 0.14 | 8.2 |
| SUPPORT REQUEST | gate | 0.08 | 0.06 | 49.1 |
| SURE CHARGE BEATS ADVANCE | rule | 0.08 | 0.06 | 27.4 |
| AFTERMATH BAND | gate | 0.06 | 0.06 | 1.4 |
| PURSUES BIG PREY | rule | 0.03 | 0.08 | 35.9 |
| WAR ENGINE JOBS | rule | 0.06 | 0.06 | 89.4 |
| BLOCKED WHEEL | rule | 0.06 | 0.03 | 12.7 |
| CHAFF PASSED | rule | 0.08 | - | 6.3 |
| REDIRECT WEIGHED | rule | - | 0.08 | 82.9 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | - | 56.6 |
| DEFENSIVE ARMY | rule | 0.06 | - | 17.6 |
| FIGHT ORDER BAND | gate | 0.06 | - | 1.8 |
| REFUSING RETIRES | rule | 0.06 | - | 0.7 |
| RULE SWITCHED OFF | gate | 0.06 | - | 15.0 |
| CARRIES OUT COUNTER | rule | - | 0.03 | 35.0 |
| CATCH ODDS | rule | - | 0.03 | 7.5 |
| FALLBACK BY WORTH | rule | 0.03 | - | 39.3 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | - | 1.2 |
| NO REASON | gate | - | 0.03 | 3.4 |
| SAFE SURE CHARGE | rule | - | 0.03 | 29.3 |
| STANDS TO CAST | rule | - | 0.03 | 11.2 |
| WHO HITS BACK | rule | 0.03 | - | 2.6 |

### Plans: gf-h2h-opp-0533c46-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 10.5 | 12% | 363 | 332 | 92% |
| Mine | charge | 2.1 | 60% | 141 | 212 | 150% |
| Mine | close in | 3.3 | 27% | 156 | 157 | 101% |
| Mine | hold | 3.5 | 33% | 231 | 0 | 0% |
| Mine | join | 0.9 | 97% | 20 | 0 | 0% |
| Mine | shoot | 15.1 | 66% | 396 | 1291 | 326% |
| Mine | support | 3.7 | 89% | 37 | 0 | 0% |
| Opponent | advance | 11.9 | 18% | 375 | 320 | 85% |
| Opponent | charge | 4.0 | 52% | 310 | 339 | 109% |
| Opponent | close in | 6.2 | 21% | 609 | 217 | 36% |
| Opponent | hold | 4.5 | 50% | 311 | 0 | 0% |
| Opponent | join | 1.0 | 94% | 39 | 0 | 0% |
| Opponent | shoot | 6.9 | 57% | 279 | 335 | 120% |
| Opponent | support | 3.6 | 89% | 24 | 0 | 0% |

### Packages: hunt the guns, gf-h2h-opp-0533c46-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 5 | 0 | 40% | 40% | 0% | 2.5 | 401 | 170 | 40% | 78 |
| Opponent | 0.4 | 16 | 3 | 31% | 54% | 0% | 2.3 | 215 | 95 | 54% | 200 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 65 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 22 |
| Dwarfen Mountain Holds | 0.2 | 3 | 0 | 33% | 33% | 0% | 2.0 | 291 | 149 | 33% | 160 |
| Empire of Man | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 582 | 0 | 0% | 90 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 348 |
| High Elf Realms | 0.6 | 3 | 0 | 33% | 33% | 0% | 3.0 | 412 | 134 | 33% | 335 |
| Kingdom of Bretonnia | 0.7 | 2 | 0 | 50% | 50% | 0% | 2.0 | 162 | 64 | 50% | 185 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 78 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 104 |
| Tomb Kings of Khemri | 1.1 | 8 | 2 | 0% | 50% | 0% | 2.7 | 142 | 53 | 50% | 48 |
| Vampire Counts | 0.8 | 3 | 1 | 100% | 100% | 0% | 2.0 | 235 | 198 | 100% | 0 |
| Warriors of Chaos | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 458 | 391 | 100% | 293 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 112 |

### Battle groups: gf-h2h-opp-0533c46-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 12.5 | 18% | 58% | 5% | 75% | 28% | 9% | 6% | 57% | 0% |
| Mine | REDIRECT COUNTER | 1.5 | 31% | 53% | 29% | 20% | 0% | 0% | 8% | 92% | 0% |
| Opponent | COUNTER-CHARGE COVER | 6.4 | 13% | 50% | 30% | 44% | 48% | 10% | 10% | 33% | 0% |
| Opponent | REDIRECT COUNTER | 2.5 | 26% | 71% | 12% | 0% | 19% | 0% | 24% | 57% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: gf-h2h-opp-0533c46-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 2 | 0 (2) | 0 | 0 | 100 | 0% | 4.5 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Mine | Chaff | 34 | 38 (34) | 20 | 17 | 56 | 44% | 2.1 | 61 (20) | 0 (9) | 0 (5) | 49 (27) | 0 (7) |
| Mine | Character | 139 | 33 (139) | 33 | 0 | 45 | 32% | 2.4 | 24 (41) | 46 (70) | 23 (5) | 32 (68) | 45 (48) |
| Mine | Clean-up | 17 | 0 (17) | 0 | 0 | 54 | 65% | 2.0 | 0 (4) | 0 (12) | 0 (1) | 0 (9) | 0 (8) |
| Mine | Fast | 2 | 0 (2) | 0 | 0 | 100 | 0% | 1.0 | - | 0 (2) | - | 0 (2) | - |
| Mine | Fast Hammer | 35 | 35 (35) | 19 | 16 | 42 | 29% | 2.5 | 30 (13) | 38 (17) | 40 (5) | 52 (22) | 10 (13) |
| Mine | Fragile | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Hammer | 62 | 37 (62) | 20 | 17 | 46 | 29% | 2.3 | 16 (19) | 54 (38) | 8 (5) | 48 (40) | 17 (22) |
| Mine | Holder | 24 | 104 (24) | 2 | 102 | 11 | 29% | 2.0 | 0 (2) | 140 (17) | 29 (4) | 133 (16) | 56 (7) |
| Mine | Shooter | 41 | 68 (41) | 39 | 29 | 38 | 2% | 1.7 | 51 (10) | 82 (24) | 39 (7) | 88 (22) | 47 (19) |
| Mine | War machine | 112 | 57 (112) | 57 | 0 | 46 | 4% | 1.3 | 47 (36) | 60 (68) | 69 (8) | 47 (29) | 60 (83) |
| Mine | Wizard | 18 | 1 (18) | 1 | 0 | 29 | 17% | 2.7 | 3 (5) | 0 (5) | 0 (5) | 0 (8) | 2 (7) |
| Opponent | Chaff | 59 | 71 (59) | 28 | 43 | 48 | 32% | 2.5 | 90 (28) | 89 (15) | 21 (16) | 72 (44) | 65 (15) |
| Opponent | Character | 108 | 58 (108) | 58 | 0 | 33 | 36% | 2.4 | 65 (37) | 52 (50) | 74 (15) | 48 (65) | 77 (37) |
| Opponent | Clean-up | 22 | 49 (22) | 20 | 29 | 21 | 45% | 3.3 | 39 (8) | 69 (10) | 26 (4) | 51 (13) | 46 (9) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast | 5 | 0 (5) | 0 | 0 | 83 | 60% | 1.5 | - | 0 (5) | - | 0 (4) | 0 (1) |
| Opponent | Fast Hammer | 49 | 46 (49) | 24 | 22 | 47 | 33% | 2.8 | 31 (19) | 35 (19) | 102 (11) | 44 (37) | 54 (12) |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Hammer | 42 | 52 (42) | 34 | 19 | 29 | 26% | 2.6 | 16 (12) | 57 (26) | 106 (4) | 53 (27) | 50 (15) |
| Opponent | Holder | 38 | 94 (38) | 13 | 80 | 12 | 29% | 2.0 | 58 (5) | 102 (26) | 90 (7) | 117 (25) | 52 (13) |
| Opponent | Shooter | 21 | 73 (21) | 22 | 51 | 3 | 0% | 1.6 | 0 (5) | 105 (14) | 0 (2) | 82 (12) | 62 (9) |
| Opponent | Support | 4 | 31 (4) | 31 | 0 | 0 | 25% | 4.7 | 0 (2) | 0 (1) | 107 (1) | 0 (1) | 43 (3) |
| Opponent | War machine | 45 | 49 (45) | 49 | 0 | 52 | 11% | 1.4 | 88 (17) | 12 (21) | 68 (7) | 65 (10) | 45 (35) |
| Opponent | Wizard | 32 | 26 (32) | 26 | 0 | 36 | 19% | 1.7 | 0 (15) | 87 (9) | 0 (2) | 10 (14) | 67 (12) |

### Charged fights: gf-h2h-opp-0533c46-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 196 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Chaos Dwarfs | 4 | 427 | 0 | 0.5 | 1.0 | 0 | 292 | -292 | 1 of 2 | 2 of 2 | - | -292 |
| Mine | Dwarfen Mountain Holds | 11 | 547 | 15 | 0.8 | 1.1 | 19 | 32 | -13 | 4 of 9 | 3 of 9 | -60 | -7 |
| Mine | Empire of Man | 11 | 363 | 148 | 1.4 | 1.1 | 109 | 138 | -29 | 7 of 15 | 13 of 15 | -117 | -16 |
| Mine | High Elf Realms | 2 | 117 | 382 | 3.5 | 1.0 | 109 | 0 | +109 | 3 of 7 | 6 of 7 | - | +109 |
| Mine | Ogre Kingdoms | 2 | 58 | 144 | 4.5 | 1.1 | 32 | 43 | -12 | 2 of 9 | 6 of 9 | +0 | -13 |
| Mine | Tomb Kings of Khemri | 3 | 14 | 1109 | 3.3 | 1.1 | 333 | 0 | +333 | 5 of 10 | 6 of 10 | +393 | +326 |
| **Mine** | all armies | 36 | 353 | 172 | 1.4 | 1.1 | 119 | 64 | +55 | 22 of 52 | 36 of 52 | +20 | +58 |
| Opponent | Chaos Dwarfs | 1 | 55 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Dwarfen Mountain Holds | 1 | 160 | 0 | 3.0 | 1.3 | 0 | 20 | -20 | 1 of 3 | 2 of 3 | -60 | +0 |
| Opponent | Empire of Man | 6 | 356 | 320 | 1.7 | 1.2 | 192 | 142 | +50 | 7 of 10 | 7 of 10 | -91 | +85 |
| Opponent | Grand Cathay | 4 | 313 | 741 | 2.0 | 2.0 | 371 | 75 | +295 | 6 of 8 | 6 of 8 | +500 | -46 |
| Opponent | High Elf Realms | 3 | 102 | 490 | 3.7 | 1.5 | 134 | 0 | +134 | 8 of 11 | 7 of 11 | +124 | +142 |
| Opponent | Kingdom of Bretonnia | 3 | 237 | 350 | 3.0 | 1.0 | 117 | 0 | +117 | 5 of 9 | 6 of 9 | - | +117 |
| Opponent | Ogre Kingdoms | 1 | 70 | 0 | 3.0 | 1.3 | 0 | 11 | -11 | 1 of 3 | 1 of 3 | +0 | -17 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 660 | 5.0 | 1.4 | 132 | 0 | +132 | 2 of 5 | 4 of 5 | +30 | +200 |
| Opponent | Tomb Kings of Khemri | 4 | 42 | 913 | 4.8 | 1.2 | 192 | 0 | +192 | 8 of 19 | 14 of 19 | +289 | +174 |
| Opponent | Vampire Counts | 4 | 0 | 517 | 5.2 | 1.2 | 98 | 15 | +83 | 9 of 21 | 17 of 21 | +47 | +92 |
| Opponent | Warriors of Chaos | 6 | 0 | 212 | 1.7 | 1.3 | 127 | 48 | +79 | 5 of 10 | 10 of 10 | +18 | +94 |
| Opponent | Wood Elf Realms | 2 | 194 | 188 | 2.5 | 1.2 | 75 | 22 | +53 | 2 of 5 | 5 of 5 | +138 | +32 |
| **Opponent** | all armies | 36 | 146 | 429 | 2.9 | 1.3 | 147 | 29 | +118 | 55 of 105 | 79 of 105 | +160 | +104 |

### Effective charges: gf-h2h-opp-0533c46-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 0 | 0 | 0 | 1 (net -583) | 0 | 0 | 1 | 0% (0 of 1) |
| Mine | Dwarfen Mountain Holds | 9 | 6 (net -27) | 0 | 1 (net +0) | 2 (net +22) | 0 | 0 | 0 | 11% (1 of 9) |
| Mine | Empire of Man | 15 | 2 (net -28) | 0 | 3 (net -247) | 6 (net +49) | 0 | 2 (net +33) | 2 | 23% (3 of 13) |
| Mine | High Elf Realms | 7 | 1 (net +100) | 0 | 1 (net +60) | 2 (net +0) | 0 | 2 (net +286) | 1 | 17% (1 of 6) |
| Mine | Ogre Kingdoms | 9 | 0 | 0 | 0 | 1 (net +0) | 4 (net +72) | 1 (net +0) | 3 | 0% (0 of 6) |
| Mine | Tomb Kings of Khemri | 10 | 3 (net +699) | 0 | 0 | 3 (net +282) | 0 | 3 (net +95) | 1 | 0% (0 of 9) |
| Opponent | Chaos Dwarfs | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Dwarfen Mountain Holds | 3 | 0 | 1 (net -60) | 0 | 1 (net +0) | 0 | 1 (net +0) | 0 | 0% (0 of 3) |
| Opponent | Empire of Man | 10 | 2 (net -190) | 0 | 3 (net -272) | 2 (net +816) | 2 (net +32) | 0 | 1 | 33% (3 of 9) |
| Opponent | Grand Cathay | 8 | 2 (net -116) | 0 | 4 (net +496) | 2 (net +306) | 0 | 0 | 0 | 50% (4 of 8) |
| Opponent | High Elf Realms | 11 | 0 | 0 | 2 (net +115) | 3 (net +207) | 1 (net +328) | 0 | 5 | 33% (2 of 6) |
| Opponent | Kingdom of Bretonnia | 9 | 1 (net +0) | 0 | 0 | 4 (net +120) | 0 | 3 (net +63) | 1 | 0% (0 of 8) |
| Opponent | Ogre Kingdoms | 3 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 2 | 0% (0 of 1) |
| Opponent | Orc & Goblin Tribes | 5 | 1 (net +435) | 0 | 0 | 1 (net +0) | 2 (net +60) | 0 | 1 | 0% (0 of 4) |
| Opponent | Tomb Kings of Khemri | 19 | 2 (net +500) | 0 | 5 (net +68) | 6 (net +154) | 1 (net +185) | 3 (net +359) | 2 | 29% (5 of 17) |
| Opponent | Vampire Counts | 21 | 8 (net +83) | 0 | 2 (net +152) | 5 (net +84) | 4 (net +60) | 2 (net +61) | 0 | 10% (2 of 21) |
| Opponent | Warriors of Chaos | 10 | 2 (net +62) | 1 (net +185) | 0 | 0 | 2 (net -222) | 2 (net +190) | 3 | 0% (0 of 7) |
| Opponent | Wood Elf Realms | 5 | 0 | 0 | 0 | 2 (net -36) | 0 | 0 | 3 | 0% (0 of 2) |

### Charged fights, damage counted: gf-h2h-opp-0533c46-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 12 | 231 | 305 | +165 | 266 | 110 | +155 | +67.2 |
| Mine | Effective (55-75%) | 5 | 291 | 277 | -136 | 64 | 178 | -114 | -39.2 |
| Mine | 76-89% | 15 | 232 | 166 | +40 | 129 | 71 | +58 | +25.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 8 | 289 | 210 | +115 | 162 | 75 | +86 | +29.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 254 | 59 | +72 | 82 | 2 | +80 | +31.6 |
| Mine | No odds | 8 | 262 | 153 | -32 | 41 | 56 | -15 | -5.7 |
| Mine | All fights | 52 | 253 | 205 | +55 | 142 | 83 | +59 | +23.3 |
| Opponent | Long shot (under 50%) | 18 | 244 | 208 | +89 | 143 | 62 | +81 | +33.1 |
| Opponent | 50-54% | 2 | 127 | 184 | +62 | 92 | 40 | +52 | +41.1 |
| Opponent | Effective (55-75%) | 16 | 433 | 236 | +128 | 200 | 101 | +98 | +22.7 |
| Opponent | 76-89% | 27 | 328 | 214 | +171 | 203 | 55 | +148 | +45.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 12 | 334 | 189 | +147 | 167 | 16 | +151 | +45.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 12 | 505 | 79 | +41 | 87 | 62 | +25 | +5.0 |
| Opponent | No odds | 18 | 285 | 162 | +97 | 104 | 3 | +101 | +35.3 |
| Opponent | All fights | 105 | 339 | 188 | +118 | 156 | 50 | +105 | +31.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| gf-h2h-opp-0533c46-p1 | move | 403 | 67 (17%) | 42 (10%) | 43 (11%) | 293 (73%) |
| gf-h2h-opp-0533c46-p1 | objective | 349 | 43 (12%) | 33 (9%) | 49 (14%) | 257 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0103, L0108, L0109 |
| Charmed Shield | Opponent | L0627, L0725, L0827, L2224 |
| Clockwork Compass | Opponent | L0712 |
| Elixir of Power | Opponent | L0511, L0619 |
| Fistful of Laurels | Mine | L1822, L1831 |
| Fistful of Laurels | Opponent | L1318 |
| Horn of the Wild Hunt | Opponent | L0833 |
| Invocation of Nehek | Opponent | L0627, L0725, L0827, L2224 |
| Opal Amulet | Opponent | L0614 |
| Ring of Doom | Mine | L1516 |
| Ring of Doom | Opponent | L0315, L0511, L0615, L0712, L0731, L0833, L1831 |
| Ring of Jet | Opponent | L0510, L0511, L0712, L0810 |
| Standard of the Fell Warrior | Mine | L1318 |
| Twice-Blessed Armour | Mine | L0708, L0712, L0716, L0725, L0730, L0731 |
| Twice-Blessed Armour | Opponent | L0507, L0510, L0810 |
| Witch Hunter's Ward | Mine | L0708, L0712, L0716, L0725, L0730, L0731, L0810, L0827, L0832, L0833, L0835 |
| Witch Hunter's Ward | Opponent | L0108, L0507, L0508, L0708 |

# Doctrine scorecard: shots-h2h-mine-7c46ffc-p4

### Scorecard: shots-h2h-mine-7c46ffc-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 5 | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | yes | 9 | - | 0 | 1 | 0 | 0 | 0 | 65 |
| L0130 | 4 | 1 | Opponent | no | 1 | 1 | 5 | 3 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | no | 1 | 3 | 5 | 1 | 0 | 0 | 0 | 170 |
| L0214 | 4 | 1 | Opponent | no | 4 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | - | 1 | 6 | 0 | 0 | 0 | 255 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | no | 0 | - | 1 | 0 | 0 | 0 | 0 | 590 |
| L0315 | 3 | 1 | Opponent | yes | 10 | 2 | 1 | 2 | 1 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | 4 | 1 | 1 | 1 | 0 | 0 | 590 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 3 | 7 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | yes | 1 | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 0 | 2 | 7 | 0 | 1 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Mine | - | - | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 1120 |
| L0520 | 4 | 1 | Opponent | no | 0 | 3 | 0 | 6 | 1 | 0 | 0 | 210 |
| L0608 | 2 | 1 | Mine | - | - | 5 | 5 | 1 | 0 | 0 | 0 | 798 |
| L0608 | 2 | 1 | Opponent | - | - | 5 | 2 | 2 | 0 | 0 | 0 | 605 |
| L0624 | 6 | 1 | Mine | no | 0 | 3 | 1 | 0 | 0 | 0 | 0 | 1086 |
| L0624 | 6 | 1 | Opponent | no | 8 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | no | - | - | 3 | 2 | 1 | 0 | 0 | 420 |
| L0713 | 5 | 1 | Opponent | yes | - | 2 | 1 | 2 | 0 | 0 | 0 | 140 |
| L0729 | 3 | 1 | Mine | no | 2 | 4 | 2 | 0 | 0 | 0 | 0 | 375 |
| L0729 | 3 | 1 | Opponent | no | 1 | 3 | 3 | 0 | 1 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 511 |
| L0819 | 3 | 1 | Opponent | no | 2 | 2 | 3 | 2 | 2 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | 3 | 1 | 1 | 0 | 0 | 0 | 602 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 5 | 5 | 1 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1017 | 3 | 1 | Opponent | yes | 4 | 2 | 4 | 0 | 2 | 0 | 0 | 49 |
| L1034 | 2 | 1 | Mine | - | - | 1 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1126 | 4 | 1 | Mine | no | 1 | 6 | 1 | 1 | 0 | 0 | 0 | 425 |
| L1126 | 4 | 1 | Opponent | no | 9 | 2 | 7 | 3 | 0 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 3 | 2 | 0 | 1 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 3 | 5 | 0 | 0 | 0 | 65 |
| L1314 | 6 | 1 | Mine | no | 10 | 2 | 2 | 0 | 0 | 0 | 0 | 140 |
| L1314 | 6 | 1 | Opponent | no | 0 | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1331 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 317 |
| L1331 | 5 | 1 | Opponent | yes | - | 5 | 2 | 2 | 2 | 0 | 0 | 170 |
| L1427 | 5 | 1 | Mine | no | - | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | yes | - | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | yes | - | 2 | 8 | 0 | 1 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 3 | 3 | 2 | 1 | 0 | 0 | 251 |
| L1621 | 1 | 1 | Mine | no | 2 | 2 | 5 | 0 | 0 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 0 | 4 | 4 | 4 | 1 | 0 | 0 | 500 |
| L1719 | 3 | 1 | Mine | no | 0 | 2 | 6 | 0 | 0 | 0 | 0 | 49 |
| L1719 | 3 | 1 | Opponent | yes | 2 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Mine | no | 0 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | no | - | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | yes | - | 1 | 1 | 4 | 0 | 0 | 0 | 0 |
| L2021 | 5 | 1 | Mine | yes | - | - | 0 | 4 | 1 | 0 | 0 | 420 |
| L2021 | 5 | 1 | Opponent | yes | - | - | 0 | 5 | 0 | 0 | 0 | 355 |
| L2123 | 5 | 1 | Mine | yes | - | - | 1 | 4 | 1 | 0 | 0 | 290 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | no | 0 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | yes | 1 | 1 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Mine | no | 5 | 2 | 6 | 0 | 1 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Opponent | yes | 1 | 6 | 2 | 0 | 1 | 0 | 0 | 170 |
| L2527 | 1 | 1 | Mine | no | 0 | 3 | 1 | 0 | 0 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 0 | 1 | 4 | 1 | 1 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Mine | no | 7 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 3 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Mine | - | - | 2 | 6 | 0 | 1 | 0 | 0 | 323 |
| L2930 | 2 | 1 | Opponent | - | - | 2 | 6 | 3 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 3 | 2 | 3 | 2 | 0 | 0 | 0 | 170 |
| L3234 | 6 | 1 | Opponent | no | 0 | 2 | 1 | 3 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 18% | 2.2 | 2.7 | 2.7 | 1.0 | 0.2 | 0.0 | 0.0 | 289.5 |
| **Average** | | | Opponent | 46% | 2.2 | 2.3 | 3.2 | 2.2 | 0.4 | 0.0 | 0.0 | 74.6 |

### KPIs: shots-h2h-mine-7c46ffc-p4

Rules off - Opponent only: STAY WORTH, BEST MOVE FOR SHOOTERS, THREAT IN THE KILL, FOCUS OVER TURNS, MISSILES IN THE PLAN, FACE THE CAST, WIZARD FRONT RANK.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 25% (45 of 180) | 1% (2 of 187) | 13% (47 of 367) |
| Winner chose to follow up after the loser gave ground |  | 98% (53 of 54); on the table 98% | 91% (58 of 64); on the table 91% | 94% (111 of 118); on the table 94% |
| Winner chose to pursue after the loser fell back in good order |  | 87% (13 of 15); on the table 87% | 91% (20 of 22); on the table 95% | 89% (33 of 37); on the table 92% |
| Winner chose to pursue after the loser fled |  | 79% (19 of 24); on the table 88% | 74% (20 of 27); on the table 78% | 76% (39 of 51); on the table 82% |
| Winner chose to follow up or pursue (all three) |  | 91% (85 of 93); on the table 94% | 87% (98 of 113); on the table 88% | 89% (183 of 206); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 31% (84 of 269) | 33% (56 of 171) | 32% (140 of 440) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 47% (84 of 180) | 46% (56 of 123) | 46% (140 of 303) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 30% (40 of 132) | 32% (28 of 87) | 31% (68 of 219) |
|     round 1 |  | 14% (3 of 22) | 33% (5 of 15) | 22% (8 of 37) |
|     rounds 2+ |  | 34% (37 of 110) | 32% (23 of 72) | 33% (60 of 182) |
|   other wizards | 50%+ | 32% (44 of 137) | 30% (24 of 80) | 31% (68 of 217) |
|     round 1 |  | 13% (3 of 23) | 29% (4 of 14) | 19% (7 of 37) |
|     rounds 2+ |  | 36% (41 of 114) | 30% (20 of 66) | 34% (61 of 180) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 53% (19 of 36) | 65% (41 of 63) | 61% (60 of 99) |
| Points that never fought | lower | 33% (22570 of 67942) | 38% (27201 of 71984) | 36% (49771 of 139926) |
|   infantry points that never fought | lower | 39% (6034 of 15347) | 64% (8838 of 13804) | 51% (14872 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 58% (156 of 270) | 55% (153 of 280) | 56% (309 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 91% (20 of 22); 1.4 uses a game | 89% (8 of 9); 0.6 uses a game | 90% (28 of 31); 1.0 uses a game |
| Bound items with another spell used |  | 56% (9 of 16); 0.6 uses a game | 40% (8 of 20); 0.4 uses a game | 47% (17 of 36); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 47% (9 of 19); 0.2 uses a game | 87% (13 of 15); 0.4 uses a game | 65% (22 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 51% (29251 of 57750) | 46% (28994 of 63347) | 48% (58245 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.2 (24%) | 0.9 (30%) | 2.2 (26%) |
| MARCHED: its unit marched | 1.0 (20%) | 0.4 (13%) | 1.4 (17%) |
| CHARGED: its unit charged | 0.2 (4%) | 0.3 (10%) | 0.5 (6%) |
| IN COMBAT: engaged in combat | 1.5 (29%) | 0.6 (18%) | 2.1 (25%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (5%) | 0.2 (2%) |
| FLEEING: fleeing | 0.1 (1%) | 0.2 (6%) | 0.2 (3%) |
| GONE: slain | 0.8 (16%) | 0.5 (16%) | 1.3 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.1 (2%) | 0.1 (2%) |
| STUPIDITY: Stupidity | 0.2 (4%) | 0.0 (0%) | 0.2 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.2 | 1.4 | 1.7 | 3.9 | 0.4 | 2.5 |
| not cast | 2.9 | 2.6 | 3.2 | 8.3 | 1.6 | 20.4 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.8 (9%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.2 (46%) | 0.1 (4%) | 2.2 (26%) | 0.4 (27%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (17%) | 0.3 (18%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (6%) | 0.0 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (4%) | 0.2 (10%) | 0.7 (23%) | 2.1 (25%) | 0.5 (32%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (6%) | 0.2 (7%) | 0.2 (8%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (8%) | 0.2 (8%) | 0.2 (8%) | 0.2 (3%) | 0.0 (0%) | 1.0 (5%) |
| GONE: slain | 0.7 (23%) | 0.5 (18%) | 0.3 (10%) | 1.3 (16%) | 0.2 (11%) | 2.8 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.1 (2%) | 0.0 (0%) | 0.2 (1%) |
| STUPIDITY: Stupidity | 0.1 (4%) | 0.1 (2%) | 0.1 (4%) | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.2 (7%) | 0.0 (0%) | 0.0 (0%) | 0.2 (11%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.6 (55%) | 0.1 (3%) | 1.4 (44%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.5 (71%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.1 a game | 0.6 a game | 0.9 a game |
| stood (cast and not dispelled) | 67% (26 of 39) | 50% (7 of 14) | 62% (33 of 53) |
| the unit moved after it | 73% (19 of 26) | 43% (3 of 7) | 67% (22 of 33) |
| it charged on its next turn | 8% (2 of 26) | 0% (0 of 7) | 6% (2 of 33) |
| the enemy charged it first | 19% (5 of 26) | 0% (0 of 7) | 15% (5 of 33) |
| it fought by the end of its next turn | 27% (7 of 26) | 14% (1 of 7) | 24% (8 of 33) |
| it moved out of a charge the enemy had planned (not charged first) | 12% (3 of 26) | 14% (1 of 7) | 12% (4 of 33) |
| none of these (no charge, no fight, no charge escaped) | 42% (11 of 26) | 86% (6 of 7) | 52% (17 of 33) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (560 of 862) | 52% (281 of 545) | 60% (841 of 1407) |
|   cavalry | 66% (55 of 83) | 63% (76 of 121) | 64% (131 of 204) |
|   character | 47% (47 of 101) | 13% (17 of 134) | 27% (64 of 235) |
|   chariot | 47% (50 of 106) | 61% (11 of 18) | 49% (61 of 124) |
|   infantry | 62% (166 of 266) | 65% (145 of 222) | 64% (311 of 488) |
|   monster | 50% (21 of 42) | 32% (6 of 19) | 44% (27 of 61) |
|   war machine | 84% (221 of 264) | 84% (26 of 31) | 84% (247 of 295) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.8 (21%) | 1.5 (20%) | 3.3 (21%) |
| CHARGED: it charged | 1.1 (14%) | 2.0 (28%) | 3.2 (20%) |
| FLEEING: it fled or was fleeing | 0.1 (2%) | 0.3 (4%) | 0.4 (3%) |
| IN COMBAT: it fought this turn or the last | 0.7 (9%) | 0.7 (9%) | 1.4 (9%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.8 (22%) | 1.0 (13%) | 2.8 (18%) |
| ONLY IN COMBAT: the only targets were in combat | 0.8 (10%) | 0.5 (6%) | 1.3 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (17%) | 1.3 (18%) | 2.7 (17%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR | 0.3 (3%) | 0.1 (1%) | 0.4 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.1 | 1.7 | 78% | 5.8 pts | 35 pts |
| character | 1.9 | 0.7 | 72% | 6.5 pts | 12 pts |
| chariot | 1.7 | 1.1 | 65% | 15.3 pts | 26 pts |
| infantry | 12.8 | 5.0 | 70% | 10.3 pts | 132 pts |
| monster | 0.8 | 0.2 | 75% | 9.1 pts | 7 pts |
| war machine | 6.9 | 4.5 | 68% | 23.0 pts | 158 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.2 | 6.6 | 5.4 |
| Charges that made contact a game | 2.9 | 4.5 | 3.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.81 declared, 0.62 contact (16 units) | 0.88 declared, 0.53 contact (17 units) | 0.85 declared, 0.58 contact (33 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.88 declared, 0.62 contact (8 units) | 1.77 declared, 1.15 contact (13 units) | 1.43 declared, 0.95 contact (21 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.53 declared, 0.36 contact (249 units) | 0.68 declared, 0.47 contact (294 units) | 0.61 declared, 0.42 contact (543 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 57% (46 of 81) | 50% (8 of 16) | 50% (3 of 6) | 55% (57 of 103) |
| Character in a unit | 73% (24 of 33) | 71% (12 of 17) | 100% (1 of 1) | 73% (37 of 51) |
| Character on its own | 84% (27 of 32) | 40% (10 of 25) | 22% (17 of 77) | 40% (54 of 134) |
| Chariot | 67% (10 of 15) | 58% (7 of 12) | - | 63% (17 of 27) |
| Infantry | 60% (50 of 83) | 36% (9 of 25) | 50% (3 of 6) | 54% (62 of 114) |
| Monster | 65% (22 of 34) | 86% (12 of 14) | - | 71% (34 of 48) |
| Monstrous | 64% (9 of 14) | 36% (5 of 14) | - | 50% (14 of 28) |
| War Machines | 77% (33 of 43) | 50% (1 of 2) | - | 76% (34 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 92% (11 of 12); on the table 100% | 34% (35 of 102) | 25% | 55% (12 of 22) | 100% (6 of 6); 2.2 uses a game | 100% (2 of 2); 1.0 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 100% (9 of 9); on the table 100% | 46% (11 of 24) | 29% | 50% (16 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (2 of 2); on the table 100% | - | 64% | 74% (20 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 67% (8 of 12); on the table 67% | 44% (8 of 18) | 47% | 65% (40 of 62) | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game | 60% (3 of 5); 0.5 uses a game |
| Grand Cathay | 4 | 93% (14 of 15); on the table 93% | 29% (24 of 84) | 37% | 49% (18 of 37) | 100% (9 of 9); 6.2 uses a game | 50% (1 of 2); 0.2 uses a game | 25% (1 of 4); 0.2 uses a game |
| High Elf Realms | 9 | 94% (29 of 31); on the table 97% | 14% (5 of 36) | 30% | 47% (33 of 70) | 86% (6 of 7); 2.6 uses a game | 40% (12 of 30); 2.9 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (1 of 1); on the table 100% | - | 24% | 17% (1 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 91% (10 of 11); on the table 91% | 17% (1 of 6) | 32% | 57% (12 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 75% (3 of 4); on the table 75% | 50% (3 of 6) | 35% | 64% (9 of 14) | 50% (1 of 2); 0.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (11 of 11); on the table 100% | 38% (16 of 42) | 31% | 58% (14 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 6 | 90% (9 of 10); on the table 90% | 33% (13 of 39) | 57% | 73% (33 of 45) | 100% (3 of 3); 1.2 uses a game | 0.0 uses a game | 67% (4 of 6); 0.8 uses a game |
| Tomb Kings of Khemri | 4 | 92% (11 of 12); on the table 92% | 17% (1 of 6) | 24% | 35% (7 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 79% (15 of 19); on the table 84% | 29% (17 of 59) | 23% | 43% (18 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 90% (27 of 30); on the table 93% | 50% (6 of 12) | 37% | 61% (44 of 72) | 100% (2 of 2); 0.4 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 85% (23 of 27); on the table 85% | 0% (0 of 6) | 36% | 57% (32 of 56) | 50% (1 of 2); 0.5 uses a game | 0.0 uses a game | 75% (3 of 4); 0.5 uses a game |

Flank and rear charges a unit could have turned to face (shots-h2h-mine-7c46ffc-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 48% (49) | 53% (33) | 50% (82) |
| ...free all their last turn and able to turn (per game) | 0.69 | 0.56 | 1.25 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.31 | 0.19 | 0.50 |
| ...with the charger already in that arc before they moved (per game) | 0.50 | 0.42 | 0.92 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.69 | 1.14 | 2.83 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.67 | 0.42 | 1.08 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.47 | 4.64 | 10.11 |

### Quality by phase: shots-h2h-mine-7c46ffc-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 47% (66 of 140) | 41% (85 of 208) |
| Strategy | Shoot objectives carried out (shot that target) | 46% (172 of 373) | 56% (66 of 118) |
| Strategy | Close-in objectives charged next turn | 15% (23 of 156) | 15% (33 of 221) |
| Strategy | Support requests answered (helper made contact too) | 36% (5 of 14) | 35% (13 of 37) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 50% (7 of 14) | 67% (4 of 6) |
| Strategy | Joined characters whose unit fought | 56% (22 of 39) | 29% (10 of 35) |
| Strategy | Lone characters that fought | 76% (64 of 84) | 80% (65 of 81) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 1.0 | 2.2 |
| Movement | Points that never moved of their own | 289.5 | 74.6 |
| Movement | Fights charged into per game | 2.8 | 3.8 |
| Movement | Charges with odds: long shots (under 50%) | 9 of 87, net +159 | 21 of 114, net -1 |
| Movement | Charges with odds: sweet spot (55-75%) | 19 of 87, net +99 | 24 of 114, net +52 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 11 of 87, net +54 | 12 of 114, net +66 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 29 of 87, net +78 | 34 of 114, net +96 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.1 | 8.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (165 of 365) | 38% (114 of 298) |
| Shooting | Points destroyed by shooting units | 83.8 | 41.4 |
| Shooting | War machine shots | 6.1 | 0.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 57% (127 of 221) | 35% (9 of 26) |
| Shooting | Points destroyed by war machines | 61.7 | 15.0 |
| Magic | Magic missiles cast | 1.5 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 42% (23 of 55) | 32% (11 of 34) |
| Magic | Wounds caused by magic missiles | 3.3 | 1.1 |
| Magic | Wounds caused by other spells | 2.8 | 1.6 |
| Magic | Points destroyed by magic (all spells) | 55.8 | 36.2 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.4 / 0.9 / 0.2 | 1.9 / 0.4 / 0.8 / 0.1 |
| Combat | Points destroyed in combat | 294.7 | 435.5 |
| Combat | Points run down | 101.8 | 62.4 |
| Combat | Net points per charged fight, damage counted | +87 | +76 |
| Combat | Net per 100 charger points, damage counted | +32.2 | +24.1 |
| Combat | First round won (charged fights) | 74% | 66% |
| Combat | Net points per charged fight | +85 | +81 |
| Combat | Net points per supported fight / lone fight | +42 / +88 | +78 / +82 |
| Combat | Charged fights on a top-3 enemy unit | 33 of 101 | 65 of 136 |
| Game | Points lost | 770.0 | 701.1 |
| Game | VP from objectives | 485.3 | 545.8 |
| Game | Lone holders (player turns) | 2.2 | 2.2 |

- Mine won / drew / lost: 14 / 7 / 15 of 36 ended games (of 36); mean margin (Mine - Opponent) -106 VP
- The side that went first won 18 of 29 games with a winner
- Points traded per game (both sides' losses): 1471
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: shots-h2h-mine-7c46ffc-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.1 | +0.0 | 0.0 | 15.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.8 | +4.4 | 0.0 | 32.9 | 1.1 | +13.6 | 0.0 | 12.6 |
| BEST FACING | 0.7 | +22.4 | 0.0 | 46.6 | 0.5 | +13.0 | 0.0 | 30.3 |
| BEST FIRST | 3.6 | +148.9 | 118.4 | 90.4 | 3.9 | +158.4 | 149.1 | 35.9 |
| BEST MOVE FOR SHOOTERS | 1.2 | +76.1 | 0.0 | 32.5 | - | - | - | - |
| BEST OVERALL | 0.4 | +23.6 | 0.0 | 11.2 | 0.6 | +19.5 | 0.0 | 35.8 |
| BEST PREY | 0.5 | +38.8 | 1.7 | 3.5 | 1.0 | +46.4 | 18.3 | 21.7 |
| BEST PRIZE | 0.0 | +2.6 | 3.0 | 0.0 | - | - | - | - |
| BIG CHARACTER SAFETY | 0.2 | -0.6 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 5.8 | 15.0 |
| BLOCKED WHEEL | 0.5 | +3.8 | 0.0 | 5.2 | 0.5 | +2.0 | 0.0 | 0.0 |
| BOMBING RUN | 0.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.6 | +0.0 | 71.8 | 25.7 | - | - | - | - |
| CANNON PLANNED TARGET | 4.9 | +158.7 | 378.5 | 116.9 | 0.5 | +23.5 | 36.0 | 0.0 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 3.2 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 7.1 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 19.8 | 7.7 | 0.1 | -13.2 | 6.1 | 1.2 |
| CAST JOB | 0.6 | +27.3 | 27.3 | 7.6 | 0.2 | +5.9 | 12.3 | 3.2 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +24.7 | 24.9 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 20.8 | 0.3 | +0.0 | 0.0 | 9.1 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | 0.0 | +0.1 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 3.2 |
| CHAFF PASSED | 0.2 | -0.3 | 3.8 | 0.0 | 0.1 | -0.1 | 0.0 | 3.8 |
| CHAMPION TAKES THE CHALLENGE | - | - | - | - | 0.0 | +0.1 | 5.1 | 0.0 |
| CHARGE NOW FIRST | 2.7 | +0.0 | 216.0 | 41.4 | 2.8 | +0.0 | 256.4 | 130.6 |
| CHARGE NOW WEIGHED | 0.2 | -11.9 | 3.8 | 6.2 | 0.5 | -36.4 | 24.3 | 15.9 |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.7 | 0.0 | 0.0 | 0.2 | -1.9 | 0.0 | 15.0 |
| CHEAP HELPER | 0.1 | +0.0 | 10.4 | 2.4 | 0.1 | +0.0 | 2.2 | 1.9 |
| COMBAT PIVOT | 0.6 | +0.0 | 23.9 | 31.5 | 0.6 | +0.0 | 22.4 | 36.2 |
| CONVEYANCE SEARCH | 0.6 | +106.6 | 15.4 | 9.9 | 0.3 | +69.1 | 0.0 | 0.0 |
| COUNTER-CHARGE COVER | 7.8 | +531.3 | 0.0 | 215.8 | 6.2 | +546.3 | 0.0 | 131.4 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 56.2 | 3.5 | 0.0 | +0.0 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | 0.1 | +5.2 | 9.7 | 0.0 | 0.1 | +9.2 | 16.1 | 2.3 |
| EDGE GIVE GROUND | - | - | - | - | 0.2 | +5.5 | 24.3 | 1.2 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +2.1 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACE THE CAST | 0.1 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.7 | +135.6 | 0.0 | 75.9 | 1.1 | +97.5 | 0.0 | 59.2 |
| FALLBACK BY WORTH | 5.1 | +55.1 | 0.0 | 42.9 | 5.7 | +73.7 | 0.0 | 80.6 |
| FIGHT LIFT | 0.1 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| FIRE AND FLEE | - | - | - | - | 0.0 | +0.3 | 0.0 | 0.0 |
| FLANK NOT WEIGHED | 5.6 | +0.0 | 0.0 | 161.0 | 4.5 | +0.0 | 0.0 | 107.6 |
| FOCUS FIRE | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.4 | 1.8 | 0.0 |
| FOCUS OVER TURNS | 1.3 | +29.0 | 68.8 | 13.6 | - | - | - | - |
| FOLLOW UP WEIGHED | 1.1 | +167.2 | 0.0 | 88.5 | 1.3 | +221.8 | 0.0 | 96.3 |
| FRIENDS SHOTS CHECKED | 0.2 | +10.3 | 0.0 | 6.1 | 0.2 | +7.2 | 0.0 | 4.9 |
| GIVES UP | 0.1 | -3.6 | 24.9 | 2.4 | 0.1 | -2.1 | 17.6 | 0.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.0 | -0.6 | 2.4 | 0.0 |
| GROUND FLIERS | 0.0 | +0.6 | 0.0 | 6.1 | 0.1 | +2.8 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 6.2 | 0.8 |
| HELPER UNSEEN | 0.2 | +0.0 | 37.4 | 0.0 | 0.4 | +0.0 | 23.6 | 19.8 |
| HILL BY ITS CHANCE | 0.5 | -70.2 | 0.0 | 16.8 | 0.6 | -54.5 | 0.0 | 11.4 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.0 | +0.1 | 0.0 | 0.0 | 0.2 | +4.0 | 11.0 | 4.3 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.3 | +14.1 | 0.0 | 11.3 | 0.3 | +19.2 | 0.0 | 3.1 |
| HUNT KEPT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| HUNT RESULT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +12.4 | 0.0 | 4.3 |
| HUNT THE GUNS | 0.1 | +22.0 | 0.0 | 0.0 | 0.2 | +57.1 | 11.0 | 5.1 |
| INVITES THE FIGHT | 1.7 | +21.6 | 65.8 | 41.5 | 1.2 | +19.0 | 4.7 | 27.8 |
| JOINT CHARGE PLAN | 0.1 | +0.6 | 0.0 | 7.8 | 0.1 | +7.8 | 0.0 | 0.0 |
| KEEP FALLS | 0.1 | +0.3 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.0 | +0.2 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 8.7 |
| KEEPS ITS TARGET | 1.9 | +57.5 | 174.4 | 52.1 | 2.2 | +66.7 | 123.3 | 47.3 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 2.0 | +68.6 | 186.0 | 18.7 | 2.0 | +118.2 | 205.8 | 37.4 |
| KILLS COUNT NEXT TURN | 5.2 | +180.9 | 151.6 | 131.9 | 7.5 | +270.7 | 239.1 | 159.2 |
| LONE CHARACTER SAFE SPOT | 0.2 | +3.6 | 0.0 | 10.1 | 0.4 | +29.9 | 12.0 | 15.0 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 5.3 |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | -5.9 | 49.5 | 4.9 | 0.6 | -3.4 | 30.7 | 4.1 |
| LOST CHARGE | 2.6 | -41.0 | 77.2 | 123.5 | 2.0 | -39.0 | 49.6 | 46.2 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.1 | -9.4 | 0.0 | 5.5 |
| MAKE SURE TOGETHER | 0.6 | +28.6 | 0.0 | 25.4 | 0.7 | +80.3 | 22.5 | 16.5 |
| MANOEUVRE | 0.4 | +11.4 | 0.0 | 22.4 | 0.1 | +5.0 | 0.0 | 5.0 |
| MARCH AT ESCAPER | 0.1 | +0.6 | 0.0 | 11.0 | 0.1 | +0.2 | 0.0 | 0.0 |
| MARCH CHECK | 0.4 | +21.5 | 0.0 | 11.1 | 0.4 | +7.5 | 0.0 | 8.5 |
| MARCH ODDS | 0.3 | +19.2 | 16.9 | 4.6 | 0.2 | +9.7 | 18.3 | 0.0 |
| MARCH OVER CASTS | 0.4 | +23.7 | 0.0 | 17.7 | 0.4 | +44.2 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.6 | +148.4 | 0.0 | 140.5 | 4.3 | +163.1 | 0.0 | 81.1 |
| MISSILES IN THE MOVE | 3.5 | +136.3 | 0.0 | 70.0 | 2.2 | +45.1 | 0.0 | 37.1 |
| MISSILES IN THE PLAN | 1.2 | +19.3 | 67.3 | 24.2 | - | - | - | - |
| MISSILES NEXT TURN | 4.3 | +89.4 | 0.0 | 124.2 | 2.9 | +28.7 | 0.0 | 37.1 |
| MODEL FACING | 0.2 | +18.5 | 0.0 | 3.3 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 0.0 | 10.6 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.2 | +3.4 | 0.0 | 0.0 | 0.1 | +8.2 | 0.0 | 3.2 |
| MOVE SPELL IN RANGE | 0.2 | +4.8 | 0.0 | 4.7 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.5 | -32.0 | 28.0 | 2.4 | 0.1 | -14.9 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.5 | +0.0 | 0.0 | 9.6 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 3.4 | +168.7 | 108.7 | 99.1 | 4.7 | +431.1 | 174.0 | 103.9 |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.1 | +3.7 | 8.6 | 0.0 |
| NO RALLY LEFT | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.2 | -10.3 | 21.5 | 3.2 | 0.6 | -26.9 | 81.1 | 3.2 |
| NOT TURNED | 5.5 | +128.7 | 0.0 | 133.8 | 4.6 | +24.9 | 0.0 | 87.6 |
| NOT WORTH A CAST | 0.8 | -0.5 | 0.0 | 20.8 | 0.4 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 14.4 | -723.4 | 5.2 | 271.1 | 13.9 | -698.5 | 0.0 | 239.4 |
| OPENS A LANE | 0.2 | +1.0 | 21.8 | 3.2 | 0.1 | +0.4 | 0.0 | 1.6 |
| OPENS UP | 0.4 | +30.3 | 23.6 | 0.0 | 0.2 | +21.9 | 10.2 | 0.0 |
| OVERRUNS AWAY | 0.4 | +7.3 | 31.8 | 21.4 | 0.7 | +11.3 | 52.5 | 36.4 |
| PATHS CROSS | 2.4 | +189.9 | 0.0 | 31.9 | 2.8 | +260.2 | 0.0 | 56.4 |
| PERIAPT WORTH | 0.0 | +3.4 | 0.0 | 0.0 | 0.1 | +8.9 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.2 | -2.2 | 0.0 | 13.9 | 0.2 | -12.0 | 0.0 | 11.9 |
| PLAN RESULT | 37.3 | +1399.9 | 1300.6 | 981.3 | 38.9 | +1152.0 | 1252.0 | 974.2 |
| PURSUES BIG PREY | 0.1 | -7.4 | 0.0 | 0.0 | 0.1 | -4.6 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +7.4 | 0.0 | 2.2 | 0.1 | +10.7 | 0.0 | 3.4 |
| RANDOM MOVE BY FIGURES | 1.0 | +14.1 | 0.0 | 38.6 | 1.8 | +32.8 | 0.0 | 61.7 |
| RANDOM MOVER NO PROMISE | 0.4 | -25.6 | 10.8 | 9.4 | 0.2 | -19.7 | 0.0 | 9.9 |
| REDIRECT BY WHAT IT STOPS | 0.3 | -0.4 | 0.0 | 4.8 | 0.5 | -20.7 | 0.0 | 10.4 |
| REDIRECT COUNTER | 2.4 | +144.3 | 0.0 | 35.0 | 4.0 | +335.0 | 0.0 | 71.8 |
| REDIRECT WEIGHED | 0.4 | +14.0 | 17.2 | 18.9 | 0.4 | +23.2 | 25.8 | 7.1 |
| RESERVE FALL BACK | 0.7 | +21.9 | 0.0 | 13.4 | 0.7 | +41.7 | 0.0 | 7.8 |
| RESTRAINS TO SHOOT | 0.1 | +3.5 | 0.0 | 0.0 | 0.2 | +6.1 | 0.0 | 6.5 |
| RISK BY ARC | 2.7 | +130.4 | 216.4 | 63.5 | 3.2 | +47.8 | 276.1 | 113.2 |
| SAFER THAN THE JOB | 0.7 | +30.5 | 0.0 | 30.9 | 0.4 | +30.7 | 0.0 | 8.3 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.9 | 0.1 | +0.0 | 0.0 | 1.8 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.9 | 0.1 | +0.0 | 0.0 | 1.8 |
| SCREEN BY WHAT IT SAVES | 0.1 | -4.5 | 0.0 | 0.0 | 0.3 | -20.2 | 0.0 | 0.8 |
| SEARCH SPOT | 3.1 | +132.1 | 0.0 | 49.0 | 2.6 | +148.1 | 0.0 | 36.1 |
| SELF MOVE SPELL | 0.1 | +16.2 | 0.0 | 21.9 | 0.5 | +12.8 | 0.0 | 36.2 |
| SET UP TOGETHER | 1.1 | +59.0 | 0.0 | 35.0 | 1.2 | +102.8 | 28.9 | 28.6 |
| SET-UP ANY TARGET | 0.5 | +63.9 | 14.3 | 0.0 | 0.1 | +37.5 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +10.7 | 2.5 | 0.0 | 0.0 | +2.2 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.9 | +49.5 | 55.6 | 0.0 | 0.4 | +9.8 | 31.4 | 4.1 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 3.8 |
| SHOT OPTIONS | 15.4 | +0.0 | 841.8 | 336.8 | 8.1 | +0.0 | 346.0 | 203.8 |
| SHOT REPLANNED | 0.5 | +0.0 | 91.9 | 19.3 | 0.1 | +0.0 | 5.1 | 0.0 |
| SHOTS IN THE MOVE | 14.8 | +598.7 | 0.0 | 310.4 | 6.8 | +204.6 | 0.0 | 78.1 |
| SPELL SETS UP CHARGE | 0.5 | +63.9 | 14.3 | 0.0 | 0.2 | +65.4 | 0.0 | 0.0 |
| SPELL WORTH | 1.2 | +22.7 | 72.2 | 73.9 | 2.4 | +43.6 | 30.0 | 30.0 |
| STABLE ROLE | 10.1 | +0.0 | 410.6 | 240.2 | 9.0 | +0.0 | 199.0 | 202.5 |
| STANDS TO CAST | - | - | - | - | 0.0 | +1.1 | 0.0 | 0.0 |
| STAY WORTH | 19.1 | +315.7 | 525.0 | 323.9 | - | - | - | - |
| STOPS | 0.1 | +0.4 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.8 |
| STOPS SHORT OF THE FLANK | 0.4 | +7.3 | 0.0 | 21.7 | 0.4 | +14.8 | 0.0 | 3.9 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 14.6 |
| SUPPORT JOB KEPT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT NARROWED | 6.3 | -53.1 | 386.9 | 155.3 | 8.2 | -57.4 | 414.7 | 179.4 |
| SUPPORTS | 3.9 | +56.6 | 204.3 | 99.1 | 5.7 | +57.4 | 174.9 | 74.4 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -2.9 | 12.9 | 1.4 | 0.1 | -1.3 | 1.5 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +0.1 | 0.0 | 16.8 | 0.3 | -8.9 | 8.2 | 3.2 |
| THREAT IN THE KILL | 10.5 | +161.4 | 707.1 | 239.1 | 0.2 | +1.8 | 28.2 | 6.0 |
| THROUGH LINE OF FIRE | 0.3 | +9.2 | 0.0 | 9.5 | 0.3 | +6.6 | 0.0 | 0.0 |
| TURN WORTH | 0.7 | -52.9 | 50.0 | 5.1 | 0.3 | -30.0 | 33.8 | 1.2 |
| TWO OR MORE ARRIVE | 0.3 | +1.0 | 0.0 | 9.6 | 0.2 | +1.8 | 0.0 | 1.5 |
| WAIT AFTER COSTS | 7.0 | -259.3 | 231.8 | 175.6 | 7.7 | -394.7 | 210.5 | 168.9 |
| WALKS TO THE FIGHT | 1.8 | +31.1 | 49.2 | 56.6 | 1.0 | +14.7 | 17.5 | 9.8 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 59.8 | 11.9 | 0.1 | +0.0 | 7.5 | 8.1 |
| WEARS DOWN | 1.0 | +36.4 | 66.9 | 38.1 | 1.4 | +50.9 | 82.9 | 103.1 |
| WHO HITS BACK | 0.2 | +11.2 | 0.0 | 2.0 | 0.3 | +25.1 | 0.0 | 25.1 |
| WHOLE FIGHT | 0.2 | +5.2 | 14.9 | 4.6 | 0.6 | +27.7 | 47.3 | 7.2 |
| WHOLE FIGHT GAIN | 0.1 | +8.9 | 9.7 | 0.0 | 0.8 | +62.8 | 63.6 | 16.6 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 8.6 | 0.0 |

### Rule changes: shots-h2h-mine-7c46ffc-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1022 | 1022 | 1022 | 28.39 | -51190 | -50.1 |
| BEST FIRST | 270 | 270 | 270 | 7.50 | +11062 | +41.0 |
| SEARCH SPOT | 205 | 205 | 201 | 5.58 | +10124 | +50.4 |
| PATHS CROSS | 186 | 186 | 186 | 5.17 | +16205 | +87.1 |
| MOVE TO CHARGE | 289 | 289 | 164 | 4.56 | +7965 | +48.6 |
| KILLS COUNT NEXT TURN | 458 | 458 | 140 | 3.89 | +4953 | +35.4 |
| COUNTER-CHARGE COVER | 503 | 294 | 134 | 3.72 | +7676 | +57.3 |
| SUPPORTS | 345 | 345 | 104 | 2.89 | +1033 | +9.9 |
| FACES THE THREAT | 102 | 102 | 102 | 2.83 | +8393 | +82.3 |
| SHOTS IN THE MOVE | 775 | 528 | 88 | 2.44 | +2941 | +33.4 |
| FOLLOW UP WEIGHED | 87 | 87 | 87 | 2.42 | +14001 | +160.9 |
| FALLBACK BY WORTH | 388 | 388 | 84 | 2.33 | +4639 | +55.2 |
| WALKS TO THE FIGHT | 100 | 100 | 66 | 1.83 | +624 | +9.5 |
| WAIT AFTER COSTS | 528 | 528 | 64 | 1.78 | +1213 | +19.0 |
| REDIRECT COUNTER | 231 | 139 | 61 | 1.69 | +4477 | +73.4 |
| RANDOM MOVE BY FIGURES | 99 | 99 | 60 | 1.67 | +1689 | +28.2 |
| ADVANCE LANE KEPT | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| CHARGE NOW FIRST | 200 | 200 | 54 | 1.50 | -3742 | -69.3 |
| RESERVE FALL BACK | 49 | 49 | 49 | 1.36 | +2286 | +46.7 |
| BEST MOVE FOR SHOOTERS | 45 | 45 | 45 | 1.25 | +2739 | +60.9 |
| MAX FOR POSITIONING | 323 | 182 | 45 | 1.25 | +646 | +14.4 |
| STAY WORTH | 689 | 573 | 45 | 1.25 | +566 | +12.6 |
| BEST FACING | 42 | 42 | 42 | 1.17 | +1273 | +30.3 |
| CANNON SIGHT KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| COMBAT PIVOT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| SAFER THAN THE JOB | 39 | 39 | 39 | 1.08 | +2204 | +56.5 |
| RISK BY ARC | 211 | 206 | 37 | 1.03 | +1291 | +34.9 |
| BEST OVERALL | 35 | 35 | 35 | 0.97 | +1551 | +44.3 |
| BLOCKED WHEEL | 35 | 35 | 35 | 0.97 | +208 | +5.9 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| CANNON PLANNED TARGET | 194 | 194 | 34 | 0.94 | +256 | +7.5 |
| SET UP TOGETHER | 82 | 66 | 31 | 0.86 | +2054 | +66.3 |
| KILLS COUNT | 146 | 144 | 30 | 0.83 | +1344 | +44.8 |
| CHARGE NOW WEIGHED | 28 | 28 | 28 | 0.78 | +1242 | +44.4 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| STOPS SHORT OF THE FLANK | 28 | 28 | 28 | 0.78 | +794 | +28.4 |
| KEEPS ITS TARGET | 149 | 148 | 27 | 0.75 | +437 | +16.2 |
| REDIRECT WEIGHED | 27 | 27 | 27 | 0.75 | +2064 | +76.4 |
| MISSILES IN THE MOVE | 207 | 115 | 24 | 0.67 | +654 | +27.2 |
| WHOLE FIGHT GAIN | 32 | 31 | 24 | 0.67 | +1151 | +47.9 |
| THREAT IN THE KILL | 386 | 318 | 22 | 0.61 | +340 | +15.5 |
| THROUGH LINE OF FIRE | 22 | 22 | 22 | 0.61 | +568 | +25.8 |
| INVITES THE FIGHT | 106 | 106 | 21 | 0.58 | +222 | +10.6 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| FOCUS OVER TURNS | 46 | 46 | 20 | 0.56 | +215 | +10.8 |
| MARCH ODDS | 20 | 20 | 20 | 0.56 | +321 | +16.0 |
| SHOOTS FROM THE BEST SPOT | 50 | 50 | 20 | 0.56 | +668 | +33.4 |
| MANOEUVRE | 19 | 19 | 19 | 0.53 | +592 | +31.2 |
| MARCH CHECK | 26 | 22 | 19 | 0.53 | +1149 | +60.4 |
| SHOT REPLANNED | 19 | 19 | 19 | 0.53 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +41 | +2.3 |
| WHO HITS BACK | 18 | 18 | 18 | 0.50 | +878 | +48.8 |
| CASTER AWAY FROM SCREEN | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| WEARS DOWN | 88 | 85 | 17 | 0.47 | +478 | +28.1 |
| BEST PREY | 53 | 53 | 15 | 0.42 | +1085 | +72.3 |
| CAST JOB | 28 | 28 | 15 | 0.42 | +516 | +34.4 |
| PIVOT GUARDS FLANK | 15 | 15 | 15 | 0.42 | -513 | -34.2 |
| FRIENDS SHOTS CHECKED | 13 | 13 | 13 | 0.36 | +632 | +48.6 |
| MAKE SURE TOGETHER | 45 | 30 | 13 | 0.36 | +1281 | +98.5 |
| MOVE AND CAST | 13 | 13 | 13 | 0.36 | +417 | +32.1 |
| STUCK PIVOT | 13 | 13 | 13 | 0.36 | +0 | +0.0 |
| BIG CHARACTER SAFETY | 11 | 11 | 11 | 0.31 | -21 | -1.9 |
| CHAFF PASSED | 11 | 11 | 11 | 0.31 | -16 | -1.5 |
| RESTRAINS TO SHOOT | 10 | 10 | 10 | 0.28 | +348 | +34.8 |
| WAR ENGINE JOBS | 28 | 28 | 10 | 0.28 | -391 | -39.1 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| LOST CHARGE | 166 | 164 | 9 | 0.25 | +121 | +13.4 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SURE CHARGE BEATS ADVANCE | 9 | 9 | 9 | 0.25 | -150 | -16.7 |
| CASTING BLOCK | 11 | 11 | 8 | 0.22 | +401 | +50.2 |
| OPENS UP | 22 | 22 | 8 | 0.22 | +320 | +40.0 |
| BLOCKED CHARGE SKIPPED | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| PURSUES BIG PREY | 7 | 7 | 7 | 0.19 | -430 | -61.4 |
| RAIDS THE BAGGAGE NEXT TURN | 8 | 8 | 7 | 0.19 | +411 | +58.7 |
| MODEL FACING | 6 | 6 | 6 | 0.17 | +664 | +110.8 |
| OVERRUNS AWAY | 40 | 40 | 6 | 0.17 | +115 | +19.2 |
| SUPPORT NARROWED | 524 | 524 | 6 | 0.17 | -41 | -6.9 |
| WHOLE FIGHT | 27 | 26 | 6 | 0.17 | +455 | +75.8 |
| MISSILES NEXT TURN | 261 | 147 | 5 | 0.14 | +7 | +1.5 |
| PERIAPT WORTH | 5 | 5 | 5 | 0.14 | +442 | +88.4 |
| KEEP FALLS | 4 | 4 | 4 | 0.11 | +110 | +27.6 |
| BACKUP TARGETS | 65 | 30 | 3 | 0.08 | +2 | +0.6 |
| FACE THE CAST | 3 | 3 | 3 | 0.08 | +36 | +12.0 |
| HUNT IN PAIRS | 24 | 14 | 3 | 0.08 | +275 | +91.8 |
| SURE REACH TOGETHER | 22 | 19 | 3 | 0.08 | +20 | +6.6 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -9 | -4.6 |
| DEFENSIVE ARMY | 9 | 9 | 2 | 0.06 | -5 | -2.4 |
| DEFENSIVE FLOOR | 4 | 4 | 2 | 0.06 | +276 | +138.0 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +77 | +38.4 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +14 | +6.9 |
| JOINT CHARGE PLAN | 8 | 8 | 2 | 0.06 | +146 | +72.8 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 12 | 12 | 2 | 0.06 | -168 | -84.0 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +51 | +25.5 |
| BEST PRIZE | 1 | 1 | 1 | 0.03 | -4 | -4.3 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +18 | +18.3 |
| CARRIES OUT SET-UP | 6 | 6 | 1 | 0.03 | -474 | -474.5 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +12 | +12.3 |
| HUNT ADVANCE | 7 | 7 | 1 | 0.03 | +1 | +0.9 |
| LONG SHOT | 36 | 34 | 1 | 0.03 | +8 | +8.0 |
| MISSILES IN THE PLAN | 42 | 5 | 1 | 0.03 | +8 | +8.0 |
| NEEDED THERE | 2 | 2 | 1 | 0.03 | +0 | +0.0 |
| REDIRECT BY WHAT IT STOPS | 29 | 29 | 1 | 0.03 | +13 | +12.7 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | -13 | -12.7 |
| STOPS | 3 | 3 | 1 | 0.03 | +11 | +11.1 |
| SUPPORT JOB KEPT | 1 | 1 | 1 | 0.03 | +87 | +87.1 |
| TWO OR MORE ARRIVE | 19 | 16 | 1 | 0.03 | +10 | +10.4 |
| ALREADY CARRIED | 4 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 20 | 20 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 3 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 38 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 13 | 13 | 0 | 0.00 | - | - |
| CHEAP HELPER | 7 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 33 | not checked | - | - | - | - |
| EDGE GIVE GROUND | 7 | 7 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 362 | not checked | - | - | - | - |
| GIVES UP | 7 | 6 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 3 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 5 | not checked | - | - | - | - |
| HELPER UNSEEN | 23 | 23 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 39 | 39 | 0 | 0.00 | - | - |
| HUNT DROPPED | 4 | trace | - | - | - | - |
| HUNT KEPT | 3 | trace | - | - | - | - |
| HUNT RESULT | 7 | trace | - | - | - | - |
| HUNT THE GUNS | 9 | trace | - | - | - | - |
| KEEPS ITS PREY | 4 | 4 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 20 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 7 | trace | - | - | - | - |
| MARCH OVER CASTS | 26 | 26 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 12 | 12 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 9 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 23 | trace | - | - | - | - |
| MOVE SPELL SPOT | 20 | not checked | - | - | - | - |
| NOT NEEDED | 30 | 30 | 0 | 0.00 | - | - |
| NOT TURNED | 364 | 364 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 44 | not checked | - | - | - | - |
| OPENS A LANE | 10 | 7 | 0 | 0.00 | - | - |
| PLAN RESULT | 2741 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 23 | 23 | 0 | 0.00 | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 15 | 15 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 21 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 21 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SHOT OPTIONS | 846 | 846 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 23 | not checked | - | - | - | - |
| SPELL WORTH | 130 | not checked | - | - | - | - |
| STABLE ROLE | 686 | 684 | 0 | 0.00 | - | - |
| TURN WORTH | 37 | 37 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: shots-h2h-mine-7c46ffc-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 12.72 | 12.25 | 51.3 |
| CHARGE NOW FIRST | rule | 0.69 | 0.81 | 69.3 |
| FALLBACK | gate | 0.56 | 0.78 | 47.0 |
| TURN GATE | gate | 0.72 | 0.44 | 33.7 |
| PIVOT GUARDS FLANK | rule | 0.22 | 0.19 | 34.2 |
| PATHS CROSS | rule | 0.08 | 0.17 | 17.8 |
| WAR ENGINE JOBS | rule | 0.25 | - | 43.4 |
| CANNON PLANNED TARGET | rule | 0.22 | - | 7.9 |
| SURE CHARGE BEATS ADVANCE | rule | 0.14 | 0.08 | 18.8 |
| AFTERMATH BAND | gate | 0.11 | 0.08 | 2.9 |
| PURSUES BIG PREY | rule | 0.08 | 0.11 | 61.4 |
| SUPPORT REQUEST | gate | 0.08 | 0.11 | 69.6 |
| BIG CHARACTER SAFETY | rule | 0.14 | 0.03 | 5.2 |
| FIGHT ORDER BAND | gate | 0.06 | 0.11 | 2.8 |
| SUPPORT NARROWED | rule | 0.08 | 0.08 | 6.9 |
| CHARGE NOW WEIGHED | rule | 0.03 | 0.11 | 87.8 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | 0.08 | 46.2 |
| CHAFF PASSED | rule | 0.06 | 0.06 | 4.0 |
| LONE CHARACTER SAFE SPOT | gate | 0.06 | 0.06 | 134.6 |
| NO REASON | gate | 0.11 | - | 26.7 |
| STOPS SHORT OF THE FLANK | rule | 0.08 | 0.03 | 3.1 |
| BLOCKED WHEEL | rule | 0.08 | - | 32.5 |
| CATCH ODDS | rule | 0.03 | 0.03 | 4.6 |
| DEFENSIVE ARMY | rule | 0.03 | 0.03 | 2.4 |
| BEST PRIZE | rule | 0.03 | - | 4.3 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 474.5 |
| FACES THE THREAT | rule | 0.03 | - | 14.4 |
| FALLBACK BY WORTH | rule | 0.03 | - | 15.9 |
| FRIENDS SHOTS CHECKED | rule | - | 0.03 | 3.2 |
| LONE WIZARD HOLDS BACK | rule | - | 0.03 | 168.0 |
| MARCH ODDS | rule | - | 0.03 | 3.1 |
| MOVE AND CAST | rule | 0.03 | - | 23.9 |
| REDIRECT WEIGHED | rule | 0.03 | - | 4.3 |
| RULE SWITCHED OFF | gate | - | 0.03 | 6.5 |
| SAFER THAN THE JOB | rule | 0.03 | - | 4.5 |
| STANDS TO CAST | rule | - | 0.03 | 12.7 |
| WHO HITS BACK | rule | 0.03 | - | 3.3 |

### Plans: shots-h2h-mine-7c46ffc-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.9 | 15% | 385 | 273 | 71% |
| Mine | charge | 3.4 | 58% | 306 | 260 | 85% |
| Mine | close in | 4.3 | 28% | 274 | 155 | 56% |
| Mine | hold | 4.3 | 25% | 266 | 0 | 0% |
| Mine | join | 0.4 | 94% | 9 | 0 | 0% |
| Mine | shoot | 8.8 | 66% | 576 | 713 | 124% |
| Mine | support | 4.2 | 85% | 48 | 0 | 0% |
| Opponent | advance | 13.4 | 16% | 353 | 346 | 98% |
| Opponent | charge | 4.9 | 57% | 554 | 457 | 82% |
| Opponent | close in | 6.1 | 26% | 459 | 150 | 33% |
| Opponent | hold | 4.5 | 32% | 300 | 0 | 0% |
| Opponent | join | 0.6 | 90% | 29 | 0 | 0% |
| Opponent | shoot | 2.9 | 66% | 75 | 205 | 276% |
| Opponent | support | 6.4 | 89% | 41 | 0 | 0% |

### Packages: hunt the guns, shots-h2h-mine-7c46ffc-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 3 | 0 | 0% | 0% | 0% | - | 264 | 0 | 0% | 16 |
| Opponent | 0.2 | 6 | 2 | 0% | 25% | 0% | 2.0 | 327 | 112 | 25% | 74 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 152 |
| Empire of Man | 0.3 | 2 | 0 | 0% | 0% | 0% | - | 286 | 0 | 0% | 21 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 20 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 58 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 117 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 149 |
| Tomb Kings of Khemri | 0.5 | 2 | 0 | 0% | 50% | 0% | 2.0 | 341 | 223 | 50% | 0 |
| Vampire Counts | 0.5 | 4 | 1 | 0% | 0% | 0% | - | 282 | 0 | 0% | 14 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 105 |
| Wood Elf Realms | 0.2 | 1 | 1 | - | - | - | - | - | - | - | 0 |

### Battle groups: shots-h2h-mine-7c46ffc-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 7.8 | 28% | 41% | 15% | 50% | 37% | 10% | 7% | 45% | 0% |
| Mine | REDIRECT COUNTER | 2.4 | 36% | 58% | 0% | - | 39% | 0% | 6% | 52% | 3% |
| Opponent | COUNTER-CHARGE COVER | 6.2 | 23% | 76% | 22% | 45% | 51% | 5% | 13% | 31% | 0% |
| Opponent | REDIRECT COUNTER | 4.0 | 26% | 68% | 26% | 20% | 21% | 0% | 11% | 64% | 4% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: shots-h2h-mine-7c46ffc-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 0 (4) | 0 | 0 | 21 | 25% | 2.0 | 0 (1) | 0 (3) | - | 0 (3) | 0 (1) |
| Mine | Chaff | 34 | 26 (34) | 18 | 7 | 51 | 32% | 2.8 | 21 (14) | 0 (5) | 38 (15) | 30 (20) | 18 (14) |
| Mine | Character | 106 | 44 (106) | 44 | 0 | 38 | 15% | 2.4 | 31 (33) | 57 (48) | 90 (7) | 36 (44) | 60 (44) |
| Mine | Clean-up | 23 | 54 (23) | 21 | 33 | 51 | 17% | 2.7 | 0 (2) | 73 (17) | 18 (4) | 74 (11) | 42 (12) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast | 4 | 0 (4) | 0 | 0 | 73 | 25% | 3.0 | 0 (2) | 0 (2) | - | 0 (3) | 0 (1) |
| Mine | Fast Hammer | 40 | 29 (40) | 23 | 6 | 53 | 18% | 2.5 | 33 (25) | 31 (9) | 6 (6) | 38 (25) | 14 (15) |
| Mine | Fragile | 4 | 0 (4) | 0 | 0 | 54 | 50% | 2.5 | 0 (1) | 0 (3) | - | 0 (1) | 0 (3) |
| Mine | Hammer | 64 | 46 (64) | 35 | 11 | 42 | 16% | 2.6 | 53 (13) | 39 (42) | 72 (9) | 47 (39) | 45 (25) |
| Mine | Holder | 31 | 78 (31) | 4 | 75 | 23 | 26% | 3.2 | 48 (9) | 118 (16) | 15 (6) | 104 (21) | 28 (10) |
| Mine | Shooter | 35 | 55 (35) | 25 | 31 | 42 | 3% | 1.6 | 10 (8) | 75 (22) | 57 (5) | 67 (26) | 22 (9) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | - | 0 (1) | - | 0 (1) |
| Mine | War machine | 56 | 39 (56) | 39 | 0 | 59 | 2% | 1.3 | 26 (16) | 39 (30) | 66 (10) | 0 (9) | 46 (47) |
| Mine | Wizard | 17 | 0 (17) | 0 | 0 | 30 | 6% | 2.1 | 0 (4) | 0 (9) | 0 (1) | 0 (6) | 0 (8) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Chaff | 77 | 45 (77) | 16 | 30 | 58 | 44% | 2.6 | 45 (32) | 45 (18) | 46 (27) | 49 (58) | 31 (19) |
| Opponent | Character | 97 | 55 (97) | 55 | 0 | 27 | 26% | 2.2 | 55 (47) | 55 (40) | 70 (6) | 58 (51) | 54 (42) |
| Opponent | Clean-up | 12 | 68 (12) | 35 | 33 | 34 | 50% | 2.2 | 21 (4) | 36 (5) | 167 (3) | 11 (7) | 106 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 54 | 37 (54) | 18 | 18 | 45 | 28% | 2.9 | 24 (23) | 50 (23) | 54 (8) | 42 (33) | 29 (21) |
| Opponent | Fragile | 17 | 13 (17) | 13 | 0 | 66 | 29% | 2.6 | 31 (4) | 13 (8) | 0 (4) | 8 (13) | 35 (3) |
| Opponent | Hammer | 65 | 31 (65) | 19 | 12 | 42 | 37% | 3.2 | 18 (20) | 38 (38) | 9 (7) | 39 (41) | 19 (24) |
| Opponent | Holder | 30 | 21 (30) | 5 | 17 | 26 | 57% | 4.3 | 9 (10) | 31 (14) | 6 (6) | 28 (18) | 10 (12) |
| Opponent | Shooter | 34 | 85 (34) | 35 | 49 | 44 | 0% | 1.4 | 27 (10) | 111 (21) | 101 (3) | 65 (19) | 108 (15) |
| Opponent | Support | 6 | 0 (6) | 0 | 0 | 67 | 83% | 6.0 | - | 0 (3) | - | 0 (1) | 0 (2) |
| Opponent | War machine | 6 | 89 (6) | 89 | 0 | 21 | 0% | 1.0 | 91 (3) | 85 (3) | - | 91 (3) | 85 (3) |
| Opponent | Wizard | 20 | 9 (20) | 9 | 0 | 46 | 15% | 2.4 | 16 (10) | 10 (3) | 0 (2) | 15 (10) | 0 (5) |

### Charged fights: shots-h2h-mine-7c46ffc-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 135 | 227 | 2.0 | 1.0 | 114 | 21 | +92 | 3 of 8 | 4 of 8 | - | +92 |
| Mine | Chaos Dwarfs | 4 | 220 | 174 | 2.0 | 1.1 | 87 | 36 | +51 | 4 of 8 | 5 of 8 | +109 | +43 |
| Mine | Dwarfen Mountain Holds | 3 | 443 | 0 | 1.3 | 1.2 | 0 | 97 | -97 | 1 of 4 | 1 of 4 | -328 | -20 |
| Mine | Empire of Man | 5 | 266 | 160 | 1.6 | 1.1 | 100 | 44 | +56 | 2 of 8 | 6 of 8 | +156 | +42 |
| Mine | Grand Cathay | 4 | 277 | 244 | 3.0 | 1.3 | 81 | 18 | +63 | 2 of 12 | 10 of 12 | +75 | +59 |
| Mine | High Elf Realms | 4 | 324 | 390 | 4.2 | 1.0 | 92 | 37 | +54 | 4 of 17 | 15 of 17 | - | +54 |
| Mine | Kingdom of Bretonnia | 1 | 210 | 987 | 5.0 | 1.0 | 197 | 55 | +142 | 3 of 5 | 3 of 5 | - | +142 |
| Mine | Lizardmen | 1 | 0 | 1584 | 7.0 | 1.1 | 226 | 0 | +226 | 3 of 7 | 6 of 7 | +55 | +255 |
| Mine | Ogre Kingdoms | 2 | 0 | 420 | 3.0 | 1.0 | 140 | 6 | +134 | 4 of 6 | 3 of 6 | - | +134 |
| Mine | Skaven | 2 | 72 | 72 | 1.5 | 1.0 | 48 | 0 | +48 | 0 of 3 | 3 of 3 | - | +48 |
| Mine | Tomb Kings of Khemri | 2 | 62 | 684 | 3.5 | 1.1 | 195 | 0 | +195 | 2 of 7 | 6 of 7 | +116 | +208 |
| Mine | Vampire Counts | 2 | 0 | 101 | 3.0 | 1.0 | 34 | 69 | -35 | 2 of 6 | 5 of 6 | - | -35 |
| Mine | Warriors of Chaos | 2 | 142 | 630 | 5.0 | 1.0 | 126 | 0 | +126 | 3 of 10 | 8 of 10 | - | +126 |
| **Mine** | all armies | 36 | 201 | 314 | 2.8 | 1.1 | 112 | 27 | +85 | 33 of 101 | 75 of 101 | +42 | +88 |
| Opponent | Empire of Man | 1 | 515 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | High Elf Realms | 5 | 250 | 592 | 4.2 | 1.2 | 141 | 73 | +68 | 16 of 21 | 13 of 21 | +96 | +62 |
| Opponent | Lizardmen | 2 | 0 | 616 | 2.5 | 1.0 | 246 | 28 | +218 | 2 of 5 | 3 of 5 | - | +218 |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 216 | 3.3 | 1.1 | 65 | 0 | +65 | 3 of 10 | 9 of 10 | +83 | +63 |
| Opponent | Skaven | 4 | 16 | 45 | 1.0 | 1.0 | 45 | 9 | +36 | 1 of 4 | 2 of 4 | - | +36 |
| Opponent | Tomb Kings of Khemri | 2 | 426 | 260 | 3.5 | 1.3 | 74 | 19 | +55 | 1 of 7 | 5 of 7 | +0 | +77 |
| Opponent | Vampire Counts | 6 | 31 | 452 | 5.5 | 1.2 | 82 | 3 | +79 | 20 of 33 | 20 of 33 | +0 | +90 |
| Opponent | Warriors of Chaos | 7 | 12 | 515 | 3.3 | 1.1 | 157 | 20 | +137 | 10 of 23 | 16 of 23 | +230 | +128 |
| Opponent | Wood Elf Realms | 6 | 64 | 430 | 5.3 | 1.2 | 81 | 31 | +50 | 11 of 32 | 22 of 32 | +91 | +40 |
| **Opponent** | all armies | 36 | 93 | 401 | 3.8 | 1.1 | 106 | 25 | +81 | 65 of 136 | 90 of 136 | +78 | +82 |

### Effective charges: shots-h2h-mine-7c46ffc-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 8 | 1 (net +330) | 0 | 3 (net +0) | 2 (net +116) | 0 | 1 (net +0) | 1 | 43% (3 of 7) |
| Mine | Chaos Dwarfs | 8 | 1 (net +0) | 0 | 2 (net +45) | 1 (net +109) | 1 (net +91) | 2 (net -32) | 1 | 29% (2 of 7) |
| Mine | Dwarfen Mountain Holds | 4 | 2 (net -30) | 0 | 2 (net -164) | 0 | 0 | 0 | 0 | 50% (2 of 4) |
| Mine | Empire of Man | 8 | 1 (net +162) | 1 (net +0) | 2 (net -16) | 1 (net +122) | 1 (net +45) | 1 (net +0) | 1 | 29% (2 of 7) |
| Mine | Grand Cathay | 12 | 0 | 0 | 3 (net -42) | 1 (net +175) | 3 (net +36) | 5 (net +120) | 0 | 25% (3 of 12) |
| Mine | High Elf Realms | 17 | 0 | 0 | 1 (net +540) | 4 (net -14) | 2 (net +60) | 9 (net +35) | 1 | 6% (1 of 16) |
| Mine | Kingdom of Bretonnia | 5 | 0 | 0 | 0 | 1 (net +540) | 0 | 1 (net +145) | 3 | 0% (0 of 2) |
| Mine | Lizardmen | 7 | 1 (net +929) | 0 | 0 | 3 (net +97) | 0 | 1 (net +255) | 2 | 0% (0 of 5) |
| Mine | Ogre Kingdoms | 6 | 0 | 0 | 1 (net +350) | 0 | 0 | 3 (net +163) | 2 | 25% (1 of 4) |
| Mine | Skaven | 3 | 0 | 0 | 0 | 0 | 0 | 3 (net +48) | 0 | 0% (0 of 3) |
| Mine | Tomb Kings of Khemri | 7 | 0 | 0 | 2 (net +346) | 1 (net +116) | 2 (net +99) | 2 (net +180) | 0 | 29% (2 of 7) |
| Mine | Vampire Counts | 6 | 1 (net -40) | 0 | 1 (net +60) | 1 (net +97) | 1 (net +0) | 1 (net +0) | 1 | 20% (1 of 5) |
| Mine | Warriors of Chaos | 10 | 2 (net +54) | 0 | 2 (net +313) | 3 (net +0) | 1 (net +27) | 0 | 2 | 25% (2 of 8) |
| Opponent | Empire of Man | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | High Elf Realms | 21 | 4 (net -158) | 0 | 2 (net +168) | 6 (net +216) | 1 (net +0) | 6 (net +36) | 2 | 11% (2 of 19) |
| Opponent | Lizardmen | 5 | 0 | 0 | 1 (net +439) | 1 (net +0) | 0 | 0 | 3 | 50% (1 of 2) |
| Opponent | Orc & Goblin Tribes | 10 | 0 | 0 | 0 | 1 (net +234) | 1 (net +83) | 3 (net +41) | 5 | 0% (0 of 5) |
| Opponent | Skaven | 4 | 0 | 0 | 1 (net +80) | 0 | 0 | 3 (net +22) | 0 | 25% (1 of 4) |
| Opponent | Tomb Kings of Khemri | 7 | 1 (net -66) | 0 | 0 | 2 (net +72) | 0 | 3 (net +125) | 1 | 0% (0 of 6) |
| Opponent | Vampire Counts | 33 | 6 (net +42) | 0 | 8 (net +35) | 5 (net +161) | 5 (net +40) | 7 (net +122) | 2 | 26% (8 of 31) |
| Opponent | Warriors of Chaos | 23 | 3 (net +119) | 0 | 3 (net +80) | 3 (net +165) | 2 (net +160) | 6 (net +218) | 6 | 18% (3 of 17) |
| Opponent | Wood Elf Realms | 32 | 7 (net +9) | 0 | 9 (net -14) | 5 (net +171) | 3 (net +62) | 5 (net +65) | 3 | 31% (9 of 29) |

### Charged fights, damage counted: shots-h2h-mine-7c46ffc-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 9 | 157 | 327 | +159 | 211 | 50 | +162 | +102.9 |
| Mine | 50-54% | 1 | 371 | 343 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 19 | 251 | 242 | +99 | 186 | 96 | +90 | +36.0 |
| Mine | 76-89% | 18 | 360 | 191 | +90 | 130 | 33 | +96 | +26.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 29 | 213 | 150 | +78 | 122 | 34 | +88 | +41.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 421 | 84 | +54 | 91 | 19 | +72 | +17.1 |
| Mine | No odds | 14 | 252 | 237 | +56 | 106 | 66 | +40 | +16.0 |
| Mine | All fights | 101 | 271 | 197 | +85 | 137 | 49 | +87 | +32.2 |
| Opponent | Long shot (under 50%) | 21 | 230 | 281 | -1 | 86 | 117 | -31 | -13.3 |
| Opponent | Effective (55-75%) | 24 | 224 | 226 | +52 | 106 | 67 | +39 | +17.4 |
| Opponent | 76-89% | 23 | 387 | 201 | +167 | 185 | 30 | +156 | +40.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 34 | 324 | 213 | +96 | 145 | 38 | +106 | +32.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 12 | 544 | 121 | +66 | 95 | 3 | +93 | +17.1 |
| Opponent | No odds | 22 | 283 | 218 | +88 | 114 | 35 | +78 | +27.7 |
| Opponent | All fights | 136 | 315 | 217 | +81 | 126 | 50 | +76 | +24.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| shots-h2h-mine-7c46ffc-p4 | move | 436 | 103 (24%) | 69 (16%) | 63 (14%) | 270 (62%) |
| shots-h2h-mine-7c46ffc-p4 | objective | 377 | 56 (15%) | 37 (10%) | 56 (15%) | 265 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

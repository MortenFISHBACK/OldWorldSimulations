# Doctrine scorecard: shots-h2h-opp-7c46ffc-p1

### Scorecard: shots-h2h-opp-7c46ffc-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 5 | 3 | 0 | 1 | 0 | 0 | 0 | 65 |
| L0102 | 6 | 1 | Opponent | no | 8 | 1 | 2 | 3 | 0 | 0 | 0 | 222 |
| L0118 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 6 | 4 | 4 | 2 | 0 | 0 | 0 | 268 |
| L0135 | 3 | 1 | Mine | no | 5 | - | 0 | 1 | 1 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 2 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Opponent | - | - | 2 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 0 | 2 | 2 | 2 | 1 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Opponent | no | 2 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 5 | 2 | 3 | 0 | 0 | 0 | 0 | 985 |
| L0319 | 1 | 1 | Opponent | no | 2 | 2 | 3 | 0 | 0 | 0 | 0 | 226 |
| L0405 | 3 | 1 | Mine | yes | 9 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 3 | - | 1 | 0 | 0 | 0 | 0 | 1120 |
| L0421 | 1 | 1 | Mine | no | 0 | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | 5 | 1 | 4 | 1 | 0 | 0 | 210 |
| L0508 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 1416 |
| L0508 | 4 | 1 | Opponent | no | 0 | 3 | 2 | 4 | 0 | 0 | 0 | 385 |
| L0524 | 2 | 1 | Mine | - | - | 5 | 3 | 0 | 0 | 0 | 0 | 613 |
| L0524 | 2 | 1 | Opponent | - | - | 2 | 4 | 3 | 1 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 1 | - | 0 | 2 | 0 | 0 | 0 | 615 |
| L0612 | 6 | 1 | Opponent | no | 3 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | 6 | 0 | 1 | 0 | 0 | 0 | 984 |
| L0628 | 4 | 1 | Opponent | no | 1 | - | 1 | 2 | 0 | 0 | 0 | 0 |
| L0717 | 3 | 1 | Mine | yes | 2 | 2 | 2 | 0 | 1 | 0 | 0 | 420 |
| L0717 | 3 | 1 | Opponent | yes | 9 | 2 | 4 | 0 | 1 | 0 | 0 | 184 |
| L0733 | 1 | 1 | Mine | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 375 |
| L0733 | 1 | 1 | Opponent | no | 1 | 3 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 1 | - | 0 | 1 | 0 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 7 | 2 | 5 | 5 | 1 | 0 | 0 | 0 |
| L0913 | 1 | 1 | Mine | no | 0 | - | 0 | 0 | 1 | 0 | 0 | 560 |
| L0913 | 1 | 1 | Opponent | no | 8 | 3 | 4 | 0 | 0 | 0 | 0 | 317 |
| L0930 | 6 | 1 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 994 |
| L0930 | 6 | 1 | Opponent | no | 3 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 0 | 2 | 4 | 0 | 1 | 0 | 0 | 501 |
| L1021 | 1 | 1 | Opponent | no | 0 | 6 | 5 | 5 | 0 | 0 | 0 | 355 |
| L1114 | 4 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 3 | 0 | 0 | 0 | 500 |
| L1131 | 3 | 1 | Mine | no | 0 | - | 1 | 0 | 0 | 0 | 0 | 330 |
| L1131 | 3 | 1 | Opponent | no | 1 | 5 | 2 | 3 | 0 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 10 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 5 | 2 | 3 | 2 | 2 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | yes | - | 3 | 3 | 2 | 0 | 0 | 0 | 140 |
| L1319 | 5 | 1 | Opponent | no | - | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 1 | 2 | 5 | 0 | 0 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 126 |
| L1431 | 3 | 1 | Mine | yes | 9 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 0 | 5 | 1 | 0 | 2 | 0 | 0 | 460 |
| L1527 | 3 | 1 | Mine | yes | 3 | 4 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | yes | - | 3 | 4 | 0 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | yes | - | 1 | 2 | 3 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | no | 0 | 1 | 3 | 0 | 3 | 0 | 0 | 72 |
| L1723 | 1 | 1 | Opponent | yes | 10 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | yes | - | - | 1 | 2 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 5 | 2 | 0 | 0 | 0 | 70 |
| L1923 | 3 | 1 | Mine | no | 0 | 2 | 7 | 0 | 1 | 0 | 0 | 382 |
| L1923 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2025 | 3 | 1 | Mine | yes | 7 | 4 | 2 | 2 | 1 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 5 | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | yes | 7 | 4 | 1 | 4 | 0 | 0 | 0 | 500 |
| L2127 | 3 | 1 | Opponent | no | 2 | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 2 | 1 | 0 | 0 | 0 | 0 | 55 |
| L2231 | 5 | 1 | Opponent | yes | - | 2 | 4 | 2 | 1 | 0 | 0 | 933 |
| L2335 | 1 | 1 | Mine | no | 0 | 2 | 5 | 0 | 2 | 0 | 0 | 317 |
| L2335 | 1 | 1 | Opponent | no | 0 | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | 4 | 4 | 4 | 1 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | no | - | 4 | 0 | 2 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Mine | no | 1 | 1 | 9 | 3 | 0 | 0 | 0 | 60 |
| L2730 | 6 | 1 | Opponent | no | 4 | 4 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 7 | 2 | 2 | 1 | 0 | 0 | 0 | 170 |
| L2934 | 6 | 1 | Opponent | no | 0 | 1 | 3 | 0 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 32% | 2.5 | 2.7 | 2.5 | 1.1 | 0.4 | 0.0 | 0.0 | 319.1 |
| **Average** | | | Opponent | 15% | 2.8 | 2.6 | 2.9 | 1.9 | 0.3 | 0.0 | 0.0 | 163.2 |

### KPIs: shots-h2h-opp-7c46ffc-p1

Rules off - Mine only: STAY WORTH, BEST MOVE FOR SHOOTERS, THREAT IN THE KILL, FOCUS OVER TURNS, MISSILES IN THE PLAN, FACE THE CAST, WIZARD FRONT RANK.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 31% (55 of 176) | 3% (5 of 181) | 17% (60 of 357) |
| Winner chose to follow up after the loser gave ground |  | 96% (75 of 78); on the table 100% | 99% (68 of 69); on the table 100% | 97% (143 of 147); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 81% (13 of 16); on the table 81% | 94% (17 of 18); on the table 94% | 88% (30 of 34); on the table 88% |
| Winner chose to pursue after the loser fled |  | 65% (20 of 31); on the table 74% | 77% (34 of 44); on the table 86% | 72% (54 of 75); on the table 81% |
| Winner chose to follow up or pursue (all three) |  | 86% (108 of 125); on the table 91% | 91% (119 of 131); on the table 95% | 89% (227 of 256); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 31% (102 of 330) | 32% (68 of 210) | 31% (170 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 46% (102 of 222) | 45% (68 of 152) | 45% (170 of 374) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 27% (40 of 150) | 27% (23 of 84) | 27% (63 of 234) |
|     round 1 |  | 24% (6 of 25) | 14% (2 of 14) | 21% (8 of 39) |
|     rounds 2+ |  | 27% (34 of 125) | 30% (21 of 70) | 28% (55 of 195) |
|   other wizards | 50%+ | 34% (62 of 180) | 36% (45 of 126) | 35% (107 of 306) |
|     round 1 |  | 23% (7 of 30) | 38% (8 of 21) | 29% (15 of 51) |
|     rounds 2+ |  | 37% (55 of 150) | 35% (37 of 105) | 36% (92 of 255) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 74% (23 of 31) | 60% (28 of 47) | 65% (51 of 78) |
| Points that never fought | lower | 36% (25610 of 71484) | 39% (27706 of 71889) | 37% (53316 of 143373) |
|   infantry points that never fought | lower | 45% (7584 of 16863) | 57% (7606 of 13348) | 50% (15190 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (156 of 279) | 59% (175 of 295) | 58% (331 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 95% (21 of 22); 2.0 uses a game | 75% (15 of 20); 1.6 uses a game | 86% (36 of 42); 1.8 uses a game |
| Bound items with another spell used |  | 69% (11 of 16); 0.6 uses a game | 25% (2 of 8); 0.1 uses a game | 54% (13 of 24); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 58% (11 of 19); 0.3 uses a game | 58% (7 of 12); 0.2 uses a game | 58% (18 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 51% (30654 of 59666) | 52% (32804 of 62699) | 52% (63458 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.2 (35%) | 1.2 (32%) | 3.5 (34%) |
| MARCHED: its unit marched | 0.9 (14%) | 0.7 (18%) | 1.6 (16%) |
| CHARGED: its unit charged | 0.1 (2%) | 0.1 (4%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.8 (28%) | 0.7 (18%) | 2.5 (24%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |
| FLEEING: fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 0.8 (13%) | 0.8 (21%) | 1.7 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (6%) | 0.1 (1%) | 0.4 (4%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.6 | 1.5 | 1.4 | 4.7 | 0.6 | 2.2 |
| not cast | 3.4 | 2.8 | 3.3 | 10.3 | 1.8 | 21.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.9 (9%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.1 (38%) | 0.2 (6%) | 3.5 (34%) | 0.4 (21%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.6 (16%) | 0.2 (13%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (5%) | 0.4 (14%) | 0.7 (21%) | 2.5 (24%) | 0.6 (32%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (5%) | 0.3 (12%) | 0.4 (12%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| GONE: slain | 0.8 (24%) | 0.5 (18%) | 0.7 (22%) | 1.7 (16%) | 0.2 (10%) | 3.2 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (7%) | 0.1 (2%) | 0.1 (3%) | 0.4 (4%) | 0.0 (0%) | 0.6 (3%) |
| STUPIDITY: Stupidity | 0.0 (1%) | 0.1 (4%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (5%) | 0.0 (0%) | 0.0 (0%) | 0.4 (21%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.9 (57%) | 0.2 (8%) | 1.2 (36%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.6 (72%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.2 a game | 0.4 a game | 0.8 a game |
| stood (cast and not dispelled) | 59% (23 of 39) | 64% (9 of 14) | 60% (32 of 53) |
| the unit moved after it | 65% (15 of 23) | 56% (5 of 9) | 62% (20 of 32) |
| it charged on its next turn | 0% (0 of 23) | 22% (2 of 9) | 6% (2 of 32) |
| the enemy charged it first | 30% (7 of 23) | 0% (0 of 9) | 22% (7 of 32) |
| it fought by the end of its next turn | 17% (4 of 23) | 0% (0 of 9) | 12% (4 of 32) |
| it moved out of a charge the enemy had planned (not charged first) | 13% (3 of 23) | 11% (1 of 9) | 12% (4 of 32) |
| none of these (no charge, no fight, no charge escaped) | 57% (13 of 23) | 67% (6 of 9) | 59% (19 of 32) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (584 of 896) | 58% (367 of 632) | 62% (951 of 1528) |
|   cavalry | 67% (42 of 63) | 66% (100 of 151) | 66% (142 of 214) |
|   character | 49% (52 of 107) | 26% (30 of 115) | 37% (82 of 222) |
|   chariot | 53% (52 of 99) | 64% (28 of 44) | 56% (80 of 143) |
|   infantry | 58% (178 of 307) | 63% (148 of 234) | 60% (326 of 541) |
|   monster | 61% (20 of 33) | 42% (11 of 26) | 53% (31 of 59) |
|   war machine | 84% (240 of 287) | 81% (50 of 62) | 83% (290 of 349) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (27%) | 1.4 (19%) | 3.7 (23%) |
| CHARGED: it charged | 0.8 (10%) | 1.8 (24%) | 2.6 (16%) |
| FLEEING: it fled or was fleeing | 0.1 (2%) | 0.2 (2%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 1.0 (12%) | 0.4 (6%) | 1.4 (9%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.7 (19%) | 1.4 (19%) | 3.1 (19%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (4%) | 0.7 (9%) | 1.0 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (20%) | 1.0 (13%) | 2.7 (17%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.3 (4%) | 0.6 (3%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| OTHER BAR | 0.3 (4%) | 0.1 (2%) | 0.4 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.8 | 1.4 | 79% | 5.0 pts | 29 pts |
| character | 2.6 | 0.8 | 77% | 6.3 pts | 16 pts |
| chariot | 2.2 | 1.4 | 68% | 12.5 pts | 28 pts |
| infantry | 13.6 | 5.1 | 75% | 8.8 pts | 119 pts |
| monster | 1.0 | 0.3 | 75% | 4.8 pts | 5 pts |
| war machine | 8.1 | 5.6 | 66% | 23.0 pts | 185 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.2 | 6.4 | 5.3 |
| Charges that made contact a game | 3.2 | 4.3 | 3.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.27 declared, 1.09 contact (22 units) | 0.57 declared, 0.36 contact (14 units) | 1.00 declared, 0.81 contact (36 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.67 declared, 0.50 contact (6 units) | 1.62 declared, 1.25 contact (8 units) | 1.21 declared, 0.93 contact (14 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.47 declared, 0.35 contact (252 units) | 0.72 declared, 0.49 contact (288 units) | 0.61 declared, 0.42 contact (540 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 54% (38 of 70) | 57% (12 of 21) | 62% (5 of 8) | 56% (55 of 99) |
| Character in a unit | 84% (26 of 31) | 61% (14 of 23) | 25% (1 of 4) | 71% (41 of 58) |
| Character on its own | 84% (47 of 56) | 68% (25 of 37) | 26% (16 of 62) | 57% (88 of 155) |
| Chariot | 56% (9 of 16) | 40% (4 of 10) | - | 50% (13 of 26) |
| Infantry | 60% (53 of 89) | 33% (12 of 36) | 50% (1 of 2) | 52% (66 of 127) |
| Monster | 62% (20 of 32) | 80% (8 of 10) | - | 67% (28 of 42) |
| Monstrous | 45% (5 of 11) | 57% (8 of 14) | - | 52% (13 of 25) |
| War Machines | 63% (26 of 41) | 100% (1 of 1) | - | 64% (27 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 92% (12 of 13); on the table 92% | 41% (57 of 138) | 50% | 67% (22 of 33) | 100% (9 of 9); 5.5 uses a game | 100% (3 of 3); 1.7 uses a game | 78% (7 of 9); 1.2 uses a game |
| Chaos Dwarfs | 3 | 67% (8 of 12); on the table 67% | 25% (6 of 24) | 36% | 46% (11 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |
| Dwarfen Mountain Holds | 5 | 87% (13 of 15); on the table 93% | - | 54% | 68% (28 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 86% (12 of 14); on the table 93% | 36% (13 of 36) | 54% | 56% (36 of 64) | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 5 | 91% (20 of 22); on the table 95% | 30% (32 of 108) | 52% | 43% (19 of 44) | 100% (12 of 12); 8.6 uses a game | 0% (0 of 1); 0.0 uses a game | 40% (2 of 5); 0.4 uses a game |
| High Elf Realms | 6 | 77% (17 of 22); on the table 82% | 23% (7 of 30) | 28% | 45% (22 of 49) | 100% (5 of 5); 2.8 uses a game | 44% (8 of 18); 1.7 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (2 of 2); on the table 100% | - | 18% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 100% (5 of 5); on the table 100% | - | 36% | 71% (10 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 80% (8 of 10); on the table 90% | 17% (2 of 12) | 38% | 67% (14 of 21) | 67% (2 of 3); 2.7 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (15 of 15); on the table 100% | 8% (3 of 36) | 7% | 75% (18 of 24) | 0.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Skaven | 4 | 85% (11 of 13); on the table 100% | 43% (13 of 30) | 24% | 68% (23 of 34) | 67% (2 of 3); 0.8 uses a game | 0.0 uses a game | 100% (4 of 4); 1.0 uses a game |
| Tomb Kings of Khemri | 6 | 77% (24 of 31); on the table 87% | 0% (0 of 12) | 30% | 33% (10 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 98% (39 of 40); on the table 100% | 31% (17 of 54) | 27% | 56% (28 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 95% (20 of 21); on the table 95% | 27% (8 of 30) | 40% | 68% (50 of 74) | 100% (4 of 4); 2.2 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 100% (21 of 21); on the table 100% | 40% (12 of 30) | 36% | 55% (36 of 66) | 33% (2 of 6); 1.3 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (shots-h2h-opp-7c46ffc-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 61% (55) | 35% (25) | 49% (80) |
| ...free all their last turn and able to turn (per game) | 0.86 | 0.33 | 1.19 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.14 | 0.47 |
| ...with the charger already in that arc before they moved (per game) | 0.58 | 0.19 | 0.78 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.53 | 1.31 | 2.83 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.28 | 0.42 | 1.69 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 4.86 | 4.89 | 9.75 |

### Quality by phase: shots-h2h-opp-7c46ffc-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 53% (78 of 147) | 44% (91 of 209) |
| Strategy | Shoot objectives carried out (shot that target) | 49% (193 of 391) | 57% (103 of 182) |
| Strategy | Close-in objectives charged next turn | 18% (23 of 128) | 16% (29 of 187) |
| Strategy | Support requests answered (helper made contact too) | 39% (7 of 18) | 65% (17 of 26) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 88% (7 of 8) | 0% (0 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 64% (9 of 14) | 55% (6 of 11) |
| Strategy | Joined characters whose unit fought | 39% (17 of 44) | 45% (18 of 40) |
| Strategy | Lone characters that fought | 82% (84 of 102) | 75% (72 of 96) |
| Movement | Charges halted short of contact | 0.1 | 0.1 |
| Movement | Idle units | 1.1 | 1.9 |
| Movement | Points that never moved of their own | 319.1 | 163.2 |
| Movement | Fights charged into per game | 2.8 | 3.6 |
| Movement | Charges with odds: long shots (under 50%) | 18 of 89, net +19 | 22 of 116, net +42 |
| Movement | Charges with odds: sweet spot (55-75%) | 11 of 89, net +209 | 22 of 116, net +105 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 6 of 89, net +75 | 5 of 116, net +49 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 33 of 89, net +39 | 41 of 116, net +167 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.5 | 9.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (166 of 378) | 44% (153 of 347) |
| Shooting | Points destroyed by shooting units | 99.8 | 68.7 |
| Shooting | War machine shots | 6.7 | 1.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (103 of 240) | 28% (14 of 50) |
| Shooting | Points destroyed by war machines | 109.6 | 8.3 |
| Magic | Magic missiles cast | 1.8 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 40% (26 of 65) | 33% (14 of 42) |
| Magic | Wounds caused by magic missiles | 3.8 | 1.5 |
| Magic | Wounds caused by other spells | 2.1 | 1.1 |
| Magic | Points destroyed by magic (all spells) | 79.2 | 35.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.6 / 0.4 / 0.9 / 0.2 | 1.6 / 0.4 / 0.6 / 0.1 |
| Combat | Points destroyed in combat | 288.3 | 403.8 |
| Combat | Points run down | 43.9 | 167.2 |
| Combat | Net points per charged fight, damage counted | +59 | +96 |
| Combat | Net per 100 charger points, damage counted | +20.5 | +36.8 |
| Combat | First round won (charged fights) | 68% | 65% |
| Combat | Net points per charged fight | +55 | +94 |
| Combat | Net points per supported fight / lone fight | +144 / +38 | +64 / +100 |
| Combat | Charged fights on a top-3 enemy unit | 43 of 100 | 52 of 130 |
| Game | Points lost | 777.8 | 722.0 |
| Game | VP from objectives | 578.3 | 714.2 |
| Game | Lone holders (player turns) | 2.5 | 2.8 |

- Mine won / drew / lost: 16 / 4 / 16 of 36 ended games (of 36); mean margin (Mine - Opponent) -211 VP
- The side that went first won 16 of 32 games with a winner
- Points traded per game (both sides' losses): 1500
- Games not ended: 0; findings 0, warnings 1

### Opponent rules: shots-h2h-opp-7c46ffc-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 21.8 | 0.3 | +0.0 | 0.0 | 3.6 |
| BACKUP TARGETS | 0.8 | +7.4 | 0.0 | 24.3 | 0.9 | +8.4 | 0.0 | 18.7 |
| BEST FACING | 0.6 | +27.7 | 0.0 | 31.5 | 0.6 | +34.7 | 0.0 | 27.2 |
| BEST FIRST | 3.8 | +213.4 | 157.1 | 52.4 | 4.1 | +182.0 | 160.1 | 66.2 |
| BEST MOVE FOR SHOOTERS | - | - | - | - | 0.7 | +50.2 | 0.0 | 17.4 |
| BEST OVERALL | 0.5 | +19.4 | 0.0 | 9.3 | 0.3 | +30.3 | 0.0 | 8.8 |
| BEST PREY | 0.9 | +59.5 | 32.3 | 42.3 | 1.0 | +36.2 | 26.0 | 23.0 |
| BEST PRIZE | 0.1 | +5.1 | 7.1 | 0.0 | 0.1 | -2.9 | 1.1 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | -0.6 | 0.0 | 11.1 | 0.0 | -0.0 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 11.1 | 10.2 | - | - | - | - |
| BLOCKED WHEEL | 0.2 | +13.4 | 0.0 | 13.8 | 0.3 | +21.1 | 0.0 | 14.2 |
| BOMBING RUN | 0.1 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 62.4 | 23.5 | 0.1 | +0.0 | 14.3 | 1.9 |
| CANNON PLANNED TARGET | 5.3 | +163.6 | 404.5 | 82.6 | 1.1 | +27.9 | 36.6 | 12.5 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 3.5 | 0.4 | +0.0 | 0.0 | 7.2 |
| CARRIES OUT COUNTER | 0.0 | -1.4 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | +0.0 | 5.1 | 0.0 | 0.2 | -1.5 | 6.2 | 0.9 |
| CAST JOB | 0.6 | +26.7 | 77.8 | 12.3 | 0.2 | +2.6 | 3.2 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +38.1 | 13.1 | 0.0 | 0.3 | +12.5 | 18.1 | 0.0 |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 20.8 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.2 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| CATCH ODDS | - | - | - | - | 0.1 | +1.8 | 0.0 | 0.0 |
| CHAFF PASSED | 0.1 | -0.3 | 0.0 | 0.0 | 0.2 | -0.9 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 3.3 | +0.0 | 220.1 | 87.1 | 3.0 | +0.0 | 293.2 | 23.2 |
| CHARGE NOW WEIGHED | 0.4 | -23.5 | 10.1 | 14.3 | 0.5 | -15.2 | 7.7 | 11.2 |
| CHARIOT WIZARD CAREFUL | 0.2 | -3.1 | 16.8 | 0.0 | 0.1 | -0.9 | 0.0 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 3.1 | 0.0 | 0.1 | +0.0 | 19.9 | 1.4 |
| COMBAT PIVOT | 0.4 | +0.0 | 22.9 | 12.5 | 0.6 | +0.0 | 51.3 | 16.4 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.6 | +128.4 | 17.9 | 38.3 | 0.2 | +48.0 | 0.0 | 15.2 |
| COUNTER-CHARGE COVER | 9.5 | +735.5 | 0.0 | 215.7 | 6.7 | +634.3 | 0.0 | 169.7 |
| DEFENSIVE ARMY | 0.4 | +0.0 | 48.5 | 11.2 | - | - | - | - |
| DEFENSIVE FLOOR | 0.1 | +1.2 | 4.0 | 1.5 | 0.1 | +3.3 | 4.7 | 0.0 |
| EDGE GIVE GROUND | 0.0 | +9.6 | 9.5 | 0.0 | 0.2 | +14.5 | 31.5 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +1.3 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACE THE CAST | - | - | - | - | 0.1 | +0.8 | 0.0 | 0.0 |
| FACES THE THREAT | 1.5 | +100.5 | 0.0 | 60.5 | 1.3 | +156.0 | 0.0 | 61.2 |
| FALLBACK BY WORTH | 4.7 | +77.5 | 0.0 | 57.5 | 6.1 | +66.3 | 0.0 | 32.1 |
| FIGHT LIFT | 0.0 | +0.7 | 7.0 | 0.0 | - | - | - | - |
| FIRE AND FLEE | 0.0 | +0.1 | 0.0 | 0.0 | 0.0 | +0.3 | 5.4 | 0.0 |
| FLANK NOT WEIGHED | 5.1 | +0.0 | 0.0 | 184.3 | 4.9 | +0.0 | 0.0 | 180.3 |
| FOCUS OVER TURNS | - | - | - | - | 0.4 | +4.1 | 23.3 | 1.9 |
| FOLLOW UP WEIGHED | 1.3 | +174.3 | 0.0 | 39.1 | 1.2 | +192.3 | 0.0 | 34.5 |
| FRIENDS SHOTS CHECKED | 0.4 | +21.9 | 0.0 | 25.1 | 0.2 | +12.6 | 0.0 | 11.1 |
| GIVES UP | 0.0 | -0.3 | 0.0 | 1.4 | 0.2 | -3.4 | 18.8 | 9.4 |
| GIVES UP ITS SCREEN | 0.0 | -0.0 | 7.0 | 1.5 | 0.1 | -0.4 | 12.7 | 0.0 |
| GROUND FLIERS | - | - | - | - | 0.0 | +0.4 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 34.1 | 0.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 30.0 | 7.8 | 0.4 | +0.0 | 27.4 | 22.0 |
| HILL BY ITS CHANCE | - | - | - | - | 0.1 | -15.1 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.0 | +0.8 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.0 | +0.0 | 0.0 | 0.0 | 0.3 | +10.5 | 6.9 | 11.3 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 6.4 |
| HUNT IN PAIRS | 0.4 | +32.6 | 0.0 | 12.1 | 0.2 | +14.4 | 0.0 | 12.8 |
| HUNT KEPT | 0.1 | +0.0 | 0.0 | 3.3 | 0.1 | +0.8 | 3.5 | 0.0 |
| HUNT RESULT | 0.0 | +0.0 | 0.0 | 0.0 | 0.3 | +13.6 | 10.2 | 14.2 |
| HUNT THE GUNS | 0.0 | +5.7 | 0.0 | 0.0 | 0.3 | +130.7 | 7.4 | 13.9 |
| INVITES THE FIGHT | 1.8 | +36.9 | 42.8 | 29.8 | 1.5 | +31.9 | 50.8 | 12.1 |
| JOINT CHARGE PLAN | 0.0 | +2.9 | 0.0 | 0.0 | 0.2 | +14.5 | 0.0 | 5.7 |
| KEEP FALLS | 0.1 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.0 | +0.1 | 0.0 | 8.2 | - | - | - | - |
| KEEPS ITS TARGET | 1.8 | +52.5 | 114.5 | 33.3 | 2.0 | +60.0 | 145.1 | 41.1 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.8 | +66.9 | 100.0 | 42.0 | 2.3 | +98.7 | 203.8 | 42.1 |
| KILLS COUNT NEXT TURN | 4.8 | +183.8 | 163.9 | 103.8 | 6.1 | +234.6 | 169.2 | 188.2 |
| LONE CHARACTER SAFE SPOT | 0.3 | +15.6 | 3.4 | 3.6 | 0.4 | +6.9 | 0.0 | 11.8 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 5.4 |
| LONE WIZARD KEPT IN | 0.7 | +49.1 | 0.0 | 0.0 | 0.2 | +24.5 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | -5.6 | 16.8 | 4.4 | 0.5 | -2.5 | 36.6 | 7.9 |
| LOST CHARGE | 2.7 | -38.8 | 69.9 | 81.8 | 2.8 | -49.6 | 62.1 | 63.9 |
| LURE BY WHAT IT DRAWS | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 0.4 | +60.4 | 22.6 | 4.6 | 0.5 | +36.9 | 0.0 | 13.3 |
| MANOEUVRE | 0.2 | +5.5 | 0.0 | 10.5 | 0.2 | +2.2 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.7 | 0.0 | 0.0 | 0.0 | +0.4 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +24.1 | 0.0 | 23.2 | 0.5 | +34.3 | 0.0 | 0.0 |
| MARCH ODDS | 0.1 | +10.4 | 2.9 | 0.0 | 0.2 | +8.5 | 3.2 | 0.0 |
| MARCH OVER CASTS | 0.4 | +20.5 | 0.0 | 25.6 | 0.5 | +50.5 | 0.0 | 9.9 |
| MAX FOR POSITIONING | 4.9 | +199.4 | 0.0 | 120.9 | 4.5 | +162.0 | 0.0 | 126.4 |
| MISSILES IN THE MOVE | 4.1 | +164.7 | 0.0 | 94.4 | 3.4 | +64.7 | 0.0 | 58.4 |
| MISSILES IN THE PLAN | - | - | - | - | 0.7 | +4.3 | 20.8 | 12.1 |
| MISSILES NEXT TURN | 4.8 | +114.0 | 0.0 | 128.9 | 4.1 | +45.3 | 0.0 | 73.8 |
| MODEL FACING | 0.3 | +74.5 | 0.0 | 3.3 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 6.2 | 0.0 | 0.2 | +0.0 | 0.0 | 11.4 |
| MOVE AND CAST | 0.2 | +25.1 | 0.0 | 6.8 | 0.3 | +16.3 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.1 | +4.2 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -45.6 | 0.0 | 13.5 | 0.1 | -0.2 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 20.1 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 2.6 | +220.9 | 64.5 | 49.3 | 4.1 | +312.7 | 97.2 | 142.2 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.1 | +8.2 | 10.1 | 15.9 |
| NO RALLY LEFT | 0.1 | +3.8 | 0.0 | 6.3 | - | - | - | - |
| NOT NEEDED | 0.2 | -10.2 | 12.8 | 3.4 | 0.4 | -14.5 | 46.2 | 6.0 |
| NOT TURNED | 4.9 | +100.2 | 0.0 | 123.3 | 4.9 | +67.6 | 0.0 | 167.6 |
| NOT WORTH A CAST | 0.7 | -0.7 | 0.0 | 23.8 | 0.3 | -0.3 | 0.0 | 0.0 |
| OFF BEST | 16.4 | -825.0 | 29.7 | 282.6 | 15.0 | -737.5 | 12.2 | 234.9 |
| OPENS A LANE | 0.2 | +1.2 | 28.9 | 6.9 | 0.1 | +0.5 | 8.6 | 0.0 |
| OPENS UP | 0.3 | +24.2 | 9.4 | 5.4 | 0.3 | +41.0 | 16.0 | 7.9 |
| OVERRUNS AWAY | 0.4 | +9.3 | 32.4 | 5.4 | 0.7 | +13.0 | 42.9 | 11.8 |
| PATHS CROSS | 1.8 | +123.0 | 0.0 | 22.3 | 2.2 | +158.3 | 0.0 | 26.4 |
| PERIAPT WORTH | 0.1 | +6.8 | 0.0 | 0.0 | 0.1 | +3.1 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.4 | 0.0 | 0.0 | 0.0 | -0.2 | 0.0 | 2.9 |
| PLAN RESULT | 37.6 | +1407.3 | 1406.9 | 975.6 | 38.4 | +1260.8 | 1517.7 | 842.5 |
| PURSUES BIG PREY | 0.1 | -2.4 | 0.0 | 5.2 | 0.1 | -12.5 | 0.0 | 27.8 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.1 | +9.7 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.1 | +7.3 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.9 | +11.2 | 0.0 | 10.6 | 1.3 | +17.4 | 0.0 | 57.5 |
| RANDOM MOVER NO PROMISE | 0.1 | -7.9 | 8.9 | 4.7 | 0.2 | -9.6 | 0.0 | 20.0 |
| REDIRECT BY WHAT IT STOPS | 0.3 | -3.2 | 0.0 | 2.8 | 0.4 | -6.3 | 0.0 | 11.8 |
| REDIRECT COUNTER | 2.2 | +145.9 | 0.0 | 53.8 | 3.9 | +333.6 | 0.0 | 40.4 |
| REDIRECT WEIGHED | 0.2 | +3.5 | 5.2 | 0.0 | 0.4 | +7.0 | 16.2 | 3.5 |
| RESERVE FALL BACK | 0.4 | +9.1 | 0.0 | 5.8 | 0.8 | +33.8 | 0.0 | 10.7 |
| RESTRAINS TO SHOOT | 0.1 | +1.0 | 0.0 | 5.8 | 0.2 | +14.0 | 0.0 | 0.0 |
| RISK BY ARC | 2.6 | +124.6 | 169.2 | 70.5 | 3.5 | +87.1 | 350.7 | 67.9 |
| SAFER THAN THE JOB | 1.3 | +73.9 | 0.0 | 39.1 | 0.4 | +19.4 | 0.0 | 0.0 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.9 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.9 |
| SCREEN BY WHAT IT SAVES | 0.1 | -5.4 | 0.0 | 0.9 | 0.1 | -3.5 | 0.0 | 0.5 |
| SEARCH SPOT | 2.2 | +108.3 | 0.0 | 59.1 | 2.8 | +141.2 | 0.0 | 21.6 |
| SELF MOVE SPELL | 0.3 | +11.0 | 0.0 | 18.1 | 0.2 | -0.1 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.8 | +120.6 | 41.1 | 6.3 | 1.2 | +115.0 | 2.4 | 32.0 |
| SET-UP ANY TARGET | 0.2 | +21.7 | 0.0 | 3.6 | 0.1 | +14.3 | 0.0 | 7.6 |
| SET-UP MISSED | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.0 | -0.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.4 | +48.9 | 129.1 | 30.1 | 0.5 | +15.1 | 36.1 | 8.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 3.8 |
| SHOT OPTIONS | 16.0 | +0.0 | 987.9 | 300.6 | 10.4 | +0.0 | 410.4 | 133.0 |
| SHOT REPLANNED | 0.5 | +0.0 | 136.1 | 3.5 | 0.2 | +0.0 | 20.4 | 0.0 |
| SHOTS IN THE MOVE | 15.0 | +564.7 | 0.0 | 231.3 | 9.2 | +200.6 | 0.0 | 99.2 |
| SPELL SETS UP CHARGE | 0.4 | +107.5 | 8.9 | 9.7 | 0.2 | +41.3 | 0.0 | 7.6 |
| SPELL WORTH | 1.5 | +21.8 | 100.7 | 71.4 | 1.8 | +43.9 | 108.2 | 105.2 |
| STABLE ROLE | 11.8 | +0.0 | 369.0 | 128.2 | 11.4 | +0.0 | 436.5 | 103.4 |
| STANDS TO CAST | 0.1 | +4.0 | 3.2 | 0.0 | 0.0 | +1.4 | 3.2 | 0.0 |
| STAY WEIGHED | 0.1 | +13.4 | 0.0 | 2.3 | 0.1 | +2.4 | 0.0 | 0.0 |
| STAY WORTH | - | - | - | - | 11.4 | +171.0 | 193.2 | 75.3 |
| STOPS | 0.0 | +0.0 | 0.0 | 1.7 | 0.1 | +2.1 | 3.9 | 2.6 |
| STOPS SHORT OF THE FLANK | 0.6 | +25.5 | 0.0 | 17.6 | 0.3 | +26.9 | 0.0 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 4.7 | 0.2 | +0.0 | 0.0 | 4.0 |
| SUPPORT NARROWED | 5.7 | -39.0 | 288.2 | 106.9 | 7.8 | -53.3 | 419.8 | 77.9 |
| SUPPORTS | 3.3 | +41.4 | 165.6 | 63.3 | 4.7 | +58.3 | 189.0 | 50.9 |
| SURE CHARGE BEATS ADVANCE | - | - | - | - | 0.1 | -2.8 | 6.3 | 0.0 |
| SURE REACH TOGETHER | 0.6 | -0.4 | 7.0 | 0.0 | 0.6 | -0.5 | 0.0 | 33.1 |
| THREAT IN THE KILL | 0.8 | +7.1 | 64.2 | 31.7 | 6.7 | +73.7 | 326.4 | 84.9 |
| THROUGH LINE OF FIRE | 0.7 | +32.9 | 0.0 | 13.1 | 0.2 | +10.2 | 0.0 | 0.0 |
| TURN WORTH | 0.6 | -46.9 | 35.4 | 21.7 | 0.6 | -43.7 | 37.6 | 4.6 |
| TWO OR MORE ARRIVE | 0.1 | +0.4 | 0.0 | 3.2 | 0.2 | +0.7 | 0.0 | 0.0 |
| WAIT AFTER COSTS | 6.7 | -297.2 | 188.6 | 117.6 | 7.8 | -385.7 | 234.5 | 171.6 |
| WALKS TO THE FIGHT | 1.9 | +40.8 | 56.2 | 29.0 | 1.3 | +48.9 | 49.1 | 7.4 |
| WAR ENGINE CHARGES | 0.1 | +10.2 | 13.1 | 1.8 | 0.1 | +6.2 | 4.6 | 2.1 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 42.4 | 1.8 | 0.5 | +0.0 | 13.1 | 6.9 |
| WEARS DOWN | 1.2 | +74.5 | 87.9 | 52.4 | 1.4 | +48.2 | 119.6 | 32.1 |
| WHO HITS BACK | 0.2 | +12.5 | 0.0 | 13.7 | 0.3 | +20.2 | 0.0 | 14.9 |
| WHOLE FIGHT | 0.2 | +10.3 | 36.5 | 8.5 | 0.6 | +40.3 | 99.9 | 7.6 |
| WHOLE FIGHT GAIN | 0.2 | +12.7 | 17.2 | 1.2 | 0.7 | +58.6 | 106.5 | 18.8 |

### Rule changes: shots-h2h-opp-7c46ffc-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1132 | 1132 | 1132 | 31.44 | -56250 | -49.7 |
| BEST FIRST | 284 | 284 | 284 | 7.89 | +14234 | +50.1 |
| SEARCH SPOT | 180 | 180 | 177 | 4.92 | +8983 | +50.8 |
| COUNTER-CHARGE COVER | 583 | 323 | 174 | 4.83 | +10553 | +60.6 |
| PATHS CROSS | 145 | 145 | 145 | 4.03 | +10127 | +69.8 |
| MOVE TO CHARGE | 241 | 241 | 127 | 3.53 | +8192 | +64.5 |
| KILLS COUNT NEXT TURN | 393 | 393 | 119 | 3.31 | +4274 | +35.9 |
| FACES THE THREAT | 102 | 102 | 102 | 2.83 | +9232 | +90.5 |
| SUPPORTS | 287 | 287 | 97 | 2.69 | +898 | +9.3 |
| FALLBACK BY WORTH | 388 | 388 | 96 | 2.67 | +5176 | +53.9 |
| FOLLOW UP WEIGHED | 88 | 88 | 88 | 2.44 | +13200 | +150.0 |
| WALKS TO THE FIGHT | 116 | 116 | 72 | 2.00 | +1459 | +20.3 |
| WAIT AFTER COSTS | 521 | 521 | 64 | 1.78 | +1232 | +19.2 |
| SAFER THAN THE JOB | 61 | 61 | 61 | 1.69 | +3359 | +55.1 |
| ARTILLERY RE-ROLL WEIGHED | 58 | 58 | 58 | 1.61 | +0 | +0.0 |
| REDIRECT COUNTER | 218 | 127 | 58 | 1.61 | +4647 | +80.1 |
| SHOTS IN THE MOVE | 872 | 578 | 56 | 1.56 | +897 | +16.0 |
| CANNON SIGHT KEPT | 52 | 52 | 52 | 1.44 | +0 | +0.0 |
| CHARGE NOW FIRST | 226 | 226 | 52 | 1.44 | -4507 | -86.7 |
| RANDOM MOVE BY FIGURES | 78 | 78 | 51 | 1.42 | +1027 | +20.1 |
| ADVANCE LANE KEPT | 49 | 49 | 49 | 1.36 | +0 | +0.0 |
| RESERVE FALL BACK | 46 | 46 | 46 | 1.28 | +1544 | +33.6 |
| RISK BY ARC | 219 | 209 | 46 | 1.28 | +1441 | +31.3 |
| MAX FOR POSITIONING | 340 | 207 | 45 | 1.25 | +485 | +10.8 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| CANNON PLANNED TARGET | 232 | 232 | 43 | 1.19 | +15 | +0.3 |
| BEST FACING | 41 | 41 | 41 | 1.14 | +2245 | +54.8 |
| MARCH CHECK | 41 | 40 | 38 | 1.06 | +2136 | +56.2 |
| SET UP TOGETHER | 72 | 66 | 38 | 1.06 | +4148 | +109.2 |
| COMBAT PIVOT | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| INVITES THE FIGHT | 121 | 121 | 35 | 0.97 | +546 | +15.6 |
| LONE WIZARD KEPT IN | 34 | 34 | 34 | 0.94 | +2648 | +77.9 |
| STAY WORTH | 412 | 330 | 34 | 0.94 | +469 | +13.8 |
| KILLS COUNT | 147 | 145 | 33 | 0.92 | +1116 | +33.8 |
| MISSILES IN THE MOVE | 270 | 164 | 32 | 0.89 | +940 | +29.4 |
| SHOOTS FROM THE BEST SPOT | 68 | 68 | 32 | 0.89 | +1008 | +31.5 |
| STOPS SHORT OF THE FLANK | 31 | 31 | 31 | 0.86 | +1888 | +60.9 |
| THROUGH LINE OF FIRE | 31 | 31 | 31 | 0.86 | +1553 | +50.1 |
| CHARGE NOW WEIGHED | 30 | 30 | 30 | 0.83 | +1519 | +50.6 |
| BEST OVERALL | 28 | 28 | 28 | 0.78 | +1791 | +64.0 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| BEST MOVE FOR SHOOTERS | 25 | 25 | 25 | 0.69 | +1808 | +72.3 |
| CASTER AWAY FROM SCREEN | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| SHOT REPLANNED | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| BEST PREY | 69 | 69 | 24 | 0.67 | +949 | +39.5 |
| SHOOTERS IN TWO RANKS | 24 | 24 | 24 | 0.67 | +58 | +2.4 |
| FRIENDS SHOTS CHECKED | 23 | 23 | 23 | 0.64 | +1245 | +54.1 |
| REDIRECT WEIGHED | 23 | 23 | 23 | 0.64 | +600 | +26.1 |
| BLOCKED WHEEL | 21 | 21 | 21 | 0.58 | +1241 | +59.1 |
| MOVE AND CAST | 20 | 20 | 20 | 0.56 | +1493 | +74.6 |
| WHO HITS BACK | 19 | 19 | 19 | 0.53 | +744 | +39.2 |
| CAST JOB | 31 | 31 | 17 | 0.47 | +257 | +15.1 |
| KEEPS ITS TARGET | 135 | 131 | 16 | 0.44 | +258 | +16.1 |
| OPENS UP | 22 | 22 | 16 | 0.44 | +783 | +49.0 |
| THREAT IN THE KILL | 268 | 211 | 16 | 0.44 | +288 | +18.0 |
| WAR ENGINE JOBS | 44 | 44 | 15 | 0.42 | -1107 | -73.8 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| MAKE SURE TOGETHER | 34 | 29 | 14 | 0.39 | +1644 | +117.4 |
| MANOEUVRE | 15 | 15 | 13 | 0.36 | +278 | +21.4 |
| WEARS DOWN | 95 | 90 | 13 | 0.36 | +563 | +43.3 |
| CASTING BLOCK | 22 | 22 | 12 | 0.33 | +696 | +58.0 |
| CHAFF PASSED | 12 | 12 | 12 | 0.33 | -41 | -3.5 |
| MARCH ODDS | 12 | 12 | 12 | 0.33 | +131 | +10.9 |
| WHOLE FIGHT GAIN | 31 | 28 | 12 | 0.33 | +605 | +50.4 |
| BIG CHARACTER SAFETY | 10 | 10 | 10 | 0.28 | -22 | -2.2 |
| MODEL FACING | 10 | 10 | 10 | 0.28 | +2684 | +268.4 |
| STUCK PIVOT | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| RESTRAINS TO SHOOT | 9 | 9 | 9 | 0.25 | +538 | +59.7 |
| HUNT IN PAIRS | 25 | 18 | 8 | 0.22 | +286 | +35.8 |
| OVERRUNS AWAY | 40 | 39 | 8 | 0.22 | +152 | +19.0 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| SUPPORT NARROWED | 486 | 486 | 8 | 0.22 | -95 | -11.8 |
| FOCUS OVER TURNS | 16 | 16 | 7 | 0.19 | +57 | +8.2 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| PURSUES BIG PREY | 7 | 7 | 7 | 0.19 | -536 | -76.5 |
| SURE REACH TOGETHER | 43 | 32 | 7 | 0.19 | +18 | +2.6 |
| WHOLE FIGHT | 31 | 30 | 7 | 0.19 | +207 | +29.6 |
| MISSILES NEXT TURN | 321 | 191 | 6 | 0.17 | +43 | +7.2 |
| BACKUP TARGETS | 60 | 31 | 5 | 0.14 | +16 | +3.2 |
| BEST PRIZE | 5 | 5 | 5 | 0.14 | -679 | -135.8 |
| BLOCKED CHARGE SKIPPED | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| HUNT ADVANCE | 11 | 11 | 5 | 0.14 | +170 | +33.9 |
| LOST CHARGE | 196 | 195 | 5 | 0.14 | +190 | +38.1 |
| PIVOT GUARDS FLANK | 5 | 5 | 5 | 0.14 | -57 | -11.5 |
| PERIAPT WORTH | 4 | 4 | 4 | 0.11 | +356 | +89.0 |
| STANDS TO CAST | 4 | 4 | 4 | 0.11 | +15 | +3.7 |
| STAY WEIGHED | 4 | 4 | 4 | 0.11 | +567 | +141.6 |
| DEFENSIVE ARMY | 15 | 15 | 3 | 0.08 | -154 | -51.3 |
| DEFENSIVE FLOOR | 4 | 4 | 3 | 0.08 | +30 | +10.1 |
| NO RALLY LEFT | 3 | 3 | 3 | 0.08 | +43 | +14.4 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 3 | 0.08 | +187 | +62.2 |
| REDIRECT BY WHAT IT STOPS | 26 | 26 | 3 | 0.08 | +92 | +30.8 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +30 | +15.0 |
| CARRIES OUT SET-UP | 9 | 9 | 2 | 0.06 | -55 | -27.3 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -27 | -13.3 |
| EDGE GIVE GROUND | 10 | 10 | 2 | 0.06 | +5 | +2.7 |
| FACE THE CAST | 2 | 2 | 2 | 0.06 | +29 | +14.5 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +15 | +7.4 |
| KEEP FALLS | 2 | 2 | 2 | 0.06 | +37 | +18.5 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| MOVE SPELL IN RANGE | 3 | 3 | 2 | 0.06 | +6 | +3.2 |
| NEEDED THERE | 3 | 3 | 2 | 0.06 | +0 | +0.0 |
| RAIDS THE BAGGAGE | 2 | 2 | 2 | 0.06 | +270 | +135.1 |
| SURE CHARGE BEATS ADVANCE | 2 | 2 | 2 | 0.06 | -102 | -50.9 |
| WAR ENGINE CHARGES | 7 | 7 | 2 | 0.06 | +172 | +85.8 |
| CARRIES OUT COUNTER | 2 | 2 | 1 | 0.03 | -49 | -49.4 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +47 | +46.9 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +29 | +28.9 |
| JOINT CHARGE PLAN | 9 | 9 | 1 | 0.03 | +75 | +74.8 |
| KEEPS ITS PREY | 1 | 1 | 1 | 0.03 | +2 | +2.5 |
| LONE WIZARD HOLDS BACK | 19 | 19 | 1 | 0.03 | -51 | -51.0 |
| LONG SHOT | 36 | 36 | 1 | 0.03 | +2 | +2.3 |
| OPENS A LANE | 10 | 4 | 1 | 0.03 | +10 | +10.4 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 28 | 28 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 33 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 9 | 9 | 0 | 0.00 | - | - |
| CHEAP HELPER | 7 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 31 | not checked | - | - | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 360 | not checked | - | - | - | - |
| GIVES UP | 8 | 7 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 3 | 3 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 4 | not checked | - | - | - | - |
| HELPER UNSEEN | 22 | 20 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 5 | 5 | 0 | 0.00 | - | - |
| HUNT DROPPED | 4 | trace | - | - | - | - |
| HUNT KEPT | 4 | trace | - | - | - | - |
| HUNT RESULT | 13 | trace | - | - | - | - |
| HUNT THE GUNS | 13 | trace | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 28 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 34 | 34 | 0 | 0.00 | - | - |
| MISSILES IN THE PLAN | 25 | 1 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 12 | 12 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 13 | trace | - | - | - | - |
| MOVE SPELL SPOT | 10 | not checked | - | - | - | - |
| NOT NEEDED | 24 | 24 | 0 | 0.00 | - | - |
| NOT TURNED | 351 | 351 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 35 | not checked | - | - | - | - |
| PLAN RESULT | 2735 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 14 | 14 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 10 | 10 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 19 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 13 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOT OPTIONS | 953 | 953 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 21 | not checked | - | - | - | - |
| SPELL WORTH | 119 | not checked | - | - | - | - |
| STABLE ROLE | 834 | 829 | 0 | 0.00 | - | - |
| STOPS | 5 | 5 | 0 | 0.00 | - | - |
| TURN WORTH | 43 | 42 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 10 | 9 | 0 | 0.00 | - | - |

### Off best figure: shots-h2h-opp-7c46ffc-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 14.42 | 13.22 | 50.4 |
| FALLBACK | gate | 0.78 | 0.92 | 40.0 |
| CHARGE NOW FIRST | rule | 0.64 | 0.81 | 86.7 |
| TURN GATE | gate | 0.42 | 0.33 | 35.1 |
| WAR ENGINE JOBS | rule | 0.33 | 0.08 | 73.8 |
| LONE CHARACTER SAFE SPOT | gate | 0.17 | 0.17 | 53.3 |
| PATHS CROSS | rule | 0.22 | 0.08 | 36.1 |
| SUPPORT REQUEST | gate | 0.17 | 0.14 | 124.4 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.19 | 0.08 | 65.1 |
| AFTERMATH BAND | gate | 0.14 | 0.08 | 2.7 |
| FIGHT ORDER BAND | gate | 0.14 | 0.08 | 2.5 |
| SUPPORT NARROWED | rule | 0.11 | 0.11 | 11.8 |
| CHARGE NOW WEIGHED | rule | 0.06 | 0.14 | 37.8 |
| PURSUES BIG PREY | rule | 0.06 | 0.14 | 76.5 |
| CHAFF PASSED | rule | 0.03 | 0.14 | 6.9 |
| BEST PRIZE | rule | 0.08 | 0.06 | 135.8 |
| BIG CHARACTER SAFETY | rule | 0.14 | - | 10.9 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.03 | 11.5 |
| THROUGH LINE OF FIRE | rule | 0.11 | - | 19.5 |
| CANNON PLANNED TARGET | rule | 0.08 | - | 77.4 |
| DEFENSIVE ARMY | rule | 0.08 | - | 51.3 |
| FACES THE THREAT | rule | 0.08 | - | 14.5 |
| MARCH ODDS | rule | - | 0.08 | 14.4 |
| REDIRECT WEIGHED | rule | 0.06 | 0.03 | 43.0 |
| BLOCKED WHEEL | rule | 0.03 | 0.03 | 12.9 |
| CARRIES OUT SET-UP | rule | - | 0.06 | 27.3 |
| SURE CHARGE BEATS ADVANCE | rule | - | 0.06 | 50.9 |
| CARRIES OUT COUNTER | rule | 0.03 | - | 49.4 |
| CATCH ODDS | rule | - | 0.03 | 26.4 |
| FOLLOW UP WEIGHED | rule | 0.03 | - | 4.8 |
| LONE WIZARD HOLDS BACK | rule | - | 0.03 | 51.0 |
| SAFER THAN THE JOB | rule | 0.03 | - | 10.3 |
| STANDS TO CAST | rule | 0.03 | - | 10.0 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | - | 0.6 |

### Plans: shots-h2h-opp-7c46ffc-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.8 | 15% | 466 | 260 | 56% |
| Mine | charge | 3.6 | 52% | 406 | 281 | 69% |
| Mine | close in | 3.5 | 26% | 281 | 93 | 33% |
| Mine | hold | 5.1 | 46% | 324 | 0 | 0% |
| Mine | join | 0.7 | 96% | 21 | 0 | 0% |
| Mine | shoot | 9.3 | 63% | 329 | 775 | 235% |
| Mine | support | 3.6 | 85% | 25 | 0 | 0% |
| Opponent | advance | 13.0 | 15% | 443 | 362 | 82% |
| Opponent | charge | 5.2 | 63% | 541 | 478 | 89% |
| Opponent | close in | 5.2 | 27% | 419 | 154 | 37% |
| Opponent | hold | 4.2 | 46% | 294 | 0 | 0% |
| Opponent | join | 1.3 | 94% | 54 | 0 | 0% |
| Opponent | shoot | 4.3 | 60% | 215 | 266 | 124% |
| Opponent | support | 5.2 | 87% | 51 | 0 | 0% |

### Packages: hunt the guns, shots-h2h-opp-7c46ffc-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 1 | 0 | 100% | 0% | 0% | - | 206 | 0 | 0% | 8 |
| Opponent | 0.3 | 12 | 0 | 8% | 17% | 8% | 2.5 | 392 | 41 | 17% | 109 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 60 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 86 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 87 |
| High Elf Realms | 0.2 | 1 | 0 | 100% | 0% | 0% | - | 206 | 0 | 0% | 120 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 88 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.7 | 2 | 0 | 50% | 50% | 0% | 2.0 | 135 | 70 | 50% | 0 |
| Skaven | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 463 | 0 | 0% | 69 |
| Tomb Kings of Khemri | 0.3 | 2 | 0 | 0% | 50% | 0% | 3.0 | 344 | 128 | 50% | 65 |
| Vampire Counts | 0.2 | 2 | 0 | 0% | 0% | 50% | - | 399 | 47 | 0% | 27 |
| Warriors of Chaos | 0.5 | 4 | 0 | 0% | 0% | 0% | - | 539 | 0 | 0% | 116 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 329 | 0 | 0% | 42 |

### Battle groups: shots-h2h-opp-7c46ffc-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.5 | 23% | 60% | 10% | 38% | 38% | 11% | 3% | 49% | 0% |
| Mine | REDIRECT COUNTER | 2.2 | 42% | 61% | 9% | 0% | 23% | 3% | 7% | 63% | 3% |
| Opponent | COUNTER-CHARGE COVER | 6.7 | 19% | 58% | 22% | 30% | 46% | 3% | 11% | 40% | 0% |
| Opponent | REDIRECT COUNTER | 3.9 | 18% | 72% | 16% | 0% | 24% | 0% | 14% | 57% | 5% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: shots-h2h-opp-7c46ffc-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 44 | 67% | 3.0 | 0 (1) | 0 (1) | 0 (1) | 0 (1) | 0 (2) |
| Mine | Chaff | 36 | 13 (36) | 8 | 5 | 62 | 47% | 2.2 | 16 (15) | 0 (10) | 22 (11) | 8 (22) | 21 (14) |
| Mine | Character | 123 | 46 (123) | 46 | 0 | 40 | 17% | 2.4 | 54 (40) | 51 (54) | 33 (10) | 51 (64) | 51 (40) |
| Mine | Clean-up | 26 | 85 (26) | 40 | 45 | 13 | 46% | 3.1 | 103 (10) | 83 (12) | 0 (4) | 114 (13) | 62 (13) |
| Mine | Fast | 4 | 18 (4) | 18 | 0 | 47 | 0% | 1.5 | 33 (1) | 0 (2) | 0 (1) | 18 (4) | - |
| Mine | Fast Hammer | 40 | 24 (40) | 16 | 9 | 64 | 22% | 2.9 | 23 (18) | 17 (11) | 33 (11) | 34 (29) | 3 (11) |
| Mine | Fragile | 5 | 14 (5) | 14 | 0 | 60 | 0% | 1.2 | - | 17 (4) | 0 (1) | 69 (1) | 0 (4) |
| Mine | Hammer | 56 | 43 (56) | 32 | 11 | 45 | 11% | 2.6 | 28 (11) | 50 (37) | 29 (8) | 44 (34) | 42 (22) |
| Mine | Holder | 26 | 85 (26) | 3 | 82 | 21 | 42% | 3.1 | 71 (9) | 91 (10) | 96 (7) | 94 (14) | 76 (12) |
| Mine | Shooter | 45 | 111 (45) | 43 | 67 | 43 | 4% | 1.8 | 11 (5) | 134 (33) | 102 (7) | 142 (23) | 81 (22) |
| Mine | Support | 5 | 24 (5) | 24 | 0 | 42 | 20% | 2.8 | - | 42 (2) | - | 42 (2) | - |
| Mine | War machine | 56 | 59 (56) | 59 | 0 | 42 | 5% | 1.3 | 74 (14) | 59 (37) | 23 (5) | 70 (11) | 57 (45) |
| Mine | Wizard | 23 | 9 (23) | 9 | 0 | 52 | 22% | 2.1 | 24 (6) | 0 (7) | 0 (2) | 24 (4) | 5 (11) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | 0 (1) | - | - | 0 (1) | - |
| Opponent | Chaff | 68 | 77 (68) | 27 | 50 | 40 | 37% | 2.7 | 101 (30) | 35 (16) | 80 (22) | 95 (50) | 25 (18) |
| Opponent | Character | 113 | 71 (113) | 71 | 0 | 38 | 22% | 2.4 | 86 (36) | 66 (60) | 97 (6) | 76 (69) | 74 (33) |
| Opponent | Clean-up | 18 | 38 (18) | 31 | 8 | 48 | 33% | 3.2 | 24 (5) | 40 (10) | 56 (3) | 51 (11) | 19 (7) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 53 | 41 (53) | 19 | 21 | 50 | 34% | 2.5 | 42 (20) | 45 (18) | 34 (15) | 37 (37) | 50 (16) |
| Opponent | Fragile | 10 | 40 (10) | 40 | 0 | 73 | 50% | 1.8 | 75 (3) | 64 (3) | 0 (4) | 31 (6) | 57 (4) |
| Opponent | Hammer | 63 | 24 (63) | 13 | 11 | 37 | 24% | 2.8 | 33 (16) | 20 (40) | 36 (7) | 24 (39) | 24 (24) |
| Opponent | Holder | 40 | 66 (40) | 4 | 62 | 22 | 40% | 3.2 | 59 (8) | 94 (19) | 27 (12) | 98 (22) | 28 (17) |
| Opponent | Shooter | 32 | 97 (32) | 37 | 59 | 28 | 0% | 1.4 | 105 (8) | 98 (18) | 82 (6) | 71 (17) | 131 (15) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (2) | - | - | - | 0 (2) |
| Opponent | War machine | 13 | 21 (13) | 21 | 0 | 53 | 23% | 1.1 | 12 (5) | 0 (5) | 77 (3) | 0 (3) | 27 (10) |
| Opponent | Wizard | 24 | 4 (24) | 4 | 0 | 37 | 8% | 2.2 | 3 (11) | 13 (6) | 0 (3) | 5 (10) | 4 (10) |

### Charged fights: shots-h2h-opp-7c46ffc-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 305 | 10 | 1.0 | 1.2 | 10 | 0 | +10 | 1 of 5 | 5 of 5 | +0 | +13 |
| Mine | Chaos Dwarfs | 3 | 22 | 663 | 5.3 | 1.0 | 124 | 4 | +120 | 7 of 16 | 11 of 15 | - | +120 |
| Mine | Dwarfen Mountain Holds | 4 | 718 | 111 | 1.8 | 1.4 | 63 | 0 | +63 | 2 of 7 | 4 of 7 | +114 | +25 |
| Mine | Empire of Man | 5 | 427 | 17 | 1.2 | 1.3 | 14 | 0 | +14 | 1 of 6 | 3 of 6 | +42 | +0 |
| Mine | Grand Cathay | 4 | 770 | 216 | 3.2 | 1.2 | 66 | 112 | -46 | 7 of 13 | 9 of 13 | -42 | -47 |
| Mine | High Elf Realms | 4 | 72 | 629 | 4.0 | 1.2 | 157 | 13 | +145 | 6 of 16 | 11 of 16 | +288 | +112 |
| Mine | Kingdom of Bretonnia | 1 | 218 | 153 | 4.0 | 1.0 | 38 | 153 | -115 | 3 of 4 | 2 of 4 | - | -115 |
| Mine | Lizardmen | 1 | 70 | 540 | 2.0 | 1.0 | 270 | 158 | +112 | 2 of 2 | 2 of 2 | - | +112 |
| Mine | Ogre Kingdoms | 1 | 70 | 66 | 1.0 | 1.0 | 66 | 0 | +66 | 0 of 1 | 0 of 1 | - | +66 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 345 | 5.0 | 1.2 | 69 | 52 | +17 | 2 of 5 | 3 of 5 | +195 | -28 |
| Mine | Skaven | 2 | 22 | 38 | 2.0 | 1.2 | 19 | 0 | +19 | 3 of 4 | 3 of 4 | +0 | +25 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 862 | 3.0 | 1.2 | 288 | 0 | +288 | 2 of 6 | 5 of 6 | +938 | +157 |
| Mine | Vampire Counts | 2 | 0 | 85 | 6.5 | 1.1 | 13 | 62 | -49 | 5 of 13 | 8 of 13 | +0 | -53 |
| Mine | Warriors of Chaos | 1 | 27 | 160 | 2.0 | 1.0 | 80 | 0 | +80 | 2 of 2 | 1 of 2 | - | +80 |
| **Mine** | all armies | 36 | 289 | 255 | 2.8 | 1.2 | 92 | 37 | +55 | 43 of 100 | 67 of 99 | +144 | +38 |
| Opponent | Beastmen Brayherds | 1 | 0 | 130 | 2.0 | 1.5 | 65 | 111 | -46 | 2 of 2 | 1 of 2 | -137 | +45 |
| Opponent | Dwarfen Mountain Holds | 1 | 112 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Empire of Man | 1 | 65 | 427 | 2.0 | 1.0 | 214 | 0 | +214 | 1 of 2 | 2 of 2 | - | +214 |
| Opponent | Grand Cathay | 1 | 460 | 95 | 3.0 | 1.0 | 32 | 0 | +32 | 1 of 3 | 2 of 3 | - | +32 |
| Opponent | High Elf Realms | 2 | 182 | 466 | 4.0 | 1.1 | 116 | 0 | +116 | 6 of 8 | 4 of 8 | +0 | +133 |
| Opponent | Lizardmen | 1 | 380 | 376 | 4.0 | 1.0 | 94 | 71 | +23 | 2 of 4 | 3 of 4 | - | +23 |
| Opponent | Ogre Kingdoms | 2 | 52 | 140 | 5.0 | 1.2 | 28 | 3 | +25 | 1 of 10 | 5 of 10 | +85 | +10 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 342 | 4.5 | 1.1 | 76 | 179 | -103 | 4 of 9 | 5 of 9 | -435 | -61 |
| Opponent | Skaven | 2 | 119 | 0 | 2.5 | 1.0 | 0 | 169 | -169 | 3 of 5 | 1 of 5 | - | -169 |
| Opponent | Tomb Kings of Khemri | 4 | 103 | 983 | 4.5 | 1.2 | 218 | 4 | +214 | 9 of 18 | 13 of 18 | +211 | +216 |
| Opponent | Vampire Counts | 6 | 23 | 700 | 4.8 | 1.3 | 145 | 35 | +110 | 12 of 29 | 21 of 29 | +107 | +111 |
| Opponent | Warriors of Chaos | 7 | 15 | 288 | 2.1 | 1.1 | 134 | 0 | +134 | 3 of 15 | 8 of 15 | +72 | +139 |
| Opponent | Wood Elf Realms | 6 | 276 | 580 | 4.0 | 1.2 | 145 | 9 | +136 | 8 of 24 | 18 of 24 | +29 | +164 |
| **Opponent** | all armies | 36 | 112 | 460 | 3.6 | 1.2 | 127 | 33 | +94 | 52 of 130 | 84 of 130 | +64 | +100 |

### Effective charges: shots-h2h-opp-7c46ffc-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 0 | 0 | 0 | 2 (net +0) | 0 | 1 (net +0) | 2 | 0% (0 of 3) |
| Mine | Chaos Dwarfs | 16 | 2 (net +26) | 0 | 2 (net +321) | 3 (net +160) | 1 (net +0) | 7 (net +98) | 1 | 13% (2 of 15) |
| Mine | Dwarfen Mountain Holds | 7 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 5 (net +89) | 0 | 0% (0 of 7) |
| Mine | Empire of Man | 6 | 2 (net +0) | 0 | 1 (net +0) | 1 (net +0) | 1 (net +83) | 1 (net +0) | 0 | 17% (1 of 6) |
| Mine | Grand Cathay | 13 | 1 (net -233) | 0 | 0 | 4 (net +66) | 2 (net +46) | 6 (net -120) | 0 | 0% (0 of 13) |
| Mine | High Elf Realms | 16 | 4 (net +356) | 0 | 4 (net +216) | 1 (net +0) | 0 | 2 (net +0) | 5 | 36% (4 of 11) |
| Mine | Kingdom of Bretonnia | 4 | 1 (net -277) | 0 | 1 (net -336) | 1 (net +0) | 1 (net +153) | 0 | 0 | 25% (1 of 4) |
| Mine | Lizardmen | 2 | 0 | 1 (net +365) | 0 | 0 | 0 | 0 | 1 | 0% (0 of 1) |
| Mine | Ogre Kingdoms | 1 | 0 | 0 | 0 | 1 (net +66) | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Orc & Goblin Tribes | 5 | 0 | 0 | 1 (net +195) | 1 (net +0) | 0 | 1 (net +90) | 2 | 33% (1 of 3) |
| Mine | Skaven | 4 | 0 | 0 | 0 | 1 (net +0) | 0 | 3 (net +25) | 0 | 0% (0 of 4) |
| Mine | Tomb Kings of Khemri | 6 | 0 | 0 | 1 (net +938) | 2 (net +55) | 1 (net +120) | 2 (net +278) | 0 | 17% (1 of 6) |
| Mine | Vampire Counts | 13 | 7 (net -89) | 0 | 1 (net +0) | 2 (net +0) | 0 | 3 (net -5) | 0 | 8% (1 of 13) |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +80) | 0 | 0% (0 of 2) |
| Opponent | Beastmen Brayherds | 2 | 1 (net -137) | 0 | 0 | 0 | 0 | 1 (net +45) | 0 | 0% (0 of 2) |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | Empire of Man | 2 | 0 | 0 | 0 | 1 (net +427) | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Grand Cathay | 3 | 1 (net +95) | 0 | 0 | 1 (net +0) | 0 | 1 (net +0) | 0 | 0% (0 of 3) |
| Opponent | High Elf Realms | 8 | 1 (net +296) | 1 (net +0) | 0 | 1 (net +0) | 0 | 5 (net +127) | 0 | 0% (0 of 8) |
| Opponent | Lizardmen | 4 | 1 (net -283) | 0 | 0 | 0 | 0 | 1 (net +110) | 2 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 10 | 2 (net -17) | 0 | 1 (net +85) | 4 (net +21) | 0 | 3 (net +37) | 0 | 10% (1 of 10) |
| Opponent | Orc & Goblin Tribes | 9 | 3 (net -98) | 0 | 0 | 1 (net +230) | 0 | 0 | 5 | 0% (0 of 4) |
| Opponent | Skaven | 5 | 1 (net +0) | 1 (net -732) | 0 | 1 (net -112) | 0 | 2 (net +0) | 0 | 0% (0 of 5) |
| Opponent | Tomb Kings of Khemri | 18 | 1 (net +776) | 1 (net +0) | 5 (net +59) | 5 (net +250) | 1 (net +77) | 3 (net +431) | 2 | 31% (5 of 16) |
| Opponent | Vampire Counts | 29 | 6 (net -52) | 0 | 7 (net +149) | 3 (net +63) | 1 (net +126) | 12 (net +178) | 0 | 24% (7 of 29) |
| Opponent | Warriors of Chaos | 15 | 3 (net +271) | 0 | 3 (net +42) | 2 (net +308) | 1 (net +104) | 5 (net +46) | 1 | 21% (3 of 14) |
| Opponent | Wood Elf Realms | 24 | 2 (net +0) | 1 (net +0) | 6 (net +124) | 3 (net +23) | 2 (net -30) | 7 (net +324) | 3 | 29% (6 of 21) |

### Charged fights, damage counted: shots-h2h-opp-7c46ffc-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 18 | 284 | 268 | +19 | 107 | 97 | +10 | +3.6 |
| Mine | 50-54% | 1 | 405 | 440 | +365 | 540 | 175 | +365 | +90.1 |
| Mine | Effective (55-75%) | 11 | 428 | 220 | +209 | 258 | 77 | +182 | +42.4 |
| Mine | 76-89% | 20 | 246 | 240 | +46 | 76 | 26 | +51 | +20.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 33 | 249 | 214 | +39 | 107 | 45 | +62 | +24.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 339 | 89 | +75 | 84 | 10 | +74 | +21.7 |
| Mine | No odds | 11 | 309 | 122 | -18 | 65 | 78 | -13 | -4.2 |
| Mine | All fights | 100 | 288 | 214 | +55 | 116 | 57 | +59 | +20.5 |
| Opponent | Long shot (under 50%) | 22 | 250 | 246 | +42 | 143 | 95 | +48 | +19.1 |
| Opponent | 50-54% | 4 | 179 | 450 | -183 | 13 | 224 | -211 | -118.1 |
| Opponent | Effective (55-75%) | 22 | 243 | 204 | +105 | 116 | 16 | +100 | +41.1 |
| Opponent | 76-89% | 22 | 309 | 197 | +125 | 143 | 26 | +117 | +38.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 41 | 263 | 188 | +167 | 212 | 30 | +182 | +69.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 458 | 88 | +49 | 83 | 35 | +48 | +10.5 |
| Opponent | No odds | 14 | 179 | 178 | -5 | 75 | 86 | -11 | -6.4 |
| Opponent | All fights | 130 | 261 | 205 | +94 | 146 | 50 | +96 | +36.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| shots-h2h-opp-7c46ffc-p1 | move | 456 | 110 (24%) | 78 (17%) | 51 (11%) | 295 (65%) |
| shots-h2h-opp-7c46ffc-p1 | objective | 315 | 52 (17%) | 34 (11%) | 42 (13%) | 221 (70%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

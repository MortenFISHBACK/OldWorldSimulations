# Doctrine scorecard: shots-h2h-opp-7c46ffc-p3

### Scorecard: shots-h2h-opp-7c46ffc-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 9 | 6 | 1 | 0 | 0 | 0 | 0 | 322 |
| L0126 | 6 | 1 | Opponent | no | 8 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 2 | 6 | 1 | 5 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Opponent | no | 9 | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | no | 0 | 4 | 2 | 2 | 1 | 0 | 0 | 251 |
| L0226 | 4 | 1 | Opponent | no | 4 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | no | - | 3 | 2 | 1 | 0 | 0 | 0 | 675 |
| L0311 | 5 | 1 | Opponent | yes | - | 3 | 0 | 1 | 1 | 0 | 0 | 330 |
| L0327 | 3 | 1 | Mine | no | 1 | 6 | 1 | 0 | 0 | 0 | 0 | 685 |
| L0327 | 3 | 1 | Opponent | no | 8 | 2 | 2 | 2 | 1 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 8 | 2 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | no | - | 2 | 1 | 3 | 1 | 0 | 0 | 140 |
| L0429 | 3 | 1 | Mine | yes | 13 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 2 | 2 | 5 | 1 | 1 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 2 | 3 | 1 | 1 | 0 | 0 | 0 | 475 |
| L0516 | 6 | 1 | Opponent | no | 1 | 2 | 6 | 1 | 1 | 0 | 0 | 200 |
| L0533 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 1193 |
| L0533 | 5 | 1 | Opponent | yes | - | 2 | 4 | 5 | 0 | 0 | 0 | 144 |
| L0620 | 2 | 1 | Mine | - | - | 3 | 5 | 0 | 0 | 0 | 0 | 929 |
| L0620 | 2 | 1 | Opponent | - | - | 3 | 3 | 1 | 1 | 0 | 0 | 210 |
| L0709 | 1 | 1 | Mine | yes | 2 | 2 | 6 | 1 | 1 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 830 |
| L0725 | 5 | 1 | Mine | no | - | 4 | 1 | 1 | 0 | 0 | 0 | 375 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 5 | 3 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | 3 | 2 | 1 | 0 | 0 | 0 | 515 |
| L0815 | 5 | 1 | Opponent | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 115 |
| L0831 | 3 | 1 | Mine | no | 0 | 6 | 1 | 1 | 0 | 0 | 0 | 605 |
| L0831 | 3 | 1 | Opponent | no | 0 | - | 0 | 3 | 2 | 0 | 0 | 314 |
| L0922 | 4 | 1 | Mine | no | 0 | 6 | 1 | 1 | 0 | 0 | 0 | 1074 |
| L0922 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 1 | 0 | 0 | 55 |
| L1013 | 5 | 1 | Mine | yes | - | 3 | 2 | 1 | 1 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | no | - | 1 | 2 | 1 | 1 | 0 | 0 | 140 |
| L1030 | 4 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 492 |
| L1030 | 4 | 1 | Opponent | yes | 3 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 4 | 2 | 7 | 0 | 0 | 0 | 0 | 427 |
| L1122 | 6 | 1 | Opponent | no | 3 | 2 | 3 | 2 | 1 | 0 | 0 | 162 |
| L1216 | 4 | 1 | Mine | no | 3 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1216 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 0 | 0 | 0 | 200 |
| L1232 | 2 | 1 | Mine | - | - | 3 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 3 | 4 | 3 | 3 | 0 | 0 | 340 |
| L1327 | 1 | 1 | Mine | no | 6 | 4 | 3 | 0 | 0 | 0 | 0 | 140 |
| L1327 | 1 | 1 | Opponent | no | 3 | 1 | 6 | 1 | 2 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Mine | no | 4 | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 0 | 3 | 4 | 0 | 0 | 0 | 0 | 170 |
| L1519 | 1 | 1 | Mine | no | 1 | 2 | 2 | 1 | 0 | 0 | 0 | 199 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 8 | 1 | 1 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | yes | - | 3 | 0 | 1 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 2 | 2 | 3 | 1 | 0 | 0 | 126 |
| L1633 | 1 | 1 | Mine | no | 4 | 2 | 2 | 0 | 2 | 0 | 0 | 260 |
| L1633 | 1 | 1 | Opponent | no | 0 | 1 | 6 | 3 | 0 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Mine | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 98 |
| L1731 | 3 | 1 | Opponent | no | 9 | 2 | 2 | 0 | 2 | 0 | 0 | 340 |
| L1831 | 1 | 1 | Mine | no | 3 | 3 | 6 | 1 | 0 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 2 | 6 | 1 | 1 | 0 | 0 | 0 | 170 |
| L1932 | 6 | 1 | Mine | no | 3 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1932 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 3 | 0 | 0 | 0 | 170 |
| L2033 | 5 | 1 | Mine | no | - | - | 2 | 4 | 1 | 0 | 0 | 617 |
| L2033 | 5 | 1 | Opponent | no | - | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Mine | yes | 1 | 1 | 6 | 2 | 2 | 0 | 0 | 144 |
| L2223 | 3 | 1 | Opponent | no | 1 | 2 | 5 | 1 | 0 | 0 | 0 | 72 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Opponent | yes | - | 2 | 6 | 3 | 1 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Mine | no | 0 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 1 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Mine | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 6 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Opponent | no | 2 | 1 | 4 | 2 | 0 | 0 | 0 | 0 |
| L3133 | 1 | 1 | Mine | no | 3 | 2 | 2 | 2 | 3 | 0 | 0 | 340 |
| L3133 | 1 | 1 | Opponent | no | 6 | 5 | 3 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 22% | 2.9 | 3.1 | 2.6 | 1.0 | 0.3 | 0.0 | 0.0 | 311.8 |
| **Average** | | | Opponent | 22% | 2.7 | 2.2 | 3.3 | 1.8 | 0.6 | 0.0 | 0.0 | 140.5 |

### KPIs: shots-h2h-opp-7c46ffc-p3

Rules off - Mine only: STAY WORTH, BEST MOVE FOR SHOOTERS, THREAT IN THE KILL, FOCUS OVER TURNS, MISSILES IN THE PLAN, FACE THE CAST, WIZARD FRONT RANK.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 30% (52 of 176) | 11% (19 of 176) | 20% (71 of 352) |
| Winner chose to follow up after the loser gave ground |  | 96% (73 of 76); on the table 96% | 98% (53 of 54); on the table 98% | 97% (126 of 130); on the table 97% |
| Winner chose to pursue after the loser fell back in good order |  | 82% (9 of 11); on the table 82% | 93% (14 of 15); on the table 93% | 88% (23 of 26); on the table 88% |
| Winner chose to pursue after the loser fled |  | 70% (16 of 23); on the table 83% | 68% (23 of 34); on the table 74% | 68% (39 of 57); on the table 77% |
| Winner chose to follow up or pursue (all three) |  | 89% (98 of 110); on the table 92% | 87% (90 of 103); on the table 89% | 88% (188 of 213); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 23% (80 of 342) | 39% (75 of 192) | 29% (155 of 534) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 38% (80 of 210) | 54% (75 of 139) | 44% (155 of 349) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 21% (41 of 192) | 41% (56 of 138) | 29% (97 of 330) |
|     round 1 |  | 16% (5 of 32) | 35% (8 of 23) | 24% (13 of 55) |
|     rounds 2+ |  | 22% (36 of 160) | 42% (48 of 115) | 31% (84 of 275) |
|   other wizards | 50%+ | 26% (39 of 150) | 35% (19 of 54) | 28% (58 of 204) |
|     round 1 |  | 36% (9 of 25) | 11% (1 of 9) | 29% (10 of 34) |
|     rounds 2+ |  | 24% (30 of 125) | 40% (18 of 45) | 28% (48 of 170) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 53% (8 of 15) | 49% (30 of 61) | 50% (38 of 76) |
| Points that never fought | lower | 34% (23512 of 68801) | 41% (29405 of 71990) | 38% (52917 of 140791) |
|   infantry points that never fought | lower | 42% (5893 of 14174) | 55% (7786 of 14220) | 48% (13679 of 28394) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 57% (156 of 272) | 60% (170 of 285) | 59% (326 of 557) |
| Bound items with a magic missile used (at least once a game) |  | 88% (22 of 25); 1.5 uses a game | 88% (21 of 24); 2.0 uses a game | 88% (43 of 49); 1.7 uses a game |
| Bound items with another spell used |  | 21% (3 of 14); 0.1 uses a game | 17% (1 of 6); 0.0 uses a game | 20% (4 of 20); 0.1 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 55% (11 of 20); 0.3 uses a game | 43% (6 of 14); 0.2 uses a game | 50% (17 of 34); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 52% (31105 of 59391) | 55% (34972 of 64043) | 54% (66077 of 123434) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.6 (21%) | 0.9 (29%) | 2.5 (24%) |
| MARCHED: its unit marched | 1.5 (21%) | 0.8 (24%) | 2.3 (22%) |
| CHARGED: its unit charged | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.7 (23%) | 0.9 (28%) | 2.6 (25%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.1 (2%) | 0.1 (1%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 1.4 (20%) | 0.5 (15%) | 1.9 (18%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (6%) | 0.1 (2%) | 0.5 (4%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.8 | 1.1 | 1.8 | 4.3 | 0.8 | 1.8 |
| not cast | 4.1 | 1.6 | 4.3 | 10.5 | 2.4 | 18.9 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.6 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 0.7 (45%) | 0.4 (10%) | 2.5 (24%) | 0.3 (12%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (22%) | 0.4 (17%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.1 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.4 (10%) | 0.2 (11%) | 0.7 (16%) | 2.6 (25%) | 0.5 (22%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.0 (0%) | 0.2 (5%) | 0.1 (1%) | 0.1 (3%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (4%) | 0.0 (2%) | 0.0 (0%) | 0.1 (1%) | 0.0 (1%) | 0.6 (3%) |
| GONE: slain | 0.9 (23%) | 0.3 (20%) | 1.1 (26%) | 1.9 (18%) | 0.4 (15%) | 2.4 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (6%) | 0.1 (7%) | 0.1 (3%) | 0.5 (4%) | 0.2 (7%) | 0.8 (4%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.1 (4%) | 0.0 (0%) | 0.1 (1%) | 0.5 (20%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.9 (48%) | 0.2 (12%) | 1.6 (37%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.7 (72%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.2 a game | 0.7 a game | 0.9 a game |
| stood (cast and not dispelled) | 69% (22 of 32) | 37% (7 of 19) | 57% (29 of 51) |
| the unit moved after it | 82% (18 of 22) | 86% (6 of 7) | 83% (24 of 29) |
| it charged on its next turn | 5% (1 of 22) | 14% (1 of 7) | 7% (2 of 29) |
| the enemy charged it first | 18% (4 of 22) | 29% (2 of 7) | 21% (6 of 29) |
| it fought by the end of its next turn | 5% (1 of 22) | 14% (1 of 7) | 7% (2 of 29) |
| it moved out of a charge the enemy had planned (not charged first) | 32% (7 of 22) | 29% (2 of 7) | 31% (9 of 29) |
| none of these (no charge, no fight, no charge escaped) | 45% (10 of 22) | 29% (2 of 7) | 41% (12 of 29) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 67% (496 of 745) | 59% (371 of 634) | 63% (867 of 1379) |
|   cavalry | 62% (39 of 63) | 63% (78 of 124) | 63% (117 of 187) |
|   character | 51% (42 of 83) | 19% (22 of 117) | 32% (64 of 200) |
|   chariot | 48% (45 of 93) | 64% (21 of 33) | 52% (66 of 126) |
|   infantry | 57% (114 of 200) | 67% (171 of 257) | 62% (285 of 457) |
|   monster | 39% (11 of 28) | 67% (2 of 3) | 42% (13 of 31) |
|   war machine | 88% (245 of 278) | 77% (77 of 100) | 85% (322 of 378) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.1 (31%) | 1.6 (22%) | 3.8 (27%) |
| CHARGED: it charged | 1.0 (14%) | 1.7 (23%) | 2.7 (19%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (2%) | 0.2 (2%) |
| IN COMBAT: it fought this turn or the last | 0.9 (13%) | 0.8 (11%) | 1.7 (12%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 0.7 (10%) | 0.8 (11%) | 1.5 (11%) |
| ONLY IN COMBAT: the only targets were in combat | 0.2 (3%) | 0.4 (6%) | 0.6 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (21%) | 1.4 (20%) | 2.9 (20%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.2 (2%) | 0.2 (2%) |
| OTHER BAR | 0.3 (5%) | 0.2 (3%) | 0.5 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.6 | 1.0 | 84% | 5.1 pts | 23 pts |
| character | 1.9 | 0.2 | 90% | 4.0 pts | 8 pts |
| chariot | 1.8 | 0.9 | 71% | 12.6 pts | 23 pts |
| infantry | 11.9 | 4.5 | 75% | 10.0 pts | 119 pts |
| monster | 0.4 | 0.0 | 94% | 1.3 pts | 1 pts |
| war machine | 9.2 | 7.3 | 61% | 25.8 pts | 236 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.9 | 5.8 | 4.9 |
| Charges that made contact a game | 2.9 | 4.1 | 3.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.88 declared, 0.73 contact (26 units) | 0.71 declared, 0.71 contact (17 units) | 0.81 declared, 0.72 contact (43 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.25 declared, 1.00 contact (4 units) | 1.60 declared, 0.90 contact (10 units) | 1.50 declared, 0.93 contact (14 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.50 declared, 0.37 contact (224 units) | 0.70 declared, 0.49 contact (259 units) | 0.61 declared, 0.43 contact (483 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 52% (40 of 77) | 47% (7 of 15) | 40% (4 of 10) | 50% (51 of 102) |
| Character in a unit | 82% (28 of 34) | 73% (11 of 15) | 44% (4 of 9) | 74% (43 of 58) |
| Character on its own | 79% (34 of 43) | 54% (22 of 41) | 33% (22 of 66) | 52% (78 of 150) |
| Chariot | 91% (10 of 11) | 75% (9 of 12) | - | 83% (19 of 23) |
| Infantry | 61% (43 of 70) | 50% (21 of 42) | 40% (2 of 5) | 56% (66 of 117) |
| Monster | 65% (22 of 34) | 71% (5 of 7) | - | 66% (27 of 41) |
| Monstrous | 80% (8 of 10) | 55% (6 of 11) | - | 67% (14 of 21) |
| War Machines | 60% (26 of 43) | 100% (2 of 2) | - | 62% (28 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (9 of 9); on the table 100% | 18% (17 of 96) | 26% | 64% (14 of 22) | 83% (5 of 6); 3.0 uses a game | 50% (1 of 2); 0.2 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 95% (20 of 21); on the table 95% | 53% (19 of 36) | 39% | 56% (18 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 83% (5 of 6); on the table 83% | - | 50% | 79% (19 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 60% (3 of 5); on the table 60% | 50% (15 of 30) | 52% | 69% (41 of 59) | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 8 | 100% (29 of 29); on the table 100% | 27% (52 of 192) | 40% | 46% (34 of 74) | 83% (15 of 18); 5.4 uses a game | 25% (1 of 4); 0.1 uses a game | 38% (3 of 8); 0.4 uses a game |
| High Elf Realms | 7 | 71% (15 of 21); on the table 86% | 19% (8 of 42) | 32% | 56% (30 of 54) | 89% (8 of 9); 2.9 uses a game | 17% (2 of 12); 0.3 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 100% (7 of 7); on the table 100% | - | 46% | 50% (9 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Lizardmen | 1 | 60% (3 of 5); on the table 60% | 67% (4 of 6) | 31% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (3 of 3); on the table 100% | 0% (0 of 6) | 19% | 71% (5 of 7) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (6 of 6); on the table 100% | 8% (1 of 12) | 9% | 69% (11 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Skaven | 2 | 80% (4 of 5); on the table 100% | 25% (3 of 12) | 39% | 57% (8 of 14) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Tomb Kings of Khemri | 6 | 92% (11 of 12); on the table 92% | 17% (1 of 6) | 34% | 69% (18 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 100% (35 of 35); on the table 100% | 28% (15 of 54) | 28% | 46% (21 of 46) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 11 | 75% (30 of 40); on the table 78% | 53% (16 of 30) | 41% | 55% (53 of 96) | 100% (4 of 4); 1.1 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 6 | 89% (8 of 9); on the table 89% | 33% (4 of 12) | 47% | 66% (41 of 62) | 91% (10 of 11); 5.7 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (shots-h2h-opp-7c46ffc-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 53% (50) | 56% (40) | 55% (90) |
| ...free all their last turn and able to turn (per game) | 0.83 | 0.61 | 1.44 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.22 | 0.31 | 0.53 |
| ...with the charger already in that arc before they moved (per game) | 0.61 | 0.47 | 1.08 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.94 | 1.42 | 3.36 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.86 | 0.58 | 1.44 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.89 | 5.03 | 10.92 |

### Quality by phase: shots-h2h-opp-7c46ffc-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.2 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 53% (69 of 130) | 42% (76 of 182) |
| Strategy | Shoot objectives carried out (shot that target) | 47% (168 of 359) | 51% (124 of 241) |
| Strategy | Close-in objectives charged next turn | 13% (22 of 169) | 18% (45 of 247) |
| Strategy | Support requests answered (helper made contact too) | 43% (6 of 14) | 30% (8 of 27) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 36% (4 of 11) | 60% (3 of 5) |
| Strategy | Joined characters whose unit fought | 49% (20 of 41) | 35% (14 of 40) |
| Strategy | Lone characters that fought | 76% (71 of 94) | 76% (71 of 94) |
| Movement | Charges halted short of contact | 0.1 | 0.3 |
| Movement | Idle units | 1.0 | 1.8 |
| Movement | Points that never moved of their own | 311.8 | 140.5 |
| Movement | Fights charged into per game | 2.8 | 3.5 |
| Movement | Charges with odds: long shots (under 50%) | 9 of 88, net -9 | 28 of 107, net +60 |
| Movement | Charges with odds: sweet spot (55-75%) | 10 of 88, net +25 | 13 of 107, net -109 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 13 of 88, net +63 | 8 of 107, net +62 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 34 of 88, net +104 | 34 of 107, net +95 |
| Shooting | Shots by shooting units (incl. breath weapons) | 7.9 | 9.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 37% (105 of 286) | 47% (161 of 344) |
| Shooting | Points destroyed by shooting units | 42.9 | 55.1 |
| Shooting | War machine shots | 6.8 | 2.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 57% (139 of 245) | 35% (30 of 85) |
| Shooting | Points destroyed by war machines | 117.9 | 21.9 |
| Magic | Magic missiles cast | 1.3 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 41% (19 of 46) | 29% (13 of 45) |
| Magic | Wounds caused by magic missiles | 2.8 | 2.5 |
| Magic | Wounds caused by other spells | 1.7 | 1.2 |
| Magic | Points destroyed by magic (all spells) | 67.5 | 50.4 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.4 / 0.3 / 0.7 / 0.1 | 1.8 / 0.2 / 0.3 / 0.4 |
| Combat | Points destroyed in combat | 325.4 | 335.4 |
| Combat | Points run down | 48.4 | 171.5 |
| Combat | Net points per charged fight, damage counted | +69 | +75 |
| Combat | Net per 100 charger points, damage counted | +25.4 | +26.6 |
| Combat | First round won (charged fights) | 76% | 65% |
| Combat | Net points per charged fight | +70 | +77 |
| Combat | Net points per supported fight / lone fight | +30 / +74 | +199 / +65 |
| Combat | Charged fights on a top-3 enemy unit | 23 of 100 | 64 of 126 |
| Game | Points lost | 742.5 | 694.6 |
| Game | VP from objectives | 505.3 | 596.1 |
| Game | Lone holders (player turns) | 2.9 | 2.7 |

- Mine won / drew / lost: 12 / 5 / 19 of 36 ended games (of 36); mean margin (Mine - Opponent) -170 VP
- The side that went first won 17 of 31 games with a winner
- Points traded per game (both sides' losses): 1437
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: shots-h2h-opp-7c46ffc-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 10.3 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.7 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.8 | +0.0 | 0.0 | 18.1 | 0.2 | +0.0 | 0.0 | 3.5 |
| BACKUP TARGETS | 0.8 | +7.8 | 0.0 | 32.3 | 0.8 | +8.6 | 0.0 | 13.3 |
| BEST FACING | 0.8 | +28.3 | 0.0 | 36.4 | 0.4 | +7.2 | 0.0 | 30.7 |
| BEST FIRST | 3.7 | +170.6 | 212.6 | 107.2 | 3.0 | +151.4 | 101.4 | 57.5 |
| BEST MOVE FOR SHOOTERS | - | - | - | - | 0.5 | +57.1 | 0.0 | 14.7 |
| BEST OVERALL | 0.7 | +35.4 | 0.0 | 28.9 | 0.5 | +42.5 | 0.0 | 38.9 |
| BEST PREY | 0.9 | +67.4 | 8.6 | 8.1 | 0.9 | +24.6 | 27.5 | 0.0 |
| BEST PRIZE | 0.1 | -6.1 | 0.0 | 6.5 | 0.0 | -0.8 | 0.0 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | +0.0 | 0.0 | 25.1 | 0.2 | -0.2 | 0.0 | 13.1 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 10.8 | 10.5 | 0.1 | +0.0 | 0.0 | 1.4 |
| BLOCKED WHEEL | 0.3 | +5.2 | 0.0 | 0.0 | 0.5 | +6.2 | 0.0 | 2.9 |
| BOMBING RUN | 0.0 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 92.4 | 14.4 | 0.2 | +0.0 | 14.1 | 0.0 |
| CANNON PLANNED TARGET | 5.9 | +189.0 | 409.8 | 83.9 | 1.6 | +82.9 | 99.5 | 10.4 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | -3.8 | 9.6 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.2 | -10.6 | 18.9 | 13.5 | 0.2 | -2.5 | 24.6 | 3.2 |
| CAST JOB | 0.8 | +31.8 | 85.1 | 2.2 | 0.9 | +22.3 | 39.6 | 6.4 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +30.0 | 8.5 | 0.0 | 0.1 | -0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 22.4 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.2 | -0.3 | 0.0 | 2.9 | 0.2 | -0.7 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 2.2 | +0.0 | 223.9 | 59.2 | 2.8 | +0.0 | 219.0 | 79.5 |
| CHARGE NOW WEIGHED | 0.6 | -54.6 | 33.5 | 12.2 | 0.5 | -50.3 | 28.1 | 14.2 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 1.2 | 2.4 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.4 | 0.0 | 0.0 | 0.1 | -1.6 | 0.0 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 5.2 | 0.0 | 0.1 | +0.0 | 16.7 | 1.1 |
| COMBAT PIVOT | 0.5 | +0.0 | 41.6 | 13.3 | 0.4 | +0.0 | 34.8 | 14.2 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 2.9 | - | - | - | - |
| CONVEYANCE SEARCH | 0.7 | +69.1 | 32.7 | 12.5 | 0.3 | +32.1 | 3.2 | 14.1 |
| COUNTER-CHARGE COVER | 9.6 | +790.7 | 0.0 | 208.1 | 6.1 | +592.6 | 0.0 | 132.8 |
| DEFENSIVE ARMY | 0.2 | -0.0 | 24.6 | 0.0 | 0.1 | +0.0 | 5.8 | 0.0 |
| DEFENSIVE FLOOR | 0.0 | +1.9 | 0.0 | 0.0 | 0.0 | +2.9 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.1 | +3.3 | 5.8 | 3.7 | 0.3 | +9.8 | 20.5 | 15.4 |
| ELIXIR WORTH | 0.0 | +0.1 | 0.0 | 9.7 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACE THE CAST | - | - | - | - | 0.1 | +0.8 | 0.0 | 3.2 |
| FACES THE THREAT | 1.9 | +146.8 | 0.0 | 54.7 | 1.4 | +109.8 | 0.0 | 67.5 |
| FALLBACK BY WORTH | 4.8 | +44.0 | 0.0 | 105.6 | 5.0 | +56.1 | 0.0 | 25.6 |
| FIGHT LIFT | 0.1 | +0.2 | 0.8 | 0.0 | 0.1 | +3.0 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.1 | +0.6 | 0.0 | 4.4 | - | - | - | - |
| FLANK NOT WEIGHED | 6.1 | +0.0 | 0.0 | 151.6 | 4.9 | +0.0 | 0.0 | 177.6 |
| FOCUS OVER TURNS | - | - | - | - | 0.8 | +17.6 | 29.5 | 2.9 |
| FOLLOW UP WEIGHED | 1.4 | +202.2 | 0.0 | 91.4 | 1.1 | +176.1 | 0.0 | 66.8 |
| FRIENDS SHOTS CHECKED | 0.2 | +16.2 | 0.0 | 9.4 | 0.1 | +8.2 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -0.3 | 4.0 | 0.0 | 0.2 | -3.3 | 31.1 | 23.3 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -3.5 | 29.9 | 0.0 |
| GROUND FLIERS | 0.0 | +1.6 | 0.0 | 7.5 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.2 | +0.0 | 15.3 | 2.2 |
| HELPER UNSEEN | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 52.8 | 3.0 |
| HILL BY ITS CHANCE | 0.2 | -19.3 | 0.0 | 1.8 | 0.4 | -44.5 | 0.0 | 14.1 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.1 | +2.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.2 | +11.0 | 0.0 | 7.6 | 0.2 | +6.7 | 3.5 | 5.8 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 3.5 | 0.0 |
| HUNT IN PAIRS | 0.2 | +8.9 | 0.0 | 17.5 | 0.8 | +83.4 | 0.0 | 38.4 |
| HUNT KEPT | 0.2 | +7.7 | 0.0 | 4.7 | 0.2 | +7.6 | 3.5 | 2.9 |
| HUNT RESULT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +9.7 | 6.9 | 0.0 |
| HUNT THE GUNS | 0.1 | +61.8 | 0.0 | 2.9 | 0.2 | +72.5 | 8.1 | 4.9 |
| INVITES THE FIGHT | 1.6 | +44.8 | 92.3 | 24.9 | 1.2 | +22.9 | 33.3 | 15.6 |
| JOINT CHARGE PLAN | 0.1 | +13.7 | 0.0 | 0.0 | 0.4 | +18.8 | 20.4 | 17.4 |
| KEEP FALLS | 0.1 | +1.7 | 0.0 | 6.1 | 0.0 | +0.3 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.1 | +0.1 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.5 | +44.2 | 132.9 | 23.2 | 2.3 | +68.3 | 174.0 | 45.5 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.8 | +77.9 | 127.4 | 35.6 | 2.0 | +101.5 | 170.4 | 35.9 |
| KILLS COUNT NEXT TURN | 5.8 | +199.7 | 224.5 | 144.6 | 7.7 | +254.3 | 356.4 | 127.5 |
| LONE CHARACTER SAFE SPOT | 0.5 | +19.5 | 21.7 | 12.6 | 0.4 | +6.7 | 9.4 | 12.3 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 19.9 | 7.6 |
| LONE WIZARD KEPT IN | 0.6 | +37.3 | 0.0 | 0.0 | 0.4 | +25.4 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | +0.6 | 20.6 | 1.7 | 0.2 | +1.1 | 4.8 | 7.8 |
| LOST CHARGE | 2.7 | -44.5 | 118.1 | 90.1 | 2.4 | -37.4 | 80.6 | 38.3 |
| MAKE SURE TOGETHER | 0.7 | +62.3 | 34.1 | 13.7 | 1.1 | +119.6 | 47.3 | 28.6 |
| MANOEUVRE | 0.3 | +12.1 | 0.0 | 4.2 | 0.1 | +9.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +1.1 | 0.0 | 0.0 | 0.1 | +0.8 | 0.0 | 4.5 |
| MARCH CHECK | 0.6 | +34.9 | 0.0 | 27.1 | 0.6 | +57.7 | 0.0 | 0.0 |
| MARCH ODDS | 0.3 | +18.6 | 29.1 | 0.0 | 0.3 | +17.0 | 6.4 | 0.0 |
| MARCH OVER CASTS | 0.7 | +67.5 | 0.0 | 35.1 | 0.4 | +34.9 | 0.0 | 18.8 |
| MAX FOR POSITIONING | 4.9 | +168.3 | 0.0 | 157.4 | 4.2 | +176.6 | 0.0 | 143.8 |
| MISSILES IN THE MOVE | 3.7 | +147.7 | 0.0 | 97.7 | 4.1 | +91.6 | 0.0 | 50.8 |
| MISSILES IN THE PLAN | - | - | - | - | 0.6 | +5.0 | 16.6 | 0.0 |
| MISSILES NEXT TURN | 4.9 | +97.6 | 0.0 | 155.8 | 5.1 | +69.9 | 0.0 | 71.5 |
| MODEL FACING | 0.1 | +12.8 | 0.0 | 1.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.4 | +0.0 | 69.1 | 22.6 | 0.2 | +0.0 | 43.7 | 0.0 |
| MOVE AND CAST | 0.5 | +22.4 | 0.0 | 2.2 | 0.6 | +24.6 | 0.0 | 3.2 |
| MOVE SPELL IN RANGE | 0.2 | +7.8 | 0.0 | 0.0 | 0.0 | +1.0 | 0.0 | 7.6 |
| MOVE SPELL OUT OF RANGE | 0.4 | -10.5 | 4.3 | 55.4 | 0.2 | -2.2 | 2.9 | 14.1 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 34.4 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 3.4 | +230.7 | 145.6 | 79.1 | 5.9 | +621.3 | 304.7 | 121.5 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +0.2 | 1.7 | 0.0 | 0.1 | +10.5 | 18.1 | 0.0 |
| NO RALLY LEFT | 0.0 | +1.2 | 0.0 | 0.0 | 0.0 | +3.9 | 0.0 | 0.0 |
| NOT NEEDED | 0.1 | -7.0 | 14.9 | 0.0 | 0.3 | -24.9 | 32.2 | 1.1 |
| NOT TURNED | 5.9 | +124.7 | 0.0 | 138.2 | 5.0 | +44.4 | 0.0 | 152.1 |
| NOT WORTH A CAST | 0.5 | -0.4 | 0.0 | 31.0 | 0.8 | -0.9 | 0.0 | 6.5 |
| OFF BEST | 15.2 | -711.9 | 11.0 | 279.0 | 14.9 | -895.7 | 17.7 | 238.0 |
| OPENS A LANE | 0.1 | +0.0 | 6.6 | 0.0 | 0.3 | +1.4 | 7.2 | 0.0 |
| OPENS UP | 0.2 | +17.1 | 4.9 | 6.5 | 0.1 | +10.7 | 9.8 | 0.0 |
| OVERRUNS AWAY | 0.5 | +13.3 | 47.4 | 49.6 | 0.3 | +5.2 | 11.8 | 30.5 |
| PATHS CROSS | 1.8 | +113.4 | 0.0 | 4.2 | 2.6 | +223.5 | 0.0 | 49.9 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +1.5 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.1 | -4.8 | 0.0 | 0.0 |
| PLAN RESULT | 36.0 | +1374.5 | 1454.3 | 908.6 | 38.1 | +1332.7 | 1408.4 | 1012.6 |
| PURSUES BIG PREY | 0.1 | -1.9 | 0.0 | 0.0 | 0.1 | -1.1 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.1 | +11.5 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +4.9 | 0.0 | 0.0 | 0.1 | +4.3 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.4 | +3.8 | 0.0 | 11.7 | 1.7 | +27.3 | 0.0 | 38.9 |
| RANDOM MOVER NO PROMISE | 0.2 | -12.0 | 0.0 | 0.0 | 0.6 | -35.9 | 35.0 | 4.7 |
| REDIRECT BY WHAT IT STOPS | 0.2 | -9.2 | 0.0 | 1.8 | 0.4 | +0.5 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.0 | +200.8 | 0.0 | 53.8 | 3.5 | +345.6 | 0.0 | 58.4 |
| REDIRECT WEIGHED | 0.3 | +6.4 | 11.5 | 6.5 | 0.4 | +8.5 | 10.2 | 0.0 |
| RESERVE FALL BACK | 0.4 | +5.7 | 0.0 | 4.4 | 1.0 | +43.0 | 0.0 | 14.3 |
| RESTRAINS TO SHOOT | 0.1 | +0.6 | 0.0 | 0.0 | 0.0 | +0.3 | 0.0 | 0.0 |
| RISK BY ARC | 2.4 | +75.6 | 222.1 | 90.4 | 2.8 | +68.9 | 275.1 | 68.2 |
| SAFER THAN THE JOB | 0.9 | +57.5 | 0.0 | 24.6 | 0.6 | +33.2 | 0.0 | 9.4 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.9 | 0.3 | +0.8 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.9 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -0.8 | 0.0 | 0.0 | 0.2 | -13.7 | 0.0 | 0.5 |
| SEARCH SPOT | 2.4 | +114.2 | 0.0 | 63.9 | 2.2 | +118.4 | 0.0 | 27.0 |
| SECOND HUNTER | 0.0 | -1.2 | 0.0 | 1.4 | - | - | - | - |
| SELF MOVE SPELL | 0.4 | +64.7 | 0.0 | 11.0 | 0.2 | +61.9 | 0.0 | 9.1 |
| SET UP TOGETHER | 1.0 | +83.6 | 62.1 | 33.9 | 2.1 | +249.0 | 98.3 | 33.9 |
| SET-UP ANY TARGET | 0.4 | +62.3 | 32.7 | 2.6 | 0.2 | +18.9 | 0.0 | 6.5 |
| SET-UP MISSED | 0.0 | +6.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.0 | -0.2 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.7 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +29.9 | 66.8 | 24.7 | 0.7 | +18.1 | 40.1 | 10.7 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OPTIONS | 14.6 | +0.0 | 622.5 | 285.6 | 10.8 | +0.0 | 409.2 | 137.5 |
| SHOT REPLANNED | 0.5 | +0.0 | 94.0 | 0.0 | 0.2 | +0.0 | 32.1 | 3.3 |
| SHOTS IN THE MOVE | 13.2 | +549.8 | 0.0 | 248.5 | 9.9 | +358.6 | 0.0 | 134.7 |
| SPELL SETS UP CHARGE | 0.5 | +98.4 | 32.7 | 2.6 | 0.2 | +18.9 | 0.0 | 6.5 |
| SPELL WORTH | 1.2 | +17.0 | 59.4 | 58.1 | 2.4 | +39.8 | 49.4 | 38.7 |
| STABLE ROLE | 9.7 | +0.0 | 343.5 | 159.8 | 8.6 | +0.0 | 257.6 | 153.8 |
| STANDS TO CAST | 0.0 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| STAY WORTH | - | - | - | - | 12.8 | +308.9 | 247.8 | 140.6 |
| STOPS | 0.2 | +4.3 | 0.0 | 0.0 | 0.2 | +10.6 | 8.1 | 2.0 |
| STOPS SHORT OF THE FLANK | 0.6 | +30.1 | 0.0 | 30.8 | 0.5 | +38.5 | 0.0 | 32.0 |
| STUCK PIVOT | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 4.7 |
| SUPPORT NARROWED | 5.3 | -49.8 | 285.0 | 101.2 | 6.2 | -37.4 | 367.4 | 134.4 |
| SUPPORTS | 3.7 | +59.3 | 140.3 | 62.6 | 3.8 | +37.4 | 140.2 | 58.7 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -5.2 | 6.7 | 9.7 | 0.1 | -2.4 | 6.8 | 2.7 |
| SURE REACH TOGETHER | 0.4 | +4.9 | 7.4 | 16.9 | 0.6 | +2.9 | 6.7 | 0.0 |
| THREAT IN THE KILL | 1.1 | +16.7 | 121.9 | 27.5 | 7.5 | +85.9 | 377.6 | 72.3 |
| THROUGH LINE OF FIRE | 0.3 | +15.4 | 0.0 | 14.7 | 0.2 | +12.7 | 0.0 | 0.0 |
| TURN WORTH | 0.4 | -31.8 | 41.0 | 2.0 | 0.3 | -24.7 | 32.6 | 3.8 |
| TWO OR MORE ARRIVE | 0.3 | +2.0 | 7.3 | 0.0 | 0.7 | +11.2 | 61.1 | 4.2 |
| WAIT AFTER COSTS | 7.2 | -314.8 | 301.3 | 162.0 | 8.6 | -553.6 | 389.5 | 161.4 |
| WALKS TO THE FIGHT | 1.9 | +42.8 | 33.1 | 33.8 | 1.0 | +16.3 | 22.9 | 10.8 |
| WAR ENGINE CHARGES | 0.1 | +13.0 | 0.0 | 5.1 | 0.1 | +0.7 | 1.7 | 2.1 |
| WAR ENGINE JOBS | 0.5 | +0.0 | 39.5 | 37.1 | 0.2 | +0.0 | 3.8 | 0.0 |
| WEARS DOWN | 0.7 | +25.3 | 57.5 | 29.9 | 1.5 | +63.4 | 102.1 | 81.9 |
| WHO HITS BACK | 0.4 | +42.9 | 0.0 | 6.4 | 0.0 | +7.1 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.4 | +9.9 | 65.4 | 3.8 | 0.5 | +39.0 | 90.6 | 16.6 |
| WHOLE FIGHT GAIN | 0.2 | +16.7 | 15.0 | 0.0 | 0.7 | +79.7 | 70.3 | 10.4 |
| WIZARD FRONT RANK | - | - | - | - | 0.0 | +0.0 | 0.0 | 9.1 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |

### Rule changes: shots-h2h-opp-7c46ffc-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1084 | 1084 | 1084 | 30.11 | -57876 | -53.4 |
| BEST FIRST | 240 | 240 | 240 | 6.67 | +11591 | +48.3 |
| MOVE TO CHARGE | 336 | 336 | 182 | 5.06 | +11797 | +64.8 |
| SEARCH SPOT | 164 | 164 | 160 | 4.44 | +8438 | +52.7 |
| PATHS CROSS | 157 | 157 | 157 | 4.36 | +12128 | +77.2 |
| COUNTER-CHARGE COVER | 565 | 304 | 137 | 3.81 | +8918 | +65.1 |
| FACES THE THREAT | 121 | 121 | 121 | 3.36 | +9237 | +76.3 |
| KILLS COUNT NEXT TURN | 487 | 487 | 106 | 2.94 | +2780 | +26.2 |
| FOLLOW UP WEIGHED | 92 | 92 | 92 | 2.56 | +13619 | +148.0 |
| SUPPORTS | 269 | 269 | 88 | 2.44 | +866 | +9.8 |
| ARTILLERY RE-ROLL WEIGHED | 72 | 72 | 72 | 2.00 | +0 | +0.0 |
| SHOTS IN THE MOVE | 834 | 581 | 68 | 1.89 | +2370 | +34.9 |
| FALLBACK BY WORTH | 352 | 352 | 63 | 1.75 | +3601 | +57.2 |
| CANNON SIGHT KEPT | 57 | 57 | 57 | 1.58 | +0 | +0.0 |
| WAIT AFTER COSTS | 568 | 568 | 56 | 1.56 | +1026 | +18.3 |
| SET UP TOGETHER | 112 | 101 | 53 | 1.47 | +4236 | +79.9 |
| SAFER THAN THE JOB | 52 | 52 | 52 | 1.44 | +3263 | +62.8 |
| WALKS TO THE FIGHT | 102 | 102 | 52 | 1.44 | +919 | +17.7 |
| RESERVE FALL BACK | 51 | 51 | 51 | 1.42 | +1751 | +34.3 |
| CANNON PLANNED TARGET | 270 | 270 | 48 | 1.33 | +2 | +0.0 |
| BEST FACING | 45 | 45 | 45 | 1.25 | +1278 | +28.4 |
| REDIRECT COUNTER | 198 | 104 | 44 | 1.22 | +4652 | +105.7 |
| BEST OVERALL | 41 | 41 | 41 | 1.14 | +2804 | +68.4 |
| CHARGE NOW FIRST | 183 | 183 | 41 | 1.14 | -2121 | -51.7 |
| CHARGE NOW WEIGHED | 41 | 41 | 41 | 1.14 | +3071 | +74.9 |
| MOVE AND CAST | 41 | 41 | 41 | 1.14 | +1691 | +41.2 |
| HOLDS AMBUSHERS | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 39 | 39 | 39 | 1.08 | +2468 | +63.3 |
| MAX FOR POSITIONING | 329 | 180 | 38 | 1.06 | +615 | +16.2 |
| RANDOM MOVE BY FIGURES | 76 | 76 | 38 | 1.06 | +1118 | +29.4 |
| ADVANCE LANE KEPT | 37 | 37 | 37 | 1.03 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2259 | +68.5 |
| CAST JOB | 63 | 63 | 32 | 0.89 | +558 | +17.4 |
| COMBAT PIVOT | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| INVITES THE FIGHT | 100 | 100 | 32 | 0.89 | +694 | +21.7 |
| MARCH CHECK | 45 | 41 | 31 | 0.86 | +2892 | +93.3 |
| BLOCKED WHEEL | 30 | 30 | 30 | 0.83 | +408 | +13.6 |
| MISSILES IN THE MOVE | 280 | 161 | 30 | 0.83 | +758 | +25.3 |
| KILLS COUNT | 138 | 133 | 27 | 0.75 | +1491 | +55.2 |
| MAKE SURE TOGETHER | 65 | 53 | 27 | 0.75 | +2462 | +91.2 |
| SHOT REPLANNED | 27 | 27 | 27 | 0.75 | +0 | +0.0 |
| RISK BY ARC | 188 | 175 | 26 | 0.72 | +1141 | +43.9 |
| STAY WORTH | 459 | 370 | 26 | 0.72 | +506 | +19.5 |
| SCOUT WAITS | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| REDIRECT WEIGHED | 23 | 23 | 23 | 0.64 | +519 | +22.6 |
| MARCH ODDS | 20 | 20 | 20 | 0.56 | +266 | +13.3 |
| THROUGH LINE OF FIRE | 20 | 20 | 20 | 0.56 | +1011 | +50.6 |
| SHOOTS FROM THE BEST SPOT | 51 | 51 | 19 | 0.53 | +433 | +22.8 |
| BEST PREY | 64 | 64 | 18 | 0.50 | +1467 | +81.5 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +36 | +2.0 |
| WHOLE FIGHT GAIN | 32 | 29 | 18 | 0.50 | +825 | +45.8 |
| BEST MOVE FOR SHOOTERS | 17 | 17 | 17 | 0.47 | +2057 | +121.0 |
| FOCUS OVER TURNS | 29 | 29 | 16 | 0.44 | +174 | +10.9 |
| KEEPS ITS TARGET | 135 | 130 | 16 | 0.44 | +247 | +15.5 |
| THREAT IN THE KILL | 310 | 246 | 16 | 0.44 | +167 | +10.5 |
| BIG CHARACTER SAFETY | 14 | 14 | 14 | 0.39 | -6 | -0.4 |
| WAR ENGINE JOBS | 24 | 24 | 14 | 0.39 | -578 | -41.3 |
| WHO HITS BACK | 14 | 14 | 14 | 0.39 | +1201 | +85.8 |
| CHAFF PASSED | 12 | 12 | 12 | 0.33 | -38 | -3.1 |
| MANOEUVRE | 12 | 12 | 12 | 0.33 | +759 | +63.3 |
| FRIENDS SHOTS CHECKED | 11 | 11 | 11 | 0.31 | +880 | +80.0 |
| WEARS DOWN | 77 | 70 | 11 | 0.31 | +573 | +52.1 |
| CASTING BLOCK | 14 | 14 | 10 | 0.28 | +444 | +44.4 |
| STUCK PIVOT | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| SURE CHARGE BEATS ADVANCE | 10 | 10 | 10 | 0.28 | -274 | -27.4 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| WHOLE FIGHT | 32 | 31 | 9 | 0.25 | +699 | +77.7 |
| BLOCKED CHARGE SKIPPED | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| HUNT IN PAIRS | 36 | 17 | 7 | 0.19 | +516 | +73.7 |
| MISSILES NEXT TURN | 358 | 203 | 7 | 0.19 | +35 | +5.1 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +141 | +20.1 |
| OPENS UP | 11 | 10 | 7 | 0.19 | +517 | +73.9 |
| LONE WIZARD HOLDS BACK | 17 | 17 | 6 | 0.17 | -417 | -69.5 |
| CARRIES OUT SET-UP | 14 | 14 | 5 | 0.14 | -474 | -94.9 |
| KEEP FALLS | 5 | 5 | 5 | 0.14 | +164 | +32.9 |
| LOST CHARGE | 184 | 183 | 5 | 0.14 | +124 | +24.8 |
| NEEDED THERE | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| SUPPORT NARROWED | 416 | 416 | 5 | 0.14 | -53 | -10.6 |
| BACKUP TARGETS | 56 | 22 | 4 | 0.11 | +34 | +8.4 |
| HORN WORTH | 4 | 4 | 4 | 0.11 | +71 | +17.6 |
| JOINT CHARGE PLAN | 17 | 17 | 4 | 0.11 | +121 | +30.2 |
| PIVOT GUARDS FLANK | 4 | 4 | 4 | 0.11 | -174 | -43.4 |
| PURSUES BIG PREY | 4 | 4 | 4 | 0.11 | -107 | -26.9 |
| RAIDS THE BAGGAGE NEXT TURN | 4 | 4 | 4 | 0.11 | +131 | +32.9 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.11 | +33 | +8.2 |
| STOPS | 12 | 12 | 4 | 0.11 | +124 | +31.1 |
| BEST PRIZE | 3 | 3 | 3 | 0.08 | -315 | -104.9 |
| EDGE GIVE GROUND | 16 | 15 | 3 | 0.08 | +192 | +63.9 |
| FACE THE CAST | 3 | 3 | 3 | 0.08 | +28 | +9.2 |
| MODEL FACING | 3 | 3 | 3 | 0.08 | +460 | +153.2 |
| CHARIOT NO STATIC JOB | 3 | 3 | 2 | 0.06 | -79 | -39.5 |
| DEFENSIVE ARMY | 10 | 10 | 2 | 0.06 | -98 | -48.8 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +23 | +11.3 |
| LONG SHOT | 25 | 22 | 2 | 0.06 | +42 | +21.0 |
| MOVE SPELL IN RANGE | 10 | 9 | 2 | 0.06 | +56 | +27.8 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +79 | +39.6 |
| OVERRUNS AWAY | 30 | 27 | 2 | 0.06 | +132 | +66.2 |
| TWO OR MORE ARRIVE | 36 | 32 | 2 | 0.06 | +27 | +13.7 |
| WAR ENGINE CHARGES | 5 | 5 | 2 | 0.06 | +371 | +185.4 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +9 | +9.2 |
| CARRIES OUT COUNTER | 2 | 2 | 1 | 0.03 | -136 | -136.4 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -2 | -1.5 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| DEFENSIVE FLOOR | 2 | 2 | 1 | 0.03 | +50 | +49.8 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +2 | +2.3 |
| HUNT ADVANCE | 14 | 14 | 1 | 0.03 | +34 | +33.6 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +54 | +54.4 |
| RAIDS THE BAGGAGE | 2 | 2 | 1 | 0.03 | +144 | +143.7 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | +9 | +9.0 |
| SURE REACH TOGETHER | 38 | 27 | 1 | 0.03 | +59 | +59.4 |
| WIZARD FRONT RANK | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 32 | 32 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 34 | trace | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 7 | 7 | 0 | 0.00 | - | - |
| CHEAP HELPER | 7 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 35 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 397 | not checked | - | - | - | - |
| GIVES UP | 10 | 9 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 5 | 5 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 6 | not checked | - | - | - | - |
| HELPER UNSEEN | 18 | 17 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 22 | 22 | 0 | 0.00 | - | - |
| HUNT DROPPED | 5 | trace | - | - | - | - |
| HUNT KEPT | 14 | trace | - | - | - | - |
| HUNT RESULT | 12 | trace | - | - | - | - |
| HUNT THE GUNS | 13 | trace | - | - | - | - |
| KEEPS ITS PREY | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 31 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 6 | trace | - | - | - | - |
| MARCH OVER CASTS | 38 | 38 | 0 | 0.00 | - | - |
| MISSILES IN THE PLAN | 20 | 1 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 19 | 19 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 20 | trace | - | - | - | - |
| MOVE SPELL SPOT | 21 | not checked | - | - | - | - |
| NOT NEEDED | 14 | 14 | 0 | 0.00 | - | - |
| NOT TURNED | 393 | 393 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 49 | not checked | - | - | - | - |
| OPENS A LANE | 14 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 2665 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 28 | 28 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 23 | 23 | 0 | 0.00 | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 11 | 11 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 20 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 20 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOT OPTIONS | 916 | 916 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 25 | not checked | - | - | - | - |
| SPELL WORTH | 130 | not checked | - | - | - | - |
| STABLE ROLE | 661 | 659 | 0 | 0.00 | - | - |
| TURN WORTH | 27 | 25 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: shots-h2h-opp-7c46ffc-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.28 | 13.28 | 54.4 |
| FALLBACK | gate | 0.69 | 0.56 | 63.3 |
| CHARGE NOW FIRST | rule | 0.64 | 0.50 | 51.7 |
| TURN GATE | gate | 0.64 | 0.44 | 40.7 |
| WAR ENGINE JOBS | rule | 0.33 | 0.06 | 41.3 |
| AFTERMATH BAND | gate | 0.28 | 0.06 | 3.7 |
| LONE CHARACTER SAFE SPOT | gate | 0.19 | 0.11 | 59.2 |
| SURE CHARGE BEATS ADVANCE | rule | 0.14 | 0.14 | 27.4 |
| SUPPORT REQUEST | gate | 0.06 | 0.19 | 37.5 |
| CANNON PLANNED TARGET | rule | 0.14 | 0.08 | 57.8 |
| CHARGE NOW WEIGHED | rule | 0.08 | 0.08 | 45.4 |
| LONE WIZARD HOLDS BACK | rule | 0.06 | 0.11 | 69.5 |
| NO REASON | gate | - | 0.17 | 66.6 |
| BIG CHARACTER SAFETY | rule | 0.06 | 0.08 | 13.7 |
| CARRIES OUT SET-UP | rule | 0.11 | 0.03 | 94.9 |
| CHAFF PASSED | rule | 0.06 | 0.08 | 7.6 |
| SUPPORT NARROWED | rule | 0.11 | 0.03 | 10.6 |
| BLOCKED WHEEL | rule | 0.03 | 0.08 | 11.8 |
| PATHS CROSS | rule | 0.06 | 0.06 | 42.9 |
| PIVOT GUARDS FLANK | rule | - | 0.11 | 43.4 |
| PURSUES BIG PREY | rule | 0.06 | 0.06 | 26.9 |
| STOPS SHORT OF THE FLANK | rule | 0.06 | 0.06 | 12.9 |
| BEST PRIZE | rule | 0.06 | 0.03 | 104.9 |
| RULE SWITCHED OFF | gate | 0.08 | - | 9.5 |
| CHARIOT NO STATIC JOB | rule | 0.06 | - | 39.5 |
| DEFENSIVE ARMY | rule | - | 0.06 | 48.8 |
| FALLBACK BY WORTH | rule | 0.03 | 0.03 | 169.8 |
| FIGHT ORDER BAND | gate | 0.03 | 0.03 | 1.0 |
| FOLLOW UP WEIGHED | rule | 0.06 | - | 4.3 |
| FRIENDS SHOTS CHECKED | rule | 0.06 | - | 4.6 |
| MARCH ODDS | rule | 0.03 | 0.03 | 2.2 |
| REDIRECT WEIGHED | rule | 0.03 | 0.03 | 130.3 |
| THROUGH LINE OF FIRE | rule | 0.03 | 0.03 | 9.8 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.03 | 5.5 |
| CARRIES OUT COUNTER | rule | 0.03 | - | 136.4 |
| CATCH ODDS | rule | 0.03 | - | 1.5 |
| MOVE AND CAST | rule | - | 0.03 | 2.7 |
| SAFER THAN THE JOB | rule | - | 0.03 | 16.8 |

### Plans: shots-h2h-opp-7c46ffc-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.4 | 17% | 445 | 341 | 77% |
| Mine | charge | 3.0 | 60% | 274 | 250 | 91% |
| Mine | close in | 4.7 | 28% | 336 | 170 | 51% |
| Mine | hold | 4.2 | 31% | 244 | 0 | 0% |
| Mine | join | 0.3 | 100% | 6 | 0 | 0% |
| Mine | shoot | 8.4 | 57% | 213 | 613 | 288% |
| Mine | support | 3.9 | 91% | 36 | 0 | 0% |
| Opponent | advance | 12.4 | 16% | 343 | 355 | 103% |
| Opponent | charge | 4.4 | 58% | 441 | 406 | 92% |
| Opponent | close in | 6.8 | 27% | 651 | 244 | 37% |
| Opponent | hold | 3.9 | 25% | 300 | 0 | 0% |
| Opponent | join | 0.9 | 94% | 30 | 0 | 0% |
| Opponent | shoot | 5.4 | 56% | 308 | 329 | 107% |
| Opponent | support | 4.2 | 87% | 30 | 0 | 0% |

### Packages: hunt the guns, shots-h2h-opp-7c46ffc-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 5 | 1 | 0% | 0% | 0% | - | 488 | 0 | 0% | 38 |
| Opponent | 0.2 | 8 | 0 | 25% | 25% | 0% | 3.0 | 326 | 44 | 12% | 123 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1.2 | 5 | 1 | 0% | 0% | 0% | - | 488 | 0 | 0% | 13 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 126 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 47 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 104 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 160 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 239 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 138 |
| Tomb Kings of Khemri | 0.8 | 5 | 0 | 20% | 20% | 0% | 4.0 | 363 | 25 | 0% | 44 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 9 |
| Warriors of Chaos | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 252 | 223 | 100% | 106 |
| Wood Elf Realms | 0.3 | 2 | 0 | 0% | 0% | 0% | - | 271 | 0 | 0% | 84 |

### Battle groups: shots-h2h-opp-7c46ffc-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.6 | 23% | 43% | 12% | 50% | 31% | 14% | 14% | 41% | 0% |
| Mine | REDIRECT COUNTER | 2.0 | 33% | 79% | 17% | 75% | 40% | 5% | 0% | 55% | 0% |
| Opponent | COUNTER-CHARGE COVER | 6.1 | 19% | 71% | 17% | 29% | 32% | 6% | 12% | 50% | 0% |
| Opponent | REDIRECT COUNTER | 3.5 | 26% | 64% | 12% | 75% | 7% | 0% | 10% | 83% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: shots-h2h-opp-7c46ffc-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 34 | 49 (34) | 18 | 31 | 48 | 32% | 2.3 | 58 (21) | 0 (4) | 44 (9) | 73 (24) | 0 (10) |
| Mine | Character | 119 | 46 (119) | 46 | 0 | 39 | 18% | 2.4 | 50 (38) | 53 (54) | 35 (8) | 49 (57) | 53 (43) |
| Mine | Clean-up | 20 | 30 (20) | 6 | 24 | 50 | 45% | 2.7 | 48 (5) | 22 (13) | 21 (2) | 41 (13) | 14 (7) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 44 | 33 (44) | 19 | 14 | 33 | 23% | 3.2 | 27 (20) | 32 (18) | 55 (6) | 37 (31) | 26 (13) |
| Mine | Fragile | 3 | 0 (3) | 0 | 0 | 100 | 0% | 4.0 | 0 (3) | - | - | 0 (1) | 0 (2) |
| Mine | Hammer | 50 | 32 (50) | 21 | 11 | 48 | 10% | 2.5 | 20 (11) | 32 (35) | 59 (4) | 28 (34) | 39 (16) |
| Mine | Holder | 25 | 50 (25) | 14 | 37 | 26 | 36% | 3.9 | 102 (6) | 27 (12) | 64 (7) | 76 (13) | 23 (12) |
| Mine | Shooter | 37 | 49 (37) | 24 | 25 | 65 | 3% | 1.8 | 80 (6) | 49 (28) | 0 (3) | 43 (22) | 59 (15) |
| Mine | Support | 4 | 30 (4) | 30 | 0 | 39 | 0% | 2.8 | 12 (2) | 59 (2) | - | 38 (3) | 0 (1) |
| Mine | War machine | 52 | 68 (52) | 68 | 0 | 34 | 2% | 1.1 | 59 (13) | 60 (35) | 191 (4) | 55 (13) | 73 (39) |
| Mine | Wizard | 16 | 21 (16) | 21 | 0 | 12 | 19% | 1.8 | 22 (4) | 0 (7) | 43 (4) | 21 (11) | 22 (4) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 68 | 68 (68) | 45 | 23 | 46 | 40% | 3.1 | 102 (29) | 89 (11) | 30 (28) | 94 (48) | 7 (20) |
| Opponent | Character | 101 | 50 (101) | 50 | 0 | 31 | 21% | 2.1 | 56 (38) | 50 (51) | 17 (4) | 46 (48) | 56 (45) |
| Opponent | Clean-up | 10 | 57 (10) | 23 | 34 | 46 | 30% | 3.0 | 43 (4) | 51 (5) | 167 (1) | 54 (6) | 61 (4) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 59 | 46 (59) | 20 | 26 | 38 | 34% | 2.5 | 47 (28) | 52 (21) | 31 (10) | 79 (26) | 19 (33) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 100 | 33% | 2.0 | - | 0 (2) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Hammer | 47 | 43 (47) | 38 | 4 | 46 | 32% | 2.9 | 8 (16) | 57 (28) | 21 (3) | 65 (29) | 3 (18) |
| Opponent | Holder | 42 | 77 (42) | 10 | 67 | 35 | 36% | 2.4 | 21 (8) | 111 (24) | 48 (9) | 59 (28) | 116 (13) |
| Opponent | Shooter | 30 | 60 (30) | 40 | 19 | 53 | 3% | 1.0 | 44 (8) | 62 (20) | 115 (2) | 72 (18) | 42 (12) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 17 | 75% | 6.0 | 0 (2) | 0 (1) | 0 (1) | 0 (1) | 0 (3) |
| Opponent | War machine | 17 | 67 (17) | 67 | 0 | 17 | 6% | 1.3 | 223 (3) | 35 (10) | 51 (4) | 64 (3) | 68 (14) |
| Opponent | Wizard | 33 | 9 (33) | 9 | 0 | 34 | 24% | 1.7 | 10 (13) | 0 (7) | 16 (3) | 16 (11) | 0 (12) |

### Charged fights: shots-h2h-opp-7c46ffc-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 0 | 135 | 1.5 | 1.2 | 90 | 137 | -47 | 3 of 6 | 4 of 6 | +0 | -56 |
| Mine | Chaos Dwarfs | 4 | 163 | 384 | 3.2 | 1.0 | 118 | 7 | +111 | 8 of 13 | 10 of 13 | - | +111 |
| Mine | Dwarfen Mountain Holds | 3 | 588 | 33 | 2.0 | 1.0 | 17 | 10 | +7 | 2 of 6 | 4 of 6 | - | +7 |
| Mine | Empire of Man | 5 | 243 | 206 | 1.4 | 1.0 | 147 | 0 | +147 | 1 of 7 | 6 of 7 | - | +147 |
| Mine | Grand Cathay | 5 | 716 | 295 | 3.4 | 1.1 | 87 | 26 | +61 | 2 of 17 | 16 of 17 | -434 | +92 |
| Mine | High Elf Realms | 4 | 111 | 476 | 2.5 | 1.2 | 190 | 0 | +190 | 3 of 10 | 7 of 10 | +273 | +170 |
| Mine | Kingdom of Bretonnia | 1 | 19 | 0 | 2.0 | 1.0 | 0 | 138 | -138 | 0 of 2 | 0 of 2 | - | -138 |
| Mine | Lizardmen | 1 | 0 | 430 | 5.0 | 1.0 | 86 | 141 | -55 | 0 of 5 | 5 of 5 | - | -55 |
| Mine | Ogre Kingdoms | 1 | 116 | 170 | 4.0 | 1.0 | 42 | 58 | -16 | 1 of 4 | 3 of 4 | - | -16 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 272 | 4.0 | 1.0 | 68 | 0 | +68 | 0 of 4 | 3 of 4 | - | +68 |
| Mine | Skaven | 1 | 0 | 19 | 2.0 | 2.0 | 10 | 32 | -23 | 0 of 2 | 1 of 2 | -46 | +0 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 416 | 5.5 | 1.2 | 76 | 0 | +76 | 2 of 11 | 7 of 11 | +135 | +62 |
| Mine | Vampire Counts | 2 | 49 | 470 | 4.5 | 1.1 | 104 | 7 | +98 | 1 of 9 | 7 of 9 | +19 | +108 |
| Mine | Warriors of Chaos | 2 | 164 | 363 | 2.0 | 1.2 | 182 | 58 | +124 | 0 of 4 | 3 of 4 | -88 | +194 |
| **Mine** | all armies | 36 | 228 | 277 | 2.8 | 1.1 | 100 | 30 | +70 | 23 of 100 | 76 of 100 | +30 | +74 |
| Opponent | Empire of Man | 1 | 380 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 3 | 488 | 346 | 2.0 | 1.7 | 173 | 0 | +173 | 2 of 6 | 6 of 6 | +317 | +28 |
| Opponent | High Elf Realms | 3 | 286 | 279 | 2.7 | 1.1 | 105 | 78 | +26 | 7 of 8 | 7 of 8 | +0 | +30 |
| Opponent | Kingdom of Bretonnia | 2 | 115 | 286 | 4.0 | 1.0 | 72 | 35 | +37 | 5 of 8 | 5 of 8 | - | +37 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 561 | 5.0 | 1.0 | 112 | 0 | +112 | 1 of 5 | 5 of 5 | - | +112 |
| Opponent | Skaven | 1 | 60 | 338 | 3.0 | 1.0 | 113 | 0 | +113 | 1 of 3 | 2 of 3 | - | +113 |
| Opponent | Tomb Kings of Khemri | 4 | 120 | 376 | 3.8 | 1.1 | 100 | 78 | +22 | 9 of 15 | 8 of 15 | +0 | +24 |
| Opponent | Vampire Counts | 6 | 14 | 603 | 5.7 | 1.2 | 106 | 23 | +83 | 16 of 34 | 17 of 34 | +148 | +75 |
| Opponent | Warriors of Chaos | 9 | 0 | 535 | 3.8 | 1.1 | 142 | 32 | +109 | 16 of 34 | 23 of 34 | +321 | +96 |
| Opponent | Wood Elf Realms | 6 | 171 | 203 | 2.2 | 1.0 | 94 | 68 | +26 | 7 of 13 | 9 of 13 | - | +26 |
| **Opponent** | all armies | 36 | 127 | 403 | 3.5 | 1.1 | 115 | 38 | +77 | 64 of 126 | 82 of 126 | +199 | +65 |

### Effective charges: shots-h2h-opp-7c46ffc-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 6 | 0 | 0 | 0 | 1 (net -85) | 0 | 3 (net +152) | 2 | 0% (0 of 4) |
| Mine | Chaos Dwarfs | 13 | 1 (net +0) | 0 | 2 (net +204) | 2 (net +221) | 0 | 6 (net +72) | 2 | 18% (2 of 11) |
| Mine | Dwarfen Mountain Holds | 6 | 1 (net -60) | 1 (net +0) | 1 (net +65) | 1 (net +0) | 0 | 2 (net +18) | 0 | 17% (1 of 6) |
| Mine | Empire of Man | 7 | 1 (net +217) | 0 | 0 | 1 (net +104) | 0 | 5 (net +142) | 0 | 0% (0 of 7) |
| Mine | Grand Cathay | 17 | 0 | 0 | 2 (net +112) | 3 (net +154) | 4 (net -59) | 5 (net +65) | 3 | 14% (2 of 14) |
| Mine | High Elf Realms | 10 | 0 | 0 | 0 | 3 (net +328) | 4 (net +183) | 2 (net +93) | 1 | 0% (0 of 9) |
| Mine | Kingdom of Bretonnia | 2 | 1 (net -275) | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 2) |
| Mine | Lizardmen | 5 | 0 | 0 | 2 (net -352) | 1 (net +144) | 0 | 1 (net +170) | 1 | 50% (2 of 4) |
| Mine | Ogre Kingdoms | 4 | 0 | 0 | 1 (net +0) | 0 | 0 | 2 (net +85) | 1 | 33% (1 of 3) |
| Mine | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 0 | 0 | 2 (net +136) | 2 | 0% (0 of 2) |
| Mine | Skaven | 2 | 1 (net +0) | 0 | 0 | 1 (net -46) | 0 | 0 | 0 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 11 | 2 (net +0) | 0 | 0 | 4 (net +95) | 3 (net +103) | 2 (net +70) | 0 | 0% (0 of 11) |
| Mine | Vampire Counts | 9 | 2 (net +19) | 0 | 2 (net +126) | 1 (net +19) | 2 (net +10) | 2 (net +275) | 0 | 22% (2 of 9) |
| Mine | Warriors of Chaos | 4 | 0 | 1 (net +30) | 0 | 2 (net +178) | 0 | 1 (net +108) | 0 | 0% (0 of 4) |
| Opponent | Grand Cathay | 6 | 0 | 0 | 0 | 1 (net +952) | 3 (net +0) | 1 (net +0) | 1 | 0% (0 of 5) |
| Opponent | High Elf Realms | 8 | 1 (net +270) | 0 | 4 (net -157) | 0 | 0 | 2 (net +177) | 1 | 57% (4 of 7) |
| Opponent | Kingdom of Bretonnia | 8 | 4 (net +74) | 1 (net +0) | 0 | 1 (net +0) | 0 | 1 (net +0) | 1 | 0% (0 of 7) |
| Opponent | Orc & Goblin Tribes | 5 | 0 | 0 | 1 (net +0) | 1 (net +199) | 0 | 0 | 3 | 50% (1 of 2) |
| Opponent | Skaven | 3 | 1 (net +0) | 0 | 0 | 0 | 0 | 2 (net +169) | 0 | 0% (0 of 3) |
| Opponent | Tomb Kings of Khemri | 15 | 4 (net +20) | 0 | 1 (net -511) | 3 (net +76) | 0 | 6 (net +48) | 1 | 7% (1 of 14) |
| Opponent | Vampire Counts | 34 | 8 (net +65) | 2 (net +246) | 5 (net +11) | 9 (net +64) | 4 (net +89) | 6 (net +139) | 0 | 15% (5 of 34) |
| Opponent | Warriors of Chaos | 34 | 9 (net +67) | 2 (net +268) | 2 (net -164) | 3 (net +171) | 1 (net +135) | 12 (net +118) | 5 | 7% (2 of 29) |
| Opponent | Wood Elf Realms | 13 | 1 (net -104) | 0 | 0 | 1 (net +0) | 0 | 4 (net +1) | 7 | 0% (0 of 6) |

### Charged fights, damage counted: shots-h2h-opp-7c46ffc-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 9 | 181 | 222 | -9 | 46 | 69 | -23 | -12.9 |
| Mine | 50-54% | 2 | 53 | 67 | +15 | 54 | 14 | +40 | +75.0 |
| Mine | Effective (55-75%) | 10 | 257 | 221 | +25 | 118 | 97 | +21 | +8.3 |
| Mine | 76-89% | 20 | 312 | 163 | +138 | 182 | 40 | +143 | +45.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 34 | 203 | 169 | +104 | 130 | 22 | +108 | +52.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 13 | 445 | 87 | +63 | 97 | 37 | +60 | +13.4 |
| Mine | No odds | 12 | 314 | 178 | -29 | 71 | 112 | -41 | -13.1 |
| Mine | All fights | 100 | 270 | 166 | +70 | 119 | 50 | +69 | +25.4 |
| Opponent | Long shot (under 50%) | 28 | 225 | 272 | +60 | 105 | 67 | +38 | +16.7 |
| Opponent | 50-54% | 5 | 393 | 416 | +206 | 284 | 76 | +208 | +52.8 |
| Opponent | Effective (55-75%) | 13 | 253 | 285 | -109 | 64 | 190 | -126 | -50.0 |
| Opponent | 76-89% | 19 | 278 | 245 | +130 | 146 | 8 | +138 | +49.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 34 | 311 | 228 | +95 | 157 | 44 | +113 | +36.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 561 | 94 | +62 | 66 | 19 | +47 | +8.4 |
| Opponent | No odds | 19 | 204 | 181 | +114 | 166 | 48 | +117 | +57.5 |
| Opponent | All fights | 126 | 284 | 238 | +77 | 135 | 59 | +75 | +26.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| shots-h2h-opp-7c46ffc-p3 | move | 458 | 84 (18%) | 64 (14%) | 61 (13%) | 313 (68%) |
| shots-h2h-opp-7c46ffc-p3 | objective | 416 | 67 (16%) | 50 (12%) | 55 (13%) | 294 (71%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

# Doctrine scorecard: shots-h2h-mine-7c46ffc-p3

### Scorecard: shots-h2h-mine-7c46ffc-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 9 | 6 | 1 | 0 | 0 | 0 | 0 | 322 |
| L0126 | 6 | 1 | Opponent | no | 8 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 2 | - | 0 | 4 | 1 | 0 | 0 | 30 |
| L0210 | 6 | 1 | Opponent | no | 10 | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | no | 1 | 3 | 1 | 0 | 1 | 0 | 0 | 523 |
| L0226 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | no | - | 6 | 0 | 1 | 0 | 0 | 0 | 590 |
| L0311 | 5 | 1 | Opponent | yes | - | - | 0 | 1 | 1 | 0 | 0 | 427 |
| L0327 | 3 | 1 | Mine | no | 1 | 6 | 1 | 0 | 0 | 0 | 0 | 685 |
| L0327 | 3 | 1 | Opponent | no | 7 | 2 | 2 | 3 | 1 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | yes | - | 2 | 2 | 0 | 0 | 0 | 0 | 479 |
| L0429 | 3 | 1 | Mine | yes | 5 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 881 |
| L0516 | 6 | 1 | Opponent | no | 6 | 2 | 4 | 0 | 1 | 0 | 0 | 200 |
| L0533 | 5 | 1 | Mine | no | - | 4 | 0 | 0 | 0 | 0 | 0 | 1120 |
| L0533 | 5 | 1 | Opponent | yes | - | 2 | 1 | 4 | 1 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | 5 | 2 | 0 | 0 | 0 | 0 | 615 |
| L0620 | 2 | 1 | Opponent | - | - | - | 1 | 4 | 2 | 0 | 0 | 210 |
| L0709 | 1 | 1 | Mine | yes | 2 | 2 | 5 | 0 | 0 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 641 |
| L0725 | 5 | 1 | Mine | no | - | 3 | 2 | 1 | 0 | 0 | 0 | 375 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 515 |
| L0815 | 5 | 1 | Opponent | yes | - | 2 | 5 | 2 | 1 | 0 | 0 | 115 |
| L0831 | 3 | 1 | Mine | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 762 |
| L0831 | 3 | 1 | Opponent | no | 2 | 6 | 2 | 1 | 0 | 0 | 0 | 340 |
| L0922 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 781 |
| L0922 | 4 | 1 | Opponent | no | 0 | 2 | 6 | 2 | 0 | 0 | 0 | 55 |
| L1013 | 5 | 1 | Mine | yes | - | 3 | 5 | 0 | 0 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | yes | - | 1 | 4 | 1 | 2 | 0 | 0 | 140 |
| L1030 | 4 | 1 | Mine | no | 0 | 2 | 1 | 0 | 0 | 0 | 0 | 501 |
| L1030 | 4 | 1 | Opponent | no | 1 | 3 | 1 | 1 | 1 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 4 | 2 | 6 | 0 | 0 | 0 | 0 | 425 |
| L1122 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 199 |
| L1216 | 4 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1216 | 4 | 1 | Opponent | no | 2 | 2 | 2 | 2 | 0 | 0 | 0 | 200 |
| L1232 | 2 | 1 | Mine | - | - | 3 | 3 | 0 | 1 | 0 | 0 | 503 |
| L1232 | 2 | 1 | Opponent | - | - | 3 | 3 | 1 | 0 | 0 | 0 | 340 |
| L1327 | 1 | 1 | Mine | no | 9 | 3 | 2 | 0 | 0 | 0 | 0 | 317 |
| L1327 | 1 | 1 | Opponent | no | 2 | 1 | 5 | 3 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Mine | no | 5 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 3 | 2 | 5 | 0 | 1 | 0 | 0 | 297 |
| L1519 | 1 | 1 | Mine | no | 3 | 2 | 5 | 1 | 0 | 0 | 0 | 199 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 104 |
| L1535 | 5 | 1 | Mine | yes | - | 3 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 2 | 6 | 3 | 0 | 0 | 0 | 251 |
| L1633 | 1 | 1 | Mine | yes | 6 | 2 | 4 | 1 | 1 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 0 | 1 | 4 | 2 | 0 | 0 | 0 | 893 |
| L1731 | 3 | 1 | Mine | no | 1 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Opponent | no | 2 | 2 | 2 | 0 | 4 | 0 | 0 | 340 |
| L1831 | 1 | 1 | Mine | no | 3 | 3 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 4 | 2 | 5 | 1 | 0 | 0 | 0 | 170 |
| L1932 | 6 | 1 | Mine | no | 2 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1932 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 170 |
| L2033 | 5 | 1 | Mine | yes | - | - | 0 | 3 | 1 | 0 | 0 | 617 |
| L2033 | 5 | 1 | Opponent | yes | - | 5 | 1 | 1 | 0 | 0 | 0 | 0 |
| L2223 | 3 | 1 | Mine | no | 1 | 1 | 7 | 0 | 0 | 0 | 0 | 55 |
| L2223 | 3 | 1 | Opponent | no | 3 | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 3 | 0 | 0 | 0 | 0 | 160 |
| L2327 | 5 | 1 | Opponent | yes | - | 2 | 6 | 2 | 1 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Mine | no | 0 | 4 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 0 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Mine | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Opponent | no | 5 | 1 | 5 | 2 | 0 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Mine | no | 5 | 3 | 3 | 1 | 2 | 0 | 0 | 170 |
| L3133 | 1 | 1 | Opponent | no | 4 | 4 | 2 | 2 | 0 | 0 | 0 | 144 |
| **Average** | | | Mine | 25% | 2.7 | 2.9 | 2.4 | 0.7 | 0.2 | 0.0 | 0.0 | 317.4 |
| **Average** | | | Opponent | 28% | 2.6 | 2.2 | 3.3 | 1.4 | 0.5 | 0.0 | 0.0 | 186.5 |

### KPIs: shots-h2h-mine-7c46ffc-p3

Rules off - Opponent only: STAY WORTH, BEST MOVE FOR SHOOTERS, THREAT IN THE KILL, FOCUS OVER TURNS, MISSILES IN THE PLAN, FACE THE CAST, WIZARD FRONT RANK.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 23% (40 of 177) | 13% (22 of 172) | 18% (62 of 349) |
| Winner chose to follow up after the loser gave ground |  | 96% (66 of 69); on the table 96% | 100% (54 of 54); on the table 100% | 98% (120 of 123); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 90% (9 of 10); on the table 90% | 89% (16 of 18); on the table 89% | 89% (25 of 28); on the table 89% |
| Winner chose to pursue after the loser fled |  | 70% (19 of 27); on the table 70% | 64% (32 of 50); on the table 70% | 66% (51 of 77); on the table 70% |
| Winner chose to follow up or pursue (all three) |  | 89% (94 of 106); on the table 89% | 84% (102 of 122); on the table 86% | 86% (196 of 228); on the table 87% |
| Magic missiles tried each own turn | 50%+ | 27% (92 of 342) | 36% (69 of 192) | 30% (161 of 534) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 43% (92 of 215) | 48% (69 of 143) | 45% (161 of 358) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 22% (43 of 192) | 33% (46 of 138) | 27% (89 of 330) |
|     round 1 |  | 16% (5 of 32) | 35% (8 of 23) | 24% (13 of 55) |
|     rounds 2+ |  | 24% (38 of 160) | 33% (38 of 115) | 28% (76 of 275) |
|   other wizards | 50%+ | 33% (49 of 150) | 43% (23 of 54) | 35% (72 of 204) |
|     round 1 |  | 48% (12 of 25) | 11% (1 of 9) | 38% (13 of 34) |
|     rounds 2+ |  | 30% (37 of 125) | 49% (22 of 45) | 35% (59 of 170) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 32% (7 of 22) | 38% (23 of 61) | 36% (30 of 83) |
| Points that never fought | lower | 32% (22239 of 68801) | 36% (26166 of 71990) | 34% (48405 of 140791) |
|   infantry points that never fought | lower | 38% (5441 of 14174) | 53% (7488 of 14220) | 46% (12929 of 28394) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 58% (158 of 272) | 61% (173 of 285) | 59% (331 of 557) |
| Bound items with a magic missile used (at least once a game) |  | 100% (25 of 25); 1.7 uses a game | 92% (22 of 24); 2.2 uses a game | 96% (47 of 49); 1.9 uses a game |
| Bound items with another spell used |  | 29% (4 of 14); 0.1 uses a game | 67% (4 of 6); 0.1 uses a game | 40% (8 of 20); 0.1 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (10 of 20); 0.3 uses a game | 50% (7 of 14); 0.2 uses a game | 50% (17 of 34); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 51% (30454 of 59391) | 53% (34247 of 64043) | 52% (64701 of 123434) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.2 (18%) | 0.9 (28%) | 2.2 (21%) |
| MARCHED: its unit marched | 1.6 (22%) | 1.0 (28%) | 2.5 (24%) |
| CHARGED: its unit charged | 0.3 (4%) | 0.0 (1%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.9 (27%) | 1.0 (28%) | 2.9 (28%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.1 (3%) | 0.2 (2%) |
| GONE: slain | 1.4 (20%) | 0.3 (10%) | 1.7 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (4%) | 0.1 (2%) | 0.3 (3%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.9 | 1.2 | 2.1 | 4.5 | 0.8 | 2.3 |
| not cast | 3.9 | 1.4 | 4.1 | 10.4 | 2.5 | 18.4 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.4 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 0.7 (48%) | 0.4 (10%) | 2.2 (21%) | 0.2 (8%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.5 (24%) | 0.6 (22%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.1 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (7%) | 0.1 (8%) | 0.8 (20%) | 2.9 (28%) | 0.7 (29%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.0 (0%) | 0.3 (7%) | 0.2 (2%) | 0.1 (4%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.4 (2%) |
| GONE: slain | 0.8 (21%) | 0.2 (13%) | 0.7 (16%) | 1.7 (17%) | 0.2 (10%) | 1.6 (9%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (6%) | 0.2 (12%) | 0.5 (12%) | 0.3 (3%) | 0.1 (6%) | 0.9 (5%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.1 (6%) | 0.1 (1%) | 0.1 (1%) | 0.4 (16%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.2 (57%) | 0.2 (13%) | 1.3 (32%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.0 (76%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.4 a game | 0.7 a game | 1.1 a game |
| stood (cast and not dispelled) | 74% (29 of 39) | 58% (11 of 19) | 69% (40 of 58) |
| the unit moved after it | 83% (24 of 29) | 91% (10 of 11) | 85% (34 of 40) |
| it charged on its next turn | 3% (1 of 29) | 9% (1 of 11) | 5% (2 of 40) |
| the enemy charged it first | 21% (6 of 29) | 18% (2 of 11) | 20% (8 of 40) |
| it fought by the end of its next turn | 7% (2 of 29) | 9% (1 of 11) | 8% (3 of 40) |
| it moved out of a charge the enemy had planned (not charged first) | 24% (7 of 29) | 36% (4 of 11) | 28% (11 of 40) |
| none of these (no charge, no fight, no charge escaped) | 52% (15 of 29) | 36% (4 of 11) | 48% (19 of 40) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (506 of 764) | 61% (362 of 598) | 64% (868 of 1362) |
|   cavalry | 69% (41 of 59) | 64% (64 of 100) | 66% (105 of 159) |
|   character | 57% (57 of 100) | 24% (28 of 118) | 39% (85 of 218) |
|   chariot | 52% (44 of 85) | 78% (29 of 37) | 60% (73 of 122) |
|   infantry | 56% (120 of 214) | 66% (166 of 251) | 62% (286 of 465) |
|   monster | 43% (15 of 35) | 100% (1 of 1) | 44% (16 of 36) |
|   war machine | 85% (229 of 271) | 81% (74 of 91) | 84% (303 of 362) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.8 (25%) | 1.4 (22%) | 3.2 (24%) |
| CHARGED: it charged | 0.9 (12%) | 1.7 (26%) | 2.6 (19%) |
| FLEEING: it fled or was fleeing | 0.2 (3%) | 0.1 (1%) | 0.2 (2%) |
| IN COMBAT: it fought this turn or the last | 0.8 (12%) | 0.7 (11%) | 1.5 (11%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.1 (1%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.0 (14%) | 0.9 (14%) | 1.9 (14%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (5%) | 0.4 (6%) | 0.8 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (19%) | 0.9 (14%) | 2.3 (17%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.1 (2%) | 0.3 (2%) |
| OTHER BAR | 0.5 (7%) | 0.2 (3%) | 0.7 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.6 | 1.0 | 80% | 6.8 pts | 32 pts |
| character | 3.0 | 0.9 | 80% | 5.8 pts | 18 pts |
| chariot | 2.0 | 0.7 | 78% | 10.2 pts | 21 pts |
| infantry | 12.4 | 3.8 | 78% | 8.1 pts | 101 pts |
| monster | 0.5 | 0.1 | 89% | 4.8 pts | 2 pts |
| war machine | 8.7 | 6.6 | 63% | 21.4 pts | 186 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.9 | 6.5 | 5.2 |
| Charges that made contact a game | 2.9 | 4.3 | 3.6 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.09 declared, 0.83 contact (23 units) | 0.90 declared, 0.80 contact (20 units) | 1.00 declared, 0.81 contact (43 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 1.00 contact (4 units) | 1.38 declared, 0.88 contact (8 units) | 1.25 declared, 0.92 contact (12 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.49 declared, 0.37 contact (224 units) | 0.76 declared, 0.50 contact (267 units) | 0.64 declared, 0.44 contact (491 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 52% (40 of 77) | 47% (7 of 15) | 40% (4 of 10) | 50% (51 of 102) |
| Character in a unit | 90% (28 of 31) | 83% (10 of 12) | 40% (2 of 5) | 83% (40 of 48) |
| Character on its own | 91% (42 of 46) | 48% (21 of 44) | 27% (19 of 70) | 51% (82 of 160) |
| Chariot | 82% (9 of 11) | 75% (9 of 12) | - | 78% (18 of 23) |
| Infantry | 69% (48 of 70) | 45% (19 of 42) | 40% (2 of 5) | 59% (69 of 117) |
| Monster | 65% (22 of 34) | 29% (2 of 7) | - | 59% (24 of 41) |
| Monstrous | 80% (8 of 10) | 64% (7 of 11) | - | 71% (15 of 21) |
| War Machines | 70% (30 of 43) | 100% (2 of 2) | - | 71% (32 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (15 of 15); on the table 100% | 27% (26 of 96) | 18% | 77% (17 of 22) | 100% (6 of 6); 2.8 uses a game | 50% (1 of 2); 0.2 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 80% (8 of 10); on the table 80% | 56% (20 of 36) | 41% | 66% (21 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 33% (1 of 3); on the table 33% | - | 53% | 67% (16 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 89% (8 of 9); on the table 89% | 40% (12 of 30) | 51% | 71% (42 of 59) | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 4); 0.0 uses a game |
| Grand Cathay | 8 | 95% (20 of 21); on the table 95% | 26% (49 of 192) | 43% | 53% (39 of 74) | 94% (17 of 18); 5.6 uses a game | 25% (1 of 4); 0.1 uses a game | 50% (4 of 8); 0.5 uses a game |
| High Elf Realms | 7 | 70% (16 of 23); on the table 70% | 36% (15 of 42) | 20% | 52% (28 of 54) | 100% (9 of 9); 4.0 uses a game | 50% (6 of 12); 1.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 100% (10 of 10); on the table 100% | - | 32% | 28% (5 of 18) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Lizardmen | 1 | 80% (4 of 5); on the table 80% | 33% (2 of 6) | 34% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (5 of 5); on the table 100% | 0% (0 of 6) | 6% | 57% (4 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 86% (6 of 7); on the table 100% | 33% (4 of 12) | 2% | 75% (12 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Skaven | 2 | 80% (4 of 5); on the table 80% | 8% (1 of 12) | 72% | 57% (8 of 14) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Tomb Kings of Khemri | 6 | 85% (17 of 20); on the table 85% | 0% (0 of 6) | 35% | 54% (14 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 100% (36 of 36); on the table 100% | 30% (16 of 54) | 26% | 57% (26 of 46) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 11 | 76% (34 of 45); on the table 80% | 43% (13 of 30) | 29% | 52% (50 of 96) | 100% (4 of 4); 1.4 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 6 | 86% (12 of 14); on the table 86% | 25% (3 of 12) | 45% | 74% (46 of 62) | 91% (10 of 11); 5.8 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (shots-h2h-mine-7c46ffc-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 42% (40) | 46% (34) | 44% (74) |
| ...free all their last turn and able to turn (per game) | 0.56 | 0.56 | 1.11 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.19 | 0.25 | 0.44 |
| ...with the charger already in that arc before they moved (per game) | 0.42 | 0.36 | 0.78 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.53 | 1.47 | 3.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.64 | 0.81 | 1.44 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.39 | 4.64 | 10.03 |

### Quality by phase: shots-h2h-mine-7c46ffc-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.2 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 58% (71 of 123) | 40% (84 of 210) |
| Strategy | Shoot objectives carried out (shot that target) | 49% (170 of 349) | 50% (112 of 226) |
| Strategy | Close-in objectives charged next turn | 15% (25 of 167) | 24% (49 of 206) |
| Strategy | Support requests answered (helper made contact too) | 50% (6 of 12) | 31% (9 of 29) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (4 of 4) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 58% (7 of 12) | 67% (4 of 6) |
| Strategy | Joined characters whose unit fought | 49% (18 of 37) | 24% (9 of 37) |
| Strategy | Lone characters that fought | 76% (74 of 98) | 79% (77 of 97) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 0.7 | 1.4 |
| Movement | Points that never moved of their own | 317.4 | 186.5 |
| Movement | Fights charged into per game | 2.9 | 3.6 |
| Movement | Charges with odds: long shots (under 50%) | 10 of 89, net +87 | 24 of 112, net +66 |
| Movement | Charges with odds: sweet spot (55-75%) | 13 of 89, net +77 | 14 of 112, net +101 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 10 of 89, net +72 | 10 of 112, net +42 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 32 of 89, net +118 | 37 of 112, net +161 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.3 | 9.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 47% (140 of 299) | 40% (139 of 346) |
| Shooting | Points destroyed by shooting units | 55.6 | 44.8 |
| Shooting | War machine shots | 6.4 | 2.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 56% (128 of 229) | 42% (36 of 85) |
| Shooting | Points destroyed by war machines | 51.1 | 9.1 |
| Magic | Magic missiles cast | 1.6 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 54% (31 of 57) | 44% (20 of 45) |
| Magic | Wounds caused by magic missiles | 3.2 | 1.5 |
| Magic | Wounds caused by other spells | 2.1 | 0.9 |
| Magic | Points destroyed by magic (all spells) | 77.6 | 33.2 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.4 / 0.3 / 1.0 / 0.1 | 1.9 / 0.2 / 0.4 / 0.6 |
| Combat | Points destroyed in combat | 379.2 | 391.4 |
| Combat | Points run down | 52.3 | 118.8 |
| Combat | Net points per charged fight, damage counted | +100 | +108 |
| Combat | Net per 100 charger points, damage counted | +35.4 | +35.5 |
| Combat | First round won (charged fights) | 74% | 63% |
| Combat | Net points per charged fight | +90 | +93 |
| Combat | Net points per supported fight / lone fight | +106 / +89 | +156 / +84 |
| Combat | Charged fights on a top-3 enemy unit | 27 of 103 | 60 of 130 |
| Game | Points lost | 767.2 | 683.6 |
| Game | VP from objectives | 481.7 | 538.3 |
| Game | Lone holders (player turns) | 2.7 | 2.6 |

- Mine won / drew / lost: 12 / 8 / 16 of 36 ended games (of 36); mean margin (Mine - Opponent) -201 VP
- The side that went first won 11 of 28 games with a winner
- Points traded per game (both sides' losses): 1451
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: shots-h2h-mine-7c46ffc-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +0.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.8 | +0.0 | 0.0 | 30.0 | 0.2 | +0.0 | 0.0 | 3.5 |
| BACKUP TARGETS | 0.7 | +6.0 | 0.0 | 24.7 | 0.8 | +8.5 | 0.0 | 10.8 |
| BEST FACING | 0.5 | +25.3 | 0.0 | 9.1 | 0.6 | +35.4 | 0.0 | 17.9 |
| BEST FIRST | 3.9 | +146.8 | 111.8 | 62.7 | 3.2 | +156.5 | 75.2 | 21.4 |
| BEST MOVE FOR SHOOTERS | 1.0 | +74.8 | 0.0 | 34.7 | - | - | - | - |
| BEST OVERALL | 0.5 | +32.9 | 0.0 | 11.0 | 0.5 | +31.7 | 0.0 | 22.8 |
| BEST PREY | 0.7 | +61.7 | 47.9 | 13.5 | 1.0 | +71.5 | 51.8 | 6.7 |
| BEST PRIZE | 0.1 | +0.9 | 2.9 | 0.0 | 0.0 | -2.1 | 0.0 | 3.2 |
| BIG CHARACTER SAFETY | 0.1 | -1.1 | 0.0 | 0.0 | 0.3 | +0.5 | 0.0 | 26.1 |
| BLOCKED CHARGE SKIPPED | - | - | - | - | 0.0 | +0.0 | 0.0 | 1.4 |
| BLOCKED WHEEL | 0.4 | +11.0 | 0.0 | 0.0 | 0.4 | +8.1 | 0.0 | 0.0 |
| BOMBING RUN | 0.0 | +0.3 | 1.5 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 3.4 | - | - | - | - |
| CANNON PLAN MISSED | 0.8 | +0.0 | 91.4 | 25.1 | 0.2 | +0.0 | 11.3 | 1.9 |
| CANNON PLANNED TARGET | 5.2 | +152.8 | 397.9 | 72.2 | 1.6 | +68.3 | 42.7 | 21.9 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | - | - | - | - | 0.1 | -4.5 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.2 | -13.2 | 11.8 | 0.0 | 0.1 | -2.5 | 10.1 | 3.2 |
| CAST JOB | 0.8 | +27.1 | 48.7 | 7.6 | 1.0 | +22.4 | 25.6 | 6.5 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.2 | +18.4 | 4.6 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.9 | +0.0 | 0.0 | 19.7 | 0.4 | +0.0 | 0.0 | 17.6 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.2 | -0.3 | 0.0 | 1.8 | 0.1 | +0.0 | 0.0 | 2.2 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 178.8 | 54.1 | 3.4 | +0.0 | 303.8 | 53.7 |
| CHARGE NOW WEIGHED | 0.4 | -29.8 | 18.1 | 1.1 | 0.4 | -20.0 | 17.4 | 2.4 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 0.0 | 4.7 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.0 | -0.2 | 0.0 | 0.0 | 0.1 | -0.1 | 0.0 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 7.9 | 3.2 | 0.2 | +0.0 | 14.6 | 3.3 |
| COMBAT PIVOT | 0.4 | +0.0 | 6.1 | 21.7 | 0.6 | +0.0 | 49.9 | 12.1 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 10.5 | - | - | - | - |
| CONVEYANCE SEARCH | 0.8 | +84.6 | 0.0 | 2.6 | 0.4 | +29.3 | 0.0 | 6.5 |
| COUNTER-CHARGE COVER | 9.2 | +750.0 | 0.0 | 155.9 | 7.4 | +688.9 | 0.0 | 152.1 |
| DEFENSIVE ARMY | 0.1 | +0.0 | 25.3 | 0.0 | 0.1 | +0.0 | 3.0 | 0.0 |
| DEFENSIVE FLOOR | 0.1 | +4.4 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 1.8 |
| EDGE GIVE GROUND | 0.2 | +9.0 | 18.0 | 1.7 | 0.2 | +2.2 | 30.3 | 0.0 |
| ELIXIR WORTH | 0.0 | +0.1 | 0.0 | 9.7 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACE THE CAST | 0.1 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.5 | +122.6 | 0.0 | 33.2 | 1.5 | +120.6 | 0.0 | 41.6 |
| FALLBACK BY WORTH | 4.7 | +49.4 | 0.0 | 66.0 | 5.4 | +68.8 | 0.0 | 32.8 |
| FIGHT LIFT | 0.1 | +0.2 | 7.7 | 0.0 | 0.0 | +0.3 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.1 | +7.7 | 2.9 | 6.8 | 0.0 | +0.2 | 0.0 | 4.4 |
| FLANK NOT WEIGHED | 5.2 | +0.0 | 0.0 | 150.8 | 4.4 | +0.0 | 0.0 | 107.2 |
| FOCUS FIRE | 0.0 | +0.3 | 0.0 | 3.5 | 0.0 | +0.9 | 1.2 | 0.0 |
| FOCUS OVER TURNS | 1.8 | +34.2 | 68.4 | 31.6 | - | - | - | - |
| FOLLOW UP WEIGHED | 1.5 | +220.1 | 0.0 | 53.9 | 1.3 | +228.2 | 0.0 | 23.8 |
| FRIENDS SHOTS CHECKED | 0.2 | +5.5 | 0.0 | 7.7 | 0.1 | +2.3 | 0.0 | 0.0 |
| GIVES UP | 0.1 | -1.3 | 25.9 | 0.0 | 0.1 | -3.0 | 0.0 | 9.1 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -0.4 | 15.1 | 0.5 |
| HELPER ALREADY ASKED | - | - | - | - | 0.0 | +0.0 | 4.2 | 1.5 |
| HELPER UNSEEN | 0.3 | +0.0 | 2.1 | 0.0 | 0.4 | +0.0 | 34.6 | 12.9 |
| HILL BY ITS CHANCE | 0.2 | -29.7 | 0.0 | 1.8 | 0.4 | -44.5 | 0.0 | 14.1 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.1 | +0.8 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +4.0 | 0.0 | 1.4 | 0.2 | +9.5 | 8.1 | 4.9 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 6.9 | 0.0 |
| HUNT IN PAIRS | 0.2 | +8.4 | 0.0 | 5.4 | 0.8 | +61.8 | 0.0 | 10.8 |
| HUNT KEPT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +5.6 | 4.6 | 4.9 |
| HUNT RESULT | 0.1 | +0.0 | 0.0 | 1.5 | 0.2 | +10.0 | 11.5 | 6.4 |
| HUNT THE GUNS | 0.1 | +49.4 | 0.0 | 3.0 | 0.2 | +53.3 | 6.9 | 0.0 |
| INVITES THE FIGHT | 1.2 | +27.6 | 48.9 | 16.2 | 1.3 | +24.3 | 40.4 | 5.4 |
| JOINT CHARGE PLAN | 0.1 | +13.8 | 4.8 | 3.8 | 0.2 | +3.0 | 4.9 | 6.4 |
| KEEP FALLS | 0.1 | +1.3 | 0.0 | 6.1 | 0.1 | +1.7 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS TARGET | 1.7 | +51.7 | 124.4 | 16.4 | 2.5 | +74.2 | 242.6 | 51.1 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.5 | +66.3 | 90.6 | 34.2 | 2.2 | +105.4 | 195.2 | 27.3 |
| KILLS COUNT NEXT TURN | 5.5 | +210.2 | 243.0 | 90.1 | 7.4 | +237.2 | 284.1 | 154.8 |
| LONE CHARACTER SAFE SPOT | 0.5 | +16.5 | 5.0 | 0.0 | 0.2 | +3.7 | 6.4 | 6.5 |
| LONE WIZARD HOLDS BACK | 0.2 | +0.0 | 7.1 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.6 | +37.3 | 0.0 | 0.0 | 0.4 | +25.4 | 0.0 | 0.0 |
| LONG SHOT | 0.2 | +2.6 | 2.2 | 1.7 | 0.5 | -5.4 | 13.5 | 13.0 |
| LOST CHARGE | 3.2 | -63.6 | 132.8 | 89.5 | 2.3 | -30.4 | 81.1 | 47.3 |
| LURE BY WHAT IT DRAWS | 0.0 | -11.5 | 0.0 | 1.0 | 0.0 | -2.9 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.8 | +73.4 | 48.6 | 4.5 | 0.9 | +53.9 | 37.2 | 17.9 |
| MANOEUVRE | 0.2 | +12.1 | 0.0 | 0.0 | 0.1 | +3.3 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +1.3 | 0.0 | 7.2 | 0.1 | +0.3 | 0.0 | 0.0 |
| MARCH CHECK | 0.6 | +53.6 | 0.0 | 6.9 | 0.5 | +41.0 | 0.0 | 3.2 |
| MARCH ODDS | 0.5 | +23.9 | 19.8 | 4.8 | 0.2 | +9.2 | 9.5 | 0.0 |
| MARCH OVER CASTS | 0.7 | +68.6 | 0.0 | 9.9 | 0.5 | +33.8 | 0.0 | 46.7 |
| MAX FOR POSITIONING | 4.7 | +155.7 | 0.0 | 103.4 | 5.1 | +241.7 | 0.0 | 102.8 |
| MISSILES IN THE MOVE | 3.8 | +158.0 | 0.0 | 103.1 | 4.2 | +79.8 | 0.0 | 79.5 |
| MISSILES IN THE PLAN | 0.6 | +9.1 | 28.2 | 3.6 | - | - | - | - |
| MISSILES NEXT TURN | 5.1 | +114.3 | 0.0 | 131.1 | 5.1 | +57.4 | 0.0 | 126.1 |
| MODEL FACING | 0.1 | +27.8 | 0.0 | 3.3 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.4 | +0.0 | 24.1 | 10.2 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE AND CAST | 0.5 | +38.0 | 0.0 | 29.4 | 0.5 | +19.7 | 0.0 | 5.8 |
| MOVE SPELL IN RANGE | 0.2 | +6.7 | 0.0 | 0.0 | 0.1 | +2.3 | 0.0 | 6.5 |
| MOVE SPELL OUT OF RANGE | 0.5 | -16.2 | 0.0 | 41.1 | 0.1 | -1.2 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.6 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 11.1 |
| MOVE TO CHARGE | 3.4 | +231.9 | 151.3 | 57.3 | 4.7 | +375.5 | 229.3 | 107.6 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| NO RALLY LEFT | - | - | - | - | 0.1 | -1.3 | 0.0 | 0.0 |
| NOT NEEDED | 0.1 | -2.7 | 5.1 | 0.0 | 0.4 | -28.6 | 58.9 | 8.0 |
| NOT TURNED | 5.4 | +73.4 | 0.0 | 145.6 | 4.6 | +22.4 | 0.0 | 95.4 |
| NOT WORTH A CAST | 0.7 | -0.4 | 0.0 | 9.9 | 0.9 | -0.9 | 0.0 | 6.5 |
| OFF BEST | 14.4 | -752.6 | 7.9 | 258.4 | 13.1 | -822.6 | 8.9 | 247.2 |
| OPENS A LANE | 0.2 | +1.2 | 34.6 | 4.6 | 0.5 | +5.5 | 22.2 | 17.4 |
| OPENS UP | 0.2 | +27.2 | 11.6 | 0.0 | 0.3 | +32.1 | 15.0 | 0.0 |
| OVERRUN THREAT | - | - | - | - | 0.0 | +0.6 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.5 | +15.9 | 35.8 | 12.3 | 0.7 | +24.2 | 37.9 | 17.0 |
| PATHS CROSS | 1.8 | +96.8 | 0.0 | 29.0 | 2.3 | +186.4 | 0.0 | 38.6 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +1.5 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.0 | -0.5 | 0.0 | 0.0 | 0.2 | -3.1 | 0.0 | 1.9 |
| PLAN RESULT | 36.1 | +1368.2 | 1333.2 | 970.9 | 37.7 | +1311.2 | 1665.0 | 861.1 |
| PURSUES BIG PREY | 0.1 | -5.1 | 0.0 | 0.0 | 0.1 | -3.8 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.1 | +11.5 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +4.9 | 0.0 | 0.0 | 0.1 | +3.5 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.6 | +6.2 | 0.0 | 20.0 | 1.7 | +13.6 | 0.0 | 48.3 |
| RANDOM MOVER NO PROMISE | 0.1 | -7.9 | 0.0 | 4.7 | 0.8 | -50.4 | 9.2 | 9.4 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -6.6 | 0.0 | 0.0 | 0.5 | -20.7 | 0.0 | 3.2 |
| REDIRECT COUNTER | 2.1 | +131.0 | 0.0 | 47.9 | 3.5 | +301.4 | 0.0 | 61.9 |
| REDIRECT WEIGHED | 0.2 | +13.6 | 12.2 | 1.7 | 0.2 | +4.9 | 4.9 | 0.0 |
| RESERVE FALL BACK | 0.4 | +8.8 | 0.0 | 1.8 | 0.8 | +28.0 | 0.0 | 10.4 |
| RESTRAINS TO SHOOT | 0.1 | +2.8 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.2 | +67.8 | 174.0 | 40.7 | 3.2 | +53.7 | 297.1 | 71.7 |
| SAFER THAN THE JOB | 0.6 | +38.1 | 0.0 | 17.5 | 0.8 | +55.3 | 0.0 | 16.4 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.9 | 0.3 | +0.8 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.9 | 0.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -0.8 | 0.0 | 0.9 | 0.2 | -15.8 | 0.0 | 0.0 |
| SEARCH SPOT | 3.2 | +138.5 | 0.0 | 55.5 | 2.1 | +99.2 | 0.0 | 23.0 |
| SECOND HUNTER | 0.0 | -1.2 | 0.0 | 0.0 | 0.0 | -0.2 | 0.0 | 0.0 |
| SELF MOVE SPELL | 0.5 | +65.0 | 0.0 | 21.9 | 0.2 | +52.7 | 0.0 | 11.0 |
| SET UP TOGETHER | 1.1 | +112.3 | 48.6 | 8.2 | 1.4 | +104.0 | 37.2 | 38.6 |
| SET-UP ANY TARGET | 0.4 | +69.6 | 0.0 | 0.0 | 0.1 | +13.2 | 0.0 | 6.5 |
| SET-UP MISSED | 0.0 | +6.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.4 | +0.7 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +43.4 | 33.9 | 21.2 | 0.7 | +29.8 | 42.5 | 15.3 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OPTIONS | 14.7 | +0.0 | 652.9 | 342.9 | 10.5 | +0.0 | 267.5 | 206.9 |
| SHOT REPLANNED | 0.4 | +0.0 | 89.9 | 9.0 | 0.1 | +0.0 | 15.3 | 0.0 |
| SHOTS IN THE MOVE | 14.0 | +503.5 | 0.0 | 303.5 | 9.4 | +319.5 | 0.0 | 152.4 |
| SPELL SETS UP CHARGE | 0.6 | +131.4 | 0.0 | 0.0 | 0.1 | +13.2 | 0.0 | 6.5 |
| SPELL WORTH | 1.4 | +19.4 | 13.8 | 25.7 | 2.3 | +31.1 | 75.4 | 65.8 |
| STABLE ROLE | 9.9 | +0.0 | 282.2 | 138.6 | 8.2 | +0.0 | 305.8 | 115.4 |
| STAY WEIGHED | 0.0 | +0.2 | 0.0 | 0.0 | 0.0 | +0.4 | 0.0 | 0.0 |
| STAY WORTH | 16.8 | +236.3 | 425.2 | 218.7 | - | - | - | - |
| STOPS | 0.1 | +0.8 | 0.0 | 1.5 | 0.1 | +2.6 | 3.5 | 0.0 |
| STOPS SHORT OF THE FLANK | 0.4 | +9.6 | 0.0 | 5.9 | 0.4 | +38.4 | 0.0 | 34.1 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 5.2 | -43.6 | 280.5 | 104.9 | 6.8 | -48.7 | 354.1 | 121.2 |
| SUPPORTS | 3.3 | +53.3 | 150.8 | 54.0 | 4.0 | +51.9 | 153.8 | 45.4 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -13.8 | 42.8 | 9.7 | 0.1 | -1.2 | 1.7 | 2.7 |
| SURE REACH TOGETHER | 0.5 | +4.6 | 0.0 | 6.1 | 0.9 | +3.5 | 0.0 | 21.2 |
| THREAT IN THE KILL | 10.5 | +134.6 | 640.0 | 235.8 | 0.1 | +0.3 | 0.0 | 0.0 |
| THROUGH LINE OF FIRE | 0.3 | +14.9 | 0.0 | 14.6 | 0.1 | +0.0 | 0.0 | 0.0 |
| TURN WORTH | 0.6 | -47.6 | 48.6 | 6.5 | 0.5 | -43.4 | 47.9 | 4.2 |
| TWO OR MORE ARRIVE | 0.3 | +3.0 | 26.6 | 0.0 | 0.6 | +5.9 | 10.1 | 12.1 |
| WAIT AFTER COSTS | 7.2 | -292.6 | 260.2 | 123.5 | 7.5 | -397.1 | 315.6 | 138.6 |
| WALKS TO THE FIGHT | 2.1 | +46.6 | 42.6 | 55.1 | 0.9 | +13.1 | 29.7 | 10.7 |
| WAR ENGINE CHARGES | 0.1 | +10.6 | 0.0 | 13.8 | 0.1 | +3.5 | 0.0 | 2.1 |
| WAR ENGINE JOBS | 0.4 | +0.0 | 32.4 | 31.2 | 0.2 | +0.0 | 2.4 | 0.0 |
| WEARS DOWN | 0.9 | +29.3 | 87.3 | 30.8 | 1.7 | +61.7 | 97.1 | 66.1 |
| WHO HITS BACK | 0.2 | +15.7 | 0.0 | 3.2 | 0.2 | +20.7 | 0.0 | 5.7 |
| WHOLE FIGHT | 0.2 | +2.7 | 26.3 | 0.0 | 0.6 | +2.8 | 79.6 | 0.5 |
| WHOLE FIGHT GAIN | 0.2 | +17.4 | 22.3 | 0.0 | 0.6 | +39.7 | 43.8 | 8.2 |
| WOUNDED STAYS OUT | 0.1 | +0.0 | 3.0 | 7.7 | - | - | - | - |

### Rule changes: shots-h2h-mine-7c46ffc-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 989 | 989 | 989 | 27.47 | -56705 | -57.3 |
| BEST FIRST | 254 | 254 | 254 | 7.06 | +10920 | +43.0 |
| SEARCH SPOT | 190 | 190 | 189 | 5.25 | +8555 | +45.3 |
| COUNTER-CHARGE COVER | 595 | 351 | 169 | 4.69 | +11014 | +65.2 |
| MOVE TO CHARGE | 293 | 293 | 156 | 4.33 | +8939 | +57.3 |
| PATHS CROSS | 149 | 149 | 149 | 4.14 | +10195 | +68.4 |
| KILLS COUNT NEXT TURN | 466 | 466 | 117 | 3.25 | +3292 | +28.1 |
| FACES THE THREAT | 108 | 108 | 108 | 3.00 | +8754 | +81.1 |
| SUPPORTS | 263 | 263 | 101 | 2.81 | +911 | +9.0 |
| FOLLOW UP WEIGHED | 100 | 100 | 100 | 2.78 | +16138 | +161.4 |
| ARTILLERY RE-ROLL WEIGHED | 74 | 74 | 74 | 2.06 | +0 | +0.0 |
| FALLBACK BY WORTH | 364 | 364 | 70 | 1.94 | +4255 | +60.8 |
| SHOTS IN THE MOVE | 842 | 556 | 70 | 1.94 | +1671 | +23.9 |
| MAX FOR POSITIONING | 353 | 230 | 63 | 1.75 | +889 | +14.1 |
| WALKS TO THE FIGHT | 110 | 110 | 60 | 1.67 | +750 | +12.5 |
| CANNON SIGHT KEPT | 57 | 57 | 57 | 1.58 | +0 | +0.0 |
| WAIT AFTER COSTS | 531 | 531 | 57 | 1.58 | +933 | +16.4 |
| SAFER THAN THE JOB | 52 | 52 | 52 | 1.44 | +3359 | +64.6 |
| REDIRECT COUNTER | 200 | 110 | 47 | 1.31 | +3354 | +71.4 |
| RESERVE FALL BACK | 45 | 45 | 45 | 1.25 | +1323 | +29.4 |
| SET UP TOGETHER | 93 | 82 | 43 | 1.19 | +2558 | +59.5 |
| BEST FACING | 42 | 42 | 42 | 1.17 | +2184 | +52.0 |
| CHARGE NOW FIRST | 206 | 206 | 41 | 1.14 | -2885 | -70.4 |
| CANNON PLANNED TARGET | 242 | 242 | 40 | 1.11 | -378 | -9.4 |
| HOLDS AMBUSHERS | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| ADVANCE LANE KEPT | 37 | 37 | 37 | 1.03 | +0 | +0.0 |
| BEST MOVE FOR SHOOTERS | 37 | 37 | 37 | 1.03 | +2690 | +72.7 |
| BEST OVERALL | 36 | 36 | 36 | 1.00 | +2325 | +64.6 |
| COMBAT PIVOT | 36 | 36 | 36 | 1.00 | +0 | +0.0 |
| MOVE AND CAST | 36 | 36 | 36 | 1.00 | +2076 | +57.7 |
| RISK BY ARC | 197 | 187 | 36 | 1.00 | +1147 | +31.9 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2259 | +68.5 |
| MISSILES IN THE MOVE | 289 | 170 | 33 | 0.92 | +600 | +18.2 |
| STAY WORTH | 605 | 496 | 32 | 0.89 | +507 | +15.8 |
| CAST JOB | 64 | 64 | 31 | 0.86 | +538 | +17.4 |
| CHARGE NOW WEIGHED | 31 | 31 | 31 | 0.86 | +2262 | +73.0 |
| KEEPS ITS TARGET | 151 | 146 | 31 | 0.86 | +523 | +16.9 |
| MARCH CHECK | 40 | 38 | 30 | 0.83 | +2717 | +90.6 |
| RANDOM MOVE BY FIGURES | 83 | 83 | 30 | 0.83 | +713 | +23.8 |
| BLOCKED WHEEL | 29 | 29 | 29 | 0.81 | +689 | +23.7 |
| STOPS SHORT OF THE FLANK | 29 | 29 | 29 | 0.81 | +1726 | +59.5 |
| INVITES THE FIGHT | 92 | 92 | 27 | 0.75 | +322 | +11.9 |
| KILLS COUNT | 133 | 128 | 27 | 0.75 | +1210 | +44.8 |
| MARCH ODDS | 26 | 26 | 26 | 0.72 | +234 | +9.0 |
| SCOUT WAITS | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 49 | 49 | 25 | 0.69 | +826 | +33.0 |
| BEST PREY | 62 | 62 | 22 | 0.61 | +1545 | +70.2 |
| FOCUS OVER TURNS | 64 | 64 | 22 | 0.61 | +265 | +12.1 |
| THREAT IN THE KILL | 382 | 304 | 22 | 0.61 | +157 | +7.1 |
| MAKE SURE TOGETHER | 59 | 40 | 20 | 0.56 | +1196 | +59.8 |
| SHOT REPLANNED | 19 | 19 | 19 | 0.53 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +36 | +2.0 |
| REDIRECT WEIGHED | 15 | 15 | 15 | 0.42 | +460 | +30.6 |
| WHO HITS BACK | 15 | 15 | 15 | 0.42 | +1151 | +76.8 |
| WHOLE FIGHT GAIN | 29 | 26 | 15 | 0.42 | +519 | +34.6 |
| BIG CHARACTER SAFETY | 13 | 13 | 13 | 0.36 | -21 | -1.6 |
| WAR ENGINE JOBS | 23 | 23 | 13 | 0.36 | -425 | -32.7 |
| THROUGH LINE OF FIRE | 12 | 12 | 12 | 0.33 | +536 | +44.7 |
| WEARS DOWN | 92 | 84 | 12 | 0.33 | +569 | +47.4 |
| FRIENDS SHOTS CHECKED | 10 | 10 | 10 | 0.28 | +280 | +28.0 |
| HUNT IN PAIRS | 35 | 27 | 10 | 0.28 | +973 | +97.3 |
| OPENS UP | 20 | 19 | 10 | 0.28 | +833 | +83.3 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CHAFF PASSED | 9 | 9 | 9 | 0.25 | -10 | -1.1 |
| LOST CHARGE | 197 | 196 | 9 | 0.25 | +288 | +32.0 |
| SURE CHARGE BEATS ADVANCE | 9 | 9 | 9 | 0.25 | -538 | -59.8 |
| LONE WIZARD HOLDS BACK | 18 | 18 | 8 | 0.22 | -294 | -36.7 |
| MANOEUVRE | 8 | 8 | 8 | 0.22 | +557 | +69.6 |
| MISSILES NEXT TURN | 364 | 212 | 8 | 0.22 | +51 | +6.3 |
| STUCK PIVOT | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +141 | +20.1 |
| PIVOT GUARDS FLANK | 7 | 7 | 7 | 0.19 | -130 | -18.5 |
| PURSUES BIG PREY | 7 | 7 | 7 | 0.19 | -319 | -45.6 |
| BACKUP TARGETS | 53 | 29 | 6 | 0.17 | +26 | +4.4 |
| CARRIES OUT SET-UP | 12 | 12 | 6 | 0.17 | -568 | -94.6 |
| CASTING BLOCK | 8 | 8 | 6 | 0.17 | +205 | +34.1 |
| KEEP FALLS | 6 | 6 | 6 | 0.17 | +289 | +48.2 |
| OVERRUNS AWAY | 43 | 40 | 6 | 0.17 | +318 | +53.0 |
| SURE REACH TOGETHER | 52 | 39 | 6 | 0.17 | +110 | +18.4 |
| WHOLE FIGHT | 31 | 30 | 6 | 0.17 | +246 | +41.0 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| DEFENSIVE ARMY | 9 | 9 | 4 | 0.11 | -199 | -49.7 |
| RAIDS THE BAGGAGE NEXT TURN | 4 | 4 | 4 | 0.11 | +24 | +6.1 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.11 | +101 | +25.3 |
| SUPPORT NARROWED | 433 | 433 | 4 | 0.11 | -38 | -9.5 |
| BEST PRIZE | 3 | 3 | 3 | 0.08 | -150 | -49.8 |
| DEFENSIVE FLOOR | 5 | 5 | 3 | 0.08 | +66 | +22.1 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.08 | +286 | +95.5 |
| MODEL FACING | 3 | 3 | 3 | 0.08 | +1001 | +333.7 |
| OPENS A LANE | 27 | 17 | 3 | 0.08 | +47 | +15.6 |
| CHARIOT NO STATIC JOB | 2 | 2 | 2 | 0.06 | -92 | -46.1 |
| FACE THE CAST | 2 | 2 | 2 | 0.06 | +6 | +3.2 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +44 | +21.9 |
| HORN WORTH | 2 | 2 | 2 | 0.06 | +29 | +14.6 |
| HUNT ADVANCE | 10 | 10 | 2 | 0.06 | +40 | +20.0 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +35 | +17.6 |
| STAY WEIGHED | 2 | 2 | 2 | 0.06 | +22 | +11.2 |
| WOUNDED STAYS OUT | 2 | 2 | 2 | 0.06 | -234 | -116.8 |
| BLOCKED CHARGE SKIPPED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +9 | +9.2 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.1 |
| CARRIES OUT COUNTER | 3 | 3 | 1 | 0.03 | -162 | -162.4 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -2 | -1.5 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| EDGE GIVE GROUND | 13 | 13 | 1 | 0.03 | +241 | +240.8 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +2 | +2.3 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| LONG SHOT | 27 | 26 | 1 | 0.03 | +63 | +62.9 |
| MISSILES IN THE PLAN | 21 | 2 | 1 | 0.03 | +10 | +10.2 |
| MOVE SPELL IN RANGE | 9 | 8 | 1 | 0.03 | +10 | +10.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +54 | +54.4 |
| RAIDS THE BAGGAGE | 2 | 2 | 1 | 0.03 | +161 | +160.6 |
| TURN WORTH | 39 | 37 | 1 | 0.03 | +39 | +39.0 |
| TWO OR MORE ARRIVE | 32 | 29 | 1 | 0.03 | +1 | +0.8 |
| WAR ENGINE CHARGES | 5 | 5 | 1 | 0.03 | +237 | +236.9 |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 37 | 37 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 47 | trace | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 5 | 5 | 0 | 0.00 | - | - |
| CHEAP HELPER | 9 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 43 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 346 | not checked | - | - | - | - |
| GIVES UP | 9 | 9 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 3 | 3 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 23 | 22 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 24 | 24 | 0 | 0.00 | - | - |
| HUNT DROPPED | 4 | trace | - | - | - | - |
| HUNT KEPT | 7 | trace | - | - | - | - |
| HUNT RESULT | 11 | trace | - | - | - | - |
| HUNT THE GUNS | 11 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 10 | 10 | 0 | 0.00 | - | - |
| KEEPS ITS PREY | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 25 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 6 | trace | - | - | - | - |
| MARCH OVER CASTS | 42 | 42 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 16 | 16 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 21 | trace | - | - | - | - |
| MOVE SPELL SPOT | 28 | not checked | - | - | - | - |
| NEEDED THERE | 2 | 2 | 0 | 0.00 | - | - |
| NOT NEEDED | 19 | 19 | 0 | 0.00 | - | - |
| NOT TURNED | 361 | 361 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 58 | not checked | - | - | - | - |
| OVERRUN THREAT | 1 | not checked | - | - | - | - |
| PLAN RESULT | 2657 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 30 | 30 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 23 | 23 | 0 | 0.00 | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 13 | 13 | 0 | 0.00 | - | - |
| SECOND HUNTER | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 24 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 21 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOT OPTIONS | 907 | 907 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 28 | not checked | - | - | - | - |
| SPELL WORTH | 136 | not checked | - | - | - | - |
| STABLE ROLE | 650 | 646 | 0 | 0.00 | - | - |
| STOPS | 5 | 5 | 0 | 0.00 | - | - |

### Off best figure: shots-h2h-mine-7c46ffc-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 12.83 | 11.58 | 58.7 |
| CHARGE NOW FIRST | rule | 0.47 | 0.67 | 70.4 |
| FALLBACK | gate | 0.44 | 0.58 | 42.8 |
| TURN GATE | gate | 0.33 | 0.69 | 45.1 |
| CANNON PLANNED TARGET | rule | 0.36 | 0.08 | 29.1 |
| WAR ENGINE JOBS | rule | 0.22 | 0.14 | 32.7 |
| LONE CHARACTER SAFE SPOT | gate | 0.28 | 0.03 | 65.9 |
| SURE CHARGE BEATS ADVANCE | rule | 0.19 | 0.06 | 59.8 |
| AFTERMATH BAND | gate | 0.11 | 0.08 | 2.1 |
| PIVOT GUARDS FLANK | rule | 0.03 | 0.17 | 18.5 |
| PURSUES BIG PREY | rule | 0.08 | 0.11 | 45.6 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.14 | 0.03 | 78.9 |
| BIG CHARACTER SAFETY | rule | 0.06 | 0.11 | 12.3 |
| CARRIES OUT SET-UP | rule | 0.14 | 0.03 | 94.6 |
| CHARGE NOW WEIGHED | rule | 0.11 | 0.06 | 28.2 |
| LONE WIZARD HOLDS BACK | rule | 0.08 | 0.08 | 48.9 |
| PATHS CROSS | rule | 0.06 | 0.11 | 42.8 |
| SUPPORT REQUEST | gate | 0.08 | 0.08 | 105.0 |
| MARCH ODDS | rule | 0.08 | 0.06 | 14.1 |
| CHAFF PASSED | rule | 0.11 | - | 2.3 |
| DEFENSIVE ARMY | rule | - | 0.11 | 49.7 |
| SUPPORT NARROWED | rule | 0.03 | 0.08 | 9.5 |
| BEST PRIZE | rule | 0.06 | 0.03 | 49.8 |
| FIGHT ORDER BAND | gate | 0.08 | - | 1.8 |
| STOPS SHORT OF THE FLANK | rule | 0.06 | 0.03 | 15.0 |
| CHARIOT NO STATIC JOB | rule | 0.06 | - | 46.1 |
| FACES THE THREAT | rule | - | 0.06 | 6.0 |
| NO REASON | gate | 0.06 | - | 6.0 |
| WOUNDED STAYS OUT | rule | 0.06 | - | 116.8 |
| BLOCKED WHEEL | rule | 0.03 | - | 8.0 |
| CARRIES OUT COUNTER | rule | - | 0.03 | 162.4 |
| CATCH ODDS | rule | 0.03 | - | 1.5 |
| FOLLOW UP WEIGHED | rule | 0.03 | - | 4.9 |
| RULE SWITCHED OFF | gate | - | 0.03 | 3.7 |
| SAFER THAN THE JOB | rule | - | 0.03 | 16.8 |
| THROUGH LINE OF FIRE | rule | 0.03 | - | 10.6 |

### Plans: shots-h2h-mine-7c46ffc-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.7 | 19% | 420 | 387 | 92% |
| Mine | charge | 2.8 | 56% | 278 | 232 | 83% |
| Mine | close in | 4.6 | 31% | 350 | 167 | 48% |
| Mine | hold | 4.6 | 34% | 243 | 0 | 0% |
| Mine | join | 0.6 | 100% | 19 | 0 | 0% |
| Mine | shoot | 8.4 | 64% | 328 | 582 | 178% |
| Mine | support | 3.4 | 94% | 37 | 0 | 0% |
| Opponent | advance | 12.6 | 18% | 382 | 407 | 107% |
| Opponent | charge | 5.1 | 53% | 584 | 460 | 79% |
| Opponent | close in | 5.7 | 29% | 427 | 195 | 46% |
| Opponent | hold | 3.6 | 25% | 279 | 0 | 0% |
| Opponent | join | 0.8 | 100% | 28 | 0 | 0% |
| Opponent | shoot | 5.2 | 54% | 110 | 249 | 226% |
| Opponent | support | 4.6 | 90% | 36 | 0 | 0% |

### Packages: hunt the guns, shots-h2h-mine-7c46ffc-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 4 | 0 | 0% | 0% | 0% | - | 445 | 0 | 0% | 25 |
| Opponent | 0.2 | 7 | 0 | 14% | 29% | 29% | 2.5 | 274 | 52 | 14% | 57 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1.0 | 4 | 0 | 0% | 0% | 0% | - | 445 | 0 | 0% | 13 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 28 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 47 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 58 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 81 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 33 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 408 |
| Tomb Kings of Khemri | 1.0 | 6 | 0 | 17% | 33% | 33% | 2.5 | 270 | 60 | 17% | 44 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 15 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 15 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 299 | 0 | 0% | 0 |

### Battle groups: shots-h2h-mine-7c46ffc-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.2 | 21% | 53% | 4% | 67% | 40% | 12% | 5% | 43% | 0% |
| Mine | REDIRECT COUNTER | 2.1 | 31% | 83% | 17% | 50% | 26% | 5% | 16% | 42% | 11% |
| Opponent | COUNTER-CHARGE COVER | 7.4 | 19% | 60% | 14% | 29% | 35% | 7% | 16% | 42% | 0% |
| Opponent | REDIRECT COUNTER | 3.5 | 28% | 69% | 20% | 71% | 14% | 7% | 21% | 57% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: shots-h2h-mine-7c46ffc-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 34 | 50 (34) | 19 | 31 | 59 | 29% | 2.5 | 57 (21) | 11 (4) | 45 (9) | 67 (24) | 15 (10) |
| Mine | Character | 119 | 57 (119) | 56 | 1 | 31 | 18% | 2.4 | 76 (37) | 59 (55) | 22 (7) | 63 (59) | 66 (40) |
| Mine | Clean-up | 20 | 42 (20) | 14 | 27 | 19 | 25% | 3.6 | 47 (5) | 33 (13) | 115 (2) | 53 (13) | 25 (7) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 44 | 33 (44) | 16 | 17 | 50 | 23% | 3.2 | 38 (20) | 31 (18) | 19 (6) | 37 (31) | 26 (13) |
| Mine | Fragile | 3 | 0 (3) | 0 | 0 | 33 | 0% | 5.0 | 0 (3) | - | - | 0 (1) | 0 (2) |
| Mine | Hammer | 50 | 42 (50) | 31 | 11 | 53 | 12% | 2.5 | 4 (11) | 57 (35) | 20 (4) | 41 (34) | 44 (16) |
| Mine | Holder | 25 | 38 (25) | 2 | 36 | 31 | 36% | 3.6 | 33 (7) | 34 (12) | 55 (6) | 60 (14) | 9 (11) |
| Mine | Shooter | 37 | 42 (37) | 7 | 36 | 54 | 3% | 1.7 | 13 (6) | 52 (28) | 7 (3) | 47 (23) | 34 (14) |
| Mine | Support | 4 | 126 (4) | 126 | 0 | 0 | 25% | 2.0 | 0 (1) | 218 (3) | - | 0 (1) | 218 (3) |
| Mine | War machine | 52 | 31 (52) | 31 | 0 | 47 | 0% | 1.2 | 34 (13) | 26 (35) | 73 (4) | 31 (13) | 31 (39) |
| Mine | Wizard | 16 | 7 (16) | 7 | 0 | 49 | 12% | 1.6 | 0 (4) | 0 (6) | 63 (1) | 12 (8) | 0 (3) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 68 | 74 (68) | 41 | 33 | 52 | 35% | 2.8 | 120 (29) | 78 (11) | 33 (28) | 97 (48) | 19 (20) |
| Opponent | Character | 101 | 59 (101) | 59 | 0 | 30 | 19% | 2.1 | 53 (33) | 72 (54) | 9 (5) | 60 (49) | 66 (43) |
| Opponent | Clean-up | 10 | 57 (10) | 13 | 44 | 24 | 30% | 2.6 | 0 (4) | 71 (5) | 201 (1) | 41 (6) | 74 (4) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 59 | 43 (59) | 24 | 18 | 40 | 25% | 2.8 | 35 (28) | 36 (21) | 83 (10) | 57 (26) | 30 (33) |
| Opponent | Fragile | 3 | 31 (3) | 31 | 0 | 67 | 33% | 2.0 | - | 46 (2) | 0 (1) | 46 (2) | 0 (1) |
| Opponent | Hammer | 47 | 31 (47) | 23 | 8 | 48 | 32% | 2.8 | 8 (16) | 36 (28) | 63 (3) | 39 (29) | 16 (18) |
| Opponent | Holder | 42 | 63 (42) | 8 | 55 | 29 | 33% | 2.8 | 30 (9) | 72 (21) | 80 (12) | 66 (28) | 58 (14) |
| Opponent | Shooter | 30 | 31 (30) | 16 | 15 | 51 | 3% | 1.2 | 38 (8) | 24 (20) | 115 (2) | 31 (18) | 32 (12) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 17 | 50% | 6.0 | 0 (1) | 0 (1) | 0 (2) | 0 (3) | 0 (1) |
| Opponent | War machine | 17 | 44 (17) | 44 | 0 | 39 | 6% | 1.4 | 98 (3) | 51 (10) | 0 (4) | 36 (3) | 46 (14) |
| Opponent | Wizard | 33 | 11 (33) | 11 | 0 | 30 | 21% | 1.9 | 0 (13) | 38 (10) | 0 (3) | 2 (14) | 29 (12) |

### Charged fights: shots-h2h-mine-7c46ffc-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 0 | 44 | 1.0 | 1.2 | 44 | 0 | +44 | 1 of 4 | 3 of 4 | +40 | +45 |
| Mine | Chaos Dwarfs | 4 | 245 | 133 | 2.8 | 1.0 | 48 | 10 | +38 | 3 of 11 | 8 of 11 | - | +38 |
| Mine | Dwarfen Mountain Holds | 3 | 543 | 61 | 1.7 | 1.0 | 37 | 13 | +24 | 0 of 5 | 2 of 5 | - | +24 |
| Mine | Empire of Man | 5 | 334 | 129 | 1.6 | 1.0 | 81 | 38 | +43 | 2 of 8 | 7 of 8 | - | +43 |
| Mine | Grand Cathay | 5 | 283 | 388 | 4.2 | 1.2 | 92 | 0 | +92 | 5 of 21 | 18 of 21 | +88 | +94 |
| Mine | High Elf Realms | 4 | 150 | 364 | 3.2 | 1.0 | 112 | 33 | +79 | 5 of 13 | 12 of 13 | - | +79 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 1161 | 5.0 | 1.2 | 232 | 55 | +177 | 1 of 5 | 4 of 5 | +141 | +186 |
| Mine | Lizardmen | 1 | 0 | 1321 | 4.0 | 1.0 | 330 | 21 | +310 | 1 of 4 | 4 of 4 | - | +310 |
| Mine | Ogre Kingdoms | 1 | 116 | 251 | 4.0 | 1.0 | 63 | 55 | +8 | 3 of 4 | 1 of 4 | - | +8 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 137 | 4.0 | 1.0 | 34 | 28 | +7 | 0 of 4 | 3 of 4 | - | +7 |
| Mine | Skaven | 1 | 0 | 19 | 2.0 | 1.0 | 10 | 0 | +10 | 0 of 2 | 2 of 2 | - | +10 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 1039 | 5.5 | 1.0 | 189 | 0 | +189 | 4 of 11 | 8 of 11 | - | +189 |
| Mine | Vampire Counts | 2 | 49 | 185 | 3.5 | 1.0 | 53 | 9 | +44 | 1 of 7 | 3 of 7 | - | +44 |
| Mine | Warriors of Chaos | 2 | 62 | 347 | 2.0 | 1.2 | 174 | 0 | +174 | 1 of 4 | 1 of 4 | +208 | +162 |
| **Mine** | all armies | 36 | 184 | 304 | 2.9 | 1.1 | 106 | 16 | +90 | 27 of 103 | 76 of 103 | +106 | +89 |
| Opponent | Empire of Man | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 3 | 483 | 492 | 3.3 | 1.3 | 148 | 0 | +148 | 3 of 10 | 8 of 10 | +318 | +74 |
| Opponent | High Elf Realms | 3 | 155 | 459 | 4.3 | 1.2 | 106 | 44 | +62 | 8 of 13 | 10 of 13 | +42 | +66 |
| Opponent | Kingdom of Bretonnia | 2 | 82 | 392 | 3.0 | 1.2 | 131 | 106 | +25 | 4 of 6 | 3 of 6 | +118 | +6 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 435 | 5.0 | 1.6 | 87 | 62 | +25 | 1 of 5 | 4 of 5 | +60 | +1 |
| Opponent | Skaven | 1 | 60 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 60 | 412 | 3.2 | 1.0 | 127 | 58 | +69 | 6 of 13 | 9 of 13 | - | +69 |
| Opponent | Vampire Counts | 6 | 33 | 789 | 5.2 | 1.2 | 153 | 47 | +106 | 14 of 31 | 13 of 31 | +93 | +108 |
| Opponent | Warriors of Chaos | 9 | 0 | 660 | 3.9 | 1.1 | 170 | 21 | +148 | 18 of 35 | 26 of 35 | +226 | +138 |
| Opponent | Wood Elf Realms | 6 | 93 | 159 | 2.8 | 1.0 | 56 | 43 | +13 | 6 of 17 | 9 of 17 | - | +13 |
| **Opponent** | all armies | 36 | 87 | 482 | 3.6 | 1.2 | 133 | 40 | +93 | 60 of 130 | 82 of 130 | +156 | +84 |

### Effective charges: shots-h2h-mine-7c46ffc-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 1 (net +0) | 1 (net +135) | 0 | 0 | 0 | 1 (net +40) | 1 | 0% (0 of 3) |
| Mine | Chaos Dwarfs | 11 | 1 (net +0) | 0 | 2 (net -56) | 3 (net +23) | 0 | 3 (net +95) | 2 | 22% (2 of 9) |
| Mine | Dwarfen Mountain Holds | 5 | 0 | 1 (net -65) | 1 (net +0) | 2 (net +40) | 0 | 1 (net +104) | 0 | 20% (1 of 5) |
| Mine | Empire of Man | 8 | 1 (net +211) | 0 | 1 (net +0) | 2 (net -130) | 0 | 3 (net +23) | 1 | 14% (1 of 7) |
| Mine | Grand Cathay | 21 | 2 (net +142) | 1 (net +0) | 3 (net +141) | 2 (net +88) | 4 (net +57) | 6 (net +94) | 3 | 17% (3 of 18) |
| Mine | High Elf Realms | 13 | 1 (net +0) | 0 | 0 | 2 (net +130) | 1 (net +125) | 6 (net +59) | 3 | 0% (0 of 10) |
| Mine | Kingdom of Bretonnia | 5 | 1 (net +190) | 0 | 0 | 0 | 0 | 4 (net +174) | 0 | 0% (0 of 5) |
| Mine | Lizardmen | 4 | 0 | 0 | 0 | 2 (net +116) | 0 | 2 (net +504) | 0 | 0% (0 of 4) |
| Mine | Ogre Kingdoms | 4 | 0 | 0 | 1 (net +0) | 1 (net +251) | 0 | 0 | 2 | 50% (1 of 2) |
| Mine | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 0 | 0 | 2 (net +14) | 2 | 0% (0 of 2) |
| Mine | Skaven | 2 | 0 | 0 | 1 (net +19) | 0 | 1 (net +0) | 0 | 0 | 50% (1 of 2) |
| Mine | Tomb Kings of Khemri | 11 | 1 (net +0) | 0 | 1 (net +75) | 4 (net +302) | 3 (net +121) | 2 (net +215) | 0 | 9% (1 of 11) |
| Mine | Vampire Counts | 7 | 1 (net +38) | 0 | 2 (net +126) | 3 (net +6) | 1 (net +0) | 0 | 0 | 29% (2 of 7) |
| Mine | Warriors of Chaos | 4 | 1 (net +144) | 0 | 1 (net +342) | 0 | 0 | 2 (net +104) | 0 | 25% (1 of 4) |
| Opponent | Grand Cathay | 10 | 2 (net +186) | 0 | 2 (net +306) | 3 (net +28) | 1 (net +77) | 2 (net +165) | 0 | 20% (2 of 10) |
| Opponent | High Elf Realms | 13 | 1 (net +126) | 1 (net +310) | 2 (net -174) | 3 (net +67) | 2 (net +42) | 3 (net +145) | 1 | 17% (2 of 12) |
| Opponent | Kingdom of Bretonnia | 6 | 3 (net -44) | 1 (net +165) | 0 | 1 (net +0) | 0 | 1 (net +118) | 0 | 0% (0 of 6) |
| Opponent | Orc & Goblin Tribes | 5 | 1 (net -255) | 0 | 0 | 1 (net +199) | 0 | 1 (net +121) | 2 | 0% (0 of 3) |
| Opponent | Tomb Kings of Khemri | 13 | 0 | 0 | 1 (net +316) | 5 (net -83) | 3 (net +73) | 3 (net +199) | 1 | 8% (1 of 12) |
| Opponent | Vampire Counts | 31 | 10 (net +106) | 2 (net +246) | 6 (net +64) | 4 (net +94) | 4 (net +9) | 5 (net +188) | 0 | 19% (6 of 31) |
| Opponent | Warriors of Chaos | 35 | 5 (net +85) | 1 (net +265) | 2 (net +232) | 4 (net +108) | 0 | 17 (net +171) | 6 | 7% (2 of 29) |
| Opponent | Wood Elf Realms | 17 | 2 (net +0) | 0 | 1 (net -19) | 1 (net +0) | 0 | 5 (net +102) | 8 | 11% (1 of 9) |

### Charged fights, damage counted: shots-h2h-mine-7c46ffc-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 10 | 233 | 277 | +87 | 103 | 34 | +68 | +29.4 |
| Mine | 50-54% | 3 | 150 | 156 | +23 | 45 | 22 | +23 | +15.5 |
| Mine | Effective (55-75%) | 13 | 212 | 187 | +77 | 110 | 32 | +79 | +37.1 |
| Mine | 76-89% | 21 | 300 | 157 | +97 | 130 | 34 | +96 | +31.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 32 | 274 | 187 | +118 | 191 | 40 | +151 | +55.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 10 | 426 | 79 | +72 | 76 | 10 | +67 | +15.6 |
| Mine | No odds | 14 | 291 | 165 | +59 | 88 | 20 | +68 | +23.4 |
| Mine | All fights | 103 | 281 | 175 | +90 | 131 | 31 | +100 | +35.4 |
| Opponent | Long shot (under 50%) | 24 | 223 | 248 | +66 | 166 | 67 | +99 | +44.4 |
| Opponent | 50-54% | 5 | 318 | 380 | +247 | 312 | 66 | +247 | +77.6 |
| Opponent | Effective (55-75%) | 14 | 244 | 248 | +101 | 198 | 105 | +93 | +37.9 |
| Opponent | 76-89% | 22 | 292 | 228 | +40 | 110 | 45 | +65 | +22.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 37 | 384 | 232 | +161 | 217 | 41 | +177 | +46.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 10 | 562 | 90 | +42 | 104 | 63 | +40 | +7.2 |
| Opponent | No odds | 18 | 151 | 189 | +37 | 101 | 63 | +38 | +25.3 |
| Opponent | All fights | 130 | 303 | 225 | +93 | 166 | 59 | +108 | +35.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| shots-h2h-mine-7c46ffc-p3 | move | 463 | 106 (23%) | 74 (16%) | 65 (14%) | 292 (63%) |
| shots-h2h-mine-7c46ffc-p3 | objective | 373 | 73 (20%) | 51 (14%) | 46 (12%) | 254 (68%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

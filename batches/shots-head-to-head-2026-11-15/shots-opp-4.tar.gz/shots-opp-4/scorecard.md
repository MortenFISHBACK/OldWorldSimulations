# Doctrine scorecard: shots-h2h-opp-7c46ffc-p4

### Scorecard: shots-h2h-opp-7c46ffc-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 6 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 4 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | yes | 5 | - | 0 | 1 | 0 | 0 | 0 | 65 |
| L0130 | 4 | 1 | Opponent | no | 1 | 1 | 9 | 1 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | no | 2 | 3 | 5 | 1 | 0 | 0 | 0 | 170 |
| L0214 | 4 | 1 | Opponent | no | 4 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 4 | 2 | 4 | 0 | 0 | 0 | 442 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | no | 6 | - | 3 | 0 | 1 | 0 | 0 | 590 |
| L0315 | 3 | 1 | Opponent | yes | 6 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | 4 | 1 | 1 | 0 | 0 | 0 | 675 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | yes | 2 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 0 | 3 | 5 | 0 | 1 | 0 | 0 | 184 |
| L0434 | 2 | 1 | Mine | - | - | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 2 | 1 | 1 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 0 | 3 | 0 | 1 | 0 | 0 | 0 | 1331 |
| L0520 | 4 | 1 | Opponent | no | 0 | - | 1 | 5 | 2 | 0 | 0 | 210 |
| L0608 | 2 | 1 | Mine | - | - | - | 0 | 4 | 0 | 0 | 0 | 615 |
| L0608 | 2 | 1 | Opponent | - | - | - | 0 | 3 | 0 | 0 | 0 | 1012 |
| L0624 | 6 | 1 | Mine | no | 0 | 5 | 1 | 0 | 0 | 0 | 0 | 615 |
| L0624 | 6 | 1 | Opponent | no | 6 | 3 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 452 |
| L0713 | 5 | 1 | Opponent | yes | - | 2 | 3 | 1 | 0 | 0 | 0 | 317 |
| L0729 | 3 | 1 | Mine | no | 3 | 2 | 1 | 0 | 0 | 0 | 0 | 513 |
| L0729 | 3 | 1 | Opponent | no | 5 | 2 | 4 | 0 | 1 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | no | 0 | 3 | 1 | 0 | 0 | 0 | 0 | 386 |
| L0819 | 3 | 1 | Opponent | yes | 4 | 2 | 0 | 2 | 2 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 515 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | no | 6 | 2 | 6 | 0 | 1 | 0 | 0 | 456 |
| L1017 | 3 | 1 | Opponent | yes | 2 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1034 | 2 | 1 | Mine | - | - | 1 | 2 | 0 | 1 | 0 | 0 | 664 |
| L1034 | 2 | 1 | Opponent | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1126 | 4 | 1 | Mine | no | 2 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1126 | 4 | 1 | Opponent | no | 4 | 2 | 2 | 2 | 1 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 3 | 4 | 0 | 1 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 3 | 3 | 0 | 0 | 0 | 65 |
| L1314 | 6 | 1 | Mine | no | 5 | 2 | 3 | 0 | 0 | 0 | 0 | 302 |
| L1314 | 6 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1331 | 5 | 1 | Mine | yes | - | 6 | 0 | 2 | 0 | 0 | 0 | 140 |
| L1331 | 5 | 1 | Opponent | yes | - | - | 2 | 2 | 2 | 0 | 0 | 340 |
| L1427 | 5 | 1 | Mine | yes | - | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | yes | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | yes | - | 2 | 7 | 0 | 1 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 2 | 6 | 0 | 0 | 0 | 0 | 66 |
| L1621 | 1 | 1 | Mine | no | 0 | 3 | 4 | 1 | 0 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 0 | - | 2 | 0 | 1 | 0 | 0 | 420 |
| L1719 | 3 | 1 | Mine | no | 2 | 2 | 6 | 0 | 2 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Opponent | yes | 5 | 2 | 5 | 0 | 0 | 0 | 0 | 156 |
| L1819 | 1 | 1 | Mine | no | 1 | 3 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 7 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | no | - | - | 2 | 3 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | no | - | 3 | 4 | 3 | 0 | 0 | 0 | 126 |
| L2021 | 5 | 1 | Mine | yes | - | 2 | 4 | 2 | 0 | 0 | 0 | 210 |
| L2021 | 5 | 1 | Opponent | no | - | 4 | 3 | 3 | 0 | 0 | 0 | 355 |
| L2123 | 5 | 1 | Mine | yes | - | - | 2 | 5 | 0 | 0 | 0 | 500 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | no | 2 | 3 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | yes | 2 | 1 | 1 | 3 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Mine | no | 4 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Opponent | yes | 1 | 5 | 1 | 1 | 0 | 0 | 0 | 170 |
| L2527 | 1 | 1 | Mine | no | 0 | 6 | 2 | 3 | 0 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 0 | 1 | 1 | 4 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Mine | no | 7 | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 5 | 2 | 2 | 3 | 0 | 0 | 0 | 216 |
| L2930 | 2 | 1 | Mine | - | - | 2 | 6 | 1 | 0 | 0 | 0 | 323 |
| L2930 | 2 | 1 | Opponent | - | - | 2 | 6 | 3 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 0 | 2 | 4 | 5 | 0 | 0 | 0 | 170 |
| L3234 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 25% | 2.5 | 2.8 | 2.7 | 1.2 | 0.2 | 0.0 | 0.0 | 291.9 |
| **Average** | | | Opponent | 43% | 2.7 | 2.1 | 3.0 | 1.7 | 0.4 | 0.0 | 0.0 | 105.8 |

### KPIs: shots-h2h-opp-7c46ffc-p4

Rules off - Mine only: STAY WORTH, BEST MOVE FOR SHOOTERS, THREAT IN THE KILL, FOCUS OVER TURNS, MISSILES IN THE PLAN, FACE THE CAST, WIZARD FRONT RANK.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 21% (35 of 164) | 2% (4 of 182) | 11% (39 of 346) |
| Winner chose to follow up after the loser gave ground |  | 93% (66 of 71); on the table 93% | 93% (51 of 55); on the table 98% | 93% (117 of 126); on the table 95% |
| Winner chose to pursue after the loser fell back in good order |  | 79% (11 of 14); on the table 86% | 100% (15 of 15); on the table 100% | 90% (26 of 29); on the table 93% |
| Winner chose to pursue after the loser fled |  | 73% (19 of 26); on the table 81% | 78% (28 of 36); on the table 81% | 76% (47 of 62); on the table 81% |
| Winner chose to follow up or pursue (all three) |  | 86% (96 of 111); on the table 89% | 89% (94 of 106); on the table 92% | 88% (190 of 217); on the table 91% |
| Magic missiles tried each own turn | 50%+ | 22% (60 of 269) | 35% (59 of 170) | 27% (119 of 439) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 38% (60 of 158) | 49% (59 of 120) | 43% (119 of 278) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 21% (28 of 136) | 38% (32 of 85) | 27% (60 of 221) |
|     round 1 |  | 17% (4 of 23) | 14% (2 of 14) | 16% (6 of 37) |
|     rounds 2+ |  | 21% (24 of 113) | 42% (30 of 71) | 29% (54 of 184) |
|   other wizards | 50%+ | 24% (32 of 133) | 28% (22 of 80) | 25% (54 of 213) |
|     round 1 |  | 13% (3 of 23) | 36% (5 of 14) | 22% (8 of 37) |
|     rounds 2+ |  | 26% (29 of 110) | 26% (17 of 66) | 26% (46 of 176) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 63% (24 of 38) | 58% (38 of 65) | 60% (62 of 103) |
| Points that never fought | lower | 30% (20253 of 67942) | 34% (24165 of 71984) | 32% (44418 of 139926) |
|   infantry points that never fought | lower | 39% (6025 of 15347) | 50% (6889 of 13804) | 44% (12914 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 63% (169 of 270) | 54% (152 of 280) | 58% (321 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 86% (19 of 22); 1.1 uses a game | 89% (8 of 9); 0.6 uses a game | 87% (27 of 31); 0.8 uses a game |
| Bound items with another spell used |  | 38% (6 of 16); 0.4 uses a game | 50% (10 of 20); 0.5 uses a game | 44% (16 of 36); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 53% (10 of 19); 0.3 uses a game | 87% (13 of 15); 0.4 uses a game | 68% (23 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 55% (31554 of 57750) | 46% (29289 of 63347) | 50% (60843 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.5 (26%) | 0.9 (28%) | 2.4 (27%) |
| MARCHED: its unit marched | 1.0 (18%) | 0.5 (17%) | 1.6 (18%) |
| CHARGED: its unit charged | 0.1 (2%) | 0.2 (5%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.7 (29%) | 0.6 (18%) | 2.2 (25%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.1 (4%) | 0.1 (1%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |
| GONE: slain | 1.2 (22%) | 0.8 (24%) | 2.0 (22%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.6 | 1.4 | 1.7 | 3.3 | 0.3 | 2.6 |
| not cast | 2.5 | 2.5 | 3.1 | 8.9 | 1.7 | 20.4 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.6 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.1 (42%) | 0.2 (6%) | 2.4 (27%) | 0.2 (13%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.6 (18%) | 0.3 (18%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.2 (8%) | 0.8 (24%) | 2.2 (25%) | 0.5 (30%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.1 (4%) | 0.1 (4%) | 0.2 (5%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (2%) | 0.0 (1%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.4 (2%) |
| GONE: slain | 0.7 (27%) | 0.7 (28%) | 0.5 (16%) | 2.0 (22%) | 0.2 (15%) | 3.6 (18%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.2 (6%) | 0.1 (1%) | 0.1 (3%) | 0.6 (3%) |
| STUPIDITY: Stupidity | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (11%) | 0.0 (0%) | 0.1 (1%) | 0.3 (17%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.6 (63%) | 0.1 (6%) | 1.3 (42%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.9 (68%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.5 a game | 0.9 a game |
| stood (cast and not dispelled) | 68% (27 of 40) | 64% (7 of 11) | 67% (34 of 51) |
| the unit moved after it | 67% (18 of 27) | 71% (5 of 7) | 68% (23 of 34) |
| it charged on its next turn | 4% (1 of 27) | 0% (0 of 7) | 3% (1 of 34) |
| the enemy charged it first | 30% (8 of 27) | 0% (0 of 7) | 24% (8 of 34) |
| it fought by the end of its next turn | 22% (6 of 27) | 14% (1 of 7) | 21% (7 of 34) |
| it moved out of a charge the enemy had planned (not charged first) | 15% (4 of 27) | 0% (0 of 7) | 12% (4 of 34) |
| none of these (no charge, no fight, no charge escaped) | 48% (13 of 27) | 86% (6 of 7) | 56% (19 of 34) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (551 of 864) | 58% (309 of 534) | 62% (860 of 1398) |
|   cavalry | 70% (53 of 76) | 76% (88 of 116) | 73% (141 of 192) |
|   character | 39% (40 of 103) | 15% (19 of 129) | 25% (59 of 232) |
|   chariot | 57% (60 of 105) | 74% (17 of 23) | 60% (77 of 128) |
|   infantry | 60% (164 of 275) | 69% (146 of 211) | 64% (310 of 486) |
|   monster | 44% (18 of 41) | 44% (11 of 25) | 44% (29 of 66) |
|   war machine | 82% (216 of 264) | 93% (28 of 30) | 83% (244 of 294) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.5 (29%) | 1.3 (20%) | 3.8 (25%) |
| CHARGED: it charged | 1.6 (18%) | 1.7 (27%) | 3.2 (22%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (2%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.7 (8%) | 0.4 (6%) | 1.1 (7%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 1.7 (19%) | 1.3 (21%) | 3.0 (20%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (5%) | 0.5 (8%) | 0.9 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.1 (12%) | 0.9 (14%) | 1.9 (13%) |
| SHELTERED: the target was sheltered | 0.3 (3%) | 0.1 (1%) | 0.3 (2%) |
| OTHER BAR | 0.3 (4%) | 0.1 (1%) | 0.4 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.4 | 1.8 | 78% | 6.9 pts | 44 pts |
| character | 2.0 | 0.4 | 86% | 7.5 pts | 15 pts |
| chariot | 2.2 | 1.0 | 70% | 11.4 pts | 25 pts |
| infantry | 12.6 | 4.2 | 76% | 9.0 pts | 114 pts |
| monster | 0.9 | 0.1 | 94% | 0.9 pts | 1 pts |
| war machine | 6.8 | 5.1 | 68% | 26.7 pts | 181 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.7 | 6.3 | 5.5 |
| Charges that made contact a game | 3.7 | 4.6 | 4.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.18 declared, 1.00 contact (17 units) | 0.75 declared, 0.44 contact (16 units) | 0.97 declared, 0.73 contact (33 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.70 declared, 1.20 contact (10 units) | 0.75 declared, 0.75 contact (8 units) | 1.28 declared, 1.00 contact (18 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.53 declared, 0.41 contact (249 units) | 0.70 declared, 0.52 contact (297 units) | 0.62 declared, 0.47 contact (546 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 57% (46 of 81) | 44% (7 of 16) | 33% (2 of 6) | 53% (55 of 103) |
| Character in a unit | 82% (18 of 22) | 64% (9 of 14) | 100% (1 of 1) | 76% (28 of 37) |
| Character on its own | 86% (37 of 43) | 46% (13 of 28) | 26% (20 of 77) | 47% (70 of 148) |
| Chariot | 93% (14 of 15) | 58% (7 of 12) | - | 78% (21 of 27) |
| Infantry | 58% (48 of 83) | 40% (10 of 25) | 33% (2 of 6) | 53% (60 of 114) |
| Monster | 59% (20 of 34) | 79% (11 of 14) | - | 65% (31 of 48) |
| Monstrous | 79% (11 of 14) | 57% (8 of 14) | - | 68% (19 of 28) |
| War Machines | 81% (35 of 43) | 100% (2 of 2) | - | 82% (37 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (15 of 15); on the table 100% | 23% (23 of 102) | 15% | 45% (10 of 22) | 83% (5 of 6); 1.8 uses a game | 50% (1 of 2); 0.8 uses a game | 67% (4 of 6); 1.0 uses a game |
| Chaos Dwarfs | 4 | 94% (16 of 17); on the table 100% | 29% (7 of 24) | 27% | 50% (16 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 83% (5 of 6); on the table 83% | - | 59% | 74% (20 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 88% (7 of 8); on the table 88% | 44% (8 of 18) | 49% | 74% (46 of 62) | 0.0 uses a game | 50% (1 of 2); 1.0 uses a game | 60% (3 of 5); 0.5 uses a game |
| Grand Cathay | 4 | 75% (6 of 8); on the table 75% | 23% (19 of 84) | 22% | 49% (18 of 37) | 89% (8 of 9); 5.0 uses a game | 50% (1 of 2); 0.5 uses a game | 25% (1 of 4); 0.2 uses a game |
| High Elf Realms | 9 | 83% (30 of 36); on the table 86% | 19% (7 of 36) | 28% | 49% (34 of 70) | 100% (7 of 7); 2.1 uses a game | 43% (13 of 30); 2.6 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (1 of 1); on the table 100% | - | 46% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 90% (9 of 10); on the table 100% | 50% (3 of 6) | 29% | 67% (14 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 78% (7 of 9); on the table 89% | 0% (0 of 6) | 40% | 93% (13 of 14) | 50% (1 of 2); 0.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (12 of 12); on the table 100% | 14% (6 of 42) | 31% | 46% (11 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 6 | 80% (8 of 10); on the table 90% | 34% (14 of 41) | 39% | 73% (33 of 45) | 100% (3 of 3); 0.8 uses a game | 0.0 uses a game | 67% (4 of 6); 0.8 uses a game |
| Tomb Kings of Khemri | 4 | 92% (11 of 12); on the table 92% | 17% (1 of 6) | 25% | 30% (6 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 82% (18 of 22); on the table 91% | 36% (20 of 56) | 22% | 55% (23 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 89% (24 of 27); on the table 89% | 50% (6 of 12) | 26% | 56% (40 of 72) | 100% (2 of 2); 0.4 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 88% (21 of 24); on the table 88% | 83% (5 of 6) | 40% | 62% (35 of 56) | 50% (1 of 2); 0.7 uses a game | 0.0 uses a game | 100% (4 of 4); 0.7 uses a game |

Flank and rear charges a unit could have turned to face (shots-h2h-opp-7c46ffc-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 43% (43) | 48% (37) | 45% (80) |
| ...free all their last turn and able to turn (per game) | 0.69 | 0.58 | 1.28 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.19 | 0.22 | 0.42 |
| ...with the charger already in that arc before they moved (per game) | 0.47 | 0.39 | 0.86 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.78 | 1.22 | 3.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.14 | 0.33 | 1.47 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.44 | 6.64 | 12.08 |

### Quality by phase: shots-h2h-opp-7c46ffc-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 57% (97 of 169) | 42% (87 of 205) |
| Strategy | Shoot objectives carried out (shot that target) | 49% (172 of 352) | 45% (69 of 153) |
| Strategy | Close-in objectives charged next turn | 15% (24 of 164) | 15% (32 of 212) |
| Strategy | Support requests answered (helper made contact too) | 68% (13 of 19) | 31% (9 of 29) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 58% (7 of 12) | 33% (3 of 9) |
| Strategy | Joined characters whose unit fought | 65% (20 of 31) | 30% (8 of 27) |
| Strategy | Lone characters that fought | 79% (73 of 92) | 76% (68 of 89) |
| Movement | Charges halted short of contact | 0.2 | 0.2 |
| Movement | Idle units | 1.2 | 1.7 |
| Movement | Points that never moved of their own | 291.9 | 105.8 |
| Movement | Fights charged into per game | 3.3 | 3.9 |
| Movement | Charges with odds: long shots (under 50%) | 15 of 109, net +10 | 22 of 118, net +1 |
| Movement | Charges with odds: sweet spot (55-75%) | 15 of 109, net -6 | 23 of 118, net +83 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 17 of 109, net +107 | 13 of 118, net +58 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 36 of 109, net +78 | 37 of 118, net +153 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.1 | 9.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (183 of 365) | 40% (131 of 325) |
| Shooting | Points destroyed by shooting units | 104.9 | 39.5 |
| Shooting | War machine shots | 6.0 | 0.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 60% (130 of 216) | 21% (6 of 28) |
| Shooting | Points destroyed by war machines | 46.5 | 17.2 |
| Magic | Magic missiles cast | 1.0 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 35% (13 of 37) | 27% (12 of 44) |
| Magic | Wounds caused by magic missiles | 2.1 | 1.6 |
| Magic | Wounds caused by other spells | 2.5 | 1.4 |
| Magic | Points destroyed by magic (all spells) | 62.6 | 36.5 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.4 / 1.2 / 0.1 | 2.0 / 0.5 / 0.6 / 0.1 |
| Combat | Points destroyed in combat | 358.1 | 450.3 |
| Combat | Points run down | 108.7 | 174.4 |
| Combat | Net points per charged fight, damage counted | +48 | +87 |
| Combat | Net per 100 charger points, damage counted | +15.7 | +26.8 |
| Combat | First round won (charged fights) | 74% | 68% |
| Combat | Net points per charged fight | +48 | +85 |
| Combat | Net points per supported fight / lone fight | -40 / +63 | +189 / +68 |
| Combat | Charged fights on a top-3 enemy unit | 41 of 119 | 66 of 140 |
| Game | Points lost | 838.3 | 743.9 |
| Game | VP from objectives | 515.0 | 580.8 |
| Game | Lone holders (player turns) | 2.5 | 2.7 |

- Mine won / drew / lost: 11 / 10 / 15 of 36 ended games (of 36); mean margin (Mine - Opponent) -182 VP
- The side that went first won 14 of 26 games with a winner
- Points traded per game (both sides' losses): 1582
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: shots-h2h-opp-7c46ffc-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 0.9 | +0.0 | 0.0 | 16.8 | 0.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.1 | +7.4 | 0.0 | 19.7 | 1.2 | +13.1 | 0.0 | 33.6 |
| BEST FACING | 0.7 | +25.3 | 0.0 | 19.6 | 0.6 | +27.7 | 0.0 | 13.2 |
| BEST FIRST | 3.6 | +125.5 | 162.2 | 85.1 | 4.2 | +171.8 | 106.2 | 67.7 |
| BEST MOVE FOR SHOOTERS | - | - | - | - | 0.7 | +44.1 | 0.0 | 25.5 |
| BEST OVERALL | 0.5 | +36.4 | 0.0 | 5.3 | 0.4 | +26.4 | 0.0 | 11.5 |
| BEST PREY | 0.6 | +32.2 | 19.3 | 15.3 | 0.8 | +34.3 | 9.3 | 20.1 |
| BEST PRIZE | - | - | - | - | 0.1 | +8.7 | 11.3 | 4.8 |
| BIG CHARACTER SAFETY | 0.1 | -0.0 | 0.0 | 0.0 | 0.1 | +0.5 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 5.1 | 0.0 | 0.1 | +0.0 | 1.4 | 7.9 |
| BLOCKED WHEEL | 0.5 | +2.6 | 0.0 | 4.9 | 0.6 | +21.9 | 0.0 | 0.0 |
| BOMBING RUN | 0.0 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 7.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.5 | +0.0 | 82.2 | 23.6 | 0.1 | +0.0 | 28.1 | 0.0 |
| CANNON PLANNED TARGET | 4.4 | +193.7 | 432.9 | 103.9 | 0.7 | +50.9 | 86.8 | 0.0 |
| CANNON SIGHT KEPT | 1.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.0 | +0.0 | 0.0 | 5.1 | 0.1 | -2.1 | 0.0 | 0.0 |
| CAST JOB | 0.5 | +24.1 | 15.5 | 20.8 | 0.3 | +7.2 | 0.0 | 9.4 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +26.9 | 8.3 | 0.0 | 0.1 | +5.5 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.9 | +0.0 | 0.0 | 30.1 | 0.2 | +0.0 | 0.0 | 16.7 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | - | - | - | - | 0.0 | +0.2 | 0.0 | 3.2 |
| CHAFF PASSED | 0.3 | -0.6 | 8.9 | 11.8 | 0.1 | -0.4 | 7.8 | 0.0 |
| CHAMPION TAKES THE CHALLENGE | 0.0 | +0.0 | 11.3 | 0.0 | 0.0 | +0.2 | 7.8 | 0.0 |
| CHARGE NOW FIRST | 2.8 | +0.0 | 279.8 | 108.3 | 3.1 | +0.0 | 371.6 | 107.4 |
| CHARGE NOW WEIGHED | 0.5 | -35.9 | 1.5 | 25.2 | 0.5 | -56.4 | 27.0 | 31.9 |
| CHARIOT NO STATIC JOB | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.1 | -1.8 | 13.9 | 13.9 | 0.2 | -2.8 | 6.6 | 15.0 |
| CHEAP HELPER | 0.1 | +0.0 | 1.2 | 5.1 | 0.0 | +0.0 | 0.0 | 0.8 |
| COMBAT PIVOT | 0.6 | +0.0 | 18.1 | 62.2 | 0.5 | +0.0 | 47.8 | 50.0 |
| CONVEYANCE SEARCH | 0.8 | +118.1 | 19.0 | 32.5 | 0.2 | +38.1 | 0.0 | 7.6 |
| COUNTER-CHARGE COVER | 8.5 | +612.7 | 0.0 | 195.7 | 7.5 | +676.2 | 0.0 | 176.3 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 13.7 | 5.7 | 0.0 | +0.0 | 1.2 | 0.0 |
| DEFENSIVE FLOOR | 0.1 | +0.9 | 2.7 | 1.8 | - | - | - | - |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +12.5 | 42.8 | 1.2 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +1.3 | 0.0 | 9.7 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACE THE CAST | - | - | - | - | 0.1 | +1.0 | 0.0 | 0.0 |
| FACES THE THREAT | 1.8 | +159.1 | 0.0 | 43.4 | 1.2 | +80.3 | 0.0 | 31.9 |
| FALLBACK BY WORTH | 4.3 | +53.5 | 0.0 | 76.6 | 6.0 | +83.2 | 0.0 | 94.9 |
| FIGHT LIFT | 0.1 | +0.3 | 4.0 | 0.0 | - | - | - | - |
| FLANK NOT WEIGHED | 5.1 | +0.0 | 0.0 | 103.9 | 6.2 | +0.0 | 0.0 | 161.0 |
| FOCUS FIRE | - | - | - | - | 0.1 | +0.8 | 1.2 | 0.0 |
| FOCUS OVER TURNS | - | - | - | - | 0.5 | +17.2 | 40.2 | 1.8 |
| FOLLOW UP WEIGHED | 1.1 | +185.1 | 0.0 | 66.2 | 1.2 | +147.7 | 0.0 | 18.6 |
| FRIENDS SHOTS CHECKED | 0.2 | +4.8 | 0.0 | 0.0 | 0.2 | +14.1 | 0.0 | 22.3 |
| GIVES UP | 0.2 | -1.8 | 13.3 | 2.4 | 0.1 | -3.5 | 20.3 | 15.0 |
| GIVES UP ITS SCREEN | - | - | - | - | 0.1 | -0.7 | 5.8 | 0.0 |
| GROUND FLIERS | 0.0 | +1.4 | 0.0 | 0.0 | 0.1 | +1.9 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 4.6 | 1.7 |
| HELPER UNSEEN | 0.3 | +0.0 | 34.9 | 14.0 | 0.3 | +0.0 | 17.9 | 0.0 |
| HILL BY ITS CHANCE | 0.8 | -73.0 | 0.0 | 8.1 | 0.5 | -38.4 | 0.0 | 15.2 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +0.2 | 0.0 | 1.5 | 0.1 | +6.9 | 3.9 | 6.2 |
| HUNT IN PAIRS | 0.2 | +9.5 | 0.0 | 0.0 | 0.7 | +30.6 | 0.0 | 13.2 |
| HUNT KEPT | - | - | - | - | 0.1 | +7.8 | 6.9 | 3.1 |
| HUNT RESULT | 0.1 | +0.3 | 0.0 | 1.9 | 0.2 | +20.4 | 21.2 | 3.1 |
| HUNT THE GUNS | 0.1 | +28.1 | 0.0 | 1.5 | 0.2 | +57.3 | 27.5 | 3.9 |
| INVITES THE FIGHT | 1.6 | +26.9 | 45.9 | 4.8 | 1.3 | +18.2 | 41.0 | 21.9 |
| JOINT CHARGE PLAN | 0.2 | +2.7 | 0.0 | 0.0 | 0.1 | +15.5 | 13.7 | 0.0 |
| KEEP FALLS | 0.1 | +1.1 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 3.2 |
| KEEPS ITS PREY | 0.0 | +0.1 | 0.0 | 0.0 | 0.1 | +0.2 | 0.0 | 8.9 |
| KEEPS ITS TARGET | 1.7 | +50.0 | 87.0 | 31.9 | 2.3 | +69.2 | 273.1 | 36.0 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 2.2 | +85.7 | 194.3 | 58.5 | 2.2 | +110.3 | 221.4 | 44.4 |
| KILLS COUNT NEXT TURN | 5.2 | +190.3 | 132.6 | 144.8 | 7.4 | +261.7 | 266.7 | 148.7 |
| LONE CHARACTER SAFE SPOT | 0.4 | +20.0 | 14.3 | 18.0 | 0.2 | +6.0 | 12.0 | 3.2 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 5.3 |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| LONG SHOT | 0.7 | -8.9 | 48.0 | 24.5 | 0.4 | -1.1 | 40.0 | 4.6 |
| LOST CHARGE | 2.8 | -39.9 | 55.1 | 108.8 | 2.1 | -39.7 | 57.3 | 47.0 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.1 | -4.8 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.4 | +27.1 | 0.0 | 16.2 | 0.5 | +122.7 | 34.0 | 16.1 |
| MANOEUVRE | 0.2 | +6.9 | 0.0 | 1.8 | 0.1 | +2.3 | 0.0 | 6.2 |
| MARCH AT ESCAPER | 0.1 | +1.3 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| MARCH CHECK | 0.4 | +24.4 | 0.0 | 2.4 | 0.2 | +4.2 | 0.0 | 8.5 |
| MARCH ODDS | 0.3 | +17.7 | 8.9 | 4.6 | 0.3 | +28.7 | 13.2 | 15.0 |
| MARCH OVER CASTS | 0.3 | +16.1 | 0.0 | 13.9 | 0.4 | +28.4 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.4 | +137.3 | 0.0 | 121.8 | 5.3 | +202.3 | 0.0 | 116.6 |
| MISSILES IN THE MOVE | 3.2 | +111.6 | 0.0 | 77.5 | 2.3 | +61.5 | 0.0 | 52.3 |
| MISSILES IN THE PLAN | - | - | - | - | 0.1 | +1.3 | 4.6 | 0.0 |
| MISSILES NEXT TURN | 4.1 | +76.4 | 0.0 | 115.3 | 3.0 | +37.7 | 0.0 | 52.3 |
| MODEL FACING | 0.1 | +10.0 | 0.0 | 3.3 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 9.1 | 0.0 | 0.2 | +0.0 | 14.2 | 0.0 |
| MOVE AND CAST | 0.1 | +1.5 | 0.0 | 8.8 | 0.3 | +18.5 | 0.0 | 7.6 |
| MOVE SPELL IN RANGE | 0.2 | +4.2 | 0.0 | 4.7 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.6 | -28.3 | 10.1 | 0.0 | 0.1 | -4.1 | 16.6 | 7.6 |
| MOVE SPELL SPOT | 0.6 | +0.0 | 0.0 | 26.2 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE | 3.4 | +152.7 | 76.2 | 92.1 | 4.2 | +330.3 | 206.9 | 87.5 |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +7.8 | 3.1 | 0.0 | 0.1 | +6.4 | 1.7 | 0.0 |
| NOT NEEDED | 0.3 | -10.8 | 33.1 | 6.1 | 0.3 | -19.5 | 41.5 | 0.0 |
| NOT TURNED | 5.4 | +71.8 | 0.0 | 100.8 | 6.6 | +96.4 | 0.0 | 165.1 |
| NOT WORTH A CAST | 0.8 | -0.5 | 0.0 | 13.9 | 0.2 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 15.0 | -717.6 | 15.1 | 277.8 | 12.9 | -678.6 | 1.7 | 165.4 |
| OPENS A LANE | 0.1 | +2.2 | 13.7 | 0.0 | - | - | - | - |
| OPENS UP | 0.4 | +32.9 | 25.2 | 0.0 | 0.4 | +37.3 | 26.6 | 25.4 |
| OVERRUNS AWAY | 0.6 | +9.5 | 53.8 | 2.6 | 0.7 | +21.4 | 52.9 | 26.1 |
| PATHS CROSS | 2.4 | +166.8 | 0.0 | 26.4 | 3.2 | +298.5 | 0.0 | 44.6 |
| PERIAPT WORTH | 0.1 | +6.8 | 0.0 | 15.0 | 0.1 | +9.7 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -0.2 | 0.0 | 1.9 | 0.1 | -0.8 | 0.0 | 1.5 |
| PLAN RESULT | 37.3 | +1460.7 | 1445.1 | 1069.4 | 39.6 | +1333.3 | 1650.6 | 1078.0 |
| PURSUES BIG PREY | 0.1 | -6.0 | 0.0 | 0.0 | 0.2 | -18.5 | 0.0 | 5.4 |
| PURSUES ON | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE | - | - | - | - | 0.0 | +4.9 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +6.3 | 0.0 | 2.2 | 0.2 | +20.6 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 1.1 | +16.6 | 0.0 | 38.6 | 1.8 | +31.3 | 0.0 | 66.0 |
| RANDOM MOVER NO PROMISE | 0.4 | -18.7 | 23.4 | 4.7 | 0.2 | -17.9 | 2.6 | 9.9 |
| REDIRECT BY WHAT IT STOPS | 0.2 | +0.6 | 0.0 | 2.0 | 0.3 | -14.7 | 0.0 | 6.4 |
| REDIRECT COUNTER | 2.0 | +129.8 | 0.0 | 19.8 | 4.2 | +358.4 | 0.0 | 65.7 |
| REDIRECT WEIGHED | 0.2 | +2.6 | 5.7 | 0.0 | 0.4 | +31.8 | 30.8 | 38.6 |
| RESERVE FALL BACK | 0.5 | +25.1 | 0.0 | 10.9 | 0.6 | +20.2 | 0.0 | 6.6 |
| RESTRAINS TO SHOOT | 0.1 | +9.3 | 0.0 | 10.3 | 0.2 | +4.0 | 0.0 | 3.4 |
| RISK BY ARC | 3.2 | +153.8 | 298.7 | 84.1 | 3.0 | +42.0 | 304.8 | 113.7 |
| SAFER THAN THE JOB | 1.1 | +76.5 | 0.0 | 42.8 | 0.3 | +23.8 | 0.0 | 4.9 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 3.7 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 3.7 |
| SCREEN BY WHAT IT SAVES | 0.0 | -1.3 | 0.0 | 0.0 | 0.3 | -15.5 | 0.0 | 0.8 |
| SEARCH SPOT | 2.3 | +79.2 | 0.0 | 36.9 | 3.7 | +165.6 | 0.0 | 47.3 |
| SECOND HUNTER | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | 0.2 | +52.0 | 0.0 | 0.0 | 0.4 | +10.4 | 0.0 | 36.2 |
| SET UP TOGETHER | 0.6 | +43.8 | 0.0 | 43.8 | 1.1 | +164.9 | 60.4 | 33.0 |
| SET-UP ANY TARGET | 0.6 | +77.0 | 19.0 | 18.6 | 0.1 | +17.3 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +17.1 | 9.0 | 2.4 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.3 | +0.8 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +32.1 | 19.8 | 13.8 | 0.7 | +31.6 | 22.9 | 23.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 3.8 |
| SHOT OPTIONS | 15.3 | +0.0 | 822.2 | 333.5 | 9.1 | +0.0 | 335.9 | 156.3 |
| SHOT REPLANNED | 0.4 | +0.0 | 128.2 | 14.6 | 0.4 | +0.0 | 65.4 | 0.0 |
| SHOTS IN THE MOVE | 14.1 | +704.9 | 0.0 | 295.7 | 7.8 | +241.0 | 0.0 | 97.1 |
| SPELL CATCH ODDS | 0.0 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.6 | +83.6 | 19.0 | 18.6 | 0.1 | +17.3 | 0.0 | 0.0 |
| SPELL WORTH | 1.4 | +24.8 | 51.9 | 76.4 | 2.6 | +47.1 | 37.6 | 37.6 |
| STABLE ROLE | 10.2 | +0.0 | 304.3 | 189.7 | 10.5 | +0.0 | 445.4 | 148.4 |
| STANDS TO CAST | 0.0 | +0.5 | 0.0 | 0.0 | 0.0 | +0.6 | 0.0 | 0.0 |
| STAY WEIGHED | 0.1 | +4.9 | 0.0 | 0.0 | - | - | - | - |
| STAY WORTH | - | - | - | - | 9.5 | +199.3 | 221.6 | 84.9 |
| STOPS | - | - | - | - | 0.1 | +6.0 | 30.5 | 0.8 |
| STOPS SHORT OF THE FLANK | 0.4 | +14.5 | 0.0 | 8.0 | 0.2 | +8.2 | 0.0 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 5.8 |
| SUPPORT JOB KEPT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT NARROWED | 5.6 | -47.0 | 310.2 | 81.0 | 8.5 | -64.3 | 496.0 | 127.5 |
| SUPPORTS | 3.6 | +51.6 | 143.8 | 37.3 | 5.8 | +66.3 | 193.2 | 58.1 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -2.7 | 3.4 | 13.4 | 0.1 | -6.8 | 8.9 | 0.0 |
| SURE REACH TOGETHER | 0.4 | +0.0 | 0.0 | 27.2 | 0.3 | -2.7 | 0.0 | 15.2 |
| THREAT IN THE KILL | 1.2 | +19.0 | 128.8 | 9.3 | 5.6 | +46.9 | 273.3 | 103.9 |
| THROUGH LINE OF FIRE | 0.4 | +13.3 | 0.0 | 11.1 | 0.3 | +9.2 | 0.0 | 8.1 |
| TURN WORTH | 0.6 | -50.9 | 51.8 | 2.4 | 0.7 | -65.4 | 62.7 | 27.4 |
| TWO OR MORE ARRIVE | 0.3 | +1.0 | 0.0 | 7.8 | 0.4 | +3.8 | 25.6 | 0.0 |
| WAIT AFTER COSTS | 7.0 | -266.6 | 141.6 | 133.1 | 7.3 | -339.3 | 329.4 | 141.3 |
| WALKS TO THE FIGHT | 1.8 | +30.2 | 12.3 | 43.8 | 0.9 | +18.1 | 30.3 | 4.9 |
| WAR ENGINE CHARGES | 0.1 | +10.3 | 8.5 | 18.9 | - | - | - | - |
| WAR ENGINE JOBS | 0.8 | +0.0 | 27.0 | 6.9 | 0.1 | +0.0 | 2.2 | 0.0 |
| WEARS DOWN | 1.2 | +45.3 | 121.8 | 54.4 | 1.6 | +44.0 | 127.6 | 89.1 |
| WHO HITS BACK | 0.3 | +25.3 | 0.0 | 1.4 | 0.3 | +17.4 | 0.0 | 5.1 |
| WHOLE FIGHT | 0.4 | +19.9 | 49.4 | 6.9 | 0.3 | +6.5 | 44.4 | 3.3 |
| WHOLE FIGHT GAIN | 0.3 | +30.5 | 37.5 | 7.3 | 0.7 | +63.1 | 39.0 | 8.2 |
| WIZARD FRONT RANK | - | - | - | - | 0.0 | +0.0 | 0.0 | 4.3 |
| WOUNDED STAYS OUT | - | - | - | - | 0.0 | +0.0 | 0.0 | 16.6 |

### Rule changes: shots-h2h-opp-7c46ffc-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1005 | 1005 | 1005 | 27.92 | -50264 | -50.0 |
| BEST FIRST | 280 | 280 | 280 | 7.78 | +10703 | +38.2 |
| SEARCH SPOT | 218 | 218 | 215 | 5.97 | +8817 | +41.0 |
| PATHS CROSS | 202 | 202 | 202 | 5.61 | +16753 | +82.9 |
| COUNTER-CHARGE COVER | 577 | 325 | 151 | 4.19 | +8310 | +55.0 |
| MOVE TO CHARGE | 277 | 277 | 141 | 3.92 | +7762 | +55.0 |
| KILLS COUNT NEXT TURN | 454 | 454 | 125 | 3.47 | +4294 | +34.4 |
| SUPPORTS | 338 | 338 | 112 | 3.11 | +1382 | +12.3 |
| FACES THE THREAT | 108 | 108 | 108 | 3.00 | +8619 | +79.8 |
| FOLLOW UP WEIGHED | 83 | 83 | 83 | 2.31 | +11978 | +144.3 |
| FALLBACK BY WORTH | 371 | 371 | 77 | 2.14 | +4923 | +63.9 |
| SHOTS IN THE MOVE | 785 | 520 | 69 | 1.92 | +3616 | +52.4 |
| RANDOM MOVE BY FIGURES | 103 | 103 | 62 | 1.72 | +1725 | +27.8 |
| WAIT AFTER COSTS | 517 | 517 | 59 | 1.64 | +943 | +16.0 |
| WALKS TO THE FIGHT | 96 | 96 | 58 | 1.61 | +709 | +12.2 |
| REDIRECT COUNTER | 225 | 144 | 57 | 1.58 | +4999 | +87.7 |
| ADVANCE LANE KEPT | 55 | 55 | 55 | 1.53 | +0 | +0.0 |
| CHARGE NOW FIRST | 213 | 213 | 53 | 1.47 | -3122 | -58.9 |
| SAFER THAN THE JOB | 53 | 53 | 53 | 1.47 | +3612 | +68.2 |
| RISK BY ARC | 225 | 220 | 50 | 1.39 | +2092 | +41.8 |
| BEST FACING | 45 | 45 | 45 | 1.25 | +1909 | +42.4 |
| MAX FOR POSITIONING | 349 | 195 | 43 | 1.19 | +468 | +10.9 |
| CANNON SIGHT KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| COMBAT PIVOT | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| RESERVE FALL BACK | 40 | 40 | 40 | 1.11 | +1633 | +40.8 |
| BLOCKED WHEEL | 39 | 39 | 39 | 1.08 | +883 | +22.6 |
| CHARGE NOW WEIGHED | 36 | 36 | 36 | 1.00 | +2392 | +66.5 |
| ARTILLERY RE-ROLL WEIGHED | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| KEEPS ITS TARGET | 143 | 142 | 35 | 0.97 | +567 | +16.2 |
| KILLS COUNT | 160 | 155 | 35 | 0.97 | +1336 | +38.2 |
| STAY WORTH | 342 | 270 | 33 | 0.92 | +606 | +18.4 |
| SHOT REPLANNED | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| THREAT IN THE KILL | 242 | 203 | 32 | 0.89 | +297 | +9.3 |
| BEST OVERALL | 31 | 31 | 31 | 0.86 | +2261 | +73.0 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| BEST MOVE FOR SHOOTERS | 26 | 26 | 26 | 0.72 | +1587 | +61.1 |
| SET UP TOGETHER | 64 | 55 | 26 | 0.72 | +3230 | +124.2 |
| CANNON PLANNED TARGET | 184 | 184 | 25 | 0.69 | -215 | -8.6 |
| STOPS SHORT OF THE FLANK | 24 | 24 | 24 | 0.67 | +818 | +34.1 |
| THROUGH LINE OF FIRE | 24 | 24 | 24 | 0.67 | +808 | +33.7 |
| WHOLE FIGHT GAIN | 38 | 34 | 24 | 0.67 | +1174 | +48.9 |
| INVITES THE FIGHT | 105 | 105 | 23 | 0.64 | +213 | +9.3 |
| REDIRECT WEIGHED | 23 | 23 | 23 | 0.64 | +1083 | +47.1 |
| MARCH ODDS | 22 | 22 | 22 | 0.61 | +482 | +21.9 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| MISSILES IN THE MOVE | 199 | 123 | 20 | 0.56 | +408 | +20.4 |
| WHO HITS BACK | 20 | 20 | 20 | 0.56 | +1000 | +50.0 |
| MARCH CHECK | 23 | 22 | 19 | 0.53 | +981 | +51.6 |
| SHOOTS FROM THE BEST SPOT | 50 | 50 | 19 | 0.53 | +625 | +32.9 |
| CAST JOB | 28 | 28 | 18 | 0.50 | +644 | +35.8 |
| SHOOTERS IN TWO RANKS | 18 | 18 | 18 | 0.50 | +41 | +2.3 |
| WEARS DOWN | 99 | 96 | 18 | 0.50 | +292 | +16.2 |
| CASTER AWAY FROM SCREEN | 17 | 17 | 17 | 0.47 | +0 | +0.0 |
| MOVE AND CAST | 15 | 15 | 15 | 0.42 | +720 | +48.0 |
| CHAFF PASSED | 14 | 14 | 14 | 0.39 | -37 | -2.6 |
| FRIENDS SHOTS CHECKED | 14 | 14 | 14 | 0.39 | +679 | +48.5 |
| STUCK PIVOT | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| FOCUS OVER TURNS | 18 | 18 | 13 | 0.36 | +346 | +26.6 |
| OPENS UP | 28 | 28 | 13 | 0.36 | +778 | +59.9 |
| CASTING BLOCK | 12 | 12 | 11 | 0.31 | +699 | +63.5 |
| MAKE SURE TOGETHER | 32 | 27 | 11 | 0.31 | +2190 | +199.1 |
| RESTRAINS TO SHOOT | 11 | 11 | 11 | 0.31 | +477 | +43.4 |
| BEST PREY | 49 | 49 | 10 | 0.28 | +303 | +30.3 |
| PURSUES BIG PREY | 10 | 10 | 10 | 0.28 | -882 | -88.2 |
| RAIDS THE BAGGAGE NEXT TURN | 10 | 10 | 10 | 0.28 | +530 | +53.0 |
| WAR ENGINE JOBS | 29 | 29 | 10 | 0.28 | -305 | -30.5 |
| BLOCKED CHARGE SKIPPED | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| BIG CHARACTER SAFETY | 8 | 8 | 8 | 0.22 | +16 | +2.0 |
| MANOEUVRE | 9 | 9 | 8 | 0.22 | +332 | +41.6 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| OVERRUNS AWAY | 45 | 43 | 7 | 0.19 | +140 | +19.9 |
| SUPPORT NARROWED | 508 | 508 | 7 | 0.19 | -45 | -6.4 |
| BACKUP TARGETS | 82 | 36 | 6 | 0.17 | +42 | +6.9 |
| HUNT IN PAIRS | 32 | 17 | 6 | 0.17 | +316 | +52.6 |
| KEEP FALLS | 6 | 6 | 6 | 0.17 | +216 | +36.1 |
| MISSILES NEXT TURN | 256 | 151 | 6 | 0.17 | +16 | +2.6 |
| SURE CHARGE BEATS ADVANCE | 6 | 6 | 6 | 0.17 | -342 | -56.9 |
| BEST PRIZE | 5 | 5 | 5 | 0.14 | -501 | -100.2 |
| NEEDED THERE | 7 | 7 | 5 | 0.14 | +0 | +0.0 |
| PERIAPT WORTH | 5 | 5 | 5 | 0.14 | +595 | +119.1 |
| PIVOT GUARDS FLANK | 5 | 5 | 5 | 0.14 | -37 | -7.5 |
| LOST CHARGE | 175 | 174 | 4 | 0.11 | +32 | +8.1 |
| MODEL FACING | 4 | 4 | 4 | 0.11 | +361 | +90.2 |
| WHOLE FIGHT | 26 | 26 | 4 | 0.11 | +282 | +70.5 |
| FACE THE CAST | 3 | 3 | 3 | 0.08 | +36 | +12.1 |
| HUNT ADVANCE | 8 | 8 | 3 | 0.08 | +61 | +20.5 |
| JOINT CHARGE PLAN | 11 | 11 | 3 | 0.08 | +513 | +171.0 |
| LONG SHOT | 41 | 40 | 3 | 0.08 | +105 | +35.0 |
| SURE REACH TOGETHER | 24 | 21 | 3 | 0.08 | +5 | +1.7 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.06 | +0 | +0.2 |
| CARRIES OUT SET-UP | 5 | 5 | 2 | 0.06 | -77 | -38.6 |
| DEFENSIVE FLOOR | 2 | 2 | 2 | 0.06 | +10 | +4.8 |
| EDGE GIVE GROUND | 12 | 12 | 2 | 0.06 | +14 | +7.2 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +48 | +24.2 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +29 | +14.4 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 13 | 13 | 2 | 0.06 | -192 | -96.2 |
| OPENS A LANE | 5 | 2 | 2 | 0.06 | +58 | +28.8 |
| STANDS TO CAST | 2 | 2 | 2 | 0.06 | -19 | -9.6 |
| STAY WEIGHED | 2 | 2 | 2 | 0.06 | +175 | +87.3 |
| STOPS | 5 | 5 | 2 | 0.06 | +100 | +50.2 |
| WAR ENGINE CHARGES | 4 | 4 | 2 | 0.06 | +67 | +33.7 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +37 | +37.4 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -6 | -6.0 |
| DEFENSIVE ARMY | 8 | 8 | 1 | 0.03 | -3 | -2.8 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +3 | +3.0 |
| RAIDS THE BAGGAGE | 1 | 1 | 1 | 0.03 | +165 | +164.6 |
| SUPPORT JOB KEPT | 1 | 1 | 1 | 0.03 | +87 | +87.1 |
| TWO OR MORE ARRIVE | 25 | 25 | 1 | 0.03 | +11 | +10.8 |
| WIZARD FRONT RANK | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.03 | -270 | -270.2 |
| ALREADY CARRIED | 4 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 22 | 22 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 41 | trace | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| CHARIOT NO STATIC JOB | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 12 | 12 | 0 | 0.00 | - | - |
| CHEAP HELPER | 6 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 37 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 410 | not checked | - | - | - | - |
| GIVES UP | 10 | 8 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 2 | 2 | 0 | 0.00 | - | - |
| GROUND FLIERS | 3 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 21 | 20 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 46 | 46 | 0 | 0.00 | - | - |
| HUNT KEPT | 4 | trace | - | - | - | - |
| HUNT RESULT | 9 | trace | - | - | - | - |
| HUNT THE GUNS | 9 | trace | - | - | - | - |
| KEEPS ITS PREY | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 21 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 6 | trace | - | - | - | - |
| MARCH OVER CASTS | 25 | 25 | 0 | 0.00 | - | - |
| MISSILES IN THE PLAN | 3 | not checked | - | - | - | - |
| MONSTER WIZARD ROAMS | 15 | 15 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 8 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 25 | trace | - | - | - | - |
| MOVE SPELL SPOT | 23 | not checked | - | - | - | - |
| NOT NEEDED | 24 | 24 | 0 | 0.00 | - | - |
| NOT TURNED | 435 | 435 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 36 | not checked | - | - | - | - |
| PLAN RESULT | 2766 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 23 | 23 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 18 | 18 | 0 | 0.00 | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 11 | 11 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 22 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 23 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SHOT OPTIONS | 879 | 879 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 24 | not checked | - | - | - | - |
| SPELL WORTH | 145 | not checked | - | - | - | - |
| STABLE ROLE | 748 | 746 | 0 | 0.00 | - | - |
| TURN WORTH | 48 | 47 | 0 | 0.00 | - | - |

### Off best figure: shots-h2h-opp-7c46ffc-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.42 | 11.50 | 51.5 |
| CHARGE NOW FIRST | rule | 0.69 | 0.78 | 58.9 |
| FALLBACK | gate | 0.39 | 0.72 | 47.1 |
| TURN GATE | gate | 0.67 | 0.36 | 27.9 |
| PATHS CROSS | rule | 0.19 | 0.25 | 9.6 |
| PURSUES BIG PREY | rule | 0.08 | 0.19 | 88.2 |
| WAR ENGINE JOBS | rule | 0.28 | - | 30.5 |
| LONE CHARACTER SAFE SPOT | gate | 0.17 | 0.08 | 80.2 |
| AFTERMATH BAND | gate | 0.11 | 0.11 | 2.6 |
| CANNON PLANNED TARGET | rule | 0.19 | - | 38.5 |
| SUPPORT NARROWED | rule | 0.06 | 0.14 | 6.4 |
| CHAFF PASSED | rule | 0.14 | 0.03 | 6.1 |
| SUPPORT REQUEST | gate | 0.08 | 0.08 | 55.5 |
| SURE CHARGE BEATS ADVANCE | rule | 0.11 | 0.06 | 56.9 |
| BEST PRIZE | rule | - | 0.14 | 100.2 |
| CHARGE NOW WEIGHED | rule | 0.11 | 0.03 | 81.3 |
| PIVOT GUARDS FLANK | rule | 0.06 | 0.08 | 7.5 |
| BIG CHARACTER SAFETY | rule | 0.08 | 0.03 | 3.7 |
| STOPS SHORT OF THE FLANK | rule | 0.08 | 0.03 | 3.7 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.03 | 0.06 | 18.5 |
| FIGHT ORDER BAND | gate | 0.06 | 0.03 | 1.4 |
| THROUGH LINE OF FIRE | rule | 0.03 | 0.06 | 3.8 |
| BLOCKED WHEEL | rule | 0.06 | - | 13.5 |
| CARRIES OUT SET-UP | rule | - | 0.06 | 38.6 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | 0.03 | 2.5 |
| LONE WIZARD HOLDS BACK | rule | 0.03 | 0.03 | 96.2 |
| REDIRECT WEIGHED | rule | - | 0.06 | 195.3 |
| RULE SWITCHED OFF | gate | 0.06 | - | 9.8 |
| STANDS TO CAST | rule | 0.03 | 0.03 | 9.6 |
| CATCH ODDS | rule | - | 0.03 | 6.0 |
| DEFENSIVE ARMY | rule | 0.03 | - | 2.8 |
| FALLBACK BY WORTH | rule | 0.03 | - | 15.9 |
| MARCH ODDS | rule | 0.03 | - | 17.3 |
| WHO HITS BACK | rule | 0.03 | - | 3.3 |
| WOUNDED STAYS OUT | rule | - | 0.03 | 270.2 |

### Plans: shots-h2h-opp-7c46ffc-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.8 | 16% | 353 | 287 | 81% |
| Mine | charge | 3.9 | 59% | 313 | 359 | 115% |
| Mine | close in | 4.6 | 26% | 259 | 107 | 41% |
| Mine | hold | 4.3 | 30% | 296 | 0 | 0% |
| Mine | join | 0.7 | 92% | 13 | 0 | 0% |
| Mine | shoot | 8.3 | 60% | 368 | 707 | 192% |
| Mine | support | 3.8 | 90% | 42 | 0 | 0% |
| Opponent | advance | 13.9 | 17% | 395 | 423 | 107% |
| Opponent | charge | 4.9 | 61% | 610 | 466 | 76% |
| Opponent | close in | 5.9 | 30% | 473 | 217 | 46% |
| Opponent | hold | 4.4 | 25% | 309 | 0 | 0% |
| Opponent | join | 0.5 | 94% | 21 | 0 | 0% |
| Opponent | shoot | 3.7 | 61% | 260 | 232 | 89% |
| Opponent | support | 6.3 | 89% | 39 | 0 | 0% |

### Packages: hunt the guns, shots-h2h-opp-7c46ffc-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 3 | 0 | 0% | 0% | 67% | - | 337 | 4 | 0% | 11 |
| Opponent | 0.2 | 6 | 0 | 50% | 67% | 0% | 2.8 | 344 | 122 | 50% | 95 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 579 | 0 | 0% | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 133 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.2 | 2 | 0 | 50% | 100% | 0% | 2.0 | 181 | 159 | 100% | 56 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 114 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 171 |
| Tomb Kings of Khemri | 0.5 | 2 | 0 | 0% | 0% | 100% | - | 216 | 5 | 0% | 0 |
| Vampire Counts | 0.4 | 3 | 0 | 67% | 67% | 0% | 3.5 | 360 | 138 | 33% | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 95 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 620 | 0 | 0% | 117 |

### Battle groups: shots-h2h-opp-7c46ffc-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 8.5 | 26% | 32% | 10% | 75% | 35% | 11% | 14% | 40% | 0% |
| Mine | REDIRECT COUNTER | 2.0 | 34% | 68% | 16% | 25% | 52% | 0% | 10% | 33% | 5% |
| Opponent | COUNTER-CHARGE COVER | 7.5 | 19% | 66% | 14% | 14% | 37% | 7% | 12% | 44% | 0% |
| Opponent | REDIRECT COUNTER | 4.2 | 21% | 78% | 16% | 20% | 19% | 0% | 0% | 78% | 4% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: shots-h2h-opp-7c46ffc-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 110 (4) | 110 | 0 | 100 | 0% | 3.2 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 34 | 22 (34) | 11 | 11 | 60 | 35% | 2.1 | 41 (14) | 0 (5) | 14 (15) | 18 (20) | 28 (14) |
| Mine | Character | 106 | 54 (106) | 54 | 0 | 38 | 14% | 2.4 | 69 (34) | 56 (46) | 29 (7) | 51 (45) | 66 (42) |
| Mine | Clean-up | 23 | 69 (23) | 37 | 32 | 52 | 17% | 2.5 | 0 (2) | 73 (17) | 87 (4) | 115 (11) | 40 (12) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast | 4 | 0 (4) | 0 | 0 | 73 | 50% | 3.0 | 0 (2) | 0 (2) | - | 0 (3) | 0 (1) |
| Mine | Fast Hammer | 40 | 24 (40) | 13 | 11 | 53 | 15% | 2.5 | 24 (25) | 27 (9) | 16 (6) | 29 (25) | 15 (15) |
| Mine | Fragile | 4 | 0 (4) | 0 | 0 | 46 | 25% | 2.7 | 0 (1) | 0 (3) | - | 0 (1) | 0 (3) |
| Mine | Hammer | 64 | 42 (64) | 31 | 11 | 58 | 17% | 2.6 | 19 (13) | 46 (42) | 56 (9) | 41 (39) | 44 (25) |
| Mine | Holder | 31 | 91 (31) | 10 | 81 | 22 | 29% | 2.9 | 68 (8) | 124 (17) | 24 (6) | 110 (20) | 61 (11) |
| Mine | Shooter | 35 | 47 (35) | 18 | 29 | 40 | 0% | 1.8 | 6 (8) | 74 (22) | 5 (5) | 37 (26) | 76 (9) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | War machine | 56 | 50 (56) | 50 | 0 | 57 | 2% | 1.3 | 46 (16) | 63 (30) | 18 (10) | 67 (9) | 47 (47) |
| Mine | Wizard | 17 | 7 (17) | 7 | 0 | 61 | 0% | 2.3 | 0 (5) | 14 (6) | 0 (1) | 0 (6) | 14 (6) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Chaff | 77 | 60 (77) | 24 | 35 | 50 | 38% | 2.8 | 68 (32) | 69 (18) | 42 (27) | 55 (58) | 78 (19) |
| Opponent | Character | 97 | 57 (97) | 56 | 1 | 34 | 25% | 2.2 | 58 (42) | 62 (39) | 48 (6) | 48 (49) | 72 (38) |
| Opponent | Clean-up | 12 | 65 (12) | 29 | 36 | 59 | 8% | 2.9 | 21 (4) | 72 (5) | 86 (3) | 43 (7) | 80 (5) |
| Opponent | Fast | 1 | 142 (1) | 142 | 0 | 0 | 0% | 5.0 | - | 142 (1) | - | 142 (1) | - |
| Opponent | Fast Hammer | 54 | 52 (54) | 34 | 18 | 46 | 30% | 2.9 | 60 (23) | 32 (23) | 84 (8) | 48 (33) | 58 (21) |
| Opponent | Fragile | 17 | 0 (17) | 0 | 0 | 66 | 18% | 2.5 | 0 (5) | 0 (8) | 0 (4) | 0 (14) | 0 (3) |
| Opponent | Hammer | 65 | 48 (65) | 30 | 18 | 37 | 28% | 3.1 | 11 (20) | 64 (38) | 20 (7) | 52 (41) | 42 (24) |
| Opponent | Holder | 30 | 51 (30) | 19 | 32 | 24 | 43% | 4.2 | 12 (9) | 75 (15) | 23 (5) | 75 (17) | 22 (12) |
| Opponent | Shooter | 34 | 61 (34) | 29 | 32 | 45 | 0% | 1.5 | 56 (10) | 67 (21) | 28 (3) | 71 (19) | 49 (15) |
| Opponent | Support | 6 | 41 (6) | 41 | 0 | 48 | 33% | 2.2 | 0 (1) | 0 (4) | 228 (1) | 0 (4) | 124 (2) |
| Opponent | War machine | 6 | 61 (6) | 61 | 0 | 21 | 17% | 1.0 | 61 (3) | 61 (3) | - | 61 (3) | 61 (3) |
| Opponent | Wizard | 20 | 10 (20) | 10 | 0 | 61 | 5% | 2.7 | 5 (10) | 5 (3) | 0 (2) | 0 (10) | 18 (5) |

### Charged fights: shots-h2h-opp-7c46ffc-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 151 | 224 | 2.2 | 1.0 | 100 | 38 | +62 | 3 of 9 | 5 of 9 | - | +62 |
| Mine | Chaos Dwarfs | 4 | 78 | 390 | 4.0 | 1.1 | 97 | 31 | +67 | 7 of 16 | 14 of 16 | +274 | +37 |
| Mine | Dwarfen Mountain Holds | 3 | 398 | 70 | 1.3 | 1.5 | 52 | 169 | -117 | 2 of 4 | 2 of 4 | -234 | +0 |
| Mine | Empire of Man | 5 | 429 | 196 | 1.4 | 1.4 | 140 | 262 | -122 | 2 of 7 | 4 of 7 | -68 | -143 |
| Mine | Grand Cathay | 4 | 156 | 337 | 4.0 | 1.2 | 84 | 14 | +71 | 5 of 16 | 12 of 16 | +82 | +68 |
| Mine | High Elf Realms | 4 | 357 | 540 | 4.5 | 1.1 | 120 | 0 | +120 | 3 of 18 | 15 of 18 | +0 | +135 |
| Mine | Kingdom of Bretonnia | 1 | 750 | 1031 | 6.0 | 1.2 | 172 | 0 | +172 | 2 of 6 | 6 of 6 | +0 | +206 |
| Mine | Lizardmen | 1 | 0 | 1289 | 7.0 | 1.3 | 184 | 154 | +30 | 5 of 7 | 5 of 7 | -233 | +135 |
| Mine | Ogre Kingdoms | 2 | 0 | 28 | 3.5 | 1.4 | 8 | 232 | -224 | 4 of 7 | 3 of 7 | -277 | -202 |
| Mine | Skaven | 2 | 192 | 206 | 3.0 | 1.0 | 68 | 22 | +47 | 1 of 6 | 4 of 6 | - | +47 |
| Mine | Tomb Kings of Khemri | 2 | 38 | 718 | 3.5 | 1.1 | 205 | 0 | +205 | 3 of 7 | 7 of 7 | +116 | +220 |
| Mine | Vampire Counts | 2 | 95 | 394 | 4.0 | 1.1 | 99 | 147 | -48 | 1 of 8 | 4 of 8 | -5 | -54 |
| Mine | Warriors of Chaos | 2 | 0 | 526 | 4.0 | 1.0 | 132 | 0 | +132 | 3 of 8 | 7 of 8 | - | +132 |
| **Mine** | all armies | 36 | 214 | 367 | 3.3 | 1.2 | 111 | 64 | +48 | 41 of 119 | 88 of 119 | -40 | +63 |
| Opponent | Empire of Man | 1 | 575 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 5 | 223 | 529 | 4.6 | 1.0 | 115 | 71 | +44 | 14 of 23 | 12 of 23 | +0 | +46 |
| Opponent | Lizardmen | 2 | 56 | 289 | 2.0 | 1.0 | 144 | 82 | +63 | 2 of 4 | 2 of 3 | - | +63 |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 266 | 3.3 | 1.2 | 80 | 61 | +19 | 4 of 10 | 8 of 10 | +160 | -16 |
| Opponent | Skaven | 4 | 124 | 138 | 1.5 | 1.0 | 92 | 20 | +72 | 4 of 6 | 4 of 6 | - | +72 |
| Opponent | Tomb Kings of Khemri | 2 | 155 | 884 | 4.5 | 1.3 | 196 | 0 | +196 | 5 of 9 | 7 of 9 | +402 | +94 |
| Opponent | Vampire Counts | 6 | 22 | 375 | 4.7 | 1.3 | 80 | 4 | +77 | 12 of 28 | 20 of 28 | +143 | +50 |
| Opponent | Warriors of Chaos | 7 | 31 | 674 | 4.6 | 1.0 | 147 | 17 | +130 | 17 of 32 | 21 of 32 | +1258 | +94 |
| Opponent | Wood Elf Realms | 6 | 66 | 384 | 4.7 | 1.2 | 82 | 14 | +69 | 8 of 28 | 21 of 28 | -32 | +90 |
| **Opponent** | all armies | 36 | 93 | 434 | 3.9 | 1.1 | 112 | 27 | +85 | 66 of 140 | 95 of 139 | +189 | +68 |

### Effective charges: shots-h2h-opp-7c46ffc-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 9 | 1 (net +330) | 0 | 3 (net -28) | 1 (net +151) | 0 | 3 (net -5) | 1 | 38% (3 of 8) |
| Mine | Chaos Dwarfs | 16 | 4 (net +15) | 0 | 1 (net +0) | 5 (net +192) | 1 (net +49) | 5 (net +0) | 0 | 6% (1 of 16) |
| Mine | Dwarfen Mountain Holds | 4 | 2 (net +0) | 0 | 0 | 1 (net -467) | 0 | 1 (net +0) | 0 | 0% (0 of 4) |
| Mine | Empire of Man | 7 | 0 | 0 | 2 (net -214) | 3 (net -238) | 1 (net +292) | 0 | 1 | 33% (2 of 6) |
| Mine | Grand Cathay | 16 | 2 (net +0) | 0 | 3 (net -36) | 1 (net +175) | 3 (net +36) | 7 (net +137) | 0 | 19% (3 of 16) |
| Mine | High Elf Realms | 18 | 2 (net +188) | 0 | 0 | 2 (net +106) | 6 (net +77) | 8 (net +138) | 0 | 0% (0 of 18) |
| Mine | Kingdom of Bretonnia | 6 | 0 | 1 (net +302) | 0 | 0 | 3 (net +52) | 2 (net +286) | 0 | 0% (0 of 6) |
| Mine | Lizardmen | 7 | 0 | 0 | 1 (net -29) | 2 (net -158) | 0 | 3 (net +57) | 1 | 17% (1 of 6) |
| Mine | Ogre Kingdoms | 7 | 0 | 0 | 2 (net -65) | 2 (net -110) | 0 | 1 (net -335) | 2 | 40% (2 of 5) |
| Mine | Skaven | 6 | 1 (net +0) | 0 | 0 | 2 (net -11) | 0 | 2 (net +46) | 1 | 0% (0 of 5) |
| Mine | Tomb Kings of Khemri | 7 | 0 | 0 | 1 (net +693) | 2 (net +174) | 1 (net +144) | 2 (net +125) | 1 | 17% (1 of 6) |
| Mine | Vampire Counts | 8 | 2 (net -306) | 0 | 1 (net +0) | 2 (net -64) | 1 (net -5) | 0 | 2 | 17% (1 of 6) |
| Mine | Warriors of Chaos | 8 | 1 (net +0) | 0 | 1 (net +0) | 2 (net +142) | 1 (net +607) | 2 (net +0) | 1 | 14% (1 of 7) |
| Opponent | High Elf Realms | 23 | 6 (net -126) | 0 | 2 (net +0) | 3 (net +218) | 2 (net +0) | 6 (net +125) | 4 | 11% (2 of 19) |
| Opponent | Lizardmen | 4 | 0 | 0 | 0 | 1 (net +458) | 0 | 0 | 3 | 0% (0 of 1) |
| Opponent | Orc & Goblin Tribes | 10 | 2 (net -42) | 0 | 2 (net +38) | 2 (net +160) | 0 | 1 (net +40) | 3 | 29% (2 of 7) |
| Opponent | Skaven | 6 | 0 | 0 | 2 (net +12) | 1 (net +0) | 0 | 2 (net +237) | 1 | 40% (2 of 5) |
| Opponent | Tomb Kings of Khemri | 9 | 1 (net +0) | 0 | 2 (net +318) | 4 (net +104) | 0 | 1 (net +540) | 1 | 25% (2 of 8) |
| Opponent | Vampire Counts | 28 | 5 (net -12) | 1 (net +0) | 7 (net +77) | 3 (net +105) | 6 (net +84) | 4 (net +114) | 2 | 27% (7 of 26) |
| Opponent | Warriors of Chaos | 32 | 4 (net +164) | 0 | 3 (net +104) | 1 (net +0) | 1 (net +110) | 15 (net +175) | 8 | 12% (3 of 24) |
| Opponent | Wood Elf Realms | 28 | 4 (net +68) | 0 | 5 (net +65) | 7 (net +58) | 4 (net +36) | 8 (net +97) | 0 | 18% (5 of 28) |

### Charged fights, damage counted: shots-h2h-opp-7c46ffc-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 15 | 317 | 299 | +10 | 102 | 120 | -18 | -5.8 |
| Mine | 50-54% | 1 | 277 | 92 | +302 | 302 | 0 | +302 | +109.0 |
| Mine | Effective (55-75%) | 15 | 279 | 224 | -6 | 109 | 95 | +14 | +5.1 |
| Mine | 76-89% | 25 | 304 | 186 | +11 | 151 | 125 | +26 | +8.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 36 | 247 | 192 | +78 | 127 | 48 | +79 | +32.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 17 | 442 | 89 | +107 | 123 | 40 | +83 | +18.7 |
| Mine | No odds | 10 | 290 | 219 | +41 | 173 | 121 | +52 | +17.8 |
| Mine | All fights | 119 | 303 | 195 | +48 | 131 | 84 | +48 | +15.7 |
| Opponent | Long shot (under 50%) | 22 | 293 | 305 | +1 | 136 | 114 | +22 | +7.6 |
| Opponent | 50-54% | 1 | 50 | 45 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Effective (55-75%) | 23 | 230 | 197 | +83 | 112 | 15 | +97 | +42.0 |
| Opponent | 76-89% | 22 | 345 | 235 | +117 | 127 | 22 | +105 | +30.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 37 | 342 | 195 | +153 | 173 | 22 | +151 | +44.3 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 13 | 528 | 129 | +58 | 89 | 27 | +61 | +11.6 |
| Opponent | No odds | 22 | 304 | 195 | +45 | 100 | 64 | +36 | +11.8 |
| Opponent | All fights | 140 | 326 | 212 | +85 | 129 | 42 | +87 | +26.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| shots-h2h-opp-7c46ffc-p4 | move | 462 | 96 (21%) | 73 (16%) | 65 (14%) | 301 (65%) |
| shots-h2h-opp-7c46ffc-p4 | objective | 376 | 56 (15%) | 43 (11%) | 53 (14%) | 267 (71%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

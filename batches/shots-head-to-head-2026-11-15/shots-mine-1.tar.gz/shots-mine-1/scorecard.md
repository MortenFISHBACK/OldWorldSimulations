# Doctrine scorecard: shots-h2h-mine-7c46ffc-p1

### Scorecard: shots-h2h-mine-7c46ffc-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 8 | 6 | 1 | 0 | 1 | 0 | 0 | 95 |
| L0102 | 6 | 1 | Opponent | no | 2 | 1 | 2 | 3 | 0 | 0 | 0 | 222 |
| L0118 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 322 |
| L0118 | 4 | 1 | Opponent | no | 1 | 2 | 3 | 5 | 0 | 0 | 0 | 68 |
| L0135 | 3 | 1 | Mine | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Opponent | no | 4 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 2 | 2 | 4 | 0 | 0 | 0 | 84 |
| L0218 | 2 | 1 | Opponent | - | - | 4 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 0 | 2 | 4 | 3 | 0 | 0 | 0 | 170 |
| L0235 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 5 | 2 | 2 | 0 | 0 | 0 | 0 | 985 |
| L0319 | 1 | 1 | Opponent | no | 1 | 2 | 4 | 0 | 1 | 0 | 0 | 260 |
| L0405 | 3 | 1 | Mine | yes | 6 | 2 | 7 | 2 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 4 | - | 1 | 0 | 0 | 0 | 0 | 1120 |
| L0421 | 1 | 1 | Mine | no | 0 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 0 | 4 | 0 | 0 | 0 | 355 |
| L0508 | 4 | 1 | Mine | no | 3 | 3 | 0 | 2 | 0 | 0 | 0 | 1092 |
| L0508 | 4 | 1 | Opponent | no | 1 | 5 | 2 | 2 | 0 | 0 | 0 | 560 |
| L0524 | 2 | 1 | Mine | - | - | 3 | 3 | 1 | 0 | 0 | 0 | 698 |
| L0524 | 2 | 1 | Opponent | - | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 2 | - | 1 | 2 | 0 | 0 | 0 | 700 |
| L0612 | 6 | 1 | Opponent | no | 6 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | 5 | 2 | 0 | 0 | 0 | 0 | 981 |
| L0628 | 4 | 1 | Opponent | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0717 | 3 | 1 | Mine | yes | 1 | 2 | 1 | 0 | 1 | 0 | 0 | 420 |
| L0717 | 3 | 1 | Opponent | yes | 8 | 2 | 2 | 0 | 3 | 0 | 0 | 184 |
| L0733 | 1 | 1 | Mine | no | 7 | 3 | 2 | 1 | 0 | 0 | 0 | 375 |
| L0733 | 1 | 1 | Opponent | no | 0 | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 679 |
| L0823 | 1 | 1 | Opponent | no | 7 | 2 | 1 | 3 | 3 | 0 | 0 | 70 |
| L0913 | 1 | 1 | Mine | no | 0 | - | 1 | 0 | 0 | 0 | 0 | 524 |
| L0913 | 1 | 1 | Opponent | no | 2 | 2 | 2 | 0 | 0 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 793 |
| L0930 | 6 | 1 | Opponent | no | 2 | 2 | 3 | 3 | 1 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 4 | 1 | 0 | 0 | 355 |
| L1114 | 4 | 1 | Mine | no | 6 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 500 |
| L1131 | 3 | 1 | Mine | no | 4 | - | 2 | 0 | 0 | 0 | 0 | 427 |
| L1131 | 3 | 1 | Opponent | no | 0 | 3 | 1 | 2 | 3 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 8 | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 3 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | yes | - | 3 | 2 | 0 | 0 | 0 | 0 | 302 |
| L1319 | 5 | 1 | Opponent | yes | - | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 3 | 4 | 0 | 0 | 1 | 0 | 0 | 317 |
| L1335 | 3 | 1 | Opponent | no | 0 | 3 | 3 | 3 | 0 | 0 | 0 | 251 |
| L1431 | 3 | 1 | Mine | yes | 9 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 0 | 5 | 1 | 0 | 2 | 0 | 0 | 460 |
| L1527 | 3 | 1 | Mine | yes | 9 | 4 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 0 | 2 | 6 | 2 | 1 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | yes | - | 3 | 1 | 1 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | yes | - | 1 | 3 | 5 | 0 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | no | 2 | 1 | 3 | 0 | 2 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Opponent | yes | 6 | 2 | 6 | 1 | 2 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | no | - | 3 | 1 | 1 | 1 | 0 | 0 | 90 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 8 | 1 | 0 | 0 | 0 | 70 |
| L1923 | 3 | 1 | Mine | yes | 4 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | no | 4 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2025 | 3 | 1 | Mine | yes | 1 | 2 | 3 | 1 | 1 | 0 | 0 | 955 |
| L2025 | 3 | 1 | Opponent | no | 5 | 4 | 8 | 3 | 0 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | yes | 10 | 4 | 2 | 1 | 1 | 0 | 0 | 500 |
| L2127 | 3 | 1 | Opponent | no | 0 | 2 | 1 | 2 | 1 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Opponent | yes | - | 2 | 5 | 2 | 4 | 0 | 0 | 1128 |
| L2335 | 1 | 1 | Mine | no | 0 | 2 | 2 | 0 | 1 | 0 | 0 | 72 |
| L2335 | 1 | 1 | Opponent | no | 2 | 2 | 4 | 3 | 1 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | 4 | 1 | 3 | 0 | 0 | 0 | 68 |
| L2531 | 5 | 1 | Opponent | yes | - | 5 | 0 | 2 | 1 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Mine | no | 1 | 1 | 9 | 3 | 0 | 0 | 0 | 60 |
| L2730 | 6 | 1 | Opponent | no | 4 | 4 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 6 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Opponent | no | 2 | 1 | 2 | 0 | 0 | 0 | 0 | 56 |
| **Average** | | | Mine | 32% | 3.3 | 2.7 | 2.5 | 0.9 | 0.2 | 0.0 | 0.0 | 330.5 |
| **Average** | | | Opponent | 21% | 2.2 | 2.5 | 2.9 | 1.9 | 0.7 | 0.0 | 0.0 | 175.0 |

### KPIs: shots-h2h-mine-7c46ffc-p1

Rules off - Opponent only: STAY WORTH, BEST MOVE FOR SHOOTERS, THREAT IN THE KILL, FOCUS OVER TURNS, MISSILES IN THE PLAN, FACE THE CAST, WIZARD FRONT RANK.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 28% (49 of 173) | 3% (5 of 177) | 15% (54 of 350) |
| Winner chose to follow up after the loser gave ground |  | 95% (76 of 80); on the table 98% | 98% (62 of 63); on the table 98% | 97% (138 of 143); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 90% (18 of 20); on the table 90% | 85% (17 of 20); on the table 85% | 88% (35 of 40); on the table 88% |
| Winner chose to pursue after the loser fled |  | 59% (16 of 27); on the table 67% | 78% (25 of 32); on the table 78% | 69% (41 of 59); on the table 73% |
| Winner chose to follow up or pursue (all three) |  | 87% (110 of 127); on the table 90% | 90% (104 of 115); on the table 90% | 88% (214 of 242); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 37% (121 of 330) | 34% (71 of 210) | 36% (192 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 52% (121 of 231) | 49% (65 of 132) | 51% (186 of 363) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 27% (41 of 150) | 20% (17 of 84) | 25% (58 of 234) |
|     round 1 |  | 12% (3 of 25) | 14% (2 of 14) | 13% (5 of 39) |
|     rounds 2+ |  | 30% (38 of 125) | 21% (15 of 70) | 27% (53 of 195) |
|   other wizards | 50%+ | 44% (80 of 180) | 40% (48 of 120) | 43% (128 of 300) |
|     round 1 |  | 33% (10 of 30) | 35% (7 of 20) | 34% (17 of 50) |
|     rounds 2+ |  | 47% (70 of 150) | 41% (41 of 100) | 44% (111 of 250) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 61% (17 of 28) | 61% (28 of 46) | 61% (45 of 74) |
| Points that never fought | lower | 35% (25219 of 71484) | 36% (25638 of 71889) | 35% (50857 of 143373) |
|   infantry points that never fought | lower | 43% (7272 of 16863) | 56% (7463 of 13348) | 49% (14735 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 44% (123 of 279) | 60% (176 of 295) | 52% (299 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 95% (21 of 22); 2.1 uses a game | 80% (16 of 20); 1.7 uses a game | 88% (37 of 42); 1.9 uses a game |
| Bound items with another spell used |  | 75% (12 of 16); 0.7 uses a game | 25% (2 of 8); 0.1 uses a game | 58% (14 of 24); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 47% (9 of 19); 0.2 uses a game | 50% (6 of 12); 0.2 uses a game | 48% (15 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 39% (23146 of 59666) | 55% (34711 of 62699) | 47% (57857 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.0 (35%) | 1.1 (27%) | 3.1 (32%) |
| MARCHED: its unit marched | 0.9 (15%) | 0.5 (12%) | 1.4 (14%) |
| CHARGED: its unit charged | 0.1 (1%) | 0.1 (4%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 1.7 (30%) | 0.7 (19%) | 2.4 (25%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (1%) | 0.1 (3%) | 0.2 (2%) |
| GONE: slain | 0.9 (15%) | 0.9 (24%) | 1.8 (19%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.2 (6%) | 0.3 (3%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.1 (4%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.1 | 1.4 | 1.5 | 5.3 | 0.4 | 2.0 |
| not cast | 3.9 | 3.0 | 3.2 | 9.7 | 1.9 | 22.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.8 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.0 (33%) | 0.2 (7%) | 3.1 (32%) | 0.6 (29%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.4 (14%) | 0.2 (12%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.1 (4%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (6%) | 0.4 (13%) | 0.4 (14%) | 2.4 (25%) | 0.5 (28%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.3 (11%) | 0.3 (11%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (4%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (1%) | 0.4 (2%) |
| GONE: slain | 1.3 (33%) | 0.7 (22%) | 0.6 (19%) | 1.8 (19%) | 0.1 (7%) | 3.0 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.1 (4%) | 0.1 (4%) | 0.3 (3%) | 0.0 (0%) | 0.2 (1%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.2 (6%) | 0.0 (0%) | 0.1 (1%) | 0.3 (16%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (51%) | 0.3 (9%) | 1.4 (46%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.4 (74%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.4 a game | 0.4 a game | 0.9 a game |
| stood (cast and not dispelled) | 64% (28 of 44) | 64% (9 of 14) | 64% (37 of 58) |
| the unit moved after it | 57% (16 of 28) | 56% (5 of 9) | 57% (21 of 37) |
| it charged on its next turn | 0% (0 of 28) | 0% (0 of 9) | 0% (0 of 37) |
| the enemy charged it first | 18% (5 of 28) | 22% (2 of 9) | 19% (7 of 37) |
| it fought by the end of its next turn | 18% (5 of 28) | 11% (1 of 9) | 16% (6 of 37) |
| it moved out of a charge the enemy had planned (not charged first) | 18% (5 of 28) | 0% (0 of 9) | 14% (5 of 37) |
| none of these (no charge, no fight, no charge escaped) | 61% (17 of 28) | 78% (7 of 9) | 65% (24 of 37) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (573 of 912) | 56% (332 of 592) | 60% (905 of 1504) |
|   cavalry | 61% (43 of 71) | 65% (78 of 120) | 63% (121 of 191) |
|   character | 47% (50 of 107) | 28% (33 of 116) | 37% (83 of 223) |
|   chariot | 48% (44 of 92) | 70% (21 of 30) | 53% (65 of 122) |
|   infantry | 61% (189 of 310) | 55% (128 of 233) | 58% (317 of 543) |
|   monster | 59% (23 of 39) | 47% (15 of 32) | 54% (38 of 71) |
|   war machine | 76% (224 of 293) | 93% (57 of 61) | 79% (281 of 354) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (18%) | 1.9 (27%) | 3.6 (22%) |
| CHARGED: it charged | 1.2 (13%) | 1.2 (17%) | 2.4 (15%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 1.1 (12%) | 0.6 (8%) | 1.7 (10%) |
| HELD FIRE: a target, but it held its fire | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 1.5 (16%) | 1.6 (23%) | 3.2 (19%) |
| ONLY IN COMBAT: the only targets were in combat | 0.8 (8%) | 0.3 (4%) | 1.0 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.2 (24%) | 1.1 (15%) | 3.3 (20%) |
| SHELTERED: the target was sheltered | 0.4 (4%) | 0.4 (5%) | 0.8 (5%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |
| OTHER BAR | 0.3 (3%) | 0.1 (1%) | 0.4 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.9 | 1.2 | 82% | 4.7 pts | 23 pts |
| character | 2.8 | 0.8 | 79% | 7.7 pts | 21 pts |
| chariot | 1.8 | 1.4 | 64% | 18.3 pts | 34 pts |
| infantry | 12.9 | 5.1 | 72% | 9.4 pts | 121 pts |
| monster | 1.3 | 0.2 | 85% | 4.5 pts | 6 pts |
| war machine | 7.8 | 6.6 | 61% | 25.6 pts | 200 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.9 | 5.6 | 5.2 |
| Charges that made contact a game | 4.0 | 3.7 | 3.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.91 contact (22 units) | 0.43 declared, 0.14 contact (14 units) | 0.78 declared, 0.61 contact (36 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.14 declared, 0.71 contact (7 units) | 1.22 declared, 1.00 contact (9 units) | 1.19 declared, 0.88 contact (16 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.58 declared, 0.47 contact (252 units) | 0.64 declared, 0.43 contact (286 units) | 0.61 declared, 0.45 contact (538 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 53% (37 of 70) | 52% (11 of 21) | 25% (2 of 8) | 51% (50 of 99) |
| Character in a unit | 68% (21 of 31) | 63% (12 of 19) | 100% (4 of 4) | 69% (37 of 54) |
| Character on its own | 77% (43 of 56) | 44% (18 of 41) | 26% (16 of 62) | 48% (77 of 159) |
| Chariot | 44% (7 of 16) | 50% (5 of 10) | - | 46% (12 of 26) |
| Infantry | 52% (46 of 89) | 36% (13 of 36) | 0% (0 of 2) | 46% (59 of 127) |
| Monster | 53% (17 of 32) | 80% (8 of 10) | - | 60% (25 of 42) |
| Monstrous | 55% (6 of 11) | 36% (5 of 14) | - | 44% (11 of 25) |
| War Machines | 66% (27 of 41) | 100% (1 of 1) | - | 67% (28 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 88% (22 of 25); on the table 92% | 53% (73 of 138) | 43% | 45% (15 of 33) | 100% (9 of 9); 6.5 uses a game | 100% (3 of 3); 2.2 uses a game | 78% (7 of 9); 1.2 uses a game |
| Chaos Dwarfs | 3 | 60% (6 of 10); on the table 60% | 25% (6 of 24) | 31% | 50% (12 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |
| Dwarfen Mountain Holds | 5 | 100% (10 of 10); on the table 100% | - | 43% | 59% (24 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 83% (10 of 12); on the table 92% | 50% (18 of 36) | 49% | 52% (33 of 64) | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 5 | 89% (25 of 28); on the table 89% | 21% (23 of 108) | 41% | 27% (12 of 44) | 100% (12 of 12); 8.6 uses a game | 100% (1 of 1); 0.2 uses a game | 0% (0 of 5); 0.0 uses a game |
| High Elf Realms | 6 | 82% (18 of 22); on the table 91% | 30% (9 of 30) | 33% | 37% (18 of 49) | 100% (5 of 5); 2.7 uses a game | 50% (9 of 18); 2.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | - | - | 61% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 80% (4 of 5); on the table 80% | - | 33% | 64% (9 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 100% (7 of 7); on the table 100% | 17% (2 of 12) | 57% | 67% (14 of 21) | 67% (2 of 3); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (9 of 9); on the table 100% | 6% (2 of 36) | 5% | 58% (14 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Skaven | 4 | 100% (14 of 14); on the table 100% | 47% (14 of 30) | 26% | 44% (15 of 34) | 100% (3 of 3); 2.2 uses a game | 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| Tomb Kings of Khemri | 6 | 89% (32 of 36); on the table 89% | 0% (0 of 12) | 30% | 27% (8 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 90% (27 of 30); on the table 90% | 39% (21 of 54) | 30% | 70% (35 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 92% (22 of 24); on the table 92% | 37% (11 of 30) | 33% | 66% (49 of 74) | 100% (4 of 4); 2.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 80% (8 of 10); on the table 80% | 43% (13 of 30) | 33% | 55% (36 of 66) | 33% (2 of 6); 1.2 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (shots-h2h-mine-7c46ffc-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 52% (38) | 37% (30) | 44% (68) |
| ...free all their last turn and able to turn (per game) | 0.47 | 0.44 | 0.92 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.14 | 0.47 |
| ...with the charger already in that arc before they moved (per game) | 0.28 | 0.28 | 0.56 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.06 | 1.47 | 2.53 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.78 | 0.83 | 1.61 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.03 | 5.39 | 10.42 |

### Quality by phase: shots-h2h-mine-7c46ffc-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 59% (89 of 152) | 40% (76 of 188) |
| Strategy | Shoot objectives carried out (shot that target) | 45% (185 of 413) | 60% (107 of 179) |
| Strategy | Close-in objectives charged next turn | 12% (15 of 122) | 12% (26 of 214) |
| Strategy | Support requests answered (helper made contact too) | 56% (9 of 16) | 52% (13 of 25) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (4 of 4) | 0% (0 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 67% (8 of 12) | 50% (6 of 12) |
| Strategy | Joined characters whose unit fought | 43% (20 of 46) | 52% (17 of 33) |
| Strategy | Lone characters that fought | 79% (79 of 100) | 81% (83 of 103) |
| Movement | Charges halted short of contact | 0.0 | 0.1 |
| Movement | Idle units | 0.9 | 1.9 |
| Movement | Points that never moved of their own | 330.5 | 175.0 |
| Movement | Fights charged into per game | 3.2 | 3.1 |
| Movement | Charges with odds: long shots (under 50%) | 18 of 106, net +119 | 26 of 97, net +1 |
| Movement | Charges with odds: sweet spot (55-75%) | 14 of 106, net +123 | 7 of 97, net +89 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 15 of 106, net +73 | 3 of 97, net +56 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 42 of 106, net +83 | 41 of 97, net +185 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.7 | 8.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 41% (159 of 384) | 43% (131 of 306) |
| Shooting | Points destroyed by shooting units | 64.3 | 42.7 |
| Shooting | War machine shots | 6.2 | 1.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 40% (89 of 224) | 35% (20 of 57) |
| Shooting | Points destroyed by war machines | 110.1 | 15.3 |
| Magic | Magic missiles cast | 2.2 | 1.4 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 44% (34 of 78) | 24% (12 of 49) |
| Magic | Wounds caused by magic missiles | 4.4 | 2.4 |
| Magic | Wounds caused by other spells | 2.2 | 0.8 |
| Magic | Points destroyed by magic (all spells) | 135.1 | 37.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.6 / 0.4 / 1.0 / 0.1 | 1.4 / 0.5 / 0.5 / 0.1 |
| Combat | Points destroyed in combat | 426.1 | 349.1 |
| Combat | Points run down | 61.9 | 179.9 |
| Combat | Net points per charged fight, damage counted | +85 | +80 |
| Combat | Net per 100 charger points, damage counted | +29.5 | +31.3 |
| Combat | First round won (charged fights) | 79% | 56% |
| Combat | Net points per charged fight | +87 | +86 |
| Combat | Net points per supported fight / lone fight | +106 / +82 | +127 / +78 |
| Combat | Charged fights on a top-3 enemy unit | 49 of 116 | 61 of 113 |
| Game | Points lost | 660.6 | 863.7 |
| Game | VP from objectives | 661.7 | 619.4 |
| Game | Lone holders (player turns) | 3.3 | 2.2 |

- Mine won / drew / lost: 17 / 8 / 11 of 36 ended games (of 36); mean margin (Mine - Opponent) +245 VP
- The side that went first won 13 of 28 games with a winner
- Points traded per game (both sides' losses): 1524
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: shots-h2h-mine-7c46ffc-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 1.8 | 0.8 | +0.0 | 0.0 | 3.5 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 3.6 | - | - | - | - |
| ARRIVAL HUNT | 0.0 | +0.1 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.2 | +0.0 | 0.0 | 6.5 | 0.2 | +0.0 | 0.0 | 3.6 |
| BACKUP TARGETS | 0.9 | +10.2 | 0.0 | 20.7 | 0.9 | +7.5 | 0.0 | 12.0 |
| BEST FACING | 0.4 | +14.5 | 0.0 | 11.9 | 0.7 | +22.8 | 0.0 | 8.4 |
| BEST FIRST | 3.6 | +178.3 | 158.8 | 34.0 | 3.8 | +166.0 | 73.8 | 46.4 |
| BEST MOVE FOR SHOOTERS | 1.1 | +85.0 | 0.0 | 16.4 | - | - | - | - |
| BEST OVERALL | 0.3 | +9.5 | 0.0 | 0.0 | 0.5 | +48.9 | 0.0 | 8.3 |
| BEST PREY | 0.9 | +69.4 | 76.5 | 21.8 | 1.2 | +55.4 | 30.4 | 19.9 |
| BEST PRIZE | 0.1 | +1.2 | 6.5 | 0.0 | 0.0 | -7.5 | 0.0 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | -0.2 | 0.0 | 11.2 | 0.1 | +0.7 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 2.9 | 0.0 | - | - | - | - |
| BLOCKED WHEEL | 0.2 | +11.7 | 0.0 | 0.0 | 0.4 | +5.6 | 0.0 | 13.8 |
| CANNON PLAN MISSED | 0.7 | +0.0 | 102.6 | 9.0 | 0.1 | +0.0 | 6.5 | 0.0 |
| CANNON PLANNED TARGET | 4.9 | +153.6 | 407.6 | 57.4 | 1.5 | +34.1 | 46.4 | 12.4 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 3.5 | 0.4 | +0.0 | 0.0 | 7.2 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 0.0 | 6.5 | 0.0 | +0.0 | 10.2 | 15.0 |
| CARRIES OUT SET-UP | 0.1 | -2.1 | 5.1 | 4.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 1.0 | +43.9 | 81.1 | 10.6 | 0.3 | +9.5 | 13.1 | 15.2 |
| CASTER AWAY FROM SCREEN | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +72.5 | 31.5 | 9.6 | 0.2 | +8.4 | 3.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 44.9 | 0.3 | +0.0 | 0.0 | 15.2 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | - | - | - | - | 0.0 | +0.3 | 0.0 | 0.0 |
| CATCH ODDS | 0.0 | +4.2 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.4 | -1.1 | 0.0 | 0.0 | 0.2 | -0.1 | 0.0 | 0.0 |
| CHAMPION TAKES THE CHALLENGE | 0.0 | +0.0 | 11.9 | 0.0 | - | - | - | - |
| CHARGE NOW FIRST | 3.4 | +0.0 | 375.1 | 54.3 | 2.7 | +0.0 | 201.5 | 110.1 |
| CHARGE NOW WEIGHED | 0.4 | -24.1 | 6.8 | 27.3 | 0.5 | -37.9 | 26.2 | 1.9 |
| CHARIOT WIZARD CAREFUL | 0.1 | -1.9 | 7.1 | 0.0 | 0.1 | -0.8 | 0.0 | 0.0 |
| CHEAP HELPER | 0.0 | +0.0 | 0.0 | 1.7 | 0.2 | +0.0 | 6.9 | 4.8 |
| COMBAT PIVOT | 0.5 | +0.0 | 46.6 | 21.8 | 0.2 | +0.0 | 11.9 | 28.1 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 0.0 | 5.4 |
| CONVEYANCE SEARCH | 0.8 | +53.2 | 21.1 | 28.3 | 0.3 | +45.3 | 31.9 | 15.2 |
| COUNTER-CHARGE COVER | 9.6 | +711.3 | 0.0 | 139.9 | 6.9 | +710.4 | 0.0 | 119.9 |
| DEFENSIVE ARMY | 0.5 | +0.0 | 62.6 | 5.1 | - | - | - | - |
| DEFENSIVE FLOOR | 0.1 | +2.5 | 7.2 | 8.2 | 0.0 | +0.1 | 0.0 | 3.0 |
| EDGE GIVE GROUND | 0.1 | +0.8 | 13.7 | 0.0 | 0.1 | +7.9 | 23.6 | 0.0 |
| ELIXIR WORTH | 0.0 | +0.4 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACE THE CAST | 0.1 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.1 | +71.0 | 0.0 | 51.6 | 1.5 | +146.5 | 0.0 | 24.0 |
| FALLBACK BY WORTH | 4.5 | +66.8 | 0.0 | 64.5 | 5.7 | +72.2 | 0.0 | 55.5 |
| FIGHT LIFT | 0.1 | +0.9 | 0.0 | 9.9 | - | - | - | - |
| FIRE AND FLEE | 0.0 | +0.1 | 0.0 | 1.7 | - | - | - | - |
| FLANK NOT WEIGHED | 4.8 | +0.0 | 0.0 | 103.6 | 5.8 | +0.0 | 0.0 | 173.2 |
| FOCUS FIRE | 0.1 | +1.8 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| FOCUS OVER TURNS | 2.4 | +57.9 | 150.1 | 50.1 | - | - | - | - |
| FOLLOW UP WEIGHED | 1.1 | +154.5 | 0.0 | 46.5 | 1.2 | +205.6 | 0.0 | 52.5 |
| FRIENDS SHOTS CHECKED | 0.3 | +35.0 | 0.0 | 5.7 | 0.1 | +17.5 | 0.0 | 12.1 |
| GIVES UP | 0.1 | -1.0 | 4.9 | 1.4 | 0.1 | -3.1 | 13.9 | 1.4 |
| GIVES UP ITS SCREEN | 0.0 | -0.0 | 6.3 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 6.5 | 2.6 |
| HELPER UNSEEN | 0.2 | +0.0 | 25.5 | 7.2 | 0.3 | +0.0 | 15.1 | 3.2 |
| HILL BY ITS CHANCE | - | - | - | - | 0.2 | -28.8 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +0.4 | 0.0 | 0.0 | 0.3 | +10.1 | 2.6 | 11.3 |
| HUNT DROPPED | 0.0 | +0.0 | 7.6 | 0.0 | 0.1 | +0.0 | 0.0 | 8.0 |
| HUNT IN PAIRS | 0.3 | +32.9 | 0.0 | 15.1 | 0.4 | +27.6 | 0.0 | 5.4 |
| HUNT KEPT | 0.1 | +0.0 | 10.6 | 0.0 | 0.1 | +0.0 | 2.8 | 4.5 |
| HUNT RESULT | 0.1 | +5.5 | 7.6 | 0.0 | 0.4 | +10.8 | 6.4 | 19.3 |
| HUNT THE GUNS | 0.1 | +14.6 | 0.0 | 0.0 | 0.4 | +128.8 | 2.6 | 12.9 |
| INVITES THE FIGHT | 1.9 | +52.4 | 102.1 | 66.0 | 1.7 | +28.7 | 43.8 | 25.4 |
| JOINT CHARGE PLAN | - | - | - | - | 0.1 | +7.6 | 0.0 | 0.0 |
| KEEP FALLS | 0.1 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | - | - | - | - | 0.1 | +0.6 | 1.8 | 0.0 |
| KEEPS ITS TARGET | 1.3 | +40.0 | 122.4 | 18.1 | 2.0 | +59.2 | 120.2 | 55.6 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.9 | +74.1 | 168.1 | 39.8 | 2.2 | +101.5 | 145.0 | 67.4 |
| KILLS COUNT NEXT TURN | 4.1 | +138.0 | 151.9 | 58.2 | 6.9 | +295.5 | 207.1 | 173.3 |
| LONE CHARACTER SAFE SPOT | 0.5 | +16.8 | 8.1 | 2.5 | 0.6 | +10.7 | 35.0 | 16.8 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.4 | +0.0 | 40.6 | 20.6 |
| LONE WIZARD KEPT IN | 0.7 | +49.1 | 0.0 | 0.0 | 0.2 | +24.5 | 0.0 | 0.0 |
| LONG SHOT | 0.5 | -6.8 | 41.6 | 24.8 | 0.5 | -1.0 | 8.8 | 10.5 |
| LOST CHARGE | 2.6 | -32.8 | 133.8 | 78.5 | 3.2 | -48.8 | 56.8 | 77.8 |
| LURE BY WHAT IT DRAWS | 0.1 | +0.0 | 0.0 | 0.0 | 0.0 | -2.8 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.4 | +28.2 | 0.0 | 3.2 | 0.5 | +90.5 | 21.8 | 7.1 |
| MANOEUVRE | 0.2 | +7.1 | 0.0 | 0.0 | 0.1 | +0.7 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.8 | 0.0 | 20.6 | - | - | - | - |
| MARCH CHECK | 0.5 | +35.2 | 0.0 | 5.5 | 0.7 | +46.6 | 0.0 | 0.0 |
| MARCH ODDS | 0.3 | +40.4 | 21.7 | 10.9 | 0.2 | +14.3 | 1.8 | 4.4 |
| MARCH OVER CASTS | 0.3 | +26.3 | 0.0 | 25.7 | 0.2 | +19.2 | 0.0 | 8.8 |
| MAX FOR POSITIONING | 4.3 | +185.2 | 0.0 | 89.8 | 4.2 | +151.1 | 0.0 | 65.4 |
| MISSILES IN THE MOVE | 4.6 | +243.8 | 0.0 | 47.1 | 3.8 | +82.0 | 0.0 | 65.6 |
| MISSILES IN THE PLAN | 1.6 | +27.1 | 122.0 | 0.0 | - | - | - | - |
| MISSILES NEXT TURN | 5.0 | +151.1 | 0.0 | 73.8 | 4.2 | +57.8 | 0.0 | 72.2 |
| MODEL FACING | 0.2 | +82.2 | 0.0 | 1.7 | - | - | - | - |
| MONSTER WIZARD ROAMS | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 6.5 | 0.0 |
| MOVE AND CAST | 0.3 | +22.6 | 0.0 | 21.7 | 0.3 | +24.8 | 0.0 | 12.0 |
| MOVE SPELL IN RANGE | 0.1 | +5.3 | 0.0 | 0.0 | 0.1 | +1.2 | 0.0 | 15.2 |
| MOVE SPELL NOT WORTH | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.2 | -38.5 | 0.0 | 23.3 | 0.1 | -4.9 | 0.0 | 7.6 |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 12.6 | 0.1 | +0.0 | 0.0 | 12.3 |
| MOVE TO CHARGE | 2.4 | +151.0 | 43.7 | 46.1 | 4.6 | +477.4 | 140.4 | 111.1 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +18.6 | 7.1 | 0.0 | 0.2 | +15.2 | 23.5 | 21.0 |
| NOT NEEDED | 0.2 | -5.6 | 17.3 | 5.4 | 0.4 | -26.9 | 43.6 | 9.3 |
| NOT TURNED | 5.0 | +110.9 | 0.0 | 100.3 | 5.4 | +69.5 | 0.0 | 125.8 |
| NOT WORTH A CAST | 0.8 | -0.7 | 0.0 | 23.5 | 0.2 | -0.3 | 0.0 | 15.2 |
| OFF BEST | 15.8 | -795.2 | 6.8 | 273.9 | 15.7 | -923.9 | 13.0 | 323.9 |
| OPENS A LANE | 0.2 | +0.3 | 13.8 | 15.5 | 0.0 | +0.1 | 2.3 | 0.0 |
| OPENS UP | 0.3 | +29.2 | 13.8 | 0.0 | 0.2 | +9.9 | 8.8 | 13.3 |
| OVERRUNS AWAY | 0.4 | +21.1 | 48.5 | 14.4 | 0.8 | +9.1 | 45.1 | 19.7 |
| PATHS CROSS | 2.1 | +135.3 | 0.0 | 20.2 | 2.4 | +203.7 | 0.0 | 28.3 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +1.5 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -0.9 | 0.0 | 7.1 | 0.2 | -3.4 | 0.0 | 2.9 |
| PLAN RESULT | 37.9 | +1673.7 | 1461.8 | 806.1 | 37.6 | +1021.7 | 1249.1 | 1060.1 |
| PURSUES BIG PREY | 0.1 | -9.4 | 0.0 | 14.8 | 0.1 | -12.4 | 0.0 | 7.4 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.0 | +4.9 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | - | - | - | - | 0.1 | +7.3 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.8 | +10.5 | 0.0 | 8.1 | 1.3 | +12.7 | 0.0 | 60.8 |
| RANDOM MOVER NO PROMISE | 0.2 | -10.9 | 4.4 | 0.0 | 0.3 | -25.7 | 0.0 | 24.0 |
| REDIRECT BY WHAT IT STOPS | 0.1 | +0.6 | 0.0 | 1.1 | 0.3 | -8.1 | 0.0 | 5.7 |
| REDIRECT COUNTER | 2.0 | +144.5 | 0.0 | 37.3 | 4.0 | +392.0 | 0.0 | 70.8 |
| REDIRECT WEIGHED | 0.1 | +6.6 | 7.8 | 0.0 | 0.5 | -2.6 | 3.4 | 9.3 |
| RESERVE FALL BACK | 0.4 | +9.0 | 0.0 | 9.4 | 0.9 | +28.3 | 0.0 | 25.5 |
| RESTRAINS TO SHOOT | 0.2 | +2.7 | 0.0 | 7.2 | 0.1 | +4.8 | 0.0 | 3.1 |
| RISK BY ARC | 2.7 | +97.0 | 258.4 | 78.4 | 3.4 | +82.7 | 195.8 | 120.9 |
| SAFER THAN THE JOB | 0.8 | +31.6 | 0.0 | 6.5 | 0.8 | +40.8 | 0.0 | 16.1 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 1.9 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 1.9 |
| SCREEN BY WHAT IT SAVES | 0.2 | -15.1 | 0.0 | 0.0 | 0.3 | -0.6 | 0.0 | 3.3 |
| SEARCH SPOT | 2.6 | +110.1 | 0.0 | 25.8 | 2.9 | +164.8 | 0.0 | 25.6 |
| SELF MOVE SPELL | 0.2 | +24.8 | 0.0 | 18.1 | 0.2 | +0.1 | 0.0 | 27.2 |
| SET UP TOGETHER | 0.6 | +68.2 | 0.0 | 8.4 | 1.4 | +228.6 | 28.3 | 9.0 |
| SET-UP ANY TARGET | 0.4 | +40.3 | 3.1 | 7.2 | 0.1 | +15.8 | 0.0 | 0.0 |
| SET-UP MISSED | 0.0 | +4.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTER COUNTED ONCE | 0.1 | -0.1 | 0.0 | 0.0 | 0.1 | -0.3 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.2 | +69.8 | 84.2 | 12.7 | 0.6 | +39.6 | 61.1 | 7.9 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 3.8 |
| SHOT OPTIONS | 15.7 | +0.0 | 861.8 | 278.1 | 9.4 | +0.0 | 354.3 | 187.2 |
| SHOT REPLANNED | 0.6 | +0.0 | 137.8 | 2.1 | 0.1 | +0.0 | 35.9 | 4.4 |
| SHOTS IN THE MOVE | 15.4 | +518.2 | 0.0 | 237.1 | 8.5 | +229.4 | 0.0 | 135.0 |
| SPELL CATCH ODDS | 0.1 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.5 | +82.8 | 3.1 | 7.2 | 0.2 | +28.5 | 12.3 | 0.0 |
| SPELL WORTH | 1.4 | +21.1 | 72.7 | 90.9 | 1.5 | +36.2 | 157.8 | 164.8 |
| STABLE ROLE | 12.2 | +0.0 | 553.9 | 159.0 | 10.1 | +0.0 | 264.6 | 166.0 |
| STANDS TO CAST | 0.1 | +6.5 | 0.0 | 0.0 | 0.1 | +2.9 | 3.2 | 0.0 |
| STAY WEIGHED | - | - | - | - | 0.1 | +3.4 | 0.0 | 0.0 |
| STAY WORTH | 19.9 | +272.4 | 553.6 | 275.9 | - | - | - | - |
| STOPS | 0.0 | +0.0 | 5.3 | 0.0 | 0.1 | +2.4 | 0.0 | 1.7 |
| STOPS SHORT OF THE FLANK | 0.3 | +9.5 | 0.0 | 0.0 | 0.5 | +39.1 | 0.0 | 26.7 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 4.0 |
| SUPPORT NARROWED | 6.0 | -54.3 | 330.1 | 89.8 | 7.6 | -53.2 | 336.3 | 135.9 |
| SUPPORTS | 3.6 | +57.7 | 108.5 | 32.3 | 4.9 | +58.2 | 180.2 | 61.3 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -1.0 | 1.8 | 0.0 | 0.0 | -1.0 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.4 | -1.5 | 7.0 | 16.9 | 0.7 | +1.7 | 1.8 | 27.3 |
| THREAT IN THE KILL | 10.1 | +186.5 | 798.2 | 178.7 | 0.4 | +2.3 | 22.5 | 15.7 |
| THROUGH LINE OF FIRE | 0.4 | +14.7 | 0.0 | 0.0 | 0.3 | +7.1 | 0.0 | 0.0 |
| TURN WORTH | 0.6 | -44.9 | 51.5 | 10.6 | 0.5 | -25.4 | 27.3 | 15.2 |
| TWO OR MORE ARRIVE | 0.1 | +0.8 | 0.0 | 8.4 | 0.4 | +6.0 | 21.8 | 1.9 |
| WAIT AFTER COSTS | 6.6 | -299.4 | 217.3 | 142.5 | 8.4 | -435.3 | 235.0 | 161.5 |
| WALKS TO THE FIGHT | 1.9 | +41.6 | 58.7 | 28.9 | 1.2 | +30.8 | 15.4 | 19.8 |
| WAR ENGINE CHARGES | 0.1 | +7.6 | 4.0 | 0.0 | 0.1 | +4.4 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.5 | +0.0 | 38.5 | 6.9 | 0.4 | +0.0 | 0.0 | 16.1 |
| WEARS DOWN | 1.2 | +46.3 | 149.5 | 38.6 | 1.6 | +41.2 | 135.9 | 72.6 |
| WHO HITS BACK | 0.5 | +24.7 | 0.0 | 15.8 | 0.1 | +8.6 | 0.0 | 5.1 |
| WHOLE FIGHT | 0.5 | +20.1 | 98.6 | 29.7 | 0.3 | +29.2 | 47.6 | 24.6 |
| WHOLE FIGHT GAIN | 0.2 | +16.4 | 13.6 | 7.9 | 0.8 | +85.4 | 67.3 | 26.3 |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 12.1 | 0.0 | - | - | - | - |

### Rule changes: shots-h2h-mine-7c46ffc-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1135 | 1135 | 1135 | 31.53 | -61889 | -54.5 |
| BEST FIRST | 263 | 263 | 263 | 7.31 | +12397 | +47.1 |
| SEARCH SPOT | 199 | 199 | 194 | 5.39 | +9896 | +51.0 |
| PATHS CROSS | 161 | 161 | 161 | 4.47 | +12204 | +75.8 |
| COUNTER-CHARGE COVER | 595 | 318 | 155 | 4.31 | +8487 | +54.8 |
| MOVE TO CHARGE | 254 | 254 | 130 | 3.61 | +9725 | +74.8 |
| KILLS COUNT NEXT TURN | 395 | 395 | 116 | 3.22 | +4627 | +39.9 |
| SUPPORTS | 306 | 306 | 103 | 2.86 | +1214 | +11.8 |
| FACES THE THREAT | 91 | 91 | 91 | 2.53 | +7828 | +86.0 |
| FOLLOW UP WEIGHED | 84 | 84 | 84 | 2.33 | +12965 | +154.3 |
| FALLBACK BY WORTH | 369 | 369 | 79 | 2.19 | +5003 | +63.3 |
| WAIT AFTER COSTS | 537 | 537 | 65 | 1.81 | +1150 | +17.7 |
| WALKS TO THE FIGHT | 109 | 109 | 63 | 1.75 | +960 | +15.2 |
| SAFER THAN THE JOB | 58 | 58 | 58 | 1.61 | +2606 | +44.9 |
| SHOTS IN THE MOVE | 860 | 562 | 57 | 1.58 | +1107 | +19.4 |
| REDIRECT COUNTER | 217 | 128 | 54 | 1.50 | +4890 | +90.6 |
| ARTILLERY RE-ROLL WEIGHED | 52 | 52 | 52 | 1.44 | +0 | +0.0 |
| CANNON SIGHT KEPT | 52 | 52 | 52 | 1.44 | +0 | +0.0 |
| CHARGE NOW FIRST | 218 | 218 | 50 | 1.39 | -4960 | -99.2 |
| ADVANCE LANE KEPT | 49 | 49 | 49 | 1.36 | +0 | +0.0 |
| RESERVE FALL BACK | 47 | 47 | 47 | 1.31 | +1342 | +28.6 |
| RANDOM MOVE BY FIGURES | 74 | 74 | 45 | 1.25 | +835 | +18.6 |
| CANNON PLANNED TARGET | 230 | 230 | 44 | 1.22 | -366 | -8.3 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| RISK BY ARC | 218 | 206 | 41 | 1.14 | +954 | +23.3 |
| FOCUS OVER TURNS | 86 | 86 | 40 | 1.11 | +740 | +18.5 |
| INVITES THE FIGHT | 132 | 132 | 40 | 1.11 | +707 | +17.7 |
| BEST MOVE FOR SHOOTERS | 39 | 39 | 39 | 1.08 | +3060 | +78.4 |
| MISSILES IN THE MOVE | 299 | 179 | 39 | 1.08 | +1790 | +45.9 |
| STAY WORTH | 717 | 578 | 39 | 1.08 | +984 | +25.2 |
| MARCH CHECK | 43 | 42 | 38 | 1.06 | +2577 | +67.8 |
| BEST FACING | 37 | 37 | 37 | 1.03 | +1340 | +36.2 |
| THREAT IN THE KILL | 377 | 285 | 37 | 1.03 | +745 | +20.1 |
| KILLS COUNT | 149 | 147 | 36 | 1.00 | +1649 | +45.8 |
| LONE WIZARD KEPT IN | 34 | 34 | 34 | 0.94 | +2648 | +77.9 |
| SET UP TOGETHER | 69 | 61 | 34 | 0.94 | +4836 | +142.2 |
| SHOOTS FROM THE BEST SPOT | 65 | 65 | 33 | 0.92 | +1483 | +44.9 |
| CHARGE NOW WEIGHED | 31 | 31 | 31 | 0.86 | +2081 | +67.1 |
| BEST OVERALL | 30 | 30 | 30 | 0.83 | +2103 | +70.1 |
| MAX FOR POSITIONING | 308 | 160 | 29 | 0.81 | +338 | +11.7 |
| BEST PREY | 76 | 76 | 28 | 0.78 | +1330 | +47.5 |
| STOPS SHORT OF THE FLANK | 28 | 28 | 28 | 0.78 | +1749 | +62.5 |
| SHOT REPLANNED | 27 | 27 | 27 | 0.75 | +0 | +0.0 |
| COMBAT PIVOT | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| CAST JOB | 47 | 47 | 24 | 0.67 | +496 | +20.7 |
| SHOOTERS IN TWO RANKS | 24 | 24 | 24 | 0.67 | +58 | +2.4 |
| THROUGH LINE OF FIRE | 24 | 24 | 24 | 0.67 | +783 | +32.6 |
| MOVE AND CAST | 23 | 23 | 23 | 0.64 | +1707 | +74.2 |
| WHOLE FIGHT GAIN | 37 | 32 | 23 | 0.64 | +1376 | +59.8 |
| WHO HITS BACK | 22 | 22 | 22 | 0.61 | +802 | +36.5 |
| REDIRECT WEIGHED | 21 | 21 | 21 | 0.58 | +1149 | +54.7 |
| BLOCKED WHEEL | 20 | 20 | 20 | 0.56 | +620 | +31.0 |
| CHAFF PASSED | 20 | 20 | 20 | 0.56 | -41 | -2.0 |
| MARCH ODDS | 19 | 19 | 19 | 0.53 | +325 | +17.1 |
| CASTING BLOCK | 27 | 27 | 17 | 0.47 | +1083 | +63.7 |
| KEEPS ITS TARGET | 119 | 117 | 17 | 0.47 | +282 | +16.6 |
| FRIENDS SHOTS CHECKED | 15 | 15 | 15 | 0.42 | +1890 | +126.0 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| HUNT IN PAIRS | 25 | 20 | 12 | 0.33 | +866 | +72.2 |
| MAKE SURE TOGETHER | 32 | 23 | 12 | 0.33 | +1359 | +113.2 |
| MANOEUVRE | 13 | 13 | 12 | 0.33 | +281 | +23.4 |
| PIVOT GUARDS FLANK | 12 | 12 | 12 | 0.33 | -155 | -12.9 |
| WAR ENGINE JOBS | 32 | 32 | 12 | 0.33 | -911 | -75.9 |
| BIG CHARACTER SAFETY | 11 | 11 | 11 | 0.31 | +19 | +1.7 |
| WEARS DOWN | 102 | 95 | 11 | 0.31 | +548 | +49.8 |
| SUPPORT NARROWED | 492 | 492 | 10 | 0.28 | -107 | -10.7 |
| LOST CHARGE | 206 | 205 | 9 | 0.25 | +140 | +15.6 |
| MODEL FACING | 9 | 9 | 9 | 0.25 | +2958 | +328.7 |
| OPENS UP | 17 | 17 | 9 | 0.25 | +464 | +51.6 |
| STUCK PIVOT | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| RESTRAINS TO SHOOT | 8 | 8 | 8 | 0.22 | +269 | +33.6 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| MISSILES NEXT TURN | 330 | 200 | 7 | 0.19 | +34 | +4.8 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| PURSUES BIG PREY | 7 | 7 | 7 | 0.19 | -784 | -112.1 |
| NEEDED THERE | 11 | 11 | 6 | 0.17 | +0 | +0.0 |
| WHOLE FIGHT | 30 | 28 | 6 | 0.17 | +136 | +22.7 |
| BACKUP TARGETS | 66 | 35 | 5 | 0.14 | +57 | +11.4 |
| STANDS TO CAST | 5 | 5 | 5 | 0.14 | +97 | +19.4 |
| BEST PRIZE | 4 | 4 | 4 | 0.11 | -1041 | -260.3 |
| BLOCKED CHARGE SKIPPED | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| KEEP FALLS | 4 | 4 | 4 | 0.11 | +108 | +27.1 |
| OVERRUNS AWAY | 44 | 42 | 4 | 0.11 | +88 | +22.1 |
| SURE CHARGE BEATS ADVANCE | 4 | 4 | 4 | 0.11 | -73 | -18.3 |
| SURE REACH TOGETHER | 41 | 31 | 4 | 0.11 | +6 | +1.6 |
| ELIXIR WORTH | 3 | 3 | 3 | 0.08 | +26 | +8.7 |
| FACE THE CAST | 3 | 3 | 3 | 0.08 | +85 | +28.3 |
| FOCUS FIRE | 3 | 3 | 3 | 0.08 | +66 | +22.0 |
| HUNT ADVANCE | 13 | 13 | 3 | 0.08 | +97 | +32.4 |
| RAIDS THE BAGGAGE NEXT TURN | 3 | 3 | 3 | 0.08 | +180 | +60.1 |
| DEFENSIVE ARMY | 18 | 18 | 2 | 0.06 | -43 | -21.3 |
| EDGE GIVE GROUND | 7 | 7 | 2 | 0.06 | +164 | +82.1 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 21 | 21 | 2 | 0.06 | -63 | -31.6 |
| LONG SHOT | 38 | 38 | 2 | 0.06 | +11 | +5.5 |
| STAY WEIGHED | 2 | 2 | 2 | 0.06 | +124 | +62.0 |
| TWO OR MORE ARRIVE | 18 | 17 | 2 | 0.06 | +8 | +3.9 |
| CARRIES OUT SET-UP | 3 | 3 | 1 | 0.03 | -74 | -74.2 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -55 | -55.4 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| DEFENSIVE FLOOR | 5 | 5 | 1 | 0.03 | +2 | +2.1 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +4 | +4.1 |
| JOINT CHARGE PLAN | 3 | 3 | 1 | 0.03 | +75 | +74.8 |
| MOVE SPELL IN RANGE | 6 | 3 | 1 | 0.03 | +4 | +3.9 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +54 | +54.0 |
| RAIDS THE BAGGAGE | 1 | 1 | 1 | 0.03 | +148 | +147.8 |
| REDIRECT BY WHAT IT STOPS | 15 | 15 | 1 | 0.03 | +38 | +37.5 |
| STOPS | 4 | 4 | 1 | 0.03 | +13 | +13.1 |
| WAR ENGINE CHARGES | 7 | 7 | 1 | 0.03 | +139 | +138.6 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 29 | 29 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 39 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARIOT WIZARD CAREFUL | 5 | 5 | 0 | 0.00 | - | - |
| CHEAP HELPER | 7 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 38 | not checked | - | - | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 379 | not checked | - | - | - | - |
| GIVES UP | 6 | 5 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 20 | 19 | 0 | 0.00 | - | - |
| HILL BY ITS CHANCE | 8 | 8 | 0 | 0.00 | - | - |
| HUNT DROPPED | 6 | trace | - | - | - | - |
| HUNT KEPT | 6 | trace | - | - | - | - |
| HUNT RESULT | 15 | trace | - | - | - | - |
| HUNT THE GUNS | 15 | trace | - | - | - | - |
| KEEPS ITS PREY | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 39 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 20 | 20 | 0 | 0.00 | - | - |
| MISSILES IN THE PLAN | 59 | 7 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 12 | 12 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 11 | trace | - | - | - | - |
| MOVE SPELL SPOT | 15 | not checked | - | - | - | - |
| NOT NEEDED | 22 | 21 | 0 | 0.00 | - | - |
| NOT TURNED | 375 | 375 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 38 | not checked | - | - | - | - |
| OPENS A LANE | 9 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 2716 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 17 | 17 | 0 | 0.00 | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 16 | 16 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 17 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 20 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SHOT OPTIONS | 906 | 906 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 3 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 24 | not checked | - | - | - | - |
| SPELL WORTH | 105 | not checked | - | - | - | - |
| STABLE ROLE | 801 | 795 | 0 | 0.00 | - | - |
| TURN WORTH | 40 | 40 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: shots-h2h-mine-7c46ffc-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.97 | 13.92 | 55.9 |
| CHARGE NOW FIRST | rule | 0.92 | 0.47 | 99.2 |
| FALLBACK | gate | 0.61 | 0.75 | 41.9 |
| TURN GATE | gate | 0.50 | 0.56 | 33.0 |
| PIVOT GUARDS FLANK | rule | 0.14 | 0.19 | 12.9 |
| WAR ENGINE JOBS | rule | 0.22 | 0.11 | 75.9 |
| LONE CHARACTER SAFE SPOT | gate | 0.14 | 0.17 | 65.2 |
| SUPPORT REQUEST | gate | 0.14 | 0.17 | 124.4 |
| SUPPORT NARROWED | rule | 0.14 | 0.11 | 11.8 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.19 | 0.03 | 40.1 |
| AFTERMATH BAND | gate | 0.14 | 0.06 | 1.8 |
| PURSUES BIG PREY | rule | 0.08 | 0.11 | 112.1 |
| PATHS CROSS | rule | 0.08 | 0.08 | 14.7 |
| CANNON PLANNED TARGET | rule | 0.06 | 0.08 | 88.7 |
| CHAFF PASSED | rule | 0.08 | 0.06 | 8.1 |
| BEST PRIZE | rule | 0.08 | 0.03 | 260.3 |
| FIGHT ORDER BAND | gate | 0.08 | 0.03 | 1.8 |
| SURE CHARGE BEATS ADVANCE | rule | 0.08 | 0.03 | 18.3 |
| BIG CHARACTER SAFETY | rule | 0.08 | - | 9.8 |
| BLOCKED WHEEL | rule | - | 0.08 | 24.5 |
| MARCH ODDS | rule | 0.06 | 0.03 | 26.2 |
| CHARGE NOW WEIGHED | rule | 0.03 | 0.03 | 28.5 |
| DEFENSIVE ARMY | rule | 0.06 | - | 21.3 |
| LONE WIZARD HOLDS BACK | rule | - | 0.06 | 31.6 |
| RULE SWITCHED OFF | gate | - | 0.06 | 20.9 |
| SAFER THAN THE JOB | rule | 0.06 | - | 14.4 |
| THROUGH LINE OF FIRE | rule | 0.03 | 0.03 | 2.2 |
| CARRIES OUT SET-UP | rule | 0.03 | - | 74.2 |
| CATCH ODDS | rule | 0.03 | - | 55.4 |
| NO REASON | gate | 0.03 | - | 8.0 |
| REDIRECT WEIGHED | rule | 0.03 | - | 18.0 |
| STANDS TO CAST | rule | 0.03 | - | 10.0 |
| STOPS SHORT OF THE FLANK | rule | 0.03 | - | 0.6 |

### Plans: shots-h2h-mine-7c46ffc-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.5 | 16% | 493 | 305 | 62% |
| Mine | charge | 3.6 | 63% | 400 | 373 | 93% |
| Mine | close in | 3.4 | 31% | 210 | 133 | 63% |
| Mine | hold | 5.2 | 39% | 328 | 0 | 0% |
| Mine | join | 0.7 | 96% | 20 | 0 | 0% |
| Mine | shoot | 9.8 | 72% | 575 | 863 | 150% |
| Mine | support | 3.9 | 91% | 41 | 0 | 0% |
| Opponent | advance | 12.3 | 14% | 443 | 275 | 62% |
| Opponent | charge | 4.6 | 52% | 482 | 322 | 67% |
| Opponent | close in | 5.9 | 24% | 535 | 157 | 29% |
| Opponent | hold | 3.9 | 42% | 306 | 0 | 0% |
| Opponent | join | 1.2 | 93% | 56 | 0 | 0% |
| Opponent | shoot | 4.3 | 50% | 143 | 268 | 187% |
| Opponent | support | 5.2 | 87% | 53 | 0 | 0% |

### Packages: hunt the guns, shots-h2h-mine-7c46ffc-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 2 | 0 | 50% | 50% | 0% | 4.0 | 262 | 98 | 50% | 15 |
| Opponent | 0.4 | 13 | 0 | 8% | 15% | 8% | 3.0 | 357 | 30 | 8% | 132 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.2 | 1 | 0 | 0% | 100% | 0% | 2.0 | 129 | 95 | 100% | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 110 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 64 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 87 |
| High Elf Realms | 0.2 | 1 | 0 | 100% | 100% | 0% | 4.0 | 206 | 196 | 100% | 181 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 158 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.3 | 1 | 0 | 0% | 0% | 0% | - | 104 | 0 | 0% | 18 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 50 |
| Tomb Kings of Khemri | 0.3 | 2 | 0 | 0% | 0% | 0% | - | 282 | 0 | 0% | 56 |
| Vampire Counts | 0.2 | 2 | 0 | 50% | 50% | 0% | 4.0 | 396 | 144 | 0% | 81 |
| Warriors of Chaos | 0.9 | 7 | 0 | 0% | 0% | 14% | - | 434 | 1 | 0% | 108 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 329 | 0 | 0% | 70 |

### Battle groups: shots-h2h-mine-7c46ffc-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.6 | 20% | 54% | 15% | 40% | 47% | 3% | 9% | 41% | 0% |
| Mine | REDIRECT COUNTER | 2.0 | 32% | 61% | 17% | 25% | 53% | 0% | 0% | 47% | 0% |
| Opponent | COUNTER-CHARGE COVER | 6.9 | 19% | 60% | 15% | 57% | 32% | 5% | 12% | 50% | 0% |
| Opponent | REDIRECT COUNTER | 4.0 | 21% | 61% | 16% | 0% | 19% | 0% | 8% | 65% | 8% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: shots-h2h-mine-7c46ffc-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 37 | 33% | 4.0 | - | 0 (2) | 0 (1) | 0 (1) | 0 (2) |
| Mine | Chaff | 36 | 22 (36) | 8 | 13 | 60 | 31% | 2.6 | 27 (15) | 0 (10) | 33 (11) | 15 (22) | 30 (14) |
| Mine | Character | 123 | 56 (123) | 56 | 0 | 31 | 16% | 2.3 | 57 (32) | 62 (62) | 74 (11) | 60 (56) | 63 (49) |
| Mine | Clean-up | 26 | 75 (26) | 33 | 42 | 27 | 38% | 3.1 | 85 (10) | 78 (12) | 0 (4) | 96 (13) | 57 (13) |
| Mine | Fast | 4 | 35 (4) | 35 | 0 | 47 | 0% | 1.5 | 67 (1) | 0 (2) | 0 (1) | 35 (4) | - |
| Mine | Fast Hammer | 40 | 45 (40) | 31 | 14 | 61 | 22% | 2.6 | 59 (18) | 14 (11) | 45 (11) | 55 (29) | 24 (11) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 60 | 0% | 2.0 | - | 0 (4) | 0 (1) | 0 (1) | 0 (4) |
| Mine | Hammer | 56 | 56 (56) | 37 | 18 | 38 | 14% | 2.4 | 64 (11) | 53 (37) | 57 (8) | 59 (34) | 52 (22) |
| Mine | Holder | 26 | 113 (26) | 15 | 97 | 18 | 38% | 3.5 | 102 (8) | 106 (11) | 139 (7) | 132 (13) | 93 (13) |
| Mine | Shooter | 45 | 108 (45) | 46 | 62 | 50 | 2% | 1.7 | 77 (5) | 125 (32) | 71 (8) | 155 (23) | 64 (22) |
| Mine | Support | 5 | 0 (5) | 0 | 0 | 0 | 20% | 3.5 | - | 0 (5) | - | 0 (2) | 0 (3) |
| Mine | War machine | 56 | 72 (56) | 72 | 0 | 30 | 5% | 1.3 | 58 (14) | 74 (37) | 98 (5) | 74 (11) | 72 (45) |
| Mine | Wizard | 23 | 26 (23) | 26 | 0 | 32 | 4% | 2.4 | 77 (4) | 15 (11) | 0 (3) | 99 (4) | 10 (14) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Opponent | Chaff | 68 | 68 (68) | 28 | 40 | 60 | 40% | 2.9 | 110 (30) | 38 (16) | 35 (22) | 75 (50) | 45 (18) |
| Opponent | Character | 113 | 42 (113) | 42 | 0 | 41 | 19% | 2.6 | 52 (38) | 41 (56) | 8 (8) | 42 (70) | 46 (32) |
| Opponent | Clean-up | 18 | 16 (18) | 3 | 13 | 34 | 33% | 2.9 | 0 (5) | 27 (10) | 15 (3) | 27 (11) | 0 (7) |
| Opponent | Early | 1 | 72 (1) | 72 | 0 | 0 | 0% | 4.0 | - | - | 72 (1) | 72 (1) | - |
| Opponent | Fast Hammer | 53 | 50 (53) | 34 | 16 | 56 | 28% | 2.6 | 49 (20) | 24 (18) | 83 (15) | 37 (37) | 79 (16) |
| Opponent | Fragile | 10 | 15 (10) | 15 | 0 | 91 | 50% | 1.6 | 0 (3) | 0 (2) | 37 (4) | 24 (6) | 0 (3) |
| Opponent | Hammer | 63 | 40 (63) | 29 | 11 | 55 | 25% | 2.7 | 47 (16) | 35 (40) | 69 (7) | 49 (39) | 22 (24) |
| Opponent | Holder | 40 | 84 (40) | 25 | 59 | 24 | 50% | 3.2 | 8 (10) | 150 (17) | 47 (12) | 130 (22) | 27 (17) |
| Opponent | Shooter | 32 | 65 (32) | 17 | 49 | 46 | 3% | 1.3 | 52 (8) | 67 (18) | 76 (6) | 55 (17) | 79 (15) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 50 | 50% | 6.0 | 0 (2) | - | - | - | 0 (2) |
| Opponent | War machine | 13 | 38 (13) | 38 | 0 | 42 | 15% | 1.1 | 12 (5) | 31 (5) | 97 (3) | 0 (3) | 49 (10) |
| Opponent | Wizard | 24 | 12 (24) | 12 | 0 | 50 | 12% | 2.0 | 24 (9) | 13 (4) | 0 (4) | 26 (8) | 0 (9) |

### Charged fights: shots-h2h-mine-7c46ffc-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 331 | 296 | 2.6 | 1.2 | 114 | 34 | +80 | 2 of 13 | 10 of 13 | -68 | +107 |
| Mine | Chaos Dwarfs | 3 | 272 | 407 | 4.3 | 1.2 | 94 | 0 | +94 | 9 of 13 | 9 of 12 | +0 | +111 |
| Mine | Dwarfen Mountain Holds | 4 | 546 | 53 | 2.0 | 1.4 | 26 | 71 | -45 | 3 of 8 | 4 of 8 | +56 | -78 |
| Mine | Empire of Man | 5 | 394 | 206 | 1.6 | 1.2 | 129 | 0 | +129 | 2 of 8 | 8 of 8 | +129 | +129 |
| Mine | Grand Cathay | 4 | 782 | 549 | 4.2 | 1.1 | 129 | 26 | +104 | 9 of 17 | 15 of 17 | +0 | +117 |
| Mine | High Elf Realms | 4 | 251 | 381 | 3.5 | 1.5 | 109 | 10 | +99 | 5 of 14 | 12 of 14 | +146 | +72 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Mine | Lizardmen | 1 | 0 | 626 | 3.0 | 1.3 | 209 | 47 | +162 | 3 of 3 | 3 of 3 | +195 | +145 |
| Mine | Ogre Kingdoms | 1 | 70 | 132 | 2.0 | 1.5 | 66 | 0 | +66 | 0 of 2 | 2 of 2 | +66 | +66 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 567 | 6.0 | 1.3 | 94 | 9 | +85 | 2 of 6 | 5 of 6 | +72 | +92 |
| Mine | Skaven | 2 | 50 | 392 | 2.0 | 1.0 | 196 | 0 | +196 | 3 of 4 | 4 of 4 | - | +196 |
| Mine | Tomb Kings of Khemri | 2 | 109 | 1048 | 5.0 | 1.3 | 210 | 34 | +175 | 4 of 10 | 7 of 10 | +326 | +111 |
| Mine | Vampire Counts | 2 | 0 | 157 | 6.5 | 1.2 | 24 | 18 | +6 | 5 of 13 | 8 of 13 | +105 | -23 |
| Mine | Warriors of Chaos | 1 | 0 | 307 | 4.0 | 1.0 | 77 | 0 | +77 | 1 of 4 | 4 of 4 | - | +77 |
| **Mine** | all armies | 36 | 309 | 347 | 3.2 | 1.2 | 108 | 20 | +87 | 49 of 116 | 91 of 115 | +106 | +82 |
| Opponent | Beastmen Brayherds | 1 | 0 | 822 | 3.0 | 1.3 | 274 | 46 | +228 | 2 of 3 | 2 of 3 | -137 | +411 |
| Opponent | Dwarfen Mountain Holds | 1 | 112 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| Opponent | Empire of Man | 1 | 255 | 1197 | 2.0 | 1.0 | 598 | 175 | +424 | 2 of 2 | 1 of 2 | - | +424 |
| Opponent | Grand Cathay | 1 | 355 | 851 | 3.0 | 1.7 | 284 | 0 | +284 | 2 of 3 | 2 of 3 | +561 | +145 |
| Opponent | High Elf Realms | 2 | 114 | 148 | 1.5 | 1.0 | 99 | 0 | +99 | 3 of 3 | 0 of 3 | - | +99 |
| Opponent | Lizardmen | 1 | 0 | 569 | 3.0 | 1.0 | 190 | 94 | +95 | 3 of 3 | 2 of 3 | - | +95 |
| Opponent | Ogre Kingdoms | 2 | 26 | 48 | 2.5 | 1.2 | 19 | 44 | -25 | 0 of 5 | 3 of 5 | -4 | -30 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 726 | 5.0 | 1.0 | 145 | 163 | -18 | 5 of 10 | 5 of 9 | - | -18 |
| Opponent | Skaven | 2 | 0 | 184 | 0.5 | 1.0 | 369 | 0 | +369 | 1 of 1 | 1 of 1 | - | +369 |
| Opponent | Tomb Kings of Khemri | 4 | 162 | 1060 | 4.2 | 1.2 | 249 | 31 | +218 | 9 of 17 | 14 of 17 | +179 | +227 |
| Opponent | Vampire Counts | 6 | 92 | 352 | 4.7 | 1.2 | 75 | 70 | +5 | 17 of 28 | 14 of 28 | +77 | -14 |
| Opponent | Warriors of Chaos | 7 | 17 | 341 | 2.4 | 1.2 | 141 | 14 | +127 | 6 of 17 | 8 of 17 | +18 | +141 |
| Opponent | Wood Elf Realms | 6 | 184 | 197 | 3.3 | 1.1 | 59 | 28 | +31 | 11 of 20 | 10 of 20 | +234 | -5 |
| **Opponent** | all armies | 36 | 95 | 433 | 3.1 | 1.2 | 138 | 52 | +86 | 61 of 113 | 63 of 112 | +127 | +78 |

### Effective charges: shots-h2h-mine-7c46ffc-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 13 | 1 (net -30) | 0 | 2 (net +114) | 1 (net +185) | 1 (net +0) | 8 (net +82) | 0 | 15% (2 of 13) |
| Mine | Chaos Dwarfs | 13 | 2 (net +164) | 0 | 0 | 2 (net +0) | 0 | 8 (net +104) | 1 | 0% (0 of 12) |
| Mine | Dwarfen Mountain Holds | 8 | 2 (net -123) | 0 | 0 | 0 | 0 | 6 (net -18) | 0 | 0% (0 of 8) |
| Mine | Empire of Man | 8 | 1 (net +0) | 0 | 0 | 0 | 3 (net +142) | 4 (net +152) | 0 | 0% (0 of 8) |
| Mine | Grand Cathay | 17 | 2 (net +192) | 0 | 4 (net +36) | 3 (net +221) | 3 (net +40) | 5 (net +90) | 0 | 24% (4 of 17) |
| Mine | High Elf Realms | 14 | 1 (net +0) | 0 | 3 (net +208) | 3 (net +127) | 3 (net +38) | 2 (net +118) | 2 | 25% (3 of 12) |
| Mine | Kingdom of Bretonnia | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Lizardmen | 3 | 0 | 0 | 0 | 0 | 0 | 1 (net +195) | 2 | 0% (0 of 1) |
| Mine | Ogre Kingdoms | 2 | 0 | 0 | 0 | 1 (net +66) | 1 (net +66) | 0 | 0 | 0% (0 of 2) |
| Mine | Orc & Goblin Tribes | 6 | 0 | 0 | 0 | 0 | 2 (net +70) | 1 (net +301) | 3 | 0% (0 of 3) |
| Mine | Skaven | 4 | 1 (net +663) | 0 | 1 (net +0) | 0 | 0 | 2 (net +60) | 0 | 25% (1 of 4) |
| Mine | Tomb Kings of Khemri | 10 | 2 (net +546) | 0 | 3 (net +183) | 2 (net +58) | 0 | 2 (net +136) | 1 | 33% (3 of 9) |
| Mine | Vampire Counts | 13 | 5 (net -9) | 0 | 1 (net +170) | 4 (net +0) | 1 (net +144) | 2 (net -93) | 0 | 8% (1 of 13) |
| Mine | Warriors of Chaos | 4 | 0 | 0 | 0 | 1 (net +0) | 1 (net +91) | 1 (net +107) | 1 | 0% (0 of 3) |
| Opponent | Beastmen Brayherds | 3 | 1 (net -137) | 0 | 0 | 1 (net +0) | 0 | 1 (net +822) | 0 | 0% (0 of 3) |
| Opponent | Dwarfen Mountain Holds | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | Empire of Man | 2 | 1 (net +142) | 0 | 0 | 0 | 0 | 1 (net +705) | 0 | 0% (0 of 2) |
| Opponent | Grand Cathay | 3 | 1 (net +185) | 0 | 1 (net +561) | 0 | 0 | 1 (net +105) | 0 | 33% (1 of 3) |
| Opponent | High Elf Realms | 3 | 2 (net +148) | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 3) |
| Opponent | Lizardmen | 3 | 1 (net -283) | 0 | 0 | 1 (net +380) | 0 | 0 | 1 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 5 | 0 | 0 | 0 | 0 | 0 | 2 (net -94) | 3 | 0% (0 of 2) |
| Opponent | Orc & Goblin Tribes | 10 | 2 (net +0) | 0 | 0 | 2 (net +326) | 0 | 0 | 6 | 0% (0 of 4) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +369) | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 17 | 2 (net -32) | 1 (net +83) | 1 (net +347) | 2 (net +58) | 2 (net +65) | 8 (net +335) | 1 | 6% (1 of 16) |
| Opponent | Vampire Counts | 28 | 8 (net -53) | 0 | 3 (net -94) | 6 (net -96) | 1 (net +38) | 9 (net +155) | 1 | 11% (3 of 27) |
| Opponent | Warriors of Chaos | 17 | 3 (net +178) | 0 | 1 (net +0) | 3 (net +167) | 0 | 8 (net +106) | 2 | 7% (1 of 15) |
| Opponent | Wood Elf Realms | 20 | 5 (net -42) | 1 (net -27) | 1 (net +0) | 3 (net +42) | 0 | 8 (net +106) | 2 | 6% (1 of 18) |

### Charged fights, damage counted: shots-h2h-mine-7c46ffc-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 18 | 281 | 308 | +119 | 145 | 52 | +93 | +33.0 |
| Mine | Effective (55-75%) | 14 | 334 | 239 | +123 | 144 | 5 | +139 | +41.7 |
| Mine | 76-89% | 17 | 231 | 220 | +83 | 103 | 36 | +66 | +28.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 42 | 264 | 197 | +83 | 141 | 47 | +94 | +35.8 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 15 | 388 | 76 | +73 | 80 | 23 | +56 | +14.5 |
| Mine | No odds | 10 | 298 | 193 | +29 | 92 | 59 | +34 | +11.3 |
| Mine | All fights | 116 | 289 | 207 | +87 | 124 | 39 | +85 | +29.5 |
| Opponent | Long shot (under 50%) | 26 | 187 | 256 | +1 | 104 | 127 | -23 | -12.4 |
| Opponent | 50-54% | 2 | 483 | 364 | +28 | 165 | 62 | +103 | +21.3 |
| Opponent | Effective (55-75%) | 7 | 389 | 308 | +89 | 138 | 113 | +25 | +6.4 |
| Opponent | 76-89% | 18 | 242 | 212 | +67 | 167 | 76 | +91 | +37.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 41 | 299 | 188 | +185 | 221 | 42 | +179 | +59.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 372 | 69 | +56 | 56 | 0 | +56 | +15.1 |
| Opponent | No odds | 16 | 171 | 195 | +0 | 107 | 95 | +12 | +6.7 |
| Opponent | All fights | 113 | 257 | 216 | +86 | 159 | 78 | +80 | +31.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| shots-h2h-mine-7c46ffc-p1 | move | 431 | 94 (22%) | 78 (18%) | 57 (13%) | 280 (65%) |
| shots-h2h-mine-7c46ffc-p1 | objective | 336 | 41 (12%) | 31 (9%) | 50 (15%) | 245 (73%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

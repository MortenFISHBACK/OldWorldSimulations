# Doctrine scorecard: shots-h2h-mine-7c46ffc-p2

### Scorecard: shots-h2h-mine-7c46ffc-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 5 | 5 | 1 | 2 | 0 | 0 | 0 | 387 |
| L0106 | 4 | 1 | Opponent | no | 0 | 2 | 0 | 1 | 1 | 0 | 0 | 1194 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 1 | 0 | 0 | 0 | 317 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | - | 2 | 3 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 2 | 1 | 0 | 0 | 0 | 0 | 615 |
| L0222 | 6 | 1 | Mine | no | 10 | 3 | 4 | 1 | 1 | 0 | 0 | 170 |
| L0222 | 6 | 1 | Opponent | no | 13 | 2 | 4 | 0 | 0 | 0 | 0 | 127 |
| L0307 | 1 | 1 | Mine | yes | 4 | 2 | 4 | 0 | 0 | 0 | 0 | 760 |
| L0307 | 1 | 1 | Opponent | yes | 3 | 3 | 2 | 2 | 1 | 0 | 0 | 375 |
| L0323 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 590 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 7 | 1 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 3 | 2 | 5 | 2 | 1 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 6 | 3 | 0 | 0 | 0 | 0 | 0 | 973 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | no | - | 2 | 2 | 3 | 0 | 0 | 0 | 50 |
| L0512 | 2 | 1 | Mine | - | - | - | 1 | 1 | 0 | 0 | 0 | 1127 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 0 | 2 | 2 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 10 | 5 | 2 | 1 | 0 | 0 | 0 | 475 |
| L0528 | 6 | 1 | Opponent | no | 3 | 5 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | - | 1 | 3 | 0 | 0 | 0 | 615 |
| L0616 | 4 | 1 | Opponent | no | 0 | 3 | 4 | 2 | 0 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 828 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 4 | 3 | 0 | 0 | 0 | 340 |
| L0721 | 1 | 1 | Mine | yes | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 375 |
| L0721 | 1 | 1 | Opponent | yes | 0 | 4 | 1 | 3 | 1 | 0 | 0 | 145 |
| L0810 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 605 |
| L0810 | 6 | 1 | Opponent | no | 11 | 2 | 4 | 0 | 1 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | 5 | 1 | 1 | 0 | 0 | 0 | 515 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 1 | 3 | 1 | 0 | 0 | 0 | 0 | 726 |
| L0918 | 6 | 1 | Opponent | no | 11 | 2 | 4 | 0 | 0 | 0 | 0 | 185 |
| L0934 | 4 | 1 | Mine | no | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 575 |
| L0934 | 4 | 1 | Opponent | no | 0 | 2 | 7 | 3 | 0 | 0 | 0 | 160 |
| L1026 | 6 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 456 |
| L1026 | 6 | 1 | Opponent | no | 5 | 2 | 5 | 2 | 1 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 3 | 3 | 0 | 0 | 0 | 0 | 225 |
| L1135 | 1 | 1 | Mine | no | 0 | 6 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1135 | 1 | 1 | Opponent | yes | 4 | 3 | 4 | 3 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 1 | 6 | 2 | 1 | 0 | 0 | 0 | 524 |
| L1228 | 4 | 1 | Opponent | no | 3 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L1323 | 3 | 1 | Mine | yes | 5 | 2 | 2 | 1 | 0 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | no | 1 | 2 | 2 | 2 | 1 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Mine | no | 0 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 0 | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 1 | 4 | 3 | 0 | 3 | 0 | 0 | 0 |
| L1629 | 3 | 1 | Mine | no | 1 | 1 | 3 | 2 | 0 | 0 | 0 | 536 |
| L1629 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 255 |
| L1727 | 5 | 1 | Mine | yes | - | 3 | 1 | 1 | 0 | 0 | 0 | 135 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 5 | 3 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 0 | 6 | 5 | 0 | 1 | 0 | 0 | 482 |
| L1827 | 3 | 1 | Opponent | no | 8 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 1 | 1 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 3 | 1 | 0 | 0 | 0 |
| L2029 | 1 | 1 | Mine | no | 2 | - | 1 | 2 | 0 | 0 | 0 | 715 |
| L2029 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 170 |
| L2131 | 1 | 1 | Mine | yes | 4 | - | 1 | 3 | 1 | 0 | 0 | 145 |
| L2131 | 1 | 1 | Opponent | yes | 2 | 2 | 4 | 0 | 2 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | no | 0 | 3 | 0 | 0 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 126 |
| L2429 | 5 | 1 | Mine | yes | - | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 4 | 1 | 1 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Mine | no | 7 | 3 | 1 | 0 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 1 | 1 | 6 | 0 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | no | - | 5 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 1 | 3 | 3 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 6 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 0 | 1 | 7 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 27% | 2.5 | 3.0 | 2.1 | 1.0 | 0.1 | 0.0 | 0.0 | 329.4 |
| **Average** | | | Opponent | 30% | 3.0 | 2.3 | 3.3 | 1.4 | 0.4 | 0.0 | 0.0 | 165.8 |

### KPIs: shots-h2h-mine-7c46ffc-p2

Rules off - Opponent only: STAY WORTH, BEST MOVE FOR SHOOTERS, THREAT IN THE KILL, FOCUS OVER TURNS, MISSILES IN THE PLAN, FACE THE CAST, WIZARD FRONT RANK.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 24% (43 of 177) | 14% (25 of 181) | 19% (68 of 358) |
| Winner chose to follow up after the loser gave ground |  | 95% (88 of 93); on the table 96% | 100% (74 of 74); on the table 100% | 97% (162 of 167); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 87% (13 of 15); on the table 93% | 87% (20 of 23); on the table 96% | 87% (33 of 38); on the table 95% |
| Winner chose to pursue after the loser fled |  | 76% (26 of 34); on the table 82% | 88% (28 of 32); on the table 94% | 82% (54 of 66); on the table 88% |
| Winner chose to follow up or pursue (all three) |  | 89% (127 of 142); on the table 92% | 95% (122 of 129); on the table 98% | 92% (249 of 271); on the table 95% |
| Magic missiles tried each own turn | 50%+ | 35% (121 of 342) | 37% (58 of 156) | 36% (179 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 55% (121 of 221) | 50% (58 of 115) | 53% (179 of 336) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 27% (40 of 150) | 26% (20 of 78) | 26% (60 of 228) |
|     round 1 |  | 16% (4 of 25) | 0% (0 of 13) | 11% (4 of 38) |
|     rounds 2+ |  | 29% (36 of 125) | 31% (20 of 65) | 29% (56 of 190) |
|   other wizards | 50%+ | 42% (81 of 192) | 49% (38 of 78) | 44% (119 of 270) |
|     round 1 |  | 44% (14 of 32) | 54% (7 of 13) | 47% (21 of 45) |
|     rounds 2+ |  | 42% (67 of 160) | 48% (31 of 65) | 44% (98 of 225) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 65% (17 of 26) | 43% (22 of 51) | 51% (39 of 77) |
| Points that never fought | lower | 35% (25370 of 71583) | 39% (28189 of 71989) | 37% (53559 of 143572) |
|   infantry points that never fought | lower | 40% (6494 of 16324) | 54% (7641 of 14029) | 47% (14135 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 59% (167 of 284) | 57% (168 of 297) | 58% (335 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 90% (18 of 20); 1.7 uses a game | 78% (14 of 18); 1.2 uses a game | 84% (32 of 38); 1.5 uses a game |
| Bound items with another spell used |  | 61% (11 of 18); 0.4 uses a game | 50% (1 of 2); 0.1 uses a game | 60% (12 of 20); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (10 of 20); 0.3 uses a game | 14% (1 of 7); 0.0 uses a game | 41% (11 of 27); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 54% (32413 of 60231) | 50% (31581 of 63281) | 52% (63994 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.6 (26%) | 0.7 (26%) | 2.3 (26%) |
| MARCHED: its unit marched | 0.8 (13%) | 0.4 (15%) | 1.2 (13%) |
| CHARGED: its unit charged | 0.1 (1%) | 0.1 (4%) | 0.2 (2%) |
| IN COMBAT: engaged in combat | 1.7 (28%) | 0.6 (22%) | 2.3 (26%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.1 (4%) | 0.1 (1%) |
| FLEEING: fleeing | 0.2 (4%) | 0.1 (2%) | 0.3 (3%) |
| GONE: slain | 1.1 (17%) | 0.3 (11%) | 1.4 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (6%) | 0.2 (6%) | 0.5 (6%) |
| STUPIDITY: Stupidity | 0.2 (4%) | 0.0 (1%) | 0.3 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.2 (8%) | 0.3 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 2.0 | 1.2 | 5.0 | 0.4 | 2.4 |
| not cast | 3.8 | 3.0 | 3.8 | 8.9 | 2.0 | 19.2 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) | 1.1 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (45%) | 0.2 (7%) | 2.3 (26%) | 0.4 (18%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.2 (13%) | 0.3 (15%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (1%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (4%) | 0.2 (7%) | 0.6 (16%) | 2.3 (26%) | 0.3 (17%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (7%) | 0.3 (11%) | 0.2 (7%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (6%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.3 (1%) |
| GONE: slain | 0.9 (23%) | 0.5 (18%) | 0.8 (21%) | 1.4 (15%) | 0.4 (21%) | 3.2 (17%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (4%) | 0.1 (4%) | 0.2 (5%) | 0.5 (6%) | 0.1 (7%) | 0.6 (3%) |
| STUPIDITY: Stupidity | 0.1 (4%) | 0.1 (2%) | 0.1 (1%) | 0.3 (3%) | 0.0 (0%) | 0.4 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.3 (10%) | 0.0 (0%) | 0.0 (0%) | 0.3 (14%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (55%) | 0.1 (4%) | 1.5 (41%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.6 (71%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.6 a game | 0.7 a game | 0.6 a game |
| stood (cast and not dispelled) | 74% (14 of 19) | 71% (17 of 24) | 72% (31 of 43) |
| the unit moved after it | 86% (12 of 14) | 47% (8 of 17) | 65% (20 of 31) |
| it charged on its next turn | 7% (1 of 14) | 12% (2 of 17) | 10% (3 of 31) |
| the enemy charged it first | 21% (3 of 14) | 0% (0 of 17) | 10% (3 of 31) |
| it fought by the end of its next turn | 14% (2 of 14) | 0% (0 of 17) | 6% (2 of 31) |
| it moved out of a charge the enemy had planned (not charged first) | 21% (3 of 14) | 6% (1 of 17) | 13% (4 of 31) |
| none of these (no charge, no fight, no charge escaped) | 50% (7 of 14) | 82% (14 of 17) | 68% (21 of 31) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (587 of 883) | 55% (440 of 803) | 61% (1027 of 1686) |
|   cavalry | 71% (54 of 76) | 61% (106 of 173) | 64% (160 of 249) |
|   character | 55% (65 of 119) | 23% (25 of 110) | 39% (90 of 229) |
|   chariot | 45% (44 of 98) | 62% (20 of 32) | 49% (64 of 130) |
|   infantry | 66% (176 of 268) | 56% (173 of 307) | 61% (349 of 575) |
|   monster | 40% (20 of 50) | 53% (25 of 47) | 46% (45 of 97) |
|   war machine | 84% (228 of 272) | 68% (91 of 134) | 79% (319 of 406) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.9 (23%) | 2.2 (22%) | 4.1 (23%) |
| CHARGED: it charged | 1.1 (14%) | 2.3 (23%) | 3.4 (19%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.1 (1%) |
| IN COMBAT: it fought this turn or the last | 1.4 (17%) | 0.6 (6%) | 2.0 (11%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 1.4 (18%) | 1.8 (18%) | 3.2 (18%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 0.7 (7%) | 0.9 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.5 (18%) | 1.7 (17%) | 3.2 (17%) |
| SHELTERED: the target was sheltered | 0.1 (1%) | 0.3 (3%) | 0.4 (2%) |
| OTHER BAR | 0.4 (5%) | 0.4 (4%) | 0.8 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.8 | 1.8 | 82% | 4.1 pts | 28 pts |
| character | 2.7 | 0.9 | 75% | 11.8 pts | 32 pts |
| chariot | 1.8 | 0.7 | 78% | 8.3 pts | 15 pts |
| infantry | 13.4 | 4.9 | 75% | 7.9 pts | 106 pts |
| monster | 1.6 | 0.5 | 80% | 4.8 pts | 8 pts |
| war machine | 8.9 | 6.5 | 66% | 23.7 pts | 210 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.1 | 7.1 | 5.6 |
| Charges that made contact a game | 3.1 | 4.7 | 3.9 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.60 declared, 0.52 contact (25 units) | 1.00 declared, 0.77 contact (13 units) | 0.74 declared, 0.61 contact (38 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.33 declared, 0.33 contact (6 units) | 1.33 declared, 0.92 contact (12 units) | 1.00 declared, 0.72 contact (18 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.53 declared, 0.39 contact (246 units) | 0.78 declared, 0.52 contact (288 units) | 0.67 declared, 0.46 contact (534 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 55% (40 of 73) | 67% (12 of 18) | 58% (7 of 12) | 57% (59 of 103) |
| Character in a unit | 97% (28 of 29) | 41% (7 of 17) | 100% (2 of 2) | 77% (37 of 48) |
| Character on its own | 79% (34 of 43) | 54% (20 of 37) | 27% (17 of 64) | 49% (71 of 144) |
| Chariot | 71% (12 of 17) | 77% (10 of 13) | - | 73% (22 of 30) |
| Infantry | 54% (51 of 94) | 56% (19 of 34) | 33% (1 of 3) | 54% (71 of 131) |
| Monster | 45% (13 of 29) | 33% (3 of 9) | - | 42% (16 of 38) |
| Monstrous | 57% (8 of 14) | 43% (6 of 14) | - | 50% (14 of 28) |
| War Machines | 77% (44 of 57) | 50% (1 of 2) | - | 76% (45 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (15 of 15); on the table 100% | 26% (27 of 102) | 36% | 64% (14 of 22) | 100% (6 of 6); 3.2 uses a game | 50% (1 of 2); 0.2 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 92% (23 of 25); on the table 96% | 56% (20 of 36) | 50% | 56% (18 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 6 | 83% (15 of 18); on the table 89% | - | 47% | 69% (37 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 81% (13 of 16); on the table 81% | 40% (19 of 48) | 42% | 70% (53 of 76) | 0.0 uses a game | 50% (1 of 2); 0.4 uses a game | 25% (1 of 4); 0.1 uses a game |
| Grand Cathay | 6 | 96% (26 of 27); on the table 96% | 37% (51 of 138) | 47% | 44% (24 of 54) | 86% (12 of 14); 7.2 uses a game | 50% (1 of 2); 0.2 uses a game | 0% (0 of 6); 0.0 uses a game |
| High Elf Realms | 4 | 80% (16 of 20); on the table 85% | 11% (2 of 18) | 27% | 48% (16 of 33) | 100% (3 of 3); 3.5 uses a game | 64% (9 of 14); 3.2 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 100% (7 of 7); on the table 100% | - | 44% | 50% (6 of 12) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Lizardmen | 1 | 100% (2 of 2); on the table 100% | - | 46% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 100% (16 of 16); on the table 100% | 0% (0 of 18) | 25% | 61% (17 of 28) | 100% (4 of 4); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (1 of 1); on the table 100% | 17% (2 of 12) | 3% | 25% (2 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 3 | 92% (11 of 12); on the table 100% | 28% (5 of 18) | 49% | 52% (13 of 25) | 50% (1 of 2); 1.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Tomb Kings of Khemri | 5 | 100% (19 of 19); on the table 100% | - | 36% | 16% (4 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 95% (42 of 44); on the table 100% | 45% (30 of 66) | 24% | 65% (35 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 82% (23 of 28); on the table 89% | 61% (11 of 18) | 35% | 59% (43 of 73) | 100% (2 of 2); 1.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 95% (20 of 21); on the table 95% | 50% (12 of 24) | 40% | 63% (49 of 78) | 57% (4 of 7); 1.7 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (shots-h2h-mine-7c46ffc-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 51% (47) | 49% (30) | 50% (77) |
| ...free all their last turn and able to turn (per game) | 0.83 | 0.53 | 1.36 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.19 | 0.36 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.31 | 0.97 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.75 | 1.22 | 2.97 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 1.08 | 1.08 | 2.17 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 5.86 | 5.14 | 11.00 |

### Quality by phase: shots-h2h-mine-7c46ffc-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 54% (72 of 133) | 45% (114 of 255) |
| Strategy | Shoot objectives carried out (shot that target) | 41% (147 of 357) | 48% (102 of 213) |
| Strategy | Close-in objectives charged next turn | 15% (20 of 131) | 23% (48 of 208) |
| Strategy | Support requests answered (helper made contact too) | 33% (3 of 9) | 36% (12 of 33) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (4 of 4) | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 40% (8 of 20) | 60% (9 of 15) |
| Strategy | Joined characters whose unit fought | 56% (25 of 45) | 26% (9 of 34) |
| Strategy | Lone characters that fought | 73% (73 of 100) | 76% (68 of 89) |
| Movement | Charges halted short of contact | 0.1 | 0.3 |
| Movement | Idle units | 1.0 | 1.4 |
| Movement | Points that never moved of their own | 329.4 | 165.8 |
| Movement | Fights charged into per game | 2.6 | 3.9 |
| Movement | Charges with odds: long shots (under 50%) | 12 of 87, net +28 | 26 of 131, net +69 |
| Movement | Charges with odds: sweet spot (55-75%) | 11 of 87, net +81 | 23 of 131, net +114 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 13 of 87, net +118 | 9 of 131, net +166 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 31 of 87, net +83 | 45 of 131, net +106 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.9 | 10.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (168 of 391) | 42% (161 of 379) |
| Shooting | Points destroyed by shooting units | 84.9 | 36.6 |
| Shooting | War machine shots | 6.3 | 2.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 60% (136 of 228) | 60% (55 of 91) |
| Shooting | Points destroyed by war machines | 63.6 | 33.7 |
| Magic | Magic missiles cast | 1.9 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 31% (21 of 67) | 26% (10 of 38) |
| Magic | Wounds caused by magic missiles | 3.1 | 1.5 |
| Magic | Wounds caused by other spells | 2.6 | 0.8 |
| Magic | Points destroyed by magic (all spells) | 55.6 | 54.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.9 / 0.7 / 1.1 / 0.1 | 1.9 / 0.4 / 0.6 / 0.1 |
| Combat | Points destroyed in combat | 314.4 | 483.9 |
| Combat | Points run down | 86.9 | 86.5 |
| Combat | Net points per charged fight, damage counted | +79 | +101 |
| Combat | Net per 100 charger points, damage counted | +29.1 | +36.0 |
| Combat | First round won (charged fights) | 72% | 71% |
| Combat | Net points per charged fight | +72 | +104 |
| Combat | Net points per supported fight / lone fight | +142 / +58 | +139 / +96 |
| Combat | Charged fights on a top-3 enemy unit | 27 of 95 | 49 of 139 |
| Game | Points lost | 812.9 | 678.1 |
| Game | VP from objectives | 523.1 | 655.3 |
| Game | Lone holders (player turns) | 2.5 | 3.0 |

- Mine won / drew / lost: 15 / 2 / 19 of 36 ended games (of 36); mean margin (Mine - Opponent) -275 VP
- The side that went first won 21 of 34 games with a winner
- Points traded per game (both sides' losses): 1491
- Games not ended: 0; findings 0, warnings 1

### Opponent rules: shots-h2h-mine-7c46ffc-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +2.0 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.4 | +0.0 | 0.0 | 16.8 | 0.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.3 | +8.1 | 0.0 | 77.1 | 1.0 | +12.8 | 0.0 | 9.5 |
| BEST FACING | 0.6 | +18.1 | 0.0 | 13.1 | 0.7 | +24.6 | 0.0 | 27.9 |
| BEST FIRST | 4.9 | +194.1 | 115.9 | 91.1 | 4.0 | +185.7 | 186.1 | 93.5 |
| BEST MOVE FOR SHOOTERS | 0.9 | +51.9 | 0.0 | 28.0 | - | - | - | - |
| BEST OVERALL | 0.8 | +60.2 | 0.0 | 48.5 | 0.6 | +35.9 | 0.0 | 39.3 |
| BEST PREY | 0.9 | +53.5 | 19.1 | 11.4 | 0.9 | +32.8 | 36.0 | 35.7 |
| BEST PRIZE | 0.0 | -0.6 | 0.0 | 0.0 | 0.0 | +4.4 | 8.6 | 0.0 |
| BIG CHARACTER SAFETY | 0.1 | -0.6 | 0.0 | 16.1 | 0.1 | -0.8 | 0.0 | 24.1 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 9.7 | 0.0 |
| BLOCKED WHEEL | 0.4 | +6.9 | 0.0 | 0.0 | 0.6 | +9.4 | 0.0 | 20.1 |
| BOMBING RUN | 0.0 | +1.4 | 0.0 | 0.0 | 0.1 | +1.3 | 2.4 | 1.7 |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 3.5 | - | - | - | - |
| CANNON PLAN MISSED | 0.6 | +0.0 | 96.2 | 15.0 | 0.3 | +0.0 | 54.1 | 0.0 |
| CANNON PLANNED TARGET | 5.0 | +104.9 | 289.4 | 108.9 | 1.8 | +114.2 | 192.8 | 13.9 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 12.3 |
| CARRIES OUT COUNTER | 0.1 | -0.3 | 5.1 | 0.0 | 0.1 | +0.0 | 7.1 | 0.0 |
| CARRIES OUT SET-UP | 0.0 | +0.0 | 3.4 | 0.0 | 0.2 | -0.6 | 20.9 | 0.0 |
| CAST JOB | 0.8 | +12.7 | 13.4 | 25.8 | 0.5 | +14.5 | 51.5 | 12.9 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +32.6 | 16.6 | 0.0 | 0.1 | +5.7 | 20.3 | 0.0 |
| CASTS AFTER FRIENDS | 0.4 | +0.0 | 0.0 | 11.1 | 0.3 | +0.0 | 0.0 | 7.6 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.2 | -0.3 | 0.0 | 0.0 | 0.2 | -0.3 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 2.8 | +0.0 | 213.8 | 86.3 | 3.9 | +0.0 | 431.0 | 115.8 |
| CHARGE NOW WEIGHED | 0.6 | -62.9 | 20.9 | 2.5 | 0.4 | -50.7 | 17.1 | 32.6 |
| CHARIOT NO STATIC JOB | 0.1 | +0.0 | 0.0 | 2.4 | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | -0.2 | 10.6 | 0.0 |
| CHEAP HELPER | 0.0 | +0.0 | 3.2 | 0.0 | 0.2 | +0.0 | 11.4 | 1.8 |
| COMBAT PIVOT | 0.5 | +0.0 | 28.6 | 21.3 | 0.7 | +0.0 | 26.6 | 19.2 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.3 | +29.1 | 0.0 | 12.5 | 0.6 | +68.8 | 21.0 | 18.9 |
| COUNTER-CHARGE COVER | 10.8 | +850.0 | 0.0 | 261.8 | 6.7 | +647.5 | 0.0 | 186.8 |
| DEFENSIVE ARMY | 0.2 | +0.0 | 13.6 | 5.2 | 0.1 | +0.0 | 32.2 | 0.0 |
| DEFENSIVE FLOOR | 0.0 | +0.7 | 0.0 | 1.5 | - | - | - | - |
| EDGE GIVE GROUND | 0.1 | +3.4 | 2.4 | 1.2 | 0.4 | +5.5 | 56.2 | 18.4 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACE THE CAST | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.8 | +148.2 | 0.0 | 22.6 | 1.2 | +104.3 | 0.0 | 54.1 |
| FALLBACK BY WORTH | 4.3 | +45.8 | 0.0 | 64.0 | 6.6 | +88.1 | 0.0 | 67.9 |
| FIGHT LIFT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +2.4 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.0 | +0.8 | 1.2 | 0.0 | 0.0 | +0.4 | 0.0 | 0.0 |
| FLANK NOT WEIGHED | 5.9 | +0.0 | 0.0 | 154.8 | 4.9 | +0.0 | 0.0 | 163.8 |
| FOCUS FIRE | 0.0 | +0.4 | 1.5 | 0.0 | 0.0 | +1.0 | 1.5 | 0.0 |
| FOCUS OVER TURNS | 1.5 | +30.2 | 48.3 | 30.1 | - | - | - | - |
| FOLLOW UP WEIGHED | 1.6 | +216.4 | 0.0 | 72.2 | 1.6 | +213.4 | 0.0 | 47.8 |
| FRIENDS SHOTS CHECKED | 0.4 | +36.3 | 0.0 | 14.9 | 0.2 | +14.8 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.1 | -2.9 | 0.0 | 0.0 |
| GIVES UP ITS SCREEN | 0.0 | -0.2 | 0.0 | 3.2 | 0.1 | -1.4 | 5.0 | 3.6 |
| GROUND FLIERS | 0.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 3.2 | 0.0 | 0.1 | +0.0 | 20.4 | 3.9 |
| HELPER UNSEEN | 0.1 | +0.0 | 3.2 | 3.2 | 0.6 | +0.0 | 37.5 | 8.1 |
| HILL BY ITS CHANCE | 0.4 | -32.6 | 0.0 | 4.1 | 0.7 | -50.3 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +0.3 | 0.0 | 4.9 | 0.3 | +4.6 | 19.3 | 10.0 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 1.9 | 0.1 | +0.0 | 3.5 | 1.9 |
| HUNT IN PAIRS | 0.5 | +49.3 | 0.0 | 27.8 | 0.5 | +24.5 | 0.0 | 5.4 |
| HUNT KEPT | 0.1 | +0.5 | 0.0 | 5.8 | 0.2 | +3.5 | 18.6 | 0.9 |
| HUNT RESULT | 0.1 | +0.0 | 0.0 | 3.3 | 0.3 | +67.7 | 3.5 | 10.9 |
| HUNT THE GUNS | 0.1 | +26.6 | 0.0 | 6.3 | 0.3 | +130.3 | 39.4 | 11.9 |
| INVITES THE FIGHT | 1.5 | +29.4 | 28.7 | 24.0 | 1.0 | +15.2 | 31.1 | 18.2 |
| JOINT CHARGE PLAN | - | - | - | - | 0.1 | +4.5 | 14.5 | 6.0 |
| KEEP FALLS | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.1 | +0.1 | 0.0 | 2.4 | 0.0 | +0.5 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.6 | +47.5 | 137.5 | 40.0 | 2.2 | +65.8 | 216.1 | 86.4 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 1.8 | +71.4 | 142.7 | 39.2 | 3.1 | +142.4 | 257.7 | 81.1 |
| KILLS COUNT NEXT TURN | 4.4 | +152.2 | 109.7 | 89.6 | 7.5 | +283.7 | 272.5 | 140.0 |
| LONE CHARACTER SAFE SPOT | 0.2 | +16.3 | 1.7 | 1.2 | 0.2 | +9.5 | 0.0 | 12.1 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 6.4 | 16.0 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +23.5 | 0.0 | 0.0 |
| LONG SHOT | 0.4 | -0.4 | 7.5 | 8.1 | 0.9 | -3.9 | 72.6 | 13.2 |
| LOST CHARGE | 2.9 | -49.0 | 42.7 | 119.6 | 2.7 | -60.5 | 110.5 | 61.2 |
| LURE BY WHAT IT DRAWS | 0.1 | -2.7 | 0.0 | 1.8 | 0.1 | -11.9 | 0.0 | 1.7 |
| MAKE SURE TOGETHER | 0.2 | +3.8 | 6.8 | 16.1 | 0.6 | +53.7 | 11.9 | 19.8 |
| MANOEUVRE | 0.2 | +3.7 | 0.0 | 2.7 | 0.2 | +5.4 | 0.0 | 4.4 |
| MARCH AT ESCAPER | 0.0 | +0.6 | 0.0 | 0.0 | 0.0 | +0.6 | 0.0 | 0.0 |
| MARCH CHECK | 0.4 | +11.3 | 0.0 | 9.1 | 0.4 | +19.3 | 0.0 | 17.3 |
| MARCH ODDS | 0.4 | +34.0 | 6.4 | 18.4 | 0.3 | +29.9 | 16.1 | 0.0 |
| MARCH OVER CASTS | 0.4 | +52.0 | 0.0 | 13.4 | 0.3 | +14.8 | 0.0 | 15.1 |
| MAX FOR POSITIONING | 5.2 | +192.9 | 0.0 | 163.7 | 4.7 | +207.7 | 0.0 | 135.2 |
| MISSILES IN THE MOVE | 3.9 | +124.0 | 0.0 | 105.9 | 3.1 | +55.2 | 0.0 | 88.1 |
| MISSILES IN THE PLAN | 1.1 | +10.6 | 43.0 | 22.4 | - | - | - | - |
| MISSILES NEXT TURN | 4.5 | +86.4 | 0.0 | 139.6 | 3.6 | +44.9 | 0.0 | 82.2 |
| MODEL FACING | 0.4 | +99.5 | 0.0 | 1.7 | 0.2 | +47.7 | 0.0 | 3.3 |
| MONSTER WIZARD ROAMS | 0.3 | +0.0 | 11.3 | 10.2 | 0.1 | +0.0 | 24.1 | 0.0 |
| MOVE AND CAST | 0.3 | +21.8 | 0.0 | 1.7 | 0.4 | +27.9 | 0.0 | 13.3 |
| MOVE SPELL IN RANGE | 0.2 | +7.8 | 0.0 | 32.2 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -8.5 | 2.2 | 5.3 | 0.1 | -4.1 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 11.1 | - | - | - | - |
| MOVE TO CHARGE | 2.8 | +138.6 | 88.2 | 111.6 | 4.6 | +312.0 | 218.1 | 106.3 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.1 | +3.4 | 3.9 | 0.0 | 0.1 | +9.0 | 17.2 | 0.0 |
| NOT NEEDED | 0.3 | -18.4 | 40.4 | 7.1 | 0.8 | -38.5 | 106.2 | 15.8 |
| NOT TURNED | 5.9 | +78.8 | 0.0 | 143.8 | 5.1 | +79.2 | 0.0 | 119.1 |
| NOT WORTH A CAST | 0.5 | -0.3 | 0.0 | 0.0 | 0.7 | -0.6 | 0.0 | 0.0 |
| OFF BEST | 14.8 | -695.4 | 0.0 | 313.8 | 14.7 | -751.8 | 19.9 | 226.3 |
| OPENS A LANE | 0.1 | +0.1 | 7.1 | 3.1 | 0.1 | +0.4 | 24.7 | 0.0 |
| OPENS UP | 0.1 | +5.7 | 3.1 | 0.0 | 0.5 | +40.2 | 25.2 | 13.6 |
| OVERRUNS AWAY | 0.5 | +6.5 | 38.9 | 23.9 | 0.8 | +15.2 | 93.1 | 13.8 |
| PATHS CROSS | 1.9 | +127.9 | 0.0 | 19.4 | 3.0 | +206.8 | 0.0 | 43.7 |
| PERIAPT WORTH | 0.0 | +1.6 | 0.0 | 0.0 | 0.0 | +1.4 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.1 | -1.5 | 0.0 | 8.6 | 0.1 | -0.5 | 0.0 | 8.6 |
| PLAN RESULT | 36.7 | +1162.4 | 1226.0 | 1011.8 | 40.9 | +1521.5 | 1610.6 | 872.8 |
| PURSUES BIG PREY | 0.1 | -0.9 | 0.0 | 0.0 | 0.1 | -14.8 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +8.3 | 0.0 | 6.8 | 0.0 | +2.4 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.7 | +20.9 | 0.0 | 14.6 | 1.4 | +20.4 | 0.0 | 33.9 |
| RANDOM MOVER NO PROMISE | 0.2 | -13.8 | 2.0 | 4.7 | 0.2 | -10.6 | 3.5 | 5.8 |
| REDIRECT BY WHAT IT STOPS | 0.1 | -1.4 | 0.0 | 0.0 | 0.2 | -0.6 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.2 | +128.9 | 0.0 | 55.7 | 3.7 | +322.8 | 0.0 | 45.5 |
| REDIRECT WEIGHED | 0.2 | +3.3 | 3.1 | 1.4 | 0.5 | +16.5 | 15.0 | 9.3 |
| RESERVE FALL BACK | 0.4 | +9.6 | 0.0 | 4.2 | 1.2 | +28.8 | 0.0 | 23.2 |
| RESTRAINS TO SHOOT | 0.1 | +12.7 | 0.0 | 0.0 | 0.1 | +1.9 | 0.0 | 0.0 |
| RISK BY ARC | 2.3 | +75.1 | 197.0 | 57.5 | 4.4 | +59.7 | 429.1 | 123.9 |
| SAFER THAN THE JOB | 1.1 | +75.2 | 0.0 | 76.1 | 1.1 | +83.9 | 0.0 | 44.2 |
| SCOUT SPOT | 0.3 | +0.8 | 0.0 | 0.0 | 0.5 | +2.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -7.4 | 0.0 | 0.0 | 0.4 | -27.0 | 0.0 | 1.5 |
| SEARCH SPOT | 3.5 | +155.0 | 0.0 | 49.4 | 2.6 | +103.3 | 0.0 | 39.9 |
| SECOND HUNTER | 0.0 | -0.0 | 0.0 | 0.0 | 0.1 | -0.6 | 20.3 | 1.8 |
| SELF MOVE SPELL | 0.2 | +17.7 | 0.0 | 9.1 | - | - | - | - |
| SET UP TOGETHER | 0.5 | +16.3 | 18.1 | 16.1 | 1.4 | +123.2 | 73.6 | 33.6 |
| SET-UP ANY TARGET | - | - | - | - | 0.1 | +11.8 | 0.0 | 11.2 |
| SET-UP MISSED | 0.1 | +8.8 | 0.0 | 2.6 | 0.1 | +7.5 | 0.0 | 11.2 |
| SHOOTER COUNTED ONCE | 0.0 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.9 | +35.6 | 59.1 | 25.5 | 0.5 | +29.4 | 49.1 | 10.7 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT OPTIONS | 15.5 | +0.0 | 586.9 | 317.4 | 12.5 | +0.0 | 444.0 | 217.5 |
| SHOT REPLANNED | 0.8 | +0.0 | 178.7 | 16.2 | 0.2 | +0.0 | 84.8 | 0.0 |
| SHOTS IN THE MOVE | 13.9 | +517.6 | 0.0 | 287.9 | 10.9 | +320.7 | 0.0 | 165.4 |
| SPELL CATCH ODDS | - | - | - | - | 0.0 | -0.3 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.1 | +20.6 | 0.0 | 0.0 | 0.1 | +29.6 | 0.0 | 11.2 |
| SPELL WORTH | 0.9 | +12.5 | 53.3 | 52.1 | 1.6 | +37.6 | 62.8 | 72.6 |
| STABLE ROLE | 10.8 | +0.0 | 320.6 | 166.4 | 11.8 | +0.0 | 426.3 | 164.2 |
| STANDS TO CAST | 0.1 | +1.1 | 0.0 | 2.2 | 0.0 | +2.5 | 0.0 | 0.0 |
| STAY WEIGHED | 0.1 | +4.9 | 0.0 | 0.0 | 0.1 | +3.1 | 0.0 | 3.9 |
| STAY WORTH | 15.4 | +262.4 | 318.1 | 252.9 | - | - | - | - |
| STOPS | 0.1 | +0.5 | 0.0 | 6.3 | 0.2 | +12.5 | 34.0 | 2.8 |
| STOPS SHORT OF THE FLANK | 0.5 | +34.9 | 0.0 | 29.5 | 0.2 | +9.0 | 0.0 | 34.0 |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 8.8 |
| SUPPORT NARROWED | 6.3 | -43.6 | 275.3 | 106.5 | 8.2 | -50.0 | 582.0 | 151.9 |
| SUPPORTS | 4.2 | +43.6 | 147.8 | 46.1 | 4.4 | +50.0 | 191.2 | 40.2 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -1.4 | 6.8 | 0.0 | 0.0 | -1.6 | 2.4 | 0.0 |
| SURE REACH TOGETHER | 0.5 | +1.8 | 0.0 | 0.0 | 0.8 | +8.2 | 11.2 | 12.2 |
| THREAT IN THE KILL | 11.0 | +132.1 | 626.5 | 298.1 | 0.6 | +13.4 | 145.0 | 0.0 |
| THROUGH LINE OF FIRE | 0.5 | +30.9 | 0.0 | 15.5 | 0.4 | +10.2 | 0.0 | 0.0 |
| TURN WORTH | 0.5 | -37.5 | 36.7 | 10.1 | 0.7 | -51.0 | 50.7 | 5.1 |
| TWO OR MORE ARRIVE | 0.1 | +0.1 | 6.8 | 5.0 | 0.3 | +0.9 | 22.8 | 10.3 |
| WAIT AFTER COSTS | 6.0 | -247.1 | 146.8 | 163.2 | 8.1 | -378.7 | 302.9 | 156.5 |
| WALKS TO THE FIGHT | 1.7 | +31.9 | 30.0 | 26.6 | 1.7 | +39.8 | 37.4 | 25.6 |
| WAR ENGINE CHARGES | 0.1 | +12.4 | 0.0 | 0.0 | 0.0 | +0.5 | 0.9 | 0.0 |
| WAR ENGINE JOBS | 0.6 | +0.0 | 32.0 | 26.2 | 0.1 | +0.0 | 0.0 | 10.3 |
| WEARS DOWN | 1.1 | +43.9 | 100.7 | 24.2 | 2.0 | +56.2 | 220.0 | 52.9 |
| WHO HITS BACK | 0.2 | +19.7 | 0.0 | 5.8 | 0.3 | +18.9 | 0.0 | 8.9 |
| WHOLE FIGHT | 0.2 | +12.3 | 10.4 | 9.4 | 0.4 | +37.4 | 74.4 | 5.4 |
| WHOLE FIGHT GAIN | 0.3 | +24.0 | 33.7 | 7.2 | 0.6 | +57.3 | 57.6 | 22.0 |
| WOUNDED STAYS OUT | 0.1 | +0.0 | 7.2 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |

### Rule changes: shots-h2h-mine-7c46ffc-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1060 | 1060 | 1060 | 29.44 | -52097 | -49.1 |
| BEST FIRST | 322 | 322 | 322 | 8.94 | +13675 | +42.5 |
| SEARCH SPOT | 220 | 220 | 216 | 6.00 | +9347 | +43.3 |
| PATHS CROSS | 176 | 176 | 176 | 4.89 | +12049 | +68.5 |
| COUNTER-CHARGE COVER | 628 | 350 | 159 | 4.42 | +11240 | +70.7 |
| KILLS COUNT NEXT TURN | 429 | 429 | 143 | 3.97 | +4424 | +30.9 |
| MOVE TO CHARGE | 266 | 266 | 124 | 3.44 | +4218 | +34.0 |
| FOLLOW UP WEIGHED | 115 | 115 | 115 | 3.19 | +15475 | +134.6 |
| SUPPORTS | 313 | 313 | 110 | 3.06 | +872 | +7.9 |
| FACES THE THREAT | 107 | 107 | 107 | 2.97 | +9089 | +84.9 |
| FALLBACK BY WORTH | 391 | 391 | 88 | 2.44 | +4819 | +54.8 |
| WAIT AFTER COSTS | 508 | 508 | 79 | 2.19 | +1709 | +21.6 |
| SAFER THAN THE JOB | 78 | 78 | 78 | 2.17 | +5729 | +73.5 |
| SHOTS IN THE MOVE | 894 | 592 | 71 | 1.97 | +1803 | +25.4 |
| CANNON SIGHT KEPT | 70 | 70 | 70 | 1.94 | +0 | +0.0 |
| WALKS TO THE FIGHT | 122 | 122 | 66 | 1.83 | +898 | +13.6 |
| ARTILLERY RE-ROLL WEIGHED | 58 | 58 | 58 | 1.61 | +0 | +0.0 |
| RESERVE FALL BACK | 57 | 57 | 57 | 1.58 | +1381 | +24.2 |
| BEST OVERALL | 53 | 53 | 53 | 1.47 | +3461 | +65.3 |
| REDIRECT COUNTER | 215 | 119 | 51 | 1.42 | +3966 | +77.8 |
| CANNON PLANNED TARGET | 245 | 245 | 49 | 1.36 | -440 | -9.0 |
| BEST FACING | 48 | 48 | 48 | 1.33 | +1540 | +32.1 |
| CHARGE NOW FIRST | 241 | 241 | 47 | 1.31 | -3835 | -81.6 |
| MAX FOR POSITIONING | 357 | 211 | 47 | 1.31 | +825 | +17.5 |
| STAY WORTH | 554 | 441 | 46 | 1.28 | +1117 | +24.3 |
| COMBAT PIVOT | 43 | 43 | 43 | 1.19 | +0 | +0.0 |
| RISK BY ARC | 241 | 237 | 43 | 1.19 | +1353 | +31.5 |
| ADVANCE LANE KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| KILLS COUNT | 176 | 173 | 42 | 1.17 | +1599 | +38.1 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 39 | 39 | 39 | 1.08 | +3572 | +91.6 |
| RANDOM MOVE BY FIGURES | 77 | 77 | 39 | 1.08 | +1487 | +38.1 |
| BLOCKED WHEEL | 37 | 37 | 37 | 1.03 | +586 | +15.8 |
| THREAT IN THE KILL | 418 | 328 | 34 | 0.94 | +385 | +11.3 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2266 | +68.7 |
| SHOT REPLANNED | 33 | 33 | 33 | 0.92 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 33 | 33 | 33 | 0.92 | +1479 | +44.8 |
| BEST MOVE FOR SHOOTERS | 32 | 32 | 32 | 0.89 | +1868 | +58.4 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| SET UP TOGETHER | 68 | 61 | 31 | 0.86 | +2106 | +67.9 |
| MISSILES IN THE MOVE | 252 | 145 | 30 | 0.83 | +970 | +32.3 |
| FOCUS OVER TURNS | 53 | 53 | 28 | 0.78 | +431 | +15.4 |
| MOVE AND CAST | 27 | 27 | 27 | 0.75 | +1787 | +66.2 |
| KEEPS ITS TARGET | 136 | 135 | 25 | 0.69 | +398 | +15.9 |
| MARCH CHECK | 27 | 27 | 25 | 0.69 | +797 | +31.9 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +50 | +2.0 |
| STOPS SHORT OF THE FLANK | 25 | 25 | 25 | 0.69 | +1583 | +63.3 |
| FRIENDS SHOTS CHECKED | 24 | 24 | 24 | 0.67 | +1843 | +76.8 |
| REDIRECT WEIGHED | 24 | 24 | 24 | 0.67 | +1021 | +42.5 |
| MARCH ODDS | 23 | 23 | 23 | 0.64 | +743 | +32.3 |
| MODEL FACING | 23 | 23 | 23 | 0.64 | +5299 | +230.4 |
| SHOOTS FROM THE BEST SPOT | 49 | 49 | 22 | 0.61 | +783 | +35.6 |
| CAST JOB | 44 | 44 | 20 | 0.56 | +352 | +17.6 |
| BEST PREY | 63 | 63 | 19 | 0.53 | +613 | +32.2 |
| INVITES THE FIGHT | 88 | 88 | 18 | 0.50 | +205 | +11.4 |
| WHOLE FIGHT GAIN | 32 | 29 | 18 | 0.50 | +1166 | +64.8 |
| WHO HITS BACK | 17 | 17 | 17 | 0.47 | +719 | +42.3 |
| CASTER AWAY FROM SCREEN | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| CHAFF PASSED | 15 | 15 | 15 | 0.42 | -22 | -1.5 |
| LOST CHARGE | 202 | 201 | 14 | 0.39 | +232 | +16.5 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| WEARS DOWN | 112 | 109 | 14 | 0.39 | +368 | +26.3 |
| MAKE SURE TOGETHER | 32 | 24 | 13 | 0.36 | +462 | +35.6 |
| CASTING BLOCK | 20 | 20 | 12 | 0.33 | +447 | +37.2 |
| STUCK PIVOT | 12 | 12 | 12 | 0.33 | +0 | +0.0 |
| MANOEUVRE | 15 | 15 | 11 | 0.31 | +330 | +30.0 |
| BIG CHARACTER SAFETY | 10 | 10 | 10 | 0.28 | -49 | -4.9 |
| WAR ENGINE JOBS | 23 | 23 | 9 | 0.25 | -436 | -48.5 |
| OPENS UP | 20 | 20 | 8 | 0.22 | +264 | +33.0 |
| RESTRAINS TO SHOOT | 8 | 8 | 8 | 0.22 | +528 | +66.1 |
| WHOLE FIGHT | 23 | 23 | 8 | 0.22 | +786 | +98.2 |
| OVERRUNS AWAY | 49 | 47 | 7 | 0.19 | +220 | +31.4 |
| SUPPORT NARROWED | 523 | 523 | 7 | 0.19 | -208 | -29.7 |
| HUNT IN PAIRS | 37 | 21 | 6 | 0.17 | +250 | +41.7 |
| PIVOT GUARDS FLANK | 6 | 6 | 6 | 0.17 | -73 | -12.2 |
| MISSILES NEXT TURN | 291 | 159 | 5 | 0.14 | +21 | +4.2 |
| STAY WEIGHED | 5 | 5 | 5 | 0.14 | +288 | +57.6 |
| SURE REACH TOGETHER | 47 | 29 | 5 | 0.14 | +60 | +11.9 |
| BLOCKED CHARGE SKIPPED | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| NEEDED THERE | 5 | 5 | 4 | 0.11 | +0 | +0.0 |
| PURSUES BIG PREY | 4 | 4 | 4 | 0.11 | -565 | -141.4 |
| RAIDS THE BAGGAGE NEXT TURN | 4 | 4 | 4 | 0.11 | +218 | +54.4 |
| SURE CHARGE BEATS ADVANCE | 4 | 4 | 4 | 0.11 | -111 | -27.8 |
| BOMBING RUN | 3 | 3 | 3 | 0.08 | +98 | +32.7 |
| STANDS TO CAST | 3 | 3 | 3 | 0.08 | -16 | -5.3 |
| BACKUP TARGETS | 81 | 48 | 2 | 0.06 | +34 | +17.0 |
| BEST PRIZE | 2 | 2 | 2 | 0.06 | -81 | -40.7 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.06 | +0 | +0.2 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| EDGE GIVE GROUND | 18 | 18 | 2 | 0.06 | +38 | +19.1 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +43 | +21.4 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +50 | +24.8 |
| LONE WIZARD HOLDS BACK | 14 | 14 | 2 | 0.06 | -291 | -145.5 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +108 | +54.1 |
| WAR ENGINE CHARGES | 4 | 4 | 2 | 0.06 | +324 | +161.9 |
| WOUNDED STAYS OUT | 3 | 3 | 2 | 0.06 | -677 | -338.4 |
| CARRIES OUT COUNTER | 5 | 5 | 1 | 0.03 | -11 | -11.0 |
| CARRIES OUT SET-UP | 7 | 7 | 1 | 0.03 | -21 | -21.3 |
| CHARIOT NO STATIC JOB | 2 | 2 | 1 | 0.03 | -55 | -54.8 |
| DEFENSIVE ARMY | 13 | 13 | 1 | 0.03 | -20 | -19.6 |
| FACE THE CAST | 1 | 1 | 1 | 0.03 | +20 | +20.5 |
| HILL BY ITS CHANCE | 40 | 40 | 1 | 0.03 | +56 | +55.8 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +5 | +4.6 |
| HUNT ADVANCE | 15 | 15 | 1 | 0.03 | +31 | +30.8 |
| JOINT CHARGE PLAN | 4 | 4 | 1 | 0.03 | +62 | +62.3 |
| KEEP FALLS | 1 | 1 | 1 | 0.03 | +2 | +1.5 |
| LONG SHOT | 50 | 48 | 1 | 0.03 | +20 | +20.0 |
| MOVE SPELL IN RANGE | 6 | 3 | 1 | 0.03 | +0 | +0.4 |
| STOPS | 9 | 9 | 1 | 0.03 | +38 | +38.2 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 3 | 3 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 32 | 32 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 27 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 2 | 2 | 0 | 0.00 | - | - |
| CHEAP HELPER | 9 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 33 | not checked | - | - | - | - |
| DEFENSIVE FLOOR | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 389 | not checked | - | - | - | - |
| GIVES UP | 5 | 4 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 5 | 5 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 5 | not checked | - | - | - | - |
| HELPER UNSEEN | 25 | 23 | 0 | 0.00 | - | - |
| HUNT DROPPED | 5 | trace | - | - | - | - |
| HUNT KEPT | 11 | trace | - | - | - | - |
| HUNT RESULT | 17 | trace | - | - | - | - |
| HUNT THE GUNS | 17 | trace | - | - | - | - |
| KEEPS ITS PREY | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 15 | not checked | - | - | - | - |
| LURE BY WHAT IT DRAWS | 6 | 6 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 28 | 28 | 0 | 0.00 | - | - |
| MISSILES IN THE PLAN | 39 | 2 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 17 | 17 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 15 | trace | - | - | - | - |
| MOVE SPELL SPOT | 9 | not checked | - | - | - | - |
| NOT NEEDED | 39 | 38 | 0 | 0.00 | - | - |
| NOT TURNED | 396 | 396 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 41 | not checked | - | - | - | - |
| OPENS A LANE | 6 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 2792 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 16 | 16 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 11 | 11 | 0 | 0.00 | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 18 | 18 | 0 | 0.00 | - | - |
| SECOND HUNTER | 5 | 5 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 8 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 4 | not checked | - | - | - | - |
| SET-UP MISSED | 6 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOT OPTIONS | 1010 | 1010 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 7 | not checked | - | - | - | - |
| SPELL WORTH | 91 | not checked | - | - | - | - |
| STABLE ROLE | 812 | 810 | 0 | 0.00 | - | - |
| TURN WORTH | 42 | 42 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 14 | 11 | 0 | 0.00 | - | - |

### Off best figure: shots-h2h-mine-7c46ffc-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 13.56 | 12.86 | 49.3 |
| CHARGE NOW FIRST | rule | 0.58 | 0.72 | 81.6 |
| TURN GATE | gate | 0.64 | 0.58 | 49.5 |
| FALLBACK | gate | 0.28 | 0.89 | 49.9 |
| CANNON PLANNED TARGET | rule | 0.42 | 0.08 | 27.9 |
| PATHS CROSS | rule | 0.11 | 0.17 | 12.3 |
| WAR ENGINE JOBS | rule | 0.22 | 0.03 | 48.5 |
| CHARGE NOW WEIGHED | rule | 0.08 | 0.14 | 43.9 |
| BIG CHARACTER SAFETY | rule | 0.11 | 0.08 | 9.0 |
| CHAFF PASSED | rule | 0.08 | 0.11 | 3.1 |
| SUPPORT NARROWED | rule | 0.08 | 0.11 | 29.7 |
| THROUGH LINE OF FIRE | rule | 0.11 | 0.08 | 25.5 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.06 | 12.2 |
| FIGHT ORDER BAND | gate | 0.11 | 0.03 | 3.2 |
| SUPPORT REQUEST | gate | - | 0.14 | 66.1 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | 0.06 | 63.0 |
| LONE CHARACTER SAFE SPOT | gate | 0.06 | 0.06 | 72.9 |
| PURSUES BIG PREY | rule | 0.06 | 0.06 | 141.4 |
| SURE CHARGE BEATS ADVANCE | rule | 0.08 | 0.03 | 27.8 |
| AFTERMATH BAND | gate | 0.03 | 0.06 | 1.9 |
| BLOCKED WHEEL | rule | 0.06 | 0.03 | 1.7 |
| STOPS SHORT OF THE FLANK | rule | 0.06 | 0.03 | 6.3 |
| BEST PRIZE | rule | 0.03 | 0.03 | 40.7 |
| FACES THE THREAT | rule | 0.03 | 0.03 | 9.5 |
| MARCH ODDS | rule | 0.06 | - | 7.4 |
| SAFER THAN THE JOB | rule | 0.03 | 0.03 | 12.5 |
| STANDS TO CAST | rule | 0.03 | 0.03 | 8.4 |
| WOUNDED STAYS OUT | rule | 0.03 | 0.03 | 338.4 |
| CARRIES OUT COUNTER | rule | 0.03 | - | 11.0 |
| CARRIES OUT SET-UP | rule | - | 0.03 | 21.3 |
| CHARIOT NO STATIC JOB | rule | 0.03 | - | 54.8 |
| DEFENSIVE ARMY | rule | - | 0.03 | 19.6 |
| LONE WIZARD HOLDS BACK | rule | 0.03 | - | 291.0 |
| NO REASON | gate | 0.03 | - | 2.6 |
| RULE SWITCHED OFF | gate | - | 0.03 | 3.8 |

### Plans: shots-h2h-mine-7c46ffc-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.1 | 16% | 478 | 273 | 57% |
| Mine | charge | 2.9 | 63% | 298 | 251 | 84% |
| Mine | close in | 3.6 | 25% | 181 | 73 | 40% |
| Mine | hold | 4.2 | 29% | 247 | 0 | 0% |
| Mine | join | 0.8 | 100% | 23 | 0 | 0% |
| Mine | shoot | 8.7 | 59% | 378 | 566 | 150% |
| Mine | support | 4.4 | 92% | 26 | 0 | 0% |
| Opponent | advance | 13.6 | 15% | 414 | 350 | 84% |
| Opponent | charge | 6.3 | 54% | 689 | 555 | 81% |
| Opponent | close in | 5.8 | 30% | 420 | 136 | 32% |
| Opponent | hold | 4.6 | 37% | 345 | 0 | 0% |
| Opponent | join | 0.9 | 94% | 49 | 0 | 0% |
| Opponent | shoot | 4.9 | 64% | 223 | 481 | 216% |
| Opponent | support | 4.8 | 90% | 42 | 0 | 0% |

### Packages: hunt the guns, shots-h2h-mine-7c46ffc-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 5 | 0 | 0% | 0% | 0% | - | 191 | 0 | 0% | 34 |
| Opponent | 0.3 | 12 | 0 | 33% | 58% | 0% | 2.9 | 391 | 203 | 58% | 66 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 122 | 0 | 0% | 34 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 155 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 59 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 99 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 156 |
| High Elf Realms | 0.5 | 2 | 0 | 0% | 0% | 0% | - | 223 | 0 | 0% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 40 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.8 | 7 | 0 | 43% | 43% | 0% | 2.7 | 412 | 193 | 43% | 147 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 48 |
| Tomb Kings of Khemri | 1.0 | 5 | 0 | 20% | 80% | 0% | 3.0 | 265 | 217 | 80% | 0 |
| Vampire Counts | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 416 | 0 | 0% | 0 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 450 | 0 | 0% | 7 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: shots-h2h-mine-7c46ffc-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 10.8 | 26% | 50% | 11% | 18% | 28% | 19% | 10% | 43% | 0% |
| Mine | REDIRECT COUNTER | 2.2 | 41% | 58% | 9% | 0% | 20% | 0% | 13% | 67% | 0% |
| Opponent | COUNTER-CHARGE COVER | 6.7 | 20% | 76% | 22% | 27% | 32% | 13% | 8% | 47% | 0% |
| Opponent | REDIRECT COUNTER | 3.7 | 21% | 71% | 14% | 25% | 12% | 0% | 21% | 62% | 4% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: shots-h2h-mine-7c46ffc-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 0 (5) | 0 | 0 | 52 | 20% | 3.8 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Mine | Chaff | 35 | 64 (35) | 31 | 33 | 72 | 31% | 2.7 | 47 (19) | 196 (7) | 4 (9) | 89 (24) | 5 (11) |
| Mine | Character | 123 | 52 (123) | 51 | 1 | 36 | 17% | 2.5 | 64 (38) | 56 (50) | 15 (13) | 72 (53) | 38 (48) |
| Mine | Clean-up | 20 | 39 (20) | 8 | 31 | 60 | 40% | 2.7 | 33 (5) | 29 (12) | 95 (3) | 72 (12) | 10 (8) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 44 | 43 (44) | 23 | 20 | 55 | 18% | 2.6 | 22 (21) | 86 (16) | 37 (7) | 32 (27) | 60 (17) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 20 | 0% | 1.8 | - | 0 (3) | 0 (2) | 0 (5) | - |
| Mine | Hammer | 57 | 30 (57) | 20 | 10 | 45 | 18% | 2.8 | 10 (18) | 48 (29) | 14 (10) | 29 (38) | 32 (19) |
| Mine | Holder | 29 | 56 (29) | 18 | 38 | 25 | 38% | 3.1 | 62 (10) | 67 (11) | 29 (7) | 68 (21) | 24 (7) |
| Mine | Shooter | 44 | 89 (44) | 37 | 52 | 51 | 5% | 1.4 | 85 (7) | 101 (30) | 44 (7) | 116 (26) | 52 (18) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | War machine | 59 | 33 (59) | 33 | 0 | 55 | 5% | 1.2 | 0 (10) | 45 (37) | 16 (12) | 13 (10) | 37 (49) |
| Mine | Wizard | 22 | 15 (22) | 15 | 0 | 45 | 23% | 2.3 | 24 (7) | 0 (5) | 29 (5) | 43 (5) | 14 (12) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Chaff | 76 | 59 (76) | 29 | 29 | 43 | 38% | 2.3 | 85 (32) | 28 (19) | 52 (25) | 73 (54) | 24 (22) |
| Opponent | Character | 94 | 62 (94) | 62 | 0 | 30 | 28% | 2.6 | 74 (41) | 62 (40) | 43 (4) | 51 (58) | 91 (27) |
| Opponent | Clean-up | 21 | 11 (21) | 6 | 5 | 43 | 29% | 3.1 | 6 (9) | 16 (12) | - | 10 (15) | 13 (6) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 50 | 0% | 5.5 | - | 0 (1) | 0 (1) | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 48 | 45 (48) | 31 | 14 | 39 | 27% | 2.6 | 45 (22) | 37 (16) | 60 (10) | 40 (28) | 54 (20) |
| Opponent | Fragile | 5 | 0 (5) | 0 | 0 | 80 | 40% | 2.0 | - | 0 (3) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | Hammer | 68 | 43 (68) | 38 | 5 | 48 | 22% | 3.0 | 22 (17) | 52 (40) | 28 (11) | 55 (42) | 25 (26) |
| Opponent | Holder | 35 | 78 (35) | 7 | 72 | 22 | 23% | 3.7 | 50 (6) | 90 (22) | 62 (7) | 105 (22) | 30 (13) |
| Opponent | Shooter | 33 | 92 (33) | 22 | 70 | 27 | 0% | 2.1 | 72 (8) | 109 (19) | 58 (6) | 141 (22) | 17 (11) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 25 | 33% | 5.5 | 0 (2) | 0 (1) | - | 0 (1) | 0 (2) |
| Opponent | War machine | 24 | 43 (24) | 43 | 0 | 14 | 12% | 1.7 | 14 (6) | 59 (14) | 30 (4) | 0 (3) | 50 (21) |
| Opponent | Wizard | 29 | 23 (29) | 23 | 0 | 55 | 7% | 1.4 | 0 (10) | 61 (7) | 28 (7) | 56 (10) | 0 (14) |

### Charged fights: shots-h2h-mine-7c46ffc-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 154 | 197 | 2.0 | 1.0 | 98 | 17 | +81 | 3 of 8 | 4 of 8 | - | +81 |
| Mine | Chaos Dwarfs | 4 | 171 | 390 | 2.2 | 1.1 | 173 | 0 | +173 | 4 of 9 | 7 of 9 | +764 | +99 |
| Mine | Dwarfen Mountain Holds | 4 | 464 | 62 | 1.5 | 1.2 | 42 | 0 | +42 | 1 of 6 | 4 of 6 | +0 | +50 |
| Mine | Empire of Man | 5 | 386 | 48 | 1.4 | 1.0 | 35 | 32 | +2 | 2 of 7 | 4 of 7 | - | +2 |
| Mine | Grand Cathay | 4 | 184 | 117 | 2.0 | 1.4 | 59 | 27 | +32 | 3 of 8 | 7 of 8 | +0 | +50 |
| Mine | High Elf Realms | 4 | 310 | 560 | 4.8 | 1.1 | 118 | 20 | +98 | 8 of 19 | 15 of 19 | +338 | +70 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 532 | 3.0 | 1.3 | 177 | 88 | +89 | 0 of 3 | 3 of 3 | -59 | +164 |
| Mine | Lizardmen | 1 | 45 | 1027 | 3.0 | 1.3 | 342 | 0 | +342 | 1 of 3 | 1 of 3 | +54 | +486 |
| Mine | Ogre Kingdoms | 1 | 0 | 45 | 7.0 | 1.0 | 6 | 114 | -108 | 2 of 7 | 3 of 6 | - | -108 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 235 | 3.0 | 1.3 | 78 | 0 | +78 | 1 of 3 | 2 of 3 | +45 | +95 |
| Mine | Skaven | 2 | 0 | 58 | 2.5 | 1.0 | 23 | 0 | +23 | 0 of 5 | 3 of 5 | - | +23 |
| Mine | Tomb Kings of Khemri | 1 | 102 | 515 | 5.0 | 1.4 | 103 | 0 | +103 | 0 of 5 | 4 of 5 | +195 | +42 |
| Mine | Vampire Counts | 3 | 41 | 148 | 3.3 | 1.5 | 44 | 49 | -4 | 2 of 10 | 9 of 10 | +98 | -73 |
| Mine | Warriors of Chaos | 1 | 19 | 866 | 2.0 | 1.0 | 433 | 0 | +433 | 0 of 2 | 2 of 2 | - | +433 |
| **Mine** | all armies | 36 | 204 | 259 | 2.6 | 1.2 | 98 | 26 | +72 | 27 of 95 | 68 of 94 | +142 | +58 |
| Opponent | Dwarfen Mountain Holds | 2 | 68 | 68 | 3.0 | 1.2 | 23 | 0 | +23 | 0 of 6 | 4 of 6 | +81 | +11 |
| Opponent | Empire of Man | 2 | 600 | 170 | 2.0 | 1.0 | 85 | 0 | +85 | 1 of 4 | 3 of 4 | - | +85 |
| Opponent | Grand Cathay | 2 | 463 | 640 | 3.0 | 1.7 | 214 | 70 | +143 | 4 of 6 | 6 of 6 | +95 | +167 |
| Opponent | Kingdom of Bretonnia | 1 | 235 | 291 | 3.0 | 1.0 | 97 | 0 | +97 | 2 of 3 | 3 of 3 | - | +97 |
| Opponent | Ogre Kingdoms | 3 | 50 | 359 | 5.3 | 1.2 | 67 | 19 | +49 | 2 of 16 | 10 of 16 | +107 | +29 |
| Opponent | Skaven | 1 | 656 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Tomb Kings of Khemri | 4 | 52 | 1330 | 5.0 | 1.4 | 266 | 74 | +192 | 10 of 20 | 13 of 20 | +326 | +135 |
| Opponent | Vampire Counts | 6 | 0 | 601 | 5.0 | 1.2 | 120 | 27 | +94 | 12 of 30 | 23 of 30 | +19 | +109 |
| Opponent | Warriors of Chaos | 8 | 51 | 349 | 1.8 | 1.0 | 200 | 35 | +165 | 5 of 14 | 8 of 14 | - | +165 |
| Opponent | Wood Elf Realms | 7 | 84 | 551 | 5.7 | 1.2 | 96 | 19 | +77 | 13 of 40 | 29 of 40 | +108 | +70 |
| **Opponent** | all armies | 36 | 125 | 520 | 3.9 | 1.2 | 135 | 31 | +104 | 49 of 139 | 99 of 139 | +139 | +96 |

### Effective charges: shots-h2h-mine-7c46ffc-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 8 | 1 (net -85) | 0 | 2 (net +35) | 3 (net +55) | 0 | 1 (net +72) | 1 | 29% (2 of 7) |
| Mine | Chaos Dwarfs | 9 | 2 (net +240) | 0 | 1 (net +268) | 4 (net +191) | 0 | 2 (net +22) | 0 | 11% (1 of 9) |
| Mine | Dwarfen Mountain Holds | 6 | 0 | 1 (net +0) | 0 | 1 (net +0) | 0 | 4 (net +62) | 0 | 0% (0 of 6) |
| Mine | Empire of Man | 7 | 0 | 0 | 2 (net -114) | 2 (net +32) | 1 (net +65) | 1 (net +0) | 1 | 33% (2 of 6) |
| Mine | Grand Cathay | 8 | 1 (net -217) | 0 | 1 (net +0) | 0 | 2 (net +0) | 4 (net +117) | 0 | 12% (1 of 8) |
| Mine | High Elf Realms | 19 | 1 (net -143) | 2 (net -58) | 1 (net +282) | 1 (net +0) | 7 (net +186) | 6 (net +71) | 1 | 6% (1 of 18) |
| Mine | Kingdom of Bretonnia | 3 | 0 | 0 | 1 (net +205) | 0 | 0 | 2 (net +32) | 0 | 33% (1 of 3) |
| Mine | Lizardmen | 3 | 2 (net +486) | 0 | 0 | 0 | 1 (net +54) | 0 | 0 | 0% (0 of 3) |
| Mine | Ogre Kingdoms | 7 | 1 (net -234) | 0 | 0 | 1 (net +0) | 1 (net +45) | 2 (net -92) | 2 | 0% (0 of 5) |
| Mine | Orc & Goblin Tribes | 3 | 0 | 0 | 1 (net +45) | 0 | 0 | 1 (net +190) | 1 | 50% (1 of 2) |
| Mine | Skaven | 5 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 3 (net +39) | 0 | 0% (0 of 5) |
| Mine | Tomb Kings of Khemri | 5 | 0 | 0 | 1 (net +250) | 0 | 0 | 2 (net +132) | 2 | 33% (1 of 3) |
| Mine | Vampire Counts | 10 | 3 (net -146) | 1 (net +114) | 1 (net +0) | 3 (net +68) | 1 (net +75) | 1 (net +0) | 0 | 10% (1 of 10) |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +433) | 0 | 0% (0 of 2) |
| Opponent | Dwarfen Mountain Holds | 6 | 1 (net +0) | 0 | 1 (net +0) | 1 (net +0) | 0 | 3 (net +45) | 0 | 17% (1 of 6) |
| Opponent | Empire of Man | 4 | 2 (net +0) | 0 | 1 (net +230) | 1 (net +110) | 0 | 0 | 0 | 25% (1 of 4) |
| Opponent | Grand Cathay | 6 | 1 (net +190) | 0 | 2 (net +182) | 0 | 1 (net +0) | 2 (net +152) | 0 | 33% (2 of 6) |
| Opponent | Kingdom of Bretonnia | 3 | 0 | 1 (net +105) | 1 (net +0) | 0 | 0 | 0 | 1 | 50% (1 of 2) |
| Opponent | Ogre Kingdoms | 16 | 2 (net +148) | 0 | 3 (net +79) | 2 (net +22) | 1 (net +104) | 5 (net +19) | 3 | 23% (3 of 13) |
| Opponent | Tomb Kings of Khemri | 20 | 4 (net +22) | 0 | 2 (net +456) | 2 (net +55) | 2 (net +389) | 9 (net +183) | 1 | 11% (2 of 19) |
| Opponent | Vampire Counts | 30 | 9 (net +54) | 0 | 5 (net +143) | 6 (net +105) | 1 (net +165) | 8 (net +101) | 1 | 17% (5 of 29) |
| Opponent | Warriors of Chaos | 14 | 3 (net +59) | 0 | 2 (net -85) | 4 (net +364) | 1 (net +80) | 4 (net +191) | 0 | 14% (2 of 14) |
| Opponent | Wood Elf Realms | 40 | 4 (net +135) | 2 (net +0) | 6 (net +55) | 9 (net +77) | 3 (net +123) | 14 (net +72) | 2 | 16% (6 of 38) |

### Charged fights, damage counted: shots-h2h-mine-7c46ffc-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 12 | 168 | 219 | +28 | 156 | 93 | +63 | +37.6 |
| Mine | 50-54% | 4 | 186 | 210 | -0 | 40 | 29 | +12 | +6.3 |
| Mine | Effective (55-75%) | 11 | 312 | 214 | +81 | 157 | 46 | +111 | +35.5 |
| Mine | 76-89% | 16 | 228 | 181 | +75 | 92 | 24 | +68 | +29.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 31 | 258 | 160 | +83 | 115 | 30 | +86 | +33.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 13 | 462 | 106 | +118 | 129 | 8 | +122 | +26.3 |
| Mine | No odds | 8 | 264 | 165 | +34 | 81 | 56 | +25 | +9.7 |
| Mine | All fights | 95 | 273 | 173 | +72 | 117 | 38 | +79 | +29.1 |
| Opponent | Long shot (under 50%) | 26 | 265 | 273 | +69 | 150 | 86 | +65 | +24.4 |
| Opponent | 50-54% | 3 | 164 | 186 | +35 | 56 | 6 | +50 | +30.4 |
| Opponent | Effective (55-75%) | 23 | 270 | 211 | +114 | 144 | 50 | +94 | +34.8 |
| Opponent | 76-89% | 25 | 220 | 150 | +122 | 146 | 29 | +117 | +53.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 45 | 278 | 183 | +106 | 175 | 60 | +115 | +41.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 646 | 129 | +166 | 201 | 51 | +149 | +23.1 |
| Opponent | No odds | 8 | 189 | 243 | +80 | 80 | 6 | +74 | +39.2 |
| Opponent | All fights | 139 | 280 | 199 | +104 | 154 | 53 | +101 | +36.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| shots-h2h-mine-7c46ffc-p2 | move | 445 | 108 (24%) | 70 (16%) | 60 (13%) | 277 (62%) |
| shots-h2h-mine-7c46ffc-p2 | objective | 339 | 68 (20%) | 47 (14%) | 47 (14%) | 224 (66%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

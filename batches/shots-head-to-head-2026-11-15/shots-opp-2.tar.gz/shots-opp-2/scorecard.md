# Doctrine scorecard: shots-h2h-opp-7c46ffc-p2

### Scorecard: shots-h2h-opp-7c46ffc-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 0 | 6 | 0 | 2 | 0 | 0 | 0 | 387 |
| L0106 | 4 | 1 | Opponent | no | 0 | 2 | 0 | 1 | 0 | 0 | 0 | 615 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 639 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | - | 0 | 4 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 2 | 1 | 0 | 0 | 0 | 0 | 743 |
| L0222 | 6 | 1 | Mine | no | 8 | 3 | 3 | 1 | 1 | 0 | 0 | 200 |
| L0222 | 6 | 1 | Opponent | no | 5 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 675 |
| L0307 | 1 | 1 | Opponent | yes | 2 | 2 | 0 | 1 | 1 | 0 | 0 | 420 |
| L0323 | 5 | 1 | Mine | no | - | - | 0 | 0 | 0 | 0 | 0 | 590 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Mine | no | 2 | 2 | 5 | 1 | 0 | 0 | 0 | 124 |
| L0409 | 1 | 1 | Opponent | no | 0 | 4 | 1 | 0 | 0 | 0 | 0 | 933 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | no | - | 2 | 1 | 5 | 1 | 0 | 0 | 348 |
| L0512 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 1042 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 2 | 2 | 1 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | yes | 7 | 5 | 2 | 1 | 0 | 0 | 0 | 475 |
| L0528 | 6 | 1 | Opponent | no | 6 | - | 1 | 1 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | 6 | 1 | 1 | 1 | 0 | 0 | 615 |
| L0616 | 4 | 1 | Opponent | no | 0 | 3 | 2 | 2 | 0 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 2 | 0 | 0 | 1 | 0 | 0 | 926 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 4 | 3 | 0 | 0 | 0 | 170 |
| L0721 | 1 | 1 | Mine | yes | 0 | 2 | 3 | 1 | 0 | 0 | 0 | 375 |
| L0721 | 1 | 1 | Opponent | yes | 0 | - | 0 | 3 | 0 | 0 | 0 | 355 |
| L0810 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 724 |
| L0810 | 6 | 1 | Opponent | no | 16 | 2 | 4 | 1 | 0 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 886 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 375 |
| L0918 | 6 | 1 | Opponent | no | 8 | 3 | 4 | 1 | 0 | 0 | 0 | 419 |
| L0934 | 4 | 1 | Mine | no | 0 | 1 | 2 | 0 | 0 | 0 | 0 | 723 |
| L0934 | 4 | 1 | Opponent | no | 0 | 2 | 7 | 4 | 0 | 0 | 0 | 216 |
| L1026 | 6 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 6 | 2 | 6 | 0 | 1 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 6 | 0 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 40 |
| L1135 | 1 | 1 | Mine | yes | 7 | - | 0 | 0 | 1 | 0 | 0 | 330 |
| L1135 | 1 | 1 | Opponent | no | 1 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 3 | 4 | 0 | 1 | 0 | 0 | 0 | 858 |
| L1228 | 4 | 1 | Opponent | no | 7 | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1323 | 3 | 1 | Mine | no | 0 | 2 | 4 | 1 | 2 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | no | 2 | 2 | 7 | 0 | 0 | 0 | 0 | 66 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 3 | 4 | 3 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Mine | no | 0 | 4 | 0 | 0 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 1 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | yes | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 484 |
| L1629 | 3 | 1 | Mine | no | 2 | 1 | 3 | 1 | 0 | 0 | 0 | 200 |
| L1629 | 3 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | yes | - | 3 | 2 | 0 | 0 | 0 | 0 | 135 |
| L1727 | 5 | 1 | Opponent | yes | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L1827 | 3 | 1 | Mine | no | 0 | 4 | 1 | 0 | 0 | 0 | 0 | 602 |
| L1827 | 3 | 1 | Opponent | no | 8 | 2 | 8 | 1 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 2 | 1 | 4 | 1 | 0 | 0 | 0 | 317 |
| L1927 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 3 | 1 | 0 | 0 | 190 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 0 | 0 | 1 | 0 | 0 | 420 |
| L2029 | 1 | 1 | Opponent | no | 0 | 2 | 6 | 0 | 0 | 0 | 0 | 170 |
| L2131 | 1 | 1 | Mine | yes | 2 | - | 2 | 2 | 0 | 0 | 0 | 0 |
| L2131 | 1 | 1 | Opponent | no | 1 | 2 | 0 | 1 | 1 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | no | 2 | 1 | 5 | 0 | 1 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 126 |
| L2429 | 5 | 1 | Mine | yes | - | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | no | - | 3 | 4 | 1 | 1 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Mine | no | 5 | 3 | 2 | 1 | 1 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 2 | 1 | 6 | 0 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | yes | - | 5 | 2 | 6 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 1 | 2 | 4 | 1 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | yes | 2 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 0 | 1 | 7 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 30% | 1.8 | 2.8 | 1.8 | 1.1 | 0.3 | 0.0 | 0.0 | 344.9 |
| **Average** | | | Opponent | 23% | 2.7 | 2.1 | 3.5 | 1.6 | 0.2 | 0.0 | 0.0 | 180.4 |

### KPIs: shots-h2h-opp-7c46ffc-p2

Rules off - Mine only: STAY WORTH, BEST MOVE FOR SHOOTERS, THREAT IN THE KILL, FOCUS OVER TURNS, MISSILES IN THE PLAN, FACE THE CAST, WIZARD FRONT RANK.

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 28% (48 of 172) | 14% (25 of 181) | 21% (73 of 353) |
| Winner chose to follow up after the loser gave ground |  | 97% (76 of 78); on the table 97% | 100% (57 of 57); on the table 100% | 99% (133 of 135); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (6 of 6); on the table 100% | 92% (12 of 13); on the table 100% | 95% (18 of 19); on the table 100% |
| Winner chose to pursue after the loser fled |  | 77% (23 of 30); on the table 87% | 67% (28 of 42); on the table 76% | 71% (51 of 72); on the table 81% |
| Winner chose to follow up or pursue (all three) |  | 92% (105 of 114); on the table 95% | 87% (97 of 112); on the table 91% | 89% (202 of 226); on the table 93% |
| Magic missiles tried each own turn | 50%+ | 30% (102 of 342) | 34% (53 of 156) | 31% (155 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 48% (102 of 213) | 49% (53 of 109) | 48% (155 of 322) |
|   fighting wizards (on a monster, chariot or monstrous mount) | 50%+ | 27% (40 of 150) | 22% (17 of 78) | 25% (57 of 228) |
|     round 1 |  | 24% (6 of 25) | 15% (2 of 13) | 21% (8 of 38) |
|     rounds 2+ |  | 27% (34 of 125) | 23% (15 of 65) | 26% (49 of 190) |
|   other wizards | 50%+ | 32% (62 of 192) | 46% (36 of 78) | 36% (98 of 270) |
|     round 1 |  | 44% (14 of 32) | 54% (7 of 13) | 47% (21 of 45) |
|     rounds 2+ |  | 30% (48 of 160) | 45% (29 of 65) | 34% (77 of 225) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 53% (17 of 32) | 62% (30 of 48) | 59% (47 of 80) |
| Points that never fought | lower | 35% (24734 of 71583) | 35% (25549 of 71989) | 35% (50283 of 143572) |
|   infantry points that never fought | lower | 44% (7177 of 16324) | 59% (8262 of 14029) | 51% (15439 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% (173 of 284) | 57% (168 of 297) | 59% (341 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 95% (19 of 20); 1.3 uses a game | 72% (13 of 18); 1.1 uses a game | 84% (32 of 38); 1.2 uses a game |
| Bound items with another spell used |  | 61% (11 of 18); 0.6 uses a game | 50% (1 of 2); 0.0 uses a game | 60% (12 of 20); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 45% (9 of 20); 0.2 uses a game | 14% (1 of 7); 0.0 uses a game | 37% (10 of 27); 0.1 uses a game |
|   their share of the points of units over 100 pts | lower | 55% (33087 of 60231) | 49% (31000 of 63281) | 52% (64087 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.8 (27%) | 0.7 (23%) | 2.5 (26%) |
| MARCHED: its unit marched | 0.8 (11%) | 0.4 (15%) | 1.2 (12%) |
| CHARGED: its unit charged | 0.2 (4%) | 0.1 (3%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 1.5 (23%) | 0.7 (25%) | 2.2 (24%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.1 (5%) | 0.1 (1%) |
| FLEEING: fleeing | 0.5 (8%) | 0.0 (0%) | 0.5 (5%) |
| GONE: slain | 1.2 (19%) | 0.5 (17%) | 1.8 (18%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (5%) | 0.1 (3%) | 0.4 (4%) |
| STUPIDITY: Stupidity | 0.2 (2%) | 0.1 (2%) | 0.2 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.2 (7%) | 0.2 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.1 | 1.5 | 1.2 | 4.3 | 0.4 | 2.1 |
| not cast | 3.7 | 3.4 | 3.8 | 9.5 | 1.9 | 19.6 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) | 1.5 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.5 (45%) | 0.2 (7%) | 2.5 (26%) | 0.6 (29%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.2 (12%) | 0.3 (17%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) | 0.1 (3%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (5%) | 0.3 (10%) | 0.6 (15%) | 2.2 (24%) | 0.2 (13%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (9%) | 0.3 (10%) | 0.3 (9%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (5%) | 0.1 (2%) | 0.1 (3%) | 0.5 (5%) | 0.1 (4%) | 0.8 (4%) |
| GONE: slain | 0.7 (19%) | 0.5 (14%) | 0.6 (17%) | 1.8 (18%) | 0.2 (10%) | 3.5 (18%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.2 (7%) | 0.4 (10%) | 0.4 (4%) | 0.2 (10%) | 1.0 (5%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.1 (2%) | 0.1 (2%) | 0.2 (2%) | 0.0 (0%) | 0.3 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.2 (5%) | 0.3 (8%) | 0.0 (1%) | 0.1 (1%) | 0.3 (14%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.9 (51%) | 0.1 (2%) | 1.3 (35%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.5 (64%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.6 a game | 0.6 a game | 0.6 a game |
| stood (cast and not dispelled) | 65% (11 of 17) | 70% (16 of 23) | 68% (27 of 40) |
| the unit moved after it | 91% (10 of 11) | 56% (9 of 16) | 70% (19 of 27) |
| it charged on its next turn | 0% (0 of 11) | 12% (2 of 16) | 7% (2 of 27) |
| the enemy charged it first | 18% (2 of 11) | 0% (0 of 16) | 7% (2 of 27) |
| it fought by the end of its next turn | 9% (1 of 11) | 0% (0 of 16) | 4% (1 of 27) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 11) | 12% (2 of 16) | 7% (2 of 27) |
| none of these (no charge, no fight, no charge escaped) | 82% (9 of 11) | 75% (12 of 16) | 78% (21 of 27) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (553 of 863) | 57% (450 of 784) | 61% (1003 of 1647) |
|   cavalry | 69% (51 of 74) | 64% (115 of 179) | 66% (166 of 253) |
|   character | 49% (53 of 108) | 22% (23 of 106) | 36% (76 of 214) |
|   chariot | 51% (57 of 111) | 65% (32 of 49) | 56% (89 of 160) |
|   infantry | 61% (155 of 256) | 59% (174 of 294) | 60% (329 of 550) |
|   monster | 36% (17 of 47) | 61% (20 of 33) | 46% (37 of 80) |
|   war machine | 82% (220 of 267) | 70% (86 of 123) | 78% (306 of 390) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.4 (28%) | 1.8 (19%) | 4.2 (24%) |
| CHARGED: it charged | 1.0 (12%) | 2.0 (22%) | 3.0 (17%) |
| FLEEING: it fled or was fleeing | 0.1 (2%) | 0.2 (2%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 1.1 (12%) | 0.5 (5%) | 1.5 (9%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 1.4 (16%) | 2.1 (23%) | 3.5 (19%) |
| ONLY IN COMBAT: the only targets were in combat | 0.6 (7%) | 0.3 (3%) | 0.9 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (16%) | 1.5 (16%) | 2.9 (16%) |
| SHELTERED: the target was sheltered | 0.3 (4%) | 0.4 (4%) | 0.7 (4%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.3 (4%) | 0.4 (5%) | 0.8 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.8 | 1.6 | 79% | 3.9 pts | 26 pts |
| character | 2.4 | 1.2 | 67% | 18.4 pts | 44 pts |
| chariot | 2.5 | 1.6 | 71% | 14.0 pts | 35 pts |
| infantry | 12.4 | 4.6 | 74% | 8.2 pts | 102 pts |
| monster | 1.3 | 0.2 | 85% | 4.5 pts | 6 pts |
| war machine | 8.5 | 6.4 | 63% | 22.2 pts | 189 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 7.1 | 5.4 |
| Charges that made contact a game | 2.7 | 5.1 | 3.9 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.67 declared, 0.50 contact (24 units) | 1.08 declared, 0.77 contact (13 units) | 0.81 declared, 0.59 contact (37 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.43 declared, 0.43 contact (7 units) | 1.82 declared, 1.09 contact (11 units) | 1.28 declared, 0.83 contact (18 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.47 declared, 0.34 contact (244 units) | 0.76 declared, 0.55 contact (290 units) | 0.63 declared, 0.46 contact (534 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 62% (45 of 73) | 50% (9 of 18) | 50% (6 of 12) | 58% (60 of 103) |
| Character in a unit | 88% (22 of 25) | 59% (10 of 17) | 75% (3 of 4) | 76% (35 of 46) |
| Character on its own | 74% (35 of 47) | 54% (20 of 37) | 16% (10 of 62) | 45% (65 of 146) |
| Chariot | 59% (10 of 17) | 77% (10 of 13) | - | 67% (20 of 30) |
| Infantry | 60% (56 of 94) | 62% (21 of 34) | 33% (1 of 3) | 60% (78 of 131) |
| Monster | 55% (16 of 29) | 67% (6 of 9) | - | 58% (22 of 38) |
| Monstrous | 43% (6 of 14) | 57% (8 of 14) | - | 50% (14 of 28) |
| War Machines | 81% (46 of 57) | 50% (1 of 2) | - | 80% (47 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (12 of 12); on the table 100% | 23% (23 of 102) | 49% | 73% (16 of 22) | 100% (6 of 6); 3.0 uses a game | 50% (1 of 2); 0.2 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 100% (10 of 10); on the table 100% | 36% (13 of 36) | 45% | 69% (22 of 32) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 6 | 87% (13 of 15); on the table 93% | - | 50% | 61% (33 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 90% (18 of 20); on the table 95% | 31% (15 of 48) | 43% | 67% (51 of 76) | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game | 25% (1 of 4); 0.1 uses a game |
| Grand Cathay | 6 | 94% (17 of 18); on the table 100% | 31% (43 of 138) | 42% | 48% (26 of 54) | 79% (11 of 14); 5.8 uses a game | 50% (1 of 2); 0.2 uses a game | 0% (0 of 6); 0.0 uses a game |
| High Elf Realms | 4 | 100% (15 of 15); on the table 100% | 28% (5 of 18) | 13% | 45% (15 of 33) | 100% (3 of 3); 1.8 uses a game | 64% (9 of 14); 4.8 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 100% (6 of 6); on the table 100% | - | 48% | 42% (5 of 12) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Lizardmen | 1 | 100% (2 of 2); on the table 100% | - | 35% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 77% (10 of 13); on the table 85% | 0% (0 of 18) | 32% | 79% (22 of 28) | 100% (4 of 4); 2.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (2 of 2); on the table 100% | 17% (2 of 12) | 3% | 25% (2 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 3 | 89% (8 of 9); on the table 89% | 39% (7 of 18) | 38% | 64% (16 of 25) | 100% (2 of 2); 1.0 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Tomb Kings of Khemri | 5 | 88% (14 of 16); on the table 88% | - | 33% | 36% (9 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 82% (32 of 39); on the table 90% | 39% (26 of 66) | 25% | 63% (34 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 79% (23 of 29); on the table 83% | 50% (9 of 18) | 26% | 52% (38 of 73) | 100% (2 of 2); 0.7 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 100% (20 of 20); on the table 100% | 50% (12 of 24) | 35% | 63% (49 of 78) | 57% (4 of 7); 1.6 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (shots-h2h-opp-7c46ffc-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 49% (56) | 51% (33) | 50% (89) |
| ...free all their last turn and able to turn (per game) | 0.78 | 0.67 | 1.44 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.47 | 0.11 | 0.58 |
| ...with the charger already in that arc before they moved (per game) | 0.50 | 0.44 | 0.94 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.78 | 1.06 | 2.83 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.92 | 0.56 | 1.47 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.28 | 4.25 | 10.53 |

### Quality by phase: shots-h2h-opp-7c46ffc-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 50% (53 of 106) | 49% (119 of 245) |
| Strategy | Shoot objectives carried out (shot that target) | 38% (121 of 316) | 56% (125 of 222) |
| Strategy | Close-in objectives charged next turn | 13% (17 of 131) | 25% (54 of 216) |
| Strategy | Support requests answered (helper made contact too) | 57% (8 of 14) | 40% (12 of 30) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (5 of 5) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 18% (2 of 11) | 57% (8 of 14) |
| Strategy | Joined characters whose unit fought | 36% (15 of 42) | 37% (14 of 38) |
| Strategy | Lone characters that fought | 77% (79 of 103) | 86% (73 of 85) |
| Movement | Charges halted short of contact | 0.2 | 0.2 |
| Movement | Idle units | 1.1 | 1.6 |
| Movement | Points that never moved of their own | 344.9 | 180.4 |
| Movement | Fights charged into per game | 2.4 | 4.3 |
| Movement | Charges with odds: long shots (under 50%) | 9 of 78, net +176 | 29 of 151, net +24 |
| Movement | Charges with odds: sweet spot (55-75%) | 9 of 78, net +194 | 29 of 151, net +142 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 13 of 78, net +103 | 12 of 151, net +68 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 29 of 78, net +64 | 43 of 151, net +174 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.8 | 10.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (164 of 353) | 50% (194 of 391) |
| Shooting | Points destroyed by shooting units | 57.8 | 50.1 |
| Shooting | War machine shots | 6.1 | 2.4 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 60% (133 of 220) | 67% (58 of 86) |
| Shooting | Points destroyed by war machines | 52.7 | 12.4 |
| Magic | Magic missiles cast | 1.9 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 37% (26 of 70) | 31% (12 of 39) |
| Magic | Wounds caused by magic missiles | 2.9 | 1.3 |
| Magic | Wounds caused by other spells | 2.0 | 0.6 |
| Magic | Points destroyed by magic (all spells) | 76.5 | 27.9 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.4 / 1.1 / 0.1 | 1.9 / 0.4 / 0.4 / 0.1 |
| Combat | Points destroyed in combat | 363.0 | 471.3 |
| Combat | Points run down | 50.2 | 136.6 |
| Combat | Net points per charged fight, damage counted | +90 | +107 |
| Combat | Net per 100 charger points, damage counted | +32.6 | +39.5 |
| Combat | First round won (charged fights) | 77% | 63% |
| Combat | Net points per charged fight | +92 | +111 |
| Combat | Net points per supported fight / lone fight | +16 / +105 | +173 / +102 |
| Combat | Charged fights on a top-3 enemy unit | 24 of 85 | 58 of 156 |
| Game | Points lost | 896.0 | 699.0 |
| Game | VP from objectives | 528.3 | 631.9 |
| Game | Lone holders (player turns) | 1.8 | 2.7 |

- Mine won / drew / lost: 15 / 2 / 19 of 36 ended games (of 36); mean margin (Mine - Opponent) -291 VP
- The side that went first won 18 of 34 games with a winner
- Points traded per game (both sides' losses): 1595
- Games not ended: 0; findings 0, warnings 1

### Opponent rules: shots-h2h-opp-7c46ffc-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 0.5 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +5.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 35.6 | 0.2 | +0.0 | 0.0 | 3.5 |
| BACKUP TARGETS | 1.1 | +6.3 | 0.0 | 31.7 | 0.9 | +11.2 | 0.0 | 22.9 |
| BEST FACING | 0.6 | +21.2 | 0.0 | 41.1 | 0.5 | +25.1 | 0.0 | 15.7 |
| BEST FIRST | 4.6 | +209.6 | 111.5 | 145.9 | 3.9 | +178.0 | 121.6 | 43.4 |
| BEST MOVE FOR SHOOTERS | - | - | - | - | 1.1 | +101.5 | 0.0 | 20.3 |
| BEST OVERALL | 0.6 | +40.5 | 0.0 | 26.6 | 0.3 | +23.3 | 0.0 | 19.1 |
| BEST PREY | 0.8 | +40.9 | 40.0 | 25.6 | 0.6 | +31.5 | 20.8 | 12.1 |
| BEST PRIZE | 0.0 | -1.7 | 0.0 | 0.0 | 0.1 | +4.2 | 7.0 | 0.0 |
| BIG CHARACTER SAFETY | 0.2 | +0.8 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 8.9 | 0.0 |
| BLOCKED WHEEL | 0.6 | +6.1 | 0.0 | 0.0 | 0.5 | +4.2 | 0.0 | 0.0 |
| BOUND ASSAILMENT | 0.1 | +0.0 | 0.0 | 15.3 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 125.8 | 22.1 | 0.2 | +0.0 | 6.8 | 2.8 |
| CANNON PLANNED TARGET | 4.4 | +54.9 | 228.0 | 127.5 | 1.8 | +66.3 | 47.2 | 27.9 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 7.7 |
| CARRIES OUT COUNTER | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 13.5 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.2 | -0.6 | 42.3 | 0.0 |
| CAST JOB | 0.6 | +23.7 | 59.0 | 9.2 | 0.2 | +3.1 | 0.0 | 6.2 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +32.5 | 10.8 | 0.0 | 0.3 | +10.6 | 23.6 | 4.4 |
| CASTS AFTER FRIENDS | 0.4 | +0.0 | 0.0 | 11.0 | 0.4 | +0.0 | 0.0 | 26.8 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +2.2 | 0.0 | 0.0 | - | - | - | - |
| CATCH ODDS | - | - | - | - | 0.0 | +2.5 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.8 | 0.0 | 6.5 | 0.1 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 2.2 | +0.0 | 201.1 | 44.8 | 3.8 | +0.0 | 446.1 | 154.2 |
| CHARGE NOW WEIGHED | 0.7 | -56.6 | 6.4 | 29.4 | 0.3 | -44.6 | 10.2 | 17.2 |
| CHARIOT WIZARD CAREFUL | 0.1 | -0.6 | 0.0 | 15.0 | - | - | - | - |
| CHEAP HELPER | - | - | - | - | 0.2 | +0.0 | 23.8 | 0.9 |
| COMBAT PIVOT | 0.6 | +0.0 | 52.7 | 16.4 | 0.7 | +0.0 | 89.9 | 40.7 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 13.9 | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.3 | +38.9 | 0.0 | 0.0 | 0.6 | +62.2 | 23.4 | 34.4 |
| COUNTER-CHARGE COVER | 9.6 | +771.9 | 0.0 | 286.5 | 6.1 | +532.0 | 0.0 | 132.8 |
| DEFENSIVE ARMY | 0.4 | +0.0 | 0.0 | 5.1 | 0.1 | +0.0 | 0.0 | 2.9 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +7.1 | 46.6 | 0.9 |
| ELIXIR WORTH | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACE THE CAST | - | - | - | - | 0.0 | +0.3 | 0.0 | 0.0 |
| FACES THE THREAT | 1.8 | +120.0 | 0.0 | 89.9 | 1.1 | +69.6 | 0.0 | 27.8 |
| FALLBACK BY WORTH | 4.8 | +79.3 | 0.0 | 45.3 | 5.0 | +51.9 | 0.0 | 68.2 |
| FIGHT LIFT | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.6 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.0 | +0.8 | 1.2 | 0.0 | 0.1 | +1.2 | 11.1 | 3.1 |
| FLANK NOT WEIGHED | 6.1 | +0.0 | 0.0 | 137.2 | 3.8 | +0.0 | 0.0 | 122.4 |
| FOCUS FIRE | - | - | - | - | 0.0 | +0.3 | 1.2 | 0.0 |
| FOCUS OVER TURNS | - | - | - | - | 0.7 | +12.8 | 33.8 | 3.9 |
| FOLLOW UP WEIGHED | 1.0 | +155.3 | 0.0 | 78.4 | 1.1 | +190.1 | 0.0 | 59.0 |
| FRIENDS SHOTS CHECKED | 0.2 | +14.5 | 0.0 | 11.9 | 0.3 | +17.1 | 0.0 | 7.2 |
| GIVES UP | 0.1 | -1.0 | 18.5 | 10.2 | 0.2 | -4.3 | 15.0 | 0.0 |
| GIVES UP ITS SCREEN | 0.1 | -0.2 | 8.9 | 3.4 | 0.0 | -1.1 | 4.5 | 0.0 |
| GROUND FLIERS | 0.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 20.3 | 0.0 | 0.1 | +0.0 | 10.7 | 0.0 |
| HELPER UNSEEN | 0.1 | +0.0 | 40.8 | 1.4 | 0.5 | +0.0 | 68.6 | 8.2 |
| HILL BY ITS CHANCE | 0.3 | -29.4 | 0.0 | 0.0 | 0.6 | -48.5 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +1.1 | 5.6 | 2.9 | 0.2 | +2.3 | 6.2 | 10.8 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 0.9 | 0.1 | +0.0 | 2.4 | 5.8 |
| HUNT IN PAIRS | 0.3 | +11.4 | 0.0 | 0.0 | 0.4 | +11.0 | 0.0 | 5.4 |
| HUNT KEPT | 0.1 | +0.9 | 13.6 | 1.4 | 0.2 | +3.0 | 26.5 | 1.9 |
| HUNT RESULT | 0.1 | +11.9 | 0.0 | 2.4 | 0.3 | +36.2 | 32.2 | 9.8 |
| HUNT THE GUNS | 0.1 | +29.8 | 2.8 | 1.4 | 0.4 | +141.0 | 29.1 | 12.9 |
| INVITES THE FIGHT | 1.5 | +20.7 | 38.3 | 30.3 | 1.2 | +20.4 | 68.4 | 34.1 |
| JOINT CHARGE PLAN | 0.1 | +2.8 | 0.0 | 0.0 | 0.1 | +8.4 | 8.0 | 6.0 |
| KEEP FALLS | 0.0 | +2.8 | 0.0 | 0.0 | - | - | - | - |
| KEEPS ITS PREY | 0.1 | +0.8 | 0.0 | 2.4 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 1.4 | +42.5 | 123.3 | 34.0 | 2.5 | +75.0 | 297.6 | 99.9 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 1.6 | +61.8 | 150.2 | 51.1 | 2.5 | +95.0 | 187.1 | 77.7 |
| KILLS COUNT NEXT TURN | 4.7 | +155.6 | 173.7 | 77.3 | 7.6 | +284.5 | 342.5 | 123.5 |
| LONE CHARACTER SAFE SPOT | 0.3 | +13.7 | 23.4 | 18.7 | 0.1 | +0.4 | 0.0 | 0.0 |
| LONE WIZARD HOLDS BACK | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 10.7 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +23.5 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | -3.6 | 3.9 | 7.8 | 0.6 | -0.7 | 41.7 | 1.1 |
| LOST CHARGE | 2.8 | -43.6 | 72.1 | 111.4 | 2.1 | -46.1 | 87.7 | 59.2 |
| LURE BY WHAT IT DRAWS | 0.0 | -3.4 | 0.0 | 1.0 | 0.1 | -15.9 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.3 | +10.5 | 9.6 | 1.7 | 0.8 | +46.2 | 15.9 | 28.2 |
| MANOEUVRE | 0.1 | +1.0 | 0.0 | 4.8 | 0.1 | +8.3 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.5 | +12.9 | 0.0 | 26.6 | 0.5 | +20.9 | 0.0 | 6.2 |
| MARCH ODDS | 0.3 | +28.5 | 0.0 | 2.2 | 0.4 | +46.3 | 4.6 | 0.0 |
| MARCH OVER CASTS | 0.5 | +65.5 | 0.0 | 18.9 | 0.3 | +36.7 | 0.0 | 3.0 |
| MAX FOR POSITIONING | 4.6 | +132.1 | 0.0 | 138.2 | 4.1 | +167.2 | 0.0 | 79.0 |
| MISSILES IN THE MOVE | 3.4 | +125.0 | 0.0 | 147.2 | 2.8 | +50.8 | 0.0 | 74.6 |
| MISSILES IN THE PLAN | - | - | - | - | 0.5 | +5.8 | 39.4 | 0.0 |
| MISSILES NEXT TURN | 3.9 | +71.3 | 0.0 | 161.9 | 3.1 | +39.0 | 0.0 | 91.4 |
| MODEL FACING | 0.2 | +59.2 | 0.0 | 3.3 | 0.3 | +94.0 | 0.0 | 0.0 |
| MONSTER WIZARD ROAMS | 0.2 | +0.0 | 0.0 | 10.2 | 0.2 | +0.0 | 24.1 | 0.0 |
| MOVE AND CAST | 0.2 | +13.6 | 0.0 | 4.6 | 0.2 | +15.5 | 0.0 | 16.4 |
| MOVE SPELL IN RANGE | 0.1 | +6.3 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL NOT WORTH | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.4 | -21.4 | 6.3 | 21.2 | 0.1 | -3.2 | 0.0 | 6.5 |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 10.2 |
| MOVE TO CHARGE | 2.5 | +123.7 | 96.7 | 49.5 | 4.8 | +314.4 | 243.1 | 107.3 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.0 | +0.9 | 3.5 | 0.0 | 0.1 | +14.0 | 13.2 | 0.0 |
| NO RALLY LEFT | 0.0 | +4.0 | 0.0 | 0.0 | 0.0 | -0.8 | 0.0 | 0.0 |
| NOT NEEDED | 0.2 | -6.2 | 24.5 | 7.4 | 0.6 | -25.5 | 79.8 | 7.2 |
| NOT TURNED | 6.3 | +102.7 | 0.0 | 140.8 | 4.2 | +36.3 | 0.0 | 92.2 |
| NOT WORTH A CAST | 0.4 | -0.2 | 0.0 | 12.1 | 0.6 | -0.5 | 0.0 | 18.9 |
| OFF BEST | 14.7 | -666.2 | 12.9 | 337.9 | 14.0 | -769.4 | 8.6 | 210.9 |
| OPENS A LANE | 0.0 | +0.2 | 0.0 | 2.8 | 0.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.1 | +7.6 | 7.9 | 0.0 | 0.4 | +26.1 | 19.2 | 12.9 |
| OVERRUNS AWAY | 0.5 | +8.0 | 71.7 | 13.7 | 0.6 | +8.2 | 48.7 | 34.2 |
| PATHS CROSS | 2.0 | +129.4 | 0.0 | 44.1 | 2.7 | +207.9 | 0.0 | 71.6 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +1.4 | 0.0 | 15.0 |
| PIVOT GUARDS FLANK | 0.1 | -2.2 | 0.0 | 1.4 | 0.1 | -0.5 | 0.0 | 3.5 |
| PLAN RESULT | 35.9 | +1371.6 | 1404.2 | 1155.6 | 40.2 | +1267.4 | 1620.8 | 900.6 |
| PURSUES BIG PREY | 0.1 | -0.7 | 0.0 | 0.0 | 0.2 | -9.0 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +8.3 | 0.0 | 3.4 | 0.1 | +4.9 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.9 | +12.0 | 0.0 | 15.3 | 1.3 | +21.4 | 0.0 | 41.1 |
| RANDOM MOVER NO PROMISE | 0.3 | -35.8 | 0.0 | 4.7 | 0.2 | -16.7 | 13.6 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.1 | +4.7 | 0.0 | 0.0 | 0.2 | -2.6 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.1 | +119.5 | 0.0 | 38.2 | 3.5 | +304.2 | 0.0 | 49.9 |
| REDIRECT WEIGHED | 0.1 | +2.1 | 3.5 | 0.0 | 0.3 | +4.9 | 3.1 | 13.7 |
| RESERVE FALL BACK | 0.2 | +5.9 | 0.0 | 0.0 | 1.0 | +30.8 | 0.0 | 8.4 |
| RESTRAINS TO SHOOT | 0.0 | +0.6 | 0.0 | 0.0 | 0.1 | +6.1 | 0.0 | 6.5 |
| RISK BY ARC | 2.0 | +73.6 | 210.7 | 63.9 | 3.8 | +75.8 | 364.1 | 126.2 |
| SAFE SURE CHARGE | - | - | - | - | 0.0 | -2.0 | 0.0 | 0.0 |
| SAFER THAN THE JOB | 0.9 | +72.3 | 0.0 | 20.4 | 0.6 | +38.6 | 0.0 | 12.3 |
| SCOUT SPOT | 0.3 | +0.8 | 0.0 | 0.0 | 0.5 | +2.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.1 | -3.1 | 0.0 | 1.2 | 0.4 | -16.8 | 0.0 | 3.8 |
| SEARCH SPOT | 2.6 | +135.2 | 0.0 | 29.6 | 3.1 | +123.1 | 0.0 | 50.5 |
| SECOND HUNTER | 0.0 | -0.0 | 0.0 | 0.0 | 0.1 | -0.4 | 4.6 | 0.9 |
| SELF MOVE SPELL | 0.2 | +21.6 | 0.0 | 31.0 | - | - | - | - |
| SET UP TOGETHER | 0.6 | +18.9 | 9.6 | 3.9 | 1.6 | +109.0 | 48.0 | 50.6 |
| SET-UP ANY TARGET | 0.1 | +15.5 | 0.0 | 0.0 | 0.2 | +14.7 | 4.4 | 18.9 |
| SET-UP MISSED | - | - | - | - | 0.1 | +53.1 | 0.0 | 10.2 |
| SHOOTER COUNTED ONCE | 0.0 | -0.1 | 0.0 | 0.0 | 0.0 | -0.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +34.1 | 31.4 | 20.1 | 0.4 | +12.5 | 26.9 | 13.3 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT OPTIONS | 14.7 | +0.0 | 505.5 | 293.9 | 13.1 | +0.0 | 339.3 | 210.3 |
| SHOT REPLANNED | 0.4 | +0.0 | 95.4 | 12.9 | 0.4 | +0.0 | 57.4 | 10.0 |
| SHOTS IN THE MOVE | 13.0 | +429.5 | 0.0 | 312.6 | 12.4 | +401.9 | 0.0 | 171.6 |
| SPELL CATCH ODDS | 0.0 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.2 | +44.5 | 0.0 | 0.0 | 0.2 | +47.6 | 4.4 | 18.9 |
| SPELL WORTH | 1.0 | +21.2 | 56.0 | 63.9 | 1.6 | +22.7 | 49.9 | 49.9 |
| STABLE ROLE | 11.3 | +0.0 | 391.8 | 185.3 | 12.3 | +0.0 | 481.1 | 155.7 |
| STANDS TO CAST | 0.1 | +3.9 | 0.0 | 11.1 | 0.1 | +4.4 | 0.0 | 3.2 |
| STAY WEIGHED | - | - | - | - | 0.1 | +5.0 | 0.0 | 0.0 |
| STAY WORTH | - | - | - | - | 15.3 | +297.1 | 192.2 | 212.8 |
| STOPS | 0.1 | +0.6 | 5.4 | 0.0 | 0.2 | +8.5 | 38.4 | 4.0 |
| STOPS SHORT OF THE FLANK | 0.5 | +18.8 | 0.0 | 20.8 | 0.3 | +16.5 | 0.0 | 36.2 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 8.8 |
| SUPPORT NARROWED | 6.1 | -43.5 | 444.8 | 110.8 | 7.5 | -54.7 | 493.6 | 136.5 |
| SUPPORTS | 4.2 | +43.5 | 268.9 | 62.6 | 4.2 | +57.0 | 172.2 | 75.2 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -3.5 | 9.8 | 0.0 | 0.1 | -8.8 | 17.9 | 0.0 |
| SURE REACH TOGETHER | 0.3 | -0.4 | 0.0 | 4.0 | 0.7 | +10.5 | 2.4 | 9.6 |
| THREAT IN THE KILL | 1.2 | +18.6 | 47.9 | 9.8 | 8.0 | +102.5 | 186.5 | 157.7 |
| THROUGH LINE OF FIRE | 0.2 | +6.6 | 0.0 | 0.0 | 0.1 | +3.6 | 0.0 | 0.0 |
| TURN WORTH | 0.5 | -37.0 | 44.0 | 4.8 | 0.4 | -25.6 | 23.7 | 14.9 |
| TWO OR MORE ARRIVE | 0.1 | +0.3 | 0.0 | 0.0 | 0.5 | +1.5 | 19.3 | 10.4 |
| WAIT AFTER COSTS | 5.8 | -223.6 | 180.6 | 101.9 | 8.3 | -405.2 | 383.3 | 155.3 |
| WALKS TO THE FIGHT | 1.6 | +35.9 | 32.0 | 12.6 | 1.6 | +29.0 | 18.7 | 20.4 |
| WAR ENGINE CHARGES | 0.1 | +6.1 | 16.1 | 2.1 | 0.0 | +0.5 | 0.9 | 0.0 |
| WAR ENGINE JOBS | 0.5 | +0.0 | 48.6 | 7.2 | 0.1 | +0.0 | 15.2 | 5.1 |
| WEARS DOWN | 0.8 | +28.2 | 95.3 | 16.0 | 2.0 | +53.7 | 296.6 | 74.2 |
| WHO HITS BACK | 0.3 | +30.3 | 0.0 | 10.2 | 0.1 | +13.3 | 0.0 | 19.7 |
| WHOLE FIGHT | 0.1 | +8.3 | 57.2 | 0.0 | 0.8 | +29.7 | 133.0 | 9.8 |
| WHOLE FIGHT GAIN | 0.4 | +33.3 | 49.3 | 8.0 | 0.8 | +77.0 | 69.6 | 20.2 |
| WOUNDED STAYS OUT | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 7.3 | 0.0 |

### Rule changes: shots-h2h-opp-7c46ffc-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| OFF BEST | 1031 | 1031 | 1031 | 28.64 | -51683 | -50.1 |
| BEST FIRST | 305 | 305 | 305 | 8.47 | +13955 | +45.8 |
| SEARCH SPOT | 207 | 207 | 204 | 5.67 | +9345 | +45.8 |
| PATHS CROSS | 169 | 169 | 169 | 4.69 | +12140 | +71.8 |
| KILLS COUNT NEXT TURN | 443 | 443 | 137 | 3.81 | +4563 | +33.3 |
| COUNTER-CHARGE COVER | 568 | 324 | 129 | 3.58 | +8420 | +65.3 |
| MOVE TO CHARGE | 262 | 262 | 123 | 3.42 | +4724 | +38.4 |
| SUPPORTS | 306 | 306 | 110 | 3.06 | +986 | +9.0 |
| FACES THE THREAT | 102 | 102 | 102 | 2.83 | +6825 | +66.9 |
| WAIT AFTER COSTS | 507 | 507 | 80 | 2.22 | +1372 | +17.2 |
| FALLBACK BY WORTH | 355 | 355 | 73 | 2.03 | +4724 | +64.7 |
| FOLLOW UP WEIGHED | 73 | 73 | 73 | 2.03 | +12435 | +170.3 |
| CANNON SIGHT KEPT | 70 | 70 | 70 | 1.94 | +0 | +0.0 |
| SHOTS IN THE MOVE | 916 | 605 | 62 | 1.72 | +1550 | +25.0 |
| WALKS TO THE FIGHT | 114 | 114 | 62 | 1.72 | +902 | +14.5 |
| ARTILLERY RE-ROLL WEIGHED | 54 | 54 | 54 | 1.50 | +0 | +0.0 |
| SAFER THAN THE JOB | 53 | 53 | 53 | 1.47 | +3990 | +75.3 |
| RANDOM MOVE BY FIGURES | 80 | 80 | 47 | 1.31 | +1204 | +25.6 |
| CHARGE NOW FIRST | 216 | 216 | 46 | 1.28 | -2494 | -54.2 |
| COMBAT PIVOT | 46 | 46 | 46 | 1.28 | +0 | +0.0 |
| MAX FOR POSITIONING | 314 | 196 | 45 | 1.25 | +501 | +11.1 |
| RESERVE FALL BACK | 45 | 45 | 45 | 1.25 | +1323 | +29.4 |
| ADVANCE LANE KEPT | 42 | 42 | 42 | 1.17 | +0 | +0.0 |
| REDIRECT COUNTER | 202 | 114 | 42 | 1.17 | +2539 | +60.4 |
| BEST FACING | 41 | 41 | 41 | 1.14 | +1667 | +40.6 |
| STAY WORTH | 551 | 430 | 41 | 1.14 | +843 | +20.6 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| BLOCKED WHEEL | 39 | 39 | 39 | 1.08 | +371 | +9.5 |
| RISK BY ARC | 207 | 203 | 39 | 1.08 | +1146 | +29.4 |
| BEST MOVE FOR SHOOTERS | 38 | 38 | 38 | 1.06 | +3655 | +96.2 |
| CHARGE NOW WEIGHED | 37 | 37 | 37 | 1.03 | +4383 | +118.5 |
| SET UP TOGETHER | 80 | 70 | 34 | 0.94 | +1868 | +54.9 |
| THREAT IN THE KILL | 334 | 284 | 34 | 0.94 | +212 | +6.2 |
| KILLS COUNT | 147 | 146 | 33 | 0.92 | +925 | +28.0 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2266 | +68.7 |
| BEST OVERALL | 32 | 32 | 32 | 0.89 | +2299 | +71.8 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| CANNON PLANNED TARGET | 225 | 225 | 30 | 0.83 | -182 | -6.1 |
| MARCH CHECK | 36 | 33 | 30 | 0.83 | +1061 | +35.4 |
| SHOT REPLANNED | 29 | 29 | 29 | 0.81 | +0 | +0.0 |
| STOPS SHORT OF THE FLANK | 29 | 29 | 29 | 0.81 | +1270 | +43.8 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +50 | +2.0 |
| KEEPS ITS TARGET | 141 | 140 | 24 | 0.67 | +364 | +15.2 |
| MARCH ODDS | 24 | 24 | 24 | 0.67 | +500 | +20.8 |
| MISSILES IN THE MOVE | 220 | 133 | 24 | 0.67 | +789 | +32.9 |
| SHOOTS FROM THE BEST SPOT | 51 | 51 | 24 | 0.67 | +777 | +32.4 |
| BEST PREY | 53 | 53 | 21 | 0.58 | +608 | +28.9 |
| MODEL FACING | 21 | 21 | 21 | 0.58 | +5514 | +262.6 |
| WHOLE FIGHT GAIN | 43 | 40 | 21 | 0.58 | +734 | +35.0 |
| FRIENDS SHOTS CHECKED | 18 | 18 | 18 | 0.50 | +1140 | +63.3 |
| INVITES THE FIGHT | 97 | 97 | 18 | 0.50 | +278 | +15.5 |
| CASTING BLOCK | 24 | 24 | 17 | 0.47 | +849 | +49.9 |
| REDIRECT WEIGHED | 17 | 17 | 17 | 0.47 | +79 | +4.6 |
| MOVE AND CAST | 16 | 16 | 16 | 0.44 | +1046 | +65.4 |
| WHO HITS BACK | 16 | 16 | 16 | 0.44 | +1076 | +67.2 |
| CAST JOB | 29 | 29 | 15 | 0.42 | +380 | +25.3 |
| CASTER AWAY FROM SCREEN | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| FOCUS OVER TURNS | 26 | 26 | 14 | 0.39 | +153 | +10.9 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| MAKE SURE TOGETHER | 37 | 26 | 13 | 0.36 | +313 | +24.1 |
| THROUGH LINE OF FIRE | 13 | 13 | 13 | 0.36 | +368 | +28.3 |
| CHAFF PASSED | 12 | 12 | 12 | 0.33 | -30 | -2.5 |
| WEARS DOWN | 100 | 97 | 12 | 0.33 | +227 | +18.9 |
| OPENS UP | 16 | 16 | 10 | 0.28 | +411 | +41.1 |
| STUCK PIVOT | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SURE CHARGE BEATS ADVANCE | 9 | 9 | 9 | 0.25 | -442 | -49.1 |
| BIG CHARACTER SAFETY | 8 | 8 | 8 | 0.22 | +34 | +4.3 |
| LOST CHARGE | 173 | 172 | 8 | 0.22 | +224 | +28.1 |
| PURSUES BIG PREY | 8 | 8 | 8 | 0.22 | -350 | -43.7 |
| SUPPORT NARROWED | 489 | 489 | 8 | 0.22 | -53 | -6.7 |
| MANOEUVRE | 9 | 9 | 7 | 0.19 | +334 | +47.6 |
| PIVOT GUARDS FLANK | 7 | 7 | 7 | 0.19 | -100 | -14.2 |
| WHOLE FIGHT | 33 | 33 | 7 | 0.19 | +229 | +32.7 |
| SURE REACH TOGETHER | 38 | 25 | 6 | 0.17 | +98 | +16.3 |
| BOUND ASSAILMENT | 5 | 5 | 5 | 0.14 | +1 | +0.2 |
| NEEDED THERE | 6 | 6 | 5 | 0.14 | +0 | +0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 5 | 5 | 5 | 0.14 | +286 | +57.1 |
| RESTRAINS TO SHOOT | 5 | 5 | 5 | 0.14 | +242 | +48.4 |
| STANDS TO CAST | 5 | 5 | 5 | 0.14 | -26 | -5.1 |
| BEST PRIZE | 4 | 4 | 4 | 0.11 | -133 | -33.3 |
| FIRE AND FLEE | 4 | 4 | 4 | 0.11 | +72 | +18.0 |
| JOINT CHARGE PLAN | 7 | 7 | 4 | 0.11 | +248 | +62.1 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| MISSILES NEXT TURN | 253 | 149 | 4 | 0.11 | +12 | +2.9 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| STAY WEIGHED | 4 | 4 | 4 | 0.11 | +181 | +45.3 |
| WAR ENGINE JOBS | 23 | 23 | 4 | 0.11 | -132 | -33.0 |
| BLOCKED CHARGE SKIPPED | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| HUNT IN PAIRS | 26 | 17 | 3 | 0.08 | +109 | +36.2 |
| OVERRUNS AWAY | 41 | 38 | 3 | 0.08 | +50 | +16.6 |
| CARRIES OUT SET-UP | 8 | 8 | 2 | 0.06 | -23 | -11.4 |
| CONTINUE AHEAD WEIGHED | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| DEFENSIVE ARMY | 16 | 16 | 2 | 0.06 | -100 | -50.0 |
| MOVE SPELL IN RANGE | 4 | 3 | 2 | 0.06 | +31 | +15.4 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +52 | +25.8 |
| BACKUP TARGETS | 73 | 35 | 1 | 0.03 | +3 | +2.8 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -25 | -24.7 |
| EDGE GIVE GROUND | 12 | 12 | 1 | 0.03 | +0 | +0.0 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +16 | +15.9 |
| FACE THE CAST | 1 | 1 | 1 | 0.03 | +12 | +12.1 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +10 | +10.0 |
| HILL BY ITS CHANCE | 32 | 32 | 1 | 0.03 | +58 | +58.5 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +5 | +4.6 |
| HUNT ADVANCE | 13 | 13 | 1 | 0.03 | +31 | +30.8 |
| KEEP FALLS | 1 | 1 | 1 | 0.03 | +111 | +110.9 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +52 | +51.9 |
| REDIRECT BY WHAT IT STOPS | 10 | 10 | 1 | 0.03 | +43 | +42.9 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -78 | -78.2 |
| STOPS | 11 | 11 | 1 | 0.03 | +18 | +18.4 |
| WOUNDED STAYS OUT | 3 | 3 | 1 | 0.03 | -57 | -57.2 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 31 | 31 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 5 | 5 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 29 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHARIOT WIZARD CAREFUL | 4 | 4 | 0 | 0.00 | - | - |
| CHEAP HELPER | 6 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 30 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 355 | not checked | - | - | - | - |
| GIVES UP | 10 | 9 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 3 | 3 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 4 | not checked | - | - | - | - |
| HELPER UNSEEN | 22 | 20 | 0 | 0.00 | - | - |
| HUNT DROPPED | 6 | trace | - | - | - | - |
| HUNT KEPT | 10 | trace | - | - | - | - |
| HUNT RESULT | 17 | trace | - | - | - | - |
| HUNT THE GUNS | 18 | trace | - | - | - | - |
| KEEPS ITS PREY | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 15 | not checked | - | - | - | - |
| LONE WIZARD HOLDS BACK | 10 | 10 | 0 | 0.00 | - | - |
| LONG SHOT | 32 | 32 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 27 | 27 | 0 | 0.00 | - | - |
| MISSILES IN THE PLAN | 17 | 1 | 0 | 0.00 | - | - |
| MONSTER WIZARD ROAMS | 15 | 15 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 17 | trace | - | - | - | - |
| MOVE SPELL SPOT | 13 | not checked | - | - | - | - |
| NOT NEEDED | 26 | 25 | 0 | 0.00 | - | - |
| NOT TURNED | 379 | 379 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 36 | not checked | - | - | - | - |
| OPENS A LANE | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 2741 | trace | - | - | - | - |
| RANDOM MOVER NO PROMISE | 21 | 21 | 0 | 0.00 | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 18 | 18 | 0 | 0.00 | - | - |
| SECOND HUNTER | 3 | 3 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 8 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 10 | not checked | - | - | - | - |
| SET-UP MISSED | 5 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOT OPTIONS | 999 | 999 | 0 | 0.00 | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 17 | not checked | - | - | - | - |
| SPELL WORTH | 94 | not checked | - | - | - | - |
| STABLE ROLE | 850 | 847 | 0 | 0.00 | - | - |
| TURN WORTH | 31 | 31 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 20 | 14 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 3 | 3 | 0 | 0.00 | - | - |

### Off best figure: shots-h2h-opp-7c46ffc-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 12.86 | 12.47 | 52.0 |
| CHARGE NOW FIRST | rule | 0.47 | 0.81 | 54.2 |
| FALLBACK | gate | 0.58 | 0.69 | 44.3 |
| TURN GATE | gate | 0.78 | 0.36 | 35.7 |
| CANNON PLANNED TARGET | rule | 0.28 | - | 19.0 |
| FIGHT ORDER BAND | gate | 0.14 | 0.11 | 1.8 |
| PATHS CROSS | rule | 0.17 | 0.08 | 25.6 |
| SURE CHARGE BEATS ADVANCE | rule | 0.11 | 0.14 | 49.1 |
| BLOCKED WHEEL | rule | 0.14 | 0.08 | 11.3 |
| PURSUES BIG PREY | rule | 0.06 | 0.17 | 43.7 |
| AFTERMATH BAND | gate | 0.11 | 0.08 | 2.7 |
| PIVOT GUARDS FLANK | rule | 0.11 | 0.08 | 14.2 |
| SUPPORT NARROWED | rule | 0.08 | 0.11 | 7.6 |
| SUPPORT REQUEST | gate | 0.03 | 0.14 | 34.5 |
| CHARGE NOW WEIGHED | rule | 0.11 | 0.03 | 34.9 |
| LONE CHARACTER SAFE SPOT | gate | 0.11 | 0.03 | 68.5 |
| BEST PRIZE | rule | 0.03 | 0.08 | 33.3 |
| CHAFF PASSED | rule | 0.11 | - | 7.5 |
| MARCH ODDS | rule | 0.03 | 0.08 | 15.2 |
| WAR ENGINE JOBS | rule | 0.08 | 0.03 | 33.0 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.06 | 0.03 | 27.5 |
| STANDS TO CAST | rule | 0.03 | 0.06 | 21.0 |
| CARRIES OUT SET-UP | rule | - | 0.06 | 11.4 |
| DEFENSIVE ARMY | rule | 0.06 | - | 50.0 |
| NO REASON | gate | - | 0.06 | 51.9 |
| REDIRECT WEIGHED | rule | - | 0.06 | 33.8 |
| THROUGH LINE OF FIRE | rule | 0.06 | - | 94.7 |
| BIG CHARACTER SAFETY | rule | - | 0.03 | 5.8 |
| CATCH ODDS | rule | - | 0.03 | 24.7 |
| FRIENDS SHOTS CHECKED | rule | 0.03 | - | 4.7 |
| SAFE SURE CHARGE | rule | - | 0.03 | 78.2 |
| STOPS SHORT OF THE FLANK | rule | - | 0.03 | 5.8 |
| WHO HITS BACK | rule | 0.03 | - | 3.7 |
| WOUNDED STAYS OUT | rule | - | 0.03 | 57.2 |

### Plans: shots-h2h-opp-7c46ffc-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.0 | 17% | 418 | 338 | 81% |
| Mine | charge | 2.6 | 65% | 245 | 292 | 119% |
| Mine | close in | 3.6 | 21% | 187 | 103 | 55% |
| Mine | hold | 4.4 | 33% | 299 | 0 | 0% |
| Mine | join | 1.0 | 95% | 31 | 0 | 0% |
| Mine | shoot | 7.8 | 68% | 177 | 638 | 361% |
| Mine | support | 4.4 | 93% | 28 | 0 | 0% |
| Opponent | advance | 13.3 | 14% | 402 | 290 | 72% |
| Opponent | charge | 5.9 | 62% | 692 | 555 | 80% |
| Opponent | close in | 6.0 | 34% | 470 | 161 | 34% |
| Opponent | hold | 4.4 | 43% | 334 | 0 | 0% |
| Opponent | join | 0.8 | 89% | 33 | 0 | 0% |
| Opponent | shoot | 5.1 | 58% | 317 | 262 | 83% |
| Opponent | support | 4.8 | 90% | 47 | 0 | 0% |

### Packages: hunt the guns, shots-h2h-opp-7c46ffc-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 5 | 0 | 20% | 40% | 0% | 3.5 | 214 | 86 | 20% | 15 |
| Opponent | 0.4 | 13 | 1 | 25% | 25% | 0% | 2.3 | 382 | 109 | 25% | 69 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.5 | 2 | 0 | 0% | 50% | 0% | 3.0 | 225 | 107 | 0% | 42 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 40 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 36 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 139 |
| High Elf Realms | 0.2 | 1 | 0 | 100% | 100% | 0% | 4.0 | 233 | 214 | 100% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 138 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.5 | 6 | 0 | 50% | 50% | 0% | 2.3 | 428 | 217 | 50% | 58 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 92 |
| Tomb Kings of Khemri | 1.0 | 5 | 0 | 0% | 0% | 0% | - | 211 | 0 | 0% | 14 |
| Vampire Counts | 0.2 | 2 | 0 | 0% | 0% | 0% | - | 431 | 0 | 0% | 0 |
| Warriors of Chaos | 0.2 | 2 | 1 | 0% | 0% | 0% | - | 490 | 0 | 0% | 74 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: shots-h2h-opp-7c46ffc-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 9.6 | 27% | 47% | 7% | 0% | 31% | 20% | 12% | 37% | 0% |
| Mine | REDIRECT COUNTER | 2.1 | 28% | 67% | 10% | 0% | 37% | 0% | 21% | 42% | 0% |
| Opponent | COUNTER-CHARGE COVER | 6.1 | 18% | 72% | 38% | 47% | 40% | 0% | 12% | 48% | 0% |
| Opponent | REDIRECT COUNTER | 3.5 | 25% | 66% | 34% | 18% | 14% | 5% | 33% | 48% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: shots-h2h-opp-7c46ffc-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 0 (5) | 0 | 0 | 52 | 20% | 3.8 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | Chaff | 35 | 50 (35) | 6 | 45 | 60 | 46% | 2.6 | 60 (19) | 81 (7) | 14 (9) | 65 (24) | 14 (11) |
| Mine | Character | 123 | 58 (123) | 57 | 1 | 47 | 24% | 2.2 | 82 (38) | 53 (48) | 34 (11) | 70 (49) | 58 (48) |
| Mine | Clean-up | 20 | 39 (20) | 2 | 36 | 38 | 50% | 2.6 | 18 (5) | 39 (12) | 95 (3) | 82 (12) | 0 (8) |
| Mine | Fast | 1 | 40 (1) | 40 | 0 | 100 | 0% | 3.0 | - | 40 (1) | - | 40 (1) | - |
| Mine | Fast Hammer | 44 | 53 (44) | 41 | 13 | 66 | 23% | 2.6 | 42 (21) | 91 (16) | 9 (7) | 60 (27) | 43 (17) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 40 | 0% | 1.6 | - | 0 (3) | 0 (2) | 0 (5) | - |
| Mine | Hammer | 57 | 26 (57) | 16 | 9 | 37 | 14% | 2.7 | 20 (18) | 33 (29) | 15 (10) | 28 (38) | 21 (19) |
| Mine | Holder | 29 | 41 (29) | 0 | 41 | 43 | 34% | 3.3 | 45 (9) | 53 (14) | 0 (6) | 52 (19) | 19 (10) |
| Mine | Shooter | 44 | 59 (44) | 12 | 46 | 50 | 2% | 1.6 | 79 (7) | 62 (30) | 29 (7) | 81 (26) | 27 (18) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 50% | 5.0 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | War machine | 59 | 35 (59) | 35 | 0 | 60 | 3% | 1.2 | 12 (10) | 39 (37) | 37 (12) | 24 (10) | 37 (49) |
| Mine | Wizard | 22 | 23 (22) | 23 | 0 | 51 | 5% | 2.3 | 1 (7) | 75 (6) | 21 (5) | 35 (6) | 21 (12) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (2) | - | - | 0 (2) |
| Opponent | Chaff | 76 | 65 (76) | 34 | 31 | 41 | 37% | 2.7 | 58 (32) | 58 (19) | 84 (25) | 83 (54) | 25 (22) |
| Opponent | Character | 94 | 73 (94) | 73 | 0 | 40 | 18% | 2.7 | 82 (40) | 74 (39) | 95 (4) | 66 (56) | 99 (27) |
| Opponent | Clean-up | 21 | 40 (21) | 26 | 13 | 38 | 29% | 2.7 | 40 (9) | 40 (12) | - | 52 (15) | 13 (6) |
| Opponent | Early | 2 | 109 (2) | 109 | 0 | 0 | 0% | 4.5 | - | 116 (1) | 102 (1) | 116 (1) | 102 (1) |
| Opponent | Fast Hammer | 48 | 53 (48) | 43 | 10 | 32 | 19% | 2.6 | 42 (22) | 51 (16) | 83 (10) | 35 (28) | 86 (20) |
| Opponent | Fragile | 5 | 16 (5) | 16 | 0 | 80 | 20% | 2.8 | - | 26 (3) | 0 (1) | 24 (3) | 0 (1) |
| Opponent | Hammer | 68 | 30 (68) | 27 | 3 | 45 | 24% | 2.6 | 28 (17) | 27 (40) | 46 (11) | 37 (42) | 18 (26) |
| Opponent | Holder | 35 | 91 (35) | 17 | 74 | 25 | 31% | 3.0 | 103 (5) | 104 (18) | 116 (7) | 140 (18) | 57 (12) |
| Opponent | Shooter | 33 | 72 (33) | 7 | 65 | 23 | 3% | 1.8 | 40 (8) | 90 (19) | 50 (6) | 101 (22) | 27 (11) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | 0 (2) | 0 (1) | - | 0 (1) | 0 (2) |
| Opponent | War machine | 24 | 19 (24) | 19 | 0 | 37 | 8% | 1.6 | 14 (6) | 15 (14) | 36 (4) | 0 (3) | 21 (21) |
| Opponent | Wizard | 29 | 17 (29) | 17 | 0 | 40 | 7% | 1.5 | 0 (10) | 44 (10) | 0 (7) | 33 (11) | 0 (16) |

### Charged fights: shots-h2h-opp-7c46ffc-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 115 | 128 | 0.5 | 1.0 | 256 | 0 | +256 | 1 of 2 | 2 of 2 | - | +256 |
| Mine | Chaos Dwarfs | 4 | 226 | 282 | 2.0 | 1.0 | 141 | 0 | +141 | 5 of 8 | 6 of 8 | - | +141 |
| Mine | Dwarfen Mountain Holds | 4 | 520 | 18 | 1.5 | 1.2 | 12 | 28 | -16 | 0 of 6 | 4 of 6 | +0 | -19 |
| Mine | Empire of Man | 5 | 246 | 18 | 0.4 | 1.0 | 46 | 0 | +46 | 1 of 2 | 1 of 2 | - | +46 |
| Mine | Grand Cathay | 4 | 300 | 35 | 2.2 | 1.1 | 16 | 0 | +16 | 1 of 9 | 8 of 9 | +0 | +18 |
| Mine | High Elf Realms | 4 | 57 | 576 | 3.8 | 1.3 | 154 | 24 | +130 | 5 of 15 | 11 of 15 | +75 | +150 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 1334 | 5.0 | 1.0 | 267 | 16 | +251 | 2 of 5 | 4 of 5 | - | +251 |
| Mine | Lizardmen | 1 | 45 | 1023 | 3.0 | 1.0 | 341 | 0 | +341 | 1 of 3 | 1 of 3 | - | +341 |
| Mine | Ogre Kingdoms | 1 | 0 | 75 | 6.0 | 1.3 | 12 | 0 | +12 | 0 of 6 | 2 of 2 | +0 | +19 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 235 | 5.0 | 1.2 | 47 | 0 | +47 | 2 of 5 | 4 of 5 | +45 | +48 |
| Mine | Skaven | 2 | 143 | 0 | 1.0 | 1.0 | 0 | 46 | -46 | 0 of 2 | 1 of 2 | - | -46 |
| Mine | Tomb Kings of Khemri | 1 | 114 | 917 | 7.0 | 1.0 | 131 | 142 | -11 | 3 of 7 | 5 of 7 | - | -11 |
| Mine | Vampire Counts | 3 | 57 | 492 | 4.7 | 1.3 | 106 | 28 | +77 | 3 of 14 | 12 of 14 | -53 | +113 |
| Mine | Warriors of Chaos | 1 | 19 | 608 | 1.0 | 1.0 | 608 | 0 | +608 | 0 of 1 | 1 of 1 | - | +608 |
| **Mine** | all armies | 36 | 187 | 275 | 2.4 | 1.2 | 117 | 24 | +92 | 24 of 85 | 62 of 81 | +16 | +105 |
| Opponent | Dwarfen Mountain Holds | 2 | 181 | 108 | 4.0 | 1.2 | 27 | 16 | +11 | 0 of 8 | 6 of 8 | +52 | +5 |
| Opponent | Empire of Man | 2 | 42 | 216 | 2.5 | 1.6 | 86 | 64 | +22 | 1 of 5 | 3 of 5 | +144 | -160 |
| Opponent | Grand Cathay | 2 | 271 | 703 | 4.0 | 1.4 | 176 | 73 | +103 | 5 of 8 | 5 of 8 | +210 | +87 |
| Opponent | Kingdom of Bretonnia | 1 | 180 | 290 | 2.0 | 1.0 | 145 | 0 | +145 | 1 of 2 | 0 of 2 | - | +145 |
| Opponent | Ogre Kingdoms | 3 | 182 | 434 | 3.7 | 1.3 | 118 | 7 | +112 | 3 of 11 | 7 of 11 | +158 | +94 |
| Opponent | Skaven | 1 | 281 | 679 | 1.0 | 2.0 | 679 | 540 | +139 | 0 of 1 | 1 of 1 | +139 | - |
| Opponent | Tomb Kings of Khemri | 4 | 34 | 1585 | 6.8 | 1.1 | 235 | 26 | +209 | 13 of 27 | 16 of 27 | +462 | +189 |
| Opponent | Vampire Counts | 6 | 0 | 808 | 5.2 | 1.2 | 156 | 42 | +114 | 13 of 31 | 19 of 31 | +203 | +97 |
| Opponent | Warriors of Chaos | 8 | 14 | 404 | 3.5 | 1.0 | 115 | 0 | +115 | 10 of 28 | 18 of 28 | +199 | +112 |
| Opponent | Wood Elf Realms | 7 | 144 | 624 | 5.0 | 1.1 | 125 | 59 | +66 | 12 of 35 | 23 of 35 | +8 | +71 |
| **Opponent** | all armies | 36 | 90 | 642 | 4.3 | 1.2 | 148 | 37 | +111 | 58 of 156 | 98 of 156 | +173 | +102 |

### Effective charges: shots-h2h-opp-7c46ffc-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 0 | 0 | 1 (net +511) | 0 | 0 | 1 (net +0) | 0 | 50% (1 of 2) |
| Mine | Chaos Dwarfs | 8 | 2 (net +108) | 0 | 1 (net +104) | 3 (net +193) | 0 | 2 (net +114) | 0 | 12% (1 of 8) |
| Mine | Dwarfen Mountain Holds | 6 | 1 (net -75) | 0 | 0 | 2 (net -30) | 0 | 2 (net +20) | 1 | 0% (0 of 5) |
| Mine | Empire of Man | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +92) | 1 | 0% (0 of 1) |
| Mine | Grand Cathay | 9 | 0 | 0 | 1 (net +0) | 3 (net +13) | 3 (net +14) | 2 (net +30) | 0 | 11% (1 of 9) |
| Mine | High Elf Realms | 15 | 0 | 0 | 2 (net +0) | 3 (net +112) | 4 (net +119) | 6 (net +190) | 0 | 13% (2 of 15) |
| Mine | Kingdom of Bretonnia | 5 | 0 | 0 | 2 (net +542) | 1 (net +0) | 0 | 1 (net +0) | 1 | 50% (2 of 4) |
| Mine | Lizardmen | 3 | 2 (net +486) | 0 | 0 | 0 | 1 (net +50) | 0 | 0 | 0% (0 of 3) |
| Mine | Ogre Kingdoms | 6 | 0 | 0 | 0 | 3 (net +0) | 0 | 2 (net +38) | 1 | 0% (0 of 5) |
| Mine | Orc & Goblin Tribes | 5 | 0 | 0 | 1 (net +45) | 0 | 0 | 2 (net +95) | 2 | 33% (1 of 3) |
| Mine | Skaven | 2 | 0 | 0 | 0 | 1 (net -92) | 0 | 1 (net +0) | 0 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 7 | 1 (net +0) | 0 | 0 | 0 | 0 | 5 (net -41) | 1 | 0% (0 of 6) |
| Mine | Vampire Counts | 14 | 3 (net +155) | 0 | 1 (net +0) | 2 (net +102) | 5 (net +155) | 3 (net -121) | 0 | 7% (1 of 14) |
| Mine | Warriors of Chaos | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +608) | 0 | 0% (0 of 1) |
| Opponent | Dwarfen Mountain Holds | 8 | 2 (net +42) | 0 | 1 (net +0) | 1 (net +0) | 1 (net +52) | 3 (net -16) | 0 | 12% (1 of 8) |
| Opponent | Empire of Man | 5 | 1 (net -319) | 0 | 0 | 2 (net +115) | 2 (net +100) | 0 | 0 | 0% (0 of 5) |
| Opponent | Grand Cathay | 8 | 1 (net +210) | 0 | 2 (net +182) | 3 (net +205) | 0 | 1 (net -162) | 1 | 29% (2 of 7) |
| Opponent | Kingdom of Bretonnia | 2 | 1 (net +185) | 1 (net +105) | 0 | 0 | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 11 | 3 (net +138) | 0 | 1 (net +89) | 1 (net +0) | 1 (net +104) | 3 (net +123) | 2 | 11% (1 of 9) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +139) | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 27 | 3 (net +128) | 1 (net -60) | 5 (net +296) | 6 (net +138) | 1 (net +91) | 10 (net +275) | 1 | 19% (5 of 26) |
| Opponent | Vampire Counts | 31 | 7 (net -36) | 1 (net -54) | 7 (net +218) | 9 (net +83) | 2 (net +56) | 5 (net +291) | 0 | 23% (7 of 31) |
| Opponent | Warriors of Chaos | 28 | 5 (net +114) | 0 | 7 (net +71) | 2 (net +32) | 2 (net +0) | 12 (net +175) | 0 | 25% (7 of 28) |
| Opponent | Wood Elf Realms | 35 | 6 (net -99) | 1 (net +55) | 6 (net +28) | 10 (net +153) | 3 (net +84) | 8 (net +111) | 1 | 18% (6 of 34) |

### Charged fights, damage counted: shots-h2h-opp-7c46ffc-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 9 | 254 | 288 | +176 | 216 | 44 | +171 | +67.5 |
| Mine | Effective (55-75%) | 9 | 255 | 204 | +194 | 218 | 12 | +206 | +80.8 |
| Mine | 76-89% | 18 | 210 | 170 | +56 | 68 | 15 | +53 | +25.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 29 | 269 | 167 | +64 | 131 | 77 | +54 | +19.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 13 | 440 | 102 | +103 | 122 | 19 | +104 | +23.5 |
| Mine | No odds | 7 | 213 | 267 | +42 | 87 | 34 | +53 | +24.9 |
| Mine | All fights | 85 | 275 | 182 | +92 | 131 | 41 | +90 | +32.6 |
| Opponent | Long shot (under 50%) | 29 | 209 | 243 | +24 | 152 | 145 | +8 | +3.6 |
| Opponent | 50-54% | 4 | 156 | 166 | +12 | 40 | 40 | +0 | +0.2 |
| Opponent | Effective (55-75%) | 29 | 284 | 225 | +142 | 191 | 38 | +153 | +54.0 |
| Opponent | 76-89% | 34 | 283 | 183 | +118 | 133 | 25 | +109 | +38.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 43 | 262 | 208 | +174 | 216 | 47 | +169 | +64.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 12 | 466 | 82 | +68 | 70 | 8 | +62 | +13.4 |
| Opponent | No odds | 5 | 143 | 183 | +41 | 93 | 44 | +49 | +34.1 |
| Opponent | All fights | 156 | 270 | 201 | +111 | 162 | 55 | +107 | +39.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| shots-h2h-opp-7c46ffc-p2 | move | 437 | 106 (24%) | 75 (17%) | 65 (15%) | 266 (61%) |
| shots-h2h-opp-7c46ffc-p2 | objective | 347 | 71 (20%) | 51 (15%) | 52 (15%) | 224 (65%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

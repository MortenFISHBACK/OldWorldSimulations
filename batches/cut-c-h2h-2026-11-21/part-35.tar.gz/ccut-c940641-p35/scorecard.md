# Doctrine scorecard: ccut-c940641-p35

### Scorecard: ccut-c940641-p35

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2127 | 3 | 1 | Mine | yes | 6 | - | 2 | 3 | 0 | 0 | 0 | 500 |
| L2127 | 3 | 1 | Opponent | no | 2 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 3 | 3 | 2 | 0 | 0 | 0 | 127 |
| L2231 | 5 | 1 | Opponent | no | - | - | 1 | 3 | 1 | 0 | 0 | 170 |
| L2335 | 1 | 1 | Mine | no | 0 | 3 | 0 | 1 | 0 | 0 | 0 | 185 |
| L2335 | 1 | 1 | Opponent | no | 2 | 1 | 4 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 67% | 3.0 | 3.0 | 1.7 | 2.0 | 0.0 | 0.0 | 0.0 | 270.7 |
| **Average** | | | Opponent | 0% | 2.0 | 1.5 | 2.3 | 2.0 | 0.3 | 0.0 | 0.0 | 56.7 |

### KPIs: ccut-c940641-p35

Rules off - Opponent only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 21% (3 of 14) | 0% (0 of 17) | 10% (3 of 31) |
| Winner chose to follow up after the loser gave ground |  | 67% (2 of 3); on the table 67% | 100% (5 of 5); on the table 100% | 88% (7 of 8); on the table 88% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 50% (1 of 2); on the table 50% | - | 50% (1 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 60% (3 of 5); on the table 60% | 100% (5 of 5); on the table 100% | 80% (8 of 10); on the table 80% |
| Magic missiles tried each own turn | 50%+ | 17% (1 of 6) | 17% (3 of 18) | 17% (4 of 24) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 33% (1 of 3) | 17% (3 of 18) | 19% (4 of 21) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 43% (3 of 7) | 67% (6 of 9) | 56% (9 of 16) |
| Points that never fought | lower | 50% (3026 of 5999) | 52% (3091 of 6000) | 51% (6117 of 11999) |
|   infantry points that never fought | lower | 85% (1315 of 1552) | 58% (605 of 1035) | 74% (1920 of 2587) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 74% (14 of 19) | 70% (21 of 30) | 71% (35 of 49) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 0.7 uses a game | 50% (1 of 2); 1.3 uses a game | 67% (2 of 3); 1.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 71% (3180 of 4484) | 62% (3434 of 5546) | 66% (6614 of 10030) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 5.0 (100%) | 5.0 (75%) |
| MARCHED: its unit marched | 0.7 (40%) | 0.0 (0%) | 0.7 (10%) |
| GONE: slain | 1.0 (60%) | 0.0 (0%) | 1.0 (15%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 10.3 | 1.0 | 1.7 | 1.3 | 0.7 | 0.0 |
| not cast | 3.7 | 1.0 | 0.3 | 6.7 | 1.3 | 16.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.0 (100%) | 0.3 (100%) | 5.0 (75%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (10%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.0 (27%) | 0.0 (0%) | 0.0 (0%) | 1.0 (15%) | 0.0 (0%) | 2.3 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (6%) |
| STUPIDITY: Stupidity | 0.3 (9%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (100%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (64%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.7 (79%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.7 a game | 0.8 a game |
| stood (cast and not dispelled) | - | 60% (3 of 5) | 60% (3 of 5) |
| the unit moved after it | - | 33% (1 of 3) | 33% (1 of 3) |
| it charged on its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| the enemy charged it first | - | 0% (0 of 3) | 0% (0 of 3) |
| it fought by the end of its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 3) | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (3 of 3) | 100% (3 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 70% (73 of 105) | 65% (20 of 31) | 68% (93 of 136) |
|   cavalry | 100% (14 of 14) | 71% (10 of 14) | 86% (24 of 28) |
|   character | 0% (0 of 17) | 20% (1 of 5) | 5% (1 of 22) |
|   chariot | 91% (10 of 11) | - | 91% (10 of 11) |
|   infantry | 78% (49 of 63) | 75% (9 of 12) | 77% (58 of 75) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.3 (3%) | 1.7 (45%) | 2.0 (14%) |
| CHARGED: it charged | 3.0 (28%) | 1.3 (36%) | 4.3 (30%) |
| FLEEING: it fled or was fleeing | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 1.0 (9%) | 0.0 (0%) | 1.0 (7%) |
| NO TARGET IN RANGE | 3.3 (31%) | 0.3 (9%) | 3.7 (26%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.0 (19%) | 0.3 (9%) | 2.3 (16%) |
| OTHER BAR | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 12.3 | 0.3 | 97% | 0.5 pts | 6 pts |
| character | 0.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 3.3 | 0.7 | 80% | 1.5 pts | 5 pts |
| infantry | 23.0 | 4.7 | 84% | 6.6 pts | 151 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.7 | 5.7 | 4.7 |
| Charges that made contact a game | 2.3 | 4.3 | 3.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.50 declared, 1.50 contact (2 units) | 1.50 declared, 1.50 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.34 declared, 0.22 contact (32 units) | 0.58 declared, 0.42 contact (24 units) | 0.45 declared, 0.30 contact (56 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 71% (5 of 7) | 100% (1 of 1) | 0% (0 of 1) | 67% (6 of 9) |
| Character in a unit | 100% (2 of 2) | 100% (1 of 1) | - | 100% (3 of 3) |
| Character on its own | 100% (6 of 6) | - | 50% (4 of 8) | 71% (10 of 14) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 64% (7 of 11) | 100% (1 of 1) | - | 67% (8 of 12) |
| Monster | 83% (5 of 6) | 100% (1 of 1) | - | 86% (6 of 7) |
| Monstrous | 50% (1 of 2) | - | - | 50% (1 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Skaven | 1 | 67% (2 of 3); on the table 67% | 17% (1 of 6) | 49% | 78% (7 of 9) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 2 | 50% (1 of 2); on the table 50% | - | 51% | 70% (7 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | - | 0% (0 of 6) | 53% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (2 of 2); on the table 100% | 33% (2 of 6) | 56% | 92% (11 of 12) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (3 of 3); on the table 100% | 17% (1 of 6) | 46% | 50% (6 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p35, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 67% (4) | 57% (4) | 62% (8) |
| ...free all their last turn and able to turn (per game) | 0.67 | 1.00 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.67 | 0.00 | 0.67 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 1.00 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.33 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.67 | 0.67 |

### Quality by phase: ccut-c940641-p35

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.0 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 33% (3 of 9) | 40% (6 of 15) |
| Strategy | Shoot objectives carried out (shot that target) | 61% (14 of 23) | 42% (5 of 12) |
| Strategy | Support requests answered (helper made contact too) | - | 33% (1 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 67% (2 of 3) |
| Strategy | Joined characters whose unit fought | 0% (0 of 3) | 25% (1 of 4) |
| Strategy | Lone characters that fought | 57% (4 of 7) | 44% (4 of 9) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.0 | 2.0 |
| Movement | Points that never moved of their own | 270.7 | 56.7 |
| Movement | Fights charged into per game | 2.3 | 3.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 5 | 1 of 8, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 5 | 1 of 8, net +540 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 5, net +125 | 3 of 8, net +75 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 of 5, net +163 | 2 of 8, net +195 |
| Shooting | Shots by shooting units (incl. breath weapons) | 27.0 | 7.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 28% (23 of 81) | 48% (10 of 21) |
| Shooting | Points destroyed by shooting units | 0.0 | 118.3 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.3 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 1) | 100% (1 of 1) |
| Magic | Wounds caused by magic missiles | 0.3 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 6.0 / 0.0 / 0.0 / 0.0 | 2.3 / 1.0 / 0.0 / 0.7 |
| Combat | Points destroyed in combat | 96.7 | 459.7 |
| Combat | Points run down | 287.7 | 0.0 |
| Combat | Net points per charged fight, damage counted | +126 | +83 |
| Combat | Net per 100 charger points, damage counted | +37.1 | +25.2 |
| Combat | First round won (charged fights) | 86% | 91% |
| Combat | Net points per charged fight | +111 | +102 |
| Combat | Net points per supported fight / lone fight | - / +111 | +300 / +58 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 7 | 5 of 11 |
| Game | Points lost | 732.7 | 414.0 |
| Game | VP from objectives | 1000.0 | 606.7 |
| Game | Lone holders (player turns) | 3.0 | 2.0 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +64 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1147
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ccut-c940641-p35

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +9.5 | 0.0 | 70.0 | - | - | - | - |
| ARMY TABLE | 27.0 | +691.9 | 0.0 | 148.0 | 23.3 | +186.0 | 0.0 | 283.0 |
| BACKUP TARGETS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.3 | -11.8 | 13.7 | 0.0 |
| CAST JOB | 0.3 | +13.9 | 0.0 | 180.0 | 3.0 | +9.3 | 96.0 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.7 | +10.9 | 0.0 | 0.0 | 0.7 | +17.5 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 48.3 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +14.6 | 0.0 | 0.0 | 0.7 | +32.1 | 0.0 | 0.0 |
| CHARACTER GUNS | 2.7 | +0.0 | 0.0 | 148.0 | - | - | - | - |
| CHARGE LOSSES | 12.3 | -439.1 | 0.0 | 995.7 | 19.3 | -557.1 | 0.0 | 507.0 |
| CHARGE NOW FIRST | 3.0 | +0.0 | 119.7 | 0.0 | 2.0 | +0.0 | 378.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 10.3 | +0.0 | 0.0 | 298.0 | 10.3 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 25.0 |
| CONVEYANCE SEARCH | - | - | - | - | 1.7 | +105.5 | 0.0 | 0.0 |
| COVER ONCE | 6.7 | -363.3 | 0.0 | 407.3 | 7.3 | -288.1 | 0.0 | 78.0 |
| DEFENSIVE ARMY | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.0 | +21.9 | 0.0 | 48.3 | 7.7 | +21.5 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -1.3 | 0.0 | 0.0 | 0.3 | -8.8 | 74.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +0.5 | 41.7 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | - | - | - | - | 3.3 | +40.7 | 20.0 | 0.0 |
| EXACT ROUND | 1.7 | +17.7 | 132.7 | 0.0 | 2.7 | -9.9 | 374.0 | 15.0 |
| FACES THE THREAT | - | - | - | - | 0.3 | +16.2 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.3 | +6.7 | 226.3 | 30.7 | 4.3 | +0.1 | 754.3 | 15.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 1.7 | +14.6 | 0.0 | 22.0 | 20.7 | +227.6 | 0.0 | 78.0 |
| FEATURE BUFFS | 2.0 | +8.0 | 0.0 | 68.0 | 2.0 | +5.4 | 0.0 | 83.7 |
| FIGHT TO THE END | 0.3 | +3.2 | 0.0 | 0.0 | 1.0 | +47.9 | 131.3 | 0.0 |
| FIRE IN ORDER | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 107.7 | +8106.3 | 516.0 | 2011.7 | 93.0 | +4678.0 | 1639.3 | 602.0 |
| FLANK NOT WEIGHED | 6.3 | +0.0 | 0.0 | 511.7 | 8.0 | +0.0 | 0.0 | 125.3 |
| FOLLOW UP WEIGHED | - | - | - | - | 0.3 | +92.3 | 0.0 | 0.0 |
| FOUR ROUNDS | 3.7 | +269.4 | 283.0 | 30.7 | 5.3 | +295.1 | 893.3 | 15.0 |
| FREED FROM HIS FIGHT | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 40.0 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -13.4 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -8.1 | 0.0 | 0.0 | 0.7 | -6.2 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.7 | -18.8 | 144.0 | 0.0 |
| GOAL WALK | 16.3 | +2049.1 | 0.0 | 620.0 | 5.3 | +239.6 | 0.0 | 0.0 |
| GUN FIGURES | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 1.0 | +0.0 | 0.0 | 40.0 |
| HELPER UNSEEN | - | - | - | - | 0.3 | +0.0 | 30.7 | 0.0 |
| HIS CHARGE BY HIS RUN | 7.3 | +0.0 | 0.0 | 865.7 | 13.3 | +0.0 | 0.0 | 507.0 |
| HIS CHARGE DENIED | 0.3 | +11.9 | 0.0 | 30.7 | 0.7 | +74.6 | 130.0 | 0.0 |
| HIS CHARGE LIST | 5.0 | +0.0 | 0.0 | 148.0 | 5.7 | +0.0 | 0.0 | 251.0 |
| HIS LEGAL MOVES | 7.0 | +0.0 | 0.0 | 310.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.7 | -15.8 | 0.0 | 40.0 | 5.3 | -109.4 | 0.0 | 0.0 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 51.0 | +21.0 | 826.7 | 0.0 |
| HIS MOVE WHY | 30.0 | +0.0 | 0.0 | 443.3 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 26.0 | +13.2 | 0.0 | 0.0 |
| HIS ONE QUARTER | 8.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 9.0 | +0.0 | 0.0 | 570.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 19.3 | +0.0 | 0.0 | 48.0 | 10.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVER COMES | 3.3 | +0.0 | 0.0 | 48.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 41.7 | +816.9 | 0.0 | 698.7 | 52.3 | +1390.8 | 0.0 | 530.3 |
| HIS SHOTS BY HIS RUN | 29.7 | +292.4 | 0.0 | 652.0 | 51.7 | +696.2 | 0.0 | 587.0 |
| HIS TURN DENIED | 0.3 | +1.5 | 38.0 | 0.0 | 1.3 | +16.8 | 114.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 21.3 | +0.0 | 0.0 | 254.7 | 15.0 | +0.0 | 0.0 | 334.7 |
| HOLDER ASSIGNMENT | 13.7 | +940.3 | 0.0 | 117.3 | 10.0 | +807.9 | 0.0 | 167.3 |
| HOLDS AMBUSHERS | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.3 | -115.6 | 283.0 | 30.7 | 4.7 | -127.8 | 639.3 | 0.0 |
| HUNT IN PAIRS | 0.7 | +11.7 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | 2.0 | -38.9 | 0.0 | 65.0 | 19.0 | -184.0 | 0.0 | 0.0 |
| JOINT CHARGE NOW | 0.7 | -69.9 | 121.7 | 0.0 | 2.3 | +105.3 | 589.3 | 15.0 |
| KEPT FROM ITS LAST STOP | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +48.6 | 0.0 | 0.0 | 0.7 | +0.4 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 7.0 | +0.0 | 311.0 | 125.7 | 4.7 | +0.0 | 200.0 | 177.0 |
| LONE WIZARD KEPT IN | 1.3 | +77.2 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 0.7 | +19.1 | 0.0 | 30.7 | 0.3 | +0.7 | 13.7 | 0.0 |
| LOST AFTER ESCAPE | 1.0 | +0.6 | 83.7 | 0.0 | 1.7 | +8.0 | 169.0 | 0.0 |
| MANOEUVRE | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +3.6 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +0.2 | 0.0 | 180.0 | - | - | - | - |
| MARCH CHECK | 0.3 | +20.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.3 | +0.6 | 0.0 | 180.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | -54.9 | 0.0 | 180.0 | - | - | - | - |
| MARCH WHEELS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.3 | +27.0 | 0.0 | 360.0 | 2.0 | +19.1 | 0.0 | 0.0 |
| MEETS IN TIME | 4.3 | +147.4 | 0.0 | 48.3 | 4.3 | +410.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.3 | +47.7 | 0.0 | 328.0 | 5.3 | +40.6 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 2.7 | +58.1 | 0.0 | 508.0 | 6.3 | +38.6 | 0.0 | 0.0 |
| MOVE ORDER | 2.0 | +0.0 | 87.7 | 74.0 | 2.7 | +0.0 | 0.0 | 38.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 0.3 | -15.9 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 6.0 | +1005.3 | 0.0 | 260.0 | 9.0 | +561.8 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 14.3 | +544.3 | 0.0 | 123.3 | 7.3 | +283.5 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 5.3 | +871.8 | 41.7 | 440.0 | 4.3 | +259.0 | 65.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -20.0 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 3.0 | -96.9 | 283.0 | 0.0 | 3.7 | -233.2 | 556.0 | 0.0 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT TURNED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | 0.3 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 5.7 | -136.2 | 0.0 | 137.7 | 8.0 | -205.9 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.3 | -91.4 | 0.0 | 245.0 | 7.0 | -103.8 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 0.3 | +11.0 | 83.7 | 0.0 | 2.0 | +48.5 | 392.3 | 15.0 |
| ONE OBJECTIVE FORMULA | 7.7 | -18.8 | 0.0 | 79.7 | 3.7 | -39.1 | 0.0 | 83.7 |
| ONE ROUTE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.7 | +24.9 | 76.0 | 0.0 | 0.3 | +13.5 | 22.0 | 0.0 |
| OVERRUNS AWAY | 1.7 | +13.7 | 108.7 | 30.7 | 1.3 | +12.7 | 234.7 | 0.0 |
| PATHS CROSS | - | - | - | - | 1.0 | +40.7 | 0.0 | 0.0 |
| PLAN RESULT | 50.0 | +321.7 | 259.7 | 1135.7 | 49.0 | +949.8 | 957.3 | 535.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 8.0 | -429.7 | 0.0 | 0.0 | 8.7 | -114.6 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | - | - | - | - | 0.7 | -11.1 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | - | - | - | - | 0.7 | -0.2 | 0.0 | 0.0 |
| QUARTER ODDS | 24.3 | +1956.1 | 83.3 | 43.3 | 30.7 | +2786.4 | 161.7 | 83.3 |
| RANDOM MOVE BY FIGURES | 2.3 | +111.7 | 0.0 | 215.0 | 3.0 | +23.2 | 0.0 | 56.7 |
| REAL GROUND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 1.0 | +17.2 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 3.0 | +158.5 | 0.0 | 46.0 | 2.0 | +86.3 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 6.7 | +28.2 | 0.0 | 22.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.7 | -11.8 | 13.7 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -10.5 | 0.0 | 0.0 | 1.3 | -10.7 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 25.0 |
| RESERVE FALL BACK | 1.0 | +8.7 | 0.0 | 0.0 | 0.7 | +102.0 | 0.0 | 38.0 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.3 | +3.5 | 0.0 | 0.0 |
| RISK BY ARC | 3.0 | -6.3 | 245.0 | 30.7 | 5.0 | -38.7 | 893.3 | 15.0 |
| ROUNDS AFTER TERROR | 0.7 | -22.5 | 121.7 | 0.0 | 1.7 | -29.6 | 223.0 | 0.0 |
| RUN DOWN | 2.3 | -72.8 | 201.3 | 0.0 | 1.7 | -3.6 | 166.7 | 0.0 |
| SAME CHARGE LATER | 0.3 | -13.8 | 41.7 | 0.0 | - | - | - | - |
| SCOUT SPOT | 1.3 | +1.1 | 0.0 | 22.0 | - | - | - | - |
| SCOUT WAITS | 1.3 | +0.0 | 0.0 | 22.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -23.5 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +10.0 | 0.0 | 0.0 | 1.3 | +70.9 | 0.0 | 38.0 |
| SECOND LOOK | 0.7 | +34.1 | 0.0 | 0.0 | 0.3 | +3.8 | 0.0 | 0.0 |
| SET CREDITED ONCE | 1.0 | -8.9 | 0.0 | 0.0 | 2.3 | -102.0 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.7 | +17.5 | 0.0 | 0.0 | 3.7 | +34.2 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.3 | +1.7 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +3.0 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 9.0 | +0.0 | 0.0 | 275.7 | 5.7 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.0 | +75.1 | 41.7 | 148.0 | 0.7 | +2.1 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.7 | -3.7 | 56.7 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 23.0 | -163.3 | 0.0 | 582.0 | 27.0 | -224.4 | 0.0 | 347.7 |
| SHOTS AFTER THE MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 27.3 | +300.4 | 0.0 | 235.7 | 7.0 | +67.8 | 0.0 | 38.0 |
| SPELL WORTH | 0.7 | +12.7 | 360.0 | 360.0 | 3.3 | +7.8 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 8.0 | +0.0 | 0.0 | 276.0 | 10.3 | +0.0 | 0.0 | 134.7 |
| STAND AND SHOOT | 0.3 | -0.5 | 38.0 | 0.0 | 1.0 | -3.7 | 62.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 3.3 | +0.0 | 130.0 | 76.0 |
| STANDS STILL | 43.7 | +0.0 | 233.0 | 433.3 | 31.3 | +0.0 | 746.0 | 167.0 |
| STAY WORTH | 22.7 | +151.1 | 191.3 | 65.0 | 11.0 | +59.8 | 421.0 | 38.0 |
| STRIKE BY THE ODDS | 0.3 | +11.4 | 56.7 | 0.0 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 8.0 | +309.2 | 0.0 | 27.3 | 2.3 | +5.5 | 0.0 | 40.0 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 20.0 | 0.0 |
| SUPPORT WORKED OUT | 8.0 | +309.2 | 0.0 | 27.3 | 2.3 | +5.5 | 0.0 | 40.0 |
| SURE REACH TOGETHER | 0.3 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 74.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 1.3 | -47.9 | 65.0 | 0.0 |
| THE RISK READS HIS RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.3 | +0.0 | 0.0 | 35.3 | 4.3 | +0.0 | 167.3 | 0.0 |
| THE ROW KEEPS ITS WAY | 3.3 | +0.0 | 0.0 | 74.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 13.7 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 50.3 | +0.0 | 0.0 | 883.0 | 46.0 | +0.0 | 0.0 | 203.3 |
| TIED UP BY THE SUM | 2.0 | +278.3 | 132.7 | 0.0 | 1.7 | +225.8 | 200.3 | 0.0 |
| TIME ON OUR SIDE | 50.3 | +431.6 | 96.7 | 686.7 | 6.0 | +41.7 | 130.0 | 0.0 |
| WAITS AGAIN | 4.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 0.7 | +27.9 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | - | - | - | - | 0.7 | -5.2 | 40.0 | 0.0 |
| WHO HITS BACK | 0.3 | +2.2 | 0.0 | 0.0 | 0.7 | +74.3 | 0.0 | 56.7 |
| WHOLE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 2.3 | -255.5 | 0.0 | 435.7 | 1.0 | -199.7 | 0.0 | 83.3 |
| WHOLE FIGHT GAIN | 0.3 | +96.2 | 83.7 | 0.0 | 0.7 | +42.9 | 254.0 | 15.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 4.7 | +84.1 | 0.0 | 251.0 |

### Rule changes: ccut-c940641-p35

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 151 | 151 | 113 | 37.67 | +2658 | +23.5 |
| HIS MOVE AS HE DECIDES | 153 | 153 | 90 | 30.00 | +0 | +0.0 |
| HIS SHOT LIST | 282 | 267 | 75 | 25.00 | +657 | +8.8 |
| HOLDER ASSIGNMENT | 71 | 71 | 65 | 21.67 | +3370 | +51.8 |
| HIS MOVE WHY | 90 | 90 | 56 | 18.67 | +0 | +0.0 |
| OFF BEST | 41 | 41 | 41 | 13.67 | -1027 | -25.0 |
| HIS SHOTS BY HIS RUN | 244 | 233 | 39 | 13.00 | +205 | +5.2 |
| FIVE ACTION | 602 | 581 | 37 | 12.33 | +1789 | +48.3 |
| LEGAL CHARGES ONLY | 35 | 35 | 35 | 11.67 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 32 | 10.67 | +0 | +0.0 |
| QUARTER ODDS | 165 | 157 | 29 | 9.67 | +1900 | +65.5 |
| DEPLOY BY FIGURES | 47 | 47 | 26 | 8.67 | +299 | +11.5 |
| REDIRECT FOR A FRIEND IN REACH | 25 | 25 | 24 | 8.00 | +68 | +2.8 |
| MOVE TO CHARGE COMPUTED | 45 | 37 | 19 | 6.33 | +1290 | +67.9 |
| GOAL WALK | 65 | 65 | 18 | 6.00 | +1452 | +80.7 |
| PROMISE BY ITS OWN SUM | 50 | 50 | 18 | 6.00 | -1633 | -90.7 |
| HIS ONE MOVE | 78 | 75 | 17 | 5.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 169 | 145 | 17 | 5.67 | +68 | +4.0 |
| MOVE ORDER | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 29 | 27 | 14 | 4.67 | +1100 | +78.6 |
| FOUR ROUNDS | 27 | 25 | 13 | 4.33 | +332 | +25.6 |
| MEETS IN TIME | 26 | 26 | 13 | 4.33 | +1082 | +83.3 |
| ADVANCE LANE KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| HARD STAY DROPPED | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| JOINT CHARGE NOW | 9 | 9 | 9 | 3.00 | +106 | +11.8 |
| RANDOM MOVE BY FIGURES | 16 | 16 | 9 | 3.00 | +405 | +45.0 |
| HOLDS AMBUSHERS | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| SUPPORT ADDS | 31 | 30 | 8 | 2.67 | +72 | +9.0 |
| SUPPORT WORKED OUT | 31 | 30 | 8 | 2.67 | +72 | +9.0 |
| THE RISK READS HIS RUN | 18 | 18 | 8 | 2.67 | +0 | +0.0 |
| CHARGE LOSSES | 95 | 91 | 7 | 2.33 | +1041 | +148.8 |
| IDLE COST | 63 | 37 | 7 | 2.33 | +23 | +3.3 |
| SHOT RISK POINTS | 150 | 145 | 7 | 2.33 | +36 | +5.2 |
| STAY WORTH | 101 | 89 | 7 | 2.33 | +147 | +21.0 |
| TIED UP BY THE SUM | 11 | 9 | 7 | 2.33 | +220 | +31.5 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +147 | +24.5 |
| SHOOTS FROM THE BEST SPOT | 8 | 8 | 6 | 2.00 | +60 | +10.0 |
| RESERVE FALL BACK | 5 | 5 | 5 | 1.67 | +332 | +66.4 |
| SEARCH SPOT | 5 | 5 | 5 | 1.67 | +243 | +48.6 |
| CAST JOB | 10 | 10 | 4 | 1.33 | +42 | +10.6 |
| CHARGE NOW FIRST | 15 | 15 | 4 | 1.33 | -52 | -13.1 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +232 | +57.9 |
| RISK BY ARC | 24 | 22 | 4 | 1.33 | +46 | +11.5 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SET UP BY THE SET | 16 | 16 | 4 | 1.33 | +108 | +26.9 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +140 | +46.7 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| ONE JOINT FIGURE | 7 | 7 | 3 | 1.00 | +39 | +13.0 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +122 | +40.7 |
| SECOND LOOK | 3 | 3 | 3 | 1.00 | +114 | +37.9 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +10 | +3.3 |
| THE ROW IN ITS ORDER | 20 | 3 | 3 | 1.00 | +0 | +0.0 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +132 | +43.9 |
| WOUNDS ON THE RANKS | 14 | 14 | 3 | 1.00 | +21 | +7.1 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 4 | 4 | 2 | 0.67 | +6 | +2.8 |
| COVER ONCE | 42 | 24 | 2 | 0.67 | +57 | +28.5 |
| EVASIVE BY THE ODDS | 10 | 10 | 2 | 0.67 | +91 | +45.6 |
| FALLS SHORT | 67 | 56 | 2 | 0.67 | +38 | +18.9 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HIS TURN DENIED | 5 | 4 | 2 | 0.67 | +17 | +8.4 |
| MAX FOR POSITIONING | 10 | 10 | 2 | 0.67 | +1 | +0.3 |
| NO DOUBLE ROUNDS | 20 | 18 | 2 | 0.67 | +79 | +39.5 |
| ONE OBJECTIVE FORMULA | 34 | 28 | 2 | 0.67 | +58 | +29.0 |
| OPENS UP | 3 | 3 | 2 | 0.67 | +30 | +15.0 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -1 | -0.3 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | -26 | -13.0 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 10 | 10 | 2 | 0.67 | +48 | +23.8 |
| WHOLE FIGHT GAIN | 3 | 3 | 2 | 0.67 | +90 | +44.8 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +29 | +28.6 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -36 | -35.5 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 13 | 12 | 1 | 0.33 | +12 | +12.2 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +49 | +48.7 |
| FIGHT TO THE END | 4 | 4 | 1 | 0.33 | +18 | +18.0 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +277 | +277.0 |
| HONEST WORTH | 24 | 22 | 1 | 0.33 | +1 | +0.7 |
| LONG SHOT | 3 | 3 | 1 | 0.33 | +1 | +1.2 |
| LOST AFTER ESCAPE | 8 | 7 | 1 | 0.33 | +1 | +1.2 |
| MANOEUVRE | 4 | 4 | 1 | 0.33 | +18 | +18.5 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +0 | +0.5 |
| MARCH CHECK | 1 | 1 | 1 | 0.33 | +44 | +44.1 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -2 | -1.6 |
| NEARER NOT NEEDED | 65 | 60 | 1 | 0.33 | +18 | +18.4 |
| OVERRUNS AWAY | 9 | 8 | 1 | 0.33 | +1 | +0.8 |
| REDIRECT COUNTER | 15 | 13 | 1 | 0.33 | +10 | +9.9 |
| REFUSING RETIRES | 2 | 2 | 1 | 0.33 | -8 | -7.8 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +11 | +10.7 |
| SHOTS IN THE MOVE | 103 | 82 | 1 | 0.33 | +13 | +12.9 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +34 | +34.2 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.5 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CHARACTER GUNS | 8 | 8 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 62 | 61 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 5 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 3 | 3 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 20 | 19 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 12 | 12 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 43 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 10 | 10 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 4 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 3 | 3 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 62 | 60 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 32 | 32 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 34 | 29 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 27 | 25 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 43 | 39 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 37 | 32 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 88 | 84 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 14 | 14 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 109 | 109 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 8 | 8 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 20 | 12 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 27 | 16 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 1 | trace | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 34 | 18 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 297 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 3 | 3 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 6 | 4 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 7 | 7 | 0 | 0.00 | - | - |
| RUN DOWN | 12 | 10 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 10 | 10 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 44 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 18 | 18 | 0 | 0.00 | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 55 | 44 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 10 | 10 | 0 | 0.00 | - | - |
| STANDS STILL | 225 | 223 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 3 | 3 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 10 | not checked | - | - | - | - |
| THE PROMISE ADDS | 4 | 4 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 24 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 3 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 14 | not checked | - | - | - | - |
| THE TABLE BINDS | 289 | not checked | - | - | - | - |
| WAITS AGAIN | 13 | 12 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p35

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.33 | 5.67 | 27.8 |
| PROMISE BY ITS OWN SUM | rule | 3.33 | 2.67 | 90.7 |
| ARMY TABLE | rule | 3.33 | 2.00 | 43.7 |
| RULE SWITCHED OFF | gate | - | 1.67 | 11.0 |
| JOINT CHARGE NOW | rule | 0.67 | 0.67 | 82.5 |
| CHARGE NOW FIRST | rule | 1.00 | - | 17.3 |
| HOLDER ASSIGNMENT | rule | 0.67 | - | 18.0 |
| AFTERMATH BAND | gate | - | 0.33 | 2.8 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.33 | 21.0 |
| BEST PRIZE | rule | - | 0.33 | 35.5 |
| MARCH OF THE TABLE | rule | 0.33 | - | 1.6 |
| NO REASON | gate | 0.33 | - | 29.0 |
| REDIRECT WEIGHED | rule | - | 0.33 | 26.0 |
| REFUSING RETIRES | rule | 0.33 | - | 7.8 |
| SET UP BY THE SET | rule | - | 0.33 | 5.2 |

### Plans: ccut-c940641-p35

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.3 | 70% | 460 | 221 | 48% |
| Mine | move | 40.7 | 92% | 2771 | 0 | 0% |
| Mine | shoot | 5.3 | 31% | 318 | 101 | 32% |
| Mine | support | 0.7 | 100% | 15 | 0 | 0% |
| Opponent | charge | 5.0 | 100% | 524 | 904 | 173% |
| Opponent | join | 5.7 | 94% | 271 | 0 | 0% |
| Opponent | move | 35.0 | 95% | 1123 | 0 | 0% |
| Opponent | shoot | 3.0 | 33% | 256 | 46 | 18% |
| Opponent | support | 0.3 | 100% | 1 | 0 | 0% |

### Battle groups: ccut-c940641-p35

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.0 | 11% | 0% | 0% | - | 0% | 100% | 0% | 0% | 0% |
| Opponent | REDIRECT COUNTER | 2.0 | 17% | 100% | 100% | 0% | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p35

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Chaff | 6 | 22 (6) | 0 | 22 | 34 | 17% | 1.0 | - | 26 (5) | 0 (1) | 26 (5) | 0 (1) |
| Mine | Character | 7 | 59 (7) | 48 | 10 | 35 | 14% | 2.5 | 123 (2) | 0 (1) | 43 (2) | 82 (4) | 0 (1) |
| Mine | Clean-up | 1 | 439 (1) | 0 | 439 | 100 | 0% | 5.0 | - | 439 (1) | - | - | 439 (1) |
| Mine | Fast Hammer | 6 | 0 (6) | 0 | 0 | 42 | 50% | 4.0 | 0 (4) | 0 (2) | - | - | 0 (6) |
| Mine | Hammer | 5 | 64 (5) | 44 | 20 | 80 | 20% | 1.5 | 80 (3) | 44 (2) | - | 138 (2) | 29 (3) |
| Mine | Holder | 8 | 89 (8) | 12 | 77 | 15 | 25% | 2.2 | 143 (2) | 94 (5) | 0 (1) | 143 (2) | 72 (6) |
| Mine | Shooter | 5 | 64 (5) | 0 | 64 | 30 | 0% | 1.8 | 0 (2) | 146 (3) | - | 76 (4) | 0 (1) |
| Mine | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | 0 (1) | - | 0 (2) | 0 (1) |
| Opponent | Chaff | 4 | 38 (4) | 0 | 38 | 50 | 25% | 4.7 | 50 (3) | - | 0 (1) | 50 (3) | 0 (1) |
| Opponent | Character | 11 | 73 (11) | 73 | 0 | 20 | 55% | 3.2 | 197 (2) | 42 (7) | 0 (1) | 35 (6) | 187 (4) |
| Opponent | Fast Hammer | 6 | 11 (6) | 2 | 10 | 20 | 33% | 2.2 | - | 13 (5) | 0 (1) | 4 (3) | 16 (3) |
| Opponent | Hammer | 8 | 11 (8) | 11 | 0 | 29 | 25% | 4.2 | 0 (3) | 17 (5) | - | 14 (6) | 0 (2) |
| Opponent | Holder | 3 | 0 (3) | 0 | 0 | 29 | 67% | 4.0 | 0 (2) | 0 (1) | - | - | 0 (3) |
| Opponent | Shooter | 3 | 99 (3) | 0 | 99 | 31 | 0% | 1.3 | - | 118 (2) | 55 (1) | 132 (2) | 26 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |

### Charged fights: ccut-c940641-p35

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 46 | -46 | 0 of 2 | 1 of 2 | - | -46 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 434 | 2.5 | 1.0 | 174 | 0 | +174 | 1 of 5 | 5 of 5 | - | +174 |
| **Mine** | all armies | 3 | 0 | 289 | 2.3 | 1.0 | 124 | 13 | +111 | 1 of 7 | 6 of 7 | - | +111 |
| Opponent | Vampire Counts | 1 | 355 | 1013 | 5.0 | 1.2 | 203 | 24 | +179 | 2 of 5 | 4 of 5 | +540 | +88 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 290 | -290 | 1 of 1 | 1 of 1 | - | -290 |
| Opponent | Wood Elf Realms | 1 | 0 | 516 | 5.0 | 1.2 | 103 | 0 | +103 | 2 of 5 | 5 of 5 | +60 | +114 |
| **Opponent** | all armies | 3 | 118 | 510 | 3.7 | 1.2 | 139 | 37 | +102 | 5 of 11 | 10 of 11 | +300 | +58 |

### Effective charges: ccut-c940641-p35

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net -46) | 0 | 0% (0 of 2) |
| Mine | Tomb Kings of Khemri | 5 | 0 | 0 | 0 | 0 | 1 (net +125) | 2 (net +372) | 2 | 0% (0 of 3) |
| Opponent | Vampire Counts | 5 | 1 (net +0) | 0 | 1 (net +540) | 0 | 1 (net +100) | 0 | 2 | 33% (1 of 3) |
| Opponent | Wood Elf Realms | 5 | 0 | 0 | 0 | 1 (net +0) | 2 (net +63) | 2 (net +195) | 0 | 0% (0 of 5) |

### Charged fights, damage counted: ccut-c940641-p35

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 266 | 158 | +163 | 200 | 31 | +169 | +63.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 431 | 125 | +125 | 125 | 0 | +125 | +29.0 |
| Mine | No odds | 2 | 440 | 125 | +0 | 41 | 0 | +41 | +9.3 |
| Mine | All fights | 7 | 340 | 144 | +111 | 144 | 18 | +126 | +37.1 |
| Opponent | Long shot (under 50%) | 1 | 186 | 210 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Effective (55-75%) | 1 | 516 | 440 | +540 | 540 | 0 | +540 | +104.7 |
| Opponent | 76-89% | 1 | 102 | 70 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 499 | 195 | +195 | 195 | 111 | +84 | +16.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 399 | 90 | +75 | 90 | 15 | +75 | +18.9 |
| Opponent | No odds | 3 | 214 | 195 | -12 | 117 | 122 | -6 | -2.7 |
| Opponent | All fights | 11 | 331 | 179 | +102 | 141 | 58 | +83 | +25.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p35 | move | 25 | 5 (20%) | 4 (16%) | 3 (12%) | 17 (68%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L2127 |
| Invocation of Nehek | Opponent | L2127 |
| Periapt of Soul Exchange | Mine | L2127 |
| Ring of Doom | Opponent | L2231 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |

# Doctrine scorecard: ccut-c940641-p29

### Scorecard: ccut-c940641-p29

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0717 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0717 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0733 | 1 | 1 | Mine | no | 6 | 4 | 1 | 2 | 0 | 0 | 0 | 170 |
| L0733 | 1 | 1 | Opponent | no | 2 | 4 | 1 | 3 | 0 | 0 | 0 | 405 |
| L0823 | 1 | 1 | Mine | no | 18 | 4 | 1 | 1 | 0 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 3 | 0 | 0 | 0 | 195 |
| **Average** | | | Mine | 0% | 12.0 | 4.0 | 1.0 | 1.5 | 0.0 | 0.0 | 0.0 | 342.5 |
| **Average** | | | Opponent | 0% | 1.0 | 3.0 | 1.0 | 3.0 | 0.0 | 0.0 | 0.0 | 300.0 |

### KPIs: ccut-c940641-p29

Rules off - Opponent only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 81% (13 of 16) | 0% (0 of 11) | 48% (13 of 27) |
| Winner chose to follow up after the loser gave ground |  | 100% (3 of 3); on the table 100% | 100% (1 of 1); on the table 100% | 100% (4 of 4); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (4 of 4); on the table 100% | 100% (1 of 1); on the table 100% | 100% (5 of 5); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 50% (6 of 12) | 25% (3 of 12) | 38% (9 of 24) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 55% (6 of 11) | 38% (3 of 8) | 47% (9 of 19) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 54% (2171 of 3999) | 69% (2747 of 4000) | 61% (4918 of 7999) |
|   infantry points that never fought | lower | 34% (190 of 561) | 100% (1045 of 1045) | 77% (1235 of 1606) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 65% (13 of 20) | 73% (11 of 15) | 69% (24 of 35) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Bound items with another spell used |  | 50% (1 of 2); 1.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.7 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 33% (1 of 3); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 56% (1999 of 3589) | 63% (2132 of 3408) | 59% (4131 of 6997) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.3 (44%) | 1.3 (27%) |
| MARCHED: its unit marched | 1.0 (50%) | 0.3 (11%) | 1.3 (27%) |
| CHARGED: its unit charged | 0.7 (33%) | 0.0 (0%) | 0.7 (13%) |
| IN COMBAT: engaged in combat | 0.3 (17%) | 0.0 (0%) | 0.3 (7%) |
| FLEEING: fleeing | 0.0 (0%) | 0.3 (11%) | 0.3 (7%) |
| GONE: slain | 0.0 (0%) | 1.0 (33%) | 1.0 (20%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 1.3 | 3.0 | 0.3 | 0.7 |
| not cast | 4.0 | 0.7 | 5.0 | 1.7 | 10.7 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (50%) | 1.3 (27%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.3 (27%) | 0.3 (20%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.7 (13%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (50%) | 0.3 (7%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.7 (17%) | 0.0 (0%) | 0.3 (7%) | 0.3 (20%) | 0.0 (0%) |
| GONE: slain | 1.0 (25%) | 0.0 (0%) | 1.0 (20%) | 1.0 (60%) | 1.0 (9%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (58%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 9.7 (91%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 54% (38 of 71) | 70% (44 of 63) | 61% (82 of 134) |
|   cavalry | 75% (9 of 12) | 50% (8 of 16) | 61% (17 of 28) |
|   character | - | 69% (9 of 13) | 69% (9 of 13) |
|   chariot | 60% (3 of 5) | - | 60% (3 of 5) |
|   infantry | 42% (5 of 12) | 79% (27 of 34) | 70% (32 of 46) |
|   war machine | 50% (21 of 42) | - | 50% (21 of 42) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (18%) | 0.7 (11%) | 2.7 (15%) |
| CHARGED: it charged | 0.0 (0%) | 2.0 (32%) | 2.0 (12%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.3 (5%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| MOVED: a war machine that moved | 1.3 (12%) | 0.0 (0%) | 1.3 (8%) |
| NO TARGET IN RANGE | 0.7 (6%) | 0.0 (0%) | 0.7 (4%) |
| ONLY IN COMBAT: the only targets were in combat | 0.7 (6%) | 1.3 (21%) | 2.0 (12%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 4.0 (36%) | 2.0 (32%) | 6.0 (35%) |
| SHELTERED: the target was sheltered | 2.0 (18%) | 0.0 (0%) | 2.0 (12%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 8.7 | 2.7 | 77% | 6.4 pts | 55 pts |
| character | 3.0 | 1.0 | 78% | 12.4 pts | 37 pts |
| chariot | 1.0 | 0.7 | 67% | 32.6 pts | 33 pts |
| infantry | 15.0 | 6.3 | 73% | 8.8 pts | 132 pts |
| war machine | 7.0 | 7.7 | 38% | 46.4 pts | 325 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.3 | 3.3 | 2.8 |
| Charges that made contact a game | 1.0 | 1.3 | 1.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.00 contact (2 units) | - | 1.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.19 declared, 0.12 contact (26 units) | 0.36 declared, 0.14 contact (28 units) | 0.28 declared, 0.13 contact (54 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (4 of 6) | 0% (0 of 2) | - | 50% (4 of 8) |
| Character in a unit | 100% (4 of 4) | - | - | 100% (4 of 4) |
| Character on its own | 100% (2 of 2) | 100% (1 of 1) | 25% (1 of 4) | 57% (4 of 7) |
| Chariot | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Infantry | 100% (1 of 1) | 67% (2 of 3) | 0% (0 of 1) | 60% (3 of 5) |
| Monster | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Monstrous | 100% (1 of 1) | - | - | 100% (1 of 1) |
| War Machines | 86% (6 of 7) | - | - | 86% (6 of 7) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 2 | 100% (4 of 4); on the table 100% | 67% (4 of 6) | 54% | 65% (13 of 20) | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Tomb Kings of Khemri | 1 | 100% (1 of 1); on the table 100% | 33% (2 of 6) | 68% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | 17% (1 of 6) | 69% | 80% (8 of 10) | 100% (2 of 2); 3.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p29, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 0% (0) | 0% (0) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: ccut-c940641-p29

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.3 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 29% (2 of 7) | 33% (2 of 6) |
| Strategy | Shoot objectives carried out (shot that target) | 18% (9 of 50) | 87% (13 of 15) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 50% (2 of 4) | - |
| Strategy | Joined characters whose unit fought | 100% (2 of 2) | 0% (0 of 3) |
| Strategy | Lone characters that fought | 43% (3 of 7) | 50% (2 of 4) |
| Movement | Charges halted short of contact | 0.0 | 0.7 |
| Movement | Idle units | 1.5 | 3.0 |
| Movement | Points that never moved of their own | 342.5 | 300.0 |
| Movement | Fights charged into per game | 1.0 | 1.5 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 2, net -273 | 2 of 3, net -12 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 2 | 0 of 3 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 2 | 0 of 3 |
| Shooting | Shots by shooting units (incl. breath weapons) | 6.0 | 17.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 61% (11 of 18) | 54% (28 of 52) |
| Shooting | Points destroyed by shooting units | 71.3 | 15.0 |
| Shooting | War machine shots | 7.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 67% (14 of 21) | - |
| Shooting | Points destroyed by war machines | 168.3 | 0.0 |
| Magic | Magic missiles cast | 1.7 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 20% (1 of 5) | 50% (1 of 2) |
| Magic | Wounds caused by magic missiles | 7.7 | 1.0 |
| Magic | Wounds caused by other spells | 4.3 | - |
| Magic | Points destroyed by magic (all spells) | 147.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 1.3 / 0.7 / 0.0 | 1.3 / 0.0 / 0.0 / 0.3 |
| Combat | Points destroyed in combat | 36.3 | 210.3 |
| Combat | Points run down | 41.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | -294 | -42 |
| Combat | Net per 100 charger points, damage counted | -131.6 | -30.7 |
| Combat | First round won (charged fights) | 0% | 0% |
| Combat | Net points per charged fight | -273 | -43 |
| Combat | Net points per supported fight / lone fight | - / -273 | -109 / -10 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 2 | 3 of 3 |
| Game | Points lost | 440.0 | 700.5 |
| Game | VP from objectives | 1340.0 | 630.0 |
| Game | Lone holders (player turns) | 12.0 | 1.0 |

- Mine won / drew / lost: 1 / 1 / 0 of 2 ended games (of 3); mean margin (Mine - Opponent) +1044 VP
- The side that went first won 0 of 1 games with a winner
- Points traded per game (both sides' losses): 1140
- Games not ended: 1 (L0717-1); findings 1, warnings 0

### Opponent rules: ccut-c940641-p29

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +21.4 | 0.0 | 0.0 | 0.3 | +13.2 | 0.0 | 0.0 |
| ARMY TABLE | 20.3 | +226.5 | 0.0 | 93.7 | 24.7 | +115.6 | 0.0 | 110.3 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +1.0 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 6.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | 0.7 | +6.4 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | 0.3 | -9.1 | 6.3 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 10.3 | +249.6 | 613.7 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 1.0 | +74.0 | 69.3 | 0.0 | 0.3 | +2.5 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.0 | +7.9 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | -2.1 | 0.0 | 0.0 | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -4.8 | 0.0 | 36.3 |
| CHARACTER GUNS | - | - | - | - | 5.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 23.3 | -1422.3 | 0.0 | 269.3 | 18.7 | -1098.2 | 0.0 | 140.3 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 0.0 | 34.7 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 69.3 | 93.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 5.0 | +0.0 | 0.0 | 0.0 | 15.7 | +0.0 | 0.0 | 12.7 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 12.0 | -396.5 | 0.0 | 93.7 | 9.0 | -559.3 | 0.0 | 105.7 |
| DEFENSIVE ARMY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | 0.7 | -17.7 | 0.0 | 0.0 | 0.3 | -0.6 | 0.0 | 36.3 |
| DEPLOY BY FIGURES | 8.7 | -71.5 | 0.0 | 0.0 | 8.7 | +28.7 | 0.0 | 65.0 |
| DUEL STOPS AT THE KILL | 0.7 | -26.0 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 1.0 | +48.8 | 0.0 | 0.0 | 1.7 | +75.0 | 0.0 | 34.7 |
| FALL BACK GOOD ORDER | 2.0 | +0.0 | 0.0 | 93.7 | 1.3 | +2.4 | 0.0 | 71.0 |
| FALLBACK BY WORTH | 0.7 | +2.6 | 0.0 | 15.0 | - | - | - | - |
| FALLS SHORT | - | - | - | - | 20.3 | +211.8 | 0.0 | 183.7 |
| FEATURE BUFFS | - | - | - | - | 0.3 | +2.6 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +10.3 | 0.0 | 0.0 | 0.7 | +17.7 | 0.0 | 0.0 |
| FIRE IN ORDER | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 115.0 | +7599.7 | 1284.0 | 550.3 | 92.3 | +6358.6 | 194.7 | 471.7 |
| FLANK NOT WEIGHED | 7.3 | +0.0 | 0.0 | 93.7 | 6.0 | +0.0 | 0.0 | 114.3 |
| FOLLOW UP WEIGHED | - | - | - | - | 0.3 | +17.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.3 | +262.7 | 0.0 | 93.7 | 2.0 | +296.2 | 0.0 | 71.0 |
| FREED FROM HIS FIGHT | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 6.3 |
| FRIEND SHOOTS FIRST | 2.0 | -75.4 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 8.0 | +607.9 | 0.0 | 0.0 | 15.0 | +1113.8 | 0.0 | 12.7 |
| GUN FIGURES | 1.0 | +93.1 | 0.0 | 0.0 | - | - | - | - |
| GUN MASK | 3.7 | +30.0 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 14.3 | +0.0 | 0.0 | 0.0 | 10.0 | +0.0 | 0.0 | 105.7 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +6.8 | 0.0 | 0.0 |
| HIS CHARGE LIST | 5.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 6.3 |
| HIS LEGAL MOVES | 8.3 | +0.0 | 0.0 | 187.3 | 5.7 | +0.0 | 0.0 | 140.3 |
| HIS MOVE AND SHOT | 4.7 | -66.0 | 0.0 | 134.7 | 2.3 | -37.8 | 0.0 | 0.0 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 40.0 | +9.3 | 352.0 | 0.0 |
| HIS MOVE WHY | 28.3 | +0.0 | 0.0 | 164.7 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 27.3 | +72.9 | 0.0 | 75.7 |
| HIS ONE QUARTER | 5.0 | +0.0 | 0.0 | 134.7 | 9.3 | +0.0 | 0.0 | 88.3 |
| HIS OWN BEST MOVE | 9.0 | +0.0 | 0.0 | 187.3 | 2.0 | +0.0 | 0.0 | 105.7 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 52.3 | +1693.4 | 0.0 | 456.7 | 62.3 | +4491.8 | 0.0 | 400.7 |
| HIS SHOTS BY HIS RUN | 42.0 | +802.1 | 0.0 | 456.7 | 43.3 | +1927.5 | 0.0 | 331.3 |
| HIS TURN DENIED | 1.3 | +67.9 | 0.0 | 0.0 | 0.7 | +22.5 | 0.0 | 36.3 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 25.0 | +0.0 | 0.0 | 269.3 | 16.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 16.3 | +1488.2 | 0.0 | 134.7 | 12.7 | +1121.8 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.7 | -72.1 | 0.0 | 0.0 | 1.3 | -56.1 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.3 | +2.7 | 0.0 | 168.3 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +41.9 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 15.7 | -253.9 | 0.0 | 12.7 |
| JOINT CHARGE NOW | 0.3 | +4.0 | 0.0 | 0.0 | 0.3 | -4.7 | 0.0 | 36.3 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.3 | -9.0 | 0.0 | 36.3 |
| KEEP FALLS | 0.3 | +12.7 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 4.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +17.2 | 0.0 | 0.0 | 1.3 | +85.6 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.7 | +0.0 | 42.7 | 176.7 | 15.7 | +0.0 | 446.3 | 63.3 |
| LONE WIZARD KEPT IN | 0.3 | +19.8 | 0.0 | 0.0 | 0.3 | +37.5 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.3 | +1.6 | 0.0 | 0.0 | 1.0 | +1.1 | 0.0 | 71.0 |
| MAKE SURE TOGETHER | 0.7 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 1.3 | -0.3 | 0.0 | 0.0 | 0.3 | +2.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +4.3 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +12.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | - | - | - | - | 0.7 | +20.8 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.7 | +68.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | +31.4 | 0.0 | 0.0 | 0.3 | +13.9 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 1.7 | +43.8 | 0.0 | 0.0 | 0.7 | +4.8 | 0.0 | 36.3 |
| MEETS IN TIME | 4.3 | +404.6 | 0.0 | 0.0 | 4.0 | +319.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.0 | +137.8 | 0.0 | 0.0 | 2.3 | +15.8 | 0.0 | 147.3 |
| MISSILES NEXT TURN | 2.7 | +82.5 | 0.0 | 0.0 | 3.0 | +29.5 | 0.0 | 147.3 |
| MOVE ORDER | 2.7 | +0.0 | 0.0 | 15.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 4.0 | +534.2 | 0.0 | 0.0 | 4.0 | +310.6 | 0.0 | 34.7 |
| NEARER NOT NEEDED | 8.0 | +359.0 | 0.0 | 0.0 | 9.7 | +470.7 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 0.7 | +42.8 | 0.0 | 0.0 | 2.0 | +116.5 | 0.0 | 34.7 |
| NEXT OBJECTIVE NEARER | 0.3 | -10.0 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 1.7 | -31.2 | 0.0 | 93.7 | 2.0 | -245.8 | 0.0 | 71.0 |
| NO LATE CUT | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT WORTH A CAST | 2.3 | -1.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 6.3 | -109.7 | 0.0 | 0.0 | 7.3 | -183.2 | 0.0 | 34.7 |
| ONE CHALLENGE TEST | - | - | - | - | 0.3 | -4.8 | 0.0 | 36.3 |
| ONE FIGHT FORMULA | 4.7 | -95.4 | 0.0 | 161.0 | 3.7 | -69.1 | 0.0 | 34.7 |
| ONE OBJECTIVE FORMULA | 5.0 | -37.3 | 0.0 | 67.3 | 4.7 | -115.6 | 0.0 | 0.0 |
| ONE ROUTE | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OPENS A LANE | 0.3 | +0.3 | 78.0 | 0.0 | - | - | - | - |
| OPENS UP | 0.3 | +6.5 | 0.0 | 0.0 | 0.3 | +18.6 | 0.0 | 0.0 |
| OVERRUNS AWAY | 1.0 | +44.8 | 0.0 | 0.0 | 0.3 | +1.1 | 0.0 | 34.7 |
| PATHS CROSS | 0.3 | -4.9 | 0.0 | 0.0 | 0.3 | -5.1 | 0.0 | 0.0 |
| PLAN RESULT | 52.3 | +1934.8 | 289.7 | 440.3 | 42.0 | +163.1 | 97.3 | 342.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 6.0 | -63.3 | 0.0 | 0.0 | 4.7 | -44.5 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 1.3 | -64.2 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 31.7 | +2445.1 | 673.3 | 269.3 | 23.0 | +2903.9 | 164.7 | 165.7 |
| REAL GROUND | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 1.3 | +45.1 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 0.7 | +17.2 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 2.7 | +0.0 | 0.0 | 19.0 |
| REDIRECT WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.3 | -2.1 | 0.0 | 0.0 | 0.7 | -21.8 | 0.0 | 34.7 |
| RISK BY ARC | 2.0 | -75.9 | 0.0 | 93.7 | 1.3 | -96.8 | 0.0 | 71.0 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | 0.7 | -8.0 | 0.0 | 0.0 | 0.3 | -4.1 | 0.0 | 0.0 |
| RUN DOWN | 1.3 | -7.4 | 0.0 | 0.0 | 1.0 | -13.0 | 0.0 | 71.0 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +1.8 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.3 | -15.6 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +9.1 | 0.0 | 0.0 | 1.0 | +19.0 | 0.0 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 0.7 | -183.0 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.0 | -3.9 | 0.0 | 0.0 | 1.7 | -11.3 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.7 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +3.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 17.7 | +0.0 | 0.0 | 15.0 | 6.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.0 | +58.1 | 69.3 | 0.0 | 1.0 | +17.8 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 1.3 | -375.9 | 0.0 | 0.0 | 0.3 | -29.7 | 0.0 | 0.0 |
| SHOT RISK POINTS | 29.7 | -490.9 | 0.0 | 456.7 | 43.0 | +548.9 | 0.0 | 394.3 |
| SHOTS AFTER THE MOVES | 4.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 24.7 | +800.1 | 0.0 | 67.3 | 19.0 | +326.6 | 0.0 | 69.3 |
| SPELL WORTH | 1.7 | +11.3 | 56.7 | 56.7 | 2.3 | +23.6 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 4.0 | +0.0 | 0.0 | 67.3 | 5.7 | +0.0 | 0.0 | 69.3 |
| STAND AND SHOOT | 0.3 | -1.3 | 0.0 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | - | - | - | - | 5.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 65.3 | +0.0 | 1284.0 | 187.3 | 26.3 | +0.0 | 194.7 | 0.0 |
| STAY WORTH | 47.3 | +310.0 | 1145.3 | 67.3 | 15.7 | +109.2 | 30.0 | 69.3 |
| STRIKE BY THE ODDS | - | - | - | - | 0.7 | +41.4 | 28.3 | 0.0 |
| SUPPORT ADDS | 2.0 | +111.3 | 0.0 | 0.0 | 1.3 | +100.1 | 0.0 | 36.3 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 93.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 2.0 | +111.3 | 0.0 | 0.0 | 1.3 | +100.1 | 0.0 | 36.3 |
| SURE REACH TOGETHER | 0.7 | +1.6 | 0.0 | 0.0 | - | - | - | - |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.7 | +13.7 | 0.0 | 36.0 |
| THE DEARER SUM KEEPS ITS PLAN | 3.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 69.3 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 2.0 | +0.0 | 0.0 | 6.3 |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 69.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 50.7 | +0.0 | 0.0 | 258.3 | 44.0 | +0.0 | 0.0 | 165.7 |
| TIED UP BY THE SUM | 0.7 | +52.6 | 0.0 | 0.0 | 0.3 | +34.2 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 45.0 | +503.8 | 0.0 | 296.0 | - | - | - | - |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | 0.3 | -7.6 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.3 | +9.5 | 0.0 | 0.0 | 0.3 | +13.3 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 4.7 | -784.3 | 0.0 | 0.0 | 1.3 | -41.8 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +4.7 | 0.0 | 36.3 |
| WOUNDS ON THE RANKS | 8.3 | +133.2 | 0.0 | 269.3 | 1.3 | +31.5 | 0.0 | 0.0 |

### Rule changes: ccut-c940641-p29

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 344 | 333 | 97 | 32.33 | +3396 | +35.0 |
| HIS MOVE AS HE DECIDES | 120 | 120 | 92 | 30.67 | +0 | +0.0 |
| ARMY TABLE | 135 | 135 | 79 | 26.33 | +298 | +3.8 |
| HOLDER ASSIGNMENT | 87 | 87 | 76 | 25.33 | +4066 | +53.5 |
| LEGAL CHARGES ONLY | 64 | 64 | 64 | 21.33 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 256 | 245 | 55 | 18.33 | +988 | +18.0 |
| HIS MOVE WHY | 85 | 85 | 44 | 14.67 | +0 | +0.0 |
| OFF BEST | 41 | 41 | 41 | 13.67 | -879 | -21.4 |
| SHOT RISK POINTS | 218 | 208 | 39 | 13.00 | +2154 | +55.2 |
| DEPLOY BY FIGURES | 52 | 52 | 33 | 11.00 | +478 | +14.5 |
| THE TABLE AGAIN | 36 | 36 | 29 | 9.67 | +0 | +0.0 |
| HIS ONE MOVE | 82 | 80 | 23 | 7.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 135 | 113 | 21 | 7.00 | +85 | +4.0 |
| ARTILLERY RE-ROLL WEIGHED | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| FIVE ACTION | 622 | 606 | 19 | 6.33 | +1804 | +94.9 |
| QUARTER ODDS | 164 | 158 | 18 | 6.00 | +1263 | +70.2 |
| MOVE TO CHARGE COMPUTED | 24 | 22 | 15 | 5.00 | +896 | +59.8 |
| CHARGE LOSSES | 126 | 120 | 13 | 4.33 | +675 | +51.9 |
| GOAL WALK | 69 | 69 | 13 | 4.33 | +500 | +38.5 |
| THE RISK READS HIS RUN | 18 | 18 | 13 | 4.33 | +0 | +0.0 |
| HARD STAY DROPPED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| MEETS IN TIME | 25 | 25 | 9 | 3.00 | +266 | +29.5 |
| COVER ONCE | 63 | 43 | 8 | 2.67 | +263 | +32.8 |
| PROMISE BY ITS OWN SUM | 32 | 32 | 8 | 2.67 | -323 | -40.4 |
| REDIRECT FOR A FRIEND IN REACH | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| FOUR ROUNDS | 13 | 13 | 6 | 2.00 | +456 | +76.0 |
| SHOOTS FROM THE BEST SPOT | 9 | 9 | 6 | 2.00 | +34 | +5.6 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +308 | +61.7 |
| STAY WORTH | 189 | 169 | 5 | 1.67 | +37 | +7.4 |
| SUPPORT ADDS | 10 | 10 | 5 | 1.67 | +32 | +6.5 |
| SUPPORT WORKED OUT | 10 | 10 | 5 | 1.67 | +32 | +6.5 |
| FIRE IN ORDER | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| IDLE COST | 47 | 29 | 4 | 1.33 | +54 | +13.6 |
| NEARER NOT NEEDED | 53 | 52 | 4 | 1.33 | +164 | +41.0 |
| NEXT CHARGE BY LIST | 8 | 6 | 4 | 1.33 | +92 | +23.1 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 24 | 24 | 4 | 1.33 | +0 | +0.0 |
| EXACT ROUND | 8 | 8 | 3 | 1.00 | +212 | +70.8 |
| MISSILES IN THE MOVE | 13 | 12 | 3 | 1.00 | +155 | +51.7 |
| SEARCH SPOT | 4 | 4 | 3 | 1.00 | +84 | +28.1 |
| SHOTS IN THE MOVE | 131 | 96 | 3 | 1.00 | +87 | +28.8 |
| THE ROW IN ITS ORDER | 15 | 3 | 3 | 1.00 | +0 | +0.0 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +104 | +51.9 |
| CAST JOB | 4 | 4 | 2 | 0.67 | +1 | +0.4 |
| FALLS SHORT | 61 | 58 | 2 | 0.67 | +8 | +4.1 |
| FIGHT TO THE END | 3 | 3 | 2 | 0.67 | +43 | +21.6 |
| GUN MASK | 11 | 11 | 2 | 0.67 | +34 | +17.1 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | -2 | -1.1 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +172 | +86.0 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -205 | -102.3 |
| MAX FOR POSITIONING | 7 | 6 | 2 | 0.67 | +3 | +1.3 |
| ONE OBJECTIVE FORMULA | 29 | 22 | 2 | 0.67 | +21 | +10.7 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | -30 | -14.9 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +22 | +11.1 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +9 | +4.5 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +124 | +62.1 |
| SUPPORT NARROWED | 2 | 2 | 2 | 0.67 | -342 | -171.0 |
| SWIFTSTRIDE BY POINTS | 2 | 2 | 2 | 0.67 | +41 | +20.6 |
| TIED UP BY THE SUM | 3 | 3 | 2 | 0.67 | +102 | +50.9 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -27 | -27.4 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -6 | -6.3 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -194 | -194.3 |
| CHARGE NOW FIRST | 7 | 7 | 1 | 0.33 | -154 | -154.5 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALLBACK BY WORTH | 2 | 2 | 1 | 0.33 | +8 | +7.8 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +51 | +50.9 |
| HIS TURN DENIED | 6 | 6 | 1 | 0.33 | +45 | +45.0 |
| HOLDS AMBUSHERS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HORN WORTH | 1 | 1 | 1 | 0.33 | +8 | +8.2 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +65 | +65.0 |
| MANOEUVRE | 5 | 5 | 1 | 0.33 | +6 | +6.0 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +37 | +37.0 |
| MARCH CHECK | 2 | 2 | 1 | 0.33 | +28 | +27.5 |
| OVERRUNS AWAY | 4 | 4 | 1 | 0.33 | +32 | +31.9 |
| REDIRECT COUNTER | 2 | 1 | 1 | 0.33 | +17 | +17.0 |
| RISK BY ARC | 10 | 10 | 1 | 0.33 | +46 | +45.6 |
| SET UP BY THE SET | 8 | 8 | 1 | 0.33 | +53 | +53.4 |
| SHORT GUN FORWARD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SURE REACH TOGETHER | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -23 | -22.8 |
| WHOLE FIGHT DANGER | 18 | 17 | 1 | 0.33 | +27 | +26.9 |
| WOUNDS ON THE RANKS | 29 | 29 | 1 | 0.33 | +24 | +23.8 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 3 | 3 | 0 | 0.00 | - | - |
| CANNON PLANNED TARGET | 31 | 31 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 16 | 12 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 62 | 60 | 0 | 0.00 | - | - |
| DEFENSIVE ARMY | 1 | 1 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 10 | 10 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 40 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 6 | 6 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 6 | 6 | 0 | 0.00 | - | - |
| GUN FIGURES | 3 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 73 | 68 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 26 | 23 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 42 | 38 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 21 | 21 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 43 | 37 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 33 | 31 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 35 | 35 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 124 | 124 | 0 | 0.00 | - | - |
| HONEST WORTH | 9 | 9 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 1 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 21 | 21 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 7 | 7 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 5 | 5 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 17 | 15 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 11 | 11 | 0 | 0.00 | - | - |
| NO LATE CUT | 8 | 8 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 7 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE FIGHT FORMULA | 25 | 15 | 0 | 0.00 | - | - |
| ONE ROUTE | 5 | 5 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | not checked | - | - | - | - |
| OPENS UP | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 283 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 4 | 4 | 0 | 0.00 | - | - |
| REAL GROUND | 5 | 5 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 3 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 7 | 7 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 1 | 1 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 72 | not checked | - | - | - | - |
| SHOT OR CHARGE | 5 | 5 | 0 | 0.00 | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 29 | 26 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 15 | 14 | 0 | 0.00 | - | - |
| STANDS STILL | 275 | 267 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 15 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 11 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 6 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 8 | not checked | - | - | - | - |
| THE TABLE BINDS | 284 | not checked | - | - | - | - |
| WAITS AGAIN | 7 | 7 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p29

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.67 | 5.67 | 20.9 |
| ARMY TABLE | rule | 2.67 | 2.67 | 89.8 |
| PROMISE BY ITS OWN SUM | rule | 1.67 | 1.00 | 40.4 |
| HOLDER ASSIGNMENT | rule | 0.67 | 1.00 | 20.4 |
| RULE SWITCHED OFF | gate | - | 1.33 | 27.6 |
| MARCH OF THE TABLE | rule | 0.67 | - | 102.3 |
| PATHS CROSS | rule | 0.33 | 0.33 | 14.9 |
| SUPPORT NARROWED | rule | 0.33 | 0.33 | 171.0 |
| AFTERMATH BAND | gate | 0.33 | - | 2.6 |
| BEST PRIZE | rule | 0.33 | - | 27.4 |
| CHAFF PASSED | rule | 0.33 | - | 6.3 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 194.3 |
| CHARGE NOW FIRST | rule | 0.33 | - | 154.5 |
| FALLBACK | gate | - | 0.33 | 1.0 |
| JOINT CHARGE NOW | rule | - | 0.33 | 14.2 |
| NO REASON | gate | 0.33 | - | 55.8 |
| WALKS ON ITS ROUTE | rule | 0.33 | - | 22.8 |

### Plans: ccut-c940641-p29

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.7 | 60% | 242 | 16 | 7% |
| Mine | join | 2.7 | 88% | 38 | 0 | 0% |
| Mine | move | 33.3 | 99% | 2098 | 0 | 0% |
| Mine | shoot | 14.7 | 68% | 969 | 1919 | 198% |
| Opponent | charge | 1.3 | 25% | 172 | 36 | 21% |
| Opponent | move | 35.7 | 94% | 1789 | 0 | 0% |
| Opponent | shoot | 4.3 | 77% | 499 | 127 | 25% |
| Opponent | support | 0.7 | 100% | 34 | 0 | 0% |

### Battle groups: ccut-c940641-p29

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 0.7 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p29

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | Character | 8 | 52 (8) | 52 | 0 | 39 | 50% | 4.2 | 111 (4) | - | 0 (3) | 62 (5) | 0 (2) |
| Mine | Clean-up | 1 | 136 (1) | 0 | 136 | 0 | 100% | - | - | 136 (1) | - | 136 (1) | - |
| Mine | Fast Hammer | 4 | 92 (4) | 37 | 55 | 25 | 50% | 3.5 | 85 (3) | - | 107 (1) | 92 (4) | - |
| Mine | Hammer | 2 | 57 (2) | 0 | 57 | 42 | 0% | 3.5 | - | 0 (1) | 97 (1) | 57 (2) | - |
| Mine | Shooter | 3 | 138 (3) | 6 | 132 | 0 | 0% | 2.7 | - | 220 (1) | 51 (2) | 220 (1) | 51 (2) |
| Mine | War machine | 7 | 57 (7) | 57 | 0 | 0 | 0% | 1.4 | 57 (7) | - | - | 0 (1) | 67 (6) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | - | - | - | - | - |
| Opponent | Chaff | 4 | 0 (4) | 0 | 0 | 22 | 50% | 1.0 | 0 (3) | 0 (1) | - | 0 (4) | - |
| Opponent | Character | 6 | 34 (6) | 34 | 0 | 42 | 0% | 1.3 | - | 0 (2) | 60 (3) | 42 (4) | 0 (1) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 44 | 67% | 5.0 | 0 (2) | 0 (1) | - | 0 (1) | 0 (2) |
| Opponent | Fast Hammer | 4 | 14 (4) | 14 | 0 | 68 | 50% | 6.0 | 44 (1) | 0 (1) | 0 (2) | 17 (3) | 0 (1) |
| Opponent | Hammer | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Holder | 3 | 188 (3) | 0 | 188 | 0 | 0% | 2.0 | 0 (1) | 273 (2) | - | 300 (2) | 0 (1) |
| Opponent | Shooter | 3 | 48 (3) | 0 | 48 | 33 | 0% | 1.0 | - | 71 (2) | 0 (1) | 68 (2) | 0 (1) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | - | 0 (1) | - | 0 (1) |

### Charged fights: ccut-c940641-p29

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 580 | 0 | 1.0 | 1.0 | 0 | 273 | -273 | 1 of 2 | 0 of 2 | - | -273 |
| Opponent | Tomb Kings of Khemri | 1 | 45 | 85 | 1.0 | 1.0 | 85 | 0 | +85 | 1 of 1 | 0 of 1 | - | +85 |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 2.0 | 1.5 | 0 | 106 | -106 | 2 of 2 | 0 of 2 | -109 | -104 |
| **Opponent** | all armies | 2 | 22 | 42 | 1.5 | 1.3 | 28 | 71 | -43 | 3 of 3 | 0 of 3 | -109 | -10 |

### Effective charges: ccut-c940641-p29

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 2 (net -273) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 1 | 1 (net +85) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Wood Elf Realms | 2 | 1 (net -109) | 0 | 0 | 1 (net -104) | 0 | 0 | 0 | 0% (0 of 2) |

### Charged fights, damage counted: ccut-c940641-p29

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 223 | 220 | -273 | 0 | 294 | -294 | -131.6 |
| Mine | All fights | 2 | 223 | 220 | -273 | 0 | 294 | -294 | -131.6 |
| Opponent | Long shot (under 50%) | 2 | 152 | 376 | -12 | 195 | 235 | -40 | -26.6 |
| Opponent | 76-89% | 1 | 104 | 238 | -104 | 60 | 104 | -44 | -42.8 |
| Opponent | All fights | 3 | 136 | 330 | -43 | 150 | 191 | -42 | -30.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p29 | move | 18 | 2 (11%) | 1 (6%) | 2 (11%) | 14 (78%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Horn of the Wild Hunt | Opponent | L0733 |
| Ring of Doom | Opponent | L0733 |
| Twice-Blessed Armour | Mine | L0717, L0733 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |

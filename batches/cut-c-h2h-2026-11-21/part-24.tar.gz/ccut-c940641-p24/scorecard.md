# Doctrine scorecard: ccut-c940641-p24

### Scorecard: ccut-c940641-p24

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2535 | 3 | 1 | Mine | no | 0 | 4 | 3 | 0 | 0 | 0 | 0 | 168 |
| L2535 | 3 | 1 | Opponent | no | 3 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | yes | - | 2 | 2 | 7 | 1 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 4 | 2 | 3 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | no | 14 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 1 | 2 | 4 | 1 | 0 | 0 | 0 | 405 |
| **Average** | | | Mine | 33% | 7.0 | 2.7 | 3.3 | 3.0 | 0.3 | 0.0 | 0.0 | 56.0 |
| **Average** | | | Opponent | 33% | 2.0 | 2.7 | 3.3 | 2.3 | 0.0 | 0.0 | 0.0 | 135.0 |

### KPIs: ccut-c940641-p24

Rules off - Mine only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 15) | 23% (3 of 13) | 11% (3 of 28) |
| Winner chose to follow up after the loser gave ground |  | 80% (4 of 5); on the table 80% | 80% (4 of 5); on the table 80% | 80% (8 of 10); on the table 80% |
| Winner chose to pursue after the loser fell back in good order |  | 25% (1 of 4); on the table 50% | - | 25% (1 of 4); on the table 50% |
| Winner chose to pursue after the loser fled |  | 33% (1 of 3); on the table 33% | 100% (1 of 1); on the table 100% | 50% (2 of 4); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 50% (6 of 12); on the table 58% | 83% (5 of 6); on the table 83% | 61% (11 of 18); on the table 67% |
| Magic missiles tried each own turn | 50%+ | 50% (12 of 24) | 56% (10 of 18) | 52% (22 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 60% (12 of 20) | 59% (10 of 17) | 59% (22 of 37) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 36% (2154 of 5999) | 28% (1668 of 6000) | 32% (3822 of 11999) |
|   infantry points that never fought | lower | 34% (264 of 780) | 46% (875 of 1918) | 42% (1139 of 2698) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 67% (12 of 18) | 71% (24 of 34) | 69% (36 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 50% (2 of 4); 2.3 uses a game | 50% (2 of 4); 1.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 57% (2746 of 4808) | 62% (3708 of 5962) | 60% (6454 of 10770) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (33%) | 1.7 (62%) | 3.0 (45%) |
| MARCHED: its unit marched | 1.0 (25%) | 0.7 (25%) | 1.7 (25%) |
| IN COMBAT: engaged in combat | 0.7 (17%) | 0.0 (0%) | 0.7 (10%) |
| GONE: slain | 0.7 (17%) | 0.0 (0%) | 0.7 (10%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.3 (12%) | 0.3 (5%) |
| STUPIDITY: Stupidity | 0.3 (8%) | 0.0 (0%) | 0.3 (5%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.7 | 2.3 | 3.7 | 7.3 | 1.3 | 3.7 |
| not cast | 4.3 | 1.0 | 2.3 | 6.7 | 4.7 | 20.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (67%) | 0.0 (0%) | 3.0 (45%) | 2.7 (57%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (25%) | 0.7 (14%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.3 (14%) | 0.7 (10%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.7 (29%) | 0.7 (10%) | 0.0 (0%) | 3.3 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (8%) | 0.3 (33%) | 0.0 (0%) | 0.3 (5%) | 0.0 (0%) | 0.3 (2%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (5%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (29%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.0 (92%) | 0.0 (0%) | 1.3 (57%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.0 (74%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 2.7 a game | 1.8 a game |
| stood (cast and not dispelled) | 33% (1 of 3) | 75% (6 of 8) | 64% (7 of 11) |
| the unit moved after it | 100% (1 of 1) | 50% (3 of 6) | 57% (4 of 7) |
| it charged on its next turn | 0% (0 of 1) | 17% (1 of 6) | 14% (1 of 7) |
| the enemy charged it first | 0% (0 of 1) | 17% (1 of 6) | 14% (1 of 7) |
| it fought by the end of its next turn | 0% (0 of 1) | 17% (1 of 6) | 14% (1 of 7) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 1) | 0% (0 of 6) | 0% (0 of 7) |
| none of these (no charge, no fight, no charge escaped) | 100% (1 of 1) | 67% (4 of 6) | 71% (5 of 7) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 0% (0 of 4) | 76% (66 of 87) | 73% (66 of 91) |
|   cavalry | - | 78% (31 of 40) | 78% (31 of 40) |
|   character | 0% (0 of 4) | 58% (11 of 19) | 48% (11 of 23) |
|   infantry | - | 86% (24 of 28) | 86% (24 of 28) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.0 (0%) | 2.0 (29%) | 2.0 (24%) |
| CHARGED: it charged | 1.0 (75%) | 3.0 (43%) | 4.0 (48%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.7 (10%) | 0.7 (8%) |
| NO TARGET IN RANGE | 0.3 (25%) | 0.0 (0%) | 0.3 (4%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.7 (10%) | 0.7 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 0.7 (10%) | 0.7 (8%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 14.7 | 1.0 | 93% | 0.4 pts | 6 pts |
| character | 4.0 | 1.0 | 75% | 4.9 pts | 20 pts |
| infantry | 10.7 | 5.7 | 72% | 7.0 pts | 74 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.0 | 5.3 | 5.2 |
| Charges that made contact a game | 4.0 | 3.7 | 3.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.25 declared, 0.25 contact (4 units) | - | 0.25 declared, 0.25 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.67 declared, 0.67 contact (3 units) | - | 0.67 declared, 0.67 contact (3 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.57 declared, 0.43 contact (21 units) | 0.52 declared, 0.35 contact (31 units) | 0.54 declared, 0.38 contact (52 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 64% (7 of 11) | 100% (2 of 2) | 100% (1 of 1) | 71% (10 of 14) |
| Character in a unit | 100% (4 of 4) | 0% (0 of 2) | - | 67% (4 of 6) |
| Character on its own | 100% (1 of 1) | 75% (3 of 4) | 17% (1 of 6) | 45% (5 of 11) |
| Infantry | 75% (9 of 12) | 100% (3 of 3) | - | 80% (12 of 15) |
| Monster | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Monstrous | 80% (4 of 5) | - | - | 80% (4 of 5) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vampire Counts | 2 | 0% (0 of 3); on the table 33% | 50% (12 of 24) | 35% | 75% (9 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 67% (6 of 9); on the table 67% | - | 37% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Wood Elf Realms | 3 | 83% (5 of 6); on the table 83% | 56% (10 of 18) | 28% | 71% (24 of 34) | 50% (2 of 4); 2.3 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p24, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 62% (5) | 50% (1) | 60% (6) |
| ...free all their last turn and able to turn (per game) | 1.00 | 0.33 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.33 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: ccut-c940641-p24

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 0.7 |
| Strategy | Charge objectives carried out (made contact) | 70% (7 of 10) | 70% (7 of 10) |
| Strategy | Shoot objectives carried out (shot that target) | 0% (0 of 2) | 33% (4 of 12) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 0% (0 of 3) |
| Strategy | Joined characters whose unit fought | 67% (2 of 3) | 67% (2 of 3) |
| Strategy | Lone characters that fought | 45% (5 of 11) | 100% (5 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 3.0 | 2.3 |
| Movement | Points that never moved of their own | 56.0 | 135.0 |
| Movement | Fights charged into per game | 3.7 | 3.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 7 | 2 of 7, net +566 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 7 | 1 of 7, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 3 of 7, net +90 | 1 of 7, net +143 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 7, net +113 | 3 of 7, net +38 |
| Shooting | Shots by shooting units (incl. breath weapons) | 0.7 | 23.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 2) | 48% (33 of 69) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 4.0 | 2.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 8% (1 of 12) | 0% (0 of 8) |
| Magic | Wounds caused by magic missiles | 0.3 | 10.0 |
| Magic | Wounds caused by other spells | 1.3 | 1.0 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 126.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 1.0 / 1.3 / 0.3 | 1.3 / 1.0 / 0.3 / 0.7 |
| Combat | Points destroyed in combat | 408.3 | 669.3 |
| Combat | Points run down | 36.3 | 0.0 |
| Combat | Net points per charged fight, damage counted | +132 | +146 |
| Combat | Net per 100 charger points, damage counted | +39.3 | +55.3 |
| Combat | First round won (charged fights) | 91% | 60% |
| Combat | Net points per charged fight | +125 | +183 |
| Combat | Net points per supported fight / lone fight | +140 / +123 | +143 / +188 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 11 | 5 of 10 |
| Game | Points lost | 712.3 | 634.0 |
| Game | VP from objectives | 593.3 | 726.7 |
| Game | Lone holders (player turns) | 7.0 | 2.0 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -262 VP
- The side that went first won 0 of 3 games with a winner
- Points traded per game (both sides' losses): 1346
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ccut-c940641-p24

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +2.6 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 23.0 | +743.2 | 0.0 | 307.3 | 31.3 | +569.6 | 0.0 | 435.0 |
| ASSAILMENT BY POINTS | 1.3 | +5.1 | 0.0 | 451.0 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +0.2 | 0.0 | 0.0 | 0.7 | +1.4 | 0.0 | 0.0 |
| CAST JOB | 0.7 | +2.5 | 83.3 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | - | - | - | - | 0.3 | +5.5 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 6.3 | +200.3 | 0.0 | 165.7 | 0.3 | +17.6 | 0.0 | 6.3 |
| CHAFF PASSED | - | - | - | - | 1.3 | -0.2 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.7 | +24.6 | 0.0 | 84.7 | 0.7 | +37.2 | 0.0 | 41.7 |
| CHARACTER GUNS | - | - | - | - | 5.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 16.7 | -514.0 | 0.0 | 198.0 | 13.0 | -296.1 | 0.0 | 193.3 |
| CHARGE NOW FIRST | 3.3 | +0.0 | 382.3 | 0.0 | 2.0 | +0.0 | 255.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 15.0 | +0.0 | 0.0 | 180.0 | 7.3 | +0.0 | 0.0 | 38.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 25.0 | - | - | - | - |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.3 | +0.0 | 25.0 | 0.0 |
| CONVEYANCE SEARCH | 0.7 | +26.3 | 70.3 | 70.3 | 2.3 | +74.3 | 0.0 | 0.0 |
| COVER ONCE | 4.7 | -266.2 | 0.0 | 182.0 | 9.0 | -279.0 | 0.0 | 38.0 |
| DEFENSIVE ARMY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -0.3 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 7.0 | +35.9 | 0.0 | 15.0 | 10.0 | -110.5 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -4.7 | 78.7 | 0.0 | 0.3 | -135.9 | 132.7 | 0.0 |
| EDGE GIVE GROUND | 0.7 | +14.2 | 78.7 | 84.7 | - | - | - | - |
| EXACT ROUND | 3.0 | +26.1 | 269.0 | 16.7 | 2.0 | -25.5 | 147.7 | 0.0 |
| FALL BACK GOOD ORDER | 3.7 | +17.6 | 466.7 | 16.7 | 1.7 | +0.0 | 122.3 | 0.0 |
| FALLBACK BY WORTH | 0.7 | +1.5 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | 21.0 | +250.0 | 0.0 | 327.0 | - | - | - | - |
| FEATURE BUFFS | - | - | - | - | 1.0 | +6.8 | 0.0 | 76.0 |
| FIGHT TO THE END | 1.0 | +4.9 | 46.7 | 101.3 | 1.3 | +111.2 | 265.3 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 81.7 | +5095.1 | 556.3 | 916.0 | 93.3 | +7758.0 | 526.0 | 804.0 |
| FLANK NOT WEIGHED | 8.0 | +0.0 | 0.0 | 227.3 | 5.3 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 1.0 | +157.4 | 0.0 | 0.0 | 0.7 | +94.1 | 0.0 | 78.7 |
| FOUR ROUNDS | 4.3 | +359.0 | 473.0 | 101.3 | 4.0 | +440.5 | 455.7 | 0.0 |
| FREED FROM HIS FIGHT | 3.7 | +0.0 | 0.0 | 298.7 | 8.3 | +0.0 | 0.0 | 34.7 |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.3 | +3.0 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 1.0 | -16.0 | 132.7 | 0.0 |
| GOAL WALK | 7.0 | +466.7 | 0.0 | 0.0 | 20.0 | +1830.2 | 0.0 | 0.0 |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 1.3 | +0.0 | 0.0 | 298.7 | 5.7 | +0.0 | 0.0 | 34.7 |
| HIS CHARGE BY HIS RUN | 10.7 | +0.0 | 0.0 | 198.0 | 12.0 | +0.0 | 0.0 | 193.3 |
| HIS CHARGE DENIED | - | - | - | - | 1.3 | +71.3 | 84.7 | 0.0 |
| HIS CHARGE LIST | 7.7 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 5.3 | +0.0 | 0.0 | 194.7 | 7.0 | +0.0 | 0.0 | 76.0 |
| HIS MOVE AND SHOT | 4.0 | -30.2 | 0.0 | 0.0 | 2.0 | -7.1 | 0.0 | 0.0 |
| HIS MOVE AS HE DECIDES | 46.3 | +13.7 | 706.3 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 11.7 | +0.0 | 0.0 | 154.3 |
| HIS ONE MOVE | 24.7 | +102.2 | 0.0 | 124.0 | - | - | - | - |
| HIS ONE QUARTER | 6.0 | +0.0 | 0.0 | 22.7 | 6.3 | +0.0 | 0.0 | 88.7 |
| HIS OWN BEST MOVE | 1.7 | +0.0 | 0.0 | 132.7 | 12.0 | +0.0 | 0.0 | 148.7 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 63.0 | +1484.2 | 0.0 | 769.3 | 29.3 | +296.0 | 0.0 | 336.0 |
| HIS SHOTS BY HIS RUN | 54.0 | +967.5 | 0.0 | 528.7 | 14.0 | +159.8 | 0.0 | 488.7 |
| HIS TURN DENIED | 1.0 | +10.7 | 52.7 | 16.7 | 0.7 | +1.6 | 265.3 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 16.7 | +0.0 | 0.0 | 310.7 | 12.0 | +0.0 | 0.0 | 365.3 |
| HOLDER ASSIGNMENT | 10.3 | +577.7 | 0.0 | 155.3 | 8.7 | +566.7 | 0.0 | 162.7 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HONEST WORTH | 4.3 | -141.1 | 473.0 | 101.3 | 3.3 | -204.6 | 323.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.3 | +8.8 | 0.0 | 168.3 |
| IDLE COST | 18.0 | -202.3 | 0.0 | 153.0 | - | - | - | - |
| JOINT CHARGE NOW | 0.3 | -17.5 | 46.7 | 0.0 | 0.7 | -23.3 | 155.3 | 0.0 |
| JOINT LOOK BACK | 0.3 | +10.2 | 46.7 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 4.3 | +0.0 | 0.0 | 265.3 | 4.3 | +0.0 | 0.0 | 88.7 |
| LANE BY FIGURES | 0.3 | +4.5 | 0.0 | 0.0 | 0.7 | +50.8 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 7.0 | +0.0 | 213.3 | 1016.3 | 9.3 | +0.0 | 671.3 | 311.7 |
| LONG SHOT | 0.3 | +0.2 | 0.0 | 16.7 | - | - | - | - |
| LOST AFTER ESCAPE | 2.0 | +5.4 | 260.7 | 0.0 | 0.3 | -1.2 | 132.7 | 0.0 |
| LURE BY WHAT IT DRAWS | 0.7 | -50.0 | 0.0 | 45.3 | - | - | - | - |
| MANOEUVRE | 2.3 | -18.8 | 0.0 | 132.7 | 1.0 | -2.3 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +27.2 | 0.0 | 0.0 | 0.3 | +38.5 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 2.0 | +142.3 | 0.0 | 72.0 |
| MARCH OF THE TABLE | 0.3 | +25.1 | 0.0 | 0.0 | 0.3 | +10.0 | 0.0 | 36.0 |
| MARCH OVER CASTS | 1.0 | -38.2 | 0.0 | 0.0 | 0.7 | -31.6 | 0.0 | 36.0 |
| MARCH WHEELS ONLY | 3.7 | +0.0 | 0.0 | 265.3 | 2.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.3 | +13.7 | 0.0 | 0.0 | 1.0 | +9.0 | 0.0 | 6.3 |
| MEETS IN TIME | 4.0 | +174.0 | 0.0 | 0.0 | 5.7 | +191.1 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.3 | +13.0 | 0.0 | 70.3 | 6.3 | +238.9 | 0.0 | 88.7 |
| MISSILES NEXT TURN | 5.0 | +12.1 | 0.0 | 70.3 | 6.7 | +129.0 | 0.0 | 124.7 |
| MOVE ORDER | 3.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 38.0 | 38.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 3.0 | -89.1 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 7.3 | +802.5 | 0.0 | 0.0 | 7.3 | +733.8 | 0.0 | 142.0 |
| NEARER NOT NEEDED | 7.3 | +254.4 | 0.0 | 0.0 | 7.3 | +368.2 | 0.0 | 114.7 |
| NEXT CHARGE BY LIST | 5.3 | +651.9 | 0.0 | 0.0 | 3.3 | +438.7 | 0.0 | 34.7 |
| NO DOUBLE ROUNDS | 4.3 | -221.7 | 473.0 | 101.3 | 2.7 | -118.5 | 387.7 | 0.0 |
| NO LATE CUT | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 22.7 | - | - | - | - |
| NOT WORTH A CAST | 1.0 | -0.1 | 0.0 | 0.0 | 1.7 | -3.3 | 0.0 | 0.0 |
| OFF BEST | 4.0 | -86.9 | 36.0 | 132.3 | 5.0 | -216.0 | 0.0 | 38.0 |
| ONE CHECK AFTER THE LAST CHANGE | 1.3 | +0.0 | 0.0 | 22.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.3 | -108.8 | 0.0 | 32.7 | 6.7 | -57.2 | 0.0 | 36.3 |
| ONE OBJECTIVE FORMULA | 5.3 | -108.4 | 0.0 | 22.7 | 0.3 | -20.0 | 0.0 | 0.0 |
| ONE ROUTE | 3.7 | +0.0 | 0.0 | 265.3 | 2.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +7.0 | 38.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 1.3 | +8.9 | 125.3 | 16.7 | - | - | - | - |
| OWN CAST FIRST | 0.3 | -1.3 | 0.0 | 0.0 | - | - | - | - |
| PATHS CROSS | 2.0 | +10.7 | 0.0 | 132.7 | - | - | - | - |
| PLAN RESULT | 43.7 | +368.3 | 419.3 | 960.3 | 43.0 | +406.2 | 718.7 | 735.7 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 7.0 | -130.7 | 0.0 | 0.0 | 13.7 | -368.7 | 0.0 | 107.3 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 1.3 | -51.7 | 0.0 | 34.7 |
| PURSUES BIG PREY | - | - | - | - | 0.3 | -5.7 | 0.0 | 0.0 |
| QUARTER ODDS | 23.0 | +3059.8 | 105.3 | 136.0 | 25.0 | +3096.7 | 113.3 | 88.7 |
| REAL GROUND | 3.7 | +0.0 | 0.0 | 265.3 | 2.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 1.3 | +0.2 | 0.0 | 30.0 | 0.7 | -16.6 | 0.0 | 12.7 |
| REDIRECT COUNTER | 4.3 | +213.1 | 0.0 | 52.7 | 0.7 | +21.3 | 0.0 | 6.3 |
| REDIRECT FOR A FRIEND IN REACH | 2.0 | +67.9 | 0.0 | 52.7 | 1.0 | +29.0 | 0.0 | 12.7 |
| REFORMS TO MEET IT | 2.0 | -87.7 | 0.0 | 0.0 | 3.0 | -60.1 | 0.0 | 34.7 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 36.3 |
| RESERVE FALL BACK | 0.3 | +1.1 | 0.0 | 0.0 | 1.0 | +0.7 | 0.0 | 52.7 |
| RISK BY ARC | 4.3 | -114.3 | 473.0 | 101.3 | 2.7 | +23.3 | 365.0 | 0.0 |
| RISK ON THE WAY | 2.3 | +0.0 | 0.0 | 265.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 2.3 | -45.1 | 314.7 | 16.7 | - | - | - | - |
| RUN DOWN | 4.3 | -69.1 | 473.0 | 101.3 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | 1.7 | -21.9 | 0.0 | 30.0 | - | - | - | - |
| SEARCH SPOT | 1.7 | +24.6 | 0.0 | 0.0 | - | - | - | - |
| SECOND LOOK | 0.7 | +50.9 | 74.0 | 0.0 | 0.3 | +6.0 | 132.7 | 0.0 |
| SET CREDITED ONCE | 0.7 | -28.4 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 1.0 | +4.2 | 0.0 | 0.0 | 1.0 | -32.3 | 0.0 | 72.0 |
| SET-UP ANY TARGET | - | - | - | - | 1.0 | +94.1 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.3 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +0.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 1.7 | +0.0 | 0.0 | 30.0 | 3.0 | +0.0 | 0.0 | 46.7 |
| SHOOTS FROM THE BEST SPOT | 0.3 | +22.2 | 0.0 | 0.0 | 1.7 | +144.2 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -5.6 | 22.7 | 0.0 |
| SHOT RISK POINTS | 41.0 | -160.6 | 0.0 | 580.7 | 10.7 | -25.2 | 0.0 | 69.3 |
| SHOTS AFTER THE MOVES | - | - | - | - | 3.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | - | - | - | - | 19.3 | +207.3 | 0.0 | 288.7 |
| SPELL OFF EDGE | - | - | - | - | 0.3 | +17.1 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | - | - | - | - | 1.0 | +94.1 | 0.0 | 0.0 |
| SPELL WORTH | 1.0 | +2.6 | 0.0 | 0.0 | 2.0 | +9.5 | 91.3 | 91.3 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | -5.4 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 11.0 | +0.0 | 0.0 | 84.7 | 6.0 | +0.0 | 0.0 | 69.3 |
| STAND AND SHOOT | 0.7 | -4.3 | 74.7 | 0.0 | - | - | - | - |
| STANDS STILL | 16.0 | +0.0 | 83.3 | 0.0 | 36.7 | +0.0 | 70.3 | 290.0 |
| STAY WORTH | - | - | - | - | 15.0 | +17.7 | 32.7 | 135.3 |
| STRIKE BY THE ODDS | 0.3 | +3.6 | 34.7 | 0.0 | 0.3 | +2.1 | 132.7 | 0.0 |
| STUPIDITY NEXT TURN | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 3.7 | +51.9 | 0.0 | 107.3 | 1.3 | +24.5 | 0.0 | 41.0 |
| SUPPORT NARROWED | - | - | - | - | 0.7 | +0.0 | 15.0 | 0.0 |
| SUPPORT WORKED OUT | 3.7 | +51.9 | 0.0 | 107.3 | 1.3 | +24.5 | 0.0 | 41.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 132.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 4.0 | +0.0 | 0.0 | 16.7 | 3.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 6.3 | +0.0 | 0.0 | 146.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE STEP BACK IS MADE | 4.3 | +0.0 | 0.0 | 84.7 | - | - | - | - |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 44.3 | +0.0 | 0.0 | 507.7 | 43.3 | +0.0 | 0.0 | 367.3 |
| TIED UP BY THE SUM | 2.3 | +281.2 | 285.0 | 0.0 | 0.3 | +41.7 | 22.7 | 0.0 |
| TIME ON OUR SIDE | - | - | - | - | 49.0 | +518.7 | 47.7 | 319.7 |
| WAITS AGAIN | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 34.7 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -94.8 | 0.0 | 0.0 |
| WHO FIGHTS | 0.7 | +18.8 | 6.3 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.3 | +16.7 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 1.3 | -36.2 | 0.0 | 65.3 | 2.7 | -259.3 | 0.0 | 193.3 |
| WOUNDS ON THE RANKS | 3.7 | +62.6 | 0.0 | 132.7 | 1.0 | +12.5 | 0.0 | 0.0 |

### Rule changes: ccut-c940641-p24

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 163 | 163 | 100 | 33.33 | +3349 | +33.5 |
| HIS MOVE AS HE DECIDES | 139 | 139 | 98 | 32.67 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 57 | 57 | 50 | 16.67 | +2446 | +48.9 |
| LEGAL CHARGES ONLY | 49 | 49 | 49 | 16.33 | +0 | +0.0 |
| FIVE ACTION | 525 | 499 | 46 | 15.33 | +2177 | +47.3 |
| HIS SHOT LIST | 277 | 264 | 43 | 14.33 | +426 | +9.9 |
| DEPLOY BY FIGURES | 51 | 51 | 35 | 11.67 | +412 | +11.8 |
| HIS SHOTS BY HIS RUN | 204 | 193 | 33 | 11.00 | +223 | +6.8 |
| QUARTER ODDS | 144 | 140 | 33 | 11.00 | +2117 | +64.1 |
| THE TABLE AGAIN | 36 | 36 | 33 | 11.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 44 | 39 | 30 | 10.00 | +1556 | +51.9 |
| OFF BEST | 27 | 27 | 27 | 9.00 | -909 | -33.7 |
| PROMISE BY ITS OWN SUM | 62 | 62 | 25 | 8.33 | -1498 | -59.9 |
| HIS MOVE WHY | 35 | 35 | 19 | 6.33 | +0 | +0.0 |
| HIS ONE MOVE | 74 | 70 | 18 | 6.00 | +0 | +0.0 |
| MOVE ORDER | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 26 | 25 | 18 | 6.00 | +1239 | +68.9 |
| TIME ON OUR SIDE | 147 | 107 | 17 | 5.67 | +53 | +3.1 |
| SHOT RISK POINTS | 155 | 140 | 16 | 5.33 | +170 | +10.6 |
| GOAL WALK | 81 | 80 | 15 | 5.00 | +773 | +51.5 |
| HARD STAY DROPPED | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| THE RISK READS HIS RUN | 18 | 18 | 13 | 4.33 | +0 | +0.0 |
| ADVANCE LANE KEPT | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| FOUR ROUNDS | 25 | 23 | 11 | 3.67 | +494 | +44.9 |
| CHAFF IN THE MOVE | 20 | 20 | 10 | 3.33 | +22 | +2.2 |
| MEETS IN TIME | 29 | 29 | 9 | 3.00 | +409 | +45.5 |
| REDIRECT FOR A FRIEND IN REACH | 9 | 9 | 8 | 2.67 | +54 | +6.7 |
| TIED UP BY THE SUM | 8 | 8 | 7 | 2.33 | +213 | +30.4 |
| IDLE COST | 54 | 40 | 6 | 2.00 | +25 | +4.2 |
| NEARER NOT NEEDED | 44 | 40 | 6 | 2.00 | +221 | +36.8 |
| PATHS CROSS | 6 | 6 | 6 | 2.00 | +32 | +5.3 |
| CHARGE NOW FIRST | 16 | 16 | 5 | 1.67 | -422 | -84.4 |
| COVER ONCE | 41 | 23 | 5 | 1.67 | +115 | +22.9 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +754 | +150.9 |
| SHOOTS FROM THE BEST SPOT | 6 | 6 | 5 | 1.67 | +70 | +14.1 |
| ASSAILMENT BY POINTS | 4 | 4 | 4 | 1.33 | +15 | +3.8 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHAFF PASSED | 4 | 4 | 4 | 1.33 | -0 | -0.1 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +185 | +46.4 |
| MARCH CHECK | 6 | 6 | 4 | 1.33 | +98 | +24.6 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +5 | +1.3 |
| SEARCH SPOT | 5 | 5 | 4 | 1.33 | +74 | +18.4 |
| HIS CHARGE DENIED | 4 | 4 | 3 | 1.00 | +73 | +24.3 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | -123 | -40.9 |
| LANE BY FIGURES | 3 | 3 | 3 | 1.00 | +166 | +55.2 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +197 | +65.7 |
| PROMISE KNOWS THE FIGHT | 4 | 4 | 3 | 1.00 | -155 | -51.7 |
| SECOND LOOK | 3 | 3 | 3 | 1.00 | +171 | +57.0 |
| SUPPORT ADDS | 15 | 13 | 3 | 1.00 | +22 | +7.3 |
| SUPPORT WORKED OUT | 15 | 13 | 3 | 1.00 | +22 | +7.3 |
| THE ROW IN ITS ORDER | 23 | 3 | 3 | 1.00 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 12 | 12 | 3 | 1.00 | +91 | +30.4 |
| CAST JOB | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHARGE LOSSES | 89 | 80 | 2 | 0.67 | +85 | +42.6 |
| FIGHT TO THE END | 7 | 6 | 2 | 0.67 | +39 | +19.6 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -105 | -52.6 |
| ONE OBJECTIVE FORMULA | 17 | 15 | 2 | 0.67 | +36 | +18.0 |
| REDIRECT BY WHAT IT STOPS | 6 | 6 | 2 | 0.67 | +22 | +10.9 |
| REDIRECT COUNTER | 15 | 12 | 2 | 0.67 | +64 | +32.0 |
| SCREEN BY WHAT IT SAVES | 5 | 5 | 2 | 0.67 | +0 | +0.0 |
| SET UP BY THE SET | 6 | 6 | 2 | 0.67 | +36 | +18.1 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +2 | +1.0 |
| SHOTS IN THE MOVE | 58 | 38 | 2 | 0.67 | +49 | +24.4 |
| STAY WORTH | 45 | 32 | 2 | 0.67 | +24 | +12.1 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +17 | +8.6 |
| SUPPORT NARROWED | 2 | 2 | 2 | 0.67 | -72 | -36.1 |
| WOUNDS ON THE RANKS | 14 | 14 | 2 | 0.67 | +17 | +8.4 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +8 | +7.8 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CASTING BLOCK | 1 | 1 | 1 | 0.33 | +16 | +16.1 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| DUEL STOPS AT THE KILL | 2 | 2 | 1 | 0.33 | +70 | +69.7 |
| EXACT ROUND | 15 | 13 | 1 | 0.33 | +2 | +1.5 |
| FALL BACK GOOD ORDER | 16 | 15 | 1 | 0.33 | +10 | +9.6 |
| FALLBACK BY WORTH | 2 | 2 | 1 | 0.33 | +4 | +4.5 |
| FALLS SHORT | 63 | 52 | 1 | 0.33 | +0 | +0.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +9 | +8.9 |
| HONEST WORTH | 23 | 22 | 1 | 0.33 | +112 | +111.7 |
| HORN WORTH | 1 | 1 | 1 | 0.33 | +26 | +26.5 |
| JOINT LOOK BACK | 1 | 1 | 1 | 0.33 | +31 | +30.6 |
| MANOEUVRE | 10 | 10 | 1 | 0.33 | +11 | +11.2 |
| MAX FOR POSITIONING | 7 | 7 | 1 | 0.33 | +0 | +0.0 |
| MISSILES IN THE MOVE | 29 | 20 | 1 | 0.33 | +2 | +1.9 |
| NO DOUBLE ROUNDS | 21 | 19 | 1 | 0.33 | +25 | +25.2 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +16 | +16.5 |
| OVERRUNS AWAY | 4 | 4 | 1 | 0.33 | +10 | +9.6 |
| OWN CAST FIRST | 1 | 1 | 1 | 0.33 | -4 | -3.8 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.33 | -17 | -17.0 |
| REFUSING RETIRES | 3 | 3 | 1 | 0.33 | -4 | -4.4 |
| RISK BY ARC | 21 | 19 | 1 | 0.33 | +2 | +1.5 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -284 | -284.3 |
| WHO FIGHTS | 2 | 2 | 1 | 0.33 | +2 | +1.5 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +47 | +47.4 |
| BACKUP TARGETS | 3 | not checked | - | - | - | - |
| CASTS AFTER FRIENDS | 8 | trace | - | - | - | - |
| CHARACTER GUNS | 16 | 14 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 67 | 65 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 9 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 2 | 2 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 40 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 36 | 35 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 21 | 21 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 68 | 62 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 40 | 37 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 37 | 32 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 18 | 16 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 37 | 36 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 41 | 40 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 5 | 4 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 86 | 85 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 26 | 25 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 1 | 1 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 7 | 6 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 17 | 16 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 35 | 25 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 9 | trace | - | - | - | - |
| NO LATE CUT | 8 | 7 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 8 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 5 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 36 | 14 | 0 | 0.00 | - | - |
| ONE ROUTE | 17 | 16 | 0 | 0.00 | - | - |
| PLAN RESULT | 260 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 17 | 16 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 15 | 13 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 11 | 11 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 7 | 6 | 0 | 0.00 | - | - |
| RUN DOWN | 13 | 12 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 3 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 14 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 9 | 9 | 0 | 0.00 | - | - |
| SPELL OFF EDGE | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 3 | not checked | - | - | - | - |
| SPELL WORTH | 9 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 51 | 44 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS STILL | 158 | 148 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 8 | 5 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 20 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 5 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 13 | not checked | - | - | - | - |
| THE TABLE BINDS | 263 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 3 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p24

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 1.67 | 6.67 | 59.9 |
| JOB FIRST | gate | 2.33 | 4.33 | 34.9 |
| ARMY TABLE | rule | 0.67 | 3.00 | 53.6 |
| CHARGE NOW FIRST | rule | 1.33 | 0.33 | 84.4 |
| RULE SWITCHED OFF | gate | 1.33 | - | 16.4 |
| JOINT CHARGE NOW | rule | 0.33 | 0.67 | 40.9 |
| PROMISE KNOWS THE FIGHT | rule | - | 1.00 | 51.7 |
| HOLDER ASSIGNMENT | rule | - | 0.67 | 3.5 |
| MARCH OF THE TABLE | rule | 0.33 | 0.33 | 52.6 |
| SUPPORT NARROWED | rule | - | 0.67 | 36.1 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.33 | 6.5 |
| FALLBACK | gate | 0.33 | - | 23.9 |
| NO REASON | gate | - | 0.33 | 115.6 |
| OWN CAST FIRST | rule | 0.33 | - | 3.8 |
| PURSUES BIG PREY | rule | - | 0.33 | 17.0 |
| REFUSING RETIRES | rule | - | 0.33 | 4.4 |
| RESERVE FALL BACK | rule | - | 0.33 | 3.8 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 284.3 |

### Plans: ccut-c940641-p24

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 4.0 | 67% | 526 | 327 | 62% |
| Mine | join | 5.3 | 100% | 219 | 0 | 0% |
| Mine | move | 32.3 | 96% | 1433 | 0 | 0% |
| Mine | shoot | 0.7 | 50% | 14 | 42 | 309% |
| Mine | support | 1.3 | 75% | 48 | 0 | 0% |
| Opponent | charge | 3.0 | 56% | 425 | 388 | 91% |
| Opponent | move | 36.3 | 94% | 2632 | 0 | 0% |
| Opponent | shoot | 3.3 | 10% | 177 | 18 | 10% |
| Opponent | support | 0.3 | 0% | 11 | 0 | 0% |

### Battle groups: ccut-c940641-p24

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.3 | 23% | 33% | 0% | - | 0% | 0% | 33% | 33% | 33% |
| Opponent | REDIRECT COUNTER | 0.7 | 50% | 100% | 0% | - | 0% | 0% | 100% | 0% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p24

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 85 (9) | 0 | 85 | 53 | 44% | 4.8 | 110 (7) | 0 (1) | 0 (1) | 96 (8) | 0 (1) |
| Mine | Character | 10 | 59 (10) | 59 | 0 | 39 | 50% | 2.4 | 38 (5) | 71 (5) | - | 34 (5) | 77 (5) |
| Mine | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 8 | 9 (8) | 1 | 8 | 38 | 50% | 2.8 | 0 (2) | 0 (4) | 44 (2) | 0 (1) | 12 (7) |
| Mine | Hammer | 2 | 226 (2) | 179 | 47 | 0 | 0% | 3.0 | 150 (1) | 315 (1) | - | 150 (1) | 315 (1) |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 39 | 0% | 1.5 | 0 (3) | - | 0 (1) | 0 (2) | 0 (2) |
| Opponent | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 50% | 3.0 | 0 (2) | - | - | 0 (2) | - |
| Opponent | Character | 7 | 92 (7) | 92 | 0 | 33 | 0% | 1.1 | 72 (3) | 177 (2) | 0 (1) | 75 (2) | 114 (4) |
| Opponent | Clean-up | 2 | 97 (2) | 0 | 97 | 100 | 0% | 1.5 | 194 (1) | 0 (1) | - | 194 (1) | 0 (1) |
| Opponent | Fast Hammer | 5 | 19 (5) | 10 | 9 | 39 | 0% | 1.6 | 19 (2) | 0 (2) | 54 (1) | 19 (2) | 19 (3) |
| Opponent | Hammer | 11 | 9 (11) | 9 | 0 | 9 | 55% | 3.4 | 0 (3) | 18 (6) | 0 (2) | 0 (2) | 10 (9) |
| Opponent | Shooter | 8 | 18 (8) | 0 | 18 | 51 | 0% | 1.1 | 21 (2) | 23 (5) | 0 (1) | 16 (3) | 19 (5) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | - | 0 (1) | - | 0 (1) |

### Charged fights: ccut-c940641-p24

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 2 | 0 | 398 | 2.0 | 1.2 | 199 | 0 | +199 | 1 of 4 | 4 of 4 | +140 | +219 |
| Mine | Warriors of Chaos | 1 | 0 | 576 | 7.0 | 1.0 | 82 | 0 | +82 | 2 of 7 | 6 of 7 | - | +82 |
| **Mine** | all armies | 3 | 0 | 457 | 3.7 | 1.1 | 125 | 0 | +125 | 3 of 11 | 10 of 11 | +140 | +123 |
| Opponent | Wood Elf Realms | 3 | 126 | 653 | 3.3 | 1.1 | 196 | 12 | +183 | 5 of 10 | 6 of 10 | +143 | +188 |

### Effective charges: ccut-c940641-p24

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 4 | 0 | 0 | 0 | 1 (net +432) | 2 (net +125) | 0 | 1 | 0% (0 of 3) |
| Mine | Warriors of Chaos | 7 | 0 | 0 | 0 | 0 | 1 (net +19) | 3 (net +113) | 3 | 0% (0 of 4) |
| Opponent | Wood Elf Realms | 10 | 2 (net +566) | 0 | 1 (net +0) | 0 | 1 (net +143) | 3 (net +38) | 3 | 14% (1 of 7) |

### Charged fights, damage counted: ccut-c940641-p24

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 1 | 147 | 158 | +432 | 432 | 37 | +395 | +268.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 352 | 227 | +113 | 161 | 5 | +157 | +44.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 3 | 399 | 90 | +90 | 90 | 0 | +90 | +22.5 |
| Mine | No odds | 4 | 324 | 139 | +83 | 101 | 22 | +79 | +24.4 |
| Mine | All fights | 11 | 336 | 151 | +125 | 144 | 12 | +132 | +39.3 |
| Opponent | Long shot (under 50%) | 2 | 300 | 414 | +566 | 566 | 0 | +566 | +188.2 |
| Opponent | Effective (55-75%) | 1 | 102 | 60 | +0 | 6 | 51 | -45 | -44.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 242 | 122 | +38 | 38 | 0 | +38 | +15.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 601 | 68 | +143 | 143 | 0 | +143 | +23.8 |
| Opponent | No odds | 3 | 201 | 487 | +149 | 190 | 153 | +38 | +18.8 |
| Opponent | All fights | 10 | 263 | 278 | +183 | 196 | 51 | +146 | +55.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p24 | move | 26 | 7 (27%) | 5 (19%) | 5 (19%) | 14 (54%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2535, L2735 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2535, L2735 |
| Ring of Doom | Opponent | L3033 |

# Doctrine scorecard: ccut-c940641-p2

### Scorecard: ccut-c940641-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0218 | 2 | 1 | Mine | - | - | 6 | 1 | 7 | 0 | 0 | 0 | 255 |
| L0218 | 2 | 1 | Opponent | - | - | - | 1 | 4 | 0 | 0 | 0 | 74 |
| L0235 | 1 | 1 | Mine | no | 2 | 2 | 2 | 4 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Opponent | no | 2 | 2 | 1 | 4 | 0 | 0 | 0 | 125 |
| L0319 | 1 | 1 | Mine | no | 7 | - | 0 | 0 | 0 | 0 | 0 | 420 |
| L0319 | 1 | 1 | Opponent | no | 1 | 3 | 4 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 4.5 | 4.0 | 1.0 | 3.7 | 0.0 | 0.0 | 0.0 | 225.0 |
| **Average** | | | Opponent | 0% | 1.5 | 2.5 | 2.0 | 3.3 | 0.0 | 0.0 | 0.0 | 66.3 |

### KPIs: ccut-c940641-p2

Rules off - Mine only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 25% (3 of 12) | 0% (0 of 15) | 11% (3 of 27) |
| Winner chose to follow up after the loser gave ground |  | 100% (4 of 4); on the table 100% | 100% (2 of 2); on the table 100% | 100% (6 of 6); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 50% (1 of 2); on the table 50% | - | 50% (1 of 2); on the table 50% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 83% (5 of 6); on the table 83% | 100% (2 of 2); on the table 100% | 88% (7 of 8); on the table 88% |
| Magic missiles tried each own turn | 50%+ | 52% (22 of 42) | 12% (3 of 24) | 38% (25 of 66) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 52% (22 of 42) | 12% (3 of 24) | 38% (25 of 66) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (8 of 12) | - | 67% (8 of 12) |
| Points that never fought | lower | 56% (3257 of 5797) | 55% (3318 of 6000) | 56% (6575 of 11797) |
|   infantry points that never fought | lower | 45% (613 of 1374) | 61% (517 of 842) | 51% (1130 of 2216) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 65% (13 of 20) | 67% (18 of 27) | 66% (31 of 47) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 6.0 uses a game | 50% (1 of 2); 1.3 uses a game | 83% (5 of 6); 3.7 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 40% (2 of 5); 0.7 uses a game | 100% (1 of 1); 0.3 uses a game | 50% (3 of 6); 0.5 uses a game |
|   their share of the points of units over 100 pts | lower | 56% (2261 of 4039) | 67% (3683 of 5515) | 62% (5944 of 9554) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 6.7 (100%) | 0.3 (5%) | 7.0 (51%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.3 (5%) | 0.3 (2%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 4.7 (67%) | 4.7 (34%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (5%) | 0.3 (2%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 1.3 (19%) | 1.3 (10%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- |
| tried | 1.3 | 4.3 | 8.3 | 0.3 |
| not cast | 2.7 | 5.7 | 13.7 | 27.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.0 (14%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (25%) | 0.0 (0%) | 7.0 (51%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (75%) | 4.0 (71%) | 4.7 (34%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (6%) | 0.3 (2%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 1.3 (10%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.0 (0%) | 1.3 (24%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 23.7 (86%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.7 a game | 1.7 a game | 2.2 a game |
| stood (cast and not dispelled) | 88% (7 of 8) | 60% (3 of 5) | 77% (10 of 13) |
| the unit moved after it | 71% (5 of 7) | 0% (0 of 3) | 50% (5 of 10) |
| it charged on its next turn | 0% (0 of 7) | 0% (0 of 3) | 0% (0 of 10) |
| the enemy charged it first | 0% (0 of 7) | 0% (0 of 3) | 0% (0 of 10) |
| it fought by the end of its next turn | 0% (0 of 7) | 0% (0 of 3) | 0% (0 of 10) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 7) | 33% (1 of 3) | 10% (1 of 10) |
| none of these (no charge, no fight, no charge escaped) | 100% (7 of 7) | 67% (2 of 3) | 90% (9 of 10) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (22 of 36) | 46% (38 of 83) | 50% (60 of 119) |
|   cavalry | - | 44% (8 of 18) | 44% (8 of 18) |
|   character | - | 58% (7 of 12) | 58% (7 of 12) |
|   chariot | 50% (6 of 12) | 58% (7 of 12) | 54% (13 of 24) |
|   infantry | - | 24% (7 of 29) | 24% (7 of 29) |
|   monster | - | 75% (9 of 12) | 75% (9 of 12) |
|   war machine | 67% (16 of 24) | - | 67% (16 of 24) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.3 (29%) | 2.7 (18%) | 4.0 (20%) |
| CHARGED: it charged | 0.0 (0%) | 0.7 (4%) | 0.7 (3%) |
| IN COMBAT: it fought this turn or the last | 0.7 (14%) | 0.7 (4%) | 1.3 (7%) |
| MOVED: a war machine that moved | 0.7 (14%) | 0.0 (0%) | 0.7 (3%) |
| NO TARGET IN RANGE | 0.0 (0%) | 5.3 (36%) | 5.3 (27%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (2%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.0 (43%) | 2.0 (13%) | 4.0 (20%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 1.3 (9%) | 1.3 (7%) |
| OTHER BAR | 0.0 (0%) | 2.0 (13%) | 2.0 (10%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.0 | 0.7 | 83% | 3.2 pts | 13 pts |
| character | 2.3 | 1.0 | 57% | 8.2 pts | 19 pts |
| chariot | 4.3 | 4.3 | 62% | 19.5 pts | 85 pts |
| infantry | 2.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| monster | 3.0 | 2.3 | 56% | 12.1 pts | 36 pts |
| war machine | 5.3 | 4.7 | 62% | 10.4 pts | 55 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.0 | 3.7 | 2.3 |
| Charges that made contact a game | 0.7 | 3.0 | 1.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | - | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.12 declared, 0.08 contact (25 units) | 0.38 declared, 0.31 contact (29 units) | 0.26 declared, 0.20 contact (54 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 33% (1 of 3) | 100% (1 of 1) | - | 50% (2 of 4) |
| Character in a unit | 86% (6 of 7) | 43% (3 of 7) | - | 64% (9 of 14) |
| Character on its own | 100% (1 of 1) | 100% (1 of 1) | 100% (2 of 2) | 100% (4 of 4) |
| Chariot | 50% (1 of 2) | 50% (1 of 2) | - | 50% (2 of 4) |
| Infantry | 60% (3 of 5) | 0% (0 of 3) | - | 38% (3 of 8) |
| Monster | 100% (2 of 2) | 0% (0 of 1) | - | 67% (2 of 3) |
| Monstrous | 100% (2 of 2) | 75% (3 of 4) | - | 83% (5 of 6) |
| War Machines | 100% (3 of 3) | 100% (1 of 1) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 2 | 100% (3 of 3); on the table 100% | 73% (22 of 30) | 63% | 67% (8 of 12) | 100% (4 of 4); 9.0 uses a game | 0.0 uses a game | 50% (2 of 4); 1.0 uses a game |
| Chaos Dwarfs | 1 | 67% (2 of 3); on the table 67% | 0% (0 of 12) | 43% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 68% | 43% (3 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (2 of 2); on the table 100% | 0% (0 of 12) | 17% | 100% (8 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Wood Elf Realms | 1 | - | 50% (3 of 6) | 80% | 58% (7 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p2, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 11% (1) | 0% (0) | 10% (1) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.00 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.00 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: ccut-c940641-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | 67% (2 of 3) | 83% (5 of 6) |
| Strategy | Shoot objectives carried out (shot that target) | 44% (12 of 27) | 40% (4 of 10) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 50% (2 of 4) |
| Strategy | Joined characters whose unit fought | 55% (6 of 11) | 80% (4 of 5) |
| Strategy | Lone characters that fought | 0% (0 of 4) | 50% (2 of 4) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 3.7 | 3.3 |
| Movement | Points that never moved of their own | 225.0 | 66.3 |
| Movement | Fights charged into per game | 0.7 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 2, net -52 | 2 of 4, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 2, net +140 | 1 of 4, net +85 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 2 | 0 of 4 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 2 | 0 of 4 |
| Shooting | Shots by shooting units (incl. breath weapons) | 2.0 | 12.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 83% (5 of 6) | 16% (6 of 38) |
| Shooting | Points destroyed by shooting units | 0.0 | 28.3 |
| Shooting | War machine shots | 5.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (7 of 16) | - |
| Shooting | Points destroyed by war machines | 0.0 | 28.3 |
| Magic | Magic missiles cast | 4.0 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 12) | 0% (0 of 2) |
| Magic | Wounds caused by magic missiles | 15.3 | 3.3 |
| Magic | Wounds caused by other spells | 0.3 | - |
| Magic | Points destroyed by magic (all spells) | 41.7 | 17.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.3 / 0.0 | 0.0 / 1.3 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 181.7 | 17.3 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +69 | -28 |
| Combat | Net per 100 charger points, damage counted | +132.2 | -14.7 |
| Combat | First round won (charged fights) | 50% | 56% |
| Combat | Net points per charged fight | +44 | -36 |
| Combat | Net points per supported fight / lone fight | - / +44 | - / -36 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 2 | 6 of 9 |
| Game | Points lost | 119.7 | 203.0 |
| Game | VP from objectives | 776.7 | 713.3 |
| Game | Lone holders (player turns) | 4.5 | 1.5 |

- Mine won / drew / lost: 1 / 2 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +305 VP
- The side that went first won 1 of 1 games with a winner
- Points traded per game (both sides' losses): 323
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: ccut-c940641-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | - | - | - | - | 1.0 | +0.0 | 0.0 | 41.7 |
| ARMY TABLE | 13.7 | +278.9 | 0.0 | 52.0 | 27.0 | -245.6 | 0.0 | 73.3 |
| ARTILLERY RE-ROLL WEIGHED | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 0.3 | +0.5 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | 0.3 | +0.8 | 0.0 | 17.3 | - | - | - | - |
| CANNON PLAN MISSED | 1.0 | +0.0 | 55.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 5.0 | +179.2 | 165.0 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 4.0 | +61.0 | 0.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +34.4 | 0.0 | 0.0 | 1.7 | +44.4 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 2.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 1.7 | +70.8 | 0.0 | 85.0 | 1.0 | +4.5 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | -6.8 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 11.3 | -210.1 | 0.0 | 0.0 | 10.0 | -462.9 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 46.7 | 0.0 | 1.0 | +0.0 | 56.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 11.0 | +0.0 | 0.0 | 0.0 | 9.3 | +0.0 | 0.0 | 55.0 |
| CONVEYANCE SEARCH | 2.3 | +273.8 | 0.0 | 0.0 | 1.7 | +149.8 | 0.0 | 0.0 |
| COVER ONCE | 3.3 | -164.7 | 0.0 | 17.3 | 5.3 | -171.4 | 0.0 | 0.0 |
| DEFENSIVE FLOOR | - | - | - | - | 0.3 | +12.2 | 28.3 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -2.5 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 9.7 | +22.3 | 0.0 | 28.3 | 8.3 | +76.7 | 0.0 | 41.7 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -2.3 | 0.0 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.3 | +13.2 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 0.7 | -11.6 | 46.7 | 17.3 | 2.0 | -3.7 | 56.7 | 0.0 |
| FALL BACK GOOD ORDER | 1.0 | +8.9 | 46.7 | 34.7 | 1.7 | +3.2 | 28.3 | 0.0 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | 23.0 | +296.9 | 0.0 | 80.3 | 3.7 | +59.5 | 0.0 | 0.0 |
| FEATURE BUFFS | 13.0 | +526.0 | 0.0 | 0.0 | 2.7 | +91.5 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +3.8 | 46.7 | 0.0 | 1.0 | +9.9 | 28.3 | 0.0 |
| FIVE ACTION | 98.0 | +8198.3 | 303.3 | 217.3 | 95.3 | +6820.0 | 289.7 | 144.0 |
| FLANK NOT WEIGHED | 6.3 | +0.0 | 0.0 | 28.3 | 4.3 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 1.0 | +101.5 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 1.0 | +56.5 | 46.7 | 34.7 | 2.3 | +195.5 | 56.7 | 0.0 |
| FREED FROM HIS FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| GOAL WALK | 7.0 | +578.2 | 0.0 | 56.7 | 11.7 | +927.2 | 0.0 | 0.0 |
| GUN FIGURES | 1.7 | +30.5 | 0.0 | 0.0 | 2.0 | +38.5 | 28.3 | 0.0 |
| HARD STAY DROPPED | 3.7 | +0.0 | 0.0 | 17.3 | 2.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 6.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE LIST | 4.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.3 | +0.0 | 0.0 | 17.3 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 5.7 | -114.7 | 0.0 | 113.3 | 1.7 | -27.5 | 0.0 | 0.0 |
| HIS MOVE AS HE DECIDES | 47.3 | +14.0 | 161.0 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 21.0 | +0.0 | 0.0 | 22.7 |
| HIS ONE MOVE | 18.0 | -71.9 | 0.0 | 17.3 | - | - | - | - |
| HIS ONE QUARTER | 5.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS OWN BEST MOVE | 0.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 21.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 61.3 | +1946.7 | 0.0 | 182.7 | 65.3 | +3259.1 | 0.0 | 144.0 |
| HIS SHOTS BY HIS RUN | 55.7 | +1129.8 | 0.0 | 182.7 | 39.7 | +814.2 | 0.0 | 144.0 |
| HIS TURN DENIED | - | - | - | - | 0.3 | +90.8 | 0.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 35.7 | +0.0 | 0.0 | 0.0 | 21.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 15.0 | +1615.0 | 0.0 | 0.0 | 14.0 | +1177.7 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.7 | -3.6 | 46.7 | 17.3 | 2.3 | -71.9 | 56.7 | 0.0 |
| IDLE COST | 15.3 | -88.0 | 0.0 | 63.0 | 3.3 | -64.9 | 0.0 | 18.3 |
| KEEP FALLS | 0.3 | +3.3 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 3.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +17.7 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 1.0 | +0.0 | 46.7 | 0.0 | 3.3 | +0.0 | 17.3 | 46.7 |
| LONE WIZARD KEPT IN | 1.3 | +116.7 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 0.7 | -1.2 | 46.7 | 17.3 | 2.0 | -8.3 | 56.7 | 0.0 |
| MANOEUVRE | 2.7 | +20.0 | 0.0 | 0.0 | 2.3 | -6.3 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +57.7 | 0.0 | 0.0 | 0.3 | +15.6 | 0.0 | 0.0 |
| MARCH CHECK | 1.0 | +49.8 | 0.0 | 0.0 | 0.7 | +24.5 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.7 | -2.9 | 0.0 | 0.0 | 0.7 | -2.9 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 2.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.0 | +29.3 | 0.0 | 56.7 | 1.7 | +12.9 | 0.0 | 0.0 |
| MEETS IN TIME | 3.3 | +262.7 | 0.0 | 0.0 | 3.0 | +302.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 7.0 | +393.2 | 0.0 | 0.0 | 4.0 | +92.5 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 6.7 | +248.4 | 0.0 | 0.0 | 4.0 | +57.5 | 0.0 | 0.0 |
| MISSILES ON ONE TARGET | 2.0 | -97.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 2.0 | +0.0 | 17.3 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 0.7 | -63.3 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.7 | +672.3 | 0.0 | 0.0 | 3.7 | +133.8 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.7 | +36.7 | 0.0 | 0.0 | 0.3 | +1.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 3.3 | +164.6 | 0.0 | 0.0 | 9.7 | +403.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 1.0 | +333.6 | 0.0 | 0.0 | 3.0 | +127.0 | 17.3 | 0.0 |
| NO DOUBLE ROUNDS | 1.0 | -35.5 | 46.7 | 34.7 | 1.7 | -26.6 | 56.7 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 2.0 | -792.4 | 0.0 | 0.0 | 4.3 | -202.8 | 28.3 | 0.0 |
| OGRE LOADER SECOND SHOT | 1.7 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 4.0 | -43.7 | 0.0 | 102.3 | 5.0 | -80.2 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +19.6 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 9.7 | +80.4 | 0.0 | 0.0 | 5.0 | -45.0 | 0.0 | 0.0 |
| ONE ROUTE | 2.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 0.3 | +1.1 | 0.0 | 0.0 | 0.7 | +1.4 | 34.7 | 0.0 |
| PATHS CROSS | 0.3 | +8.5 | 0.0 | 0.0 | 0.3 | -19.8 | 0.0 | 0.0 |
| PLAN RESULT | 44.0 | +145.6 | 175.0 | 137.0 | 43.0 | +178.1 | 28.3 | 172.3 |
| PROMISE BY ITS OWN SUM | 5.7 | -996.4 | 0.0 | 17.3 | 7.0 | -174.7 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | -11.9 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.3 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| PURSUES BIG PREY | 0.3 | -53.8 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 20.0 | +1666.0 | 0.0 | 0.0 | 16.3 | +2206.9 | 0.0 | 36.7 |
| RANDOM MOVE BY FIGURES | 4.0 | +115.7 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | 2.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.7 | +27.5 | 0.0 | 56.7 | - | - | - | - |
| REDIRECT COUNTER | 4.3 | +266.7 | 0.0 | 56.7 | 2.0 | -54.2 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 4.3 | +34.4 | 0.0 | 85.0 | 3.3 | +0.0 | 0.0 | 59.3 |
| REFORMS TO MEET IT | - | - | - | - | 1.3 | -15.3 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 36.7 |
| RESERVE FALL BACK | - | - | - | - | 0.7 | +29.9 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | 0.3 | +36.7 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | - | - | - | - | 1.3 | -3.9 | 56.7 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.3 | -19.2 | 0.0 | 0.0 |
| RUN DOWN | 0.7 | -0.7 | 46.7 | 17.3 | 1.3 | -4.6 | 56.7 | 0.0 |
| SAME TERRAIN AS THE BOARD | 0.3 | +0.0 | 0.0 | 28.3 | - | - | - | - |
| SCOUT SPOT | - | - | - | - | 0.7 | -0.1 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 1.7 | -23.8 | 0.0 | 0.0 | 1.0 | -49.6 | 0.0 | 0.0 |
| SEARCH SPOT | 1.0 | +8.1 | 0.0 | 0.0 | 0.3 | +1.5 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +4.5 | 28.3 | 0.0 |
| SET CREDITED ONCE | 0.3 | -3.9 | 0.0 | 0.0 | 0.3 | -1.6 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.7 | +10.2 | 0.0 | 0.0 | 0.7 | -15.5 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.3 | +59.5 | 0.0 | 0.0 | 0.3 | +26.5 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.3 | +17.2 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.7 | -5.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 9.3 | +0.0 | 0.0 | 28.3 | 5.0 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.7 | +194.9 | 0.0 | 0.0 | 1.3 | +20.7 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -1.1 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.3 | +0.0 | 18.3 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 46.0 | +681.4 | 0.0 | 182.7 | 45.7 | +467.6 | 0.0 | 144.0 |
| SHOTS AFTER THE MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 8.0 | +552.7 | 0.0 | 0.0 | 16.0 | +370.3 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.3 | +59.5 | 0.0 | 0.0 | 0.3 | +26.5 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | -7.2 | 0.0 | 17.3 | - | - | - | - |
| SPOT AS THE GAME MOVES | 6.3 | +0.0 | 0.0 | 56.7 | 6.3 | +0.0 | 0.0 | 36.7 |
| STAND AND SHOOT | 0.7 | -8.5 | 46.7 | 17.3 | 0.3 | -6.3 | 0.0 | 0.0 |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 47.7 | +0.0 | 256.7 | 52.0 | 39.0 | +0.0 | 233.0 | 34.0 |
| STAY WORTH | 18.7 | +24.3 | 256.7 | 0.0 | 17.3 | +117.5 | 176.3 | 0.0 |
| STRIKE BY THE ODDS | - | - | - | - | 1.0 | +12.2 | 0.0 | 48.0 |
| STUCK PIVOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 2.7 | +80.2 | 0.0 | 0.0 | 5.0 | +681.9 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 17.3 | 1.0 | +0.0 | 56.7 | 0.0 |
| SUPPORT WORKED OUT | 2.7 | +80.2 | 0.0 | 0.0 | 5.0 | +681.9 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 1.0 | +7.4 | 0.0 | 11.3 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +0.1 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 5.0 | +0.0 | 0.0 | 56.7 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 3.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE STEP BACK IS MADE | 2.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 44.0 | +0.0 | 0.0 | 119.7 | 45.0 | +0.0 | 0.0 | 29.7 |
| TIME ON OUR SIDE | 8.7 | +135.9 | 0.0 | 0.0 | 58.7 | +513.3 | 0.0 | 45.3 |
| WAITS AGAIN | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | - | - | - | - | 1.3 | +0.0 | 56.7 | 0.0 |
| WHO FIGHTS | 0.3 | +1.3 | 0.0 | 17.3 | 1.3 | -1.2 | 28.3 | 0.0 |
| WHOLE FIGHT DANGER | 1.3 | -52.3 | 0.0 | 0.0 | 1.0 | -244.8 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 3.7 | +317.9 | 0.0 | 0.0 | 2.0 | +214.5 | 0.0 | 0.0 |

### Rule changes: ccut-c940641-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| SHOT RISK POINTS | 275 | 269 | 103 | 34.33 | +2055 | +19.9 |
| HIS SHOTS BY HIS RUN | 286 | 275 | 102 | 34.00 | +1414 | +13.9 |
| HIS MOVE AS HE DECIDES | 142 | 142 | 100 | 33.33 | +0 | +0.0 |
| HIS SHOT LIST | 380 | 370 | 90 | 30.00 | +1085 | +12.1 |
| HOLDER ASSIGNMENT | 87 | 87 | 81 | 27.00 | +4216 | +52.0 |
| ARMY TABLE | 122 | 122 | 80 | 26.67 | +144 | +1.8 |
| DEPLOY BY FIGURES | 54 | 54 | 36 | 12.00 | +491 | +13.6 |
| FIVE ACTION | 580 | 561 | 28 | 9.33 | +1476 | +52.7 |
| THE TABLE AGAIN | 36 | 36 | 27 | 9.00 | +0 | +0.0 |
| HIS MOVE WHY | 63 | 63 | 25 | 8.33 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 23 | 23 | 23 | 7.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 202 | 173 | 23 | 7.67 | +48 | +2.1 |
| OFF BEST | 19 | 19 | 19 | 6.33 | -2986 | -157.1 |
| HARD STAY DROPPED | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| HIS ONE MOVE | 54 | 54 | 17 | 5.67 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 38 | 38 | 17 | 5.67 | -3513 | -206.7 |
| QUARTER ODDS | 109 | 102 | 14 | 4.67 | +1074 | +76.7 |
| LEGAL CHARGES ONLY | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| MEETS IN TIME | 19 | 19 | 13 | 4.33 | +889 | +68.4 |
| GOAL WALK | 56 | 53 | 12 | 4.00 | +753 | +62.7 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| STAY WORTH | 108 | 89 | 12 | 4.00 | +96 | +8.0 |
| MOVE TO CHARGE COMPUTED | 19 | 17 | 11 | 3.67 | +1804 | +164.0 |
| SHOOTS FROM THE BEST SPOT | 12 | 12 | 11 | 3.67 | +149 | +13.6 |
| ARTILLERY RE-ROLL WEIGHED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| CAST JOB | 12 | 12 | 10 | 3.33 | +17 | +1.7 |
| SUPPORT ADDS | 23 | 21 | 9 | 3.00 | +161 | +17.9 |
| SUPPORT WORKED OUT | 23 | 21 | 9 | 3.00 | +161 | +17.9 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 8 | 2.67 | +347 | +43.4 |
| THE RISK READS HIS RUN | 18 | 18 | 8 | 2.67 | +0 | +0.0 |
| MAX FOR POSITIONING | 11 | 9 | 7 | 2.33 | +5 | +0.8 |
| CASTER AWAY FROM SCREEN | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CASTING BLOCK | 6 | 6 | 6 | 2.00 | +45 | +7.5 |
| CHAFF IN THE MOVE | 8 | 8 | 6 | 2.00 | +1 | +0.2 |
| FOUR ROUNDS | 10 | 9 | 6 | 2.00 | +260 | +43.4 |
| MISSILES IN THE MOVE | 33 | 20 | 6 | 2.00 | +476 | +79.3 |
| NEXT CHARGE BY LIST | 12 | 11 | 6 | 2.00 | +930 | +155.0 |
| OGRE LOADER SECOND SHOT | 5 | 5 | 5 | 1.67 | +1 | +0.3 |
| WOUNDS ON THE RANKS | 17 | 16 | 5 | 1.67 | +352 | +70.3 |
| CHARGE LOSSES | 64 | 61 | 4 | 1.33 | +95 | +23.8 |
| FEATURE BUFFS | 47 | 47 | 4 | 1.33 | +24 | +5.9 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +350 | +87.5 |
| REDIRECT COUNTER | 19 | 15 | 4 | 1.33 | +183 | +45.8 |
| SHOTS IN THE MOVE | 72 | 51 | 4 | 1.33 | +295 | +73.8 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FALLS SHORT | 80 | 61 | 3 | 1.00 | +47 | +15.7 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +304 | +101.5 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +220 | +73.3 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 1.00 | +114 | +38.2 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SEARCH SPOT | 4 | 4 | 3 | 1.00 | +29 | +9.5 |
| SHOTS AFTER THE MOVES | 11 | 11 | 3 | 1.00 | +0 | +0.0 |
| STRIKE BY THE ODDS | 3 | 3 | 3 | 1.00 | +37 | +12.2 |
| CANNON SIGHT KEPT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| COVER ONCE | 26 | 15 | 2 | 0.67 | +43 | +21.4 |
| IDLE COST | 56 | 43 | 2 | 0.67 | +4 | +1.9 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +53 | +26.6 |
| MANOEUVRE | 15 | 15 | 2 | 0.67 | +68 | +34.2 |
| MARCH CHECK | 5 | 5 | 2 | 0.67 | +32 | +16.0 |
| ONE OBJECTIVE FORMULA | 44 | 32 | 2 | 0.67 | +74 | +37.1 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | -34 | -17.1 |
| PROMISE KNOWS THE FIGHT | 6 | 5 | 2 | 0.67 | -36 | -17.8 |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +90 | +44.9 |
| SET UP BY THE SET | 4 | 4 | 2 | 0.67 | +13 | +6.6 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CANNON PLANNED TARGET | 15 | 15 | 1 | 0.33 | +0 | +0.2 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -20 | -20.4 |
| CHARGE NOW FIRST | 6 | 6 | 1 | 0.33 | -94 | -94.3 |
| DEFENSIVE FLOOR | 1 | 1 | 1 | 0.33 | +36 | +35.8 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.33 | +40 | +39.7 |
| HIS MOVE AND SHOT | 22 | 22 | 1 | 0.33 | +0 | +0.0 |
| HIS TURN DENIED | 1 | 1 | 1 | 0.33 | +169 | +169.2 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +14 | +13.6 |
| NEARER NOT NEEDED | 39 | 34 | 1 | 0.33 | +16 | +15.7 |
| NO DOUBLE ROUNDS | 8 | 7 | 1 | 0.33 | +6 | +6.5 |
| OPENS A LANE | 3 | 2 | 1 | 0.33 | +2 | +1.7 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -2 | -1.6 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.33 | -162 | -161.5 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -1 | -0.8 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +110 | +110.2 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +14 | +13.6 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SHOT REPLANNED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SUPPORT NARROWED | 4 | 4 | 1 | 0.33 | -117 | -116.8 |
| SURE REACH TOGETHER | 3 | 2 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.2 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 3 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 10 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 61 | 59 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 12 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| EXACT ROUND | 8 | 7 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 8 | 8 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 4 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 32 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 15 | 13 | 0 | 0.00 | - | - |
| GUN FIGURES | 11 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 9 | 7 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 27 | 25 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 22 | 20 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 18 | 18 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 15 | 12 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 12 | 12 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 63 | 62 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 172 | 172 | 0 | 0.00 | - | - |
| HONEST WORTH | 9 | 8 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 25 | 25 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 6 | 6 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 8 | 7 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 14 | 14 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 32 | 18 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 6 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 2 | trace | - | - | - | - |
| MOVE SPELL SPOT | 7 | not checked | - | - | - | - |
| NO LATE CUT | 8 | 8 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| ONE FIGHT FORMULA | 27 | 12 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE ROUTE | 14 | 14 | 0 | 0.00 | - | - |
| PLAN RESULT | 261 | trace | - | - | - | - |
| REAL GROUND | 14 | 14 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 4 | 4 | 0 | 0.00 | - | - |
| RISK BY ARC | 4 | 3 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 3 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 6 | 5 | 0 | 0.00 | - | - |
| SAME TERRAIN AS THE BOARD | 1 | not checked | - | - | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 8 | 8 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 2 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 43 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 2 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 38 | 31 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 6 | 6 | 0 | 0.00 | - | - |
| STANDS STILL | 260 | 251 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 4 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 20 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 25 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 3 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 19 | not checked | - | - | - | - |
| THE TABLE BINDS | 267 | not checked | - | - | - | - |
| WAITS AGAIN | 7 | 7 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 4 | 4 | 0 | 0.00 | - | - |
| WHO FIGHTS | 5 | 5 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 7 | 7 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p2

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 2.67 | 3.00 | 206.7 |
| ARMY TABLE | rule | 0.33 | 5.00 | 89.5 |
| JOB FIRST | gate | 1.67 | 3.67 | 149.8 |
| HOLDER ASSIGNMENT | rule | 1.33 | 1.33 | 30.2 |
| NO REASON | gate | - | 0.67 | 17.9 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.67 | 17.8 |
| CHAFF PASSED | rule | 0.33 | - | 20.4 |
| CHARGE NOW FIRST | rule | - | 0.33 | 94.3 |
| PATHS CROSS | rule | - | 0.33 | 59.5 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 1.6 |
| PURSUES BIG PREY | rule | 0.33 | - | 161.5 |
| REFUSING RETIRES | rule | - | 0.33 | 0.8 |
| RULE SWITCHED OFF | gate | 0.33 | - | 553.0 |
| SUPPORT NARROWED | rule | - | 0.33 | 116.8 |

### Plans: ccut-c940641-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.7 | 50% | 18 | 28 | 156% |
| Mine | move | 35.7 | 98% | 2672 | 0 | 0% |
| Mine | shoot | 6.7 | 50% | 278 | 118 | 42% |
| Mine | support | 1.0 | 67% | 20 | 0 | 0% |
| Opponent | charge | 1.3 | 50% | 138 | 83 | 60% |
| Opponent | move | 38.7 | 97% | 2716 | 0 | 0% |
| Opponent | shoot | 2.7 | 62% | 155 | 95 | 61% |
| Opponent | support | 0.3 | 100% | 0 | 0 | 0% |

### Battle groups: ccut-c940641-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.3 | 15% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 2.0 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (2) | - | 0 (2) | - |
| Mine | Character | 11 | 10 (11) | 10 | 0 | 0 | 27% | 2.2 | - | 5 (6) | 15 (5) | 10 (11) | - |
| Mine | Clean-up | 2 | 226 (2) | 0 | 226 | 0 | 50% | 4.0 | 221 (1) | - | 231 (1) | 226 (2) | - |
| Mine | Fast Hammer | 10 | 21 (10) | 21 | 0 | 55 | 70% | 3.7 | 41 (6) | 0 (1) | 0 (3) | 0 (7) | 74 (3) |
| Mine | Hammer | 9 | 51 (9) | 18 | 33 | 0 | 33% | 3.2 | 0 (2) | 62 (4) | 83 (3) | 51 (9) | - |
| Mine | Holder | 2 | 0 (2) | 0 | 0 | 0 | 50% | 6.0 | 0 (1) | - | 0 (1) | - | 0 (2) |
| Mine | War machine | 4 | 0 (4) | 0 | 0 | 0 | 0% | 1.2 | 0 (4) | - | - | - | 0 (4) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 75% | 1.0 | 0 (2) | 0 (1) | 0 (1) | 0 (2) | 0 (2) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 8 | 53 (8) | 0 | 53 | 59 | 62% | 4.3 | 109 (3) | 0 (4) | 0 (1) | 59 (7) | 0 (1) |
| Opponent | Character | 7 | 4 (7) | 4 | 0 | 14 | 0% | 2.0 | 0 (1) | 8 (4) | 0 (1) | 5 (4) | 3 (2) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 0 | 67% | 5.0 | - | 0 (3) | - | 0 (3) | - |
| Opponent | Fast Hammer | 1 | 0 (1) | 0 | 0 | 0 | 0% | 3.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Hammer | 10 | 54 (10) | 14 | 40 | 6 | 30% | 2.6 | 9 (5) | 100 (4) | 68 (1) | 20 (5) | 79 (5) |
| Opponent | Shooter | 4 | 63 (4) | 0 | 63 | 27 | 0% | 1.5 | 0 (1) | 110 (2) | 21 (1) | 51 (3) | 105 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 3.0 | - | 0 (2) | - | 0 (2) | - |

### Charged fights: ccut-c940641-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 62 | 70 | 1.0 | 1.0 | 70 | 26 | +44 | 1 of 2 | 1 of 2 | - | +44 |
| Mine | Chaos Dwarfs | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 42 | 47 | 0.7 | 1.0 | 70 | 26 | +44 | 1 of 2 | 1 of 2 | - | +44 |
| Opponent | Ogre Kingdoms | 1 | 170 | 0 | 1.0 | 1.0 | 0 | 34 | -34 | 1 of 1 | 0 of 1 | - | -34 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 0 | 6.0 | 1.0 | 0 | 62 | -62 | 5 of 6 | 3 of 6 | - | -62 |
| Opponent | Wood Elf Realms | 1 | 52 | 85 | 2.0 | 1.0 | 42 | 0 | +42 | 0 of 2 | 2 of 2 | - | +42 |
| **Opponent** | all armies | 3 | 74 | 28 | 3.0 | 1.0 | 9 | 45 | -36 | 6 of 9 | 5 of 9 | - | -36 |

### Effective charges: ccut-c940641-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 1 (net -52) | 0 | 1 (net +140) | 0 | 0 | 0 | 0 | 50% (1 of 2) |
| Opponent | Orc & Goblin Tribes | 6 | 2 (net +0) | 0 | 0 | 0 | 0 | 0 | 4 | 0% (0 of 2) |
| Opponent | Wood Elf Realms | 2 | 0 | 0 | 1 (net +85) | 1 (net +0) | 0 | 0 | 0 | 50% (1 of 2) |

### Charged fights, damage counted: ccut-c940641-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 52 | 297 | -52 | 50 | 52 | -2 | -4.8 |
| Mine | Effective (55-75%) | 1 | 52 | 140 | +140 | 140 | 0 | +140 | +269.2 |
| Mine | All fights | 2 | 52 | 218 | +44 | 95 | 26 | +69 | +132.2 |
| Opponent | Long shot (under 50%) | 2 | 302 | 312 | +0 | 44 | 120 | -76 | -25.1 |
| Opponent | Effective (55-75%) | 1 | 125 | 85 | +85 | 85 | 36 | +49 | +39.4 |
| Opponent | 76-89% | 1 | 126 | 84 | +0 | 30 | 21 | +9 | +7.1 |
| Opponent | No odds | 5 | 169 | 260 | -81 | 50 | 81 | -31 | -18.4 |
| Opponent | All fights | 9 | 189 | 233 | -36 | 50 | 78 | -28 | -14.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p2 | move | 20 | 2 (10%) | 1 (5%) | 3 (15%) | 15 (75%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Elixir of Power | Opponent | L0319 |
| Fistful of Laurels | Opponent | L0218 |
| Ring of Doom | Mine | L0218, L0235 |

# Doctrine scorecard: ccut-c940641-p39

### Scorecard: ccut-c940641-p39

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0409 | 1 | 1 | Mine | no | 11 | 3 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 3 | - | 0 | 2 | 0 | 0 | 0 | 295 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 1 | 4 | 0 | 0 | 0 | 65 |
| L0425 | 5 | 1 | Opponent | no | - | 4 | 4 | 5 | 0 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 503 |
| L0512 | 2 | 1 | Opponent | - | - | 5 | 1 | 0 | 0 | 0 | 0 | 165 |
| **Average** | | | Mine | 50% | 11.0 | 2.5 | 0.3 | 2.7 | 0.0 | 0.0 | 0.0 | 189.3 |
| **Average** | | | Opponent | 0% | 3.0 | 4.5 | 1.7 | 2.3 | 0.0 | 0.0 | 0.0 | 153.3 |

### KPIs: ccut-c940641-p39

Rules off - Opponent only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 8) | 0% (0 of 12) | 0% (0 of 20) |
| Winner chose to follow up after the loser gave ground |  | 100% (5 of 5); on the table 100% | 100% (1 of 1); on the table 100% | 100% (6 of 6); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 100% (5 of 5); on the table 100% | 100% (2 of 2); on the table 100% | 100% (7 of 7); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 67% (8 of 12) | 56% (20 of 36) | 58% (28 of 48) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 73% (8 of 11) | 57% (20 of 35) | 61% (28 of 46) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 67% (4005 of 5998) | 70% (4198 of 5998) | 68% (8203 of 11996) |
|   infantry points that never fought | lower | 83% (1185 of 1424) | 100% (1187 of 1187) | 91% (2372 of 2611) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 65% (15 of 23) | 74% (20 of 27) | 70% (35 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (3 of 3); 3.3 uses a game | 100% (3 of 3); 1.7 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 64% (3257 of 5120) | 80% (4377 of 5442) | 72% (7634 of 10562) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (50%) | 3.3 (62%) | 4.0 (60%) |
| MARCHED: its unit marched | 0.3 (25%) | 1.7 (31%) | 2.0 (30%) |
| IN COMBAT: engaged in combat | 0.3 (25%) | 0.3 (6%) | 0.7 (10%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 7.0 | 1.7 | 2.0 | 9.3 | 0.7 | 0.3 |
| not cast | 3.0 | 4.3 | 4.0 | 6.7 | 1.3 | 19.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.3 (77%) | 3.0 (75%) | 4.0 (60%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (30%) | 0.3 (25%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (15%) | 0.3 (8%) | 0.7 (10%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (25%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (8%) | 0.3 (8%) | 0.0 (0%) | 0.7 (50%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.0 (100%) | 0.0 (0%) | 0.3 (8%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.0 (92%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.3 a game | 1.7 a game | 1.0 a game |
| stood (cast and not dispelled) | 100% (1 of 1) | 80% (4 of 5) | 83% (5 of 6) |
| the unit moved after it | 0% (0 of 1) | 100% (4 of 4) | 80% (4 of 5) |
| it charged on its next turn | 0% (0 of 1) | 25% (1 of 4) | 20% (1 of 5) |
| the enemy charged it first | 0% (0 of 1) | 0% (0 of 4) | 0% (0 of 5) |
| it fought by the end of its next turn | 0% (0 of 1) | 0% (0 of 4) | 0% (0 of 5) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 1) | 0% (0 of 4) | 0% (0 of 5) |
| none of these (no charge, no fight, no charge escaped) | 100% (1 of 1) | 75% (3 of 4) | 80% (4 of 5) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 68% (65 of 96) | 54% (38 of 71) | 62% (103 of 167) |
|   cavalry | 50% (6 of 12) | - | 50% (6 of 12) |
|   character | 90% (19 of 21) | 100% (2 of 2) | 91% (21 of 23) |
|   chariot | 29% (7 of 24) | 40% (2 of 5) | 31% (9 of 29) |
|   infantry | 58% (7 of 12) | 43% (12 of 28) | 48% (19 of 40) |
|   monster | - | 67% (4 of 6) | 67% (4 of 6) |
|   war machine | 96% (26 of 27) | 60% (18 of 30) | 77% (44 of 57) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (23%) | 1.7 (15%) | 4.0 (19%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.7 (6%) | 0.7 (3%) |
| NO TARGET IN RANGE | 5.3 (52%) | 1.3 (12%) | 6.7 (31%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 2.7 (24%) | 2.7 (12%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.3 (23%) | 1.7 (15%) | 4.0 (19%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 3.0 (27%) | 3.0 (14%) |
| STUPIDITY | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.0 | 0.3 | 83% | 10.0 pts | 20 pts |
| character | 7.7 | 1.0 | 87% | 5.4 pts | 41 pts |
| chariot | 3.0 | 2.3 | 56% | 5.9 pts | 18 pts |
| infantry | 9.3 | 1.0 | 89% | 4.8 pts | 45 pts |
| monster | 2.7 | 0.3 | 88% | 8.6 pts | 23 pts |
| war machine | 14.7 | 16.0 | 61% | 33.5 pts | 491 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.0 | 2.3 | 1.7 |
| Charges that made contact a game | 0.7 | 1.3 | 1.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.50 declared, 0.50 contact (2 units) | 0.33 declared, 0.33 contact (3 units) | 0.40 declared, 0.40 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 1.00 contact (1 units) | 1.00 declared, 1.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.09 declared, 0.04 contact (23 units) | 0.28 declared, 0.11 contact (18 units) | 0.17 declared, 0.07 contact (41 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | 100% (2 of 2) | - | 67% (4 of 6) |
| Character in a unit | 100% (5 of 5) | 100% (2 of 2) | - | 100% (7 of 7) |
| Character on its own | 100% (2 of 2) | 60% (3 of 5) | 75% (3 of 4) | 73% (8 of 11) |
| Chariot | - | 80% (4 of 5) | - | 80% (4 of 5) |
| Infantry | 50% (6 of 12) | 67% (2 of 3) | - | 53% (8 of 15) |
| Monstrous | - | 100% (1 of 1) | - | 100% (1 of 1) |
| War Machines | 60% (3 of 5) | - | - | 60% (3 of 5) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 2 | 100% (5 of 5); on the table 100% | 67% (8 of 12) | 71% | 56% (9 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Dwarfen Mountain Holds | 1 | - | - | 58% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | 100% (1 of 1); on the table 100% | 25% (3 of 12) | 87% | 75% (9 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 67% (12 of 18) | 73% | 56% (5 of 9) | 100% (3 of 3); 10.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Vampire Counts | 1 | 100% (1 of 1); on the table 100% | 83% (5 of 6) | 50% | 100% (6 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p39, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (2) | 50% (1) | 75% (3) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: ccut-c940641-p39

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 67% (2 of 3) | 60% (3 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 38% (18 of 47) | 51% (20 of 39) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 50% (2 of 4) | 14% (1 of 7) |
| Strategy | Lone characters that fought | 43% (3 of 7) | 43% (3 of 7) |
| Movement | Charges halted short of contact | 0.3 | 1.0 |
| Movement | Idle units | 2.7 | 2.3 |
| Movement | Points that never moved of their own | 189.3 | 153.3 |
| Movement | Fights charged into per game | 0.7 | 1.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 1 | 0 of 2 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 1 | 1 of 2, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 1 | 0 of 2 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 1, net +265 | 0 of 2 |
| Shooting | Shots by shooting units (incl. breath weapons) | 14.0 | 6.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 62% (26 of 42) | 80% (16 of 20) |
| Shooting | Points destroyed by shooting units | 15.0 | 0.0 |
| Shooting | War machine shots | 8.7 | 6.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 73% (19 of 26) | 22% (4 of 18) |
| Shooting | Points destroyed by war machines | 126.3 | 68.0 |
| Magic | Magic missiles cast | 1.3 | 3.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 50% (2 of 4) | 80% (8 of 10) |
| Magic | Wounds caused by magic missiles | 4.3 | 2.3 |
| Magic | Points destroyed by magic (all spells) | 84.7 | 76.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.3 / 0.0 / 0.0 / 0.0 | 1.3 / 0.3 / 0.3 / 0.3 |
| Combat | Points destroyed in combat | 88.3 | 63.3 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +36 | +12 |
| Combat | Net per 100 charger points, damage counted | +8.7 | +4.1 |
| Combat | First round won (charged fights) | 50% | 50% |
| Combat | Net points per charged fight | +132 | +48 |
| Combat | Net points per supported fight / lone fight | - / +132 | - / +48 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 2 | 2 of 4 |
| Game | Points lost | 208.0 | 314.3 |
| Game | VP from objectives | 830.0 | 510.0 |
| Game | Lone holders (player turns) | 11.0 | 3.0 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +526 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 522
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ccut-c940641-p39

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +7.1 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 14.0 | +88.6 | 0.0 | 0.0 | 20.3 | +44.0 | 0.0 | 30.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.7 | +6.5 | 0.0 | 0.0 | 0.3 | +1.6 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 8.0 | +98.9 | 126.3 | 63.3 | 6.3 | +151.5 | 299.7 | 0.0 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 2.3 | +130.7 | 0.0 | 0.0 | 5.3 | +46.7 | 156.0 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 1.3 | +29.8 | 0.0 | 21.7 | - | - | - | - |
| CHALLENGE BY POINTS | 0.7 | +6.8 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 3.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 13.7 | -449.7 | 0.0 | 185.3 | 16.0 | -732.5 | 0.0 | 505.3 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 31.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.3 | +34.2 | 0.0 | 0.0 | 0.7 | +50.2 | 0.0 | 0.0 |
| COVER ONCE | 9.3 | -417.3 | 0.0 | 108.3 | 4.3 | -331.4 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 1.3 | -10.7 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 8.7 | +61.0 | 0.0 | 0.0 | 6.3 | +5.3 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -1.4 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | - | - | - | - | 2.0 | +24.7 | 63.3 | 0.0 |
| FALL BACK GOOD ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 31.7 | 0.0 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | 6.3 | +108.6 | 0.0 | 0.0 | 19.7 | +124.9 | 0.0 | 731.3 |
| FEATURE BUFFS | 0.7 | +0.6 | 0.0 | 0.0 | 0.7 | +13.1 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +34.7 | 0.0 | 0.0 | 1.3 | +9.7 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 103.7 | +5317.4 | 1072.0 | 508.7 | 98.3 | +3072.7 | 818.7 | 874.0 |
| FLANK NOT WEIGHED | 5.0 | +0.0 | 0.0 | 76.7 | 3.0 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 1.3 | +248.8 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 1.0 | +143.6 | 0.0 | 0.0 | 2.3 | +192.9 | 63.3 | 0.0 |
| FREED FROM HIS FIGHT | 2.7 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.3 | -2.1 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.3 | -9.5 | 0.0 | 0.0 |
| GOAL WALK | 11.3 | +897.3 | 0.0 | 0.0 | 6.3 | +347.9 | 0.0 | 169.3 |
| GUN FIGURES | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| GUN MASK | 0.7 | +32.7 | 0.0 | 0.0 | 0.7 | +62.8 | 0.0 | 0.0 |
| HARD STAY DROPPED | 3.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.7 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 4.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +48.4 | 0.0 | 0.0 |
| HIS CHARGE LIST | 7.3 | +0.0 | 0.0 | 75.3 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.7 | -19.6 | 0.0 | 46.3 | 1.7 | -30.1 | 0.0 | 15.0 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 43.0 | +16.0 | 289.3 | 0.0 |
| HIS MOVE WHY | 16.7 | +0.0 | 0.0 | 92.7 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 17.0 | -1.7 | 0.0 | 0.0 |
| HIS ONE QUARTER | 4.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 3.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 47.3 | +3335.7 | 0.0 | 382.0 | 53.0 | +4248.1 | 0.0 | 844.0 |
| HIS SHOTS BY HIS RUN | 29.3 | +483.6 | 0.0 | 382.0 | 36.3 | +707.6 | 0.0 | 535.3 |
| HIS TURN DENIED | 0.3 | +12.8 | 0.0 | 0.0 | 1.3 | +50.7 | 31.7 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 16.7 | +0.0 | 0.0 | 0.0 | 12.0 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 9.3 | +884.1 | 0.0 | 0.0 | 8.7 | +635.2 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -56.6 | 0.0 | 0.0 | 2.3 | -120.5 | 63.3 | 0.0 |
| HUNT IN PAIRS | 0.3 | +37.8 | 0.0 | 0.0 | 0.7 | +114.3 | 0.0 | 0.0 |
| IDLE COST | 5.3 | -94.5 | 0.0 | 92.7 | 13.7 | -203.8 | 0.0 | 422.0 |
| KEPT FROM ITS LAST STOP | 3.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +64.9 | 0.0 | 0.0 | - | - | - | - |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 3.3 | +0.0 | 176.7 | 0.0 | 1.7 | +0.0 | 0.0 | 176.7 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.7 | +30.1 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | - | - | - | - | 2.3 | +0.6 | 63.3 | 0.0 |
| MANOEUVRE | 2.3 | -35.0 | 0.0 | 0.0 | 3.0 | -4.1 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +12.8 | 0.0 | 0.0 | 2.7 | +185.9 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 1.0 | +23.6 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.7 | +38.3 | 0.0 | 0.0 | 1.3 | +17.0 | 0.0 | 0.0 |
| MEETS IN TIME | 5.3 | +153.6 | 0.0 | 0.0 | 2.3 | +33.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.3 | +162.3 | 0.0 | 0.0 | 10.3 | +87.4 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 3.0 | +79.0 | 0.0 | 0.0 | 12.0 | +117.4 | 0.0 | 126.3 |
| MOVE ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 3.7 | +138.7 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.7 | -1.7 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.3 | +130.7 | 0.0 | 0.0 | 1.3 | +61.1 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 9.7 | +419.5 | 0.0 | 0.0 | 9.3 | +407.9 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 0.7 | +29.9 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 0.7 | -64.2 | 0.0 | 0.0 | 1.7 | -142.1 | 63.3 | 0.0 |
| NO LATE CUT | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT TURNED | 0.3 | +10.7 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 2.0 | -89.7 | 0.0 | 0.0 | 5.0 | -150.0 | 0.0 | 88.3 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 2.0 | -57.3 | 0.0 | 0.0 | 2.0 | -34.0 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 3.3 | -86.5 | 0.0 | 0.0 | 4.7 | -132.1 | 0.0 | 0.0 |
| ONE ROUTE | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | - | - | - | - | 1.0 | +13.3 | 43.3 | 0.0 |
| OPENS UP | 0.3 | +16.7 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| PATHS CROSS | 0.3 | +9.4 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -11.1 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 46.3 | +426.6 | 371.0 | 416.0 | 44.7 | +525.9 | 317.0 | 367.3 |
| PROMISE BY ITS OWN SUM | 7.3 | -276.4 | 0.0 | 0.0 | 2.7 | -57.2 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.3 | -2.1 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | - | - | - | - | 0.3 | -0.8 | 39.0 | 0.0 |
| QUARTER ODDS | 17.7 | +1670.2 | 0.0 | 0.0 | 18.3 | +1208.0 | 0.0 | 0.0 |
| REAL GROUND | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.7 | -12.5 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 0.3 | -0.2 | 0.0 | 21.7 | 0.3 | +52.9 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 0.7 | +3.5 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 15.0 |
| REFORMS TO MEET IT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | -1.1 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +1.5 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.0 | -21.7 | 0.0 | 0.0 | 2.0 | -84.0 | 31.7 | 0.0 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RUN DOWN | - | - | - | - | 1.3 | -11.7 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.3 | -32.0 | 0.0 | 0.0 | 1.3 | -39.2 | 0.0 | 30.0 |
| SEARCH SPOT | 1.3 | +19.9 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.7 | +10.0 | 31.7 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +19.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 17.0 | +0.0 | 0.0 | 63.3 | 14.0 | +0.0 | 0.0 | 15.0 |
| SHOOTS FROM THE BEST SPOT | 6.7 | +315.4 | 314.0 | 0.0 | 3.3 | +17.2 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -0.5 | 0.0 | 0.0 |
| SHOT RISK POINTS | 25.3 | +379.1 | 0.0 | 382.0 | 28.3 | -128.6 | 0.0 | 704.7 |
| SHOTS AFTER THE MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 18.3 | +474.4 | 0.0 | 101.0 | 16.7 | +580.5 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +19.1 | 0.0 | 0.0 |
| SPELL WORTH | 0.3 | +1.7 | 0.0 | 0.0 | 2.0 | +52.8 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.7 | +6.2 | 63.3 | 0.0 |
| SPOT AS THE GAME MOVES | 4.0 | +0.0 | 0.0 | 46.3 | 5.7 | +0.0 | 0.0 | 84.7 |
| STAND AND SHOOT | 0.3 | -3.0 | 0.0 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | - | - | - | - | 2.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 63.0 | +0.0 | 1072.0 | 202.0 | 46.3 | +0.0 | 755.3 | 505.3 |
| STAY WORTH | 32.0 | -10.1 | 252.7 | 37.7 | 28.7 | -181.0 | 755.3 | 0.0 |
| STUBBORN BY POINTS | 0.3 | +52.3 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 1.7 | +61.0 | 0.0 | 0.0 | 5.3 | +117.3 | 0.0 | 30.0 |
| SUPPORT WORKED OUT | 1.7 | +61.0 | 0.0 | 0.0 | 5.3 | +117.3 | 0.0 | 30.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.7 | +0.0 | 0.0 | 92.7 | 4.0 | +0.0 | 0.0 | 84.7 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.7 | +0.0 | 0.0 | 92.7 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 51.3 | +0.0 | 0.0 | 254.3 | 46.3 | +0.0 | 0.0 | 452.0 |
| TIED UP BY THE SUM | 0.3 | +29.1 | 0.0 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 45.3 | +409.3 | 535.3 | 173.7 | 16.3 | +165.9 | 0.0 | 0.0 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.7 | +11.7 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 1.3 | -46.1 | 0.0 | 0.0 | 1.7 | -161.0 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 3.7 | +92.4 | 0.0 | 0.0 | 1.3 | +6.0 | 0.0 | 0.0 |

### Rule changes: ccut-c940641-p39

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 129 | 129 | 81 | 27.00 | +0 | +0.0 |
| ARMY TABLE | 103 | 103 | 70 | 23.33 | +690 | +9.9 |
| HIS SHOT LIST | 301 | 288 | 64 | 21.33 | +1814 | +28.4 |
| HOLDER ASSIGNMENT | 54 | 54 | 52 | 17.33 | +3578 | +68.8 |
| HIS SHOTS BY HIS RUN | 197 | 190 | 44 | 14.67 | +336 | +7.6 |
| HIS MOVE WHY | 50 | 50 | 33 | 11.00 | +0 | +0.0 |
| SHOT RISK POINTS | 161 | 154 | 28 | 9.33 | +1065 | +38.0 |
| TIME ON OUR SIDE | 185 | 173 | 25 | 8.33 | +75 | +3.0 |
| DEPLOY BY FIGURES | 45 | 45 | 22 | 7.33 | +460 | +20.9 |
| SHOOTS FROM THE BEST SPOT | 30 | 30 | 22 | 7.33 | +204 | +9.3 |
| OFF BEST | 21 | 21 | 21 | 7.00 | -720 | -34.3 |
| THE TABLE AGAIN | 36 | 36 | 21 | 7.00 | +0 | +0.0 |
| HIS ONE MOVE | 51 | 51 | 19 | 6.33 | +0 | +0.0 |
| QUARTER ODDS | 108 | 101 | 19 | 6.33 | +718 | +37.8 |
| ARTILLERY RE-ROLL WEIGHED | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| FIVE ACTION | 606 | 588 | 15 | 5.00 | +585 | +39.0 |
| LEGAL CHARGES ONLY | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| CAST JOB | 23 | 23 | 14 | 4.67 | +88 | +6.3 |
| HARD STAY DROPPED | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 30 | 30 | 14 | 4.67 | -1001 | -71.5 |
| CHARGE LOSSES | 89 | 85 | 13 | 4.33 | +530 | +40.8 |
| STAY WORTH | 182 | 173 | 12 | 4.00 | +101 | +8.4 |
| GOAL WALK | 53 | 53 | 11 | 3.67 | +598 | +54.4 |
| MEETS IN TIME | 23 | 23 | 10 | 3.33 | +383 | +38.3 |
| MOVE ORDER | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| MARCH CHECK | 9 | 9 | 9 | 3.00 | +253 | +28.1 |
| SUPPORT ADDS | 21 | 21 | 8 | 2.67 | +89 | +11.1 |
| SUPPORT WORKED OUT | 21 | 21 | 8 | 2.67 | +89 | +11.1 |
| IDLE COST | 57 | 48 | 7 | 2.33 | +26 | +3.7 |
| COVER ONCE | 41 | 31 | 6 | 2.00 | +88 | +14.7 |
| MOVE TO CHARGE COMPUTED | 11 | 10 | 6 | 2.00 | +227 | +37.8 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| OGRE LOADER SECOND SHOT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CANNON SIGHT KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 4 | 4 | 4 | 1.33 | +53 | +13.2 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +746 | +186.5 |
| FOUR ROUNDS | 10 | 8 | 4 | 1.33 | +147 | +36.6 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +195 | +48.6 |
| NEARER NOT NEEDED | 57 | 57 | 4 | 1.33 | +197 | +49.3 |
| REDIRECT FOR A FRIEND IN REACH | 5 | 5 | 4 | 1.33 | +4 | +1.1 |
| CANNON PLANNED TARGET | 43 | 43 | 3 | 1.00 | +0 | +0.0 |
| GUN MASK | 4 | 4 | 3 | 1.00 | +100 | +33.4 |
| SEARCH SPOT | 5 | 5 | 3 | 1.00 | +100 | +33.2 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +6 | +2.0 |
| THE RISK READS HIS RUN | 18 | 18 | 3 | 1.00 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 22 | 3 | 3 | 1.00 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 15 | 15 | 3 | 1.00 | +30 | +10.1 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +20 | +10.1 |
| CHARGE NOW FIRST | 6 | 6 | 2 | 0.67 | -130 | -65.0 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FALLS SHORT | 78 | 73 | 2 | 0.67 | +26 | +12.8 |
| FIGHT TO THE END | 6 | 6 | 2 | 0.67 | +19 | +9.5 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +90 | +45.1 |
| MANOEUVRE | 16 | 16 | 2 | 0.67 | +9 | +4.5 |
| MISSILES IN THE MOVE | 38 | 33 | 2 | 0.67 | +65 | +32.3 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +28 | +14.1 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +30 | +15.1 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +35 | +17.5 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +21 | +21.2 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS CHARGE DENIED | 1 | 1 | 1 | 0.33 | +71 | +71.4 |
| HIS TURN DENIED | 5 | 4 | 1 | 0.33 | +17 | +17.0 |
| MAX FOR POSITIONING | 9 | 8 | 1 | 0.33 | +16 | +16.3 |
| NEXT CHARGE BY LIST | 2 | 2 | 1 | 0.33 | +72 | +71.7 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +33 | +33.2 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -33 | -33.3 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -2 | -2.3 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +4 | +4.4 |
| RISK BY ARC | 9 | 7 | 1 | 0.33 | +33 | +33.2 |
| SHOTS AFTER THE MOVES | 20 | 20 | 1 | 0.33 | +0 | +0.0 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +157 | +156.7 |
| TIED UP BY THE SUM | 1 | 1 | 1 | 0.33 | +33 | +33.2 |
| BACKUP TARGETS | 3 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 4 | trace | - | - | - | - |
| CHARACTER GUNS | 11 | 11 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 39 | 38 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 4 | 3 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 6 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 9 | 8 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 24 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 23 | 18 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 3 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 23 | 18 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 24 | 23 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 40 | 40 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 12 | 11 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 16 | 14 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 22 | 20 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 13 | 12 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 86 | 84 | 0 | 0.00 | - | - |
| HONEST WORTH | 10 | 8 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 3 | 3 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 19 | 18 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LOST AFTER ESCAPE | 7 | 5 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 10 | 9 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 45 | 41 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 11 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 2 | trace | - | - | - | - |
| NO DOUBLE ROUNDS | 7 | 6 | 0 | 0.00 | - | - |
| NO LATE CUT | 8 | 7 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 5 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 12 | 9 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 24 | 17 | 0 | 0.00 | - | - |
| ONE ROUTE | 10 | 9 | 0 | 0.00 | - | - |
| OPENS A LANE | 3 | 2 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 273 | trace | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 10 | 9 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 2 | 2 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 4 | 3 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 5 | 5 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 93 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | not checked | - | - | - | - |
| SHOTS IN THE MOVE | 105 | 88 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 7 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 29 | 27 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 7 | 0 | 0.00 | - | - |
| STANDS STILL | 328 | 319 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 11 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 20 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 1 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 14 | not checked | - | - | - | - |
| THE TABLE BINDS | 293 | not checked | - | - | - | - |
| WAITS AGAIN | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 9 | 9 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p39

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| ARMY TABLE | rule | 2.67 | 2.00 | 56.7 |
| JOB FIRST | gate | 1.67 | 3.00 | 36.3 |
| PROMISE BY ITS OWN SUM | rule | 3.33 | 1.33 | 71.5 |
| RULE SWITCHED OFF | gate | - | 1.67 | 10.3 |
| HOLDER ASSIGNMENT | rule | 0.33 | 1.00 | 12.6 |
| CHARGE NOW FIRST | rule | 0.33 | 0.33 | 65.0 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.33 | 147.3 |
| NO REASON | gate | 0.33 | - | 12.5 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 33.3 |
| PROMISE SHOT AWAY | rule | - | 0.33 | 2.3 |

### Plans: ccut-c940641-p39

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 33% | 96 | 20 | 21% |
| Mine | join | 0.7 | 100% | 23 | 0 | 0% |
| Mine | move | 31.7 | 96% | 1802 | 0 | 0% |
| Mine | shoot | 12.7 | 53% | 366 | 406 | 111% |
| Mine | support | 0.3 | 100% | 0 | 0 | - |
| Opponent | charge | 1.7 | 40% | 114 | 85 | 75% |
| Opponent | join | 1.7 | 100% | 93 | 0 | 0% |
| Opponent | move | 29.7 | 99% | 876 | 0 | 0% |
| Opponent | shoot | 11.0 | 67% | 373 | 441 | 118% |
| Opponent | support | 0.7 | 50% | 0 | 0 | - |

### Battle groups: ccut-c940641-p39

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 0.3 | 100% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p39

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Character | 11 | 20 (11) | 20 | 0 | 9 | 18% | 2.3 | 26 (8) | 0 (3) | - | 27 (8) | 0 (3) |
| Mine | Clean-up | 6 | 102 (6) | 0 | 102 | 0 | 83% | 5.0 | 16 (3) | 185 (2) | 250 (1) | 125 (5) | 0 (1) |
| Mine | Fast Hammer | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Hammer | 6 | 3 (6) | 3 | 0 | 0 | 50% | 2.7 | 0 (2) | 5 (4) | - | 0 (5) | 15 (1) |
| Mine | Holder | 2 | 11 (2) | 0 | 11 | 50 | 100% | - | 22 (1) | 0 (1) | - | 11 (2) | - |
| Mine | Shooter | 2 | 63 (2) | 0 | 63 | 0 | 0% | 2.0 | 126 (1) | 0 (1) | - | 63 (2) | - |
| Mine | War machine | 5 | 80 (5) | 80 | 0 | 40 | 0% | 1.2 | 199 (2) | 0 (1) | 0 (2) | - | 80 (5) |
| Opponent | Chaff | 4 | 0 (4) | 0 | 0 | 18 | 100% | - | 0 (4) | - | - | 0 (3) | 0 (1) |
| Opponent | Character | 9 | 11 (9) | 11 | 0 | 0 | 33% | 4.0 | 0 (3) | 20 (5) | 0 (1) | 13 (6) | 0 (3) |
| Opponent | Clean-up | 2 | 0 (2) | 0 | 0 | 57 | 100% | - | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 1 | 0 (1) | 0 | 0 | 0 | 0% | 3.0 | 0 (1) | - | - | - | 0 (1) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 38 | 33% | 1.5 | - | 0 (3) | - | 0 (2) | 0 (1) |
| Opponent | Holder | 3 | 155 (3) | 43 | 112 | 0 | 33% | 4.5 | - | 163 (2) | 137 (1) | 229 (2) | 0 (1) |
| Opponent | Shooter | 3 | 58 (3) | 0 | 58 | 0 | 0% | 1.0 | - | 87 (1) | 43 (2) | 87 (2) | 0 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | War machine | 5 | 29 (5) | 29 | 0 | 0 | 0% | 1.4 | - | - | 29 (5) | - | 29 (5) |
| Opponent | Wizard | 5 | 0 (5) | 0 | 0 | 48 | 40% | 2.0 | 0 (3) | 0 (2) | - | 0 (2) | 0 (3) |

### Charged fights: ccut-c940641-p39

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 150 | 132 | 1.0 | 1.0 | 132 | 0 | +132 | 2 of 2 | 1 of 2 | - | +132 |
| Mine | Dwarfen Mountain Holds | 1 | 379 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 226 | 88 | 0.7 | 1.0 | 132 | 0 | +132 | 2 of 2 | 1 of 2 | - | +132 |
| Opponent | Empire of Man | 1 | 139 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 295 | 190 | 3.0 | 1.0 | 63 | 0 | +63 | 1 of 3 | 2 of 3 | - | +63 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| **Opponent** | all armies | 3 | 145 | 63 | 1.3 | 1.0 | 48 | 0 | +48 | 2 of 4 | 2 of 4 | - | +48 |

### Effective charges: ccut-c940641-p39

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +265) | 1 | 0% (0 of 1) |
| Opponent | Grand Cathay | 3 | 0 | 0 | 0 | 1 (net +95) | 0 | 0 | 2 | 0% (0 of 1) |
| Opponent | Vampire Counts | 1 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 100% (1 of 1) |

### Charged fights, damage counted: ccut-c940641-p39

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 339 | 265 | +265 | 265 | 194 | +71 | +21.0 |
| Mine | No odds | 1 | 480 | 348 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | All fights | 2 | 410 | 306 | +132 | 132 | 97 | +36 | +8.7 |
| Opponent | Effective (55-75%) | 1 | 480 | 339 | +0 | 145 | 360 | -215 | -44.7 |
| Opponent | 76-89% | 1 | 205 | 95 | +95 | 95 | 0 | +95 | +46.3 |
| Opponent | No odds | 2 | 270 | 167 | +48 | 85 | 0 | +85 | +31.5 |
| Opponent | All fights | 4 | 306 | 192 | +48 | 102 | 90 | +12 | +4.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p39 | move | 9 | 1 (11%) | 1 (11%) | 1 (11%) | 7 (78%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0425 |
| Clockwork Compass | Opponent | L0512 |
| Invocation of Nehek | Opponent | L0425 |
| Ring of Doom | Opponent | L0512 |
| Ring of Jet | Opponent | L0512 |

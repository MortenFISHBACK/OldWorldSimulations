# Doctrine scorecard: ccut-c940641-p18

### Scorecard: ccut-c940641-p18

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0918 | 6 | 1 | Mine | no | 2 | 6 | 1 | 1 | 0 | 0 | 0 | 250 |
| L0918 | 6 | 1 | Opponent | no | 4 | - | 2 | 3 | 1 | 0 | 0 | 185 |
| L0934 | 4 | 1 | Mine | no | 0 | 5 | 0 | 1 | 0 | 0 | 0 | 524 |
| L0934 | 4 | 1 | Opponent | no | 0 | 3 | 3 | 6 | 0 | 0 | 0 | 500 |
| L1026 | 6 | 1 | Mine | no | 12 | 3 | 2 | 0 | 0 | 0 | 0 | 165 |
| L1026 | 6 | 1 | Opponent | no | 2 | 4 | 3 | 4 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 4.7 | 4.7 | 1.0 | 0.7 | 0.0 | 0.0 | 0.0 | 313.0 |
| **Average** | | | Opponent | 0% | 2.0 | 3.5 | 2.7 | 4.3 | 0.3 | 0.0 | 0.0 | 228.3 |

### KPIs: ccut-c940641-p18

Rules off - Mine only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 64% (7 of 11) | 0% (0 of 14) | 28% (7 of 25) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 67% (2 of 3); on the table 67% | 67% (2 of 3); on the table 67% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 100% (1 of 1); on the table 100% | 75% (3 of 4); on the table 75% | 80% (4 of 5); on the table 80% |
| Magic missiles tried each own turn | 50%+ | 35% (17 of 48) | 0% (0 of 12) | 28% (17 of 60) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 42% (17 of 40) | 0% (0 of 12) | 33% (17 of 52) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 63% (3773 of 5997) | 87% (5195 of 5998) | 75% (8968 of 11995) |
|   infantry points that never fought | lower | 51% (814 of 1591) | 86% (987 of 1147) | 66% (1801 of 2738) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 62% (21 of 34) | 70% (14 of 20) | 65% (35 of 54) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 1.0 uses a game | 100% (1 of 1); 1.3 uses a game | 100% (3 of 3); 1.2 uses a game |
| Bound items with another spell used |  | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 61% (3445 of 5667) | 67% (3454 of 5186) | 64% (6899 of 10853) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 4.3 (42%) | 0.7 (17%) | 5.0 (35%) |
| MARCHED: its unit marched | 2.3 (23%) | 1.3 (33%) | 3.7 (26%) |
| CHARGED: its unit charged | 1.0 (10%) | 0.0 (0%) | 1.0 (7%) |
| IN COMBAT: engaged in combat | 1.7 (16%) | 0.0 (0%) | 1.7 (12%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.7 (17%) | 0.7 (5%) |
| GONE: slain | 1.0 (10%) | 0.0 (0%) | 1.0 (7%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 1.3 (33%) | 1.3 (9%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 1.0 | 5.7 | 0.3 | 1.0 |
| not cast | 2.0 | 5.0 | 14.3 | 3.7 | 15.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (40%) | 5.0 (35%) | 1.0 (27%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 3.7 (26%) | 1.0 (27%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 1.0 (7%) | 0.3 (9%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (7%) | 1.7 (12%) | 0.7 (18%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (100%) | 2.0 (40%) | 0.7 (5%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.7 (13%) | 1.0 (7%) | 0.7 (18%) | 2.3 (16%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 1.3 (9%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.7 (84%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (82 of 131) | 77% (56 of 73) | 68% (138 of 204) |
|   cavalry | - | 67% (8 of 12) | 67% (8 of 12) |
|   character | 100% (8 of 8) | 83% (15 of 18) | 88% (23 of 26) |
|   chariot | 76% (13 of 17) | 100% (5 of 5) | 82% (18 of 22) |
|   infantry | 48% (22 of 46) | 65% (17 of 26) | 54% (39 of 72) |
|   monster | 75% (9 of 12) | 92% (11 of 12) | 83% (20 of 24) |
|   war machine | 62% (30 of 48) | - | 62% (30 of 48) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.3 (20%) | 4.0 (71%) | 7.3 (33%) |
| CHARGED: it charged | 0.3 (2%) | 0.7 (12%) | 1.0 (5%) |
| IN COMBAT: it fought this turn or the last | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |
| MOVED: a war machine that moved | 1.3 (8%) | 0.0 (0%) | 1.3 (6%) |
| NO TARGET IN RANGE | 3.0 (18%) | 0.3 (6%) | 3.3 (15%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 3.7 (22%) | 0.7 (12%) | 4.3 (20%) |
| SHELTERED: the target was sheltered | 3.3 (20%) | 0.0 (0%) | 3.3 (15%) |
| OTHER BAR | 0.7 (4%) | 0.0 (0%) | 0.7 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.0 | 1.0 | 75% | 2.4 pts | 10 pts |
| character | 7.7 | 2.0 | 78% | 5.2 pts | 40 pts |
| chariot | 6.0 | 5.3 | 56% | 20.0 pts | 120 pts |
| infantry | 13.3 | 8.7 | 62% | 8.1 pts | 108 pts |
| monster | 9.7 | 2.0 | 86% | 1.8 pts | 17 pts |
| war machine | 10.3 | 12.3 | 58% | 19.3 pts | 200 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.3 | 2.3 | 2.3 |
| Charges that made contact a game | 1.3 | 1.7 | 1.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.33 declared, 0.67 contact (3 units) | 0.00 declared, 0.00 contact (1 units) | 1.00 declared, 0.50 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 3.00 declared, 2.00 contact (1 units) | 3.00 declared, 2.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.15 declared, 0.10 contact (20 units) | 0.13 declared, 0.10 contact (31 units) | 0.14 declared, 0.10 contact (51 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | - | - | 50% (2 of 4) |
| Character in a unit | 100% (5 of 5) | 100% (1 of 1) | - | 100% (6 of 6) |
| Character on its own | - | 33% (1 of 3) | 60% (3 of 5) | 50% (4 of 8) |
| Chariot | 100% (3 of 3) | 50% (1 of 2) | - | 80% (4 of 5) |
| Infantry | 45% (5 of 11) | 50% (1 of 2) | 0% (0 of 1) | 43% (6 of 14) |
| Monster | 100% (1 of 1) | 100% (1 of 1) | - | 100% (2 of 2) |
| Monstrous | 50% (1 of 2) | 100% (5 of 5) | - | 86% (6 of 7) |
| War Machines | 62% (5 of 8) | - | - | 62% (5 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 2 | - | 46% (11 of 24) | 75% | 62% (15 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | 100% (1 of 1); on the table 100% | 25% (6 of 24) | 38% | 60% (6 of 10) | 100% (2 of 2); 3.0 uses a game | 0% (0 of 1); 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Ogre Kingdoms | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 96% | 100% (7 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 50% (1 of 2); on the table 50% | 0% (0 of 6) | 69% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (1 of 1); on the table 100% | - | 95% | 50% (4 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p18, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 75% (3) | 33% (1) | 57% (4) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.33 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.00 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: ccut-c940641-p18

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 33% (2 of 6) | 40% (2 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 35% (20 of 57) | 74% (14 of 19) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 100% (1 of 1) | - |
| Strategy | Joined characters whose unit fought | 44% (4 of 9) | 0% (0 of 1) |
| Strategy | Lone characters that fought | 60% (3 of 5) | 20% (1 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.7 | 4.3 |
| Movement | Points that never moved of their own | 313.0 | 228.3 |
| Movement | Fights charged into per game | 1.0 | 1.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 2 | 0 of 3 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | 1 of 3, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 2, net +60 | 0 of 3 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 2 | 1 of 3, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 17.7 | 18.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 32% (17 of 53) | 41% (23 of 56) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 10.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (15 of 30) | - |
| Shooting | Points destroyed by war machines | 86.0 | 0.0 |
| Magic | Magic missiles cast | 2.7 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 12% (1 of 8) | - |
| Magic | Wounds caused by magic missiles | 4.0 | - |
| Magic | Points destroyed by magic (all spells) | 18.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.3 / 0.3 / 0.3 | 3.0 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 87.7 | 302.3 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +159 | +210 |
| Combat | Net per 100 charger points, damage counted | +51.8 | +88.7 |
| Combat | First round won (charged fights) | 100% | 80% |
| Combat | Net points per charged fight | +76 | +207 |
| Combat | Net points per supported fight / lone fight | +60 / +84 | - / +207 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 3 | 2 of 5 |
| Game | Points lost | 357.7 | 324.7 |
| Game | VP from objectives | 536.7 | 713.3 |
| Game | Lone holders (player turns) | 4.7 | 2.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -242 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 682
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ccut-c940641-p18

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 12.7 | +281.9 | 0.0 | 34.7 | 33.0 | +467.0 | 0.0 | 302.7 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +15.6 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 6.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ASSAILMENT BY POINTS | 0.3 | +3.1 | 0.0 | 123.0 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 0.7 | +1.4 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.3 | -24.0 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.7 | +0.0 | 71.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 9.0 | +158.9 | 229.0 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 3.3 | +49.8 | 0.0 | 0.0 | 0.7 | +0.9 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | - | - | - | - | 1.3 | +29.1 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.0 | +31.3 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +17.2 | 0.0 | 54.0 | 0.3 | +20.9 | 0.0 | 36.3 |
| CHAMPION KNOWS CHALLENGE | 0.3 | -1.7 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 6.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 19.7 | -560.3 | 0.0 | 432.0 | 21.0 | -704.0 | 0.0 | 132.7 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 40.0 | 0.0 | 0.7 | +0.0 | 267.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 8.7 | +0.0 | 0.0 | 289.3 | 19.0 | +0.0 | 0.0 | 142.0 |
| COVER ONCE | 8.7 | -270.7 | 0.0 | 144.7 | 2.7 | -279.4 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | 0.3 | -0.2 | 0.0 | 0.0 | 1.0 | -15.9 | 69.3 | 0.0 |
| DEPLOY BY FIGURES | 9.0 | -55.1 | 0.0 | 0.0 | 9.0 | +40.5 | 0.0 | 0.0 |
| DUELLIST ONE MODEL | 0.3 | +3.7 | 36.3 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | - | - | - | - | 1.0 | +0.9 | 0.0 | 0.0 |
| EXACT ROUND | 1.7 | +3.3 | 60.0 | 123.0 | 1.3 | +11.4 | 356.3 | 0.0 |
| FALL BACK GOOD ORDER | 1.7 | +1.7 | 56.3 | 123.0 | 2.0 | +0.6 | 391.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 33.7 | +398.5 | 0.0 | 335.3 |
| FEATURE BUFFS | 1.0 | +19.0 | 0.0 | 0.0 | 0.7 | +10.0 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +0.1 | 20.0 | 0.0 | 0.7 | +18.4 | 157.7 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 105.7 | +4557.0 | 1061.7 | 879.0 | 106.3 | +5193.4 | 391.0 | 1052.0 |
| FLANK NOT WEIGHED | 5.3 | +0.0 | 0.0 | 144.7 | 3.7 | +0.0 | 0.0 | 40.0 |
| FOLLOW UP WEIGHED | 0.3 | +28.1 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 2.7 | +100.6 | 116.3 | 123.0 | 2.0 | +161.1 | 391.0 | 0.0 |
| FREED FROM HIS FIGHT | 2.7 | +0.0 | 0.0 | 54.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.3 | -0.5 | 0.0 | 0.0 | 0.7 | -3.8 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -0.4 | 0.0 | 123.0 | - | - | - | - |
| GOAL WALK | 9.3 | +511.9 | 0.0 | 0.0 | 23.0 | +2108.3 | 0.0 | 97.3 |
| GROUND FLIERS | 0.3 | +8.7 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 2.0 | +0.0 | 61.7 | 0.0 | 0.3 | +7.7 | 0.0 | 0.0 |
| GUN MASK | 4.3 | +172.9 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 4.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 246.7 |
| HE REFORMS ONCE FREED | 2.0 | +0.0 | 0.0 | 54.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 11.0 | +0.0 | 0.0 | 252.7 | 5.7 | +0.0 | 0.0 | 72.7 |
| HIS CHARGE LIST | 3.0 | +0.0 | 0.0 | 144.7 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 1.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 22.7 |
| HIS MOVE AND SHOT | 4.3 | -13.8 | 0.0 | 343.3 | 8.0 | -86.3 | 0.0 | 43.0 |
| HIS MOVE AS HE DECIDES | 52.0 | +14.7 | 532.7 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 23.7 | +0.0 | 0.0 | 181.0 |
| HIS ONE MOVE | 16.3 | +12.3 | 0.0 | 343.3 | - | - | - | - |
| HIS ONE QUARTER | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 0.7 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 22.7 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 43.3 | +1205.7 | 0.0 | 268.0 | 81.3 | +6072.8 | 0.0 | 521.3 |
| HIS SHOTS BY HIS RUN | 39.7 | +551.9 | 0.0 | 557.3 | 63.7 | +1597.7 | 0.0 | 341.0 |
| HIS TURN DENIED | 0.3 | +0.7 | 0.0 | 0.0 | 1.0 | +59.1 | 69.3 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 19.3 | +0.0 | 0.0 | 54.0 | 20.3 | +0.0 | 0.0 | 40.0 |
| HOLDER ASSIGNMENT | 13.3 | +1188.6 | 0.0 | 54.0 | 14.0 | +1400.9 | 0.0 | 20.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.3 | -69.5 | 116.3 | 123.0 | 1.7 | -79.0 | 391.0 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 0.3 | +3.2 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 24.0 | -330.7 | 0.0 | 50.3 |
| JOINT CHARGE NOW | 1.0 | -19.7 | 20.0 | 0.0 | - | - | - | - |
| JOINT LOOK BACK | 0.3 | +2.5 | 20.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 6.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 40.0 |
| LANE BY FIGURES | 0.7 | +15.4 | 0.0 | 0.0 | 1.3 | +93.2 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 0.7 | +0.0 | 0.0 | 157.7 | 4.0 | +0.0 | 138.7 | 126.0 |
| LONE WIZARD KEPT IN | 1.3 | +43.3 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 1.0 | +21.2 | 56.3 | 0.0 | 0.7 | -2.0 | 34.7 | 0.0 |
| LOST AFTER ESCAPE | 1.0 | -0.3 | 40.0 | 0.0 | 1.7 | +11.4 | 356.3 | 0.0 |
| MAKE SURE TOGETHER | 1.0 | +3.2 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 3.3 | -2.5 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 1.0 | +13.8 | 0.0 | 54.0 | 0.3 | +1.3 | 0.0 | 0.0 |
| MARCH BY THE SUM | 1.3 | +63.0 | 0.0 | 54.0 | - | - | - | - |
| MARCH CHECK | 2.3 | +163.2 | 0.0 | 54.0 | 0.3 | +17.4 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 1.0 | +8.8 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | 1.7 | +100.2 | 0.0 | 144.7 | 0.7 | +67.5 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 4.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.3 | +18.7 | 0.0 | 144.7 | 2.3 | +23.3 | 0.0 | 22.7 |
| MEETS IN TIME | 3.7 | +414.2 | 0.0 | 0.0 | 3.7 | +549.1 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 8.7 | +143.0 | 0.0 | 144.7 | 1.7 | +29.9 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 11.7 | +107.6 | 0.0 | 343.3 | 3.3 | +26.7 | 0.0 | 0.0 |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 41.3 | 11.3 |
| MOVE TO CHARGE COMPUTED | 2.7 | +142.8 | 0.0 | 289.3 | 3.3 | +192.5 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.7 | +317.8 | 0.0 | 54.0 | 4.7 | +220.0 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 1.0 | +72.5 | 0.0 | 289.3 | 3.0 | +168.2 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.7 | -69.3 | 116.3 | 123.0 | 1.7 | -192.2 | 391.0 | 0.0 |
| NO LATE CUT | 4.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 4.0 | -77.9 | 36.3 | 0.0 | 4.7 | -64.1 | 0.0 | 72.7 |
| OGRE LOADER SECOND SHOT | 3.3 | +11.5 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.0 | -71.2 | 0.0 | 144.7 | 4.0 | -68.1 | 0.0 | 11.3 |
| ONE OBJECTIVE FORMULA | 4.3 | +80.2 | 0.0 | 0.0 | 5.3 | -31.6 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | -1.0 | 0.0 | 0.0 |
| ONE ROUTE | 4.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +17.2 | 34.7 | 0.0 |
| OVERRUNS AWAY | 0.3 | +0.7 | 0.0 | 0.0 | 0.7 | +8.7 | 267.7 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | -0.9 | 0.0 | 0.0 |
| PLAN RESULT | 46.0 | +917.6 | 174.3 | 747.3 | 48.7 | +400.8 | 157.7 | 541.7 |
| PROMISE BY ITS OWN SUM | 5.7 | -174.0 | 0.0 | 289.3 | 4.7 | -134.2 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 10.3 | +687.2 | 375.7 | 0.0 | 14.7 | +1035.2 | 0.0 | 269.3 |
| REAL GROUND | 4.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | +24.3 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 4.7 | +349.6 | 0.0 | 20.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 6.7 | +38.9 | 0.0 | 60.7 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -3.9 | 0.0 | 289.3 | - | - | - | - |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 1.3 | +31.0 | 0.0 | 35.7 |
| RISK BY ARC | 2.7 | +134.2 | 116.3 | 123.0 | 1.3 | -106.2 | 337.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.3 | -43.5 | 356.3 | 0.0 |
| RUN DOWN | 0.7 | -9.7 | 0.0 | 0.0 | 2.0 | -32.5 | 391.0 | 0.0 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +7.2 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 4.0 | -399.7 | 0.0 | 0.0 |
| SEARCH SPOT | 1.0 | +6.4 | 0.0 | 34.7 | - | - | - | - |
| SECOND LOOK | 0.3 | +2.9 | 36.3 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.3 | -0.4 | 0.0 | 0.0 | 0.7 | -8.1 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.0 | +9.2 | 0.0 | 0.0 | 1.7 | -9.2 | 144.7 | 0.0 |
| SET UP TOGETHER | 1.0 | +3.2 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 18.3 | +0.0 | 0.0 | 0.0 | 8.3 | +0.0 | 0.0 | 265.3 |
| SHOOTS FROM THE BEST SPOT | 3.7 | +109.7 | 55.3 | 0.0 | 0.3 | +1.2 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.7 | -1.0 | 40.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 26.3 | -295.0 | 0.0 | 378.0 | 47.3 | -177.0 | 0.0 | 332.7 |
| SHOTS AFTER THE MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 31.0 | +937.4 | 0.0 | 34.7 | 18.7 | +271.5 | 0.0 | 301.0 |
| SPELL WORTH | - | - | - | - | 4.0 | +53.1 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.7 | -9.4 | 267.7 | 0.0 |
| SPOT AS THE GAME MOVES | 7.0 | +0.0 | 0.0 | 144.7 | 8.7 | +0.0 | 0.0 | 124.7 |
| STAND AND SHOOT | 0.3 | -1.4 | 0.0 | 0.0 | 0.3 | -2.8 | 34.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 10.7 | +0.0 | 0.0 | 37.3 |
| STANDS STILL | 58.7 | +0.0 | 945.3 | 54.0 | 29.3 | +0.0 | 0.0 | 548.7 |
| STAY WORTH | 49.0 | +151.8 | 676.0 | 34.7 | 26.7 | +232.3 | 0.0 | 850.3 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +0.2 | 0.0 | 11.3 |
| SUPPORT ADDS | 2.0 | +143.4 | 0.0 | 289.3 | 1.3 | +8.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 20.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 2.0 | +143.4 | 0.0 | 289.3 | 1.3 | +8.0 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 34.7 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 102.3 |
| THE ROW KEEPS ITS WAY | 3.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | 2.7 | +0.0 | 0.0 | 144.7 | - | - | - | - |
| THE STEP BACK IS MADE | 3.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 44.7 | +0.0 | 0.0 | 378.0 | 52.3 | +0.0 | 0.0 | 520.3 |
| TIED UP BY THE SUM | 1.0 | +112.2 | 40.0 | 123.0 | 0.3 | +53.6 | 34.7 | 0.0 |
| TIME ON OUR SIDE | 50.7 | +640.7 | 160.7 | 378.0 | - | - | - | - |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 493.3 |
| WHO FIGHTS | 0.3 | -2.7 | 0.0 | 0.0 | - | - | - | - |
| WHO GETS IN | 0.7 | -7.1 | 0.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.7 | +19.7 | 0.0 | 0.0 | 1.3 | +60.8 | 0.0 | 36.3 |
| WHOLE FIGHT DANGER | 2.0 | -143.7 | 0.0 | 54.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 5.7 | +38.5 | 0.0 | 0.0 | 0.7 | +10.5 | 0.0 | 0.0 |

### Rule changes: ccut-c940641-p18

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 374 | 364 | 135 | 45.00 | +2512 | +18.6 |
| HIS MOVE AS HE DECIDES | 156 | 156 | 112 | 37.33 | +0 | +0.0 |
| ARMY TABLE | 137 | 137 | 109 | 36.33 | +2105 | +19.3 |
| HIS SHOTS BY HIS RUN | 310 | 298 | 90 | 30.00 | +1170 | +13.0 |
| HOLDER ASSIGNMENT | 82 | 82 | 76 | 25.33 | +4397 | +57.9 |
| HIS MOVE WHY | 71 | 71 | 45 | 15.00 | +0 | +0.0 |
| SHOT RISK POINTS | 221 | 211 | 43 | 14.33 | +1006 | +23.4 |
| GOAL WALK | 97 | 95 | 39 | 13.00 | +1757 | +45.1 |
| DEPLOY BY FIGURES | 54 | 54 | 32 | 10.67 | +492 | +15.4 |
| THE TABLE AGAIN | 36 | 36 | 30 | 10.00 | +0 | +0.0 |
| HARD STAY DROPPED | 27 | 27 | 27 | 9.00 | +0 | +0.0 |
| OFF BEST | 26 | 26 | 26 | 8.67 | -427 | -16.4 |
| TIME ON OUR SIDE | 152 | 124 | 21 | 7.00 | +115 | +5.5 |
| ARTILLERY RE-ROLL WEIGHED | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| HIS ONE MOVE | 49 | 44 | 18 | 6.00 | +0 | +0.0 |
| MEETS IN TIME | 22 | 22 | 18 | 6.00 | +1382 | +76.8 |
| REDIRECT FOR A FRIEND IN REACH | 20 | 20 | 18 | 6.00 | +0 | +0.0 |
| STAY WORTH | 227 | 205 | 18 | 6.00 | +140 | +7.8 |
| MOVE ORDER | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| IDLE COST | 72 | 51 | 12 | 4.00 | +128 | +10.7 |
| PROMISE BY ITS OWN SUM | 31 | 31 | 12 | 4.00 | -925 | -77.1 |
| MOVE TO CHARGE COMPUTED | 18 | 12 | 11 | 3.67 | +305 | +27.7 |
| FIVE ACTION | 636 | 620 | 10 | 3.33 | +373 | +37.3 |
| NEXT CHARGE BY LIST | 12 | 11 | 10 | 3.33 | +305 | +30.5 |
| OGRE LOADER SECOND SHOT | 10 | 10 | 10 | 3.33 | +34 | +3.4 |
| CAST JOB | 12 | 12 | 8 | 2.67 | +46 | +5.7 |
| CHARGE LOSSES | 122 | 112 | 8 | 2.67 | +542 | +67.8 |
| THE RISK READS HIS RUN | 18 | 18 | 8 | 2.67 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 12 | 12 | 7 | 2.33 | +25 | +3.6 |
| FOUR ROUNDS | 14 | 13 | 6 | 2.00 | +226 | +37.6 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +326 | +54.3 |
| WHO HITS BACK | 6 | 6 | 6 | 2.00 | +198 | +33.0 |
| MARCH CHECK | 8 | 8 | 5 | 1.67 | +57 | +11.4 |
| MAX FOR POSITIONING | 14 | 12 | 5 | 1.67 | +4 | +0.8 |
| NEARER NOT NEEDED | 31 | 30 | 5 | 1.67 | +192 | +38.3 |
| SCOUT WAITS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 19 | 19 | 5 | 1.67 | +12 | +2.4 |
| ADVANCE LANE KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CASTING BLOCK | 4 | 4 | 4 | 1.33 | +37 | +9.2 |
| COVER ONCE | 34 | 27 | 4 | 1.33 | +150 | +37.6 |
| GUN MASK | 13 | 13 | 4 | 1.33 | +214 | +53.6 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +130 | +32.5 |
| MARCH BY THE SUM | 4 | 4 | 4 | 1.33 | +189 | +47.2 |
| MARCH OF THE TABLE | 4 | 4 | 4 | 1.33 | -26 | -6.6 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +93 | +23.2 |
| RISK BY ARC | 12 | 11 | 4 | 1.33 | +33 | +8.2 |
| SHOTS IN THE MOVE | 149 | 120 | 4 | 1.33 | +92 | +22.9 |
| TIED UP BY THE SUM | 4 | 4 | 4 | 1.33 | +140 | +35.0 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FEATURE BUFFS | 5 | 5 | 3 | 1.00 | +29 | +9.7 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | -59 | -19.6 |
| SHOTS AFTER THE MOVES | 26 | 26 | 3 | 1.00 | +0 | +0.0 |
| SUPPORT ADDS | 10 | 10 | 3 | 1.00 | +226 | +75.4 |
| SUPPORT WORKED OUT | 10 | 10 | 3 | 1.00 | +226 | +75.4 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 3 | 3 | 2 | 0.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +114 | +57.2 |
| EVASIVE BY THE ODDS | 3 | 3 | 2 | 0.67 | +0 | +0.0 |
| HIS MOVE AND SHOT | 37 | 30 | 2 | 0.67 | +3 | +1.4 |
| MANOEUVRE | 12 | 12 | 2 | 0.67 | +15 | +7.3 |
| SET UP BY THE SET | 8 | 8 | 2 | 0.67 | +93 | +46.3 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| THE ROW IN ITS ORDER | 22 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHO GETS IN | 2 | 2 | 2 | 0.67 | -21 | -10.6 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +9 | +9.4 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -72 | -71.9 |
| CHARGE NOW FIRST | 4 | 4 | 1 | 0.33 | -24 | -23.7 |
| FALLS SHORT | 101 | 83 | 1 | 0.33 | +13 | +12.7 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +84 | +84.3 |
| HIS TURN DENIED | 4 | 4 | 1 | 0.33 | +62 | +62.0 |
| HOLDS AMBUSHERS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| JOINT LOOK BACK | 1 | 1 | 1 | 0.33 | +8 | +7.5 |
| LONG SHOT | 5 | 4 | 1 | 0.33 | +19 | +19.3 |
| MISSILES IN THE MOVE | 31 | 22 | 1 | 0.33 | +26 | +25.6 |
| MISSILES NEXT TURN | 45 | 29 | 1 | 0.33 | +1 | +1.1 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -3 | -3.0 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | -3 | -2.8 |
| PROMISE READS THE TABLE | 1 | 1 | 1 | 0.33 | +11 | +11.0 |
| QUARTER ODDS | 75 | 72 | 1 | 0.33 | +88 | +88.4 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SEARCH SPOT | 3 | 3 | 1 | 0.33 | +19 | +19.2 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +9 | +8.7 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +1 | +0.6 |
| WHOLE FIGHT DANGER | 6 | 6 | 1 | 0.33 | +20 | +19.8 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLANNED TARGET | 27 | 27 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 19 | 19 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 83 | 81 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| DUELLIST ONE MODEL | 1 | not checked | - | - | - | - |
| EXACT ROUND | 9 | 9 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 11 | 10 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 27 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 18 | 18 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 3 | 3 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 7 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 12 | 12 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 50 | 45 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 15 | 14 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 20 | 20 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 8 | 8 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 23 | 23 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 119 | 119 | 0 | 0.00 | - | - |
| HONEST WORTH | 12 | 11 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 29 | 29 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 3 | 3 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 8 | 8 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 3 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 4 | trace | - | - | - | - |
| MARCH OVER CASTS | 7 | 7 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 20 | 20 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 13 | 12 | 0 | 0.00 | - | - |
| NO LATE CUT | 20 | 20 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 5 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 24 | 18 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 29 | 26 | 0 | 0.00 | - | - |
| ONE ROUTE | 20 | 20 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 284 | trace | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 2 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 20 | 20 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 14 | 14 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 2 | 1 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 8 | 8 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 12 | 12 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 3 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 80 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 47 | 43 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 32 | 30 | 0 | 0.00 | - | - |
| STANDS STILL | 264 | 261 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 13 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 27 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 8 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 23 | not checked | - | - | - | - |
| THE TABLE BINDS | 291 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 4 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 12 | 12 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p18

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.67 | 3.67 | 17.5 |
| PROMISE BY ITS OWN SUM | rule | 2.67 | 1.33 | 77.1 |
| HOLDER ASSIGNMENT | rule | 2.33 | 1.00 | 26.6 |
| ARMY TABLE | rule | 0.33 | 2.33 | 19.0 |
| NO REASON | gate | - | 1.00 | 12.8 |
| JOINT CHARGE NOW | rule | 0.67 | - | 35.9 |
| MARCH OF THE TABLE | rule | 0.67 | - | 13.2 |
| BEST PRIZE | rule | - | 0.33 | 71.9 |
| CHARGE NOW FIRST | rule | 0.33 | - | 23.7 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 3.0 |
| PATHS CROSS | rule | - | 0.33 | 2.8 |
| RULE SWITCHED OFF | gate | 0.33 | - | 3.0 |
| WHO GETS IN | rule | 0.33 | - | 34.2 |

### Plans: ccut-c940641-p18

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.0 | 67% | 94 | 99 | 106% |
| Mine | move | 27.7 | 98% | 1288 | 0 | 0% |
| Mine | shoot | 16.3 | 67% | 656 | 818 | 125% |
| Opponent | charge | 1.3 | 100% | 124 | 326 | 263% |
| Opponent | move | 40.0 | 95% | 1853 | 0 | 0% |
| Opponent | shoot | 5.3 | 38% | 280 | 74 | 27% |
| Opponent | support | 2.0 | 100% | 19 | 0 | 0% |

### Battle groups: ccut-c940641-p18

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 4.7 | 29% | 75% | 25% | 0% | 0% | 0% | 33% | 67% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p18

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 12 | 8 (12) | 8 | 0 | 46 | 33% | 3.0 | 6 (5) | 5 (5) | 32 (2) | 11 (7) | 6 (5) |
| Mine | Clean-up | 2 | 108 (2) | 8 | 100 | 0 | 50% | 4.0 | - | - | 108 (2) | 108 (2) | - |
| Mine | Fast Hammer | 3 | 13 (3) | 0 | 13 | 35 | 33% | 2.0 | 0 (1) | 20 (2) | - | 18 (2) | 0 (1) |
| Mine | Hammer | 7 | 15 (7) | 15 | 0 | 0 | 14% | 2.0 | 52 (1) | 5 (3) | 13 (3) | 21 (5) | 0 (2) |
| Mine | Shooter | 6 | 111 (6) | 0 | 111 | 33 | 0% | 2.0 | 0 (1) | 231 (2) | 67 (3) | 133 (5) | 0 (1) |
| Mine | War machine | 8 | 16 (8) | 16 | 0 | 0 | 0% | 1.1 | 0 (1) | 28 (4) | 6 (3) | - | 16 (8) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 2.0 | - | 0 (2) | - | 0 (2) | - |
| Opponent | Chaff | 11 | 112 (11) | 0 | 112 | 50 | 45% | 3.0 | 94 (3) | 117 (1) | 118 (7) | 112 (11) | - |
| Opponent | Character | 6 | 42 (6) | 42 | 0 | 0 | 0% | 1.7 | 97 (2) | 14 (2) | 0 (2) | 10 (2) | 63 (4) |
| Opponent | Clean-up | 4 | 27 (4) | 0 | 27 | 24 | 50% | 1.0 | - | 56 (2) | 0 (2) | 36 (3) | 0 (1) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Opponent | Hammer | 10 | 6 (10) | 6 | 0 | 25 | 50% | 1.4 | 0 (4) | 11 (4) | 0 (2) | 24 (2) | 0 (8) |
| Opponent | Holder | 1 | 67 (1) | 0 | 67 | 0 | 100% | - | - | 67 (1) | - | - | 67 (1) |
| Opponent | Shooter | 1 | 150 (1) | 0 | 150 | 0 | 0% | 1.0 | - | 150 (1) | - | 150 (1) | - |

### Charged fights: ccut-c940641-p18

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 157 | 54 | 0.5 | 1.0 | 109 | 0 | +109 | 0 of 1 | 1 of 1 | - | +109 |
| Mine | Grand Cathay | 1 | 0 | 120 | 2.0 | 1.5 | 60 | 0 | +60 | 0 of 2 | 2 of 2 | +60 | +60 |
| **Mine** | all armies | 3 | 105 | 76 | 1.0 | 1.3 | 76 | 0 | +76 | 0 of 3 | 3 of 3 | +60 | +84 |
| Opponent | Ogre Kingdoms | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 17 | -17 | 0 of 2 | 1 of 2 | - | -17 |
| Opponent | Vampire Counts | 1 | 0 | 965 | 2.0 | 1.0 | 482 | 0 | +482 | 2 of 2 | 2 of 2 | - | +482 |
| Opponent | Wood Elf Realms | 1 | 0 | 104 | 1.0 | 1.0 | 104 | 0 | +104 | 0 of 1 | 1 of 1 | - | +104 |
| **Opponent** | all armies | 3 | 0 | 356 | 1.7 | 1.0 | 214 | 7 | +207 | 2 of 5 | 4 of 5 | - | +207 |

### Effective charges: ccut-c940641-p18

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 2 | 0 | 0 | 0 | 1 (net +60) | 1 (net +60) | 0 | 0 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 2 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Opponent | Vampire Counts | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 1 | 0% (0 of 1) |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 0 | 1 (net +104) | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: ccut-c940641-p18

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 1 | 376 | 60 | +60 | 307 | 0 | +307 | +81.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 334 | 60 | +60 | 60 | 0 | +60 | +18.0 |
| Mine | No odds | 1 | 209 | 109 | +109 | 109 | 0 | +109 | +52.2 |
| Mine | All fights | 3 | 306 | 76 | +76 | 159 | 0 | +159 | +51.8 |
| Opponent | Effective (55-75%) | 1 | 40 | 104 | +0 | 16 | 2 | +14 | +35.0 |
| Opponent | 76-89% | 1 | 109 | 104 | +104 | 104 | 0 | +104 | +95.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 500 | 369 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | No odds | 2 | 267 | 262 | +466 | 482 | 17 | +466 | +174.3 |
| Opponent | All fights | 5 | 237 | 220 | +207 | 217 | 7 | +210 | +88.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p18 | move | 15 | 3 (20%) | 2 (13%) | 2 (13%) | 10 (67%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0934, L1026 |
| Fistful of Laurels | Opponent | L0918 |
| Ring of Jet | Mine | L1026 |
| Twice-Blessed Armour | Mine | L1026 |

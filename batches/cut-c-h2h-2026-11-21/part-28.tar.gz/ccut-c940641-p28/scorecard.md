# Doctrine scorecard: ccut-c940641-p28

### Scorecard: ccut-c940641-p28

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0524 | 2 | 1 | Mine | - | - | 5 | 1 | 1 | 0 | 0 | 0 | 380 |
| L0524 | 2 | 1 | Opponent | - | - | - | 1 | 4 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 1 | - | 0 | 3 | 0 | 0 | 0 | 275 |
| L0612 | 6 | 1 | Opponent | no | 6 | 4 | 2 | 0 | 0 | 0 | 0 | 165 |
| L0628 | 4 | 1 | Mine | no | 0 | - | 0 | 4 | 0 | 0 | 0 | 461 |
| L0628 | 4 | 1 | Opponent | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 351 |
| **Average** | | | Mine | 0% | 0.5 | 5.0 | 0.3 | 2.7 | 0.0 | 0.0 | 0.0 | 372.0 |
| **Average** | | | Opponent | 0% | 4.0 | 4.0 | 1.0 | 1.7 | 0.0 | 0.0 | 0.0 | 172.0 |

### KPIs: ccut-c940641-p28

Rules off - Opponent only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 100% (15 of 15) | 0% (0 of 16) | 48% (15 of 31) |
| Winner chose to follow up after the loser gave ground |  | 50% (3 of 6); on the table 67% | 100% (2 of 2); on the table 100% | 62% (5 of 8); on the table 75% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | 100% (1 of 1); on the table 100% | 50% (1 of 2); on the table 50% |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 50% (4 of 8); on the table 62% | 100% (4 of 4); on the table 100% | 67% (8 of 12); on the table 75% |
| Magic missiles tried each own turn | 50%+ | - | 40% (12 of 30) | 40% (12 of 30) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 41% (12 of 29) | 41% (12 of 29) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 89% (5352 of 6000) | 74% (4468 of 5998) | 82% (9820 of 11998) |
|   infantry points that never fought | lower | 90% (1999 of 2232) | 100% (694 of 694) | 92% (2693 of 2926) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 70% (19 of 27) | 57% (13 of 23) | 64% (32 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (3 of 3); 3.7 uses a game | 100% (3 of 3); 1.8 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 66% (2796 of 4232) | 65% (3786 of 5787) | 66% (6582 of 10019) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.0 (17%) | 1.0 (17%) |
| MARCHED: its unit marched | - | 3.7 (61%) | 3.7 (61%) |
| CHARGED: its unit charged | - | 1.0 (17%) | 1.0 (17%) |
| IN COMBAT: engaged in combat | - | 0.3 (6%) | 0.3 (6%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 6.0 | 1.0 | 4.0 | 1.0 | 1.0 |
| not cast | 2.0 | 3.0 | 6.0 | 3.0 | 23.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.0 (100%) | 1.0 (17%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 3.7 (61%) | 1.7 (56%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 1.0 (17%) | 0.3 (11%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (17%) | 0.0 (0%) | 0.3 (6%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (33%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (83%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 22.7 (99%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (132 of 210) | 75% (12 of 16) | 64% (144 of 226) |
|   cavalry | 41% (9 of 22) | 25% (1 of 4) | 38% (10 of 26) |
|   character | 84% (27 of 32) | - | 84% (27 of 32) |
|   infantry | 50% (27 of 54) | - | 50% (27 of 54) |
|   monster | 75% (9 of 12) | - | 75% (9 of 12) |
|   war machine | 67% (60 of 90) | 92% (11 of 12) | 70% (71 of 102) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 5.0 (19%) | 0.3 (25%) | 5.3 (20%) |
| CHARGED: it charged | 1.7 (6%) | 0.0 (0%) | 1.7 (6%) |
| FLEEING: it fled or was fleeing | 0.3 (1%) | 0.0 (0%) | 0.3 (1%) |
| IN COMBAT: it fought this turn or the last | 0.7 (3%) | 0.3 (25%) | 1.0 (4%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.3 (25%) | 0.3 (1%) |
| NO TARGET IN RANGE | 9.7 (37%) | 0.3 (25%) | 10.0 (37%) |
| ONLY IN COMBAT: the only targets were in combat | 1.3 (5%) | 0.0 (0%) | 1.3 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 6.7 (26%) | 0.0 (0%) | 6.7 (24%) |
| SHELTERED: the target was sheltered | 0.7 (3%) | 0.0 (0%) | 0.7 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| character | 10.0 | 4.0 | 80% | 6.0 pts | 60 pts |
| infantry | 18.7 | 5.0 | 79% | 4.9 pts | 91 pts |
| monster | 3.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 24.0 | 17.7 | 62% | 23.6 pts | 565 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.0 | 3.0 | 2.5 |
| Charges that made contact a game | 2.0 | 1.0 | 1.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.67 declared, 0.00 contact (3 units) | 0.67 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.29 declared, 0.29 contact (21 units) | 0.54 declared, 0.23 contact (13 units) | 0.38 declared, 0.26 contact (34 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 0% (0 of 4) | 100% (1 of 1) | 50% (1 of 2) | 29% (2 of 7) |
| Character in a unit | 88% (7 of 8) | 100% (3 of 3) | - | 91% (10 of 11) |
| Character on its own | - | 75% (3 of 4) | 100% (3 of 3) | 86% (6 of 7) |
| Infantry | 29% (2 of 7) | 33% (2 of 6) | - | 31% (4 of 13) |
| Monster | 50% (1 of 2) | - | - | 50% (1 of 2) |
| War Machines | 90% (9 of 10) | - | - | 90% (9 of 10) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dwarfen Mountain Holds | 3 | 50% (4 of 8); on the table 62% | - | 89% | 70% (19 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 39% (7 of 18) | 89% | 56% (5 of 9) | 100% (3 of 3); 11.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 1 | 100% (1 of 1); on the table 100% | 33% (2 of 6) | 89% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (3 of 3); on the table 100% | 50% (3 of 6) | 45% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p28, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 100% (1) | 33% (1) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: ccut-c940641-p28

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 100% (6 of 6) | 38% (3 of 8) |
| Strategy | Shoot objectives carried out (shot that target) | 49% (35 of 72) | 29% (7 of 24) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 100% (2 of 2) |
| Strategy | Joined characters whose unit fought | 8% (1 of 12) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 0% (0 of 1) | 38% (3 of 8) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.7 | 1.7 |
| Movement | Points that never moved of their own | 372.0 | 172.0 |
| Movement | Fights charged into per game | 1.3 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 4, net +347 | 2 of 3, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 4 | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 4 | 0 of 3 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 4, net +14 | 1 of 3, net +95 |
| Shooting | Shots by shooting units (incl. breath weapons) | 26.0 | 0.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 54% (42 of 78) | 0% (0 of 1) |
| Shooting | Points destroyed by shooting units | 73.7 | 0.0 |
| Shooting | War machine shots | 20.0 | 3.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 67% (40 of 60) | 45% (5 of 11) |
| Shooting | Points destroyed by war machines | 0.0 | 93.3 |
| Magic | Magic missiles cast | - | 2.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 62% (5 of 8) |
| Magic | Wounds caused by magic missiles | - | 4.7 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 20.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 4.3 / 0.7 / 1.0 / 0.7 |
| Combat | Points destroyed in combat | 135.7 | 51.7 |
| Combat | Points run down | 13.7 | 0.0 |
| Combat | Net points per charged fight, damage counted | +109 | +36 |
| Combat | Net per 100 charger points, damage counted | +110.4 | +18.2 |
| Combat | First round won (charged fights) | 75% | 33% |
| Combat | Net points per charged fight | +97 | +32 |
| Combat | Net points per supported fight / lone fight | +174 / +20 | - / +32 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 4 | 2 of 3 |
| Game | Points lost | 165.0 | 206.3 |
| Game | VP from objectives | 616.7 | 586.7 |
| Game | Lone holders (player turns) | 0.5 | 4.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +72 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 371
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ccut-c940641-p28

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.7 | +54.2 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 9.7 | +130.8 | 0.0 | 60.0 | 8.0 | +147.6 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| ASSAILMENT BY POINTS | - | - | - | - | 0.3 | +1.5 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 1.7 | +0.0 | 114.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 16.0 | +240.8 | 374.3 | 106.7 | 3.7 | +99.3 | 80.0 | 0.0 |
| CANNON SIGHT KEPT | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CAST JOB | - | - | - | - | 5.7 | +44.9 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | - | - | - | - | 0.3 | +6.7 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 0.7 | +20.8 | 0.0 | 0.0 |
| CHARACTER GUNS | 6.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 14.0 | -287.2 | 0.0 | 191.7 | 14.0 | -472.5 | 0.0 | 135.7 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 50.7 | 0.0 | 1.3 | +0.0 | 31.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 8.7 | +0.0 | 0.0 | 0.0 | 8.3 | +0.0 | 0.0 | 33.3 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| COVER ONCE | 10.0 | -642.8 | 0.0 | 31.7 | 3.7 | -202.9 | 0.0 | 0.0 |
| DEFENSIVE ARMY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -3.8 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 13.3 | -169.6 | 0.0 | 0.0 | 4.3 | +35.7 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.7 | -33.7 | 0.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +0.4 | 0.0 | 0.0 |
| EXACT ROUND | 1.7 | +37.4 | 342.0 | 20.0 | 1.3 | +6.3 | 31.7 | 0.0 |
| FALL BACK GOOD ORDER | 0.7 | +0.0 | 57.0 | 0.0 | 2.3 | +3.8 | 31.7 | 16.7 |
| FALLS SHORT | - | - | - | - | 22.3 | +253.2 | 0.0 | 0.0 |
| FEATURE BUFFS | 0.7 | +0.5 | 0.0 | 0.0 | 1.3 | +4.4 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.0 | +0.7 | 87.7 | 0.0 | 0.3 | +7.4 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 136.0 | +4665.0 | 1611.0 | 576.7 | 67.7 | +2421.0 | 171.7 | 348.7 |
| FLANK NOT WEIGHED | 4.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.3 | +86.3 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 2.0 | +269.8 | 379.0 | 20.0 | 3.0 | +210.4 | 31.7 | 16.7 |
| FREED FROM HIS FIGHT | 2.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 1.0 | -16.1 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.3 | -1.3 | 37.0 | 0.0 | 0.3 | -6.6 | 0.0 | 0.0 |
| GOAL WALK | 3.0 | +250.4 | 0.0 | 0.0 | 2.3 | +96.6 | 0.0 | 0.0 |
| GUN FIGURES | 1.3 | +41.5 | 135.7 | 0.0 | - | - | - | - |
| GUN MASK | 2.7 | +135.5 | 0.0 | 0.0 | 2.3 | +119.2 | 0.0 | 0.0 |
| HARD STAY DROPPED | 6.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 8.7 | +0.0 | 0.0 | 71.7 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE LIST | 13.7 | +0.0 | 0.0 | 83.3 | 5.7 | +0.0 | 0.0 | 271.3 |
| HIS LEGAL MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.3 | -22.4 | 0.0 | 20.0 | 3.7 | -36.1 | 0.0 | 135.7 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 37.0 | +15.3 | 60.0 | 0.0 |
| HIS MOVE WHY | 41.7 | +0.0 | 0.0 | 80.0 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 14.3 | -6.1 | 0.0 | 0.0 |
| HIS ONE QUARTER | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS OWN BEST MOVE | 3.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 49.3 | +1696.0 | 0.0 | 240.0 | 38.0 | +3812.5 | 0.0 | 298.7 |
| HIS SHOTS BY HIS RUN | 28.0 | +486.5 | 0.0 | 260.0 | 33.7 | +817.2 | 0.0 | 298.7 |
| HIS TURN DENIED | - | - | - | - | 0.3 | +34.5 | 0.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 12.7 | +0.0 | 0.0 | 0.0 | 13.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 9.0 | +872.6 | 0.0 | 0.0 | 9.0 | +1093.1 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -5.8 | 70.7 | 0.0 | 2.7 | -105.3 | 31.7 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +54.9 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 17.3 | -445.8 | 0.0 | 30.3 |
| JOINT CHARGE NOW | 1.0 | -1.2 | 308.3 | 20.0 | 0.3 | -3.6 | 0.0 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 3.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +42.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 77.0 |
| LOST AFTER ESCAPE | 1.0 | +4.8 | 87.7 | 0.0 | 1.3 | -5.8 | 0.0 | 0.0 |
| MANOEUVRE | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | -15.9 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.3 | +25.3 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 1.7 | +106.3 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +17.1 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 2.7 | +192.3 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 0.3 | +1.2 | 0.0 | 0.0 | 1.7 | +20.5 | 0.0 | 0.0 |
| MEETS IN TIME | 9.3 | +185.0 | 0.0 | 0.0 | 2.3 | +331.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | - | - | - | - | 7.3 | +55.7 | 0.0 | 0.0 |
| MISSILES NEXT TURN | - | - | - | - | 9.7 | +52.4 | 0.0 | 135.7 |
| MODEL FACING | 3.0 | +851.3 | 0.0 | 20.0 | - | - | - | - |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 1.7 | +41.1 | 0.0 | 0.0 | 1.0 | +82.9 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.0 | +231.6 | 0.0 | 0.0 | 4.7 | +215.2 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | - | - | - | - | 1.0 | +82.9 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.0 | -49.2 | 379.0 | 20.0 | 2.3 | -61.0 | 31.7 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 4.7 | -199.7 | 0.0 | 53.3 | 3.7 | -98.7 | 0.0 | 0.0 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 3.7 | +5.3 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 2.7 | -13.5 | 0.0 | 20.0 | 2.0 | -33.9 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 0.3 | -56.4 | 135.7 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 4.3 | -6.4 | 0.0 | 0.0 | 4.0 | -91.6 | 0.0 | 0.0 |
| ONE ROUTE | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | - | - | - | - | 0.3 | +0.5 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.3 | +1.7 | 20.0 | 0.0 | 0.7 | +2.9 | 0.0 | 0.0 |
| PATHS CROSS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +57.0 | 0.0 | 0.0 |
| PLAN RESULT | 59.7 | +1039.2 | 696.3 | 310.0 | 31.7 | +187.2 | 51.7 | 389.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 3.3 | -41.3 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.7 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 16.7 | +1062.0 | 814.0 | 60.0 | 2.0 | +700.0 | 0.0 | 271.3 |
| REAL GROUND | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | +10.6 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.0 | +50.2 | 0.0 | 0.0 | 1.0 | +39.2 | 0.0 | 13.7 |
| REDIRECT FOR A FRIEND IN REACH | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +9.2 | 0.0 | 13.7 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.3 | -1.7 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.0 | +52.4 | 379.0 | 20.0 | 2.7 | +42.8 | 0.0 | 16.7 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.7 | -18.7 | 31.7 | 16.7 |
| RUN DOWN | 1.7 | -24.7 | 359.0 | 20.0 | 2.0 | -5.6 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -99.9 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +10.0 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +0.4 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.7 | +0.7 | 0.0 | 0.0 | 0.7 | -10.9 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.7 | +16.5 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 2.0 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 24.3 | +0.0 | 0.0 | 106.7 | 8.0 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +37.7 | 0.0 | 0.0 | 3.0 | +67.0 | 60.0 | 0.0 |
| SHORT GUN FORWARD | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 0.7 | -7.6 | 50.7 | 0.0 | 0.7 | -1.3 | 0.0 | 0.0 |
| SHOT RISK POINTS | 27.0 | +783.0 | 0.0 | 240.0 | 19.3 | +263.2 | 0.0 | 298.7 |
| SHOTS AFTER THE MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 32.3 | +1202.5 | 0.0 | 146.7 | 4.0 | +297.1 | 0.0 | 0.0 |
| SPELL WORTH | - | - | - | - | 6.0 | +121.7 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | +0.9 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 20.0 |
| STAND AND SHOOT | - | - | - | - | 1.0 | -11.7 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 4.0 | +0.0 | 40.0 | 0.0 |
| STANDS STILL | 102.7 | +0.0 | 1232.0 | 476.7 | 23.3 | +0.0 | 140.0 | 0.0 |
| STAY WORTH | 60.0 | +373.5 | 1092.0 | 360.0 | 12.7 | +180.1 | 80.0 | 0.0 |
| SUPPORT ADDS | 1.0 | +7.5 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 0.0 | 16.7 |
| SUPPORT WORKED OUT | 1.0 | +7.5 | 0.0 | 0.0 | - | - | - | - |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +2.5 | 0.0 | 13.7 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 135.7 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 54.7 | +0.0 | 0.0 | 166.7 | 32.3 | +0.0 | 0.0 | 166.0 |
| TIED UP BY THE SUM | 0.7 | +19.0 | 50.7 | 0.0 | 1.3 | +134.1 | 31.7 | 0.0 |
| TIME ON OUR SIDE | 61.0 | +612.1 | 40.0 | 40.0 | - | - | - | - |
| WAITS AGAIN | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -76.9 | 0.0 | 0.0 |
| WHO FIGHTS | - | - | - | - | 1.0 | +9.0 | 31.7 | 0.0 |
| WHOLE FIGHT DANGER | 2.0 | -86.7 | 0.0 | 31.7 | 1.3 | -37.4 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | 0.3 | +1.0 | 37.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 2.3 | +23.3 | 0.0 | 0.0 | 2.3 | +169.5 | 0.0 | 135.7 |

### Rule changes: ccut-c940641-p28

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 262 | 261 | 88 | 29.33 | +2957 | +33.6 |
| HIS MOVE AS HE DECIDES | 111 | 111 | 65 | 21.67 | +0 | +0.0 |
| HIS MOVE WHY | 125 | 125 | 61 | 20.33 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 54 | 54 | 50 | 16.67 | +3890 | +77.8 |
| HIS SHOTS BY HIS RUN | 185 | 180 | 49 | 16.33 | +773 | +15.8 |
| ARMY TABLE | 53 | 53 | 34 | 11.33 | +602 | +17.7 |
| TIME ON OUR SIDE | 183 | 171 | 33 | 11.00 | +45 | +1.4 |
| DEPLOY BY FIGURES | 53 | 53 | 32 | 10.67 | +329 | +10.3 |
| SHOT RISK POINTS | 139 | 139 | 32 | 10.67 | +2142 | +66.9 |
| OFF BEST | 25 | 25 | 25 | 8.33 | -895 | -35.8 |
| HARD STAY DROPPED | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| HIS ONE MOVE | 43 | 43 | 20 | 6.67 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 18 | 6.00 | +0 | +0.0 |
| COVER ONCE | 41 | 38 | 14 | 4.67 | +55 | +4.0 |
| MEETS IN TIME | 35 | 35 | 14 | 4.67 | +462 | +33.0 |
| FIVE ACTION | 611 | 605 | 13 | 4.33 | +363 | +27.9 |
| CHARGE LOSSES | 84 | 84 | 12 | 4.00 | +723 | +60.2 |
| CAST JOB | 17 | 17 | 11 | 3.67 | +6 | +0.5 |
| OGRE LOADER SECOND SHOT | 11 | 11 | 11 | 3.67 | +16 | +1.4 |
| ARTILLERY RE-ROLL WEIGHED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| CANNON SIGHT KEPT | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| IDLE COST | 52 | 42 | 10 | 3.33 | +335 | +33.5 |
| FOUR ROUNDS | 15 | 14 | 9 | 3.00 | +407 | +45.2 |
| MODEL FACING | 9 | 9 | 9 | 3.00 | +2554 | +283.8 |
| SHOOTS FROM THE BEST SPOT | 13 | 13 | 9 | 3.00 | +92 | +10.2 |
| CANNON PLANNED TARGET | 59 | 59 | 7 | 2.33 | +0 | +0.0 |
| THE RISK READS HIS RUN | 18 | 18 | 7 | 2.33 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 15 | 15 | 6 | 2.00 | -124 | -20.6 |
| SHOOTERS IN TWO RANKS | 6 | 6 | 6 | 2.00 | +12 | +2.0 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 23 | 23 | 6 | 2.00 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| RISK BY ARC | 14 | 13 | 5 | 1.67 | +88 | +17.6 |
| TIED UP BY THE SUM | 6 | 5 | 5 | 1.67 | +96 | +19.3 |
| FALLS SHORT | 67 | 58 | 4 | 1.33 | +64 | +16.1 |
| GOAL WALK | 16 | 15 | 4 | 1.33 | +359 | +89.9 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | -14 | -3.6 |
| MOVE TO CHARGE COMPUTED | 8 | 6 | 4 | 1.33 | +41 | +10.2 |
| QUARTER ODDS | 56 | 56 | 4 | 1.33 | +65 | +16.3 |
| STAY WORTH | 218 | 209 | 4 | 1.33 | +53 | +13.2 |
| WOUNDS ON THE RANKS | 14 | 14 | 4 | 1.33 | +105 | +26.2 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MANOEUVRE | 10 | 10 | 3 | 1.00 | +22 | +7.3 |
| MARCH CHECK | 5 | 5 | 3 | 1.00 | +125 | +41.8 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +171 | +57.0 |
| SET UP BY THE SET | 4 | 4 | 3 | 1.00 | +49 | +16.2 |
| SHOTS IN THE MOVE | 109 | 100 | 3 | 1.00 | +169 | +56.5 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +163 | +81.4 |
| CHARGE NOW FIRST | 6 | 6 | 2 | 0.67 | -18 | -8.9 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| GUN MASK | 15 | 15 | 2 | 0.67 | +58 | +29.1 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +128 | +64.0 |
| MOVE ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SEARCH SPOT | 4 | 4 | 2 | 0.67 | +30 | +15.0 |
| WHO FIGHTS | 3 | 3 | 2 | 0.67 | +8 | +4.2 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +5 | +4.6 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| DENIED BY THE FIGHT | 1 | 1 | 1 | 0.33 | +24 | +24.5 |
| DUEL STOPS AT THE KILL | 2 | 2 | 1 | 0.33 | +24 | +24.5 |
| EXACT ROUND | 9 | 8 | 1 | 0.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +259 | +258.8 |
| HIS MOVE AND SHOT | 21 | 21 | 1 | 0.33 | +0 | +0.0 |
| LOST AFTER ESCAPE | 7 | 7 | 1 | 0.33 | +2 | +2.5 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +76 | +75.8 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -51 | -51.4 |
| MAX FOR POSITIONING | 6 | 6 | 1 | 0.33 | +11 | +11.0 |
| MISSILES IN THE MOVE | 22 | 15 | 1 | 0.33 | +9 | +8.9 |
| NEARER NOT NEEDED | 29 | 28 | 1 | 0.33 | +39 | +39.2 |
| NEXT CHARGE BY LIST | 3 | 3 | 1 | 0.33 | +32 | +31.9 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +90 | +89.6 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +8 | +7.6 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -231 | -230.8 |
| WHOLE FIGHT GAIN | 1 | 1 | 1 | 0.33 | +2 | +2.5 |
| CANNON PLAN MISSED | 5 | 5 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 20 | 20 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 51 | 51 | 0 | 0.00 | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | not checked | - | - | - | - |
| FALL BACK GOOD ORDER | 9 | 9 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 6 | 6 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 22 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 14 | 14 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 3 | 3 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 4 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 6 | 6 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 44 | 44 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 58 | 58 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 25 | 24 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 8 | 8 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 20 | 20 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 78 | 78 | 0 | 0.00 | - | - |
| HONEST WORTH | 11 | 10 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 2 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 13 | 13 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 8 | 8 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 7 | 7 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 29 | 22 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 13 | 12 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 14 | 12 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 25 | 22 | 0 | 0.00 | - | - |
| ONE ROUTE | 7 | 7 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | not checked | - | - | - | - |
| OVERRUNS AWAY | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 274 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 7 | 7 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 6 | 6 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 5 | 5 | 0 | 0.00 | - | - |
| RUN DOWN | 11 | 10 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 97 | not checked | - | - | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL WORTH | 18 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 24 | 18 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 12 | 12 | 0 | 0.00 | - | - |
| STANDS STILL | 378 | 376 | 0 | 0.00 | - | - |
| SUPPORT ADDS | 3 | 3 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| SUPPORT WORKED OUT | 3 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 6 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 8 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 12 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 3 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 5 | not checked | - | - | - | - |
| THE TABLE BINDS | 261 | not checked | - | - | - | - |
| WAITS AGAIN | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 10 | 10 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p28

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.67 | 3.33 | 36.6 |
| PROMISE BY ITS OWN SUM | rule | 2.00 | - | 20.6 |
| JOINT CHARGE NOW | rule | 0.67 | 0.33 | 31.5 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.67 | - | 39.8 |
| ARMY TABLE | rule | 0.67 | - | 9.3 |
| CHARGE NOW FIRST | rule | - | 0.67 | 8.9 |
| DEPLOY BY FIGURES | rule | 0.33 | - | 6.9 |
| FALLBACK | gate | 0.33 | - | 38.9 |
| HOLDER ASSIGNMENT | rule | - | 0.33 | 5.5 |
| MARCH OF THE TABLE | rule | - | 0.33 | 51.4 |
| RULE SWITCHED OFF | gate | - | 0.33 | 9.2 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 230.8 |

### Plans: ccut-c940641-p28

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.3 | 25% | 39 | 50 | 128% |
| Mine | join | 1.7 | 100% | 54 | 0 | 0% |
| Mine | move | 35.7 | 99% | 1158 | 0 | 0% |
| Mine | shoot | 21.0 | 68% | 684 | 990 | 145% |
| Opponent | charge | 3.0 | 11% | 179 | 58 | 32% |
| Opponent | join | 1.0 | 100% | 54 | 0 | 0% |
| Opponent | move | 21.3 | 97% | 728 | 0 | 0% |
| Opponent | shoot | 5.3 | 56% | 200 | 129 | 65% |
| Opponent | support | 1.0 | 100% | 25 | 0 | 0% |

### Battle groups: ccut-c940641-p28

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.0 | 33% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 1.0 | 67% | 50% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p28

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Character | 13 | 3 (13) | 3 | 0 | 0 | 38% | 2.5 | 6 (6) | 0 (6) | 0 (1) | 4 (11) | 0 (2) |
| Mine | Clean-up | 4 | 67 (4) | 67 | 0 | 0 | 75% | 1.0 | 0 (1) | 0 (1) | 131 (2) | 67 (4) | - |
| Mine | Fast | 3 | 0 (3) | 0 | 0 | 27 | 0% | 1.7 | - | 0 (1) | 0 (2) | 0 (3) | - |
| Mine | Hammer | 4 | 114 (4) | 10 | 104 | 0 | 25% | 3.0 | 25 (1) | 177 (3) | - | 114 (4) | - |
| Mine | Shooter | 8 | 62 (8) | 3 | 59 | 5 | 12% | 2.0 | 16 (1) | 118 (4) | 9 (3) | 48 (6) | 98 (2) |
| Mine | War machine | 17 | 7 (17) | 7 | 0 | 22 | 12% | 1.5 | 0 (4) | 12 (9) | 0 (4) | 0 (3) | 8 (14) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 63 | 33% | 4.0 | 0 (2) | - | 0 (1) | 0 (3) | - |
| Opponent | Character | 10 | 2 (10) | 2 | 0 | 2 | 50% | 3.2 | 0 (3) | 0 (4) | 0 (2) | 0 (8) | 0 (1) |
| Opponent | Clean-up | 1 | 59 (1) | 59 | 0 | 0 | 0% | 3.0 | - | 59 (1) | - | 59 (1) | - |
| Opponent | Fast Hammer | 3 | 5 (3) | 0 | 5 | 34 | 67% | 6.0 | 0 (1) | 17 (1) | 0 (1) | 7 (2) | 0 (1) |
| Opponent | Holder | 6 | 93 (6) | 6 | 87 | 10 | 33% | 3.0 | 54 (1) | 100 (5) | - | 120 (4) | 47 (2) |
| Opponent | War machine | 2 | 85 (2) | 85 | 0 | 0 | 0% | 1.0 | - | 170 (1) | 0 (1) | - | 85 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 2.5 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |

### Charged fights: ccut-c940641-p28

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 3 | 74 | 149 | 1.3 | 1.5 | 112 | 15 | +97 | 1 of 4 | 3 of 4 | +174 | +20 |
| Opponent | Grand Cathay | 1 | 340 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 2 of 2 | 0 of 2 | - | +0 |
| Opponent | Vampire Counts | 1 | 0 | 95 | 1.0 | 1.0 | 95 | 0 | +95 | 0 of 1 | 1 of 1 | - | +95 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 113 | 32 | 1.0 | 1.0 | 32 | 0 | +32 | 2 of 3 | 1 of 3 | - | +32 |

### Effective charges: ccut-c940641-p28

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 4 | 1 (net +347) | 0 | 0 | 0 | 0 | 3 (net +14) | 0 | 0% (0 of 4) |
| Opponent | Grand Cathay | 2 | 2 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Vampire Counts | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +95) | 0 | 0% (0 of 1) |

### Charged fights, damage counted: ccut-c940641-p28

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 120 | 357 | +347 | 407 | 100 | +307 | +255.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 92 | 71 | +14 | 71 | 28 | +43 | +46.9 |
| Mine | All fights | 4 | 99 | 142 | +97 | 155 | 46 | +109 | +110.4 |
| Opponent | Long shot (under 50%) | 2 | 217 | 183 | +0 | 102 | 119 | -17 | -7.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 161 | 95 | +95 | 142 | 0 | +142 | +88.5 |
| Opponent | All fights | 3 | 198 | 154 | +32 | 116 | 79 | +36 | +18.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p28 | move | 9 | 2 (22%) | 2 (22%) | 1 (11%) | 6 (67%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0524 |
| Clockwork Compass | Opponent | L0612 |
| Invocation of Nehek | Opponent | L0524 |
| Ring of Doom | Opponent | L0612 |
| Ring of Jet | Opponent | L0612 |

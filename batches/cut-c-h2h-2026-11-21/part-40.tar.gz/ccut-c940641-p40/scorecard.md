# Doctrine scorecard: ccut-c940641-p40

### Scorecard: ccut-c940641-p40

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0528 | 6 | 1 | Mine | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 702 |
| L0528 | 6 | 1 | Opponent | no | 9 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | - | 1 | 4 | 0 | 0 | 0 | 678 |
| L0616 | 4 | 1 | Opponent | no | 0 | - | 0 | 0 | 0 | 0 | 0 | 100 |
| L0632 | 2 | 1 | Mine | - | - | 4 | 2 | 1 | 0 | 0 | 0 | 571 |
| L0632 | 2 | 1 | Opponent | - | - | 6 | 1 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 0.0 | 4.0 | 1.0 | 2.7 | 0.0 | 0.0 | 0.0 | 650.3 |
| **Average** | | | Opponent | 0% | 4.5 | 6.0 | 0.3 | 1.7 | 0.0 | 0.0 | 0.0 | 33.3 |

### KPIs: ccut-c940641-p40

Rules off - Opponent only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 100% (13 of 13) | 0% (0 of 10) | 57% (13 of 23) |
| Winner chose to follow up after the loser gave ground |  | 0% (0 of 1); on the table 0% | 100% (2 of 2); on the table 100% | 67% (2 of 3); on the table 67% |
| Winner chose to pursue after the loser fell back in good order |  | 50% (2 of 4); on the table 50% | 100% (1 of 1); on the table 100% | 60% (3 of 5); on the table 60% |
| Winner chose to pursue after the loser fled |  | 100% (2 of 2); on the table 100% | 50% (1 of 2); on the table 50% | 75% (3 of 4); on the table 75% |
| Winner chose to follow up or pursue (all three) |  | 57% (4 of 7); on the table 57% | 80% (4 of 5); on the table 80% | 67% (8 of 12); on the table 67% |
| Magic missiles tried each own turn | 50%+ | - | 0% (0 of 6) | 0% (0 of 6) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 0% (0 of 6) | 0% (0 of 6) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 82% (9 of 11) | 82% (9 of 11) |
| Points that never fought | lower | 90% (5422 of 6000) | 85% (5111 of 5999) | 88% (10533 of 11999) |
|   infantry points that never fought | lower | 90% (1999 of 2232) | 100% (720 of 720) | 92% (2719 of 2952) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 74% (20 of 27) | 67% (14 of 21) | 71% (34 of 48) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 72% (3035 of 4232) | 72% (3892 of 5415) | 72% (6927 of 9647) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.3 (67%) | 1.3 (67%) |
| MARCHED: its unit marched | - | 0.7 (33%) | 0.7 (33%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Assailments |
| --- | --- | --- | --- | --- |
| tried | 1.3 | 0.0 | 0.0 | 0.0 |
| not cast | 2.7 | 2.0 | 2.0 | 4.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (100%) | 1.3 (67%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.7 (33%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.7 (25%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (75%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.0 (100%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 68% (134 of 198) | 58% (21 of 36) | 66% (155 of 234) |
|   cavalry | 45% (10 of 22) | 69% (9 of 13) | 54% (19 of 35) |
|   character | 68% (15 of 22) | 0% (0 of 5) | 56% (15 of 27) |
|   infantry | 51% (26 of 51) | 17% (1 of 6) | 47% (27 of 57) |
|   monster | 69% (9 of 13) | - | 69% (9 of 13) |
|   war machine | 82% (74 of 90) | 92% (11 of 12) | 83% (85 of 102) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.7 (17%) | 1.0 (20%) | 4.7 (18%) |
| CHARGED: it charged | 2.0 (9%) | 0.3 (7%) | 2.3 (9%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.3 (7%) | 0.3 (1%) |
| IN COMBAT: it fought this turn or the last | 0.3 (2%) | 0.0 (0%) | 0.3 (1%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.3 (7%) | 0.3 (1%) |
| NO TARGET IN RANGE | 7.0 (33%) | 2.7 (53%) | 9.7 (37%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (2%) | 0.0 (0%) | 0.3 (1%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 7.0 (33%) | 0.3 (7%) | 7.3 (28%) |
| SHELTERED: the target was sheltered | 1.0 (5%) | 0.0 (0%) | 1.0 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.7 | 1.7 | 75% | 9.8 pts | 65 pts |
| character | 5.0 | 5.0 | 47% | 20.8 pts | 104 pts |
| infantry | 17.3 | 4.0 | 79% | 5.5 pts | 96 pts |
| monster | 3.0 | 0.3 | 89% | 2.2 pts | 7 pts |
| war machine | 28.3 | 18.0 | 65% | 20.6 pts | 585 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 0.7 | 1.8 |
| Charges that made contact a game | 2.7 | 0.3 | 1.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.43 declared, 0.38 contact (21 units) | 0.10 declared, 0.05 contact (20 units) | 0.27 declared, 0.22 contact (41 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | - | 50% (1 of 2) | 50% (3 of 6) |
| Character in a unit | 100% (6 of 6) | 100% (3 of 3) | 100% (1 of 1) | 100% (10 of 10) |
| Character on its own | 100% (1 of 1) | 100% (2 of 2) | 100% (3 of 3) | 100% (6 of 6) |
| Infantry | 43% (3 of 7) | 50% (3 of 6) | - | 46% (6 of 13) |
| Monster | 50% (2 of 4) | - | - | 50% (2 of 4) |
| Monstrous | 100% (1 of 1) | - | - | 100% (1 of 1) |
| War Machines | 75% (6 of 8) | - | - | 75% (6 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dwarfen Mountain Holds | 3 | 57% (4 of 7); on the table 57% | - | 90% | 74% (20 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | - | - | 100% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 2 | 80% (4 of 5); on the table 80% | 0% (0 of 6) | 78% | 67% (10 of 15) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p40, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | - | 80% (4) | 80% (4) |
| ...free all their last turn and able to turn (per game) | 0.00 | 1.00 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.67 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: ccut-c940641-p40

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | 88% (7 of 8) | 50% (1 of 2) |
| Strategy | Shoot objectives carried out (shot that target) | 60% (60 of 100) | 58% (7 of 12) |
| Strategy | Support requests answered (helper made contact too) | 100% (2 of 2) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 12) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 0% (0 of 1) | 0% (0 of 6) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.7 | 1.7 |
| Movement | Points that never moved of their own | 650.3 | 33.3 |
| Movement | Fights charged into per game | 1.7 | 0.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 5 | 0 of 1 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 5 | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 5 | 0 of 1 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 of 5, net +69 | 0 of 1 |
| Shooting | Shots by shooting units (incl. breath weapons) | 20.7 | 4.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 47% (29 of 62) | 14% (2 of 14) |
| Shooting | Points destroyed by shooting units | 266.3 | 0.0 |
| Shooting | War machine shots | 24.7 | 3.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 68% (50 of 74) | 64% (7 of 11) |
| Shooting | Points destroyed by war machines | 278.7 | 73.3 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 1.3 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 46.3 | 117.7 |
| Combat | Points run down | 45.7 | 0.0 |
| Combat | Net points per charged fight, damage counted | +57 | -76 |
| Combat | Net per 100 charger points, damage counted | +57.7 | -56.5 |
| Combat | First round won (charged fights) | 80% | 100% |
| Combat | Net points per charged fight | +31 | +0 |
| Combat | Net points per supported fight / lone fight | +46 / +8 | - / +0 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 5 | 0 of 1 |
| Game | Points lost | 174.3 | 600.7 |
| Game | VP from objectives | 556.7 | 470.0 |
| Game | Lone holders (player turns) | 0.0 | 4.5 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +594 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 775
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ccut-c940641-p40

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +25.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 9.0 | +165.3 | 0.0 | 0.0 | 15.3 | +190.4 | 0.0 | 412.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 2.3 | +0.0 | 337.7 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 23.7 | +495.2 | 2626.7 | 75.0 | 3.7 | +122.7 | 146.7 | 0.0 |
| CANNON SIGHT KEPT | 3.0 | +0.0 | 0.0 | 38.3 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 3.0 | +58.0 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | -0.6 | 0.0 | 0.0 |
| CHARACTER GUNS | 4.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 7.3 | -223.4 | 0.0 | 0.0 | 24.7 | -1561.0 | 0.0 | 1700.7 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 137.7 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 8.0 | +0.0 | 0.0 | 0.0 | 11.0 | +0.0 | 0.0 | 341.3 |
| COMBAT PIVOT | 0.3 | +0.0 | 45.7 | 0.0 | - | - | - | - |
| COVER ONCE | 11.3 | -920.6 | 0.0 | 0.0 | 5.0 | -269.0 | 0.0 | 248.3 |
| DEFENSIVE ARMY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | 0.3 | -2.3 | 45.7 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 13.0 | -157.2 | 0.0 | 38.3 | 6.0 | +73.0 | 0.0 | 0.0 |
| EXACT ROUND | 3.0 | +43.5 | 229.7 | 0.0 | 0.7 | +3.1 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 3.0 | +0.1 | 229.7 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 15.0 | +356.2 | 0.0 | 755.7 |
| FEATURE BUFFS | 1.7 | +38.9 | 0.0 | 0.0 | 0.7 | +8.9 | 0.0 | 91.3 |
| FIGHT TO THE END | 1.3 | +1.9 | 137.0 | 0.0 | 0.3 | +3.2 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.3 | +2.2 | 0.0 | 0.0 | - | - | - | - |
| FIRE IN ORDER | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 137.0 | +4653.7 | 6505.0 | 150.0 | 72.3 | +2389.9 | 293.3 | 2200.0 |
| FLANK NOT WEIGHED | 3.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 91.3 |
| FOLLOW UP WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +47.8 | 0.0 | 0.0 |
| FOUR ROUNDS | 3.0 | +39.3 | 229.7 | 0.0 | 0.7 | +34.8 | 0.0 | 0.0 |
| FREED FROM HIS FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 46.3 |
| FRIEND SHOOTS FIRST | 1.3 | -49.3 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.3 | +15.3 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 2.3 | +66.9 | 0.0 | 0.0 | 14.0 | +943.8 | 0.0 | 275.7 |
| GUN FIGURES | 1.3 | +23.8 | 163.0 | 0.0 | - | - | - | - |
| GUN MASK | 3.0 | +55.0 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HE REFORMS ONCE FREED | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 46.3 |
| HIS CHARGE BY HIS RUN | 4.3 | +0.0 | 0.0 | 0.0 | 9.3 | +0.0 | 0.0 | 1019.7 |
| HIS CHARGE DENIED | 0.3 | +2.0 | 45.7 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 6.7 | +0.0 | 0.0 | 0.0 | 19.3 | +0.0 | 0.0 | 421.3 |
| HIS LEGAL MOVES | 4.3 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 562.3 |
| HIS MOVE AND SHOT | - | - | - | - | 2.7 | -22.2 | 0.0 | 0.0 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 39.7 | +15.3 | 0.0 | 0.0 |
| HIS ONE MOVE | - | - | - | - | 13.7 | -1.6 | 0.0 | 0.0 |
| HIS ONE QUARTER | 2.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 26.7 |
| HIS OWN BEST MOVE | 7.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 359.7 |
| HIS RANDOM MOVE | 19.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 34.0 | +1004.0 | 0.0 | 0.0 | 57.0 | +4664.9 | 0.0 | 1806.0 |
| HIS SHOTS BY HIS RUN | 20.7 | +278.6 | 0.0 | 0.0 | 49.0 | +1319.2 | 0.0 | 2009.7 |
| HIS TURN DENIED | - | - | - | - | 0.7 | +17.9 | 0.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 12.0 | +0.0 | 0.0 | 0.0 | 14.7 | +0.0 | 0.0 | 442.0 |
| HOLDER ASSIGNMENT | 9.3 | +1055.4 | 0.0 | 0.0 | 8.3 | +875.6 | 0.0 | 175.3 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.0 | -10.8 | 183.3 | 0.0 | 0.7 | -29.8 | 0.0 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +9.5 | 0.0 | 163.0 |
| IDLE COST | - | - | - | - | 15.0 | -277.2 | 0.0 | 587.0 |
| JOINT CHARGE NOW | 1.3 | +31.8 | 91.3 | 0.0 | - | - | - | - |
| KEEPS SCOUTS OR AMBUSH | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 1.3 | +77.7 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 1.3 | +0.0 | 113.3 | 77.7 | 4.0 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.3 | +25.0 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 3.0 | +7.6 | 229.7 | 0.0 | 0.3 | +0.8 | 0.0 | 0.0 |
| MANOEUVRE | 0.3 | -1.0 | 0.0 | 0.0 | 2.3 | +3.8 | 0.0 | 137.7 |
| MARCH CHECK | - | - | - | - | 0.7 | +40.9 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 0.3 | +22.8 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 0.7 | +6.8 | 0.0 | 0.0 | 2.0 | +33.6 | 0.0 | 163.0 |
| MEETS IN TIME | 6.0 | +54.8 | 0.0 | 0.0 | 3.0 | +184.7 | 0.0 | 0.0 |
| MISSILES NEXT TURN | - | - | - | - | 1.7 | +4.5 | 0.0 | 0.0 |
| MODEL FACING | 4.0 | +1107.7 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 157.0 |
| MOVE TO CHARGE COMPUTED | 6.7 | +189.5 | 0.0 | 0.0 | 1.0 | +45.7 | 0.0 | 157.0 |
| NEARER NOT NEEDED | 5.7 | +245.4 | 0.0 | 0.0 | 3.7 | +158.4 | 0.0 | 91.3 |
| NEXT CHARGE BY LIST | 3.3 | +108.7 | 0.0 | 0.0 | 0.7 | +39.1 | 0.0 | 157.0 |
| NO DOUBLE ROUNDS | 2.7 | -42.0 | 229.7 | 0.0 | 0.7 | -15.3 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 5.7 | -115.0 | 46.3 | 0.0 | 2.0 | -105.1 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 6.7 | -65.7 | 0.0 | 0.0 | 3.7 | -95.9 | 0.0 | 483.0 |
| ONE OBJECTIVE FORMULA | 3.7 | -71.1 | 0.0 | 0.0 | 3.3 | -97.9 | 0.0 | 175.3 |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.3 | +11.7 | 0.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.7 | +18.6 | 0.0 | 0.0 |
| PATHS CROSS | 0.7 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -3.7 | 0.0 | 46.3 |
| PLAN RESULT | 61.7 | +2939.4 | 1899.7 | 227.7 | 34.7 | +98.5 | 35.0 | 949.0 |
| PROMISE BY ITS OWN SUM | 12.3 | -201.4 | 0.0 | 0.0 | 2.0 | -12.9 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -4.6 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 15.0 | +917.3 | 53.3 | 70.0 | 10.0 | +893.0 | 140.0 | 53.3 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.7 | +81.2 | 0.0 | 113.3 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 1.3 | -26.4 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 3.0 | +210.7 | 0.0 | 26.7 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.7 | +6.5 | 0.0 | 26.7 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.3 | -66.9 | 0.0 | 0.0 | 0.3 | -0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 1.7 | +58.0 | 0.0 | 26.7 |
| RISK BY ARC | 2.0 | +119.4 | 229.7 | 0.0 | 0.7 | -35.2 | 0.0 | 0.0 |
| RUN DOWN | 3.0 | -18.2 | 229.7 | 0.0 | 0.3 | -2.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | -35.1 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +100.4 | 0.0 | 326.0 |
| SECOND LOOK | 0.3 | +5.3 | 46.3 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.3 | -4.6 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 0.3 | +4.6 | 0.0 | 0.0 | 0.7 | +17.5 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 2.0 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 33.7 | +0.0 | 0.0 | 75.0 | 5.0 | +0.0 | 0.0 | 163.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +28.1 | 0.0 | 0.0 | 0.7 | +7.9 | 0.0 | 163.0 |
| SHORT GUN FORWARD | 2.0 | +0.0 | 0.0 | 38.3 | - | - | - | - |
| SHOT RISK POINTS | 11.3 | +487.6 | 0.0 | 0.0 | 36.7 | -1154.1 | 0.0 | 1708.3 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 42.0 | +1571.3 | 0.0 | 75.0 | 8.3 | +325.4 | 0.0 | 389.7 |
| SPELL WORTH | - | - | - | - | 1.3 | +35.8 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 1.0 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 511.0 |
| STAND AND SHOOT | - | - | - | - | 0.7 | -2.6 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 1.7 | +0.0 | 0.0 | 163.0 |
| STANDS STILL | 104.3 | +0.0 | 6275.3 | 150.0 | 20.7 | +0.0 | 293.3 | 485.0 |
| STAY WORTH | 75.3 | -126.2 | 5216.0 | 185.0 | 10.3 | +265.3 | 223.3 | 163.0 |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 3.7 | +157.2 | 0.0 | 0.0 | 3.3 | +89.4 | 0.0 | 137.0 |
| SUPPORT NARROWED | 1.3 | +0.0 | 138.3 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 3.7 | +157.2 | 0.0 | 0.0 | 3.3 | +89.4 | 0.0 | 137.0 |
| SURE REACH TOGETHER | 0.3 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.7 | +1.5 | 0.0 | 13.7 |
| THE DEARER SUM KEEPS ITS PLAN | 2.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -4.6 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 45.7 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 59.3 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 2.3 | +0.0 | 0.0 | 163.0 |
| THE STEP BACK IS MADE | - | - | - | - | 1.0 | +0.0 | 0.0 | 45.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 63.3 | +0.0 | 0.0 | 75.0 | 34.0 | +0.0 | 0.0 | 1043.3 |
| TIED UP BY THE SUM | 0.7 | +17.9 | 92.0 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 54.7 | +607.3 | 0.0 | 0.0 | - | - | - | - |
| WAITS AGAIN | 3.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 46.3 |
| WEAPON BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 46.3 |
| WHO FIGHTS | 0.7 | -20.8 | 92.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | - | - | - | - | 0.7 | +23.9 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.3 | -178.4 | 0.0 | 0.0 | 2.7 | -316.6 | 0.0 | 612.0 |
| WOUNDED STAYS OUT | 0.3 | +0.0 | 46.3 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | - | - | - | - | 7.7 | +719.7 | 0.0 | 0.0 |

### Rule changes: ccut-c940641-p40

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 119 | 119 | 73 | 24.33 | +0 | +0.0 |
| HIS SHOT LIST | 273 | 261 | 70 | 23.33 | +1515 | +21.6 |
| HOLDER ASSIGNMENT | 53 | 53 | 50 | 16.67 | +3395 | +67.9 |
| ARMY TABLE | 73 | 73 | 49 | 16.33 | +846 | +17.3 |
| HIS SHOTS BY HIS RUN | 209 | 201 | 42 | 14.00 | +493 | +11.7 |
| DEPLOY BY FIGURES | 57 | 57 | 39 | 13.00 | +580 | +14.9 |
| SHOT RISK POINTS | 144 | 140 | 34 | 11.33 | +2015 | +59.3 |
| TIME ON OUR SIDE | 164 | 145 | 26 | 8.67 | +167 | +6.4 |
| OFF BEST | 23 | 23 | 23 | 7.67 | -660 | -28.7 |
| PROMISE BY ITS OWN SUM | 43 | 43 | 23 | 7.67 | -643 | -27.9 |
| THE TABLE AGAIN | 36 | 36 | 22 | 7.33 | +0 | +0.0 |
| HIS ONE MOVE | 41 | 41 | 20 | 6.67 | +0 | +0.0 |
| FIVE ACTION | 628 | 613 | 18 | 6.00 | +258 | +14.3 |
| HARD STAY DROPPED | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| MOVE ORDER | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| CANNON PLANNED TARGET | 82 | 82 | 14 | 4.67 | -31 | -2.2 |
| MOVE TO CHARGE COMPUTED | 23 | 17 | 14 | 4.67 | +174 | +12.4 |
| MODEL FACING | 12 | 12 | 12 | 4.00 | +3323 | +276.9 |
| THE RISK READS HIS RUN | 18 | 18 | 11 | 3.67 | +0 | +0.0 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| CHARGE LOSSES | 96 | 96 | 9 | 3.00 | +335 | +37.2 |
| RANDOM MOVE BY FIGURES | 11 | 11 | 9 | 3.00 | +244 | +27.1 |
| CHAFF IN THE MOVE | 9 | 9 | 8 | 2.67 | +34 | +4.2 |
| NEXT CHARGE BY LIST | 12 | 10 | 8 | 2.67 | +143 | +17.8 |
| SUPPORT ADDS | 21 | 19 | 8 | 2.67 | +156 | +19.5 |
| SUPPORT WORKED OUT | 21 | 19 | 8 | 2.67 | +156 | +19.5 |
| SHOTS IN THE MOVE | 151 | 126 | 7 | 2.33 | +185 | +26.5 |
| ARTILLERY RE-ROLL WEIGHED | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| COVER ONCE | 49 | 32 | 6 | 2.00 | +35 | +5.9 |
| MEETS IN TIME | 27 | 27 | 6 | 2.00 | +34 | +5.6 |
| SHOOTERS IN TWO RANKS | 6 | 6 | 6 | 2.00 | +12 | +2.0 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| STAY WORTH | 257 | 244 | 6 | 2.00 | +89 | +14.8 |
| FOUR ROUNDS | 11 | 10 | 5 | 1.67 | +103 | +20.6 |
| GOAL WALK | 49 | 48 | 5 | 1.67 | +164 | +32.9 |
| QUARTER ODDS | 75 | 75 | 5 | 1.67 | +101 | +20.2 |
| RESERVE FALL BACK | 5 | 5 | 5 | 1.67 | +174 | +34.8 |
| SEARCH SPOT | 6 | 6 | 5 | 1.67 | +301 | +60.2 |
| SHOOTS FROM THE BEST SPOT | 6 | 6 | 5 | 1.67 | +19 | +3.9 |
| SHOTS AFTER THE MOVES | 26 | 26 | 5 | 1.67 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 23 | 23 | 5 | 1.67 | +118 | +23.5 |
| IDLE COST | 45 | 37 | 4 | 1.33 | +75 | +18.9 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | +95 | +23.8 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +233 | +58.2 |
| RISK BY ARC | 8 | 7 | 4 | 1.33 | +27 | +6.8 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | -2 | -0.6 |
| EXACT ROUND | 11 | 10 | 3 | 1.00 | +10 | +3.2 |
| FIRE IN ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 5 | 5 | 3 | 1.00 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +143 | +71.7 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MARCH CHECK | 2 | 2 | 2 | 0.67 | +96 | +47.9 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SUPPORT NARROWED | 4 | 4 | 2 | 0.67 | -42 | -21.2 |
| SWIFTSTRIDE BY POINTS | 2 | 2 | 2 | 0.67 | +5 | +2.3 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +39 | +19.4 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +75 | +75.1 |
| CHARGE NOW FIRST | 4 | 4 | 1 | 0.33 | -38 | -37.9 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FIGHT TO THE END | 5 | 5 | 1 | 0.33 | +10 | +9.6 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.33 | +6 | +6.4 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +46 | +45.8 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +75 | +75.0 |
| MANOEUVRE | 8 | 8 | 1 | 0.33 | +11 | +11.4 |
| NEARER NOT NEEDED | 28 | 27 | 1 | 0.33 | +6 | +6.5 |
| OVERRUNS AWAY | 2 | 2 | 1 | 0.33 | +46 | +45.9 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -11 | -11.2 |
| REDIRECT COUNTER | 9 | 8 | 1 | 0.33 | +33 | +33.2 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +210 | +210.2 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +16 | +16.0 |
| SET UP BY THE SET | 3 | 3 | 1 | 0.33 | +22 | +21.8 |
| THE ROW IN ITS ORDER | 11 | 1 | 1 | 0.33 | +0 | +0.0 |
| TIED UP BY THE SUM | 2 | 1 | 1 | 0.33 | +10 | +9.6 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 15 | 15 | 1 | 0.33 | +14 | +13.8 |
| CANNON PLAN MISSED | 7 | 7 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 12 | 12 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 57 | 57 | 0 | 0.00 | - | - |
| DEFENSIVE ARMY | 4 | 4 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 10 | 9 | 0 | 0.00 | - | - |
| FALLS SHORT | 45 | 34 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 7 | 7 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 19 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 5 | 4 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GUN FIGURES | 4 | not checked | - | - | - | - |
| GUN MASK | 9 | 9 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 5 | 4 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 41 | 41 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 78 | 74 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 32 | 29 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 8 | 8 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 21 | 21 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 31 | 27 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 57 | 55 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 7 | 7 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 80 | 80 | 0 | 0.00 | - | - |
| HONEST WORTH | 8 | 8 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 10 | 10 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 10 | 9 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MAX FOR POSITIONING | 8 | 8 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 5 | 5 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 10 | 9 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 31 | 21 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 21 | 17 | 0 | 0.00 | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 289 | trace | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 3 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 5 | 5 | 0 | 0.00 | - | - |
| RUN DOWN | 10 | 9 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 116 | not checked | - | - | - | - |
| SPELL WORTH | 4 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 23 | 12 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 5 | 4 | 0 | 0.00 | - | - |
| STANDS STILL | 375 | 369 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 3 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 14 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 7 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 3 | not checked | - | - | - | - |
| THE TABLE BINDS | 292 | not checked | - | - | - | - |
| WAITS AGAIN | 10 | 8 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 1 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p40

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 7.00 | 0.67 | 27.9 |
| JOB FIRST | gate | 4.67 | 1.67 | 33.3 |
| ARMY TABLE | rule | 1.33 | 2.33 | 25.6 |
| CANNON PLANNED TARGET | rule | 1.00 | - | 10.0 |
| SUPPORT NARROWED | rule | 0.67 | - | 21.2 |
| CHAFF PASSED | rule | - | 0.33 | 1.6 |
| CHARGE NOW FIRST | rule | - | 0.33 | 37.9 |
| DEPLOY BY FIGURES | rule | - | 0.33 | 5.8 |
| FALLBACK | gate | 0.33 | - | 7.6 |
| FIGHT ORDER BAND | gate | 0.33 | - | 0.9 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 24.1 |
| JOINT CHARGE NOW | rule | 0.33 | - | 5.7 |
| NO REASON | gate | 0.33 | - | 15.4 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 11.2 |
| RULE SWITCHED OFF | gate | - | 0.33 | 2.7 |

### Plans: ccut-c940641-p40

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.0 | 50% | 119 | 204 | 171% |
| Mine | join | 2.7 | 100% | 75 | 0 | 0% |
| Mine | move | 29.7 | 100% | 839 | 0 | 0% |
| Mine | shoot | 27.3 | 70% | 1043 | 2736 | 262% |
| Opponent | charge | 0.3 | 100% | 13 | 18 | 134% |
| Opponent | move | 30.0 | 89% | 1079 | 0 | 0% |
| Opponent | shoot | 3.3 | 30% | 223 | 81 | 36% |
| Opponent | support | 1.0 | 100% | 3 | 0 | 0% |

### Battle groups: ccut-c940641-p40

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 3.0 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p40

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | Character | 13 | 0 (13) | 0 | 0 | 0 | 54% | 2.7 | 0 (2) | 0 (8) | 0 (3) | 0 (8) | 0 (5) |
| Mine | Clean-up | 3 | 0 (3) | 0 | 0 | 0 | 33% | 1.0 | 0 (1) | 0 (1) | 0 (1) | 0 (2) | 0 (1) |
| Mine | Hammer | 6 | 69 (6) | 28 | 41 | 0 | 67% | 2.5 | - | 104 (4) | 0 (2) | 95 (5) | 0 (1) |
| Mine | Shooter | 10 | 78 (10) | 25 | 53 | 16 | 10% | 2.2 | - | 114 (4) | 39 (6) | 123 (5) | 21 (5) |
| Mine | War machine | 17 | 77 (17) | 77 | 0 | 20 | 12% | 1.5 | 90 (9) | 0 (2) | 83 (6) | 0 (3) | 93 (14) |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 46 | 60% | 2.0 | 0 (4) | - | 0 (1) | 0 (4) | 0 (1) |
| Opponent | Character | 8 | 0 (8) | 0 | 0 | 44 | 75% | 2.5 | 0 (3) | 0 (1) | 0 (3) | 0 (5) | 0 (2) |
| Opponent | Clean-up | 3 | 53 (3) | 0 | 53 | 0 | 67% | 5.0 | 71 (1) | 34 (2) | - | 53 (3) | - |
| Opponent | Fast Hammer | 4 | 53 (4) | 0 | 53 | 24 | 50% | 2.5 | - | 95 (3) | 0 (1) | 121 (2) | 0 (2) |
| Opponent | Hammer | 3 | 88 (3) | 88 | 0 | 42 | 33% | 4.0 | 0 (1) | 104 (2) | - | 88 (3) | - |
| Opponent | Holder | 2 | 40 (2) | 0 | 40 | 100 | 0% | 3.5 | - | 40 (2) | - | 40 (2) | - |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | 0 (1) | - | - | - | 0 (1) |
| Opponent | War machine | 2 | 110 (2) | 110 | 0 | 0 | 0% | 1.0 | - | - | 110 (2) | - | 110 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 1.0 | 0 (1) | 0 (1) | - | 0 (2) | - |

### Charged fights: ccut-c940641-p40

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 3 | 545 | 92 | 1.7 | 1.6 | 55 | 24 | +31 | 0 of 5 | 4 of 5 | +46 | +8 |
| Opponent | Kingdom of Bretonnia | 1 | 220 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Warriors of Chaos | 2 | 0 | 0 | 0.5 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| **Opponent** | all armies | 3 | 73 | 0 | 0.3 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |

### Effective charges: ccut-c940641-p40

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 5 | 0 | 0 | 0 | 1 (net -120) | 0 | 4 (net +69) | 0 | 0% (0 of 5) |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: ccut-c940641-p40

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 1 | 60 | 137 | -120 | 100 | 150 | -50 | -83.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 109 | 137 | +69 | 84 | 0 | +84 | +77.2 |
| Mine | All fights | 5 | 99 | 137 | +31 | 87 | 30 | +57 | +57.7 |
| Opponent | 76-89% | 1 | 135 | 105 | +0 | 0 | 76 | -76 | -56.5 |
| Opponent | All fights | 1 | 135 | 105 | +0 | 0 | 76 | -76 | -56.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p40 | move | 23 | 1 (4%) | 1 (4%) | 2 (9%) | 20 (87%) |

## Decision items and abilities without guidance

None: every decision item and ability on these lists has its guidance line.

# Doctrine scorecard: ccut-c940641-p9

### Scorecard: ccut-c940641-p9

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1527 | 3 | 1 | Mine | no | 9 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 1 | 2 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1625 | 5 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1723 | 1 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1723 | 1 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| **Average** | | | Mine | 0% | 9.0 | 2.0 | 3.0 | 0.0 | 1.0 | 0.0 | 0.0 | 0.0 |
| **Average** | | | Opponent | 0% | 1.0 | 2.0 | 3.0 | 2.0 | 1.0 | 0.0 | 0.0 | 0.0 |

### KPIs: ccut-c940641-p9

Rules off - Mine only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 11) | 0% (0 of 12) | 0% (0 of 23) |
| Winner chose to follow up after the loser gave ground |  | 100% (3 of 3); on the table 100% | 50% (1 of 2); on the table 50% | 80% (4 of 5); on the table 80% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | 100% (3 of 3); on the table 100% | 33% (1 of 3); on the table 33% | 67% (4 of 6); on the table 67% |
| Magic missiles tried each own turn | 50%+ | 0% (0 of 5) | 73% (11 of 15) | 55% (11 of 20) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 80% (8 of 10) | 80% (8 of 10) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 44% (885 of 2000) | 49% (976 of 2000) | 47% (1861 of 4000) |
|   infantry points that never fought | lower | 58% (176 of 302) | 66% (114 of 174) | 61% (290 of 476) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 29% (2 of 7) | 83% (5 of 6) | 54% (7 of 13) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.3 uses a game | 0.0 uses a game | 100% (2 of 2); 1.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 26% (510 of 1940) | 70% (1075 of 1546) | 45% (1585 of 3486) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 0.7 (50%) | 0.7 (50%) |
| GONE: slain | - | 0.7 (50%) | 0.7 (50%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 2.7 | 0.7 | 1.0 | 3.7 | 0.0 | 0.0 |
| not cast | 4.7 | 2.3 | 1.0 | 1.3 | 1.0 | 21.7 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (14%) | 0.0 (0%) | 0.7 (50%) | 1.0 (100%) | 0.0 (0%) |
| GONE: slain | 0.7 (14%) | 0.0 (0%) | 0.0 (0%) | 0.7 (50%) | 0.0 (0%) | 2.7 (12%) |
| OFF THE TABLE: off the table or not arrived | 0.7 (14%) | 0.7 (29%) | 0.7 (67%) | 0.0 (0%) | 0.0 (0%) | 1.7 (8%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.3 (14%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 1.0 (43%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.3 (71%) | 0.0 (0%) | 0.3 (33%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.7 (77%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 0.0 a game | 0.5 a game |
| stood (cast and not dispelled) | - | - | - |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 52% (13 of 25) | - | 52% (13 of 25) |
|   character | 33% (3 of 9) | - | 33% (3 of 9) |
|   chariot | 67% (4 of 6) | - | 67% (4 of 6) |
|   infantry | 60% (6 of 10) | - | 60% (6 of 10) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (50%) | - | 2.0 (50%) |
| CHARGED: it charged | 1.0 (25%) | - | 1.0 (25%) |
| NO TARGET IN RANGE | 0.7 (17%) | - | 0.7 (17%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (8%) | - | 0.3 (8%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| character | 1.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 1.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 2.7 | 1.0 | 75% | 4.2 pts | 11 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 4.0 | 3.5 |
| Charges that made contact a game | 2.7 | 2.7 | 2.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (3 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.00 declared, 0.00 contact (3 units) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (4 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.39 declared, 0.35 contact (23 units) | 0.44 declared, 0.30 contact (27 units) | 0.42 declared, 0.32 contact (50 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (2 of 3) | - | 50% (1 of 2) | 60% (3 of 5) |
| Character on its own | 100% (2 of 2) | - | 33% (1 of 3) | 60% (3 of 5) |
| Chariot | 100% (1 of 1) | - | - | 100% (1 of 1) |
| Infantry | 0% (0 of 2) | - | - | 0% (0 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 1 | 100% (3 of 3); on the table 100% | - | 44% | 29% (2 of 7) | 100% (2 of 2); 7.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 33% (1 of 3); on the table 33% | 67% (8 of 12) | 49% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p9, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (2) | 0% (0) | 20% (2) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.00 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.00 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.33 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: ccut-c940641-p9

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 80% (4 of 5) | 33% (4 of 12) |
| Strategy | Shoot objectives carried out (shot that target) | 14% (1 of 7) | 0% (0 of 12) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | - | 0% (0 of 1) |
| Strategy | Lone characters that fought | 50% (1 of 2) | 40% (2 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.0 | 2.0 |
| Movement | Points that never moved of their own | 0.0 | 0.0 |
| Movement | Fights charged into per game | 5.0 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 3 | 0 of 1 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 3, net -60 | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 3, net +60 | 0 of 1 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 3, net +190 | 0 of 1 |
| Shooting | Shots by shooting units (incl. breath weapons) | 4.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (7 of 14) | - |
| Shooting | Points destroyed by shooting units | 25.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | - | 2.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 29% (2 of 7) |
| Magic | Wounds caused by magic missiles | 1.0 | 0.7 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.3 / 0.0 / 0.0 | 2.3 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 336.0 | 20.0 |
| Combat | Points run down | 0.0 | 173.7 |
| Combat | Net points per charged fight, damage counted | +182 | +63 |
| Combat | Net per 100 charger points, damage counted | +45.9 | +33.9 |
| Combat | First round won (charged fights) | 40% | 100% |
| Combat | Net points per charged fight | +171 | +0 |
| Combat | Net points per supported fight / lone fight | - / +171 | - / +0 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 5 | 0 of 1 |
| Game | Points lost | 581.0 | 933.0 |
| Game | VP from objectives | 910.0 | 430.0 |
| Game | Lone holders (player turns) | 9.0 | 1.0 |

- Mine won / drew / lost: 1 / 0 / 0 of 1 ended games (of 3); mean margin (Mine - Opponent) +1012 VP
- The side that went first won 1 of 1 games with a winner
- Points traded per game (both sides' losses): 1514
- Games not ended: 2 (L1625-1, L1723-1); findings 3, warnings 0

### Opponent rules: ccut-c940641-p9

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH IN POINTS | - | - | - | - | 0.7 | +89.8 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +30.2 | 0.0 | 0.0 |
| ARMY TABLE | 14.7 | +299.2 | 0.0 | 437.0 | 17.7 | +107.3 | 0.0 | 0.0 |
| BACKUP TARGETS | - | - | - | - | 0.3 | +1.0 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 0.7 | +8.8 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 0.3 | +2.2 | 0.0 | 0.0 | 1.0 | +9.2 | 131.7 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 263.3 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 3.3 | +172.5 | 0.0 | 20.0 |
| CHALLENGE BY POINTS | 0.3 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 0.3 | -5.0 | 143.3 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 14.7 | -1065.0 | 0.0 | 305.3 | 10.3 | -586.3 | 0.0 | 126.7 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 83.3 | 20.0 | 2.7 | +0.0 | 173.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 9.3 | +0.0 | 0.0 | 347.3 | 17.7 | +0.0 | 0.0 | 56.7 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 20.0 | 0.0 |
| COVER ONCE | 10.0 | -418.9 | 0.0 | 263.3 | 9.7 | -746.4 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -3.1 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 7.3 | +4.0 | 0.0 | 0.0 | 7.7 | +7.5 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 1.0 | -159.5 | 143.3 | 0.0 | - | - | - | - |
| EXACT ROUND | 0.7 | +10.1 | 63.3 | 20.0 | 3.7 | +17.5 | 305.3 | 15.0 |
| FACES THE THREAT | - | - | - | - | 0.3 | +21.8 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.7 | +0.0 | 20.0 | 20.0 | 3.3 | +17.5 | 42.0 | 0.0 |
| FALLS SHORT | 3.7 | +3.6 | 0.0 | 0.0 | 17.3 | +199.5 | 0.0 | 83.3 |
| FEATURE BUFFS | 1.3 | +17.4 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 1.0 | +31.6 | 143.3 | 20.0 | 2.3 | +12.6 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 42.0 | - | - | - | - |
| FIVE ACTION | 52.3 | +3126.8 | 528.3 | 714.7 | 77.3 | +3523.3 | 437.0 | 215.0 |
| FLANK NOT WEIGHED | 7.0 | +0.0 | 0.0 | 305.3 | 4.0 | +0.0 | 0.0 | 0.0 |
| FOCUS FIRE | - | - | - | - | 0.3 | +16.6 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 1.3 | +293.2 | 0.0 | 0.0 | 0.7 | +102.2 | 0.0 | 143.3 |
| FOUR ROUNDS | 2.7 | +421.2 | 370.0 | 20.0 | 4.0 | +277.2 | 305.3 | 15.0 |
| FREED FROM HIS FIGHT | 5.0 | +0.0 | 0.0 | 263.3 | 5.0 | +0.0 | 0.0 | 40.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 2.3 | -7.9 | 0.0 | 0.0 |
| GIVES UP | 0.7 | -29.0 | 286.7 | 0.0 | 0.7 | -25.2 | 0.0 | 0.0 |
| GOAL WALK | 11.3 | +869.3 | 0.0 | 0.0 | 5.0 | +418.4 | 0.0 | 0.0 |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 3.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 14.0 | +0.0 | 0.0 | 305.3 | 9.7 | +0.0 | 0.0 | 126.7 |
| HIS CHARGE LIST | 4.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 7.0 | +0.0 | 0.0 | 521.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 1.0 | -5.1 | 0.0 | 0.0 | 4.7 | -91.8 | 0.0 | 63.3 |
| HIS MOVE AS HE DECIDES | 32.3 | +6.3 | 230.0 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 25.7 | +0.0 | 0.0 | 0.0 |
| HIS ONE MOVE | 14.0 | +52.6 | 0.0 | 0.0 | - | - | - | - |
| HIS ONE QUARTER | 3.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 3.7 | +0.0 | 0.0 | 257.7 | 9.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 4.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 4.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 24.0 | +157.9 | 0.0 | 526.7 | 34.7 | +880.7 | 0.0 | 136.7 |
| HIS SHOTS BY HIS RUN | 17.3 | +72.6 | 0.0 | 263.3 | 30.3 | +358.3 | 0.0 | 166.7 |
| HIS TURN DENIED | 0.3 | +0.7 | 0.0 | 0.0 | 2.7 | +34.3 | 263.3 | 15.0 |
| HIS TURN RUN | 4.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 14.3 | +0.0 | 0.0 | 84.0 | 9.7 | +0.0 | 0.0 | 40.0 |
| HOLDER ASSIGNMENT | 9.0 | +659.4 | 0.0 | 42.0 | 8.3 | +534.2 | 0.0 | 20.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.7 | -187.1 | 370.0 | 20.0 | 3.7 | -127.0 | 173.7 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +5.1 | 0.0 | 0.0 |
| IDLE COST | 1.3 | -20.0 | 0.0 | 0.0 | 17.3 | -198.3 | 0.0 | 80.0 |
| JOINT CHARGE NOW | 0.7 | -25.0 | 286.7 | 0.0 | 1.0 | +259.9 | 263.3 | 15.0 |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +33.0 | 0.0 | 0.0 | 1.3 | +56.1 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 7.0 | +0.0 | 231.7 | 40.0 | 6.7 | +0.0 | 40.0 | 188.3 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.3 | +23.5 | 20.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.3 | +7.9 | 0.0 | 0.0 | 0.3 | +7.5 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.3 | -1.0 | 143.3 | 0.0 | 2.7 | +7.8 | 42.0 | 0.0 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.7 | -49.5 | 0.0 | 0.0 |
| MANOEUVRE | 0.7 | +1.4 | 0.0 | 0.0 | 1.3 | -1.4 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 0.3 | +11.5 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | +105.3 | 0.0 | 0.0 | 0.3 | +21.8 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.0 | +16.5 | 0.0 | 263.3 | 2.3 | +47.9 | 0.0 | 0.0 |
| MEETS IN TIME | 4.0 | +232.5 | 0.0 | 0.0 | 4.3 | +194.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.3 | +94.4 | 0.0 | 263.3 | 3.0 | +19.6 | 0.0 | 63.3 |
| MISSILES NEXT TURN | 3.0 | +61.3 | 0.0 | 263.3 | 4.0 | +21.9 | 0.0 | 63.3 |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 5.0 | +302.9 | 0.0 | 0.0 | 11.7 | +922.4 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 8.0 | +285.1 | 0.0 | 84.0 | 7.7 | +253.7 | 0.0 | 20.0 |
| NEXT CHARGE BY LIST | 2.7 | +183.0 | 0.0 | 0.0 | 8.3 | +608.4 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -10.0 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.0 | -45.0 | 306.7 | 20.0 | 4.0 | -197.7 | 305.3 | 15.0 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 4.7 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 4.7 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.0 | -1.0 | 0.0 | 131.7 | - | - | - | - |
| OFF BEST | 1.3 | -58.3 | 0.0 | 0.0 | 4.0 | -87.0 | 0.0 | 143.3 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 131.7 | - | - | - | - |
| ONE FIGHT FORMULA | 4.0 | -80.6 | 0.0 | 263.3 | 6.3 | -143.0 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 0.7 | +8.4 | 286.7 | 0.0 | 0.3 | +19.2 | 131.7 | 15.0 |
| ONE OBJECTIVE FORMULA | 5.3 | -40.6 | 0.0 | 42.0 | 3.0 | -32.2 | 0.0 | 20.0 |
| ONE PROMISE A TARGET | - | - | - | - | 1.0 | -32.3 | 0.0 | 0.0 |
| ONE ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.3 | +0.6 | 63.3 | 0.0 | 1.7 | +18.9 | 42.0 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.7 | +8.8 | 0.0 | 20.0 |
| PLAN RESULT | 22.3 | +394.6 | 480.0 | 387.3 | 37.0 | +695.5 | 213.7 | 373.3 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 6.7 | -82.9 | 0.0 | 0.0 | 11.0 | -345.7 | 0.0 | 0.0 |
| PROMISE IN STEPS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 1.0 | -39.2 | 0.0 | 0.0 |
| PURSUES BIG PREY | - | - | - | - | 0.3 | -36.7 | 0.0 | 0.0 |
| QUARTER ODDS | 5.7 | +784.7 | 78.3 | 0.0 | 14.0 | +1525.2 | 0.0 | 0.0 |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 1.3 | +77.9 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.7 | +20.7 | 0.0 | 0.0 | 3.3 | +420.1 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 1.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 20.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.7 | +0.0 | 0.0 | 15.0 |
| REFORMS TO MEET IT | 1.7 | -30.4 | 0.0 | 0.0 | 2.7 | -76.0 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.7 | +4.2 | 0.0 | 131.7 | 0.3 | +8.1 | 0.0 | 0.0 |
| RISK BY ARC | 2.3 | +11.2 | 350.0 | 20.0 | 3.7 | +36.5 | 305.3 | 15.0 |
| RISK ON THE WAY | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 2.0 | -46.9 | 42.0 | 0.0 |
| RUN DOWN | - | - | - | - | 3.0 | -50.5 | 173.7 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | -39.5 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | -46.6 | 0.0 | 0.0 | 0.7 | +17.1 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +16.2 | 143.3 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | 1.3 | +68.7 | 0.0 | 263.3 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 1.0 | -46.6 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.7 | +0.0 | 143.3 | 0.0 | 2.0 | +57.7 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.3 | +1.6 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 1.0 | +2.0 | 0.0 | 0.0 | 0.3 | +1.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 3.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +51.9 | 143.3 | 0.0 | 1.3 | +51.9 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -6.4 | 0.0 | 20.0 | 1.0 | -13.4 | 0.0 | 0.0 |
| SHOT RISK POINTS | 11.3 | -49.6 | 0.0 | 263.3 | 30.0 | -132.9 | 0.0 | 53.3 |
| SHOTS AFTER THE MOVES | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 9.7 | +179.6 | 0.0 | 347.3 | 7.3 | +31.9 | 0.0 | 0.0 |
| SPELL WORTH | 0.3 | +0.0 | 20.0 | 0.0 | - | - | - | - |
| SPELLS IN THE FIGHT | - | - | - | - | 0.7 | -11.7 | 263.3 | 15.0 |
| SPOT AS THE GAME MOVES | 4.7 | +0.0 | 0.0 | 42.0 | 9.0 | +0.0 | 0.0 | 180.0 |
| STAND AND SHOOT | 0.3 | -4.2 | 0.0 | 0.0 | 1.0 | -8.3 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 10.3 | +0.0 | 158.3 | 263.3 | 14.7 | +0.0 | 131.7 | 0.0 |
| STAY WORTH | 8.3 | +74.1 | 0.0 | 84.0 | 8.3 | +13.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 1.7 | +194.5 | 0.0 | 0.0 | 4.7 | +225.4 | 0.0 | 0.0 |
| SUPPORT NARROWED | 1.0 | +0.0 | 0.0 | 20.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 1.7 | +194.5 | 0.0 | 0.0 | 4.7 | +225.4 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +7.4 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 20.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -37.8 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | 4.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 42.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 4.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 23.3 | +0.0 | 0.0 | 347.3 | 39.3 | +0.0 | 0.0 | 100.0 |
| TIED UP BY THE SUM | 1.0 | +142.0 | 83.3 | 0.0 | 1.0 | +151.0 | 42.0 | 0.0 |
| TIME ON OUR SIDE | 20.3 | +332.2 | 0.0 | 431.3 | 3.7 | +36.3 | 0.0 | 0.0 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | - | - | - | - | 0.7 | -2.1 | 131.7 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +25.0 | 0.0 | 25.0 |
| WHOLE FIGHT DANGER | 4.7 | -992.2 | 0.0 | 0.0 | 1.3 | -377.2 | 0.0 | 126.7 |
| WHOLE FIGHT GAIN | 0.7 | +25.0 | 286.7 | 0.0 | 0.3 | +8.1 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 1.7 | +11.3 | 0.0 | 0.0 |

### Rule changes: ccut-c940641-p9

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 97 | 97 | 78 | 26.00 | +0 | +0.0 |
| ARMY TABLE | 97 | 97 | 71 | 23.67 | +1236 | +17.4 |
| HIS MOVE WHY | 77 | 77 | 58 | 19.33 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 52 | 52 | 48 | 16.00 | +2707 | +56.4 |
| LEGAL CHARGES ONLY | 41 | 41 | 41 | 13.67 | +0 | +0.0 |
| FIVE ACTION | 389 | 374 | 29 | 9.67 | +1365 | +47.1 |
| DEPLOY BY FIGURES | 45 | 45 | 25 | 8.33 | +242 | +9.7 |
| HIS SHOT LIST | 176 | 167 | 25 | 8.33 | +161 | +6.4 |
| MOVE TO CHARGE COMPUTED | 50 | 43 | 22 | 7.33 | +805 | +36.6 |
| THE TABLE AGAIN | 26 | 26 | 22 | 7.33 | +0 | +0.0 |
| MEETS IN TIME | 25 | 25 | 19 | 6.33 | +1217 | +64.0 |
| PROMISE BY ITS OWN SUM | 53 | 53 | 19 | 6.33 | -1286 | -67.7 |
| OFF BEST | 16 | 16 | 16 | 5.33 | -436 | -27.2 |
| HIS SHOTS BY HIS RUN | 143 | 137 | 15 | 5.00 | +146 | +9.8 |
| GOAL WALK | 49 | 49 | 14 | 4.67 | +757 | +54.1 |
| NEXT CHARGE BY LIST | 33 | 29 | 14 | 4.67 | +768 | +54.9 |
| FOUR ROUNDS | 20 | 19 | 12 | 4.00 | +440 | +36.7 |
| HIS ONE MOVE | 42 | 41 | 12 | 4.00 | +0 | +0.0 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| IDLE COST | 56 | 51 | 10 | 3.33 | +111 | +11.1 |
| QUARTER ODDS | 59 | 58 | 10 | 3.33 | +583 | +58.3 |
| THE RISK READS HIS RUN | 12 | 12 | 9 | 3.00 | +0 | +0.0 |
| LANE BY FIGURES | 8 | 8 | 8 | 2.67 | +267 | +33.4 |
| SUPPORT ADDS | 19 | 17 | 7 | 2.33 | +427 | +61.0 |
| SUPPORT WORKED OUT | 19 | 17 | 7 | 2.33 | +427 | +61.0 |
| COVER ONCE | 59 | 39 | 6 | 2.00 | +154 | +25.7 |
| FOLLOW UP WEIGHED | 6 | 6 | 6 | 2.00 | +1186 | +197.7 |
| MAX FOR POSITIONING | 10 | 10 | 6 | 2.00 | +0 | +0.1 |
| SHOT RISK POINTS | 124 | 116 | 6 | 2.00 | +52 | +8.6 |
| TIED UP BY THE SUM | 6 | 6 | 6 | 2.00 | +204 | +34.0 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 10 | 10 | 5 | 1.67 | +0 | +0.0 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | +705 | +140.9 |
| SHOOTS FROM THE BEST SPOT | 8 | 8 | 5 | 1.67 | +95 | +19.1 |
| CAST JOB | 4 | 4 | 4 | 1.33 | +5 | +1.3 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHARGE LOSSES | 75 | 72 | 4 | 1.33 | +417 | +104.3 |
| CHARGE NOW FIRST | 15 | 15 | 4 | 1.33 | -348 | -87.1 |
| SHOOTERS IN TWO RANKS | 4 | 4 | 4 | 1.33 | +11 | +2.8 |
| HARD STAY DROPPED | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MANOEUVRE | 6 | 6 | 3 | 1.00 | +7 | +2.3 |
| ONE PROMISE A TARGET | 3 | 3 | 3 | 1.00 | -97 | -32.3 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +37 | +12.3 |
| RISK BY ARC | 18 | 17 | 3 | 1.00 | +65 | +21.8 |
| SEARCH SPOT | 4 | 4 | 3 | 1.00 | +56 | +18.8 |
| TIME ON OUR SIDE | 72 | 55 | 3 | 1.00 | +19 | +6.5 |
| WHOLE FIGHT DANGER | 18 | 18 | 3 | 1.00 | +89 | +29.8 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +269 | +134.7 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HIS TURN DENIED | 9 | 9 | 2 | 0.67 | +40 | +20.2 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +46 | +23.1 |
| NO DOUBLE ROUNDS | 18 | 17 | 2 | 0.67 | +55 | +27.5 |
| ONE OBJECTIVE FORMULA | 25 | 22 | 2 | 0.67 | +23 | +11.3 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +26 | +13.2 |
| REDIRECT BY WHAT IT STOPS | 4 | 4 | 2 | 0.67 | +0 | +0.0 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +74 | +36.8 |
| STAY WORTH | 50 | 42 | 2 | 0.67 | +5 | +2.3 |
| SUPPORT NARROWED | 4 | 4 | 2 | 0.67 | -304 | -152.2 |
| THE ROW IN ITS ORDER | 13 | 2 | 2 | 0.67 | +0 | +0.0 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +91 | +90.6 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +3 | +2.9 |
| EXACT ROUND | 13 | 13 | 1 | 0.33 | +3 | +2.6 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +65 | +65.3 |
| FALLS SHORT | 63 | 52 | 1 | 0.33 | +29 | +29.4 |
| FIGHT TO THE END | 10 | 9 | 1 | 0.33 | +3 | +2.7 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +50 | +49.7 |
| HONEST WORTH | 19 | 18 | 1 | 0.33 | +9 | +8.8 |
| MARCH CHECK | 1 | 1 | 1 | 0.33 | +35 | +34.7 |
| MISSILES IN THE MOVE | 16 | 13 | 1 | 0.33 | +26 | +25.7 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.33 | -110 | -110.2 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +49 | +48.6 |
| SET UP BY THE SET | 8 | 8 | 1 | 0.33 | +20 | +20.0 |
| SHOTS AFTER THE MOVES | 9 | 9 | 1 | 0.33 | +0 | +0.0 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +19 | +18.9 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +46 | +45.9 |
| BACKUP TARGETS | 1 | not checked | - | - | - | - |
| CANNON PLANNED TARGET | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | not checked | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 81 | 76 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 3 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 15 | 15 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 33 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 30 | 26 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 7 | 7 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 3 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 20 | 17 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 71 | 67 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 30 | 30 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 33 | 33 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 17 | 15 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 16 | 16 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 38 | 37 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 25 | 25 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 12 | 12 | 0 | 0.00 | - | - |
| HIS TURN RUN | 26 | 26 | 0 | 0.00 | - | - |
| HOLD ODDS | 72 | 72 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 18 | 18 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LOST AFTER ESCAPE | 9 | 8 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 7 | 7 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 21 | 18 | 0 | 0.00 | - | - |
| NEARER NOT NEEDED | 47 | 44 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 14 | 14 | 0 | 0.00 | - | - |
| NO SECOND RUN | 14 | 14 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 3 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 31 | 18 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 3 | 2 | 0 | 0.00 | - | - |
| ONE ROUTE | 7 | 7 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 6 | 6 | 0 | 0.00 | - | - |
| PLAN RESULT | 178 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 3 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 3 | 3 | 0 | 0.00 | - | - |
| REAL GROUND | 7 | 7 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 12 | 9 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 13 | 10 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 6 | 6 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 6 | 6 | 0 | 0.00 | - | - |
| RUN DOWN | 9 | 9 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 4 | not checked | - | - | - | - |
| SET CREDITED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 21 | not checked | - | - | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SHOTS IN THE MOVE | 51 | 42 | 0 | 0.00 | - | - |
| SPELL WORTH | 1 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 41 | 35 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 6 | 6 | 0 | 0.00 | - | - |
| STANDS STILL | 75 | 70 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 6 | 6 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 6 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 15 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 1 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 9 | not checked | - | - | - | - |
| THE TABLE BINDS | 188 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 3 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 3 | 2 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 5 | 5 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p9

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 2.00 | 4.33 | 67.7 |
| JOB FIRST | gate | 1.00 | 3.33 | 24.7 |
| ARMY TABLE | rule | 0.33 | 3.33 | 78.1 |
| CHARGE NOW FIRST | rule | 1.00 | 0.33 | 87.1 |
| HOLDER ASSIGNMENT | rule | 0.33 | 1.00 | 13.5 |
| ONE PROMISE A TARGET | rule | - | 1.00 | 32.3 |
| JOINT CHARGE NOW | rule | 0.67 | - | 37.4 |
| SUPPORT NARROWED | rule | 0.67 | - | 152.2 |
| AFTERMATH BAND | gate | - | 0.33 | 0.9 |
| FIGHT ORDER BAND | gate | 0.33 | - | 0.8 |
| FOLLOW UP WEIGHED | rule | - | 0.33 | 0.9 |
| NO REASON | gate | - | 0.33 | 113.4 |
| PURSUES BIG PREY | rule | - | 0.33 | 110.2 |

### Plans: ccut-c940641-p9

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.7 | 62% | 306 | 310 | 101% |
| Mine | move | 17.7 | 92% | 1179 | 0 | 0% |
| Mine | shoot | 2.0 | 67% | 168 | 85 | 50% |
| Opponent | charge | 3.3 | 80% | 588 | 562 | 96% |
| Opponent | join | 2.3 | 100% | 101 | 0 | 0% |
| Opponent | move | 27.3 | 96% | 986 | 0 | 0% |
| Opponent | shoot | 2.7 | 62% | 56 | 133 | 238% |
| Opponent | support | 1.3 | 100% | 10 | 0 | 0% |

### Battle groups: ccut-c940641-p9

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.7 | 50% | 0% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 3.3 | 20% | 50% | 0% | - | 100% | 0% | 0% | 0% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p9

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 2 | 96 (2) | 96 | 0 | 44 | 0% | 1.0 | - | 96 (2) | - | 0 (1) | 172 (1) |
| Mine | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 3 | 36 (3) | 8 | 28 | 0 | 0% | 2.3 | - | 36 (3) | - | 106 (1) | 11 (2) |
| Mine | Shooter | 2 | 124 (2) | 25 | 99 | 42 | 0% | 2.0 | 95 (1) | 145 (1) | - | 95 (1) | 145 (1) |
| Opponent | Chaff | 4 | 202 (4) | 190 | 12 | 75 | 50% | 3.0 | 405 (2) | 44 (2) | - | 405 (2) | 44 (2) |
| Opponent | Character | 4 | 18 (4) | 18 | 0 | 40 | 75% | 2.0 | - | 24 (2) | 0 (1) | 27 (1) | 0 (2) |
| Opponent | Fast Hammer | 3 | 0 (3) | 0 | 0 | 57 | 33% | 2.0 | 0 (1) | - | 0 (2) | - | 0 (3) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 76 | 0% | 3.5 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |

### Charged fights: ccut-c940641-p9

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 1 | 75 | 913 | 5.0 | 1.0 | 183 | 12 | +171 | 3 of 5 | 2 of 5 | - | +171 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |

### Effective charges: ccut-c940641-p9

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 5 | 0 | 0 | 1 (net -60) | 0 | 1 (net +60) | 1 (net +190) | 2 | 33% (1 of 3) |
| Opponent | Vampire Counts | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: ccut-c940641-p9

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 60 | 75 | -60 | 56 | 60 | -4 | -6.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 497 | 190 | +190 | 190 | 0 | +190 | +38.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 432 | 60 | +60 | 60 | 0 | +60 | +13.9 |
| Mine | No odds | 2 | 497 | 380 | +332 | 332 | 0 | +332 | +66.7 |
| Mine | All fights | 5 | 397 | 217 | +171 | 194 | 12 | +182 | +45.9 |
| Opponent | 76-89% | 1 | 186 | 126 | +0 | 63 | 0 | +63 | +33.9 |
| Opponent | All fights | 1 | 186 | 126 | +0 | 63 | 0 | +63 | +33.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p9 | move | 24 | 7 (29%) | 6 (25%) | 2 (8%) | 15 (62%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1527, L1625 |
| Invocation of Nehek | Opponent | L1527, L1625 |
| Ring of Doom | Mine | L1527 |

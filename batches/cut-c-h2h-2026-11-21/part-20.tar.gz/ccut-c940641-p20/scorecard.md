# Doctrine scorecard: ccut-c940641-p20

### Scorecard: ccut-c940641-p20

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1323 | 3 | 1 | Mine | no | 1 | 2 | 4 | 0 | 0 | 0 | 0 | 317 |
| L1323 | 3 | 1 | Opponent | yes | 0 | 2 | 7 | 2 | 1 | 0 | 0 | 66 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | - | 2 | 1 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Mine | no | 4 | 6 | 1 | 3 | 0 | 0 | 0 | 246 |
| L1435 | 1 | 1 | Opponent | no | 0 | 1 | 1 | 5 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 2.5 | 3.3 | 3.7 | 1.7 | 0.0 | 0.0 | 0.0 | 187.7 |
| **Average** | | | Opponent | 50% | 0.0 | 1.5 | 3.3 | 2.7 | 0.3 | 0.0 | 0.0 | 22.0 |

### KPIs: ccut-c940641-p20

Rules off - Mine only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 14) | 6% (1 of 16) | 3% (1 of 30) |
| Winner chose to follow up after the loser gave ground |  | 50% (1 of 2); on the table 50% | 100% (2 of 2); on the table 100% | 75% (3 of 4); on the table 75% |
| Winner chose to pursue after the loser fell back in good order |  | - | 50% (1 of 2); on the table 50% | 50% (1 of 2); on the table 50% |
| Winner chose to pursue after the loser fled |  | 67% (2 of 3); on the table 67% | 100% (2 of 2); on the table 100% | 80% (4 of 5); on the table 80% |
| Winner chose to follow up or pursue (all three) |  | 60% (3 of 5); on the table 60% | 83% (5 of 6); on the table 83% | 73% (8 of 11); on the table 73% |
| Magic missiles tried each own turn | 50%+ | 28% (5 of 18) | - | 28% (5 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 36% (5 of 14) | - | 36% (5 of 14) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 60% (3606 of 6000) | 53% (3152 of 6000) | 56% (6758 of 12000) |
|   infantry points that never fought | lower | 38% (354 of 923) | 69% (797 of 1159) | 55% (1151 of 2082) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 65% (17 of 26) | 79% (19 of 24) | 72% (36 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.7 uses a game | 100% (2 of 2); 2.3 uses a game | 100% (3 of 3); 2.0 uses a game |
| Bound items with another spell used |  | 29% (4 of 14); 1.7 uses a game | 0.0 uses a game | 29% (4 of 14); 0.8 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 63% (3663 of 5860) | 79% (4057 of 5131) | 70% (7720 of 10991) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (23%) | - | 1.0 (23%) |
| MARCHED: its unit marched | 2.0 (46%) | - | 2.0 (46%) |
| GONE: slain | 1.3 (31%) | - | 1.3 (31%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 5.7 | 4.3 | 3.0 | 1.7 | 0.0 |
| not cast | 2.3 | 5.7 | 5.0 | 4.3 | 28.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.3 (41%) | 0.0 (0%) | 1.0 (23%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (46%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (86%) | 2.0 (35%) | 2.0 (40%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 1.3 (24%) | 1.3 (27%) | 1.3 (31%) | 6.0 (21%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.3 (14%) | 0.0 (0%) | 1.7 (33%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 21.7 (77%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 3.0 a game | 0.0 a game | 1.5 a game |
| stood (cast and not dispelled) | 56% (5 of 9) | - | 56% (5 of 9) |
| the unit moved after it | 20% (1 of 5) | - | 20% (1 of 5) |
| it charged on its next turn | 0% (0 of 5) | - | 0% (0 of 5) |
| the enemy charged it first | 20% (1 of 5) | - | 20% (1 of 5) |
| it fought by the end of its next turn | 20% (1 of 5) | - | 20% (1 of 5) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 5) | - | 0% (0 of 5) |
| none of these (no charge, no fight, no charge escaped) | 80% (4 of 5) | - | 80% (4 of 5) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 49% (40 of 81) | 61% (64 of 105) | 56% (104 of 186) |
|   cavalry | 29% (7 of 24) | 71% (15 of 21) | 49% (22 of 45) |
|   character | 18% (5 of 28) | 52% (11 of 21) | 33% (16 of 49) |
|   chariot | - | 82% (9 of 11) | 82% (9 of 11) |
|   infantry | 95% (19 of 20) | 55% (23 of 42) | 68% (42 of 62) |
|   monster | - | 60% (6 of 10) | 60% (6 of 10) |
|   war machine | 100% (9 of 9) | - | 100% (9 of 9) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (17%) | 1.0 (7%) | 3.3 (12%) |
| CHARGED: it charged | 1.7 (12%) | 2.7 (20%) | 4.3 (16%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.7 (5%) | 0.7 (2%) |
| NO TARGET IN RANGE | 7.7 (56%) | 4.3 (32%) | 12.0 (44%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 1.7 (12%) | 1.7 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.0 (15%) | 3.0 (22%) | 5.0 (18%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.3 (2%) | 0.3 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 11.7 | 0.7 | 94% | 2.1 pts | 24 pts |
| character | 6.7 | 2.3 | 70% | 8.8 pts | 59 pts |
| chariot | 3.0 | 2.0 | 67% | 38.1 pts | 114 pts |
| infantry | 21.3 | 4.7 | 83% | 9.9 pts | 212 pts |
| monster | 2.7 | 1.3 | 62% | 27.2 pts | 73 pts |
| war machine | 3.0 | 0.3 | 89% | 3.6 pts | 11 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.0 | 4.7 | 4.3 |
| Charges that made contact a game | 3.3 | 3.0 | 3.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (3 units) | - | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.52 declared, 0.43 contact (23 units) | 0.42 declared, 0.27 contact (33 units) | 0.46 declared, 0.34 contact (56 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 65% (11 of 17) | - | - | 65% (11 of 17) |
| Character in a unit | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Character on its own | - | 50% (2 of 4) | 62% (5 of 8) | 58% (7 of 12) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 90% (9 of 10) | 100% (1 of 1) | - | 91% (10 of 11) |
| Monster | 50% (1 of 2) | 100% (1 of 1) | - | 67% (2 of 3) |
| Monstrous | 100% (2 of 2) | 100% (2 of 2) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 3 | 60% (3 of 5); on the table 60% | 28% (5 of 18) | 60% | 65% (17 of 26) | 100% (1 of 1); 1.7 uses a game | 29% (4 of 14); 1.7 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (1 of 1); on the table 100% | - | 41% | 86% (6 of 7) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (4 of 4); on the table 100% | - | 23% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 0% (0 of 1); on the table 0% | - | 94% | 83% (10 of 12) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p20, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 71% (5) | 25% (1) | 55% (6) |
| ...free all their last turn and able to turn (per game) | 1.33 | 0.33 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.33 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: ccut-c940641-p20

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.0 | 1.7 |
| Strategy | Charge objectives carried out (made contact) | 83% (10 of 12) | 22% (2 of 9) |
| Strategy | Shoot objectives carried out (shot that target) | 36% (9 of 25) | 53% (9 of 17) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 3) | 100% (5 of 5) |
| Strategy | Joined characters whose unit fought | - | 50% (1 of 2) |
| Strategy | Lone characters that fought | 43% (3 of 7) | 60% (3 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.7 | 2.7 |
| Movement | Points that never moved of their own | 187.7 | 22.0 |
| Movement | Fights charged into per game | 3.3 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 9 | 1 of 5, net +300 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 9 | 1 of 5, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 4 of 9, net +43 | 0 of 5 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 9, net +297 | 2 of 5, net +124 |
| Shooting | Shots by shooting units (incl. breath weapons) | 12.3 | 22.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 24% (9 of 37) | 60% (41 of 68) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 3.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 89% (8 of 9) | - |
| Shooting | Points destroyed by war machines | 0.0 | 166.7 |
| Magic | Magic missiles cast | 1.0 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (1 of 3) | - |
| Magic | Wounds caused by magic missiles | 1.3 | 0.3 |
| Magic | Wounds caused by other spells | 1.0 | - |
| Magic | Points destroyed by magic (all spells) | 23.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 1.0 / 0.0 / 0.0 | 3.0 / 1.7 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 361.0 | 50.3 |
| Combat | Points run down | 0.0 | 59.0 |
| Combat | Net points per charged fight, damage counted | +125 | +103 |
| Combat | Net per 100 charger points, damage counted | +39.5 | +31.3 |
| Combat | First round won (charged fights) | 80% | 78% |
| Combat | Net points per charged fight | +114 | +88 |
| Combat | Net points per supported fight / lone fight | - / +114 | - / +88 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 10 | 2 of 9 |
| Game | Points lost | 449.7 | 384.7 |
| Game | VP from objectives | 370.0 | 1003.3 |
| Game | Lone holders (player turns) | 2.5 | 0.0 |

- Mine won / drew / lost: 0 / 1 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -642 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 834
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: ccut-c940641-p20

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +103.4 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 24.7 | +477.8 | 0.0 | 523.0 | 36.0 | +297.2 | 0.0 | 245.3 |
| BEST PRIZE | 0.3 | +2.8 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.7 | +0.1 | 0.0 | 100.7 | - | - | - | - |
| CANNON PLANNED TARGET | 3.0 | +0.0 | 0.0 | 93.3 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | - | - | - | - | 0.3 | -66.9 | 76.7 | 0.0 |
| CAST JOB | 1.0 | +19.2 | 66.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.7 | +0.0 | 0.0 | 166.7 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 0.3 | +9.4 | 0.0 | 11.3 |
| CHAFF PASSED | 0.3 | -0.9 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 1.3 | +89.5 | 0.0 | 159.7 | 1.0 | +36.9 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | 0.3 | -1.3 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LIST READ AGAIN | 0.3 | +5.2 | 22.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 23.7 | -1116.2 | 0.0 | 486.7 | 15.3 | -782.0 | 0.0 | 23.3 |
| CHARGE NOW FIRST | 3.0 | +0.0 | 293.0 | 0.0 | 2.7 | +0.0 | 313.0 | 0.0 |
| CHARGER SLAIN LOST | 0.3 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 8.7 | +0.0 | 0.0 | 153.3 | 10.3 | +0.0 | 0.0 | 11.3 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 3.0 | +335.5 | 166.7 | 166.7 | - | - | - | - |
| COVER ONCE | 8.0 | -377.0 | 0.0 | 135.7 | 8.0 | -579.5 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -1.3 | 76.7 | 0.0 |
| DEPLOY BY FIGURES | 8.0 | -26.8 | 0.0 | 0.0 | 9.3 | +8.3 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -42.4 | 0.0 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.3 | +7.5 | 20.0 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | 0.7 | +2.0 | 0.0 | 59.0 | 2.0 | +84.3 | 0.0 | 0.0 |
| EXACT ROUND | 2.0 | +20.6 | 172.7 | 0.0 | 2.0 | +30.9 | 100.0 | 0.0 |
| FALL BACK GOOD ORDER | 3.3 | +11.2 | 303.7 | 0.0 | 1.7 | +13.4 | 254.0 | 0.0 |
| FALLS SHORT | 8.3 | +100.0 | 0.0 | 166.7 | 16.7 | +109.9 | 0.0 | 88.7 |
| FEATURE BUFFS | 3.0 | +23.3 | 0.0 | 0.0 | 2.3 | +29.5 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +0.3 | 0.0 | 0.0 | 0.3 | +19.8 | 76.7 | 0.0 |
| FIVE ACTION | 94.7 | +3754.6 | 517.7 | 1364.7 | 108.0 | +6645.5 | 2079.7 | 840.0 |
| FLANK NOT WEIGHED | 6.0 | +0.0 | 0.0 | 177.3 | 8.7 | +0.0 | 0.0 | 11.3 |
| FOLLOW UP WEIGHED | - | - | - | - | 0.7 | +82.2 | 0.0 | 0.0 |
| FOUR ROUNDS | 4.0 | +180.6 | 315.0 | 0.0 | 4.0 | +259.4 | 336.3 | 0.0 |
| FREED FROM HIS FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.3 | -0.2 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 1.0 | -27.6 | 76.7 | 0.0 |
| GOAL WALK | 5.0 | +380.4 | 0.0 | 177.3 | 8.3 | +462.1 | 0.0 | 0.0 |
| GUN FIGURES | - | - | - | - | 2.0 | +78.7 | 166.7 | 61.7 |
| GUN MASK | 1.0 | -5.7 | 0.0 | 151.0 | - | - | - | - |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 25.7 |
| HE REFORMS ONCE FREED | 0.7 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 14.7 | +0.0 | 0.0 | 153.3 | 7.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.7 | +27.7 | 76.7 | 0.0 |
| HIS CHARGE LIST | 7.7 | +0.0 | 0.0 | 100.7 | 16.3 | +0.0 | 0.0 | 22.0 |
| HIS LEGAL MOVES | 6.0 | +0.0 | 0.0 | 320.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 5.7 | -64.6 | 0.0 | 410.0 | 4.7 | -40.9 | 0.0 | 23.3 |
| HIS MOVE AS HE DECIDES | 52.0 | +17.3 | 343.0 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 17.3 | +0.0 | 0.0 | 312.7 |
| HIS ONE MOVE | 24.3 | -149.3 | 0.0 | 50.3 | - | - | - | - |
| HIS ONE QUARTER | 7.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 3.0 | +0.0 | 0.0 | 166.7 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 64.3 | +3491.8 | 0.0 | 983.3 | 63.3 | +1538.3 | 0.0 | 419.3 |
| HIS SHOTS BY HIS RUN | 57.7 | +1790.5 | 0.0 | 900.3 | 36.7 | +414.5 | 0.0 | 526.0 |
| HIS TURN DENIED | 1.0 | +90.5 | 42.0 | 0.0 | 1.3 | +29.3 | 82.3 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 17.3 | +0.0 | 0.0 | 0.0 | 16.3 | +0.0 | 0.0 | 44.0 |
| HOLDER ASSIGNMENT | 9.0 | +907.9 | 0.0 | 0.0 | 10.0 | +973.1 | 0.0 | 22.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.7 | -203.0 | 315.0 | 0.0 | 4.0 | -176.2 | 336.3 | 0.0 |
| IDLE COST | 4.7 | -68.6 | 0.0 | 0.0 | 14.7 | -186.8 | 0.0 | 45.3 |
| KEPT FROM ITS LAST STOP | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.7 | +82.5 | 0.0 | 0.0 | 1.0 | +20.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 2.3 | +0.0 | 0.0 | 50.3 | 2.7 | +0.0 | 59.0 | 189.7 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.3 | +37.5 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 2.0 | +2.0 | 139.3 | 0.0 | 1.7 | +3.0 | 236.3 | 0.0 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.7 | -114.4 | 0.0 | 11.3 |
| MAKE SURE TOGETHER | - | - | - | - | 0.7 | +0.5 | 0.0 | 0.0 |
| MANOEUVRE | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +112.3 | 0.0 | 13.3 |
| MARCH BY THE SUM | 1.0 | +41.8 | 0.0 | 166.7 | - | - | - | - |
| MARCH CHECK | 0.7 | +24.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.7 | +34.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 2.0 | +193.2 | 0.0 | 166.7 | - | - | - | - |
| MARCH WHEELS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.7 | +21.5 | 0.0 | 0.0 | 2.3 | +34.9 | 0.0 | 25.7 |
| MEETS IN TIME | 3.3 | +208.6 | 0.0 | 0.0 | 6.0 | +79.8 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.7 | +30.8 | 0.0 | 0.0 | 3.3 | +66.6 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 5.7 | +28.6 | 0.0 | 166.7 | 3.3 | +60.8 | 0.0 | 0.0 |
| MOVE ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 22.0 | 0.0 |
| MOVE SPELL SPOT | 1.7 | +0.0 | 0.0 | 166.7 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 7.0 | +607.9 | 0.0 | 0.0 | 5.7 | +247.9 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 8.3 | +326.2 | 0.0 | 203.7 | 8.3 | +365.3 | 0.0 | 159.3 |
| NEXT CHARGE BY LIST | 4.0 | +378.9 | 0.0 | 0.0 | 3.7 | +154.5 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.7 | -58.2 | 273.0 | 0.0 | 3.3 | -164.1 | 336.3 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 0.3 | -0.7 | 0.0 | 0.0 |
| OFF BEST | 8.0 | -238.6 | 0.0 | 123.3 | 6.7 | -299.2 | 50.3 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 4.7 | -108.7 | 0.0 | 0.0 | 5.3 | -118.5 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 5.3 | -24.9 | 0.0 | 0.0 | 4.0 | -127.8 | 0.0 | 22.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | -2.1 | 0.0 | 0.0 |
| ONE ROUTE | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +33.7 | 11.3 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 2.0 | +22.4 | 170.7 | 0.0 | 1.7 | +3.0 | 262.7 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +7.3 | 0.0 | 0.0 |
| PLAN RESULT | 42.3 | +352.1 | 240.7 | 840.3 | 49.3 | +1206.6 | 370.3 | 555.3 |
| PROMISE BY ITS OWN SUM | 10.0 | -319.3 | 0.0 | 0.0 | 11.0 | -295.9 | 0.0 | 0.0 |
| PROMISE IN STEPS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.3 | -2.0 | 23.3 | 0.0 | - | - | - | - |
| PURSUES BIG PREY | - | - | - | - | 0.3 | -5.8 | 0.0 | 0.0 |
| QUARTER ODDS | 15.7 | +1366.0 | 23.3 | 0.0 | 20.7 | +2298.2 | 23.3 | 0.0 |
| REAL GROUND | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 3.7 | +313.4 | 0.0 | 68.7 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 3.3 | +0.0 | 0.0 | 94.3 |
| REDIRECT WEIGHED | 0.3 | +2.8 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 2.3 | -122.3 | 0.0 | 0.0 | 2.3 | -86.9 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 3.7 | -76.9 | 315.0 | 0.0 | 3.0 | -11.0 | 313.0 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 1.0 | -37.2 | 200.7 | 0.0 | 1.7 | -42.8 | 200.7 | 0.0 |
| RUN DOWN | 2.0 | -22.0 | 139.3 | 0.0 | 3.7 | -27.3 | 336.3 | 0.0 |
| SCOUT SPOT | - | - | - | - | 1.3 | -0.1 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | -104.9 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +7.3 | 0.0 | 50.3 | 0.7 | +1.0 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.7 | +26.2 | 50.3 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 1.0 | -36.0 | 0.0 | 0.0 |
| SET UP BY THE SET | - | - | - | - | 2.3 | +36.1 | 50.3 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.7 | +0.5 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.7 | +88.1 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +2.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 8.3 | +0.0 | 0.0 | 152.3 | 7.0 | +0.0 | 0.0 | 153.7 |
| SHOOTS FROM THE BEST SPOT | 2.0 | +45.4 | 23.3 | 0.0 | 3.3 | +32.0 | 576.7 | 0.0 |
| SHOT OR CHARGE | 0.7 | -4.8 | 22.7 | 0.0 | 0.7 | -10.8 | 76.7 | 0.0 |
| SHOT RISK POINTS | 39.0 | -366.3 | 0.0 | 712.0 | 19.7 | -215.8 | 0.0 | 80.0 |
| SHOTS AFTER THE MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 13.7 | +278.1 | 0.0 | 211.3 | 22.0 | +669.4 | 0.0 | 365.3 |
| SPELL SETS UP CHARGE | 0.7 | +88.1 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 2.0 | +31.0 | 0.0 | 0.0 | 1.7 | +20.9 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | +2.2 | 25.7 | 0.0 | 0.3 | -6.2 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 7.0 | +0.0 | 0.0 | 344.0 | 5.0 | +0.0 | 0.0 | 87.3 |
| STAND AND SHOOT | 1.3 | -4.4 | 222.7 | 0.0 | 1.3 | -7.9 | 82.3 | 0.0 |
| STANDS FOR A REASON | 1.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 40.0 | +0.0 | 202.7 | 473.0 | 43.3 | +0.0 | 1743.3 | 409.3 |
| STAY WORTH | 23.0 | +75.2 | 179.3 | 317.0 | 16.3 | +91.0 | 333.3 | 61.7 |
| STRIKE BY THE ODDS | 0.3 | +18.0 | 20.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 3.0 | +337.8 | 0.0 | 227.7 | 4.7 | +279.6 | 0.0 | 11.3 |
| SUPPORT NARROWED | 0.3 | +0.0 | 22.0 | 0.0 | 0.7 | +0.0 | 153.3 | 0.0 |
| SUPPORT WORKED OUT | 3.0 | +337.8 | 0.0 | 227.7 | 4.7 | +279.6 | 0.0 | 11.3 |
| SURE REACH TOGETHER | - | - | - | - | 1.7 | +30.3 | 0.0 | 44.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.3 | +0.0 | 0.0 | 50.3 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -8.2 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.0 | +0.0 | 0.0 | 100.7 | 3.7 | +0.0 | 0.0 | 61.7 |
| THE ROW KEEPS ITS WAY | 3.7 | +0.0 | 0.0 | 50.3 | 6.7 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 45.0 | +0.0 | 0.0 | 605.7 | 51.7 | +0.0 | 0.0 | 425.7 |
| TIED UP BY THE SUM | 1.7 | +135.5 | 88.7 | 0.0 | 1.7 | +283.3 | 159.7 | 0.0 |
| TIME ON OUR SIDE | 37.3 | +410.8 | 44.0 | 499.0 | 25.3 | +274.6 | 0.0 | 378.3 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | - | - | - | - | 0.3 | +0.0 | 166.7 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -54.4 | 0.0 | 0.0 |
| WHO FIGHTS | 0.3 | -0.5 | 25.7 | 0.0 | 0.3 | -4.5 | 76.7 | 0.0 |
| WHO HITS BACK | 0.7 | +52.7 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | - | - | - | - | 0.3 | +27.6 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.7 | -277.6 | 0.0 | 153.3 | 2.7 | -458.2 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 1.0 | +61.2 | 0.0 | 0.0 |

### Rule changes: ccut-c940641-p20

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 182 | 182 | 142 | 47.33 | +2553 | +18.0 |
| HIS MOVE AS HE DECIDES | 156 | 156 | 104 | 34.67 | +0 | +0.0 |
| HIS SHOT LIST | 383 | 353 | 96 | 32.00 | +1294 | +13.5 |
| HIS SHOTS BY HIS RUN | 283 | 260 | 66 | 22.00 | +1213 | +18.4 |
| HOLDER ASSIGNMENT | 57 | 57 | 53 | 17.67 | +3390 | +64.0 |
| OFF BEST | 44 | 44 | 44 | 14.67 | -1614 | -36.7 |
| DEPLOY BY FIGURES | 52 | 52 | 32 | 10.67 | +353 | +11.0 |
| THE TABLE AGAIN | 36 | 36 | 32 | 10.67 | +0 | +0.0 |
| SHOT RISK POINTS | 176 | 162 | 30 | 10.00 | +958 | +31.9 |
| HIS MOVE WHY | 52 | 52 | 27 | 9.00 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 63 | 63 | 26 | 8.67 | -1846 | -71.0 |
| MOVE TO CHARGE COMPUTED | 38 | 35 | 23 | 7.67 | +995 | +43.3 |
| FIVE ACTION | 608 | 572 | 20 | 6.67 | +810 | +40.5 |
| TIME ON OUR SIDE | 188 | 160 | 19 | 6.33 | +73 | +3.8 |
| HIS ONE MOVE | 73 | 73 | 18 | 6.00 | +0 | +0.0 |
| QUARTER ODDS | 109 | 95 | 16 | 5.33 | +1319 | +82.5 |
| LEGAL CHARGES ONLY | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| HARD STAY DROPPED | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| MEETS IN TIME | 28 | 28 | 13 | 4.33 | +486 | +37.4 |
| NEXT CHARGE BY LIST | 23 | 23 | 13 | 4.33 | +653 | +50.2 |
| THE RISK READS HIS RUN | 18 | 18 | 13 | 4.33 | +0 | +0.0 |
| ADVANCE LANE KEPT | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| GOAL WALK | 40 | 39 | 12 | 4.00 | +480 | +40.0 |
| STAY WORTH | 118 | 109 | 11 | 3.67 | +92 | +8.3 |
| FOUR ROUNDS | 24 | 21 | 10 | 3.33 | +261 | +26.1 |
| MOVE ORDER | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 107 | 85 | 9 | 3.00 | +311 | +34.6 |
| CHARGE LOSSES | 117 | 107 | 8 | 2.67 | +630 | +78.8 |
| LANE BY FIGURES | 8 | 8 | 8 | 2.67 | +308 | +38.5 |
| CHALLENGE BY POINTS | 7 | 7 | 7 | 2.33 | +379 | +54.1 |
| SUPPORT ADDS | 23 | 23 | 7 | 2.33 | +85 | +12.2 |
| SUPPORT WORKED OUT | 23 | 23 | 7 | 2.33 | +85 | +12.2 |
| TIED UP BY THE SUM | 10 | 8 | 7 | 2.33 | +201 | +28.7 |
| CHARGE NOW FIRST | 17 | 17 | 6 | 2.00 | -215 | -35.9 |
| COVER ONCE | 48 | 26 | 6 | 2.00 | +188 | +31.4 |
| SCOUT WAITS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 16 | 16 | 5 | 1.67 | +54 | +10.8 |
| SHOTS AFTER THE MOVES | 24 | 24 | 5 | 1.67 | +0 | +0.0 |
| EVASIVE BY THE ODDS | 8 | 8 | 4 | 1.33 | +187 | +46.8 |
| SEARCH SPOT | 4 | 4 | 4 | 1.33 | +25 | +6.2 |
| SET UP BY THE SET | 7 | 7 | 4 | 1.33 | +80 | +20.1 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CAST JOB | 3 | 3 | 3 | 1.00 | +27 | +8.9 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +125 | +41.7 |
| MAX FOR POSITIONING | 15 | 14 | 3 | 1.00 | +3 | +1.1 |
| WHOLE FIGHT DANGER | 16 | 16 | 3 | 1.00 | +164 | +54.5 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.67 | +0 | +0.1 |
| CANNON PLANNED TARGET | 9 | 9 | 2 | 0.67 | +0 | +0.0 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| EXACT ROUND | 12 | 10 | 2 | 0.67 | +7 | +3.5 |
| FALLS SHORT | 75 | 68 | 2 | 0.67 | +16 | +8.2 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +246 | +123.2 |
| HIS TURN DENIED | 7 | 6 | 2 | 0.67 | +58 | +29.2 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MANOEUVRE | 9 | 9 | 2 | 0.67 | +390 | +194.8 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -102 | -51.0 |
| NEARER NOT NEEDED | 50 | 49 | 2 | 0.67 | +53 | +26.3 |
| REDIRECT COUNTER | 11 | 10 | 2 | 0.67 | +243 | +121.7 |
| RISK BY ARC | 20 | 17 | 2 | 0.67 | +106 | +52.8 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +78 | +39.2 |
| SET CREDITED ONCE | 3 | 3 | 2 | 0.67 | +3 | +1.4 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +6 | +3.0 |
| SURE REACH TOGETHER | 5 | 5 | 2 | 0.67 | +7 | +3.4 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +71 | +35.5 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +310 | +310.1 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -31 | -31.0 |
| CARRIES OUT SET-UP | 1 | 1 | 1 | 0.33 | -201 | -200.7 |
| CHAFF IN THE MOVE | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -3 | -2.8 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +16 | +15.7 |
| FIGHT TO THE END | 2 | 2 | 1 | 0.33 | +12 | +11.8 |
| HIS CHARGE DENIED | 2 | 1 | 1 | 0.33 | +6 | +6.3 |
| HIS MOVE AND SHOT | 31 | 29 | 1 | 0.33 | +10 | +9.8 |
| HONEST WORTH | 23 | 20 | 1 | 0.33 | +1 | +0.8 |
| IDLE COST | 58 | 42 | 1 | 0.33 | +5 | +5.1 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +112 | +112.5 |
| MARCH CHECK | 2 | 2 | 1 | 0.33 | +65 | +65.2 |
| NO DOUBLE ROUNDS | 18 | 15 | 1 | 0.33 | +1 | +0.8 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -6 | -6.2 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +22 | +21.9 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -6 | -6.1 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.33 | -17 | -17.3 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +93 | +92.8 |
| ROUNDS AFTER TERROR | 8 | 6 | 1 | 0.33 | +1 | +0.8 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +54 | +54.1 |
| THE ROW IN ITS ORDER | 17 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT | 1 | 1 | 1 | 0.33 | +6 | +6.3 |
| WOUNDS ON THE RANKS | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| CASTS AFTER FRIENDS | 5 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 57 | 56 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 9 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | not checked | - | - | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 15 | 13 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 16 | 16 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 44 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 21 | 21 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 6 | not checked | - | - | - | - |
| GUN MASK | 3 | 3 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 17 | 17 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 66 | 61 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 72 | 68 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 29 | 28 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 29 | 23 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 23 | 21 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 101 | 100 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 12 | 11 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 11 | 10 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH OVER CASTS | 6 | 6 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 5 | 5 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 18 | 14 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 27 | 21 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 5 | not checked | - | - | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 30 | 15 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 28 | 24 | 0 | 0.00 | - | - |
| ONE ROUTE | 5 | 5 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 11 | 9 | 0 | 0.00 | - | - |
| PLAN RESULT | 275 | trace | - | - | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 5 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 14 | 13 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 17 | 14 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 2 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 46 | not checked | - | - | - | - |
| SHOT OR CHARGE | 4 | 3 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 2 | not checked | - | - | - | - |
| SPELL WORTH | 11 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 36 | 30 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 8 | 7 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 7 | 0 | 0.00 | - | - |
| STANDS STILL | 250 | 230 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 3 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 15 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 31 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 7 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 20 | not checked | - | - | - | - |
| THE TABLE BINDS | 290 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 4 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 1 | 1 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 1 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p20

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.33 | 5.67 | 35.4 |
| PROMISE BY ITS OWN SUM | rule | 4.33 | 4.33 | 71.0 |
| ARMY TABLE | rule | 4.00 | 4.00 | 49.3 |
| RULE SWITCHED OFF | gate | 2.67 | - | 16.7 |
| CHARGE NOW FIRST | rule | 1.33 | 0.67 | 35.9 |
| NO REASON | gate | - | 1.00 | 103.5 |
| DEPLOY BY FIGURES | rule | - | 0.67 | 6.2 |
| MARCH OF THE TABLE | rule | 0.67 | - | 51.0 |
| BEST PRIZE | rule | 0.33 | - | 31.0 |
| CARRIES OUT SET-UP | rule | - | 0.33 | 200.7 |
| CHAFF PASSED | rule | 0.33 | - | 2.8 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 3.4 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 6.2 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 6.1 |
| PURSUES BIG PREY | rule | - | 0.33 | 17.3 |

### Plans: ccut-c940641-p20

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.3 | 80% | 469 | 272 | 58% |
| Mine | move | 31.7 | 96% | 1472 | 0 | 0% |
| Mine | shoot | 7.3 | 32% | 180 | 80 | 44% |
| Opponent | charge | 3.3 | 40% | 388 | 320 | 82% |
| Opponent | move | 40.3 | 94% | 1729 | 0 | 0% |
| Opponent | shoot | 5.0 | 73% | 886 | 887 | 100% |
| Opponent | support | 0.7 | 100% | 0 | 0 | - |

### Battle groups: ccut-c940641-p20

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 3.7 | 45% | 60% | 20% | 0% | 25% | 0% | 0% | 75% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p20

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 7 | 39 (7) | 39 | 0 | 17 | 14% | 1.2 | 13 (5) | 182 (1) | 0 (1) | 13 (5) | 91 (2) |
| Mine | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 14 | 37 (14) | 4 | 34 | 15 | 50% | 3.4 | 20 (8) | 61 (6) | - | 43 (9) | 28 (5) |
| Mine | Shooter | 4 | 0 (4) | 0 | 0 | 26 | 0% | 1.0 | 0 (3) | 0 (1) | - | 0 (3) | 0 (1) |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 100 | 0% | 1.0 | 0 (2) | - | - | - | 0 (2) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Opponent | Chaff | 7 | 176 (7) | 0 | 176 | 79 | 14% | 2.5 | - | 345 (4) | 16 (3) | 405 (4) | 14 (3) |
| Opponent | Character | 4 | 30 (4) | 30 | 0 | 0 | 0% | 1.5 | - | 30 (4) | - | 0 (2) | 55 (2) |
| Opponent | Clean-up | 4 | 0 (4) | 0 | 0 | 20 | 100% | - | 0 (1) | 0 (2) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | Fast Hammer | 4 | 45 (4) | 45 | 0 | 0 | 25% | 1.7 | 0 (2) | 93 (2) | - | 0 (3) | 154 (1) |
| Opponent | Hammer | 8 | 33 (8) | 33 | 0 | 32 | 38% | 2.6 | 0 (2) | 70 (3) | 0 (3) | 81 (4) | 0 (4) |
| Opponent | Holder | 3 | 141 (3) | 0 | 141 | 31 | 33% | 1.5 | 450 (1) | - | 0 (1) | 450 (1) | 0 (1) |
| Opponent | Shooter | 4 | 66 (4) | 0 | 66 | 0 | 0% | 2.0 | 0 (1) | 142 (2) | 0 (1) | 121 (2) | 28 (2) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 61 | 0% | 2.0 | 0 (2) | - | - | 0 (1) | 0 (1) |

### Charged fights: ccut-c940641-p20

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 3 | 23 | 380 | 3.3 | 1.0 | 114 | 0 | +114 | 3 of 10 | 8 of 10 | - | +114 |
| Opponent | Ogre Kingdoms | 1 | 500 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 849 | 7.0 | 1.0 | 121 | 9 | +113 | 2 of 7 | 6 of 7 | - | +113 |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| **Opponent** | all armies | 3 | 167 | 283 | 3.0 | 1.0 | 94 | 7 | +88 | 2 of 9 | 7 of 9 | - | +88 |

### Effective charges: ccut-c940641-p20

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 10 | 0 | 0 | 0 | 2 (net +38) | 4 (net +43) | 3 (net +297) | 1 | 0% (0 of 9) |
| Opponent | Tomb Kings of Khemri | 7 | 1 (net +300) | 0 | 0 | 1 (net -60) | 0 | 2 (net +124) | 3 | 0% (0 of 4) |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 100% (1 of 1) |

### Charged fights, damage counted: ccut-c940641-p20

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 2 | 143 | 77 | +38 | 38 | 0 | +38 | +26.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 489 | 266 | +297 | 352 | 18 | +334 | +68.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 268 | 58 | +43 | 62 | 0 | +62 | +23.3 |
| Mine | No odds | 1 | 342 | 185 | +0 | 37 | 114 | -77 | -22.5 |
| Mine | All fights | 10 | 317 | 137 | +114 | 142 | 17 | +125 | +39.5 |
| Opponent | Long shot (under 50%) | 1 | 195 | 230 | +300 | 300 | 32 | +268 | +137.2 |
| Opponent | Effective (55-75%) | 1 | 126 | 151 | +0 | 30 | 0 | +30 | +24.0 |
| Opponent | 76-89% | 1 | 431 | 342 | -60 | 0 | 60 | -60 | -13.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 436 | 170 | +124 | 134 | 0 | +134 | +30.7 |
| Opponent | No odds | 4 | 336 | 175 | +76 | 135 | 29 | +106 | +31.6 |
| Opponent | All fights | 9 | 330 | 196 | +88 | 126 | 23 | +103 | +31.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p20 | move | 23 | 5 (22%) | 3 (13%) | 3 (13%) | 15 (65%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Fistful of Laurels | Opponent | L1418 |
| Opal Amulet | Mine | L1418, L1435 |
| Standard of the Fell Warrior | Mine | L1323 |

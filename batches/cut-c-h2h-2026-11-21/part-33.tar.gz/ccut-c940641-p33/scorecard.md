# Doctrine scorecard: ccut-c940641-p33

### Scorecard: ccut-c940641-p33

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1527 | 3 | 1 | Mine | no | 3 | 4 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1527 | 3 | 1 | Opponent | no | 3 | 2 | 6 | 3 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1625 | 5 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1723 | 1 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1723 | 1 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| **Average** | | | Mine | 0% | 3.0 | 4.0 | 1.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| **Average** | | | Opponent | 0% | 3.0 | 2.0 | 6.0 | 3.0 | 0.0 | 0.0 | 0.0 | 0.0 |

### KPIs: ccut-c940641-p33

Rules off - Opponent only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 12) | 0% (0 of 12) | 0% (0 of 24) |
| Winner chose to follow up after the loser gave ground |  | - | 100% (2 of 2); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 67% (2 of 3); on the table 100% | 67% (2 of 3); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | - | 80% (4 of 5); on the table 100% | 80% (4 of 5); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 0% (0 of 4) | 62% (10 of 16) | 50% (10 of 20) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 50% (6 of 12) | 50% (6 of 12) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 9% (176 of 2000) | 24% (474 of 2000) | 16% (650 of 4000) |
|   infantry points that never fought | lower | 58% (176 of 302) | 100% (174 of 174) | 74% (350 of 476) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 14% (1 of 7) | 50% (3 of 6) | 31% (4 of 13) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 1.7 uses a game | 0.0 uses a game | 100% (2 of 2); 0.8 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 9% (176 of 1940) | 33% (509 of 1546) | 20% (685 of 3486) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 2.0 (100%) | 2.0 (100%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 2.3 | 1.3 | 1.3 | 3.3 | 0.3 | 0.7 |
| not cast | 5.3 | 2.0 | 0.7 | 2.0 | 1.0 | 22.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (17%) | 0.0 (0%) | 2.0 (100%) | 1.0 (100%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.3 (17%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.3 (6%) | 1.3 (67%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 5.0 (94%) | 0.0 (0%) | 0.7 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 21.0 (95%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.0 a game | 0.7 a game |
| stood (cast and not dispelled) | - | - | - |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 54% (13 of 24) | - | 54% (13 of 24) |
|   character | 38% (3 of 8) | - | 38% (3 of 8) |
|   chariot | 43% (3 of 7) | - | 43% (3 of 7) |
|   infantry | 78% (7 of 9) | - | 78% (7 of 9) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (45%) | - | 1.7 (45%) |
| CHARGED: it charged | 1.0 (27%) | - | 1.0 (27%) |
| IN COMBAT: it fought this turn or the last | 0.3 (9%) | - | 0.3 (9%) |
| NO TARGET IN RANGE | 0.3 (9%) | - | 0.3 (9%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (9%) | - | 0.3 (9%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| character | 1.3 | 0.7 | 75% | 29.4 pts | 39 pts |
| chariot | 1.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 4.0 | 0.0 | 100% | 0.0 pts | 0 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.3 | 5.7 | 4.0 |
| Charges that made contact a game | 2.3 | 4.0 | 3.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (3 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.50 declared, 0.50 contact (2 units) | 1.00 declared, 1.00 contact (2 units) | 0.75 declared, 0.75 contact (4 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.25 declared, 0.25 contact (24 units) | 0.60 declared, 0.40 contact (25 units) | 0.43 declared, 0.33 contact (49 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 33% (1 of 3) | - | 0% (0 of 2) | 20% (1 of 5) |
| Character in a unit | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Character on its own | - | - | 0% (0 of 3) | 0% (0 of 3) |
| Chariot | 0% (0 of 1) | - | - | 0% (0 of 1) |
| Infantry | 50% (1 of 2) | - | - | 50% (1 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 1 | - | - | 9% | 14% (1 of 7) | 100% (2 of 2); 5.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 80% (4 of 5); on the table 100% | 50% (6 of 12) | 24% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p33, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 33% (2) | 60% (3) | 45% (5) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.67 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.00 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: ccut-c940641-p33

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 60% (3 of 5) | 47% (7 of 15) |
| Strategy | Shoot objectives carried out (shot that target) | 15% (2 of 13) | 0% (0 of 9) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | - | 33% (1 of 3) |
| Strategy | Lone characters that fought | 100% (2 of 2) | 67% (2 of 3) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.0 | 3.0 |
| Movement | Points that never moved of their own | 0.0 | 0.0 |
| Movement | Fights charged into per game | 4.0 | 6.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 4 | 1 of 5, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 4, net +0 | 2 of 5, net +130 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 4, net +60 | 0 of 5 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 4 | 1 of 5, net +296 |
| Shooting | Shots by shooting units (incl. breath weapons) | 5.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 65% (11 of 17) | - |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | - | 1.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 20% (1 of 5) |
| Magic | Wounds caused by magic missiles | 1.0 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.3 / 0.3 / 0.3 / 0.0 | 1.3 / 0.3 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 102.0 | 20.0 |
| Combat | Points run down | 0.0 | 202.7 |
| Combat | Net points per charged fight, damage counted | +30 | +114 |
| Combat | Net per 100 charger points, damage counted | +11.2 | +45.3 |
| Combat | First round won (charged fights) | 75% | 83% |
| Combat | Net points per charged fight | +30 | +114 |
| Combat | Net points per supported fight / lone fight | - / +30 | +296 / +77 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 4 | 2 of 6 |
| Game | Points lost | 817.0 | 306.0 |
| Game | VP from objectives | 460.0 | 690.0 |
| Game | Lone holders (player turns) | 3.0 | 3.0 |

- Mine won / drew / lost: 0 / 0 / 1 of 1 ended games (of 3); mean margin (Mine - Opponent) -791 VP
- The side that went first won 0 of 1 games with a winner
- Points traded per game (both sides' losses): 1123
- Games not ended: 2 (L1625-1, L1723-1); findings 2, warnings 0

### Opponent rules: ccut-c940641-p33

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH IN POINTS | 0.3 | +115.8 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 18.0 | +123.3 | 0.0 | 124.0 | 22.3 | +758.3 | 0.0 | 50.0 |
| BACKUP TARGETS | 0.3 | +0.7 | 0.0 | 0.0 | 0.3 | +1.0 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 1.7 | +17.6 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | - | - | - | - | 1.3 | +7.7 | 40.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 2.0 | +79.9 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | - | - | - | - | 0.3 | +5.1 | 0.0 | 0.0 |
| CHARGE LOSSES | 14.0 | -505.1 | 0.0 | 84.0 | 11.7 | -750.9 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 25.0 | 20.0 | 3.7 | +0.0 | 405.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 9.0 | +0.0 | 0.0 | 0.0 | 11.0 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| COVER ONCE | 11.7 | -663.1 | 0.0 | 20.0 | 9.0 | -1200.8 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 1.0 | -3.3 | 160.7 | 0.0 |
| DEPLOY BY FIGURES | 7.3 | +4.0 | 0.0 | 0.0 | 7.7 | +7.5 | 0.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.7 | +32.1 | 0.0 | 0.0 |
| EXACT ROUND | 2.0 | +12.9 | 102.0 | 20.0 | 4.0 | -4.8 | 104.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.3 | +0.0 | 25.0 | 20.0 | 3.7 | +6.4 | 264.7 | 0.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 15.0 |
| FALLS SHORT | - | - | - | - | 23.0 | +260.8 | 0.0 | 0.0 |
| FEATURE BUFFS | 1.0 | +16.5 | 0.0 | 0.0 | 0.3 | +2.5 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +14.4 | 0.0 | 20.0 | 3.0 | +33.3 | 104.0 | 0.0 |
| FIVE ACTION | 58.0 | +3491.3 | 117.0 | 228.0 | 76.3 | +4018.9 | 465.3 | 25.0 |
| FLANK NOT WEIGHED | 8.0 | +0.0 | 0.0 | 42.0 | 8.3 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | - | - | - | - | 1.0 | +269.7 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.0 | +187.2 | 102.0 | 20.0 | 5.7 | +433.3 | 425.3 | 0.0 |
| FREED FROM HIS FIGHT | 6.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -0.7 | 0.0 | 0.0 | 0.3 | -0.1 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -8.7 | 62.0 | 0.0 | 0.7 | -21.7 | 0.0 | 0.0 |
| GOAL WALK | 11.0 | +899.1 | 0.0 | 0.0 | 4.3 | +384.2 | 0.0 | 0.0 |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HE REFORMS ONCE FREED | 3.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 12.0 | +0.0 | 0.0 | 84.0 | 8.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | 0.3 | +2.9 | 0.0 | 0.0 | 1.0 | +113.4 | 321.3 | 0.0 |
| HIS CHARGE LIST | 11.0 | +0.0 | 0.0 | 40.0 | 12.7 | +0.0 | 0.0 | 25.0 |
| HIS LEGAL MOVES | 7.7 | +0.0 | 0.0 | 40.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.3 | -23.2 | 0.0 | 0.0 | 5.0 | -69.0 | 0.0 | 0.0 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 28.0 | +6.7 | 62.0 | 0.0 |
| HIS MOVE WHY | 8.7 | +0.0 | 0.0 | 20.0 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 22.7 | -5.7 | 0.0 | 0.0 |
| HIS ONE QUARTER | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 10.7 | +0.0 | 0.0 | 40.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 4.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 24.7 | +193.6 | 0.0 | 0.0 | 35.7 | +720.8 | 0.0 | 25.0 |
| HIS SHOTS BY HIS RUN | 21.3 | +114.3 | 0.0 | 0.0 | 35.7 | +473.2 | 0.0 | 25.0 |
| HIS TURN DENIED | - | - | - | - | 2.0 | +31.3 | 42.0 | 0.0 |
| HIS TURN RUN | 4.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 5.3 | +0.0 | 0.0 | 84.0 | 11.0 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 4.3 | +405.3 | 0.0 | 42.0 | 8.7 | +571.2 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.7 | -69.2 | 40.0 | 20.0 | 5.7 | -168.3 | 425.3 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 1.7 | +29.8 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 18.0 | -227.1 | 0.0 | 0.0 |
| JOINT CHARGE NOW | 0.3 | +16.9 | 0.0 | 0.0 | 0.7 | +18.3 | 321.3 | 0.0 |
| KEPT FROM ITS LAST STOP | 0.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +33.0 | 0.0 | 0.0 | 1.3 | +56.1 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 9.0 | +0.0 | 77.0 | 548.3 | 6.3 | +0.0 | 180.7 | 62.0 |
| LONE WIZARD KEPT IN | 0.3 | +7.9 | 0.0 | 0.0 | 0.3 | +7.5 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.3 | -0.0 | 0.0 | 0.0 | 3.3 | +23.5 | 244.7 | 0.0 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 1.0 | -74.4 | 0.0 | 25.0 |
| MANOEUVRE | 0.7 | -1.6 | 0.0 | 0.0 | 2.7 | +4.6 | 0.0 | 25.0 |
| MARCH CHECK | 0.3 | +6.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | +197.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 0.7 | +8.4 | 0.0 | 0.0 | 4.7 | +204.3 | 0.0 | 15.0 |
| MEETS IN TIME | 4.0 | +232.5 | 0.0 | 0.0 | 4.3 | +194.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.7 | +27.6 | 0.0 | 0.0 | 4.0 | +37.3 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 2.0 | +37.4 | 0.0 | 0.0 | 4.7 | +21.0 | 0.0 | 0.0 |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 11.3 | +1005.4 | 0.0 | 40.0 | 13.0 | +1149.2 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 7.3 | +263.8 | 0.0 | 84.0 | 9.3 | +317.5 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 10.7 | +975.1 | 0.0 | 40.0 | 7.7 | +640.1 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -15.3 | 15.0 | 0.0 | 0.3 | -21.8 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.0 | -11.3 | 15.0 | 20.0 | 5.0 | -306.6 | 405.3 | 0.0 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 4.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 4.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT WORTH A CAST | 0.7 | -0.6 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 3.0 | -235.6 | 0.0 | 0.0 | 3.7 | -118.6 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.3 | -102.5 | 0.0 | 20.0 | 5.0 | -118.1 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 1.3 | +11.3 | 0.0 | 42.0 | 2.7 | +24.9 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 1.3 | -87.6 | 0.0 | 40.0 | - | - | - | - |
| ONE ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.7 | +27.9 | 25.0 | 0.0 | 0.3 | +18.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 2.3 | +23.1 | 244.7 | 0.0 |
| PATHS CROSS | 0.3 | +6.0 | 0.0 | 0.0 | 0.7 | +29.0 | 0.0 | 0.0 |
| PLAN RESULT | 23.7 | +211.6 | 87.0 | 331.0 | 38.3 | +618.1 | 269.0 | 117.0 |
| PROMISE BELOW ZERO | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 10.0 | -227.7 | 0.0 | 0.0 | 10.0 | -319.1 | 0.0 | 0.0 |
| PROMISE HOLDS THE SPOT | 0.3 | +8.4 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 1.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.7 | -54.1 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | - | - | - | - | 0.7 | -0.5 | 40.0 | 0.0 |
| QUARTER ODDS | 4.7 | +753.2 | 0.0 | 0.0 | 7.0 | +961.0 | 321.3 | 0.0 |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 1.0 | +31.9 | 0.0 | 30.0 |
| REDIRECT COUNTER | 1.3 | +26.9 | 0.0 | 0.0 | 6.0 | +668.5 | 0.0 | 40.0 |
| REDIRECT FOR A FRIEND IN REACH | 1.7 | +0.0 | 0.0 | 0.0 | 3.0 | +41.9 | 0.0 | 55.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 4.7 | -337.6 | 0.0 | 0.0 | 2.0 | -35.1 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 160.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +1.6 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.0 | +147.7 | 102.0 | 20.0 | 4.7 | +23.4 | 425.3 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 3.3 | -43.2 | 84.0 | 0.0 |
| RUN DOWN | - | - | - | - | 5.0 | -107.7 | 425.3 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.7 | -44.6 | 0.0 | 0.0 |
| SEARCH SPOT | - | - | - | - | 2.0 | +29.9 | 0.0 | 15.0 |
| SECOND LOOK | 0.3 | +35.9 | 0.0 | 0.0 | 0.7 | +33.9 | 0.0 | 0.0 |
| SELF MOVE SPELL | 2.0 | +40.1 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.7 | -10.1 | 0.0 | 0.0 | 1.0 | -18.1 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.7 | +11.3 | 0.0 | 0.0 | 1.0 | +28.8 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 1.0 | +2.0 | 0.0 | 0.0 | 0.3 | +1.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 3.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.3 | +3.7 | 0.0 | 42.0 | 1.3 | +20.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 1.3 | -5.7 | 20.0 | 0.0 |
| SHOT RISK POINTS | 13.0 | -55.5 | 0.0 | 0.0 | 26.3 | -191.1 | 0.0 | 25.0 |
| SHOTS AFTER THE MOVES | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 11.3 | +248.9 | 0.0 | 42.0 | 5.7 | +24.7 | 0.0 | 0.0 |
| SPELL WORTH | 0.7 | +3.6 | 20.0 | 0.0 | - | - | - | - |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | -29.7 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 4.3 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | - | - | - | - | 1.0 | -5.9 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 4.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 15.0 | +0.0 | 15.0 | 42.0 | 15.3 | +0.0 | 40.0 | 0.0 |
| STAY WORTH | 8.0 | +10.5 | 0.0 | 0.0 | 4.7 | +10.0 | 40.0 | 0.0 |
| STRIKE BY THE ODDS | 0.7 | +3.7 | 0.0 | 180.7 | - | - | - | - |
| STUPIDITY NEXT TURN | 2.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.3 | +219.2 | 0.0 | 0.0 | 8.7 | +734.2 | 0.0 | 25.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 20.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 2.3 | +219.2 | 0.0 | 0.0 | 8.7 | +734.2 | 0.0 | 25.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +5.2 | 0.0 | 66.3 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 1.0 | -84.7 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | - | - | - | - | 4.7 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 84.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 42.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 4.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 27.0 | +0.0 | 0.0 | 104.0 | 38.0 | +0.0 | 0.0 | 0.0 |
| TIED UP BY THE SUM | 1.0 | +109.0 | 40.0 | 0.0 | 1.3 | +137.3 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 28.3 | +445.3 | 0.0 | 104.0 | - | - | - | - |
| WAITS AGAIN | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | 0.3 | -27.5 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | - | - | - | - | 1.0 | +0.0 | 0.0 | 25.0 |
| WHAT THE JOINER ADDS | 0.7 | +86.1 | 124.0 | 0.0 | 0.7 | +4.3 | 40.0 | 0.0 |
| WHO FIGHTS | 0.3 | -21.9 | 62.0 | 0.0 | 0.7 | +18.5 | 0.0 | 0.0 |
| WHO HITS BACK | 0.3 | +3.5 | 0.0 | 0.0 | 0.7 | +14.3 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.3 | +0.0 | 62.0 | 0.0 | 0.3 | +2.7 | 20.0 | 0.0 |
| WHOLE FIGHT DANGER | 4.7 | -438.6 | 0.0 | 84.0 | 2.7 | -505.8 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 0.7 | +2.7 | 0.0 | 0.0 | 2.3 | +20.6 | 0.0 | 0.0 |

### Rule changes: ccut-c940641-p33

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 121 | 121 | 86 | 28.67 | +2840 | +33.0 |
| HIS MOVE AS HE DECIDES | 84 | 84 | 64 | 21.33 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 46 | 46 | 46 | 15.33 | +0 | +0.0 |
| FIVE ACTION | 403 | 381 | 36 | 12.00 | +1790 | +49.7 |
| HOLDER ASSIGNMENT | 39 | 39 | 35 | 11.67 | +1980 | +56.6 |
| HIS SHOT LIST | 181 | 170 | 34 | 11.33 | +179 | +5.3 |
| DEPLOY BY FIGURES | 45 | 45 | 25 | 8.33 | +242 | +9.7 |
| MOVE TO CHARGE COMPUTED | 73 | 67 | 24 | 8.00 | +698 | +29.1 |
| THE TABLE AGAIN | 27 | 27 | 23 | 7.67 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 171 | 163 | 22 | 7.33 | +59 | +2.7 |
| OFF BEST | 20 | 20 | 20 | 6.67 | -1063 | -53.1 |
| MEETS IN TIME | 25 | 25 | 19 | 6.33 | +1217 | +64.0 |
| PROMISE BY ITS OWN SUM | 60 | 60 | 19 | 6.33 | -1640 | -86.3 |
| NEXT CHARGE BY LIST | 55 | 53 | 18 | 6.00 | +702 | +39.0 |
| HIS MOVE WHY | 26 | 26 | 17 | 5.67 | +0 | +0.0 |
| HIS ONE MOVE | 68 | 68 | 14 | 4.67 | +0 | +0.0 |
| FOUR ROUNDS | 23 | 20 | 13 | 4.33 | +485 | +37.3 |
| MOVE ORDER | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 14 | 14 | 13 | 4.33 | +48 | +3.7 |
| COVER ONCE | 62 | 44 | 11 | 3.67 | +211 | +19.1 |
| GOAL WALK | 46 | 45 | 11 | 3.67 | +649 | +59.0 |
| LANE BY FIGURES | 8 | 8 | 8 | 2.67 | +267 | +33.4 |
| SUPPORT ADDS | 33 | 30 | 8 | 2.67 | +425 | +53.1 |
| SUPPORT WORKED OUT | 33 | 30 | 8 | 2.67 | +425 | +53.1 |
| THE RISK READS HIS RUN | 14 | 14 | 8 | 2.67 | +0 | +0.0 |
| REDIRECT COUNTER | 22 | 22 | 7 | 2.33 | +856 | +122.3 |
| SHOT RISK POINTS | 118 | 111 | 7 | 2.33 | +15 | +2.1 |
| RISK BY ARC | 20 | 17 | 6 | 2.00 | +127 | +21.2 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| IDLE COST | 54 | 42 | 5 | 1.67 | +73 | +14.6 |
| QUARTER ODDS | 35 | 31 | 5 | 1.67 | +232 | +46.3 |
| SEARCH SPOT | 6 | 6 | 5 | 1.67 | +90 | +18.0 |
| SHOOTS FROM THE BEST SPOT | 5 | 5 | 5 | 1.67 | +0 | +0.1 |
| TIED UP BY THE SUM | 7 | 6 | 5 | 1.67 | +132 | +26.3 |
| CAST JOB | 4 | 4 | 4 | 1.33 | +5 | +1.4 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 6 | 6 | 4 | 1.33 | +41 | +10.2 |
| ONE PROMISE A TARGET | 4 | 4 | 4 | 1.33 | -263 | -65.8 |
| SHOOTERS IN TWO RANKS | 4 | 4 | 4 | 1.33 | +11 | +2.8 |
| WHAT THE JOINER ADDS | 4 | 4 | 4 | 1.33 | +274 | +68.6 |
| CHARGE LOSSES | 77 | 73 | 3 | 1.00 | +480 | +160.0 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +809 | +269.7 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | +105 | +35.1 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +105 | +35.0 |
| SECOND LOOK | 3 | 3 | 3 | 1.00 | +210 | +69.8 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +53 | +17.8 |
| CHARGE NOW FIRST | 13 | 13 | 2 | 0.67 | -98 | -48.9 |
| HARD STAY DROPPED | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +46 | +23.1 |
| MANOEUVRE | 10 | 10 | 2 | 0.67 | +18 | +9.2 |
| MAX FOR POSITIONING | 16 | 15 | 2 | 0.67 | +19 | +9.6 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -1 | -0.7 |
| SHOTS AFTER THE MOVES | 9 | 9 | 2 | 0.67 | +0 | +0.0 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +11 | +5.6 |
| THE ROW IN ITS ORDER | 9 | 2 | 2 | 0.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 85 | 60 | 2 | 0.67 | +3 | +1.4 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +347 | +347.3 |
| CANNON PLANNED TARGET | 5 | 5 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +15 | +15.2 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 18 | 15 | 1 | 0.33 | +0 | +0.0 |
| FALLS SHORT | 69 | 62 | 1 | 0.33 | +10 | +10.0 |
| FEATURE BUFFS | 4 | 4 | 1 | 0.33 | +3 | +2.6 |
| MARCH CHECK | 1 | 1 | 1 | 0.33 | +17 | +17.3 |
| MISSILES IN THE MOVE | 17 | 15 | 1 | 0.33 | +38 | +37.5 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| ONE FIGHT FORMULA | 28 | 15 | 1 | 0.33 | +12 | +12.5 |
| OPENS UP | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| OVERRUNS AWAY | 7 | 5 | 1 | 0.33 | +8 | +7.7 |
| PROMISE HOLDS THE SPOT | 1 | 1 | 1 | 0.33 | +25 | +25.3 |
| PROMISE READS THE TABLE | 2 | 2 | 1 | 0.33 | -109 | -109.2 |
| REDIRECT BY WHAT IT STOPS | 3 | 3 | 1 | 0.33 | +12 | +12.1 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +30 | +29.8 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +5 | +4.7 |
| SET UP BY THE SET | 5 | 5 | 1 | 0.33 | +11 | +10.6 |
| SHOTS IN THE MOVE | 51 | 40 | 1 | 0.33 | +14 | +14.4 |
| SUPPORT NARROWED | 2 | 2 | 1 | 0.33 | -115 | -115.4 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +16 | +15.7 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -82 | -82.4 |
| WHOLE FIGHT DANGER | 22 | 20 | 1 | 0.33 | +22 | +21.7 |
| WOUNDS ON THE RANKS | 9 | 8 | 1 | 0.33 | +3 | +2.6 |
| BACKUP TARGETS | 2 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 60 | 58 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 15 | 13 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 11 | 9 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 49 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 35 | 27 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 3 | 3 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 23 | 17 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 62 | 58 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 4 | 4 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 71 | 64 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 38 | 34 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 25 | 25 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 6 | 6 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 39 | 35 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 26 | 26 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 14 | 14 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 6 | 5 | 0 | 0.00 | - | - |
| HIS TURN RUN | 27 | 27 | 0 | 0.00 | - | - |
| HOLD ODDS | 49 | 49 | 0 | 0.00 | - | - |
| HONEST WORTH | 22 | 19 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 5 | 3 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 16 | 16 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 11 | 9 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 20 | 17 | 0 | 0.00 | - | - |
| NEARER NOT NEEDED | 50 | 47 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 18 | 16 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 13 | 13 | 0 | 0.00 | - | - |
| NO SECOND RUN | 13 | 13 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 12 | 11 | 0 | 0.00 | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 186 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 4 | 4 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 11 | 6 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 20 | 20 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 2 | 2 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 10 | 9 | 0 | 0.00 | - | - |
| RUN DOWN | 15 | 14 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 5 | 5 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 5 | 5 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 18 | not checked | - | - | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SPELL WORTH | 2 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 33 | 26 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 12 | 12 | 0 | 0.00 | - | - |
| STANDS STILL | 91 | 82 | 0 | 0.00 | - | - |
| STAY WORTH | 38 | 32 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 14 | 12 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE PROMISE ADDS | 3 | 3 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 14 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 4 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 9 | not checked | - | - | - | - |
| THE TABLE BINDS | 195 | not checked | - | - | - | - |
| WAITS AGAIN | 5 | 5 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 3 | 3 | 0 | 0.00 | - | - |
| WHO FIGHTS | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p33

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 3.00 | 3.33 | 86.3 |
| JOB FIRST | gate | 1.67 | 3.00 | 56.1 |
| ARMY TABLE | rule | 1.67 | 1.67 | 51.7 |
| NO REASON | gate | 1.33 | - | 55.1 |
| ONE PROMISE A TARGET | rule | 1.33 | - | 65.8 |
| CHARGE NOW FIRST | rule | 0.33 | 0.33 | 48.9 |
| RULE SWITCHED OFF | gate | - | 0.67 | 28.4 |
| HOLDER ASSIGNMENT | rule | - | 0.33 | 1.0 |
| JOINT CHARGE NOW | rule | - | 0.33 | 109.1 |
| PROMISE READS THE TABLE | rule | - | 0.33 | 109.2 |
| PROMISE SHOT AWAY | rule | - | 0.33 | 1.0 |
| SUPPORT NARROWED | rule | - | 0.33 | 115.4 |
| WALKS ON ITS ROUTE | rule | 0.33 | - | 82.4 |

### Plans: ccut-c940641-p33

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.7 | 80% | 148 | 115 | 78% |
| Mine | move | 18.7 | 96% | 1309 | 0 | 0% |
| Mine | shoot | 3.3 | 40% | 88 | 97 | 110% |
| Opponent | charge | 4.0 | 75% | 728 | 520 | 72% |
| Opponent | join | 3.0 | 100% | 129 | 0 | 0% |
| Opponent | move | 27.7 | 96% | 1119 | 0 | 0% |
| Opponent | shoot | 2.0 | 50% | 66 | 98 | 149% |
| Opponent | support | 1.7 | 80% | 15 | 0 | 0% |

### Battle groups: ccut-c940641-p33

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.3 | 50% | 50% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 6.0 | 28% | 100% | 20% | 0% | 0% | 0% | 25% | 75% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p33

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 2 | 13 (2) | 13 | 0 | 0 | 0% | 1.0 | - | 13 (2) | - | 11 (1) | 15 (1) |
| Mine | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 3 | 41 (3) | 25 | 16 | 91 | 0% | 2.0 | - | 41 (3) | - | 60 (1) | 34 (2) |
| Mine | Shooter | 2 | 30 (2) | 0 | 30 | 42 | 0% | 2.0 | 71 (1) | 0 (1) | - | 71 (1) | 0 (1) |
| Opponent | Chaff | 4 | 25 (4) | 25 | 0 | 50 | 50% | 2.0 | 19 (2) | 30 (2) | - | 19 (2) | 30 (2) |
| Opponent | Character | 4 | 68 (4) | 68 | 0 | 0 | 25% | 5.3 | 0 (1) | 93 (2) | 0 (1) | 102 (1) | 0 (3) |
| Opponent | Fast Hammer | 3 | 29 (3) | 17 | 12 | 25 | 0% | 3.3 | 24 (1) | - | 34 (2) | - | 29 (3) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 4.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |

### Charged fights: ccut-c940641-p33

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 1 | 0 | 120 | 4.0 | 1.0 | 30 | 0 | +30 | 0 of 4 | 3 of 4 | - | +30 |
| Opponent | Vampire Counts | 1 | 0 | 867 | 6.0 | 1.2 | 144 | 31 | +114 | 2 of 6 | 5 of 6 | +296 | +77 |

### Effective charges: ccut-c940641-p33

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 4 | 0 | 0 | 1 (net +0) | 1 (net +0) | 2 (net +60) | 0 | 0 | 25% (1 of 4) |
| Opponent | Vampire Counts | 6 | 1 (net +0) | 0 | 2 (net +130) | 1 (net +126) | 0 | 1 (net +296) | 1 | 40% (2 of 5) |

### Charged fights, damage counted: ccut-c940641-p33

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 60 | 75 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 76-89% | 1 | 115 | 186 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 446 | 60 | +60 | 60 | 0 | +60 | +13.5 |
| Mine | All fights | 4 | 267 | 95 | +30 | 30 | 0 | +30 | +11.2 |
| Opponent | Long shot (under 50%) | 1 | 50 | 115 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Effective (55-75%) | 2 | 116 | 246 | +130 | 130 | 0 | +130 | +112.1 |
| Opponent | 76-89% | 1 | 186 | 126 | +126 | 126 | 0 | +126 | +67.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 851 | 432 | +296 | 482 | 186 | +296 | +34.8 |
| Opponent | No odds | 1 | 186 | 199 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | All fights | 6 | 251 | 227 | +114 | 144 | 31 | +114 | +45.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p33 | move | 24 | 6 (25%) | 4 (17%) | 5 (21%) | 13 (54%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1527, L1625 |
| Invocation of Nehek | Opponent | L1527, L1625 |
| Ring of Doom | Mine | L1527 |

# Doctrine scorecard: ccut-c940641-p23

### Scorecard: ccut-c940641-p23

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2131 | 1 | 1 | Mine | yes | 9 | - | 0 | 4 | 0 | 0 | 0 | 290 |
| L2131 | 1 | 1 | Opponent | no | 0 | - | 0 | 2 | 1 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | no | 5 | 2 | 2 | 0 | 0 | 0 | 0 | 72 |
| L2235 | 3 | 1 | Opponent | no | 0 | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Mine | yes | - | - | 1 | 3 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | no | - | 2 | 1 | 5 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 67% | 7.0 | 2.0 | 1.0 | 2.3 | 0.0 | 0.0 | 0.0 | 120.7 |
| **Average** | | | Opponent | 0% | 0.0 | 2.0 | 2.3 | 3.0 | 0.3 | 0.0 | 0.0 | 56.7 |

### KPIs: ccut-c940641-p23

Rules off - Mine only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 15) | 0% (0 of 16) | 0% (0 of 31) |
| Winner chose to follow up after the loser gave ground |  | 50% (2 of 4); on the table 75% | 100% (3 of 3); on the table 100% | 71% (5 of 7); on the table 86% |
| Winner chose to pursue after the loser fell back in good order |  | 67% (2 of 3); on the table 67% | - | 67% (2 of 3); on the table 67% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 57% (4 of 7); on the table 71% | 100% (3 of 3); on the table 100% | 70% (7 of 10); on the table 80% |
| Magic missiles tried each own turn | 50%+ | 17% (2 of 12) | - | 17% (2 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 17% (2 of 12) | - | 17% (2 of 12) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 55% (6 of 11) | 50% (7 of 14) | 52% (13 of 25) |
| Points that never fought | lower | 52% (3146 of 5997) | 54% (3243 of 5999) | 53% (6389 of 11996) |
|   infantry points that never fought | lower | 59% (993 of 1675) | 72% (946 of 1306) | 65% (1939 of 2981) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 71% (15 of 21) | 74% (23 of 31) | 73% (38 of 52) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.7 uses a game | 50% (1 of 2); 1.0 uses a game | 67% (2 of 3); 1.3 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 68% (3297 of 4866) | 71% (4198 of 5884) | 70% (7495 of 10750) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.7 (50%) | - | 1.7 (50%) |
| MARCHED: its unit marched | 1.7 (50%) | - | 1.7 (50%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 5.3 | 1.0 | 0.7 | 0.7 | 1.3 |
| not cast | 4.7 | 7.0 | 1.3 | 3.3 | 22.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 5.0 (71%) | 0.0 (0%) | 1.7 (50%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (50%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (10%) | 0.3 (25%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 1.3 (19%) | 0.7 (50%) | 0.0 (0%) | 3.7 (16%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.7 (100%) | 0.0 (0%) | 0.3 (25%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.7 (82%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 0.7 a game | 0.3 a game |
| stood (cast and not dispelled) | - | 50% (1 of 2) | 50% (1 of 2) |
| the unit moved after it | - | 0% (0 of 1) | 0% (0 of 1) |
| it charged on its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| the enemy charged it first | - | 0% (0 of 1) | 0% (0 of 1) |
| it fought by the end of its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 1) | 0% (0 of 1) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (1 of 1) | 100% (1 of 1) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 73% (43 of 59) | 51% (18 of 35) | 65% (61 of 94) |
|   cavalry | 89% (8 of 9) | 36% (5 of 14) | 57% (13 of 23) |
|   character | 0% (0 of 9) | 33% (3 of 9) | 17% (3 of 18) |
|   chariot | 100% (9 of 9) | - | 100% (9 of 9) |
|   infantry | 81% (26 of 32) | 83% (10 of 12) | 82% (36 of 44) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.0 (0%) | 1.3 (24%) | 1.3 (12%) |
| CHARGED: it charged | 2.0 (38%) | 0.7 (12%) | 2.7 (24%) |
| IN COMBAT: it fought this turn or the last | 0.7 (12%) | 0.3 (6%) | 1.0 (9%) |
| NO TARGET IN RANGE | 1.0 (19%) | 3.0 (53%) | 4.0 (36%) |
| ONLY IN COMBAT: the only targets were in combat | 1.0 (19%) | 0.0 (0%) | 1.0 (9%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (12%) | 0.3 (6%) | 1.0 (9%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 8.7 | 0.7 | 92% | 1.5 pts | 13 pts |
| character | 1.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 3.0 | 0.7 | 78% | 9.2 pts | 28 pts |
| infantry | 13.3 | 4.0 | 75% | 7.6 pts | 101 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.7 | 2.7 | 2.7 |
| Charges that made contact a game | 2.7 | 2.3 | 2.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | - | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 1.00 contact (1 units) | 1.00 declared, 1.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.29 declared, 0.29 contact (28 units) | 0.28 declared, 0.24 contact (25 units) | 0.28 declared, 0.26 contact (53 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 83% (5 of 6) | 100% (4 of 4) | - | 90% (9 of 10) |
| Character in a unit | 100% (3 of 3) | 100% (1 of 1) | 100% (1 of 1) | 100% (5 of 5) |
| Character on its own | 100% (4 of 4) | 100% (1 of 1) | 43% (3 of 7) | 67% (8 of 12) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 73% (8 of 11) | 75% (3 of 4) | - | 73% (11 of 15) |
| Monster | 60% (3 of 5) | 0% (0 of 1) | - | 50% (3 of 6) |
| Monstrous | 0% (0 of 2) | - | - | 0% (0 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Skaven | 1 | 33% (1 of 3); on the table 67% | 17% (1 of 6) | 71% | 78% (7 of 9) | 100% (1 of 1); 5.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 1 | 75% (3 of 4); on the table 75% | - | 9% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | - | 17% (1 of 6) | 77% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | 100% (1 of 1); on the table 100% | - | 72% | 79% (15 of 19) | 100% (1 of 1); 1.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (2 of 2); on the table 100% | - | 19% | 67% (8 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p23, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 33% (1) | 67% (2) | 50% (3) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.00 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.67 | 0.67 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.67 | 0.67 |

### Quality by phase: ccut-c940641-p23

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 100% (7 of 7) | 88% (7 of 8) |
| Strategy | Shoot objectives carried out (shot that target) | 38% (5 of 13) | 50% (5 of 10) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 100% (2 of 2) |
| Strategy | Joined characters whose unit fought | 40% (2 of 5) | 0% (0 of 2) |
| Strategy | Lone characters that fought | 33% (2 of 6) | 57% (4 of 7) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 2.3 | 3.0 |
| Movement | Points that never moved of their own | 120.7 | 56.7 |
| Movement | Fights charged into per game | 2.7 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 7 | 1 of 7, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 7 | 1 of 7, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 4 of 7, net +32 | 1 of 7, net -405 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 7, net +144 | 3 of 7, net +113 |
| Shooting | Shots by shooting units (incl. breath weapons) | 15.7 | 7.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 32% (15 of 47) | 73% (16 of 22) |
| Shooting | Points destroyed by shooting units | 72.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.7 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 50% (1 of 2) | - |
| Magic | Wounds caused by magic missiles | 0.3 | - |
| Magic | Wounds caused by other spells | - | 0.7 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 4.7 / 0.0 / 0.0 / 0.0 | 0.0 / 0.7 / 1.0 / 0.0 |
| Combat | Points destroyed in combat | 368.7 | 314.3 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +100 | +4 |
| Combat | Net per 100 charger points, damage counted | +28.0 | +2.1 |
| Combat | First round won (charged fights) | 100% | 86% |
| Combat | Net points per charged fight | +86 | -2 |
| Combat | Net points per supported fight / lone fight | - / +86 | - / -2 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 8 | 1 of 7 |
| Game | Points lost | 346.0 | 501.7 |
| Game | VP from objectives | 960.0 | 430.0 |
| Game | Lone holders (player turns) | 7.0 | 0.0 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +739 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 848
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ccut-c940641-p23

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +1.9 | 0.0 | 30.7 | - | - | - | - |
| AFTERMATH WITH FRIENDS | 0.3 | +10.4 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 26.3 | +277.7 | 0.0 | 418.7 | 26.7 | +42.7 | 0.0 | 261.0 |
| ASSAILMENT BY POINTS | - | - | - | - | 0.3 | +0.8 | 0.0 | 91.3 |
| BACKUP TARGETS | - | - | - | - | 0.3 | +1.7 | 0.0 | 42.0 |
| BLOWS WHERE AIMED | 0.3 | -0.4 | 52.7 | 0.0 | - | - | - | - |
| CAST JOB | 1.3 | +104.9 | 0.0 | 0.0 | 1.3 | +4.4 | 21.7 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.3 | +7.4 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 0.3 | -0.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +2.6 | 0.0 | 0.0 | 1.3 | +43.7 | 0.0 | 238.3 |
| CHARACTER GUNS | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 13.7 | -536.5 | 0.0 | 148.3 | 25.0 | -1194.7 | 0.0 | 541.7 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 125.3 | 0.0 | 1.7 | +0.0 | 148.0 | 76.0 |
| CLOSES ON WHAT IT BEATS | 11.7 | +0.0 | 0.0 | 170.0 | 10.0 | +0.0 | 0.0 | 83.3 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 0.7 | +104.4 | 0.0 | 0.0 |
| COVER ONCE | 8.3 | -463.4 | 0.0 | 86.7 | 10.7 | -565.6 | 0.0 | 121.7 |
| DENIED BY THE FIGHT | 0.3 | -4.8 | 0.0 | 0.0 | 0.3 | -3.2 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 7.7 | +9.0 | 0.0 | 0.0 | 7.7 | +16.7 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -1.1 | 41.7 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.3 | +15.8 | 52.7 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | - | - | - | - | 3.0 | +781.9 | 40.7 | 41.7 |
| EXACT ROUND | 1.7 | +9.0 | 170.3 | 0.0 | 1.7 | -1.6 | 66.3 | 42.0 |
| FACES THE THREAT | - | - | - | - | 0.7 | +28.3 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.3 | +6.5 | 212.0 | 0.0 | 2.0 | +0.0 | 86.3 | 197.0 |
| FALLS SHORT | 7.3 | +107.7 | 0.0 | 40.0 | 18.0 | +165.1 | 0.0 | 251.0 |
| FEATURE BUFFS | 0.7 | +3.1 | 0.0 | 0.0 | 0.7 | +21.5 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +18.7 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 97.3 | +6347.1 | 726.7 | 655.7 | 92.0 | +4693.5 | 295.0 | 1051.0 |
| FLANK NOT WEIGHED | 7.0 | +0.0 | 0.0 | 65.0 | 7.7 | +0.0 | 0.0 | 125.0 |
| FOLLOW UP WEIGHED | 1.0 | +326.0 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 2.7 | +172.7 | 253.7 | 0.0 | 2.7 | +116.1 | 192.0 | 231.0 |
| FREED FROM HIS FIGHT | 3.7 | +0.0 | 0.0 | 81.3 | 8.7 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 1.3 | -16.9 | 0.0 | 0.0 | 0.7 | -2.1 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.3 | +10.4 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.7 | -9.2 | 86.7 | 0.0 | - | - | - | - |
| GOAL WALK | 3.7 | +148.0 | 0.0 | 0.0 | 16.7 | +1649.5 | 0.0 | 83.3 |
| GUN FIGURES | 1.7 | +25.9 | 0.0 | 21.7 | - | - | - | - |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.0 | +0.0 | 0.0 | 81.3 | 6.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 10.0 | +0.0 | 0.0 | 105.0 | 12.0 | +0.0 | 0.0 | 435.0 |
| HIS CHARGE DENIED | 0.7 | +29.0 | 83.7 | 0.0 | 0.3 | +26.4 | 65.0 | 0.0 |
| HIS CHARGE LIST | 6.3 | +0.0 | 0.0 | 58.3 | 8.0 | +0.0 | 0.0 | 120.7 |
| HIS LEGAL MOVES | 3.7 | +0.0 | 0.0 | 65.0 | 6.0 | +0.0 | 0.0 | 52.7 |
| HIS MOVE AND SHOT | 2.0 | -40.5 | 0.0 | 20.0 | 6.3 | -49.2 | 0.0 | 72.7 |
| HIS MOVE AS HE DECIDES | 41.7 | +11.3 | 606.3 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 29.3 | +0.0 | 0.0 | 224.7 |
| HIS ONE MOVE | 23.3 | -2.9 | 0.0 | 170.0 | - | - | - | - |
| HIS ONE QUARTER | 2.7 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 41.7 |
| HIS OWN BEST MOVE | 2.3 | +0.0 | 0.0 | 20.0 | 8.3 | +0.0 | 0.0 | 167.3 |
| HIS RANDOM MOVE | 28.7 | +0.0 | 0.0 | 290.0 | 14.3 | +0.0 | 0.0 | 77.3 |
| HIS RANDOM MOVER COMES | 5.3 | +0.0 | 0.0 | 43.3 | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 26.7 | +348.1 | 0.0 | 412.3 | 52.3 | +1287.3 | 0.0 | 736.7 |
| HIS SHOTS BY HIS RUN | 28.7 | +210.5 | 0.0 | 299.7 | 43.0 | +578.5 | 0.0 | 744.0 |
| HIS TURN DENIED | 0.3 | +3.0 | 0.0 | 0.0 | 1.0 | +26.3 | 42.3 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 20.7 | +0.0 | 0.0 | 84.7 | 8.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 14.7 | +984.2 | 0.0 | 42.3 | 5.7 | +411.1 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.7 | -97.2 | 253.7 | 0.0 | 2.7 | -56.1 | 192.0 | 231.0 |
| HUNT IN PAIRS | 0.7 | +1.5 | 0.0 | 65.0 | - | - | - | - |
| IDLE COST | 5.0 | -86.1 | 0.0 | 0.0 | 13.3 | -153.5 | 0.0 | 160.3 |
| KEPT FROM ITS LAST STOP | 4.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +16.4 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 11.0 | +0.0 | 420.7 | 218.0 | 4.0 | +0.0 | 21.7 | 568.7 |
| LONE WIZARD KEPT IN | 1.0 | +52.2 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.3 | +17.6 | 24.0 | 0.0 |
| LOST AFTER ESCAPE | 0.7 | +0.1 | 41.7 | 0.0 | 0.7 | -0.0 | 65.0 | 42.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| MANOEUVRE | 1.0 | -1.5 | 0.0 | 21.7 | 1.7 | +155.1 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +14.5 | 0.0 | 0.0 | 0.3 | +18.8 | 0.0 | 52.7 |
| MARCH OVER CASTS | 1.0 | +17.4 | 0.0 | 0.0 | 0.3 | +87.0 | 0.0 | 52.7 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.7 | +20.6 | 0.0 | 0.0 | 1.0 | +6.4 | 0.0 | 38.7 |
| MEETS IN TIME | 5.3 | +188.6 | 0.0 | 0.0 | 3.7 | +115.9 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.7 | +80.7 | 0.0 | 0.0 | 2.0 | +14.4 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 4.7 | +42.3 | 0.0 | 0.0 | 2.3 | +14.2 | 0.0 | 52.7 |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 105.3 | 76.0 |
| MOVE TO CHARGE COMPUTED | 7.7 | +789.5 | 0.0 | 190.0 | 7.3 | +608.9 | 0.0 | 153.3 |
| NEARER NOT NEEDED | 8.3 | +276.2 | 0.0 | 68.0 | 7.0 | +323.9 | 0.0 | 90.7 |
| NEXT CHARGE BY LIST | 4.7 | +551.4 | 0.0 | 190.0 | 5.0 | +368.5 | 0.0 | 76.7 |
| NEXT OBJECTIVE NEARER | 0.7 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 2.3 | -97.7 | 212.0 | 0.0 | 2.3 | -53.3 | 151.3 | 197.0 |
| NO LATE CUT | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.7 | +7.1 | 0.0 | 0.0 |
| NOT WORTH A CAST | 4.7 | -4.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 5.0 | -198.5 | 41.7 | 86.7 | 6.7 | -204.8 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.3 | -88.6 | 0.0 | 40.7 | 6.0 | -199.6 | 0.0 | 160.3 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | -5.7 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 6.3 | -50.5 | 0.0 | 0.0 | 1.7 | +69.9 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 1.0 | +11.9 | 0.0 | 38.7 |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +5.0 | 20.0 | 155.0 |
| OVERRUNS AWAY | 0.3 | +0.3 | 52.7 | 0.0 | 0.7 | +1.0 | 83.3 | 0.0 |
| PATHS CROSS | 0.3 | +4.4 | 0.0 | 0.0 | 0.3 | +8.4 | 0.0 | 0.0 |
| PERIAPT WORTH | 0.3 | +40.5 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 46.3 | +357.8 | 162.3 | 626.3 | 43.0 | +226.7 | 84.0 | 807.3 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 9.0 | -184.7 | 0.0 | 20.0 | 12.0 | -585.8 | 0.0 | 76.7 |
| PROMISE KNOWS THE FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | -1.1 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | - | - | - | - | 0.7 | -0.8 | 0.0 | 0.0 |
| QUARTER ODDS | 24.3 | +2552.1 | 279.7 | 0.0 | 23.7 | +2084.0 | 64.7 | 143.7 |
| RANDOM MOVE BY FIGURES | 3.7 | +122.7 | 0.0 | 145.0 | 4.7 | +39.9 | 0.0 | 0.0 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 3.3 | +168.4 | 0.0 | 20.0 | 0.7 | +17.3 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.0 | +0.0 | 0.0 | 68.0 | - | - | - | - |
| REFORMS TO MEET IT | 2.0 | -50.9 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 0.7 | +24.5 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.3 | +20.7 | 212.0 | 0.0 | 2.7 | +39.8 | 192.0 | 231.0 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | 1.0 | -9.7 | 94.7 | 0.0 | - | - | - | - |
| RUN DOWN | 2.0 | -8.4 | 219.7 | 0.0 | - | - | - | - |
| SAME CHARGE LATER | 0.3 | -9.4 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 0.7 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 1.0 | -13.3 | 0.0 | 0.0 | 0.7 | -2.8 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +23.8 | 41.7 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 2.0 | +19.0 | 0.0 | 0.0 | 1.0 | +21.9 | 0.0 | 76.7 |
| SET UP TOGETHER | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.3 | +1.3 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 5.3 | +0.0 | 0.0 | 21.7 | 4.0 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.3 | +33.6 | 125.0 | 0.0 | 1.7 | +37.8 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -3.9 | 34.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 13.0 | -205.7 | 0.0 | 206.3 | 24.0 | -108.8 | 0.0 | 413.7 |
| SHOTS AFTER THE MOVES | 2.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 15.7 | +364.7 | 0.0 | 150.3 | 6.7 | +196.8 | 0.0 | 42.0 |
| SPELL WORTH | 1.3 | +16.1 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 6.3 | +0.0 | 0.0 | 86.7 | 12.0 | +0.0 | 0.0 | 273.7 |
| STAND AND SHOOT | 0.3 | -0.5 | 52.7 | 0.0 | 1.0 | -0.9 | 64.7 | 76.0 |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 37.3 | +0.0 | 473.0 | 166.3 | 34.7 | +0.0 | 103.0 | 0.0 |
| STAY WORTH | 10.7 | +80.7 | 144.0 | 42.3 | 5.7 | +24.5 | 21.7 | 90.7 |
| STUCK PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 9.0 | +503.7 | 0.0 | 21.7 | 6.0 | +226.9 | 0.0 | 119.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 66.3 | 0.0 |
| SUPPORT WORKED OUT | 9.0 | +503.7 | 0.0 | 21.7 | 6.0 | +226.9 | 0.0 | 119.0 |
| SURE REACH TOGETHER | - | - | - | - | 1.7 | +5.8 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +4.4 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.7 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 159.0 |
| THE ROW KEEPS ITS WAY | 3.0 | +0.0 | 0.0 | 21.7 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | 2.0 | +0.0 | 0.0 | 18.3 | - | - | - | - |
| THE STEP BACK IS MADE | 3.7 | +0.0 | 0.0 | 43.3 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 47.0 | +0.0 | 0.0 | 255.3 | 43.0 | +0.0 | 0.0 | 410.0 |
| TIED UP BY THE SUM | 2.0 | +240.1 | 159.3 | 0.0 | 0.3 | +32.2 | 20.0 | 155.0 |
| TIME ON OUR SIDE | 32.0 | +310.5 | 41.7 | 256.0 | 18.0 | +168.2 | 0.0 | 0.0 |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 38.7 |
| WALKS ON ITS ROUTE | 0.3 | -7.6 | 0.0 | 0.0 | - | - | - | - |
| WEAPON BY POINTS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | - | - | - | - | 1.3 | +0.0 | 42.3 | 42.0 |
| WHO HITS BACK | 0.3 | +18.3 | 0.0 | 0.0 | 1.0 | +78.0 | 0.0 | 189.0 |
| WHOLE FIGHT DANGER | 3.7 | -237.1 | 0.0 | 43.3 | 6.3 | -851.8 | 0.0 | 250.0 |
| WOUNDS ON THE RANKS | 1.7 | +6.4 | 0.0 | 0.0 | 3.0 | +67.2 | 0.0 | 105.3 |

### Rule changes: ccut-c940641-p23

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 159 | 159 | 103 | 34.33 | +953 | +9.2 |
| HIS MOVE AS HE DECIDES | 125 | 125 | 91 | 30.33 | +0 | +0.0 |
| HIS MOVE WHY | 88 | 88 | 57 | 19.00 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 61 | 61 | 57 | 19.00 | +3138 | +55.1 |
| LEGAL CHARGES ONLY | 45 | 45 | 45 | 15.00 | +0 | +0.0 |
| FIVE ACTION | 568 | 535 | 39 | 13.00 | +1608 | +41.2 |
| OFF BEST | 35 | 35 | 35 | 11.67 | -1210 | -34.6 |
| PROMISE BY ITS OWN SUM | 63 | 63 | 29 | 9.67 | -2311 | -79.7 |
| HIS SHOT LIST | 237 | 215 | 28 | 9.33 | +427 | +15.3 |
| THE TABLE AGAIN | 36 | 36 | 26 | 8.67 | +0 | +0.0 |
| DEPLOY BY FIGURES | 46 | 46 | 23 | 7.67 | +275 | +12.0 |
| MOVE TO CHARGE COMPUTED | 45 | 32 | 23 | 7.67 | +1302 | +56.6 |
| QUARTER ODDS | 144 | 141 | 19 | 6.33 | +1779 | +93.6 |
| HIS ONE MOVE | 70 | 68 | 18 | 6.00 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 215 | 195 | 18 | 6.00 | +171 | +9.5 |
| GOAL WALK | 61 | 57 | 17 | 5.67 | +836 | +49.2 |
| MOVE ORDER | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 29 | 23 | 16 | 5.33 | +1044 | +65.2 |
| ADVANCE LANE KEPT | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 25 | 25 | 13 | 4.33 | +488 | +37.5 |
| TIME ON OUR SIDE | 150 | 126 | 12 | 4.00 | +53 | +4.4 |
| CHARGE LOSSES | 116 | 105 | 11 | 3.67 | +1185 | +107.7 |
| MEETS IN TIME | 27 | 27 | 11 | 3.67 | +349 | +31.8 |
| SUPPORT ADDS | 45 | 42 | 10 | 3.33 | +305 | +30.5 |
| SUPPORT WORKED OUT | 45 | 42 | 10 | 3.33 | +305 | +30.5 |
| REDIRECT FOR A FRIEND IN REACH | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| THE RISK READS HIS RUN | 18 | 18 | 9 | 3.00 | +0 | +0.0 |
| FOUR ROUNDS | 16 | 15 | 8 | 2.67 | +196 | +24.5 |
| SHOT RISK POINTS | 111 | 97 | 8 | 2.67 | +217 | +27.1 |
| COVER ONCE | 57 | 32 | 7 | 2.33 | +96 | +13.8 |
| EVASIVE BY THE ODDS | 9 | 9 | 7 | 2.33 | +2340 | +334.2 |
| HOLDS AMBUSHERS | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 12 | 12 | 7 | 2.33 | +48 | +6.8 |
| HARD STAY DROPPED | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| IDLE COST | 55 | 35 | 6 | 2.00 | +32 | +5.3 |
| TIED UP BY THE SUM | 7 | 6 | 6 | 2.00 | +331 | +55.2 |
| CHALLENGE BY POINTS | 5 | 5 | 5 | 1.67 | +139 | +27.8 |
| SET UP BY THE SET | 9 | 9 | 5 | 1.67 | +282 | +56.3 |
| WHOLE FIGHT DANGER | 30 | 30 | 5 | 1.67 | +147 | +29.5 |
| MANOEUVRE | 8 | 8 | 4 | 1.33 | +489 | +122.3 |
| MISSILES IN THE MOVE | 17 | 12 | 4 | 1.33 | +64 | +16.1 |
| WHO HITS BACK | 4 | 4 | 4 | 1.33 | +259 | +64.8 |
| CAST JOB | 8 | 8 | 3 | 1.00 | +6 | +1.9 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +978 | +326.1 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +157 | +52.2 |
| ONE PROMISE A TARGET | 3 | 3 | 3 | 1.00 | +36 | +11.9 |
| RISK BY ARC | 15 | 14 | 3 | 1.00 | +85 | +28.3 |
| STUCK PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 30 | 3 | 3 | 1.00 | +0 | +0.0 |
| FACES THE THREAT | 2 | 2 | 2 | 0.67 | +85 | +42.4 |
| HIS TURN DENIED | 4 | 4 | 2 | 0.67 | +48 | +24.0 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +51 | +25.7 |
| NEARER NOT NEEDED | 46 | 45 | 2 | 0.67 | +35 | +17.4 |
| ONE OBJECTIVE FORMULA | 24 | 16 | 2 | 0.67 | +39 | +19.6 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +38 | +19.2 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -2 | -1.1 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +74 | +36.8 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +5 | +2.5 |
| SHOTS AFTER THE MOVES | 12 | 12 | 2 | 0.67 | +0 | +0.0 |
| SUPPORT NARROWED | 4 | 4 | 2 | 0.67 | -43 | -21.6 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +6 | +5.6 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +31 | +31.3 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +2 | +2.3 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -0 | -0.1 |
| CHARGE NOW FIRST | 9 | 9 | 1 | 0.33 | -8 | -7.9 |
| EXACT ROUND | 10 | 9 | 1 | 0.33 | +6 | +5.9 |
| FIGHT TO THE END | 1 | 1 | 1 | 0.33 | +37 | +37.5 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | +31 | +31.1 |
| HIS CHARGE DENIED | 3 | 3 | 1 | 0.33 | +27 | +27.3 |
| HONEST WORTH | 16 | 15 | 1 | 0.33 | +6 | +5.9 |
| LONG SHOT | 1 | 1 | 1 | 0.33 | +47 | +46.6 |
| MAX FOR POSITIONING | 8 | 5 | 1 | 0.33 | +0 | +0.0 |
| ONE FIGHT FORMULA | 34 | 15 | 1 | 0.33 | +103 | +103.5 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +122 | +121.5 |
| PROMISE KNOWS THE FIGHT | 3 | 2 | 1 | 0.33 | -3 | -3.4 |
| REDIRECT COUNTER | 12 | 9 | 1 | 0.33 | +27 | +27.4 |
| SEARCH SPOT | 5 | 5 | 1 | 0.33 | +38 | +38.5 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +71 | +71.4 |
| SHOTS IN THE MOVE | 67 | 47 | 1 | 0.33 | +68 | +67.9 |
| STAY WORTH | 49 | 44 | 1 | 0.33 | +5 | +5.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +13 | +13.3 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -23 | -22.9 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CHAFF IN THE MOVE | 4 | 2 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 8 | 8 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 65 | 62 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 2 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 13 | 12 | 0 | 0.00 | - | - |
| FALLS SHORT | 76 | 62 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 44 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 37 | 37 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 6 | 5 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 5 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 26 | 26 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 66 | 63 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 43 | 42 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 29 | 24 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 25 | 18 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 30 | 29 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 32 | 27 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 129 | 116 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 27 | 27 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 88 | 86 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 18 | 16 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 4 | 4 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH CHECK | 2 | 2 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 9 | 7 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 21 | 18 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 14 | 13 | 0 | 0.00 | - | - |
| NO LATE CUT | 8 | 6 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 14 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE ROUTE | 9 | 7 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 268 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 9 | 7 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 6 | 6 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | not checked | - | - | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 6 | 5 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 28 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 4 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 55 | 52 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 6 | 1 | 0 | 0.00 | - | - |
| STANDS STILL | 216 | 208 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 5 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 12 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 17 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 6 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 20 | not checked | - | - | - | - |
| THE TABLE BINDS | 270 | not checked | - | - | - | - |
| WAITS AGAIN | 7 | 5 | 0 | 0.00 | - | - |
| WHO FIGHTS | 4 | 4 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 14 | 14 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p23

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 3.33 | 6.33 | 79.7 |
| JOB FIRST | gate | 3.33 | 6.00 | 39.0 |
| ARMY TABLE | rule | 2.67 | 3.33 | 78.8 |
| RULE SWITCHED OFF | gate | 1.67 | - | 7.0 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.33 | 16.1 |
| NO REASON | gate | - | 0.67 | 41.4 |
| PROMISE SHOT AWAY | rule | - | 0.67 | 1.1 |
| SUPPORT NARROWED | rule | 0.33 | 0.33 | 21.6 |
| CHARGE NOW FIRST | rule | 0.33 | - | 7.9 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 33.3 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.33 | 3.4 |
| SET UP BY THE SET | rule | 0.33 | - | 3.8 |
| WALKS ON ITS ROUTE | rule | 0.33 | - | 22.9 |

### Plans: ccut-c940641-p23

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 57% | 331 | 228 | 69% |
| Mine | join | 1.7 | 100% | 96 | 0 | 0% |
| Mine | move | 39.7 | 93% | 1920 | 0 | 0% |
| Mine | shoot | 2.7 | 50% | 268 | 130 | 49% |
| Opponent | charge | 2.3 | 86% | 221 | 175 | 79% |
| Opponent | join | 1.0 | 100% | 20 | 0 | 0% |
| Opponent | move | 37.3 | 98% | 1776 | 0 | 0% |
| Opponent | shoot | 2.3 | 43% | 105 | 51 | 49% |

### Battle groups: ccut-c940641-p23

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.3 | 20% | 100% | 50% | 0% | 100% | 0% | 0% | 0% | 0% |
| Opponent | REDIRECT COUNTER | 0.7 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p23

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Chaff | 5 | 111 (5) | 36 | 75 | 64 | 40% | 1.3 | 137 (4) | 0 (1) | - | 137 (4) | 0 (1) |
| Mine | Character | 9 | 33 (9) | 33 | 0 | 0 | 44% | 2.2 | 47 (5) | 0 (4) | - | 34 (4) | 32 (5) |
| Mine | Clean-up | 2 | 0 (2) | 0 | 0 | 0 | 50% | 3.0 | - | 0 (1) | 0 (1) | 0 (1) | 0 (1) |
| Mine | Fast Hammer | 4 | 0 (4) | 0 | 0 | 39 | 25% | 2.7 | 0 (2) | 0 (2) | - | 0 (1) | 0 (3) |
| Mine | Hammer | 4 | 33 (4) | 33 | 0 | 43 | 0% | 1.5 | 60 (1) | 33 (2) | 0 (1) | 23 (3) | 60 (1) |
| Mine | Holder | 7 | 91 (7) | 54 | 38 | 11 | 57% | 4.7 | 85 (3) | 106 (3) | 0 (1) | 100 (6) | 0 (1) |
| Mine | Shooter | 5 | 122 (5) | 0 | 122 | 63 | 0% | 1.2 | 164 (1) | 225 (2) | 0 (2) | 49 (3) | 245 (2) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | - | - | - | 0 (2) |
| Opponent | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Character | 9 | 10 (9) | 10 | 0 | 33 | 44% | 2.6 | 16 (5) | 0 (2) | 0 (1) | 14 (6) | 7 (2) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 5 | 7 (5) | 0 | 7 | 32 | 60% | 1.0 | 11 (3) | - | 0 (2) | 0 (2) | 12 (3) |
| Opponent | Hammer | 10 | 45 (10) | 45 | 0 | 23 | 20% | 3.4 | 47 (4) | 51 (5) | 0 (1) | 89 (4) | 16 (6) |
| Opponent | Holder | 4 | 6 (4) | 0 | 6 | 0 | 75% | 3.0 | 25 (1) | 0 (2) | - | - | 7 (3) |
| Opponent | Shooter | 3 | 0 (3) | 0 | 0 | 31 | 33% | 1.0 | 0 (1) | 0 (2) | - | - | 0 (3) |

### Charged fights: ccut-c940641-p23

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Tomb Kings of Khemri | 1 | 216 | 808 | 7.0 | 1.0 | 115 | 17 | +98 | 1 of 7 | 7 of 7 | - | +98 |
| Mine | Vampire Counts | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| **Mine** | all armies | 3 | 72 | 269 | 2.7 | 1.0 | 101 | 15 | +86 | 1 of 8 | 8 of 8 | - | +86 |
| Opponent | Warriors of Chaos | 2 | 0 | 30 | 0.5 | 1.0 | 60 | 465 | -405 | 0 of 1 | 1 of 1 | - | -405 |
| Opponent | Wood Elf Realms | 1 | 0 | 394 | 6.0 | 1.0 | 66 | 0 | +66 | 1 of 6 | 5 of 6 | - | +66 |
| **Opponent** | all armies | 3 | 0 | 151 | 2.3 | 1.0 | 65 | 66 | -2 | 1 of 7 | 6 of 7 | - | -2 |

### Effective charges: ccut-c940641-p23

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Tomb Kings of Khemri | 7 | 0 | 0 | 0 | 0 | 4 (net +32) | 2 (net +216) | 1 | 0% (0 of 6) |
| Mine | Vampire Counts | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0 | 0 | 1 (net -405) | 0 | 0 | 0% (0 of 1) |
| Opponent | Wood Elf Realms | 6 | 1 (net +0) | 0 | 1 (net +0) | 1 (net +55) | 0 | 3 (net +113) | 0 | 17% (1 of 6) |

### Charged fights, damage counted: ccut-c940641-p23

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 262 | 146 | +144 | 205 | 22 | +183 | +69.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 416 | 120 | +32 | 63 | 30 | +32 | +7.8 |
| Mine | No odds | 1 | 411 | 125 | +125 | 125 | 0 | +125 | +30.4 |
| Mine | All fights | 8 | 358 | 130 | +86 | 124 | 23 | +100 | +28.0 |
| Opponent | Long shot (under 50%) | 1 | 102 | 170 | +0 | 45 | 34 | +11 | +10.8 |
| Opponent | Effective (55-75%) | 1 | 102 | 72 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 76-89% | 1 | 102 | 55 | +55 | 55 | 0 | +55 | +53.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 234 | 113 | +113 | 113 | 0 | +113 | +48.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 365 | 60 | -405 | 89 | 465 | -376 | -102.9 |
| Opponent | All fights | 7 | 196 | 99 | -2 | 75 | 71 | +4 | +2.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p23 | move | 25 | 3 (12%) | 2 (8%) | 4 (16%) | 18 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2429 |
| Invocation of Nehek | Mine | L2429 |
| Periapt of Soul Exchange | Mine | L2131 |
| Ring of Doom | Opponent | L2131 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |

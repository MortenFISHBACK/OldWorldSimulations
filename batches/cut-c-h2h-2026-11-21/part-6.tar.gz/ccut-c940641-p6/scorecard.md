# Doctrine scorecard: ccut-c940641-p6

### Scorecard: ccut-c940641-p6

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0913 | 1 | 1 | Mine | no | 3 | - | 0 | 1 | 0 | 0 | 0 | 420 |
| L0913 | 1 | 1 | Opponent | no | 14 | 5 | 1 | 0 | 0 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 310 |
| L0930 | 6 | 1 | Opponent | no | 12 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 5 | 3 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 0 | - | 0 | 5 | 1 | 0 | 0 | 290 |
| **Average** | | | Mine | 0% | 2.7 | 3.0 | 1.0 | 0.3 | 0.0 | 0.0 | 0.0 | 353.3 |
| **Average** | | | Opponent | 0% | 8.7 | 5.0 | 0.3 | 2.7 | 0.3 | 0.0 | 0.0 | 143.3 |

### KPIs: ccut-c940641-p6

Rules off - Mine only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 36% (5 of 14) | 0% (0 of 11) | 20% (5 of 25) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | 100% (3 of 3); on the table 100% | 100% (5 of 5); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 100% (2 of 2); on the table 100% | 100% (3 of 3); on the table 100% | 100% (5 of 5); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 38% (18 of 48) | 8% (1 of 12) | 32% (19 of 60) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 40% (18 of 45) | 17% (1 of 6) | 37% (19 of 51) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 57% (8 of 14) | 57% (8 of 14) |
| Points that never fought | lower | 76% (4561 of 5997) | 79% (4714 of 5999) | 77% (9275 of 11996) |
|   infantry points that never fought | lower | 76% (1211 of 1591) | 88% (1456 of 1660) | 82% (2667 of 3251) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 62% (21 of 34) | 70% (16 of 23) | 65% (37 of 57) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 3.0 uses a game | 50% (1 of 2); 1.7 uses a game | 75% (3 of 4); 2.3 uses a game |
| Bound items with another spell used |  | 0% (0 of 1); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 100% (2 of 2); 0.7 uses a game | 67% (2 of 3); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 61% (3438 of 5667) | 64% (3275 of 5150) | 62% (6713 of 10817) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 5.3 (53%) | 0.7 (18%) | 6.0 (44%) |
| MARCHED: its unit marched | 3.7 (37%) | 0.7 (18%) | 4.3 (32%) |
| IN COMBAT: engaged in combat | 1.0 (10%) | 0.0 (0%) | 1.0 (7%) |
| GONE: slain | 0.0 (0%) | 2.0 (55%) | 2.0 (15%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (9%) | 0.3 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 2.0 | 3.0 | 0.7 | 6.3 | 0.3 | 0.3 |
| not cast | 2.0 | 5.0 | 1.3 | 13.7 | 1.7 | 19.7 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 4.0 (80%) | 0.0 (0%) | 6.0 (44%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.3 (32%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (7%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 2.0 (100%) | 0.0 (0%) | 1.3 (100%) | 2.0 (15%) | 0.0 (0%) | 4.3 (22%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 1.0 (20%) | 0.0 (0%) | 0.3 (2%) | 1.7 (100%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.3 (78%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 0.7 a game | 0.3 a game |
| stood (cast and not dispelled) | - | 100% (2 of 2) | 100% (2 of 2) |
| the unit moved after it | - | 100% (2 of 2) | 100% (2 of 2) |
| it charged on its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| the enemy charged it first | - | 0% (0 of 2) | 0% (0 of 2) |
| it fought by the end of its next turn | - | 0% (0 of 2) | 0% (0 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 2) | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (2 of 2) | 100% (2 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (73 of 120) | 75% (36 of 48) | 65% (109 of 168) |
|   character | 100% (2 of 2) | 22% (2 of 9) | 36% (4 of 11) |
|   chariot | 87% (13 of 15) | 78% (7 of 9) | 83% (20 of 24) |
|   infantry | 44% (24 of 54) | 83% (15 of 18) | 54% (39 of 72) |
|   monster | 58% (7 of 12) | - | 58% (7 of 12) |
|   war machine | 73% (27 of 37) | 100% (12 of 12) | 80% (39 of 49) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 5.0 (32%) | 1.7 (42%) | 6.7 (34%) |
| CHARGED: it charged | 1.3 (9%) | 0.7 (17%) | 2.0 (10%) |
| MOVED: a war machine that moved | 1.3 (9%) | 0.0 (0%) | 1.3 (7%) |
| NO TARGET IN RANGE | 4.7 (30%) | 1.3 (33%) | 6.0 (31%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.7 (17%) | 0.0 (0%) | 2.7 (14%) |
| SHELTERED: the target was sheltered | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR | 0.3 (2%) | 0.3 (8%) | 0.7 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| character | 1.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 6.7 | 1.7 | 85% | 5.8 pts | 39 pts |
| infantry | 17.0 | 6.7 | 73% | 6.0 pts | 103 pts |
| monster | 4.3 | 1.0 | 77% | 7.0 pts | 30 pts |
| war machine | 13.3 | 16.0 | 42% | 39.1 pts | 521 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.0 | 1.0 | 1.5 |
| Charges that made contact a game | 1.0 | 1.0 | 1.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.33 declared, 0.33 contact (3 units) | 0.00 declared, 0.00 contact (2 units) | 0.20 declared, 0.20 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.25 declared, 0.10 contact (20 units) | 0.13 declared, 0.13 contact (23 units) | 0.19 declared, 0.12 contact (43 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 40% (2 of 5) | - | - | 40% (2 of 5) |
| Character in a unit | 100% (6 of 6) | 100% (2 of 2) | - | 100% (8 of 8) |
| Character on its own | 100% (1 of 1) | 50% (2 of 4) | 25% (1 of 4) | 44% (4 of 9) |
| Chariot | 100% (3 of 3) | 100% (2 of 2) | - | 100% (5 of 5) |
| Infantry | 36% (5 of 14) | 75% (3 of 4) | - | 44% (8 of 18) |
| Monster | - | 100% (2 of 2) | - | 100% (2 of 2) |
| Monstrous | - | 100% (2 of 2) | - | 100% (2 of 2) |
| War Machines | 75% (6 of 8) | - | - | 75% (6 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 2 | 100% (1 of 1); on the table 100% | 42% (10 of 24) | 81% | 67% (16 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | 100% (1 of 1); on the table 100% | 33% (8 of 24) | 66% | 50% (5 of 10) | 100% (2 of 2); 9.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| High Elf Realms | 1 | - | 17% (1 of 6) | 88% | 38% (3 of 8) | 100% (1 of 1); 5.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game |
| Skaven | 1 | 100% (3 of 3); on the table 100% | 0% (0 of 6) | 72% | 89% (8 of 9) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 1 | - | - | 76% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p6, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 67% (2) | 67% (2) | 67% (4) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.67 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.67 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: ccut-c940641-p6

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 17% (1 of 6) | 100% (3 of 3) |
| Strategy | Shoot objectives carried out (shot that target) | 16% (8 of 51) | 50% (10 of 20) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 100% (2 of 2) | - |
| Strategy | Joined characters whose unit fought | 12% (1 of 8) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 33% (2 of 6) | 40% (2 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.3 | 2.7 |
| Movement | Points that never moved of their own | 353.3 | 143.3 |
| Movement | Fights charged into per game | 1.0 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 3 | 0 of 3 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 3 | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 3 | 0 of 3 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 3, net -32 | 2 of 3, net +62 |
| Shooting | Shots by shooting units (incl. breath weapons) | 15.3 | 9.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 37% (17 of 46) | 63% (17 of 27) |
| Shooting | Points destroyed by shooting units | 0.0 | 98.3 |
| Shooting | War machine shots | 9.0 | 4.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (13 of 27) | 50% (6 of 12) |
| Shooting | Points destroyed by war machines | 181.3 | 0.0 |
| Magic | Magic missiles cast | 3.3 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 40% (4 of 10) | 0% (0 of 1) |
| Magic | Wounds caused by magic missiles | 9.3 | 3.0 |
| Magic | Points destroyed by magic (all spells) | 188.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.7 / 0.0 / 0.3 | 1.3 / 2.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 48.3 | 121.7 |
| Combat | Points run down | 0.0 | 45.0 |
| Combat | Net points per charged fight, damage counted | +9 | +148 |
| Combat | Net per 100 charger points, damage counted | +4.0 | +73.3 |
| Combat | First round won (charged fights) | 100% | 100% |
| Combat | Net points per charged fight | -32 | +87 |
| Combat | Net points per supported fight / lone fight | - / -32 | - / +87 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 3 | 1 of 3 |
| Game | Points lost | 266.3 | 564.7 |
| Game | VP from objectives | 730.0 | 986.7 |
| Game | Lone holders (player turns) | 2.7 | 8.7 |

- Mine won / drew / lost: 0 / 3 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +29 VP
- Points traded per game (both sides' losses): 831
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: ccut-c940641-p6

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 22.3 | +330.6 | 0.0 | 0.0 | 18.7 | +145.2 | 0.0 | 258.3 |
| ARTILLERY RE-ROLL WEIGHED | 4.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +0.4 | 0.0 | 0.0 | 0.7 | +3.5 | 0.0 | 159.7 |
| CANNON PLANNED TARGET | 9.3 | +254.9 | 719.3 | 125.0 | 4.0 | +65.8 | 208.3 | 0.0 |
| CANNON SIGHT KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 3.3 | +78.8 | 266.7 | 0.0 | 0.7 | +11.1 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | - | - | - | - | 0.7 | +0.0 | 0.0 | 266.7 |
| CHAFF IN THE MOVE | - | - | - | - | 1.3 | +20.0 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | -0.1 | 0.0 | 0.0 | 0.3 | -2.2 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +16.7 | 0.0 | 0.0 | 0.7 | +4.3 | 0.0 | 319.3 |
| CHAMPION KNOWS CHALLENGE | 0.3 | +46.0 | 159.7 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 2.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LIST READ AGAIN | 0.3 | +7.1 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 15.0 | -640.6 | 0.0 | 0.0 | 32.0 | -1647.7 | 0.0 | 1042.7 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 208.0 | 45.0 | 0.7 | +0.0 | 86.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 5.0 | +0.0 | 0.0 | 0.0 | 8.7 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 0.7 | +103.6 | 266.7 | 266.7 |
| COVER ONCE | 7.3 | -652.4 | 0.0 | 41.7 | 4.0 | -182.1 | 0.0 | 293.0 |
| DENIED BY THE FIGHT | 0.3 | -0.6 | 159.7 | 0.0 | 0.3 | -7.0 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 8.7 | -63.5 | 0.0 | 0.0 | 7.0 | +37.9 | 0.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +0.6 | 41.7 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| EXACT ROUND | 1.3 | +5.2 | 48.3 | 45.0 | 0.7 | +2.7 | 86.7 | 0.0 |
| FALL BACK GOOD ORDER | 1.7 | +4.0 | 159.7 | 45.0 | 0.7 | +16.8 | 45.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 26.7 | +298.2 | 0.0 | 606.3 |
| FEATURE BUFFS | 2.0 | +38.7 | 0.0 | 0.0 | 2.7 | +44.9 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +1.6 | 159.7 | 0.0 | 0.3 | -0.4 | 45.0 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 102.7 | +6574.4 | 3990.7 | 364.3 | 97.0 | +6100.7 | 491.7 | 1572.7 |
| FLANK NOT WEIGHED | 4.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 159.7 |
| FOLLOW UP WEIGHED | - | - | - | - | 0.7 | +72.4 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.0 | +39.9 | 208.0 | 45.0 | 1.0 | +78.9 | 86.7 | 0.0 |
| FREED FROM HIS FIGHT | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 40.0 |
| FRIEND SHOOTS FIRST | 0.7 | -18.9 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 9.3 | +1437.3 | 0.0 | 0.0 | 14.0 | +1765.9 | 0.0 | 0.0 |
| GUN FIGURES | 3.3 | +41.5 | 133.3 | 0.0 | 0.7 | +0.0 | 0.0 | 21.7 |
| GUN MASK | 6.7 | +99.6 | 0.0 | 0.0 | 2.0 | +49.9 | 0.0 | 133.3 |
| HARD STAY DROPPED | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 7.0 | +0.0 | 0.0 | 0.0 | 12.7 | +0.0 | 0.0 | 634.3 |
| HIS CHARGE DENIED | 0.3 | +19.3 | 159.7 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 5.3 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 48.3 |
| HIS LEGAL MOVES | 1.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 266.7 |
| HIS MOVE AND SHOT | 2.0 | -23.3 | 0.0 | 0.0 | 5.3 | -73.1 | 0.0 | 133.3 |
| HIS MOVE AS HE DECIDES | 42.0 | +8.7 | 583.0 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 42.7 | +0.0 | 0.0 | 578.3 |
| HIS ONE MOVE | 20.0 | -16.4 | 0.0 | 0.0 | - | - | - | - |
| HIS ONE QUARTER | 5.0 | +0.0 | 0.0 | 0.0 | 8.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 2.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 266.7 |
| HIS RANDOM MOVE | 14.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 4.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 40.0 | +1278.0 | 0.0 | 0.0 | 76.0 | +5875.3 | 0.0 | 1486.0 |
| HIS SHOTS BY HIS RUN | 29.7 | +514.6 | 0.0 | 0.0 | 73.0 | +2208.9 | 0.0 | 1244.3 |
| HIS TURN DENIED | - | - | - | - | 0.7 | +51.9 | 41.7 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 22.3 | +0.0 | 0.0 | 0.0 | 32.0 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 13.3 | +1165.5 | 0.0 | 0.0 | 16.7 | +1664.4 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.0 | -37.1 | 208.0 | 45.0 | 0.7 | -18.8 | 41.7 | 0.0 |
| IDLE COST | - | - | - | - | 13.0 | -267.8 | 0.0 | 538.3 |
| JOINT CHARGE NOW | 0.7 | +12.6 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 3.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.7 | +11.3 | 0.0 | 0.0 | 0.7 | +40.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | - | - | - | - | 2.3 | +0.0 | 0.0 | 958.0 |
| LONE WIZARD KEPT IN | 1.3 | +60.0 | 0.0 | 0.0 | 0.3 | +58.3 | 0.0 | 0.0 |
| LONG SHOT | 1.0 | -25.5 | 159.7 | 0.0 | 0.7 | +0.0 | 0.0 | 43.3 |
| LOST AFTER ESCAPE | 1.3 | +7.0 | 159.7 | 45.0 | 0.7 | +1.1 | 45.0 | 0.0 |
| MANOEUVRE | 2.3 | -9.4 | 0.0 | 0.0 | 1.3 | -0.9 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 1.7 | +96.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.7 | +29.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.3 | +3.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 2.3 | -256.3 | 0.0 | 0.0 | 0.3 | +29.6 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 4.0 | +43.6 | 0.0 | 0.0 | 0.3 | +4.3 | 0.0 | 133.3 |
| MEETS IN TIME | 4.3 | +509.9 | 0.0 | 0.0 | 3.3 | +324.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 11.0 | +212.7 | 0.0 | 0.0 | 2.3 | +69.7 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 14.3 | +200.4 | 0.0 | 0.0 | 4.0 | +41.4 | 0.0 | 446.7 |
| MOVE ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 266.7 |
| MOVE TO CHARGE COMPUTED | 6.3 | +289.6 | 0.0 | 0.0 | 3.0 | +329.3 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 12.3 | +593.0 | 0.0 | 0.0 | 7.7 | +345.6 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 3.3 | +164.6 | 0.0 | 0.0 | 2.3 | +285.4 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -10.0 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 1.7 | -115.0 | 208.0 | 45.0 | 0.7 | -32.1 | 41.7 | 0.0 |
| NO LATE CUT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO RALLY LEFT | - | - | - | - | 0.3 | +12.2 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 7.3 | -249.6 | 0.0 | 41.7 | 2.7 | -96.3 | 0.0 | 0.0 |
| OGRE LOADER SECOND SHOT | 3.7 | +37.8 | 0.0 | 0.0 | - | - | - | - |
| ONE CHALLENGE TEST | 0.3 | +46.0 | 159.7 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 5.7 | -99.0 | 0.0 | 0.0 | 4.7 | -120.9 | 0.0 | 293.0 |
| ONE OBJECTIVE FORMULA | 5.3 | -0.2 | 0.0 | 0.0 | 8.3 | +120.5 | 0.0 | 0.0 |
| ONE ROUTE | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.3 | +12.3 | 0.0 | 45.0 | 0.3 | +2.2 | 45.0 | 0.0 |
| PERIAPT WORTH | - | - | - | - | 0.3 | +18.0 | 0.0 | 0.0 |
| PLAN RESULT | 44.7 | +1580.8 | 1786.0 | 367.7 | 45.0 | +378.3 | 83.3 | 1004.3 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 9.0 | -158.0 | 0.0 | 0.0 | 3.3 | -43.9 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.7 | -0.9 | 0.0 | 0.0 | - | - | - | - |
| PURSUES BIG PREY | - | - | - | - | 0.3 | -25.0 | 0.0 | 0.0 |
| QUARTER ODDS | 16.0 | +1676.7 | 43.3 | 69.3 | 19.3 | +1955.1 | 83.3 | 80.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.7 | +90.3 | 0.0 | 96.7 |
| REAL GROUND | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 0.3 | -15.2 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.7 | -45.9 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 0.7 | -18.8 | 48.3 | 45.0 | 1.0 | -7.3 | 86.7 | 0.0 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | 0.3 | -0.7 | 0.0 | 0.0 | - | - | - | - |
| RUN DOWN | 2.0 | -19.4 | 208.0 | 45.0 | 1.0 | -12.2 | 86.7 | 0.0 |
| SAME CHARGE LATER | 0.3 | -0.5 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.0 | -114.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 1.0 | -6.2 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 1.0 | +20.9 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 16.7 | +0.0 | 0.0 | 159.7 | 7.3 | +0.0 | 0.0 | 21.7 |
| SHOOTS FROM THE BEST SPOT | 3.7 | +57.4 | 0.0 | 0.0 | 1.0 | +16.3 | 0.0 | 0.0 |
| SHOT OR CHARGE | 1.0 | -70.9 | 479.0 | 0.0 | 1.3 | -16.7 | 41.7 | 0.0 |
| SHOT RISK POINTS | 13.3 | -96.2 | 0.0 | 0.0 | 45.7 | -512.2 | 0.0 | 1129.3 |
| SHOTS AFTER THE MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 25.7 | +915.5 | 0.0 | 159.7 | 11.0 | +367.6 | 0.0 | 203.0 |
| SPELL WORTH | - | - | - | - | 2.0 | +60.0 | 446.7 | 446.7 |
| SPELLS IN THE FIGHT | 0.3 | +1.3 | 48.3 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 4.3 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 355.0 |
| STANDS FOR A REASON | - | - | - | - | 3.0 | +0.0 | 0.0 | 499.3 |
| STANDS STILL | 47.3 | +0.0 | 3782.7 | 319.3 | 36.3 | +0.0 | 405.0 | 447.7 |
| STAY WORTH | 43.7 | +244.2 | 3489.7 | 250.0 | 19.0 | +291.8 | 405.0 | 86.7 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 1.7 | +31.7 | 0.0 | 0.0 | 4.0 | +236.1 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 45.0 | - | - | - | - |
| SUPPORT WORKED OUT | 1.7 | +31.7 | 0.0 | 0.0 | 4.0 | +236.1 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 21.7 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 3.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 40.0 |
| THE ROW KEEPS ITS WAY | 4.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 21.7 |
| THE ROW READS HIS LAST RUN | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE STEP BACK IS MADE | 3.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 21.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 47.0 | +0.0 | 0.0 | 159.7 | 46.7 | +0.0 | 0.0 | 738.0 |
| TIED UP BY THE SUM | 0.7 | +58.5 | 48.3 | 45.0 | 0.3 | +23.9 | 41.7 | 0.0 |
| TIME ON OUR SIDE | 39.0 | +575.8 | 0.0 | 15.0 | - | - | - | - |
| WAITS AGAIN | 2.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | +0.6 | 90.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +1.7 | 45.0 | 0.0 |
| WHOLE FIGHT DANGER | 5.3 | -409.4 | 0.0 | 0.0 | 3.7 | -363.9 | 0.0 | 586.0 |
| WOUNDS ON THE RANKS | 1.0 | +10.9 | 0.0 | 0.0 | 3.0 | +182.1 | 0.0 | 0.0 |

### Rule changes: ccut-c940641-p6

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE WHY | 128 | 128 | 101 | 33.67 | +0 | +0.0 |
| HIS MOVE AS HE DECIDES | 126 | 126 | 100 | 33.33 | +0 | +0.0 |
| HIS SHOT LIST | 348 | 341 | 95 | 31.67 | +2770 | +29.2 |
| ARMY TABLE | 123 | 123 | 88 | 29.33 | +1197 | +13.6 |
| HOLDER ASSIGNMENT | 90 | 90 | 85 | 28.33 | +5314 | +62.5 |
| HIS SHOTS BY HIS RUN | 308 | 304 | 77 | 25.67 | +1003 | +13.0 |
| SHOT RISK POINTS | 177 | 175 | 47 | 15.67 | +1874 | +39.9 |
| DEPLOY BY FIGURES | 47 | 47 | 33 | 11.00 | +783 | +23.7 |
| OFF BEST | 30 | 30 | 30 | 10.00 | -1037 | -34.6 |
| THE TABLE AGAIN | 36 | 36 | 29 | 9.67 | +0 | +0.0 |
| CHARGE LOSSES | 141 | 139 | 27 | 9.00 | +1358 | +50.3 |
| FIVE ACTION | 599 | 592 | 24 | 8.00 | +1104 | +46.0 |
| GOAL WALK | 70 | 69 | 22 | 7.33 | +3038 | +138.1 |
| HIS ONE MOVE | 60 | 59 | 18 | 6.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 28 | 27 | 14 | 4.67 | +582 | +41.6 |
| PROMISE BY ITS OWN SUM | 37 | 37 | 13 | 4.33 | -606 | -46.6 |
| ARTILLERY RE-ROLL WEIGHED | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| QUARTER ODDS | 106 | 102 | 12 | 4.00 | +1252 | +104.4 |
| MEETS IN TIME | 23 | 23 | 11 | 3.67 | +1042 | +94.7 |
| OGRE LOADER SECOND SHOT | 11 | 11 | 11 | 3.67 | +113 | +10.3 |
| STAY WORTH | 188 | 171 | 11 | 3.67 | +131 | +11.9 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| CAST JOB | 12 | 12 | 9 | 3.00 | +81 | +9.0 |
| MOVE ORDER | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 17 | 16 | 8 | 2.67 | +397 | +49.7 |
| RANDOM MOVE BY FIGURES | 14 | 14 | 8 | 2.67 | +271 | +33.8 |
| SHOOTS FROM THE BEST SPOT | 14 | 14 | 8 | 2.67 | +66 | +8.3 |
| SHOTS AFTER THE MOVES | 24 | 24 | 8 | 2.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 117 | 96 | 8 | 2.67 | +9 | +1.1 |
| LEGAL CHARGES ONLY | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| HARD STAY DROPPED | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| FOUR ROUNDS | 9 | 9 | 5 | 1.67 | +214 | +42.7 |
| LONE WIZARD KEPT IN | 5 | 5 | 5 | 1.67 | +355 | +71.0 |
| MARCH BY THE SUM | 5 | 5 | 5 | 1.67 | +290 | +58.0 |
| CANNON PLANNED TARGET | 40 | 40 | 4 | 1.33 | +58 | +14.6 |
| CASTER AWAY FROM SCREEN | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 8 | 8 | 4 | 1.33 | -66 | -16.6 |
| FALLS SHORT | 80 | 66 | 4 | 1.33 | +29 | +7.4 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +154 | +38.5 |
| THE RISK READS HIS RUN | 18 | 18 | 4 | 1.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +63 | +21.0 |
| COVER ONCE | 34 | 23 | 3 | 1.00 | +14 | +4.7 |
| FEATURE BUFFS | 14 | 14 | 3 | 1.00 | +32 | +10.7 |
| GUN MASK | 26 | 26 | 3 | 1.00 | +99 | +32.9 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| IDLE COST | 39 | 32 | 3 | 1.00 | +18 | +5.8 |
| ONE OBJECTIVE FORMULA | 41 | 29 | 3 | 1.00 | +195 | +64.9 |
| SUPPORT ADDS | 17 | 17 | 3 | 1.00 | +37 | +12.3 |
| SUPPORT WORKED OUT | 17 | 17 | 3 | 1.00 | +37 | +12.3 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | -7 | -3.4 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +217 | +108.6 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +38 | +18.9 |
| MISSILES IN THE MOVE | 40 | 26 | 2 | 0.67 | +16 | +7.9 |
| OVERRUNS AWAY | 2 | 2 | 2 | 0.67 | +8 | +3.9 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| SHOTS IN THE MOVE | 110 | 80 | 2 | 0.67 | +54 | +27.1 |
| TIED UP BY THE SUM | 3 | 3 | 2 | 0.67 | +13 | +6.3 |
| WAR ENGINE JOBS | 2 | 2 | 2 | 0.67 | -4 | -2.1 |
| WHAT THE JOINER ADDS | 2 | 2 | 2 | 0.67 | +1 | +0.4 |
| ADVANCE LANE KEPT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 1 | 0.33 | +89 | +89.4 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +21 | +21.3 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EVASIVE BY THE ODDS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 6 | 6 | 1 | 0.33 | +5 | +5.1 |
| FALL BACK GOOD ORDER | 7 | 7 | 1 | 0.33 | +8 | +7.5 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| LOST AFTER ESCAPE | 6 | 6 | 1 | 0.33 | +0 | +0.4 |
| MARCH CHECK | 2 | 2 | 1 | 0.33 | +35 | +34.6 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -11 | -10.6 |
| NEARER NOT NEEDED | 60 | 55 | 1 | 0.33 | +22 | +21.5 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.33 | +32 | +32.5 |
| ONE CHALLENGE TEST | 1 | 1 | 1 | 0.33 | +89 | +89.4 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +54 | +54.0 |
| PROMISE KNOWS THE FIGHT | 2 | 2 | 1 | 0.33 | -3 | -2.6 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.33 | -75 | -75.0 |
| REFORMS TO MEET IT | 5 | 5 | 1 | 0.33 | +21 | +20.8 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +3 | +3.3 |
| SET UP BY THE SET | 3 | 3 | 1 | 0.33 | +6 | +6.4 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +1 | +0.8 |
| THE ROW IN ITS ORDER | 25 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT | 1 | 1 | 1 | 0.33 | +0 | +0.4 |
| WOUNDS ON THE RANKS | 12 | 12 | 1 | 0.33 | +4 | +3.8 |
| BACKUP TARGETS | 3 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CHARACTER GUNS | 14 | 14 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 41 | 41 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 2 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 26 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 10 | 9 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 12 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 59 | 59 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 38 | 38 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 13 | 13 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 22 | 22 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 41 | 38 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 17 | 17 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 42 | 41 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 13 | 12 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 163 | 163 | 0 | 0.00 | - | - |
| HONEST WORTH | 8 | 8 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 13 | 13 | 0 | 0.00 | - | - |
| LONG SHOT | 5 | 5 | 0 | 0.00 | - | - |
| MANOEUVRE | 11 | 11 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 8 | 8 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 8 | 8 | 0 | 0.00 | - | - |
| MAX FOR POSITIONING | 13 | 13 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 55 | 41 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 2 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 7 | 7 | 0 | 0.00 | - | - |
| NO LATE CUT | 5 | 5 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 31 | 19 | 0 | 0.00 | - | - |
| ONE ROUTE | 8 | 8 | 0 | 0.00 | - | - |
| PLAN RESULT | 269 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 8 | 8 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 1 | not checked | - | - | - | - |
| REFUSING RETIRES | 2 | 2 | 0 | 0.00 | - | - |
| RISK BY ARC | 5 | 5 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 9 | 9 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 3 | 3 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 72 | not checked | - | - | - | - |
| SHOT OR CHARGE | 7 | 7 | 0 | 0.00 | - | - |
| SPELL WORTH | 6 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 32 | 29 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 9 | 9 | 0 | 0.00 | - | - |
| STANDS STILL | 251 | 249 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 10 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 27 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 1 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 16 | not checked | - | - | - | - |
| THE TABLE BINDS | 281 | not checked | - | - | - | - |
| WAITS AGAIN | 11 | 11 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 27 | 26 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p6

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 7.00 | 2.67 | 32.5 |
| ARMY TABLE | rule | 4.33 | 2.33 | 71.9 |
| PROMISE BY ITS OWN SUM | rule | 3.67 | 0.67 | 46.6 |
| HOLDER ASSIGNMENT | rule | 1.00 | 0.67 | 20.8 |
| CHARGE NOW FIRST | rule | 1.00 | 0.33 | 16.6 |
| WAR ENGINE JOBS | rule | 0.67 | - | 2.1 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.33 | - | 95.8 |
| CHAFF PASSED | rule | - | 0.33 | 6.6 |
| JOINT CHARGE NOW | rule | 0.33 | - | 22.3 |
| MARCH OF THE TABLE | rule | 0.33 | - | 10.6 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | - | 2.6 |
| PURSUES BIG PREY | rule | - | 0.33 | 75.0 |

### Plans: ccut-c940641-p6

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 33% | 84 | 48 | 57% |
| Mine | move | 29.3 | 100% | 2017 | 0 | 0% |
| Mine | shoot | 14.3 | 42% | 736 | 1532 | 208% |
| Opponent | charge | 0.7 | 100% | 112 | 87 | 77% |
| Opponent | move | 37.7 | 95% | 2474 | 0 | 0% |
| Opponent | shoot | 5.7 | 71% | 278 | 292 | 105% |
| Opponent | support | 1.0 | 100% | 0 | 0 | - |

### Battle groups: ccut-c940641-p6

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p6

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 10 | 16 (10) | 16 | 0 | 17 | 50% | 2.8 | 24 (6) | 0 (4) | - | 19 (6) | 10 (4) |
| Mine | Clean-up | 3 | 77 (3) | 0 | 77 | 0 | 67% | 5.0 | 16 (1) | 108 (2) | - | 77 (3) | - |
| Mine | Fast Hammer | 3 | 10 (3) | 10 | 0 | 29 | 0% | 2.7 | 14 (2) | - | 0 (1) | 10 (3) | - |
| Mine | Hammer | 6 | 0 (6) | 0 | 0 | 0 | 17% | 2.0 | 0 (2) | 0 (4) | - | 0 (5) | 0 (1) |
| Mine | Shooter | 6 | 115 (6) | 0 | 115 | 17 | 0% | 1.7 | 0 (1) | 144 (3) | 130 (2) | 115 (6) | - |
| Mine | War machine | 8 | 50 (8) | 50 | 0 | 35 | 0% | 1.4 | 0 (3) | 128 (3) | 20 (2) | 0 (1) | 57 (7) |
| Mine | Wizard | 4 | 167 (4) | 167 | 0 | 0 | 50% | 1.5 | 0 (1) | 222 (3) | - | 222 (3) | 0 (1) |
| Opponent | Chaff | 2 | 288 (2) | 0 | 288 | 44 | 100% | - | 514 (1) | 0 (1) | - | 514 (1) | 0 (1) |
| Opponent | Character | 9 | 43 (9) | 34 | 9 | 53 | 56% | 1.5 | 123 (1) | 32 (7) | 0 (1) | 25 (5) | 67 (4) |
| Opponent | Clean-up | 3 | 103 (3) | 0 | 103 | 0 | 100% | - | 0 (1) | 188 (2) | - | 188 (2) | 0 (1) |
| Opponent | Fast Hammer | 6 | 70 (6) | 0 | 70 | 0 | 83% | 1.0 | - | 105 (4) | 16 (2) | 70 (6) | - |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Hammer | 4 | 0 (4) | 0 | 0 | 22 | 25% | 2.3 | - | 0 (2) | 0 (2) | 0 (4) | - |
| Opponent | Holder | 4 | 34 (4) | 34 | 0 | 0 | 50% | 3.5 | - | 34 (4) | - | 147 (1) | 0 (3) |
| Opponent | Shooter | 4 | 10 (4) | 10 | 0 | 28 | 25% | 1.7 | 0 (1) | 0 (1) | 13 (2) | 11 (3) | 0 (1) |
| Opponent | War machine | 2 | 179 (2) | 179 | 0 | 0 | 0% | 1.0 | - | - | 179 (2) | 179 (1) | 179 (1) |

### Charged fights: ccut-c940641-p6

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 440 | 0 | 0.5 | 1.0 | 0 | 240 | -240 | 1 of 1 | 1 of 1 | - | -240 |
| Mine | Grand Cathay | 1 | 230 | 145 | 2.0 | 1.0 | 72 | 0 | +72 | 0 of 2 | 2 of 2 | - | +72 |
| **Mine** | all armies | 3 | 370 | 48 | 1.0 | 1.0 | 48 | 80 | -32 | 1 of 3 | 3 of 3 | - | -32 |
| Opponent | High Elf Realms | 1 | 295 | 125 | 2.0 | 1.0 | 62 | 0 | +62 | 1 of 2 | 2 of 2 | - | +62 |
| Opponent | Skaven | 1 | 0 | 135 | 1.0 | 1.0 | 135 | 0 | +135 | 0 of 1 | 1 of 1 | - | +135 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 98 | 87 | 1.0 | 1.0 | 87 | 0 | +87 | 1 of 3 | 3 of 3 | - | +87 |

### Effective charges: ccut-c940641-p6

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net -240) | 0 | 0% (0 of 1) |
| Mine | Grand Cathay | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +72) | 0 | 0% (0 of 2) |
| Opponent | High Elf Realms | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +62) | 0 | 0% (0 of 2) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 1 (net +135) | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: ccut-c940641-p6

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 238 | 239 | -32 | 112 | 102 | +9 | +4.0 |
| Mine | All fights | 3 | 238 | 239 | -32 | 112 | 102 | +9 | +4.0 |
| Opponent | 76-89% | 1 | 112 | 135 | +135 | 218 | 39 | +179 | +160.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 247 | 176 | +62 | 132 | 0 | +132 | +53.6 |
| Opponent | All fights | 3 | 202 | 162 | +87 | 161 | 13 | +148 | +73.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p6 | move | 19 | 4 (21%) | 3 (16%) | 0 (0%) | 15 (79%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Periapt of Soul Exchange | Opponent | L1021 |
| Ring of Jet | Mine | L1021 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Opponent | L1021 |
| Twice-Blessed Armour | Mine | L1021 |

# Doctrine scorecard: ccut-c940641-p36

### Scorecard: ccut-c940641-p36

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2531 | 5 | 1 | Mine | yes | - | 4 | 4 | 3 | 0 | 0 | 0 | 211 |
| L2531 | 5 | 1 | Opponent | yes | - | 2 | 2 | 3 | 1 | 0 | 0 | 170 |
| L2730 | 6 | 1 | Mine | no | 0 | 2 | 12 | 3 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 6 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L2934 | 6 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| **Average** | | | Mine | 50% | 0.0 | 3.0 | 8.0 | 3.0 | 0.0 | 0.0 | 0.0 | 105.5 |
| **Average** | | | Opponent | 50% | 6.0 | 2.0 | 2.5 | 2.0 | 0.5 | 0.0 | 0.0 | 85.0 |

### KPIs: ccut-c940641-p36

Rules off - Opponent only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 13) | 0% (0 of 12) | 0% (0 of 25) |
| Winner chose to follow up after the loser gave ground |  | - | 83% (5 of 6); on the table 83% | 83% (5 of 6); on the table 83% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (3 of 3); on the table 100% | - | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 100% (3 of 3); on the table 100% | 83% (5 of 6); on the table 83% | 89% (8 of 9); on the table 89% |
| Magic missiles tried each own turn | 50%+ | 50% (3 of 6) | 33% (2 of 6) | 42% (5 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 50% (3 of 6) | 40% (2 of 5) | 45% (5 of 11) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 100% (2 of 2) | 86% (6 of 7) | 89% (8 of 9) |
| Points that never fought | lower | 43% (1714 of 3999) | 28% (1107 of 4000) | 35% (2821 of 7999) |
|   infantry points that never fought | lower | 68% (310 of 457) | 27% (150 of 559) | 45% (460 of 1016) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 58% (7 of 12) | 83% (15 of 18) | 73% (22 of 30) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game | 100% (1 of 1); 0.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 53% (1677 of 3154) | 90% (3306 of 3654) | 73% (4983 of 6808) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (67%) | 0.7 (50%) | 1.3 (57%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.3 (25%) | 0.3 (14%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (25%) | 0.3 (14%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.3 (33%) | 0.0 (0%) | 0.3 (14%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 1.7 | 1.3 | 2.3 | 1.7 | 0.7 | 1.0 |
| not cast | 4.3 | 0.0 | 1.7 | 2.3 | 1.3 | 20.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | - | 0.3 (20%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (8%) | - | 0.3 (20%) | 1.3 (57%) | 0.7 (50%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | - | 0.0 (0%) | 0.3 (14%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | - | 0.0 (0%) | 0.3 (14%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | - | 0.0 (0%) | 0.3 (14%) | 0.7 (50%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.0 (92%) | - | 1.0 (60%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 19.0 (95%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.3 a game | 0.0 a game | 1.2 a game |
| stood (cast and not dispelled) | 86% (6 of 7) | - | 86% (6 of 7) |
| the unit moved after it | 83% (5 of 6) | - | 83% (5 of 6) |
| it charged on its next turn | 33% (2 of 6) | - | 33% (2 of 6) |
| the enemy charged it first | 17% (1 of 6) | - | 17% (1 of 6) |
| it fought by the end of its next turn | 0% (0 of 6) | - | 0% (0 of 6) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 6) | - | 0% (0 of 6) |
| none of these (no charge, no fight, no charge escaped) | 50% (3 of 6) | - | 50% (3 of 6) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | - | 0% (0 of 3) | 0% (0 of 3) |
|   character | - | 0% (0 of 3) | 0% (0 of 3) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| CHARGED: it charged | - | 0.7 (67%) | 0.7 (67%) |
| NO TARGET IN RANGE | - | 0.3 (33%) | 0.3 (33%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.3 | 2.7 | 4.0 |
| Charges that made contact a game | 2.3 | 2.0 | 2.2 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | - | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, units carrying another wizard (or one alone) | 2.00 declared, 1.67 contact (3 units) | 0.00 declared, 0.00 contact (1 units) | 1.50 declared, 1.25 contact (4 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.42 declared, 0.08 contact (24 units) | 0.31 declared, 0.23 contact (26 units) | 0.36 declared, 0.16 contact (50 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 60% (3 of 5) | 67% (2 of 3) | 0% (0 of 1) | 56% (5 of 9) |
| Character in a unit | 100% (4 of 4) | 100% (1 of 1) | 100% (1 of 1) | 100% (6 of 6) |
| Character on its own | 33% (1 of 3) | 100% (2 of 2) | 67% (2 of 3) | 62% (5 of 8) |
| Infantry | 75% (3 of 4) | - | - | 75% (3 of 4) |
| Monster | 100% (2 of 2) | 100% (1 of 1) | - | 100% (3 of 3) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vampire Counts | 2 | 100% (3 of 3); on the table 100% | 50% (3 of 6) | 43% | 58% (7 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | 83% (5 of 6); on the table 83% | 33% (2 of 6) | 28% | 83% (15 of 18) | 100% (1 of 1); 1.5 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p36, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 80% (4) | 83% (5) | 82% (9) |
| ...free all their last turn and able to turn (per game) | 1.00 | 1.00 | 2.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.67 | 0.67 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 1.00 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: ccut-c940641-p36

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 20% (3 of 15) | 50% (3 of 6) |
| Strategy | Shoot objectives carried out (shot that target) | 0% (0 of 1) | 0% (0 of 3) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 3) | - |
| Strategy | Joined characters whose unit fought | 20% (1 of 5) | 100% (3 of 3) |
| Strategy | Lone characters that fought | 33% (2 of 6) | 80% (4 of 5) |
| Movement | Charges halted short of contact | 1.3 | 0.0 |
| Movement | Idle units | 3.0 | 2.0 |
| Movement | Points that never moved of their own | 105.5 | 85.0 |
| Movement | Fights charged into per game | 3.5 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 5, net -42 | 1 of 4, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 5 | 0 of 4 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 5 | 0 of 4 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 5, net +273 | 2 of 4, net +74 |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 0.7 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 2) | - |
| Magic | Wounds caused by other spells | 0.3 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.7 / 0.0 / 0.3 / 0.7 | 0.0 / 1.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 158.3 | 148.7 |
| Combat | Points run down | 81.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +121 | +37 |
| Combat | Net per 100 charger points, damage counted | +30.1 | +12.3 |
| Combat | First round won (charged fights) | 86% | 67% |
| Combat | Net points per charged fight | +135 | +32 |
| Combat | Net points per supported fight / lone fight | - / +135 | - / +32 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 7 | 3 of 6 |
| Game | Points lost | 223.0 | 638.5 |
| Game | VP from objectives | 620.0 | 530.0 |
| Game | Lone holders (player turns) | 0.0 | 6.0 |

- Mine won / drew / lost: 1 / 0 / 1 of 2 ended games (of 3); mean margin (Mine - Opponent) +416 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 862
- Games not ended: 1 (L2934-1); findings 2, warnings 0

### Opponent rules: ccut-c940641-p36

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.3 | +96.4 | 0.0 | 159.7 |
| ARMY TABLE | 15.3 | +298.2 | 0.0 | 49.0 | 17.3 | -394.4 | 0.0 | 122.3 |
| ASSAILMENT BY POINTS | 0.3 | +2.3 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -41.6 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.3 | -22.4 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 0.7 | +3.7 | 113.3 | 0.0 | 2.0 | +12.2 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 2.7 | +70.2 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +7.2 | 0.0 | 84.7 | 0.7 | +7.4 | 0.0 | 0.0 |
| CHARGE LIST READ AGAIN | 0.3 | +10.2 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 6.7 | -158.5 | 0.0 | 0.0 | 5.7 | -294.2 | 0.0 | 65.3 |
| CHARGE NOW FIRST | 3.0 | +0.0 | 411.7 | 30.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 19.7 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 26.7 |
| CONVEYANCE SEARCH | 2.0 | +11.4 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 6.0 | -427.3 | 0.0 | 0.0 | 7.7 | -301.2 | 0.0 | 32.7 |
| DEPLOY BY FIGURES | 7.0 | +107.4 | 0.0 | 0.0 | 7.3 | -37.6 | 0.0 | 0.0 |
| EXACT ROUND | 3.7 | +24.8 | 521.0 | 0.0 | 2.7 | -23.2 | 64.0 | 319.3 |
| FALL BACK GOOD ORDER | 4.0 | +10.2 | 444.3 | 0.0 | 2.0 | +0.0 | 64.0 | 159.7 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | 16.7 | +275.5 | 0.0 | 49.0 | - | - | - | - |
| FEATURE BUFFS | - | - | - | - | 1.0 | +7.6 | 0.0 | 32.7 |
| FIGHT TO THE END | 2.7 | +70.2 | 421.0 | 0.0 | 1.0 | +61.0 | 49.0 | 319.3 |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 71.0 | +3731.3 | 634.3 | 98.0 | 58.3 | +4704.0 | 64.0 | 857.0 |
| FLANK NOT WEIGHED | 4.7 | +0.0 | 0.0 | 49.0 | 11.0 | +0.0 | 0.0 | 201.7 |
| FOCUS FIRE | - | - | - | - | 0.3 | +5.7 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.3 | +55.1 | 0.0 | 0.0 | 1.7 | +118.4 | 0.0 | 0.0 |
| FOUR ROUNDS | 5.3 | +590.6 | 521.0 | 0.0 | 2.7 | +211.3 | 64.0 | 319.3 |
| FREED FROM HIS FIGHT | 4.0 | +0.0 | 0.0 | 0.0 | 9.7 | +0.0 | 0.0 | 102.7 |
| FRIEND CHARGES FIRST | 0.3 | -57.7 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.3 | -20.3 | 0.0 | 0.0 | 0.7 | -13.2 | 49.0 | 0.0 |
| GOAL WALK | 7.0 | +596.1 | 0.0 | 0.0 | 11.0 | +887.5 | 0.0 | 207.0 |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 0.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 23.3 |
| HELPER UNSEEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 4.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 65.3 |
| HIS CHARGE DENIED | - | - | - | - | 0.7 | +3.2 | 0.0 | 319.3 |
| HIS CHARGE LIST | 1.3 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 134.3 |
| HIS LEGAL MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 1.0 | -5.1 | 0.0 | 0.0 | - | - | - | - |
| HIS MOVE AS HE DECIDES | - | - | - | - | 35.7 | +10.0 | 79.0 | 0.0 |
| HIS MOVE WHY | 21.3 | +0.0 | 0.0 | 64.0 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 12.0 | -34.5 | 0.0 | 0.0 |
| HIS ONE QUARTER | 3.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 5.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 13.0 | +0.0 | 0.0 | 98.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVER COMES | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 4.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 23.7 | +219.0 | 0.0 | 49.0 | 12.0 | +38.4 | 0.0 | 0.0 |
| HIS SHOTS BY HIS RUN | 15.3 | +124.4 | 0.0 | 49.0 | 1.7 | +1.6 | 0.0 | 0.0 |
| HIS TURN DENIED | 0.3 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| HIS TURN RUN | 4.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 16.0 | +0.0 | 0.0 | 0.0 | 15.3 | +0.0 | 0.0 | 224.0 |
| HOLDER ASSIGNMENT | 9.7 | +967.0 | 0.0 | 0.0 | 9.3 | +873.8 | 0.0 | 112.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 5.3 | -201.9 | 521.0 | 0.0 | 1.7 | -61.9 | 15.0 | 319.3 |
| IDLE COST | 19.3 | -206.1 | 0.0 | 49.0 | - | - | - | - |
| JOINT CHARGE NOW | 1.0 | +0.4 | 59.3 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.0 | +42.8 | 0.0 | 0.0 | 0.7 | +13.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 8.7 | +0.0 | 283.7 | 413.7 | 4.3 | +0.0 | 233.3 | 138.7 |
| LOST AFTER ESCAPE | 4.0 | +16.0 | 521.0 | 0.0 | 1.0 | -5.3 | 0.0 | 159.7 |
| MANOEUVRE | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +13.9 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +2.2 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.7 | +34.1 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 0.3 | +2.0 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +37.6 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 1.0 | +43.0 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.0 | +18.6 | 0.0 | 0.0 | 3.3 | +31.8 | 0.0 | 26.7 |
| MEETS IN TIME | 3.7 | +311.9 | 0.0 | 0.0 | 3.3 | +260.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.0 | +8.3 | 0.0 | 0.0 | 2.0 | +23.3 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 1.7 | +3.9 | 0.0 | 0.0 | 3.3 | +45.7 | 0.0 | 0.0 |
| MOVE ORDER | 3.0 | +0.0 | 49.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 4.7 | +468.0 | 0.0 | 0.0 | 6.7 | +952.9 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 7.7 | +274.4 | 0.0 | 0.0 | 7.0 | +316.8 | 0.0 | 65.3 |
| NEXT CHARGE BY LIST | 4.0 | +407.4 | 0.0 | 0.0 | 3.3 | +319.7 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 4.7 | -295.2 | 461.7 | 0.0 | 1.7 | -66.7 | 64.0 | 159.7 |
| NO LATE CUT | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 4.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 4.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 2.3 | -0.6 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 3.3 | -24.0 | 0.0 | 49.0 | 2.7 | -186.4 | 15.0 | 69.0 |
| ONE CHALLENGE TEST | - | - | - | - | 0.3 | -5.6 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.0 | -52.3 | 0.0 | 0.0 | 4.3 | -58.1 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 0.3 | +2.5 | 0.0 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 5.7 | +14.1 | 0.0 | 0.0 | 3.3 | +68.9 | 0.0 | 56.0 |
| ONE PROMISE A TARGET | 0.7 | -39.1 | 0.0 | 0.0 | 0.3 | -31.7 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.7 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| PATHS CROSS | 1.0 | +20.7 | 0.0 | 0.0 | 0.7 | +1.0 | 0.0 | 0.0 |
| PLAN RESULT | 36.3 | +432.7 | 290.7 | 128.0 | 24.0 | +50.8 | 79.0 | 611.3 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 6.0 | -78.9 | 0.0 | 0.0 | 11.3 | -1007.9 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | -0.6 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| QUARTER ODDS | 8.7 | +751.7 | 113.3 | 0.0 | 8.3 | +934.0 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.7 | +44.3 | 0.0 | 0.0 | 2.3 | +9.6 | 0.0 | 0.0 |
| REAL GROUND | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 2.3 | +45.8 | 0.0 | 30.0 | - | - | - | - |
| REDIRECT COUNTER | 3.3 | +128.8 | 0.0 | 15.0 | 2.0 | +135.6 | 0.0 | 50.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.7 | +111.9 | 0.0 | 30.0 | 1.3 | +0.0 | 0.0 | 50.0 |
| REFORMS TO MEET IT | 0.7 | -1.2 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| RISK BY ARC | 4.0 | +171.7 | 444.3 | 0.0 | 2.3 | +63.0 | 64.0 | 319.3 |
| ROUNDS AFTER TERROR | 3.0 | -46.0 | 169.0 | 0.0 | - | - | - | - |
| RUN DOWN | 5.0 | -83.1 | 521.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | 2.3 | -123.0 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 1.0 | +31.0 | 0.0 | 0.0 | 0.3 | +14.5 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.7 | +55.7 | 15.0 | 0.0 |
| SET CREDITED ONCE | 1.7 | -36.2 | 0.0 | 0.0 | 1.3 | -7.2 | 0.0 | 0.0 |
| SET UP BY THE SET | 3.7 | +36.7 | 69.0 | 0.0 | 1.7 | +21.5 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.3 | +2.1 | 0.0 | 0.0 | - | - | - | - |
| SET-UP ANY TARGET | 0.7 | +71.5 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 3.0 | +0.0 | 0.0 | 15.0 | 1.0 | +0.0 | 0.0 | 69.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -0.2 | 0.0 | 0.0 |
| SHOT RISK POINTS | 9.7 | -23.4 | 0.0 | 0.0 | 1.7 | +4.6 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | - | - | - | - | 1.7 | +12.7 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.7 | +71.5 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 1.7 | +11.6 | 0.0 | 0.0 | - | - | - | - |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | -0.3 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 7.3 | +0.0 | 0.0 | 98.0 | 7.0 | +0.0 | 0.0 | 57.7 |
| STANDS STILL | 12.0 | +0.0 | 113.3 | 49.0 | 17.7 | +0.0 | 0.0 | 179.3 |
| STAY WORTH | 0.7 | +1.2 | 113.3 | 0.0 | 3.3 | +74.8 | 0.0 | 0.0 |
| STRIKE BY THE ODDS | 0.3 | +1.7 | 0.0 | 0.0 | 0.3 | -61.5 | 0.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 1.0 | +72.0 | 0.0 | 0.0 | 6.0 | +605.7 | 0.0 | 53.3 |
| SUPPORT NARROWED | 0.7 | +0.0 | 228.7 | 0.0 | 0.3 | +0.0 | 15.0 | 0.0 |
| SUPPORT WORKED OUT | 1.0 | +72.0 | 0.0 | 0.0 | 6.0 | +605.7 | 0.0 | 53.3 |
| SURE REACH TOGETHER | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -1.4 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | - | - | - | - | 4.3 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 32.7 |
| THE ROW KEEPS ITS WAY | 4.0 | +0.0 | 0.0 | 49.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 2.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 4.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 37.3 | +0.0 | 0.0 | 64.0 | 26.3 | +0.0 | 0.0 | 303.3 |
| TIED UP BY THE SUM | 2.0 | +236.3 | 125.0 | 0.0 | 1.3 | +116.4 | 64.0 | 159.7 |
| TIME ON OUR SIDE | - | - | - | - | 34.0 | +418.4 | 0.0 | 389.3 |
| WAITS AGAIN | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | +4.5 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | 0.7 | -15.6 | 65.3 | 0.0 | 0.7 | +19.4 | 0.0 | 0.0 |
| WHO FIGHTS | 0.3 | +7.6 | 159.7 | 0.0 | 0.3 | -0.4 | 49.0 | 0.0 |
| WHO HITS BACK | 0.3 | +45.8 | 0.0 | 84.7 | 0.3 | +45.0 | 0.0 | 57.7 |
| WHOLE FIGHT | 0.3 | +6.0 | 32.7 | 0.0 | 0.3 | -3.4 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 1.7 | -109.6 | 0.0 | 0.0 | 4.3 | -290.8 | 0.0 | 65.3 |
| WHOLE FIGHT GAIN | 0.7 | +1.4 | 26.7 | 0.0 | - | - | - | - |
| WOUNDED STAYS OUT | - | - | - | - | 0.3 | +0.0 | 15.0 | 0.0 |
| WOUNDS ON THE RANKS | 0.7 | +1.0 | 0.0 | 0.0 | - | - | - | - |

### Rule changes: ccut-c940641-p36

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 107 | 107 | 77 | 25.67 | +0 | +0.0 |
| ARMY TABLE | 98 | 98 | 64 | 21.33 | +758 | +11.8 |
| HOLDER ASSIGNMENT | 57 | 57 | 52 | 17.33 | +3114 | +59.9 |
| HIS MOVE WHY | 64 | 64 | 40 | 13.33 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 39 | 39 | 39 | 13.00 | +0 | +0.0 |
| DEPLOY BY FIGURES | 43 | 43 | 24 | 8.00 | +122 | +5.1 |
| FIVE ACTION | 388 | 368 | 24 | 8.00 | +1235 | +51.5 |
| PROMISE BY ITS OWN SUM | 52 | 52 | 24 | 8.00 | -3260 | -135.8 |
| THE TABLE AGAIN | 27 | 27 | 24 | 8.00 | +0 | +0.0 |
| GOAL WALK | 54 | 54 | 20 | 6.67 | +1283 | +64.1 |
| OFF BEST | 18 | 18 | 18 | 6.00 | -631 | -35.1 |
| IDLE COST | 58 | 38 | 15 | 5.00 | +103 | +6.9 |
| MOVE ORDER | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| FOUR ROUNDS | 24 | 21 | 13 | 4.33 | +1103 | +84.8 |
| HIS ONE MOVE | 36 | 33 | 13 | 4.33 | +0 | +0.0 |
| MEETS IN TIME | 21 | 21 | 13 | 4.33 | +865 | +66.5 |
| MOVE TO CHARGE COMPUTED | 34 | 24 | 13 | 4.33 | +647 | +49.8 |
| REDIRECT FOR A FRIEND IN REACH | 15 | 15 | 11 | 3.67 | +74 | +6.8 |
| TIME ON OUR SIDE | 102 | 80 | 10 | 3.33 | +0 | +0.0 |
| HIS SHOT LIST | 107 | 97 | 8 | 2.67 | +18 | +2.3 |
| NEXT CHARGE BY LIST | 22 | 19 | 8 | 2.67 | +400 | +50.1 |
| RANDOM MOVE BY FIGURES | 9 | 9 | 8 | 2.67 | +162 | +20.3 |
| THE RISK READS HIS RUN | 13 | 13 | 8 | 2.67 | +0 | +0.0 |
| RISK BY ARC | 19 | 16 | 7 | 2.33 | +261 | +37.3 |
| TIED UP BY THE SUM | 10 | 8 | 7 | 2.33 | +174 | +24.9 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 6 | 6 | 6 | 2.00 | +520 | +86.7 |
| HOLDS AMBUSHERS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| QUARTER ODDS | 51 | 46 | 6 | 2.00 | +367 | +61.1 |
| FIGHT TO THE END | 11 | 11 | 5 | 1.67 | +141 | +28.1 |
| HARD STAY DROPPED | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 51 | 47 | 5 | 1.67 | +11 | +2.3 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +170 | +33.9 |
| PATHS CROSS | 5 | 5 | 5 | 1.67 | +65 | +13.0 |
| SET UP BY THE SET | 16 | 15 | 5 | 1.67 | +221 | +44.3 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 8 | 7 | 4 | 1.33 | +0 | +0.0 |
| COVER ONCE | 41 | 27 | 4 | 1.33 | +74 | +18.5 |
| EXACT ROUND | 19 | 17 | 4 | 1.33 | +18 | +4.6 |
| MAX FOR POSITIONING | 13 | 13 | 4 | 1.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +44 | +14.6 |
| CHARGE NOW FIRST | 9 | 9 | 3 | 1.00 | -153 | -51.0 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | +1 | +0.4 |
| NEARER NOT NEEDED | 44 | 42 | 3 | 1.00 | +92 | +30.6 |
| ONE OBJECTIVE FORMULA | 27 | 24 | 3 | 1.00 | +217 | +72.2 |
| ONE PROMISE A TARGET | 3 | 3 | 3 | 1.00 | -212 | -70.7 |
| SUPPORT ADDS | 21 | 18 | 3 | 1.00 | +24 | +7.9 |
| SUPPORT WORKED OUT | 21 | 18 | 3 | 1.00 | +24 | +7.9 |
| WHOLE FIGHT DANGER | 18 | 18 | 3 | 1.00 | +208 | +69.3 |
| CAST JOB | 8 | 8 | 2 | 0.67 | +6 | +3.0 |
| FALLS SHORT | 50 | 39 | 2 | 0.67 | +0 | +0.0 |
| MANOEUVRE | 5 | 5 | 2 | 0.67 | +42 | +20.9 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +102 | +51.1 |
| PROMISE KNOWS THE FIGHT | 13 | 8 | 2 | 0.67 | -2 | -0.8 |
| SEARCH SPOT | 4 | 4 | 2 | 0.67 | +137 | +68.3 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +167 | +83.5 |
| SHOT RISK POINTS | 34 | 29 | 2 | 0.67 | +0 | +0.0 |
| STAY WORTH | 12 | 10 | 2 | 0.67 | +102 | +51.0 |
| SUPPORT NARROWED | 3 | 3 | 2 | 0.67 | -155 | -77.6 |
| WHAT THE JOINER ADDS | 4 | 4 | 2 | 0.67 | +69 | +34.6 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +68 | +34.0 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +289 | +289.2 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +7 | +7.0 |
| CARRIES OUT SET-UP | 1 | 1 | 1 | 0.33 | -67 | -67.3 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +30 | +30.5 |
| FEATURE BUFFS | 3 | 3 | 1 | 0.33 | +6 | +5.6 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +17 | +17.0 |
| HONEST WORTH | 21 | 19 | 1 | 0.33 | +57 | +56.8 |
| LOST AFTER ESCAPE | 15 | 15 | 1 | 0.33 | +3 | +2.7 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -113 | -112.7 |
| MISSILES IN THE MOVE | 12 | 6 | 1 | 0.33 | +3 | +2.8 |
| NO DOUBLE ROUNDS | 19 | 17 | 1 | 0.33 | +32 | +32.4 |
| REDIRECT BY WHAT IT STOPS | 7 | 7 | 1 | 0.33 | +0 | +0.0 |
| REDIRECT COUNTER | 16 | 14 | 1 | 0.33 | +0 | +0.0 |
| STRIKE BY THE ODDS | 2 | 2 | 1 | 0.33 | +5 | +5.2 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | +14 | +13.6 |
| WHOLE FIGHT | 2 | 2 | 1 | 0.33 | +3 | +2.7 |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 5 | trace | - | - | - | - |
| CHARGE LOSSES | 37 | 34 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 83 | 82 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 6 | not checked | - | - | - | - |
| FALL BACK GOOD ORDER | 18 | 15 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 47 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 41 | 37 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 10 | 10 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 29 | 28 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 28 | 28 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 15 | 15 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 3 | 2 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 12 | 12 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 19 | 18 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 51 | 48 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 6 | 6 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 27 | 27 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 13 | 13 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | not checked | - | - | - | - |
| HIS TURN RUN | 27 | 27 | 0 | 0.00 | - | - |
| HOLD ODDS | 94 | 93 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 9 | 9 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH CHECK | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 15 | 8 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 14 | 14 | 0 | 0.00 | - | - |
| NO SECOND RUN | 14 | 14 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 7 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE FIGHT FORMULA | 22 | 7 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 181 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 2 | 2 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 9 | 8 | 0 | 0.00 | - | - |
| RUN DOWN | 15 | 14 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 7 | 7 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 9 | 8 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 2 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 12 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | not checked | - | - | - | - |
| SHOTS IN THE MOVE | 5 | 3 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 2 | not checked | - | - | - | - |
| SPELL WORTH | 5 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 43 | 40 | 0 | 0.00 | - | - |
| STANDS STILL | 89 | 87 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 5 | 5 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 20 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 16 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 2 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 14 | not checked | - | - | - | - |
| THE TABLE BINDS | 191 | not checked | - | - | - | - |
| WAITS AGAIN | 5 | 4 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 2 | 2 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p36

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 1.33 | 6.67 | 135.8 |
| ARMY TABLE | rule | 1.00 | 3.67 | 89.1 |
| JOB FIRST | gate | 2.33 | 2.00 | 42.5 |
| CHARGE NOW FIRST | rule | 1.00 | - | 51.0 |
| ONE PROMISE A TARGET | rule | 0.67 | 0.33 | 70.7 |
| NO REASON | gate | 0.67 | - | 5.3 |
| RULE SWITCHED OFF | gate | - | 0.67 | 33.0 |
| SUPPORT NARROWED | rule | 0.67 | - | 77.6 |
| CARRIES OUT SET-UP | rule | 0.33 | - | 67.3 |
| FIGHT ORDER BAND | gate | 0.33 | - | 1.6 |
| JOINT CHARGE NOW | rule | 0.33 | - | 3.8 |
| MARCH OF THE TABLE | rule | - | 0.33 | 112.7 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | - | 1.7 |

### Plans: ccut-c940641-p36

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 4.0 | 42% | 414 | 376 | 91% |
| Mine | join | 4.0 | 100% | 166 | 0 | 0% |
| Mine | move | 26.0 | 100% | 1001 | 0 | 0% |
| Mine | shoot | 0.3 | 100% | 54 | 57 | 106% |
| Mine | support | 2.0 | 100% | 56 | 0 | 0% |
| Opponent | charge | 2.0 | 33% | 250 | 51 | 20% |
| Opponent | join | 0.7 | 100% | 23 | 0 | 0% |
| Opponent | move | 20.3 | 97% | 1632 | 0 | 0% |
| Opponent | shoot | 1.0 | 0% | 64 | 0 | 0% |

### Battle groups: ccut-c940641-p36

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.3 | 20% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 2.0 | 67% | 50% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p36

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 8 | 97 (8) | 0 | 97 | 9 | 88% | 4.0 | 0 (4) | 286 (2) | 133 (2) | 156 (5) | 0 (3) |
| Mine | Character | 7 | 34 (7) | 34 | 0 | 0 | 57% | 4.3 | 50 (2) | 0 (4) | 0 (1) | 37 (5) | 0 (2) |
| Mine | Fast | 1 | 67 (1) | 67 | 0 | 100 | 0% | 2.0 | - | 67 (1) | - | - | 67 (1) |
| Mine | Fast Hammer | 4 | 85 (4) | 57 | 28 | 0 | 25% | 3.7 | - | 43 (3) | 295 (1) | 43 (3) | 295 (1) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 73 | 50% | 2.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 50% | 1.0 | 0 (2) | 0 (1) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | Chaff | 1 | 471 (1) | 0 | 471 | 100 | 100% | - | - | 471 (1) | - | 471 (1) | - |
| Opponent | Character | 8 | 10 (8) | 10 | 0 | 35 | 12% | 4.0 | 0 (2) | 17 (5) | 0 (1) | 16 (5) | 0 (3) |
| Opponent | Fast Hammer | 5 | 38 (5) | 0 | 38 | 11 | 20% | 4.0 | 60 (2) | 0 (1) | 39 (2) | 51 (2) | 31 (3) |
| Opponent | Hammer | 4 | 40 (4) | 40 | 0 | 55 | 25% | 3.0 | - | 40 (4) | - | 0 (2) | 88 (2) |
| Opponent | Holder | 4 | 0 (4) | 0 | 0 | 16 | 75% | 5.0 | 0 (1) | 0 (2) | 0 (1) | 0 (1) | 0 (3) |

### Charged fights: ccut-c940641-p36

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 2 | 0 | 598 | 3.5 | 1.0 | 171 | 36 | +135 | 2 of 7 | 6 of 7 | - | +135 |
| Opponent | Warriors of Chaos | 2 | 0 | 96 | 3.0 | 1.0 | 32 | 0 | +32 | 3 of 6 | 4 of 6 | - | +32 |

### Effective charges: ccut-c940641-p36

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 7 | 2 (net -42) | 0 | 0 | 0 | 0 | 3 (net +273) | 2 | 0% (0 of 5) |
| Opponent | Warriors of Chaos | 6 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 2 (net +74) | 2 | 0% (0 of 4) |

### Charged fights, damage counted: ccut-c940641-p36

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 367 | 186 | -42 | 192 | 337 | -145 | -39.4 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 376 | 387 | +273 | 273 | 0 | +273 | +72.7 |
| Mine | No odds | 2 | 476 | 164 | +104 | 158 | 0 | +158 | +33.1 |
| Mine | All fights | 7 | 402 | 266 | +135 | 217 | 96 | +121 | +30.1 |
| Opponent | Long shot (under 50%) | 1 | 479 | 471 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 76-89% | 1 | 510 | 471 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 298 | 166 | +74 | 74 | 0 | +74 | +24.7 |
| Opponent | No odds | 2 | 116 | 196 | +22 | 38 | 0 | +38 | +33.0 |
| Opponent | All fights | 6 | 303 | 278 | +32 | 37 | 0 | +37 | +12.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p36 | move | 19 | 1 (5%) | 0 (0%) | 5 (26%) | 13 (68%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2531, L2730 |
| Charmed Shield | Opponent | L2934 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Ring of Doom | Opponent | L2531 |

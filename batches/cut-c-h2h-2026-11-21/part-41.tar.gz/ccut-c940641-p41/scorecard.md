# Doctrine scorecard: ccut-c940641-p41

### Scorecard: ccut-c940641-p41

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0721 | 1 | 1 | Mine | no | 4 | 1 | 5 | 1 | 0 | 0 | 0 | 170 |
| L0721 | 1 | 1 | Opponent | yes | 0 | - | 1 | 5 | 1 | 0 | 0 | 355 |
| L0810 | 6 | 1 | Mine | no | 0 | - | 1 | 2 | 0 | 0 | 0 | 461 |
| L0810 | 6 | 1 | Opponent | no | 8 | 2 | 0 | 0 | 0 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | - | 0 | 2 | 0 | 0 | 0 | 426 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 0 | 6 | 0 | 0 | 0 | 60 |
| **Average** | | | Mine | 0% | 2.0 | 1.0 | 2.0 | 1.7 | 0.0 | 0.0 | 0.0 | 352.3 |
| **Average** | | | Opponent | 67% | 4.0 | 2.0 | 0.3 | 3.7 | 0.3 | 0.0 | 0.0 | 248.3 |

### KPIs: ccut-c940641-p41

Rules off - Opponent only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 100% (14 of 14) | 0% (0 of 14) | 50% (14 of 28) |
| Winner chose to follow up after the loser gave ground |  | - | 88% (7 of 8); on the table 88% | 88% (7 of 8); on the table 88% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (1 of 1); on the table 100% | 89% (8 of 9); on the table 89% | 90% (9 of 10); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 33% (2 of 6) | 22% (8 of 36) | 24% (10 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 40% (2 of 5) | 27% (8 of 30) | 29% (10 of 35) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 67% (8 of 12) | 67% (8 of 12) |
| Points that never fought | lower | 74% (4429 of 5999) | 77% (4638 of 5998) | 76% (9067 of 11997) |
|   infantry points that never fought | lower | 92% (891 of 968) | 72% (799 of 1113) | 81% (1690 of 2081) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 73% (22 of 30) | 72% (18 of 25) | 73% (40 of 55) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (3 of 3); 4.3 uses a game | 100% (3 of 3); 2.2 uses a game |
| Bound items with another spell used |  | 100% (1 of 1); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 33% (1 of 3); 0.3 uses a game | 50% (1 of 2); 0.3 uses a game | 40% (2 of 5); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 67% (3579 of 5378) | 78% (4021 of 5181) | 72% (7600 of 10559) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 5.0 (54%) | 5.0 (47%) |
| MARCHED: its unit marched | 0.7 (50%) | 2.3 (25%) | 3.0 (28%) |
| CHARGED: its unit charged | 0.3 (25%) | 0.0 (0%) | 0.3 (3%) |
| IN COMBAT: engaged in combat | 0.3 (25%) | 0.3 (4%) | 0.7 (6%) |
| FLEEING: fleeing | 0.0 (0%) | 1.0 (11%) | 1.0 (9%) |
| GONE: slain | 0.0 (0%) | 0.7 (7%) | 0.7 (6%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 6.7 | 2.0 | 5.3 | 3.3 | 1.0 | 0.0 |
| not cast | 3.3 | 0.0 | 0.7 | 10.7 | 3.0 | 28.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | - | 0.3 (50%) | 5.0 (47%) | 1.7 (56%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | - | 0.0 (0%) | 3.0 (28%) | 1.0 (33%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | - | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | - | 0.0 (0%) | 0.7 (6%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | - | 0.0 (0%) | 1.0 (9%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.7 (20%) | - | 0.0 (0%) | 0.7 (6%) | 0.0 (0%) | 2.7 (10%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.3 (11%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.7 (80%) | - | 0.3 (50%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 25.0 (89%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 5.3 a game | 2.7 a game |
| stood (cast and not dispelled) | - | 56% (9 of 16) | 56% (9 of 16) |
| the unit moved after it | - | 56% (5 of 9) | 56% (5 of 9) |
| it charged on its next turn | - | 0% (0 of 9) | 0% (0 of 9) |
| the enemy charged it first | - | 0% (0 of 9) | 0% (0 of 9) |
| it fought by the end of its next turn | - | 0% (0 of 9) | 0% (0 of 9) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 9) | 0% (0 of 9) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (9 of 9) | 100% (9 of 9) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 80% (71 of 89) | 81% (25 of 31) | 80% (96 of 120) |
|   cavalry | 88% (15 of 17) | - | 88% (15 of 17) |
|   chariot | 100% (9 of 9) | 76% (13 of 17) | 85% (22 of 26) |
|   infantry | 50% (4 of 8) | 82% (9 of 11) | 68% (13 of 19) |
|   war machine | 78% (43 of 55) | 100% (3 of 3) | 79% (46 of 58) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.7 (28%) | 0.0 (0%) | 1.7 (21%) |
| CHARGED: it charged | 0.3 (6%) | 0.0 (0%) | 0.3 (4%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.3 (17%) | 0.3 (4%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (17%) | 0.3 (4%) |
| MOVED: a war machine that moved | 1.7 (28%) | 0.0 (0%) | 1.7 (21%) |
| NO TARGET IN RANGE | 0.7 (11%) | 1.3 (67%) | 2.0 (25%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (17%) | 0.0 (0%) | 1.0 (12%) |
| OTHER BAR | 0.7 (11%) | 0.0 (0%) | 0.7 (8%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 10.0 | 3.0 | 77% | 7.4 pts | 74 pts |
| chariot | 7.7 | 1.3 | 91% | 9.4 pts | 72 pts |
| infantry | 4.3 | 2.0 | 62% | 15.4 pts | 67 pts |
| war machine | 15.7 | 14.3 | 60% | 31.3 pts | 490 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.3 | 2.7 | 2.5 |
| Charges that made contact a game | 2.0 | 1.3 | 1.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 2.00 declared, 1.00 contact (1 units) | 0.20 declared, 0.20 contact (5 units) | 0.50 declared, 0.33 contact (6 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.50 declared, 0.00 contact (2 units) | 0.50 declared, 0.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.23 declared, 0.23 contact (22 units) | 0.27 declared, 0.14 contact (22 units) | 0.25 declared, 0.18 contact (44 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 56% (5 of 9) | 33% (1 of 3) | 100% (1 of 1) | 54% (7 of 13) |
| Character in a unit | 100% (8 of 8) | - | - | 100% (8 of 8) |
| Character on its own | 100% (3 of 3) | 50% (1 of 2) | 75% (3 of 4) | 78% (7 of 9) |
| Chariot | 33% (1 of 3) | 100% (2 of 2) | - | 60% (3 of 5) |
| Infantry | 67% (2 of 3) | 100% (1 of 1) | 50% (1 of 2) | 67% (4 of 6) |
| Monster | - | 100% (1 of 1) | - | 100% (1 of 1) |
| War Machines | 77% (10 of 13) | - | - | 77% (10 of 13) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 3 | 100% (1 of 1); on the table 100% | 33% (2 of 6) | 74% | 73% (22 of 30) | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 33% (1 of 3); 0.3 uses a game |
| Grand Cathay | 1 | - | 21% (5 of 24) | 90% | 50% (5 of 10) | 100% (2 of 2); 9.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 67% (2 of 3); on the table 67% | 17% (1 of 6) | 54% | 78% (7 of 9) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 1 | 100% (6 of 6); on the table 100% | 33% (2 of 6) | 88% | 100% (6 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p41, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 33% (1) | 40% (2) | 38% (3) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.67 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.33 | 0.33 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: ccut-c940641-p41

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.0 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 29% (2 of 7) | 43% (3 of 7) |
| Strategy | Shoot objectives carried out (shot that target) | 33% (16 of 49) | 46% (6 of 13) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (2 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 60% (3 of 5) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 6) | 25% (1 of 4) |
| Strategy | Lone characters that fought | 25% (2 of 8) | 33% (3 of 9) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 1.7 | 3.7 |
| Movement | Points that never moved of their own | 352.3 | 248.3 |
| Movement | Fights charged into per game | 2.0 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 6, net +140 | 1 of 3, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 6, net +0 | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 6 | 0 of 3 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 6, net +0 | 1 of 3, net +77 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.3 | 7.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 32% (10 of 31) | 50% (11 of 22) |
| Shooting | Points destroyed by shooting units | 103.3 | 0.0 |
| Shooting | War machine shots | 14.3 | 1.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (19 of 43) | 0% (0 of 4) |
| Shooting | Points destroyed by war machines | 226.7 | 43.3 |
| Magic | Magic missiles cast | 0.7 | 2.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 100% (2 of 2) | 57% (4 of 7) |
| Magic | Wounds caused by magic missiles | - | 5.0 |
| Magic | Wounds caused by other spells | 0.3 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.3 / 1.7 / 0.0 / 0.0 | 4.0 / 0.0 / 0.0 / 0.7 |
| Combat | Points destroyed in combat | 116.7 | 41.7 |
| Combat | Points run down | 0.0 | 25.7 |
| Combat | Net points per charged fight, damage counted | +123 | +101 |
| Combat | Net per 100 charger points, damage counted | +57.3 | +56.8 |
| Combat | First round won (charged fights) | 67% | 100% |
| Combat | Net points per charged fight | +92 | +67 |
| Combat | Net points per supported fight / lone fight | - / +92 | +0 / +101 |
| Combat | Charged fights on a top-3 enemy unit | 4 of 6 | 1 of 3 |
| Game | Points lost | 327.0 | 536.7 |
| Game | VP from objectives | 560.0 | 683.3 |
| Game | Lone holders (player turns) | 2.0 | 4.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +109 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 864
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ccut-c940641-p41

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.3 | +18.7 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | 0.3 | +3.2 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 8.0 | +36.4 | 0.0 | 0.0 | 22.3 | +487.9 | 0.0 | 248.3 |
| ARTILLERY RE-ROLL WEIGHED | 6.0 | +0.0 | 0.0 | 41.7 | 0.3 | +0.0 | 0.0 | 55.0 |
| CANNON PLAN MISSED | 1.0 | +0.0 | 360.0 | 0.0 | 0.3 | +0.0 | 43.3 | 55.0 |
| CANNON PLANNED TARGET | 13.0 | +494.3 | 1250.0 | 41.7 | 1.0 | +107.3 | 86.7 | 165.0 |
| CANNON SIGHT KEPT | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 55.0 |
| CARRIES OUT SET-UP | - | - | - | - | 0.3 | -6.9 | 0.0 | 0.0 |
| CAST JOB | 1.3 | +50.0 | 236.7 | 0.0 | 2.3 | +21.4 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 3.0 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.0 | +21.9 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | - | - | - | - | 3.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 12.3 | -456.5 | 0.0 | 160.3 | 19.0 | -1633.3 | 0.0 | 680.0 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 2.7 | +0.0 | 306.7 | 93.7 | 1.7 | +0.0 | 41.7 | 68.3 |
| CLOSES ON WHAT IT BEATS | 4.7 | +0.0 | 0.0 | 67.3 | 14.3 | +0.0 | 0.0 | 116.7 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | - | - | - | - | 5.3 | +396.9 | 0.0 | 0.0 |
| COVER ONCE | 6.7 | -442.7 | 0.0 | 0.0 | 7.0 | -477.3 | 0.0 | 68.3 |
| DENIED BY THE FIGHT | 0.3 | -0.5 | 0.0 | 0.0 | 0.7 | -6.1 | 41.7 | 68.3 |
| DEPLOY BY FIGURES | 7.0 | -106.9 | 0.0 | 0.0 | 7.3 | -20.3 | 0.0 | 55.0 |
| EDGE GIVE GROUND | 0.3 | +38.9 | 68.3 | 0.0 | - | - | - | - |
| EXACT ROUND | 1.7 | +23.7 | 138.3 | 93.7 | 2.0 | -14.1 | 41.7 | 68.3 |
| FALL BACK GOOD ORDER | 1.7 | +19.7 | 70.0 | 93.7 | 2.7 | +0.9 | 67.3 | 68.3 |
| FALLS SHORT | - | - | - | - | 27.7 | +299.7 | 0.0 | 450.0 |
| FEATURE BUFFS | - | - | - | - | 2.3 | +29.5 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | -0.8 | 68.3 | 93.7 | 1.3 | +101.1 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 93.0 | +5325.8 | 3013.3 | 363.0 | 96.7 | +4373.8 | 266.3 | 1628.3 |
| FLANK NOT WEIGHED | 2.0 | +0.0 | 0.0 | 25.7 | 3.3 | +0.0 | 0.0 | 68.3 |
| FOLLOW UP WEIGHED | - | - | - | - | 1.0 | +157.9 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.3 | +52.0 | 138.3 | 93.7 | 2.7 | +221.5 | 67.3 | 68.3 |
| FREED FROM HIS FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 70.0 |
| FRIEND SHOOTS FIRST | 1.0 | -19.2 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 7.3 | +559.7 | 0.0 | 25.7 | 16.3 | +1152.9 | 0.0 | 0.0 |
| GROUND FLIERS | 0.3 | +8.5 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 3.7 | +2.3 | 0.0 | 0.0 | 2.0 | +8.4 | 0.0 | 21.7 |
| GUN MASK | 2.0 | +79.1 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HE REFORMS ONCE FREED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 6.7 | +0.0 | 0.0 | 160.3 | 7.3 | +0.0 | 0.0 | 140.0 |
| HIS CHARGE LIST | 6.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 1.3 | +0.0 | 0.0 | 134.7 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 5.0 | -70.7 | 0.0 | 67.3 | 2.7 | -32.0 | 0.0 | 180.0 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 30.3 | +11.7 | 212.3 | 0.0 |
| HIS MOVE WHY | 12.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 29.0 | +67.5 | 0.0 | 0.0 |
| HIS ONE QUARTER | 5.3 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 3.0 | +0.0 | 0.0 | 134.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 8.0 | +0.0 | 0.0 | 51.3 | - | - | - | - |
| HIS RANDOM MOVER COMES | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 27.7 | +654.9 | 0.0 | 51.3 | 68.0 | +4902.1 | 0.0 | 778.3 |
| HIS SHOTS BY HIS RUN | 25.0 | +537.8 | 0.0 | 186.0 | 58.0 | +1879.7 | 0.0 | 915.0 |
| HIS TURN DENIED | 0.3 | +3.7 | 0.0 | 0.0 | 2.0 | +106.6 | 41.7 | 68.3 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 11.7 | +0.0 | 0.0 | 186.0 | 22.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 8.0 | +867.7 | 0.0 | 93.0 | 14.0 | +974.7 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.0 | -44.8 | 70.0 | 93.7 | 2.7 | -65.6 | 67.3 | 68.3 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +26.1 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 15.7 | -227.2 | 0.0 | 385.0 |
| JOINT CHARGE NOW | - | - | - | - | 1.3 | -14.9 | 0.0 | 0.0 |
| JOINT LOOK BACK | - | - | - | - | 0.3 | +20.3 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 3.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +1.4 | 0.0 | 0.0 | 1.0 | +51.5 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 3.0 | +0.0 | 0.0 | 0.0 | 9.0 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 0.7 | +46.6 | 0.0 | 0.0 | 0.3 | +58.3 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 2.0 | -15.6 | 138.3 | 93.7 | 1.7 | +2.1 | 67.3 | 68.3 |
| MANOEUVRE | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +3.7 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +29.6 | 0.0 | 0.0 | 0.3 | +5.6 | 0.0 | 68.3 |
| MARCH CHECK | - | - | - | - | 0.7 | +10.8 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +5.9 | 0.0 | 0.0 | 1.3 | +26.2 | 0.0 | 68.3 |
| MARCH OVER CASTS | 0.7 | -98.4 | 0.0 | 0.0 | 0.7 | +141.7 | 0.0 | 68.3 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.3 | +38.9 | 0.0 | 0.0 | 2.7 | +60.9 | 0.0 | 180.0 |
| MEETS IN TIME | 4.0 | +342.3 | 0.0 | 0.0 | 4.3 | +157.8 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 0.7 | +17.9 | 0.0 | 0.0 | 7.0 | +89.4 | 0.0 | 180.0 |
| MISSILES NEXT TURN | 1.3 | +41.8 | 0.0 | 0.0 | 10.3 | +102.2 | 0.0 | 428.3 |
| MOVE ORDER | - | - | - | - | 4.0 | +0.0 | 21.7 | 0.0 |
| MOVE SPELL SPOT | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 4.0 | +301.0 | 0.0 | 0.0 | 4.0 | +655.3 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 8.0 | +320.2 | 0.0 | 122.0 | 8.7 | +412.4 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 3.3 | +232.3 | 236.7 | 0.0 | 2.3 | +365.1 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -3.9 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.0 | -98.5 | 68.3 | 93.7 | 2.0 | -86.2 | 67.3 | 68.3 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO RALLY LEFT | 0.3 | +19.0 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT WORTH A CAST | 1.3 | -1.2 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 7.3 | -544.4 | 0.0 | 0.0 | 4.0 | -216.7 | 0.0 | 55.0 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 0.3 | +36.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.7 | -82.2 | 0.0 | 67.3 | 3.7 | -84.1 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 1.0 | +15.3 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 2.7 | -13.9 | 0.0 | 93.0 | 8.3 | -115.9 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | -47.5 | 0.0 | 0.0 |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +14.8 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.7 | +16.0 | 70.0 | 0.0 | - | - | - | - |
| PATHS CROSS | 0.3 | +23.9 | 0.0 | 0.0 | 1.7 | +15.6 | 0.0 | 0.0 |
| PERIAPT WORTH | - | - | - | - | 0.3 | +41.3 | 0.0 | 180.0 |
| PLAN RESULT | 40.7 | +1428.8 | 1086.7 | 308.7 | 49.0 | +196.3 | 0.0 | 881.7 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 9.7 | -416.1 | 0.0 | 0.0 | 4.0 | -67.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 1.0 | -19.2 | 0.0 | 0.0 | 0.7 | -31.9 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.3 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 19.3 | +1577.1 | 93.3 | 0.0 | 21.0 | +1551.3 | 0.0 | 91.7 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.0 | +50.2 | 0.0 | 236.7 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.3 | -2.4 | 0.0 | 0.0 | 0.3 | +15.0 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 0.7 | +20.3 | 0.0 | 0.0 |
| RISK BY ARC | 1.7 | -4.3 | 138.3 | 93.7 | 2.3 | +29.5 | 67.3 | 68.3 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.0 | -27.0 | 0.0 | 0.0 |
| RUN DOWN | 2.0 | -14.8 | 68.3 | 93.7 | 1.7 | -20.3 | 67.3 | 68.3 |
| SAFER THAN THE JOB | - | - | - | - | 0.3 | +16.1 | 0.0 | 0.0 |
| SAME CHARGE LATER | 0.7 | -35.5 | 118.3 | 0.0 | - | - | - | - |
| SCOUT SPOT | 0.7 | +4.7 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 4.0 | -268.7 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +1.9 | 0.0 | 54.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| SET CREDITED ONCE | 1.3 | -14.7 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 1.3 | +9.3 | 0.0 | 0.0 | 0.3 | +24.5 | 0.0 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +34.4 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 1.0 | +111.4 | 68.3 | 0.0 |
| SHOOTERS ON THE TABLE | 16.7 | +0.0 | 0.0 | 41.7 | 5.0 | +0.0 | 0.0 | 366.7 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +2.1 | 0.0 | 0.0 | 1.7 | +29.0 | 25.7 | 180.0 |
| SHORT GUN FORWARD | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -0.3 | 0.0 | 0.0 |
| SHOT REPLANNED | - | - | - | - | 0.3 | +0.0 | 43.3 | 55.0 |
| SHOT RISK POINTS | 16.3 | -150.2 | 0.0 | 160.3 | 41.7 | -99.3 | 0.0 | 958.3 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 22.0 | +1228.0 | 0.0 | 109.0 | 7.3 | +262.7 | 0.0 | 208.3 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +34.4 | 0.0 | 0.0 |
| SPELL WORTH | 0.7 | +1.8 | 0.0 | 0.0 | 5.3 | +89.8 | 360.0 | 360.0 |
| SPELLS IN THE FIGHT | 1.0 | -4.0 | 70.0 | 93.7 | - | - | - | - |
| SPOT AS THE GAME MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 11.0 | +0.0 | 0.0 | 70.0 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -1.2 | 25.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 1.3 | +0.0 | 25.7 | 180.0 |
| STANDS STILL | 67.3 | +0.0 | 2875.0 | 83.3 | 24.7 | +0.0 | 199.0 | 671.7 |
| STAY WORTH | 39.0 | +523.0 | 2875.0 | 147.7 | 9.0 | +106.8 | 173.3 | 581.7 |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 96.7 |
| STUPIDITY NEXT TURN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.3 | +53.3 | 0.0 | 0.0 | 5.0 | +139.6 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 2.3 | +53.3 | 0.0 | 0.0 | 5.0 | +139.6 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 1.0 | +0.9 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +1.5 | 0.0 | 54.7 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -28.2 | 0.0 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 0.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 25.0 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 0.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 40.7 | +0.0 | 0.0 | 134.7 | 47.3 | +0.0 | 0.0 | 661.7 |
| TIED UP BY THE SUM | 0.3 | +22.3 | 0.0 | 0.0 | 0.3 | +22.2 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 47.3 | +495.5 | 0.0 | 147.7 | - | - | - | - |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.3 | +2.8 | 0.0 | 0.0 | 1.0 | +44.0 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.3 | -174.9 | 0.0 | 25.7 | 2.3 | -219.9 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.7 | +10.0 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 2.0 | +28.3 | 0.0 | 134.7 | 3.7 | +96.1 | 0.0 | 0.0 |

### Rule changes: ccut-c940641-p41

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 287 | 273 | 67 | 22.33 | +1999 | +29.8 |
| ARMY TABLE | 91 | 91 | 64 | 21.33 | +1754 | +27.4 |
| HOLDER ASSIGNMENT | 66 | 66 | 61 | 20.33 | +3898 | +63.9 |
| HIS MOVE AS HE DECIDES | 91 | 91 | 56 | 18.67 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 249 | 237 | 54 | 18.00 | +987 | +18.3 |
| LEGAL CHARGES ONLY | 36 | 36 | 36 | 12.00 | +0 | +0.0 |
| SHOT RISK POINTS | 174 | 160 | 36 | 12.00 | +1030 | +28.6 |
| OFF BEST | 34 | 34 | 34 | 11.33 | -2283 | -67.2 |
| DEPLOY BY FIGURES | 43 | 43 | 25 | 8.33 | +379 | +15.2 |
| TIME ON OUR SIDE | 142 | 121 | 23 | 7.67 | +53 | +2.3 |
| FIVE ACTION | 569 | 548 | 22 | 7.33 | +1180 | +53.7 |
| HIS ONE MOVE | 87 | 86 | 22 | 7.33 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 22 | 7.33 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 19 | 19 | 19 | 6.33 | +0 | +0.0 |
| QUARTER ODDS | 121 | 110 | 18 | 6.00 | +818 | +45.5 |
| PROMISE BY ITS OWN SUM | 41 | 41 | 14 | 4.67 | -1450 | -103.5 |
| GOAL WALK | 71 | 71 | 13 | 4.33 | +865 | +66.5 |
| MEETS IN TIME | 25 | 25 | 12 | 4.00 | +880 | +73.3 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 24 | 20 | 12 | 4.00 | +493 | +41.1 |
| NEXT CHARGE BY LIST | 17 | 16 | 10 | 3.33 | +414 | +41.4 |
| THE RISK READS HIS RUN | 18 | 18 | 10 | 3.33 | +0 | +0.0 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| CHARGE NOW FIRST | 13 | 13 | 9 | 3.00 | -205 | -22.8 |
| IDLE COST | 47 | 41 | 9 | 3.00 | +42 | +4.7 |
| CAST JOB | 11 | 11 | 8 | 2.67 | +30 | +3.7 |
| HIS MOVE WHY | 36 | 36 | 8 | 2.67 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 8 | 2.67 | +151 | +18.8 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| HARD STAY DROPPED | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| PATHS CROSS | 6 | 6 | 6 | 2.00 | +119 | +19.8 |
| REDIRECT FOR A FRIEND IN REACH | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| FALLS SHORT | 83 | 71 | 5 | 1.67 | +14 | +2.8 |
| FOUR ROUNDS | 15 | 14 | 5 | 1.67 | +159 | +31.7 |
| MARCH OF THE TABLE | 5 | 5 | 5 | 1.67 | -96 | -19.2 |
| CHARGE LOSSES | 94 | 84 | 4 | 1.33 | +306 | +76.6 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | -45 | -11.2 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +159 | +39.7 |
| SHOOTS FROM THE BEST SPOT | 7 | 7 | 4 | 1.33 | +9 | +2.3 |
| COVER ONCE | 41 | 30 | 3 | 1.00 | +22 | +7.2 |
| FIGHT TO THE END | 6 | 6 | 3 | 1.00 | +127 | +42.2 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +474 | +157.9 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +315 | +104.9 |
| MAX FOR POSITIONING | 12 | 11 | 3 | 1.00 | +2 | +0.6 |
| MISSILES IN THE MOVE | 23 | 14 | 3 | 1.00 | +17 | +5.7 |
| RISK BY ARC | 12 | 12 | 3 | 1.00 | +90 | +30.0 |
| STAY WORTH | 144 | 126 | 3 | 1.00 | +13 | +4.3 |
| SUPPORT ADDS | 22 | 18 | 3 | 1.00 | +3 | +0.9 |
| SUPPORT WORKED OUT | 22 | 18 | 3 | 1.00 | +3 | +0.9 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 3 | 3 | 2 | 0.67 | +0 | +0.0 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +105 | +52.7 |
| MARCH CHECK | 2 | 2 | 2 | 0.67 | +14 | +7.0 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +61 | +30.5 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHORT GUN FORWARD | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHO FIGHTS | 4 | 4 | 2 | 0.67 | +80 | +40.2 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +56 | +55.9 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +10 | +9.5 |
| CANNON PLANNED TARGET | 42 | 42 | 1 | 0.33 | +26 | +26.4 |
| CARRIES OUT SET-UP | 1 | 1 | 1 | 0.33 | -21 | -20.6 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -48 | -47.9 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +50 | +49.7 |
| EXACT ROUND | 11 | 10 | 1 | 0.33 | +25 | +25.0 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS TURN DENIED | 7 | 7 | 1 | 0.33 | +26 | +25.6 |
| HUNT IN PAIRS | 2 | 2 | 1 | 0.33 | +25 | +25.0 |
| JOINT LOOK BACK | 1 | 1 | 1 | 0.33 | +61 | +60.8 |
| MANOEUVRE | 10 | 10 | 1 | 0.33 | +11 | +11.2 |
| MISSILES NEXT TURN | 35 | 22 | 1 | 0.33 | +0 | +0.0 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.33 | +28 | +28.3 |
| OGRE LOADER SECOND SHOT | 1 | 1 | 1 | 0.33 | +108 | +108.0 |
| ONE OBJECTIVE FORMULA | 33 | 24 | 1 | 0.33 | +0 | +0.0 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -142 | -142.5 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +124 | +123.8 |
| PROMISE READS THE TABLE | 5 | 5 | 1 | 0.33 | +122 | +121.6 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -1 | -1.1 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.33 | +48 | +48.3 |
| SEARCH SPOT | 2 | 2 | 1 | 0.33 | +6 | +5.6 |
| SHOT REPLANNED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 22 | 22 | 1 | 0.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 88 | 56 | 1 | 0.33 | +40 | +39.9 |
| SPELLS IN THE FIGHT | 3 | 3 | 1 | 0.33 | +5 | +5.4 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +5 | +4.6 |
| THE ROW IN ITS ORDER | 19 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 14 | 14 | 1 | 0.33 | +1 | +1.3 |
| WOUNDS ON THE RANKS | 17 | 17 | 1 | 0.33 | +61 | +60.9 |
| CANNON PLAN MISSED | 4 | 4 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 9 | trace | - | - | - | - |
| CHARACTER GUNS | 10 | 10 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 57 | 54 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 16 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 13 | 12 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 7 | 7 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 16 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 6 | 5 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 3 | 3 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 17 | not checked | - | - | - | - |
| GUN MASK | 6 | 6 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 1 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 42 | 34 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 20 | 18 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 12 | 10 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 23 | 19 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 36 | 29 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 11 | 8 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 24 | 22 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 3 | 3 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 103 | 103 | 0 | 0.00 | - | - |
| HONEST WORTH | 14 | 13 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 16 | 16 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 11 | 10 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 8 | 8 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 7 | not checked | - | - | - | - |
| NEARER NOT NEEDED | 50 | 47 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 12 | 11 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 25 | 13 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 3 | 3 | 0 | 0.00 | - | - |
| ONE ROUTE | 8 | 8 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | not checked | - | - | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 269 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| REAL GROUND | 8 | 8 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 2 | not checked | - | - | - | - |
| REFORMS TO MEET IT | 2 | not checked | - | - | - | - |
| ROUNDS AFTER TERROR | 3 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 11 | 10 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 12 | 12 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SET UP BY THE SET | 5 | 5 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 65 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 18 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 45 | 43 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 4 | 4 | 0 | 0.00 | - | - |
| STANDS STILL | 276 | 267 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 1 | not checked | - | - | - | - |
| SURE REACH TOGETHER | 3 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 11 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 13 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 4 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 9 | not checked | - | - | - | - |
| THE TABLE BINDS | 264 | not checked | - | - | - | - |
| TIED UP BY THE SUM | 2 | 2 | 0 | 0.00 | - | - |
| WAITS AGAIN | 6 | 5 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p41

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 7.33 | 1.67 | 75.5 |
| PROMISE BY ITS OWN SUM | rule | 4.00 | 0.67 | 103.5 |
| ARMY TABLE | rule | 2.00 | 1.33 | 49.5 |
| CHARGE NOW FIRST | rule | 2.33 | 0.67 | 22.8 |
| RULE SWITCHED OFF | gate | - | 2.00 | 35.2 |
| HOLDER ASSIGNMENT | rule | 0.33 | 1.33 | 14.0 |
| MARCH OF THE TABLE | rule | 0.33 | 1.00 | 24.1 |
| JOINT CHARGE NOW | rule | - | 1.00 | 47.2 |
| AFTERMATH NEEDS NEXT CHARGE | gate | - | 0.33 | 32.5 |
| CARRIES OUT SET-UP | rule | - | 0.33 | 20.6 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 47.9 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 142.5 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 1.1 |

### Plans: ccut-c940641-p41

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.7 | 80% | 216 | 185 | 86% |
| Mine | join | 0.3 | 100% | 4 | 0 | 0% |
| Mine | move | 25.7 | 97% | 1122 | 0 | 0% |
| Mine | shoot | 13.0 | 54% | 908 | 1244 | 137% |
| Opponent | charge | 2.3 | 57% | 328 | 85 | 26% |
| Opponent | join | 3.0 | 100% | 119 | 0 | 0% |
| Opponent | move | 38.3 | 95% | 2108 | 0 | 0% |
| Opponent | shoot | 3.7 | 45% | 255 | 111 | 44% |
| Opponent | support | 1.7 | 100% | 0 | 0 | - |

### Battle groups: ccut-c940641-p41

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 0.3 | 100% | 0% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p41

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |
| Mine | Character | 12 | 14 (12) | 14 | 0 | 26 | 83% | 1.0 | 0 (4) | 0 (4) | 30 (3) | 22 (6) | 0 (5) |
| Mine | Fast Hammer | 5 | 34 (5) | 15 | 19 | 0 | 40% | 3.7 | 29 (3) | 0 (1) | 76 (1) | 34 (3) | 36 (2) |
| Mine | Hammer | 4 | 28 (4) | 0 | 28 | 0 | 50% | 1.0 | 0 (1) | 40 (3) | - | 0 (3) | 97 (1) |
| Mine | Shooter | 5 | 67 (5) | 54 | 13 | 65 | 0% | 1.4 | 125 (1) | 12 (2) | 81 (2) | 67 (5) | - |
| Mine | War machine | 11 | 48 (11) | 48 | 0 | 18 | 9% | 1.4 | 106 (5) | 0 (6) | - | 29 (2) | 53 (9) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 4.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 25 | 100% | - | 0 (3) | 0 (2) | - | 0 (5) | - |
| Opponent | Character | 11 | 5 (11) | 5 | 0 | 36 | 27% | 2.9 | 0 (3) | 0 (4) | 14 (3) | 14 (5) | 0 (5) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 6 | 47 (6) | 0 | 47 | 0 | 33% | 1.8 | 45 (3) | 50 (3) | - | 88 (4) | 0 (2) |
| Opponent | Fragile | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | - | 0 (1) | 0 (1) | - | 0 (2) |
| Opponent | Hammer | 4 | 59 (4) | 59 | 0 | 49 | 0% | 3.0 | 147 (2) | 0 (1) | 0 (1) | 85 (3) | 0 (1) |
| Opponent | Holder | 4 | 145 (4) | 16 | 129 | 0 | 75% | 3.0 | - | 0 (2) | 269 (2) | 189 (3) | 0 (1) |
| Opponent | Shooter | 2 | 0 (2) | 0 | 0 | 50 | 0% | 2.0 | - | - | 0 (2) | 0 (1) | 0 (1) |
| Opponent | War machine | 2 | 39 (2) | 39 | 0 | 100 | 0% | 1.0 | - | 39 (2) | - | 79 (1) | 0 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | - | - | 0 (2) | - |

### Charged fights: ccut-c940641-p41

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 3 | 330 | 185 | 2.0 | 1.0 | 92 | 0 | +92 | 4 of 6 | 4 of 6 | - | +92 |
| Opponent | Grand Cathay | 1 | 130 | 125 | 1.0 | 1.0 | 125 | 0 | +125 | 0 of 1 | 1 of 1 | - | +125 |
| Opponent | Skaven | 1 | 0 | 77 | 1.0 | 1.0 | 77 | 0 | +77 | 0 of 1 | 1 of 1 | - | +77 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 1.0 | 2.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | +0 | - |
| **Opponent** | all armies | 3 | 43 | 67 | 1.0 | 1.3 | 67 | 0 | +67 | 1 of 3 | 3 of 3 | +0 | +101 |

### Effective charges: ccut-c940641-p41

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 6 | 1 (net +140) | 0 | 2 (net +0) | 2 (net +208) | 0 | 1 (net +0) | 0 | 33% (2 of 6) |
| Opponent | Grand Cathay | 1 | 0 | 0 | 0 | 1 (net +125) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +77) | 0 | 0% (0 of 1) |
| Opponent | Vampire Counts | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: ccut-c940641-p41

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 189 | 222 | +140 | 140 | 0 | +140 | +74.1 |
| Mine | Effective (55-75%) | 2 | 185 | 184 | +0 | 53 | 23 | +30 | +16.5 |
| Mine | 76-89% | 2 | 272 | 208 | +208 | 251 | 20 | +230 | +84.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 189 | 92 | +0 | 78 | 0 | +78 | +41.4 |
| Mine | All fights | 6 | 215 | 183 | +92 | 138 | 14 | +123 | +57.3 |
| Opponent | Long shot (under 50%) | 1 | 236 | 265 | +0 | 132 | 32 | +101 | +42.7 |
| Opponent | 76-89% | 1 | 205 | 125 | +125 | 125 | 0 | +125 | +61.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 92 | 77 | +77 | 77 | 0 | +77 | +83.7 |
| Opponent | All fights | 3 | 178 | 156 | +67 | 112 | 11 | +101 | +56.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p41 | move | 13 | 3 (23%) | 1 (8%) | 2 (15%) | 8 (62%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0827 |
| Invocation of Nehek | Opponent | L0827 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Jet | Opponent | L0810 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721 |
| Twice-Blessed Armour | Opponent | L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |

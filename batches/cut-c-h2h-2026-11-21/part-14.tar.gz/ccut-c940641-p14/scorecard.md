# Doctrine scorecard: ccut-c940641-p14

### Scorecard: ccut-c940641-p14

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0222 | 6 | 1 | Mine | no | 0 | 1 | 2 | 6 | 1 | 0 | 0 | 170 |
| L0222 | 6 | 1 | Opponent | no | 7 | 1 | 4 | 1 | 0 | 0 | 0 | 216 |
| L0307 | 1 | 1 | Mine | yes | 5 | - | 0 | 2 | 0 | 0 | 0 | 675 |
| L0307 | 1 | 1 | Opponent | no | 5 | 5 | 0 | 3 | 1 | 0 | 0 | 375 |
| L0323 | 5 | 1 | Mine | no | - | 2 | 2 | 1 | 0 | 0 | 0 | 340 |
| L0323 | 5 | 1 | Opponent | yes | - | 4 | 1 | 2 | 0 | 0 | 0 | 245 |
| **Average** | | | Mine | 33% | 2.5 | 1.5 | 1.3 | 3.0 | 0.3 | 0.0 | 0.0 | 395.0 |
| **Average** | | | Opponent | 33% | 6.0 | 3.3 | 1.7 | 2.0 | 0.3 | 0.0 | 0.0 | 278.7 |

### KPIs: ccut-c940641-p14

Rules off - Mine only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 42% (5 of 12) | 0% (0 of 16) | 18% (5 of 28) |
| Winner chose to follow up after the loser gave ground |  | 80% (4 of 5); on the table 80% | 100% (4 of 4); on the table 100% | 89% (8 of 9); on the table 89% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 100% (3 of 3); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 80% (4 of 5); on the table 80% | 100% (8 of 8); on the table 100% | 92% (12 of 13); on the table 92% |
| Magic missiles tried each own turn | 50%+ | 33% (12 of 36) | 33% (2 of 6) | 33% (14 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 35% (12 of 34) | 50% (2 of 4) | 37% (14 of 38) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 0% (0 of 2) | - | 0% (0 of 2) |
| Points that never fought | lower | 58% (3431 of 5897) | 64% (3824 of 5999) | 61% (7255 of 11896) |
|   infantry points that never fought | lower | 68% (979 of 1437) | 88% (828 of 938) | 76% (1807 of 2375) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 50% (11 of 22) | 60% (12 of 20) | 55% (23 of 42) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 3.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (2 of 4); 0.7 uses a game | 0% (0 of 1); 0.0 uses a game | 40% (2 of 5); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 44% (1952 of 4484) | 58% (2675 of 4648) | 51% (4627 of 9132) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 6.7 (83%) | 0.0 (0%) | 6.7 (71%) |
| MARCHED: its unit marched | 0.7 (8%) | 0.7 (50%) | 1.3 (14%) |
| IN COMBAT: engaged in combat | 0.7 (8%) | 0.0 (0%) | 0.7 (7%) |
| GONE: slain | 0.0 (0%) | 0.7 (50%) | 0.7 (7%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 6.0 | 1.3 | 4.7 | 0.3 | 0.3 |
| not cast | 0.0 | 2.7 | 9.3 | 1.7 | 7.7 |
| NOT CHOSEN: could have been cast at a target | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (13%) |
| NO TARGET: no enemy in range, sight and arc it may target | - | 0.0 (0%) | 6.7 (71%) | 0.3 (20%) | 0.0 (0%) |
| MARCHED: its unit marched | - | 0.0 (0%) | 1.3 (14%) | 0.3 (20%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | - | 0.7 (25%) | 0.7 (7%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | - | 0.0 (0%) | 0.7 (7%) | 0.7 (40%) | 1.3 (17%) |
| OTHER BAR: another bar (miscast, baggage ...) | - | 0.0 (0%) | 0.0 (0%) | 0.3 (20%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | - | 2.0 (75%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 5.3 (70%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.0 a game | 0.7 a game |
| stood (cast and not dispelled) | 50% (2 of 4) | - | 50% (2 of 4) |
| the unit moved after it | 100% (2 of 2) | - | 100% (2 of 2) |
| it charged on its next turn | 0% (0 of 2) | - | 0% (0 of 2) |
| the enemy charged it first | 50% (1 of 2) | - | 50% (1 of 2) |
| it fought by the end of its next turn | 50% (1 of 2) | - | 50% (1 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 2) | - | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | 50% (1 of 2) | - | 50% (1 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 79% (45 of 57) | 60% (59 of 99) | 67% (104 of 156) |
|   cavalry | - | 88% (7 of 8) | 88% (7 of 8) |
|   character | - | 0% (0 of 18) | 0% (0 of 18) |
|   chariot | 68% (15 of 22) | 50% (1 of 2) | 67% (16 of 24) |
|   infantry | - | 68% (40 of 59) | 68% (40 of 59) |
|   war machine | 86% (30 of 35) | 92% (11 of 12) | 87% (41 of 47) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.3 (8%) | 0.7 (5%) | 1.0 (6%) |
| CHARGED: it charged | 0.3 (8%) | 1.7 (12%) | 2.0 (12%) |
| IN COMBAT: it fought this turn or the last | 1.0 (25%) | 0.7 (5%) | 1.7 (10%) |
| MOVED: a war machine that moved | 1.0 (25%) | 0.0 (0%) | 1.0 (6%) |
| NO TARGET IN RANGE | 0.3 (8%) | 3.7 (28%) | 4.0 (23%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 2.7 (20%) | 2.7 (15%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (25%) | 3.0 (22%) | 4.0 (23%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.7 (5%) | 0.7 (4%) |
| OTHER BAR | 0.0 (0%) | 0.3 (2%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.7 | 0.3 | 88% | 0.5 pts | 1 pts |
| chariot | 5.3 | 7.7 | 25% | 39.2 pts | 209 pts |
| infantry | 15.3 | 5.0 | 74% | 7.0 pts | 107 pts |
| war machine | 13.7 | 14.7 | 68% | 37.5 pts | 512 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.3 | 3.7 | 2.5 |
| Charges that made contact a game | 1.3 | 2.3 | 1.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (4 units) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.20 declared, 0.20 contact (20 units) | 0.37 declared, 0.23 contact (30 units) | 0.30 declared, 0.22 contact (50 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (2 of 3) | 0% (0 of 1) | - | 50% (2 of 4) |
| Character in a unit | 60% (3 of 5) | 0% (0 of 2) | - | 43% (3 of 7) |
| Character on its own | 100% (1 of 1) | - | 60% (3 of 5) | 67% (4 of 6) |
| Chariot | - | 50% (2 of 4) | - | 50% (2 of 4) |
| Infantry | 0% (0 of 2) | 33% (1 of 3) | - | 20% (1 of 5) |
| Monster | 80% (4 of 5) | - | - | 80% (4 of 5) |
| War Machines | 78% (7 of 9) | 0% (0 of 2) | - | 64% (7 of 11) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1 | 75% (3 of 4); on the table 75% | 75% (9 of 12) | 25% | 17% (1 of 6) | 100% (2 of 2); 9.0 uses a game | 0.0 uses a game | 50% (1 of 2); 1.0 uses a game |
| Chaos Dwarfs | 2 | 100% (1 of 1); on the table 100% | 12% (3 of 24) | 74% | 62% (10 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Empire of Man | 1 | 100% (1 of 1); on the table 100% | 33% (2 of 6) | 91% | 70% (7 of 10) | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 2 | 100% (7 of 7); on the table 100% | - | 50% | 50% (5 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p14, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 57% (4) | - | 57% (4) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.00 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.00 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: ccut-c940641-p14

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 100% (3 of 3) | 27% (3 of 11) |
| Strategy | Shoot objectives carried out (shot that target) | 56% (27 of 48) | 46% (16 of 35) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 71% (5 of 7) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 20% (1 of 5) | 43% (3 of 7) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 3.0 | 2.0 |
| Movement | Points that never moved of their own | 395.0 | 278.7 |
| Movement | Fights charged into per game | 1.3 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 3 | 3 of 7, net -179 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 3, net +0 | 1 of 7, net +230 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 3, net +66 | 0 of 7 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 3, net -25 | 1 of 7, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 5.0 | 17.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 67% (10 of 15) | 33% (17 of 51) |
| Shooting | Points destroyed by shooting units | 126.7 | 54.0 |
| Shooting | War machine shots | 10.0 | 3.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 17% (5 of 30) | 55% (6 of 11) |
| Shooting | Points destroyed by war machines | 101.7 | 36.7 |
| Magic | Magic missiles cast | 2.0 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 17% (1 of 6) | 50% (1 of 2) |
| Magic | Wounds caused by magic missiles | 7.0 | 1.3 |
| Magic | Points destroyed by magic (all spells) | 48.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 5.0 / 0.0 / 0.0 / 0.3 |
| Combat | Points destroyed in combat | 321.7 | 160.0 |
| Combat | Points run down | 0.0 | 30.3 |
| Combat | Net points per charged fight, damage counted | +27 | +30 |
| Combat | Net per 100 charger points, damage counted | +20.1 | +9.2 |
| Combat | First round won (charged fights) | 75% | 57% |
| Combat | Net points per charged fight | +42 | +1 |
| Combat | Net points per supported fight / lone fight | - / +42 | - / +1 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 4 | 4 of 7 |
| Game | Points lost | 481.0 | 564.7 |
| Game | VP from objectives | 516.7 | 856.7 |
| Game | Lone holders (player turns) | 2.5 | 6.0 |

- Mine won / drew / lost: 0 / 2 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -253 VP
- The side that went first won 1 of 1 games with a winner
- Points traded per game (both sides' losses): 1046
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: ccut-c940641-p14

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +198.1 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 17.7 | +142.7 | 0.0 | 0.0 | 23.0 | +617.5 | 0.0 | 238.7 |
| ARTILLERY RE-ROLL WEIGHED | 4.3 | +0.0 | 0.0 | 200.0 | - | - | - | - |
| BLOWS WHERE AIMED | - | - | - | - | 0.7 | -213.5 | 0.0 | 65.0 |
| CANNON PLAN MISSED | 0.7 | +0.0 | 23.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 9.7 | +19.4 | 223.3 | 510.0 | 3.7 | +157.2 | 83.3 | 0.0 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 41.7 |
| CAST JOB | 3.7 | +73.5 | 170.3 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 1.3 | +68.7 | 24.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.7 | +19.2 | 0.0 | 0.0 | 0.3 | +3.9 | 0.0 | 22.0 |
| CHAFF PASSED | 0.3 | -0.7 | 0.0 | 103.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.7 | +12.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 17.3 | -559.6 | 0.0 | 160.0 | 22.0 | -409.1 | 0.0 | 415.0 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 22.0 | 0.0 | 1.7 | +0.0 | 56.7 | 235.3 |
| CLOSES ON WHAT IT BEATS | 12.0 | +0.0 | 0.0 | 0.0 | 9.3 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 56.7 | 1.0 | +0.0 | 56.7 | 170.3 |
| CONVEYANCE SEARCH | 1.3 | +395.0 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 10.7 | -574.2 | 0.0 | 216.7 | 5.7 | -124.4 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -4.2 | 0.0 | 170.3 |
| DEPLOY BY FIGURES | 9.0 | -61.4 | 0.0 | 0.0 | 7.3 | -45.6 | 0.0 | 41.7 |
| EDGE GIVE GROUND | - | - | - | - | 0.7 | +30.0 | 153.3 | 0.0 |
| ENGINEER BY LORE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 1.0 | +1.7 | 46.0 | 0.0 | 2.7 | -59.4 | 313.3 | 65.0 |
| FALL BACK GOOD ORDER | 1.3 | +0.0 | 68.0 | 30.3 | 2.7 | +4.0 | 160.0 | 235.3 |
| FALLS SHORT | 9.0 | +184.3 | 0.0 | 0.0 | 15.7 | +125.8 | 0.0 | 214.7 |
| FEATURE BUFFS | 7.7 | +137.3 | 0.0 | 0.0 | 3.7 | +84.7 | 0.0 | 88.0 |
| FIGHT TO THE END | - | - | - | - | 1.3 | +126.2 | 103.3 | 170.3 |
| FIVE ACTION | 94.3 | +2765.2 | 1006.3 | 1313.7 | 100.3 | +6959.2 | 1291.3 | 1009.3 |
| FLANK NOT WEIGHED | 10.0 | +0.0 | 0.0 | 103.3 | 3.0 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.7 | +169.9 | 0.0 | 0.0 | 1.3 | +265.5 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.3 | +39.6 | 68.0 | 30.3 | 3.7 | +391.8 | 313.3 | 235.3 |
| FREED FROM HIS FIGHT | 6.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 1.0 | -5.0 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.3 | -1.1 | 24.0 | 0.0 | 1.0 | -21.0 | 103.3 | 0.0 |
| GOAL WALK | 14.0 | +746.6 | 0.0 | 0.0 | 19.0 | +2158.1 | 0.0 | 36.7 |
| GUN FIGURES | 3.3 | +11.5 | 148.7 | 103.3 | - | - | - | - |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 22.0 |
| HE REFORMS ONCE FREED | 2.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 13.0 | +0.0 | 0.0 | 160.0 | 3.3 | +0.0 | 0.0 | 65.0 |
| HIS CHARGE LIST | 10.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS LEGAL MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 130.0 |
| HIS MOVE AND SHOT | 1.0 | -0.7 | 0.0 | 0.0 | 2.3 | -44.7 | 0.0 | 109.0 |
| HIS MOVE AS HE DECIDES | 46.3 | +14.0 | 976.3 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 19.3 | +0.0 | 0.0 | 134.7 |
| HIS ONE MOVE | 18.3 | -51.5 | 0.0 | 0.0 | - | - | - | - |
| HIS ONE QUARTER | 3.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 2.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 130.0 |
| HIS RANDOM MOVE | - | - | - | - | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 54.0 | +1210.1 | 0.0 | 56.7 | 63.3 | +2226.7 | 0.0 | 685.0 |
| HIS SHOTS BY HIS RUN | 46.0 | +677.8 | 0.0 | 160.0 | 47.0 | +755.5 | 0.0 | 728.7 |
| HIS TURN DENIED | 0.7 | +2.5 | 22.0 | 30.3 | 2.0 | +56.0 | 103.3 | 235.3 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 21.0 | +0.0 | 0.0 | 0.0 | 20.7 | +0.0 | 0.0 | 176.0 |
| HOLDER ASSIGNMENT | 8.7 | +894.1 | 0.0 | 0.0 | 12.7 | +1072.5 | 0.0 | 44.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -18.7 | 68.0 | 30.3 | 3.0 | -84.6 | 313.3 | 170.3 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +47.6 | 0.0 | 65.0 |
| IDLE COST | 10.0 | -55.9 | 0.0 | 0.0 | 14.0 | -212.8 | 0.0 | 83.3 |
| JOINT CHARGE NOW | 0.3 | -11.1 | 0.0 | 0.0 | 0.7 | +66.5 | 0.0 | 65.0 |
| KEEP FALLS | 0.7 | +3.3 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | - | - | - | - | 5.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 1.3 | +45.8 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 1.3 | +0.0 | 207.0 | 34.7 | 10.7 | +0.0 | 361.7 | 192.7 |
| LONE WIZARD KEPT IN | 0.7 | +17.5 | 0.0 | 0.0 | 1.0 | +78.3 | 0.0 | 0.0 |
| LONG SHOT | 1.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 0.3 | -0.1 | 0.0 | 0.0 | 1.0 | -0.4 | 153.3 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 1.0 | +2.9 | 0.0 | 0.0 |
| MANOEUVRE | 3.7 | +15.4 | 0.0 | 0.0 | 1.7 | -10.1 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.7 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.3 | +3.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.3 | +14.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | -1.1 | 0.0 | 0.0 | 0.7 | +46.4 | 0.0 | 126.7 |
| MARCH WHEELS ONLY | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.0 | +76.7 | 0.0 | 0.0 | 2.0 | +30.3 | 0.0 | 89.0 |
| MEETS IN TIME | 3.3 | +203.8 | 0.0 | 0.0 | 1.7 | +142.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 5.0 | +114.6 | 0.0 | 0.0 | 0.7 | +8.6 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 7.3 | +92.2 | 0.0 | 0.0 | 1.3 | +31.1 | 0.0 | 126.7 |
| MISSILES ON ONE TARGET | 0.3 | -1.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 5.0 | +142.6 | 0.0 | 0.0 | 3.7 | +196.6 | 0.0 | 65.0 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 7.0 | +352.3 | 0.0 | 0.0 | 10.0 | +423.5 | 0.0 | 44.0 |
| NEXT CHARGE BY LIST | 2.7 | +65.0 | 0.0 | 0.0 | 2.0 | +64.9 | 0.0 | 65.0 |
| NO DOUBLE ROUNDS | 1.0 | -7.7 | 46.0 | 30.3 | 3.7 | -148.3 | 313.3 | 235.3 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 7.0 | -91.8 | 24.0 | 76.7 | 5.3 | -195.5 | 0.0 | 88.3 |
| OGRE LOADER SECOND SHOT | 1.7 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 3.3 | -18.6 | 0.0 | 0.0 | 6.3 | -139.7 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 0.3 | +0.2 | 0.0 | 0.0 | 0.3 | +246.4 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 6.3 | -47.4 | 0.0 | 0.0 | 5.0 | +79.9 | 0.0 | 22.0 |
| ONE ROUTE | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 0.3 | +1.1 | 22.0 | 103.3 | - | - | - | - |
| OVERRUNS AWAY | 0.3 | +3.2 | 22.0 | 30.3 | 0.3 | +10.3 | 0.0 | 0.0 |
| PATHS CROSS | 0.7 | +42.8 | 0.0 | 0.0 | 0.3 | +5.3 | 0.0 | 0.0 |
| PLAN RESULT | 42.0 | +664.4 | 58.7 | 824.7 | 44.7 | +646.3 | 330.0 | 976.3 |
| PROMISE BELOW ZERO | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 5.3 | -64.7 | 0.0 | 0.0 | 9.7 | -272.7 | 0.0 | 65.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 0.7 | -0.3 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 14.7 | +855.3 | 506.7 | 613.3 | 17.0 | +1969.4 | 153.3 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.7 | +0.0 | 0.0 | 56.7 | - | - | - | - |
| REAL GROUND | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.0 | +70.8 | 0.0 | 0.0 | 1.0 | +21.6 | 0.0 | 66.0 |
| REDIRECT FOR A FRIEND IN REACH | 2.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 90.0 |
| REFORMS TO MEET IT | - | - | - | - | 0.3 | -0.4 | 0.0 | 0.0 |
| RISK BY ARC | 1.3 | +15.8 | 68.0 | 30.3 | 2.3 | -27.4 | 76.7 | 235.3 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.3 | -29.5 | 0.0 | 235.3 |
| RUN DOWN | - | - | - | - | 1.7 | -5.4 | 153.3 | 170.3 |
| SCOUT SPOT | - | - | - | - | 2.0 | +1.8 | 0.0 | 48.0 |
| SCOUT WAITS | - | - | - | - | 2.0 | +0.0 | 0.0 | 48.0 |
| SCREEN BY WHAT IT SAVES | 1.7 | -374.1 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 0.7 | +16.4 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +3.9 | 24.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.7 | -6.2 | 0.0 | 0.0 | 1.3 | -48.0 | 0.0 | 45.3 |
| SET UP BY THE SET | 0.7 | +6.1 | 0.0 | 0.0 | 3.7 | +4.5 | 0.0 | 134.3 |
| SET UP TOGETHER | - | - | - | - | 1.7 | +14.0 | 0.0 | 23.3 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 15.0 | +0.0 | 0.0 | 510.0 | 12.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 3.0 | +95.4 | 275.3 | 0.0 | 2.0 | +11.5 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -4.8 | 0.0 | 0.0 | 2.0 | -12.4 | 310.0 | 0.0 |
| SHOT RISK POINTS | 27.3 | -275.6 | 0.0 | 103.3 | 34.3 | -204.7 | 0.0 | 709.0 |
| SHOTS AFTER THE MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.3 | +354.4 | 0.0 | 613.3 | 22.7 | +361.7 | 0.0 | 112.0 |
| SPOT AS THE GAME MOVES | 8.3 | +0.0 | 0.0 | 56.7 | 6.0 | +0.0 | 0.0 | 255.3 |
| STAND AND SHOOT | 0.3 | -0.3 | 24.0 | 0.0 | 0.7 | -3.7 | 103.3 | 0.0 |
| STANDS FOR A REASON | 1.3 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 310.0 | 88.0 |
| STANDS STILL | 47.7 | +0.0 | 938.3 | 1180.0 | 39.3 | +0.0 | 978.0 | 177.0 |
| STANDS TO CAST | 0.3 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| STAY WORTH | 32.3 | -569.8 | 363.7 | 730.0 | 33.3 | +363.8 | 943.3 | 22.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +0.5 | 0.0 | 65.0 |
| STUBBORN BY POINTS | 0.3 | +7.5 | 0.0 | 76.7 | - | - | - | - |
| SUPPORT ADDS | 8.7 | +620.5 | 0.0 | 0.0 | 3.0 | +41.9 | 0.0 | 130.0 |
| SUPPORT WORKED OUT | 8.7 | +620.5 | 0.0 | 0.0 | 3.0 | +41.9 | 0.0 | 130.0 |
| SURE REACH TOGETHER | - | - | - | - | 1.7 | +8.3 | 0.0 | 22.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 22.0 |
| THE PROMISE ADDS | 0.3 | -20.8 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 3.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 191.7 |
| THE ROW KEEPS ITS WAY | 2.3 | +0.0 | 0.0 | 103.3 | 3.7 | +0.0 | 0.0 | 60.0 |
| THE ROW READS HIS LAST RUN | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE STEP BACK IS MADE | 1.7 | +0.0 | 0.0 | 103.3 | 2.3 | +0.0 | 0.0 | 101.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 44.7 | +0.0 | 0.0 | 613.3 | 47.7 | +0.0 | 0.0 | 387.0 |
| TIED UP BY THE SUM | 0.7 | +31.4 | 46.0 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 21.3 | +293.3 | 0.0 | 103.3 | 17.0 | +177.4 | 0.0 | 178.0 |
| TWO OR MORE ARRIVE | - | - | - | - | 0.7 | +0.8 | 0.0 | 23.3 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 65.0 |
| WAR ENGINE JOBS | 2.0 | +0.0 | 253.3 | 0.0 | - | - | - | - |
| WEAPON BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | 0.3 | -0.2 | 24.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 1.7 | -283.3 | 0.0 | 56.7 | - | - | - | - |
| WHOLE FIGHT GAIN | 0.3 | +11.1 | 0.0 | 0.0 | - | - | - | - |
| WOUNDED STAYS OUT | - | - | - | - | 0.3 | +0.0 | 0.0 | 170.3 |
| WOUNDS ON THE RANKS | 4.0 | +125.2 | 0.0 | 0.0 | 3.7 | +162.6 | 0.0 | 0.0 |

### Rule changes: ccut-c940641-p14

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 139 | 139 | 97 | 32.33 | +0 | +0.0 |
| HIS SHOT LIST | 352 | 339 | 94 | 31.33 | +1344 | +14.3 |
| ARMY TABLE | 122 | 122 | 88 | 29.33 | +1997 | +22.7 |
| HOLDER ASSIGNMENT | 64 | 64 | 60 | 20.00 | +3915 | +65.2 |
| HIS SHOTS BY HIS RUN | 279 | 265 | 51 | 17.00 | +415 | +8.1 |
| OFF BEST | 37 | 37 | 37 | 12.33 | -862 | -23.3 |
| HIS MOVE WHY | 58 | 58 | 36 | 12.00 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 36 | 36 | 36 | 12.00 | +0 | +0.0 |
| DEPLOY BY FIGURES | 49 | 49 | 32 | 10.67 | +405 | +12.6 |
| SHOT RISK POINTS | 185 | 174 | 32 | 10.67 | +539 | +16.8 |
| THE TABLE AGAIN | 36 | 36 | 27 | 9.00 | +0 | +0.0 |
| HIS ONE MOVE | 55 | 51 | 23 | 7.67 | +0 | +0.0 |
| GOAL WALK | 99 | 96 | 22 | 7.33 | +1376 | +62.5 |
| FIVE ACTION | 584 | 567 | 21 | 7.00 | +1112 | +53.0 |
| TIME ON OUR SIDE | 115 | 100 | 20 | 6.67 | +50 | +2.5 |
| PROMISE BY ITS OWN SUM | 45 | 45 | 18 | 6.00 | -1012 | -56.2 |
| SUPPORT ADDS | 35 | 33 | 17 | 5.67 | +483 | +28.4 |
| SUPPORT WORKED OUT | 35 | 33 | 17 | 5.67 | +483 | +28.4 |
| REDIRECT FOR A FRIEND IN REACH | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| COVER ONCE | 49 | 39 | 11 | 3.67 | +112 | +10.2 |
| SHOOTS FROM THE BEST SPOT | 15 | 15 | 11 | 3.67 | +106 | +9.7 |
| MOVE TO CHARGE COMPUTED | 26 | 20 | 10 | 3.33 | +241 | +24.1 |
| HARD STAY DROPPED | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| STAY WORTH | 197 | 180 | 9 | 3.00 | +63 | +7.0 |
| FALLS SHORT | 74 | 60 | 8 | 2.67 | +69 | +8.6 |
| FOUR ROUNDS | 15 | 14 | 8 | 2.67 | +566 | +70.7 |
| CANNON PLANNED TARGET | 40 | 40 | 7 | 2.33 | +0 | +0.0 |
| CHARGE LOSSES | 118 | 110 | 7 | 2.33 | +299 | +42.7 |
| THE RISK READS HIS RUN | 18 | 18 | 7 | 2.33 | +0 | +0.0 |
| CANNON SIGHT KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 6 | 6 | 6 | 2.00 | +1306 | +217.7 |
| MEETS IN TIME | 15 | 15 | 6 | 2.00 | +516 | +86.1 |
| SCOUT WAITS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 6 | 6 | 5 | 1.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 5 | 5 | 5 | 1.67 | +288 | +57.5 |
| MANOEUVRE | 16 | 16 | 5 | 1.67 | +72 | +14.4 |
| NEXT CHARGE BY LIST | 14 | 11 | 5 | 1.67 | +137 | +27.4 |
| OGRE LOADER SECOND SHOT | 5 | 5 | 5 | 1.67 | +1 | +0.2 |
| COMBAT PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +137 | +34.3 |
| MAX FOR POSITIONING | 12 | 9 | 4 | 1.33 | +1 | +0.2 |
| MOVE ORDER | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| QUARTER ODDS | 95 | 94 | 4 | 1.33 | +317 | +79.3 |
| THE ROW IN ITS ORDER | 21 | 4 | 4 | 1.33 | +0 | +0.0 |
| CAST JOB | 11 | 11 | 3 | 1.00 | +59 | +19.8 |
| CASTING BLOCK | 4 | 4 | 3 | 1.00 | +39 | +13.1 |
| CHARGE NOW FIRST | 6 | 6 | 3 | 1.00 | -198 | -66.1 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | +166 | +55.4 |
| ONE OBJECTIVE FORMULA | 34 | 29 | 3 | 1.00 | +110 | +36.8 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +144 | +48.1 |
| REDIRECT COUNTER | 9 | 5 | 3 | 1.00 | +83 | +27.7 |
| SHOTS AFTER THE MOVES | 26 | 26 | 3 | 1.00 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 23 | 22 | 3 | 1.00 | +45 | +14.9 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | -2 | -1.1 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +36 | +18.0 |
| EDGE GIVE GROUND | 2 | 2 | 2 | 0.67 | +42 | +21.0 |
| HUNT IN PAIRS | 2 | 2 | 2 | 0.67 | +95 | +47.3 |
| IDLE COST | 72 | 40 | 2 | 0.67 | +36 | +17.8 |
| KEEP FALLS | 2 | 2 | 2 | 0.67 | +30 | +15.2 |
| NEARER NOT NEEDED | 51 | 48 | 2 | 0.67 | +76 | +38.1 |
| RISK BY ARC | 11 | 10 | 2 | 0.67 | +20 | +9.9 |
| SEARCH SPOT | 4 | 4 | 2 | 0.67 | +49 | +24.6 |
| SET UP BY THE SET | 13 | 12 | 2 | 0.67 | +44 | +22.2 |
| SURE REACH TOGETHER | 5 | 5 | 2 | 0.67 | +3 | +1.5 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +594 | +594.3 |
| FEATURE BUFFS | 34 | 32 | 1 | 0.33 | +37 | +36.7 |
| FIGHT TO THE END | 4 | 4 | 1 | 0.33 | +64 | +64.3 |
| HIS TURN DENIED | 8 | 8 | 1 | 0.33 | +5 | +5.0 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +10 | +9.8 |
| MARCH CHECK | 1 | 1 | 1 | 0.33 | +24 | +23.9 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| ONE JOINT FIGURE | 2 | 2 | 1 | 0.33 | +298 | +298.1 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +12 | +11.6 |
| SET UP TOGETHER | 5 | 3 | 1 | 0.33 | +14 | +13.8 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +4 | +4.0 |
| SHOTS IN THE MOVE | 117 | 89 | 1 | 0.33 | +51 | +50.9 |
| STANDS TO CAST | 1 | 1 | 1 | 0.33 | -0 | -0.2 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +2 | +1.5 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +23 | +22.5 |
| TIED UP BY THE SUM | 2 | 1 | 1 | 0.33 | +22 | +21.9 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 1 | 1 | 1 | 0.33 | +12 | +12.4 |
| WOUNDED STAYS OUT | 1 | 1 | 1 | 0.33 | -3 | -2.8 |
| BLOWS WHERE AIMED | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 64 | 63 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 4 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| EXACT ROUND | 11 | 10 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 12 | 11 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 39 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 31 | 30 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 3 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 10 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 16 | 16 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 49 | 45 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 31 | 29 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 17 | 16 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 10 | 10 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 18 | 17 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 22 | 19 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 10 | 10 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 125 | 121 | 0 | 0.00 | - | - |
| HONEST WORTH | 13 | 12 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 15 | 15 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 1 | 1 | 0 | 0.00 | - | - |
| LONG SHOT | 3 | 3 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 4 | 4 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 3 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 3 | 3 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 17 | 8 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 26 | 17 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 1 | not checked | - | - | - | - |
| MOVE SPELL SPOT | 2 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 14 | 13 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 29 | 12 | 0 | 0.00 | - | - |
| ONE ROUTE | 3 | 3 | 0 | 0.00 | - | - |
| OPENS A LANE | 1 | 1 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 260 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| RANDOM MOVE BY FIGURES | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 3 | 3 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 1 | not checked | - | - | - | - |
| ROUNDS AFTER TERROR | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 5 | 5 | 0 | 0.00 | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 5 | 5 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 6 | 5 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 82 | not checked | - | - | - | - |
| SHOT OR CHARGE | 7 | 7 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 43 | 33 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 25 | 24 | 0 | 0.00 | - | - |
| STANDS STILL | 261 | 255 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 18 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 4 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 12 | not checked | - | - | - | - |
| THE TABLE BINDS | 277 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 2 | not checked | - | - | - | - |
| WAITS AGAIN | 12 | 11 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 6 | 6 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | not checked | - | - | - | - |
| WHOLE FIGHT DANGER | 5 | 5 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p14

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.33 | 5.00 | 27.1 |
| PROMISE BY ITS OWN SUM | rule | 2.00 | 4.00 | 56.2 |
| ARMY TABLE | rule | 2.00 | 1.00 | 62.7 |
| CHARGE NOW FIRST | rule | - | 1.00 | 66.1 |
| RULE SWITCHED OFF | gate | 1.00 | - | 5.9 |
| AFTERMATH BAND | gate | 0.67 | - | 0.6 |
| HOLDER ASSIGNMENT | rule | - | 0.67 | 34.5 |
| CHAFF PASSED | rule | 0.33 | - | 2.2 |
| FIGHT ORDER BAND | gate | - | 0.33 | 4.5 |
| FOLLOW UP WEIGHED | rule | 0.33 | - | 0.7 |
| JOINT CHARGE NOW | rule | 0.33 | - | 33.4 |
| WOUNDED STAYS OUT | rule | - | 0.33 | 2.8 |

### Plans: ccut-c940641-p14

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 100% | 33 | 68 | 204% |
| Mine | move | 26.7 | 99% | 1248 | 0 | 0% |
| Mine | shoot | 13.7 | 51% | 220 | 596 | 271% |
| Mine | support | 0.7 | 100% | 0 | 0 | 0% |
| Opponent | charge | 3.0 | 22% | 480 | 157 | 33% |
| Opponent | move | 33.0 | 94% | 2141 | 0 | 0% |
| Opponent | shoot | 8.7 | 50% | 479 | 490 | 102% |

### Battle groups: ccut-c940641-p14

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.0 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 1.0 | 100% | 100% | 0% | - | 67% | 0% | 0% | 33% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p14

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Character | 7 | 63 (7) | 63 | 0 | 0 | 29% | 2.4 | 0 (1) | 0 (1) | 78 (5) | 71 (6) | 0 (1) |
| Mine | Clean-up | 4 | 18 (4) | 18 | 0 | 24 | 50% | 5.0 | 0 (1) | 23 (3) | - | 0 (3) | 73 (1) |
| Mine | Fast Hammer | 5 | 39 (5) | 39 | 0 | 16 | 80% | 1.0 | - | 81 (3) | 0 (2) | 46 (4) | 0 (1) |
| Mine | Hammer | 9 | 35 (9) | 22 | 13 | 20 | 22% | 1.9 | 0 (1) | 41 (4) | 39 (4) | 47 (7) | 0 (2) |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | War machine | 8 | 26 (8) | 26 | 0 | 69 | 0% | 1.0 | 21 (2) | 20 (5) | 48 (1) | 16 (3) | 32 (5) |
| Mine | Wizard | 5 | 20 (5) | 20 | 0 | 0 | 60% | 3.5 | 0 (1) | 0 (2) | 47 (2) | 47 (2) | 0 (3) |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 100 | 20% | 1.2 | 0 (1) | 0 (4) | - | 0 (5) | - |
| Opponent | Character | 8 | 20 (8) | 20 | 0 | 36 | 50% | 2.0 | 34 (3) | 0 (2) | 23 (3) | 24 (6) | 0 (2) |
| Opponent | Clean-up | 4 | 68 (4) | 0 | 68 | 37 | 100% | - | 0 (2) | 0 (1) | 139 (1) | 79 (3) | 0 (1) |
| Opponent | Fast Hammer | 6 | 28 (6) | 28 | 0 | 17 | 50% | 5.0 | 56 (3) | 0 (3) | - | 60 (2) | 12 (4) |
| Opponent | Holder | 9 | 71 (9) | 9 | 62 | 9 | 0% | 2.1 | 0 (2) | 68 (4) | 114 (3) | 156 (4) | 0 (5) |
| Opponent | Shooter | 2 | 124 (2) | 31 | 93 | 0 | 0% | 3.0 | 59 (1) | 194 (1) | - | 59 (1) | 194 (1) |
| Opponent | War machine | 3 | 29 (3) | 29 | 0 | 33 | 33% | 1.0 | 29 (3) | - | - | 0 (2) | 88 (1) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 0% | 1.0 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |

### Charged fights: ccut-c940641-p14

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 144 | 127 | 2.0 | 1.0 | 64 | 0 | +64 | 0 of 2 | 1 of 2 | - | +64 |
| Mine | Chaos Dwarfs | 2 | 342 | 66 | 1.0 | 1.0 | 66 | 46 | +20 | 0 of 2 | 2 of 2 | - | +20 |
| **Mine** | all armies | 3 | 276 | 86 | 1.3 | 1.0 | 65 | 23 | +42 | 0 of 4 | 3 of 4 | - | +42 |
| Opponent | Empire of Man | 1 | 110 | 230 | 1.0 | 1.0 | 230 | 0 | +230 | 0 of 1 | 1 of 1 | - | +230 |
| Opponent | Tomb Kings of Khemri | 2 | 81 | 240 | 3.0 | 1.0 | 80 | 118 | -38 | 4 of 6 | 3 of 6 | - | -38 |
| **Opponent** | all armies | 3 | 91 | 237 | 2.3 | 1.0 | 101 | 101 | +1 | 4 of 7 | 4 of 7 | - | +1 |

### Effective charges: ccut-c940641-p14

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Mine | Chaos Dwarfs | 2 | 0 | 0 | 0 | 0 | 1 (net +66) | 1 (net -25) | 0 | 0% (0 of 2) |
| Opponent | Empire of Man | 1 | 0 | 0 | 1 (net +230) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | Tomb Kings of Khemri | 6 | 3 (net -179) | 0 | 0 | 2 (net +155) | 0 | 1 (net +0) | 0 | 0% (0 of 6) |

### Charged fights, damage counted: ccut-c940641-p14

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 85 | 55 | +0 | 0 | 42 | -42 | -50.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 91 | 66 | -25 | 66 | 91 | -25 | -27.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 310 | 66 | +66 | 66 | 0 | +66 | +21.3 |
| Mine | No odds | 1 | 52 | 72 | +127 | 127 | 17 | +110 | +210.9 |
| Mine | All fights | 4 | 134 | 65 | +42 | 65 | 38 | +27 | +20.1 |
| Opponent | Long shot (under 50%) | 3 | 339 | 272 | -179 | 124 | 241 | -117 | -34.5 |
| Opponent | Effective (55-75%) | 1 | 189 | 230 | +230 | 230 | 0 | +230 | +121.7 |
| Opponent | 76-89% | 2 | 436 | 240 | +155 | 288 | 147 | +141 | +32.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 195 | 95 | +0 | 48 | 0 | +48 | +24.4 |
| Opponent | All fights | 7 | 325 | 232 | +1 | 175 | 145 | +30 | +9.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p14 | move | 13 | 2 (15%) | 1 (8%) | 2 (15%) | 9 (69%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Ring of Doom | Mine | L0222 |
| Twice-Blessed Armour | Opponent | L0307 |
| Witch Hunter's Ward | Opponent | L0307 |

# Doctrine scorecard: ccut-c940641-p44

### Scorecard: ccut-c940641-p44

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1323 | 3 | 1 | Mine | no | 11 | 2 | 2 | 0 | 1 | 0 | 0 | 302 |
| L1323 | 3 | 1 | Opponent | yes | 0 | 2 | 4 | 3 | 1 | 0 | 0 | 66 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 5 | 2 | 1 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 6 | 4 | 0 | 0 | 0 | 0 | 305 |
| L1435 | 1 | 1 | Mine | no | 0 | 5 | 0 | 3 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 0 | 6 | 1 | 3 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 5.5 | 3.0 | 2.3 | 1.7 | 0.7 | 0.0 | 0.0 | 100.7 |
| **Average** | | | Opponent | 50% | 0.0 | 4.7 | 3.0 | 2.0 | 0.3 | 0.0 | 0.0 | 123.7 |

### KPIs: ccut-c940641-p44

Rules off - Opponent only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 14) | 0% (0 of 16) | 0% (0 of 30) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | - | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 100% (3 of 3); on the table 100% | 0% (0 of 1); on the table 100% | 75% (3 of 4); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (5 of 5); on the table 100% | 0% (0 of 1); on the table 100% | 83% (5 of 6); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 22% (4 of 18) | - | 22% (4 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 44% (4 of 9) | - | 44% (4 of 9) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 48% (2896 of 6000) | 56% (3380 of 6000) | 52% (6276 of 12000) |
|   infantry points that never fought | lower | 56% (516 of 923) | 53% (620 of 1159) | 55% (1136 of 2082) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 50% (13 of 26) | 67% (16 of 24) | 58% (29 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 0.7 uses a game | 50% (1 of 2); 0.7 uses a game | 67% (2 of 3); 0.7 uses a game |
| Bound items with another spell used |  | 36% (5 of 14); 2.3 uses a game | 0.0 uses a game | 36% (5 of 14); 1.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 48% (2817 of 5860) | 64% (3268 of 5131) | 55% (6085 of 10991) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (21%) | - | 1.0 (21%) |
| MARCHED: its unit marched | 0.7 (14%) | - | 0.7 (14%) |
| IN COMBAT: engaged in combat | 0.7 (14%) | - | 0.7 (14%) |
| GONE: slain | 2.3 (50%) | - | 2.3 (50%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 3.3 | 2.3 | 1.3 | 1.0 |
| not cast | 3.7 | 6.7 | 5.7 | 4.7 | 27.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.3 (50%) | 0.0 (0%) | 1.0 (21%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (14%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (5%) | 0.7 (12%) | 0.7 (14%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 1.7 (45%) | 1.7 (25%) | 1.7 (29%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.7 (45%) | 1.3 (20%) | 2.7 (47%) | 2.3 (50%) | 8.3 (31%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.3 (9%) | 0.0 (0%) | 0.7 (12%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 17.3 (64%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.3 a game | 0.0 a game | 1.2 a game |
| stood (cast and not dispelled) | 86% (6 of 7) | - | 86% (6 of 7) |
| the unit moved after it | 0% (0 of 6) | - | 0% (0 of 6) |
| it charged on its next turn | 0% (0 of 6) | - | 0% (0 of 6) |
| the enemy charged it first | 17% (1 of 6) | - | 17% (1 of 6) |
| it fought by the end of its next turn | 17% (1 of 6) | - | 17% (1 of 6) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 6) | - | 0% (0 of 6) |
| none of these (no charge, no fight, no charge escaped) | 83% (5 of 6) | - | 83% (5 of 6) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 59% (46 of 78) | 60% (56 of 94) | 59% (102 of 172) |
|   cavalry | 54% (13 of 24) | 56% (9 of 16) | 55% (22 of 40) |
|   character | 14% (3 of 22) | 43% (6 of 14) | 25% (9 of 36) |
|   chariot | - | 67% (8 of 12) | 67% (8 of 12) |
|   infantry | 90% (18 of 20) | 65% (26 of 40) | 73% (44 of 60) |
|   monster | - | 58% (7 of 12) | 58% (7 of 12) |
|   war machine | 100% (12 of 12) | - | 100% (12 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (19%) | 1.3 (11%) | 3.3 (14%) |
| CHARGED: it charged | 1.7 (16%) | 1.3 (11%) | 3.0 (13%) |
| FLEEING: it fled or was fleeing | 0.3 (3%) | 0.0 (0%) | 0.3 (1%) |
| IN COMBAT: it fought this turn or the last | 0.7 (6%) | 0.7 (5%) | 1.3 (6%) |
| NO TARGET IN RANGE | 5.3 (50%) | 3.0 (24%) | 8.3 (36%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 1.0 (8%) | 1.0 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (6%) | 4.0 (32%) | 4.7 (20%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.3 (3%) | 0.3 (1%) |
| OTHER BAR | 0.0 (0%) | 1.0 (8%) | 1.0 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 11.7 | 1.0 | 91% | 1.6 pts | 19 pts |
| character | 4.7 | 1.0 | 79% | 3.3 pts | 16 pts |
| chariot | 2.7 | 1.3 | 75% | 31.2 pts | 83 pts |
| infantry | 20.3 | 7.0 | 75% | 7.8 pts | 158 pts |
| monster | 2.3 | 1.3 | 57% | 35.7 pts | 83 pts |
| war machine | 4.0 | 0.0 | 100% | 0.0 pts | 0 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.3 | 3.7 | 3.5 |
| Charges that made contact a game | 3.0 | 2.7 | 2.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.33 declared, 0.33 contact (3 units) | - | 0.33 declared, 0.33 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.39 declared, 0.35 contact (23 units) | 0.33 declared, 0.24 contact (33 units) | 0.36 declared, 0.29 contact (56 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 59% (10 of 17) | - | - | 59% (10 of 17) |
| Character in a unit | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Character on its own | - | 50% (2 of 4) | 50% (4 of 8) | 50% (6 of 12) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 50% (5 of 10) | 0% (0 of 1) | - | 45% (5 of 11) |
| Monster | 100% (2 of 2) | 0% (0 of 1) | - | 67% (2 of 3) |
| Monstrous | 100% (2 of 2) | 50% (1 of 2) | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 3 | 100% (5 of 5); on the table 100% | 22% (4 of 18) | 48% | 50% (13 of 26) | 100% (1 of 1); 0.7 uses a game | 36% (5 of 14); 2.3 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | - | - | 44% | 71% (5 of 7) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 0% (0 of 1); on the table 100% | - | 43% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | - | 82% | 67% (8 of 12) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p44, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 40% (2) | 60% (3) | 50% (5) |
| ...free all their last turn and able to turn (per game) | 0.33 | 1.00 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.67 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: ccut-c940641-p44

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.0 | 1.7 |
| Strategy | Charge objectives carried out (made contact) | 78% (7 of 9) | 40% (2 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 42% (11 of 26) | 58% (7 of 12) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | 0% (0 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 33% (1 of 3) | 50% (3 of 6) |
| Strategy | Joined characters whose unit fought | - | 0% (0 of 2) |
| Strategy | Lone characters that fought | 71% (5 of 7) | 60% (3 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.7 | 2.0 |
| Movement | Points that never moved of their own | 100.7 | 123.7 |
| Movement | Fights charged into per game | 2.7 | 2.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 7 | 1 of 4, net +500 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 7 | 0 of 4 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 5 of 7, net +71 | 0 of 4 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 7, net +336 | 2 of 4, net +374 |
| Shooting | Shots by shooting units (incl. breath weapons) | 14.3 | 21.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 21% (9 of 43) | 51% (32 of 63) |
| Shooting | Points destroyed by shooting units | 34.7 | 207.7 |
| Shooting | War machine shots | 4.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 75% (9 of 12) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.0 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (1 of 3) | - |
| Magic | Wounds caused by magic missiles | 2.7 | 0.3 |
| Magic | Wounds caused by other spells | 4.3 | - |
| Magic | Points destroyed by magic (all spells) | 113.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.3 / 1.0 / 1.0 / 0.0 | 3.3 / 2.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 197.3 | 563.0 |
| Combat | Points run down | 340.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +130 | +223 |
| Combat | Net per 100 charger points, damage counted | +34.3 | +86.6 |
| Combat | First round won (charged fights) | 88% | 62% |
| Combat | Net points per charged fight | +128 | +202 |
| Combat | Net points per supported fight / lone fight | +66 / +137 | - / +202 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 8 | 5 of 8 |
| Game | Points lost | 805.7 | 716.0 |
| Game | VP from objectives | 486.7 | 846.7 |
| Game | Lone holders (player turns) | 5.5 | 0.0 |

- Mine won / drew / lost: 0 / 1 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -492 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 1522
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ccut-c940641-p44

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 25.3 | +54.4 | 0.0 | 801.7 | 38.7 | +1272.7 | 0.0 | 348.7 |
| ASSAILMENT BY POINTS | 0.3 | +2.0 | 0.0 | 133.3 | - | - | - | - |
| BACKUP TARGETS | 0.7 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | 0.3 | -30.3 | 76.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.7 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.3 | +0.0 | 23.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 4.0 | +13.0 | 23.3 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 0.7 | +12.8 | 44.0 | 108.0 | 0.7 | +15.7 | 0.0 | 231.3 |
| CASTS AFTER FRIENDS | 2.0 | +0.0 | 0.0 | 300.0 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 0.7 | +15.1 | 0.0 | 22.7 |
| CHAFF PASSED | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 1.0 | +50.5 | 0.0 | 0.0 | 0.7 | +48.5 | 0.0 | 41.7 |
| CHARGE LIST READ AGAIN | 0.3 | +9.4 | 22.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 24.7 | -1500.6 | 0.0 | 1774.3 | 15.7 | -480.9 | 0.0 | 65.0 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 151.0 | 0.0 | 1.0 | +0.0 | 249.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 11.3 | +0.0 | 0.0 | 0.0 | 11.7 | +0.0 | 0.0 | 23.3 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 2.3 | +491.7 | 433.3 | 433.3 | - | - | - | - |
| COVER ONCE | 10.0 | -401.5 | 0.0 | 535.0 | 12.0 | -1118.5 | 0.0 | 195.7 |
| DENIED BY THE FIGHT | 0.3 | -2.0 | 0.0 | 0.0 | 0.3 | -0.3 | 166.7 | 0.0 |
| DEPLOY BY FIGURES | 8.0 | -26.8 | 0.0 | 0.0 | 9.3 | +8.3 | 0.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +41.9 | 147.3 | 0.0 |
| EVASIVE BY THE ODDS | 0.3 | +1.6 | 0.0 | 54.0 | 2.7 | +67.5 | 41.0 | 0.0 |
| EXACT ROUND | 1.7 | +8.6 | 148.7 | 0.0 | 1.7 | +23.8 | 610.7 | 78.0 |
| FALL BACK GOOD ORDER | 2.0 | +34.4 | 193.0 | 0.0 | 1.3 | +9.2 | 415.7 | 0.0 |
| FALLS SHORT | 10.7 | +120.6 | 0.0 | 214.3 | 15.3 | +185.7 | 0.0 | 191.3 |
| FEATURE BUFFS | 1.7 | +9.3 | 0.0 | 0.0 | 0.7 | +2.7 | 0.0 | 0.0 |
| FIRE IN ORDER | 1.3 | +0.0 | 78.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 95.7 | +4138.8 | 546.3 | 2496.0 | 102.7 | +8328.5 | 2110.7 | 1803.3 |
| FLANK NOT WEIGHED | 5.7 | +0.0 | 0.0 | 415.7 | 12.7 | +0.0 | 0.0 | 337.3 |
| FOLLOW UP WEIGHED | 0.3 | +23.2 | 0.0 | 0.0 | 0.3 | +29.4 | 0.0 | 0.0 |
| FOUR ROUNDS | 3.0 | +127.7 | 308.3 | 0.0 | 2.3 | +243.4 | 610.7 | 101.3 |
| FREED FROM HIS FIGHT | 2.3 | +0.0 | 0.0 | 0.0 | 9.3 | +0.0 | 0.0 | 122.7 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.3 | -8.3 | 0.0 | 0.0 |
| GIVES UP | 0.7 | -4.9 | 46.0 | 0.0 | - | - | - | - |
| GOAL WALK | 8.3 | +523.0 | 0.0 | 266.7 | 9.0 | +560.3 | 0.0 | 0.0 |
| GUN FIGURES | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +2.5 | 0.0 | 0.0 |
| GUN MASK | 1.0 | +23.7 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 25.7 |
| HE REFORMS ONCE FREED | 1.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 36.7 |
| HIS CHARGE BY HIS RUN | 16.3 | +0.0 | 0.0 | 1651.3 | 10.3 | +0.0 | 0.0 | 65.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.7 | +25.6 | 214.3 | 78.0 |
| HIS CHARGE LIST | 8.3 | +0.0 | 0.0 | 0.0 | 11.3 | +0.0 | 0.0 | 557.3 |
| HIS LEGAL MOVES | 8.7 | +0.0 | 0.0 | 95.3 | 5.0 | +0.0 | 0.0 | 84.0 |
| HIS MOVE AND SHOT | 7.3 | -176.5 | 0.0 | 531.0 | 6.3 | -14.7 | 0.0 | 0.0 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 42.7 | +10.7 | 1227.3 | 0.0 |
| HIS MOVE WHY | 27.7 | +0.0 | 0.0 | 804.0 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 26.0 | +22.1 | 0.0 | 88.3 |
| HIS ONE QUARTER | 10.3 | +0.0 | 0.0 | 115.7 | 7.7 | +0.0 | 0.0 | 84.7 |
| HIS OWN BEST MOVE | 9.7 | +0.0 | 0.0 | 95.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 66.3 | +3628.1 | 0.0 | 1300.7 | 64.7 | +1915.7 | 0.0 | 1083.3 |
| HIS SHOTS BY HIS RUN | 61.3 | +2000.8 | 0.0 | 1960.0 | 40.0 | +426.6 | 0.0 | 672.7 |
| HIS TURN DENIED | 1.3 | +167.2 | 59.3 | 0.0 | 0.7 | +6.4 | 133.3 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 20.3 | +0.0 | 0.0 | 0.0 | 18.0 | +0.0 | 0.0 | 173.3 |
| HOLDER ASSIGNMENT | 11.0 | +1048.6 | 0.0 | 0.0 | 10.3 | +921.6 | 0.0 | 86.7 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.0 | -130.5 | 308.3 | 0.0 | 1.7 | -58.4 | 444.0 | 78.0 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +5.5 | 0.0 | 0.0 |
| IDLE COST | 7.3 | -94.0 | 0.0 | 214.3 | 15.0 | -197.0 | 0.0 | 87.0 |
| JOINT CHARGE NOW | 0.7 | -8.7 | 44.0 | 0.0 | - | - | - | - |
| JOINT ON THE TABLE | 0.3 | +0.7 | 22.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 3.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.7 | +82.5 | 0.0 | 0.0 | 1.0 | +20.0 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 4.7 | +0.0 | 116.7 | 789.7 | 3.3 | +0.0 | 300.0 | 195.3 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.3 | +37.5 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.0 | +2.3 | 142.3 | 0.0 | 1.0 | +3.2 | 214.3 | 78.0 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.7 | -138.5 | 0.0 | 22.7 |
| MAKE SURE TOGETHER | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| MANOEUVRE | 2.0 | +0.0 | 0.0 | 0.0 | 4.0 | +59.4 | 0.0 | 13.3 |
| MARCH BY THE SUM | 0.3 | +13.3 | 0.0 | 133.3 | 0.3 | +82.5 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 0.3 | +6.0 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.7 | +15.8 | 0.0 | 300.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | +188.4 | 0.0 | 300.0 | 0.3 | -43.3 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.7 | +6.5 | 0.0 | 0.0 | 2.7 | +114.9 | 0.0 | 36.0 |
| MEETS IN TIME | 3.3 | +208.6 | 0.0 | 0.0 | 6.0 | +79.8 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.7 | +20.0 | 0.0 | 108.0 | 2.7 | +58.1 | 0.0 | 231.3 |
| MISSILES NEXT TURN | 3.7 | +18.4 | 0.0 | 541.3 | 3.3 | +86.5 | 0.0 | 231.3 |
| MOVE ORDER | 2.3 | +0.0 | 0.0 | 166.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 2.0 | +0.0 | 0.0 | 300.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 4.7 | +629.1 | 0.0 | 0.0 | 9.0 | +1290.2 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 7.0 | +257.4 | 0.0 | 0.0 | 9.3 | +382.7 | 0.0 | 178.7 |
| NEXT CHARGE BY LIST | 3.3 | +425.9 | 0.0 | 0.0 | 7.3 | +1129.1 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.7 | -141.7 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 2.3 | -40.7 | 264.3 | 0.0 | 2.3 | -189.1 | 610.7 | 101.3 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 11.3 |
| NOT WORTH A CAST | - | - | - | - | 0.3 | -0.7 | 0.0 | 0.0 |
| OFF BEST | 4.0 | -259.3 | 0.0 | 0.0 | 8.0 | -517.6 | 0.0 | 163.3 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 24.7 |
| ONE FIGHT FORMULA | 6.0 | -131.6 | 0.0 | 214.3 | 4.0 | -102.6 | 0.0 | 42.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | -3.2 | 0.0 | 23.3 |
| ONE OBJECTIVE FORMULA | 7.3 | +30.5 | 0.0 | 0.0 | 4.3 | -135.3 | 0.0 | 73.3 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | -53.7 | 0.0 | 0.0 |
| ONE ROUTE | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 1.0 | +1.8 | 34.0 | 0.0 | - | - | - | - |
| OPENS UP | 0.3 | +3.1 | 22.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 1.3 | +29.0 | 159.7 | 0.0 | 1.0 | +2.4 | 181.0 | 78.0 |
| PATHS CROSS | - | - | - | - | 0.7 | +22.0 | 0.0 | 0.0 |
| PLAN RESULT | 42.3 | +325.1 | 80.0 | 1509.7 | 47.7 | +764.9 | 949.0 | 1182.7 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 9.3 | -187.1 | 0.0 | 0.0 | 9.7 | -365.8 | 0.0 | 84.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.3 | -33.2 | 0.0 | 0.0 |
| PURSUES BIG PREY | - | - | - | - | 0.3 | -1.9 | 0.0 | 0.0 |
| QUARTER ODDS | 17.0 | +1385.9 | 93.3 | 1236.0 | 18.3 | +2179.5 | 429.7 | 108.0 |
| REAL GROUND | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 3.3 | +395.8 | 0.0 | 93.3 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 3.7 | +0.0 | 0.0 | 104.7 |
| REFORMS TO MEET IT | 2.0 | -113.8 | 0.0 | 0.0 | 1.0 | -69.4 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.3 | -94.8 | 217.0 | 0.0 | 1.7 | +18.3 | 296.7 | 101.3 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.3 | -27.5 | 115.7 | 0.0 | 1.0 | -19.5 | 296.7 | 78.0 |
| RUN DOWN | 1.7 | -12.9 | 220.3 | 0.0 | 2.0 | -9.8 | 610.7 | 78.0 |
| SCOUT SPOT | - | - | - | - | 1.3 | -0.1 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.0 | -41.4 | 0.0 | 11.3 |
| SEARCH SPOT | 0.7 | +26.2 | 0.0 | 0.0 | 1.0 | +1.4 | 0.0 | 78.0 |
| SET CREDITED ONCE | - | - | - | - | 3.0 | -118.2 | 0.0 | 43.3 |
| SET UP BY THE SET | 0.3 | -3.4 | 0.0 | 166.7 | 5.7 | +143.7 | 0.0 | 66.7 |
| SET UP TOGETHER | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +2.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 8.3 | +0.0 | 0.0 | 54.0 | 5.3 | +0.0 | 0.0 | 301.0 |
| SHOOTS FROM THE BEST SPOT | 0.3 | +2.1 | 0.0 | 0.0 | 1.7 | +47.4 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -1.5 | 0.0 | 23.3 |
| SHOT RISK POINTS | 43.0 | -572.0 | 0.0 | 1275.0 | 22.7 | -19.9 | 0.0 | 231.3 |
| SHOTS AFTER THE MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 15.7 | +310.5 | 0.0 | 149.0 | 21.7 | +1066.5 | 0.0 | 424.7 |
| SPELL WORTH | 0.7 | +15.4 | 266.7 | 266.7 | 1.7 | +16.3 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | +3.7 | 13.3 | 0.0 | 0.7 | -21.3 | 214.3 | 78.0 |
| SPOT AS THE GAME MOVES | 8.0 | +0.0 | 0.0 | 633.3 | 8.7 | +0.0 | 0.0 | 53.3 |
| STAND AND SHOOT | 1.0 | -6.6 | 44.0 | 0.0 | 0.3 | -2.0 | 0.0 | 0.0 |
| STANDS FOR A REASON | 1.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 38.7 | +0.0 | 238.0 | 510.7 | 31.7 | +0.0 | 1500.0 | 1164.7 |
| STAY WORTH | 25.7 | +50.3 | 144.7 | 244.0 | 15.7 | +131.5 | 500.0 | 180.0 |
| SUPPORT ADDS | 3.0 | +317.7 | 0.0 | 0.0 | 4.3 | +303.5 | 0.0 | 49.3 |
| SUPPORT NARROWED | 0.3 | +0.0 | 22.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 3.0 | +317.7 | 0.0 | 0.0 | 4.3 | +303.5 | 0.0 | 49.3 |
| SURE REACH TOGETHER | - | - | - | - | 1.3 | +5.9 | 0.0 | 44.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2.7 | +0.0 | 0.0 | 133.3 | 2.3 | +0.0 | 0.0 | 20.0 |
| THE PROMISE ADDS | 0.3 | -11.5 | 0.0 | 0.0 | 0.3 | -33.2 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 4.3 | +0.0 | 0.0 | 133.3 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 4.0 | +0.0 | 0.0 | 47.7 | 6.3 | +0.0 | 0.0 | 24.7 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 2.3 | +0.0 | 0.0 | 47.7 | 6.7 | +0.0 | 0.0 | 24.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 45.7 | +0.0 | 0.0 | 1081.3 | 49.7 | +0.0 | 0.0 | 847.3 |
| TIED UP BY THE SUM | 2.0 | +189.0 | 101.3 | 0.0 | 0.7 | +119.0 | 115.7 | 0.0 |
| TIME ON OUR SIDE | 30.3 | +353.4 | 44.0 | 415.7 | 22.3 | +259.3 | 0.0 | 743.7 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WALKS ON ITS ROUTE | 0.3 | -5.8 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | - | - | - | - | 2.3 | +0.0 | 666.7 | 0.0 |
| WHO FIGHTS | 0.3 | -1.0 | 13.3 | 0.0 | - | - | - | - |
| WHO HITS BACK | 1.3 | +186.9 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 3.7 | -432.0 | 0.0 | 594.7 | 2.7 | -279.6 | 0.0 | 23.3 |

### Rule changes: ccut-c940641-p44

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 192 | 192 | 159 | 53.00 | +4186 | +26.3 |
| HIS SHOT LIST | 393 | 372 | 100 | 33.33 | +2074 | +20.7 |
| HIS MOVE AS HE DECIDES | 128 | 128 | 96 | 32.00 | +0 | +0.0 |
| HIS MOVE WHY | 83 | 83 | 63 | 21.00 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 304 | 288 | 61 | 20.33 | +887 | +14.5 |
| HOLDER ASSIGNMENT | 64 | 64 | 60 | 20.00 | +4212 | +70.2 |
| OFF BEST | 36 | 36 | 36 | 12.00 | -2330 | -64.7 |
| SHOT RISK POINTS | 197 | 188 | 35 | 11.67 | +1181 | +33.7 |
| DEPLOY BY FIGURES | 52 | 52 | 32 | 10.67 | +353 | +11.0 |
| THE TABLE AGAIN | 36 | 36 | 29 | 9.67 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 41 | 39 | 27 | 9.00 | +2858 | +105.8 |
| LEGAL CHARGES ONLY | 24 | 24 | 24 | 8.00 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 32 | 30 | 21 | 7.00 | +2755 | +131.2 |
| PROMISE BY ITS OWN SUM | 57 | 57 | 21 | 7.00 | -1659 | -79.0 |
| HIS ONE MOVE | 78 | 76 | 18 | 6.00 | +0 | +0.0 |
| FIVE ACTION | 595 | 569 | 14 | 4.67 | +1153 | +82.4 |
| QUARTER ODDS | 106 | 102 | 14 | 4.67 | +1285 | +91.8 |
| GOAL WALK | 52 | 52 | 13 | 4.33 | +672 | +51.7 |
| MEETS IN TIME | 28 | 28 | 13 | 4.33 | +486 | +37.4 |
| ADVANCE LANE KEPT | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| THE RISK READS HIS RUN | 18 | 18 | 12 | 4.00 | +0 | +0.0 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 158 | 135 | 11 | 3.67 | +50 | +4.5 |
| CHARGE LOSSES | 121 | 115 | 10 | 3.33 | +1576 | +157.6 |
| SUPPORT ADDS | 22 | 22 | 10 | 3.33 | +552 | +55.2 |
| SUPPORT WORKED OUT | 22 | 22 | 10 | 3.33 | +552 | +55.2 |
| FOUR ROUNDS | 16 | 16 | 9 | 3.00 | +423 | +47.0 |
| LANE BY FIGURES | 8 | 8 | 8 | 2.67 | +308 | +38.5 |
| SET UP BY THE SET | 18 | 18 | 8 | 2.67 | +355 | +44.4 |
| HARD STAY DROPPED | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| TIED UP BY THE SUM | 8 | 8 | 7 | 2.33 | +332 | +47.5 |
| COVER ONCE | 66 | 35 | 6 | 2.00 | +85 | +14.1 |
| CHALLENGE BY POINTS | 5 | 5 | 5 | 1.67 | +297 | +59.3 |
| MANOEUVRE | 18 | 18 | 5 | 1.67 | +266 | +53.3 |
| SCOUT WAITS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| FIRE IN ORDER | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 112 | 82 | 4 | 1.33 | +139 | +34.7 |
| THE ROW IN ITS ORDER | 23 | 4 | 4 | 1.33 | +0 | +0.0 |
| WHO HITS BACK | 4 | 4 | 4 | 1.33 | +529 | +132.2 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHARGE NOW FIRST | 7 | 7 | 3 | 1.00 | -186 | -61.9 |
| HIS TURN DENIED | 6 | 6 | 3 | 1.00 | +176 | +58.5 |
| SEARCH SPOT | 5 | 5 | 3 | 1.00 | +96 | +32.0 |
| SHOOTS FROM THE BEST SPOT | 6 | 6 | 3 | 1.00 | +36 | +12.1 |
| BOUND ASSAILMENT | 2 | 2 | 2 | 0.67 | +0 | +0.1 |
| CAST JOB | 4 | 4 | 2 | 0.67 | +22 | +11.2 |
| CHAFF IN THE MOVE | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +158 | +79.0 |
| HIS MOVE AND SHOT | 41 | 38 | 2 | 0.67 | +70 | +35.1 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| IDLE COST | 67 | 53 | 2 | 0.67 | +10 | +5.2 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | -26 | -13.1 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +288 | +143.8 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -47 | -23.7 |
| MAX FOR POSITIONING | 13 | 12 | 2 | 0.67 | +3 | +1.3 |
| NEARER NOT NEEDED | 49 | 47 | 2 | 0.67 | +51 | +25.6 |
| OVERRUNS AWAY | 7 | 7 | 2 | 0.67 | +25 | +12.7 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +66 | +33.0 |
| RISK BY ARC | 12 | 12 | 2 | 0.67 | +43 | +21.4 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +6 | +3.0 |
| SHOTS AFTER THE MOVES | 20 | 20 | 2 | 0.67 | +0 | +0.0 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +6 | +5.9 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -163 | -163.1 |
| CANNON PLANNED TARGET | 12 | 12 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -1 | -0.7 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +28 | +28.2 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EVASIVE BY THE ODDS | 9 | 9 | 1 | 0.33 | +68 | +68.1 |
| EXACT ROUND | 10 | 10 | 1 | 0.33 | +0 | +0.1 |
| FALL BACK GOOD ORDER | 10 | 10 | 1 | 0.33 | +34 | +34.1 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.33 | +2 | +1.9 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +112 | +112.5 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -161 | -161.1 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +7 | +7.1 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.33 | -6 | -5.8 |
| SURE REACH TOGETHER | 4 | 4 | 1 | 0.33 | +2 | +2.1 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +12 | +11.9 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -17 | -17.4 |
| WHOLE FIGHT DANGER | 19 | 19 | 1 | 0.33 | +370 | +370.5 |
| BACKUP TARGETS | 2 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 6 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 69 | 69 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 7 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| FALLS SHORT | 78 | 61 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 7 | 7 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 55 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 35 | 34 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 5 | not checked | - | - | - | - |
| GUN MASK | 3 | 3 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 19 | 18 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 80 | 78 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 59 | 58 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 41 | 38 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 54 | 51 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 32 | 32 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 115 | 115 | 0 | 0.00 | - | - |
| HONEST WORTH | 14 | 14 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | not checked | - | - | - | - |
| KEPT FROM ITS LAST STOP | 15 | 15 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 6 | 6 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 2 | 2 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH CHECK | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 5 | 5 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 13 | 11 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 21 | 18 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 6 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 2 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 14 | 14 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 30 | 16 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 35 | 25 | 0 | 0.00 | - | - |
| ONE ROUTE | 5 | 5 | 0 | 0.00 | - | - |
| OPENS A LANE | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 270 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 5 | 5 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 10 | 8 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 9 | 8 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 11 | 11 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 9 | 9 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 41 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 7 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 50 | 45 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 9 | 5 | 0 | 0.00 | - | - |
| STANDS STILL | 211 | 191 | 0 | 0.00 | - | - |
| STAY WORTH | 124 | 110 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 15 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 31 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 3 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 27 | not checked | - | - | - | - |
| THE TABLE BINDS | 286 | not checked | - | - | - | - |
| WAITS AGAIN | 2 | 2 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 7 | 7 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p44

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.33 | 7.33 | 63.1 |
| ARMY TABLE | rule | 3.67 | 3.67 | 63.7 |
| PROMISE BY ITS OWN SUM | rule | 3.67 | 3.33 | 79.0 |
| CHARGE NOW FIRST | rule | 1.00 | - | 61.9 |
| DEPLOY BY FIGURES | rule | - | 0.67 | 6.2 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.33 | 8.1 |
| MARCH OF THE TABLE | rule | 0.67 | - | 23.7 |
| NO REASON | gate | 0.67 | - | 100.6 |
| RULE SWITCHED OFF | gate | - | 0.67 | 54.9 |
| BEST PRIZE | rule | 0.33 | - | 163.1 |
| CHAFF PASSED | rule | 0.33 | - | 0.7 |
| JOINT CHARGE NOW | rule | 0.33 | - | 28.1 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 161.1 |
| PURSUES BIG PREY | rule | - | 0.33 | 5.8 |
| SET UP BY THE SET | rule | - | 0.33 | 1.2 |
| WALKS ON ITS ROUTE | rule | 0.33 | - | 17.4 |

### Plans: ccut-c940641-p44

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 100% | 335 | 231 | 69% |
| Mine | move | 32.3 | 94% | 1718 | 0 | 0% |
| Mine | shoot | 7.7 | 39% | 230 | 94 | 41% |
| Opponent | charge | 1.3 | 75% | 285 | 262 | 92% |
| Opponent | move | 41.7 | 93% | 2830 | 0 | 0% |
| Opponent | shoot | 3.7 | 73% | 638 | 503 | 79% |
| Opponent | support | 1.0 | 67% | 0 | 0 | - |

### Battle groups: ccut-c940641-p44

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 3.3 | 30% | 100% | 0% | - | 0% | 0% | 0% | 67% | 33% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p44

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 7 | 59 (7) | 59 | 0 | 74 | 14% | 1.2 | 22 (5) | 267 (1) | 0 (1) | 22 (5) | 133 (2) |
| Mine | Clean-up | 1 | 161 (1) | 30 | 130 | 0 | 0% | 5.0 | 161 (1) | - | - | 161 (1) | - |
| Mine | Fast Hammer | 14 | 26 (14) | 8 | 18 | 14 | 43% | 3.5 | 18 (8) | 36 (6) | - | 41 (9) | 0 (5) |
| Mine | Shooter | 4 | 25 (4) | 25 | 0 | 23 | 0% | 1.0 | 26 (3) | 19 (1) | - | 33 (3) | 0 (1) |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | - | - | - | 0 (2) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 7 | 148 (7) | 0 | 148 | 100 | 14% | 2.3 | - | 287 (4) | 16 (3) | 338 (4) | 14 (3) |
| Opponent | Character | 4 | 74 (4) | 74 | 0 | 14 | 0% | 1.2 | - | 74 (4) | - | 0 (2) | 137 (2) |
| Opponent | Clean-up | 4 | 0 (4) | 0 | 0 | 41 | 75% | 5.0 | 0 (1) | 0 (2) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | Fast Hammer | 4 | 4 (4) | 0 | 4 | 19 | 50% | 2.0 | 8 (2) | 0 (2) | - | 6 (3) | 0 (1) |
| Opponent | Hammer | 8 | 75 (8) | 75 | 0 | 46 | 12% | 3.3 | 115 (2) | 20 (3) | 133 (3) | 0 (4) | 126 (4) |
| Opponent | Holder | 3 | 256 (3) | 84 | 172 | 69 | 0% | 1.7 | 550 (1) | - | 123 (2) | 550 (1) | 123 (2) |
| Opponent | Shooter | 4 | 77 (4) | 22 | 55 | 21 | 0% | 1.5 | 0 (1) | 118 (2) | 112 (1) | 189 (2) | 0 (2) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 61 | 0% | 2.7 | 0 (2) | - | - | 0 (1) | 0 (1) |

### Charged fights: ccut-c940641-p44

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 3 | 148 | 342 | 2.7 | 1.1 | 128 | 0 | +128 | 1 of 8 | 7 of 8 | +66 | +137 |
| Opponent | Ogre Kingdoms | 1 | 500 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 1 of 2 | 0 of 2 | - | +0 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 1189 | 5.0 | 1.0 | 238 | 14 | +224 | 3 of 5 | 4 of 5 | - | +224 |
| Opponent | Wood Elf Realms | 1 | 123 | 500 | 1.0 | 1.0 | 500 | 0 | +500 | 1 of 1 | 1 of 1 | - | +500 |
| **Opponent** | all armies | 3 | 208 | 563 | 2.7 | 1.0 | 211 | 9 | +202 | 5 of 8 | 5 of 8 | - | +202 |

### Effective charges: ccut-c940641-p44

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 8 | 0 | 0 | 0 | 0 | 5 (net +71) | 2 (net +336) | 1 | 0% (0 of 7) |
| Opponent | Tomb Kings of Khemri | 5 | 0 | 0 | 0 | 1 (net +442) | 0 | 2 (net +374) | 2 | 0% (0 of 3) |
| Opponent | Wood Elf Realms | 1 | 1 (net +500) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: ccut-c940641-p44

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 489 | 266 | +336 | 336 | 0 | +336 | +68.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 313 | 56 | +71 | 71 | 0 | +71 | +22.7 |
| Mine | No odds | 1 | 500 | 125 | +0 | 18 | 0 | +18 | +3.6 |
| Mine | All fights | 8 | 381 | 117 | +128 | 130 | 0 | +130 | +34.3 |
| Opponent | Long shot (under 50%) | 1 | 125 | 500 | +500 | 500 | 0 | +500 | +400.0 |
| Opponent | 76-89% | 1 | 440 | 342 | +442 | 442 | 0 | +442 | +100.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 436 | 324 | +374 | 456 | 24 | +432 | +99.1 |
| Opponent | No odds | 4 | 156 | 255 | -18 | 15 | 20 | -5 | -3.2 |
| Opponent | All fights | 8 | 258 | 314 | +202 | 239 | 16 | +223 | +86.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p44 | move | 21 | 4 (19%) | 4 (19%) | 2 (10%) | 15 (71%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Fistful of Laurels | Opponent | L1418 |
| Opal Amulet | Mine | L1418, L1435 |
| Standard of the Fell Warrior | Mine | L1323 |

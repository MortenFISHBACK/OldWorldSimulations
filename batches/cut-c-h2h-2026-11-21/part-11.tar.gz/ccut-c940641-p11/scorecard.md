# Doctrine scorecard: ccut-c940641-p11

### Scorecard: ccut-c940641-p11

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2127 | 3 | 1 | Mine | no | 1 | - | 0 | 0 | 0 | 0 | 0 | 555 |
| L2127 | 3 | 1 | Opponent | no | 0 | 2 | 6 | 1 | 1 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 4 | 6 | 1 | 0 | 0 | 0 | 242 |
| L2231 | 5 | 1 | Opponent | no | - | - | 1 | 2 | 3 | 0 | 0 | 170 |
| L2335 | 1 | 1 | Mine | no | 2 | 2 | 2 | 1 | 1 | 0 | 0 | 72 |
| L2335 | 1 | 1 | Opponent | no | 3 | 1 | 6 | 0 | 0 | 0 | 0 | 114 |
| **Average** | | | Mine | 33% | 1.5 | 3.0 | 2.7 | 0.7 | 0.3 | 0.0 | 0.0 | 289.7 |
| **Average** | | | Opponent | 0% | 1.5 | 1.5 | 4.3 | 1.0 | 1.3 | 0.0 | 0.0 | 94.7 |

### KPIs: ccut-c940641-p11

Rules off - Mine only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 31% (4 of 13) | 0% (0 of 14) | 15% (4 of 27) |
| Winner chose to follow up after the loser gave ground |  | 100% (3 of 3); on the table 100% | 100% (2 of 2); on the table 100% | 100% (5 of 5); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | - | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fled |  | 50% (1 of 2); on the table 50% | 40% (2 of 5); on the table 60% | 43% (3 of 7); on the table 57% |
| Winner chose to follow up or pursue (all three) |  | 67% (4 of 6); on the table 67% | 57% (4 of 7); on the table 71% | 62% (8 of 13); on the table 69% |
| Magic missiles tried each own turn | 50%+ | 0% (0 of 6) | 33% (6 of 18) | 25% (6 of 24) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 0% (0 of 3) | 38% (6 of 16) | 32% (6 of 19) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 62% (5 of 8) | 60% (6 of 10) | 61% (11 of 18) |
| Points that never fought | lower | 37% (2206 of 5999) | 26% (1552 of 6000) | 31% (3758 of 11999) |
|   infantry points that never fought | lower | 65% (1006 of 1552) | 46% (480 of 1035) | 57% (1486 of 2587) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 58% (11 of 19) | 70% (21 of 30) | 65% (32 of 49) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.7 uses a game | 50% (1 of 2); 0.7 uses a game | 67% (2 of 3); 1.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 48% (2134 of 4484) | 60% (3330 of 5546) | 54% (5464 of 10030) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (17%) | 1.7 (42%) | 2.0 (33%) |
| MARCHED: its unit marched | 0.7 (33%) | 1.0 (25%) | 1.7 (28%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (8%) | 0.3 (6%) |
| GONE: slain | 1.0 (50%) | 0.3 (8%) | 1.3 (22%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.7 (17%) | 0.7 (11%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 10.7 | 1.7 | 1.3 | 2.0 | 0.3 | 1.0 |
| not cast | 3.3 | 0.3 | 0.7 | 6.0 | 1.7 | 15.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (100%) | 0.0 (0%) | 2.0 (33%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (28%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (10%) | 0.0 (0%) | 0.0 (0%) | 0.3 (6%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| GONE: slain | 1.3 (40%) | 0.0 (0%) | 0.0 (0%) | 1.3 (22%) | 0.3 (20%) | 2.7 (18%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (11%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (80%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (50%) | 0.0 (0%) | 0.7 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.0 (80%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.3 a game | 0.7 a game |
| stood (cast and not dispelled) | - | 25% (1 of 4) | 25% (1 of 4) |
| the unit moved after it | - | 0% (0 of 1) | 0% (0 of 1) |
| it charged on its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| the enemy charged it first | - | 0% (0 of 1) | 0% (0 of 1) |
| it fought by the end of its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 1) | 0% (0 of 1) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (1 of 1) | 100% (1 of 1) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 72% (75 of 104) | 75% (24 of 32) | 73% (99 of 136) |
|   cavalry | 100% (15 of 15) | 93% (13 of 14) | 97% (28 of 29) |
|   character | 0% (0 of 19) | 33% (2 of 6) | 8% (2 of 25) |
|   chariot | 82% (9 of 11) | - | 82% (9 of 11) |
|   infantry | 86% (51 of 59) | 75% (9 of 12) | 85% (60 of 71) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.0 (0%) | 1.0 (38%) | 1.0 (8%) |
| CHARGED: it charged | 3.7 (38%) | 1.0 (38%) | 4.7 (38%) |
| FLEEING: it fled or was fleeing | 0.0 (0%) | 0.3 (12%) | 0.3 (3%) |
| IN COMBAT: it fought this turn or the last | 0.7 (7%) | 0.0 (0%) | 0.7 (5%) |
| NO TARGET IN RANGE | 3.7 (38%) | 0.3 (12%) | 4.0 (32%) |
| ONLY IN COMBAT: the only targets were in combat | 1.0 (10%) | 0.0 (0%) | 1.0 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (7%) | 0.0 (0%) | 0.7 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 15.0 | 1.7 | 89% | 4.0 pts | 60 pts |
| character | 0.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 3.0 | 0.7 | 78% | 3.5 pts | 10 pts |
| infantry | 24.0 | 6.7 | 76% | 8.1 pts | 194 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.7 | 5.3 | 5.0 |
| Charges that made contact a game | 3.0 | 4.3 | 3.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.50 declared, 1.50 contact (2 units) | 1.50 declared, 1.50 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.44 declared, 0.28 contact (32 units) | 0.59 declared, 0.45 contact (22 units) | 0.50 declared, 0.35 contact (54 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 71% (5 of 7) | 100% (1 of 1) | 0% (0 of 1) | 67% (6 of 9) |
| Character in a unit | 100% (2 of 2) | 100% (1 of 1) | - | 100% (3 of 3) |
| Character on its own | 100% (6 of 6) | - | 25% (2 of 8) | 57% (8 of 14) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 64% (7 of 11) | 100% (1 of 1) | - | 67% (8 of 12) |
| Monster | 67% (4 of 6) | 100% (1 of 1) | - | 71% (5 of 7) |
| Monstrous | 50% (1 of 2) | - | - | 50% (1 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Skaven | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 18% | 78% (7 of 9) | 100% (1 of 1); 5.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 2 | 60% (3 of 5); on the table 60% | - | 46% | 40% (4 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 50% (3 of 6); on the table 67% | 17% (1 of 6) | 11% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | - | 0% (0 of 6) | 26% | 92% (11 of 12) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (1 of 1); on the table 100% | 83% (5 of 6) | 40% | 58% (7 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p11, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 78% (7) | 43% (3) | 62% (10) |
| ...free all their last turn and able to turn (per game) | 1.67 | 1.00 | 2.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 1.67 | 1.00 | 2.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.33 | 0.33 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: ccut-c940641-p11

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.0 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 46% (6 of 13) | 38% (6 of 16) |
| Strategy | Shoot objectives carried out (shot that target) | 53% (9 of 17) | 14% (1 of 7) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 60% (3 of 5) |
| Strategy | Joined characters whose unit fought | 25% (1 of 4) | 33% (1 of 3) |
| Strategy | Lone characters that fought | 83% (5 of 6) | 80% (8 of 10) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.7 | 1.0 |
| Movement | Points that never moved of their own | 289.7 | 94.7 |
| Movement | Fights charged into per game | 3.0 | 4.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 8 | 3 of 11, net +18 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 8, net +242 | 1 of 11, net +302 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 4 of 8, net +122 | 2 of 11, net +66 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 8, net +0 | 4 of 11, net +218 |
| Shooting | Shots by shooting units (incl. breath weapons) | 27.3 | 8.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 26% (21 of 82) | 62% (15 of 24) |
| Shooting | Points destroyed by shooting units | 40.0 | 228.3 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | - | 1.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 20% (1 of 5) |
| Magic | Wounds caused by magic missiles | 2.0 | 2.7 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 6.7 / 0.0 / 0.0 / 0.0 | 2.0 / 1.7 / 1.0 / 0.3 |
| Combat | Points destroyed in combat | 583.0 | 525.3 |
| Combat | Points run down | 80.3 | 37.3 |
| Combat | Net points per charged fight, damage counted | +147 | +78 |
| Combat | Net per 100 charger points, damage counted | +43.4 | +31.8 |
| Combat | First round won (charged fights) | 89% | 77% |
| Combat | Net points per charged fight | +182 | +76 |
| Combat | Net points per supported fight / lone fight | - / +182 | - / +76 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 9 | 5 of 13 |
| Game | Points lost | 774.0 | 759.7 |
| Game | VP from objectives | 1023.3 | 630.0 |
| Game | Lone holders (player turns) | 1.5 | 1.5 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +349 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 1534
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: ccut-c940641-p11

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | 0.3 | +11.2 | 0.0 | 0.0 | 0.3 | +18.4 | 0.0 | 0.0 |
| ARMY TABLE | 29.7 | +466.5 | 0.0 | 504.3 | 22.3 | +253.1 | 0.0 | 313.3 |
| ASSAILMENT BY POINTS | - | - | - | - | 0.7 | +0.9 | 0.0 | 126.7 |
| BACKUP TARGETS | - | - | - | - | 0.3 | +1.2 | 0.0 | 0.0 |
| BEST OVERALL | - | - | - | - | 0.3 | +2.0 | 0.0 | 0.0 |
| BEST PRIZE | 0.3 | -4.0 | 0.0 | 180.0 | - | - | - | - |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -173.7 | 0.0 | 0.0 |
| CAST JOB | - | - | - | - | 2.3 | +5.8 | 24.0 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.3 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | - | - | - | - | 1.3 | +44.0 | 0.0 | 125.0 |
| CHAMPION TAKES THE CHALLENGE | - | - | - | - | 0.3 | +15.7 | 37.3 | 0.0 |
| CHARACTER GUNS | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 14.7 | -319.1 | 0.0 | 791.3 | 24.3 | -1114.4 | 0.0 | 682.7 |
| CHARGE NOW FIRST | 3.0 | +0.0 | 288.3 | 180.0 | 2.7 | +0.0 | 267.0 | 62.0 |
| CLOSES ON WHAT IT BEATS | 12.0 | +0.0 | 0.0 | 248.0 | 14.0 | +0.0 | 0.0 | 56.7 |
| COMBAT PIVOT | 1.0 | +0.0 | 62.0 | 65.0 | 0.7 | +0.0 | 37.3 | 56.7 |
| CONVEYANCE SEARCH | - | - | - | - | 1.3 | +315.1 | 0.0 | 0.0 |
| COVER ONCE | 8.0 | -460.6 | 0.0 | 612.7 | 7.3 | -373.8 | 0.0 | 163.3 |
| DENIED BY THE FIGHT | 0.3 | -9.8 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.0 | +21.9 | 0.0 | 48.3 | 7.7 | +21.5 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.7 | -2.2 | 83.3 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 1.7 | +5.2 | 211.0 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | - | - | - | - | 4.3 | +1064.5 | 44.0 | 0.0 |
| EXACT ROUND | 2.0 | +11.2 | 76.7 | 0.0 | 4.3 | -56.7 | 213.7 | 77.0 |
| FALL BACK GOOD ORDER | 4.0 | +3.3 | 375.0 | 180.0 | 4.0 | +5.5 | 474.0 | 15.0 |
| FALLS SHORT | 1.7 | +14.6 | 0.0 | 22.0 | 19.3 | +233.2 | 0.0 | 20.0 |
| FEATURE BUFFS | 1.7 | +7.6 | 0.0 | 22.0 | 2.3 | +80.2 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +23.3 | 70.0 | 0.0 |
| FIRE IN ORDER | - | - | - | - | 0.7 | +0.0 | 180.0 | 0.0 |
| FIVE ACTION | 104.7 | +8448.1 | 851.0 | 2390.3 | 83.7 | +5611.7 | 1420.0 | 1012.3 |
| FLANK NOT WEIGHED | 8.3 | +0.0 | 0.0 | 679.7 | 9.0 | +0.0 | 0.0 | 219.3 |
| FOLLOW UP WEIGHED | 1.3 | +297.7 | 0.0 | 0.0 | 1.0 | +127.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 4.7 | +369.5 | 416.7 | 180.0 | 5.3 | +292.7 | 496.0 | 77.0 |
| FREED FROM HIS FIGHT | 5.3 | +0.0 | 0.0 | 382.0 | 3.7 | +0.0 | 0.0 | 439.3 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -22.5 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.3 | -3.5 | 0.0 | 24.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.7 | +5.4 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.3 | -0.4 | 41.7 | 0.0 | 0.3 | -4.3 | 37.3 | 15.0 |
| GOAL WALK | 14.7 | +1615.0 | 0.0 | 421.3 | 6.0 | +307.1 | 0.0 | 0.0 |
| GUN FIGURES | 2.3 | +1.1 | 0.0 | 43.3 | - | - | - | - |
| HARD STAY DROPPED | 3.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 4.7 | +0.0 | 0.0 | 202.0 | 2.7 | +0.0 | 0.0 | 272.0 |
| HIS CHARGE BY HIS RUN | 10.7 | +0.0 | 0.0 | 791.3 | 18.0 | +0.0 | 0.0 | 642.7 |
| HIS CHARGE DENIED | 0.3 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 7.7 | +0.0 | 0.0 | 860.0 | 1.0 | +0.0 | 0.0 | 40.0 |
| HIS LEGAL MOVES | 6.3 | +0.0 | 0.0 | 248.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 5.7 | -47.6 | 0.0 | 46.7 | 3.7 | -28.1 | 0.0 | 41.7 |
| HIS MOVE AS HE DECIDES | 44.3 | +11.7 | 693.3 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 11.0 | +0.0 | 0.0 | 259.7 |
| HIS ONE MOVE | 21.3 | +31.8 | 0.0 | 364.3 | - | - | - | - |
| HIS ONE QUARTER | 3.3 | +0.0 | 0.0 | 531.3 | 4.3 | +0.0 | 0.0 | 88.0 |
| HIS OWN BEST MOVE | 3.3 | +0.0 | 0.0 | 203.3 | 9.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 17.3 | +0.0 | 0.0 | 72.0 | 9.0 | +0.0 | 0.0 | 40.0 |
| HIS RANDOM MOVER COMES | 3.0 | +0.0 | 0.0 | 72.0 | 1.7 | +0.0 | 0.0 | 40.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 47.7 | +673.2 | 0.0 | 1172.0 | 50.3 | +1066.5 | 0.0 | 838.7 |
| HIS SHOTS BY HIS RUN | 37.3 | +502.3 | 0.0 | 832.7 | 56.3 | +659.7 | 0.0 | 870.7 |
| HIS TURN DENIED | 0.3 | +2.0 | 38.0 | 0.0 | 1.7 | +22.2 | 44.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 21.0 | +0.0 | 0.0 | 259.3 | 19.0 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 12.3 | +995.9 | 0.0 | 118.7 | 10.7 | +931.6 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.7 | -183.3 | 416.7 | 180.0 | 5.0 | -216.1 | 458.7 | 62.0 |
| HUNT IN PAIRS | 0.7 | +0.4 | 0.0 | 65.0 | - | - | - | - |
| IDLE COST | 2.0 | -38.9 | 0.0 | 0.0 | 15.7 | -140.9 | 0.0 | 83.3 |
| JOINT CHARGE NOW | - | - | - | - | 0.3 | -7.8 | 37.3 | 15.0 |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +48.6 | 0.0 | 0.0 | 0.7 | +0.4 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 10.0 | +0.0 | 137.3 | 443.7 | 3.0 | +0.0 | 54.0 | 76.0 |
| LONE WIZARD KEPT IN | 1.3 | +77.2 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 1.0 | +40.0 | 44.0 | 0.0 |
| LOST AFTER ESCAPE | 1.7 | +2.1 | 205.7 | 180.0 | 1.7 | +22.9 | 55.7 | 0.0 |
| MANOEUVRE | 1.3 | -5.2 | 0.0 | 0.0 | 2.0 | +0.9 | 0.0 | 20.0 |
| MARCH AT ESCAPER | - | - | - | - | 1.0 | +5.6 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 1.0 | +49.1 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | -34.1 | 0.0 | 180.0 | 1.3 | +651.7 | 0.0 | 83.7 |
| MAX FOR POSITIONING | 0.3 | +0.2 | 0.0 | 0.0 | 0.3 | +35.5 | 0.0 | 0.0 |
| MEETS IN TIME | 4.3 | +147.4 | 0.0 | 48.3 | 4.3 | +410.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.7 | +32.2 | 0.0 | 0.0 | 4.0 | +70.7 | 0.0 | 20.0 |
| MISSILES NEXT TURN | 2.7 | +31.6 | 0.0 | 360.0 | 6.3 | +41.6 | 0.0 | 103.7 |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 21.7 | 2.7 | +0.0 | 83.7 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 1.0 | -46.3 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 8.0 | +1634.3 | 0.0 | 200.7 | 9.3 | +666.1 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 14.7 | +578.5 | 0.0 | 105.3 | 7.7 | +322.6 | 0.0 | 58.0 |
| NEXT CHARGE BY LIST | 5.7 | +1381.6 | 0.0 | 65.0 | 7.0 | +549.2 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 4.3 | -148.4 | 368.7 | 180.0 | 3.7 | -227.7 | 414.7 | 15.0 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 4.3 | -75.0 | 0.0 | 43.7 | 6.0 | -165.8 | 0.0 | 83.7 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 1.3 | +0.0 | 0.0 | 40.0 |
| ONE FIGHT FORMULA | 5.0 | -111.2 | 0.0 | 24.0 | 6.3 | -88.9 | 0.0 | 103.7 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +21.9 | 37.3 | 15.0 |
| ONE OBJECTIVE FORMULA | 5.7 | -50.8 | 0.0 | 118.7 | 5.3 | -11.6 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | -11.8 | 0.0 | 0.0 |
| OPENS UP | 0.7 | +51.4 | 38.0 | 0.0 | 1.0 | +68.0 | 81.3 | 0.0 |
| OVERRUNS AWAY | 0.7 | +1.6 | 79.7 | 0.0 | 0.3 | +1.1 | 18.3 | 0.0 |
| PATHS CROSS | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +81.7 | 0.0 | 0.0 |
| PERIAPT WORTH | 0.3 | +34.4 | 0.0 | 180.0 | - | - | - | - |
| PLAN RESULT | 48.7 | +363.9 | 205.0 | 1363.7 | 45.7 | +435.8 | 541.7 | 972.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 8.3 | -360.2 | 0.0 | 0.0 | 8.3 | -86.4 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 1.0 | -1.9 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -3.5 | 0.0 | 24.0 | 0.3 | -16.7 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 1.0 | -4.8 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 24.7 | +2287.7 | 364.3 | 828.0 | 21.3 | +2923.4 | 816.7 | 294.3 |
| RANDOM MOVE BY FIGURES | 2.7 | +154.4 | 0.0 | 188.3 | 3.3 | +117.0 | 0.0 | 56.7 |
| REDIRECT COUNTER | 3.7 | +142.2 | 0.0 | 108.3 | 1.0 | +7.9 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 5.0 | +0.0 | 0.0 | 110.3 | 1.0 | +0.0 | 0.0 | 15.0 |
| REDIRECT WEIGHED | 0.7 | -4.0 | 0.0 | 180.0 | - | - | - | - |
| REFORMS TO MEET IT | 2.3 | -36.0 | 0.0 | 70.7 | 1.7 | -29.1 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 37.3 | - | - | - | - |
| RESERVE FALL BACK | 1.0 | +21.0 | 0.0 | 46.0 | 0.7 | +199.7 | 0.0 | 0.0 |
| RISK BY ARC | 2.7 | -77.0 | 246.7 | 180.0 | 4.0 | -2.3 | 458.7 | 77.0 |
| ROUNDS AFTER TERROR | 1.7 | -45.8 | 208.3 | 180.0 | 0.7 | -19.8 | 0.0 | 0.0 |
| RUN DOWN | 4.0 | -95.9 | 416.7 | 180.0 | 2.3 | -36.5 | 93.0 | 77.0 |
| SAFER THAN THE JOB | - | - | - | - | 0.3 | +2.0 | 0.0 | 0.0 |
| SCOUT SPOT | 1.3 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 0.7 | -2.3 | 0.0 | 0.0 | - | - | - | - |
| SECOND LOOK | 0.3 | +0.3 | 41.7 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 1.7 | -102.7 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.3 | +59.7 | 0.0 | 0.0 | 3.7 | +49.1 | 0.0 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +8.4 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +3.0 | 0.0 | 0.0 | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 5.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.0 | +88.9 | 76.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 1.3 | -9.7 | 77.3 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 28.3 | -236.1 | 0.0 | 720.7 | 27.3 | -297.7 | 0.0 | 272.7 |
| SHOTS AFTER THE MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 25.0 | +316.5 | 0.0 | 359.3 | 7.3 | +435.9 | 0.0 | 38.0 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +8.4 | 0.0 | 0.0 |
| SPELL WORTH | 0.7 | +22.3 | 360.0 | 360.0 | 4.0 | +5.8 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 8.7 | +0.0 | 0.0 | 737.0 | 11.3 | +0.0 | 0.0 | 367.0 |
| STAND AND SHOOT | 0.3 | -2.5 | 38.0 | 0.0 | 1.7 | -2.7 | 88.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 1.3 | +0.0 | 0.0 | 40.0 |
| STANDS STILL | 43.7 | +0.0 | 434.3 | 386.3 | 19.3 | +0.0 | 924.0 | 119.3 |
| STAY WORTH | 22.0 | +76.5 | 203.7 | 65.3 | 7.0 | +50.8 | 24.0 | 0.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | -132.4 | 0.0 | 0.0 |
| STUBBORN BY POINTS | - | - | - | - | 0.3 | +7.2 | 0.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 56.7 |
| STUPIDITY NEXT TURN | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 3.7 | +390.7 | 0.0 | 136.0 | 1.7 | +120.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 3.7 | +390.7 | 0.0 | 136.0 | 1.7 | +120.0 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +1.2 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 3.3 | +0.0 | 0.0 | 202.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.7 | -237.3 | 0.0 | 0.0 | 0.3 | -16.7 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 4.0 | +0.0 | 0.0 | 456.3 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 83.3 |
| THE ROW READS HIS LAST RUN | 1.0 | +0.0 | 0.0 | 180.0 | - | - | - | - |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 41.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 48.3 | +0.0 | 0.0 | 1011.0 | 42.0 | +0.0 | 0.0 | 419.3 |
| TIED UP BY THE SUM | 2.7 | +383.0 | 246.3 | 180.0 | 1.3 | +153.3 | 109.0 | 0.0 |
| TIME ON OUR SIDE | 54.3 | +431.1 | 0.0 | 871.7 | 7.3 | +84.3 | 0.0 | 79.7 |
| WAITS AGAIN | 0.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -1.3 | 0.0 | 0.0 |
| WAR ENGINE CHARGES | - | - | - | - | 0.3 | +33.6 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 1.3 | -36.7 | 74.7 | 124.0 |
| WHO FIGHTS | 0.3 | +0.4 | 0.0 | 0.0 | 1.7 | +4.2 | 151.3 | 15.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +20.3 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.7 | +4.6 | 37.3 | 62.0 |
| WHOLE FIGHT DANGER | 3.0 | -93.9 | 0.0 | 254.7 | 6.7 | -678.9 | 0.0 | 523.3 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +7.8 | 37.3 | 15.0 |
| WOUNDS ON THE RANKS | 0.3 | +1.7 | 0.0 | 0.0 | 6.3 | +147.6 | 0.0 | 167.3 |

### Rule changes: ccut-c940641-p11

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 156 | 156 | 118 | 39.33 | +2473 | +21.0 |
| HIS MOVE AS HE DECIDES | 133 | 133 | 98 | 32.67 | +0 | +0.0 |
| HIS SHOT LIST | 294 | 287 | 66 | 22.00 | +745 | +11.3 |
| HOLDER ASSIGNMENT | 69 | 69 | 63 | 21.00 | +3889 | +61.7 |
| HIS SHOTS BY HIS RUN | 281 | 275 | 56 | 18.67 | +349 | +6.2 |
| LEGAL CHARGES ONLY | 39 | 39 | 39 | 13.00 | +0 | +0.0 |
| FIVE ACTION | 565 | 554 | 31 | 10.33 | +1931 | +62.3 |
| OFF BEST | 31 | 31 | 31 | 10.33 | -722 | -23.3 |
| THE TABLE AGAIN | 36 | 36 | 30 | 10.00 | +0 | +0.0 |
| DEPLOY BY FIGURES | 47 | 47 | 26 | 8.67 | +299 | +11.5 |
| MOVE TO CHARGE COMPUTED | 52 | 50 | 24 | 8.00 | +2206 | +91.9 |
| HIS MOVE WHY | 33 | 33 | 23 | 7.67 | +0 | +0.0 |
| HIS ONE MOVE | 64 | 63 | 18 | 6.00 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 38 | 36 | 17 | 5.67 | +2030 | +119.4 |
| TIME ON OUR SIDE | 185 | 163 | 17 | 5.67 | +37 | +2.2 |
| PROMISE BY ITS OWN SUM | 50 | 50 | 15 | 5.00 | -1340 | -89.3 |
| QUARTER ODDS | 138 | 135 | 15 | 5.00 | +1171 | +78.1 |
| FOUR ROUNDS | 30 | 29 | 13 | 4.33 | +305 | +23.4 |
| HARD STAY DROPPED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| MEETS IN TIME | 26 | 26 | 13 | 4.33 | +1082 | +83.3 |
| SHOT RISK POINTS | 167 | 163 | 13 | 4.33 | +118 | +9.1 |
| GOAL WALK | 62 | 61 | 12 | 4.00 | +946 | +78.8 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 18 | 18 | 11 | 3.67 | +814 | +74.0 |
| THE RISK READS HIS RUN | 18 | 18 | 11 | 3.67 | +0 | +0.0 |
| TIED UP BY THE SUM | 12 | 11 | 11 | 3.67 | +403 | +36.7 |
| ADVANCE LANE KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| EVASIVE BY THE ODDS | 13 | 13 | 8 | 2.67 | +3002 | +375.3 |
| HOLDS AMBUSHERS | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| IDLE COST | 53 | 33 | 8 | 2.67 | +22 | +2.7 |
| CHARGE LOSSES | 117 | 114 | 7 | 2.33 | +790 | +112.8 |
| FOLLOW UP WEIGHED | 7 | 7 | 7 | 2.33 | +1274 | +182.0 |
| WHOLE FIGHT DANGER | 29 | 29 | 7 | 2.33 | +265 | +37.9 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +147 | +24.5 |
| SHOOTS FROM THE BEST SPOT | 6 | 6 | 6 | 2.00 | +186 | +31.0 |
| COMBAT PIVOT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| RESERVE FALL BACK | 5 | 5 | 5 | 1.67 | +662 | +132.4 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +132 | +33.0 |
| COVER ONCE | 46 | 24 | 4 | 1.33 | +105 | +26.3 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +232 | +57.9 |
| PATHS CROSS | 4 | 4 | 4 | 1.33 | +245 | +61.3 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SET UP BY THE SET | 12 | 12 | 4 | 1.33 | +380 | +95.1 |
| STAY WORTH | 87 | 78 | 4 | 1.33 | +24 | +6.0 |
| SUPPORT ADDS | 16 | 16 | 4 | 1.33 | +89 | +22.2 |
| SUPPORT WORKED OUT | 16 | 16 | 4 | 1.33 | +89 | +22.2 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHARGE NOW FIRST | 17 | 17 | 3 | 1.00 | -116 | -38.6 |
| NO DOUBLE ROUNDS | 24 | 23 | 3 | 1.00 | +24 | +8.1 |
| PROMISE KNOWS THE FIGHT | 3 | 3 | 3 | 1.00 | -6 | -1.9 |
| PROMISE SHOT AWAY | 3 | 3 | 3 | 1.00 | -14 | -4.8 |
| RISK BY ARC | 20 | 19 | 3 | 1.00 | +7 | +2.4 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +10 | +3.3 |
| SHOTS IN THE MOVE | 97 | 74 | 3 | 1.00 | +199 | +66.4 |
| AFTERMATH WITH FRIENDS | 2 | 2 | 2 | 0.67 | +89 | +44.3 |
| ASSAILMENT BY POINTS | 2 | 2 | 2 | 0.67 | +3 | +1.3 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FIGHT TO THE END | 3 | 3 | 2 | 0.67 | +6 | +3.0 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 2 | 2 | 2 | 0.67 | +16 | +8.1 |
| HONEST WORTH | 29 | 28 | 2 | 0.67 | +18 | +8.9 |
| NEARER NOT NEEDED | 67 | 64 | 2 | 0.67 | +72 | +35.8 |
| OPENS UP | 5 | 5 | 2 | 0.67 | +24 | +12.2 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | -10 | -5.2 |
| REFUSING RETIRES | 2 | 2 | 2 | 0.67 | -47 | -23.6 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| BEST OVERALL | 1 | 1 | 1 | 0.33 | +6 | +5.9 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -12 | -12.0 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 5 | 5 | 1 | 0.33 | +2 | +1.5 |
| EXACT ROUND | 19 | 19 | 1 | 0.33 | +2 | +1.7 |
| FALLS SHORT | 63 | 52 | 1 | 0.33 | +24 | +24.3 |
| FEATURE BUFFS | 12 | 12 | 1 | 0.33 | +6 | +6.3 |
| HIS TURN DENIED | 6 | 6 | 1 | 0.33 | +2 | +2.5 |
| JOINT CHARGE NOW | 1 | 1 | 1 | 0.33 | -23 | -23.3 |
| LONG SHOT | 3 | 3 | 1 | 0.33 | +2 | +2.5 |
| MANOEUVRE | 10 | 10 | 1 | 0.33 | +12 | +12.0 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| MAX FOR POSITIONING | 2 | 2 | 1 | 0.33 | +65 | +64.6 |
| MISSILES IN THE MOVE | 17 | 11 | 1 | 0.33 | +2 | +1.5 |
| ONE JOINT FIGURE | 1 | 1 | 1 | 0.33 | +37 | +37.3 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -36 | -35.5 |
| OVERRUNS AWAY | 3 | 2 | 1 | 0.33 | +0 | +0.5 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +103 | +103.3 |
| RUN DOWN | 19 | 18 | 1 | 0.33 | +101 | +100.6 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.33 | +6 | +5.9 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +1 | +0.9 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +22 | +21.5 |
| SUPPORT NARROWED | 2 | 2 | 1 | 0.33 | -1 | -1.4 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +4 | +3.6 |
| THE PROMISE ADDS | 3 | 3 | 1 | 0.33 | +30 | +29.5 |
| THE ROW IN ITS ORDER | 20 | 1 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -4 | -4.0 |
| WHO FIGHTS | 6 | 6 | 1 | 0.33 | +4 | +4.3 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +59 | +59.3 |
| WOUNDS ON THE RANKS | 20 | 20 | 1 | 0.33 | +45 | +44.8 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CAST JOB | 7 | 7 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CHAFF IN THE MOVE | 1 | 1 | 0 | 0.00 | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 10 | 10 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 78 | 76 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 4 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 24 | 23 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 52 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 27 | 27 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 7 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 22 | 22 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 86 | 84 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 26 | 26 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 29 | 27 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 28 | 27 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 23 | 22 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 37 | 36 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 79 | 78 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 14 | 14 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 120 | 120 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | not checked | - | - | - | - |
| KEPT FROM ITS LAST STOP | 8 | 8 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 10 | 9 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH CHECK | 3 | 3 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 27 | 17 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 3 | trace | - | - | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 34 | 18 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 33 | 24 | 0 | 0.00 | - | - |
| PLAN RESULT | 283 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 14 | 11 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 12 | 12 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 7 | 7 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SEARCH SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 5 | 5 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 29 | not checked | - | - | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 10 | 10 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 14 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 60 | 51 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 6 | 6 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 4 | 4 | 0 | 0.00 | - | - |
| STANDS STILL | 189 | 187 | 0 | 0.00 | - | - |
| STRIKE BY THE ODDS | 1 | 1 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 5 | 5 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 13 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 12 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 3 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 8 | not checked | - | - | - | - |
| THE TABLE BINDS | 271 | not checked | - | - | - | - |
| WAITS AGAIN | 8 | 8 | 0 | 0.00 | - | - |
| WAR ENGINE CHARGES | 1 | 1 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 4 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p11

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.67 | 5.67 | 24.2 |
| PROMISE BY ITS OWN SUM | rule | 3.33 | 1.67 | 89.3 |
| ARMY TABLE | rule | 2.33 | 2.33 | 59.5 |
| HOLDER ASSIGNMENT | rule | 0.67 | 0.67 | 8.8 |
| CHARGE NOW FIRST | rule | 0.67 | 0.33 | 38.6 |
| PROMISE KNOWS THE FIGHT | rule | - | 1.00 | 1.9 |
| PROMISE SHOT AWAY | rule | 1.00 | - | 4.8 |
| REFUSING RETIRES | rule | 0.67 | - | 23.6 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.33 | - | 9.7 |
| BEST PRIZE | rule | 0.33 | - | 12.0 |
| JOINT CHARGE NOW | rule | - | 0.33 | 23.3 |
| NO REASON | gate | - | 0.33 | 28.3 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 35.5 |
| REDIRECT WEIGHED | rule | 0.33 | - | 10.5 |
| RULE SWITCHED OFF | gate | 0.33 | - | 7.0 |
| SUPPORT NARROWED | rule | 0.33 | - | 1.4 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 4.0 |

### Plans: ccut-c940641-p11

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.3 | 60% | 571 | 259 | 45% |
| Mine | move | 41.3 | 91% | 2847 | 0 | 0% |
| Mine | shoot | 4.0 | 33% | 273 | 105 | 38% |
| Opponent | charge | 4.3 | 54% | 653 | 396 | 61% |
| Opponent | join | 5.0 | 100% | 215 | 0 | 0% |
| Opponent | move | 35.0 | 94% | 1483 | 0 | 0% |
| Opponent | shoot | 1.3 | 25% | 30 | 40 | 132% |

### Battle groups: ccut-c940641-p11

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.7 | 55% | 33% | 0% | - | 33% | 0% | 0% | 67% | 0% |
| Opponent | REDIRECT COUNTER | 1.0 | 33% | 100% | 0% | - | 100% | 0% | 0% | 0% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p11

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | - | - | - |
| Mine | Chaff | 6 | 15 (6) | 0 | 15 | 82 | 0% | 1.2 | - | 17 (5) | 0 (1) | 17 (5) | 0 (1) |
| Mine | Character | 7 | 69 (7) | 69 | 0 | 54 | 0% | 3.1 | 140 (2) | 0 (1) | 56 (2) | 97 (4) | 0 (1) |
| Mine | Clean-up | 1 | 220 (1) | 0 | 220 | 0 | 0% | 2.0 | - | 220 (1) | - | - | 220 (1) |
| Mine | Fast Hammer | 6 | 25 (6) | 25 | 0 | 29 | 33% | 5.2 | 35 (4) | 0 (2) | - | - | 25 (6) |
| Mine | Hammer | 5 | 70 (5) | 44 | 26 | 39 | 0% | 2.2 | 79 (3) | 59 (2) | - | 136 (2) | 39 (3) |
| Mine | Holder | 8 | 41 (8) | 7 | 34 | 51 | 12% | 2.6 | 68 (3) | 36 (4) | - | 102 (2) | 29 (5) |
| Mine | Shooter | 5 | 64 (5) | 0 | 64 | 15 | 0% | 1.4 | 0 (2) | 146 (3) | - | 76 (4) | 0 (1) |
| Mine | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | 0 (1) | - | 0 (2) | 0 (1) |
| Opponent | Chaff | 4 | 160 (4) | 23 | 138 | 44 | 25% | 3.0 | 214 (3) | - | 0 (1) | 214 (3) | 0 (1) |
| Opponent | Character | 11 | 47 (11) | 47 | 0 | 32 | 18% | 4.1 | 129 (2) | 24 (7) | 0 (1) | 20 (6) | 122 (4) |
| Opponent | Fast Hammer | 6 | 41 (6) | 24 | 17 | 35 | 0% | 3.3 | - | 45 (5) | 19 (1) | 6 (3) | 64 (3) |
| Opponent | Hammer | 8 | 20 (8) | 20 | 0 | 53 | 0% | 4.4 | 0 (3) | 32 (5) | - | 26 (6) | 0 (2) |
| Opponent | Holder | 3 | 0 (3) | 0 | 0 | 65 | 67% | 4.0 | 0 (1) | 0 (2) | - | - | 0 (3) |
| Opponent | Shooter | 3 | 272 (3) | 148 | 124 | 31 | 0% | 1.3 | - | 94 (2) | 682 (1) | 396 (2) | 0 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 76 | 0% | 1.0 | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |

### Charged fights: ccut-c940641-p11

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| Mine | Tomb Kings of Khemri | 2 | 60 | 817 | 4.0 | 1.0 | 204 | 0 | +204 | 1 of 8 | 8 of 8 | - | +204 |
| **Mine** | all armies | 3 | 40 | 545 | 3.0 | 1.0 | 182 | 0 | +182 | 1 of 9 | 8 of 9 | - | +182 |
| Opponent | Vampire Counts | 1 | 145 | 1219 | 9.0 | 1.0 | 135 | 53 | +82 | 3 of 9 | 7 of 9 | - | +82 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 144 | -144 | 1 of 1 | 0 of 1 | - | -144 |
| Opponent | Wood Elf Realms | 1 | 540 | 397 | 3.0 | 1.0 | 132 | 0 | +132 | 1 of 3 | 3 of 3 | - | +132 |
| **Opponent** | all armies | 3 | 228 | 539 | 4.3 | 1.0 | 124 | 48 | +76 | 5 of 13 | 10 of 13 | - | +76 |

### Effective charges: ccut-c940641-p11

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Skaven | 1 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Mine | Tomb Kings of Khemri | 8 | 0 | 0 | 1 (net +483) | 1 (net +662) | 4 (net +122) | 1 (net +0) | 1 | 14% (1 of 7) |
| Opponent | Vampire Counts | 9 | 3 (net +18) | 0 | 1 (net +302) | 1 (net -436) | 1 (net +67) | 2 (net +270) | 1 | 12% (1 of 8) |
| Opponent | Wood Elf Realms | 3 | 0 | 0 | 0 | 0 | 1 (net +66) | 2 (net +166) | 0 | 0% (0 of 3) |

### Charged fights, damage counted: ccut-c940641-p11

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 2 | 118 | 96 | +242 | 242 | 32 | +209 | +177.1 |
| Mine | 76-89% | 1 | 431 | 201 | +662 | 662 | 0 | +662 | +153.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 195 | 102 | +0 | 34 | 130 | -96 | -49.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 4 | 436 | 122 | +122 | 145 | 61 | +84 | +19.3 |
| Mine | No odds | 1 | 440 | 125 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | All fights | 9 | 338 | 123 | +182 | 196 | 49 | +147 | +43.4 |
| Opponent | Long shot (under 50%) | 3 | 47 | 77 | +18 | 29 | 0 | +29 | +62.5 |
| Opponent | Effective (55-75%) | 1 | 186 | 210 | +302 | 302 | 0 | +302 | +162.4 |
| Opponent | 76-89% | 1 | 186 | 145 | -436 | 0 | 436 | -436 | -234.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 279 | 186 | +218 | 223 | 8 | +214 | +76.8 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 485 | 89 | +66 | 89 | 22 | +66 | +13.7 |
| Opponent | No odds | 2 | 296 | 326 | +33 | 160 | 126 | +34 | +11.7 |
| Opponent | All fights | 13 | 245 | 166 | +76 | 137 | 59 | +78 | +31.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p11 | move | 28 | 3 (11%) | 2 (7%) | 9 (32%) | 16 (57%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L2127 |
| Invocation of Nehek | Opponent | L2127 |
| Periapt of Soul Exchange | Mine | L2127 |
| Ring of Doom | Opponent | L2231 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |

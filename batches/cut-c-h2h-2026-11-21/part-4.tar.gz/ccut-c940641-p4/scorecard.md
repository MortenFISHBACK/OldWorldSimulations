# Doctrine scorecard: ccut-c940641-p4

### Scorecard: ccut-c940641-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0524 | 2 | 1 | Mine | - | - | 4 | 1 | 1 | 0 | 0 | 0 | 453 |
| L0524 | 2 | 1 | Opponent | - | - | 6 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 1 | - | 0 | 4 | 0 | 0 | 0 | 235 |
| L0612 | 6 | 1 | Opponent | no | 2 | 6 | 0 | 1 | 0 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | - | 2 | 5 | 0 | 0 | 0 | 346 |
| L0628 | 4 | 1 | Opponent | no | 9 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 0.5 | 4.0 | 1.0 | 3.3 | 0.0 | 0.0 | 0.0 | 344.7 |
| **Average** | | | Opponent | 0% | 5.5 | 6.0 | 1.0 | 2.0 | 0.0 | 0.0 | 0.0 | 110.0 |

### KPIs: ccut-c940641-p4

Rules off - Mine only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 100% (15 of 15) | 0% (0 of 15) | 50% (15 of 30) |
| Winner chose to follow up after the loser gave ground |  | - | 100% (3 of 3); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (1 of 1); on the table 100% | 100% (3 of 3); on the table 100% | 100% (4 of 4); on the table 100% |
| Magic missiles tried each own turn | 50%+ | - | 23% (7 of 30) | 23% (7 of 30) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 24% (7 of 29) | 24% (7 of 29) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 78% (4699 of 6000) | 66% (3952 of 5998) | 72% (8651 of 11998) |
|   infantry points that never fought | lower | 79% (1760 of 2232) | 100% (694 of 694) | 84% (2454 of 2926) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 59% (16 of 27) | 61% (14 of 23) | 60% (30 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 67% (2 of 3); 2.3 uses a game | 67% (2 of 3); 1.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 52% (2199 of 4232) | 63% (3664 of 5787) | 59% (5863 of 10019) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 3.0 (39%) | 3.0 (39%) |
| MARCHED: its unit marched | - | 4.0 (52%) | 4.0 (52%) |
| CHARGED: its unit charged | - | 0.3 (4%) | 0.3 (4%) |
| IN COMBAT: engaged in combat | - | 0.3 (4%) | 0.3 (4%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 6.0 | 1.3 | 2.3 | 0.7 | 0.3 |
| not cast | 2.0 | 2.7 | 7.7 | 3.3 | 23.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.7 (100%) | 3.0 (39%) | 0.7 (20%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 4.0 (52%) | 1.7 (50%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.3 (10%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (20%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 23.3 (99%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 59% (129 of 217) | 81% (13 of 16) | 61% (142 of 233) |
|   cavalry | 48% (11 of 23) | 25% (1 of 4) | 44% (12 of 27) |
|   character | 88% (28 of 32) | - | 88% (28 of 32) |
|   infantry | 39% (22 of 56) | - | 39% (22 of 56) |
|   monster | 75% (9 of 12) | - | 75% (9 of 12) |
|   war machine | 63% (59 of 94) | 100% (12 of 12) | 67% (71 of 106) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 4.0 (14%) | 0.7 (67%) | 4.7 (15%) |
| CHARGED: it charged | 1.0 (3%) | 0.0 (0%) | 1.0 (3%) |
| MOVED: a war machine that moved | 0.3 (1%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET IN RANGE | 11.7 (40%) | 0.3 (33%) | 12.0 (40%) |
| ONLY IN COMBAT: the only targets were in combat | 1.0 (3%) | 0.0 (0%) | 1.0 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 8.3 (28%) | 0.0 (0%) | 8.3 (27%) |
| SHELTERED: the target was sheltered | 2.3 (8%) | 0.0 (0%) | 2.3 (8%) |
| OTHER BAR | 0.7 (2%) | 0.0 (0%) | 0.7 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.0 | 1.3 | 67% | 9.5 pts | 38 pts |
| character | 11.3 | 5.0 | 76% | 8.3 pts | 95 pts |
| infantry | 15.7 | 4.3 | 81% | 7.7 pts | 121 pts |
| monster | 3.0 | 0.7 | 78% | 6.4 pts | 19 pts |
| war machine | 24.0 | 15.0 | 69% | 16.9 pts | 407 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.3 | 3.0 | 2.2 |
| Charges that made contact a game | 1.0 | 2.0 | 1.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.67 declared, 0.33 contact (3 units) | 0.67 declared, 0.33 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.50 declared, 0.50 contact (2 units) | 0.50 declared, 0.50 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.18 declared, 0.14 contact (22 units) | 0.50 declared, 0.33 contact (12 units) | 0.29 declared, 0.21 contact (34 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 25% (1 of 4) | 100% (1 of 1) | 50% (1 of 2) | 43% (3 of 7) |
| Character in a unit | 71% (5 of 7) | 50% (2 of 4) | 100% (1 of 1) | 67% (8 of 12) |
| Character on its own | 100% (1 of 1) | 100% (3 of 3) | 50% (1 of 2) | 83% (5 of 6) |
| Infantry | 14% (1 of 7) | 50% (3 of 6) | - | 31% (4 of 13) |
| Monster | 100% (2 of 2) | - | - | 100% (2 of 2) |
| War Machines | 80% (8 of 10) | - | - | 80% (8 of 10) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dwarfen Mountain Holds | 3 | 100% (1 of 1); on the table 100% | - | 78% | 59% (16 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | 100% (3 of 3); on the table 100% | 17% (3 of 18) | 62% | 67% (6 of 9) | 67% (2 of 3); 7.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Vampire Counts | 1 | - | 33% (2 of 6) | 86% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | - | 33% (2 of 6) | 49% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p4, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 100% (2) | 67% (2) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.67 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.67 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: ccut-c940641-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 75% (3 of 4) | 56% (5 of 9) |
| Strategy | Shoot objectives carried out (shot that target) | 48% (30 of 63) | 35% (6 of 17) |
| Strategy | Support requests answered (helper made contact too) | - | 67% (2 of 3) |
| Strategy | Joined characters whose unit fought | 36% (4 of 11) | 33% (2 of 6) |
| Strategy | Lone characters that fought | 0% (0 of 2) | 67% (4 of 6) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 3.3 | 2.0 |
| Movement | Points that never moved of their own | 344.7 | 110.0 |
| Movement | Fights charged into per game | 1.0 | 1.3 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 3, net -60 | 0 of 2 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 3 | 0 of 2 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 3 | 1 of 2, net +0 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 3, net +30 | 1 of 2, net +95 |
| Shooting | Shots by shooting units (incl. breath weapons) | 26.3 | 0.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 48% (38 of 79) | 0% (0 of 1) |
| Shooting | Points destroyed by shooting units | 106.7 | 0.0 |
| Shooting | War machine shots | 19.7 | 4.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 68% (40 of 59) | 25% (3 of 12) |
| Shooting | Points destroyed by war machines | 0.0 | 60.0 |
| Magic | Magic missiles cast | - | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 25% (1 of 4) |
| Magic | Wounds caused by magic missiles | - | 1.3 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 5.3 / 0.0 / 0.0 / 0.3 |
| Combat | Points destroyed in combat | 36.7 | 51.7 |
| Combat | Points run down | 0.0 | 21.7 |
| Combat | Net points per charged fight, damage counted | +18 | +9 |
| Combat | Net per 100 charger points, damage counted | +32.6 | +3.3 |
| Combat | First round won (charged fights) | 67% | 75% |
| Combat | Net points per charged fight | +0 | +28 |
| Combat | Net points per supported fight / lone fight | - / +0 | +0 / +37 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 3 | 2 of 4 |
| Game | Points lost | 189.0 | 143.3 |
| Game | VP from objectives | 730.0 | 606.7 |
| Game | Lone holders (player turns) | 0.5 | 5.5 |

- Mine won / drew / lost: 0 / 3 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +95 VP
- Points traded per game (both sides' losses): 332
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: ccut-c940641-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 10.7 | +28.6 | 0.0 | 0.0 | 11.0 | -78.3 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 0.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.7 | +1.5 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | - | - | - | - | 0.7 | -55.0 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.7 | +0.0 | 27.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 14.3 | +81.5 | 255.7 | 20.0 | 4.0 | +82.5 | 60.0 | 0.0 |
| CANNON SIGHT KEPT | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CAST JOB | - | - | - | - | 3.0 | +18.4 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.7 | +99.5 | 0.0 | 60.0 |
| CHAFF PASSED | 0.3 | -0.8 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -5.0 | 0.0 | 0.0 |
| CHARACTER GUNS | 4.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 10.3 | -234.9 | 0.0 | 51.7 | 16.7 | -941.2 | 0.0 | 93.0 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 31.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 8.7 | +0.0 | 0.0 | 0.0 | 8.7 | +0.0 | 0.0 | 0.0 |
| COVER ONCE | 9.7 | -608.4 | 0.0 | 109.7 | 4.3 | -164.7 | 0.0 | 56.0 |
| DEFENSIVE ARMY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -9.4 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 13.3 | -169.6 | 0.0 | 40.0 | 4.3 | +35.7 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.7 | -40.1 | 0.0 | 0.0 |
| EXACT ROUND | 0.7 | +1.2 | 33.7 | 0.0 | 1.3 | +3.9 | 75.0 | 0.0 |
| FALL BACK GOOD ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 2.7 | +1.5 | 53.3 | 33.3 |
| FALLS SHORT | - | - | - | - | 24.7 | +224.0 | 0.0 | 69.7 |
| FEATURE BUFFS | 0.7 | +1.4 | 0.0 | 0.0 | 1.3 | +5.5 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +1.2 | 13.7 | 0.0 | - | - | - | - |
| FIVE ACTION | 141.3 | +4424.4 | 385.0 | 433.3 | 68.0 | +2287.0 | 75.0 | 246.7 |
| FLANK NOT WEIGHED | 4.0 | +0.0 | 0.0 | 60.7 | 4.0 | +0.0 | 0.0 | 13.7 |
| FOLLOW UP WEIGHED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.3 | +41.4 | 33.7 | 20.0 | 3.0 | +103.3 | 75.0 | 33.3 |
| FREED FROM HIS FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 1.3 | -21.0 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.3 | -0.6 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 3.7 | +284.3 | 0.0 | 0.0 | 1.7 | +69.6 | 0.0 | 0.0 |
| GUN FIGURES | 2.3 | +2.9 | 37.0 | 0.0 | - | - | - | - |
| GUN MASK | 3.3 | +44.4 | 0.0 | 0.0 | 2.0 | +60.6 | 0.0 | 0.0 |
| HARD STAY DROPPED | 4.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 5.0 | +0.0 | 0.0 | 31.7 | 6.7 | +0.0 | 0.0 | 56.0 |
| HIS CHARGE DENIED | 0.3 | +2.7 | 20.0 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 16.0 | +0.0 | 0.0 | 126.7 | 11.0 | +0.0 | 0.0 | 74.0 |
| HIS LEGAL MOVES | 2.3 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 112.0 |
| HIS MOVE AND SHOT | 2.7 | -8.9 | 0.0 | 20.0 | 5.3 | -85.4 | 0.0 | 50.7 |
| HIS MOVE AS HE DECIDES | 33.0 | +6.3 | 193.7 | 0.0 | - | - | - | - |
| HIS ONE MOVE | 18.3 | -32.0 | 0.0 | 40.0 | - | - | - | - |
| HIS ONE QUARTER | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 1.7 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 112.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 49.7 | +1781.4 | 0.0 | 120.0 | 42.7 | +4508.0 | 0.0 | 101.3 |
| HIS SHOTS BY HIS RUN | 32.0 | +522.1 | 0.0 | 126.7 | 39.7 | +1178.1 | 0.0 | 213.3 |
| HIS TURN DENIED | - | - | - | - | 0.7 | +46.9 | 0.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 17.0 | +0.0 | 0.0 | 0.0 | 14.0 | +0.0 | 0.0 | 112.0 |
| HOLDER ASSIGNMENT | 11.0 | +994.1 | 0.0 | 0.0 | 9.0 | +1076.2 | 0.0 | 56.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -3.9 | 33.7 | 0.0 | 2.3 | -62.7 | 75.0 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 1.0 | +58.2 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 15.7 | -402.4 | 0.0 | 37.0 |
| JOINT CHARGE NOW | - | - | - | - | 1.7 | -259.5 | 43.3 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.3 | -2.7 | 0.0 | 0.0 |
| KEEP FALLS | - | - | - | - | 0.3 | +0.7 | 0.0 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +42.7 | 0.0 | 0.0 |
| LONE CHARACTER SAFE SPOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 0.3 | +1.4 | 20.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 1.0 | +0.6 | 13.7 | 20.0 | 1.3 | -11.4 | 21.7 | 0.0 |
| MANOEUVRE | 1.7 | -6.3 | 0.0 | 21.7 | 1.3 | +10.2 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +0.7 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.3 | +93.2 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 1.3 | +76.2 | 0.0 | 56.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +17.3 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 2.7 | +347.7 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | - | - | - | - | 1.7 | +16.5 | 0.0 | 0.0 |
| MEETS IN TIME | 9.3 | +185.0 | 0.0 | 40.0 | 2.3 | +331.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | - | - | - | - | 5.3 | +26.9 | 0.0 | 0.0 |
| MISSILES NEXT TURN | - | - | - | - | 9.7 | +51.6 | 0.0 | 56.0 |
| MODEL FACING | 5.0 | +1590.0 | 0.0 | 20.0 | - | - | - | - |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 6.3 | +271.7 | 0.0 | 40.0 | 1.7 | +113.5 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.0 | +261.9 | 0.0 | 0.0 | 5.0 | +233.4 | 0.0 | 76.0 |
| NEXT CHARGE BY LIST | 2.3 | +96.6 | 0.0 | 0.0 | 1.7 | +113.5 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.0 | -8.1 | 33.7 | 0.0 | 1.7 | -29.9 | 75.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 6.0 | -183.9 | 0.0 | 0.0 | 3.7 | -129.5 | 0.0 | 13.7 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 5.0 | +6.1 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.7 | -21.2 | 0.0 | 0.0 | 3.3 | -75.4 | 0.0 | 0.0 |
| ONE JOINT FIGURE | - | - | - | - | 1.0 | +87.7 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 6.7 | -92.4 | 0.0 | 0.0 | 4.0 | -127.1 | 0.0 | 56.0 |
| ONE ROUTE | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.3 | +0.5 | 20.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 62.0 | +672.8 | 189.0 | 264.7 | 32.0 | +79.6 | 0.0 | 230.7 |
| PROMISE BY ITS OWN SUM | 10.0 | -235.0 | 0.0 | 40.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 1.3 | -31.6 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 17.7 | +1088.6 | 0.0 | 60.0 | 2.0 | +689.1 | 0.0 | 0.0 |
| REAL GROUND | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 1.0 | +54.8 | 0.0 | 40.0 |
| REDIRECT COUNTER | 1.3 | +126.9 | 0.0 | 21.7 | 1.3 | -3.5 | 0.0 | 33.7 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.3 | +0.0 | 0.0 | 13.7 |
| REDIRECT WEIGHED | - | - | - | - | 0.7 | -55.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -9.9 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RISK BY ARC | 1.3 | +32.7 | 33.7 | 20.0 | 0.7 | +50.9 | 0.0 | 16.7 |
| ROUNDS AFTER TERROR | - | - | - | - | 2.0 | -12.5 | 53.3 | 33.3 |
| RUN DOWN | 0.7 | -11.9 | 13.7 | 0.0 | 1.7 | -4.4 | 43.3 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -100.9 | 0.0 | 0.0 |
| SEARCH SPOT | 1.7 | +41.8 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.7 | -21.7 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 0.7 | +11.2 | 0.0 | 0.0 | 1.7 | +0.3 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.7 | -1.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 2.0 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 22.0 | +0.0 | 0.0 | 98.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.7 | +23.0 | 0.0 | 0.0 | 0.3 | +0.5 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 2.0 | +0.0 | 0.0 | 40.0 | - | - | - | - |
| SHOT OR CHARGE | 0.7 | -10.7 | 13.7 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 29.3 | +931.6 | 0.0 | 140.0 | 21.7 | -672.8 | 0.0 | 143.7 |
| SHOTS AFTER THE MOVES | 5.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 33.3 | +877.4 | 0.0 | 60.0 | 4.3 | +262.4 | 0.0 | 37.0 |
| SPELL WORTH | - | - | - | - | 6.0 | +148.0 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 5.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 56.0 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -6.8 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 103.3 | +0.0 | 351.3 | 373.3 | 19.7 | +0.0 | 0.0 | 0.0 |
| STAY WORTH | 54.7 | +112.2 | 295.3 | 100.0 | 12.3 | +192.6 | 0.0 | 37.0 |
| STRIKE BY THE ODDS | 0.3 | +1.9 | 0.0 | 20.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.7 | +187.9 | 0.0 | 0.0 | 1.7 | +118.5 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 20.0 | 0.0 | 0.3 | +0.0 | 0.0 | 16.7 |
| SUPPORT WORKED OUT | 2.7 | +187.9 | 0.0 | 0.0 | 1.7 | +118.5 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 2.0 | +7.9 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 50.7 |
| THE ROW READS HIS LAST RUN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 55.3 | +0.0 | 0.0 | 161.3 | 33.3 | +0.0 | 0.0 | 106.7 |
| TIED UP BY THE SUM | 0.7 | +18.4 | 13.7 | 0.0 | 0.3 | +22.0 | 31.7 | 0.0 |
| TIME ON OUR SIDE | 61.0 | +630.1 | 0.0 | 208.0 | - | - | - | - |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.7 | +4.8 | 13.7 | 20.0 | 0.7 | +13.4 | 31.7 | 0.0 |
| WHO GETS IN | - | - | - | - | 1.0 | -271.1 | 0.0 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +12.7 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 1.3 | -42.5 | 0.0 | 31.7 | 0.7 | -41.5 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 1.0 | +299.0 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 2.7 | +47.0 | 0.0 | 0.0 | 2.3 | +344.6 | 0.0 | 0.0 |

### Rule changes: ccut-c940641-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 277 | 271 | 92 | 30.67 | +2492 | +27.1 |
| HIS MOVE AS HE DECIDES | 99 | 99 | 80 | 26.67 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 60 | 60 | 56 | 18.67 | +2860 | +51.1 |
| HIS SHOTS BY HIS RUN | 215 | 202 | 49 | 16.33 | +709 | +14.5 |
| SHOT RISK POINTS | 153 | 148 | 48 | 16.00 | +1882 | +39.2 |
| ARMY TABLE | 65 | 65 | 45 | 15.00 | +880 | +19.5 |
| TIME ON OUR SIDE | 183 | 164 | 33 | 11.00 | +90 | +2.7 |
| DEPLOY BY FIGURES | 53 | 53 | 32 | 10.67 | +329 | +10.3 |
| OFF BEST | 29 | 29 | 29 | 9.67 | -940 | -32.4 |
| FIVE ACTION | 628 | 615 | 23 | 7.67 | +568 | +24.7 |
| THE TABLE AGAIN | 36 | 36 | 21 | 7.00 | +0 | +0.0 |
| HIS ONE MOVE | 55 | 53 | 18 | 6.00 | +0 | +0.0 |
| HARD STAY DROPPED | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| CHARGE LOSSES | 81 | 77 | 16 | 5.33 | +723 | +45.2 |
| MOVE TO CHARGE COMPUTED | 24 | 22 | 16 | 5.33 | +382 | +23.9 |
| CANNON PLANNED TARGET | 55 | 55 | 15 | 5.00 | +59 | +4.0 |
| MODEL FACING | 15 | 15 | 15 | 5.00 | +4770 | +318.0 |
| OGRE LOADER SECOND SHOT | 15 | 15 | 15 | 5.00 | +18 | +1.2 |
| MEETS IN TIME | 35 | 35 | 14 | 4.67 | +462 | +33.0 |
| PROMISE BY ITS OWN SUM | 39 | 39 | 14 | 4.67 | -705 | -50.4 |
| ARTILLERY RE-ROLL WEIGHED | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| CANNON SIGHT KEPT | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 22 | 22 | 10 | 3.33 | +0 | +0.0 |
| FOUR ROUNDS | 13 | 13 | 9 | 3.00 | +74 | +8.2 |
| COVER ONCE | 42 | 36 | 8 | 2.67 | +0 | +0.0 |
| IDLE COST | 47 | 40 | 8 | 2.67 | +291 | +36.4 |
| QUARTER ODDS | 59 | 57 | 8 | 2.67 | +659 | +82.4 |
| GOAL WALK | 16 | 16 | 6 | 2.00 | +473 | +78.8 |
| SHOOTERS IN TWO RANKS | 6 | 6 | 6 | 2.00 | +12 | +2.0 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| THE RISK READS HIS RUN | 18 | 18 | 6 | 2.00 | +0 | +0.0 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | -779 | -155.7 |
| MOVE ORDER | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 12 | 12 | 5 | 1.67 | +119 | +23.8 |
| SUPPORT ADDS | 13 | 12 | 5 | 1.67 | +139 | +27.8 |
| SUPPORT WORKED OUT | 13 | 12 | 5 | 1.67 | +139 | +27.8 |
| WOUNDS ON THE RANKS | 15 | 15 | 5 | 1.67 | +100 | +20.0 |
| GUN MASK | 16 | 16 | 4 | 1.33 | +88 | +21.9 |
| MARCH CHECK | 4 | 4 | 4 | 1.33 | +93 | +23.3 |
| REDIRECT FOR A FRIEND IN REACH | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| RISK BY ARC | 6 | 6 | 4 | 1.33 | +28 | +7.0 |
| SEARCH SPOT | 5 | 5 | 4 | 1.33 | +125 | +31.4 |
| SHOOTS FROM THE BEST SPOT | 6 | 6 | 4 | 1.33 | +51 | +12.8 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CAST JOB | 9 | 9 | 3 | 1.00 | +7 | +2.3 |
| EXACT ROUND | 6 | 6 | 3 | 1.00 | +1 | +0.3 |
| FALLS SHORT | 74 | 67 | 3 | 1.00 | +64 | +21.5 |
| ONE JOINT FIGURE | 3 | 3 | 3 | 1.00 | +42 | +13.9 |
| SHOTS IN THE MOVE | 113 | 97 | 3 | 1.00 | +108 | +35.8 |
| STAY WORTH | 201 | 186 | 3 | 1.00 | +22 | +7.4 |
| TIED UP BY THE SUM | 3 | 3 | 3 | 1.00 | +27 | +9.0 |
| WHO FIGHTS | 4 | 4 | 3 | 1.00 | +5 | +1.5 |
| WHO GETS IN | 3 | 3 | 3 | 1.00 | -813 | -271.1 |
| WHOLE FIGHT GAIN | 3 | 3 | 3 | 1.00 | +42 | +13.9 |
| BEST PRIZE | 2 | 2 | 2 | 0.67 | -165 | -82.4 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HIS TURN DENIED | 2 | 2 | 2 | 0.67 | +40 | +19.8 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +128 | +64.0 |
| MAX FOR POSITIONING | 5 | 5 | 2 | 0.67 | +1 | +0.6 |
| NEARER NOT NEEDED | 33 | 28 | 2 | 0.67 | +70 | +34.9 |
| PROMISE READS THE TABLE | 4 | 4 | 2 | 0.67 | -71 | -35.6 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +8 | +4.2 |
| SET UP BY THE SET | 7 | 6 | 2 | 0.67 | -52 | -26.0 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +8 | +3.8 |
| SUPPORT NARROWED | 2 | 2 | 2 | 0.67 | -33 | -16.6 |
| WHOLE FIGHT DANGER | 6 | 6 | 2 | 0.67 | +441 | +220.6 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 5 | 3 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -2 | -2.5 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +6 | +5.5 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | -2 | -1.8 |
| HIS CHARGE DENIED | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| HIS MOVE AND SHOT | 24 | 22 | 1 | 0.33 | +0 | +0.0 |
| HUNT IN PAIRS | 3 | 3 | 1 | 0.33 | +58 | +58.1 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +1 | +1.2 |
| LONG SHOT | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| MANOEUVRE | 9 | 9 | 1 | 0.33 | +42 | +41.5 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +280 | +279.7 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -52 | -51.9 |
| OVERRUNS AWAY | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| REDIRECT BY WHAT IT STOPS | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| REDIRECT COUNTER | 8 | 6 | 1 | 0.33 | +68 | +68.2 |
| SURE REACH TOGETHER | 6 | 6 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +37 | +36.7 |
| BACKUP TARGETS | 2 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 14 | 14 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 3 | 3 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 52 | 52 | 0 | 0.00 | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 9 | 9 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 6 | 6 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 24 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GUN FIGURES | 7 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 35 | 35 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 81 | 81 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 29 | 27 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 8 | 6 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 27 | 25 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 93 | 93 | 0 | 0.00 | - | - |
| HONEST WORTH | 10 | 10 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 7 | 7 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LOST AFTER ESCAPE | 7 | 7 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 8 | 8 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 5 | 5 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 16 | 16 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 29 | 27 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 8 | 8 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 21 | 15 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 32 | 28 | 0 | 0.00 | - | - |
| ONE ROUTE | 5 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 282 | trace | - | - | - | - |
| REAL GROUND | 5 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 2 | 2 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 6 | 6 | 0 | 0.00 | - | - |
| RUN DOWN | 7 | 7 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 2 | 1 | 0 | 0.00 | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 84 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 18 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 25 | 16 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 2 | 2 | 0 | 0.00 | - | - |
| STANDS STILL | 369 | 361 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 10 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 12 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 22 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 2 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 8 | not checked | - | - | - | - |
| THE TABLE BINDS | 266 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 4 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p4

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.67 | 3.33 | 32.5 |
| PROMISE BY ITS OWN SUM | rule | 4.67 | - | 50.4 |
| ARMY TABLE | rule | 1.33 | 0.33 | 34.5 |
| JOINT CHARGE NOW | rule | - | 1.33 | 205.1 |
| WHO GETS IN | rule | - | 1.00 | 271.1 |
| BEST PRIZE | rule | - | 0.67 | 82.4 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.33 | 27.6 |
| RULE SWITCHED OFF | gate | 0.67 | - | 22.8 |
| SET UP BY THE SET | rule | - | 0.67 | 26.0 |
| SUPPORT NARROWED | rule | 0.33 | 0.33 | 16.6 |
| AFTERMATH BAND | gate | 0.33 | - | 1.8 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 1.5 |
| CHAFF PASSED | rule | 0.33 | - | 2.5 |
| DEPLOY BY FIGURES | rule | 0.33 | - | 6.9 |
| FRIENDS SHOTS CHECKED | rule | 0.33 | - | 1.8 |
| LONE CHARACTER SAFE SPOT | gate | 0.33 | - | 82.2 |
| MARCH OF THE TABLE | rule | - | 0.33 | 51.9 |
| NO REASON | gate | - | 0.33 | 29.4 |
| PROMISE READS THE TABLE | rule | 0.33 | - | 80.3 |
| REDIRECT WEIGHED | rule | - | 0.33 | 11.5 |

### Plans: ccut-c940641-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 33% | 33 | 36 | 109% |
| Mine | join | 2.0 | 83% | 96 | 0 | 0% |
| Mine | move | 40.0 | 98% | 1269 | 0 | 0% |
| Mine | shoot | 19.0 | 42% | 439 | 637 | 145% |
| Opponent | charge | 1.3 | 25% | 75 | 32 | 42% |
| Opponent | join | 1.0 | 100% | 54 | 0 | 0% |
| Opponent | move | 24.3 | 96% | 770 | 0 | 0% |
| Opponent | shoot | 4.7 | 50% | 219 | 48 | 22% |
| Opponent | support | 0.7 | 50% | 29 | 0 | 0% |

### Battle groups: ccut-c940641-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.3 | 25% | 0% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 1.3 | 50% | 50% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Character | 13 | 2 (13) | 2 | 0 | 8 | 31% | 3.1 | 4 (6) | 0 (6) | 0 (1) | 3 (11) | 0 (2) |
| Mine | Clean-up | 4 | 18 (4) | 18 | 0 | 0 | 75% | 1.0 | 0 (1) | 0 (1) | 36 (2) | 18 (4) | - |
| Mine | Fast | 3 | 0 (3) | 0 | 0 | 0 | 33% | 1.0 | - | 0 (1) | 0 (2) | 0 (3) | - |
| Mine | Hammer | 4 | 134 (4) | 12 | 121 | 0 | 25% | 2.7 | 5 (1) | 224 (3) | - | 134 (4) | - |
| Mine | Shooter | 8 | 81 (8) | 3 | 78 | 5 | 25% | 2.3 | 148 (1) | 118 (4) | 9 (3) | 74 (6) | 98 (2) |
| Mine | War machine | 17 | 10 (17) | 10 | 0 | 16 | 18% | 1.4 | 0 (4) | 18 (9) | 0 (4) | 0 (3) | 12 (14) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 63 | 67% | 4.0 | 0 (2) | - | 0 (1) | 0 (3) | - |
| Opponent | Character | 10 | 5 (10) | 5 | 0 | 2 | 20% | 4.4 | 7 (3) | 0 (5) | 14 (2) | 3 (9) | 14 (1) |
| Opponent | Clean-up | 1 | 59 (1) | 59 | 0 | 0 | 0% | 4.0 | - | 59 (1) | - | 59 (1) | - |
| Opponent | Fast Hammer | 3 | 25 (3) | 0 | 25 | 0 | 67% | 6.0 | 0 (1) | 84 (1) | 0 (1) | 35 (2) | 0 (1) |
| Opponent | Holder | 6 | 76 (6) | 0 | 76 | 26 | 50% | 2.3 | 0 (1) | 89 (5) | - | 94 (4) | 44 (2) |
| Opponent | War machine | 2 | 55 (2) | 55 | 0 | 0 | 0% | 1.0 | - | 109 (1) | 0 (1) | - | 55 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 1.0 | 0 (1) | 0 (1) | - | 0 (2) | - |

### Charged fights: ccut-c940641-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 3 | 107 | 20 | 1.0 | 1.0 | 20 | 20 | +0 | 1 of 3 | 2 of 3 | - | +0 |
| Opponent | Grand Cathay | 1 | 180 | 0 | 1.0 | 3.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | +0 | - |
| Opponent | Vampire Counts | 1 | 0 | 160 | 3.0 | 1.0 | 53 | 17 | +37 | 1 of 3 | 2 of 3 | - | +37 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 60 | 53 | 1.3 | 1.5 | 40 | 12 | +28 | 2 of 4 | 3 of 4 | +0 | +37 |

### Effective charges: ccut-c940641-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 3 | 1 (net -60) | 0 | 0 | 0 | 0 | 2 (net +30) | 0 | 0% (0 of 3) |
| Opponent | Grand Cathay | 1 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0% (0 of 1) |
| Opponent | Vampire Counts | 3 | 0 | 0 | 0 | 0 | 0 | 1 (net +95) | 2 | 0% (0 of 1) |

### Charged fights, damage counted: ccut-c940641-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 60 | 494 | -60 | 0 | 60 | -60 | -100.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 55 | 86 | +30 | 58 | 0 | +58 | +105.0 |
| Mine | All fights | 3 | 57 | 222 | +0 | 38 | 20 | +18 | +32.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 161 | 95 | +95 | 95 | 0 | +95 | +59.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 756 | 183 | +0 | 26 | 98 | -72 | -9.6 |
| Opponent | No odds | 2 | 106 | 144 | +8 | 32 | 25 | +8 | +7.1 |
| Opponent | All fights | 4 | 282 | 142 | +28 | 47 | 37 | +9 | +3.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p4 | move | 14 | 3 (21%) | 1 (7%) | 2 (14%) | 9 (64%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0524 |
| Clockwork Compass | Opponent | L0612 |
| Invocation of Nehek | Opponent | L0524 |
| Ring of Doom | Opponent | L0612 |
| Ring of Jet | Opponent | L0612 |

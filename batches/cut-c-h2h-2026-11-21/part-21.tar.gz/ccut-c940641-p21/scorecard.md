# Doctrine scorecard: ccut-c940641-p21

### Scorecard: ccut-c940641-p21

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1531 | 1 | 1 | Mine | no | 1 | 2 | 6 | 2 | 0 | 0 | 0 | 60 |
| L1531 | 1 | 1 | Opponent | no | 1 | - | 0 | 1 | 2 | 0 | 0 | 535 |
| L1629 | 3 | 1 | Mine | no | 6 | 2 | 4 | 0 | 1 | 0 | 0 | 200 |
| L1629 | 3 | 1 | Opponent | no | 0 | 3 | 1 | 3 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Mine | yes | - | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Opponent | yes | - | 3 | 2 | 4 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 3.5 | 2.3 | 4.3 | 0.7 | 0.3 | 0.0 | 0.0 | 86.7 |
| **Average** | | | Opponent | 33% | 0.5 | 3.0 | 1.0 | 2.7 | 1.0 | 0.0 | 0.0 | 178.3 |

### KPIs: ccut-c940641-p21

Rules off - Mine only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 16) | 0% (0 of 16) | 0% (0 of 32) |
| Winner chose to follow up after the loser gave ground |  | 100% (10 of 10); on the table 100% | 50% (1 of 2); on the table 50% | 92% (11 of 12); on the table 92% |
| Winner chose to pursue after the loser fell back in good order |  | - | 50% (1 of 2); on the table 50% | 50% (1 of 2); on the table 50% |
| Winner chose to pursue after the loser fled |  | 50% (2 of 4); on the table 75% | 50% (1 of 2); on the table 50% | 50% (3 of 6); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 86% (12 of 14); on the table 93% | 50% (3 of 6); on the table 50% | 75% (15 of 20); on the table 80% |
| Magic missiles tried each own turn | 50%+ | - | 17% (2 of 12) | 17% (2 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 29% (2 of 7) | 29% (2 of 7) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 56% (5 of 9) | 56% (5 of 9) |
| Points that never fought | lower | 35% (2121 of 6000) | 34% (2047 of 5999) | 35% (4168 of 11999) |
|   infantry points that never fought | lower | 43% (573 of 1332) | 65% (553 of 855) | 51% (1126 of 2187) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 45% (9 of 20) | 84% (21 of 25) | 67% (30 of 45) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.3 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (3 of 3); 1.3 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 47% (2394 of 5135) | 76% (4128 of 5430) | 62% (6522 of 10565) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.7 (50%) | 1.7 (50%) |
| FLEEING: fleeing | - | 1.7 (50%) | 1.7 (50%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.7 | 1.3 | 1.0 | 0.7 | 2.7 |
| not cast | 6.3 | 0.7 | 1.0 | 3.3 | 17.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (50%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (50%) | 0.0 (0%) |
| GONE: slain | 1.0 (16%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.3 (5%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.7 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 5.0 (79%) | 0.0 (0%) | 1.0 (100%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.3 (94%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 0.0 a game | 0.5 a game |
| stood (cast and not dispelled) | - | - | - |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 52% (44 of 85) | 20% (1 of 5) | 50% (45 of 90) |
|   cavalry | 78% (7 of 9) | 50% (1 of 2) | 73% (8 of 11) |
|   character | 33% (3 of 9) | 0% (0 of 3) | 25% (3 of 12) |
|   chariot | 33% (2 of 6) | - | 33% (2 of 6) |
|   infantry | 56% (23 of 41) | - | 56% (23 of 41) |
|   monster | 33% (5 of 15) | - | 33% (5 of 15) |
|   war machine | 80% (4 of 5) | - | 80% (4 of 5) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (20%) | 0.0 (0%) | 2.7 (18%) |
| CHARGED: it charged | 2.7 (20%) | 0.3 (25%) | 3.0 (20%) |
| IN COMBAT: it fought this turn or the last | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |
| MOVED: a war machine that moved | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 4.3 (32%) | 0.3 (25%) | 4.7 (31%) |
| ONLY IN COMBAT: the only targets were in combat | 2.3 (17%) | 0.0 (0%) | 2.3 (16%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (7%) | 0.3 (25%) | 1.3 (9%) |
| OTHER BAR | 0.0 (0%) | 0.3 (25%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.0 | 1.7 | 78% | 3.3 pts | 10 pts |
| character | 2.0 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 0.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 12.0 | 2.3 | 86% | 7.8 pts | 94 pts |
| monster | 1.7 | 0.3 | 80% | 3.8 pts | 6 pts |
| war machine | 1.3 | 0.0 | 100% | 0.0 pts | 0 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 7.3 | 2.3 | 4.8 |
| Charges that made contact a game | 6.0 | 1.0 | 3.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.75 declared, 0.75 contact (4 units) | 1.33 declared, 0.67 contact (3 units) | 1.00 declared, 0.71 contact (7 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.95 declared, 0.75 contact (20 units) | 0.16 declared, 0.05 contact (19 units) | 0.56 declared, 0.41 contact (39 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 100% (5 of 5) | 100% (3 of 3) | 100% (2 of 2) | 100% (10 of 10) |
| Character in a unit | 100% (3 of 3) | - | - | 100% (3 of 3) |
| Character on its own | 75% (3 of 4) | 100% (2 of 2) | 44% (4 of 9) | 60% (9 of 15) |
| Chariot | 0% (0 of 1) | - | - | 0% (0 of 1) |
| Infantry | 57% (4 of 7) | 0% (0 of 3) | - | 40% (4 of 10) |
| Monster | 67% (4 of 6) | - | - | 67% (4 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 1 | 71% (5 of 7); on the table 86% | - | 43% | 43% (3 of 7) | 100% (2 of 2); 7.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (2 of 2); on the table 100% | - | 32% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | 100% (5 of 5); on the table 100% | - | 31% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 0% (0 of 3); on the table 0% | 17% (1 of 6) | 34% | 100% (6 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | 100% (3 of 3); on the table 100% | 17% (1 of 6) | 34% | 79% (15 of 19) | 100% (1 of 1); 0.5 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p21, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (2) | 36% (4) | 46% (6) |
| ...free all their last turn and able to turn (per game) | 0.00 | 1.00 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.67 | 0.33 | 1.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.67 | 0.67 |

### Quality by phase: ccut-c940641-p21

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 4.3 |
| Strategy | Charge objectives carried out (made contact) | 72% (13 of 18) | 29% (2 of 7) |
| Strategy | Shoot objectives carried out (shot that target) | 32% (6 of 19) | 0% (0 of 3) |
| Strategy | Support requests answered (helper made contact too) | 75% (3 of 4) | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 100% (1 of 1) | 33% (1 of 3) |
| Strategy | Lone characters that fought | 88% (7 of 8) | 80% (8 of 10) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 0.7 | 2.7 |
| Movement | Points that never moved of their own | 86.7 | 178.3 |
| Movement | Fights charged into per game | 4.7 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 11, net +0 | 0 of 3 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 11, net +0 | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 11, net +140 | 2 of 3, net +50 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 of 11, net +160 | 1 of 3, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 15.3 | 0.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (20 of 46) | 50% (1 of 2) |
| Shooting | Points destroyed by shooting units | 48.7 | 0.0 |
| Shooting | War machine shots | 1.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 100% (4 of 4) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | - | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 100% (1 of 1) |
| Magic | Wounds caused by magic missiles | 2.0 | - |
| Magic | Wounds caused by other spells | 2.0 | - |
| Magic | Points destroyed by magic (all spells) | 95.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 1.3 / 1.7 / 0.0 | 0.7 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 305.3 | 125.7 |
| Combat | Points run down | 229.7 | 0.0 |
| Combat | Net points per charged fight, damage counted | +113 | +56 |
| Combat | Net per 100 charger points, damage counted | +28.0 | +13.9 |
| Combat | First round won (charged fights) | 79% | 100% |
| Combat | Net points per charged fight | +95 | +33 |
| Combat | Net points per supported fight / lone fight | +108 / +93 | - / +33 |
| Combat | Charged fights on a top-3 enemy unit | 6 of 14 | 0 of 3 |
| Game | Points lost | 185.7 | 662.3 |
| Game | VP from objectives | 1023.3 | 516.7 |
| Game | Lone holders (player turns) | 3.5 | 0.5 |

- Mine won / drew / lost: 3 / 0 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +1006 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 848
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ccut-c940641-p21

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.3 | +10.3 | 0.0 | 0.0 |
| ARMY TABLE | 27.7 | +331.8 | 0.0 | 0.0 | 27.7 | -56.7 | 0.0 | 488.7 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +1.1 | 0.0 | 28.3 |
| BACKUP TARGETS | - | - | - | - | 1.0 | +7.1 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.3 | +12.9 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 1.3 | +0.0 | 0.0 | 66.7 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 3.0 | +30.0 | 311.0 | 0.0 | 1.3 | +5.1 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 0.7 | +3.3 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +9.4 | 0.0 | 0.0 | 0.7 | +4.8 | 0.0 | 0.0 |
| CHARGE LOSSES | 2.7 | -122.7 | 0.0 | 0.0 | 20.3 | -1522.8 | 0.0 | 618.3 |
| CHARGE NOT DECLARED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE NOW FIRST | 2.3 | +0.0 | 269.0 | 92.3 | 1.0 | +0.0 | 33.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 9.3 | +0.0 | 0.0 | 26.7 | 11.3 | +0.0 | 0.0 | 76.7 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 56.7 |
| COVER ONCE | 7.3 | -431.1 | 0.0 | 0.0 | 9.3 | -880.0 | 0.0 | 103.7 |
| DENIED BY THE FIGHT | 1.0 | -2.0 | 494.0 | 0.0 | 0.3 | -0.3 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 7.3 | -26.0 | 0.0 | 33.3 | 6.3 | +63.8 | 0.0 | 124.0 |
| DUEL STOPS AT THE KILL | 0.7 | -160.4 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 3.3 | +29.8 | 679.3 | 92.3 | 1.0 | +7.6 | 60.0 | 164.7 |
| FALL BACK GOOD ORDER | 3.3 | +1.8 | 377.0 | 92.3 | 2.0 | +0.0 | 26.7 | 181.3 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 19.7 | +239.8 | 0.0 | 386.0 |
| FEATURE BUFFS | 1.3 | +19.1 | 0.0 | 0.0 | 0.7 | +14.8 | 0.0 | 0.0 |
| FIGHT LIFT | 0.3 | +51.9 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 2.7 | +47.0 | 575.7 | 92.3 | 0.7 | +8.5 | 0.0 | 16.7 |
| FIRE IN ORDER | 0.7 | +0.0 | 0.0 | 26.7 | - | - | - | - |
| FIVE ACTION | 89.0 | +7841.3 | 1709.7 | 371.3 | 72.3 | +4354.7 | 60.0 | 1272.0 |
| FLANK NOT WEIGHED | 3.0 | +0.0 | 0.0 | 0.0 | 13.3 | +0.0 | 0.0 | 322.7 |
| FOLLOW UP WEIGHED | 2.0 | +383.5 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 6.7 | +715.6 | 1049.3 | 184.7 | 2.3 | +70.1 | 60.0 | 181.3 |
| FREED FROM HIS FIGHT | - | - | - | - | 7.7 | +0.0 | 0.0 | 0.0 |
| FRIEND CHARGES FIRST | 0.7 | -7.6 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.7 | -4.1 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 1.0 | -11.6 | 56.7 | 0.0 | - | - | - | - |
| GOAL WALK | 9.7 | +775.2 | 0.0 | 0.0 | 7.7 | +633.3 | 0.0 | 0.0 |
| HARD STAY DROPPED | 3.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 38.7 |
| HE REFORMS ONCE FREED | - | - | - | - | 5.0 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | 1.3 | +0.0 | 494.0 | 92.3 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 0.7 | +0.0 | 0.0 | 0.0 | 17.0 | +0.0 | 0.0 | 453.7 |
| HIS CHARGE DENIED | 1.0 | +122.7 | 494.0 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 3.3 | +0.0 | 0.0 | 0.0 | 9.0 | +0.0 | 0.0 | 224.0 |
| HIS LEGAL MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 124.0 |
| HIS MOVE AND SHOT | 1.7 | -24.6 | 0.0 | 0.0 | 4.3 | -40.9 | 0.0 | 413.0 |
| HIS MOVE AS HE DECIDES | 36.0 | +10.0 | 770.7 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 26.0 | +0.0 | 0.0 | 356.7 |
| HIS ONE MOVE | 22.7 | +2.6 | 0.0 | 26.7 | - | - | - | - |
| HIS ONE QUARTER | 6.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 20.0 |
| HIS OWN BEST MOVE | 2.7 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 154.0 |
| HIS RANDOM MOVE | 16.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 3.3 | +45.7 | 0.0 | 53.3 | 32.7 | +651.3 | 0.0 | 420.7 |
| HIS SHOTS BY HIS RUN | 8.3 | +126.8 | 0.0 | 0.0 | 38.7 | +650.4 | 0.0 | 911.7 |
| HIS TURN DENIED | - | - | - | - | 1.0 | +10.9 | 26.7 | 181.3 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 16.0 | +0.0 | 0.0 | 0.0 | 12.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 10.7 | +951.3 | 0.0 | 0.0 | 7.7 | +732.3 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 4.7 | -175.1 | 406.7 | 92.3 | 2.0 | -90.7 | 60.0 | 181.3 |
| HUNT RESULT | 0.3 | +87.3 | 0.0 | 0.0 | - | - | - | - |
| HUNT THE GUNS | 0.3 | +92.9 | 65.0 | 0.0 | - | - | - | - |
| IDLE COST | - | - | - | - | 14.3 | -192.5 | 0.0 | 218.3 |
| JOINT CHARGE NOW | 2.3 | +201.8 | 742.3 | 92.3 | 0.7 | +14.6 | 0.0 | 16.7 |
| JOINT ON THE TABLE | 0.3 | +109.0 | 164.7 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +91.8 | 0.0 | 0.0 | 1.0 | +8.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 12.3 | +0.0 | 495.0 | 53.3 | 4.3 | +0.0 | 0.0 | 193.7 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 0.3 | +8.4 | 83.7 | 0.0 |
| LONE WIZARD KEPT IN | 0.3 | +5.0 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 0.3 | +0.7 | 164.7 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 3.0 | +13.9 | 723.7 | 184.7 | 1.3 | +3.5 | 0.0 | 16.7 |
| MANOEUVRE | 0.7 | -0.2 | 0.0 | 0.0 | 1.0 | +194.4 | 0.0 | 83.7 |
| MARCH CHECK | 0.7 | +37.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.8 | 0.0 | 65.0 |
| MARCH OVER CASTS | 0.3 | +125.9 | 0.0 | 0.0 | 0.3 | +46.4 | 0.0 | 65.0 |
| MARCH WHEELS ONLY | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.7 | +28.1 | 0.0 | 26.7 | 4.0 | +78.2 | 0.0 | 63.3 |
| MEETS IN TIME | 3.7 | +211.0 | 0.0 | 0.0 | 3.3 | +109.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 3.0 | +42.6 | 0.0 | 0.0 | 1.0 | +20.6 | 0.0 | 65.0 |
| MISSILES NEXT TURN | 3.0 | +22.5 | 0.0 | 0.0 | 1.3 | +11.5 | 0.0 | 65.0 |
| MOVE ORDER | 2.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 10.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 6.7 | +725.8 | 0.0 | 26.7 | 6.7 | +593.9 | 0.0 | 154.0 |
| MOVES UNITS SPELL | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 9.7 | +423.4 | 0.0 | 26.7 | 6.0 | +264.2 | 0.0 | 140.3 |
| NEXT CHARGE BY LIST | 4.0 | +596.5 | 0.0 | 0.0 | 4.0 | +229.6 | 0.0 | 30.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.7 | -30.5 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 6.3 | -294.2 | 1049.3 | 184.7 | 2.0 | -28.2 | 60.0 | 164.7 |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.7 | +0.0 | 0.0 | 38.7 |
| NOT WORTH A CAST | 1.0 | -0.6 | 0.0 | 0.0 | 0.7 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 4.7 | -226.8 | 56.7 | 0.0 | 4.0 | -160.8 | 0.0 | 67.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.7 | -101.8 | 0.0 | 0.0 | 6.3 | -136.9 | 0.0 | 241.7 |
| ONE JOINT FIGURE | 2.0 | +256.1 | 577.7 | 92.3 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 3.7 | +21.3 | 0.0 | 0.0 | 2.7 | -13.4 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.7 | -76.3 | 0.0 | 0.0 | 0.3 | -31.2 | 0.0 | 0.0 |
| ONE ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +11.2 | 28.3 | 0.0 | 1.3 | +71.2 | 60.0 | 164.7 |
| OVERRUNS AWAY | - | - | - | - | 0.7 | +8.4 | 0.0 | 0.0 |
| PATHS CROSS | - | - | - | - | 1.0 | +177.5 | 0.0 | 83.7 |
| PLAN RESULT | 41.0 | +1388.6 | 434.0 | 304.7 | 37.0 | +74.6 | 200.7 | 927.3 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 10.0 | -200.6 | 0.0 | 26.7 | 7.7 | -203.2 | 0.0 | 124.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | 1.0 | -6.4 | 116.0 | 0.0 | - | - | - | - |
| PURSUES BIG PREY | - | - | - | - | 0.3 | -111.6 | 0.0 | 0.0 |
| QUARTER ODDS | 24.3 | +3155.1 | 83.7 | 0.0 | 19.3 | +2453.5 | 33.3 | 70.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.0 | +57.3 | 0.0 | 113.3 |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.3 | +135.5 | 0.0 | 26.7 | 2.3 | +108.8 | 0.0 | 88.3 |
| REDIRECT FOR A FRIEND IN REACH | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 38.3 |
| REDIRECT WEIGHED | - | - | - | - | 1.0 | +12.9 | 0.0 | 181.3 |
| REFORMS TO MEET IT | 3.3 | -68.1 | 0.0 | 0.0 | 1.3 | -38.9 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 0.3 | +9.0 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 5.3 | +333.9 | 909.0 | 184.7 | 2.0 | -45.3 | 60.0 | 181.3 |
| ROUNDS AFTER TERROR | 0.7 | -21.2 | 112.0 | 0.0 | 1.3 | -40.3 | 26.7 | 181.3 |
| RUN DOWN | 4.0 | -98.6 | 919.3 | 184.7 | 2.3 | -11.4 | 60.0 | 181.3 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -65.9 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | -2.0 | 0.0 | 0.0 | 0.7 | +64.9 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +18.4 | 56.7 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | 2.0 | +50.2 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 0.7 | -25.3 | 0.0 | 0.0 | 3.0 | -50.2 | 0.0 | 184.7 |
| SET UP BY THE SET | 2.3 | -0.1 | 16.7 | 0.0 | 3.0 | +33.5 | 0.0 | 184.7 |
| SHOOTERS IN TWO RANKS | 1.0 | +2.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 5.7 | +0.0 | 0.0 | 66.7 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.7 | +39.8 | 30.0 | 0.0 | 1.0 | +7.2 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.7 | -7.4 | 229.7 | 33.3 | - | - | - | - |
| SHOT RISK POINTS | 2.3 | -30.4 | 0.0 | 0.0 | 21.0 | -313.6 | 0.0 | 739.7 |
| SHOTS AFTER THE MOVES | 3.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOTS IN THE MOVE | 12.7 | +245.5 | 0.0 | 93.3 | 0.3 | +4.3 | 0.0 | 28.3 |
| SPELL WORTH | 1.7 | +85.0 | 26.7 | 0.0 | 2.0 | +6.3 | 40.0 | 40.0 |
| SPELLS IN THE FIGHT | 0.3 | +0.5 | 16.7 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 4.7 | +0.0 | 0.0 | 0.0 | 10.7 | +0.0 | 0.0 | 305.0 |
| STAND AND SHOOT | 0.3 | -1.8 | 28.3 | 0.0 | 1.0 | -5.5 | 26.7 | 164.7 |
| STANDS STILL | 34.0 | +0.0 | 660.3 | 133.3 | 10.3 | +0.0 | 0.0 | 213.3 |
| STAY WORTH | 13.0 | +25.2 | 388.3 | 100.0 | 0.3 | +5.0 | 0.0 | 164.7 |
| STOPS | 0.3 | +4.0 | 65.0 | 0.0 | - | - | - | - |
| STRIKE BY THE ODDS | 1.0 | +8.5 | 83.7 | 0.0 | 0.3 | +0.1 | 0.0 | 0.0 |
| STUBBORN BY POINTS | 0.3 | +18.3 | 0.0 | 92.3 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 56.7 |
| STUPIDITY NEXT TURN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 4.7 | +368.6 | 0.0 | 26.7 | 8.0 | +872.1 | 0.0 | 130.0 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 4.7 | +368.6 | 0.0 | 26.7 | 8.0 | +872.1 | 0.0 | 130.0 |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 112.0 |
| THE PROMISE ADDS | 0.3 | -30.9 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.3 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 62.0 | 93.3 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 39.7 | +0.0 | 0.0 | 93.3 | 35.3 | +0.0 | 0.0 | 488.7 |
| TIED UP BY THE SUM | 2.0 | +288.9 | 158.3 | 0.0 | 1.7 | +201.4 | 60.0 | 164.7 |
| TIME ON OUR SIDE | 40.3 | +492.3 | 130.0 | 26.7 | - | - | - | - |
| WAITS AGAIN | 3.7 | +0.0 | 0.0 | 26.7 | 3.0 | +0.0 | 0.0 | 30.0 |
| WEAPON BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 28.3 |
| WHO FIGHTS | 1.3 | -132.6 | 248.3 | 92.3 | - | - | - | - |
| WHO GETS IN | 1.3 | +257.0 | 658.7 | 92.3 | - | - | - | - |
| WHO HITS BACK | 0.3 | +5.4 | 0.0 | 0.0 | 0.7 | +154.4 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.0 | -107.2 | 0.0 | 0.0 | 4.0 | -1126.8 | 0.0 | 83.7 |
| WHOLE FIGHT GAIN | 2.0 | +167.2 | 577.7 | 92.3 | - | - | - | - |
| WOUNDS ON THE RANKS | 0.3 | +1.9 | 0.0 | 0.0 | 3.7 | +114.7 | 0.0 | 83.7 |

### Rule changes: ccut-c940641-p21

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 166 | 166 | 97 | 32.33 | +696 | +7.2 |
| HIS MOVE AS HE DECIDES | 108 | 108 | 78 | 26.00 | +0 | +0.0 |
| HIS MOVE WHY | 78 | 78 | 60 | 20.00 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 55 | 55 | 52 | 17.33 | +2815 | +54.1 |
| LEGAL CHARGES ONLY | 50 | 50 | 50 | 16.67 | +0 | +0.0 |
| FIVE ACTION | 484 | 467 | 37 | 12.33 | +2397 | +64.8 |
| QUARTER ODDS | 131 | 130 | 33 | 11.00 | +3500 | +106.0 |
| THE TABLE AGAIN | 36 | 36 | 30 | 10.00 | +0 | +0.0 |
| OFF BEST | 26 | 26 | 26 | 8.67 | -1163 | -44.7 |
| DEPLOY BY FIGURES | 41 | 41 | 25 | 8.33 | +230 | +9.2 |
| MOVE TO CHARGE COMPUTED | 40 | 35 | 20 | 6.67 | +846 | +42.3 |
| HIS ONE MOVE | 68 | 67 | 18 | 6.00 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 53 | 53 | 17 | 5.67 | -1211 | -71.2 |
| FOUR ROUNDS | 27 | 26 | 16 | 5.33 | +928 | +58.0 |
| MOVE ORDER | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| HARD STAY DROPPED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 141 | 136 | 13 | 4.33 | +90 | +6.9 |
| TIME ON OUR SIDE | 121 | 102 | 13 | 4.33 | +73 | +5.6 |
| GOAL WALK | 52 | 51 | 12 | 4.00 | +886 | +73.8 |
| HIS SHOT LIST | 108 | 105 | 11 | 3.67 | +48 | +4.4 |
| NEXT CHARGE BY LIST | 24 | 24 | 11 | 3.67 | +386 | +35.1 |
| SUPPORT ADDS | 38 | 36 | 11 | 3.67 | +586 | +53.3 |
| SUPPORT WORKED OUT | 38 | 36 | 11 | 3.67 | +586 | +53.3 |
| COVER ONCE | 50 | 32 | 10 | 3.33 | +236 | +23.6 |
| RISK BY ARC | 22 | 22 | 10 | 3.33 | +293 | +29.3 |
| JOINT CHARGE NOW | 9 | 9 | 9 | 3.00 | +649 | +72.1 |
| MAX FOR POSITIONING | 20 | 17 | 9 | 3.00 | +37 | +4.1 |
| THE RISK READS HIS RUN | 18 | 18 | 9 | 3.00 | +0 | +0.0 |
| TIED UP BY THE SUM | 11 | 10 | 9 | 3.00 | +254 | +28.2 |
| CHARGE LOSSES | 69 | 67 | 8 | 2.67 | +960 | +120.0 |
| IDLE COST | 43 | 33 | 8 | 2.67 | +40 | +5.0 |
| MEETS IN TIME | 21 | 21 | 8 | 2.67 | +429 | +53.6 |
| REDIRECT FOR A FRIEND IN REACH | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 7 | 7 | 7 | 2.33 | +1151 | +164.4 |
| LANE BY FIGURES | 7 | 7 | 7 | 2.33 | +300 | +42.8 |
| CAST JOB | 13 | 13 | 6 | 2.00 | +9 | +1.6 |
| HOLDS AMBUSHERS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 18 | 18 | 6 | 2.00 | +963 | +160.5 |
| OPENS UP | 5 | 5 | 5 | 1.67 | +179 | +35.8 |
| RANDOM MOVE BY FIGURES | 9 | 9 | 5 | 1.67 | +172 | +34.4 |
| SHOOTS FROM THE BEST SPOT | 11 | 11 | 5 | 1.67 | +17 | +3.3 |
| CHARGE NOW FIRST | 10 | 10 | 4 | 1.33 | -82 | -20.4 |
| ONE FIGHT FORMULA | 33 | 21 | 4 | 1.33 | +11 | +2.9 |
| REDIRECT COUNTER | 14 | 12 | 4 | 1.33 | +197 | +49.4 |
| SET UP BY THE SET | 16 | 16 | 4 | 1.33 | +163 | +40.7 |
| SHOT RISK POINTS | 70 | 67 | 4 | 1.33 | +12 | +3.1 |
| STAY WORTH | 40 | 34 | 4 | 1.33 | +31 | +7.7 |
| THE ROW IN ITS ORDER | 31 | 4 | 4 | 1.33 | +0 | +0.0 |
| WHO GETS IN | 4 | 4 | 4 | 1.33 | +771 | +192.8 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +43 | +14.3 |
| MISSILES IN THE MOVE | 12 | 7 | 3 | 1.00 | +20 | +6.8 |
| NEARER NOT NEEDED | 47 | 45 | 3 | 1.00 | +121 | +40.3 |
| ONE PROMISE A TARGET | 3 | 3 | 3 | 1.00 | -323 | -107.6 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +533 | +177.5 |
| PROMISE SHOT AWAY | 3 | 3 | 3 | 1.00 | -19 | -6.4 |
| REDIRECT WEIGHED | 3 | 3 | 3 | 1.00 | +288 | +95.9 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +6 | +2.0 |
| STRIKE BY THE ODDS | 4 | 4 | 3 | 1.00 | +10 | +3.4 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +377 | +125.8 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| EXACT ROUND | 13 | 12 | 2 | 0.67 | +57 | +28.7 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MARCH CHECK | 2 | 2 | 2 | 0.67 | +12 | +5.9 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -2 | -1.2 |
| NO DOUBLE ROUNDS | 25 | 24 | 2 | 0.67 | +26 | +13.2 |
| ONE JOINT FIGURE | 6 | 6 | 2 | 0.67 | +293 | +146.6 |
| SEARCH SPOT | 3 | 3 | 2 | 0.67 | +195 | +97.4 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +31 | +30.8 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -2 | -2.5 |
| CANNON PLANNED TARGET | 4 | 4 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -273 | -272.7 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALLS SHORT | 59 | 50 | 1 | 0.33 | +0 | +0.0 |
| FEATURE BUFFS | 6 | 6 | 1 | 0.33 | +7 | +7.0 |
| FIGHT TO THE END | 10 | 10 | 1 | 0.33 | +56 | +56.0 |
| HIS CHARGE DENIED | 3 | 3 | 1 | 0.33 | +56 | +56.0 |
| HIS MOVE AND SHOT | 18 | 17 | 1 | 0.33 | +5 | +5.4 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.33 | +327 | +327.2 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +15 | +15.0 |
| LOST AFTER ESCAPE | 13 | 13 | 1 | 0.33 | +56 | +56.0 |
| MANOEUVRE | 5 | 5 | 1 | 0.33 | +583 | +583.2 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| OVERRUNS AWAY | 2 | 2 | 1 | 0.33 | +7 | +7.4 |
| PURSUES BIG PREY | 1 | 1 | 1 | 0.33 | -335 | -334.8 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +27 | +27.1 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +55 | +55.2 |
| SET CREDITED ONCE | 11 | 11 | 1 | 0.33 | +0 | +0.2 |
| SHOTS IN THE MOVE | 39 | 29 | 1 | 0.33 | +13 | +13.1 |
| SPELLS IN THE FIGHT | 1 | 1 | 1 | 0.33 | +1 | +1.3 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +55 | +55.0 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -177 | -177.4 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 6 | 6 | 1 | 0.33 | +81 | +81.2 |
| WOUNDS ON THE RANKS | 12 | 12 | 1 | 0.33 | +61 | +61.3 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 3 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 62 | 57 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 16 | 16 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 49 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 23 | 23 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 2 | 2 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 15 | 15 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 4 | 4 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 53 | 51 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 37 | 35 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 31 | 29 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 34 | 33 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 28 | 26 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 48 | 46 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 5 | 5 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 3 | 3 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 85 | 85 | 0 | 0.00 | - | - |
| HONEST WORTH | 20 | 19 | 0 | 0.00 | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| KEPT FROM ITS LAST STOP | 10 | 10 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 1 | not checked | - | - | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 3 | 3 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 13 | 10 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 5 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 19 | 13 | 0 | 0.00 | - | - |
| ONE ROUTE | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 234 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 1 | not checked | - | - | - | - |
| REAL GROUND | 3 | 3 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 14 | 14 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 6 | 6 | 0 | 0.00 | - | - |
| RUN DOWN | 19 | 19 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 24 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 9 | 9 | 0 | 0.00 | - | - |
| SPELL WORTH | 11 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 46 | 43 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS STILL | 133 | 129 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 2 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 21 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 3 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 14 | not checked | - | - | - | - |
| THE TABLE BINDS | 225 | not checked | - | - | - | - |
| WAITS AGAIN | 20 | 18 | 0 | 0.00 | - | - |
| WHO FIGHTS | 4 | 4 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p21

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| ARMY TABLE | rule | 4.67 | 6.00 | 79.5 |
| JOB FIRST | gate | 3.67 | 3.67 | 47.2 |
| PROMISE BY ITS OWN SUM | rule | 3.67 | 2.00 | 71.2 |
| HOLDER ASSIGNMENT | rule | 1.33 | 0.67 | 39.6 |
| CHARGE NOW FIRST | rule | 1.00 | 0.33 | 20.4 |
| JOINT CHARGE NOW | rule | 1.00 | 0.33 | 128.8 |
| ONE PROMISE A TARGET | rule | 0.67 | 0.33 | 107.6 |
| PROMISE SHOT AWAY | rule | 1.00 | - | 6.4 |
| RULE SWITCHED OFF | gate | 0.67 | - | 25.5 |
| AFTERMATH BAND | gate | 0.33 | - | 3.4 |
| BEST PRIZE | rule | - | 0.33 | 2.5 |
| CHARGE NOT DECLARED | rule | 0.33 | - | 272.7 |
| FALLBACK | gate | - | 0.33 | 71.0 |
| FOLLOW UP WEIGHED | rule | 0.33 | - | 3.4 |
| MARCH OF THE TABLE | rule | - | 0.33 | 2.5 |
| PATHS CROSS | rule | - | 0.33 | 18.3 |
| PURSUES BIG PREY | rule | - | 0.33 | 334.8 |
| REDIRECT WEIGHED | rule | - | 0.33 | 2.5 |
| SUPPORT NARROWED | rule | - | 0.33 | 177.4 |
| WHO GETS IN | rule | 0.33 | - | 292.1 |

### Plans: ccut-c940641-p21

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 5.7 | 65% | 965 | 967 | 100% |
| Mine | move | 30.3 | 99% | 1947 | 0 | 0% |
| Mine | shoot | 5.0 | 60% | 275 | 421 | 153% |
| Opponent | charge | 2.0 | 33% | 197 | 75 | 38% |
| Opponent | join | 2.3 | 86% | 130 | 0 | 0% |
| Opponent | move | 32.0 | 93% | 1860 | 0 | 0% |
| Opponent | shoot | 0.3 | 0% | 69 | 0 | 0% |
| Opponent | support | 0.3 | 100% | 0 | 0 | - |

### Packages: hunt the guns, ccut-c940641-p21

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.3 | 1 | 0 | 100% | 100% | 0% | 2.0 | 279 | 262 | 100% | 0 |
| Opponent | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 1.0 | 1 | 0 | 100% | 100% | 0% | 2.0 | 279 | 262 | 100% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: ccut-c940641-p21

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.3 | 14% | 100% | 100% | 0% | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 2.3 | 29% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p21

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | 0 (3) | - | - | 0 (3) | - |
| Mine | Chaff | 2 | 225 (2) | 19 | 206 | 50 | 0% | 1.5 | 112 (1) | 338 (1) | - | 112 (1) | 338 (1) |
| Mine | Character | 8 | 33 (8) | 33 | 0 | 10 | 12% | 2.4 | 29 (4) | 51 (3) | 0 (1) | 42 (5) | 6 (3) |
| Mine | Clean-up | 1 | 154 (1) | 0 | 154 | 0 | 0% | 4.0 | 154 (1) | - | - | 154 (1) | - |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 4 | 32 (4) | 32 | 0 | 0 | 25% | 1.3 | 26 (3) | 54 (1) | - | 12 (3) | 170 (1) |
| Mine | Hammer | 3 | 99 (3) | 99 | 0 | 0 | 0% | 3.0 | 106 (1) | 97 (2) | - | 106 (1) | 97 (2) |
| Mine | Shooter | 6 | 71 (6) | 17 | 53 | 0 | 0% | 1.8 | 29 (3) | 128 (3) | - | 108 (3) | 34 (3) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 0% | 3.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 100 | 0% | 1.0 | 0 (2) | - | - | 0 (1) | 0 (1) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 78 | 40% | 3.0 | 0 (2) | 0 (3) | - | 0 (1) | 0 (4) |
| Opponent | Character | 10 | 31 (10) | 20 | 11 | 31 | 30% | 3.7 | 0 (4) | 52 (5) | 27 (1) | 0 (7) | 71 (3) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 0% | 3.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 6 | 0 (6) | 0 | 0 | 32 | 67% | 4.5 | 0 (3) | 0 (3) | - | 0 (4) | 0 (2) |
| Opponent | Hammer | 5 | 38 (5) | 0 | 38 | 36 | 20% | 4.0 | 59 (3) | 0 (2) | - | 46 (4) | 0 (1) |
| Opponent | Holder | 4 | 18 (4) | 0 | 18 | 17 | 25% | 4.7 | 0 (1) | 26 (3) | - | - | 18 (4) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 57 | 0% | 3.3 | 0 (1) | 0 (1) | 0 (1) | 0 (1) | 0 (2) |

### Charged fights: ccut-c940641-p21

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 1 | 116 | 616 | 4.0 | 1.0 | 154 | 0 | +154 | 2 of 4 | 4 of 4 | - | +154 |
| Mine | Kingdom of Bretonnia | 1 | 30 | 749 | 4.0 | 1.5 | 187 | 69 | +118 | 1 of 4 | 3 of 4 | +217 | +85 |
| Mine | Lizardmen | 1 | 286 | 240 | 6.0 | 1.3 | 40 | 0 | +40 | 3 of 6 | 4 of 6 | +0 | +48 |
| **Mine** | all armies | 3 | 144 | 535 | 4.7 | 1.3 | 115 | 20 | +95 | 6 of 14 | 11 of 14 | +108 | +93 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 0 of 2 | 2 of 2 | - | +0 |
| Opponent | Warriors of Chaos | 2 | 0 | 50 | 0.5 | 1.0 | 100 | 0 | +100 | 0 of 1 | 1 of 1 | - | +100 |
| **Opponent** | all armies | 3 | 0 | 33 | 1.0 | 1.0 | 33 | 0 | +33 | 0 of 3 | 3 of 3 | - | +33 |

### Effective charges: ccut-c940641-p21

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 4 | 0 | 1 (net +195) | 0 | 0 | 0 | 2 (net +126) | 1 | 0% (0 of 3) |
| Mine | Kingdom of Bretonnia | 4 | 0 | 0 | 1 (net +0) | 0 | 1 (net +85) | 2 (net +194) | 0 | 25% (1 of 4) |
| Mine | Lizardmen | 6 | 2 (net +0) | 0 | 0 | 1 (net +0) | 1 (net +195) | 0 | 2 | 0% (0 of 4) |
| Opponent | Vampire Counts | 2 | 0 | 0 | 0 | 0 | 1 (net +0) | 1 (net +0) | 0 | 0% (0 of 2) |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0 | 0 | 1 (net +100) | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: ccut-c940641-p21

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 287 | 380 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 50-54% | 1 | 115 | 195 | +195 | 301 | 0 | +301 | +261.4 |
| Mine | Effective (55-75%) | 1 | 277 | 122 | +0 | 38 | 0 | +38 | +13.6 |
| Mine | 76-89% | 1 | 945 | 380 | +0 | 95 | 0 | +95 | +10.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 538 | 252 | +160 | 307 | 151 | +156 | +29.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 388 | 72 | +140 | 140 | 0 | +140 | +36.1 |
| Mine | No odds | 3 | 274 | 88 | +72 | 83 | 0 | +83 | +30.2 |
| Mine | All fights | 14 | 404 | 205 | +95 | 156 | 43 | +113 | +28.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 380 | 175 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 418 | 92 | +50 | 85 | 0 | +85 | +20.2 |
| Opponent | All fights | 3 | 405 | 119 | +33 | 56 | 0 | +56 | +13.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p21 | move | 22 | 5 (23%) | 4 (18%) | 4 (18%) | 13 (59%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1727 |
| Invocation of Nehek | Opponent | L1727 |
| Ring of Doom | Mine | L1531 |
| Ring of Doom | Opponent | L1531 |

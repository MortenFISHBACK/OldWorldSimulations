# Doctrine scorecard: ccut-c940641-p30

### Scorecard: ccut-c940641-p30

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0913 | 1 | 1 | Mine | no | 5 | 5 | 1 | 2 | 0 | 0 | 0 | 375 |
| L0913 | 1 | 1 | Opponent | no | 12 | 5 | 2 | 0 | 0 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 0 | 5 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0930 | 6 | 1 | Opponent | no | 3 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 11 | 3 | 2 | 0 | 0 | 0 | 0 | 165 |
| L1021 | 1 | 1 | Opponent | no | 0 | - | 0 | 6 | 0 | 0 | 0 | 290 |
| **Average** | | | Mine | 0% | 5.3 | 4.3 | 1.3 | 1.3 | 0.0 | 0.0 | 0.0 | 180.0 |
| **Average** | | | Opponent | 0% | 5.0 | 5.0 | 0.7 | 2.7 | 0.0 | 0.0 | 0.0 | 143.3 |

### KPIs: ccut-c940641-p30

Rules off - Opponent only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 43% (6 of 14) | 0% (0 of 13) | 22% (6 of 27) |
| Winner chose to follow up after the loser gave ground |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 0% |
| Winner chose to follow up or pursue (all three) |  | - | 50% (1 of 2); on the table 50% | 50% (1 of 2); on the table 50% |
| Magic missiles tried each own turn | 50%+ | 46% (22 of 48) | 25% (3 of 12) | 42% (25 of 60) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 52% (22 of 42) | 25% (3 of 12) | 46% (25 of 54) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 27% (3 of 11) | 27% (3 of 11) |
| Points that never fought | lower | 70% (4200 of 5997) | 64% (3857 of 5999) | 67% (8057 of 11996) |
|   infantry points that never fought | lower | 93% (1487 of 1591) | 100% (1660 of 1660) | 97% (3147 of 3251) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 76% (26 of 34) | 52% (12 of 23) | 67% (38 of 57) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 1.7 uses a game | 50% (1 of 2); 1.7 uses a game | 75% (3 of 4); 1.7 uses a game |
| Bound items with another spell used |  | 0% (0 of 1); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 100% (2 of 2); 0.7 uses a game | 67% (2 of 3); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 74% (4212 of 5667) | 47% (2425 of 5150) | 61% (6637 of 10817) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.7 (42%) | 2.0 (67%) | 5.7 (49%) |
| MARCHED: its unit marched | 3.0 (35%) | 0.7 (22%) | 3.7 (31%) |
| IN COMBAT: engaged in combat | 2.0 (23%) | 0.0 (0%) | 2.0 (17%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (11%) | 0.3 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 4.3 | 1.7 | 8.3 | 0.3 | 1.0 |
| not cast | 0.0 | 3.7 | 0.3 | 11.7 | 1.7 | 19.0 |
| NO TARGET: no enemy in range, sight and arc it may target | - | 2.7 (73%) | 0.0 (0%) | 5.7 (49%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | - | 0.0 (0%) | 0.0 (0%) | 3.7 (31%) | 0.3 (20%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | - | 0.0 (0%) | 0.0 (0%) | 2.0 (17%) | 0.3 (20%) | 0.0 (0%) |
| GONE: slain | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR: another bar (miscast, baggage ...) | - | 1.0 (27%) | 0.0 (0%) | 0.3 (3%) | 1.0 (60%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | - | 0.0 (0%) | 0.3 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.7 (98%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.7 a game | 0.8 a game |
| stood (cast and not dispelled) | - | 80% (4 of 5) | 80% (4 of 5) |
| the unit moved after it | - | 25% (1 of 4) | 25% (1 of 4) |
| it charged on its next turn | - | 0% (0 of 4) | 0% (0 of 4) |
| the enemy charged it first | - | 0% (0 of 4) | 0% (0 of 4) |
| it fought by the end of its next turn | - | 0% (0 of 4) | 0% (0 of 4) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 4) | 0% (0 of 4) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (4 of 4) | 100% (4 of 4) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (80 of 123) | 73% (37 of 51) | 67% (117 of 174) |
|   character | 100% (3 of 3) | 50% (8 of 16) | 58% (11 of 19) |
|   chariot | 82% (14 of 17) | 100% (6 of 6) | 87% (20 of 23) |
|   infantry | 54% (30 of 56) | 65% (11 of 17) | 56% (41 of 73) |
|   monster | 60% (6 of 10) | - | 60% (6 of 10) |
|   war machine | 73% (27 of 37) | 100% (12 of 12) | 80% (39 of 49) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.3 (23%) | 2.7 (57%) | 6.0 (32%) |
| CHARGED: it charged | 0.0 (0%) | 0.3 (7%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |
| MOVED: a war machine that moved | 1.7 (12%) | 0.0 (0%) | 1.7 (9%) |
| NO TARGET IN RANGE | 5.3 (37%) | 1.0 (21%) | 6.3 (33%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.0 (14%) | 0.7 (14%) | 2.7 (14%) |
| SHELTERED: the target was sheltered | 1.3 (9%) | 0.0 (0%) | 1.3 (7%) |
| OTHER BAR | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| character | 4.3 | 1.0 | 77% | 2.7 pts | 12 pts |
| chariot | 6.7 | 1.3 | 85% | 5.5 pts | 37 pts |
| infantry | 16.7 | 10.0 | 60% | 13.0 pts | 217 pts |
| monster | 4.0 | 0.7 | 83% | 5.0 pts | 20 pts |
| war machine | 13.0 | 11.0 | 62% | 22.0 pts | 286 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.7 | 0.7 | 1.2 |
| Charges that made contact a game | 1.3 | 0.7 | 1.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 1.00 contact (3 units) | 0.00 declared, 0.00 contact (2 units) | 0.60 declared, 0.60 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.11 declared, 0.05 contact (19 units) | 0.09 declared, 0.09 contact (23 units) | 0.10 declared, 0.07 contact (42 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 40% (2 of 5) | - | - | 40% (2 of 5) |
| Character in a unit | 100% (7 of 7) | 0% (0 of 2) | - | 78% (7 of 9) |
| Character on its own | - | 25% (1 of 4) | 50% (2 of 4) | 38% (3 of 8) |
| Chariot | 100% (3 of 3) | 100% (2 of 2) | - | 100% (5 of 5) |
| Infantry | 57% (8 of 14) | 75% (3 of 4) | - | 61% (11 of 18) |
| Monster | - | 50% (1 of 2) | - | 50% (1 of 2) |
| Monstrous | - | 100% (2 of 2) | - | 100% (2 of 2) |
| War Machines | 88% (7 of 8) | - | - | 88% (7 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 2 | - | 58% (14 of 24) | 85% | 83% (20 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 33% (8 of 24) | 40% | 60% (6 of 10) | 100% (2 of 2); 5.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| High Elf Realms | 1 | - | 17% (1 of 6) | 71% | 25% (2 of 8) | 100% (1 of 1); 5.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game |
| Skaven | 1 | 50% (1 of 2); on the table 50% | 33% (2 of 6) | 58% | 89% (8 of 9) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 1 | - | - | 64% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p30, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (1) | 50% (2) | 60% (3) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.67 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.67 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.33 | 0.00 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: ccut-c940641-p30

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 40% (2 of 5) | 100% (2 of 2) |
| Strategy | Shoot objectives carried out (shot that target) | 18% (9 of 49) | 63% (12 of 19) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 67% (2 of 3) | - |
| Strategy | Joined characters whose unit fought | 10% (1 of 10) | 50% (2 of 4) |
| Strategy | Lone characters that fought | 75% (3 of 4) | 60% (3 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.3 | 2.7 |
| Movement | Points that never moved of their own | 180.0 | 143.3 |
| Movement | Fights charged into per game | 1.3 | 0.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 4 | 0 of 2 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 4, net -265 | 0 of 2 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 4, net +0 | 1 of 2, net +104 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 4, net +0 | 1 of 2, net +227 |
| Shooting | Shots by shooting units (incl. breath weapons) | 17.7 | 9.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 77% (41 of 53) | 48% (13 of 27) |
| Shooting | Points destroyed by shooting units | 0.0 | 83.3 |
| Shooting | War machine shots | 9.0 | 4.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (12 of 27) | 33% (4 of 12) |
| Shooting | Points destroyed by war machines | 70.0 | 0.0 |
| Magic | Magic missiles cast | 2.7 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 50% (4 of 8) | 0% (0 of 2) |
| Magic | Wounds caused by magic missiles | 5.7 | 1.0 |
| Magic | Wounds caused by other spells | 2.3 | - |
| Magic | Points destroyed by magic (all spells) | 309.3 | 55.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 1.0 / 0.7 / 0.3 | 3.7 / 2.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 0.0 | 123.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | -49 | +209 |
| Combat | Net per 100 charger points, damage counted | -14.6 | +70.9 |
| Combat | First round won (charged fights) | 75% | 100% |
| Combat | Net points per charged fight | -66 | +166 |
| Combat | Net points per supported fight / lone fight | - / -66 | - / +166 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 4 | 1 of 2 |
| Game | Points lost | 378.7 | 383.3 |
| Game | VP from objectives | 683.3 | 763.3 |
| Game | Lone holders (player turns) | 5.3 | 5.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -52 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 762
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: ccut-c940641-p30

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +11.7 | 0.0 | 0.0 |
| ARMY TABLE | 22.0 | +371.5 | 0.0 | 328.0 | 30.0 | -78.6 | 0.0 | 612.0 |
| ARTILLERY RE-ROLL WEIGHED | 3.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 8.3 | +420.8 | 293.3 | 180.0 | 4.0 | +65.8 | 118.0 | 0.0 |
| CANNON SIGHT KEPT | 2.0 | +0.0 | 0.0 | 41.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 2.0 | +37.1 | 0.0 | 0.0 | 1.3 | +22.3 | 69.3 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | 0.3 | +4.4 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 1.0 | +26.7 | 0.0 | 80.0 |
| CHAFF PASSED | 0.7 | -8.5 | 0.0 | 88.3 | 0.3 | -2.2 | 41.7 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +10.6 | 0.0 | 75.7 | - | - | - | - |
| CHARACTER GUNS | 4.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 17.3 | -533.7 | 0.0 | 151.3 | 32.3 | -2321.8 | 0.0 | 994.0 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 123.0 | 88.3 | 0.3 | +0.0 | 75.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 4.7 | +0.0 | 0.0 | 0.0 | 11.7 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | - | - | - | - | 1.7 | +227.6 | 0.0 | 0.0 |
| COVER ONCE | 11.0 | -739.8 | 0.0 | 110.3 | 5.3 | -139.9 | 0.0 | 21.7 |
| DEFENSIVE ARMY | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.7 | -63.5 | 0.0 | 41.7 | 7.0 | +37.9 | 0.0 | 0.0 |
| EXACT ROUND | 1.7 | +47.0 | 228.3 | 88.3 | - | - | - | - |
| FACES THE THREAT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.3 | +15.7 | 48.3 | 88.3 | 0.3 | +0.0 | 75.7 | 0.0 |
| FALLS SHORT | 2.3 | +43.9 | 0.0 | 75.7 | 27.3 | +341.3 | 0.0 | 54.3 |
| FEATURE BUFFS | 2.0 | +33.2 | 0.0 | 0.0 | 3.3 | +34.9 | 0.0 | 0.0 |
| FIGHT TO THE END | - | - | - | - | 0.3 | +3.3 | 75.7 | 0.0 |
| FIVE ACTION | 105.3 | +7546.8 | 1243.7 | 955.7 | 103.3 | +4654.3 | 568.3 | 1323.3 |
| FLANK NOT WEIGHED | 3.7 | +0.0 | 0.0 | 75.7 | 5.0 | +0.0 | 0.0 | 21.7 |
| FOLLOW UP WEIGHED | - | - | - | - | 0.3 | +104.3 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.7 | +228.9 | 228.3 | 88.3 | 0.7 | +55.6 | 110.3 | 0.0 |
| FREED FROM HIS FIGHT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.7 | -44.9 | 0.0 | 0.0 | 0.7 | -2.2 | 0.0 | 0.0 |
| GOAL WALK | 10.7 | +1534.8 | 0.0 | 0.0 | 14.3 | +1614.5 | 0.0 | 0.0 |
| GUN FIGURES | 3.0 | +14.7 | 0.0 | 88.3 | 0.3 | +0.0 | 0.0 | 21.7 |
| GUN MASK | 4.0 | +66.7 | 0.0 | 0.0 | 1.3 | +72.5 | 0.0 | 0.0 |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 10.7 | +0.0 | 0.0 | 151.3 | 10.3 | +0.0 | 0.0 | 489.3 |
| HIS CHARGE LIST | 3.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 161.7 |
| HIS LEGAL MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 360.0 |
| HIS MOVE AND SHOT | 3.3 | -30.0 | 0.0 | 0.0 | 5.0 | -95.7 | 0.0 | 228.3 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 40.3 | +15.3 | 397.3 | 0.0 |
| HIS ONE MOVE | - | - | - | - | 20.0 | -32.4 | 0.0 | 397.3 |
| HIS ONE QUARTER | 4.7 | +0.0 | 0.0 | 110.0 | 9.0 | +0.0 | 0.0 | 74.7 |
| HIS OWN BEST MOVE | 4.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 180.0 |
| HIS RANDOM MOVE | 16.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 4.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 38.3 | +1019.1 | 0.0 | 261.3 | 78.7 | +5845.1 | 0.0 | 920.0 |
| HIS SHOTS BY HIS RUN | 33.7 | +746.1 | 0.0 | 328.0 | 82.3 | +3041.8 | 0.0 | 1323.3 |
| HIS TURN DENIED | 0.3 | +8.1 | 180.0 | 0.0 | - | - | - | - |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 19.7 | +0.0 | 0.0 | 0.0 | 30.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 12.0 | +1184.3 | 0.0 | 0.0 | 15.7 | +1452.0 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.3 | -46.2 | 228.3 | 0.0 | 0.7 | -23.8 | 110.3 | 0.0 |
| IDLE COST | 0.3 | -1.3 | 0.0 | 0.0 | 14.7 | -297.4 | 0.0 | 76.0 |
| JOINT CHARGE NOW | - | - | - | - | 0.3 | +14.8 | 34.7 | 0.0 |
| KEPT FROM ITS LAST STOP | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.7 | +11.3 | 0.0 | 0.0 | 0.7 | +40.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 1.3 | +60.0 | 0.0 | 0.0 | 0.3 | +58.3 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.3 | +2.8 | 48.3 | 88.3 | 0.3 | +0.1 | 75.7 | 0.0 |
| MANOEUVRE | 3.7 | -47.4 | 0.0 | 0.0 | 3.3 | +10.3 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +18.3 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 2.0 | +134.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 2.0 | +116.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.7 | +101.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 3.3 | -322.4 | 0.0 | 0.0 | 1.0 | +41.4 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 5.7 | +59.8 | 0.0 | 0.0 | - | - | - | - |
| MEETS IN TIME | 4.3 | +509.9 | 0.0 | 0.0 | 3.3 | +324.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 10.7 | +183.4 | 0.0 | 0.0 | 2.3 | +53.4 | 0.0 | 360.0 |
| MISSILES NEXT TURN | 14.3 | +185.9 | 0.0 | 0.0 | 5.7 | +44.1 | 0.0 | 180.0 |
| MOVE ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 4.7 | +466.4 | 0.0 | 176.7 | 3.0 | +231.9 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 13.7 | +637.1 | 0.0 | 0.0 | 8.3 | +382.2 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 3.0 | +207.3 | 0.0 | 0.0 | 2.0 | +220.1 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.7 | -113.1 | 228.3 | 88.3 | 0.7 | -44.1 | 110.3 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 6.3 | -177.9 | 0.0 | 125.0 | 1.3 | -42.2 | 0.0 | 21.7 |
| OGRE LOADER SECOND SHOT | 3.0 | +25.8 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 212.7 |
| ONE FIGHT FORMULA | 6.3 | -107.3 | 0.0 | 88.3 | 4.3 | -82.1 | 0.0 | 180.0 |
| ONE OBJECTIVE FORMULA | 6.7 | -9.8 | 0.0 | 0.0 | 7.0 | +50.1 | 0.0 | 0.0 |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.3 | +4.0 | 0.0 | 0.0 | 0.3 | +2.0 | 34.7 | 0.0 |
| OWN CAST FIRST | 0.7 | -8.0 | 0.0 | 0.0 | - | - | - | - |
| PATHS CROSS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PERIAPT WORTH | - | - | - | - | 0.3 | +18.0 | 0.0 | 0.0 |
| PLAN RESULT | 46.0 | +448.6 | 445.7 | 674.0 | 46.7 | +304.9 | 194.3 | 790.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 9.0 | -130.7 | 0.0 | 0.0 | 3.3 | -16.5 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.7 | -1.9 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.7 | -2.2 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.3 | -13.1 | 48.3 | 0.0 | - | - | - | - |
| QUARTER ODDS | 17.7 | +2039.4 | 1012.0 | 289.3 | 23.3 | +1884.9 | 318.3 | 869.3 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.7 | +17.7 | 0.0 | 193.3 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -88.6 | 0.0 | 176.7 | - | - | - | - |
| RISK BY ARC | 1.0 | -26.9 | 48.3 | 88.3 | 0.7 | -29.9 | 110.3 | 0.0 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | 0.3 | -7.6 | 0.0 | 0.0 | 0.3 | -9.6 | 34.7 | 0.0 |
| RUN DOWN | 1.3 | -15.6 | 48.3 | 88.3 | 0.7 | -2.2 | 110.3 | 0.0 |
| SAME CHARGE LATER | 0.3 | -8.2 | 0.0 | 0.0 | - | - | - | - |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.0 | -114.0 | 0.0 | 106.7 |
| SEARCH SPOT | 1.0 | +59.2 | 0.0 | 0.0 | 0.3 | +20.0 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 15.7 | +0.0 | 0.0 | 214.7 | 7.0 | +0.0 | 0.0 | 53.3 |
| SHOOTS FROM THE BEST SPOT | 1.7 | +20.9 | 0.0 | 0.0 | 1.0 | +27.3 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.7 | -99.1 | 360.0 | 55.0 | 0.3 | -1.6 | 34.7 | 0.0 |
| SHOT RISK POINTS | 14.0 | -112.9 | 0.0 | 261.3 | 48.7 | -892.0 | 0.0 | 888.7 |
| SHOTS AFTER THE MOVES | 5.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 31.0 | +1139.9 | 0.0 | 269.7 | 12.0 | +297.0 | 0.0 | 21.7 |
| SPELL WORTH | - | - | - | - | 4.0 | +124.1 | 360.0 | 360.0 |
| SPELLS IN THE FIGHT | 0.7 | +3.5 | 228.3 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 5.3 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 118.3 |
| STANDS FOR A REASON | - | - | - | - | 5.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 43.7 | +0.0 | 1015.3 | 539.3 | 36.7 | +0.0 | 458.0 | 171.3 |
| STAY WORTH | 43.7 | +227.3 | 543.3 | 518.3 | 19.3 | +324.0 | 388.7 | 43.3 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.0 | +46.7 | 0.0 | 0.0 | 3.3 | +184.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 2.0 | +46.7 | 0.0 | 0.0 | 3.3 | +184.0 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 21.7 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 5.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 54.3 |
| THE ROW KEEPS ITS WAY | 4.3 | +0.0 | 0.0 | 75.7 | 4.0 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 2.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 48.7 | +0.0 | 0.0 | 378.7 | 50.0 | +0.0 | 0.0 | 618.3 |
| TIED UP BY THE SUM | 0.3 | +48.7 | 48.3 | 0.0 | 0.3 | +37.7 | 75.7 | 0.0 |
| TIME ON OUR SIDE | 34.3 | +561.1 | 0.0 | 88.3 | - | - | - | - |
| WAITS AGAIN | 4.0 | +0.0 | 0.0 | 176.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.7 | +70.6 | 0.0 | 88.3 | - | - | - | - |
| WHO HITS BACK | - | - | - | - | 0.3 | +12.2 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 5.7 | -376.8 | 0.0 | 0.0 | 4.0 | -520.1 | 0.0 | 360.0 |
| WOUNDS ON THE RANKS | 3.0 | +21.4 | 0.0 | 0.0 | 1.7 | +52.0 | 0.0 | 0.0 |

### Rule changes: ccut-c940641-p30

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOTS BY HIS RUN | 348 | 338 | 99 | 33.00 | +1882 | +19.0 |
| HIS SHOT LIST | 351 | 341 | 98 | 32.67 | +2854 | +29.1 |
| ARMY TABLE | 156 | 156 | 89 | 29.67 | +1641 | +18.4 |
| HOLDER ASSIGNMENT | 83 | 83 | 78 | 26.00 | +5305 | +68.0 |
| HIS MOVE AS HE DECIDES | 121 | 121 | 75 | 25.00 | +0 | +0.0 |
| SHOT RISK POINTS | 188 | 183 | 37 | 12.33 | +2056 | +55.6 |
| DEPLOY BY FIGURES | 47 | 47 | 33 | 11.00 | +783 | +23.7 |
| THE TABLE AGAIN | 36 | 36 | 27 | 9.00 | +0 | +0.0 |
| CHARGE LOSSES | 149 | 145 | 25 | 8.33 | +2083 | +83.3 |
| GOAL WALK | 75 | 75 | 25 | 8.33 | +3077 | +123.1 |
| OFF BEST | 23 | 23 | 23 | 7.67 | -661 | -28.7 |
| HIS ONE MOVE | 60 | 60 | 21 | 7.00 | +0 | +0.0 |
| FIVE ACTION | 626 | 612 | 20 | 6.67 | +879 | +44.0 |
| QUARTER ODDS | 123 | 117 | 17 | 5.67 | +858 | +50.5 |
| MOVE ORDER | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 37 | 37 | 14 | 4.67 | -442 | -31.5 |
| MOVE TO CHARGE COMPUTED | 23 | 23 | 12 | 4.00 | +473 | +39.4 |
| COVER ONCE | 49 | 39 | 11 | 3.67 | +372 | +33.8 |
| MEETS IN TIME | 23 | 23 | 11 | 3.67 | +1042 | +94.7 |
| THE RISK READS HIS RUN | 18 | 18 | 10 | 3.33 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| OGRE LOADER SECOND SHOT | 9 | 9 | 9 | 3.00 | +78 | +8.6 |
| STAY WORTH | 189 | 173 | 8 | 2.67 | +106 | +13.2 |
| NEXT CHARGE BY LIST | 15 | 15 | 7 | 2.33 | +220 | +31.5 |
| SHOOTS FROM THE BEST SPOT | 8 | 8 | 7 | 2.33 | +104 | +14.8 |
| SHOTS AFTER THE MOVES | 21 | 21 | 7 | 2.33 | +0 | +0.0 |
| CANNON PLANNED TARGET | 37 | 37 | 6 | 2.00 | -19 | -3.1 |
| CAST JOB | 10 | 10 | 6 | 2.00 | +40 | +6.7 |
| MARCH BY THE SUM | 6 | 6 | 6 | 2.00 | +402 | +67.0 |
| FOUR ROUNDS | 7 | 7 | 5 | 1.67 | +123 | +24.6 |
| HARD STAY DROPPED | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 5 | 5 | 5 | 1.67 | +355 | +71.0 |
| TIME ON OUR SIDE | 103 | 86 | 5 | 1.67 | +18 | +3.5 |
| CASTER AWAY FROM SCREEN | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| GUN MASK | 16 | 15 | 4 | 1.33 | +113 | +28.3 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +154 | +38.5 |
| LEGAL CHARGES ONLY | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| MANOEUVRE | 21 | 21 | 4 | 1.33 | +87 | +21.7 |
| ONE OBJECTIVE FORMULA | 41 | 29 | 4 | 1.33 | +82 | +20.6 |
| SEARCH SPOT | 4 | 4 | 4 | 1.33 | +238 | +59.4 |
| THE ROW IN ITS ORDER | 32 | 4 | 4 | 1.33 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 29 | 28 | 4 | 1.33 | +195 | +48.7 |
| CHAFF IN THE MOVE | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | -32 | -10.7 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MARCH CHECK | 6 | 5 | 3 | 1.00 | +81 | +26.9 |
| MISSILES IN THE MOVE | 39 | 31 | 3 | 1.00 | +14 | +4.7 |
| NEARER NOT NEEDED | 66 | 62 | 3 | 1.00 | +89 | +29.7 |
| RANDOM MOVE BY FIGURES | 11 | 11 | 3 | 1.00 | +53 | +17.7 |
| SUPPORT ADDS | 16 | 15 | 3 | 1.00 | +87 | +29.0 |
| SUPPORT WORKED OUT | 16 | 15 | 3 | 1.00 | +87 | +29.0 |
| CHARGE NOW FIRST | 5 | 5 | 2 | 0.67 | -127 | -63.4 |
| EXACT ROUND | 5 | 5 | 2 | 0.67 | +35 | +17.4 |
| FALLS SHORT | 89 | 69 | 2 | 0.67 | +32 | +16.2 |
| FEATURE BUFFS | 16 | 16 | 2 | 0.67 | +1 | +0.4 |
| HIS MOVE AND SHOT | 25 | 23 | 2 | 0.67 | +11 | +5.7 |
| IDLE COST | 45 | 40 | 2 | 0.67 | +11 | +5.4 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -305 | -152.7 |
| MAX FOR POSITIONING | 17 | 16 | 2 | 0.67 | +0 | +0.2 |
| OWN CAST FIRST | 2 | 2 | 2 | 0.67 | -24 | -12.0 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| SHOTS IN THE MOVE | 129 | 101 | 2 | 0.67 | +23 | +11.5 |
| TIED UP BY THE SUM | 2 | 2 | 2 | 0.67 | +79 | +39.7 |
| WAR ENGINE JOBS | 2 | 2 | 2 | 0.67 | -4 | -2.1 |
| ADVANCE LANE KEPT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +35 | +35.0 |
| CATCH ODDS | 1 | 1 | 1 | 0.33 | -8 | -8.0 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +32 | +31.7 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 5 | 5 | 1 | 0.33 | +30 | +29.8 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +313 | +312.8 |
| JOINT CHARGE NOW | 1 | 1 | 1 | 0.33 | +44 | +44.3 |
| OVERRUNS AWAY | 2 | 2 | 1 | 0.33 | +8 | +7.9 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +54 | +54.0 |
| PROMISE KNOWS THE FIGHT | 3 | 3 | 1 | 0.33 | -6 | -5.5 |
| PROMISE SHOT AWAY | 1 | 1 | 1 | 0.33 | -39 | -39.4 |
| REDIRECT FOR A FRIEND IN REACH | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 2 | 2 | 1 | 0.33 | +30 | +29.8 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +36 | +36.5 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 4 | trace | - | - | - | - |
| CHARACTER GUNS | 22 | 22 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 49 | 47 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 5 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 6 | 6 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 26 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GUN FIGURES | 10 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 63 | 62 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 27 | 27 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 26 | 25 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 41 | 37 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 25 | 25 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 49 | 47 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 14 | 14 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 150 | 150 | 0 | 0.00 | - | - |
| HONEST WORTH | 6 | 6 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 9 | 9 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 5 | 5 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 13 | 13 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 60 | 45 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 4 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 7 | 7 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 5 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 32 | 21 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| PLAN RESULT | 278 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 2 | 2 | 0 | 0.00 | - | - |
| RISK BY ARC | 5 | 5 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 6 | 6 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 0 | 0.00 | - | - |
| SET UP BY THE SET | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 68 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 39 | 37 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 16 | 16 | 0 | 0.00 | - | - |
| STANDS STILL | 241 | 236 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 13 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 25 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 5 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 15 | not checked | - | - | - | - |
| THE TABLE BINDS | 296 | not checked | - | - | - | - |
| WAITS AGAIN | 15 | 15 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 14 | 13 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p30

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 6.00 | 1.33 | 29.9 |
| ARMY TABLE | rule | 1.67 | 3.33 | 57.2 |
| PROMISE BY ITS OWN SUM | rule | 4.00 | 0.67 | 31.5 |
| CHAFF PASSED | rule | 0.67 | 0.33 | 10.7 |
| CHARGE NOW FIRST | rule | 0.67 | - | 63.4 |
| MARCH OF THE TABLE | rule | 0.67 | - | 152.7 |
| OWN CAST FIRST | rule | 0.67 | - | 12.0 |
| WAR ENGINE JOBS | rule | 0.67 | - | 2.1 |
| AFTERMATH BAND | gate | 0.33 | - | 2.5 |
| CANNON PLANNED TARGET | rule | - | 0.33 | 65.8 |
| CATCH ODDS | rule | 0.33 | - | 8.0 |
| HOLDER ASSIGNMENT | rule | - | 0.33 | 4.3 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | - | 5.5 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 39.4 |

### Plans: ccut-c940641-p30

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 33% | 178 | 54 | 31% |
| Mine | join | 0.3 | 100% | 4 | 0 | 0% |
| Mine | move | 30.3 | 99% | 2298 | 0 | 0% |
| Mine | shoot | 14.3 | 35% | 681 | 394 | 58% |
| Opponent | charge | 0.3 | 100% | 42 | 76 | 180% |
| Opponent | move | 40.0 | 96% | 2334 | 0 | 0% |
| Opponent | shoot | 5.3 | 56% | 297 | 229 | 77% |
| Opponent | support | 1.0 | 67% | 0 | 0 | - |

### Deployment: positions vs output by unit type: ccut-c940641-p30

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 10 | 46 (10) | 46 | 0 | 0 | 40% | 3.0 | 68 (6) | 0 (4) | - | 17 (7) | 127 (3) |
| Mine | Clean-up | 3 | 60 (3) | 0 | 60 | 0 | 100% | - | 0 (1) | 92 (2) | - | 60 (3) | - |
| Mine | Fast Hammer | 3 | 0 (3) | 0 | 0 | 0 | 0% | 3.7 | 0 (2) | - | 0 (1) | 0 (3) | - |
| Mine | Hammer | 6 | 0 (6) | 0 | 0 | 35 | 33% | 1.2 | 0 (2) | 0 (4) | - | 0 (5) | 0 (1) |
| Mine | Shooter | 6 | 139 (6) | 0 | 139 | 17 | 0% | 1.5 | 0 (1) | 212 (3) | 101 (2) | 139 (6) | - |
| Mine | War machine | 8 | 19 (8) | 19 | 0 | 50 | 0% | 1.5 | 0 (3) | 0 (3) | 64 (2) | 0 (1) | 22 (7) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 50% | 1.5 | 0 (1) | 0 (3) | - | 0 (3) | 0 (1) |
| Opponent | Chaff | 2 | 72 (2) | 0 | 72 | 0 | 100% | - | 129 (1) | 0 (1) | - | 129 (1) | 0 (1) |
| Opponent | Character | 9 | 26 (9) | 26 | 0 | 20 | 22% | 3.4 | 38 (1) | 23 (7) | 30 (1) | 31 (7) | 18 (2) |
| Opponent | Clean-up | 3 | 91 (3) | 0 | 91 | 0 | 67% | 6.0 | 0 (1) | 166 (2) | - | 166 (2) | 0 (1) |
| Opponent | Fast Hammer | 6 | 85 (6) | 24 | 61 | 10 | 67% | 3.0 | - | 105 (4) | 54 (2) | 85 (6) | - |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Hammer | 4 | 0 (4) | 0 | 0 | 43 | 25% | 2.0 | - | 0 (2) | 0 (2) | 0 (4) | - |
| Opponent | Holder | 4 | 0 (4) | 0 | 0 | 48 | 100% | - | - | 0 (4) | - | 0 (2) | 0 (2) |
| Opponent | Shooter | 4 | 27 (4) | 27 | 0 | 28 | 25% | 2.0 | 0 (1) | 0 (1) | 37 (2) | 31 (3) | 0 (1) |
| Opponent | War machine | 2 | 89 (2) | 89 | 0 | 0 | 0% | 1.0 | - | - | 89 (2) | 179 (1) | 0 (1) |

### Charged fights: ccut-c940641-p30

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 89 | 0 | 0.5 | 1.0 | 0 | 265 | -265 | 0 of 1 | 0 of 1 | - | -265 |
| Mine | Grand Cathay | 1 | 960 | 0 | 3.0 | 1.0 | 0 | 0 | +0 | 1 of 3 | 3 of 3 | - | +0 |
| **Mine** | all armies | 3 | 379 | 0 | 1.3 | 1.0 | 0 | 66 | -66 | 1 of 4 | 3 of 4 | - | -66 |
| Opponent | High Elf Realms | 1 | 250 | 331 | 2.0 | 1.0 | 166 | 0 | +166 | 1 of 2 | 2 of 2 | - | +166 |
| Opponent | Skaven | 1 | 165 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 138 | 110 | 0.7 | 1.0 | 166 | 0 | +166 | 1 of 2 | 2 of 2 | - | +166 |

### Effective charges: ccut-c940641-p30

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 1 | 0 | 0 | 1 (net -265) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Mine | Grand Cathay | 3 | 0 | 0 | 0 | 0 | 1 (net +0) | 2 (net +0) | 0 | 0% (0 of 3) |
| Opponent | High Elf Realms | 2 | 0 | 0 | 0 | 0 | 1 (net +104) | 1 (net +227) | 0 | 0% (0 of 2) |

### Charged fights, damage counted: ccut-c940641-p30

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 265 | 717 | -265 | 50 | 265 | -216 | -81.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 352 | 292 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 369 | 41 | +0 | 20 | 0 | +20 | +5.6 |
| Mine | All fights | 4 | 334 | 336 | -66 | 18 | 66 | -49 | -14.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 247 | 227 | +227 | 314 | 0 | +314 | +126.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 342 | 104 | +104 | 104 | 0 | +104 | +30.4 |
| Opponent | All fights | 2 | 294 | 166 | +166 | 209 | 0 | +209 | +70.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p30 | move | 19 | 6 (32%) | 5 (26%) | 0 (0%) | 13 (68%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Periapt of Soul Exchange | Opponent | L1021 |
| Ring of Jet | Mine | L1021 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Opponent | L1021 |
| Twice-Blessed Armour | Mine | L1021 |

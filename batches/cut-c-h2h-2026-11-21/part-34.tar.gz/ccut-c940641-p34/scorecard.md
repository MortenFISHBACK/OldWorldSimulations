# Doctrine scorecard: ccut-c940641-p34

### Scorecard: ccut-c940641-p34

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1823 | 5 | 1 | Mine | yes | - | 6 | 1 | 2 | 1 | 0 | 0 | 234 |
| L1823 | 5 | 1 | Opponent | yes | - | 1 | 6 | 3 | 1 | 0 | 0 | 202 |
| L1923 | 3 | 1 | Mine | no | 1 | 1 | 5 | 0 | 1 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | yes | 8 | 2 | 3 | 2 | 0 | 0 | 0 | 325 |
| L2025 | 3 | 1 | Mine | no | 1 | - | 1 | 4 | 1 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 8 | 3 | 6 | 4 | 0 | 0 | 0 | 68 |
| **Average** | | | Mine | 33% | 1.0 | 3.5 | 2.3 | 2.0 | 1.0 | 0.0 | 0.0 | 218.0 |
| **Average** | | | Opponent | 67% | 8.0 | 2.0 | 5.0 | 3.0 | 0.3 | 0.0 | 0.0 | 198.3 |

### KPIs: ccut-c940641-p34

Rules off - Opponent only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 15) | 6% (1 of 16) | 3% (1 of 31) |
| Winner chose to follow up after the loser gave ground |  | 50% (1 of 2); on the table 50% | 100% (5 of 5); on the table 100% | 86% (6 of 7); on the table 86% |
| Winner chose to pursue after the loser fell back in good order |  | - | 50% (1 of 2); on the table 50% | 50% (1 of 2); on the table 50% |
| Winner chose to pursue after the loser fled |  | - | 100% (7 of 7); on the table 100% | 100% (7 of 7); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 50% (1 of 2); on the table 50% | 93% (13 of 14); on the table 93% | 88% (14 of 16); on the table 88% |
| Magic missiles tried each own turn | 50%+ | 10% (3 of 30) | 39% (7 of 18) | 21% (10 of 48) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 18% (3 of 17) | 39% (7 of 18) | 29% (10 of 35) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 0% (0 of 2) | - | 0% (0 of 2) |
| Points that never fought | lower | 21% (1262 of 5999) | 50% (3001 of 5999) | 36% (4263 of 11998) |
|   infantry points that never fought | lower | 67% (664 of 993) | 88% (917 of 1037) | 78% (1581 of 2030) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 64% (14 of 22) | 56% (9 of 16) | 61% (23 of 38) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 0.7 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (1 of 2); 0.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 67% (3471 of 5151) | 46% (2065 of 4500) | 57% (5536 of 9651) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (7%) | 3.7 (100%) | 4.3 (34%) |
| MARCHED: its unit marched | 1.7 (19%) | 0.0 (0%) | 1.7 (13%) |
| CHARGED: its unit charged | 0.7 (7%) | 0.0 (0%) | 0.7 (5%) |
| IN COMBAT: engaged in combat | 2.3 (26%) | 0.0 (0%) | 2.3 (18%) |
| REAR RANK: in a rear rank | 1.0 (11%) | 0.0 (0%) | 1.0 (8%) |
| GONE: slain | 2.0 (22%) | 0.0 (0%) | 2.0 (16%) |
| NOT OFFERED: not in the cast list | 0.7 (7%) | 0.0 (0%) | 0.7 (5%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.0 | 0.7 | 1.7 | 3.3 | 1.3 |
| not cast | 7.0 | 1.3 | 4.3 | 12.7 | 18.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (50%) | 0.0 (0%) | 4.3 (34%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (13%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (5%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (5%) | 0.3 (25%) | 0.3 (8%) | 2.3 (18%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 1.7 (24%) | 0.0 (0%) | 1.7 (38%) | 1.0 (8%) | 0.0 (0%) |
| GONE: slain | 2.0 (29%) | 0.0 (0%) | 0.0 (0%) | 2.0 (16%) | 3.0 (16%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.3 (25%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (5%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 3.0 (43%) | 0.0 (0%) | 2.3 (54%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.3 (77%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.3 a game | 1.3 a game | 0.8 a game |
| stood (cast and not dispelled) | - | 75% (3 of 4) | 75% (3 of 4) |
| the unit moved after it | - | 100% (3 of 3) | 100% (3 of 3) |
| it charged on its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| the enemy charged it first | - | 0% (0 of 3) | 0% (0 of 3) |
| it fought by the end of its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 3) | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (3 of 3) | 100% (3 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 59% (34 of 58) | 53% (42 of 79) | 55% (76 of 137) |
|   cavalry | - | 88% (14 of 16) | 88% (14 of 16) |
|   character | 83% (5 of 6) | 0% (0 of 22) | 18% (5 of 28) |
|   chariot | 44% (4 of 9) | - | 44% (4 of 9) |
|   infantry | 56% (19 of 34) | 68% (28 of 41) | 63% (47 of 75) |
|   monster | 67% (6 of 9) | - | 67% (6 of 9) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.3 (17%) | 0.0 (0%) | 1.3 (7%) |
| CHARGED: it charged | 0.3 (4%) | 3.0 (24%) | 3.3 (16%) |
| IN COMBAT: it fought this turn or the last | 0.7 (8%) | 1.3 (11%) | 2.0 (10%) |
| NO TARGET IN RANGE | 3.7 (46%) | 2.7 (22%) | 6.3 (31%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (4%) | 4.3 (35%) | 4.7 (23%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 1.0 (8%) | 1.0 (5%) |
| SHELTERED: the target was sheltered | 0.3 (4%) | 0.0 (0%) | 0.3 (2%) |
| OTHER BAR | 1.3 (17%) | 0.0 (0%) | 1.3 (7%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.0 | 1.7 | 73% | 8.2 pts | 41 pts |
| character | 1.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 1.7 | 2.0 | 60% | 33.5 pts | 56 pts |
| infantry | 18.0 | 5.7 | 80% | 4.6 pts | 82 pts |
| monster | 2.7 | 1.0 | 75% | 12.2 pts | 32 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 7.3 | 5.2 |
| Charges that made contact a game | 2.3 | 6.3 | 4.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 2.00 declared, 2.00 contact (1 units) | 2.00 declared, 2.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.32 declared, 0.25 contact (28 units) | 0.69 declared, 0.59 contact (29 units) | 0.51 declared, 0.42 contact (57 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | - | 33% (1 of 3) | - | 33% (1 of 3) |
| Character in a unit | 100% (1 of 1) | - | - | 100% (1 of 1) |
| Character on its own | 50% (2 of 4) | 75% (3 of 4) | 43% (3 of 7) | 53% (8 of 15) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 83% (5 of 6) | - | - | 83% (5 of 6) |
| Monster | 50% (2 of 4) | 67% (2 of 3) | - | 57% (4 of 7) |
| Monstrous | - | 75% (3 of 4) | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ogre Kingdoms | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 18% | 71% (5 of 7) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | - | 17% (2 of 12) | 3% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 0% (0 of 1); on the table 0% | 8% (1 of 12) | 43% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 2 | 92% (11 of 12); on the table 92% | 17% (1 of 6) | 45% | 50% (5 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (2 of 2); on the table 100% | 50% (6 of 12) | 61% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p34, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 55% (6) | 67% (2) | 57% (8) |
| ...free all their last turn and able to turn (per game) | 1.33 | 0.00 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.00 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: ccut-c940641-p34

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.7 | 2.3 |
| Strategy | Charge objectives carried out (made contact) | 100% (3 of 3) | 56% (10 of 18) |
| Strategy | Shoot objectives carried out (shot that target) | 50% (7 of 14) | 79% (11 of 14) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | - | 0% (0 of 4) |
| Strategy | Lone characters that fought | 90% (9 of 10) | 71% (5 of 7) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 2.0 | 3.0 |
| Movement | Points that never moved of their own | 218.0 | 198.3 |
| Movement | Fights charged into per game | 2.0 | 5.7 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 3, net +0 | 2 of 14, net +542 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 3, net +126 | 1 of 14, net -195 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 3 | 0 of 14 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 3 | 8 of 14, net +280 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.7 | 15.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 23% (8 of 35) | 18% (8 of 45) |
| Shooting | Points destroyed by shooting units | 65.0 | 0.0 |
| Shooting | Points destroyed by war machines | 23.3 | 0.0 |
| Magic | Magic missiles cast | 0.7 | 2.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 2) | 0% (0 of 6) |
| Magic | Wounds caused by magic missiles | 1.7 | 0.3 |
| Magic | Points destroyed by magic (all spells) | 15.0 | 21.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 0.0 / 1.3 / 0.0 | 1.7 / 0.3 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 151.0 | 942.0 |
| Combat | Points run down | 0.0 | 595.3 |
| Combat | Net points per charged fight, damage counted | -89 | +246 |
| Combat | Net per 100 charger points, damage counted | -51.0 | +67.6 |
| Combat | First round won (charged fights) | 33% | 88% |
| Combat | Net points per charged fight | -88 | +232 |
| Combat | Net points per supported fight / lone fight | +126 / -131 | +245 / +231 |
| Combat | Charged fights on a top-3 enemy unit | 4 of 6 | 10 of 17 |
| Game | Points lost | 1606.0 | 254.3 |
| Game | VP from objectives | 326.7 | 1000.0 |
| Game | Lone holders (player turns) | 1.0 | 8.0 |

- Mine won / drew / lost: 0 / 0 / 3 of 3 ended games (of 3); mean margin (Mine - Opponent) -2256 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 1860
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ccut-c940641-p34

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +55.6 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +29.3 | 0.0 | 0.0 |
| ARMY TABLE | 20.3 | -506.3 | 0.0 | 316.0 | 16.3 | +460.8 | 0.0 | 80.0 |
| ASSAILMENT BY POINTS | 0.7 | +1.3 | 0.0 | 243.7 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +2.2 | 0.0 | 0.0 | 0.7 | +5.9 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.3 | -1.2 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -122.9 | 131.0 | 0.0 |
| CAST JOB | 0.3 | +1.4 | 0.0 | 0.0 | 0.7 | +4.9 | 43.3 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.7 | +6.9 | 44.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.3 | +7.6 | 0.0 | 0.0 | 1.7 | +55.5 | 0.0 | 44.0 |
| CHAFF PASSED | - | - | - | - | 0.7 | -3.1 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.7 | +10.7 | 0.0 | 0.0 | 0.7 | +2.7 | 0.0 | 0.0 |
| CHARGE LOSSES | 12.7 | -1293.6 | 0.0 | 1224.3 | 7.3 | -202.8 | 0.0 | 195.0 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 0.0 | 152.0 | 4.0 | +0.0 | 683.0 | 65.0 |
| CLOSES ON WHAT IT BEATS | 4.7 | +0.0 | 0.0 | 36.7 | 15.0 | +0.0 | 0.0 | 204.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | - | - | - | - | 1.0 | +83.9 | 0.0 | 0.0 |
| COVER ONCE | 13.3 | -481.2 | 0.0 | 754.0 | 2.7 | -94.5 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -6.1 | 100.3 | 0.0 |
| DEPLOY BY FIGURES | 7.7 | +43.1 | 0.0 | 0.0 | 7.3 | +33.6 | 0.0 | 23.3 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.7 | -261.0 | 131.0 | 0.0 |
| EXACT ROUND | 1.0 | -3.9 | 22.0 | 76.0 | 5.3 | +25.6 | 782.0 | 65.0 |
| FALL BACK GOOD ORDER | 0.7 | +0.0 | 22.0 | 0.0 | 6.0 | +4.8 | 1151.3 | 65.0 |
| FALLS SHORT | 6.7 | +110.4 | 0.0 | 267.0 | 14.0 | +156.8 | 0.0 | 87.0 |
| FEATURE BUFFS | 2.0 | +13.8 | 0.0 | 0.0 | 1.3 | +13.3 | 0.0 | 44.0 |
| FIGHT TO THE END | - | - | - | - | 3.0 | +102.3 | 379.3 | 65.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 15.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 76.7 | +4678.5 | 341.0 | 2534.0 | 92.3 | +9056.8 | 1642.3 | 495.0 |
| FLANK NOT WEIGHED | 14.3 | +0.0 | 0.0 | 611.3 | 2.3 | +0.0 | 0.0 | 0.0 |
| FOCUS FIRE | - | - | - | - | 0.3 | +14.1 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | - | - | - | - | 1.7 | +332.1 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.0 | +26.8 | 22.0 | 76.0 | 7.3 | +702.3 | 1402.3 | 65.0 |
| FREED FROM HIS FIGHT | 15.3 | +0.0 | 0.0 | 538.7 | - | - | - | - |
| FRIEND SHOOTS FIRST | 1.3 | -8.7 | 0.0 | 0.0 | 1.3 | -6.8 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 1.0 | -10.4 | 241.7 | 0.0 |
| GOAL WALK | 10.0 | +652.2 | 0.0 | 286.7 | 5.3 | +376.1 | 0.0 | 30.0 |
| GUN FIGURES | 4.7 | +31.9 | 95.0 | 83.3 | - | - | - | - |
| HARD STAY DROPPED | 2.3 | +0.0 | 0.0 | 78.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 11.7 | +0.0 | 0.0 | 256.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 10.3 | +0.0 | 0.0 | 996.0 | 3.3 | +0.0 | 0.0 | 65.0 |
| HIS CHARGE DENIED | 0.3 | +2.3 | 0.0 | 76.0 | - | - | - | - |
| HIS CHARGE LIST | 6.0 | +0.0 | 0.0 | 61.7 | 0.3 | +0.0 | 0.0 | 22.0 |
| HIS LEGAL MOVES | 4.7 | +0.0 | 0.0 | 273.3 | 5.0 | +0.0 | 0.0 | 22.0 |
| HIS MOVE AND SHOT | 2.0 | -10.0 | 0.0 | 178.3 | 4.0 | -39.2 | 0.0 | 15.0 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 38.3 | +10.7 | 1462.7 | 0.0 |
| HIS MOVE WHY | 15.7 | +0.0 | 0.0 | 542.7 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 24.3 | -77.3 | 0.0 | 167.0 |
| HIS ONE QUARTER | 3.3 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 7.0 | +0.0 | 0.0 | 273.3 | 1.7 | +0.0 | 0.0 | 37.0 |
| HIS RANDOM MOVE | - | - | - | - | 4.3 | +0.0 | 0.0 | 15.0 |
| HIS RANDOM MOVER COMES | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 41.3 | +271.3 | 0.0 | 1367.7 | 31.7 | +805.7 | 0.0 | 174.0 |
| HIS SHOTS BY HIS RUN | 34.7 | +246.5 | 0.0 | 1187.3 | 29.3 | +465.9 | 0.0 | 400.0 |
| HIS TURN DENIED | 0.3 | +0.6 | 22.0 | 0.0 | 1.3 | +35.6 | 183.7 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 12.3 | +0.0 | 0.0 | 208.0 | 23.7 | +0.0 | 0.0 | 132.0 |
| HOLDER ASSIGNMENT | 7.0 | +452.0 | 0.0 | 104.0 | 12.7 | +984.5 | 0.0 | 44.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.3 | -0.5 | 22.0 | 0.0 | 7.0 | -227.1 | 1271.3 | 65.0 |
| HUNT IN PAIRS | - | - | - | - | 1.0 | +92.3 | 0.0 | 0.0 |
| IDLE COST | 1.7 | -22.1 | 0.0 | 121.7 | 11.7 | -159.6 | 0.0 | 30.0 |
| JOINT CHARGE NOW | - | - | - | - | 0.7 | +41.5 | 146.7 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.3 | -99.7 | 131.0 | 0.0 |
| JOINT LOOK BACK | - | - | - | - | 0.3 | +18.9 | 85.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 1.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +6.3 | 0.0 | 116.7 | 1.7 | +89.0 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.3 | +0.0 | 42.0 | 309.3 | 14.3 | +0.0 | 717.0 | 176.0 |
| LONE WIZARD KEPT IN | 0.3 | +16.1 | 0.0 | 0.0 | 0.7 | +39.2 | 0.0 | 0.0 |
| LONG SHOT | 1.7 | -4.8 | 0.0 | 119.3 | - | - | - | - |
| LOST AFTER ESCAPE | 0.3 | -0.2 | 22.0 | 0.0 | 4.7 | +11.9 | 728.7 | 65.0 |
| LURE BY WHAT IT DRAWS | 0.3 | -43.7 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 2.0 | -1.6 | 0.0 | 78.3 | 1.0 | -7.5 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.7 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.7 | +29.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.7 | +68.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.3 | +7.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | +6.2 | 0.0 | 180.0 | 0.3 | -11.6 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 6.3 | +174.6 | 0.0 | 127.3 | 1.3 | +62.7 | 0.0 | 0.0 |
| MEETS IN TIME | 3.7 | +210.7 | 0.0 | 0.0 | 2.3 | +191.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.3 | +37.9 | 0.0 | 115.7 | 3.0 | +38.2 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 4.3 | +68.3 | 0.0 | 295.7 | 4.0 | +26.4 | 0.0 | 0.0 |
| MOVE ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 65.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.3 | -14.5 | 0.0 | 135.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 4.0 | +137.8 | 0.0 | 0.0 | 13.3 | +1184.6 | 0.0 | 160.0 |
| MOVES UNITS SPELL | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 10.3 | +451.8 | 0.0 | 206.3 | 11.3 | +406.8 | 0.0 | 22.0 |
| NEXT CHARGE BY LIST | 2.0 | +59.7 | 0.0 | 0.0 | 6.7 | +577.7 | 0.0 | 160.0 |
| NO DOUBLE ROUNDS | 0.7 | -16.1 | 22.0 | 76.0 | 6.3 | -356.6 | 1140.3 | 65.0 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 5.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT WORTH A CAST | 1.3 | -0.7 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 3.0 | -90.1 | 0.0 | 0.0 | 5.3 | -182.5 | 78.3 | 66.0 |
| ONE CHALLENGE TEST | - | - | - | - | 0.3 | +10.6 | 115.7 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 3.7 | -28.7 | 0.0 | 76.0 | 8.7 | -188.1 | 0.0 | 80.0 |
| ONE OBJECTIVE FORMULA | 4.0 | -55.8 | 0.0 | 104.0 | 5.0 | -28.2 | 0.0 | 22.0 |
| ONE PROMISE A TARGET | 1.0 | -33.1 | 0.0 | 0.0 | 0.3 | -15.4 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +4.3 | 36.7 | 0.0 |
| OVERRUNS AWAY | 0.7 | +2.1 | 22.0 | 76.0 | 1.0 | +7.9 | 246.7 | 0.0 |
| PERIAPT WORTH | 0.3 | +18.1 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.3 | -14.1 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 36.3 | +177.9 | 87.0 | 2066.3 | 45.7 | +1006.1 | 912.3 | 405.0 |
| PROMISE BELOW ZERO | 0.7 | +0.0 | 0.0 | 18.3 | 0.7 | +0.0 | 0.0 | 65.0 |
| PROMISE BY ITS OWN SUM | 4.3 | -45.8 | 0.0 | 0.0 | 16.0 | -563.7 | 0.0 | 0.0 |
| PROMISE IN STEPS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 4.0 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 1.3 | -16.5 | 0.0 | 0.0 | 1.0 | -59.8 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | - | - | - | - | 1.0 | -1.2 | 0.0 | 0.0 |
| QUARTER ODDS | 17.0 | +1454.4 | 0.0 | 597.3 | 26.0 | +4170.0 | 584.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | -2.2 | 0.0 | 44.0 |
| REDIRECT COUNTER | 6.7 | +349.5 | 0.0 | 51.3 | 2.3 | +59.2 | 0.0 | 22.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.3 | +0.0 | 0.0 | 0.0 | 5.3 | +23.8 | 0.0 | 125.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | -1.2 | 0.0 | 0.0 |
| REFORMS TO MEET IT | - | - | - | - | 2.0 | -40.8 | 0.0 | 30.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 115.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 2.3 | +96.1 | 0.0 | 22.0 |
| RISK BY ARC | 0.3 | -2.6 | 0.0 | 76.0 | 5.3 | -46.2 | 1088.3 | 65.0 |
| RISK ON THE WAY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 5.7 | -211.1 | 1144.3 | 65.0 |
| RUN DOWN | - | - | - | - | 6.0 | -68.1 | 1091.3 | 65.0 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.3 | -12.3 | 0.0 | 0.0 | 0.7 | -9.2 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +60.4 | 0.0 | 0.0 | 1.0 | +79.8 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.7 | +70.2 | 115.0 | 0.0 |
| SELF MOVE SPELL | 2.0 | +5.9 | 0.0 | 217.3 | - | - | - | - |
| SET CREDITED ONCE | 1.0 | -13.5 | 0.0 | 0.0 | 1.7 | -42.7 | 0.0 | 0.0 |
| SET UP BY THE SET | 2.0 | +35.8 | 0.0 | 0.0 | 3.7 | +20.6 | 78.3 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +1.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 4.3 | +0.0 | 0.0 | 198.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 1.3 | +26.4 | 15.0 | 0.0 | 1.0 | +2.4 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.7 | -4.3 | 61.7 | 0.0 |
| SHOT RISK POINTS | 16.7 | -158.4 | 0.0 | 631.7 | 18.7 | +67.1 | 0.0 | 247.0 |
| SHOTS AFTER THE MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 12.0 | +317.3 | 0.0 | 359.3 | 14.3 | +124.8 | 0.0 | 66.0 |
| SPELL WORTH | 1.0 | +58.2 | 315.0 | 346.7 | - | - | - | - |
| SPOT AS THE GAME MOVES | 9.0 | +0.0 | 0.0 | 437.0 | 7.0 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | - | - | - | - | 1.0 | -6.3 | 178.3 | 0.0 |
| STANDS FOR A REASON | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 28.0 | +0.0 | 319.0 | 851.3 | 34.0 | +0.0 | 240.0 | 87.0 |
| STAY WORTH | 9.3 | +7.0 | 130.0 | 21.7 | 16.0 | +113.8 | 240.0 | 0.0 |
| STRIKE BY THE ODDS | - | - | - | - | 1.0 | -46.2 | 262.0 | 22.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 10.0 | +1258.8 | 0.0 | 77.0 | 5.0 | +147.9 | 0.0 | 22.0 |
| SUPPORT NARROWED | 0.7 | +0.0 | 0.0 | 152.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 10.0 | +1258.8 | 0.0 | 77.0 | 5.0 | +147.9 | 0.0 | 22.0 |
| SURE REACH TOGETHER | 1.3 | +9.2 | 0.0 | 0.0 | - | - | - | - |
| SWIFTSTRIDE BY POINTS | 1.0 | +1.9 | 0.0 | 139.3 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -10.1 | 0.0 | 0.0 | 0.3 | -19.1 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 4.7 | +0.0 | 0.0 | 100.3 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 3.0 | +0.0 | 0.0 | 25.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 2.7 | +0.0 | 0.0 | 47.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 5.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 35.7 | +0.0 | 0.0 | 1018.0 | 45.0 | +0.0 | 0.0 | 204.0 |
| TIED UP BY THE SUM | - | - | - | - | 2.0 | +272.4 | 333.0 | 0.0 |
| TIME ON OUR SIDE | 34.3 | +306.3 | 44.0 | 787.7 | 20.3 | +151.7 | 0.0 | 87.0 |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 22.0 |
| WAR ENGINE JOBS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | 0.3 | -1.0 | 0.0 | 0.0 | 1.0 | +61.4 | 393.0 | 0.0 |
| WHO FIGHTS | 0.3 | -1.9 | 22.0 | 0.0 | 1.7 | -1.2 | 262.7 | 65.0 |
| WHO GETS IN | - | - | - | - | 0.3 | -21.6 | 85.0 | 0.0 |
| WHO HITS BACK | 0.3 | +4.5 | 0.0 | 0.0 | 0.3 | +36.0 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +1.1 | 262.0 | 0.0 |
| WHOLE FIGHT DANGER | 5.3 | -1170.3 | 0.0 | 709.3 | 0.7 | -14.9 | 0.0 | 0.0 |
| WOUNDED STAYS OUT | - | - | - | - | 0.3 | +0.0 | 21.7 | 0.0 |
| WOUNDS ON THE RANKS | 1.0 | +23.9 | 0.0 | 0.0 | 0.3 | +1.4 | 0.0 | 0.0 |

### Rule changes: ccut-c940641-p34

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 115 | 115 | 83 | 27.67 | +0 | +0.0 |
| ARMY TABLE | 110 | 110 | 75 | 25.00 | +370 | +4.9 |
| HOLDER ASSIGNMENT | 59 | 59 | 53 | 17.67 | +2863 | +54.0 |
| LEGAL CHARGES ONLY | 53 | 53 | 53 | 17.67 | +0 | +0.0 |
| FIVE ACTION | 507 | 487 | 45 | 15.00 | +2301 | +51.1 |
| HIS SHOT LIST | 219 | 208 | 41 | 13.67 | +378 | +9.2 |
| HIS MOVE WHY | 47 | 47 | 31 | 10.33 | +0 | +0.0 |
| THE TABLE AGAIN | 35 | 35 | 31 | 10.33 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 26 | 26 | 26 | 8.67 | +63 | +2.4 |
| MOVE TO CHARGE COMPUTED | 52 | 46 | 25 | 8.33 | +869 | +34.7 |
| OFF BEST | 25 | 25 | 25 | 8.33 | -818 | -32.7 |
| HIS SHOTS BY HIS RUN | 192 | 182 | 24 | 8.00 | +173 | +7.2 |
| PROMISE BY ITS OWN SUM | 61 | 61 | 24 | 8.00 | -1828 | -76.2 |
| HARD STAY DROPPED | 21 | 21 | 21 | 7.00 | +0 | +0.0 |
| DEPLOY BY FIGURES | 45 | 45 | 19 | 6.33 | +155 | +8.1 |
| QUARTER ODDS | 129 | 124 | 19 | 6.33 | +1982 | +104.3 |
| HIS ONE MOVE | 73 | 72 | 18 | 6.00 | +0 | +0.0 |
| SHOT RISK POINTS | 106 | 101 | 17 | 5.67 | +201 | +11.8 |
| SUPPORT ADDS | 45 | 43 | 17 | 5.67 | +965 | +56.7 |
| SUPPORT WORKED OUT | 45 | 43 | 17 | 5.67 | +965 | +56.7 |
| MOVE ORDER | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| TIME ON OUR SIDE | 164 | 152 | 16 | 5.33 | +105 | +6.6 |
| GOAL WALK | 46 | 44 | 13 | 4.33 | +462 | +35.5 |
| FOUR ROUNDS | 25 | 22 | 12 | 4.00 | +500 | +41.7 |
| CHARGE LOSSES | 60 | 55 | 11 | 3.67 | +931 | +84.6 |
| NEXT CHARGE BY LIST | 26 | 25 | 10 | 3.33 | +548 | +54.8 |
| ADVANCE LANE KEPT | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| MEETS IN TIME | 18 | 18 | 8 | 2.67 | +507 | +63.4 |
| COVER ONCE | 48 | 37 | 7 | 2.33 | +42 | +6.0 |
| MAX FOR POSITIONING | 23 | 20 | 7 | 2.33 | +31 | +4.4 |
| RESERVE FALL BACK | 7 | 7 | 7 | 2.33 | +288 | +41.2 |
| SCOUT WAITS | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 79 | 64 | 7 | 2.33 | +358 | +51.1 |
| THE RISK READS HIS RUN | 18 | 18 | 7 | 2.33 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 18 | 16 | 7 | 2.33 | +287 | +41.0 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +286 | +47.6 |
| SHOOTS FROM THE BEST SPOT | 7 | 7 | 6 | 2.00 | +41 | +6.8 |
| CHAFF IN THE MOVE | 6 | 6 | 5 | 1.67 | +63 | +12.7 |
| FOLLOW UP WEIGHED | 5 | 5 | 5 | 1.67 | +996 | +199.2 |
| CASTER AWAY FROM SCREEN | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +40 | +10.0 |
| ONE PROMISE A TARGET | 4 | 4 | 4 | 1.33 | -146 | -36.4 |
| SET UP BY THE SET | 17 | 16 | 4 | 1.33 | +200 | +49.9 |
| EXACT ROUND | 19 | 16 | 3 | 1.00 | +67 | +22.4 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +166 | +55.3 |
| MARCH CHECK | 5 | 4 | 3 | 1.00 | +48 | +15.9 |
| PROMISE SHOT AWAY | 3 | 3 | 3 | 1.00 | -4 | -1.2 |
| SEARCH SPOT | 4 | 4 | 3 | 1.00 | +420 | +140.1 |
| SUPPORT NARROWED | 3 | 3 | 3 | 1.00 | -562 | -187.2 |
| SWIFTSTRIDE BY POINTS | 3 | 3 | 3 | 1.00 | +6 | +1.9 |
| TIED UP BY THE SUM | 6 | 4 | 3 | 1.00 | +77 | +25.5 |
| ASSAILMENT BY POINTS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | -9 | -4.7 |
| CHARGE NOW FIRST | 14 | 14 | 2 | 0.67 | -86 | -43.2 |
| FIGHT TO THE END | 9 | 8 | 2 | 0.67 | +26 | +12.9 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| IDLE COST | 40 | 19 | 2 | 0.67 | +18 | +8.8 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +125 | +62.3 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +90 | +44.8 |
| NEARER NOT NEEDED | 65 | 61 | 2 | 0.67 | +59 | +29.6 |
| PROMISE READS THE TABLE | 7 | 7 | 2 | 0.67 | -93 | -46.4 |
| REDIRECT COUNTER | 27 | 22 | 2 | 0.67 | +96 | +48.1 |
| RISK BY ARC | 17 | 16 | 2 | 0.67 | +47 | +23.5 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +210 | +105.2 |
| STAY WORTH | 76 | 68 | 2 | 0.67 | +0 | +0.1 |
| STRIKE BY THE ODDS | 3 | 3 | 2 | 0.67 | +7 | +3.3 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +36 | +18.0 |
| WOUNDS ON THE RANKS | 4 | 4 | 2 | 0.67 | +23 | +11.4 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +167 | +166.7 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +88 | +87.9 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -12 | -12.2 |
| CAST JOB | 3 | 3 | 1 | 0.33 | +2 | +2.4 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALLS SHORT | 62 | 54 | 1 | 0.33 | +0 | +0.0 |
| FEATURE BUFFS | 10 | 10 | 1 | 0.33 | +2 | +2.0 |
| FOCUS FIRE | 1 | 1 | 1 | 0.33 | +42 | +42.4 |
| HIS MOVE AND SHOT | 18 | 17 | 1 | 0.33 | +3 | +2.6 |
| HONEST WORTH | 22 | 19 | 1 | 0.33 | +17 | +17.3 |
| HUNT IN PAIRS | 3 | 1 | 1 | 0.33 | +18 | +18.5 |
| JOINT LOOK BACK | 1 | 1 | 1 | 0.33 | +57 | +56.8 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -21 | -21.2 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| NO DOUBLE ROUNDS | 21 | 18 | 1 | 0.33 | +17 | +17.3 |
| ONE FIGHT FORMULA | 37 | 21 | 1 | 0.33 | +23 | +22.6 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +54 | +54.4 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -42 | -42.4 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | -12 | -12.2 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +5 | +5.0 |
| SHOTS AFTER THE MOVES | 18 | 18 | 1 | 0.33 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 19 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO GETS IN | 1 | 1 | 1 | 0.33 | -65 | -64.7 |
| BACKUP TARGETS | 3 | 2 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CASTING BLOCK | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 59 | 57 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 20 | 18 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 50 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 46 | 45 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 8 | 8 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 14 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 35 | 35 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 41 | 39 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 19 | 19 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 29 | 28 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 32 | 31 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 26 | 25 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 13 | 11 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 7 | 5 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 5 | 5 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 108 | 108 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 19 | 19 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 1 | 1 | 0 | 0.00 | - | - |
| LONG SHOT | 5 | 5 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 15 | 13 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MANOEUVRE | 9 | 9 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 6 | 6 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 16 | 10 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 25 | 16 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 1 | trace | - | - | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 17 | 17 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 27 | 22 | 0 | 0.00 | - | - |
| ONE ROUTE | 6 | 6 | 0 | 0.00 | - | - |
| OPENS UP | 1 | not checked | - | - | - | - |
| OVERRUNS AWAY | 5 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 246 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 4 | 4 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 12 | 10 | 0 | 0.00 | - | - |
| RANDOM MOVE BY FIGURES | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 6 | 6 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 6 | 6 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 2 | 2 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 17 | 14 | 0 | 0.00 | - | - |
| RUN DOWN | 18 | 15 | 0 | 0.00 | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 8 | 7 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 26 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 3 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 48 | 43 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 3 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 6 | 4 | 0 | 0.00 | - | - |
| STANDS STILL | 186 | 180 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 4 | 2 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 4 | 4 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 3 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 12 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 1 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 11 | not checked | - | - | - | - |
| THE TABLE BINDS | 242 | not checked | - | - | - | - |
| WAITS AGAIN | 8 | 7 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 1 | 1 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 4 | 4 | 0 | 0.00 | - | - |
| WHO FIGHTS | 6 | 5 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p34

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 1.00 | 7.00 | 76.2 |
| JOB FIRST | gate | 2.67 | 3.67 | 29.3 |
| ARMY TABLE | rule | 3.33 | 0.67 | 107.1 |
| RULE SWITCHED OFF | gate | - | 1.67 | 48.4 |
| ONE PROMISE A TARGET | rule | 1.00 | 0.33 | 36.4 |
| SUPPORT NARROWED | rule | 0.67 | 0.33 | 187.2 |
| CHARGE NOW FIRST | rule | - | 0.67 | 43.2 |
| PROMISE READS THE TABLE | rule | - | 0.67 | 46.4 |
| PROMISE SHOT AWAY | rule | - | 0.67 | 1.7 |
| BEST PRIZE | rule | - | 0.33 | 12.2 |
| CHAFF PASSED | rule | - | 0.33 | 9.3 |
| DEPLOY BY FIGURES | rule | 0.33 | - | 1.1 |
| HOLDER ASSIGNMENT | rule | - | 0.33 | 12.5 |
| JOINT CHARGE NOW | rule | - | 0.33 | 64.7 |
| MARCH OF THE TABLE | rule | 0.33 | - | 21.2 |
| NO REASON | gate | 0.33 | - | 19.9 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 42.4 |
| REDIRECT WEIGHED | rule | - | 0.33 | 12.2 |
| WHO GETS IN | rule | - | 0.33 | 64.7 |

### Plans: ccut-c940641-p34

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.3 | 100% | 9 | 22 | 257% |
| Mine | move | 31.7 | 89% | 1871 | 0 | 0% |
| Mine | shoot | 4.0 | 50% | 638 | 156 | 24% |
| Mine | support | 0.3 | 100% | 0 | 0 | - |
| Opponent | charge | 6.0 | 78% | 1268 | 869 | 69% |
| Opponent | join | 2.3 | 100% | 97 | 0 | 0% |
| Opponent | move | 33.0 | 96% | 2009 | 0 | 0% |
| Opponent | shoot | 3.7 | 64% | 380 | 137 | 36% |
| Opponent | support | 0.7 | 100% | 13 | 0 | 0% |

### Battle groups: ccut-c940641-p34

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 6.7 | 10% | 100% | 100% | 50% | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 2.3 | 43% | 67% | 0% | - | 33% | 0% | 0% | 67% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p34

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Mine | Chaff | 7 | 47 (7) | 38 | 9 | 50 | 29% | 2.8 | 53 (6) | 0 (1) | - | 47 (7) | - |
| Mine | Character | 8 | 7 (8) | 7 | 0 | 116 | 12% | 2.4 | 0 (2) | - | 0 (1) | - | 0 (3) |
| Mine | Clean-up | 4 | 48 (4) | 0 | 48 | 31 | 75% | 5.0 | 77 (2) | 0 (1) | 0 (1) | 156 (1) | 0 (3) |
| Mine | Fast Hammer | 1 | 6 (1) | 6 | 0 | 115 | 0% | 4.0 | 6 (1) | - | - | - | 6 (1) |
| Mine | Hammer | 11 | 21 (11) | 21 | 0 | 87 | 9% | 2.0 | 10 (3) | 29 (7) | 0 (1) | 8 (4) | 29 (7) |
| Mine | Shooter | 3 | 0 (3) | 0 | 0 | 67 | 0% | 1.7 | 0 (2) | 0 (1) | - | 0 (1) | 0 (2) |
| Mine | Wizard | 2 | 7 (2) | 7 | 0 | 126 | 0% | 2.0 | - | - | - | - | - |
| Opponent | Chaff | 8 | 132 (8) | 11 | 121 | 47 | 50% | 1.0 | 252 (2) | 123 (4) | 0 (2) | 201 (5) | 0 (3) |
| Opponent | Character | 8 | 137 (8) | 137 | 0 | 0 | 12% | 2.6 | 113 (5) | 176 (3) | - | 191 (3) | 106 (5) |
| Opponent | Clean-up | 4 | 39 (4) | 39 | 0 | 0 | 75% | 1.0 | 0 (2) | 52 (2) | - | 0 (2) | 52 (2) |
| Opponent | Fast Hammer | 7 | 90 (7) | 90 | 0 | 36 | 57% | 2.3 | 97 (2) | 84 (5) | - | 214 (4) | 0 (3) |
| Opponent | Holder | 4 | 159 (4) | 0 | 159 | 0 | 0% | 1.8 | 350 (2) | - | 0 (2) | 350 (2) | 0 (2) |
| Opponent | Shooter | 4 | 0 (4) | 0 | 0 | 12 | 0% | 1.5 | 0 (2) | 0 (2) | - | 0 (2) | 0 (2) |
| Opponent | Wizard | 3 | 17 (3) | 17 | 0 | 0 | 0% | 2.3 | 0 (1) | 0 (1) | 76 (1) | - | 17 (3) |

### Charged fights: ccut-c940641-p34

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 1 | 265 | 126 | 2.0 | 1.5 | 63 | 114 | -51 | 1 of 2 | 1 of 2 | +126 | -228 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 132 | 3.0 | 1.0 | 44 | 187 | -143 | 2 of 3 | 1 of 3 | - | -143 |
| Mine | Skaven | 1 | 45 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| **Mine** | all armies | 3 | 103 | 86 | 2.0 | 1.2 | 43 | 132 | -88 | 4 of 6 | 2 of 6 | +126 | -131 |
| Opponent | Tomb Kings of Khemri | 2 | 0 | 1616 | 6.0 | 1.2 | 269 | 16 | +253 | 6 of 12 | 11 of 12 | +245 | +255 |
| Opponent | Vampire Counts | 1 | 65 | 910 | 5.0 | 1.0 | 182 | 0 | +182 | 4 of 5 | 4 of 5 | - | +182 |
| **Opponent** | all armies | 3 | 22 | 1381 | 5.7 | 1.1 | 244 | 11 | +232 | 10 of 17 | 15 of 17 | +245 | +231 |

### Effective charges: ccut-c940641-p34

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 2 | 0 | 0 | 1 (net +126) | 1 (net -228) | 0 | 0 | 0 | 50% (1 of 2) |
| Mine | Skaven | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 12 | 1 (net +1084) | 0 | 1 (net -195) | 2 (net +189) | 0 | 6 (net +238) | 2 | 10% (1 of 10) |
| Opponent | Vampire Counts | 5 | 1 (net +0) | 0 | 0 | 1 (net +95) | 0 | 2 (net +408) | 1 | 0% (0 of 4) |

### Charged fights, damage counted: ccut-c940641-p34

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 0 | 254 | +0 | 0 | 0 | +0 | - |
| Mine | Effective (55-75%) | 1 | 68 | 66 | +126 | 126 | 34 | +92 | +135.3 |
| Mine | 76-89% | 1 | 228 | 195 | -228 | 32 | 228 | -196 | -85.7 |
| Mine | No odds | 3 | 249 | 312 | -143 | 44 | 187 | -143 | -57.4 |
| Mine | All fights | 6 | 174 | 242 | -88 | 48 | 137 | -89 | -51.0 |
| Opponent | Long shot (under 50%) | 2 | 122 | 276 | +542 | 542 | 0 | +542 | +442.4 |
| Opponent | Effective (55-75%) | 1 | 195 | 235 | -195 | 0 | 195 | -195 | -100.0 |
| Opponent | 76-89% | 3 | 290 | 173 | +158 | 187 | 0 | +187 | +64.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 8 | 445 | 271 | +280 | 299 | 0 | +299 | +67.1 |
| Opponent | No odds | 3 | 440 | 168 | +115 | 115 | 0 | +115 | +26.1 |
| Opponent | All fights | 17 | 364 | 234 | +232 | 258 | 11 | +246 | +67.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p34 | move | 26 | 5 (19%) | 5 (19%) | 5 (19%) | 16 (62%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L2025 |
| Elixir of Power | Mine | L1923 |
| Fistful of Laurels | Mine | L1823 |
| Invocation of Nehek | Opponent | L2025 |
| Periapt of Soul Exchange | Mine | L2025 |

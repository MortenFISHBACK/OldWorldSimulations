# Doctrine scorecard: ccut-c940641-p10

### Scorecard: ccut-c940641-p10

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1823 | 5 | 1 | Mine | no | - | 5 | 0 | 4 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 1 | 1 | 2 | 1 | 0 | 0 | 142 |
| L1923 | 3 | 1 | Mine | no | 1 | 1 | 7 | 0 | 0 | 0 | 0 | 255 |
| L1923 | 3 | 1 | Opponent | yes | 10 | 2 | 4 | 2 | 0 | 0 | 0 | 257 |
| L2025 | 3 | 1 | Mine | yes | 4 | - | 1 | 1 | 0 | 0 | 0 | 420 |
| L2025 | 3 | 1 | Opponent | no | 8 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 33% | 2.5 | 3.0 | 2.7 | 1.7 | 0.0 | 0.0 | 0.0 | 225.0 |
| **Average** | | | Opponent | 67% | 9.0 | 1.7 | 3.3 | 2.0 | 0.3 | 0.0 | 0.0 | 133.0 |

### KPIs: ccut-c940641-p10

Rules off - Mine only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 13) | 7% (1 of 15) | 4% (1 of 28) |
| Winner chose to follow up after the loser gave ground |  | 80% (4 of 5); on the table 80% | 100% (2 of 2); on the table 100% | 86% (6 of 7); on the table 86% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 43% (3 of 7); on the table 57% | 43% (3 of 7); on the table 57% |
| Winner chose to follow up or pursue (all three) |  | 80% (4 of 5); on the table 80% | 60% (6 of 10); on the table 70% | 67% (10 of 15); on the table 73% |
| Magic missiles tried each own turn | 50%+ | 17% (5 of 30) | 50% (9 of 18) | 29% (14 of 48) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 25% (5 of 20) | 50% (9 of 18) | 37% (14 of 38) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 43% (3 of 7) | - | 43% (3 of 7) |
| Points that never fought | lower | 40% (2376 of 5999) | 50% (3024 of 5999) | 45% (5400 of 11998) |
|   infantry points that never fought | lower | 75% (741 of 993) | 74% (770 of 1037) | 74% (1511 of 2030) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 41% (9 of 22) | 56% (9 of 16) | 47% (18 of 38) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (1 of 2); 0.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 49% (2540 of 5151) | 54% (2427 of 4500) | 51% (4967 of 9651) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (4%) | 2.7 (89%) | 3.0 (26%) |
| MARCHED: its unit marched | 1.3 (16%) | 0.3 (11%) | 1.7 (15%) |
| CHARGED: its unit charged | 1.3 (16%) | 0.0 (0%) | 1.3 (12%) |
| IN COMBAT: engaged in combat | 1.3 (16%) | 0.0 (0%) | 1.3 (12%) |
| REAR RANK: in a rear rank | 1.0 (12%) | 0.0 (0%) | 1.0 (9%) |
| GONE: slain | 0.7 (8%) | 0.0 (0%) | 0.7 (6%) |
| OFF THE TABLE: off the table or not arrived | 1.3 (16%) | 0.0 (0%) | 1.3 (12%) |
| NOT OFFERED: not in the cast list | 1.0 (12%) | 0.0 (0%) | 1.0 (9%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 1.7 | 1.7 | 4.7 | 0.7 |
| not cast | 6.0 | 0.3 | 4.3 | 11.3 | 19.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (100%) | 0.0 (0%) | 3.0 (26%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (15%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (12%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (12%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (33%) | 0.0 (0%) | 2.0 (46%) | 1.0 (9%) | 0.0 (0%) |
| GONE: slain | 0.3 (6%) | 0.0 (0%) | 0.3 (8%) | 0.7 (6%) | 0.3 (2%) |
| OFF THE TABLE: off the table or not arrived | 1.3 (22%) | 0.0 (0%) | 0.0 (0%) | 1.3 (12%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (9%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (39%) | 0.0 (0%) | 2.0 (46%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.7 (97%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.7 a game | 0.8 a game |
| stood (cast and not dispelled) | - | 60% (3 of 5) | 60% (3 of 5) |
| the unit moved after it | - | 100% (3 of 3) | 100% (3 of 3) |
| it charged on its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| the enemy charged it first | - | 0% (0 of 3) | 0% (0 of 3) |
| it fought by the end of its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 3) | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (3 of 3) | 100% (3 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 53% (30 of 57) | 66% (51 of 77) | 60% (81 of 134) |
|   cavalry | - | 93% (14 of 15) | 93% (14 of 15) |
|   character | 83% (5 of 6) | 0% (0 of 18) | 21% (5 of 24) |
|   chariot | 100% (11 of 11) | - | 100% (11 of 11) |
|   infantry | 29% (8 of 28) | 84% (37 of 44) | 62% (45 of 72) |
|   monster | 50% (6 of 12) | - | 50% (6 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (30%) | 0.0 (0%) | 2.7 (15%) |
| CHARGED: it charged | 0.7 (7%) | 0.7 (8%) | 1.3 (8%) |
| IN COMBAT: it fought this turn or the last | 0.3 (4%) | 0.3 (4%) | 0.7 (4%) |
| NO TARGET IN RANGE | 4.3 (48%) | 5.0 (58%) | 9.3 (53%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 2.0 (23%) | 2.0 (11%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.0 (11%) | 0.7 (8%) | 1.7 (9%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.3 | 2.7 | 56% | 11.0 pts | 58 pts |
| character | 1.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| chariot | 4.0 | 6.3 | 42% | 48.2 pts | 193 pts |
| infantry | 17.7 | 7.3 | 75% | 7.8 pts | 139 pts |
| monster | 2.0 | 0.0 | 100% | 0.0 pts | 0 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.3 | 5.7 | 5.0 |
| Charges that made contact a game | 3.7 | 3.7 | 3.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 4.00 declared, 1.00 contact (1 units) | 4.00 declared, 1.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.46 declared, 0.39 contact (28 units) | 0.43 declared, 0.33 contact (30 units) | 0.45 declared, 0.36 contact (58 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | - | 67% (2 of 3) | - | 67% (2 of 3) |
| Character in a unit | 100% (1 of 1) | 100% (1 of 1) | - | 100% (2 of 2) |
| Character on its own | 0% (0 of 4) | 33% (1 of 3) | 57% (4 of 7) | 36% (5 of 14) |
| Chariot | 0% (0 of 2) | - | - | 0% (0 of 2) |
| Infantry | 33% (2 of 6) | - | - | 33% (2 of 6) |
| Monster | 50% (2 of 4) | 33% (1 of 3) | - | 43% (3 of 7) |
| Monstrous | - | 100% (4 of 4) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ogre Kingdoms | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 61% | 43% (3 of 7) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (2 of 2); on the table 100% | 17% (2 of 12) | 0% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 50% (1 of 2); on the table 50% | 25% (3 of 12) | 58% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Tomb Kings of Khemri | 2 | 56% (5 of 9); on the table 67% | 17% (1 of 6) | 51% | 50% (5 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (1 of 1); on the table 100% | 67% (8 of 12) | 50% | 67% (4 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p10, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 40% (4) | 60% (3) | 47% (7) |
| ...free all their last turn and able to turn (per game) | 1.00 | 1.00 | 2.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.67 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: ccut-c940641-p10

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.7 | 2.3 |
| Strategy | Charge objectives carried out (made contact) | 86% (6 of 7) | 56% (9 of 16) |
| Strategy | Shoot objectives carried out (shot that target) | 31% (4 of 13) | 86% (18 of 21) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | 50% (1 of 2) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 0% (0 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 0% (0 of 2) |
| Strategy | Joined characters whose unit fought | 0% (0 of 1) | 0% (0 of 3) |
| Strategy | Lone characters that fought | 78% (7 of 9) | 50% (4 of 8) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.7 | 2.0 |
| Movement | Points that never moved of their own | 225.0 | 133.0 |
| Movement | Fights charged into per game | 3.0 | 3.3 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 6, net +0 | 3 of 8, net -166 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 6, net +66 | 0 of 8 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 6, net +66 | 1 of 8, net +0 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 6, net +147 | 3 of 8, net +163 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.3 | 19.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 19% (6 of 31) | 33% (19 of 58) |
| Shooting | Points destroyed by shooting units | 0.0 | 11.3 |
| Shooting | Points destroyed by war machines | 46.7 | 0.0 |
| Magic | Magic missiles cast | 1.3 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 4) | 50% (2 of 4) |
| Magic | Wounds caused by magic missiles | 1.0 | - |
| Magic | Points destroyed by magic (all spells) | 15.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.0 / 0.3 / 0.0 | 1.0 / 0.7 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 369.3 | 310.3 |
| Combat | Points run down | 0.0 | 403.0 |
| Combat | Net points per charged fight, damage counted | +20 | +202 |
| Combat | Net per 100 charger points, damage counted | +9.7 | +71.6 |
| Combat | First round won (charged fights) | 67% | 70% |
| Combat | Net points per charged fight | +36 | +179 |
| Combat | Net points per supported fight / lone fight | +130 / +8 | +0 / +199 |
| Combat | Charged fights on a top-3 enemy unit | 4 of 9 | 5 of 10 |
| Game | Points lost | 963.7 | 431.0 |
| Game | VP from objectives | 446.7 | 1093.3 |
| Game | Lone holders (player turns) | 2.5 | 9.0 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -1305 VP
- The side that went first won 3 of 3 games with a winner
- Points traded per game (both sides' losses): 1395
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: ccut-c940641-p10

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +32.6 | 0.0 | 0.0 |
| ARMY TABLE | 20.0 | -251.4 | 0.0 | 78.3 | 19.0 | +138.7 | 0.0 | 44.0 |
| ASSAILMENT BY POINTS | 0.3 | +0.3 | 0.0 | 108.7 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +2.2 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | - | - | - | - | 0.3 | -8.3 | 21.7 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -263.9 | 131.0 | 0.0 |
| CAST JOB | - | - | - | - | 0.3 | +1.6 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 1.7 | +25.6 | 66.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | -2.9 | 78.3 | 42.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | -23.2 | 11.7 | 84.7 |
| CHARGE LOSSES | 19.3 | -1305.0 | 0.0 | 294.3 | 12.0 | -436.8 | 0.0 | 268.0 |
| CHARGE NOT DECLARED | 0.3 | +0.0 | 22.0 | 0.0 | - | - | - | - |
| CHARGE NOW FIRST | 0.7 | +0.0 | 87.0 | 0.0 | 3.0 | +0.0 | 370.0 | 16.7 |
| CLOSES ON WHAT IT BEATS | 4.0 | +0.0 | 0.0 | 0.0 | 16.0 | +0.0 | 0.0 | 208.3 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 70.0 | 1.0 | +0.0 | 273.3 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 0.7 | +22.2 | 0.0 | 0.0 |
| COVER ONCE | 9.7 | -415.6 | 0.0 | 107.3 | 3.0 | -102.9 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 7.7 | +43.1 | 0.0 | 36.7 | 7.3 | +33.6 | 0.0 | 23.3 |
| EDGE GIVE GROUND | 0.7 | +16.0 | 130.0 | 0.0 | 0.3 | +4.1 | 85.0 | 0.0 |
| EXACT ROUND | 1.0 | +1.2 | 87.0 | 29.7 | 4.3 | -30.6 | 534.3 | 65.0 |
| FALL BACK GOOD ORDER | 1.0 | +0.0 | 44.0 | 29.7 | 4.3 | +19.0 | 278.3 | 81.7 |
| FALLS SHORT | 2.0 | +19.0 | 0.0 | 103.3 | 15.0 | +146.6 | 0.0 | 186.7 |
| FEATURE BUFFS | 2.3 | +5.7 | 0.0 | 0.0 | 0.7 | +6.9 | 0.0 | 44.0 |
| FIGHT TO THE END | - | - | - | - | 3.0 | +0.2 | 256.7 | 101.3 |
| FIRE IN ORDER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 75.0 | +4593.3 | 312.3 | 686.3 | 97.3 | +7815.7 | 1242.0 | 1113.7 |
| FLANK NOT WEIGHED | 11.3 | +0.0 | 0.0 | 29.7 | 4.0 | +0.0 | 0.0 | 139.0 |
| FOLLOW UP WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +98.3 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.3 | +77.1 | 223.0 | 29.7 | 5.7 | +612.1 | 557.7 | 166.3 |
| FREED FROM HIS FIGHT | 11.0 | +0.0 | 0.0 | 171.3 | 1.3 | +0.0 | 0.0 | 25.0 |
| FRIEND SHOOTS FIRST | 0.7 | -4.4 | 0.0 | 11.3 | 1.3 | -11.5 | 0.0 | 23.3 |
| GIVES UP | - | - | - | - | 1.0 | -20.0 | 33.3 | 84.7 |
| GOAL WALK | 9.3 | +655.8 | 0.0 | 0.0 | 7.7 | +497.1 | 0.0 | 130.0 |
| GUN FIGURES | 5.0 | +88.8 | 118.3 | 43.3 | - | - | - | - |
| HARD STAY DROPPED | 2.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 8.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 14.3 | +0.0 | 0.0 | 163.3 | 6.3 | +0.0 | 0.0 | 268.0 |
| HIS CHARGE DENIED | 1.0 | +114.5 | 130.0 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 3.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 22.0 |
| HIS LEGAL MOVES | 4.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 1.0 | -3.1 | 0.0 | 85.0 | 6.3 | -73.5 | 0.0 | 80.0 |
| HIS MOVE AS HE DECIDES | 44.3 | +18.3 | 698.0 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 35.0 | +0.0 | 0.0 | 400.7 |
| HIS ONE MOVE | 18.3 | -133.9 | 0.0 | 238.7 | - | - | - | - |
| HIS ONE QUARTER | 6.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 98.0 |
| HIS OWN BEST MOVE | 4.3 | +0.0 | 0.0 | 0.0 | 8.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 14.0 | +0.0 | 0.0 | 480.3 |
| HIS RANDOM MOVER COMES | - | - | - | - | 5.3 | +0.0 | 0.0 | 267.3 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 5.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 40.0 | +348.7 | 0.0 | 586.7 | 26.3 | +614.9 | 0.0 | 250.7 |
| HIS SHOTS BY HIS RUN | 38.0 | +230.7 | 0.0 | 442.0 | 37.7 | +551.4 | 0.0 | 418.7 |
| HIS TURN DENIED | 0.7 | +1.7 | 44.0 | 11.3 | - | - | - | - |
| HIS TURN RUN | 5.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 15.0 | +0.0 | 0.0 | 128.0 | 19.3 | +0.0 | 0.0 | 256.0 |
| HOLDER ASSIGNMENT | 8.0 | +588.8 | 0.0 | 82.3 | 10.7 | +960.6 | 0.0 | 106.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.7 | -56.4 | 158.0 | 29.7 | 4.3 | -152.9 | 479.3 | 84.7 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +13.1 | 0.0 | 0.0 |
| IDLE COST | 1.3 | -33.8 | 0.0 | 0.0 | 11.7 | -180.9 | 0.0 | 170.0 |
| JOINT CHARGE NOW | 0.7 | -30.8 | 130.0 | 0.0 | 1.3 | +80.2 | 23.3 | 0.0 |
| JOINT KNOWS CHALLENGE | - | - | - | - | 0.3 | -7.1 | 11.7 | 84.7 |
| KEPT FROM ITS LAST STOP | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +6.3 | 0.0 | 0.0 | 1.7 | +89.0 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.3 | +0.0 | 171.7 | 240.7 | 10.0 | +0.0 | 782.3 | 128.0 |
| LONE WIZARD KEPT IN | 0.3 | +16.1 | 0.0 | 0.0 | 0.7 | +39.2 | 0.0 | 0.0 |
| LONG SHOT | 0.3 | -10.9 | 65.0 | 0.0 | 0.7 | +13.0 | 11.7 | 16.7 |
| LOST AFTER ESCAPE | 0.3 | -0.2 | 22.0 | 11.3 | 3.3 | +4.7 | 186.0 | 166.3 |
| LOST CHARGE | - | - | - | - | 0.3 | -0.2 | 85.0 | 0.0 |
| MANOEUVRE | 1.3 | +8.8 | 0.0 | 0.0 | 0.7 | -4.1 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.7 | +5.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 1.3 | +137.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 2.0 | +80.3 | 0.0 | 64.0 | - | - | - | - |
| MARCH OVER CASTS | 1.0 | -28.2 | 0.0 | 0.0 | 0.7 | +101.1 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.7 | +50.9 | 0.0 | 11.3 | 2.3 | +34.5 | 0.0 | 63.3 |
| MEETS IN TIME | 3.7 | +210.7 | 0.0 | 18.3 | 2.3 | +191.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.3 | +31.9 | 0.0 | 64.0 | 3.7 | +26.3 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 4.3 | +37.6 | 0.0 | 64.0 | 4.3 | +17.6 | 0.0 | 0.0 |
| MOVE ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 25.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 4.7 | +291.5 | 0.0 | 22.7 | 10.7 | +1031.1 | 0.0 | 305.7 |
| MOVES UNITS SPELL | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 7.7 | +300.4 | 0.0 | 64.0 | 13.3 | +488.5 | 0.0 | 44.0 |
| NEXT CHARGE BY LIST | 0.7 | +56.0 | 0.0 | 0.0 | 5.0 | +617.9 | 0.0 | 192.7 |
| NO DOUBLE ROUNDS | 1.3 | -12.9 | 152.0 | 29.7 | 5.0 | -281.8 | 441.0 | 149.7 |
| NO LATE CUT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.3 | -0.5 | 0.0 | 31.7 | - | - | - | - |
| OFF BEST | 2.7 | -89.2 | 0.0 | 85.0 | 7.7 | -450.3 | 0.0 | 84.0 |
| ONE CHECK AFTER THE LAST CHANGE | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 23.3 |
| ONE FIGHT FORMULA | 4.7 | -59.3 | 0.0 | 29.7 | 7.3 | -150.7 | 0.0 | 197.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | +0.8 | 0.0 | 81.7 |
| ONE OBJECTIVE FORMULA | 5.0 | -77.5 | 0.0 | 64.0 | 5.0 | +10.1 | 0.0 | 64.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | -8.5 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.7 | +59.2 | 41.7 | 0.0 |
| OVERRUNS AWAY | 0.7 | +15.4 | 87.0 | 11.3 | 0.7 | +3.6 | 0.0 | 0.0 |
| PERIAPT WORTH | 0.3 | +18.1 | 0.0 | 0.0 | - | - | - | - |
| PIVOT GUARDS FLANK | 0.3 | -4.4 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 35.7 | +243.3 | 220.7 | 853.7 | 46.3 | +891.9 | 192.7 | 714.7 |
| PROMISE BY ITS OWN SUM | 5.7 | -60.8 | 0.0 | 11.3 | 16.0 | -650.9 | 0.0 | 113.0 |
| PROMISE IN STEPS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.0 | +0.0 | 0.0 | 0.0 | 3.0 | -2.7 | 0.0 | 184.3 |
| PROMISE READS THE TABLE | 1.0 | -14.5 | 0.0 | 11.3 | 0.7 | -10.2 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | - | - | - | - | 2.0 | -1.6 | 0.0 | 0.0 |
| QUARTER ODDS | 19.3 | +1907.2 | 179.0 | 131.0 | 24.0 | +3031.0 | 247.7 | 196.0 |
| RANDOM MOVE BY FIGURES | 2.3 | +31.5 | 0.0 | 70.0 | - | - | - | - |
| REAL GROUND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 3.7 | +214.9 | 0.0 | 11.3 | 3.3 | +126.3 | 0.0 | 106.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.0 | +0.0 | 0.0 | 29.7 | 3.0 | +0.0 | 0.0 | 59.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -19.3 | 0.0 | 0.0 | 1.7 | -69.4 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 84.7 |
| RESERVE FALL BACK | - | - | - | - | 1.7 | +51.6 | 0.0 | 49.0 |
| RESTRAINS TO SHOOT | 0.3 | +2.7 | 0.0 | 0.0 | 0.3 | +9.0 | 0.0 | 0.0 |
| RISK BY ARC | 1.0 | -5.1 | 87.0 | 18.3 | 3.3 | -13.7 | 275.0 | 81.7 |
| RISK ON THE WAY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 3.0 | -157.5 | 326.0 | 101.3 |
| RUN DOWN | - | - | - | - | 4.0 | -48.5 | 335.0 | 166.3 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | - | - | - | - | 2.0 | +115.1 | 0.0 | 22.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +1.6 | 70.0 | 0.0 |
| SELF MOVE SPELL | 1.7 | -3.2 | 0.0 | 108.7 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 0.7 | -28.7 | 0.0 | 15.0 |
| SET UP BY THE SET | 0.7 | -1.7 | 0.0 | 0.0 | 1.7 | +17.5 | 78.3 | 15.0 |
| SET UP TOGETHER | - | - | - | - | 0.7 | +0.8 | 0.0 | 23.3 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +1.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 2.7 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 2.0 | +89.4 | 23.3 | 0.0 | 2.0 | +17.0 | 78.3 | 0.0 |
| SHOT OR CHARGE | 0.3 | -2.3 | 0.0 | 0.0 | 0.3 | -69.3 | 131.0 | 0.0 |
| SHOT RISK POINTS | 19.3 | -214.1 | 0.0 | 271.0 | 18.3 | +39.3 | 0.0 | 235.7 |
| SHOTS AFTER THE MOVES | 1.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 10.0 | +235.1 | 0.0 | 43.3 | 18.0 | +354.8 | 0.0 | 106.0 |
| SPELL WORTH | 1.3 | +28.8 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 7.3 | +0.0 | 0.0 | 364.3 | 4.3 | +0.0 | 0.0 | 108.0 |
| STAND AND SHOOT | 0.3 | -0.5 | 0.0 | 18.3 | 1.0 | -8.4 | 21.7 | 0.0 |
| STANDS FOR A REASON | 1.3 | +0.0 | 22.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 23.7 | +0.0 | 89.3 | 155.0 | 36.7 | +0.0 | 684.3 | 0.0 |
| STAY WORTH | 8.7 | +34.8 | 22.0 | 0.0 | 22.3 | +201.4 | 344.0 | 42.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.7 | -71.4 | 262.0 | 0.0 |
| STUPIDITY NEXT TURN | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 10.7 | +1274.1 | 0.0 | 0.0 | 5.0 | +170.9 | 0.0 | 45.3 |
| SUPPORT NARROWED | 0.3 | +0.0 | 65.0 | 0.0 | 0.3 | +0.0 | 0.0 | 16.7 |
| SUPPORT WORKED OUT | 10.7 | +1274.1 | 0.0 | 0.0 | 5.0 | +170.9 | 0.0 | 45.3 |
| SURE REACH TOGETHER | - | - | - | - | 0.7 | +1.5 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -10.1 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 5.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 3.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 3.3 | +0.0 | 0.0 | 85.7 | 2.3 | +0.0 | 0.0 | 84.7 |
| THE ROW READS HIS LAST RUN | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE STEP BACK IS MADE | 2.3 | +0.0 | 0.0 | 21.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 5.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 32.7 | +0.0 | 0.0 | 137.0 | 47.7 | +0.0 | 0.0 | 473.7 |
| TIED UP BY THE SUM | 0.7 | +103.2 | 87.0 | 0.0 | 1.3 | +166.0 | 190.0 | 0.0 |
| TIME ON OUR SIDE | 31.7 | +339.4 | 44.0 | 118.7 | 21.0 | +181.1 | 0.0 | 84.0 |
| WAITS AGAIN | 2.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 23.3 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 23.3 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -105.0 | 233.3 | 0.0 |
| WHO FIGHTS | 0.7 | -2.4 | 22.0 | 29.7 | 1.3 | +30.3 | 43.3 | 0.0 |
| WHO HITS BACK | 1.0 | +26.2 | 0.0 | 23.0 | - | - | - | - |
| WHOLE FIGHT | - | - | - | - | 0.3 | +17.8 | 116.7 | 0.0 |
| WHOLE FIGHT DANGER | 6.3 | -1077.6 | 0.0 | 78.3 | 3.7 | -225.7 | 0.0 | 203.0 |
| WOUNDS ON THE RANKS | 2.0 | +133.9 | 0.0 | 131.0 | 1.0 | +0.9 | 0.0 | 0.0 |

### Rule changes: ccut-c940641-p10

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 133 | 133 | 78 | 26.00 | +0 | +0.0 |
| ARMY TABLE | 117 | 117 | 76 | 25.33 | +243 | +3.2 |
| HIS MOVE WHY | 105 | 105 | 64 | 21.33 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 56 | 56 | 50 | 16.67 | +3240 | +64.8 |
| FIVE ACTION | 517 | 496 | 45 | 15.00 | +2787 | +61.9 |
| LEGAL CHARGES ONLY | 40 | 40 | 40 | 13.33 | +0 | +0.0 |
| HIS SHOT LIST | 199 | 183 | 37 | 12.33 | +292 | +7.9 |
| THE TABLE AGAIN | 33 | 33 | 32 | 10.67 | +0 | +0.0 |
| OFF BEST | 31 | 31 | 31 | 10.33 | -1618 | -52.2 |
| HIS SHOTS BY HIS RUN | 227 | 213 | 29 | 9.67 | +157 | +5.4 |
| QUARTER ODDS | 130 | 126 | 28 | 9.33 | +1647 | +58.8 |
| PROMISE BY ITS OWN SUM | 65 | 65 | 27 | 9.00 | -2135 | -79.1 |
| MOVE TO CHARGE COMPUTED | 46 | 38 | 25 | 8.33 | +907 | +36.3 |
| DEPLOY BY FIGURES | 45 | 45 | 19 | 6.33 | +155 | +8.1 |
| REDIRECT FOR A FRIEND IN REACH | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| TIME ON OUR SIDE | 158 | 138 | 18 | 6.00 | +46 | +2.6 |
| HIS ONE MOVE | 55 | 54 | 17 | 5.67 | +0 | +0.0 |
| HARD STAY DROPPED | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| GOAL WALK | 51 | 47 | 15 | 5.00 | +491 | +32.8 |
| CHARGE LOSSES | 94 | 86 | 12 | 4.00 | +1296 | +108.0 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| FOUR ROUNDS | 24 | 23 | 11 | 3.67 | +882 | +80.2 |
| SHOT RISK POINTS | 113 | 108 | 11 | 3.67 | +226 | +20.6 |
| SUPPORT ADDS | 47 | 45 | 10 | 3.33 | +346 | +34.6 |
| SUPPORT WORKED OUT | 47 | 45 | 10 | 3.33 | +346 | +34.6 |
| NEXT CHARGE BY LIST | 17 | 16 | 9 | 3.00 | +494 | +54.9 |
| ADVANCE LANE KEPT | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| MEETS IN TIME | 18 | 18 | 8 | 2.67 | +507 | +63.4 |
| SCOUT WAITS | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| THE RISK READS HIS RUN | 15 | 15 | 7 | 2.33 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 30 | 27 | 7 | 2.33 | +340 | +48.6 |
| JOINT CHARGE NOW | 6 | 6 | 6 | 2.00 | +148 | +24.7 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +286 | +47.6 |
| PROMISE SHOT AWAY | 6 | 6 | 6 | 2.00 | -5 | -0.8 |
| SHOOTS FROM THE BEST SPOT | 12 | 12 | 6 | 2.00 | +144 | +24.0 |
| RESERVE FALL BACK | 5 | 5 | 5 | 1.67 | +155 | +31.0 |
| RISK BY ARC | 13 | 12 | 5 | 1.67 | +50 | +10.0 |
| STAY WORTH | 93 | 82 | 5 | 1.67 | +11 | +2.3 |
| CASTER AWAY FROM SCREEN | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 11 | 11 | 4 | 1.33 | -240 | -59.9 |
| COMBAT PIVOT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| COVER ONCE | 38 | 25 | 4 | 1.33 | +29 | +7.3 |
| MARCH BY THE SUM | 4 | 4 | 4 | 1.33 | +411 | +102.9 |
| MARCH CHECK | 6 | 6 | 4 | 1.33 | +43 | +10.9 |
| PROMISE KNOWS THE FIGHT | 12 | 10 | 4 | 1.33 | -8 | -2.0 |
| SHOTS IN THE MOVE | 84 | 66 | 4 | 1.33 | +146 | +36.6 |
| TIED UP BY THE SUM | 6 | 5 | 4 | 1.33 | +45 | +11.2 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | -9 | -2.9 |
| EXACT ROUND | 16 | 15 | 3 | 1.00 | +10 | +3.3 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +295 | +98.3 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +166 | +55.3 |
| MAX FOR POSITIONING | 15 | 13 | 3 | 1.00 | +2 | +0.7 |
| RANDOM MOVE BY FIGURES | 7 | 7 | 3 | 1.00 | +94 | +31.5 |
| SEARCH SPOT | 6 | 6 | 3 | 1.00 | +345 | +115.1 |
| SHOTS AFTER THE MOVES | 13 | 13 | 3 | 1.00 | +0 | +0.0 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +37 | +12.4 |
| CASTING BLOCK | 5 | 5 | 2 | 0.67 | +1 | +0.4 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HIS CHARGE DENIED | 3 | 3 | 2 | 0.67 | +222 | +111.2 |
| MANOEUVRE | 6 | 6 | 2 | 0.67 | +31 | +15.5 |
| NEARER NOT NEEDED | 63 | 59 | 2 | 0.67 | +35 | +17.4 |
| ONE FIGHT FORMULA | 36 | 19 | 2 | 0.67 | +31 | +15.5 |
| OPENS UP | 2 | 2 | 2 | 0.67 | +2 | +1.1 |
| REDIRECT COUNTER | 21 | 20 | 2 | 0.67 | +35 | +17.5 |
| RESTRAINS TO SHOOT | 2 | 2 | 2 | 0.67 | +35 | +17.6 |
| SET UP BY THE SET | 7 | 7 | 2 | 0.67 | +195 | +97.4 |
| SURE REACH TOGETHER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 13 | 2 | 2 | 0.67 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 9 | 9 | 2 | 0.67 | +61 | +30.4 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +98 | +97.8 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +1 | +0.8 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -25 | -25.0 |
| CAST JOB | 1 | 1 | 1 | 0.33 | +2 | +1.5 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -50 | -49.9 |
| EDGE GIVE GROUND | 3 | 3 | 1 | 0.33 | +1 | +1.2 |
| FALL BACK GOOD ORDER | 16 | 15 | 1 | 0.33 | +16 | +15.7 |
| FALLS SHORT | 51 | 43 | 1 | 0.33 | +6 | +6.2 |
| FEATURE BUFFS | 9 | 9 | 1 | 0.33 | +2 | +2.0 |
| FIGHT TO THE END | 9 | 8 | 1 | 0.33 | +1 | +1.2 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS MOVE AND SHOT | 22 | 21 | 1 | 0.33 | +84 | +83.9 |
| HONEST WORTH | 18 | 17 | 1 | 0.33 | +1 | +1.2 |
| IDLE COST | 39 | 21 | 1 | 0.33 | +4 | +4.2 |
| LOST AFTER ESCAPE | 11 | 11 | 1 | 0.33 | +0 | +0.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| NO DOUBLE ROUNDS | 19 | 18 | 1 | 0.33 | +1 | +1.2 |
| ONE JOINT FIGURE | 2 | 2 | 1 | 0.33 | +6 | +5.9 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -26 | -25.6 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +54 | +54.4 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -13 | -13.3 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +16 | +16.4 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +5 | +4.8 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +5 | +5.0 |
| STRIKE BY THE ODDS | 2 | 2 | 1 | 0.33 | +4 | +3.5 |
| WHOLE FIGHT | 1 | 1 | 1 | 0.33 | +8 | +7.9 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 60 | 60 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 2 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 46 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 37 | 36 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 6 | 6 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 15 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 28 | 27 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 62 | 57 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 12 | 12 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 24 | 18 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 34 | 31 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 39 | 32 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 42 | 40 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 16 | 14 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 15 | 15 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS TURN RUN | 35 | 35 | 0 | 0.00 | - | - |
| HOLD ODDS | 103 | 102 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 1 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 9 | 9 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONG SHOT | 3 | 3 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 18 | 10 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 26 | 17 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 5 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 30 | 17 | 0 | 0.00 | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 4 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 246 | trace | - | - | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 5 | 5 | 0 | 0.00 | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 7 | 6 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 9 | 9 | 0 | 0.00 | - | - |
| RUN DOWN | 12 | 12 | 0 | 0.00 | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 5 | not checked | - | - | - | - |
| SET CREDITED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 31 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 4 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 35 | 31 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 7 | 6 | 0 | 0.00 | - | - |
| STANDS STILL | 181 | 177 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 4 | 2 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 17 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 1 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 10 | not checked | - | - | - | - |
| THE TABLE BINDS | 241 | not checked | - | - | - | - |
| WAITS AGAIN | 12 | 12 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 2 | 2 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 6 | 6 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p10

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 1.67 | 7.33 | 79.1 |
| JOB FIRST | gate | 1.67 | 7.00 | 45.8 |
| ARMY TABLE | rule | 3.67 | 0.67 | 114.2 |
| PROMISE SHOT AWAY | rule | - | 2.00 | 0.8 |
| CHARGE NOW FIRST | rule | - | 1.33 | 59.9 |
| PROMISE KNOWS THE FIGHT | rule | - | 1.33 | 2.0 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.33 | 0.33 | 199.8 |
| CHAFF PASSED | rule | - | 0.67 | 4.3 |
| JOINT CHARGE NOW | rule | 0.33 | 0.33 | 79.2 |
| RULE SWITCHED OFF | gate | 0.67 | - | 8.7 |
| BEST PRIZE | rule | - | 0.33 | 25.0 |
| CHARGE NOT DECLARED | rule | 0.33 | - | 49.9 |
| DEPLOY BY FIGURES | rule | 0.33 | - | 1.1 |
| HOLDER ASSIGNMENT | rule | - | 0.33 | 57.1 |
| NO REASON | gate | - | 0.33 | 9.4 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 25.6 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 13.3 |

### Plans: ccut-c940641-p10

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.7 | 80% | 197 | 174 | 88% |
| Mine | move | 30.7 | 93% | 1972 | 0 | 0% |
| Mine | shoot | 3.3 | 50% | 344 | 69 | 20% |
| Opponent | charge | 5.0 | 53% | 677 | 544 | 80% |
| Opponent | join | 2.0 | 100% | 76 | 0 | 0% |
| Opponent | move | 33.3 | 93% | 1846 | 0 | 0% |
| Opponent | shoot | 6.0 | 56% | 277 | 347 | 125% |

### Battle groups: ccut-c940641-p10

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.7 | 9% | 100% | 0% | - | 0% | 0% | 100% | 0% | 0% |
| Opponent | REDIRECT COUNTER | 3.3 | 40% | 50% | 0% | - | 50% | 0% | 0% | 50% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p10

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 7 | 29 (7) | 20 | 9 | 43 | 29% | 2.0 | 33 (6) | 0 (1) | - | 29 (7) | - |
| Mine | Character | 8 | 26 (8) | 26 | 0 | 54 | 0% | 2.0 | 5 (3) | - | 0 (1) | - | 4 (4) |
| Mine | Clean-up | 4 | 53 (4) | 0 | 53 | 31 | 75% | 6.0 | 31 (2) | 94 (1) | 79 (1) | 62 (1) | 49 (3) |
| Mine | Fast Hammer | 1 | 1 (1) | 1 | 0 | 115 | 0% | 2.0 | 1 (1) | - | - | - | 1 (1) |
| Mine | Hammer | 11 | 34 (11) | 33 | 1 | 37 | 9% | 2.0 | 10 (3) | 49 (7) | 0 (1) | 17 (4) | 45 (7) |
| Mine | Shooter | 3 | 0 (3) | 0 | 0 | 67 | 0% | 2.0 | 0 (2) | 0 (1) | - | 0 (1) | 0 (2) |
| Mine | Wizard | 2 | 7 (2) | 7 | 0 | 126 | 0% | 2.0 | - | - | - | - | - |
| Opponent | Chaff | 8 | 161 (8) | 11 | 150 | 48 | 38% | 1.2 | 231 (2) | 146 (4) | 106 (2) | 210 (5) | 67 (3) |
| Opponent | Character | 8 | 35 (8) | 35 | 0 | 2 | 25% | 3.0 | 9 (5) | 76 (3) | - | 15 (3) | 46 (5) |
| Opponent | Clean-up | 4 | 43 (4) | 43 | 0 | 74 | 50% | 3.0 | 0 (2) | 57 (2) | - | 0 (2) | 57 (2) |
| Opponent | Fast Hammer | 7 | 121 (7) | 121 | 0 | 42 | 43% | 2.5 | 228 (2) | 40 (5) | - | 234 (4) | 39 (3) |
| Opponent | Holder | 4 | 114 (4) | 0 | 114 | 23 | 0% | 1.5 | 250 (2) | - | 0 (2) | 250 (2) | 0 (2) |
| Opponent | Shooter | 4 | 7 (4) | 7 | 0 | 0 | 0% | 1.5 | 14 (2) | 0 (2) | - | 0 (2) | 9 (2) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 0% | 3.0 | 0 (1) | 0 (1) | 0 (1) | - | 0 (3) |

### Charged fights: ccut-c940641-p10

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 1 | 140 | 261 | 2.0 | 2.0 | 130 | 0 | +130 | 1 of 2 | 2 of 2 | +130 | - |
| Mine | Orc & Goblin Tribes | 1 | 0 | 126 | 5.0 | 1.0 | 25 | 43 | -18 | 2 of 5 | 3 of 5 | - | -18 |
| Mine | Skaven | 1 | 45 | 147 | 2.0 | 1.0 | 74 | 0 | +74 | 1 of 2 | 1 of 2 | - | +74 |
| **Mine** | all armies | 3 | 62 | 178 | 3.0 | 1.2 | 59 | 24 | +36 | 4 of 9 | 6 of 9 | +130 | +8 |
| Opponent | Tomb Kings of Khemri | 2 | 17 | 988 | 3.5 | 1.1 | 282 | 28 | +254 | 4 of 7 | 6 of 7 | +0 | +297 |
| Opponent | Vampire Counts | 1 | 0 | 310 | 3.0 | 1.0 | 103 | 101 | +2 | 1 of 3 | 1 of 3 | - | +2 |
| **Opponent** | all armies | 3 | 11 | 762 | 3.3 | 1.1 | 229 | 50 | +179 | 5 of 10 | 7 of 10 | +0 | +199 |

### Effective charges: ccut-c940641-p10

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Ogre Kingdoms | 2 | 0 | 0 | 1 (net +66) | 1 (net +195) | 0 | 0 | 0 | 50% (1 of 2) |
| Mine | Orc & Goblin Tribes | 5 | 0 | 0 | 0 | 1 (net -55) | 1 (net +66) | 0 | 3 | 0% (0 of 2) |
| Mine | Skaven | 2 | 1 (net +0) | 0 | 0 | 0 | 0 | 1 (net +147) | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 7 | 1 (net -195) | 0 | 0 | 1 (net +350) | 1 (net +0) | 3 (net +163) | 1 | 0% (0 of 6) |
| Opponent | Vampire Counts | 3 | 2 (net -152) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 2) |

### Charged fights, damage counted: ccut-c940641-p10

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 0 | 480 | +0 | 0 | 0 | +0 | - |
| Mine | Effective (55-75%) | 1 | 68 | 66 | +66 | 71 | 145 | -74 | -108.4 |
| Mine | 76-89% | 2 | 258 | 130 | +70 | 98 | 28 | +70 | +27.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 192 | 147 | +147 | 147 | 0 | +147 | +76.6 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 343 | 66 | +66 | 66 | 0 | +66 | +19.2 |
| Mine | No odds | 3 | 249 | 232 | -33 | 20 | 53 | -33 | -13.2 |
| Mine | All fights | 9 | 208 | 191 | +36 | 60 | 40 | +20 | +9.7 |
| Opponent | Long shot (under 50%) | 3 | 166 | 101 | -166 | 23 | 168 | -145 | -87.3 |
| Opponent | 76-89% | 1 | 431 | 350 | +350 | 350 | 0 | +350 | +81.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 342 | 247 | +163 | 245 | 43 | +202 | +59.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 195 | 60 | +0 | 50 | 0 | +50 | +25.6 |
| Opponent | No odds | 2 | 338 | 276 | +723 | 726 | 0 | +726 | +215.2 |
| Opponent | All fights | 10 | 282 | 201 | +179 | 266 | 63 | +202 | +71.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p10 | move | 24 | 11 (46%) | 10 (42%) | 2 (8%) | 11 (46%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L2025 |
| Elixir of Power | Mine | L1923 |
| Fistful of Laurels | Mine | L1823 |
| Invocation of Nehek | Opponent | L2025 |
| Periapt of Soul Exchange | Mine | L2025 |

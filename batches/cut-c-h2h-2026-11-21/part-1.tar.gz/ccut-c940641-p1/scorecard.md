# Doctrine scorecard: ccut-c940641-p1

### Scorecard: ccut-c940641-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 1 | - | 0 | 0 | 0 | 0 | 0 | 55 |
| L0102 | 6 | 1 | Opponent | no | 7 | 2 | 0 | 5 | 0 | 0 | 0 | 170 |
| L0118 | 4 | 1 | Mine | no | 4 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 0 | - | 2 | 5 | 0 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Mine | no | 4 | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Opponent | no | 1 | 6 | 1 | 7 | 0 | 0 | 0 | 224 |
| **Average** | | | Mine | 0% | 3.0 | - | 0.0 | 1.7 | 0.0 | 0.0 | 0.0 | 18.3 |
| **Average** | | | Opponent | 0% | 2.7 | 4.0 | 1.0 | 5.7 | 0.0 | 0.0 | 0.0 | 131.3 |

### KPIs: ccut-c940641-p1

Rules off - Mine only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 5) | 0% (0 of 13) | 0% (0 of 18) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 100% (2 of 2); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (1 of 1); on the table 100% | 100% (3 of 3); on the table 100% | 100% (4 of 4); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 40% (36 of 90) | 38% (9 of 24) | 39% (45 of 114) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 41% (36 of 87) | 38% (9 of 24) | 41% (45 of 111) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 67% (4 of 6) | 67% (4 of 6) |
| Points that never fought | lower | 55% (3140 of 5700) | 85% (5021 of 5899) | 70% (8161 of 11599) |
|   infantry points that never fought | lower | 60% (1622 of 2703) | 100% (1219 of 1219) | 72% (2841 of 3922) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 33% (5 of 15) | 88% (22 of 25) | 68% (27 of 40) |
| Bound items with a magic missile used (at least once a game) |  | 100% (3 of 3); 4.0 uses a game | 75% (3 of 4); 2.3 uses a game | 86% (6 of 7); 3.2 uses a game |
| Bound items with another spell used |  | 67% (2 of 3); 0.7 uses a game | 0.0 uses a game | 67% (2 of 3); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (3 of 3); 1.0 uses a game | 50% (1 of 2); 0.3 uses a game | 80% (4 of 5); 0.7 uses a game |
|   their share of the points of units over 100 pts | lower | 36% (1452 of 4077) | 86% (4197 of 4883) | 63% (5649 of 8960) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 13.3 (74%) | 3.0 (60%) | 16.3 (71%) |
| MARCHED: its unit marched | 2.7 (15%) | 2.0 (40%) | 4.7 (20%) |
| IN COMBAT: engaged in combat | 0.7 (4%) | 0.0 (0%) | 0.7 (3%) |
| GONE: slain | 0.3 (2%) | 0.0 (0%) | 0.3 (1%) |
| STUPIDITY: Stupidity | 0.7 (4%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.3 (2%) | 0.0 (0%) | 0.3 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 9.7 | 2.7 | 10.7 | 15.0 | 1.0 |
| not cast | 8.3 | 7.3 | 5.3 | 23.0 | 43.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 4.3 (59%) | 1.0 (19%) | 16.3 (71%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.7 (20%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (5%) | 0.3 (6%) | 0.7 (3%) | 0.0 (0%) |
| GONE: slain | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.3 (4%) | 0.0 (0%) | 0.7 (12%) | 0.7 (3%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 7.7 (92%) | 2.7 (36%) | 3.3 (62%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 40.7 (95%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 8.7 a game | 2.7 a game | 5.7 a game |
| stood (cast and not dispelled) | 62% (16 of 26) | 62% (5 of 8) | 62% (21 of 34) |
| the unit moved after it | 75% (12 of 16) | 20% (1 of 5) | 62% (13 of 21) |
| it charged on its next turn | 0% (0 of 16) | 0% (0 of 5) | 0% (0 of 21) |
| the enemy charged it first | 6% (1 of 16) | 0% (0 of 5) | 5% (1 of 21) |
| it fought by the end of its next turn | 6% (1 of 16) | 0% (0 of 5) | 5% (1 of 21) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 16) | 0% (0 of 5) | 0% (0 of 21) |
| none of these (no charge, no fight, no charge escaped) | 94% (15 of 16) | 100% (5 of 5) | 95% (20 of 21) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (20 of 33) | 46% (28 of 61) | 51% (48 of 94) |
|   cavalry | - | 50% (6 of 12) | 50% (6 of 12) |
|   character | - | 73% (8 of 11) | 73% (8 of 11) |
|   chariot | - | 50% (1 of 2) | 50% (1 of 2) |
|   infantry | 61% (20 of 33) | 25% (6 of 24) | 46% (26 of 57) |
|   monster | - | 58% (7 of 12) | 58% (7 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (62%) | 3.0 (27%) | 5.7 (37%) |
| CHARGED: it charged | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| FLEEING: it fled or was fleeing | 0.3 (8%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 1.0 (23%) | 6.7 (61%) | 7.7 (50%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (8%) | 1.0 (9%) | 1.3 (9%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.0 | 0.3 | 89% | 0.6 pts | 2 pts |
| character | 2.7 | 1.3 | 50% | 4.4 pts | 12 pts |
| chariot | 0.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 8.7 | 3.0 | 81% | 3.1 pts | 27 pts |
| monster | 2.3 | 2.0 | 57% | 6.9 pts | 16 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.0 | 1.3 | 0.7 |
| Charges that made contact a game | 0.0 | 1.3 | 0.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.00 declared, 0.00 contact (15 units) | 0.12 declared, 0.12 contact (32 units) | 0.09 declared, 0.09 contact (47 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 100% (3 of 3) | - | - | 100% (3 of 3) |
| Character in a unit | 50% (2 of 4) | 60% (6 of 10) | - | 57% (8 of 14) |
| Character on its own | 100% (1 of 1) | 100% (1 of 1) | 100% (1 of 1) | 100% (3 of 3) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 80% (4 of 5) | 14% (1 of 7) | - | 42% (5 of 12) |
| Monster | 100% (1 of 1) | 100% (1 of 1) | - | 100% (2 of 2) |
| Monstrous | 100% (2 of 2) | 100% (2 of 2) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (3 of 3); on the table 100% | 41% (44 of 108) | 63% | 48% (10 of 21) | 100% (5 of 5); 4.5 uses a game | 67% (2 of 3); 0.5 uses a game | 80% (4 of 5); 1.0 uses a game |
| Ogre Kingdoms | 1 | - | - | 94% | 100% (7 of 7) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (1 of 1); on the table 100% | 17% (1 of 6) | 75% | 83% (10 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p1, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 25% (1) | - | 25% (1) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.00 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.00 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: ccut-c940641-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.0 | 1.7 |
| Strategy | Charge objectives carried out (made contact) | - | 50% (1 of 2) |
| Strategy | Shoot objectives carried out (shot that target) | 15% (3 of 20) | 21% (3 of 14) |
| Strategy | Hexes on a unit its side charged or shot that turn | 50% (2 of 4) | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 47% (8 of 17) | 0% (0 of 7) |
| Strategy | Lone characters that fought | 100% (1 of 1) | 33% (1 of 3) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.7 | 5.7 |
| Movement | Points that never moved of their own | 18.3 | 131.3 |
| Movement | Fights charged into per game | 0.0 | 1.3 |
| Movement | Charges with odds: long shots (under 50%) | - | 0 of 2 |
| Movement | Charges with odds: sweet spot (55-75%) | - | 1 of 2, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | - | 0 of 2 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | - | 1 of 2, net +55 |
| Shooting | Shots by shooting units (incl. breath weapons) | 6.7 | 9.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 25% (5 of 20) | 62% (18 of 29) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 10.3 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 32% (10 of 31) | 33% (1 of 3) |
| Magic | Wounds caused by magic missiles | 24.3 | 3.0 |
| Magic | Wounds caused by other spells | 0.7 | - |
| Magic | Points destroyed by magic (all spells) | 291.0 | 18.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 6.7 / 1.3 / 1.0 / 0.0 | 1.7 / 0.3 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 11.3 | 43.3 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | - | +22 |
| Combat | Net per 100 charger points, damage counted | - | +12.3 |
| Combat | First round won (charged fights) | - | 50% |
| Combat | Net points per charged fight | - | +38 |
| Combat | Net points per supported fight / lone fight | - / - | - / +38 |
| Combat | Charged fights on a top-3 enemy unit | - | 3 of 4 |
| Game | Points lost | 101.7 | 400.7 |
| Game | VP from objectives | 860.0 | 800.0 |
| Game | Lone holders (player turns) | 3.0 | 2.7 |

- Mine won / drew / lost: 1 / 2 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +418 VP
- The side that went first won 0 of 1 games with a winner
- Points traded per game (both sides' losses): 502
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: ccut-c940641-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 98.3 |
| ARMY TABLE | 12.0 | +31.4 | 0.0 | 36.7 | 26.7 | +169.8 | 0.0 | 28.3 |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -83.5 | 0.0 | 0.0 |
| CAST JOB | - | - | - | - | 2.0 | +9.0 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 4.0 | +398.7 | 83.3 | 0.0 | 1.3 | +12.3 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 5.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.3 | +18.3 | 0.0 | 18.3 | 0.7 | +16.0 | 0.0 | 20.0 |
| CHARGE LOSSES | 18.0 | -318.1 | 0.0 | 43.3 | 13.3 | -490.6 | 0.0 | 196.7 |
| CHARGE NOW FIRST | - | - | - | - | 0.3 | +0.0 | 18.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 3.3 | +0.0 | 0.0 | 0.0 | 18.0 | +0.0 | 0.0 | 289.3 |
| CONVEYANCE SEARCH | 8.3 | +1129.6 | 0.0 | 0.0 | 2.7 | +83.0 | 0.0 | 0.0 |
| COVER ONCE | 2.7 | -268.3 | 0.0 | 0.0 | 5.3 | -185.0 | 0.0 | 30.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -1.7 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 5.0 | +41.5 | 0.0 | 0.0 | 10.0 | -145.9 | 0.0 | 198.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 1.3 | +15.4 | 0.0 | 0.0 |
| EXACT ROUND | - | - | - | - | 0.7 | +56.8 | 18.3 | 0.0 |
| FALL BACK GOOD ORDER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 22.0 | +281.0 | 0.0 | 28.3 |
| FEATURE BUFFS | 14.7 | +637.3 | 0.0 | 58.3 | - | - | - | - |
| FIVE ACTION | 57.3 | +8650.6 | 195.0 | 171.7 | 98.0 | +2923.6 | 73.3 | 696.0 |
| FLANK NOT WEIGHED | 1.7 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 49.7 |
| FOLLOW UP WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FOUR ROUNDS | - | - | - | - | 0.7 | -25.6 | 18.3 | 0.0 |
| FREED FROM HIS FIGHT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| GOAL WALK | 4.7 | +622.0 | 0.0 | 0.0 | - | - | - | - |
| GROUND FLIERS | - | - | - | - | 0.3 | +6.1 | 0.0 | 0.0 |
| GUN FIGURES | - | - | - | - | 0.3 | +0.0 | 0.0 | 61.7 |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 7.3 | +0.0 | 0.0 | 43.3 | 5.3 | +0.0 | 0.0 | 83.3 |
| HIS CHARGE LIST | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.3 | -22.7 | 0.0 | 0.0 | 3.0 | -65.9 | 0.0 | 56.7 |
| HIS MOVE AS HE DECIDES | 46.0 | +11.7 | 302.7 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 18.0 | +0.0 | 0.0 | 228.7 |
| HIS ONE MOVE | 13.7 | +52.2 | 0.0 | 0.0 | - | - | - | - |
| HIS ONE QUARTER | 4.7 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 90.0 |
| HIS OWN BEST MOVE | 2.3 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 7.7 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.0 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 33.7 | +442.0 | 0.0 | 55.0 | 56.0 | +2710.8 | 0.0 | 350.0 |
| HIS SHOTS BY HIS RUN | 36.7 | +210.9 | 0.0 | 153.3 | 40.0 | +979.2 | 0.0 | 375.7 |
| HIS TURN DENIED | - | - | - | - | 0.3 | +15.6 | 0.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 40.7 | +0.0 | 0.0 | 138.3 | 15.0 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 16.7 | +1961.1 | 0.0 | 21.7 | 10.0 | +976.4 | 0.0 | 38.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | - | - | - | - | 0.7 | -34.4 | 18.3 | 0.0 |
| IDLE COST | - | - | - | - | 30.3 | -333.1 | 0.0 | 269.0 |
| KEPT FROM ITS LAST STOP | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 9.0 | +0.0 | 81.0 | 186.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| LONE WIZARD KEPT IN | 3.0 | +270.0 | 0.0 | 0.0 | 0.7 | +87.5 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | - | - | - | - | 0.3 | -5.9 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.7 | +2.1 | 0.0 | 30.0 |
| MANOEUVRE | 1.7 | -28.4 | 0.0 | 0.0 | 1.0 | +58.3 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.7 | +38.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.7 | +87.7 | 0.0 | 0.0 | 0.7 | +31.8 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +14.8 | 0.0 | 0.0 | 1.0 | +64.4 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | -40.1 | 0.0 | 0.0 | 0.3 | -23.5 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 1.7 | +25.1 | 0.0 | 18.3 | 1.0 | +3.8 | 0.0 | 28.3 |
| MEETS IN TIME | 1.7 | +224.8 | 0.0 | 0.0 | 7.7 | +309.7 | 0.0 | 198.0 |
| MISSILES IN THE MOVE | 9.0 | +647.0 | 0.0 | 0.0 | 5.3 | +75.4 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 9.0 | +527.6 | 0.0 | 0.0 | 6.3 | +57.4 | 0.0 | 0.0 |
| MISSILES ON ONE TARGET | 3.3 | -182.4 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 1.0 | +0.0 | 18.3 | 0.0 | 2.3 | +0.0 | 0.0 | 11.3 |
| MOVE SPELL OUT OF RANGE | 2.0 | -180.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | - | - | - | - | 4.3 | +184.7 | 0.0 | 0.0 |
| MOVES UNITS SPELL | - | - | - | - | 0.3 | +18.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.3 | +281.2 | 0.0 | 0.0 | 3.0 | +166.7 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | - | - | - | - | 3.0 | +157.2 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -1.9 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | - | - | - | - | 0.7 | -8.4 | 18.3 | 0.0 |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 3.0 | -4.5 | 0.0 | 0.0 | 2.3 | -3.2 | 0.0 | 0.0 |
| OFF BEST | 1.3 | -19.9 | 0.0 | 0.0 | 1.0 | -7.3 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 3.3 | -39.8 | 0.0 | 36.7 | 4.0 | -41.3 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 8.7 | +254.2 | 0.0 | 21.7 | 3.3 | -52.1 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | -9.1 | 0.0 | 0.0 |
| OPENS A LANE | 0.7 | +1.1 | 83.3 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | - | - | - | - | 0.3 | +21.1 | 18.3 | 0.0 |
| PLAN RESULT | 24.3 | +174.9 | 0.0 | 98.3 | 43.3 | +31.8 | 18.3 | 314.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | - | - | - | - | 3.7 | -9.1 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 0.3 | -0.5 | 0.0 | 0.0 |
| QUARTER ODDS | 14.0 | +1675.9 | 0.0 | 0.0 | 18.7 | +1726.1 | 0.0 | 90.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 2.0 | +108.5 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.7 | +54.1 | 0.0 | 18.3 | 2.7 | +39.7 | 0.0 | 68.0 |
| REDIRECT FOR A FRIEND IN REACH | 2.0 | +0.0 | 0.0 | 73.3 | 3.0 | +0.0 | 0.0 | 102.0 |
| REFORMS TO MEET IT | - | - | - | - | 1.7 | -168.1 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE MOVE SPELL | 0.7 | +15.4 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | - | - | - | - | 0.3 | -23.1 | 18.3 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.3 | +2.8 | 0.0 | 0.0 |
| RUN DOWN | - | - | - | - | 0.7 | -1.0 | 18.3 | 0.0 |
| SCOUT SPOT | 1.0 | +1.2 | 0.0 | 0.0 | 0.7 | +2.1 | 0.0 | 0.0 |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.3 | -4.3 | 0.0 | 18.3 | 0.7 | -0.7 | 0.0 | 20.0 |
| SEARCH SPOT | 1.3 | +22.3 | 0.0 | 0.0 | 0.7 | +18.5 | 0.0 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 0.3 | -0.6 | 0.0 | 0.0 |
| SET UP BY THE SET | - | - | - | - | 0.3 | +0.6 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.7 | +2.1 | 0.0 | 30.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +45.9 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.7 | -1.3 | 0.0 | 20.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 36.7 |
| SHOOTERS ON THE TABLE | 5.7 | +0.0 | 0.0 | 18.3 | 5.3 | +0.0 | 0.0 | 10.0 |
| SHOOTS FROM THE BEST SPOT | 5.3 | +207.7 | 83.3 | 0.0 | 0.3 | +0.6 | 18.3 | 0.0 |
| SHOT RISK POINTS | 21.7 | -185.9 | 0.0 | 98.3 | 53.7 | +584.2 | 0.0 | 449.3 |
| SHOTS AFTER THE MOVES | 2.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 6.7 | +187.6 | 0.0 | 0.0 | 10.0 | +79.3 | 0.0 | 61.7 |
| SPELL SETS UP CHARGE | 1.0 | +267.2 | 0.0 | 0.0 | 0.3 | +45.9 | 0.0 | 0.0 |
| SPELL WORTH | 2.3 | +11.6 | 28.3 | 0.0 | 1.7 | +7.5 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 5.3 | +0.0 | 0.0 | 58.3 | 4.3 | +0.0 | 0.0 | 69.7 |
| STANDS FOR A REASON | - | - | - | - | 13.0 | +0.0 | 55.0 | 0.0 |
| STANDS STILL | 21.0 | +0.0 | 195.0 | 73.3 | 31.7 | +0.0 | 55.0 | 0.0 |
| STAY WORTH | 8.7 | +59.6 | 28.3 | 0.0 | 15.3 | +64.4 | 36.7 | 61.7 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | -83.5 | 0.0 | 0.0 |
| SUPPORT ADDS | 3.0 | +97.9 | 0.0 | 0.0 | 1.0 | +15.9 | 0.0 | 28.3 |
| SUPPORT WORKED OUT | 3.0 | +97.9 | 0.0 | 0.0 | 1.0 | +15.9 | 0.0 | 28.3 |
| SURE REACH TOGETHER | - | - | - | - | 1.0 | +1.6 | 0.0 | 30.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +0.1 | 0.0 | 11.3 |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 28.3 | 0.0 |
| THE ROW KEEPS ITS WAY | 3.0 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 64.3 |
| THE ROW READS HIS LAST RUN | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE STEP BACK IS MADE | 2.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 22.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 28.3 | +0.0 | 0.0 | 95.0 | 47.7 | +0.0 | 0.0 | 337.3 |
| TIED UP BY THE SUM | - | - | - | - | 0.3 | +7.8 | 18.3 | 0.0 |
| TIME ON OUR SIDE | 27.7 | +686.3 | 0.0 | 150.0 | - | - | - | - |
| WAITS AGAIN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | - | - | - | - | 0.3 | -67.3 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 4.0 | -127.9 | 0.0 | 43.3 | - | - | - | - |
| WOUNDS ON THE RANKS | 11.0 | +218.9 | 0.0 | 0.0 | 1.7 | +112.7 | 0.0 | 0.0 |

### Rule changes: ccut-c940641-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 138 | 138 | 103 | 34.33 | +0 | +0.0 |
| HIS SHOT LIST | 269 | 268 | 88 | 29.33 | +1483 | +16.9 |
| HOLDER ASSIGNMENT | 80 | 80 | 72 | 24.00 | +3640 | +50.6 |
| ARMY TABLE | 116 | 116 | 66 | 22.00 | +216 | +3.3 |
| HIS SHOTS BY HIS RUN | 230 | 227 | 52 | 17.33 | +587 | +11.3 |
| SHOT RISK POINTS | 226 | 223 | 39 | 13.00 | +554 | +14.2 |
| HIS MOVE WHY | 54 | 54 | 37 | 12.33 | +0 | +0.0 |
| DEPLOY BY FIGURES | 45 | 45 | 30 | 10.00 | +432 | +14.4 |
| LEGAL CHARGES ONLY | 28 | 28 | 28 | 9.33 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 28 | 9.33 | +0 | +0.0 |
| HIS ONE MOVE | 41 | 41 | 18 | 6.00 | +0 | +0.0 |
| IDLE COST | 91 | 75 | 18 | 6.00 | +162 | +9.0 |
| QUARTER ODDS | 98 | 97 | 17 | 5.67 | +1141 | +67.1 |
| REDIRECT FOR A FRIEND IN REACH | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| MEETS IN TIME | 28 | 28 | 14 | 4.67 | +257 | +18.3 |
| CASTING BLOCK | 16 | 16 | 13 | 4.33 | +447 | +34.4 |
| TIME ON OUR SIDE | 83 | 73 | 12 | 4.00 | +136 | +11.3 |
| LONE WIZARD KEPT IN | 11 | 11 | 11 | 3.67 | +1073 | +97.5 |
| HARD STAY DROPPED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| MOVE ORDER | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 17 | 17 | 10 | 3.33 | +52 | +5.2 |
| WOUNDS ON THE RANKS | 38 | 38 | 9 | 3.00 | +148 | +16.4 |
| CASTER AWAY FROM SCREEN | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 13 | 12 | 8 | 2.67 | +276 | +34.5 |
| STAY WORTH | 72 | 53 | 8 | 2.67 | +74 | +9.2 |
| FALLS SHORT | 66 | 51 | 7 | 2.33 | +98 | +14.0 |
| FEATURE BUFFS | 44 | 44 | 7 | 2.33 | +152 | +21.8 |
| FIVE ACTION | 466 | 461 | 7 | 2.33 | +683 | +97.5 |
| NEXT CHARGE BY LIST | 9 | 9 | 7 | 2.33 | +271 | +38.7 |
| OFF BEST | 7 | 7 | 7 | 2.33 | -82 | -11.7 |
| CAST JOB | 6 | 6 | 6 | 2.00 | +8 | +1.3 |
| GOAL WALK | 14 | 14 | 6 | 2.00 | +1220 | +203.2 |
| SCOUT WAITS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SEARCH SPOT | 6 | 6 | 6 | 2.00 | +122 | +20.4 |
| THE RISK READS HIS RUN | 18 | 18 | 6 | 2.00 | +0 | +0.0 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHARGE LOSSES | 94 | 92 | 4 | 1.33 | +128 | +32.0 |
| MARCH BY THE SUM | 4 | 4 | 4 | 1.33 | +359 | +89.6 |
| MAX FOR POSITIONING | 8 | 8 | 4 | 1.33 | +4 | +0.9 |
| RANDOM MOVE BY FIGURES | 6 | 6 | 4 | 1.33 | +325 | +81.4 |
| CHAFF IN THE MOVE | 3 | 3 | 3 | 1.00 | +19 | +6.3 |
| MISSILES NEXT TURN | 46 | 31 | 3 | 1.00 | +190 | +63.4 |
| SHOTS IN THE MOVE | 50 | 32 | 3 | 1.00 | +59 | +19.7 |
| SUPPORT ADDS | 12 | 12 | 3 | 1.00 | +28 | +9.3 |
| SUPPORT WORKED OUT | 12 | 12 | 3 | 1.00 | +28 | +9.3 |
| COVER ONCE | 24 | 16 | 2 | 0.67 | +43 | +21.5 |
| HIS MOVE AND SHOT | 22 | 22 | 2 | 0.67 | +0 | +0.0 |
| MARCH CHECK | 4 | 4 | 2 | 0.67 | +23 | +11.7 |
| MISSILES IN THE MOVE | 43 | 29 | 2 | 0.67 | +237 | +118.6 |
| REDIRECT COUNTER | 10 | 7 | 2 | 0.67 | +38 | +19.2 |
| RESERVE MOVE SPELL | 2 | 2 | 2 | 0.67 | +46 | +23.1 |
| EXACT ROUND | 2 | 2 | 1 | 0.33 | +84 | +83.7 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| LANE BY FIGURES | 1 | 1 | 1 | 0.33 | +2 | +1.7 |
| MANOEUVRE | 8 | 8 | 1 | 0.33 | +182 | +182.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| NEARER NOT NEEDED | 28 | 26 | 1 | 0.33 | +42 | +42.1 |
| ONE OBJECTIVE FORMULA | 36 | 25 | 1 | 0.33 | +58 | +57.7 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -27 | -27.3 |
| OVERRUNS AWAY | 1 | 1 | 1 | 0.33 | +32 | +32.3 |
| PROMISE BY ITS OWN SUM | 11 | 11 | 1 | 0.33 | -27 | -27.2 |
| PROMISE KNOWS THE FIGHT | 1 | 1 | 1 | 0.33 | -2 | -1.6 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -14 | -14.5 |
| SET UP BY THE SET | 1 | 1 | 1 | 0.33 | +1 | +0.8 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.2 |
| THE ROW IN ITS ORDER | 13 | 1 | 1 | 0.33 | +0 | +0.0 |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 19 | trace | - | - | - | - |
| CHARGE NOW FIRST | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 64 | 62 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 33 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| EVASIVE BY THE ODDS | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 20 | not checked | - | - | - | - |
| FOUR ROUNDS | 2 | 2 | 0 | 0.00 | - | - |
| FREED FROM HIS FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 1 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 38 | 37 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 6 | 6 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 25 | 23 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 33 | 33 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 27 | 25 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 23 | 23 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 6 | 6 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 167 | 167 | 0 | 0.00 | - | - |
| HONEST WORTH | 2 | 2 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 10 | 10 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 10 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 6 | trace | - | - | - | - |
| MOVE SPELL SPOT | 5 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 16 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 22 | 19 | 0 | 0.00 | - | - |
| OPENS A LANE | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 203 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 5 | 5 | 0 | 0.00 | - | - |
| RISK BY ARC | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| RUN DOWN | 2 | 2 | 0 | 0.00 | - | - |
| SCOUT SPOT | 5 | 5 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 33 | not checked | - | - | - | - |
| SHOTS AFTER THE MOVES | 14 | 14 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 4 | not checked | - | - | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 29 | 29 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 39 | 38 | 0 | 0.00 | - | - |
| STANDS STILL | 158 | 157 | 0 | 0.00 | - | - |
| STRIKE BY THE ODDS | 1 | 1 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 3 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 4 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 32 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 3 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 24 | not checked | - | - | - | - |
| THE TABLE BINDS | 228 | not checked | - | - | - | - |
| TIED UP BY THE SUM | 1 | 1 | 0 | 0.00 | - | - |
| WAITS AGAIN | 1 | 1 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 12 | 12 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p1

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| ARMY TABLE | rule | 1.33 | 2.67 | 48.8 |
| JOB FIRST | gate | 1.33 | 1.00 | 11.7 |
| HOLDER ASSIGNMENT | rule | 1.67 | - | 7.1 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 27.3 |
| PROMISE BY ITS OWN SUM | rule | - | 0.33 | 27.2 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.33 | 1.6 |
| REFUSING RETIRES | rule | 0.33 | - | 14.5 |

### Plans: ccut-c940641-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | move | 19.7 | 93% | 2549 | 0 | 0% |
| Mine | shoot | 4.7 | 50% | 833 | 175 | 21% |
| Opponent | charge | 0.3 | 100% | 11 | 18 | 170% |
| Opponent | move | 39.7 | 93% | 1031 | 0 | 0% |
| Opponent | shoot | 3.0 | 56% | 61 | 14 | 22% |
| Opponent | support | 0.3 | 0% | 3 | 0 | 0% |

### Battle groups: ccut-c940641-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.7 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 2.7 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 3 | 0 (3) | 0 | 0 | 67 | 67% | 2.0 | 0 (1) | 0 (1) | 0 (1) | 0 (2) | 0 (1) |
| Mine | Character | 18 | 29 (18) | 29 | 0 | 4 | 17% | 1.5 | 76 (3) | 25 (11) | 7 (3) | 46 (11) | 3 (6) |
| Mine | Hammer | 6 | 44 (6) | 2 | 42 | 0 | 50% | 4.7 | 112 (1) | 35 (4) | 11 (1) | 59 (4) | 14 (2) |
| Mine | Holder | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | - | 0 (2) | - | 0 (1) | 0 (1) |
| Mine | Shooter | 6 | 108 (6) | 0 | 108 | 17 | 0% | 1.8 | - | 129 (5) | 0 (1) | 138 (4) | 46 (2) |
| Opponent | Chaff | 6 | 141 (6) | 0 | 141 | 38 | 67% | 3.0 | 0 (3) | 514 (2) | 0 (1) | 141 (6) | - |
| Opponent | Character | 8 | 3 (8) | 3 | 0 | 0 | 38% | 1.0 | 5 (4) | 0 (4) | - | 0 (4) | 6 (4) |
| Opponent | Early | 1 | 144 (1) | 144 | 0 | 100 | 0% | 6.0 | - | 144 (1) | - | - | 144 (1) |
| Opponent | Fast Hammer | 7 | 9 (7) | 9 | 0 | 28 | 57% | 1.7 | 0 (1) | 0 (3) | 25 (3) | 29 (3) | 0 (4) |
| Opponent | Hammer | 13 | 12 (13) | 0 | 12 | 28 | 62% | 1.8 | - | 17 (8) | 0 (5) | 0 (3) | 16 (10) |
| Opponent | Holder | 1 | 250 (1) | 0 | 250 | 0 | 100% | - | - | 250 (1) | - | - | 250 (1) |
| Opponent | Shooter | 3 | 99 (3) | 0 | 99 | 62 | 67% | 1.0 | 257 (1) | 0 (2) | - | 257 (1) | 0 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 5.0 | - | 0 (2) | - | 0 (2) | - |

### Charged fights: ccut-c940641-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 291 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Beastmen Brayherds | 1 | 0 | 55 | 1.0 | 1.0 | 55 | 0 | +55 | 0 of 1 | 1 of 1 | - | +55 |
| Opponent | Ogre Kingdoms | 1 | 0 | 130 | 2.0 | 1.0 | 65 | 17 | +48 | 2 of 2 | 0 of 2 | - | +48 |
| Opponent | Wood Elf Realms | 1 | 55 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| **Opponent** | all armies | 3 | 18 | 62 | 1.3 | 1.0 | 46 | 8 | +38 | 3 of 4 | 2 of 4 | - | +38 |

### Effective charges: ccut-c940641-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Beastmen Brayherds | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +55) | 0 | 0% (0 of 1) |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 100% (1 of 1) |

### Charged fights, damage counted: ccut-c940641-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Effective (55-75%) | 1 | 499 | 322 | +0 | 8 | 0 | +8 | +1.6 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 85 | 55 | +55 | 55 | 0 | +55 | +64.7 |
| Opponent | No odds | 2 | 62 | 579 | +48 | 65 | 53 | +12 | +19.4 |
| Opponent | All fights | 4 | 177 | 384 | +38 | 48 | 26 | +22 | +12.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p1 | move | 13 | 0 (0%) | 0 (0%) | 0 (0%) | 13 (100%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135 |
| Fistful of Laurels | Opponent | L0118 |
| Ring of Doom | Opponent | L0102 |

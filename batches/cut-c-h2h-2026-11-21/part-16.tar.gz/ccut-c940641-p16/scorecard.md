# Doctrine scorecard: ccut-c940641-p16

### Scorecard: ccut-c940641-p16

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0528 | 6 | 1 | Mine | no | 2 | - | 0 | 2 | 0 | 0 | 0 | 335 |
| L0528 | 6 | 1 | Opponent | no | 9 | - | 0 | 2 | 0 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 4 | - | 2 | 2 | 0 | 0 | 0 | 798 |
| L0616 | 4 | 1 | Opponent | no | 0 | 4 | 0 | 1 | 1 | 0 | 0 | 100 |
| L0632 | 2 | 1 | Mine | - | - | 4 | 2 | 2 | 0 | 0 | 0 | 500 |
| L0632 | 2 | 1 | Opponent | - | - | 3 | 1 | 4 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 3.0 | 4.0 | 1.3 | 2.0 | 0.0 | 0.0 | 0.0 | 544.3 |
| **Average** | | | Opponent | 0% | 4.5 | 3.5 | 0.3 | 2.3 | 0.3 | 0.0 | 0.0 | 33.3 |

### KPIs: ccut-c940641-p16

Rules off - Mine only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 100% (13 of 13) | 0% (0 of 10) | 57% (13 of 23) |
| Winner chose to follow up after the loser gave ground |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | - | 100% (3 of 3); on the table 100% | 100% (3 of 3); on the table 100% |
| Magic missiles tried each own turn | 50%+ | - | 0% (0 of 6) | 0% (0 of 6) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 0% (0 of 6) | 0% (0 of 6) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 67% (8 of 12) | 67% (8 of 12) |
| Points that never fought | lower | 88% (5267 of 6000) | 68% (4066 of 5999) | 78% (9333 of 11999) |
|   infantry points that never fought | lower | 90% (1999 of 2232) | 100% (720 of 720) | 92% (2719 of 2952) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 74% (20 of 27) | 71% (15 of 21) | 73% (35 of 48) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 65% (2739 of 4232) | 62% (3373 of 5415) | 63% (6112 of 9647) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.7 (83%) | 1.7 (83%) |
| MARCHED: its unit marched | - | 0.3 (17%) | 0.3 (17%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Assailments |
| --- | --- | --- | --- | --- |
| tried | 0.7 | 0.0 | 0.0 | 0.0 |
| not cast | 3.3 | 2.0 | 2.0 | 4.0 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (100%) | 1.7 (83%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.3 (17%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 1.3 (40%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (60%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.0 (100%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (122 of 194) | 59% (22 of 37) | 62% (144 of 231) |
|   cavalry | 48% (10 of 21) | 79% (11 of 14) | 60% (21 of 35) |
|   character | 64% (16 of 25) | 0% (0 of 6) | 52% (16 of 31) |
|   infantry | 43% (20 of 47) | 0% (0 of 5) | 38% (20 of 52) |
|   monster | 83% (10 of 12) | - | 83% (10 of 12) |
|   war machine | 74% (66 of 89) | 92% (11 of 12) | 76% (77 of 101) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 6.3 (26%) | 0.7 (13%) | 7.0 (24%) |
| CHARGED: it charged | 1.7 (7%) | 0.3 (7%) | 2.0 (7%) |
| IN COMBAT: it fought this turn or the last | 0.3 (1%) | 0.0 (0%) | 0.3 (1%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.3 (7%) | 0.3 (1%) |
| NO TARGET IN RANGE | 6.7 (28%) | 2.0 (40%) | 8.7 (30%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (1%) | 0.0 (0%) | 0.3 (1%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 5.7 (24%) | 1.7 (33%) | 7.3 (25%) |
| SHELTERED: the target was sheltered | 1.7 (7%) | 0.0 (0%) | 1.7 (6%) |
| OTHER BAR | 1.3 (6%) | 0.0 (0%) | 1.3 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.3 | 1.7 | 82% | 6.7 pts | 49 pts |
| character | 5.3 | 4.0 | 69% | 9.9 pts | 53 pts |
| infantry | 13.3 | 3.7 | 78% | 6.2 pts | 82 pts |
| monster | 3.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 25.7 | 16.3 | 58% | 19.1 pts | 489 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.3 | 1.7 | 2.0 |
| Charges that made contact a game | 2.3 | 0.7 | 1.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.33 declared, 0.33 contact (21 units) | 0.25 declared, 0.10 contact (20 units) | 0.29 declared, 0.22 contact (41 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 100% (4 of 4) | - | 50% (1 of 2) | 83% (5 of 6) |
| Character in a unit | 100% (7 of 7) | 67% (2 of 3) | 100% (1 of 1) | 91% (10 of 11) |
| Character on its own | - | 50% (1 of 2) | 33% (1 of 3) | 40% (2 of 5) |
| Infantry | 71% (5 of 7) | 17% (1 of 6) | - | 46% (6 of 13) |
| Monster | 100% (4 of 4) | - | - | 100% (4 of 4) |
| Monstrous | 100% (1 of 1) | - | - | 100% (1 of 1) |
| War Machines | 88% (7 of 8) | - | - | 88% (7 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dwarfen Mountain Holds | 3 | - | - | 88% | 74% (20 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | - | - | 64% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Warriors of Chaos | 2 | 100% (3 of 3); on the table 100% | 0% (0 of 6) | 70% | 87% (13 of 15) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p16, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 100% (5) | 83% (5) |
| ...free all their last turn and able to turn (per game) | 0.00 | 1.33 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.67 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: ccut-c940641-p16

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | 100% (7 of 7) | 40% (2 of 5) |
| Strategy | Shoot objectives carried out (shot that target) | 67% (58 of 86) | 53% (8 of 15) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 0% (0 of 11) | 0% (0 of 5) |
| Strategy | Lone characters that fought | 50% (1 of 2) | 60% (3 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 2.0 | 2.3 |
| Movement | Points that never moved of their own | 544.3 | 33.3 |
| Movement | Fights charged into per game | 2.0 | 0.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 6 | 0 of 1 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 6, net +0 | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 6 | 1 of 1, net +120 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 6, net +68 | 0 of 1 |
| Shooting | Shots by shooting units (incl. breath weapons) | 19.7 | 6.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 59% (35 of 59) | 11% (2 of 18) |
| Shooting | Points destroyed by shooting units | 207.7 | 0.0 |
| Shooting | War machine shots | 22.0 | 3.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 74% (49 of 66) | 64% (7 of 11) |
| Shooting | Points destroyed by war machines | 46.3 | 73.3 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 0.3 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 45.7 | 71.7 |
| Combat | Points run down | 0.0 | 77.7 |
| Combat | Net points per charged fight, damage counted | +69 | +192 |
| Combat | Net per 100 charger points, damage counted | +92.9 | +44.6 |
| Combat | First round won (charged fights) | 83% | 100% |
| Combat | Net points per charged fight | +23 | +199 |
| Combat | Net points per supported fight / lone fight | +137 / +0 | - / +199 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 6 | 1 of 2 |
| Game | Points lost | 283.7 | 276.3 |
| Game | VP from objectives | 610.0 | 420.0 |
| Game | Lone holders (player turns) | 3.0 | 4.5 |

- Mine won / drew / lost: 1 / 2 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +183 VP
- The side that went first won 0 of 1 games with a winner
- Points traded per game (both sides' losses): 560
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ccut-c940641-p16

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.7 | +18.1 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 7.0 | +133.9 | 0.0 | 0.0 | 21.0 | +390.3 | 0.0 | 229.7 |
| ARTILLERY RE-ROLL WEIGHED | 4.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +3.9 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -68.5 | 61.0 | 0.0 |
| CANNON PLAN MISSED | 1.3 | +0.0 | 148.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 22.0 | +502.6 | 1182.7 | 75.0 | 3.7 | +122.7 | 146.7 | 0.0 |
| CANNON SIGHT KEPT | 3.0 | +0.0 | 0.0 | 38.3 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 3.0 | +58.5 | 0.0 | 10.0 |
| CHAFF PASSED | 1.3 | -1.5 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 0.3 | +30.3 | 0.0 | 61.0 | - | - | - | - |
| CHARACTER GUNS | 4.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 7.3 | -139.0 | 0.0 | 0.0 | 20.3 | -1101.0 | 0.0 | 646.0 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 45.7 | 0.0 | 0.7 | +0.0 | 117.7 | 157.0 |
| CLOSES ON WHAT IT BEATS | 9.7 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 45.7 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 61.0 | 0.0 |
| COVER ONCE | 4.7 | -446.8 | 0.0 | 0.0 | 5.7 | -220.1 | 0.0 | 45.7 |
| DEFENSIVE ARMY | 0.3 | +0.0 | 0.0 | 77.7 | - | - | - | - |
| DENIED BY THE FIGHT | 0.3 | -0.7 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 13.0 | -157.2 | 0.0 | 38.3 | 6.0 | +73.0 | 0.0 | 0.0 |
| EXACT ROUND | 2.0 | +26.8 | 91.3 | 0.0 | 1.7 | -3.4 | 256.3 | 157.0 |
| FALL BACK GOOD ORDER | 2.0 | +15.5 | 91.3 | 0.0 | 0.3 | +0.0 | 40.0 | 157.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 20.3 | +137.8 | 0.0 | 221.0 |
| FEATURE BUFFS | 1.3 | +18.3 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 1.0 | +0.8 | 0.0 | 0.0 | 0.3 | +14.1 | 61.0 | 0.0 |
| FIRE IN ORDER | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 132.3 | +6485.8 | 3241.0 | 305.3 | 76.3 | +2292.8 | 549.7 | 995.3 |
| FLANK NOT WEIGHED | 2.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 45.7 |
| FOLLOW UP WEIGHED | - | - | - | - | 0.3 | +107.7 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.3 | +65.0 | 91.3 | 0.0 | 1.7 | +66.7 | 256.3 | 157.0 |
| FRIEND SHOOTS FIRST | 0.7 | -36.5 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | - | - | - | - | 0.7 | -1.3 | 61.0 | 0.0 |
| GOAL WALK | 3.7 | +105.8 | 0.0 | 0.0 | 13.3 | +944.8 | 0.0 | 0.0 |
| GUN FIGURES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| GUN MASK | 2.3 | +68.0 | 0.0 | 0.0 | 0.7 | -18.3 | 0.0 | 0.0 |
| HARD STAY DROPPED | 5.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | - | - | - | - | 0.7 | +0.0 | 155.3 | 0.0 |
| HIS CHARGE BY HIS RUN | 3.7 | +0.0 | 0.0 | 0.0 | 12.0 | +0.0 | 0.0 | 572.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +9.3 | 0.0 | 0.0 |
| HIS CHARGE LIST | 5.7 | +0.0 | 0.0 | 0.0 | 17.7 | +0.0 | 0.0 | 275.3 |
| HIS LEGAL MOVES | 3.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 157.0 |
| HIS MOVE AND SHOT | 1.7 | -20.1 | 0.0 | 0.0 | 4.3 | -25.7 | 0.0 | 359.7 |
| HIS MOVE AS HE DECIDES | 34.7 | +8.0 | 572.3 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 33.7 | +0.0 | 0.0 | 516.7 |
| HIS ONE MOVE | 18.7 | +39.3 | 0.0 | 0.0 | - | - | - | - |
| HIS ONE QUARTER | 3.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 3.0 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 157.0 |
| HIS RANDOM MOVE | 18.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 27.0 | +688.5 | 0.0 | 0.0 | 59.7 | +4625.8 | 0.0 | 838.3 |
| HIS SHOTS BY HIS RUN | 19.0 | +256.1 | 0.0 | 77.7 | 52.0 | +1733.3 | 0.0 | 747.0 |
| HIS TURN DENIED | 0.3 | +2.9 | 0.0 | 0.0 | 0.7 | +19.5 | 155.3 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 15.0 | +0.0 | 0.0 | 77.7 | 11.7 | +0.0 | 0.0 | 258.0 |
| HOLDER ASSIGNMENT | 10.3 | +1216.0 | 0.0 | 77.7 | 7.3 | +714.8 | 0.0 | 175.3 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.7 | -15.5 | 45.7 | 0.0 | 1.3 | -89.7 | 178.7 | 157.0 |
| IDLE COST | - | - | - | - | 17.0 | -334.9 | 0.0 | 221.3 |
| JOINT CHARGE NOW | 0.3 | -21.2 | 45.7 | 0.0 | 0.7 | +237.7 | 155.3 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 5.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 46.3 |
| LANE BY FIGURES | - | - | - | - | 1.3 | +77.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 1.0 | +0.0 | 0.0 | 61.0 | 2.7 | +0.0 | 61.0 | 46.3 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.3 | +25.0 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | -5.1 | 61.0 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| MANOEUVRE | 1.3 | -25.9 | 0.0 | 0.0 | 2.0 | +19.8 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 0.7 | +8.8 | 0.0 | 0.0 | 1.3 | +10.2 | 0.0 | 0.0 |
| MEETS IN TIME | 6.0 | +54.8 | 0.0 | 0.0 | 3.0 | +184.7 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | - | - | - | - | 0.3 | +0.5 | 0.0 | 0.0 |
| MISSILES NEXT TURN | - | - | - | - | 1.7 | +4.3 | 0.0 | 0.0 |
| MODEL FACING | 4.7 | +1464.6 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 2.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 46.3 | 45.7 |
| MOVE TO CHARGE COMPUTED | 6.3 | +311.4 | 0.0 | 0.0 | 1.7 | +88.8 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 3.7 | +185.7 | 0.0 | 0.0 | 4.0 | +278.1 | 0.0 | 91.3 |
| NEXT CHARGE BY LIST | 2.0 | +180.4 | 0.0 | 0.0 | 1.7 | +88.8 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -38.9 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.0 | -29.9 | 91.3 | 0.0 | 1.0 | -27.5 | 117.7 | 157.0 |
| NO LATE CUT | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 5.7 | -141.8 | 0.0 | 77.7 | 2.7 | -124.9 | 0.0 | 0.0 |
| ONE CHALLENGE TEST | - | - | - | - | 0.3 | +1.2 | 77.7 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.7 | -47.6 | 0.0 | 0.0 | 2.7 | -58.4 | 0.0 | 157.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +7.6 | 77.7 | 0.0 |
| ONE OBJECTIVE FORMULA | 3.0 | +1.7 | 0.0 | 77.7 | 3.0 | -40.4 | 0.0 | 129.0 |
| ONE ROUTE | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.3 | +8.7 | 0.0 | 0.0 | 1.0 | +7.1 | 117.7 | 157.0 |
| PATHS CROSS | 0.3 | +1.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 10.0 |
| PIVOT GUARDS FLANK | - | - | - | - | 0.3 | -2.7 | 0.0 | 0.0 |
| PLAN RESULT | 60.0 | +2084.8 | 1223.3 | 366.3 | 37.0 | +359.7 | 96.0 | 582.3 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 9.0 | -141.8 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 13.0 | +989.2 | 0.0 | 0.0 | 9.7 | +874.1 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.0 | +71.3 | 0.0 | 0.0 |
| REAL GROUND | 2.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 3.0 | -14.6 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 3.7 | +196.4 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.3 | -13.9 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 1.0 | +17.2 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | 0.7 | +14.7 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.0 | +83.3 | 91.3 | 0.0 | 1.3 | +64.9 | 178.7 | 157.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.0 | -8.9 | 178.7 | 157.0 |
| RUN DOWN | 2.0 | -15.7 | 91.3 | 0.0 | 0.7 | -7.4 | 77.7 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.0 | -89.0 | 0.0 | 20.0 |
| SEARCH SPOT | 0.3 | +5.0 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | - | - | - | - | 0.7 | -14.8 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.3 | +3.9 | 0.0 | 0.0 | 1.0 | +14.8 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 2.0 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 30.3 | +0.0 | 0.0 | 152.7 | 6.7 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.3 | +1.6 | 0.0 | 0.0 | 0.3 | +34.0 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 2.0 | +0.0 | 0.0 | 38.3 | - | - | - | - |
| SHOT OR CHARGE | 0.3 | -0.9 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 11.3 | +149.9 | 0.0 | 0.0 | 32.7 | -737.2 | 0.0 | 432.3 |
| SHOTS AFTER THE MOVES | 6.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 36.3 | +1505.4 | 0.0 | 152.7 | 9.3 | +347.4 | 0.0 | 37.0 |
| SPELL WORTH | - | - | - | - | 0.7 | +9.3 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 3.0 | +0.0 | 0.0 | 0.0 | 9.0 | +0.0 | 0.0 | 313.0 |
| STAND AND SHOOT | 0.3 | -1.2 | 0.0 | 0.0 | 0.3 | -4.5 | 61.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 3.0 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 93.0 | +0.0 | 3149.7 | 227.7 | 26.3 | +0.0 | 293.3 | 0.0 |
| STAY WORTH | 77.7 | +698.0 | 2808.3 | 105.0 | 13.3 | +363.3 | 293.3 | 0.0 |
| STUCK PIVOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.7 | +93.0 | 0.0 | 0.0 | 2.7 | +63.0 | 0.0 | 45.7 |
| SUPPORT NARROWED | 1.0 | +0.0 | 45.7 | 0.0 | 0.3 | +0.0 | 40.0 | 157.0 |
| SUPPORT WORKED OUT | 2.7 | +93.0 | 0.0 | 0.0 | 2.7 | +63.0 | 0.0 | 45.7 |
| SURE REACH TOGETHER | 0.3 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.7 | +9.7 | 0.0 | 10.0 |
| THE DEARER SUM KEEPS ITS PLAN | 2.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 10.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 92.0 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 13.7 |
| THE ROW READS HIS LAST RUN | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 13.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 61.7 | +0.0 | 0.0 | 152.7 | 36.3 | +0.0 | 0.0 | 406.0 |
| TIED UP BY THE SUM | 0.7 | +17.2 | 45.7 | 0.0 | 0.7 | +47.7 | 40.0 | 157.0 |
| TIME ON OUR SIDE | 53.3 | +591.2 | 27.3 | 77.7 | - | - | - | - |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WEAPON BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 45.7 |
| WHO FIGHTS | 1.0 | -1.6 | 45.7 | 0.0 | 0.7 | +6.1 | 77.7 | 0.0 |
| WHO HITS BACK | 0.3 | +7.7 | 0.0 | 0.0 | 0.3 | +8.0 | 0.0 | 157.0 |
| WHOLE FIGHT DANGER | - | - | - | - | 3.0 | -290.4 | 0.0 | 488.7 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +15.9 | 77.7 | 0.0 |
| WOUNDS ON THE RANKS | 2.3 | +101.1 | 0.0 | 0.0 | 5.0 | +265.8 | 0.0 | 0.0 |

### Rule changes: ccut-c940641-p16

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE WHY | 101 | 101 | 81 | 27.00 | +0 | +0.0 |
| HIS MOVE AS HE DECIDES | 104 | 104 | 80 | 26.67 | +0 | +0.0 |
| HIS SHOT LIST | 260 | 253 | 69 | 23.00 | +1948 | +28.2 |
| ARMY TABLE | 84 | 84 | 58 | 19.33 | +1339 | +23.1 |
| HOLDER ASSIGNMENT | 53 | 53 | 50 | 16.67 | +3070 | +61.4 |
| HIS SHOTS BY HIS RUN | 213 | 210 | 49 | 16.33 | +721 | +14.7 |
| DEPLOY BY FIGURES | 57 | 57 | 39 | 13.00 | +580 | +14.9 |
| SHOT RISK POINTS | 132 | 128 | 31 | 10.33 | +919 | +29.6 |
| TIME ON OUR SIDE | 160 | 144 | 26 | 8.67 | +82 | +3.1 |
| OFF BEST | 25 | 25 | 25 | 8.33 | -800 | -32.0 |
| THE TABLE AGAIN | 36 | 36 | 23 | 7.67 | +0 | +0.0 |
| FIVE ACTION | 626 | 617 | 21 | 7.00 | +434 | +20.7 |
| HARD STAY DROPPED | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 24 | 22 | 19 | 6.33 | +634 | +33.4 |
| HIS ONE MOVE | 56 | 55 | 18 | 6.00 | +0 | +0.0 |
| CANNON PLANNED TARGET | 77 | 77 | 16 | 5.33 | -60 | -3.7 |
| MODEL FACING | 14 | 14 | 14 | 4.67 | +4394 | +313.8 |
| MOVE ORDER | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 32 | 32 | 14 | 4.67 | -425 | -30.4 |
| ARTILLERY RE-ROLL WEIGHED | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| GOAL WALK | 51 | 51 | 9 | 3.00 | +478 | +53.1 |
| NEXT CHARGE BY LIST | 11 | 11 | 9 | 3.00 | +521 | +57.9 |
| CHAFF IN THE MOVE | 9 | 9 | 8 | 2.67 | +52 | +6.6 |
| FOUR ROUNDS | 12 | 12 | 8 | 2.67 | +129 | +16.2 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 8 | 2.67 | +214 | +26.8 |
| SUPPORT ADDS | 16 | 16 | 8 | 2.67 | +128 | +15.9 |
| SUPPORT WORKED OUT | 16 | 16 | 8 | 2.67 | +128 | +15.9 |
| CHARGE LOSSES | 83 | 82 | 7 | 2.33 | +125 | +17.9 |
| IDLE COST | 51 | 41 | 7 | 2.33 | +50 | +7.1 |
| QUARTER ODDS | 68 | 65 | 7 | 2.33 | +313 | +44.7 |
| REDIRECT FOR A FRIEND IN REACH | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| COVER ONCE | 31 | 24 | 6 | 2.00 | +146 | +24.3 |
| EXACT ROUND | 11 | 11 | 6 | 2.00 | +43 | +7.1 |
| MEETS IN TIME | 27 | 27 | 6 | 2.00 | +34 | +5.6 |
| RISK BY ARC | 10 | 10 | 6 | 2.00 | +134 | +22.3 |
| SHOOTERS IN TWO RANKS | 6 | 6 | 6 | 2.00 | +12 | +2.0 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SHOTS IN THE MOVE | 137 | 116 | 6 | 2.00 | +98 | +16.2 |
| SHOTS AFTER THE MOVES | 25 | 25 | 5 | 1.67 | +0 | +0.0 |
| CHAFF PASSED | 4 | 4 | 4 | 1.33 | -4 | -1.1 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +233 | +58.2 |
| STAY WORTH | 273 | 257 | 4 | 1.33 | +67 | +16.8 |
| WOUNDS ON THE RANKS | 22 | 22 | 4 | 1.33 | +191 | +47.8 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| GUN MASK | 9 | 9 | 3 | 1.00 | +132 | +43.9 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | +649 | +216.4 |
| MANOEUVRE | 10 | 10 | 3 | 1.00 | +59 | +19.8 |
| RESERVE FALL BACK | 3 | 3 | 3 | 1.00 | +52 | +17.2 |
| STUCK PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| THE RISK READS HIS RUN | 18 | 18 | 3 | 1.00 | +0 | +0.0 |
| TIED UP BY THE SUM | 4 | 4 | 3 | 1.00 | +30 | +9.9 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +54 | +27.2 |
| FALLS SHORT | 61 | 52 | 2 | 0.67 | +22 | +10.9 |
| FEATURE BUFFS | 4 | 4 | 2 | 0.67 | +4 | +2.2 |
| FIGHT TO THE END | 4 | 4 | 2 | 0.67 | +16 | +7.8 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| OVERRUNS AWAY | 4 | 4 | 2 | 0.67 | +8 | +3.9 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +3 | +1.6 |
| REDIRECT BY WHAT IT STOPS | 9 | 9 | 2 | 0.67 | +25 | +12.3 |
| RESTRAINS TO SHOOT | 2 | 2 | 2 | 0.67 | +44 | +22.1 |
| SHOOTS FROM THE BEST SPOT | 2 | 2 | 2 | 0.67 | +61 | +30.7 |
| SWIFTSTRIDE BY POINTS | 2 | 2 | 2 | 0.67 | +29 | +14.5 |
| WHO FIGHTS | 5 | 5 | 2 | 0.67 | +3 | +1.3 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +25 | +12.3 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +91 | +90.9 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +323 | +323.1 |
| FRIEND SHOOTS FIRST | 2 | 2 | 1 | 0.33 | +12 | +12.3 |
| HIS CHARGE DENIED | 1 | 1 | 1 | 0.33 | +1 | +0.6 |
| HIS MOVE AND SHOT | 18 | 18 | 1 | 0.33 | +4 | +3.7 |
| HIS TURN DENIED | 3 | 3 | 1 | 0.33 | +1 | +0.6 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +75 | +75.0 |
| ONE FIGHT FORMULA | 22 | 18 | 1 | 0.33 | +0 | +0.0 |
| ONE OBJECTIVE FORMULA | 18 | 11 | 1 | 0.33 | +20 | +19.9 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -8 | -8.2 |
| REDIRECT COUNTER | 11 | 10 | 1 | 0.33 | +45 | +44.7 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -11 | -10.7 |
| SEARCH SPOT | 1 | 1 | 1 | 0.33 | +15 | +15.0 |
| THE ROW IN ITS ORDER | 16 | 1 | 1 | 0.33 | +0 | +0.0 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 9 | 8 | 1 | 0.33 | +4 | +4.1 |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 4 | 4 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 14 | 14 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 5 | 5 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 51 | 51 | 0 | 0.00 | - | - |
| DEFENSIVE ARMY | 1 | 1 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 7 | 7 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 25 | not checked | - | - | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 47 | 46 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 70 | 68 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 23 | 22 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 17 | 17 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 23 | 23 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 55 | 55 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 80 | 79 | 0 | 0.00 | - | - |
| HONEST WORTH | 9 | 9 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 18 | 18 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 6 | 6 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH WHEELS ONLY | 10 | 10 | 0 | 0.00 | - | - |
| MAX FOR POSITIONING | 6 | 6 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 1 | 1 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 5 | 5 | 0 | 0.00 | - | - |
| NEARER NOT NEEDED | 23 | 21 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 9 | 9 | 0 | 0.00 | - | - |
| NO LATE CUT | 6 | 6 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE ROUTE | 10 | 10 | 0 | 0.00 | - | - |
| PLAN RESULT | 291 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 2 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 10 | 10 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 4 | 4 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 8 | 8 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 0 | 0.00 | - | - |
| SET UP BY THE SET | 2 | 2 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 4 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 111 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 2 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 36 | 23 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 9 | 9 | 0 | 0.00 | - | - |
| STANDS STILL | 358 | 355 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 4 | 4 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 11 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 18 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 1 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 11 | not checked | - | - | - | - |
| THE TABLE BINDS | 294 | not checked | - | - | - | - |
| WAITS AGAIN | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p16

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.00 | 2.33 | 32.5 |
| PROMISE BY ITS OWN SUM | rule | 4.67 | - | 30.4 |
| ARMY TABLE | rule | 1.33 | 2.00 | 26.4 |
| CANNON PLANNED TARGET | rule | 2.33 | - | 9.6 |
| CHAFF PASSED | rule | 0.67 | - | 2.2 |
| DEPLOY BY FIGURES | rule | - | 0.33 | 5.8 |
| FALLBACK | gate | 0.33 | - | 7.6 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 29.1 |
| JOINT CHARGE NOW | rule | 0.33 | - | 63.7 |
| NO REASON | gate | - | 0.33 | 71.9 |
| PIVOT GUARDS FLANK | rule | - | 0.33 | 8.2 |
| REFUSING RETIRES | rule | 0.33 | - | 10.7 |
| RULE SWITCHED OFF | gate | 0.33 | - | 5.8 |

### Plans: ccut-c940641-p16

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.0 | 33% | 63 | 144 | 228% |
| Mine | join | 2.7 | 100% | 88 | 0 | 0% |
| Mine | move | 31.3 | 99% | 1276 | 0 | 0% |
| Mine | shoot | 24.0 | 83% | 1422 | 1941 | 137% |
| Opponent | charge | 1.7 | 80% | 220 | 206 | 93% |
| Opponent | move | 29.0 | 97% | 897 | 0 | 0% |
| Opponent | shoot | 4.3 | 46% | 318 | 154 | 49% |
| Opponent | support | 2.0 | 83% | 29 | 0 | 0% |

### Battle groups: ccut-c940641-p16

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 3.7 | 9% | 0% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p16

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | Character | 13 | 3 (13) | 3 | 0 | 6 | 46% | 2.6 | 0 (3) | 0 (5) | 7 (4) | 4 (7) | 0 (5) |
| Mine | Clean-up | 3 | 0 (3) | 0 | 0 | 0 | 33% | 1.0 | 0 (1) | 0 (1) | 0 (1) | 0 (2) | 0 (1) |
| Mine | Hammer | 6 | 97 (6) | 28 | 68 | 0 | 50% | 3.0 | - | 108 (4) | 73 (2) | 100 (5) | 88 (1) |
| Mine | Shooter | 10 | 44 (10) | 0 | 44 | 29 | 0% | 2.7 | - | 45 (4) | 43 (6) | 42 (5) | 47 (5) |
| Mine | War machine | 17 | 36 (17) | 36 | 0 | 20 | 12% | 1.3 | 15 (9) | 0 (2) | 83 (6) | 157 (3) | 10 (14) |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 27 | 60% | 2.0 | 0 (4) | - | 0 (1) | 0 (4) | 0 (1) |
| Opponent | Character | 8 | 25 (8) | 25 | 0 | 18 | 50% | 3.5 | 10 (3) | 0 (1) | 43 (4) | 38 (5) | 0 (3) |
| Opponent | Clean-up | 3 | 53 (3) | 0 | 53 | 0 | 67% | 4.0 | 71 (1) | 34 (2) | - | 53 (3) | - |
| Opponent | Fast Hammer | 4 | 27 (4) | 0 | 27 | 12 | 50% | 2.5 | - | 48 (3) | 0 (1) | 61 (2) | 0 (2) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 0 | 67% | 6.0 | 0 (1) | 0 (2) | - | 0 (3) | - |
| Opponent | Holder | 2 | 0 (2) | 0 | 0 | 100 | 0% | 3.5 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | War machine | 2 | 110 (2) | 110 | 0 | 0 | 0% | 1.0 | - | - | 110 (2) | - | 110 (2) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 1.0 | 0 (1) | 0 (1) | - | 0 (2) | - |

### Charged fights: ccut-c940641-p16

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 3 | 254 | 46 | 2.0 | 1.2 | 23 | 0 | +23 | 0 of 6 | 5 of 6 | +137 | +0 |
| Opponent | Kingdom of Bretonnia | 1 | 220 | 120 | 1.0 | 1.0 | 120 | 0 | +120 | 0 of 1 | 1 of 1 | - | +120 |
| Opponent | Warriors of Chaos | 2 | 0 | 139 | 0.5 | 1.0 | 278 | 0 | +278 | 1 of 1 | 1 of 1 | - | +278 |
| **Opponent** | all armies | 3 | 73 | 133 | 0.7 | 1.0 | 199 | 0 | +199 | 1 of 2 | 2 of 2 | - | +199 |

### Effective charges: ccut-c940641-p16

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Dwarfen Mountain Holds | 6 | 0 | 0 | 1 (net +0) | 3 (net +0) | 0 | 2 (net +68) | 0 | 17% (1 of 6) |
| Opponent | Kingdom of Bretonnia | 1 | 0 | 0 | 0 | 0 | 1 (net +120) | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: ccut-c940641-p16

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 60 | 275 | +0 | 0 | 20 | -20 | -33.3 |
| Mine | 76-89% | 3 | 72 | 117 | +0 | 52 | 27 | +25 | +34.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 85 | 137 | +68 | 179 | 0 | +179 | +211.0 |
| Mine | All fights | 6 | 74 | 150 | +23 | 86 | 17 | +69 | +92.9 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 371 | 120 | +120 | 120 | 15 | +105 | +28.4 |
| Opponent | No odds | 1 | 489 | 183 | +278 | 278 | 0 | +278 | +56.9 |
| Opponent | All fights | 2 | 430 | 152 | +199 | 199 | 7 | +192 | +44.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p16 | move | 17 | 4 (24%) | 4 (24%) | 0 (0%) | 13 (76%) |

## Decision items and abilities without guidance

None: every decision item and ability on these lists has its guidance line.

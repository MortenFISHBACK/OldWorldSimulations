# Doctrine scorecard: ccut-c940641-p27

### Scorecard: ccut-c940641-p27

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0405 | 3 | 1 | Mine | no | 2 | 5 | 0 | 3 | 1 | 0 | 0 | 139 |
| L0405 | 3 | 1 | Opponent | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 548 |
| L0421 | 1 | 1 | Mine | no | 9 | 5 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 2 | - | 0 | 6 | 0 | 0 | 0 | 210 |
| L0508 | 4 | 1 | Mine | no | 7 | - | 0 | 2 | 0 | 0 | 0 | 380 |
| L0508 | 4 | 1 | Opponent | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 560 |
| **Average** | | | Mine | 0% | 6.0 | 5.0 | 0.3 | 2.0 | 0.3 | 0.0 | 0.0 | 173.0 |
| **Average** | | | Opponent | 0% | 0.7 | - | 0.0 | 3.7 | 0.0 | 0.0 | 0.0 | 439.3 |

### KPIs: ccut-c940641-p27

Rules off - Opponent only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 10% (1 of 10) | 71% (5 of 7) | 35% (6 of 17) |
| Winner chose to follow up after the loser gave ground |  | 0% (0 of 2); on the table 100% | 100% (1 of 1); on the table 100% | 33% (1 of 3); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 33% (1 of 3); on the table 100% | 100% (1 of 1); on the table 100% | 50% (2 of 4); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 25% (3 of 12) | 0% (0 of 6) | 17% (3 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 30% (3 of 10) | 0% (0 of 5) | 20% (3 of 15) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 44% (4 of 9) | 44% (4 of 9) |
| Points that never fought | lower | 86% (5131 of 5998) | 88% (5254 of 5999) | 87% (10385 of 11997) |
|   infantry points that never fought | lower | 87% (1235 of 1424) | 100% (1703 of 1703) | 94% (2938 of 3127) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 52% (12 of 23) | 69% (18 of 26) | 61% (30 of 49) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 52% (2688 of 5120) | 65% (3058 of 4677) | 59% (5746 of 9797) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.7 (56%) | 0.7 (33%) | 2.3 (47%) |
| MARCHED: its unit marched | 0.7 (22%) | 1.0 (50%) | 1.7 (33%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (17%) | 0.3 (7%) |
| GONE: slain | 0.7 (22%) | 0.0 (0%) | 0.7 (13%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.7 | 1.0 | 1.0 | 1.3 | 0.7 |
| not cast | 2.3 | 3.0 | 5.0 | 2.7 | 11.3 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.7 (56%) | 2.3 (47%) | 0.3 (12%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.7 (33%) | 0.3 (12%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.3 (7%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.7 (29%) | 0.7 (22%) | 0.7 (13%) | 0.7 (25%) | 0.3 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (50%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (71%) | 0.7 (22%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 11.0 (97%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 0.0 a game | 0.5 a game |
| stood (cast and not dispelled) | 67% (2 of 3) | - | 67% (2 of 3) |
| the unit moved after it | 50% (1 of 2) | - | 50% (1 of 2) |
| it charged on its next turn | 0% (0 of 2) | - | 0% (0 of 2) |
| the enemy charged it first | 0% (0 of 2) | - | 0% (0 of 2) |
| it fought by the end of its next turn | 0% (0 of 2) | - | 0% (0 of 2) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 2) | - | 0% (0 of 2) |
| none of these (no charge, no fight, no charge escaped) | 100% (2 of 2) | - | 100% (2 of 2) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 63% (52 of 83) | 70% (75 of 107) | 67% (127 of 190) |
|   cavalry | 67% (8 of 12) | 0% (0 of 7) | 42% (8 of 19) |
|   character | 50% (5 of 10) | 81% (22 of 27) | 73% (27 of 37) |
|   chariot | 65% (15 of 23) | 38% (5 of 13) | 56% (20 of 36) |
|   infantry | 17% (2 of 12) | 50% (11 of 22) | 38% (13 of 34) |
|   war machine | 85% (22 of 26) | 97% (37 of 38) | 92% (59 of 64) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.0 (29%) | 2.0 (19%) | 5.0 (24%) |
| NO TARGET IN RANGE | 4.3 (42%) | 5.3 (50%) | 9.7 (46%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 3.0 (29%) | 3.0 (28%) | 6.0 (29%) |
| OTHER BAR | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.7 | 0.3 | 88% | 0.6 pts | 2 pts |
| character | 9.0 | 4.3 | 74% | 11.8 pts | 107 pts |
| chariot | 6.7 | 10.7 | 45% | 22.5 pts | 150 pts |
| infantry | 8.0 | 1.7 | 83% | 4.9 pts | 39 pts |
| war machine | 19.7 | 19.0 | 56% | 24.3 pts | 477 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.7 | 0.0 | 0.3 |
| Charges that made contact a game | 0.7 | 0.0 | 0.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.09 declared, 0.09 contact (22 units) | 0.00 declared, 0.00 contact (22 units) | 0.05 declared, 0.05 contact (44 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 0% (0 of 3) | 100% (1 of 1) | - | 25% (1 of 4) |
| Character in a unit | 90% (9 of 10) | 50% (1 of 2) | - | 83% (10 of 12) |
| Character on its own | 100% (2 of 2) | 0% (0 of 2) | 100% (3 of 3) | 71% (5 of 7) |
| Chariot | 50% (1 of 2) | 60% (3 of 5) | - | 57% (4 of 7) |
| Infantry | 62% (5 of 8) | 40% (2 of 5) | 0% (0 of 1) | 50% (7 of 14) |
| Monster | - | 0% (0 of 1) | - | 0% (0 of 1) |
| War Machines | 75% (3 of 4) | - | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 2 | 33% (1 of 3); on the table 100% | 25% (3 of 12) | 78% | 44% (7 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Dwarfen Mountain Holds | 2 | - | - | 98% | 71% (10 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | - | - | 100% | 70% (7 of 10) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 67% | 67% (6 of 9) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p27, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | - | 50% (1) | 50% (1) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: ccut-c940641-p27

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 50% (1 of 2) | - |
| Strategy | Shoot objectives carried out (shot that target) | 66% (23 of 35) | 70% (30 of 43) |
| Strategy | Joined characters whose unit fought | 0% (0 of 5) | 0% (0 of 10) |
| Strategy | Lone characters that fought | 33% (2 of 6) | 20% (1 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.0 | 3.7 |
| Movement | Points that never moved of their own | 173.0 | 439.3 |
| Movement | Fights charged into per game | 0.7 | 0.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 2 | - |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | - |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 2, net +95 | - |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 2, net +540 | - |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.0 | 12.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (15 of 30) | 89% (34 of 38) |
| Shooting | Points destroyed by shooting units | 156.3 | 103.3 |
| Shooting | War machine shots | 7.3 | 12.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 23% (5 of 22) | 54% (20 of 37) |
| Shooting | Points destroyed by war machines | 176.0 | 261.3 |
| Magic | Magic missiles cast | 0.3 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 1) | - |
| Magic | Wounds caused by magic missiles | 1.7 | - |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 1.3 | 1.7 / 0.0 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 211.7 | 21.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +325 | - |
| Combat | Net per 100 charger points, damage counted | +95.9 | - |
| Combat | First round won (charged fights) | 100% | - |
| Combat | Net points per charged fight | +318 | - |
| Combat | Net points per supported fight / lone fight | - / +318 | - / - |
| Combat | Charged fights on a top-3 enemy unit | 1 of 2 | - |
| Game | Points lost | 416.3 | 726.3 |
| Game | VP from objectives | 1050.0 | 726.7 |
| Game | Lone holders (player turns) | 6.0 | 0.7 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +633 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 1143
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ccut-c940641-p27

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +6.9 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 15.0 | +686.5 | 0.0 | 92.7 | 9.3 | +32.8 | 0.0 | 209.3 |
| ARTILLERY RE-ROLL WEIGHED | 1.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 43.3 |
| ASSAILMENT BY POINTS | - | - | - | - | 0.7 | +3.8 | 0.0 | 360.0 |
| CANNON PLAN MISSED | 1.7 | +0.0 | 233.3 | 31.7 | 1.0 | +0.0 | 261.3 | 0.0 |
| CANNON PLANNED TARGET | 6.7 | +26.8 | 565.3 | 95.0 | 12.3 | +343.8 | 1252.0 | 190.0 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 1.3 | +10.2 | 0.0 | 30.3 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 3.3 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 21.0 | -919.7 | 0.0 | 593.3 | 10.7 | -904.6 | 0.0 | 617.3 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 241.3 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 10.3 | +0.0 | 0.0 | 43.3 | 5.0 | +0.0 | 0.0 | 124.0 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 70.0 |
| CONVEYANCE SEARCH | 1.0 | +113.8 | 46.3 | 0.0 | - | - | - | - |
| COVER ONCE | 3.3 | -122.3 | 0.0 | 31.7 | 4.3 | -292.6 | 0.0 | 210.7 |
| DEPLOY BY FIGURES | 8.7 | +40.3 | 0.0 | 0.0 | 9.0 | -53.5 | 0.0 | 135.0 |
| EXACT ROUND | 0.7 | +6.2 | 211.7 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 0.3 | +0.0 | 180.0 | 0.0 | - | - | - | - |
| FALLS SHORT | 9.0 | +129.1 | 0.0 | 286.0 | 8.0 | +127.9 | 0.0 | 136.0 |
| FEATURE BUFFS | - | - | - | - | 1.3 | +11.9 | 0.0 | 122.7 |
| FIRE IN ORDER | 1.7 | +0.0 | 72.3 | 31.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 95.3 | +6856.5 | 1756.0 | 1069.3 | 84.0 | +3814.3 | 3282.7 | 1517.3 |
| FLANK NOT WEIGHED | 1.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 217.3 |
| FOLLOW UP WEIGHED | - | - | - | - | 0.3 | +87.9 | 0.0 | 70.0 |
| FOUR ROUNDS | 0.7 | +140.0 | 211.7 | 0.0 | - | - | - | - |
| FREED FROM HIS FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -2.2 | 30.7 | 0.0 | - | - | - | - |
| GOAL WALK | 14.3 | +2083.6 | 0.0 | 43.3 | 3.0 | +87.8 | 0.0 | 0.0 |
| GUN FIGURES | 3.7 | +20.8 | 104.7 | 0.0 | 1.7 | +2.7 | 0.0 | 0.0 |
| HARD STAY DROPPED | 2.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 5.7 | +0.0 | 0.0 | 490.0 | 5.7 | +0.0 | 0.0 | 482.7 |
| HIS CHARGE LIST | 1.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 102.3 |
| HIS LEGAL MOVES | 4.7 | +0.0 | 0.0 | 103.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.7 | -28.7 | 0.0 | 0.0 | 3.7 | -117.8 | 0.0 | 61.3 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 39.3 | +12.3 | 683.0 | 0.0 |
| HIS MOVE WHY | 11.0 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 15.3 | -32.0 | 0.0 | 360.0 |
| HIS ONE QUARTER | 3.3 | +0.0 | 0.0 | 206.7 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 6.0 | +0.0 | 0.0 | 103.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 5.3 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.0 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 50.3 | +2532.3 | 0.0 | 792.7 | 36.0 | +1367.6 | 0.0 | 369.3 |
| HIS SHOTS BY HIS RUN | 38.3 | +1212.5 | 0.0 | 772.7 | 25.0 | +511.9 | 0.0 | 493.7 |
| HIS TURN DENIED | 0.3 | +8.0 | 31.7 | 0.0 | - | - | - | - |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 14.3 | +0.0 | 0.0 | 0.0 | 16.7 | +0.0 | 0.0 | 245.3 |
| HOLDER ASSIGNMENT | 10.0 | +1050.2 | 0.0 | 0.0 | 10.0 | +868.3 | 0.0 | 128.7 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.7 | -14.4 | 211.7 | 0.0 | - | - | - | - |
| HUNT IN PAIRS | 2.0 | +404.0 | 0.0 | 193.3 | - | - | - | - |
| IDLE COST | 6.7 | -112.4 | 0.0 | 261.3 | 9.0 | -119.0 | 0.0 | 88.7 |
| KEPT FROM ITS LAST STOP | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +36.6 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 0.7 | +0.0 | 140.0 | 21.7 | 0.3 | +0.0 | 0.0 | 180.0 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.7 | +63.4 | 0.0 | 0.0 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.3 | -17.3 | 0.0 | 18.3 |
| MANOEUVRE | 2.7 | +6.6 | 0.0 | 0.0 | 2.3 | -5.6 | 0.0 | 61.3 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.3 | +65.6 | 0.0 | 180.0 |
| MARCH CHECK | 1.0 | +83.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.3 | +17.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | +3.5 | 0.0 | 0.0 | 0.7 | +73.4 | 0.0 | 180.0 |
| MARCH WHEELS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.0 | +229.1 | 0.0 | 193.3 | 0.7 | +0.8 | 0.0 | 21.7 |
| MEETS IN TIME | 2.7 | +300.6 | 0.0 | 0.0 | 3.7 | +178.8 | 0.0 | 41.7 |
| MISSILES IN THE MOVE | 1.7 | +17.1 | 0.0 | 193.3 | 0.3 | +3.2 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 3.0 | +36.4 | 0.0 | 193.3 | 3.0 | +8.8 | 0.0 | 180.0 |
| MOVE ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 2.3 | +101.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 2.0 | -68.2 | 0.0 | 193.3 | - | - | - | - |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 4.3 | +702.9 | 0.0 | 103.3 | 0.3 | +21.9 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 7.0 | +359.8 | 0.0 | 0.0 | 5.7 | +231.9 | 0.0 | 98.7 |
| NEXT CHARGE BY LIST | 4.3 | +704.8 | 30.7 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 0.7 | -35.7 | 211.7 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 0.3 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 6.3 | -254.3 | 0.0 | 31.7 | 4.0 | -292.4 | 0.0 | 105.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 4.7 | -114.8 | 0.0 | 296.7 | 0.7 | -4.5 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 2.0 | +21.4 | 0.0 | 0.0 | 4.7 | +7.4 | 0.0 | 61.3 |
| ONE ROUTE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.7 | +14.0 | 211.7 | 0.0 | - | - | - | - |
| PATHS CROSS | 0.3 | -2.1 | 0.0 | 0.0 | 0.3 | +1.8 | 0.0 | 21.7 |
| PERIAPT WORTH | - | - | - | - | 0.3 | +40.5 | 0.0 | 0.0 |
| PLAN RESULT | 42.0 | +788.8 | 455.0 | 809.7 | 39.7 | +1326.7 | 909.3 | 1084.0 |
| PROMISE BY ITS OWN SUM | 10.0 | -343.9 | 0.0 | 103.3 | 1.3 | -42.7 | 0.0 | 0.0 |
| QUARTER ODDS | 26.0 | +2643.6 | 426.3 | 270.0 | 21.3 | +2095.1 | 1780.0 | 506.7 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.0 | +8.6 | 0.0 | 118.3 |
| REAL GROUND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.3 | +36.3 | 0.0 | 21.7 | 0.3 | -0.8 | 0.0 | 18.3 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 0.3 | +0.0 | 0.0 | 21.7 |
| RESERVE FALL BACK | 0.3 | +14.8 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 0.7 | -24.6 | 211.7 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | 0.3 | -1.1 | 31.7 | 0.0 | - | - | - | - |
| SAME CHARGE LATER | 0.3 | -14.2 | 30.7 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.3 | -166.9 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 4.7 | -1127.4 | 0.0 | 386.7 | - | - | - | - |
| SET UP BY THE SET | 5.3 | +944.1 | 61.3 | 386.7 | - | - | - | - |
| SET-UP ANY TARGET | 0.3 | +44.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | 0.7 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 10.3 | +0.0 | 0.0 | 95.0 | 15.0 | +0.0 | 0.0 | 208.3 |
| SHOOTS FROM THE BEST SPOT | 2.0 | +61.8 | 0.0 | 0.0 | 0.3 | +7.7 | 0.0 | 0.0 |
| SHORT GUN FORWARD | - | - | - | - | 0.3 | +0.0 | 0.0 | 45.0 |
| SHOT RISK POINTS | 33.7 | +539.2 | 0.0 | 743.3 | 18.0 | -14.3 | 0.0 | 473.0 |
| SHOTS AFTER THE MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 17.7 | +405.9 | 0.0 | 126.7 | 21.0 | +828.8 | 0.0 | 190.0 |
| SPELL SETS UP CHARGE | 0.3 | +44.3 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | - | - | - | - | 3.7 | +89.2 | 360.0 | 360.0 |
| SPOT AS THE GAME MOVES | 6.3 | +0.0 | 0.0 | 193.3 | 4.3 | +0.0 | 0.0 | 180.0 |
| STANDS FOR A REASON | 2.0 | +0.0 | 0.0 | 386.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 49.7 | +0.0 | 1544.3 | 389.3 | 49.3 | +0.0 | 3282.7 | 799.0 |
| STAY WORTH | 30.3 | +254.4 | 1108.3 | 325.0 | 37.3 | -15.0 | 2183.3 | 637.3 |
| STUCK PIVOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 48.3 |
| SUPPORT ADDS | - | - | - | - | 3.0 | +184.4 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | - | - | - | - | 3.0 | +184.4 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 4.7 | +0.0 | 0.0 | 21.7 | 3.7 | +0.0 | 0.0 | 59.0 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 4.0 | +0.0 | 0.0 | 21.7 | 3.0 | +0.0 | 0.0 | 59.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 45.7 | +0.0 | 0.0 | 503.0 | 40.7 | +0.0 | 0.0 | 641.3 |
| TIED UP BY THE SUM | 0.3 | +29.4 | 31.7 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 25.3 | +336.6 | 330.7 | 86.7 | 15.0 | +209.0 | 0.0 | 154.0 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -20.0 | 0.0 | 67.3 |
| WAR ENGINE JOBS | 2.3 | +0.0 | 21.7 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 1.3 | -91.7 | 0.0 | 0.0 | 2.0 | -646.9 | 0.0 | 360.0 |
| WOUNDS ON THE RANKS | 2.7 | +199.1 | 0.0 | 0.0 | 2.0 | +28.2 | 0.0 | 134.7 |

### Rule changes: ccut-c940641-p27

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 118 | 118 | 81 | 27.00 | +0 | +0.0 |
| ARMY TABLE | 73 | 73 | 57 | 19.00 | +1990 | +34.9 |
| HOLDER ASSIGNMENT | 60 | 60 | 56 | 18.67 | +3419 | +61.0 |
| HIS SHOTS BY HIS RUN | 190 | 179 | 51 | 17.00 | +1139 | +22.3 |
| HIS SHOT LIST | 259 | 245 | 40 | 13.33 | +626 | +15.6 |
| DEPLOY BY FIGURES | 53 | 53 | 38 | 12.67 | +613 | +16.1 |
| OFF BEST | 31 | 31 | 31 | 10.33 | -1640 | -52.9 |
| GOAL WALK | 52 | 43 | 22 | 7.33 | +2717 | +123.5 |
| SHOT RISK POINTS | 155 | 145 | 20 | 6.67 | +370 | +18.5 |
| HIS ONE MOVE | 46 | 45 | 18 | 6.00 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 18 | 6.00 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| TIME ON OUR SIDE | 121 | 101 | 15 | 5.00 | +10 | +0.7 |
| IDLE COST | 47 | 40 | 13 | 4.33 | +73 | +5.6 |
| PROMISE BY ITS OWN SUM | 34 | 34 | 13 | 4.33 | -1160 | -89.2 |
| SET UP BY THE SET | 16 | 16 | 13 | 4.33 | +1741 | +133.9 |
| HARD STAY DROPPED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| MOVE ORDER | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| STAY WORTH | 203 | 175 | 10 | 3.33 | +140 | +14.0 |
| ADVANCE LANE KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| CANNON PLANNED TARGET | 57 | 57 | 9 | 3.00 | -72 | -8.0 |
| HIS MOVE WHY | 33 | 33 | 8 | 2.67 | +0 | +0.0 |
| QUARTER ODDS | 142 | 140 | 8 | 2.67 | +972 | +121.5 |
| FIRE IN ORDER | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| FIVE ACTION | 538 | 521 | 6 | 2.00 | +314 | +52.4 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| MEETS IN TIME | 19 | 19 | 5 | 1.67 | +199 | +39.8 |
| THE RISK READS HIS RUN | 18 | 18 | 5 | 1.67 | +0 | +0.0 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +110 | +27.4 |
| NEXT CHARGE BY LIST | 13 | 13 | 4 | 1.33 | +871 | +217.8 |
| RANDOM MOVE BY FIGURES | 9 | 9 | 4 | 1.33 | +26 | +6.5 |
| SHOOTERS IN TWO RANKS | 4 | 4 | 4 | 1.33 | +8 | +2.0 |
| SHOTS IN THE MOVE | 116 | 75 | 4 | 1.33 | +51 | +12.8 |
| CHAFF IN THE MOVE | 4 | 4 | 3 | 1.00 | +0 | +0.0 |
| CHARGE LOSSES | 95 | 88 | 3 | 1.00 | +585 | +195.0 |
| HUNT IN PAIRS | 6 | 5 | 3 | 1.00 | +532 | +177.5 |
| LEGAL CHARGES ONLY | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MANOEUVRE | 15 | 15 | 3 | 1.00 | +29 | +9.8 |
| MOVE TO CHARGE COMPUTED | 14 | 13 | 3 | 1.00 | +870 | +289.9 |
| SHOOTS FROM THE BEST SPOT | 7 | 7 | 3 | 1.00 | +117 | +38.9 |
| STUCK PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| ASSAILMENT BY POINTS | 2 | 2 | 2 | 0.67 | +12 | +5.8 |
| FALLS SHORT | 51 | 45 | 2 | 0.67 | +22 | +10.8 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +190 | +95.2 |
| MAX FOR POSITIONING | 11 | 6 | 2 | 0.67 | +59 | +29.4 |
| NEARER NOT NEEDED | 38 | 36 | 2 | 0.67 | +79 | +39.5 |
| ONE OBJECTIVE FORMULA | 20 | 11 | 2 | 0.67 | +48 | +23.9 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | -1 | -0.5 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +21 | +20.7 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +264 | +263.6 |
| FOUR ROUNDS | 2 | 2 | 1 | 0.33 | +173 | +173.4 |
| HONEST WORTH | 2 | 2 | 1 | 0.33 | +96 | +96.0 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +197 | +196.9 |
| MARCH CHECK | 3 | 2 | 1 | 0.33 | +0 | +0.0 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -52 | -52.3 |
| OVERRUNS AWAY | 2 | 2 | 1 | 0.33 | +40 | +39.5 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +122 | +121.5 |
| REDIRECT COUNTER | 2 | 1 | 1 | 0.33 | +56 | +56.4 |
| REDIRECT FOR A FRIEND IN REACH | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +44 | +44.5 |
| SET CREDITED ONCE | 14 | 14 | 1 | 0.33 | +55 | +55.2 |
| SHORT GUN FORWARD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 23 | 23 | 1 | 0.33 | +0 | +0.0 |
| SUPPORT ADDS | 9 | 8 | 1 | 0.33 | +14 | +14.5 |
| SUPPORT WORKED OUT | 9 | 8 | 1 | 0.33 | +14 | +14.5 |
| TIED UP BY THE SUM | 1 | 1 | 1 | 0.33 | +40 | +39.5 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -60 | -60.0 |
| WAR ENGINE JOBS | 7 | 7 | 1 | 0.33 | -32 | -32.4 |
| WOUNDS ON THE RANKS | 14 | 14 | 1 | 0.33 | +18 | +17.6 |
| CANNON PLAN MISSED | 8 | 8 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CHARACTER GUNS | 30 | 30 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 3 | 3 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 46 | 45 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 3 | not checked | - | - | - | - |
| COVER ONCE | 23 | 12 | 0 | 0.00 | - | - |
| EXACT ROUND | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 4 | 4 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 11 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 16 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 34 | 33 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 13 | 13 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 16 | 12 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 19 | 18 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 20 | 20 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 19 | 15 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 16 | 11 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 6 | 6 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 93 | 92 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 7 | 6 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 6 | 3 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 18 | 10 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 7 | 1 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 6 | trace | - | - | - | - |
| MOVE SPELL SPOT | 1 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 16 | 8 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 245 | trace | - | - | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| RISK BY ARC | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 1 | 1 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SEARCH SPOT | 1 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 76 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 11 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 32 | 21 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 10 | 10 | 0 | 0.00 | - | - |
| STANDS STILL | 297 | 293 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 6 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 11 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 25 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 2 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 21 | not checked | - | - | - | - |
| THE TABLE BINDS | 259 | not checked | - | - | - | - |
| WAITS AGAIN | 3 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 10 | 10 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p27

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.33 | 4.00 | 53.3 |
| PROMISE BY ITS OWN SUM | rule | 3.67 | 0.67 | 89.2 |
| CANNON PLANNED TARGET | rule | - | 1.67 | 14.4 |
| ARMY TABLE | rule | 1.00 | 0.33 | 110.9 |
| NO REASON | gate | 1.00 | - | 48.8 |
| MARCH OF THE TABLE | rule | 0.33 | - | 52.3 |
| PATHS CROSS | rule | 0.33 | - | 6.4 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 60.0 |
| WAR ENGINE JOBS | rule | 0.33 | - | 32.4 |

### Plans: ccut-c940641-p27

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 0.7 | 100% | 240 | 212 | 88% |
| Mine | join | 0.3 | 100% | 11 | 0 | 0% |
| Mine | move | 31.0 | 95% | 2836 | 0 | 0% |
| Mine | shoot | 10.0 | 60% | 250 | 577 | 231% |
| Opponent | join | 1.0 | 100% | 35 | 0 | 0% |
| Opponent | move | 25.3 | 89% | 1034 | 0 | 0% |
| Opponent | shoot | 12.7 | 63% | 599 | 1327 | 222% |
| Opponent | support | 0.7 | 100% | 0 | 0 | - |

### Battle groups: ccut-c940641-p27

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p27

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | 0 (1) | - | 0 (1) | 0 (2) | - |
| Mine | Character | 11 | 33 (11) | 33 | 0 | 23 | 18% | 2.4 | 19 (5) | 70 (4) | 0 (2) | 15 (7) | 52 (4) |
| Mine | Clean-up | 3 | 157 (3) | 58 | 99 | 0 | 67% | 3.0 | 157 (3) | - | - | 150 (2) | 169 (1) |
| Mine | Hammer | 8 | 23 (8) | 9 | 15 | 20 | 12% | 1.7 | 0 (2) | 28 (6) | - | 40 (5) | 7 (3) |
| Mine | Holder | 4 | 105 (4) | 0 | 105 | 27 | 75% | 2.0 | 0 (1) | 138 (3) | - | 237 (1) | 56 (3) |
| Mine | Shooter | 1 | 27 (1) | 0 | 27 | 0 | 0% | 2.0 | 27 (1) | - | - | - | 27 (1) |
| Mine | War machine | 5 | 111 (5) | 111 | 0 | 40 | 0% | 1.0 | 111 (5) | - | - | 278 (2) | 0 (3) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 100 | 100% | - | 0 (1) | 0 (1) | 0 (1) | 0 (1) | 0 (2) |
| Opponent | Character | 14 | 16 (14) | 16 | 0 | 32 | 50% | 2.6 | 21 (10) | 0 (1) | - | 20 (9) | 0 (2) |
| Opponent | Clean-up | 4 | 96 (4) | 0 | 96 | 0 | 100% | - | - | 96 (4) | - | 96 (4) | - |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Hammer | 6 | 55 (6) | 26 | 29 | 29 | 17% | 2.6 | 75 (2) | 0 (1) | 64 (3) | 55 (6) | - |
| Opponent | Holder | 3 | 0 (3) | 0 | 0 | 65 | 100% | - | - | 0 (1) | 0 (1) | 0 (1) | 0 (1) |
| Opponent | Shooter | 4 | 12 (4) | 0 | 12 | 54 | 75% | 4.0 | - | 20 (3) | 0 (1) | 12 (4) | - |
| Opponent | War machine | 9 | 79 (9) | 79 | 0 | 62 | 11% | 1.0 | 79 (9) | - | - | 0 (1) | 92 (8) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | 0 (1) | - |

### Charged fights: ccut-c940641-p27

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 134 | 318 | 1.0 | 1.0 | 318 | 0 | +318 | 1 of 2 | 2 of 2 | - | +318 |
| Mine | Dwarfen Mountain Holds | 1 | 730 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 332 | 212 | 0.7 | 1.0 | 318 | 0 | +318 | 1 of 2 | 2 of 2 | - | +318 |
| Opponent | Dwarfen Mountain Holds | 1 | 1029 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 1 | 65 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 365 | 0 | 0.0 | - | - | - | - | - | - | - | - |

### Effective charges: ccut-c940641-p27

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 0 | 0 | 0 | 0 | 1 (net +95) | 1 (net +540) | 0 | 0% (0 of 2) |

### Charged fights, damage counted: ccut-c940641-p27

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 339 | 440 | +540 | 540 | 0 | +540 | +159.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 339 | 95 | +95 | 110 | 0 | +110 | +32.4 |
| Mine | All fights | 2 | 339 | 268 | +318 | 325 | 0 | +325 | +95.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p27 | move | 8 | 1 (12%) | 1 (12%) | 0 (0%) | 7 (88%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Periapt of Soul Exchange | Opponent | L0421 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421 |
| Witch Hunter's Ward | Opponent | L0508 |

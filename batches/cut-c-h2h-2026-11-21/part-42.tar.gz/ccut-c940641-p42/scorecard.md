# Doctrine scorecard: ccut-c940641-p42

### Scorecard: ccut-c940641-p42

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0918 | 6 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Opponent | no | 8 | - | 1 | 3 | 1 | 0 | 0 | 0 |
| L0934 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 399 |
| L0934 | 4 | 1 | Opponent | no | 0 | 3 | 4 | 6 | 0 | 0 | 0 | 500 |
| L1026 | 6 | 1 | Mine | no | 2 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1026 | 6 | 1 | Opponent | no | 4 | 5 | 2 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 0.7 | 2.0 | 0.7 | 1.0 | 0.0 | 0.0 | 0.0 | 133.0 |
| **Average** | | | Opponent | 0% | 4.0 | 4.0 | 2.3 | 3.7 | 0.3 | 0.0 | 0.0 | 166.7 |

### KPIs: ccut-c940641-p42

Rules off - Opponent only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 46% (6 of 13) | 0% (0 of 12) | 24% (6 of 25) |
| Winner chose to follow up after the loser gave ground |  | 100% (3 of 3); on the table 100% | 100% (3 of 3); on the table 100% | 100% (6 of 6); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 100% (4 of 4); on the table 100% | 100% (3 of 3); on the table 100% | 100% (7 of 7); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 38% (18 of 48) | 8% (1 of 12) | 32% (19 of 60) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 41% (18 of 44) | 9% (1 of 11) | 35% (19 of 55) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 63% (3783 of 5997) | 77% (4602 of 5998) | 70% (8385 of 11995) |
|   infantry points that never fought | lower | 62% (985 of 1591) | 91% (1047 of 1147) | 74% (2032 of 2738) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 68% (23 of 34) | 75% (15 of 20) | 70% (38 of 54) |
| Bound items with a magic missile used (at least once a game) |  | 50% (1 of 2); 1.7 uses a game | 100% (1 of 1); 1.3 uses a game | 67% (2 of 3); 1.5 uses a game |
| Bound items with another spell used |  | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 70% (3940 of 5667) | 69% (3564 of 5186) | 69% (7504 of 10853) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 5.3 (53%) | 0.3 (9%) | 5.7 (41%) |
| MARCHED: its unit marched | 3.0 (30%) | 1.0 (27%) | 4.0 (29%) |
| CHARGED: its unit charged | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| IN COMBAT: engaged in combat | 1.0 (10%) | 0.3 (9%) | 1.3 (10%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.7 (18%) | 0.7 (5%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 1.3 (36%) | 1.3 (10%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 1.0 | 6.3 | 0.7 | 1.0 |
| not cast | 2.0 | 5.0 | 13.7 | 3.3 | 15.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.7 (53%) | 5.7 (41%) | 1.3 (40%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 4.0 (29%) | 1.3 (40%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 1.3 (10%) | 0.3 (10%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (100%) | 2.0 (40%) | 0.7 (5%) | 0.0 (0%) | 0.0 (0%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.3 (7%) | 0.3 (2%) | 0.3 (10%) | 0.7 (4%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 1.3 (10%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.0 (93%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (80 of 131) | 68% (54 of 79) | 64% (134 of 210) |
|   cavalry | - | 55% (6 of 11) | 55% (6 of 11) |
|   character | 100% (7 of 7) | 56% (10 of 18) | 68% (17 of 25) |
|   chariot | 83% (15 of 18) | 92% (11 of 12) | 87% (26 of 30) |
|   infantry | 47% (22 of 47) | 62% (16 of 26) | 52% (38 of 73) |
|   monster | 50% (6 of 12) | 92% (11 of 12) | 71% (17 of 24) |
|   war machine | 64% (30 of 47) | - | 64% (30 of 47) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.0 (18%) | 4.3 (52%) | 7.3 (29%) |
| CHARGED: it charged | 0.0 (0%) | 1.0 (12%) | 1.0 (4%) |
| IN COMBAT: it fought this turn or the last | 0.3 (2%) | 0.0 (0%) | 0.3 (1%) |
| MOVED: a war machine that moved | 2.7 (16%) | 0.0 (0%) | 2.7 (11%) |
| NO TARGET IN RANGE | 3.3 (20%) | 1.0 (12%) | 4.3 (17%) |
| ONLY IN COMBAT: the only targets were in combat | 1.0 (6%) | 0.3 (4%) | 1.3 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 3.7 (22%) | 1.3 (16%) | 5.0 (20%) |
| SHELTERED: the target was sheltered | 2.7 (16%) | 0.0 (0%) | 2.7 (11%) |
| OTHER BAR | 0.3 (2%) | 0.3 (4%) | 0.7 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.0 | 0.7 | 78% | 1.8 pts | 5 pts |
| character | 5.7 | 2.3 | 59% | 4.6 pts | 26 pts |
| chariot | 8.7 | 6.3 | 65% | 15.4 pts | 133 pts |
| infantry | 13.0 | 6.3 | 69% | 6.9 pts | 90 pts |
| monster | 7.7 | 1.3 | 87% | 2.7 pts | 21 pts |
| war machine | 10.3 | 11.0 | 61% | 21.8 pts | 225 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.0 | 2.7 | 1.8 |
| Charges that made contact a game | 0.7 | 2.3 | 1.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.67 contact (3 units) | 1.00 declared, 1.00 contact (1 units) | 1.00 declared, 0.75 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.00 declared, 0.00 contact (20 units) | 0.23 declared, 0.19 contact (31 units) | 0.14 declared, 0.12 contact (51 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | - | - | 50% (2 of 4) |
| Character in a unit | 100% (5 of 5) | 100% (1 of 1) | - | 100% (6 of 6) |
| Character on its own | - | 33% (1 of 3) | 60% (3 of 5) | 50% (4 of 8) |
| Chariot | 100% (3 of 3) | 100% (2 of 2) | - | 100% (5 of 5) |
| Infantry | 36% (4 of 11) | 100% (2 of 2) | 0% (0 of 1) | 43% (6 of 14) |
| Monster | 100% (1 of 1) | 100% (1 of 1) | - | 100% (2 of 2) |
| Monstrous | 100% (2 of 2) | 100% (5 of 5) | - | 100% (7 of 7) |
| War Machines | 75% (6 of 8) | - | - | 75% (6 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 2 | 100% (1 of 1); on the table 100% | 50% (12 of 24) | 62% | 71% (17 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | 100% (3 of 3); on the table 100% | 25% (6 of 24) | 65% | 60% (6 of 10) | 50% (1 of 2); 5.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Ogre Kingdoms | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 6) | 96% | 100% (7 of 7) | 100% (1 of 1); 4.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (1 of 1); on the table 100% | 17% (1 of 6) | 64% | 60% (3 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (1 of 1); on the table 100% | - | 70% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p42, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 67% (4) | 0% (0) | 57% (4) |
| ...free all their last turn and able to turn (per game) | 1.00 | 0.00 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 1.00 | 0.00 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: ccut-c940641-p42

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 50% (1 of 2) | 57% (4 of 7) |
| Strategy | Shoot objectives carried out (shot that target) | 38% (20 of 53) | 46% (13 of 28) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 1) | - |
| Strategy | Joined characters whose unit fought | 44% (4 of 9) | 0% (0 of 1) |
| Strategy | Lone characters that fought | 40% (2 of 5) | 40% (2 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.0 | 3.7 |
| Movement | Points that never moved of their own | 133.0 | 166.7 |
| Movement | Fights charged into per game | 0.7 | 2.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 1 | 0 of 6 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 1 | 1 of 6, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 1, net +45 | 0 of 6 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 1 | 2 of 6, net +350 |
| Shooting | Shots by shooting units (incl. breath weapons) | 16.7 | 18.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 10% (5 of 50) | 43% (23 of 54) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 10.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 47% (14 of 30) | - |
| Shooting | Points destroyed by war machines | 41.3 | 0.0 |
| Magic | Magic missiles cast | 3.7 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 9% (1 of 11) | 100% (1 of 1) |
| Magic | Wounds caused by magic missiles | 5.3 | 2.0 |
| Magic | Wounds caused by other spells | 0.7 | - |
| Magic | Points destroyed by magic (all spells) | 67.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.3 / 0.7 / 0.3 | 2.7 / 0.0 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 82.7 | 88.3 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +52 | +80 |
| Combat | Net per 100 charger points, damage counted | +19.5 | +40.0 |
| Combat | First round won (charged fights) | 100% | 57% |
| Combat | Net points per charged fight | +52 | +94 |
| Combat | Net points per supported fight / lone fight | - / +52 | - / +94 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 2 | 3 of 7 |
| Game | Points lost | 310.7 | 253.3 |
| Game | VP from objectives | 566.7 | 746.7 |
| Game | Lone holders (player turns) | 0.7 | 4.0 |

- Mine won / drew / lost: 0 / 2 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -270 VP
- The side that went first won 1 of 1 games with a winner
- Points traded per game (both sides' losses): 564
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ccut-c940641-p42

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 12.0 | +322.6 | 0.0 | 324.0 | 27.7 | +261.8 | 0.0 | 277.3 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +15.6 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ASSAILMENT BY POINTS | 0.3 | +2.3 | 0.0 | 144.7 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 0.3 | +0.9 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.3 | -24.0 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.3 | +0.0 | 30.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 9.0 | +220.7 | 196.0 | 83.3 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 2.3 | +49.2 | 71.3 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | - | - | - | - | 1.3 | +24.3 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.7 | +1.6 | 0.0 | 144.7 | - | - | - | - |
| CHARACTER GUNS | 6.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 18.3 | -816.1 | 0.0 | 500.7 | 21.3 | -781.1 | 0.0 | 168.3 |
| CHARGE NOW FIRST | - | - | - | - | 0.3 | +0.0 | 144.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 9.7 | +0.0 | 0.0 | 0.0 | 15.0 | +0.0 | 0.0 | 88.0 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 88.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| COVER ONCE | 8.3 | -321.0 | 0.0 | 233.0 | 2.3 | -189.9 | 0.0 | 0.0 |
| DENIED BY THE FIGHT | - | - | - | - | 0.7 | -15.7 | 69.3 | 0.0 |
| DEPLOY BY FIGURES | 9.0 | -55.1 | 0.0 | 0.0 | 9.0 | +40.5 | 0.0 | 0.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +41.9 | 144.7 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 0.7 | +0.9 | 0.0 | 0.0 |
| EXACT ROUND | 1.0 | +1.6 | 35.0 | 0.0 | 2.0 | +29.2 | 267.7 | 36.3 |
| FALL BACK GOOD ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.5 | 302.3 | 0.0 |
| FALLS SHORT | - | - | - | - | 33.7 | +378.1 | 0.0 | 221.0 |
| FEATURE BUFFS | 0.7 | +3.6 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.3 | +1.6 | 0.0 | 0.0 | 0.3 | +0.2 | 34.7 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 106.3 | +4490.6 | 680.0 | 991.3 | 109.7 | +5789.7 | 302.3 | 746.3 |
| FLANK NOT WEIGHED | 6.7 | +0.0 | 0.0 | 377.7 | 5.0 | +0.0 | 0.0 | 36.3 |
| FOLLOW UP WEIGHED | 0.7 | +17.9 | 0.0 | 0.0 | 0.7 | +119.6 | 0.0 | 0.0 |
| FOUR ROUNDS | 1.0 | +25.4 | 35.0 | 0.0 | 2.3 | +129.1 | 302.3 | 36.3 |
| FREED FROM HIS FIGHT | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 0.7 | -4.1 | 0.0 | 0.0 |
| GIVES UP | 0.7 | -5.2 | 20.0 | 0.0 | - | - | - | - |
| GOAL WALK | 9.0 | +446.3 | 0.0 | 0.0 | 25.0 | +2262.1 | 0.0 | 97.3 |
| GUN FIGURES | 2.7 | +10.2 | 123.3 | 0.0 | 1.0 | +7.7 | 0.0 | 123.3 |
| GUN MASK | 5.3 | +264.0 | 0.0 | 88.3 | - | - | - | - |
| HARD STAY DROPPED | 2.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 61.7 |
| HE REFORMS ONCE FREED | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 9.3 | +0.0 | 0.0 | 466.0 | 5.3 | +0.0 | 0.0 | 72.7 |
| HIS CHARGE LIST | 2.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.7 | +0.0 | 0.0 | 578.7 | 2.3 | +0.0 | 0.0 | 47.7 |
| HIS MOVE AND SHOT | 4.0 | -26.2 | 0.0 | 0.0 | 9.0 | -118.5 | 0.0 | 34.0 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 37.3 | +12.7 | 570.0 | 0.0 |
| HIS MOVE WHY | 27.3 | +0.0 | 0.0 | 144.7 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 23.3 | -6.1 | 0.0 | 13.3 |
| HIS ONE QUARTER | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 3.7 | +0.0 | 0.0 | 578.7 | 1.7 | +0.0 | 0.0 | 47.7 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 41.0 | +1316.0 | 0.0 | 535.3 | 79.3 | +5922.1 | 0.0 | 411.0 |
| HIS SHOTS BY HIS RUN | 36.7 | +929.1 | 0.0 | 535.3 | 65.3 | +1601.7 | 0.0 | 388.7 |
| HIS TURN DENIED | - | - | - | - | 1.3 | +145.8 | 157.7 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 19.7 | +0.0 | 0.0 | 0.0 | 19.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 13.3 | +1324.5 | 0.0 | 0.0 | 14.7 | +1433.2 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -21.5 | 35.0 | 0.0 | 2.0 | -49.7 | 302.3 | 36.3 |
| HUNT IN PAIRS | 0.3 | +9.9 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | - | - | - | - | 24.0 | -405.7 | 0.0 | 118.0 |
| KEEP FALLS | 0.3 | +1.6 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 6.3 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.7 | +15.4 | 0.0 | 0.0 | 1.3 | +93.2 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 1.0 | +0.0 | 20.0 | 123.0 | 3.7 | +0.0 | 104.0 | 89.7 |
| LONE WIZARD KEPT IN | 1.3 | +43.3 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.7 | -2.2 | 34.7 | 0.0 |
| LOST AFTER ESCAPE | 0.7 | -0.4 | 20.0 | 0.0 | 1.7 | +4.0 | 123.0 | 36.3 |
| MAKE SURE TOGETHER | - | - | - | - | 0.3 | +5.4 | 0.0 | 35.7 |
| MANOEUVRE | 2.3 | -12.8 | 0.0 | 0.0 | 0.7 | -1.2 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 1.0 | +10.7 | 0.0 | 144.7 | - | - | - | - |
| MARCH BY THE SUM | 1.0 | +36.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.7 | +82.0 | 0.0 | 0.0 | 1.0 | +52.2 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +6.7 | 0.0 | 0.0 | 0.3 | +40.0 | 0.0 | 0.0 |
| MARCH OVER CASTS | 1.7 | +302.5 | 0.0 | 144.7 | - | - | - | - |
| MARCH WHEELS ONLY | 4.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.3 | +15.2 | 0.0 | 144.7 | 1.7 | +23.3 | 0.0 | 58.3 |
| MEETS IN TIME | 3.7 | +414.2 | 0.0 | 0.0 | 3.7 | +549.1 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 10.0 | +158.2 | 0.0 | 144.7 | 1.7 | +25.1 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 12.3 | +122.2 | 0.0 | 289.3 | 2.7 | +24.0 | 0.0 | 0.0 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 71.3 | 62.0 |
| MOVE TO CHARGE COMPUTED | 1.7 | +53.7 | 0.0 | 0.0 | 4.0 | +356.5 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.0 | +273.1 | 0.0 | 0.0 | 6.7 | +311.7 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 0.7 | +11.3 | 0.0 | 0.0 | 3.0 | +216.0 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.0 | -7.0 | 35.0 | 0.0 | 2.0 | -157.9 | 302.3 | 36.3 |
| NO LATE CUT | 4.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| OFF BEST | 5.0 | -96.8 | 20.0 | 0.0 | 3.7 | -64.1 | 0.0 | 35.7 |
| OGRE LOADER SECOND SHOT | 3.0 | +11.9 | 0.0 | 0.0 | - | - | - | - |
| ONE CHALLENGE TEST | 0.3 | -1.8 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 3.0 | -38.6 | 0.0 | 88.3 | 4.3 | -77.4 | 0.0 | 83.3 |
| ONE OBJECTIVE FORMULA | 4.3 | +58.5 | 0.0 | 0.0 | 5.7 | +6.6 | 0.0 | 0.0 |
| ONE ROUTE | 4.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +17.2 | 34.7 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +21.7 | 0.0 | 0.0 |
| PLAN RESULT | 45.7 | +878.6 | 232.3 | 653.3 | 49.0 | +357.0 | 179.3 | 379.0 |
| PROMISE BY ITS OWN SUM | 5.0 | -106.3 | 0.0 | 0.0 | 4.7 | -169.5 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.7 | -11.6 | 0.0 | 0.0 |
| QUARTER ODDS | 9.3 | +664.7 | 251.0 | 260.0 | 13.3 | +848.1 | 88.3 | 36.3 |
| REAL GROUND | 4.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.3 | +5.6 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 3.3 | +130.5 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 5.0 | +12.9 | 0.0 | 36.0 |
| REFORMS TO MEET IT | - | - | - | - | 2.0 | -50.9 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +3.6 | 0.0 | 0.0 |
| RISK BY ARC | 1.0 | +29.9 | 35.0 | 0.0 | 1.7 | -104.0 | 302.3 | 36.3 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.7 | -24.4 | 179.3 | 0.0 |
| RUN DOWN | - | - | - | - | 1.7 | -21.2 | 214.0 | 36.3 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +7.2 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.7 | -266.7 | 0.0 | 0.0 |
| SEARCH SPOT | 1.0 | +3.3 | 0.0 | 34.7 | 0.3 | +4.1 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +7.8 | 20.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 1.3 | -10.9 | 0.0 | 26.7 |
| SET UP BY THE SET | - | - | - | - | 1.7 | +61.2 | 0.0 | 26.7 |
| SET UP TOGETHER | - | - | - | - | 0.3 | +5.4 | 0.0 | 35.7 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 17.0 | +0.0 | 0.0 | 83.3 | 10.7 | +0.0 | 0.0 | 18.7 |
| SHOOTS FROM THE BEST SPOT | 4.7 | +76.0 | 108.7 | 0.0 | 5.0 | +133.0 | 0.0 | 123.3 |
| SHOT OR CHARGE | 0.3 | -4.1 | 0.0 | 0.0 | 0.7 | -35.8 | 0.0 | 36.3 |
| SHOT RISK POINTS | 23.7 | -375.6 | 0.0 | 211.3 | 49.0 | -37.7 | 0.0 | 289.0 |
| SHOTS AFTER THE MOVES | 5.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 30.0 | +1141.4 | 0.0 | 206.3 | 18.0 | +333.6 | 0.0 | 142.0 |
| SPELL WORTH | - | - | - | - | 4.0 | +39.5 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 4.7 | +0.0 | 0.0 | 0.0 | 6.7 | +0.0 | 0.0 | 85.7 |
| STAND AND SHOOT | - | - | - | - | 0.7 | -5.1 | 34.7 | 36.3 |
| STANDS FOR A REASON | - | - | - | - | 11.7 | +0.0 | 0.0 | 73.0 |
| STANDS STILL | 55.7 | +0.0 | 645.0 | 166.7 | 36.7 | +0.0 | 0.0 | 269.0 |
| STAY WORTH | 45.7 | +487.7 | 429.3 | 284.7 | 29.3 | +305.6 | 0.0 | 207.7 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +0.2 | 0.0 | 11.3 |
| SUPPORT ADDS | 0.3 | +54.4 | 0.0 | 0.0 | 1.0 | +44.3 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 0.3 | +54.4 | 0.0 | 0.0 | 1.0 | +44.3 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 123.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 18.7 |
| THE ROW KEEPS ITS WAY | 4.7 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 3.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 46.0 | +0.0 | 0.0 | 495.7 | 54.0 | +0.0 | 0.0 | 349.3 |
| TIED UP BY THE SUM | 0.3 | +28.3 | 15.0 | 0.0 | 0.3 | +53.6 | 34.7 | 0.0 |
| TIME ON OUR SIDE | 53.3 | +682.4 | 37.3 | 324.0 | - | - | - | - |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 123.3 |
| WHO FIGHTS | - | - | - | - | 0.3 | -6.4 | 0.0 | 0.0 |
| WHO HITS BACK | 0.3 | +2.5 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 2.3 | -333.9 | 0.0 | 289.3 | 0.7 | -30.7 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 5.0 | +65.7 | 0.0 | 0.0 | 0.7 | +9.0 | 0.0 | 0.0 |

### Rule changes: ccut-c940641-p42

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 361 | 353 | 134 | 44.67 | +2713 | +20.2 |
| ARMY TABLE | 119 | 119 | 98 | 32.67 | +1644 | +16.8 |
| HIS SHOTS BY HIS RUN | 306 | 298 | 96 | 32.00 | +1392 | +14.5 |
| HOLDER ASSIGNMENT | 84 | 84 | 78 | 26.00 | +4965 | +63.6 |
| HIS MOVE AS HE DECIDES | 112 | 112 | 74 | 24.67 | +0 | +0.0 |
| HIS MOVE WHY | 82 | 82 | 55 | 18.33 | +0 | +0.0 |
| SHOT RISK POINTS | 218 | 211 | 52 | 17.33 | +1492 | +28.7 |
| GOAL WALK | 102 | 100 | 35 | 11.67 | +1394 | +39.8 |
| DEPLOY BY FIGURES | 54 | 54 | 32 | 10.67 | +492 | +15.4 |
| THE TABLE AGAIN | 36 | 36 | 28 | 9.33 | +0 | +0.0 |
| OFF BEST | 26 | 26 | 26 | 8.67 | -483 | -18.6 |
| HARD STAY DROPPED | 23 | 23 | 23 | 7.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 160 | 137 | 20 | 6.67 | +115 | +5.8 |
| HIS ONE MOVE | 70 | 69 | 19 | 6.33 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| MEETS IN TIME | 22 | 22 | 18 | 6.00 | +1382 | +76.8 |
| MOVE ORDER | 17 | 17 | 17 | 5.67 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 15 | 15 | 15 | 5.00 | +9 | +0.6 |
| STAY WORTH | 225 | 201 | 15 | 5.00 | +133 | +8.9 |
| LEGAL CHARGES ONLY | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 29 | 29 | 13 | 4.33 | -827 | -63.7 |
| SHOOTS FROM THE BEST SPOT | 29 | 29 | 13 | 4.33 | +208 | +16.0 |
| IDLE COST | 72 | 48 | 12 | 4.00 | +136 | +11.3 |
| FIVE ACTION | 648 | 634 | 10 | 3.33 | +272 | +27.2 |
| OGRE LOADER SECOND SHOT | 9 | 9 | 9 | 3.00 | +36 | +4.0 |
| MOVE TO CHARGE COMPUTED | 17 | 13 | 8 | 2.67 | +309 | +38.6 |
| CAST JOB | 7 | 7 | 7 | 2.33 | +33 | +4.8 |
| GUN MASK | 16 | 16 | 7 | 2.33 | +301 | +43.0 |
| CHARGE LOSSES | 119 | 114 | 6 | 2.00 | +356 | +59.3 |
| LANE BY FIGURES | 6 | 6 | 6 | 2.00 | +326 | +54.3 |
| MAX FOR POSITIONING | 12 | 11 | 6 | 2.00 | +16 | +2.7 |
| MARCH CHECK | 8 | 8 | 5 | 1.67 | +101 | +20.1 |
| SCOUT WAITS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| SHOTS IN THE MOVE | 144 | 118 | 5 | 1.67 | +196 | +39.2 |
| THE RISK READS HIS RUN | 18 | 18 | 5 | 1.67 | +0 | +0.0 |
| ADVANCE LANE KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CASTING BLOCK | 4 | 4 | 4 | 1.33 | +14 | +3.4 |
| FALLS SHORT | 101 | 84 | 4 | 1.33 | +4 | +1.1 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +412 | +103.1 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +130 | +32.5 |
| NEARER NOT NEEDED | 38 | 35 | 4 | 1.33 | +85 | +21.2 |
| NEXT CHARGE BY LIST | 11 | 8 | 4 | 1.33 | +45 | +11.3 |
| WOUNDS ON THE RANKS | 17 | 17 | 4 | 1.33 | +6 | +1.6 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FOUR ROUNDS | 10 | 9 | 3 | 1.00 | +64 | +21.2 |
| HIS TURN DENIED | 4 | 4 | 3 | 1.00 | +257 | +85.5 |
| MARCH BY THE SUM | 3 | 3 | 3 | 1.00 | +111 | +36.9 |
| QUARTER ODDS | 68 | 64 | 3 | 1.00 | +161 | +53.7 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +5 | +2.4 |
| COVER ONCE | 32 | 26 | 2 | 0.67 | +5 | +2.5 |
| EXACT ROUND | 9 | 8 | 2 | 0.67 | +61 | +30.5 |
| HIS MOVE AND SHOT | 39 | 37 | 2 | 0.67 | +6 | +3.0 |
| MANOEUVRE | 9 | 9 | 2 | 0.67 | +7 | +3.5 |
| MARCH OF THE TABLE | 2 | 2 | 2 | 0.67 | -140 | -70.0 |
| MISSILES IN THE MOVE | 35 | 29 | 2 | 0.67 | +15 | +7.7 |
| MISSILES NEXT TURN | 45 | 33 | 2 | 0.67 | +8 | +4.2 |
| ONE OBJECTIVE FORMULA | 30 | 28 | 2 | 0.67 | +65 | +32.5 |
| RISK BY ARC | 8 | 7 | 2 | 0.67 | +30 | +14.8 |
| SEARCH SPOT | 4 | 4 | 2 | 0.67 | +22 | +11.1 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +4 | +2.0 |
| SHOTS AFTER THE MOVES | 25 | 25 | 2 | 0.67 | +0 | +0.0 |
| TIED UP BY THE SUM | 2 | 2 | 2 | 0.67 | +127 | +63.7 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +7 | +6.9 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -72 | -71.9 |
| EVASIVE BY THE ODDS | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| FIGHT TO THE END | 2 | 2 | 1 | 0.33 | +1 | +1.2 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HOLDS AMBUSHERS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +6 | +6.1 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +65 | +65.0 |
| PROMISE READS THE TABLE | 2 | 2 | 1 | 0.33 | -14 | -14.3 |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 1 | 0.33 | +9 | +8.7 |
| REFORMS TO MEET IT | 6 | 5 | 1 | 0.33 | +12 | +12.0 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -37 | -37.2 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +11 | +10.7 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +23 | +23.4 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +1 | +0.6 |
| SUPPORT ADDS | 4 | 4 | 1 | 0.33 | +113 | +113.2 |
| SUPPORT WORKED OUT | 4 | 4 | 1 | 0.33 | +113 | +113.2 |
| THE ROW IN ITS ORDER | 19 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +7 | +7.5 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLANNED TARGET | 27 | 27 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 19 | 19 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 74 | 73 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| EDGE GIVE GROUND | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 7 | 7 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 35 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 7 | 7 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 2 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 11 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 5 | 5 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 44 | 44 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 12 | 11 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 15 | 14 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 7 | 7 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 16 | 13 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 118 | 118 | 0 | 0.00 | - | - |
| HONEST WORTH | 9 | 8 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 27 | 27 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 4 | 4 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 7 | 6 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 16 | 16 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 9 | 8 | 0 | 0.00 | - | - |
| NO LATE CUT | 16 | 16 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHALLENGE TEST | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 22 | 16 | 0 | 0.00 | - | - |
| ONE ROUTE | 16 | 16 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 284 | trace | - | - | - | - |
| REAL GROUND | 16 | 16 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 10 | 10 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 4 | 4 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 5 | 5 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 8 | 8 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SET UP BY THE SET | 5 | 5 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 83 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL WORTH | 12 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 34 | 32 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 35 | 33 | 0 | 0.00 | - | - |
| STANDS STILL | 277 | 271 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 13 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 33 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 3 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 21 | not checked | - | - | - | - |
| THE TABLE BINDS | 300 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 4 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 17 | 17 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 9 | 9 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p42

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.33 | 2.67 | 20.1 |
| PROMISE BY ITS OWN SUM | rule | 3.00 | 1.33 | 63.7 |
| ARMY TABLE | rule | - | 4.00 | 36.1 |
| HOLDER ASSIGNMENT | rule | 1.00 | 0.67 | 24.0 |
| RULE SWITCHED OFF | gate | - | 1.00 | 15.6 |
| MARCH OF THE TABLE | rule | 0.33 | 0.33 | 70.0 |
| AFTERMATH BAND | gate | 0.33 | - | 1.0 |
| BEST PRIZE | rule | - | 0.33 | 71.9 |
| NO REASON | gate | 0.33 | - | 13.0 |
| PROMISE READS THE TABLE | rule | - | 0.33 | 14.3 |
| REFUSING RETIRES | rule | - | 0.33 | 37.2 |

### Plans: ccut-c940641-p42

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 67% | 27 | 47 | 173% |
| Mine | move | 30.0 | 98% | 1280 | 0 | 0% |
| Mine | shoot | 14.7 | 61% | 780 | 832 | 107% |
| Opponent | charge | 1.0 | 100% | 142 | 197 | 138% |
| Opponent | move | 39.7 | 95% | 2038 | 0 | 0% |
| Opponent | shoot | 7.0 | 52% | 425 | 160 | 38% |
| Opponent | support | 1.3 | 100% | 0 | 0 | - |

### Battle groups: ccut-c940641-p42

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 3.3 | 10% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p42

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 12 | 18 (12) | 18 | 0 | 25 | 33% | 2.9 | 21 (5) | 9 (5) | 32 (2) | 27 (7) | 9 (5) |
| Mine | Clean-up | 2 | 83 (2) | 0 | 83 | 0 | 100% | - | - | - | 83 (2) | 83 (2) | - |
| Mine | Fast Hammer | 3 | 13 (3) | 0 | 13 | 0 | 33% | 1.5 | 0 (1) | 20 (2) | - | 18 (2) | 0 (1) |
| Mine | Hammer | 7 | 6 (7) | 2 | 4 | 17 | 14% | 1.8 | 0 (1) | 14 (3) | 0 (3) | 9 (5) | 0 (2) |
| Mine | Shooter | 6 | 94 (6) | 17 | 77 | 33 | 0% | 2.0 | 105 (1) | 159 (2) | 48 (3) | 113 (5) | 0 (1) |
| Mine | War machine | 8 | 11 (8) | 11 | 0 | 12 | 0% | 1.1 | 0 (1) | 25 (4) | 0 (3) | - | 11 (8) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 2.0 | - | 0 (2) | - | 0 (2) | - |
| Opponent | Chaff | 11 | 155 (11) | 0 | 155 | 44 | 45% | 2.5 | 142 (3) | 117 (1) | 171 (7) | 155 (11) | - |
| Opponent | Character | 6 | 32 (6) | 32 | 0 | 0 | 0% | 1.7 | 43 (2) | 51 (2) | 0 (2) | 37 (2) | 28 (4) |
| Opponent | Clean-up | 4 | 27 (4) | 0 | 27 | 24 | 25% | 2.7 | - | 56 (2) | 0 (2) | 36 (3) | 0 (1) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Opponent | Hammer | 10 | 0 (10) | 0 | 0 | 16 | 50% | 1.4 | 0 (4) | 0 (4) | 0 (2) | 0 (2) | 0 (8) |
| Opponent | Holder | 1 | 92 (1) | 0 | 92 | 0 | 100% | - | - | 92 (1) | - | - | 92 (1) |
| Opponent | Shooter | 1 | 150 (1) | 0 | 150 | 0 | 0% | 1.0 | - | 150 (1) | - | 150 (1) | - |

### Charged fights: ccut-c940641-p42

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 144 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Mine | Grand Cathay | 1 | 40 | 105 | 2.0 | 1.0 | 52 | 0 | +52 | 0 of 2 | 2 of 2 | - | +52 |
| **Mine** | all armies | 3 | 109 | 35 | 0.7 | 1.0 | 52 | 0 | +52 | 0 of 2 | 2 of 2 | - | +52 |
| Opponent | Ogre Kingdoms | 1 | 0 | 0 | 2.0 | 1.0 | 0 | 17 | -17 | 1 of 2 | 1 of 2 | - | -17 |
| Opponent | Vampire Counts | 1 | 0 | 434 | 2.0 | 1.0 | 217 | 0 | +217 | 1 of 2 | 1 of 2 | - | +217 |
| Opponent | Wood Elf Realms | 1 | 0 | 369 | 3.0 | 1.0 | 123 | 36 | +87 | 1 of 3 | 2 of 3 | - | +87 |
| **Opponent** | all armies | 3 | 0 | 268 | 2.3 | 1.0 | 115 | 20 | +94 | 3 of 7 | 4 of 7 | - | +94 |

### Effective charges: ccut-c940641-p42

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 2 | 0 | 0 | 0 | 0 | 1 (net +45) | 0 | 1 | 0% (0 of 1) |
| Opponent | Ogre Kingdoms | 2 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Vampire Counts | 2 | 0 | 0 | 1 (net +0) | 0 | 0 | 1 (net +434) | 0 | 50% (1 of 2) |
| Opponent | Wood Elf Realms | 3 | 0 | 0 | 0 | 2 (net -2) | 0 | 1 (net +265) | 0 | 0% (0 of 3) |

### Charged fights, damage counted: ccut-c940641-p42

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 334 | 45 | +45 | 45 | 0 | +45 | +13.5 |
| Mine | No odds | 1 | 205 | 60 | +60 | 60 | 0 | +60 | +29.3 |
| Mine | All fights | 2 | 270 | 52 | +52 | 52 | 0 | +52 | +19.5 |
| Opponent | Effective (55-75%) | 1 | 110 | 162 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 76-89% | 3 | 86 | 158 | -2 | 59 | 56 | +2 | +2.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 499 | 300 | +350 | 350 | 55 | +294 | +58.9 |
| Opponent | No odds | 1 | 34 | 189 | -34 | 0 | 34 | -34 | -100.0 |
| Opponent | All fights | 7 | 200 | 203 | +94 | 125 | 45 | +80 | +40.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p42 | move | 14 | 4 (29%) | 3 (21%) | 1 (7%) | 9 (64%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0934, L1026 |
| Fistful of Laurels | Opponent | L0918 |
| Ring of Jet | Mine | L1026 |
| Twice-Blessed Armour | Mine | L1026 |

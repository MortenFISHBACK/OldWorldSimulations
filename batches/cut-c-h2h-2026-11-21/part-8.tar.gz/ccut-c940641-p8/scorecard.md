# Doctrine scorecard: ccut-c940641-p8

### Scorecard: ccut-c940641-p8

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1319 | 5 | 1 | Mine | yes | - | 3 | 2 | 2 | 0 | 0 | 0 | 140 |
| L1319 | 5 | 1 | Opponent | no | - | 2 | 5 | 3 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 5 | 4 | 1 | 0 | 1 | 0 | 0 | 540 |
| L1335 | 3 | 1 | Opponent | no | 0 | 4 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Mine | yes | 4 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | no | 0 | - | 3 | 1 | 1 | 0 | 0 | 170 |
| **Average** | | | Mine | 67% | 4.5 | 3.0 | 1.7 | 1.3 | 0.3 | 0.0 | 0.0 | 226.7 |
| **Average** | | | Opponent | 0% | 0.0 | 3.0 | 4.0 | 1.7 | 0.3 | 0.0 | 0.0 | 56.7 |

### KPIs: ccut-c940641-p8

Rules off - Mine only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 7% (1 of 15) | 0% (0 of 13) | 4% (1 of 28) |
| Winner chose to follow up after the loser gave ground |  | 0% (0 of 1); on the table 0% | 100% (4 of 4); on the table 100% | 80% (4 of 5); on the table 80% |
| Winner chose to pursue after the loser fell back in good order |  | 67% (2 of 3); on the table 67% | 100% (2 of 2); on the table 100% | 80% (4 of 5); on the table 80% |
| Winner chose to pursue after the loser fled |  | 25% (1 of 4); on the table 25% | 50% (1 of 2); on the table 50% | 33% (2 of 6); on the table 33% |
| Winner chose to follow up or pursue (all three) |  | 38% (3 of 8); on the table 38% | 88% (7 of 8); on the table 88% | 62% (10 of 16); on the table 62% |
| Magic missiles tried each own turn | 50%+ | 28% (5 of 18) | 33% (8 of 24) | 31% (13 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 33% (5 of 15) | 44% (8 of 18) | 39% (13 of 33) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 30% (3 of 10) | 30% (3 of 10) |
| Points that never fought | lower | 54% (3233 of 6000) | 36% (2186 of 6000) | 45% (5419 of 12000) |
|   infantry points that never fought | lower | 70% (923 of 1315) | 67% (620 of 921) | 69% (1543 of 2236) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 48% (12 of 25) | 78% (25 of 32) | 65% (37 of 57) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 3.3 uses a game | 50% (1 of 2); 1.0 uses a game | 75% (3 of 4); 2.2 uses a game |
| Bound items with another spell used |  | 30% (3 of 10); 4.0 uses a game | 0.0 uses a game | 30% (3 of 10); 2.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 43% (2474 of 5720) | 80% (4692 of 5830) | 62% (7166 of 11550) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.0 (46%) | 2.0 (38%) | 4.0 (41%) |
| MARCHED: its unit marched | 1.0 (23%) | 0.7 (12%) | 1.7 (17%) |
| CHARGED: its unit charged | 0.3 (8%) | 0.7 (12%) | 1.0 (10%) |
| IN COMBAT: engaged in combat | 0.3 (8%) | 0.7 (12%) | 1.0 (10%) |
| FLEEING: fleeing | 0.0 (0%) | 0.7 (12%) | 0.7 (7%) |
| GONE: slain | 0.7 (15%) | 0.7 (12%) | 1.3 (14%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.0 | 0.0 | 3.0 | 4.3 | 0.3 | 2.3 |
| not cast | 3.0 | 4.0 | 3.0 | 9.7 | 1.7 | 21.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.7 (92%) | 0.3 (11%) | 4.0 (41%) | 0.7 (40%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (17%) | 0.3 (20%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (10%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (8%) | 0.0 (0%) | 1.0 (10%) | 0.3 (20%) | 0.0 (0%) |
| FLEEING: fleeing | 0.3 (11%) | 0.0 (0%) | 0.3 (11%) | 0.7 (7%) | 0.0 (0%) | 0.7 (3%) |
| GONE: slain | 0.7 (22%) | 0.0 (0%) | 0.7 (22%) | 1.3 (14%) | 0.0 (0%) | 1.7 (8%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (20%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (67%) | 0.0 (0%) | 1.7 (56%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 18.0 (83%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.7 a game | 0.3 a game | 1.5 a game |
| stood (cast and not dispelled) | 75% (6 of 8) | - | 75% (6 of 8) |
| the unit moved after it | 17% (1 of 6) | - | 17% (1 of 6) |
| it charged on its next turn | 0% (0 of 6) | - | 0% (0 of 6) |
| the enemy charged it first | 0% (0 of 6) | - | 0% (0 of 6) |
| it fought by the end of its next turn | 0% (0 of 6) | - | 0% (0 of 6) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 6) | - | 0% (0 of 6) |
| none of these (no charge, no fight, no charge escaped) | 100% (6 of 6) | - | 100% (6 of 6) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 67% (60 of 90) | 80% (24 of 30) | 70% (84 of 120) |
|   cavalry | 89% (8 of 9) | 94% (15 of 16) | 92% (23 of 25) |
|   character | 31% (10 of 32) | 50% (3 of 6) | 34% (13 of 38) |
|   infantry | 76% (22 of 29) | 75% (6 of 8) | 76% (28 of 37) |
|   war machine | 100% (20 of 20) | - | 100% (20 of 20) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.3 (33%) | 0.7 (33%) | 4.0 (33%) |
| CHARGED: it charged | 2.0 (20%) | 0.3 (17%) | 2.3 (19%) |
| IN COMBAT: it fought this turn or the last | 0.3 (3%) | 0.0 (0%) | 0.3 (3%) |
| NO TARGET IN RANGE | 2.3 (23%) | 0.7 (33%) | 3.0 (25%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 0.0 (0%) | 0.3 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (17%) | 0.3 (17%) | 2.0 (17%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 12.3 | 2.0 | 86% | 7.2 pts | 89 pts |
| character | 6.3 | 2.0 | 79% | 10.9 pts | 69 pts |
| infantry | 16.3 | 8.0 | 63% | 13.6 pts | 222 pts |
| war machine | 6.7 | 1.0 | 85% | 2.0 pts | 13 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 5.7 | 4.3 |
| Charges that made contact a game | 2.3 | 3.3 | 2.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.33 declared, 0.00 contact (3 units) | - | 0.33 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.36 declared, 0.32 contact (22 units) | 0.71 declared, 0.42 contact (24 units) | 0.54 declared, 0.37 contact (46 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 60% (9 of 15) | 100% (2 of 2) | - | 65% (11 of 17) |
| Character in a unit | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Character on its own | 86% (6 of 7) | 60% (3 of 5) | 43% (3 of 7) | 63% (12 of 19) |
| Infantry | 75% (9 of 12) | 50% (1 of 2) | - | 71% (10 of 14) |
| Monster | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Monstrous | 0% (0 of 2) | 100% (2 of 2) | - | 50% (2 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 3 | 38% (3 of 8); on the table 38% | 28% (5 of 18) | 54% | 48% (12 of 25) | 100% (2 of 2); 3.3 uses a game | 30% (3 of 10); 4.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (1 of 1); on the table 100% | 50% (6 of 12) | 18% | 88% (7 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (1 of 1); on the table 100% | 17% (1 of 6) | 13% | 83% (10 of 12) | 100% (1 of 1); 3.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 83% (5 of 6); on the table 83% | 17% (1 of 6) | 78% | 67% (8 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p8, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 67% (6) | 40% (2) | 57% (8) |
| ...free all their last turn and able to turn (per game) | 1.67 | 0.67 | 2.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.67 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: ccut-c940641-p8

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 4.0 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 50% (4 of 8) | 36% (4 of 11) |
| Strategy | Shoot objectives carried out (shot that target) | 67% (20 of 30) | 46% (6 of 13) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | - | 0% (0 of 1) |
| Strategy | Lone characters that fought | 50% (4 of 8) | 91% (10 of 11) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.3 | 1.7 |
| Movement | Points that never moved of their own | 226.7 | 56.7 |
| Movement | Fights charged into per game | 2.3 | 3.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 4 | 1 of 6, net +162 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 4, net +201 | 0 of 6 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 4, net +339 | 1 of 6, net +70 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 4, net +120 | 1 of 6, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 14.3 | 8.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 33% (14 of 43) | 71% (17 of 24) |
| Shooting | Points destroyed by shooting units | 41.7 | 133.3 |
| Shooting | War machine shots | 6.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 55% (11 of 20) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.3 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 25% (1 of 4) | 33% (1 of 3) |
| Magic | Wounds caused by magic missiles | 3.3 | 0.7 |
| Magic | Wounds caused by other spells | 2.7 | - |
| Magic | Points destroyed by magic (all spells) | 207.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.3 / 0.0 / 1.0 / 0.0 | 2.0 / 0.0 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 190.7 | 165.0 |
| Combat | Points run down | 38.7 | 0.0 |
| Combat | Net points per charged fight, damage counted | +188 | +10 |
| Combat | Net per 100 charger points, damage counted | +57.0 | +5.8 |
| Combat | First round won (charged fights) | 86% | 60% |
| Combat | Net points per charged fight | +165 | +22 |
| Combat | Net points per supported fight / lone fight | - / +165 | - / +22 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 7 | 4 of 10 |
| Game | Points lost | 402.7 | 926.0 |
| Game | VP from objectives | 686.7 | 440.0 |
| Game | Lone holders (player turns) | 4.5 | 0.0 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +846 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1329
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ccut-c940641-p8

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.7 | +21.5 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 32.0 | +540.5 | 0.0 | 442.7 | 22.0 | -37.7 | 0.0 | 307.0 |
| ASSAILMENT BY POINTS | 0.7 | +12.9 | 0.0 | 0.0 | 0.7 | +2.2 | 0.0 | 0.0 |
| BEST PRIZE | 0.3 | -32.4 | 0.0 | 0.0 | - | - | - | - |
| BLOWS WHERE AIMED | 0.7 | -109.4 | 162.3 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 2.3 | +0.5 | 0.0 | 201.3 | - | - | - | - |
| CANNON PLAN MISSED | 1.0 | +0.0 | 120.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 6.7 | +151.1 | 429.3 | 46.7 | - | - | - | - |
| CARRIES OUT SET-UP | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | - | - | - | - | 0.3 | +1.7 | 0.0 | 38.7 |
| CASTING BLOCK | - | - | - | - | 1.0 | +9.1 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 2.0 | +0.0 | 0.0 | 266.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 0.7 | +2.7 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 1.0 | +8.7 | 0.0 | 50.3 | 0.7 | +36.6 | 0.0 | 41.7 |
| CHAMPION KNOWS CHALLENGE | 0.3 | -2.0 | 38.7 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 14.7 | -811.4 | 0.0 | 766.3 | 17.3 | -857.1 | 0.0 | 702.3 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 381.7 | 0.0 | 2.3 | +0.0 | 228.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 4.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 155.3 |
| CONVEYANCE SEARCH | 2.0 | +332.3 | 266.7 | 266.7 | - | - | - | - |
| COVER ONCE | 7.0 | -390.5 | 0.0 | 100.7 | 4.0 | -267.6 | 0.0 | 143.7 |
| DENIED BY THE FIGHT | 0.3 | -4.9 | 114.3 | 0.0 | 0.3 | -1.8 | 54.0 | 0.0 |
| DEPLOY BY FIGURES | 7.3 | -21.6 | 0.0 | 0.0 | 7.7 | +43.4 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.7 | -49.4 | 41.7 | 0.0 | - | - | - | - |
| EDGE GIVE GROUND | 0.3 | +26.2 | 41.7 | 0.0 | 0.7 | +33.8 | 50.3 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 3.7 | +324.3 | 320.7 | 125.0 |
| EXACT ROUND | 1.3 | -12.3 | 200.3 | 0.0 | 4.0 | +56.7 | 228.3 | 38.7 |
| FALL BACK GOOD ORDER | 2.0 | +4.8 | 356.3 | 0.0 | 2.3 | +3.9 | 178.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 17.3 | +220.2 | 0.0 | 485.7 |
| FEATURE BUFFS | 0.7 | +8.3 | 0.0 | 0.0 | 1.0 | +4.2 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.3 | +34.7 | 201.0 | 0.0 | 1.3 | +1.8 | 151.0 | 0.0 |
| FIRE IN ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 96.3 | +7036.8 | 1672.0 | 1018.0 | 69.0 | +5200.3 | 2095.0 | 1245.7 |
| FLANK NOT WEIGHED | 8.0 | +0.0 | 0.0 | 234.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | - | - | - | - | 1.3 | +198.7 | 0.0 | 0.0 |
| FOUR ROUNDS | 3.0 | +553.1 | 462.0 | 0.0 | 4.0 | +178.9 | 228.3 | 38.7 |
| FREED FROM HIS FIGHT | 6.0 | +0.0 | 0.0 | 317.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 0.7 | -1.0 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.7 | -13.3 | 38.7 | 0.0 | 0.3 | -1.3 | 0.0 | 0.0 |
| GOAL WALK | 6.3 | +419.2 | 0.0 | 0.0 | 8.3 | +413.9 | 0.0 | 67.0 |
| GUN FIGURES | 1.0 | +11.3 | 0.0 | 0.0 | - | - | - | - |
| GUN MASK | 1.0 | +2.2 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 3.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 3.7 | +0.0 | 0.0 | 317.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 8.0 | +0.0 | 0.0 | 551.0 | 9.3 | +0.0 | 0.0 | 364.0 |
| HIS CHARGE LIST | 6.3 | +0.0 | 0.0 | 367.3 | 7.0 | +0.0 | 0.0 | 134.7 |
| HIS LEGAL MOVES | 5.0 | +0.0 | 0.0 | 50.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 1.0 | -11.8 | 0.0 | 50.3 | 5.0 | -32.0 | 0.0 | 250.7 |
| HIS MOVE AS HE DECIDES | 36.3 | +9.0 | 894.7 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 7.3 | +0.0 | 0.0 | 373.3 |
| HIS ONE MOVE | 21.0 | +159.2 | 0.0 | 0.0 | - | - | - | - |
| HIS ONE QUARTER | 3.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 166.7 |
| HIS OWN BEST MOVE | 0.7 | +0.0 | 0.0 | 50.3 | 3.3 | +0.0 | 0.0 | 38.7 |
| HIS RANDOM MOVE | 17.7 | +0.0 | 0.0 | 182.7 | - | - | - | - |
| HIS RANDOM MOVER COMES | 1.0 | +0.0 | 0.0 | 82.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 32.7 | +1104.7 | 0.0 | 516.3 | 37.0 | +909.1 | 0.0 | 842.3 |
| HIS SHOTS BY HIS RUN | 28.0 | +574.4 | 0.0 | 842.7 | 44.3 | +996.4 | 0.0 | 1053.7 |
| HIS TURN DENIED | 1.3 | +121.4 | 191.0 | 0.0 | 1.0 | +34.6 | 77.3 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 14.3 | +0.0 | 0.0 | 82.0 | 8.0 | +0.0 | 0.0 | 134.0 |
| HOLDER ASSIGNMENT | 8.7 | +686.9 | 0.0 | 41.0 | 5.3 | +458.7 | 0.0 | 67.0 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.7 | -117.6 | 347.7 | 0.0 | 2.0 | -42.2 | 127.7 | 0.0 |
| IDLE COST | - | - | - | - | 11.7 | -154.0 | 0.0 | 288.7 |
| JOINT CHARGE NOW | 0.7 | +154.3 | 228.7 | 0.0 | 0.7 | +213.4 | 0.0 | 0.0 |
| JOINT KNOWS CHALLENGE | 0.3 | -7.0 | 114.3 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +97.5 | 0.0 | 0.0 | 0.3 | +7.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.7 | +0.0 | 98.3 | 195.7 | 2.3 | +0.0 | 151.0 | 76.0 |
| LONE CHARACTER SAFE SPOT | - | - | - | - | 1.0 | +6.4 | 201.0 | 0.0 |
| LOST AFTER ESCAPE | 1.0 | +1.6 | 228.7 | 0.0 | 2.0 | -0.2 | 154.7 | 38.7 |
| MAKE SURE TOGETHER | 1.0 | +15.3 | 0.0 | 133.3 | - | - | - | - |
| MANOEUVRE | 1.3 | -0.2 | 0.0 | 0.0 | 0.3 | +3.2 | 0.0 | 48.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +0.0 | 0.0 | 48.0 |
| MARCH CHECK | - | - | - | - | 0.7 | +23.4 | 0.0 | 48.0 |
| MARCH OVER CASTS | 0.3 | +73.1 | 0.0 | 133.3 | 1.0 | +140.9 | 0.0 | 113.0 |
| MAX FOR POSITIONING | 1.7 | +4.8 | 0.0 | 133.3 | 1.3 | +85.9 | 0.0 | 0.0 |
| MEETS IN TIME | 3.3 | +197.2 | 0.0 | 0.0 | 4.3 | +88.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 5.0 | +79.8 | 0.0 | 187.3 | 4.3 | +209.2 | 0.0 | 77.3 |
| MISSILES NEXT TURN | 7.0 | +46.6 | 0.0 | 320.7 | 4.3 | +116.2 | 0.0 | 125.3 |
| MOVE ORDER | 1.7 | +0.0 | 0.0 | 91.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 2.0 | +0.0 | 0.0 | 266.7 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 4.0 | +305.8 | 0.0 | 0.0 | 5.0 | +343.2 | 0.0 | 77.3 |
| MOVES UNITS SPELL | - | - | - | - | 0.3 | +1.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.3 | +210.0 | 0.0 | 91.3 | 6.3 | +242.9 | 0.0 | 105.0 |
| NEXT CHARGE BY LIST | 0.7 | +36.4 | 0.0 | 0.0 | 4.0 | +270.8 | 0.0 | 77.3 |
| NO DOUBLE ROUNDS | 2.7 | -143.9 | 462.0 | 0.0 | 3.7 | -115.5 | 228.3 | 38.7 |
| NO LATE CUT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 5.7 | -159.5 | 38.7 | 50.3 | 4.0 | -224.7 | 0.0 | 155.7 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.7 | -140.2 | 0.0 | 133.3 | 5.7 | -121.5 | 0.0 | 144.3 |
| ONE JOINT FIGURE | - | - | - | - | 0.3 | +8.5 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 4.7 | +24.6 | 0.0 | 41.0 | 1.7 | +30.6 | 0.0 | 67.0 |
| OPENS A LANE | 1.0 | +5.2 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.3 | +14.6 | 23.3 | 0.0 |
| OVERRUNS AWAY | 0.7 | +15.4 | 80.3 | 0.0 | 1.0 | +6.8 | 127.7 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +26.2 | 0.0 | 65.0 |
| PLAN RESULT | 42.3 | +689.4 | 660.3 | 681.3 | 36.7 | +1072.4 | 1155.7 | 1167.3 |
| PROMISE BY ITS OWN SUM | 11.0 | -377.3 | 0.0 | 0.0 | 7.0 | -164.0 | 0.0 | 38.7 |
| PROMISE KNOWS THE FIGHT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.7 | -5.0 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 27.7 | +3523.8 | 915.7 | 0.0 | 18.0 | +2052.7 | 0.0 | 205.3 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.3 | +6.0 | 0.0 | 113.3 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 1.3 | +24.7 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 2.0 | +237.9 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 2.0 | +143.1 | 0.0 | 0.0 |
| REDIRECT WEIGHED | 0.3 | +55.6 | 0.0 | 0.0 | - | - | - | - |
| REFORMS TO MEET IT | 0.3 | -12.6 | 0.0 | 0.0 | 1.7 | -25.4 | 0.0 | 38.7 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| RISK BY ARC | 3.0 | +26.8 | 462.0 | 0.0 | 3.7 | +8.6 | 228.3 | 38.7 |
| ROUNDS AFTER TERROR | 1.3 | -67.5 | 229.3 | 0.0 | 0.3 | -1.4 | 23.3 | 0.0 |
| RUN DOWN | 2.7 | -146.5 | 462.0 | 0.0 | 3.3 | -20.5 | 228.3 | 38.7 |
| SEARCH SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +57.9 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +13.3 | 38.7 | 0.0 | 0.3 | +19.5 | 0.0 | 38.7 |
| SELF MOVE SPELL | - | - | - | - | 1.7 | +3.4 | 0.0 | 0.0 |
| SET CREDITED ONCE | 3.3 | -68.5 | 0.0 | 0.0 | - | - | - | - |
| SET UP BY THE SET | 3.3 | +366.8 | 0.0 | 0.0 | 1.0 | +16.8 | 266.7 | 0.0 |
| SET UP TOGETHER | 1.0 | +15.3 | 0.0 | 133.3 | 0.3 | +0.8 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.3 | +19.4 | 133.3 | 133.3 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 9.3 | +0.0 | 0.0 | 46.7 | 5.7 | +0.0 | 0.0 | 38.0 |
| SHOOTS FROM THE BEST SPOT | 3.3 | +109.0 | 83.3 | 0.0 | 1.0 | +5.9 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -0.3 | 38.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 18.0 | -283.5 | 0.0 | 725.3 | 27.3 | -249.5 | 0.0 | 779.7 |
| SHOTS AFTER THE MOVES | 4.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 20.0 | +532.9 | 0.0 | 275.0 | 7.7 | +501.3 | 0.0 | 74.7 |
| SPELL SETS UP CHARGE | 0.3 | +19.4 | 133.3 | 133.3 | - | - | - | - |
| SPELL WORTH | 3.0 | +73.4 | 266.7 | 266.7 | 2.0 | +9.8 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | -4.1 | 114.3 | 0.0 | 1.7 | -20.5 | 100.7 | 38.7 |
| SPOT AS THE GAME MOVES | 9.7 | +0.0 | 0.0 | 266.7 | 8.7 | +0.0 | 0.0 | 339.0 |
| STAND AND SHOOT | 0.3 | -5.2 | 38.0 | 0.0 | 1.0 | -1.3 | 0.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 2.3 | +0.0 | 0.0 | 38.7 |
| STANDS STILL | 45.0 | +0.0 | 1210.0 | 201.3 | 22.3 | +0.0 | 1866.7 | 467.0 |
| STAY WORTH | 28.0 | +98.3 | 648.0 | 431.7 | 14.3 | +290.8 | 1733.3 | 112.7 |
| STRIKE BY THE ODDS | 0.3 | +10.3 | 0.0 | 0.0 | - | - | - | - |
| STUBBORN BY POINTS | - | - | - | - | 0.3 | +2.4 | 50.3 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 5.3 | +410.4 | 0.0 | 50.3 | 3.7 | +1049.1 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 114.3 | 0.0 | 0.7 | +0.0 | 73.7 | 0.0 |
| SUPPORT WORKED OUT | 5.3 | +410.4 | 0.0 | 50.3 | 3.7 | +1049.1 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | +1.4 | 0.0 | 50.3 | 0.7 | +21.3 | 0.0 | 67.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -14.4 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 5.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 36.7 |
| THE ROW READS HIS LAST RUN | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 84.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 46.0 | +0.0 | 0.0 | 509.0 | 31.0 | +0.0 | 0.0 | 559.7 |
| TIED UP BY THE SUM | 0.7 | +58.6 | 38.0 | 0.0 | 0.7 | +44.1 | 23.3 | 0.0 |
| TIME ON OUR SIDE | 43.3 | +538.7 | 0.0 | 462.3 | - | - | - | - |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 38.7 |
| WHO FIGHTS | - | - | - | - | 0.7 | -3.3 | 104.3 | 0.0 |
| WHO HITS BACK | 0.3 | +111.5 | 0.0 | 0.0 | 0.3 | +26.1 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.7 | -247.7 | 0.0 | 615.3 | 1.0 | -390.4 | 0.0 | 67.0 |
| WHOLE FIGHT GAIN | 0.3 | +1.4 | 114.3 | 0.0 | 0.3 | +4.2 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 3.0 | +88.1 | 0.0 | 268.0 |

### Rule changes: ccut-c940641-p8

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 162 | 162 | 113 | 37.67 | +2197 | +19.4 |
| HIS MOVE AS HE DECIDES | 109 | 109 | 82 | 27.33 | +0 | +0.0 |
| HIS SHOT LIST | 209 | 196 | 49 | 16.33 | +1114 | +22.7 |
| HIS SHOTS BY HIS RUN | 217 | 204 | 43 | 14.33 | +471 | +11.0 |
| HOLDER ASSIGNMENT | 42 | 42 | 35 | 11.67 | +1950 | +55.7 |
| THE TABLE AGAIN | 36 | 36 | 31 | 10.33 | +0 | +0.0 |
| OFF BEST | 29 | 29 | 29 | 9.67 | -1152 | -39.7 |
| FIVE ACTION | 496 | 474 | 28 | 9.33 | +1946 | +69.5 |
| DEPLOY BY FIGURES | 45 | 45 | 26 | 8.67 | +294 | +11.3 |
| PROMISE BY ITS OWN SUM | 54 | 54 | 24 | 8.00 | -1624 | -67.7 |
| QUARTER ODDS | 137 | 129 | 23 | 7.67 | +1698 | +73.8 |
| HIS MOVE WHY | 22 | 22 | 20 | 6.67 | +0 | +0.0 |
| SHOT RISK POINTS | 136 | 129 | 19 | 6.33 | +579 | +30.5 |
| HIS ONE MOVE | 63 | 61 | 18 | 6.00 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| HARD STAY DROPPED | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 27 | 21 | 14 | 4.67 | +462 | +33.0 |
| ADVANCE LANE KEPT | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| CHARGE LOSSES | 96 | 90 | 11 | 3.67 | +1649 | +149.9 |
| GOAL WALK | 44 | 44 | 11 | 3.67 | +902 | +82.0 |
| FOUR ROUNDS | 21 | 20 | 10 | 3.33 | +783 | +78.3 |
| THE RISK READS HIS RUN | 18 | 18 | 10 | 3.33 | +0 | +0.0 |
| TIME ON OUR SIDE | 130 | 111 | 10 | 3.33 | +53 | +5.3 |
| COVER ONCE | 33 | 23 | 8 | 2.67 | +236 | +29.5 |
| MEETS IN TIME | 23 | 23 | 8 | 2.67 | +188 | +23.5 |
| MOVE ORDER | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| BOUND ASSAILMENT | 7 | 7 | 7 | 2.33 | +1 | +0.2 |
| STAY WORTH | 127 | 117 | 7 | 2.33 | +155 | +22.2 |
| SUPPORT ADDS | 27 | 25 | 7 | 2.33 | +633 | +90.5 |
| SUPPORT WORKED OUT | 27 | 25 | 7 | 2.33 | +633 | +90.5 |
| REDIRECT FOR A FRIEND IN REACH | 6 | 6 | 6 | 2.00 | +229 | +38.2 |
| SHOOTS FROM THE BEST SPOT | 13 | 13 | 6 | 2.00 | +31 | +5.2 |
| CHALLENGE BY POINTS | 5 | 5 | 5 | 1.67 | +136 | +27.2 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +314 | +62.7 |
| NEXT CHARGE BY LIST | 14 | 8 | 5 | 1.67 | +362 | +72.4 |
| RISK BY ARC | 20 | 19 | 5 | 1.67 | +69 | +13.9 |
| SET UP BY THE SET | 13 | 12 | 5 | 1.67 | +885 | +177.1 |
| WHOLE FIGHT DANGER | 11 | 11 | 5 | 1.67 | +322 | +64.3 |
| ASSAILMENT BY POINTS | 4 | 4 | 4 | 1.33 | +45 | +11.3 |
| EXACT ROUND | 16 | 16 | 4 | 1.33 | +44 | +10.9 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +596 | +149.1 |
| JOINT CHARGE NOW | 4 | 4 | 4 | 1.33 | +1103 | +275.8 |
| EVASIVE BY THE ODDS | 11 | 11 | 3 | 1.00 | +274 | +91.3 |
| FIRE IN ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 10 | 10 | 3 | 1.00 | +18 | +6.0 |
| REDIRECT COUNTER | 6 | 5 | 3 | 1.00 | +197 | +65.6 |
| SEARCH SPOT | 5 | 5 | 3 | 1.00 | +178 | +59.3 |
| SWIFTSTRIDE BY POINTS | 3 | 3 | 3 | 1.00 | +68 | +22.7 |
| TIED UP BY THE SUM | 4 | 4 | 3 | 1.00 | +80 | +26.5 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +64 | +32.2 |
| CANNON PLANNED TARGET | 20 | 20 | 2 | 0.67 | +0 | +0.0 |
| EDGE GIVE GROUND | 3 | 3 | 2 | 0.67 | +45 | +22.5 |
| FALLS SHORT | 52 | 50 | 2 | 0.67 | +42 | +20.8 |
| FIGHT TO THE END | 8 | 7 | 2 | 0.67 | +0 | +0.0 |
| IDLE COST | 35 | 25 | 2 | 0.67 | +0 | +0.2 |
| NO DOUBLE ROUNDS | 19 | 18 | 2 | 0.67 | +97 | +48.4 |
| ONE OBJECTIVE FORMULA | 19 | 15 | 2 | 0.67 | +53 | +26.4 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -15 | -7.6 |
| REDIRECT BY WHAT IT STOPS | 4 | 4 | 2 | 0.67 | +229 | +114.7 |
| REFUSING RETIRES | 3 | 3 | 2 | 0.67 | -9 | -4.4 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +98 | +49.2 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +364 | +181.8 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -97 | -97.1 |
| CAST JOB | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CASTING BLOCK | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 13 | 13 | 1 | 0.33 | -30 | -29.6 |
| FALL BACK GOOD ORDER | 13 | 13 | 1 | 0.33 | +0 | +0.1 |
| HIS TURN DENIED | 7 | 6 | 1 | 0.33 | +284 | +283.5 |
| LOST AFTER ESCAPE | 9 | 9 | 1 | 0.33 | +0 | +0.1 |
| MANOEUVRE | 5 | 5 | 1 | 0.33 | +10 | +9.7 |
| MAX FOR POSITIONING | 9 | 7 | 1 | 0.33 | +0 | +0.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| ONE FIGHT FORMULA | 34 | 21 | 1 | 0.33 | +30 | +29.7 |
| OPENS A LANE | 3 | 2 | 1 | 0.33 | +3 | +2.8 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +29 | +29.2 |
| OVERRUNS AWAY | 5 | 4 | 1 | 0.33 | +0 | +0.0 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +79 | +78.6 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +173 | +172.9 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SHOTS AFTER THE MOVES | 18 | 18 | 1 | 0.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 83 | 56 | 1 | 0.33 | +143 | +142.6 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +31 | +31.0 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SUPPORT NARROWED | 3 | 3 | 1 | 0.33 | -326 | -325.7 |
| THE ROW IN ITS ORDER | 23 | 1 | 1 | 0.33 | +0 | +0.0 |
| BLOWS WHERE AIMED | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 3 | 3 | 0 | 0.00 | - | - |
| CARRIES OUT SET-UP | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 7 | trace | - | - | - | - |
| CHAFF IN THE MOVE | 2 | 2 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | not checked | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 32 | 31 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 6 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 5 | 5 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 33 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 20 | 18 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 2 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 3 | not checked | - | - | - | - |
| GUN MASK | 3 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 12 | 10 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 52 | 49 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 40 | 38 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 19 | 18 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 18 | 18 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 27 | 24 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 12 | 12 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 53 | 53 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 3 | 3 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 67 | 67 | 0 | 0.00 | - | - |
| HONEST WORTH | 14 | 13 | 0 | 0.00 | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 3 | 3 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 3 | not checked | - | - | - | - |
| MAKE SURE TOGETHER | 3 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH CHECK | 2 | 2 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 28 | 18 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 34 | 26 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 6 | not checked | - | - | - | - |
| NEARER NOT NEEDED | 35 | 33 | 0 | 0.00 | - | - |
| NO LATE CUT | 1 | 1 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 237 | trace | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 5 | 3 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 6 | 4 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 5 | 5 | 0 | 0.00 | - | - |
| RUN DOWN | 18 | 17 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 5 | not checked | - | - | - | - |
| SET CREDITED ONCE | 10 | 9 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 4 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 45 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 15 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 6 | 6 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 55 | 53 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 4 | 4 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 7 | 7 | 0 | 0.00 | - | - |
| STANDS STILL | 202 | 191 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 15 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 4 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 9 | not checked | - | - | - | - |
| THE TABLE BINDS | 231 | not checked | - | - | - | - |
| WAITS AGAIN | 5 | 4 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 2 | 2 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 9 | 9 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p8

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 5.33 | 2.67 | 67.7 |
| JOB FIRST | gate | 4.33 | 3.00 | 34.6 |
| ARMY TABLE | rule | 2.33 | 4.33 | 73.7 |
| RULE SWITCHED OFF | gate | 1.33 | - | 56.2 |
| NO REASON | gate | - | 0.67 | 78.1 |
| PROMISE SHOT AWAY | rule | 0.67 | - | 7.6 |
| REFUSING RETIRES | rule | - | 0.67 | 4.4 |
| BEST PRIZE | rule | 0.33 | - | 97.1 |
| CHARGE NOW FIRST | rule | - | 0.33 | 29.6 |
| DEPLOY BY FIGURES | rule | - | 0.33 | 6.7 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 9.4 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.33 | 10.3 |
| SUPPORT NARROWED | rule | - | 0.33 | 325.7 |

### Plans: ccut-c940641-p8

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.7 | 75% | 944 | 324 | 34% |
| Mine | move | 32.0 | 98% | 1910 | 0 | 0% |
| Mine | shoot | 7.7 | 65% | 235 | 366 | 156% |
| Opponent | charge | 3.7 | 45% | 501 | 231 | 46% |
| Opponent | join | 1.3 | 100% | 45 | 0 | 0% |
| Opponent | move | 26.7 | 91% | 2267 | 0 | 0% |
| Opponent | shoot | 4.7 | 57% | 451 | 841 | 187% |
| Opponent | support | 0.3 | 0% | 11 | 0 | 0% |

### Battle groups: ccut-c940641-p8

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 2.0 | 33% | 100% | 0% | - | 0% | 0% | 50% | 50% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p8

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 8 | 77 (8) | 77 | 0 | 13 | 12% | 2.3 | 91 (6) | 35 (2) | - | 90 (2) | 73 (6) |
| Mine | Clean-up | 3 | 46 (3) | 0 | 46 | 32 | 33% | 1.0 | 73 (2) | 0 (1) | - | 73 (2) | 0 (1) |
| Mine | Fast Hammer | 7 | 40 (7) | 11 | 29 | 43 | 43% | 2.8 | 7 (3) | 20 (3) | 196 (1) | 10 (2) | 52 (5) |
| Mine | Holder | 2 | 72 (2) | 0 | 72 | 0 | 50% | 4.0 | 72 (2) | - | - | 72 (2) | - |
| Mine | Shooter | 5 | 27 (5) | 27 | 0 | 19 | 0% | 1.4 | 34 (4) | 0 (1) | - | 34 (4) | 0 (1) |
| Mine | War machine | 4 | 0 (4) | 0 | 0 | 25 | 0% | 1.0 | 0 (2) | 0 (2) | - | 0 (2) | 0 (2) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 0 | 67% | 5.0 | 0 (3) | - | - | 0 (3) | - |
| Opponent | Character | 9 | 10 (9) | 10 | 0 | 63 | 0% | 2.7 | 6 (3) | 33 (4) | - | 12 (3) | 15 (4) |
| Opponent | Clean-up | 3 | 141 (3) | 141 | 0 | 0 | 0% | 2.0 | - | 141 (3) | - | 148 (1) | 137 (2) |
| Opponent | Fast Hammer | 3 | 38 (3) | 0 | 38 | 77 | 0% | 2.0 | 171 (1) | 0 (2) | - | 0 (1) | 75 (2) |
| Opponent | Hammer | 8 | 9 (8) | 9 | 0 | 41 | 38% | 4.0 | 0 (4) | 36 (2) | 0 (2) | 0 (5) | 29 (3) |
| Opponent | Holder | 3 | 0 (3) | 0 | 0 | 35 | 67% | 4.0 | - | 0 (1) | 0 (1) | - | 0 (2) |
| Opponent | Shooter | 3 | 110 (3) | 110 | 0 | 62 | 0% | 1.3 | - | 157 (2) | 0 (1) | - | 110 (3) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 34 | 0% | 2.0 | 0 (1) | 0 (1) | - | - | 0 (2) |

### Charged fights: ccut-c940641-p8

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 3 | 249 | 385 | 2.3 | 1.0 | 165 | 0 | +165 | 2 of 7 | 6 of 7 | - | +165 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 70 | 4.0 | 1.0 | 18 | 88 | -70 | 2 of 4 | 2 of 4 | - | -70 |
| Opponent | Warriors of Chaos | 1 | 0 | 151 | 2.0 | 1.0 | 76 | 58 | +18 | 1 of 2 | 1 of 2 | - | +18 |
| Opponent | Wood Elf Realms | 1 | 400 | 464 | 4.0 | 1.0 | 116 | 0 | +116 | 1 of 4 | 3 of 4 | - | +116 |
| **Opponent** | all armies | 3 | 133 | 228 | 3.3 | 1.0 | 68 | 47 | +22 | 4 of 10 | 6 of 10 | - | +22 |

### Effective charges: ccut-c940641-p8

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 7 | 0 | 0 | 1 (net +201) | 0 | 1 (net +339) | 2 (net +120) | 3 | 25% (1 of 4) |
| Opponent | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 0 | 1 (net +70) | 0 | 3 | 0% (0 of 1) |
| Opponent | Warriors of Chaos | 2 | 0 | 0 | 0 | 1 (net +151) | 0 | 0 | 1 | 0% (0 of 1) |
| Opponent | Wood Elf Realms | 4 | 1 (net +162) | 0 | 0 | 2 (net +151) | 0 | 1 (net +0) | 0 | 0% (0 of 4) |

### Charged fights, damage counted: ccut-c940641-p8

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 489 | 201 | +201 | 201 | 0 | +201 | +41.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 247 | 120 | +120 | 199 | 0 | +199 | +80.4 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 489 | 144 | +339 | 339 | 0 | +339 | +69.3 |
| Mine | No odds | 3 | 278 | 231 | +126 | 126 | 0 | +126 | +45.1 |
| Mine | All fights | 7 | 330 | 183 | +165 | 188 | 0 | +188 | +57.0 |
| Opponent | Long shot (under 50%) | 1 | 102 | 247 | +162 | 162 | 0 | +162 | +158.8 |
| Opponent | 76-89% | 3 | 107 | 155 | +151 | 167 | 0 | +167 | +156.5 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 102 | 151 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 350 | 70 | +70 | 70 | 0 | +70 | +20.0 |
| Opponent | No odds | 4 | 217 | 354 | -116 | 39 | 197 | -158 | -72.6 |
| Opponent | All fights | 10 | 174 | 235 | +22 | 89 | 79 | +10 | +5.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p8 | move | 20 | 5 (25%) | 3 (15%) | 7 (35%) | 8 (40%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Elixir of Power | Opponent | L1319 |
| Opal Amulet | Mine | L1431 |
| Ring of Doom | Opponent | L1431 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |

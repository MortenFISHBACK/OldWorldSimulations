# Doctrine scorecard: ccut-c940641-p5

### Scorecard: ccut-c940641-p5

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0717 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L0717 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L0733 | 1 | 1 | Mine | no | 6 | 6 | 0 | 1 | 0 | 0 | 0 | 295 |
| L0733 | 1 | 1 | Opponent | no | 2 | 3 | 3 | 3 | 1 | 0 | 0 | 405 |
| L0823 | 1 | 1 | Mine | no | 11 | - | 0 | 1 | 0 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 3 | 1 | 0 | 0 | 267 |
| **Average** | | | Mine | 0% | 8.5 | 6.0 | 0.0 | 1.0 | 0.0 | 0.0 | 0.0 | 405.0 |
| **Average** | | | Opponent | 0% | 1.0 | 2.5 | 3.5 | 3.0 | 1.0 | 0.0 | 0.0 | 336.0 |

### KPIs: ccut-c940641-p5

Rules off - Mine only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 80% (12 of 15) | 0% (0 of 10) | 48% (12 of 25) |
| Winner chose to follow up after the loser gave ground |  | 0% (0 of 2); on the table 0% | 100% (3 of 3); on the table 100% | 60% (3 of 5); on the table 60% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (1 of 1); on the table 100% | - | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 33% (1 of 3); on the table 33% | 100% (3 of 3); on the table 100% | 67% (4 of 6); on the table 67% |
| Magic missiles tried each own turn | 50%+ | 67% (8 of 12) | 25% (3 of 12) | 46% (11 of 24) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 73% (8 of 11) | 25% (3 of 12) | 48% (11 of 23) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 56% (2228 of 3999) | 69% (2756 of 4000) | 62% (4984 of 7999) |
|   infantry points that never fought | lower | 34% (190 of 561) | 100% (1045 of 1045) | 77% (1235 of 1606) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 55% (11 of 20) | 67% (10 of 15) | 60% (21 of 35) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (2 of 2); 2.3 uses a game | 100% (2 of 2); 1.2 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 0.7 uses a game | 0.0 uses a game | 100% (2 of 2); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 33% (1 of 3); 0.3 uses a game | 0% (0 of 1); 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 45% (1629 of 3589) | 56% (1921 of 3408) | 51% (3550 of 6997) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (50%) | 2.3 (78%) | 3.0 (69%) |
| MARCHED: its unit marched | 0.3 (25%) | 0.7 (22%) | 1.0 (23%) |
| IN COMBAT: engaged in combat | 0.3 (25%) | 0.0 (0%) | 0.3 (8%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 4.7 | 1.0 | 3.7 | 1.3 | 0.7 |
| not cast | 3.3 | 1.0 | 4.3 | 0.7 | 10.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (67%) | 3.0 (69%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.0 (23%) | 0.7 (100%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (33%) | 0.3 (8%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (3%) |
| GONE: slain | 1.0 (30%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (70%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 9.7 (91%) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 67% (41 of 61) | 70% (47 of 67) | 69% (88 of 128) |
|   cavalry | 75% (9 of 12) | 75% (15 of 20) | 75% (24 of 32) |
|   character | - | 44% (8 of 18) | 44% (8 of 18) |
|   chariot | 100% (2 of 2) | - | 100% (2 of 2) |
|   infantry | 50% (6 of 12) | 83% (24 of 29) | 73% (30 of 41) |
|   war machine | 69% (24 of 35) | - | 69% (24 of 35) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.3 (20%) | 1.7 (25%) | 3.0 (22%) |
| CHARGED: it charged | 0.0 (0%) | 2.3 (35%) | 2.3 (18%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (5%) | 0.3 (2%) |
| MOVED: a war machine that moved | 0.7 (10%) | 0.0 (0%) | 0.7 (5%) |
| NO TARGET IN RANGE | 0.7 (10%) | 1.0 (15%) | 1.7 (12%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.7 (10%) | 0.7 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.3 (35%) | 0.7 (10%) | 3.0 (22%) |
| SHELTERED: the target was sheltered | 1.3 (20%) | 0.0 (0%) | 1.3 (10%) |
| OTHER BAR | 0.3 (5%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 10.7 | 3.3 | 78% | 8.2 pts | 88 pts |
| character | 2.7 | 0.7 | 75% | 5.2 pts | 14 pts |
| chariot | 0.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 13.7 | 4.3 | 78% | 9.0 pts | 124 pts |
| war machine | 8.0 | 7.7 | 50% | 29.4 pts | 235 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.0 | 3.7 | 2.8 |
| Charges that made contact a game | 1.7 | 1.7 | 1.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | - | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.23 declared, 0.19 contact (26 units) | 0.38 declared, 0.17 contact (29 units) | 0.31 declared, 0.18 contact (55 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (3 of 6) | 0% (0 of 2) | - | 38% (3 of 8) |
| Character in a unit | 100% (4 of 4) | - | - | 100% (4 of 4) |
| Character on its own | 50% (1 of 2) | 100% (1 of 1) | 25% (1 of 4) | 43% (3 of 7) |
| Chariot | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Infantry | 0% (0 of 1) | 67% (2 of 3) | 0% (0 of 1) | 40% (2 of 5) |
| Monster | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Monstrous | 100% (1 of 1) | - | - | 100% (1 of 1) |
| War Machines | 86% (6 of 7) | - | - | 86% (6 of 7) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 2 | 33% (1 of 3); on the table 33% | 67% (4 of 6) | 56% | 55% (11 of 20) | 0.0 uses a game | 100% (1 of 1); 0.5 uses a game | 50% (1 of 2); 0.5 uses a game |
| Tomb Kings of Khemri | 1 | 100% (3 of 3); on the table 100% | 0% (0 of 6) | 69% | 20% (1 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | 50% (3 of 6) | 69% | 90% (9 of 10) | 100% (2 of 2); 7.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p5, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 40% (2) | 100% (2) | 57% (4) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.67 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.67 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: ccut-c940641-p5

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.3 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 83% (5 of 6) | 50% (4 of 8) |
| Strategy | Shoot objectives carried out (shot that target) | 27% (15 of 55) | 67% (6 of 9) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 2) | - |
| Strategy | Joined characters whose unit fought | 50% (1 of 2) | 0% (0 of 3) |
| Strategy | Lone characters that fought | 43% (3 of 7) | 50% (2 of 4) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.0 | 3.0 |
| Movement | Points that never moved of their own | 405.0 | 336.0 |
| Movement | Fights charged into per game | 1.0 | 2.5 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 2 | 1 of 4, net +210 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | 0 of 4 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 2 | 1 of 4, net +130 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 2, net +106 | 1 of 4, net +265 |
| Shooting | Shots by shooting units (incl. breath weapons) | 6.0 | 16.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 61% (11 of 18) | 45% (22 of 49) |
| Shooting | Points destroyed by shooting units | 166.0 | 67.3 |
| Shooting | War machine shots | 8.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 54% (13 of 24) | - |
| Shooting | Points destroyed by war machines | 84.3 | 0.0 |
| Magic | Magic missiles cast | 2.0 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 6) | 0% (0 of 2) |
| Magic | Wounds caused by magic missiles | 5.0 | 2.7 |
| Magic | Wounds caused by other spells | 2.7 | - |
| Magic | Points destroyed by magic (all spells) | 237.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.3 / 0.7 / 0.3 / 0.0 | 2.3 / 0.0 / 0.0 / 0.7 |
| Combat | Points destroyed in combat | 71.0 | 160.0 |
| Combat | Points run down | 0.0 | 45.0 |
| Combat | Net points per charged fight, damage counted | +106 | +92 |
| Combat | Net per 100 charger points, damage counted | +57.6 | +36.8 |
| Combat | First round won (charged fights) | 100% | 60% |
| Combat | Net points per charged fight | +106 | +121 |
| Combat | Net points per supported fight / lone fight | - / +106 | - / +121 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 2 | 4 of 5 |
| Game | Points lost | 493.5 | 788.5 |
| Game | VP from objectives | 935.0 | 1015.0 |
| Game | Lone holders (player turns) | 8.5 | 1.0 |

- Mine won / drew / lost: 1 / 0 / 1 of 2 ended games (of 3); mean margin (Mine - Opponent) +100 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 1282
- Games not ended: 1 (L0717-1); findings 1, warnings 0

### Opponent rules: ccut-c940641-p5

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +145.0 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH WITH FRIENDS | 0.3 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 19.3 | +180.2 | 0.0 | 134.7 | 33.3 | +365.7 | 0.0 | 465.7 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 5.0 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| BACKUP TARGETS | 0.3 | +2.8 | 0.0 | 67.3 | - | - | - | - |
| BEST PRIZE | - | - | - | - | 0.7 | -49.6 | 45.0 | 0.0 |
| CANNON PLAN MISSED | 2.0 | +0.0 | 6.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 12.7 | +446.4 | 636.7 | 260.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 1.7 | +67.5 | 0.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.3 | +13.8 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 0.7 | +3.0 | 0.0 | 0.0 | 1.0 | +36.9 | 0.0 | 0.0 |
| CHAFF PASSED | 1.7 | -3.5 | 0.0 | 0.0 | 1.0 | -1.4 | 0.0 | 0.0 |
| CHARACTER GUNS | - | - | - | - | 5.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 20.3 | -1213.7 | 0.0 | 446.0 | 18.0 | -1203.1 | 0.0 | 308.0 |
| CHARGE NOW FIRST | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 173.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 2.3 | +0.0 | 0.0 | 0.0 | 16.0 | +0.0 | 0.0 | 6.3 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 176.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| COVER ONCE | 15.3 | -731.1 | 0.0 | 0.0 | 7.0 | -379.0 | 0.0 | 65.0 |
| DEPLOY BY FIGURES | 8.7 | -71.5 | 0.0 | 0.0 | 8.7 | +28.7 | 0.0 | 65.0 |
| EXACT ROUND | 2.0 | +0.5 | 71.0 | 0.0 | 2.7 | +89.1 | 188.3 | 0.0 |
| FALL BACK GOOD ORDER | 2.0 | +18.5 | 71.0 | 0.0 | 2.0 | +0.0 | 100.0 | 0.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | - | - | - | - | 21.0 | +242.4 | 0.0 | 181.0 |
| FIGHT TO THE END | - | - | - | - | 1.0 | +21.2 | 88.3 | 0.0 |
| FIRE IN ORDER | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 111.3 | +6995.8 | 2065.7 | 966.0 | 89.0 | +5684.5 | 592.3 | 854.3 |
| FLANK NOT WEIGHED | 11.7 | +0.0 | 0.0 | 15.0 | 4.7 | +0.0 | 0.0 | 214.0 |
| FOLLOW UP WEIGHED | 1.0 | +225.6 | 0.0 | 0.0 | 1.0 | +398.2 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.0 | +61.8 | 71.0 | 0.0 | 2.7 | +294.6 | 188.3 | 0.0 |
| FREED FROM HIS FIGHT | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 1.7 | -68.0 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | - | - | - | - | 0.3 | -2.7 | 0.0 | 0.0 |
| GOAL WALK | 5.3 | +320.6 | 0.0 | 0.0 | 18.3 | +1190.7 | 0.0 | 12.7 |
| GUN FIGURES | 0.7 | +0.0 | 0.0 | 88.3 | - | - | - | - |
| GUN MASK | 2.7 | +37.3 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 2.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 15.7 | +0.0 | 0.0 | 311.3 | 12.0 | +0.0 | 0.0 | 273.3 |
| HIS CHARGE LIST | 2.3 | +0.0 | 0.0 | 0.0 | 8.7 | +0.0 | 0.0 | 324.0 |
| HIS LEGAL MOVES | 4.0 | +0.0 | 0.0 | 134.7 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.0 | -79.2 | 0.0 | 134.7 | 1.7 | -23.6 | 0.0 | 6.3 |
| HIS MOVE AS HE DECIDES | 45.3 | +11.3 | 430.3 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 15.3 | +0.0 | 0.0 | 407.0 |
| HIS ONE MOVE | 24.7 | -93.9 | 0.0 | 0.0 | - | - | - | - |
| HIS ONE QUARTER | 11.0 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 143.3 |
| HIS OWN BEST MOVE | 2.0 | +0.0 | 0.0 | 67.3 | 5.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 52.7 | +2087.0 | 0.0 | 311.3 | 64.7 | +3794.7 | 0.0 | 789.3 |
| HIS SHOTS BY HIS RUN | 52.0 | +1170.1 | 0.0 | 446.0 | 42.3 | +1726.3 | 0.0 | 389.3 |
| HIS TURN DENIED | - | - | - | - | 1.3 | +107.6 | 173.3 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 22.0 | +0.0 | 0.0 | 134.7 | 21.0 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 14.0 | +1227.0 | 0.0 | 67.3 | 14.3 | +1300.3 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.7 | -37.7 | 36.3 | 0.0 | 2.7 | -106.3 | 188.3 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 0.7 | +4.0 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 13.3 | -214.9 | 0.0 | 140.7 |
| KEPT FROM ITS LAST STOP | 6.7 | +0.0 | 0.0 | 134.7 | 3.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +17.2 | 0.0 | 0.0 | 1.3 | +85.6 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 5.7 | +0.0 | 114.0 | 88.3 | 14.0 | +0.0 | 214.0 | 524.0 |
| LONE CHARACTER SAFE SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 34.7 | 78.0 |
| LONE WIZARD KEPT IN | 0.3 | +19.8 | 0.0 | 0.0 | 0.3 | +37.5 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.0 | +0.1 | 71.0 | 0.0 | 0.7 | +0.5 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.7 | +4.2 | 0.0 | 0.0 | - | - | - | - |
| MANOEUVRE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +4.3 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +8.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.3 | +26.6 | 0.0 | 0.0 | 0.3 | +6.0 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +12.2 | 0.0 | 36.0 |
| MARCH OVER CASTS | 0.7 | -55.5 | 0.0 | 0.0 | 0.7 | +9.8 | 0.0 | 36.0 |
| MARCH WHEELS ONLY | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.3 | +99.9 | 0.0 | 0.0 | 1.7 | +72.5 | 0.0 | 41.0 |
| MEETS IN TIME | 4.3 | +404.6 | 0.0 | 0.0 | 4.0 | +319.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.7 | +183.6 | 0.0 | 0.0 | 2.7 | +53.7 | 0.0 | 252.7 |
| MISSILES NEXT TURN | 3.0 | +90.4 | 0.0 | 0.0 | 2.7 | +36.3 | 0.0 | 210.7 |
| MOVE ORDER | 1.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 42.3 |
| MOVE TO CHARGE COMPUTED | 7.3 | +462.6 | 0.0 | 0.0 | 5.0 | +345.5 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 7.3 | +324.2 | 0.0 | 0.0 | 10.3 | +526.2 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 3.3 | +227.2 | 0.0 | 0.0 | 3.0 | +200.7 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.7 | -3.6 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.0 | -42.5 | 71.0 | 0.0 | 2.7 | -120.8 | 188.3 | 0.0 |
| NO LATE CUT | 2.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 5.7 | +0.0 | 0.0 | 0.0 |
| NO RALLY LEFT | - | - | - | - | 0.3 | +2.2 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 5.7 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 2.3 | -1.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 6.7 | -258.5 | 0.0 | 88.3 | 6.7 | -297.4 | 0.0 | 148.7 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 6.7 | -121.8 | 0.0 | 0.0 | 4.3 | -95.2 | 0.0 | 65.0 |
| ONE OBJECTIVE FORMULA | 5.0 | -142.9 | 0.0 | 0.0 | 5.0 | -15.9 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.7 | -66.5 | 0.0 | 0.0 |
| ONE ROUTE | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +36.1 | 15.0 | 0.0 |
| OVERRUNS AWAY | 0.7 | +8.5 | 0.0 | 0.0 | 1.0 | +11.0 | 15.0 | 0.0 |
| PATHS CROSS | 1.0 | +51.1 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 51.0 | +1498.8 | 402.0 | 601.3 | 40.0 | +258.3 | 146.7 | 495.3 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 65.0 |
| PROMISE BY ITS OWN SUM | 9.3 | -165.9 | 0.0 | 0.0 | 6.3 | -129.0 | 0.0 | 0.0 |
| PROMISE IN STEPS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 0.3 | -5.5 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -26.6 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 30.3 | +2466.8 | 887.0 | 269.3 | 20.0 | +2006.7 | 404.0 | 321.3 |
| REAL GROUND | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 1.3 | +5.3 | 0.0 | 6.3 |
| REDIRECT COUNTER | 0.7 | +57.3 | 0.0 | 0.0 | 2.3 | +34.5 | 0.0 | 6.3 |
| REDIRECT FOR A FRIEND IN REACH | 0.3 | +0.0 | 0.0 | 0.0 | 3.0 | +73.6 | 0.0 | 12.7 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | -43.1 | 45.0 | 0.0 |
| REFORMS TO MEET IT | 1.3 | -62.7 | 0.0 | 0.0 | 0.7 | -2.5 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +16.3 | 0.0 | 0.0 |
| RISK BY ARC | 1.3 | +5.1 | 0.0 | 0.0 | 2.0 | -287.7 | 145.0 | 0.0 |
| RISK ON THE WAY | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.7 | -32.3 | 85.0 | 0.0 |
| RUN DOWN | 1.7 | -9.5 | 34.7 | 0.0 | 1.7 | -8.1 | 85.0 | 0.0 |
| SCOUT SPOT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +1.8 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +64.0 | 0.0 | 0.0 | 0.7 | +21.0 | 0.0 | 0.0 |
| SET CREDITED ONCE | 1.0 | -10.4 | 0.0 | 0.0 | 0.3 | -33.2 | 0.0 | 0.0 |
| SET UP BY THE SET | 2.7 | +35.2 | 0.0 | 0.0 | 0.3 | +33.2 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.7 | +4.2 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.7 | +3.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 20.0 | +0.0 | 0.0 | 275.0 | 4.7 | +0.0 | 0.0 | 78.0 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +71.6 | 138.7 | 0.0 | 1.0 | +11.5 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT OR CHARGE | 0.7 | -1.7 | 0.0 | 0.0 | 0.3 | -8.3 | 0.0 | 0.0 |
| SHOT RISK POINTS | 30.7 | -257.7 | 0.0 | 269.3 | 39.7 | +874.4 | 0.0 | 781.7 |
| SHOTS AFTER THE MOVES | 4.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 24.0 | +1245.8 | 0.0 | 348.3 | 18.7 | +309.0 | 0.0 | 174.7 |
| SPELL WORTH | 0.7 | +10.3 | 56.7 | 56.7 | 4.0 | +60.3 | 114.0 | 156.0 |
| SPELLS IN THE FIGHT | 0.3 | +1.9 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | 0.7 | -9.3 | 0.0 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | - | - | - | - | 6.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 60.0 | +0.0 | 1994.7 | 520.0 | 19.7 | +0.0 | 404.0 | 209.7 |
| STAY WORTH | 43.0 | +414.3 | 780.0 | 409.0 | 15.0 | +96.5 | 0.0 | 174.7 |
| STRIKE BY THE ODDS | - | - | - | - | 1.0 | +273.0 | 28.3 | 0.0 |
| SUPPORT ADDS | 3.7 | +260.6 | 0.0 | 0.0 | 4.3 | +237.4 | 0.0 | 47.3 |
| SUPPORT WORKED OUT | 3.7 | +260.6 | 0.0 | 0.0 | 4.3 | +237.4 | 0.0 | 47.3 |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 1.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 99.7 |
| THE ROW READS HIS LAST RUN | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 54.0 | +0.0 | 0.0 | 498.0 | 43.0 | +0.0 | 0.0 | 508.3 |
| TIED UP BY THE SUM | 0.7 | +33.6 | 0.0 | 0.0 | 1.3 | +147.0 | 100.0 | 0.0 |
| TIME ON OUR SIDE | 44.3 | +482.4 | 0.0 | 103.3 | - | - | - | - |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| WEAPON BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | 0.7 | +0.5 | 36.3 | 0.0 | 0.7 | +247.7 | 0.0 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +48.6 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 3.0 | -648.5 | 0.0 | 176.7 | 3.3 | -255.5 | 0.0 | 72.7 |
| WOUNDS ON THE RANKS | 7.0 | +194.9 | 0.0 | 269.3 | 3.3 | +128.9 | 0.0 | 36.0 |

### Rule changes: ccut-c940641-p5

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 158 | 158 | 104 | 34.67 | +1916 | +18.4 |
| HIS MOVE AS HE DECIDES | 136 | 136 | 102 | 34.00 | +0 | +0.0 |
| HIS SHOT LIST | 352 | 341 | 92 | 30.67 | +2620 | +28.5 |
| HOLDER ASSIGNMENT | 85 | 85 | 74 | 24.67 | +4022 | +54.3 |
| LEGAL CHARGES ONLY | 59 | 59 | 59 | 19.67 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 283 | 271 | 52 | 17.33 | +829 | +15.9 |
| HIS MOVE WHY | 46 | 46 | 40 | 13.33 | +0 | +0.0 |
| OFF BEST | 40 | 40 | 40 | 13.33 | -1667 | -41.7 |
| SHOT RISK POINTS | 211 | 206 | 36 | 12.00 | +1131 | +31.4 |
| DEPLOY BY FIGURES | 52 | 52 | 33 | 11.00 | +478 | +14.5 |
| FIVE ACTION | 601 | 581 | 31 | 10.33 | +2229 | +71.9 |
| THE TABLE AGAIN | 35 | 35 | 29 | 9.67 | +0 | +0.0 |
| QUARTER ODDS | 151 | 142 | 24 | 8.00 | +1509 | +62.9 |
| HIS ONE MOVE | 74 | 73 | 18 | 6.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 37 | 33 | 17 | 5.67 | +603 | +35.5 |
| PROMISE BY ITS OWN SUM | 47 | 47 | 17 | 5.67 | -885 | -52.0 |
| HARD STAY DROPPED | 16 | 16 | 16 | 5.33 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| GOAL WALK | 71 | 71 | 15 | 5.00 | +489 | +32.6 |
| TIME ON OUR SIDE | 133 | 111 | 15 | 5.00 | +43 | +2.8 |
| MOVE ORDER | 14 | 14 | 14 | 4.67 | +0 | +0.0 |
| CHARGE LOSSES | 115 | 111 | 12 | 4.00 | +431 | +35.9 |
| STAY WORTH | 174 | 161 | 12 | 4.00 | +82 | +6.8 |
| NEXT CHARGE BY LIST | 19 | 17 | 10 | 3.33 | +379 | +37.9 |
| SUPPORT ADDS | 24 | 21 | 10 | 3.33 | +578 | +57.8 |
| SUPPORT WORKED OUT | 24 | 21 | 10 | 3.33 | +578 | +57.8 |
| MEETS IN TIME | 25 | 25 | 9 | 3.00 | +266 | +29.5 |
| CHAFF PASSED | 8 | 8 | 8 | 2.67 | -15 | -1.8 |
| COVER ONCE | 67 | 47 | 8 | 2.67 | +317 | +39.7 |
| REDIRECT FOR A FRIEND IN REACH | 10 | 10 | 8 | 2.67 | +110 | +13.8 |
| THE RISK READS HIS RUN | 18 | 18 | 7 | 2.33 | +0 | +0.0 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 6 | 6 | 6 | 2.00 | +1871 | +311.9 |
| FOUR ROUNDS | 14 | 14 | 6 | 2.00 | +451 | +75.2 |
| WHOLE FIGHT DANGER | 19 | 19 | 6 | 2.00 | +457 | +76.1 |
| WOUNDS ON THE RANKS | 31 | 30 | 6 | 2.00 | +179 | +29.8 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +308 | +61.7 |
| MAX FOR POSITIONING | 12 | 12 | 5 | 1.67 | +130 | +26.0 |
| SHOTS IN THE MOVE | 128 | 94 | 5 | 1.67 | +217 | +43.4 |
| EXACT ROUND | 14 | 14 | 4 | 1.33 | +64 | +15.9 |
| FIRE IN ORDER | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CAST JOB | 5 | 5 | 3 | 1.00 | +61 | +20.2 |
| COMBAT PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +153 | +51.1 |
| REDIRECT COUNTER | 9 | 8 | 3 | 1.00 | +159 | +53.0 |
| SEARCH SPOT | 4 | 4 | 3 | 1.00 | +255 | +85.0 |
| STRIKE BY THE ODDS | 3 | 3 | 3 | 1.00 | +158 | +52.7 |
| TIED UP BY THE SUM | 6 | 6 | 3 | 1.00 | +38 | +12.7 |
| BEST PRIZE | 2 | 2 | 2 | 0.67 | -149 | -74.4 |
| CHARGE NOW FIRST | 9 | 9 | 2 | 0.67 | -51 | -25.5 |
| FALLS SHORT | 63 | 57 | 2 | 0.67 | +8 | +3.8 |
| HIS TURN DENIED | 4 | 4 | 2 | 0.67 | +19 | +9.3 |
| HONEST WORTH | 13 | 13 | 2 | 0.67 | +8 | +4.1 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +172 | +86.0 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +26 | +13.1 |
| MISSILES IN THE MOVE | 16 | 10 | 2 | 0.67 | +162 | +81.0 |
| NO DOUBLE ROUNDS | 14 | 14 | 2 | 0.67 | +8 | +4.1 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -200 | -99.8 |
| RISK BY ARC | 10 | 10 | 2 | 0.67 | +35 | +17.6 |
| RUN DOWN | 10 | 10 | 2 | 0.67 | +8 | +4.1 |
| SET UP BY THE SET | 9 | 9 | 2 | 0.67 | +80 | +40.0 |
| SHOOTERS IN TWO RANKS | 2 | 2 | 2 | 0.67 | +9 | +4.5 |
| SHOOTS FROM THE BEST SPOT | 5 | 5 | 2 | 0.67 | +33 | +16.5 |
| THE ROW IN ITS ORDER | 11 | 2 | 2 | 0.67 | +0 | +0.0 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +435 | +434.9 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +12 | +12.1 |
| CANNON PLANNED TARGET | 38 | 38 | 1 | 0.33 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 5 | 5 | 1 | 0.33 | +4 | +3.5 |
| GUN MASK | 8 | 8 | 1 | 0.33 | +9 | +9.3 |
| HIS MOVE AND SHOT | 17 | 17 | 1 | 0.33 | +16 | +16.5 |
| HOLDS AMBUSHERS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| IDLE COST | 40 | 26 | 1 | 0.33 | +9 | +9.1 |
| MARCH CHECK | 2 | 2 | 1 | 0.33 | +80 | +79.8 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -37 | -36.6 |
| NEARER NOT NEEDED | 53 | 51 | 1 | 0.33 | +42 | +42.1 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.33 | +3 | +3.2 |
| ONE FIGHT FORMULA | 33 | 19 | 1 | 0.33 | +0 | +0.0 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +54 | +54.2 |
| PROMISE KNOWS THE FIGHT | 3 | 2 | 1 | 0.33 | -16 | -16.5 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +14 | +14.0 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +49 | +48.9 |
| ROUNDS AFTER TERROR | 5 | 5 | 1 | 0.33 | +7 | +7.3 |
| SHORT GUN FORWARD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 21 | 21 | 1 | 0.33 | +0 | +0.0 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 4 | 4 | 1 | 0.33 | +38 | +37.9 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +125 | +125.3 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 6 | 6 | 0 | 0.00 | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 17 | 17 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 55 | 54 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 12 | 12 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 49 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 9 | 8 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 5 | 5 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 2 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 83 | 81 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 33 | 32 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 22 | 21 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 54 | 49 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 22 | 21 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 35 | 35 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 35 | 35 | 0 | 0.00 | - | - |
| HOLD ODDS | 129 | 128 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 29 | 28 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 2 | not checked | - | - | - | - |
| LOST AFTER ESCAPE | 5 | 5 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MANOEUVRE | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 5 | 4 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 17 | 10 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO LATE CUT | 7 | 6 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 17 | 17 | 0 | 0.00 | - | - |
| NO SECOND RUN | 17 | 17 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 7 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 30 | 25 | 0 | 0.00 | - | - |
| ONE ROUTE | 5 | 4 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 5 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 273 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 5 | 4 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 6 | 6 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 8 | 7 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 74 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL WORTH | 14 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 29 | 28 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 19 | 19 | 0 | 0.00 | - | - |
| STANDS STILL | 239 | 230 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 13 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 19 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 4 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 11 | not checked | - | - | - | - |
| THE TABLE BINDS | 291 | not checked | - | - | - | - |
| WAITS AGAIN | 6 | 6 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p5

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.33 | 5.67 | 43.2 |
| ARMY TABLE | rule | 2.00 | 4.33 | 48.7 |
| PROMISE BY ITS OWN SUM | rule | 3.67 | 2.00 | 52.0 |
| CHAFF PASSED | rule | 1.67 | 1.00 | 1.8 |
| HOLDER ASSIGNMENT | rule | 0.67 | 1.00 | 18.6 |
| RULE SWITCHED OFF | gate | 1.00 | - | 41.3 |
| BEST PRIZE | rule | - | 0.67 | 74.4 |
| CHARGE NOW FIRST | rule | - | 0.67 | 25.5 |
| NO REASON | gate | - | 0.67 | 56.2 |
| ONE PROMISE A TARGET | rule | - | 0.67 | 99.8 |
| FIGHT ORDER BAND | gate | 0.33 | - | 2.8 |
| LONE CHARACTER SAFE SPOT | gate | - | 0.33 | 2.3 |
| MARCH OF THE TABLE | rule | - | 0.33 | 36.6 |
| PATHS CROSS | rule | 0.33 | - | 15.1 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | - | 16.5 |

### Plans: ccut-c940641-p5

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 33% | 103 | 39 | 38% |
| Mine | join | 2.7 | 88% | 22 | 0 | 0% |
| Mine | move | 31.7 | 100% | 1735 | 0 | 0% |
| Mine | shoot | 15.7 | 70% | 1185 | 1460 | 123% |
| Opponent | charge | 2.3 | 57% | 297 | 213 | 72% |
| Opponent | move | 34.7 | 94% | 2031 | 0 | 0% |
| Opponent | shoot | 2.0 | 67% | 94 | 46 | 49% |
| Opponent | support | 1.0 | 67% | 49 | 0 | 0% |

### Battle groups: ccut-c940641-p5

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.7 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 2.3 | 14% | 0% | 100% | 100% | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p5

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | 0 (1) | - |
| Mine | Character | 8 | 74 (8) | 74 | 0 | 4 | 62% | 3.0 | 138 (4) | - | 21 (3) | 89 (5) | 0 (2) |
| Mine | Clean-up | 1 | 109 (1) | 0 | 109 | 0 | 100% | - | - | 109 (1) | - | 109 (1) | - |
| Mine | Fast Hammer | 4 | 92 (4) | 37 | 55 | 25 | 50% | 3.5 | 94 (3) | - | 88 (1) | 92 (4) | - |
| Mine | Hammer | 2 | 14 (2) | 0 | 14 | 42 | 0% | 1.5 | - | 0 (1) | 24 (1) | 14 (2) | - |
| Mine | Shooter | 3 | 208 (3) | 95 | 113 | 0 | 0% | 2.7 | - | 338 (1) | 70 (2) | 338 (1) | 70 (2) |
| Mine | War machine | 7 | 28 (7) | 28 | 0 | 44 | 0% | 1.6 | 28 (7) | - | - | 0 (1) | 34 (6) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | - | - | - | - | - |
| Opponent | Chaff | 4 | 0 (4) | 0 | 0 | 11 | 50% | 1.0 | 0 (3) | 0 (1) | - | 0 (4) | - |
| Opponent | Character | 6 | 38 (6) | 38 | 0 | 42 | 17% | 1.2 | 0 (1) | 76 (2) | 26 (3) | 40 (5) | 0 (1) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 44 | 67% | 6.0 | 0 (2) | 0 (1) | - | 0 (1) | 0 (2) |
| Opponent | Fast Hammer | 4 | 14 (4) | 14 | 0 | 100 | 25% | 3.3 | 44 (1) | 0 (1) | 0 (2) | 17 (3) | 0 (1) |
| Opponent | Hammer | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Holder | 3 | 386 (3) | 105 | 281 | 0 | 0% | 2.7 | 450 (1) | 450 (1) | 281 (1) | 450 (2) | 281 (1) |
| Opponent | Shooter | 3 | 62 (3) | 0 | 62 | 33 | 0% | 1.0 | - | 93 (2) | 0 (1) | 68 (2) | 49 (1) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | - | 0 (1) | - | 0 (1) |

### Charged fights: ccut-c940641-p5

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 732 | 106 | 1.0 | 1.0 | 106 | 0 | +106 | 0 of 2 | 2 of 2 | - | +106 |
| Opponent | Tomb Kings of Khemri | 1 | 202 | 605 | 4.0 | 1.0 | 151 | 0 | +151 | 3 of 4 | 3 of 4 | - | +151 |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| **Opponent** | all armies | 2 | 101 | 302 | 2.5 | 1.0 | 121 | 0 | +121 | 4 of 5 | 3 of 5 | - | +121 |

### Effective charges: ccut-c940641-p5

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +106) | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 4 | 1 (net +210) | 0 | 0 | 1 (net +0) | 1 (net +130) | 1 (net +265) | 0 | 0% (0 of 4) |

### Charged fights, damage counted: ccut-c940641-p5

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 185 | 106 | +106 | 106 | 0 | +106 | +57.6 |
| Mine | All fights | 2 | 185 | 106 | +106 | 106 | 0 | +106 | +57.6 |
| Opponent | Long shot (under 50%) | 1 | 195 | 371 | +210 | 243 | 179 | +64 | +32.7 |
| Opponent | 76-89% | 1 | 195 | 371 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 431 | 265 | +265 | 265 | 0 | +265 | +61.5 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 431 | 130 | +130 | 130 | 0 | +130 | +30.2 |
| Opponent | No odds | 1 | 0 | 380 | +0 | 326 | 324 | +2 | - |
| Opponent | All fights | 5 | 250 | 303 | +121 | 193 | 101 | +92 | +36.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p5 | move | 20 | 4 (20%) | 3 (15%) | 3 (15%) | 13 (65%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Horn of the Wild Hunt | Opponent | L0733 |
| Ring of Doom | Opponent | L0733 |
| Twice-Blessed Armour | Mine | L0717, L0733 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |

# Doctrine scorecard: ccut-c940641-p3

### Scorecard: ccut-c940641-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0405 | 3 | 1 | Mine | no | 9 | 2 | 1 | 4 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 1148 |
| L0421 | 1 | 1 | Mine | no | 7 | 4 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 0 | 7 | 0 | 0 | 0 | 210 |
| L0508 | 4 | 1 | Mine | no | 7 | - | 0 | 2 | 0 | 0 | 0 | 380 |
| L0508 | 4 | 1 | Opponent | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 560 |
| **Average** | | | Mine | 0% | 7.7 | 3.0 | 0.7 | 3.0 | 0.0 | 0.0 | 0.0 | 126.7 |
| **Average** | | | Opponent | 0% | 0.0 | - | 0.0 | 4.0 | 0.0 | 0.0 | 0.0 | 639.3 |

### KPIs: ccut-c940641-p3

Rules off - Mine only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 11) | 83% (5 of 6) | 29% (5 of 17) |
| Winner chose to follow up after the loser gave ground |  | - | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | 50% (1 of 2); on the table 50% | 50% (1 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | - | 33% (1 of 3); on the table 33% | 33% (1 of 3); on the table 33% |
| Magic missiles tried each own turn | 50%+ | 42% (5 of 12) | 17% (1 of 6) | 33% (6 of 18) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 45% (5 of 11) | 25% (1 of 4) | 40% (6 of 15) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 44% (4 of 9) | 44% (4 of 9) |
| Points that never fought | lower | 78% (4663 of 5998) | 72% (4320 of 5999) | 75% (8983 of 11997) |
|   infantry points that never fought | lower | 95% (1359 of 1424) | 73% (1242 of 1703) | 83% (2601 of 3127) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% (14 of 23) | 69% (18 of 26) | 65% (32 of 49) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (1 of 1); 0.7 uses a game | 100% (1 of 1); 0.3 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 50% (1 of 2); 0.3 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 54% (2783 of 5120) | 62% (2908 of 4677) | 58% (5691 of 9797) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.0 (43%) | 0.7 (40%) | 1.7 (42%) |
| MARCHED: its unit marched | 1.0 (43%) | 0.3 (20%) | 1.3 (33%) |
| IN COMBAT: engaged in combat | 0.3 (14%) | 0.0 (0%) | 0.3 (8%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.7 (40%) | 0.7 (17%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.0 | 0.3 | 2.0 | 1.0 | 0.7 |
| not cast | 3.0 | 3.7 | 4.0 | 3.0 | 11.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (12%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.3 (64%) | 1.7 (42%) | 0.7 (22%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.3 (33%) | 0.3 (11%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (9%) | 0.3 (8%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.3 (11%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (11%) | 0.0 (0%) | 0.7 (17%) | 0.0 (0%) | 1.3 (12%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (67%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (78%) | 1.0 (27%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 8.7 (76%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.3 a game | 0.0 a game | 0.2 a game |
| stood (cast and not dispelled) | 0% (0 of 1) | - | 0% (0 of 1) |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 57% (43 of 75) | 76% (81 of 106) | 69% (124 of 181) |
|   cavalry | 67% (6 of 9) | 0% (0 of 7) | 38% (6 of 16) |
|   character | 50% (5 of 10) | 93% (26 of 28) | 82% (31 of 38) |
|   chariot | 44% (8 of 18) | 58% (7 of 12) | 50% (15 of 30) |
|   infantry | 17% (2 of 12) | 57% (12 of 21) | 42% (14 of 33) |
|   war machine | 85% (22 of 26) | 95% (36 of 38) | 91% (58 of 64) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (22%) | 1.3 (16%) | 3.7 (19%) |
| CHARGED: it charged | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.3 (4%) | 0.3 (2%) |
| NO TARGET IN RANGE | 5.7 (53%) | 4.3 (52%) | 10.0 (53%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (4%) | 0.3 (2%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.3 (22%) | 1.7 (20%) | 4.0 (21%) |
| OTHER BAR | 0.0 (0%) | 0.3 (4%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 2.0 | 0.3 | 83% | 0.8 pts | 2 pts |
| character | 11.0 | 4.7 | 70% | 13.1 pts | 145 pts |
| chariot | 5.0 | 6.0 | 40% | 23.5 pts | 118 pts |
| infantry | 7.7 | 2.0 | 78% | 5.6 pts | 43 pts |
| war machine | 19.3 | 16.7 | 62% | 25.7 pts | 496 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.0 | 0.0 | 1.0 |
| Charges that made contact a game | 1.7 | 0.0 | 0.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.27 declared, 0.23 contact (22 units) | 0.00 declared, 0.00 contact (22 units) | 0.14 declared, 0.11 contact (44 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 33% (1 of 3) | 100% (1 of 1) | - | 50% (2 of 4) |
| Character in a unit | 100% (10 of 10) | 0% (0 of 2) | - | 83% (10 of 12) |
| Character on its own | 100% (2 of 2) | 50% (1 of 2) | 67% (2 of 3) | 71% (5 of 7) |
| Chariot | 50% (1 of 2) | 60% (3 of 5) | - | 57% (4 of 7) |
| Infantry | 75% (6 of 8) | 40% (2 of 5) | 0% (0 of 1) | 57% (8 of 14) |
| Monster | - | 0% (0 of 1) | - | 0% (0 of 1) |
| War Machines | 75% (3 of 4) | - | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 2 | - | 42% (5 of 12) | 67% | 56% (9 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Dwarfen Mountain Holds | 2 | 0% (0 of 2); on the table 0% | - | 86% | 71% (10 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | - | - | 100% | 70% (7 of 10) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 100% (1 of 1); on the table 100% | 17% (1 of 6) | 44% | 67% (6 of 9) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p3, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | - | 100% (1) | 100% (1) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.33 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.33 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: ccut-c940641-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 2.0 |
| Strategy | Charge objectives carried out (made contact) | 50% (3 of 6) | - |
| Strategy | Shoot objectives carried out (shot that target) | 60% (18 of 30) | 77% (34 of 44) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 5) | 40% (4 of 10) |
| Strategy | Lone characters that fought | 50% (3 of 6) | 20% (1 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 3.0 | 4.0 |
| Movement | Points that never moved of their own | 126.7 | 639.3 |
| Movement | Fights charged into per game | 1.3 | 0.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 3 | - |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 3, net +0 | - |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 3 | - |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 of 3, net +540 | - |
| Shooting | Shots by shooting units (incl. breath weapons) | 7.0 | 16.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 43% (9 of 21) | 77% (37 of 48) |
| Shooting | Points destroyed by shooting units | 159.0 | 103.3 |
| Shooting | War machine shots | 7.3 | 12.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 23% (5 of 22) | 58% (21 of 36) |
| Shooting | Points destroyed by war machines | 176.0 | 68.0 |
| Magic | Magic missiles cast | 0.7 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 50% (1 of 2) | 0% (0 of 1) |
| Magic | Wounds caused by magic missiles | 1.3 | 0.3 |
| Magic | Wounds caused by other spells | 0.3 | 0.3 |
| Magic | Points destroyed by magic (all spells) | 88.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.3 / 1.0 | 0.7 / 0.0 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 31.7 | 59.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +85 | - |
| Combat | Net per 100 charger points, damage counted | +23.0 | - |
| Combat | First round won (charged fights) | 50% | - |
| Combat | Net points per charged fight | +154 | - |
| Combat | Net points per supported fight / lone fight | -112 / +243 | - / - |
| Combat | Charged fights on a top-3 enemy unit | 3 of 4 | - |
| Game | Points lost | 397.0 | 723.3 |
| Game | VP from objectives | 946.7 | 810.0 |
| Game | Lone holders (player turns) | 7.7 | 0.0 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +416 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 1120
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ccut-c940641-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.3 | +15.2 | 0.0 | 0.0 |
| ARMY TABLE | 15.3 | +193.5 | 0.0 | 440.0 | 11.0 | +113.4 | 0.0 | 204.7 |
| ARTILLERY RE-ROLL WEIGHED | 1.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 75.0 |
| ASSAILMENT BY POINTS | - | - | - | - | 0.3 | +1.6 | 0.0 | 180.0 |
| BEST PRIZE | 0.7 | -16.0 | 31.7 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 1.7 | +0.0 | 233.3 | 31.7 | 1.3 | +0.0 | 331.7 | 31.7 |
| CANNON PLANNED TARGET | 6.7 | +26.8 | 565.3 | 95.0 | 12.0 | +448.1 | 696.0 | 221.7 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 0.7 | +8.9 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 1.7 | +20.5 | 0.0 | 12.0 |
| CHARACTER GUNS | 3.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 19.7 | -826.1 | 0.0 | 310.0 | 7.0 | -639.8 | 0.0 | 661.3 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 276.7 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 9.0 | +0.0 | 0.0 | 146.7 | 3.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.3 | +1.3 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 2.7 | -125.8 | 0.0 | 135.0 | 3.7 | -369.6 | 0.0 | 180.0 |
| DENIED BY THE FIGHT | 1.3 | -12.5 | 180.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 8.7 | +40.3 | 0.0 | 0.0 | 9.0 | -53.5 | 0.0 | 135.0 |
| DUEL STOPS AT THE KILL | 0.7 | -45.0 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 1.0 | +10.8 | 211.7 | 0.0 | - | - | - | - |
| FALL BACK GOOD ORDER | 1.7 | +0.0 | 180.0 | 37.3 | - | - | - | - |
| FALLS SHORT | 6.7 | +110.8 | 0.0 | 140.7 | 9.0 | +135.3 | 0.0 | 180.0 |
| FEATURE BUFFS | - | - | - | - | 0.7 | +1.3 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| FIRE IN ORDER | 1.7 | +0.0 | 41.7 | 31.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| FIVE ACTION | 94.7 | +6612.6 | 1795.0 | 1208.0 | 87.7 | +4942.7 | 2012.0 | 1557.0 |
| FLANK NOT WEIGHED | 0.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 198.3 |
| FOUR ROUNDS | 2.0 | +281.5 | 211.7 | 37.3 | - | - | - | - |
| FRIEND SHOOTS FIRST | 1.3 | -66.2 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 10.3 | +1527.4 | 0.0 | 250.0 | 3.0 | +87.8 | 0.0 | 0.0 |
| GUN FIGURES | 2.0 | +8.4 | 70.0 | 103.3 | 2.0 | +0.9 | 0.0 | 0.0 |
| HARD STAY DROPPED | 2.7 | +0.0 | 0.0 | 103.3 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 2.3 | +0.0 | 0.0 | 103.3 | 4.0 | +0.0 | 0.0 | 478.3 |
| HIS CHARGE LIST | 1.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 21.7 |
| HIS LEGAL MOVES | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS MOVE AND SHOT | 1.3 | -18.7 | 0.0 | 0.0 | 1.7 | -34.3 | 0.0 | 158.3 |
| HIS MOVE AS HE DECIDES | 30.3 | +11.0 | 373.0 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 23.7 | +0.0 | 0.0 | 123.3 |
| HIS ONE MOVE | 25.3 | -92.2 | 0.0 | 37.3 | - | - | - | - |
| HIS ONE QUARTER | 2.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 48.3 |
| HIS OWN BEST MOVE | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVE | 9.3 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS RANDOM MOVER COMES | 4.3 | +0.0 | 0.0 | 43.3 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 47.3 | +2593.8 | 0.0 | 687.3 | 33.0 | +1151.0 | 0.0 | 720.3 |
| HIS SHOTS BY HIS RUN | 35.3 | +1116.4 | 0.0 | 667.3 | 23.7 | +517.6 | 0.0 | 897.0 |
| HIS TURN DENIED | 1.3 | +127.0 | 0.0 | 37.3 | - | - | - | - |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 15.0 | +0.0 | 0.0 | 74.7 | 14.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 9.7 | +998.8 | 0.0 | 74.7 | 9.7 | +1047.4 | 0.0 | 67.3 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.7 | -67.8 | 211.7 | 0.0 | - | - | - | - |
| IDLE COST | 8.3 | -124.6 | 0.0 | 21.7 | 9.0 | -117.3 | 0.0 | 272.0 |
| JOINT CHARGE NOW | 1.0 | -69.7 | 0.0 | 37.3 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 3.7 | +0.0 | 0.0 | 74.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +36.6 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LONE WIZARD KEPT IN | - | - | - | - | 0.7 | +63.4 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.7 | -0.3 | 0.0 | 0.0 | - | - | - | - |
| MAKE SURE TOGETHER | 1.3 | +179.3 | 0.0 | 37.3 | - | - | - | - |
| MANOEUVRE | 3.0 | +26.9 | 0.0 | 103.3 | 2.0 | -11.8 | 0.0 | 21.7 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +8.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.3 | +52.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | +147.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 2.3 | +0.0 | 0.0 | 74.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.3 | +245.5 | 0.0 | 0.0 | 0.3 | +27.7 | 0.0 | 21.7 |
| MEETS IN TIME | 2.7 | +300.6 | 0.0 | 0.0 | 3.7 | +178.8 | 0.0 | 41.7 |
| MISSILES IN THE MOVE | 2.3 | +46.0 | 0.0 | 0.0 | 1.0 | +7.0 | 0.0 | 180.0 |
| MISSILES NEXT TURN | 3.0 | +35.3 | 0.0 | 0.0 | 2.3 | +6.9 | 0.0 | 180.0 |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 3.7 | +125.8 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 3.3 | -160.2 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 5.3 | +515.2 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 5.7 | +246.8 | 0.0 | 0.0 | 5.7 | +227.9 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 3.7 | +502.5 | 96.7 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 1.7 | -82.2 | 211.7 | 37.3 | - | - | - | - |
| NO LATE CUT | 2.3 | +0.0 | 0.0 | 74.7 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | - | - | - | - | 0.3 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 3.7 | -163.5 | 0.0 | 31.7 | 2.3 | -31.8 | 0.0 | 41.7 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 6.3 | -176.6 | 0.0 | 0.0 | 0.3 | -9.5 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 1.0 | +333.9 | 0.0 | 37.3 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 2.0 | +8.3 | 0.0 | 0.0 | 4.7 | -42.5 | 0.0 | 0.0 |
| ONE ROUTE | 2.3 | +0.0 | 0.0 | 74.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.3 | +0.9 | 0.0 | 0.0 | - | - | - | - |
| PATHS CROSS | 0.3 | -2.2 | 0.0 | 0.0 | 0.3 | +2.2 | 0.0 | 0.0 |
| PERIAPT WORTH | - | - | - | - | 0.3 | +33.0 | 0.0 | 180.0 |
| PLAN RESULT | 42.0 | +780.8 | 635.0 | 750.7 | 41.0 | +1213.3 | 595.7 | 1108.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 7.0 | -229.6 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 1.0 | -34.2 | 96.7 | 0.0 | - | - | - | - |
| PROMISE READS THE TABLE | 0.7 | -19.1 | 0.0 | 37.3 | - | - | - | - |
| QUARTER ODDS | 25.3 | +2343.2 | 343.0 | 156.0 | 23.7 | +1895.6 | 1218.7 | 321.7 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.0 | +13.6 | 0.0 | 285.0 |
| REAL GROUND | 2.3 | +0.0 | 0.0 | 74.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.3 | +36.3 | 0.0 | 21.7 | 0.7 | +8.3 | 0.0 | 21.7 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 0.7 | +0.0 | 0.0 | 43.3 |
| REDIRECT WEIGHED | 0.7 | -16.0 | 31.7 | 0.0 | - | - | - | - |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.7 | +9.8 | 180.0 | 37.3 | - | - | - | - |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 74.7 | - | - | - | - |
| ROUNDS AFTER TERROR | 1.0 | -19.4 | 31.7 | 0.0 | - | - | - | - |
| RUN DOWN | 0.7 | -1.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.0 | -229.9 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.3 | +179.3 | 0.0 | 37.3 | - | - | - | - |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.7 | -0.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | 0.7 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 9.3 | +0.0 | 0.0 | 95.0 | 15.3 | +0.0 | 0.0 | 221.7 |
| SHOOTS FROM THE BEST SPOT | 2.3 | +95.5 | 43.3 | 206.7 | 0.7 | +25.7 | 0.0 | 0.0 |
| SHORT GUN FORWARD | - | - | - | - | 0.3 | +0.0 | 0.0 | 45.0 |
| SHOT OR CHARGE | 0.7 | -8.9 | 0.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 32.0 | +972.8 | 0.0 | 552.7 | 16.0 | +139.6 | 0.0 | 708.7 |
| SHOTS AFTER THE MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 14.7 | +386.3 | 0.0 | 370.7 | 21.3 | +1315.0 | 0.0 | 253.3 |
| SPELL WORTH | - | - | - | - | 3.0 | +51.8 | 180.0 | 180.0 |
| SPOT AS THE GAME MOVES | 4.7 | +0.0 | 0.0 | 206.7 | 3.0 | +0.0 | 0.0 | 48.3 |
| STAND AND SHOOT | 0.3 | -4.1 | 0.0 | 37.3 | - | - | - | - |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 50.0 | +0.0 | 1583.3 | 699.3 | 54.0 | +0.0 | 2012.0 | 943.0 |
| STAY WORTH | 27.0 | +259.5 | 1104.0 | 569.0 | 36.7 | -76.2 | 1206.7 | 574.0 |
| STUCK PIVOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 96.7 |
| SUPPORT ADDS | 3.0 | +37.8 | 0.0 | 0.0 | 6.7 | +872.7 | 0.0 | 21.7 |
| SUPPORT WORKED OUT | 3.0 | +37.8 | 0.0 | 0.0 | 6.7 | +872.7 | 0.0 | 21.7 |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 21.7 |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.0 | +0.0 | 0.0 | 103.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 4.3 | +0.0 | 0.0 | 21.7 | 4.7 | +0.0 | 0.0 | 43.3 |
| THE ROW READS HIS LAST RUN | 0.3 | +0.0 | 0.0 | 103.3 | - | - | - | - |
| THE STEP BACK IS MADE | 3.7 | +0.0 | 0.0 | 21.7 | 3.3 | +0.0 | 0.0 | 43.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 44.0 | +0.0 | 0.0 | 450.3 | 42.3 | +0.0 | 0.0 | 537.0 |
| TIED UP BY THE SUM | 0.3 | +30.3 | 0.0 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 24.7 | +308.7 | 269.3 | 293.3 | 16.3 | +209.0 | 206.7 | 175.7 |
| TWO OR MORE ARRIVE | 0.7 | +5.3 | 0.0 | 0.0 | - | - | - | - |
| WAITS AGAIN | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WALKS ON ITS ROUTE | - | - | - | - | 0.3 | -20.0 | 0.0 | 67.3 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 43.3 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.3 | +9.6 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 4.0 | -150.6 | 0.0 | 0.0 | 2.7 | -534.7 | 0.0 | 408.3 |
| WHOLE FIGHT GAIN | 1.0 | +199.0 | 0.0 | 37.3 | - | - | - | - |
| WOUNDS ON THE RANKS | 2.7 | +199.1 | 0.0 | 0.0 | 1.0 | +9.1 | 0.0 | 134.7 |

### Rule changes: ccut-c940641-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 91 | 91 | 58 | 19.33 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 58 | 58 | 54 | 18.00 | +4139 | +76.7 |
| HIS SHOT LIST | 241 | 230 | 53 | 17.67 | +1402 | +26.4 |
| HIS SHOTS BY HIS RUN | 177 | 171 | 46 | 15.33 | +581 | +12.6 |
| ARMY TABLE | 79 | 79 | 44 | 14.67 | +636 | +14.5 |
| DEPLOY BY FIGURES | 53 | 53 | 38 | 12.67 | +613 | +16.1 |
| HIS MOVE WHY | 71 | 71 | 38 | 12.67 | +0 | +0.0 |
| SHOT RISK POINTS | 144 | 139 | 29 | 9.67 | +1139 | +39.3 |
| HIS ONE MOVE | 76 | 76 | 24 | 8.00 | +0 | +0.0 |
| OFF BEST | 18 | 18 | 18 | 6.00 | -586 | -32.6 |
| THE TABLE AGAIN | 36 | 36 | 17 | 5.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 123 | 107 | 17 | 5.67 | +34 | +2.0 |
| GOAL WALK | 40 | 39 | 14 | 4.67 | +1068 | +76.3 |
| ARTILLERY RE-ROLL WEIGHED | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| IDLE COST | 52 | 48 | 13 | 4.33 | +74 | +5.7 |
| FIVE ACTION | 547 | 534 | 11 | 3.67 | +827 | +75.2 |
| HARD STAY DROPPED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| ADVANCE LANE KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| MOVE ORDER | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 16 | 13 | 8 | 2.67 | +473 | +59.1 |
| NEXT CHARGE BY LIST | 11 | 11 | 8 | 2.67 | +519 | +64.9 |
| PROMISE BY ITS OWN SUM | 21 | 21 | 8 | 2.67 | -689 | -86.1 |
| FIRE IN ORDER | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHARGE LOSSES | 80 | 76 | 5 | 1.67 | +183 | +36.6 |
| MEETS IN TIME | 19 | 19 | 5 | 1.67 | +199 | +39.8 |
| QUARTER ODDS | 147 | 142 | 5 | 1.67 | +567 | +113.4 |
| SUPPORT ADDS | 29 | 27 | 5 | 1.67 | +606 | +121.2 |
| SUPPORT WORKED OUT | 29 | 27 | 5 | 1.67 | +606 | +121.2 |
| CANNON PLANNED TARGET | 56 | 56 | 4 | 1.33 | -243 | -60.9 |
| CHAFF IN THE MOVE | 5 | 5 | 4 | 1.33 | +0 | +0.0 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +110 | +27.4 |
| MANOEUVRE | 15 | 15 | 4 | 1.33 | +81 | +20.2 |
| MAX FOR POSITIONING | 8 | 8 | 4 | 1.33 | +216 | +54.0 |
| RANDOM MOVE BY FIGURES | 9 | 9 | 4 | 1.33 | +41 | +10.2 |
| SHOOTERS IN TWO RANKS | 4 | 4 | 4 | 1.33 | +8 | +2.0 |
| STAY WORTH | 191 | 174 | 4 | 1.33 | +114 | +28.4 |
| THE RISK READS HIS RUN | 18 | 18 | 4 | 1.33 | +0 | +0.0 |
| FOUR ROUNDS | 6 | 6 | 3 | 1.00 | +233 | +77.5 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | -209 | -69.7 |
| SHOOTS FROM THE BEST SPOT | 9 | 9 | 3 | 1.00 | +55 | +18.4 |
| STUCK PIVOT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| BEST PRIZE | 2 | 2 | 2 | 0.67 | -115 | -57.5 |
| COVER ONCE | 19 | 14 | 2 | 0.67 | +6 | +3.0 |
| FALLS SHORT | 47 | 42 | 2 | 0.67 | +22 | +10.8 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +190 | +95.2 |
| MARCH CHECK | 4 | 4 | 2 | 0.67 | +3 | +1.4 |
| ONE JOINT FIGURE | 3 | 3 | 2 | 0.67 | +270 | +135.1 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| PROMISE KNOWS THE FIGHT | 3 | 2 | 2 | 0.67 | -103 | -51.4 |
| REDIRECT COUNTER | 3 | 2 | 2 | 0.67 | +99 | +49.6 |
| REDIRECT FOR A FRIEND IN REACH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | -36 | -18.1 |
| WHOLE FIGHT GAIN | 3 | 3 | 2 | 0.67 | +213 | +106.3 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +46 | +45.6 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +5 | +4.9 |
| CAST JOB | 2 | 2 | 1 | 0.33 | +4 | +3.9 |
| EXACT ROUND | 3 | 3 | 1 | 0.33 | +9 | +9.4 |
| HIS MOVE AND SHOT | 9 | 9 | 1 | 0.33 | +3 | +2.8 |
| LEGAL CHARGES ONLY | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +24 | +23.9 |
| ONE FIGHT FORMULA | 20 | 12 | 1 | 0.33 | +31 | +30.8 |
| ONE OBJECTIVE FORMULA | 20 | 12 | 1 | 0.33 | +28 | +28.1 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +99 | +99.0 |
| PROMISE READS THE TABLE | 2 | 2 | 1 | 0.33 | +13 | +12.6 |
| SHORT GUN FORWARD | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 19 | 19 | 1 | 0.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 108 | 77 | 1 | 0.33 | +8 | +8.5 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -60 | -60.0 |
| WAR ENGINE JOBS | 2 | 2 | 1 | 0.33 | -27 | -26.8 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +29 | +29.0 |
| CANNON PLAN MISSED | 9 | 9 | 0 | 0.00 | - | - |
| CHARACTER GUNS | 25 | 25 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 6 | 6 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 37 | 36 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 1 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 5 | 5 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 11 | not checked | - | - | - | - |
| FRIEND SHOOTS FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GUN FIGURES | 12 | not checked | - | - | - | - |
| HIS CHARGE BY HIS RUN | 19 | 19 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 11 | 11 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 4 | 2 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 19 | 19 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 3 | 3 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 28 | 24 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 13 | 11 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 4 | 4 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 88 | 87 | 0 | 0.00 | - | - |
| HONEST WORTH | 5 | 5 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 13 | 12 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 2 | 2 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 4 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 9 | 9 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 10 | 4 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 16 | 11 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 11 | 4 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 10 | trace | - | - | - | - |
| NEARER NOT NEEDED | 34 | 33 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 5 | 5 | 0 | 0.00 | - | - |
| NO LATE CUT | 7 | 7 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE ROUTE | 9 | 9 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 249 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 9 | 9 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK BY ARC | 5 | 5 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 4 | 4 | 0 | 0.00 | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 74 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 9 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 23 | 15 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 4 | 4 | 0 | 0.00 | - | - |
| STANDS STILL | 312 | 306 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 5 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 10 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 27 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 1 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 21 | not checked | - | - | - | - |
| THE TABLE BINDS | 259 | not checked | - | - | - | - |
| TIED UP BY THE SUM | 1 | 1 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 2 | not checked | - | - | - | - |
| WAITS AGAIN | 8 | 6 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 20 | 18 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 11 | 11 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p3

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.00 | 2.33 | 28.1 |
| PROMISE BY ITS OWN SUM | rule | 2.67 | - | 86.1 |
| RULE SWITCHED OFF | gate | 1.33 | - | 54.6 |
| ARMY TABLE | rule | 0.67 | - | 105.7 |
| BEST PRIZE | rule | 0.67 | - | 57.5 |
| CANNON PLANNED TARGET | rule | - | 0.67 | 121.8 |
| JOINT CHARGE NOW | rule | 0.67 | - | 159.8 |
| PROMISE KNOWS THE FIGHT | rule | 0.67 | - | 51.4 |
| AFTERMATH BAND | gate | 0.33 | - | 2.0 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 42.0 |
| PATHS CROSS | rule | 0.33 | - | 6.7 |
| REDIRECT WEIGHED | rule | 0.33 | - | 53.3 |
| WALKS ON ITS ROUTE | rule | - | 0.33 | 60.0 |
| WAR ENGINE JOBS | rule | 0.33 | - | 26.8 |

### Plans: ccut-c940641-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.7 | 20% | 448 | 195 | 44% |
| Mine | join | 0.3 | 100% | 11 | 0 | 0% |
| Mine | move | 30.7 | 95% | 2062 | 0 | 0% |
| Mine | shoot | 9.3 | 64% | 318 | 586 | 184% |
| Opponent | join | 1.0 | 100% | 35 | 0 | 0% |
| Opponent | move | 26.7 | 89% | 1286 | 0 | 0% |
| Opponent | shoot | 12.7 | 74% | 764 | 1213 | 159% |
| Opponent | support | 0.7 | 100% | 0 | 0 | - |

### Battle groups: ccut-c940641-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 0.7 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | 0 (1) | - | 0 (1) | 0 (2) | - |
| Mine | Character | 11 | 26 (11) | 26 | 0 | 0 | 18% | 2.0 | 44 (5) | 21 (4) | 0 (2) | 35 (7) | 15 (4) |
| Mine | Clean-up | 3 | 99 (3) | 0 | 99 | 0 | 100% | - | 99 (3) | - | - | 150 (2) | 0 (1) |
| Mine | Hammer | 8 | 26 (8) | 11 | 15 | 37 | 38% | 1.8 | 0 (2) | 31 (6) | - | 46 (5) | 7 (3) |
| Mine | Holder | 4 | 41 (4) | 0 | 41 | 49 | 75% | 1.0 | 0 (1) | 54 (3) | - | 151 (1) | 0 (3) |
| Mine | Shooter | 1 | 134 (1) | 0 | 134 | 0 | 0% | 2.0 | 134 (1) | - | - | - | 134 (1) |
| Mine | War machine | 5 | 111 (5) | 111 | 0 | 40 | 0% | 1.0 | 111 (5) | - | - | 278 (2) | 0 (3) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 100 | 100% | - | 0 (1) | 0 (1) | 0 (1) | 0 (1) | 0 (2) |
| Opponent | Character | 14 | 17 (14) | 17 | 0 | 32 | 36% | 3.0 | 23 (10) | 0 (3) | - | 22 (9) | 0 (4) |
| Opponent | Clean-up | 4 | 96 (4) | 0 | 96 | 0 | 75% | 5.0 | - | 96 (4) | - | 96 (4) | - |
| Opponent | Fragile | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Hammer | 6 | 59 (6) | 30 | 29 | 40 | 17% | 2.4 | 95 (2) | 0 (1) | 55 (3) | 59 (6) | - |
| Opponent | Holder | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | - | 0 (2) | 0 (1) | 0 (1) | 0 (2) |
| Opponent | Shooter | 4 | 12 (4) | 0 | 12 | 54 | 75% | 3.0 | - | 20 (3) | 0 (1) | 12 (4) | - |
| Opponent | War machine | 9 | 21 (9) | 21 | 0 | 71 | 11% | 1.0 | 21 (9) | - | - | 0 (1) | 24 (8) |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | 0 (1) | - | 0 (1) | - |

### Charged fights: ccut-c940641-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 270 | 365 | 2.0 | 1.2 | 182 | 28 | +154 | 3 of 4 | 2 of 4 | -112 | +243 |
| Mine | Dwarfen Mountain Holds | 1 | 730 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 423 | 243 | 1.3 | 1.2 | 182 | 28 | +154 | 3 of 4 | 2 of 4 | -112 | +243 |
| Opponent | Dwarfen Mountain Holds | 1 | 449 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 1 | 65 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Skaven | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 171 | 0 | 0.0 | - | - | - | - | - | - | - | - |

### Effective charges: ccut-c940641-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 4 | 0 | 0 | 1 (net +0) | 1 (net -112) | 0 | 1 (net +540) | 1 | 33% (1 of 3) |

### Charged fights, damage counted: ccut-c940641-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 339 | 239 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 76-89% | 1 | 451 | 239 | -112 | 76 | 312 | -236 | -52.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 339 | 440 | +540 | 553 | 170 | +384 | +113.3 |
| Mine | No odds | 1 | 339 | 95 | +190 | 190 | 0 | +190 | +56.0 |
| Mine | All fights | 4 | 367 | 253 | +154 | 205 | 120 | +85 | +23.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p3 | move | 15 | 3 (20%) | 2 (13%) | 0 (0%) | 12 (80%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Periapt of Soul Exchange | Opponent | L0421 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421 |
| Witch Hunter's Ward | Opponent | L0508 |

# Doctrine scorecard: ccut-c940641-p37

### Scorecard: ccut-c940641-p37

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0106 | 4 | 1 | Opponent | no | 0 | - | 0 | 3 | 0 | 0 | 0 | 1315 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 3 | 0 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 2 | 5 | 4 | 0 | 0 | 0 | 72 |
| L0206 | 2 | 1 | Mine | - | - | - | 0 | 5 | 0 | 0 | 0 | 170 |
| L0206 | 2 | 1 | Opponent | - | - | 3 | 0 | 1 | 0 | 0 | 0 | 683 |
| **Average** | | | Mine | 0% | 0.0 | - | 0.0 | 3.0 | 0.0 | 0.0 | 0.0 | 56.7 |
| **Average** | | | Opponent | 0% | 0.0 | 2.5 | 1.7 | 2.7 | 0.0 | 0.0 | 0.0 | 690.0 |

### KPIs: ccut-c940641-p37

Rules off - Opponent only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 9) | 65% (11 of 17) | 42% (11 of 26) |
| Winner chose to follow up after the loser gave ground |  | 80% (4 of 5); on the table 80% | 100% (3 of 3); on the table 100% | 88% (7 of 8); on the table 88% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 80% (4 of 5); on the table 80% | 100% (3 of 3); on the table 100% | 88% (7 of 8); on the table 88% |
| Magic missiles tried each own turn | 50%+ | 52% (47 of 90) | - | 52% (47 of 90) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 57% (47 of 82) | - | 57% (47 of 82) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 50% (3 of 6) | - | 50% (3 of 6) |
| Points that never fought | lower | 80% (4538 of 5699) | 75% (4506 of 6000) | 77% (9044 of 11699) |
|   infantry points that never fought | lower | 83% (1862 of 2239) | 89% (1878 of 2111) | 86% (3740 of 4350) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 38% (6 of 16) | 60% (15 of 25) | 51% (21 of 41) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 3.7 uses a game | 0.0 uses a game | 100% (4 of 4); 1.8 uses a game |
| Bound items with another spell used |  | 50% (1 of 2); 1.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.7 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (4 of 4); 1.3 uses a game | 0.0 uses a game | 100% (4 of 4); 0.7 uses a game |
|   their share of the points of units over 100 pts | lower | 31% (1221 of 3916) | 54% (2353 of 4382) | 43% (3574 of 8298) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 5.7 (40%) | - | 5.7 (40%) |
| MARCHED: its unit marched | 6.0 (42%) | - | 6.0 (42%) |
| IN COMBAT: engaged in combat | 1.7 (12%) | - | 1.7 (12%) |
| GONE: slain | 1.0 (7%) | - | 1.0 (7%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.0 | 1.0 | 7.7 | 15.7 | 0.0 | 0.3 |
| not cast | 2.0 | 3.0 | 2.3 | 14.3 | 2.0 | 27.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (67%) | 0.0 (0%) | 5.7 (40%) | 1.7 (83%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 6.0 (42%) | 0.3 (17%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (22%) | 1.0 (43%) | 1.7 (12%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.3 (14%) | 1.0 (7%) | 0.0 (0%) | 1.7 (6%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (100%) | 0.3 (11%) | 1.0 (43%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 25.7 (93%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 9.0 a game | 0.0 a game | 4.5 a game |
| stood (cast and not dispelled) | 52% (14 of 27) | - | 52% (14 of 27) |
| the unit moved after it | 64% (9 of 14) | - | 64% (9 of 14) |
| it charged on its next turn | 0% (0 of 14) | - | 0% (0 of 14) |
| the enemy charged it first | 29% (4 of 14) | - | 29% (4 of 14) |
| it fought by the end of its next turn | 29% (4 of 14) | - | 29% (4 of 14) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 14) | - | 0% (0 of 14) |
| none of these (no charge, no fight, no charge escaped) | 71% (10 of 14) | - | 71% (10 of 14) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (11 of 17) | 61% (118 of 195) | 61% (129 of 212) |
|   cavalry | - | 52% (15 of 29) | 52% (15 of 29) |
|   character | - | 61% (14 of 23) | 61% (14 of 23) |
|   chariot | - | 0% (0 of 1) | 0% (0 of 1) |
|   infantry | 65% (11 of 17) | 53% (34 of 64) | 56% (45 of 81) |
|   monster | - | 82% (9 of 11) | 82% (9 of 11) |
|   war machine | - | 69% (46 of 67) | 69% (46 of 67) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.3 (67%) | 0.7 (3%) | 2.0 (7%) |
| CHARGED: it charged | 0.0 (0%) | 1.7 (6%) | 1.7 (6%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.7 (3%) | 0.7 (2%) |
| NO TARGET IN RANGE | 0.7 (33%) | 10.0 (39%) | 10.7 (39%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 2.7 (10%) | 2.7 (10%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 5.0 (19%) | 5.0 (18%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 1.0 (4%) | 1.0 (4%) |
| OTHER BAR | 0.0 (0%) | 4.0 (16%) | 4.0 (14%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.7 | 2.0 | 74% | 2.6 pts | 20 pts |
| character | 4.7 | 4.0 | 57% | 12.5 pts | 58 pts |
| infantry | 22.0 | 9.7 | 68% | 5.0 pts | 109 pts |
| monster | 3.0 | 1.7 | 67% | 7.3 pts | 22 pts |
| war machine | 15.3 | 11.3 | 57% | 7.8 pts | 119 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.0 | 3.3 | 2.2 |
| Charges that made contact a game | 1.0 | 2.0 | 1.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.15 declared, 0.15 contact (20 units) | 0.37 declared, 0.22 contact (27 units) | 0.28 declared, 0.19 contact (47 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Character in a unit | 100% (3 of 3) | 25% (1 of 4) | - | 57% (4 of 7) |
| Character on its own | 67% (2 of 3) | 100% (2 of 2) | 0% (0 of 2) | 57% (4 of 7) |
| Infantry | 57% (4 of 7) | 29% (2 of 7) | - | 43% (6 of 14) |
| Monster | 40% (2 of 5) | - | - | 40% (2 of 5) |
| War Machines | 62% (5 of 8) | - | - | 62% (5 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 3 | 80% (4 of 5); on the table 80% | 52% (47 of 90) | 80% | 38% (6 of 16) | 100% (4 of 4); 3.7 uses a game | 50% (1 of 2); 1.3 uses a game | 100% (4 of 4); 1.3 uses a game |
| Dwarfen Mountain Holds | 2 | 100% (2 of 2); on the table 100% | - | 83% | 65% (13 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (1 of 1); on the table 100% | - | 59% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p37, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | - | 0% (0) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: ccut-c940641-p37

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 0.7 |
| Strategy | Charge objectives carried out (made contact) | 100% (3 of 3) | 10% (1 of 10) |
| Strategy | Shoot objectives carried out (shot that target) | 22% (4 of 18) | 44% (36 of 81) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | 0% (0 of 2) |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 2) | - |
| Strategy | Joined characters whose unit fought | 10% (1 of 10) | 12% (1 of 8) |
| Strategy | Lone characters that fought | 25% (2 of 8) | 50% (1 of 2) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 3.0 | 2.7 |
| Movement | Points that never moved of their own | 56.7 | 690.0 |
| Movement | Fights charged into per game | 0.7 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 2 | 2 of 4, net -98 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 2 | 1 of 4, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 2 | 0 of 4 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 2 | 1 of 4, net +225 |
| Shooting | Shots by shooting units (incl. breath weapons) | 3.7 | 25.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 45% (5 of 11) | 65% (50 of 77) |
| Shooting | Points destroyed by shooting units | 0.0 | 306.7 |
| Shooting | War machine shots | - | 15.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | - | 72% (33 of 46) |
| Shooting | Points destroyed by war machines | 0.0 | 17.3 |
| Magic | Magic missiles cast | 7.0 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (7 of 21) | - |
| Magic | Wounds caused by magic missiles | 16.0 | - |
| Magic | Points destroyed by magic (all spells) | 126.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.7 / 0.3 / 0.0 | 3.3 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 160.0 | 75.0 |
| Combat | Points run down | 0.0 | 21.7 |
| Combat | Net points per charged fight, damage counted | +118 | +10 |
| Combat | Net per 100 charger points, damage counted | +176.6 | +4.5 |
| Combat | First round won (charged fights) | 100% | 0% |
| Combat | Net points per charged fight | +112 | +5 |
| Combat | Net points per supported fight / lone fight | +105 / +120 | - / +5 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 2 | 4 of 6 |
| Game | Points lost | 425.7 | 338.0 |
| Game | VP from objectives | 686.7 | 470.0 |
| Game | Lone holders (player turns) | 0.0 | 0.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +133 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 764
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ccut-c940641-p37

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +117.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 16.3 | +159.4 | 0.0 | 204.3 | 15.3 | +128.5 | 0.0 | 147.3 |
| BEST PRIZE | - | - | - | - | 0.3 | -4.8 | 0.0 | 0.0 |
| CANNON PLAN MISSED | - | - | - | - | 0.7 | +0.0 | 66.7 | 0.0 |
| CANNON PLANNED TARGET | - | - | - | - | 14.3 | +104.9 | 593.3 | 110.0 |
| CANNON SIGHT KEPT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 2.3 | +36.1 | 0.0 | 143.3 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 6.3 | +506.9 | 96.0 | 181.3 | - | - | - | - |
| CASTS AFTER FRIENDS | 4.7 | +0.0 | 0.0 | 31.7 | - | - | - | - |
| CATCH FLIERS | 0.3 | +8.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 2.0 | +76.4 | 0.0 | 27.0 | 1.3 | +86.8 | 0.0 | 24.0 |
| CHAFF PASSED | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +6.1 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | - | - | - | - | 7.0 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 17.3 | -1029.0 | 0.0 | 311.3 | 9.0 | -844.1 | 0.0 | 18.3 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 75.0 | 0.0 | 1.3 | +0.0 | 43.3 | 0.0 |
| CLOSES ON WHAT IT BEATS | 12.0 | +0.0 | 0.0 | 157.3 | 5.3 | +0.0 | 0.0 | 75.0 |
| COMBAT PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 5.7 | +669.4 | 181.3 | 31.7 | - | - | - | - |
| COVER ONCE | 5.3 | -277.3 | 0.0 | 82.3 | 6.3 | -204.1 | 0.0 | 100.0 |
| DENIED BY THE FIGHT | - | - | - | - | 1.0 | -7.3 | 43.3 | 65.0 |
| DEPLOY BY FIGURES | 6.7 | +87.5 | 0.0 | 0.0 | 12.3 | -197.3 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 1.0 | -493.0 | 0.0 | 0.0 |
| EXACT ROUND | 0.7 | -4.1 | 70.0 | 10.0 | 2.0 | +12.9 | 21.7 | 65.0 |
| FALL BACK GOOD ORDER | 0.7 | +1.0 | 75.0 | 0.0 | 2.7 | +0.8 | 43.3 | 65.0 |
| FALLS SHORT | 14.0 | +355.9 | 0.0 | 319.3 | 10.7 | +80.0 | 0.0 | 243.0 |
| FEATURE BUFFS | 13.7 | +429.3 | 0.0 | 119.7 | 0.7 | +3.5 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +3.6 | 70.0 | 10.0 | 1.7 | +209.4 | 0.0 | 65.0 |
| FIRE IN ORDER | - | - | - | - | 0.7 | +0.0 | 28.3 | 0.0 |
| FIVE ACTION | 66.7 | +6365.8 | 254.0 | 1182.7 | 133.3 | +4474.1 | 2368.3 | 897.7 |
| FLANK NOT WEIGHED | 3.7 | +0.0 | 0.0 | 157.3 | 3.7 | +0.0 | 0.0 | 35.0 |
| FOUR ROUNDS | 1.0 | +27.7 | 110.0 | 10.0 | 3.7 | +504.4 | 65.0 | 65.0 |
| FREED FROM HIS FIGHT | 0.3 | +0.0 | 0.0 | 90.7 | 1.7 | +0.0 | 0.0 | 35.0 |
| FRIEND SHOOTS FIRST | 0.7 | -18.3 | 48.0 | 43.3 | 0.7 | -0.4 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | - | - | - | - | 0.3 | -0.1 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.7 | -13.7 | 21.7 | 0.0 |
| GOAL WALK | 13.3 | +2286.0 | 0.0 | 296.0 | - | - | - | - |
| GUN FIGURES | - | - | - | - | 2.0 | +29.1 | 90.7 | 0.0 |
| GUN MASK | - | - | - | - | 2.7 | +244.4 | 0.0 | 20.0 |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 85.0 |
| HE REFORMS ONCE FREED | 0.3 | +0.0 | 0.0 | 90.7 | 0.7 | +0.0 | 0.0 | 35.0 |
| HIS CHARGE BY HIS RUN | 11.0 | +0.0 | 0.0 | 242.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +1.1 | 0.0 | 0.0 |
| HIS CHARGE LIST | 11.7 | +0.0 | 0.0 | 392.7 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.7 | +0.0 | 0.0 | 105.3 | 2.7 | +0.0 | 0.0 | 24.0 |
| HIS MOVE AND SHOT | 5.7 | -34.3 | 0.0 | 184.7 | 1.7 | -75.1 | 0.0 | 0.0 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 29.3 | +7.0 | 447.3 | 0.0 |
| HIS MOVE WHY | 19.0 | +0.0 | 0.0 | 400.7 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 16.3 | +115.5 | 0.0 | 109.0 |
| HIS ONE QUARTER | - | - | - | - | 4.0 | +0.0 | 0.0 | 120.0 |
| HIS OWN BEST MOVE | 3.7 | +0.0 | 0.0 | 105.3 | 1.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 7.3 | +0.0 | 0.0 | 110.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 46.0 | +1489.0 | 0.0 | 739.7 | 49.0 | +1729.5 | 0.0 | 348.7 |
| HIS SHOTS BY HIS RUN | 38.7 | +863.5 | 0.0 | 670.0 | 36.7 | +899.8 | 0.0 | 434.3 |
| HIS TURN DENIED | - | - | - | - | 2.0 | +98.1 | 65.0 | 65.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 34.3 | +0.0 | 0.0 | 464.0 | 14.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 12.0 | +1325.0 | 0.0 | 224.7 | 9.0 | +1045.2 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -1.7 | 110.0 | 10.0 | 3.0 | -144.3 | 65.0 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 2.0 | +205.1 | 0.0 | 65.0 |
| HUNT RESULT | 0.3 | +41.9 | 0.0 | 17.3 | - | - | - | - |
| HUNT THE GUNS | 0.3 | +42.9 | 40.0 | 0.0 | - | - | - | - |
| IDLE COST | 10.0 | -66.6 | 0.0 | 174.0 | 5.7 | -93.5 | 0.0 | 42.3 |
| JOINT CHARGE NOW | 0.7 | +6.0 | 70.0 | 10.0 | 1.3 | -25.5 | 43.3 | 0.0 |
| KEEPS SCOUTS OR AMBUSH | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 3.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +18.2 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 7.7 | +0.0 | 113.0 | 110.0 | 9.0 | +0.0 | 299.7 | 138.0 |
| LONE WIZARD KEPT IN | 2.7 | +247.6 | 0.0 | 0.0 | 0.7 | +60.4 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.0 | -1.0 | 110.0 | 10.0 | 2.0 | +6.8 | 0.0 | 65.0 |
| MANOEUVRE | 0.7 | +3.5 | 0.0 | 90.7 | 1.7 | -7.1 | 0.0 | 100.0 |
| MARCH BY THE SUM | 1.7 | +193.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.0 | +20.2 | 0.0 | 27.0 | - | - | - | - |
| MARCH OVER CASTS | 1.7 | -77.3 | 0.0 | 27.0 | - | - | - | - |
| MARCH WHEELS ONLY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.0 | +70.2 | 0.0 | 117.7 | 1.7 | +43.9 | 0.0 | 35.0 |
| MEETS IN TIME | 3.0 | +105.1 | 0.0 | 0.0 | 7.7 | +68.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 8.0 | +403.0 | 0.0 | 246.7 | - | - | - | - |
| MISSILES NEXT TURN | 9.3 | +305.6 | 0.0 | 235.3 | - | - | - | - |
| MISSILES ON ONE TARGET | 3.0 | -97.7 | 0.0 | 0.0 | - | - | - | - |
| MODEL FACING | - | - | - | - | 4.0 | +423.0 | 0.0 | 40.0 |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.3 | +6.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 2.7 | -137.6 | 0.0 | 63.3 | - | - | - | - |
| MOVE SPELL SPOT | 2.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 1.0 | +102.8 | 0.0 | 0.0 | 3.7 | +235.7 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 3.7 | +138.5 | 0.0 | 43.3 | 9.3 | +387.3 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 1.7 | +132.8 | 48.0 | 43.3 | 1.7 | +173.2 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.0 | -17.8 | 110.0 | 10.0 | 3.7 | -85.1 | 65.0 | 65.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT WORTH A CAST | 0.3 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 1.7 | -19.7 | 0.0 | 0.0 | 6.3 | -258.9 | 0.0 | 105.0 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 4.0 | -134.4 | 0.0 | 254.0 | 4.7 | -43.9 | 0.0 | 55.0 |
| ONE JOINT FIGURE | - | - | - | - | 1.3 | +140.8 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 7.3 | +43.3 | 0.0 | 224.7 | 3.7 | -22.9 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 1.3 | +11.9 | 96.0 | 0.0 | 0.7 | +6.3 | 20.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.3 | +19.6 | 0.0 | 0.0 |
| OVERRUNS AWAY | 0.3 | +0.7 | 40.0 | 0.0 | 1.3 | +29.5 | 21.7 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +2.9 | 0.0 | 18.3 |
| PLAN RESULT | 29.3 | +168.7 | 72.0 | 457.3 | 59.3 | +1276.4 | 807.0 | 553.7 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 27.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 2.3 | -11.8 | 0.0 | 0.0 | 6.0 | -90.1 | 0.0 | 40.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.7 | -0.7 | 0.0 | 0.0 |
| QUARTER ODDS | 6.7 | +974.9 | 0.0 | 0.0 | 17.3 | +940.5 | 0.0 | 260.0 |
| RANDOM MOVE BY FIGURES | 2.0 | +7.9 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | +8.6 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.3 | +95.7 | 0.0 | 38.3 | 1.0 | +25.4 | 0.0 | 24.0 |
| REDIRECT FOR A FRIEND IN REACH | 3.0 | +0.0 | 0.0 | 102.3 | 1.7 | +34.6 | 0.0 | 24.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | - | - | - | - | 0.3 | -1.1 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.7 | +2.6 | 0.0 | 0.0 |
| RESERVE MOVE SPELL | 1.3 | +30.9 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.0 | -19.5 | 110.0 | 10.0 | 3.3 | +2.5 | 65.0 | 65.0 |
| RISK ON THE WAY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 2.0 | -65.8 | 43.3 | 65.0 |
| RUN DOWN | 0.7 | -2.3 | 70.0 | 10.0 | 3.3 | -20.0 | 65.0 | 65.0 |
| SCOUT SPOT | 0.7 | +0.4 | 0.0 | 0.0 | 0.7 | -0.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 1.0 | -121.6 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 0.3 | +0.3 | 0.0 | 21.7 | 0.7 | +4.4 | 0.0 | 20.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +4.0 | 0.0 | 0.0 |
| SET CREDITED ONCE | 3.3 | -81.4 | 0.0 | 289.3 | 2.7 | -317.4 | 0.0 | 130.0 |
| SET UP BY THE SET | 3.3 | +57.8 | 0.0 | 289.3 | 4.0 | +339.1 | 0.0 | 189.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 1.7 | +4.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 5.0 | +0.0 | 0.0 | 172.3 | 26.3 | +0.0 | 0.0 | 110.0 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +11.0 | 0.0 | 0.0 | 2.0 | +19.1 | 181.3 | 0.0 |
| SHORT GUN FORWARD | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.7 | -5.0 | 0.0 | 0.0 |
| SHOT RISK POINTS | 31.7 | -207.4 | 0.0 | 494.7 | 34.7 | +441.6 | 0.0 | 594.3 |
| SHOTS AFTER THE MOVES | 1.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 3.7 | +74.2 | 0.0 | 86.7 | 45.3 | +783.4 | 0.0 | 231.3 |
| SPELL OFF EDGE | 0.7 | +39.4 | 35.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 1.0 | +485.5 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 1.0 | +5.9 | 65.0 | 0.0 | - | - | - | - |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | -22.1 | 0.0 | 65.0 |
| SPOT AS THE GAME MOVES | 6.0 | +0.0 | 0.0 | 235.7 | 2.7 | +0.0 | 0.0 | 85.0 |
| STAND AND SHOOT | 1.0 | -2.2 | 110.0 | 10.0 | 1.0 | -3.8 | 65.0 | 0.0 |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 93.7 | 5.0 | +0.0 | 0.0 | 24.0 |
| STANDS STILL | 22.3 | +0.0 | 144.0 | 411.3 | 89.7 | +0.0 | 2303.3 | 574.0 |
| STAY WORTH | 4.3 | +24.3 | 0.0 | 21.7 | 65.3 | +83.1 | 1440.7 | 263.3 |
| STOPS | 0.3 | +1.4 | 40.0 | 0.0 | - | - | - | - |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +12.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 6.3 | +261.7 | 0.0 | 67.3 | 2.0 | +25.6 | 0.0 | 70.0 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 6.3 | +261.7 | 0.0 | 67.3 | 2.0 | +25.6 | 0.0 | 70.0 |
| SURE REACH TOGETHER | 0.3 | +0.5 | 0.0 | 0.0 | 1.3 | +4.7 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 50.0 | 2.7 | +0.0 | 0.0 | 18.3 |
| THE PROMISE ADDS | - | - | - | - | 0.7 | -12.8 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 1.3 | +0.0 | 0.0 | 45.7 | 1.0 | +0.0 | 0.0 | 20.0 |
| THE ROW KEEPS ITS WAY | 1.3 | +0.0 | 0.0 | 34.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 34.7 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 30.7 | +0.0 | 0.0 | 553.0 | 59.0 | +0.0 | 0.0 | 336.3 |
| TIED UP BY THE SUM | - | - | - | - | 1.3 | +100.6 | 65.0 | 0.0 |
| TIME ON OUR SIDE | 9.0 | +252.1 | 0.0 | 86.7 | 41.0 | +357.9 | 181.3 | 75.0 |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 90.7 | 0.3 | +0.0 | 0.0 | 35.0 |
| WHO FIGHTS | 0.3 | +0.9 | 35.0 | 10.0 | 0.3 | +22.0 | 0.0 | 65.0 |
| WHO HITS BACK | 1.0 | +37.4 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 2.7 | -542.1 | 0.0 | 21.7 | 2.0 | -622.0 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | 0.3 | +3.5 | 35.0 | 10.0 | 0.7 | +64.3 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 7.7 | +735.2 | 0.0 | 181.3 | - | - | - | - |

### Rule changes: ccut-c940641-p37

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 285 | 276 | 79 | 26.33 | +835 | +10.6 |
| HIS MOVE AS HE DECIDES | 88 | 88 | 67 | 22.33 | +0 | +0.0 |
| ARMY TABLE | 95 | 95 | 62 | 20.67 | +449 | +7.2 |
| HOLDER ASSIGNMENT | 63 | 63 | 61 | 20.33 | +2829 | +46.4 |
| HIS SHOTS BY HIS RUN | 226 | 220 | 58 | 19.33 | +513 | +8.8 |
| LEGAL CHARGES ONLY | 50 | 50 | 50 | 16.67 | +0 | +0.0 |
| HIS MOVE WHY | 57 | 57 | 41 | 13.67 | +0 | +0.0 |
| SHOT RISK POINTS | 199 | 190 | 37 | 12.33 | +458 | +12.4 |
| DEPLOY BY FIGURES | 57 | 57 | 34 | 11.33 | +500 | +14.7 |
| FIVE ACTION | 600 | 589 | 30 | 10.00 | +2623 | +87.4 |
| GOAL WALK | 40 | 40 | 24 | 8.00 | +4066 | +169.4 |
| OFF BEST | 24 | 24 | 24 | 8.00 | -836 | -34.8 |
| THE TABLE AGAIN | 36 | 36 | 24 | 8.00 | +0 | +0.0 |
| HARD STAY DROPPED | 23 | 23 | 23 | 7.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 150 | 136 | 20 | 6.67 | +147 | +7.4 |
| HIS ONE MOVE | 49 | 49 | 18 | 6.00 | +0 | +0.0 |
| CANNON PLANNED TARGET | 43 | 43 | 17 | 5.67 | -22 | -1.3 |
| CASTING BLOCK | 19 | 19 | 15 | 5.00 | +192 | +12.8 |
| REDIRECT FOR A FRIEND IN REACH | 14 | 14 | 14 | 4.67 | +99 | +7.0 |
| MEETS IN TIME | 32 | 32 | 12 | 4.00 | +122 | +10.1 |
| MODEL FACING | 12 | 12 | 12 | 4.00 | +1269 | +105.8 |
| LONE WIZARD KEPT IN | 10 | 10 | 10 | 3.33 | +924 | +92.4 |
| SUPPORT ADDS | 25 | 25 | 10 | 3.33 | +245 | +24.5 |
| SUPPORT WORKED OUT | 25 | 25 | 10 | 3.33 | +245 | +24.5 |
| WOUNDS ON THE RANKS | 23 | 22 | 9 | 3.00 | +575 | +63.9 |
| CHAFF IN THE MOVE | 10 | 10 | 8 | 2.67 | +294 | +36.7 |
| PROMISE BY ITS OWN SUM | 25 | 25 | 8 | 2.67 | -306 | -38.2 |
| QUARTER ODDS | 72 | 72 | 8 | 2.67 | +978 | +122.2 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 14 | 11 | 7 | 2.33 | +391 | +55.8 |
| SET UP BY THE SET | 22 | 22 | 7 | 2.33 | +326 | +46.6 |
| CHARGE LOSSES | 79 | 76 | 6 | 2.00 | +203 | +33.9 |
| FOUR ROUNDS | 14 | 13 | 6 | 2.00 | +842 | +140.3 |
| JOINT CHARGE NOW | 6 | 6 | 6 | 2.00 | -59 | -9.8 |
| MAX FOR POSITIONING | 14 | 12 | 6 | 2.00 | +11 | +1.8 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| GUN MASK | 8 | 8 | 5 | 1.67 | +422 | +84.4 |
| MARCH BY THE SUM | 5 | 5 | 5 | 1.67 | +581 | +116.1 |
| SHOOTERS IN TWO RANKS | 5 | 5 | 5 | 1.67 | +12 | +2.4 |
| CAST JOB | 7 | 7 | 4 | 1.33 | +37 | +9.3 |
| FALLS SHORT | 74 | 55 | 4 | 1.33 | +92 | +23.0 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| MOVE ORDER | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 10 | 10 | 4 | 1.33 | +366 | +91.5 |
| RESERVE MOVE SPELL | 4 | 4 | 4 | 1.33 | +93 | +23.2 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 8 | 8 | 4 | 1.33 | +26 | +6.6 |
| TIED UP BY THE SUM | 4 | 4 | 4 | 1.33 | +164 | +41.0 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 6 | 6 | 3 | 1.00 | +24 | +7.9 |
| RISK BY ARC | 13 | 12 | 3 | 1.00 | +61 | +20.3 |
| SHOTS IN THE MOVE | 147 | 122 | 3 | 1.00 | +26 | +8.8 |
| SURE REACH TOGETHER | 5 | 4 | 3 | 1.00 | +0 | +0.0 |
| THE RISK READS HIS RUN | 18 | 18 | 3 | 1.00 | +0 | +0.0 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +44 | +14.6 |
| FEATURE BUFFS | 43 | 43 | 2 | 0.67 | +58 | +28.8 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HUNT IN PAIRS | 6 | 5 | 2 | 0.67 | +159 | +79.7 |
| IDLE COST | 47 | 37 | 2 | 0.67 | +7 | +3.3 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +55 | +27.4 |
| MANOEUVRE | 7 | 7 | 2 | 0.67 | +16 | +8.2 |
| MISSILES IN THE MOVE | 24 | 21 | 2 | 0.67 | +28 | +14.2 |
| OPENS A LANE | 6 | 4 | 2 | 0.67 | +18 | +8.9 |
| OVERRUNS AWAY | 5 | 5 | 2 | 0.67 | +51 | +25.5 |
| REDIRECT WEIGHED | 2 | 2 | 2 | 0.67 | +278 | +138.9 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +8 | +3.9 |
| SEARCH SPOT | 3 | 3 | 2 | 0.67 | +26 | +13.1 |
| STAY WORTH | 209 | 198 | 2 | 0.67 | +1 | +0.5 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +351 | +350.9 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -14 | -14.4 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +18 | +18.3 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FRIEND SHOOTS FIRST | 4 | 4 | 1 | 0.33 | +2 | +2.5 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | -0 | -0.2 |
| HIS MOVE AND SHOT | 22 | 22 | 1 | 0.33 | +1 | +1.3 |
| HIS TURN DENIED | 6 | 6 | 1 | 0.33 | +37 | +36.6 |
| MARCH CHECK | 3 | 3 | 1 | 0.33 | +1 | +1.3 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| ONE JOINT FIGURE | 4 | 3 | 1 | 0.33 | +196 | +195.7 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +9 | +8.8 |
| PROMISE READS THE TABLE | 2 | 2 | 1 | 0.33 | +12 | +11.7 |
| REDIRECT COUNTER | 10 | 6 | 1 | 0.33 | +46 | +46.4 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +12 | +11.9 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +36 | +36.1 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -30 | -29.5 |
| THE ROW IN ITS ORDER | 7 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 14 | 14 | 1 | 0.33 | +11 | +11.2 |
| WHOLE FIGHT GAIN | 3 | 3 | 1 | 0.33 | +5 | +4.7 |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 14 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 21 | 21 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 6 | 6 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 52 | 50 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 17 | not checked | - | - | - | - |
| COVER ONCE | 35 | 23 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 3 | 3 | 0 | 0.00 | - | - |
| EXACT ROUND | 8 | 7 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 10 | 9 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 7 | 7 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 22 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 6 | 6 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 6 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 3 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 49 | 46 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | not checked | - | - | - | - |
| HIS CHARGE LIST | 50 | 50 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 16 | 15 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 12 | 12 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 16 | 16 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 22 | 20 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 146 | 146 | 0 | 0.00 | - | - |
| HONEST WORTH | 12 | 12 | 0 | 0.00 | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| KEPT FROM ITS LAST STOP | 19 | 19 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 4 | 4 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 9 | 8 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 28 | 21 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 9 | not checked | - | - | - | - |
| MOVE SPELL IN RANGE | 1 | 1 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 8 | trace | - | - | - | - |
| MOVE SPELL SPOT | 8 | not checked | - | - | - | - |
| NEARER NOT NEEDED | 39 | 38 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 14 | 13 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 26 | 17 | 0 | 0.00 | - | - |
| ONE OBJECTIVE FORMULA | 33 | 20 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 266 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 4 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 1 | 1 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 4 | 4 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 6 | 6 | 0 | 0.00 | - | - |
| RUN DOWN | 12 | 11 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 18 | 18 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 94 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 14 | 14 | 0 | 0.00 | - | - |
| SPELL OFF EDGE | 2 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 3 | not checked | - | - | - | - |
| SPELL WORTH | 3 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 26 | 25 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 6 | 6 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 17 | 15 | 0 | 0.00 | - | - |
| STANDS STILL | 336 | 333 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 12 | not checked | - | - | - | - |
| THE PROMISE ADDS | 2 | 2 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 8 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 8 | not checked | - | - | - | - |
| THE TABLE BINDS | 269 | not checked | - | - | - | - |
| WAITS AGAIN | 5 | 5 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p37

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 1.00 | 6.00 | 30.0 |
| ARMY TABLE | rule | 1.67 | 3.33 | 41.4 |
| PROMISE BY ITS OWN SUM | rule | 0.33 | 2.33 | 38.2 |
| HOLDER ASSIGNMENT | rule | 1.67 | 0.67 | 12.7 |
| CANNON PLANNED TARGET | rule | - | 1.00 | 7.3 |
| JOINT CHARGE NOW | rule | - | 0.67 | 140.1 |
| AFTERMATH BAND | gate | 0.33 | - | 2.2 |
| BEST PRIZE | rule | - | 0.33 | 14.4 |
| NO REASON | gate | 0.33 | - | 29.1 |
| RESERVE FALL BACK | rule | - | 0.33 | 22.1 |
| RULE SWITCHED OFF | gate | - | 0.33 | 174.5 |
| SUPPORT NARROWED | rule | - | 0.33 | 29.5 |
| WHO HITS BACK | rule | 0.33 | - | 2.2 |

### Plans: ccut-c940641-p37

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 100% | 36 | 110 | 308% |
| Mine | move | 24.7 | 93% | 2627 | 0 | 0% |
| Mine | shoot | 3.7 | 36% | 417 | 59 | 14% |
| Opponent | charge | 3.3 | 40% | 441 | 97 | 22% |
| Opponent | move | 33.0 | 95% | 1122 | 0 | 0% |
| Opponent | shoot | 22.7 | 88% | 531 | 1180 | 222% |
| Opponent | support | 0.3 | 100% | 17 | 0 | 0% |

### Packages: hunt the guns, ccut-c940641-p37

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.3 | 1 | 0 | 100% | 100% | 0% | 2.0 | 129 | 126 | 100% | 135 |
| Opponent | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.3 | 1 | 0 | 100% | 100% | 0% | 2.0 | 129 | 126 | 100% | 135 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: ccut-c940641-p37

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.3 | 29% | 50% | 0% | - | 100% | 0% | 0% | 0% | 0% |
| Opponent | REDIRECT COUNTER | 1.0 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p37

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 4 | 12 (4) | 12 | 0 | 50 | 25% | 3.0 | 31 (2) | - | 0 (2) | 16 (3) | 0 (1) |
| Mine | Character | 15 | 19 (15) | 19 | 0 | 17 | 33% | 2.9 | - | 28 (8) | 0 (2) | 18 (6) | 25 (4) |
| Mine | Clean-up | 3 | 128 (3) | 128 | 0 | 67 | 33% | 3.5 | 0 (1) | 191 (2) | - | 128 (3) | - |
| Mine | Fast Hammer | 2 | 0 (2) | 0 | 0 | 100 | 100% | - | 0 (2) | - | - | 0 (1) | 0 (1) |
| Mine | Hammer | 6 | 65 (6) | 9 | 56 | 16 | 67% | 3.5 | 35 (1) | 74 (3) | 59 (2) | 57 (4) | 78 (2) |
| Mine | Holder | 5 | 0 (5) | 0 | 0 | 0 | 60% | 3.5 | 0 (4) | - | 0 (1) | 0 (1) | 0 (4) |
| Mine | Shooter | 2 | 77 (2) | 0 | 77 | 100 | 0% | 1.0 | - | 154 (1) | 0 (1) | 77 (2) | - |
| Mine | Wizard | 3 | 0 (3) | 0 | 0 | 27 | 33% | 2.0 | - | - | 0 (1) | 0 (1) | - |
| Opponent | Chaff | 2 | 139 (2) | 0 | 139 | 50 | 0% | 1.5 | 278 (1) | 0 (1) | - | 139 (2) | - |
| Opponent | Character | 8 | 34 (8) | 34 | 0 | 0 | 25% | 2.8 | 0 (1) | 39 (6) | 0 (1) | 46 (4) | 28 (4) |
| Opponent | Clean-up | 6 | 7 (6) | 7 | 0 | 23 | 17% | 2.4 | 0 (1) | 11 (5) | - | 10 (5) | 0 (1) |
| Opponent | Fast Hammer | 4 | 11 (4) | 11 | 0 | 47 | 25% | 3.0 | 0 (1) | 33 (1) | 0 (2) | 14 (3) | 0 (1) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 0 | 67% | 3.0 | 0 (1) | 0 (1) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Shooter | 10 | 66 (10) | 24 | 43 | 9 | 20% | 2.1 | 87 (2) | 65 (8) | - | 79 (8) | 33 (2) |
| Opponent | War machine | 12 | 33 (12) | 33 | 0 | 28 | 8% | 1.9 | 35 (10) | - | 23 (2) | 0 (2) | 41 (10) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (2) | - | - | 0 (2) |

### Charged fights: ccut-c940641-p37

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 126 | 75 | 0.7 | 1.5 | 112 | 0 | +112 | 0 of 2 | 2 of 2 | +105 | +120 |
| Opponent | Dwarfen Mountain Holds | 2 | 486 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 2 | 0 of 2 | - | +0 |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 225 | 4.0 | 1.0 | 56 | 49 | +8 | 4 of 4 | 0 of 4 | - | +8 |
| **Opponent** | all armies | 3 | 324 | 75 | 2.0 | 1.0 | 38 | 32 | +5 | 4 of 6 | 0 of 6 | - | +5 |

### Effective charges: ccut-c940641-p37

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 0 | 0 | 0 | 2 (net +112) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Dwarfen Mountain Holds | 2 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Opponent | Tomb Kings of Khemri | 4 | 2 (net -98) | 0 | 0 | 0 | 0 | 1 (net +225) | 1 | 0% (0 of 3) |

### Charged fights, damage counted: ccut-c940641-p37

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 76-89% | 2 | 67 | 112 | +112 | 130 | 12 | +118 | +176.6 |
| Mine | All fights | 2 | 67 | 112 | +112 | 130 | 12 | +118 | +176.6 |
| Opponent | Long shot (under 50%) | 2 | 313 | 322 | -98 | 0 | 98 | -98 | -31.2 |
| Opponent | Effective (55-75%) | 1 | 60 | 55 | +0 | 22 | 20 | +2 | +3.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 431 | 322 | +225 | 225 | 0 | +225 | +52.2 |
| Opponent | No odds | 2 | 122 | 187 | +0 | 55 | 40 | +14 | +11.7 |
| Opponent | All fights | 6 | 227 | 232 | +5 | 59 | 49 | +10 | +4.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p37 | move | 18 | 2 (11%) | 0 (0%) | 1 (6%) | 15 (83%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122 |
| Ring of Doom | Mine | L0206 |

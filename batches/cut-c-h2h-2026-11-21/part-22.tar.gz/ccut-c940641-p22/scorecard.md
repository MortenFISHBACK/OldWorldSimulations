# Doctrine scorecard: ccut-c940641-p22

### Scorecard: ccut-c940641-p22

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1827 | 3 | 1 | Mine | - | - | - | - | - | - | - | - | - |
| L1827 | 3 | 1 | Opponent | - | - | - | - | - | - | - | - | - |
| L1927 | 1 | 1 | Mine | no | 2 | 1 | 4 | 0 | 1 | 0 | 0 | 255 |
| L1927 | 1 | 1 | Opponent | no | 2 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 420 |
| L2029 | 1 | 1 | Opponent | no | 4 | 2 | 3 | 5 | 0 | 0 | 0 | 170 |
| **Average** | | | Mine | 0% | 1.0 | 1.0 | 2.0 | 1.0 | 0.5 | 0.0 | 0.0 | 337.5 |
| **Average** | | | Opponent | 0% | 3.0 | 2.0 | 3.0 | 4.0 | 0.0 | 0.0 | 0.0 | 85.0 |

### KPIs: ccut-c940641-p22

Rules off - Mine only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 10) | 0% (0 of 11) | 0% (0 of 21) |
| Winner chose to follow up after the loser gave ground |  | 100% (1 of 1); on the table 100% | 100% (4 of 4); on the table 100% | 100% (5 of 5); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 100% (2 of 2); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (1 of 1); on the table 100% | 100% (7 of 7); on the table 100% | 100% (8 of 8); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 37% (7 of 19) | 12% (1 of 8) | 30% (8 of 27) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 54% (7 of 13) | 12% (1 of 8) | 38% (8 of 21) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 50% (3 of 6) | 33% (2 of 6) | 42% (5 of 12) |
| Points that never fought | lower | 17% (684 of 3999) | 45% (1780 of 3999) | 31% (2464 of 7998) |
|   infantry points that never fought | lower | 54% (454 of 836) | 91% (565 of 619) | 70% (1019 of 1455) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 67% (10 of 15) | 46% (6 of 13) | 57% (16 of 28) |
| Bound items with a magic missile used (at least once a game) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (1 of 2); 0.3 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 62% (2152 of 3466) | 36% (1220 of 3430) | 49% (3372 of 6896) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (17%) | 2.3 (100%) | 3.0 (47%) |
| MARCHED: its unit marched | 1.0 (25%) | 0.0 (0%) | 1.0 (16%) |
| IN COMBAT: engaged in combat | 2.0 (50%) | 0.0 (0%) | 2.0 (32%) |
| NOT OFFERED: not in the cast list | 0.3 (8%) | 0.0 (0%) | 0.3 (5%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 3.0 | 1.7 | 2.7 | 0.7 | 3.0 |
| not cast | 6.3 | 5.3 | 6.3 | 2.0 | 20.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 3.0 (47%) | 1.0 (50%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.0 (16%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 2.0 (32%) | 0.0 (0%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.7 (11%) | 0.3 (6%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (10%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 1.0 (19%) | 0.0 (0%) | 1.0 (50%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.3 (5%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 5.7 (89%) | 4.0 (75%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 16.3 (82%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 0.7 a game | 0.8 a game |
| stood (cast and not dispelled) | 0% (0 of 3) | 0% (0 of 2) | 0% (0 of 5) |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 92% (11 of 12) | 0% (0 of 6) | 61% (11 of 18) |
|   cavalry | - | 0% (0 of 2) | 0% (0 of 2) |
|   character | - | 0% (0 of 4) | 0% (0 of 4) |
|   infantry | 92% (11 of 12) | - | 92% (11 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.0 (0%) | 0.3 (17%) | 0.3 (14%) |
| CHARGED: it charged | 0.0 (0%) | 1.0 (50%) | 1.0 (43%) |
| NO TARGET IN RANGE | 0.3 (100%) | 0.7 (33%) | 1.0 (43%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| infantry | 3.7 | 1.3 | 64% | 11.1 pts | 41 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.0 | 3.3 | 2.7 |
| Charges that made contact a game | 1.7 | 2.0 | 1.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (3 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 1.00 contact (2 units) | 1.00 declared, 1.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.21 declared, 0.18 contact (28 units) | 0.31 declared, 0.15 contact (26 units) | 0.26 declared, 0.17 contact (54 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 0% (0 of 2) | 67% (2 of 3) | 0% (0 of 1) | 33% (2 of 6) |
| Character in a unit | 75% (3 of 4) | 100% (1 of 1) | - | 80% (4 of 5) |
| Character on its own | 100% (2 of 2) | - | 40% (2 of 5) | 57% (4 of 7) |
| Infantry | 75% (3 of 4) | 0% (0 of 1) | - | 60% (3 of 5) |
| Monster | 0% (0 of 1) | 100% (2 of 2) | - | 67% (2 of 3) |
| Monstrous | - | 50% (1 of 2) | - | 50% (1 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Orc & Goblin Tribes | 1 | 100% (1 of 1); on the table 100% | 25% (3 of 12) | 0% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | - | 67% (4 of 6) | 34% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 1 | 100% (6 of 6); on the table 100% | 0% (0 of 6) | 22% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (1 of 1); on the table 100% | - | 67% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p22, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 40% (2) | 50% (2) | 44% (4) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.67 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.67 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.33 | 0.00 | 0.33 |

### Quality by phase: ccut-c940641-p22

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.7 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 0% (0 of 1) | 56% (5 of 9) |
| Strategy | Shoot objectives carried out (shot that target) | 67% (2 of 3) | 0% (0 of 2) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 0% (0 of 2) | - |
| Strategy | Joined characters whose unit fought | 100% (4 of 4) | 0% (0 of 2) |
| Strategy | Lone characters that fought | 75% (3 of 4) | 83% (5 of 6) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 1.0 | 4.0 |
| Movement | Points that never moved of their own | 337.5 | 85.0 |
| Movement | Fights charged into per game | 2.0 | 2.5 |
| Movement | Charges with odds: long shots (under 50%) | - | 2 of 5, net -496 |
| Movement | Charges with odds: sweet spot (55-75%) | - | 0 of 5 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | - | 1 of 5, net +38 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | - | 2 of 5, net +245 |
| Shooting | Shots by shooting units (incl. breath weapons) | 3.7 | 0.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 55% (6 of 11) | 0% (0 of 2) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 2.3 | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 14% (1 of 7) | 0% (0 of 1) |
| Magic | Wounds caused by magic missiles | 2.7 | - |
| Magic | Wounds caused by other spells | 0.3 | - |
| Magic | Points destroyed by magic (all spells) | 10.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.7 / 0.0 / 1.0 / 0.0 | 0.7 / 0.0 / 0.7 / 0.0 |
| Combat | Points destroyed in combat | 570.0 | 364.3 |
| Combat | Points run down | 0.0 | 78.3 |
| Combat | Net points per charged fight, damage counted | +73 | -97 |
| Combat | Net per 100 charger points, damage counted | +36.4 | -27.0 |
| Combat | First round won (charged fights) | 25% | 60% |
| Combat | Net points per charged fight | +78 | -93 |
| Combat | Net points per supported fight / lone fight | - / +78 | - / -93 |
| Combat | Charged fights on a top-3 enemy unit | 2 of 4 | 3 of 5 |
| Game | Points lost | 1040.0 | 745.0 |
| Game | VP from objectives | 310.0 | 1025.0 |
| Game | Lone holders (player turns) | 1.0 | 3.0 |

- Mine won / drew / lost: 0 / 1 / 1 of 2 ended games (of 3); mean margin (Mine - Opponent) -910 VP
- The side that went first won 1 of 1 games with a winner
- Points traded per game (both sides' losses): 1785
- Games not ended: 1 (L1827-1); findings 2, warnings 0

### Opponent rules: ccut-c940641-p22

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 22.3 | -149.9 | 0.0 | 464.3 | 14.3 | +343.3 | 0.0 | 62.7 |
| ASSAILMENT BY POINTS | 0.3 | +0.4 | 0.0 | 0.0 | 0.7 | +9.7 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.3 | -5.4 | 70.0 | 0.0 |
| CAST JOB | 0.7 | +2.8 | 10.0 | 0.0 | 0.7 | +2.1 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 0.3 | +1.2 | 18.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.0 | +18.3 | 0.0 | 0.0 |
| CHAFF PASSED | 0.7 | -4.2 | 0.0 | 21.7 | - | - | - | - |
| CHALLENGE BY POINTS | 0.7 | +45.1 | 0.0 | 0.0 | 0.3 | +15.9 | 0.0 | 16.7 |
| CHARGE LOSSES | 5.7 | -547.3 | 0.0 | 304.0 | 7.7 | -657.3 | 0.0 | 410.7 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 241.7 | 314.3 |
| CLOSES ON WHAT IT BEATS | 3.0 | +0.0 | 0.0 | 121.7 | 19.0 | +0.0 | 0.0 | 50.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 116.7 | 0.3 | +0.0 | 0.0 | 190.3 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.7 | +60.7 | 64.0 | 31.7 | 0.7 | +10.2 | 0.0 | 0.0 |
| COVER ONCE | 4.3 | -173.7 | 0.0 | 142.3 | 1.0 | -17.3 | 0.0 | 62.0 |
| DEPLOY BY FIGURES | 8.0 | -112.9 | 0.0 | 0.0 | 7.0 | +58.5 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -119.5 | 0.0 | 190.3 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +27.0 | 0.0 | 0.0 |
| EXACT ROUND | 0.3 | +2.5 | 0.0 | 0.0 | 2.0 | -4.7 | 241.7 | 314.3 |
| FALL BACK GOOD ORDER | - | - | - | - | 1.7 | +0.0 | 254.3 | 442.7 |
| FALLS SHORT | - | - | - | - | 13.7 | +179.3 | 0.0 | 205.3 |
| FEATURE BUFFS | 0.3 | +1.5 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.3 | +1.0 | 0.0 | 0.0 | 2.0 | +190.9 | 241.7 | 504.7 |
| FIVE ACTION | 48.0 | +3774.4 | 28.0 | 866.7 | 71.3 | +5084.0 | 254.3 | 1334.7 |
| FLANK NOT WEIGHED | 8.0 | +0.0 | 0.0 | 200.7 | 1.3 | +0.0 | 0.0 | 10.0 |
| FOLLOW UP WEIGHED | - | - | - | - | 1.3 | +234.7 | 0.0 | 62.0 |
| FOUR ROUNDS | 0.3 | +18.8 | 0.0 | 0.0 | 3.3 | +401.4 | 254.3 | 504.7 |
| FREED FROM HIS FIGHT | 4.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FRIEND SHOOTS FIRST | 0.3 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | - | - | - | - | 0.3 | -2.9 | 0.0 | 0.0 |
| GOAL WALK | 13.0 | +1534.0 | 0.0 | 315.0 | 8.7 | +1175.9 | 0.0 | 0.0 |
| GUN FIGURES | 3.3 | +1.9 | 10.0 | 43.3 | - | - | - | - |
| HE REFORMS ONCE FREED | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE BY HIS RUN | 3.3 | +0.0 | 0.0 | 304.0 | 2.7 | +0.0 | 0.0 | 410.7 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +11.4 | 0.0 | 0.0 |
| HIS CHARGE LIST | 3.0 | +0.0 | 0.0 | 156.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 2.0 | +0.0 | 0.0 | 135.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 1.0 | -19.0 | 0.0 | 0.0 | 3.7 | -52.1 | 0.0 | 0.0 |
| HIS MOVE AS HE DECIDES | 32.0 | +8.3 | 610.3 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 38.3 | +0.0 | 0.0 | 924.7 |
| HIS ONE MOVE | 13.7 | -104.9 | 0.0 | 151.0 | - | - | - | - |
| HIS ONE QUARTER | 0.7 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 1.3 | +0.0 | 0.0 | 18.3 | 7.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 14.3 | +0.0 | 0.0 | 214.7 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVER COMES | 2.3 | +0.0 | 0.0 | 128.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 4.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 3.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 5.3 | +85.9 | 0.0 | 0.0 | 23.3 | +292.0 | 0.0 | 435.3 |
| HIS SHOTS BY HIS RUN | 9.0 | +91.0 | 0.0 | 165.3 | 18.7 | +253.8 | 0.0 | 414.7 |
| HIS TURN DENIED | - | - | - | - | 0.3 | +3.3 | 0.0 | 0.0 |
| HIS TURN RUN | 4.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 10.3 | +0.0 | 0.0 | 55.0 | 10.3 | +0.0 | 0.0 | 573.3 |
| HOLDER ASSIGNMENT | 7.7 | +810.7 | 0.0 | 36.7 | 7.3 | +856.1 | 0.0 | 286.7 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 0.3 | -1.2 | 0.0 | 0.0 | 3.3 | -163.5 | 254.3 | 504.7 |
| IDLE COST | - | - | - | - | 16.3 | -196.9 | 0.0 | 33.3 |
| JOINT CHARGE NOW | - | - | - | - | 0.3 | -6.3 | 78.3 | 0.0 |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +9.3 | 0.0 | 0.0 | 1.3 | +47.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.3 | +0.0 | 331.0 | 285.0 | 3.3 | +0.0 | 302.7 | 80.0 |
| LONE WIZARD KEPT IN | 0.3 | +7.9 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | - | - | - | - | 1.0 | +3.8 | 85.0 | 190.3 |
| MANOEUVRE | 1.0 | +1.4 | 0.0 | 21.7 | 0.7 | +1.7 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.7 | +180.5 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.3 | +7.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.7 | -14.6 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.3 | +150.7 | 0.0 | 36.7 | 1.7 | +29.9 | 0.0 | 0.0 |
| MEETS IN TIME | 5.0 | +381.2 | 0.0 | 0.0 | 3.3 | +411.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.3 | +37.9 | 0.0 | 0.0 | 1.3 | +3.4 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 2.7 | +19.1 | 0.0 | 0.0 | 1.7 | +1.9 | 0.0 | 0.0 |
| MOVE ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 3.0 | +165.7 | 0.0 | 116.7 | 7.7 | +723.4 | 0.0 | 62.0 |
| MOVES UNITS SPELL | 0.3 | +1.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 6.0 | +245.7 | 0.0 | 155.0 | 4.0 | +169.8 | 0.0 | 143.3 |
| NEXT CHARGE BY LIST | 1.3 | +84.0 | 18.0 | 0.0 | 2.7 | +364.5 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 0.3 | -16.0 | 0.0 | 0.0 | 3.0 | -72.2 | 254.3 | 314.3 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 4.7 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 4.7 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT WORTH A CAST | 0.7 | -0.5 | 0.0 | 0.0 | 2.0 | -0.7 | 0.0 | 0.0 |
| OFF BEST | 1.7 | -60.5 | 0.0 | 0.0 | 2.3 | -60.0 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 2.0 | -5.6 | 0.0 | 0.0 | 4.3 | -116.0 | 0.0 | 143.3 |
| ONE OBJECTIVE FORMULA | 1.3 | +34.3 | 0.0 | 0.0 | 1.3 | +5.2 | 0.0 | 143.3 |
| ONE PROMISE A TARGET | - | - | - | - | 0.7 | -16.3 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.7 | +58.0 | 12.7 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.7 | +4.2 | 0.0 | 190.3 |
| PERIAPT WORTH | 0.3 | +18.1 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 23.0 | +18.0 | 18.0 | 958.3 | 32.3 | +254.3 | 70.0 | 814.3 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 4.7 | -107.1 | 0.0 | 116.7 | 11.3 | -391.5 | 0.0 | 62.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 62.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.3 | -13.1 | 0.0 | 0.0 |
| QUARTER ODDS | 7.3 | +918.9 | 10.0 | 0.0 | 17.7 | +2482.5 | 12.7 | 342.7 |
| RANDOM MOVE BY FIGURES | 2.0 | +94.2 | 0.0 | 140.0 | 2.0 | +25.1 | 0.0 | 0.0 |
| REAL GROUND | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.7 | +55.5 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 2.3 | +147.3 | 0.0 | 36.7 | 2.3 | +111.2 | 0.0 | 10.0 |
| REDIRECT FOR A FRIEND IN REACH | 2.7 | +93.7 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 20.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | -5.4 | 70.0 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -13.4 | 0.0 | 0.0 | 1.3 | -5.9 | 0.0 | 0.0 |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 62.0 |
| RISK BY ARC | 0.3 | +1.6 | 0.0 | 0.0 | 3.0 | +65.9 | 254.3 | 504.7 |
| ROUNDS AFTER TERROR | - | - | - | - | 2.3 | -73.0 | 254.3 | 504.7 |
| RUN DOWN | - | - | - | - | 2.7 | -15.7 | 254.3 | 504.7 |
| SCOUT SPOT | 0.7 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.0 | -101.3 | 0.0 | 10.0 |
| SEARCH SPOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +17.0 | 0.0 | 0.0 |
| SELF MOVE SPELL | 2.0 | -4.2 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 0.7 | -2.1 | 0.0 | 10.0 |
| SET UP BY THE SET | 0.7 | +13.1 | 0.0 | 0.0 | 1.3 | -4.8 | 0.0 | 10.0 |
| SET-UP ANY TARGET | 0.3 | +16.0 | 64.0 | 31.7 | - | - | - | - |
| SHOOTERS ON THE TABLE | 2.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 10.0 |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 0.7 | +14.5 | 0.0 | 0.0 |
| SHOT RISK POINTS | 3.0 | -24.6 | 0.0 | 12.7 | 14.3 | -111.4 | 0.0 | 110.0 |
| SHOTS AFTER THE MOVES | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 4.0 | +67.4 | 0.0 | 43.3 | 0.3 | +7.2 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.3 | +16.0 | 64.0 | 31.7 | - | - | - | - |
| SPELL WORTH | 1.3 | +28.8 | 0.0 | 0.0 | 0.7 | +5.7 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | - | - | - | - | 0.3 | +2.7 | 85.0 | 190.3 |
| SPOT AS THE GAME MOVES | 7.3 | +0.0 | 0.0 | 359.3 | 6.0 | +0.0 | 0.0 | 0.0 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -7.0 | 0.0 | 0.0 |
| STANDS STILL | 14.0 | +0.0 | 28.0 | 140.0 | 15.0 | +0.0 | 0.0 | 306.7 |
| STAY WORTH | 4.7 | +14.4 | 10.0 | 43.3 | - | - | - | - |
| STRIKE BY THE ODDS | 1.0 | +5.2 | 430.0 | 0.0 | 0.7 | +3.9 | 0.0 | 124.0 |
| STUBBORN BY POINTS | 0.3 | +31.4 | 0.0 | 0.0 | - | - | - | - |
| STUPIDITY NEXT TURN | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 5.3 | +494.6 | 0.0 | 12.7 | 2.0 | +34.5 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 62.0 |
| SUPPORT WORKED OUT | 5.3 | +494.6 | 0.0 | 12.7 | 2.0 | +34.5 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +0.7 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -13.3 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 3.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 3.7 | +0.0 | 0.0 | 78.3 | 3.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 64.0 | 3.0 | +0.0 | 0.0 | 62.0 |
| THE ROW READS HIS LAST RUN | 0.7 | +0.0 | 0.0 | 12.7 | - | - | - | - |
| THE STEP BACK IS MADE | 2.0 | +0.0 | 0.0 | 21.7 | 2.3 | +0.0 | 0.0 | 62.0 |
| THE TABLE AGAIN | 3.7 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 20.7 | +0.0 | 0.0 | 253.3 | 35.0 | +0.0 | 0.0 | 420.0 |
| TIED UP BY THE SUM | 0.3 | +5.3 | 0.0 | 0.0 | 1.3 | +158.6 | 91.0 | 62.0 |
| TIME ON OUR SIDE | 22.3 | +278.3 | 0.0 | 253.3 | - | - | - | - |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 153.3 | 1.0 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -55.7 | 0.0 | 380.7 |
| WHO FIGHTS | - | - | - | - | 0.7 | +59.0 | 78.3 | 124.0 |
| WHO GETS IN | - | - | - | - | 0.3 | -6.3 | 78.3 | 0.0 |
| WHO HITS BACK | - | - | - | - | 0.3 | +53.9 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | -0.5 | 0.0 | 190.3 |
| WHOLE FIGHT DANGER | 4.0 | -497.3 | 0.0 | 291.3 | 1.0 | -417.9 | 0.0 | 348.7 |
| WOUNDS ON THE RANKS | 0.3 | +6.0 | 0.0 | 0.0 | 1.3 | +23.6 | 0.0 | 0.0 |

### Rule changes: ccut-c940641-p22

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE WHY | 115 | 115 | 81 | 27.00 | +0 | +0.0 |
| HIS MOVE AS HE DECIDES | 96 | 96 | 71 | 23.67 | +0 | +0.0 |
| ARMY TABLE | 110 | 110 | 67 | 22.33 | +1347 | +20.1 |
| HOLDER ASSIGNMENT | 45 | 45 | 39 | 13.00 | +2921 | +74.9 |
| DEPLOY BY FIGURES | 45 | 45 | 26 | 8.67 | +294 | +11.3 |
| LEGAL CHARGES ONLY | 23 | 23 | 23 | 7.67 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 48 | 48 | 22 | 7.33 | -1496 | -68.0 |
| FIVE ACTION | 358 | 344 | 20 | 6.67 | +757 | +37.8 |
| THE TABLE AGAIN | 25 | 25 | 18 | 6.00 | +0 | +0.0 |
| GOAL WALK | 65 | 64 | 15 | 5.00 | +1479 | +98.6 |
| HIS SHOT LIST | 86 | 81 | 15 | 5.00 | +47 | +3.1 |
| MOVE TO CHARGE COMPUTED | 32 | 25 | 15 | 5.00 | +305 | +20.3 |
| HIS ONE MOVE | 41 | 40 | 14 | 4.67 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 14 | 14 | 14 | 4.67 | +154 | +11.0 |
| HIS SHOTS BY HIS RUN | 83 | 77 | 12 | 4.00 | +57 | +4.8 |
| OFF BEST | 12 | 12 | 12 | 4.00 | -362 | -30.1 |
| IDLE COST | 49 | 35 | 11 | 3.67 | +42 | +3.8 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| QUARTER ODDS | 75 | 74 | 10 | 3.33 | +1160 | +116.0 |
| SUPPORT ADDS | 22 | 21 | 8 | 2.67 | +255 | +31.9 |
| SUPPORT WORKED OUT | 22 | 21 | 8 | 2.67 | +255 | +31.9 |
| MEETS IN TIME | 25 | 25 | 7 | 2.33 | +441 | +63.0 |
| FOUR ROUNDS | 11 | 11 | 6 | 2.00 | +735 | +122.5 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +171 | +34.2 |
| MAX FOR POSITIONING | 12 | 12 | 5 | 1.67 | +30 | +5.9 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 5 | 1.67 | +358 | +71.6 |
| REDIRECT COUNTER | 14 | 10 | 5 | 1.67 | +254 | +50.9 |
| STRIKE BY THE ODDS | 5 | 5 | 5 | 1.67 | +28 | +5.5 |
| ADVANCE LANE KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +704 | +176.1 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| THE RISK READS HIS RUN | 11 | 11 | 4 | 1.33 | +0 | +0.0 |
| ASSAILMENT BY POINTS | 3 | 3 | 3 | 1.00 | +30 | +10.1 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +183 | +60.9 |
| CHARGE NOW FIRST | 6 | 6 | 3 | 1.00 | -83 | -27.7 |
| MISSILES IN THE MOVE | 11 | 5 | 3 | 1.00 | +11 | +3.6 |
| NEARER NOT NEEDED | 30 | 27 | 3 | 1.00 | +53 | +17.5 |
| NEXT CHARGE BY LIST | 12 | 10 | 3 | 1.00 | +125 | +41.8 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SHOT RISK POINTS | 52 | 49 | 3 | 1.00 | +12 | +3.8 |
| TIED UP BY THE SUM | 5 | 5 | 3 | 1.00 | +179 | +59.6 |
| TIME ON OUR SIDE | 67 | 53 | 3 | 1.00 | +19 | +6.4 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 3 | 3 | 2 | 0.67 | +0 | +0.0 |
| CHAFF PASSED | 2 | 2 | 2 | 0.67 | -13 | -6.3 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MANOEUVRE | 5 | 5 | 2 | 0.67 | +9 | +4.6 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +542 | +270.8 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -49 | -24.5 |
| RISK BY ARC | 10 | 10 | 2 | 0.67 | +172 | +86.2 |
| SHOOTS FROM THE BEST SPOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SUPPORT NARROWED | 4 | 4 | 2 | 0.67 | -20 | -9.8 |
| THE ROW IN ITS ORDER | 22 | 2 | 2 | 0.67 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 5 | 5 | 2 | 0.67 | +42 | +20.8 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -16 | -16.2 |
| CAST JOB | 4 | 4 | 1 | 0.33 | +0 | +0.0 |
| CASTING BLOCK | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE LOSSES | 40 | 36 | 1 | 0.33 | +7 | +7.3 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| COVER ONCE | 16 | 9 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +40 | +39.6 |
| FIGHT TO THE END | 7 | 7 | 1 | 0.33 | +406 | +405.9 |
| HIS CHARGE DENIED | 1 | 1 | 1 | 0.33 | +19 | +19.4 |
| HIS MOVE AND SHOT | 14 | 13 | 1 | 0.33 | +5 | +4.6 |
| JOINT CHARGE NOW | 1 | 1 | 1 | 0.33 | -19 | -18.8 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +24 | +23.8 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| ONE FIGHT FORMULA | 19 | 11 | 1 | 0.33 | +1 | +1.1 |
| OPENS UP | 2 | 2 | 1 | 0.33 | +27 | +27.4 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +54 | +54.4 |
| PROMISE READS THE TABLE | 1 | 1 | 1 | 0.33 | -36 | -35.9 |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 1 | 0.33 | +57 | +57.2 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +291 | +291.1 |
| REFUSING RETIRES | 3 | 3 | 1 | 0.33 | -3 | -3.3 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +51 | +51.1 |
| SET UP BY THE SET | 6 | 6 | 1 | 0.33 | +30 | +30.0 |
| SHOTS IN THE MOVE | 13 | 10 | 1 | 0.33 | +6 | +6.2 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +94 | +94.2 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO FIGHTS | 2 | 2 | 1 | 0.33 | +116 | +116.3 |
| WHO GETS IN | 1 | 1 | 1 | 0.33 | -19 | -18.8 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +84 | +83.7 |
| WHOLE FIGHT DANGER | 15 | 13 | 1 | 0.33 | +74 | +73.6 |
| CLOSES ON WHAT IT BEATS | 66 | 66 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 4 | not checked | - | - | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| EXACT ROUND | 7 | 7 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 5 | 5 | 0 | 0.00 | - | - |
| FALLS SHORT | 41 | 33 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 28 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 12 | 10 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 10 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 6 | 6 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 18 | 16 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 10 | 10 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 21 | 20 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 17 | 16 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 26 | 23 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 52 | 50 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 9 | 9 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 27 | 27 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 11 | 11 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS TURN RUN | 28 | 28 | 0 | 0.00 | - | - |
| HOLD ODDS | 62 | 61 | 0 | 0.00 | - | - |
| HONEST WORTH | 11 | 11 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 8 | 8 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 3 | 3 | 0 | 0.00 | - | - |
| MARCH CHECK | 1 | 1 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 2 | 2 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 3 | 3 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 13 | 8 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 10 | 10 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 14 | 14 | 0 | 0.00 | - | - |
| NO SECOND RUN | 14 | 14 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 8 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 8 | 4 | 0 | 0.00 | - | - |
| ONE ROUTE | 3 | 3 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 166 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 5 | 3 | 0 | 0.00 | - | - |
| REAL GROUND | 3 | 3 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 6 | 4 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 7 | 7 | 0 | 0.00 | - | - |
| RUN DOWN | 8 | 8 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SEARCH SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 11 | not checked | - | - | - | - |
| SHOTS AFTER THE MOVES | 4 | 4 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 6 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 40 | 32 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS STILL | 87 | 83 | 0 | 0.00 | - | - |
| STAY WORTH | 14 | 12 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 3 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 6 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 14 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 2 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 13 | not checked | - | - | - | - |
| THE TABLE BINDS | 167 | not checked | - | - | - | - |
| WAITS AGAIN | 7 | 7 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p22

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 1.67 | 5.67 | 68.0 |
| ARMY TABLE | rule | 4.00 | 1.00 | 108.6 |
| JOB FIRST | gate | 1.00 | 2.00 | 38.5 |
| CHARGE NOW FIRST | rule | - | 1.00 | 27.7 |
| FIGHT ORDER BAND | gate | 0.33 | 0.33 | 1.3 |
| ONE PROMISE A TARGET | rule | - | 0.67 | 24.5 |
| SUPPORT NARROWED | rule | - | 0.67 | 9.8 |
| BEST PRIZE | rule | - | 0.33 | 16.2 |
| CHAFF PASSED | rule | 0.33 | - | 12.7 |
| HOLDER ASSIGNMENT | rule | - | 0.33 | 30.0 |
| JOINT CHARGE NOW | rule | - | 0.33 | 18.8 |
| PROMISE READS THE TABLE | rule | - | 0.33 | 35.9 |
| REFUSING RETIRES | rule | 0.33 | - | 3.3 |
| RULE SWITCHED OFF | gate | 0.33 | - | 12.6 |
| WHO GETS IN | rule | - | 0.33 | 18.8 |

### Plans: ccut-c940641-p22

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | move | 22.0 | 86% | 1546 | 0 | 0% |
| Mine | shoot | 0.7 | 50% | 85 | 18 | 21% |
| Mine | support | 0.3 | 100% | 47 | 0 | 0% |
| Opponent | charge | 2.7 | 50% | 439 | 254 | 58% |
| Opponent | join | 1.3 | 100% | 50 | 0 | 0% |
| Opponent | move | 28.0 | 96% | 1710 | 0 | 0% |
| Opponent | support | 0.3 | 100% | 0 | 0 | - |

### Battle groups: ccut-c940641-p22

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.3 | 14% | 100% | 0% | - | 100% | 0% | 0% | 0% | 0% |
| Opponent | REDIRECT COUNTER | 2.3 | 29% | 100% | 0% | - | 50% | 0% | 0% | 50% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p22

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 55 (2) | 0 | 55 | 100 | 0% | 3.0 | 55 (2) | - | - | 55 (2) | - |
| Mine | Character | 5 | 88 (5) | 88 | 0 | 44 | 20% | 2.5 | 7 (1) | 403 (2) | 0 (1) | 173 (3) | 7 (1) |
| Mine | Clean-up | 2 | 0 (2) | 0 | 0 | 16 | 50% | 5.0 | 0 (2) | - | - | 0 (1) | 0 (1) |
| Mine | Fast Hammer | 1 | 187 (1) | 187 | 0 | 0 | 0% | 3.0 | - | 187 (1) | - | 187 (1) | - |
| Mine | Hammer | 5 | 3 (5) | 0 | 3 | 105 | 0% | 2.6 | 0 (2) | 10 (2) | 0 (1) | 4 (4) | 0 (1) |
| Mine | Holder | 3 | 43 (3) | 0 | 43 | 46 | 67% | 4.0 | 0 (1) | 79 (2) | - | 43 (3) | - |
| Mine | Shooter | 3 | 0 (3) | 0 | 0 | 67 | 0% | 1.3 | 0 (1) | 0 (2) | - | 0 (2) | 0 (1) |
| Mine | Wizard | 3 | 0 (3) | 0 | 0 | 20 | 0% | 2.0 | - | 0 (2) | - | 0 (2) | - |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 5 | 20 (5) | 20 | 0 | 11 | 80% | 4.0 | 31 (3) | 0 (1) | 0 (1) | 73 (2) | 0 (3) |
| Opponent | Character | 6 | 68 (6) | 68 | 0 | 55 | 17% | 3.0 | 116 (2) | 0 (2) | 93 (1) | 100 (4) | 0 (1) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 5 | 50 (5) | 30 | 21 | 69 | 40% | 3.0 | - | 62 (3) | 28 (2) | 50 (5) | - |
| Opponent | Hammer | 2 | 158 (2) | 85 | 73 | 0 | 50% | 3.0 | - | 158 (2) | - | 245 (1) | 111 (1) |
| Opponent | Holder | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | - | 0 (1) | - | 0 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 1.0 | 0 (1) | - | 0 (1) | - | 0 (2) |

### Charged fights: ccut-c940641-p22

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Orc & Goblin Tribes | 1 | 0 | 717 | 4.0 | 1.0 | 179 | 101 | +78 | 2 of 4 | 1 of 4 | - | +78 |
| Mine | Skaven | 1 | 30 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 2 | 15 | 358 | 2.0 | 1.0 | 179 | 101 | +78 | 2 of 4 | 1 of 4 | - | +78 |
| Opponent | Vampire Counts | 1 | 0 | 490 | 4.0 | 1.0 | 122 | 248 | -126 | 3 of 4 | 2 of 4 | - | -126 |
| Opponent | Warriors of Chaos | 1 | 0 | 38 | 1.0 | 1.0 | 38 | 0 | +38 | 0 of 1 | 1 of 1 | - | +38 |
| **Opponent** | all armies | 2 | 0 | 264 | 2.5 | 1.0 | 106 | 199 | -93 | 3 of 5 | 3 of 5 | - | -93 |

### Effective charges: ccut-c940641-p22

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | Vampire Counts | 4 | 2 (net -496) | 0 | 0 | 0 | 0 | 2 (net +245) | 0 | 0% (0 of 4) |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0 | 0 | 1 (net +38) | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: ccut-c940641-p22

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | No odds | 4 | 201 | 236 | +78 | 181 | 108 | +73 | +36.4 |
| Mine | All fights | 4 | 201 | 236 | +78 | 181 | 108 | +73 | +36.4 |
| Opponent | Long shot (under 50%) | 2 | 328 | 343 | -496 | 0 | 496 | -496 | -151.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 328 | 245 | +245 | 245 | 0 | +245 | +74.6 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 494 | 38 | +38 | 70 | 55 | +16 | +3.2 |
| Opponent | All fights | 5 | 362 | 243 | -93 | 112 | 210 | -97 | -27.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p22 | move | 11 | 3 (27%) | 2 (18%) | 0 (0%) | 8 (73%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1827, L1927 |
| Elixir of Power | Mine | L1927 |
| Fistful of Laurels | Mine | L1827 |
| Invocation of Nehek | Opponent | L1827, L1927 |
| Periapt of Soul Exchange | Mine | L2029 |

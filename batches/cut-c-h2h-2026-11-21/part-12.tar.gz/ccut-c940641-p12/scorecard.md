# Doctrine scorecard: ccut-c940641-p12

### Scorecard: ccut-c940641-p12

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L2531 | 5 | 1 | Mine | yes | - | 4 | 4 | 4 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | yes | - | 2 | 3 | 1 | 0 | 0 | 0 | 170 |
| L2730 | 6 | 1 | Mine | no | 0 | 2 | 7 | 2 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 3 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 0 | 3 | 2 | 2 | 0 | 0 | 0 | 170 |
| L2934 | 6 | 1 | Opponent | no | 3 | 4 | 1 | 4 | 0 | 0 | 0 | 227 |
| **Average** | | | Mine | 33% | 0.0 | 3.0 | 4.3 | 2.7 | 0.0 | 0.0 | 0.0 | 56.7 |
| **Average** | | | Opponent | 33% | 3.0 | 2.7 | 2.3 | 1.7 | 0.0 | 0.0 | 0.0 | 132.3 |

### KPIs: ccut-c940641-p12

Rules off - Mine only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 16) | 0% (0 of 17) | 0% (0 of 33) |
| Winner chose to follow up after the loser gave ground |  | 67% (4 of 6); on the table 67% | 80% (4 of 5); on the table 80% | 73% (8 of 11); on the table 73% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 2); on the table 0% | - | 0% (0 of 2); on the table 0% |
| Winner chose to pursue after the loser fled |  | 33% (1 of 3); on the table 67% | - | 33% (1 of 3); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 45% (5 of 11); on the table 55% | 80% (4 of 5); on the table 80% | 56% (9 of 16); on the table 62% |
| Magic missiles tried each own turn | 50%+ | 67% (4 of 6) | 17% (1 of 6) | 42% (5 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 80% (4 of 5) | 20% (1 of 5) | 50% (5 of 10) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 67% (4 of 6) | 71% (5 of 7) | 69% (9 of 13) |
| Points that never fought | lower | 34% (2063 of 5998) | 28% (1695 of 5998) | 31% (3758 of 11996) |
|   infantry points that never fought | lower | 51% (457 of 902) | 24% (262 of 1072) | 36% (719 of 1974) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 53% (10 of 19) | 62% (16 of 26) | 58% (26 of 45) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game | 100% (1 of 1); 0.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 48% (2424 of 5038) | 52% (2791 of 5360) | 50% (5215 of 10398) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (50%) | 1.3 (80%) | 1.7 (71%) |
| IN COMBAT: engaged in combat | 0.3 (50%) | 0.3 (20%) | 0.7 (29%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.0 | 2.0 | 2.0 | 1.7 | 0.3 | 2.0 |
| not cast | 3.0 | 0.0 | 2.0 | 2.3 | 1.7 | 22.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | - | 0.3 (17%) | 0.0 (0%) | 0.0 (0%) | 1.0 (5%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | - | 0.0 (0%) | 1.7 (71%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | - | 0.3 (17%) | 0.7 (29%) | 0.0 (0%) | 0.0 (0%) |
| STUPIDITY: Stupidity | 0.7 (22%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 1.7 (100%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (78%) | - | 1.3 (67%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 20.3 (92%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.0 a game | 0.0 a game | 1.0 a game |
| stood (cast and not dispelled) | 100% (6 of 6) | - | 100% (6 of 6) |
| the unit moved after it | 100% (6 of 6) | - | 100% (6 of 6) |
| it charged on its next turn | 17% (1 of 6) | - | 17% (1 of 6) |
| the enemy charged it first | 0% (0 of 6) | - | 0% (0 of 6) |
| it fought by the end of its next turn | 0% (0 of 6) | - | 0% (0 of 6) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 6) | - | 0% (0 of 6) |
| none of these (no charge, no fight, no charge escaped) | 83% (5 of 6) | - | 83% (5 of 6) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 0% (0 of 7) | 63% (24 of 38) | 53% (24 of 45) |
|   cavalry | 0% (0 of 4) | 83% (10 of 12) | 62% (10 of 16) |
|   character | 0% (0 of 3) | 38% (6 of 16) | 32% (6 of 19) |
|   infantry | - | 80% (8 of 10) | 80% (8 of 10) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.0 (0%) | 1.0 (21%) | 1.0 (14%) |
| CHARGED: it charged | 1.0 (43%) | 2.0 (43%) | 3.0 (43%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (7%) | 0.3 (5%) |
| NO TARGET IN RANGE | 1.0 (43%) | 0.7 (14%) | 1.7 (24%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (14%) | 0.0 (0%) | 0.3 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 0.7 (14%) | 0.7 (10%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.7 | 0.7 | 90% | 1.2 pts | 8 pts |
| character | 2.0 | 0.3 | 83% | 9.1 pts | 18 pts |
| infantry | 4.7 | 1.3 | 71% | 11.6 pts | 54 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 6.0 | 4.3 | 5.2 |
| Charges that made contact a game | 4.3 | 3.3 | 3.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | - | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.33 declared, 0.67 contact (3 units) | 1.00 declared, 1.00 contact (1 units) | 1.25 declared, 0.75 contact (4 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.61 declared, 0.48 contact (23 units) | 0.46 declared, 0.35 contact (26 units) | 0.53 declared, 0.41 contact (49 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 57% (4 of 7) | 60% (3 of 5) | 0% (0 of 1) | 54% (7 of 13) |
| Character in a unit | 100% (4 of 4) | 50% (1 of 2) | 100% (1 of 1) | 86% (6 of 7) |
| Character on its own | 67% (2 of 3) | 100% (1 of 1) | 29% (2 of 7) | 45% (5 of 11) |
| Infantry | 43% (3 of 7) | 0% (0 of 1) | - | 38% (3 of 8) |
| Monster | 67% (2 of 3) | 100% (1 of 1) | - | 75% (3 of 4) |
| Monstrous | 100% (2 of 2) | - | - | 100% (2 of 2) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Vampire Counts | 2 | 20% (1 of 5); on the table 40% | 67% (4 of 6) | 37% | 67% (8 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 3 | 75% (6 of 8); on the table 75% | 17% (1 of 6) | 20% | 60% (15 of 25) | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Wood Elf Realms | 1 | 67% (2 of 3); on the table 67% | - | 56% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p12, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 43% (3) | 67% (6) | 56% (9) |
| ...free all their last turn and able to turn (per game) | 0.67 | 2.00 | 2.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 1.33 | 2.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 1.33 | 1.33 |

### Quality by phase: ccut-c940641-p12

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 60% (9 of 15) | 83% (10 of 12) |
| Strategy | Shoot objectives carried out (shot that target) | 0% (0 of 2) | 38% (3 of 8) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | 50% (1 of 2) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | - |
| Strategy | Joined characters whose unit fought | 50% (3 of 6) | 100% (3 of 3) |
| Strategy | Lone characters that fought | 57% (4 of 7) | 43% (3 of 7) |
| Movement | Charges halted short of contact | 0.3 | 0.3 |
| Movement | Idle units | 2.7 | 1.7 |
| Movement | Points that never moved of their own | 56.7 | 132.3 |
| Movement | Fights charged into per game | 4.3 | 3.0 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 10, net +0 | 2 of 7, net +248 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 10 | 0 of 7 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 10, net +236 | 1 of 7, net +45 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 of 10, net -22 | 2 of 7, net +22 |
| Shooting | Shots by shooting units (incl. breath weapons) | 1.0 | 8.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 3) | 58% (15 of 26) |
| Shooting | Points destroyed by shooting units | 30.3 | 0.0 |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Points destroyed by magic (all spells) | 0.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.7 / 0.0 / 0.3 / 0.3 | 0.0 / 2.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 151.7 | 317.7 |
| Combat | Points run down | 72.3 | 50.7 |
| Combat | Net points per charged fight, damage counted | +30 | +63 |
| Combat | Net per 100 charger points, damage counted | +12.2 | +20.3 |
| Combat | First round won (charged fights) | 69% | 56% |
| Combat | Net points per charged fight | +49 | +80 |
| Combat | Net points per supported fight / lone fight | - / +49 | +0 / +90 |
| Combat | Charged fights on a top-3 enemy unit | 4 of 13 | 5 of 9 |
| Game | Points lost | 351.7 | 371.3 |
| Game | VP from objectives | 496.7 | 586.7 |
| Game | Lone holders (player turns) | 0.0 | 3.0 |

- Mine won / drew / lost: 1 / 1 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) -57 VP
- The side that went first won 0 of 2 games with a winner
- Points traded per game (both sides' losses): 723
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ccut-c940641-p12

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +155.4 | 0.0 | 0.0 | 0.3 | +13.2 | 0.0 | 0.0 |
| ARMY TABLE | 18.0 | +345.8 | 0.0 | 87.3 | 16.0 | -534.8 | 0.0 | 129.7 |
| ASSAILMENT BY POINTS | 0.7 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 1.0 | +4.0 | 56.7 | 0.0 | 2.0 | +14.9 | 199.3 | 77.3 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS FROM BEHIND | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 2.0 | +26.6 | 0.0 | 35.0 | 0.3 | +9.0 | 0.0 | 9.0 |
| CHAFF PASSED | - | - | - | - | 1.3 | -0.6 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 1.7 | +38.3 | 0.0 | 0.0 | 0.7 | +34.2 | 0.0 | 86.7 |
| CHARGE LIST READ AGAIN | - | - | - | - | 0.3 | +9.8 | 0.0 | 0.0 |
| CHARGE LOSSES | 11.7 | -339.8 | 0.0 | 40.7 | 5.7 | -295.8 | 0.0 | 105.3 |
| CHARGE NOT DECLARED | 0.3 | +0.0 | 32.7 | 0.0 | - | - | - | - |
| CHARGE NOW FIRST | 4.3 | +0.0 | 261.0 | 62.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 18.7 | +0.0 | 0.0 | 60.0 | 14.3 | +0.0 | 0.0 | 65.3 |
| COMBAT PIVOT | 0.3 | +0.0 | 9.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 1.7 | +39.1 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 8.0 | -665.4 | 0.0 | 40.7 | 7.0 | -449.1 | 0.0 | 30.3 |
| DENIED BY THE FIGHT | 0.7 | -2.6 | 0.0 | 40.7 | - | - | - | - |
| DEPLOY BY FIGURES | 7.0 | +107.4 | 0.0 | 0.0 | 7.3 | -37.6 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.7 | -133.0 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.7 | +29.6 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 4.3 | +24.0 | 125.3 | 62.0 | 2.7 | -0.1 | 41.7 | 0.0 |
| FALL BACK GOOD ORDER | 4.3 | +2.2 | 97.0 | 102.7 | 3.7 | +1.3 | 56.7 | 0.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 19.7 | +283.9 | 0.0 | 55.7 | - | - | - | - |
| FEATURE BUFFS | 0.7 | +6.7 | 0.0 | 0.0 | 1.3 | +14.4 | 0.0 | 0.0 |
| FIGHT TO THE END | 2.0 | +31.6 | 0.0 | 62.0 | 0.3 | +2.8 | 0.0 | 0.0 |
| FIVE ACTION | 80.3 | +4144.5 | 270.0 | 310.7 | 84.7 | +5636.5 | 256.0 | 532.3 |
| FLANK NOT WEIGHED | 8.3 | +0.0 | 0.0 | 10.0 | 11.0 | +0.0 | 0.0 | 141.7 |
| FOLLOW UP WEIGHED | 1.0 | +85.2 | 0.0 | 0.0 | 1.7 | +317.2 | 0.0 | 0.0 |
| FOUR ROUNDS | 6.0 | +447.0 | 213.3 | 102.7 | 4.3 | +529.1 | 56.7 | 0.0 |
| FREED FROM HIS FIGHT | 3.3 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 1.3 | -19.6 | 16.7 | 0.0 |
| GOAL WALK | 7.3 | +551.5 | 0.0 | 0.0 | 12.3 | +1032.5 | 0.0 | 0.0 |
| HARD STAY DROPPED | 0.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 38.7 |
| HE REFORMS ONCE FREED | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 8.0 | +0.0 | 0.0 | 40.7 | 4.7 | +0.0 | 0.0 | 105.3 |
| HIS CHARGE DENIED | 0.7 | +59.3 | 0.0 | 40.7 | 0.3 | +1.9 | 0.0 | 0.0 |
| HIS CHARGE LIST | 2.7 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 69.7 |
| HIS LEGAL MOVES | 5.0 | +0.0 | 0.0 | 81.3 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.0 | -20.4 | 0.0 | 0.0 | 0.7 | -6.5 | 0.0 | 0.0 |
| HIS MOVE AS HE DECIDES | 45.0 | +13.3 | 480.0 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 11.3 | +0.0 | 0.0 | 32.7 |
| HIS ONE MOVE | 21.3 | +43.1 | 0.0 | 15.0 | - | - | - | - |
| HIS OWN BEST MOVE | 3.0 | +0.0 | 0.0 | 40.7 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 12.0 | +0.0 | 0.0 | 63.3 | 11.3 | +0.0 | 0.0 | 18.0 |
| HIS RANDOM MOVER COMES | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 18.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 27.7 | +412.3 | 0.0 | 48.3 | 12.3 | +156.0 | 0.0 | 126.7 |
| HIS SHOTS BY HIS RUN | 34.0 | +399.0 | 0.0 | 96.3 | 9.0 | +160.4 | 0.0 | 188.7 |
| HIS TURN DENIED | 0.3 | +1.6 | 53.3 | 0.0 | 0.3 | +0.9 | 0.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 16.0 | +0.0 | 0.0 | 81.3 | 18.7 | +0.0 | 0.0 | 130.7 |
| HOLDER ASSIGNMENT | 10.0 | +902.2 | 0.0 | 40.7 | 11.0 | +1307.1 | 0.0 | 65.3 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 5.3 | -174.7 | 213.3 | 62.0 | 4.0 | -178.0 | 56.7 | 0.0 |
| IDLE COST | 21.3 | -325.4 | 0.0 | 48.3 | - | - | - | - |
| JOINT CHARGE NOW | 0.7 | +16.7 | 32.7 | 0.0 | 1.3 | +100.1 | 0.0 | 0.0 |
| JOINT ON THE TABLE | 0.3 | +18.0 | 32.7 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 65.3 |
| LANE BY FIGURES | 1.0 | +42.8 | 0.0 | 0.0 | 0.7 | +13.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 6.7 | +0.0 | 250.0 | 502.7 | 10.0 | +0.0 | 394.0 | 76.7 |
| LONG SHOT | 0.3 | +0.8 | 0.0 | 0.0 | 0.3 | -1.7 | 15.0 | 0.0 |
| LOST AFTER ESCAPE | 2.7 | +6.8 | 126.0 | 62.0 | 1.7 | -1.9 | 0.0 | 0.0 |
| LURE BY WHAT IT DRAWS | - | - | - | - | 0.3 | -2.1 | 0.0 | 9.0 |
| MAKE SURE TOGETHER | 0.3 | +0.3 | 0.0 | 15.0 | - | - | - | - |
| MANOEUVRE | 2.0 | +0.0 | 0.0 | 0.0 | 0.3 | -7.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.3 | +7.4 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 0.3 | +37.6 | 0.0 | 0.0 |
| MARCH OVER CASTS | - | - | - | - | 0.3 | -1.8 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 65.3 |
| MAX FOR POSITIONING | 3.0 | +210.3 | 0.0 | 15.0 | 1.3 | +56.9 | 0.0 | 0.0 |
| MEETS IN TIME | 3.7 | +311.9 | 0.0 | 0.0 | 3.3 | +260.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.7 | +5.2 | 0.0 | 0.0 | 1.7 | +22.1 | 0.0 | 38.7 |
| MISSILES NEXT TURN | 1.7 | +3.4 | 0.0 | 0.0 | 2.7 | +27.0 | 0.0 | 38.7 |
| MOVE ORDER | 3.0 | +0.0 | 0.0 | 31.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 7.0 | +554.6 | 0.0 | 0.0 | 6.0 | +678.6 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 7.3 | +268.4 | 0.0 | 40.7 | 7.3 | +358.2 | 0.0 | 88.0 |
| NEXT CHARGE BY LIST | 5.3 | +386.3 | 0.0 | 0.0 | 5.3 | +644.4 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -2.6 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 5.3 | -173.7 | 204.3 | 102.7 | 2.7 | -75.8 | 41.7 | 0.0 |
| NO LATE CUT | - | - | - | - | 0.7 | +0.0 | 0.0 | 65.3 |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 1.3 | +19.5 | 0.0 | 23.3 |
| NOT WORTH A CAST | 1.3 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 6.0 | -179.7 | 0.0 | 70.7 | 5.7 | -253.9 | 0.0 | 32.3 |
| ONE CHALLENGE TEST | 0.3 | +1.0 | 30.3 | 0.0 | 0.7 | -4.9 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 10.0 | - | - | - | - |
| ONE FIGHT FORMULA | 6.7 | -115.5 | 0.0 | 15.0 | 3.7 | -124.6 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 0.3 | +2.5 | 0.0 | 0.0 | 0.3 | +63.3 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 5.0 | -24.3 | 0.0 | 40.7 | 4.7 | +132.3 | 0.0 | 32.7 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | -13.3 | 0.0 | 0.0 |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 65.3 |
| OPENS UP | - | - | - | - | 1.0 | +106.7 | 25.0 | 0.0 |
| OVERRUNS AWAY | 1.7 | +33.3 | 72.0 | 0.0 | - | - | - | - |
| PATHS CROSS | 1.0 | +46.6 | 0.0 | 0.0 | 1.7 | +55.4 | 0.0 | 0.0 |
| PLAN RESULT | 43.7 | +309.2 | 56.7 | 396.3 | 43.3 | +294.8 | 463.0 | 503.3 |
| PROMISE BY ITS OWN SUM | 8.0 | -137.8 | 0.0 | 0.0 | 11.3 | -546.7 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.0 | -0.6 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| QUARTER ODDS | 6.7 | +589.3 | 48.0 | 0.0 | 5.0 | +785.5 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 2.0 | +107.0 | 0.0 | 0.0 | 2.3 | +4.8 | 0.0 | 0.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 65.3 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 1.3 | +46.3 | 0.0 | 46.7 |
| REDIRECT COUNTER | 4.3 | +306.0 | 0.0 | 55.0 | 3.7 | +105.6 | 0.0 | 32.3 |
| REDIRECT FOR A FRIEND IN REACH | 2.7 | +0.0 | 0.0 | 40.0 | 3.7 | +83.9 | 0.0 | 64.7 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.0 | -73.1 | 0.0 | 0.0 | 3.0 | -201.1 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 2.0 | +0.0 | 0.0 | 30.3 |
| RESERVE FALL BACK | 0.3 | +36.3 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 5.3 | +111.6 | 213.3 | 102.7 | 3.7 | +104.6 | 46.7 | 0.0 |
| ROUNDS AFTER TERROR | 2.0 | -44.6 | 80.7 | 0.0 | 0.3 | -16.5 | 0.0 | 0.0 |
| RUN DOWN | 4.3 | -60.9 | 204.3 | 62.0 | 1.0 | -2.7 | 10.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 3.0 | -193.4 | 0.0 | 70.0 | - | - | - | - |
| SEARCH SPOT | 1.3 | +33.5 | 0.0 | 0.0 | 0.7 | +10.8 | 0.0 | 0.0 |
| SECOND LOOK | 1.0 | +34.3 | 0.0 | 40.7 | 0.3 | +39.6 | 0.0 | 0.0 |
| SET CREDITED ONCE | 2.7 | -41.4 | 0.0 | 45.0 | 3.0 | -57.3 | 0.0 | 0.0 |
| SET UP BY THE SET | 4.0 | +30.9 | 0.0 | 45.0 | 3.7 | +54.0 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.3 | +0.3 | 0.0 | 15.0 | 0.3 | +2.5 | 0.0 | 0.0 |
| SET-UP ANY TARGET | 0.3 | +37.9 | 0.0 | 0.0 | - | - | - | - |
| SHOOTER COUNTED ONCE | 0.3 | -0.9 | 0.0 | 10.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 2.0 | +0.0 | 0.0 | 35.0 | 3.0 | +0.0 | 0.0 | 47.7 |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 0.7 | +25.4 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 1.3 | -13.8 | 15.0 | 0.0 |
| SHOT RISK POINTS | 14.0 | -147.3 | 0.0 | 70.7 | 7.0 | +46.6 | 0.0 | 161.3 |
| SHOTS AFTER THE MOVES | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 1.0 | +39.6 | 0.0 | 0.0 | 7.0 | +46.6 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | 0.3 | +37.9 | 0.0 | 0.0 | - | - | - | - |
| SPELL WORTH | 2.0 | +8.3 | 0.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 10.7 | +0.0 | 0.0 | 62.0 | 8.3 | +0.0 | 0.0 | 63.0 |
| STAND AND SHOOT | 0.3 | -2.1 | 53.3 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| STANDS STILL | 13.0 | +0.0 | 56.7 | 40.7 | 35.7 | +0.0 | 199.3 | 284.0 |
| STAY WORTH | 0.7 | +3.4 | 0.0 | 0.0 | 10.3 | +48.2 | 0.0 | 0.0 |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| STUPIDITY NEXT TURN | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 7.0 | +1036.0 | 0.0 | 0.0 | 5.0 | +578.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 7.0 | +1036.0 | 0.0 | 0.0 | 5.0 | +578.0 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -1.4 | 0.0 | 15.0 | - | - | - | - |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 3.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 63.0 |
| THE ROW KEEPS ITS WAY | 5.7 | +0.0 | 0.0 | 40.7 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE STEP BACK IS MADE | 4.3 | +0.0 | 0.0 | 40.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 41.0 | +0.0 | 0.0 | 139.0 | 40.7 | +0.0 | 0.0 | 270.7 |
| TIED UP BY THE SUM | 2.7 | +302.6 | 151.0 | 0.0 | 0.7 | +80.7 | 15.0 | 0.0 |
| TIME ON OUR SIDE | - | - | - | - | 65.0 | +627.6 | 30.0 | 468.3 |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | +14.0 | 0.0 | 0.0 |
| WHO FIGHTS | 1.3 | +30.9 | 53.3 | 0.0 | 0.7 | -0.1 | 0.0 | 0.0 |
| WHO GETS IN | 0.3 | +18.0 | 32.7 | 0.0 | - | - | - | - |
| WHO HITS BACK | 1.0 | +178.0 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 1.0 | -193.5 | 0.0 | 0.0 | 3.3 | -282.5 | 0.0 | 65.3 |
| WHOLE FIGHT GAIN | 0.3 | +1.3 | 0.0 | 0.0 | 0.7 | +16.8 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 1.0 | +11.6 | 0.0 | 0.0 | 0.7 | +5.3 | 0.0 | 0.0 |

### Rule changes: ccut-c940641-p12

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 135 | 135 | 95 | 31.67 | +0 | +0.0 |
| ARMY TABLE | 102 | 102 | 68 | 22.67 | +800 | +11.8 |
| HOLDER ASSIGNMENT | 63 | 63 | 58 | 19.33 | +5163 | +89.0 |
| LEGAL CHARGES ONLY | 50 | 50 | 50 | 16.67 | +0 | +0.0 |
| OFF BEST | 35 | 35 | 35 | 11.67 | -1300 | -37.2 |
| THE TABLE AGAIN | 36 | 36 | 32 | 10.67 | +0 | +0.0 |
| TIME ON OUR SIDE | 195 | 159 | 30 | 10.00 | +25 | +0.8 |
| FIVE ACTION | 495 | 471 | 26 | 8.67 | +2152 | +82.8 |
| DEPLOY BY FIGURES | 43 | 43 | 24 | 8.00 | +122 | +5.1 |
| HIS MOVE WHY | 34 | 34 | 23 | 7.67 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 58 | 58 | 22 | 7.33 | -2054 | -93.3 |
| HIS SHOT LIST | 120 | 111 | 19 | 6.33 | +129 | +6.8 |
| FOUR ROUNDS | 31 | 28 | 18 | 6.00 | +1484 | +82.4 |
| HIS ONE MOVE | 64 | 61 | 18 | 6.00 | +0 | +0.0 |
| GOAL WALK | 59 | 58 | 17 | 5.67 | +1100 | +64.7 |
| REDIRECT FOR A FRIEND IN REACH | 19 | 19 | 17 | 5.67 | +25 | +1.5 |
| HIS SHOTS BY HIS RUN | 129 | 121 | 16 | 5.33 | +129 | +8.1 |
| MEETS IN TIME | 21 | 21 | 13 | 4.33 | +865 | +66.5 |
| HARD STAY DROPPED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| RISK BY ARC | 27 | 24 | 10 | 3.33 | +240 | +24.0 |
| SHOT RISK POINTS | 63 | 59 | 10 | 3.33 | +178 | +17.8 |
| RANDOM MOVE BY FIGURES | 13 | 13 | 9 | 3.00 | +336 | +37.3 |
| SUPPORT ADDS | 36 | 36 | 9 | 3.00 | +390 | +43.3 |
| SUPPORT WORKED OUT | 36 | 36 | 9 | 3.00 | +390 | +43.3 |
| TIED UP BY THE SUM | 10 | 9 | 9 | 3.00 | +343 | +38.1 |
| COVER ONCE | 45 | 30 | 8 | 2.67 | +211 | +26.4 |
| FOLLOW UP WEIGHED | 8 | 8 | 8 | 2.67 | +1207 | +150.9 |
| IDLE COST | 64 | 41 | 8 | 2.67 | +80 | +10.0 |
| MOVE TO CHARGE COMPUTED | 39 | 31 | 8 | 2.67 | +785 | +98.1 |
| PATHS CROSS | 8 | 8 | 8 | 2.67 | +306 | +38.2 |
| SET UP BY THE SET | 23 | 22 | 8 | 2.67 | +518 | +64.7 |
| CAST JOB | 9 | 9 | 7 | 2.33 | +3 | +0.4 |
| CHALLENGE BY POINTS | 7 | 7 | 7 | 2.33 | +218 | +31.1 |
| QUARTER ODDS | 35 | 34 | 7 | 2.33 | +897 | +128.1 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CHAFF IN THE MOVE | 7 | 7 | 6 | 2.00 | +0 | +0.0 |
| FALLS SHORT | 59 | 51 | 6 | 2.00 | +8 | +1.4 |
| HOLDS AMBUSHERS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| JOINT CHARGE NOW | 6 | 6 | 6 | 2.00 | +351 | +58.4 |
| MAX FOR POSITIONING | 13 | 13 | 6 | 2.00 | +64 | +10.7 |
| NEXT CHARGE BY LIST | 32 | 26 | 6 | 2.00 | +753 | +125.5 |
| THE RISK READS HIS RUN | 18 | 18 | 6 | 2.00 | +0 | +0.0 |
| CHARGE NOW FIRST | 15 | 15 | 5 | 1.67 | -386 | -77.2 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +170 | +33.9 |
| CASTS FROM BEHIND | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CHAFF PASSED | 4 | 4 | 4 | 1.33 | -2 | -0.4 |
| REFUSING RETIRES | 6 | 6 | 4 | 1.33 | +317 | +79.2 |
| SECOND LOOK | 4 | 4 | 4 | 1.33 | +222 | +55.4 |
| OVERRUNS AWAY | 5 | 5 | 3 | 1.00 | +61 | +20.4 |
| REDIRECT COUNTER | 24 | 20 | 3 | 1.00 | +158 | +52.8 |
| SEARCH SPOT | 6 | 6 | 3 | 1.00 | +133 | +44.2 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +471 | +157.1 |
| AFTERMATH IN POINTS | 2 | 2 | 2 | 0.67 | +506 | +252.9 |
| ASSAILMENT BY POINTS | 2 | 2 | 2 | 0.67 | +7 | +3.5 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HONEST WORTH | 28 | 26 | 2 | 0.67 | +26 | +13.0 |
| ONE OBJECTIVE FORMULA | 29 | 28 | 2 | 0.67 | +133 | +66.5 |
| REDIRECT BY WHAT IT STOPS | 4 | 4 | 2 | 0.67 | +25 | +12.6 |
| SHOTS IN THE MOVE | 24 | 18 | 2 | 0.67 | +10 | +4.8 |
| STAY WORTH | 33 | 25 | 2 | 0.67 | +17 | +8.5 |
| SUPPORT NARROWED | 2 | 2 | 2 | 0.67 | -246 | -122.8 |
| WHAT THE JOINER ADDS | 2 | 2 | 2 | 0.67 | +67 | +33.3 |
| WHO FIGHTS | 6 | 6 | 2 | 0.67 | +13 | +6.7 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE LIST READ AGAIN | 1 | 1 | 1 | 0.33 | +30 | +29.5 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -135 | -134.8 |
| EDGE GIVE GROUND | 2 | 2 | 1 | 0.33 | +9 | +9.4 |
| EXACT ROUND | 21 | 20 | 1 | 0.33 | +9 | +9.2 |
| HIS CHARGE DENIED | 3 | 1 | 1 | 0.33 | +2 | +1.6 |
| HIS TURN DENIED | 2 | 2 | 1 | 0.33 | +4 | +4.1 |
| JOINT ON THE TABLE | 1 | 1 | 1 | 0.33 | +54 | +53.9 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +22 | +22.3 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -113 | -112.7 |
| NO DOUBLE ROUNDS | 24 | 22 | 1 | 0.33 | +4 | +3.9 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -40 | -39.8 |
| OPENS UP | 3 | 2 | 1 | 0.33 | +40 | +39.8 |
| PROMISE KNOWS THE FIGHT | 4 | 4 | 1 | 0.33 | -2 | -1.7 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +90 | +89.5 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +109 | +108.8 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 20 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO GETS IN | 1 | 1 | 1 | 0.33 | +54 | +53.9 |
| WHOLE FIGHT DANGER | 13 | 11 | 1 | 0.33 | +12 | +11.8 |
| WHOLE FIGHT GAIN | 3 | 3 | 1 | 0.33 | +2 | +1.6 |
| CASTS AFTER FRIENDS | 6 | trace | - | - | - | - |
| CHARGE LOSSES | 52 | 47 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 99 | 97 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 5 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | not checked | - | - | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 24 | 21 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 2 | 2 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 6 | 6 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 7 | 6 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 58 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 29 | 29 | 0 | 0.00 | - | - |
| GIVES UP | 4 | 4 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 10 | 10 | 0 | 0.00 | - | - |
| HELPER UNSEEN | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 38 | 35 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 31 | 30 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 24 | 24 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 8 | 8 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 23 | 22 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 70 | 63 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 10 | 10 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 104 | 104 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 8 | 8 | 0 | 0.00 | - | - |
| LONG SHOT | 2 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 13 | 13 | 0 | 0.00 | - | - |
| LURE BY WHAT IT DRAWS | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MANOEUVRE | 7 | 7 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 1 | 1 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 4 | 4 | 0 | 0.00 | - | - |
| MISSILES IN THE MOVE | 10 | 5 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 13 | 7 | 0 | 0.00 | - | - |
| NEARER NOT NEEDED | 44 | 41 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 4 | 4 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 3 | 3 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 1 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 31 | 12 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 2 | 2 | 0 | 0.00 | - | - |
| ONE ROUTE | 4 | 4 | 0 | 0.00 | - | - |
| PLAN RESULT | 261 | trace | - | - | - | - |
| REAL GROUND | 4 | 4 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 12 | 9 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 7 | 7 | 0 | 0.00 | - | - |
| RUN DOWN | 16 | 16 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 9 | 9 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 17 | 16 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 15 | not checked | - | - | - | - |
| SHOOTS FROM THE BEST SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SHOT OR CHARGE | 4 | 4 | 0 | 0.00 | - | - |
| SHOTS AFTER THE MOVES | 2 | 2 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPELL WORTH | 6 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 57 | 52 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 1 | 1 | 0 | 0.00 | - | - |
| STANDS STILL | 146 | 136 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 7 | 7 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 22 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 1 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 16 | not checked | - | - | - | - |
| THE TABLE BINDS | 245 | not checked | - | - | - | - |
| WAITS AGAIN | 14 | 12 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 5 | 5 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p12

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.33 | 5.00 | 37.5 |
| PROMISE BY ITS OWN SUM | rule | 1.67 | 5.67 | 93.3 |
| ARMY TABLE | rule | 0.67 | 3.67 | 111.0 |
| CHARGE NOW FIRST | rule | 1.00 | 0.67 | 77.2 |
| RULE SWITCHED OFF | gate | 1.33 | - | 12.4 |
| HOLDER ASSIGNMENT | rule | 0.33 | 0.67 | 23.2 |
| REFUSING RETIRES | rule | - | 1.00 | 4.5 |
| CHAFF PASSED | rule | - | 0.67 | 0.7 |
| JOINT CHARGE NOW | rule | 0.33 | 0.33 | 15.8 |
| SUPPORT NARROWED | rule | 0.67 | - | 122.8 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.33 | - | 192.1 |
| CHARGE NOT DECLARED | rule | 0.33 | - | 134.8 |
| FALLBACK | gate | - | 0.33 | 8.3 |
| FIGHT ORDER BAND | gate | - | 0.33 | 0.6 |
| MARCH OF THE TABLE | rule | - | 0.33 | 112.7 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 39.8 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | - | 1.7 |

### Plans: ccut-c940641-p12

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 4.7 | 64% | 424 | 253 | 60% |
| Mine | join | 4.3 | 100% | 170 | 0 | 0% |
| Mine | move | 32.7 | 96% | 1520 | 0 | 0% |
| Mine | shoot | 0.7 | 50% | 69 | 57 | 82% |
| Mine | support | 1.3 | 75% | 0 | 0 | - |
| Opponent | charge | 3.0 | 78% | 377 | 148 | 39% |
| Opponent | join | 2.3 | 100% | 192 | 0 | 0% |
| Opponent | move | 35.0 | 93% | 2058 | 0 | 0% |
| Opponent | shoot | 2.3 | 71% | 116 | 147 | 126% |
| Opponent | support | 0.7 | 100% | 42 | 0 | 0% |

### Battle groups: ccut-c940641-p12

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 4.3 | 46% | 33% | 33% | 0% | 0% | 0% | 25% | 75% | 0% |
| Opponent | REDIRECT COUNTER | 3.7 | 27% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p12

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 9 | 74 (9) | 0 | 74 | 23 | 78% | 2.0 | 0 (4) | 133 (3) | 156 (2) | 115 (6) | 0 (3) |
| Mine | Character | 9 | 25 (9) | 25 | 0 | 2 | 22% | 3.3 | 40 (2) | 14 (6) | 0 (1) | 31 (6) | 0 (3) |
| Mine | Clean-up | 1 | 123 (1) | 0 | 123 | 100 | 0% | 4.0 | - | - | 123 (1) | 123 (1) | - |
| Mine | Fast | 1 | 67 (1) | 67 | 0 | 100 | 0% | 2.0 | - | 67 (1) | - | - | 67 (1) |
| Mine | Fast Hammer | 6 | 25 (6) | 13 | 12 | 12 | 17% | 3.4 | - | 18 (4) | 43 (2) | 20 (3) | 33 (3) |
| Mine | Hammer | 2 | 52 (2) | 27 | 24 | 76 | 0% | 3.0 | - | 52 (2) | - | 79 (1) | 37 (1) |
| Mine | Holder | 1 | 62 (1) | 62 | 0 | 0 | 0% | 4.0 | 62 (1) | - | - | 62 (1) | - |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 25% | 1.3 | 0 (2) | 0 (1) | 0 (1) | 0 (3) | 0 (1) |
| Opponent | Chaff | 3 | 145 (3) | 0 | 145 | 100 | 33% | 5.5 | 0 (1) | 257 (1) | 0 (1) | 145 (3) | - |
| Opponent | Character | 10 | 36 (10) | 36 | 0 | 0 | 30% | 3.0 | 46 (3) | 34 (6) | 0 (1) | 33 (6) | 41 (4) |
| Opponent | Clean-up | 2 | 0 (2) | 0 | 0 | 0 | 50% | 3.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 5 | 24 (5) | 0 | 24 | 11 | 0% | 3.0 | 30 (2) | 0 (1) | 31 (2) | 41 (2) | 15 (3) |
| Opponent | Fragile | 2 | 0 (2) | 0 | 0 | 0 | 50% | 1.0 | 0 (1) | - | 0 (1) | 0 (2) | - |
| Opponent | Hammer | 6 | 28 (6) | 6 | 22 | 58 | 17% | 4.0 | - | 36 (4) | 0 (2) | 0 (3) | 59 (3) |
| Opponent | Holder | 6 | 64 (6) | 0 | 64 | 38 | 17% | 3.2 | 38 (4) | 119 (2) | - | - | 64 (6) |
| Opponent | Shooter | 1 | 56 (1) | 0 | 56 | 100 | 0% | 2.0 | - | - | 56 (1) | 56 (1) | - |

### Charged fights: ccut-c940641-p12

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 2 | 0 | 274 | 4.0 | 1.0 | 68 | 23 | +45 | 2 of 8 | 5 of 8 | - | +45 |
| Mine | Warriors of Chaos | 1 | 91 | 278 | 5.0 | 1.0 | 56 | 0 | +56 | 2 of 5 | 4 of 5 | - | +56 |
| **Mine** | all armies | 3 | 30 | 275 | 4.3 | 1.0 | 64 | 14 | +49 | 4 of 13 | 9 of 13 | - | +49 |
| Opponent | Warriors of Chaos | 2 | 0 | 197 | 4.0 | 1.1 | 49 | 21 | +28 | 4 of 8 | 4 of 8 | +0 | +32 |
| Opponent | Wood Elf Realms | 1 | 0 | 495 | 1.0 | 1.0 | 495 | 0 | +495 | 1 of 1 | 1 of 1 | - | +495 |
| **Opponent** | all armies | 3 | 0 | 296 | 3.0 | 1.1 | 99 | 19 | +80 | 5 of 9 | 5 of 9 | +0 | +90 |

### Effective charges: ccut-c940641-p12

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Vampire Counts | 8 | 2 (net +0) | 0 | 0 | 1 (net +70) | 1 (net +380) | 3 (net -29) | 1 | 0% (0 of 7) |
| Mine | Warriors of Chaos | 5 | 0 | 0 | 0 | 1 (net +187) | 1 (net +91) | 1 (net +0) | 2 | 0% (0 of 3) |
| Opponent | Warriors of Chaos | 8 | 1 (net +0) | 0 | 0 | 2 (net -60) | 1 (net +45) | 2 (net +22) | 2 | 0% (0 of 6) |
| Opponent | Wood Elf Realms | 1 | 1 (net +495) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: ccut-c940641-p12

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 367 | 186 | +0 | 78 | 210 | -132 | -35.9 |
| Mine | 76-89% | 2 | 136 | 166 | +128 | 128 | 0 | +128 | +94.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 191 | 143 | -22 | 55 | 72 | -17 | -9.0 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 487 | 106 | +236 | 236 | 0 | +236 | +48.4 |
| Mine | No odds | 3 | 165 | 235 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | All fights | 13 | 249 | 169 | +49 | 85 | 54 | +30 | +12.2 |
| Opponent | Long shot (under 50%) | 2 | 489 | 352 | +248 | 248 | 28 | +220 | +44.9 |
| Opponent | 76-89% | 2 | 116 | 152 | -60 | 25 | 85 | -60 | -51.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 346 | 212 | +22 | 22 | 148 | -125 | -36.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 479 | 45 | +45 | 45 | 0 | +45 | +9.4 |
| Opponent | No odds | 2 | 200 | 199 | +127 | 225 | 0 | +225 | +112.1 |
| Opponent | All fights | 9 | 309 | 208 | +80 | 121 | 58 | +63 | +20.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p12 | move | 20 | 5 (25%) | 4 (20%) | 5 (25%) | 10 (50%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L2531, L2730 |
| Charmed Shield | Opponent | L2934 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Ring of Doom | Opponent | L2531 |

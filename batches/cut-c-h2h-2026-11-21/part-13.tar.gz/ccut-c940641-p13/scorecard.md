# Doctrine scorecard: ccut-c940641-p13

### Scorecard: ccut-c940641-p13

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0106 | 4 | 1 | Opponent | no | 0 | 5 | 0 | 1 | 0 | 0 | 0 | 1064 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 3 | 1 | 2 | 1 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | 4 | 0 | 6 | 0 | 0 | 0 | 170 |
| L0206 | 2 | 1 | Opponent | - | - | - | 0 | 3 | 1 | 0 | 0 | 1078 |
| **Average** | | | Mine | 0% | 2.0 | 4.0 | 0.0 | 2.7 | 0.0 | 0.0 | 0.0 | 56.7 |
| **Average** | | | Opponent | 0% | 0.0 | 4.0 | 0.3 | 2.0 | 0.7 | 0.0 | 0.0 | 714.0 |

### KPIs: ccut-c940641-p13

Rules off - Mine only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 8) | 65% (11 of 17) | 44% (11 of 25) |
| Winner chose to follow up after the loser gave ground |  | 50% (1 of 2); on the table 50% | - | 50% (1 of 2); on the table 50% |
| Winner chose to pursue after the loser fell back in good order |  | 50% (1 of 2); on the table 100% | - | 50% (1 of 2); on the table 100% |
| Winner chose to pursue after the loser fled |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 50% (2 of 4); on the table 75% | 100% (1 of 1); on the table 100% | 60% (3 of 5); on the table 80% |
| Magic missiles tried each own turn | 50%+ | 64% (58 of 90) | - | 64% (58 of 90) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 69% (58 of 84) | - | 69% (58 of 84) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 100% (6 of 6) | - | 100% (6 of 6) |
| Points that never fought | lower | 52% (2938 of 5699) | 79% (4767 of 6000) | 66% (7705 of 11699) |
|   infantry points that never fought | lower | 52% (1163 of 2239) | 98% (2061 of 2111) | 74% (3224 of 4350) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (9 of 16) | 68% (17 of 25) | 63% (26 of 41) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 5.7 uses a game | 0.0 uses a game | 100% (4 of 4); 2.8 uses a game |
| Bound items with another spell used |  | 100% (2 of 2); 1.7 uses a game | 0.0 uses a game | 100% (2 of 2); 0.8 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (4 of 4); 1.3 uses a game | 0.0 uses a game | 100% (4 of 4); 0.7 uses a game |
|   their share of the points of units over 100 pts | lower | 45% (1758 of 3916) | 60% (2636 of 4382) | 53% (4394 of 8298) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 4.7 (44%) | - | 4.7 (44%) |
| MARCHED: its unit marched | 4.0 (38%) | - | 4.0 (38%) |
| IN COMBAT: engaged in combat | 2.0 (19%) | - | 2.0 (19%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.3 | 1.0 | 6.3 | 19.3 | 0.3 | 2.0 |
| not cast | 1.7 | 3.0 | 3.7 | 10.7 | 1.7 | 26.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.7 (56%) | 0.0 (0%) | 4.7 (44%) | 1.3 (80%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.0 (38%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.7 (18%) | 2.0 (19%) | 0.3 (20%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (100%) | 1.3 (44%) | 3.0 (82%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 24.0 (92%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 8.0 a game | 0.0 a game | 4.0 a game |
| stood (cast and not dispelled) | 67% (16 of 24) | - | 67% (16 of 24) |
| the unit moved after it | 50% (8 of 16) | - | 50% (8 of 16) |
| it charged on its next turn | 0% (0 of 16) | - | 0% (0 of 16) |
| the enemy charged it first | 6% (1 of 16) | - | 6% (1 of 16) |
| it fought by the end of its next turn | 0% (0 of 16) | - | 0% (0 of 16) |
| it moved out of a charge the enemy had planned (not charged first) | 6% (1 of 16) | - | 6% (1 of 16) |
| none of these (no charge, no fight, no charge escaped) | 88% (14 of 16) | - | 88% (14 of 16) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 55% (12 of 22) | 62% (123 of 198) | 61% (135 of 220) |
|   cavalry | - | 65% (20 of 31) | 65% (20 of 31) |
|   character | - | 64% (14 of 22) | 64% (14 of 22) |
|   chariot | - | 67% (4 of 6) | 67% (4 of 6) |
|   infantry | 55% (12 of 22) | 59% (37 of 63) | 58% (49 of 85) |
|   monster | - | 88% (7 of 8) | 88% (7 of 8) |
|   war machine | - | 60% (41 of 68) | 60% (41 of 68) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (70%) | 1.7 (7%) | 4.0 (14%) |
| CHARGED: it charged | 0.0 (0%) | 1.7 (7%) | 1.7 (6%) |
| NO TARGET IN RANGE | 0.7 (20%) | 9.7 (39%) | 10.3 (36%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 1.3 (5%) | 1.3 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.3 (10%) | 5.7 (23%) | 6.0 (21%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.7 (3%) | 0.7 (2%) |
| OTHER BAR | 0.0 (0%) | 4.3 (17%) | 4.3 (15%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 10.0 | 3.3 | 77% | 4.1 pts | 41 pts |
| character | 4.7 | 2.7 | 71% | 4.7 pts | 22 pts |
| chariot | 1.3 | 0.7 | 50% | 4.0 pts | 5 pts |
| infantry | 24.0 | 7.7 | 74% | 3.7 pts | 89 pts |
| monster | 2.7 | 0.3 | 88% | 1.0 pts | 3 pts |
| war machine | 13.7 | 16.7 | 41% | 15.3 pts | 209 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 1.0 | 2.7 | 1.8 |
| Charges that made contact a game | 1.0 | 2.0 | 1.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | - | - |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.15 declared, 0.15 contact (20 units) | 0.30 declared, 0.22 contact (27 units) | 0.23 declared, 0.19 contact (47 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Character in a unit | 100% (4 of 4) | 25% (1 of 4) | - | 62% (5 of 8) |
| Character on its own | 100% (2 of 2) | 100% (2 of 2) | 0% (0 of 2) | 67% (4 of 6) |
| Infantry | 71% (5 of 7) | 43% (3 of 7) | - | 57% (8 of 14) |
| Monster | 80% (4 of 5) | - | - | 80% (4 of 5) |
| War Machines | 62% (5 of 8) | - | - | 62% (5 of 8) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 3 | 50% (2 of 4); on the table 75% | 64% (58 of 90) | 52% | 56% (9 of 16) | 100% (4 of 4); 5.7 uses a game | 100% (2 of 2); 1.7 uses a game | 100% (4 of 4); 1.3 uses a game |
| Dwarfen Mountain Holds | 2 | - | - | 86% | 75% (15 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Tomb Kings of Khemri | 1 | 100% (1 of 1); on the table 100% | - | 66% | 40% (2 of 5) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p13, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 0% (0) | 0% (0) | 0% (0) |
| ...free all their last turn and able to turn (per game) | 0.00 | 0.00 | 0.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: ccut-c940641-p13

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 0.7 |
| Strategy | Charge objectives carried out (made contact) | 100% (3 of 3) | 62% (5 of 8) |
| Strategy | Shoot objectives carried out (shot that target) | 31% (4 of 13) | 47% (35 of 75) |
| Strategy | Support requests answered (helper made contact too) | - | 50% (1 of 2) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 0% (0 of 2) | - |
| Strategy | Joined characters whose unit fought | 75% (9 of 12) | 0% (0 of 8) |
| Strategy | Lone characters that fought | 0% (0 of 6) | 50% (1 of 2) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.7 | 2.0 |
| Movement | Points that never moved of their own | 56.7 | 714.0 |
| Movement | Fights charged into per game | 0.7 | 1.3 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 2 | 2 of 4, net -52 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 2, net +0 | 0 of 4 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 2 | 1 of 4, net -65 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 2 | 1 of 4, net +55 |
| Shooting | Shots by shooting units (incl. breath weapons) | 4.3 | 29.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 31% (4 of 13) | 57% (50 of 87) |
| Shooting | Points destroyed by shooting units | 0.0 | 191.0 |
| Shooting | War machine shots | - | 13.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | - | 59% (24 of 41) |
| Shooting | Points destroyed by war machines | 0.0 | 34.7 |
| Magic | Magic missiles cast | 10.0 | - |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 53% (16 of 30) | - |
| Magic | Wounds caused by magic missiles | 20.0 | - |
| Magic | Wounds caused by other spells | 0.7 | - |
| Magic | Points destroyed by magic (all spells) | 281.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.3 / 0.7 / 1.3 / 0.3 | 3.3 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 140.0 | 50.0 |
| Combat | Points run down | 0.0 | 18.3 |
| Combat | Net points per charged fight, damage counted | -49 | -5 |
| Combat | Net per 100 charger points, damage counted | -58.3 | -1.6 |
| Combat | First round won (charged fights) | 100% | 50% |
| Combat | Net points per charged fight | +18 | -29 |
| Combat | Net points per supported fight / lone fight | +0 / +35 | -85 / +28 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 2 | 2 of 4 |
| Game | Points lost | 315.7 | 438.3 |
| Game | VP from objectives | 830.0 | 493.3 |
| Game | Lone holders (player turns) | 2.0 | 0.0 |

- Mine won / drew / lost: 2 / 1 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +454 VP
- The side that went first won 1 of 2 games with a winner
- Points traded per game (both sides' losses): 754
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ccut-c940641-p13

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +172.7 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH WITH FRIENDS | 0.3 | +7.7 | 0.0 | 17.3 | - | - | - | - |
| ALREADY CARRIED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 20.7 | +119.7 | 0.0 | 250.3 | 23.7 | +300.2 | 0.0 | 149.0 |
| BACKUP TARGETS | - | - | - | - | 0.3 | +0.2 | 0.0 | 0.0 |
| CANNON PLAN MISSED | - | - | - | - | 0.7 | +0.0 | 181.3 | 0.0 |
| CANNON PLANNED TARGET | - | - | - | - | 14.0 | +301.8 | 668.7 | 40.0 |
| CANNON SIGHT KEPT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | 4.7 | +412.6 | 88.0 | 181.3 | - | - | - | - |
| CASTS AFTER FRIENDS | 5.0 | +0.0 | 0.0 | 73.3 | - | - | - | - |
| CATCH FLIERS | 0.3 | +10.4 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 2.3 | +64.6 | 0.0 | 18.3 | - | - | - | - |
| CHAFF PASSED | - | - | - | - | 4.3 | -0.2 | 0.0 | 24.0 |
| CHALLENGE BY POINTS | 0.3 | +5.8 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | - | - | - | - | 7.3 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 17.7 | -1213.0 | 0.0 | 315.7 | 11.7 | -277.3 | 0.0 | 117.7 |
| CHARGE NOW FIRST | 0.3 | +0.0 | 40.0 | 28.3 | 1.0 | +0.0 | 60.7 | 65.0 |
| CHARIOT NO STATIC JOB | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 8.3 | +0.0 | 0.0 | 17.3 | 8.3 | +0.0 | 0.0 | 261.0 |
| CONVEYANCE SEARCH | 6.0 | +987.5 | 90.7 | 73.3 | - | - | - | - |
| COVER ONCE | 6.0 | -237.8 | 0.0 | 151.3 | 4.3 | -137.0 | 0.0 | 126.0 |
| DEFENSIVE ARMY | - | - | - | - | 0.3 | +0.0 | 90.7 | 0.0 |
| DENIED BY THE FIGHT | 0.3 | -0.3 | 35.0 | 17.3 | 0.7 | -0.8 | 21.7 | 0.0 |
| DEPLOY BY FIGURES | 6.7 | +87.5 | 0.0 | 0.0 | 12.3 | -197.3 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -245.9 | 0.0 | 0.0 |
| EXACT ROUND | 1.0 | +3.7 | 110.0 | 45.7 | 1.0 | -0.6 | 40.0 | 100.0 |
| FALL BACK GOOD ORDER | 0.7 | +1.0 | 75.0 | 45.7 | 2.0 | +1.7 | 65.0 | 100.0 |
| FALLS SHORT | 13.3 | +391.3 | 0.0 | 252.7 | 16.7 | +44.6 | 0.0 | 237.3 |
| FEATURE BUFFS | 16.0 | +491.9 | 0.0 | 169.3 | 1.0 | +5.0 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.7 | +1.6 | 70.0 | 17.3 | 0.3 | +47.8 | 0.0 | 0.0 |
| FIVE ACTION | 71.7 | +7616.7 | 403.0 | 923.7 | 139.3 | +3936.7 | 1988.7 | 1012.0 |
| FLANK NOT WEIGHED | 3.7 | +0.0 | 0.0 | 63.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 0.3 | +88.4 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 1.0 | +16.0 | 110.0 | 45.7 | 2.7 | +139.6 | 105.0 | 100.0 |
| FREED FROM HIS FIGHT | 1.7 | +0.0 | 0.0 | 45.7 | 1.3 | +0.0 | 0.0 | 20.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 1.3 | -18.1 | 0.0 | 0.0 |
| GOAL WALK | 14.7 | +2519.5 | 0.0 | 91.3 | 0.3 | +11.9 | 0.0 | 0.0 |
| GUN FIGURES | - | - | - | - | 0.7 | +64.2 | 73.3 | 0.0 |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 1.0 | +0.0 | 0.0 | 45.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 12.0 | +0.0 | 0.0 | 315.7 | 4.7 | +0.0 | 0.0 | 61.0 |
| HIS CHARGE LIST | 15.0 | +0.0 | 0.0 | 113.7 | 5.7 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 4.3 | +0.0 | 0.0 | 86.7 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 5.0 | -47.5 | 0.0 | 28.3 | 1.7 | -80.8 | 0.0 | 20.0 |
| HIS MOVE AS HE DECIDES | 46.0 | +16.3 | 631.7 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 15.0 | +0.0 | 0.0 | 212.0 |
| HIS ONE MOVE | 15.7 | +49.4 | 0.0 | 108.0 | - | - | - | - |
| HIS ONE QUARTER | 0.7 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 2.0 | +0.0 | 0.0 | 17.3 | 5.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 10.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 55.0 | +1640.4 | 0.0 | 653.3 | 58.7 | +2252.7 | 0.0 | 316.7 |
| HIS SHOTS BY HIS RUN | 45.7 | +867.0 | 0.0 | 653.3 | 48.3 | +1353.6 | 0.0 | 536.7 |
| HIS TURN DENIED | 0.7 | +4.8 | 70.0 | 17.3 | 1.7 | +18.4 | 43.3 | 35.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 40.0 | +0.0 | 0.0 | 403.7 | 14.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 15.0 | +1536.1 | 0.0 | 155.7 | 9.0 | +1010.1 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.0 | -3.4 | 110.0 | 45.7 | 2.0 | -80.3 | 105.0 | 65.0 |
| HUNT IN PAIRS | - | - | - | - | 2.0 | +277.3 | 0.0 | 65.0 |
| HUNT RESULT | 0.3 | +43.1 | 0.0 | 0.0 | - | - | - | - |
| HUNT THE GUNS | 0.3 | +44.7 | 40.0 | 28.3 | - | - | - | - |
| IDLE COST | 10.3 | -73.0 | 0.0 | 171.0 | 6.3 | -116.7 | 0.0 | 24.0 |
| JOINT CHARGE NOW | 0.3 | +11.5 | 35.0 | 0.0 | 2.0 | +20.7 | 65.0 | 100.0 |
| KEEPS SCOUTS OR AMBUSH | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 3.3 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +18.2 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 9.7 | +0.0 | 378.0 | 203.3 | 6.7 | +0.0 | 268.0 | 210.0 |
| LONE WIZARD KEPT IN | 2.7 | +247.6 | 0.0 | 0.0 | 0.7 | +60.4 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.7 | -1.1 | 70.0 | 17.3 | 2.0 | -0.9 | 86.7 | 100.0 |
| MAKE SURE TOGETHER | - | - | - | - | 0.7 | +0.5 | 0.0 | 35.0 |
| MANOEUVRE | 1.3 | +11.1 | 0.0 | 119.0 | 1.7 | -9.1 | 0.0 | 100.0 |
| MARCH BY THE SUM | 1.7 | +123.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.7 | +14.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 2.0 | -78.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.0 | +56.6 | 0.0 | 0.0 | 3.3 | +40.3 | 0.0 | 35.0 |
| MEETS IN TIME | 3.0 | +105.1 | 0.0 | 0.0 | 7.7 | +68.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 8.0 | +453.0 | 0.0 | 235.3 | - | - | - | - |
| MISSILES NEXT TURN | 9.3 | +316.6 | 0.0 | 144.7 | - | - | - | - |
| MISSILES ON ONE TARGET | 3.3 | -75.9 | 0.0 | 181.3 | - | - | - | - |
| MODEL FACING | - | - | - | - | 4.0 | +1144.1 | 0.0 | 40.0 |
| MOVE ORDER | 0.7 | +0.0 | 21.7 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 2.3 | -63.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 2.3 | +0.0 | 0.0 | 90.7 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 1.3 | +134.9 | 0.0 | 0.0 | 4.0 | +103.3 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 5.3 | +222.1 | 0.0 | 43.3 | 10.0 | +465.1 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 1.0 | +132.6 | 0.0 | 0.0 | 2.3 | +47.3 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 1.0 | -89.5 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 1.0 | -20.2 | 110.0 | 45.7 | 2.7 | -56.3 | 105.0 | 100.0 |
| NO LATE CUT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.7 | -2.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 2.0 | -78.5 | 0.0 | 0.0 | 6.0 | -132.6 | 0.0 | 58.3 |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.3 | -145.5 | 0.0 | 175.3 | 5.0 | -45.2 | 0.0 | 96.0 |
| ONE JOINT FIGURE | 0.7 | -4.3 | 70.0 | 17.3 | 1.0 | -7.2 | 0.0 | 35.0 |
| ONE OBJECTIVE FORMULA | 9.0 | -80.3 | 0.0 | 134.0 | 3.7 | -167.5 | 0.0 | 0.0 |
| ONE ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | - | - | - | - | 3.0 | +11.3 | 86.7 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.7 | +20.5 | 43.3 | 65.0 |
| PIVOT GUARDS FLANK | 0.7 | -31.2 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 32.7 | +101.7 | 138.0 | 484.7 | 61.0 | +935.5 | 587.7 | 843.3 |
| PROMISE BY ITS OWN SUM | 1.3 | +0.0 | 0.0 | 0.0 | 4.0 | -33.6 | 0.0 | 0.0 |
| PROMISE IN STEPS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.7 | -10.9 | 0.0 | 0.0 |
| QUARTER ODDS | 6.7 | +1123.3 | 162.0 | 0.0 | 16.0 | +730.5 | 0.0 | 472.3 |
| RANDOM MOVE BY FIGURES | 2.0 | +20.6 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 1.3 | +15.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | 1.7 | +58.7 | 0.0 | 18.3 | 2.3 | +83.5 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 4.3 | +24.4 | 0.0 | 119.0 | 3.3 | +0.0 | 0.0 | 24.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -1.8 | 0.0 | 0.0 | 2.0 | -0.3 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +2.7 | 0.0 | 0.0 | 1.0 | -2.1 | 0.0 | 0.0 |
| RESERVE MOVE SPELL | 2.0 | +115.7 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.0 | -18.6 | 110.0 | 45.7 | 1.7 | -30.8 | 43.3 | 100.0 |
| RISK ON THE WAY | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 1.7 | +59.7 | 86.7 | 65.0 |
| RUN DOWN | 0.7 | -2.3 | 70.0 | 17.3 | 2.0 | -8.7 | 105.0 | 65.0 |
| SCOUT SPOT | 0.7 | +0.4 | 0.0 | 0.0 | 0.7 | -0.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +0.6 | 0.0 | 0.0 | 0.3 | +14.1 | 0.0 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 3.3 | -400.7 | 0.0 | 0.0 |
| SET UP BY THE SET | - | - | - | - | 5.7 | +575.6 | 0.0 | 130.0 |
| SET UP TOGETHER | - | - | - | - | 1.0 | +1.1 | 0.0 | 35.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 1.7 | +4.0 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 4.3 | +0.0 | 0.0 | 112.3 | 24.3 | +0.0 | 0.0 | 177.7 |
| SHOOTS FROM THE BEST SPOT | 1.7 | +64.6 | 35.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| SHORT GUN FORWARD | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.7 | -1.4 | 0.0 | 35.0 |
| SHOT RISK POINTS | 34.7 | -176.7 | 0.0 | 318.3 | 48.0 | +491.1 | 0.0 | 495.7 |
| SHOTS AFTER THE MOVES | 1.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 4.3 | +99.6 | 0.0 | 86.7 | 45.3 | +1083.6 | 0.0 | 213.3 |
| SPELL WORTH | 1.3 | +13.7 | 130.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 5.0 | +0.0 | 0.0 | 68.3 | 5.3 | +0.0 | 0.0 | 83.3 |
| STAND AND SHOOT | 0.7 | -1.9 | 70.0 | 17.3 | 1.3 | -5.2 | 86.7 | 65.0 |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 0.0 | 8.0 | +0.0 | 0.0 | 48.0 |
| STANDS STILL | 19.7 | +0.0 | 293.0 | 304.7 | 93.7 | +0.0 | 1883.7 | 443.3 |
| STAY WORTH | 7.3 | +47.7 | 40.0 | 181.3 | 66.0 | -166.2 | 646.7 | 112.3 |
| STOPS | 0.3 | +3.4 | 40.0 | 28.3 | - | - | - | - |
| SUPPORT ADDS | 10.3 | +744.5 | 0.0 | 161.3 | 0.7 | +11.5 | 0.0 | 81.0 |
| SUPPORT WORKED OUT | 10.3 | +744.5 | 0.0 | 161.3 | 0.7 | +11.5 | 0.0 | 81.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +1.1 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 21.7 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 1.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.3 | +0.0 | 0.0 | 17.3 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | 1.7 | +0.0 | 0.0 | 126.3 | - | - | - | - |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 108.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 34.0 | +0.0 | 0.0 | 439.0 | 63.3 | +0.0 | 0.0 | 456.0 |
| TIED UP BY THE SUM | - | - | - | - | 0.7 | +62.4 | 43.3 | 65.0 |
| TIME ON OUR SIDE | 11.7 | +285.5 | 0.0 | 160.0 | 45.7 | +369.5 | 0.0 | 130.0 |
| WAITS AGAIN | 2.7 | +0.0 | 0.0 | 108.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| WEAPON BY POINTS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WHO FIGHTS | 0.3 | +1.1 | 35.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 3.0 | -801.2 | 0.0 | 216.0 | 0.3 | -22.7 | 0.0 | 0.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.3 | +28.8 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 8.0 | +692.6 | 0.0 | 181.3 | 1.0 | +10.0 | 0.0 | 0.0 |

### Rule changes: ccut-c940641-p13

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS SHOT LIST | 341 | 335 | 93 | 31.00 | +1455 | +15.6 |
| ARMY TABLE | 133 | 133 | 91 | 30.33 | +1003 | +11.0 |
| HIS MOVE AS HE DECIDES | 138 | 138 | 89 | 29.67 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 282 | 277 | 88 | 29.33 | +1144 | +13.0 |
| HOLDER ASSIGNMENT | 72 | 72 | 70 | 23.33 | +2810 | +40.1 |
| SHOT RISK POINTS | 248 | 243 | 59 | 19.67 | +1045 | +17.7 |
| LEGAL CHARGES ONLY | 49 | 49 | 49 | 16.33 | +0 | +0.0 |
| DEPLOY BY FIGURES | 57 | 57 | 34 | 11.33 | +500 | +14.7 |
| TIME ON OUR SIDE | 172 | 164 | 28 | 9.33 | +243 | +8.7 |
| OFF BEST | 24 | 24 | 24 | 8.00 | -634 | -26.4 |
| HARD STAY DROPPED | 23 | 23 | 23 | 7.67 | +0 | +0.0 |
| GOAL WALK | 45 | 45 | 22 | 7.33 | +3662 | +166.5 |
| REDIRECT FOR A FRIEND IN REACH | 23 | 23 | 21 | 7.00 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 21 | 7.00 | +0 | +0.0 |
| FIVE ACTION | 633 | 626 | 19 | 6.33 | +2072 | +109.1 |
| HIS MOVE WHY | 45 | 45 | 18 | 6.00 | +0 | +0.0 |
| HIS ONE MOVE | 47 | 47 | 18 | 6.00 | +0 | +0.0 |
| CASTING BLOCK | 14 | 14 | 14 | 4.67 | +450 | +32.1 |
| CHAFF PASSED | 13 | 13 | 13 | 4.33 | -1 | -0.0 |
| MEETS IN TIME | 32 | 32 | 12 | 4.00 | +122 | +10.1 |
| MODEL FACING | 12 | 12 | 12 | 4.00 | +3432 | +286.0 |
| SUPPORT ADDS | 33 | 33 | 12 | 4.00 | +423 | +35.2 |
| SUPPORT WORKED OUT | 33 | 33 | 12 | 4.00 | +423 | +35.2 |
| CANNON PLANNED TARGET | 42 | 42 | 10 | 3.33 | +15 | +1.5 |
| LONE WIZARD KEPT IN | 10 | 10 | 10 | 3.33 | +924 | +92.4 |
| WOUNDS ON THE RANKS | 27 | 27 | 9 | 3.00 | +600 | +66.6 |
| FEATURE BUFFS | 51 | 51 | 8 | 2.67 | +66 | +8.3 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| JOINT CHARGE NOW | 7 | 7 | 7 | 2.33 | +97 | +13.8 |
| QUARTER ODDS | 68 | 68 | 7 | 2.33 | +1044 | +149.1 |
| MAX FOR POSITIONING | 19 | 17 | 6 | 2.00 | +1 | +0.1 |
| MISSILES IN THE MOVE | 24 | 19 | 6 | 2.00 | +290 | +48.4 |
| MOVE TO CHARGE COMPUTED | 16 | 15 | 6 | 2.00 | +277 | +46.1 |
| RANDOM MOVE BY FIGURES | 6 | 6 | 6 | 2.00 | +62 | +10.3 |
| RESERVE MOVE SPELL | 6 | 6 | 6 | 2.00 | +347 | +57.8 |
| SET UP BY THE SET | 17 | 16 | 6 | 2.00 | +382 | +63.7 |
| SHOOTS FROM THE BEST SPOT | 6 | 6 | 6 | 2.00 | +61 | +10.2 |
| SHORT GUN FORWARD | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| THE RISK READS HIS RUN | 18 | 18 | 6 | 2.00 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| COVER ONCE | 31 | 24 | 5 | 1.67 | +115 | +23.0 |
| FALLS SHORT | 90 | 70 | 5 | 1.67 | +2 | +0.4 |
| FOUR ROUNDS | 11 | 11 | 5 | 1.67 | +293 | +58.5 |
| MARCH BY THE SUM | 5 | 5 | 5 | 1.67 | +369 | +73.9 |
| NEXT CHARGE BY LIST | 10 | 10 | 5 | 1.67 | +252 | +50.4 |
| SHOOTERS IN TWO RANKS | 5 | 5 | 5 | 1.67 | +12 | +2.4 |
| SHOTS IN THE MOVE | 149 | 135 | 5 | 1.67 | +349 | +69.9 |
| CHARGE LOSSES | 88 | 87 | 4 | 1.33 | +455 | +113.7 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| IDLE COST | 50 | 32 | 4 | 1.33 | +38 | +9.6 |
| NEARER NOT NEEDED | 46 | 46 | 4 | 1.33 | +181 | +45.2 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +2 | +0.5 |
| SCOUT WAITS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MOVE ORDER | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 16 | 16 | 3 | 1.00 | -101 | -33.5 |
| CHAFF IN THE MOVE | 7 | 6 | 2 | 0.67 | +13 | +6.7 |
| CHARIOT NO STATIC JOB | 2 | 2 | 2 | 0.67 | -69 | -34.6 |
| HIS TURN DENIED | 7 | 7 | 2 | 0.67 | +22 | +11.1 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +55 | +27.4 |
| ONE OBJECTIVE FORMULA | 38 | 28 | 2 | 0.67 | +71 | +35.5 |
| OPENS A LANE | 9 | 9 | 2 | 0.67 | +0 | +0.1 |
| PIVOT GUARDS FLANK | 2 | 2 | 2 | 0.67 | -94 | -46.8 |
| REDIRECT COUNTER | 12 | 10 | 2 | 0.67 | +37 | +18.6 |
| SEARCH SPOT | 2 | 2 | 2 | 0.67 | +44 | +22.0 |
| STAY WORTH | 220 | 213 | 2 | 0.67 | +4 | +1.9 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +518 | +518.2 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +23 | +23.1 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +17 | +17.4 |
| EXACT ROUND | 6 | 6 | 1 | 0.33 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 1 | 1 | 1 | 0.33 | +265 | +265.3 |
| FRIEND SHOOTS FIRST | 4 | 3 | 1 | 0.33 | +0 | +0.0 |
| HIS MOVE AND SHOT | 20 | 20 | 1 | 0.33 | +5 | +5.3 |
| MANOEUVRE | 9 | 9 | 1 | 0.33 | +93 | +93.0 |
| MISSILES NEXT TURN | 28 | 20 | 1 | 0.33 | +0 | +0.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| ONE FIGHT FORMULA | 31 | 25 | 1 | 0.33 | +0 | +0.3 |
| ONE JOINT FIGURE | 5 | 5 | 1 | 0.33 | +144 | +143.5 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +149 | +149.3 |
| REFORMS TO MEET IT | 8 | 7 | 1 | 0.33 | +0 | +0.0 |
| ROUNDS AFTER TERROR | 5 | 5 | 1 | 0.33 | +72 | +72.4 |
| SHOTS AFTER THE MOVES | 16 | 16 | 1 | 0.33 | +0 | +0.0 |
| STOPS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 8 | 1 | 1 | 0.33 | +0 | +0.0 |
| TIED UP BY THE SUM | 2 | 2 | 1 | 0.33 | +72 | +72.4 |
| WEAPON BY POINTS | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 10 | 10 | 1 | 0.33 | +17 | +16.6 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 15 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 22 | 22 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 4 | 4 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 50 | 50 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 18 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 1 | 1 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 8 | 8 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 18 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 9 | 9 | 0 | 0.00 | - | - |
| GUN FIGURES | 2 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 5 | 5 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 50 | 49 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 62 | 62 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 20 | 19 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 11 | 11 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 21 | 19 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 30 | 29 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 164 | 164 | 0 | 0.00 | - | - |
| HONEST WORTH | 9 | 9 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 6 | 6 | 0 | 0.00 | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| KEPT FROM ITS LAST STOP | 21 | 21 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 3 | 3 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 8 | 8 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 2 | not checked | - | - | - | - |
| MARCH CHECK | 2 | 2 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 6 | 6 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 5 | 5 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 10 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 7 | trace | - | - | - | - |
| MOVE SPELL SPOT | 7 | not checked | - | - | - | - |
| NEXT OBJECTIVE NEARER | 3 | 2 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 11 | 11 | 0 | 0.00 | - | - |
| NO LATE CUT | 3 | 3 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 5 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE ROUTE | 5 | 5 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 281 | trace | - | - | - | - |
| PROMISE IN STEPS | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 5 | 5 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 4 | 4 | 0 | 0.00 | - | - |
| RISK BY ARC | 8 | 8 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 4 | 4 | 0 | 0.00 | - | - |
| RUN DOWN | 8 | 8 | 0 | 0.00 | - | - |
| SCOUT SPOT | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 10 | 10 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 3 | 3 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 86 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 4 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 31 | 29 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 6 | 6 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 26 | 25 | 0 | 0.00 | - | - |
| STANDS STILL | 340 | 337 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 9 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 5 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 7 | not checked | - | - | - | - |
| THE TABLE BINDS | 292 | not checked | - | - | - | - |
| WAITS AGAIN | 9 | 8 | 0 | 0.00 | - | - |
| WHO FIGHTS | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p13

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 1.67 | 5.67 | 18.5 |
| ARMY TABLE | rule | 1.67 | 2.33 | 27.7 |
| HOLDER ASSIGNMENT | rule | 2.67 | 0.33 | 35.9 |
| CANNON PLANNED TARGET | rule | - | 1.00 | 1.7 |
| JOINT CHARGE NOW | rule | - | 1.00 | 33.2 |
| PROMISE BY ITS OWN SUM | rule | - | 1.00 | 33.5 |
| CHARIOT NO STATIC JOB | rule | 0.67 | - | 34.6 |
| PIVOT GUARDS FLANK | rule | 0.67 | - | 46.8 |
| CHAFF PASSED | rule | - | 0.33 | 0.5 |
| NO REASON | gate | - | 0.33 | 197.6 |
| RESERVE FALL BACK | rule | - | 0.33 | 22.1 |
| RULE SWITCHED OFF | gate | 0.33 | - | 29.1 |

### Plans: ccut-c940641-p13

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.0 | 33% | 13 | 75 | 557% |
| Mine | move | 27.7 | 94% | 3042 | 0 | 0% |
| Mine | shoot | 3.3 | 20% | 470 | 27 | 6% |
| Mine | support | 0.7 | 100% | 14 | 0 | 0% |
| Opponent | charge | 1.7 | 40% | 223 | 46 | 21% |
| Opponent | move | 39.3 | 96% | 1204 | 0 | 0% |
| Opponent | shoot | 20.0 | 87% | 270 | 890 | 329% |

### Packages: hunt the guns, ccut-c940641-p13

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.3 | 1 | 0 | 100% | 100% | 0% | 2.0 | 134 | 129 | 100% | 227 |
| Opponent | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.3 | 1 | 0 | 100% | 100% | 0% | 2.0 | 134 | 129 | 100% | 227 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: ccut-c940641-p13

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.7 | 20% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 2.3 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p13

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 4 | 0 (4) | 0 | 0 | 62 | 25% | 3.7 | 0 (2) | - | 0 (2) | 0 (3) | 0 (1) |
| Mine | Character | 15 | 38 (15) | 38 | 0 | 0 | 13% | 3.5 | - | 32 (10) | 66 (2) | 47 (6) | 32 (6) |
| Mine | Clean-up | 3 | 0 (3) | 0 | 0 | 67 | 67% | 3.0 | 0 (1) | 0 (2) | - | 0 (3) | - |
| Mine | Fast Hammer | 2 | 71 (2) | 71 | 0 | 50 | 50% | 4.0 | 71 (2) | - | - | 141 (1) | 0 (1) |
| Mine | Hammer | 6 | 82 (6) | 11 | 70 | 16 | 50% | 4.3 | 0 (1) | 105 (3) | 68 (2) | 56 (4) | 124 (2) |
| Mine | Holder | 5 | 49 (5) | 0 | 49 | 0 | 60% | 4.5 | 14 (3) | 195 (1) | 0 (1) | 0 (1) | 59 (4) |
| Mine | Shooter | 2 | 154 (2) | 0 | 154 | 100 | 0% | 1.0 | - | 308 (1) | 0 (1) | 154 (2) | - |
| Mine | Wizard | 3 | 0 (3) | 0 | 0 | 51 | 33% | 2.5 | - | - | 0 (1) | 0 (1) | - |
| Opponent | Chaff | 2 | 69 (2) | 0 | 69 | 50 | 0% | 1.5 | 139 (1) | 0 (1) | - | 69 (2) | - |
| Opponent | Character | 8 | 8 (8) | 8 | 0 | 0 | 38% | 2.6 | 0 (1) | 9 (6) | 0 (1) | 0 (4) | 11 (4) |
| Opponent | Clean-up | 6 | 28 (6) | 11 | 17 | 23 | 33% | 2.0 | 0 (1) | 43 (5) | - | 15 (5) | 66 (1) |
| Opponent | Fast Hammer | 4 | 12 (4) | 12 | 0 | 87 | 25% | 2.3 | 0 (1) | 7 (1) | 21 (2) | 15 (3) | 0 (1) |
| Opponent | Hammer | 3 | 0 (3) | 0 | 0 | 0 | 67% | 5.0 | 0 (1) | 0 (1) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Holder | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Shooter | 10 | 31 (10) | 0 | 31 | 23 | 10% | 2.4 | 87 (2) | 26 (8) | - | 43 (8) | 0 (2) |
| Opponent | War machine | 12 | 55 (12) | 55 | 0 | 19 | 8% | 1.7 | 54 (10) | - | 61 (2) | 35 (2) | 60 (10) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (2) | - | - | 0 (2) |

### Charged fights: ccut-c940641-p13

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 282 | 40 | 0.7 | 1.5 | 60 | 42 | +18 | 0 of 2 | 2 of 2 | +0 | +35 |
| Opponent | Dwarfen Mountain Holds | 2 | 338 | 0 | 0.5 | 2.0 | 0 | 105 | -105 | 1 of 1 | 0 of 1 | -105 | - |
| Opponent | Tomb Kings of Khemri | 1 | 0 | 185 | 3.0 | 1.3 | 62 | 65 | -3 | 1 of 3 | 2 of 3 | -65 | +28 |
| **Opponent** | all armies | 3 | 226 | 62 | 1.3 | 1.5 | 46 | 75 | -29 | 2 of 4 | 2 of 4 | -85 | +28 |

### Effective charges: ccut-c940641-p13

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 0 | 0 | 1 (net +0) | 1 (net +35) | 0 | 0 | 0 | 50% (1 of 2) |
| Opponent | Dwarfen Mountain Holds | 1 | 1 (net -105) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 3 | 1 (net +0) | 0 | 0 | 0 | 1 (net -65) | 1 (net +55) | 0 | 0% (0 of 3) |

### Charged fights, damage counted: ccut-c940641-p13

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 82 | 105 | +0 | 129 | 262 | -132 | -161.5 |
| Mine | 76-89% | 1 | 85 | 120 | +35 | 120 | 85 | +35 | +41.2 |
| Mine | All fights | 2 | 84 | 112 | +18 | 125 | 173 | -49 | -58.3 |
| Opponent | Long shot (under 50%) | 2 | 283 | 579 | -52 | 44 | 52 | -9 | -3.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 72 | 55 | +55 | 55 | 24 | +31 | +43.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 606 | 65 | -65 | 162 | 195 | -33 | -5.5 |
| Opponent | All fights | 4 | 311 | 320 | -29 | 76 | 81 | -5 | -1.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p13 | move | 17 | 0 (0%) | 0 (0%) | 0 (0%) | 17 (100%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122 |
| Ring of Doom | Mine | L0206 |

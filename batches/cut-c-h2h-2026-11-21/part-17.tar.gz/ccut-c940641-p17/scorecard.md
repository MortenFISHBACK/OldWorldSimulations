# Doctrine scorecard: ccut-c940641-p17

### Scorecard: ccut-c940641-p17

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0721 | 1 | 1 | Mine | no | 0 | 1 | 3 | 0 | 0 | 0 | 0 | 295 |
| L0721 | 1 | 1 | Opponent | yes | 2 | - | 2 | 2 | 1 | 0 | 0 | 410 |
| L0810 | 6 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 560 |
| L0810 | 6 | 1 | Opponent | no | 17 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | - | 1 | 1 | 0 | 0 | 0 | 390 |
| L0827 | 5 | 1 | Opponent | yes | - | 2 | 1 | 5 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 0.0 | 1.0 | 1.3 | 1.0 | 0.0 | 0.0 | 0.0 | 415.0 |
| **Average** | | | Opponent | 67% | 9.5 | 2.0 | 1.7 | 2.3 | 0.3 | 0.0 | 0.0 | 246.7 |

### KPIs: ccut-c940641-p17

Rules off - Mine only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 93% (14 of 15) | 0% (0 of 15) | 47% (14 of 30) |
| Winner chose to follow up after the loser gave ground |  | 50% (1 of 2); on the table 50% | 100% (10 of 10); on the table 100% | 92% (11 of 12); on the table 92% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 0% | 0% (0 of 2); on the table 0% |
| Winner chose to pursue after the loser fled |  | - | 50% (1 of 2); on the table 50% | 50% (1 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 33% (1 of 3); on the table 33% | 85% (11 of 13); on the table 85% | 75% (12 of 16); on the table 75% |
| Magic missiles tried each own turn | 50%+ | 67% (4 of 6) | 53% (19 of 36) | 55% (23 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 67% (4 of 6) | 58% (19 of 33) | 59% (23 of 39) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 56% (5 of 9) | 56% (5 of 9) |
| Points that never fought | lower | 57% (3393 of 5999) | 69% (4109 of 5998) | 63% (7502 of 11997) |
|   infantry points that never fought | lower | 92% (891 of 968) | 62% (687 of 1113) | 76% (1578 of 2081) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 67% (20 of 30) | 60% (15 of 25) | 64% (35 of 55) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (3 of 3); 3.0 uses a game | 100% (3 of 3); 1.5 uses a game |
| Bound items with another spell used |  | 100% (1 of 1); 1.0 uses a game | 0% (0 of 1); 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 33% (1 of 3); 0.3 uses a game | 50% (1 of 2); 0.3 uses a game | 40% (2 of 5); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 60% (3207 of 5378) | 63% (3289 of 5181) | 62% (6496 of 10559) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.7 (47%) | 2.7 (42%) |
| MARCHED: its unit marched | 0.7 (100%) | 1.7 (29%) | 2.3 (37%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.3 (6%) | 0.3 (5%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (12%) | 0.7 (11%) |
| GONE: slain | 0.0 (0%) | 0.3 (6%) | 0.3 (5%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 7.7 | 1.7 | 4.0 | 7.7 | 1.7 | 0.3 |
| not cast | 2.3 | 0.3 | 2.0 | 6.3 | 2.3 | 27.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (2%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.3 (100%) | 0.7 (33%) | 2.7 (42%) | 0.7 (29%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.3 (37%) | 0.7 (29%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (5%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (11%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 0.3 (14%) | 0.0 (0%) | 0.0 (0%) | 0.3 (5%) | 0.0 (0%) | 1.0 (4%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (43%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (86%) | 0.0 (0%) | 1.3 (67%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 26.0 (94%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 4.0 a game | 2.0 a game |
| stood (cast and not dispelled) | - | 58% (7 of 12) | 58% (7 of 12) |
| the unit moved after it | - | 43% (3 of 7) | 43% (3 of 7) |
| it charged on its next turn | - | 14% (1 of 7) | 14% (1 of 7) |
| the enemy charged it first | - | 0% (0 of 7) | 0% (0 of 7) |
| it fought by the end of its next turn | - | 0% (0 of 7) | 0% (0 of 7) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 7) | 0% (0 of 7) |
| none of these (no charge, no fight, no charge escaped) | - | 86% (6 of 7) | 86% (6 of 7) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 76% (63 of 83) | 71% (17 of 24) | 75% (80 of 107) |
|   cavalry | 79% (15 of 19) | - | 79% (15 of 19) |
|   chariot | 100% (8 of 8) | 69% (9 of 13) | 81% (17 of 21) |
|   infantry | 67% (8 of 12) | 62% (5 of 8) | 65% (13 of 20) |
|   war machine | 73% (32 of 44) | 100% (3 of 3) | 74% (35 of 47) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.3 (20%) | 0.3 (14%) | 1.7 (19%) |
| CHARGED: it charged | 0.3 (5%) | 0.0 (0%) | 0.3 (4%) |
| FLEEING: it fled or was fleeing | 0.7 (10%) | 0.0 (0%) | 0.7 (7%) |
| IN COMBAT: it fought this turn or the last | 0.7 (10%) | 0.7 (29%) | 1.3 (15%) |
| MOVED: a war machine that moved | 0.7 (10%) | 0.0 (0%) | 0.7 (7%) |
| NO TARGET IN RANGE | 0.3 (5%) | 1.3 (57%) | 1.7 (19%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (5%) | 0.0 (0%) | 0.3 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (20%) | 0.0 (0%) | 1.3 (15%) |
| SHELTERED: the target was sheltered | 0.3 (5%) | 0.0 (0%) | 0.3 (4%) |
| OTHER BAR | 0.7 (10%) | 0.0 (0%) | 0.7 (7%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 9.7 | 5.0 | 69% | 8.7 pts | 84 pts |
| chariot | 6.0 | 1.0 | 89% | 4.2 pts | 25 pts |
| infantry | 4.3 | 1.0 | 85% | 4.8 pts | 21 pts |
| war machine | 12.0 | 11.0 | 67% | 38.7 pts | 465 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.3 | 4.0 | 3.2 |
| Charges that made contact a game | 2.3 | 3.3 | 2.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (1 units) | 0.60 declared, 0.40 contact (5 units) | 0.50 declared, 0.33 contact (6 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (2 units) | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.32 declared, 0.32 contact (22 units) | 0.41 declared, 0.36 contact (22 units) | 0.36 declared, 0.34 contact (44 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 44% (4 of 9) | 33% (1 of 3) | 100% (1 of 1) | 46% (6 of 13) |
| Character in a unit | 100% (8 of 8) | - | - | 100% (8 of 8) |
| Character on its own | 67% (2 of 3) | 50% (1 of 2) | 50% (2 of 4) | 56% (5 of 9) |
| Chariot | 67% (2 of 3) | 50% (1 of 2) | - | 60% (3 of 5) |
| Infantry | 33% (1 of 3) | 100% (1 of 1) | 50% (1 of 2) | 50% (3 of 6) |
| Monster | - | 0% (0 of 1) | - | 0% (0 of 1) |
| War Machines | 77% (10 of 13) | - | - | 77% (10 of 13) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 3 | 33% (1 of 3); on the table 33% | 67% (4 of 6) | 57% | 67% (20 of 30) | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Grand Cathay | 1 | - | 58% (14 of 24) | 90% | 40% (4 of 10) | 100% (2 of 2); 7.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Skaven | 1 | 0% (0 of 2); on the table 0% | 33% (2 of 6) | 39% | 67% (6 of 9) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Vampire Counts | 1 | 100% (11 of 11); on the table 100% | 50% (3 of 6) | 77% | 83% (5 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p17, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 38% (3) | 60% (3) | 46% (6) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.67 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.33 | 0.67 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.00 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.33 | 0.33 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: ccut-c940641-p17

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.0 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 57% (4 of 7) | 75% (9 of 12) |
| Strategy | Shoot objectives carried out (shot that target) | 20% (9 of 46) | 14% (2 of 14) |
| Strategy | Support requests answered (helper made contact too) | 100% (1 of 1) | 100% (1 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 100% (4 of 4) | - |
| Strategy | Joined characters whose unit fought | 17% (1 of 6) | 50% (2 of 4) |
| Strategy | Lone characters that fought | 38% (3 of 8) | 22% (2 of 9) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.0 | 2.3 |
| Movement | Points that never moved of their own | 415.0 | 246.7 |
| Movement | Fights charged into per game | 2.0 | 2.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 6 | 2 of 8, net +125 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 6, net -71 | 0 of 8 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 6 | 1 of 8, net +215 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 of 6, net -19 | 2 of 8, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 11.7 | 4.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 29% (10 of 35) | 64% (9 of 14) |
| Shooting | Points destroyed by shooting units | 88.0 | 0.0 |
| Shooting | War machine shots | 10.7 | 1.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 56% (18 of 32) | 0% (0 of 4) |
| Shooting | Points destroyed by war machines | 222.0 | 43.3 |
| Magic | Magic missiles cast | 1.3 | 3.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 75% (3 of 4) | 60% (6 of 10) |
| Magic | Wounds caused by magic missiles | 0.3 | 8.7 |
| Magic | Wounds caused by other spells | 1.0 | - |
| Magic | Points destroyed by magic (all spells) | 96.7 | 54.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 1.3 / 0.3 / 0.0 | 4.3 / 0.0 / 0.0 / 0.7 |
| Combat | Points destroyed in combat | 70.0 | 340.0 |
| Combat | Points run down | 0.0 | 56.7 |
| Combat | Net points per charged fight, damage counted | +10 | +145 |
| Combat | Net per 100 charger points, damage counted | +4.9 | +95.7 |
| Combat | First round won (charged fights) | 100% | 62% |
| Combat | Net points per charged fight | -28 | +90 |
| Combat | Net points per supported fight / lone fight | +0 / -34 | +0 / +103 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 6 | 3 of 8 |
| Game | Points lost | 607.7 | 605.7 |
| Game | VP from objectives | 606.7 | 636.7 |
| Game | Lone holders (player turns) | 0.0 | 9.5 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) +22 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1213
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ccut-c940641-p17

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +62.3 | 0.0 | 0.0 | - | - | - | - |
| AFTERMATH WITH FRIENDS | - | - | - | - | 0.3 | +8.3 | 0.0 | 0.0 |
| ARMY TABLE | 10.3 | +193.2 | 0.0 | 54.7 | 17.7 | +672.4 | 0.0 | 224.3 |
| ARTILLERY RE-ROLL WEIGHED | 3.3 | +0.0 | 0.0 | 170.0 | 0.3 | +0.0 | 0.0 | 55.0 |
| BACKUP TARGETS | 1.0 | +11.8 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 43.3 | 55.0 |
| CANNON PLANNED TARGET | 9.0 | +545.0 | 713.3 | 301.7 | 1.0 | +107.3 | 86.7 | 165.0 |
| CANNON SIGHT KEPT | 2.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 55.0 |
| CAST JOB | 0.7 | +134.2 | 360.0 | 0.0 | 4.3 | +65.4 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.3 | +3.3 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | - | - | - | - | 2.0 | +47.0 | 0.0 | 36.3 |
| CHAFF PASSED | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | - | - | - | - | 4.0 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 12.0 | -644.6 | 0.0 | 84.7 | 17.3 | -1685.0 | 0.0 | 570.0 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 2.7 | +0.0 | 408.3 | 156.7 | 1.7 | +0.0 | 56.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 6.7 | +0.0 | 0.0 | 0.0 | 12.3 | +0.0 | 0.0 | 18.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 48.3 |
| CONVEYANCE SEARCH | - | - | - | - | 4.7 | +305.1 | 0.0 | 0.0 |
| COVER ONCE | 5.0 | -279.5 | 0.0 | 131.7 | 6.7 | -405.0 | 0.0 | 381.7 |
| DEFENSIVE ARMY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| DENIED BY THE FIGHT | 0.7 | -2.9 | 0.0 | 0.0 | 1.0 | -14.3 | 41.7 | 0.0 |
| DEPLOY BY FIGURES | 7.0 | -106.9 | 0.0 | 0.0 | 7.3 | -20.3 | 0.0 | 55.0 |
| EXACT ROUND | 1.7 | -8.1 | 48.3 | 93.7 | 3.0 | +1.7 | 156.7 | 0.0 |
| FALL BACK GOOD ORDER | 2.0 | +42.9 | 48.3 | 156.7 | 3.7 | +6.0 | 141.7 | 0.0 |
| FALLS SHORT | 2.7 | +52.4 | 0.0 | 30.0 | 21.7 | +210.4 | 0.0 | 245.0 |
| FEATURE BUFFS | 0.7 | +11.0 | 0.0 | 0.0 | 2.0 | +18.4 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.0 | +9.6 | 48.3 | 93.7 | 1.3 | +104.3 | 0.0 | 0.0 |
| FIVE ACTION | 86.0 | +7799.8 | 3017.0 | 1107.7 | 91.0 | +4201.0 | 330.0 | 1619.3 |
| FLANK NOT WEIGHED | 5.0 | +0.0 | 0.0 | 15.0 | 6.3 | +0.0 | 0.0 | 180.0 |
| FOLLOW UP WEIGHED | 1.3 | +175.0 | 0.0 | 156.7 | 1.3 | +225.7 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.3 | +156.6 | 48.3 | 156.7 | 4.0 | +262.2 | 156.7 | 0.0 |
| FREED FROM HIS FIGHT | 2.3 | +0.0 | 0.0 | 0.0 | 4.7 | +0.0 | 0.0 | 250.0 |
| FRIEND SHOOTS FIRST | 1.3 | -74.6 | 0.0 | 0.0 | - | - | - | - |
| GOAL WALK | 7.0 | +405.3 | 0.0 | 0.0 | 17.0 | +1257.2 | 0.0 | 0.0 |
| GUN FIGURES | 2.7 | +21.7 | 15.0 | 0.0 | 1.7 | +4.7 | 126.0 | 86.7 |
| GUN MASK | 1.3 | +20.9 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 3.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 180.0 |
| HIS CHARGE BY HIS RUN | 5.3 | +0.0 | 0.0 | 30.0 | 8.7 | +0.0 | 0.0 | 500.0 |
| HIS CHARGE DENIED | 0.3 | +0.6 | 0.0 | 0.0 | 0.3 | +143.9 | 0.0 | 0.0 |
| HIS CHARGE LIST | 4.0 | +0.0 | 0.0 | 30.0 | 3.7 | +0.0 | 0.0 | 70.0 |
| HIS LEGAL MOVES | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.3 | -47.9 | 0.0 | 54.7 | 1.7 | -27.2 | 0.0 | 70.0 |
| HIS MOVE AS HE DECIDES | 45.3 | +13.3 | 499.3 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 26.0 | +0.0 | 0.0 | 315.0 |
| HIS ONE MOVE | 16.3 | -19.3 | 0.0 | 0.0 | - | - | - | - |
| HIS ONE QUARTER | - | - | - | - | 2.3 | +0.0 | 0.0 | 48.0 |
| HIS OWN BEST MOVE | 1.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 6.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 29.0 | +707.1 | 0.0 | 155.0 | 54.3 | +3265.8 | 0.0 | 929.3 |
| HIS SHOTS BY HIS RUN | 22.3 | +442.9 | 0.0 | 84.7 | 51.7 | +1860.5 | 0.0 | 979.3 |
| HIS TURN DENIED | 0.3 | +3.4 | 0.0 | 0.0 | 2.3 | +121.9 | 126.7 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 11.7 | +0.0 | 0.0 | 0.0 | 18.7 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 7.3 | +915.0 | 0.0 | 0.0 | 11.3 | +941.2 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 1.7 | -25.2 | 48.3 | 156.7 | 3.0 | -76.6 | 115.0 | 0.0 |
| HUNT IN PAIRS | - | - | - | - | 1.0 | +52.0 | 0.0 | 0.0 |
| HUNT RESULT | - | - | - | - | 0.3 | +154.3 | 41.7 | 15.0 |
| HUNT THE GUNS | - | - | - | - | 0.3 | +182.4 | 41.7 | 0.0 |
| IDLE COST | 2.0 | -24.9 | 0.0 | 15.0 | 14.0 | -182.4 | 0.0 | 201.7 |
| JOINT CHARGE NOW | 0.7 | -1.4 | 0.0 | 0.0 | 1.0 | -78.0 | 0.0 | 0.0 |
| KEEP FALLS | 0.3 | +13.6 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 0.3 | +1.4 | 0.0 | 0.0 | 1.0 | +51.5 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.0 | +0.0 | 70.0 | 374.7 | 5.3 | +0.0 | 43.3 | 0.0 |
| LONE WIZARD KEPT IN | 0.7 | +46.6 | 0.0 | 0.0 | 0.3 | +58.3 | 0.0 | 0.0 |
| LONG SHOT | - | - | - | - | 0.3 | +1.1 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 1.3 | -4.2 | 48.3 | 93.7 | 2.0 | +8.6 | 126.7 | 0.0 |
| LOST CHARGE | 0.3 | -0.4 | 0.0 | 63.0 | - | - | - | - |
| MAKE SURE TOGETHER | - | - | - | - | 0.3 | +1.4 | 0.0 | 180.0 |
| MANOEUVRE | 2.3 | -9.8 | 0.0 | 0.0 | 1.3 | +36.2 | 0.0 | 21.7 |
| MARCH BY THE SUM | 0.3 | +32.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | - | - | - | - | 0.7 | +34.3 | 0.0 | 0.0 |
| MARCH OF THE TABLE | - | - | - | - | 1.0 | +64.7 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | -6.2 | 0.0 | 0.0 | 1.3 | +187.7 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 2.3 | +108.5 | 0.0 | 0.0 | 3.7 | +111.5 | 0.0 | 180.0 |
| MEETS IN TIME | 4.0 | +342.3 | 0.0 | 0.0 | 4.3 | +157.8 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.3 | +210.3 | 0.0 | 0.0 | 8.3 | +130.3 | 0.0 | 360.0 |
| MISSILES NEXT TURN | 1.7 | +116.3 | 0.0 | 0.0 | 11.3 | +129.8 | 0.0 | 360.0 |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 21.7 | 180.0 |
| MOVE SPELL SPOT | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 3.0 | +273.6 | 0.0 | 0.0 | 5.0 | +804.5 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 7.3 | +284.3 | 0.0 | 54.7 | 7.3 | +309.6 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 1.7 | +207.6 | 0.0 | 0.0 | 5.0 | +785.8 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.0 | -111.4 | 48.3 | 156.7 | 2.7 | -116.4 | 126.7 | 0.0 |
| NO LATE CUT | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.4 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 2.7 | -97.9 | 0.0 | 130.0 | 3.0 | -71.5 | 0.0 | 73.0 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 0.3 | +36.0 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 5.7 | -111.8 | 0.0 | 0.0 | 5.3 | -114.4 | 0.0 | 180.0 |
| ONE JOINT FIGURE | 0.3 | -2.2 | 0.0 | 0.0 | 0.3 | +10.8 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 2.7 | +98.2 | 0.0 | 0.0 | 7.0 | -57.6 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | - | - | - | - | 0.3 | -71.9 | 0.0 | 0.0 |
| ONE ROUTE | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OPENS A LANE | 0.7 | +2.4 | 96.7 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.3 | +11.5 | 15.0 | 0.0 |
| PATHS CROSS | 0.3 | +2.4 | 0.0 | 0.0 | 0.7 | +2.1 | 0.0 | 0.0 |
| PERIAPT WORTH | - | - | - | - | 0.3 | +24.8 | 0.0 | 0.0 |
| PLAN RESULT | 38.3 | +1372.0 | 1561.0 | 812.3 | 46.7 | +388.0 | 218.0 | 901.0 |
| PROMISE BY ITS OWN SUM | 4.0 | -71.5 | 0.0 | 0.0 | 6.0 | -182.3 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 1.0 | -1.4 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.7 | -38.1 | 0.0 | 0.0 | 0.3 | -28.2 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.7 | -0.4 | 0.0 | 41.7 | - | - | - | - |
| QUARTER ODDS | 19.0 | +1503.5 | 1608.7 | 173.3 | 16.3 | +1179.7 | 0.0 | 504.3 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.0 | +59.0 | 0.0 | 285.0 |
| REAL GROUND | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 1.0 | +37.9 | 0.0 | 0.0 |
| REDIRECT COUNTER | 0.3 | +12.2 | 0.0 | 0.0 | 2.0 | +132.0 | 0.0 | 18.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.0 | +45.3 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.7 | -57.7 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.7 | -16.0 | 48.3 | 156.7 | 2.7 | +18.7 | 98.3 | 0.0 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 0.7 | -2.6 | 43.3 | 0.0 |
| RUN DOWN | 2.0 | -15.4 | 48.3 | 156.7 | 2.3 | -20.2 | 141.7 | 0.0 |
| SAFER THAN THE JOB | - | - | - | - | 0.3 | +21.1 | 0.0 | 0.0 |
| SCOUT SPOT | 0.7 | +4.7 | 0.0 | 0.0 | - | - | - | - |
| SCOUT WAITS | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.0 | -88.0 | 0.0 | 55.0 |
| SEARCH SPOT | 0.7 | +8.4 | 0.0 | 0.0 | 0.3 | +1.9 | 0.0 | 0.0 |
| SET CREDITED ONCE | - | - | - | - | 0.3 | -3.9 | 0.0 | 0.0 |
| SET UP BY THE SET | - | - | - | - | 1.0 | -19.0 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.3 | +1.4 | 0.0 | 180.0 |
| SET-UP ANY TARGET | - | - | - | - | 1.3 | +141.2 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.7 | +70.9 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 15.0 | +0.0 | 0.0 | 301.7 | 4.3 | +0.0 | 0.0 | 165.0 |
| SHOOTS FROM THE BEST SPOT | - | - | - | - | 2.0 | +32.5 | 0.0 | 180.0 |
| SHORT GUN FORWARD | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | - | - | - | - | 0.3 | +0.0 | 43.3 | 55.0 |
| SHOT RISK POINTS | 11.3 | +43.9 | 0.0 | 54.7 | 34.3 | -94.0 | 0.0 | 1094.3 |
| SHOTS AFTER THE MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 19.0 | +2194.7 | 0.0 | 439.7 | 6.0 | +239.9 | 0.0 | 251.7 |
| SPELL SETS UP CHARGE | - | - | - | - | 1.3 | +141.2 | 0.0 | 0.0 |
| SPELL WORTH | 1.7 | +3.6 | 0.0 | 0.0 | 5.7 | +95.9 | 360.0 | 360.0 |
| SPELLS IN THE FIGHT | 0.7 | -6.1 | 48.3 | 93.7 | - | - | - | - |
| SPOT AS THE GAME MOVES | 5.0 | +0.0 | 0.0 | 0.0 | 10.7 | +0.0 | 0.0 | 250.0 |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 180.0 |
| STANDS STILL | 53.7 | +0.0 | 2968.7 | 896.3 | 24.7 | +0.0 | 173.3 | 743.3 |
| STAY WORTH | 38.7 | +1762.5 | 2932.7 | 608.0 | 8.3 | +96.8 | 173.3 | 581.7 |
| STOPS | - | - | - | - | 0.3 | +18.3 | 41.7 | 0.0 |
| STRIKE BY THE ODDS | 0.7 | +82.4 | 0.0 | 0.0 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 3.0 | +61.5 | 0.0 | 0.0 | 3.7 | +66.3 | 0.0 | 36.7 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 3.0 | +61.5 | 0.0 | 0.0 | 3.7 | +66.3 | 0.0 | 36.7 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +1.5 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.7 | +12.7 | 0.0 | 67.3 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 41.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -28.2 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 3.3 | +0.0 | 0.0 | 0.0 | 6.3 | +0.0 | 0.0 | 201.7 |
| THE ROW KEEPS ITS WAY | 2.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 21.7 |
| THE STEP BACK IS MADE | 0.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 21.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 36.7 | +0.0 | 0.0 | 371.3 | 44.0 | +0.0 | 0.0 | 659.7 |
| TIED UP BY THE SUM | 1.3 | +117.7 | 0.0 | 63.0 | 0.3 | +17.2 | 15.0 | 0.0 |
| TIME ON OUR SIDE | 33.0 | +404.7 | 0.0 | 69.7 | 10.0 | +117.1 | 0.0 | 0.0 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| WALKS ON ITS ROUTE | 0.3 | -13.5 | 0.0 | 0.0 | - | - | - | - |
| WHO FIGHTS | 0.3 | -33.6 | 0.0 | 0.0 | 1.7 | +76.6 | 43.3 | 0.0 |
| WHO HITS BACK | 0.3 | +6.1 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 5.0 | -467.5 | 0.0 | 30.0 | 3.0 | -196.5 | 0.0 | 201.7 |
| WHOLE FIGHT GAIN | 0.3 | +1.5 | 0.0 | 0.0 | 0.3 | +1.0 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 3.0 | +34.5 | 0.0 | 0.0 | 2.7 | +130.1 | 0.0 | 0.0 |

### Rule changes: ccut-c940641-p17

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 136 | 136 | 96 | 32.00 | +0 | +0.0 |
| ARMY TABLE | 84 | 84 | 65 | 21.67 | +2235 | +34.4 |
| HIS SHOT LIST | 250 | 247 | 64 | 21.33 | +1348 | +21.1 |
| HIS MOVE WHY | 78 | 78 | 57 | 19.00 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 56 | 56 | 51 | 17.00 | +3966 | +77.8 |
| HIS SHOTS BY HIS RUN | 222 | 220 | 48 | 16.00 | +634 | +13.2 |
| FIVE ACTION | 531 | 525 | 32 | 10.67 | +1063 | +33.2 |
| TIME ON OUR SIDE | 129 | 118 | 30 | 10.00 | +26 | +0.9 |
| SHOT RISK POINTS | 137 | 134 | 27 | 9.00 | +677 | +25.1 |
| GOAL WALK | 72 | 72 | 26 | 8.67 | +1176 | +45.2 |
| THE TABLE AGAIN | 36 | 36 | 26 | 8.67 | +0 | +0.0 |
| DEPLOY BY FIGURES | 43 | 43 | 25 | 8.33 | +379 | +15.2 |
| LEGAL CHARGES ONLY | 25 | 25 | 25 | 8.33 | +0 | +0.0 |
| HIS ONE MOVE | 49 | 49 | 18 | 6.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 24 | 22 | 17 | 5.67 | +1028 | +60.5 |
| OFF BEST | 17 | 17 | 17 | 5.67 | -508 | -29.9 |
| NEXT CHARGE BY LIST | 20 | 18 | 16 | 5.33 | +1103 | +68.9 |
| CAST JOB | 15 | 15 | 15 | 5.00 | +228 | +15.2 |
| MOVE ORDER | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| MEETS IN TIME | 25 | 25 | 12 | 4.00 | +880 | +73.3 |
| ARTILLERY RE-ROLL WEIGHED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| HARD STAY DROPPED | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| QUARTER ODDS | 106 | 104 | 10 | 3.33 | +642 | +64.2 |
| CANNON SIGHT KEPT | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| CHARGE LOSSES | 88 | 87 | 9 | 3.00 | +719 | +79.8 |
| FOUR ROUNDS | 19 | 19 | 9 | 3.00 | +330 | +36.7 |
| FOLLOW UP WEIGHED | 8 | 8 | 8 | 2.67 | +1202 | +150.3 |
| SUPPORT ADDS | 20 | 19 | 8 | 2.67 | +81 | +10.1 |
| SUPPORT WORKED OUT | 20 | 19 | 8 | 2.67 | +81 | +10.1 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| IDLE COST | 48 | 40 | 7 | 2.33 | +28 | +3.9 |
| PROMISE BY ITS OWN SUM | 30 | 30 | 7 | 2.33 | -761 | -108.7 |
| CHARGE NOW FIRST | 13 | 13 | 6 | 2.00 | -463 | -77.2 |
| SHOOTS FROM THE BEST SPOT | 6 | 6 | 6 | 2.00 | +26 | +4.4 |
| WHOLE FIGHT DANGER | 24 | 24 | 6 | 2.00 | +223 | +37.2 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | -238 | -47.7 |
| RANDOM MOVE BY FIGURES | 9 | 9 | 5 | 1.67 | +177 | +35.4 |
| THE RISK READS HIS RUN | 18 | 18 | 5 | 1.67 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 17 | 17 | 5 | 1.67 | +90 | +18.0 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +159 | +39.7 |
| STAY WORTH | 141 | 131 | 4 | 1.33 | +269 | +67.1 |
| TIED UP BY THE SUM | 5 | 5 | 4 | 1.33 | +123 | +30.8 |
| CHAFF IN THE MOVE | 6 | 5 | 3 | 1.00 | +0 | +0.0 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 3 | 3 | 3 | 1.00 | +315 | +104.9 |
| MARCH OF THE TABLE | 3 | 3 | 3 | 1.00 | -194 | -64.7 |
| MAX FOR POSITIONING | 18 | 17 | 3 | 1.00 | +7 | +2.4 |
| MISSILES IN THE MOVE | 29 | 20 | 3 | 1.00 | +45 | +15.0 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +13 | +4.5 |
| PROMISE KNOWS THE FIGHT | 3 | 3 | 3 | 1.00 | -4 | -1.4 |
| REDIRECT BY WHAT IT STOPS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SHOTS IN THE MOVE | 75 | 62 | 3 | 1.00 | +235 | +78.2 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 17 | 17 | 2 | 0.67 | +49 | +24.5 |
| FIGHT TO THE END | 7 | 7 | 2 | 0.67 | +158 | +79.2 |
| HIS TURN DENIED | 8 | 8 | 2 | 0.67 | +28 | +14.2 |
| MANOEUVRE | 11 | 11 | 2 | 0.67 | +108 | +54.2 |
| MARCH CHECK | 2 | 2 | 2 | 0.67 | +47 | +23.4 |
| ONE FIGHT FORMULA | 33 | 18 | 2 | 0.67 | +54 | +27.1 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -1 | -0.6 |
| RISK BY ARC | 13 | 13 | 2 | 0.67 | +13 | +6.6 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SEARCH SPOT | 3 | 3 | 2 | 0.67 | +31 | +15.5 |
| SHORT GUN FORWARD | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 19 | 19 | 2 | 0.67 | +0 | +0.0 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +247 | +123.7 |
| SWIFTSTRIDE BY POINTS | 2 | 2 | 2 | 0.67 | +38 | +19.0 |
| THE ROW IN ITS ORDER | 29 | 2 | 2 | 0.67 | +0 | +0.0 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +187 | +186.9 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +25 | +24.9 |
| CANNON PLANNED TARGET | 30 | 30 | 1 | 0.33 | +55 | +55.1 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -14 | -14.3 |
| COVER ONCE | 35 | 26 | 1 | 0.33 | +0 | +0.0 |
| GUN MASK | 4 | 4 | 1 | 0.33 | +18 | +17.7 |
| HUNT IN PAIRS | 3 | 3 | 1 | 0.33 | +25 | +25.0 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +65 | +65.4 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +96 | +96.5 |
| MISSILES NEXT TURN | 39 | 24 | 1 | 0.33 | +0 | +0.0 |
| OGRE LOADER SECOND SHOT | 1 | 1 | 1 | 0.33 | +108 | +108.0 |
| ONE JOINT FIGURE | 2 | 2 | 1 | 0.33 | +8 | +7.8 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -216 | -215.6 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.33 | +74 | +74.4 |
| PROMISE READS THE TABLE | 3 | 3 | 1 | 0.33 | -99 | -99.3 |
| SAFER THAN THE JOB | 1 | 1 | 1 | 0.33 | +63 | +63.3 |
| SET UP BY THE SET | 3 | 3 | 1 | 0.33 | +60 | +60.4 |
| SHOT REPLANNED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SPELLS IN THE FIGHT | 2 | 2 | 1 | 0.33 | +5 | +5.4 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| WALKS ON ITS ROUTE | 1 | 1 | 1 | 0.33 | -41 | -40.6 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +18 | +18.3 |
| BACKUP TARGETS | 3 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 7 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHARACTER GUNS | 12 | 12 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 57 | 56 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 14 | not checked | - | - | - | - |
| DEFENSIVE ARMY | 2 | 2 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 5 | 5 | 0 | 0.00 | - | - |
| EXACT ROUND | 14 | 14 | 0 | 0.00 | - | - |
| FALLS SHORT | 73 | 57 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 8 | 8 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 34 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 21 | 21 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GUN FIGURES | 13 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 7 | 7 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 42 | 42 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 23 | 23 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 9 | 9 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 18 | 18 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 7 | 7 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 13 | 11 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 19 | 17 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 7 | 7 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 91 | 91 | 0 | 0.00 | - | - |
| HONEST WORTH | 14 | 14 | 0 | 0.00 | - | - |
| HUNT RESULT | 1 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| KEPT FROM ITS LAST STOP | 11 | 11 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 10 | 10 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 5 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 6 | not checked | - | - | - | - |
| NEARER NOT NEEDED | 44 | 41 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 14 | 14 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE OBJECTIVE FORMULA | 29 | 19 | 0 | 0.00 | - | - |
| ONE ROUTE | 5 | 5 | 0 | 0.00 | - | - |
| OPENS A LANE | 2 | 2 | 0 | 0.00 | - | - |
| OPENS UP | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 255 | trace | - | - | - | - |
| REAL GROUND | 5 | 5 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 7 | 5 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 2 | 2 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 13 | 13 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 4 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SHOOTERS ON THE TABLE | 58 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 4 | not checked | - | - | - | - |
| SPELL WORTH | 22 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 47 | 44 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 4 | 4 | 0 | 0.00 | - | - |
| STANDS STILL | 235 | 231 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 7 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | 1 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 3 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 19 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 8 | not checked | - | - | - | - |
| THE TABLE BINDS | 242 | not checked | - | - | - | - |
| WAITS AGAIN | 6 | 6 | 0 | 0.00 | - | - |
| WHO FIGHTS | 6 | 6 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 2 | 2 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p17

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 2.67 | 2.67 | 31.5 |
| ARMY TABLE | rule | 1.67 | 3.33 | 50.3 |
| PROMISE BY ITS OWN SUM | rule | 1.33 | 1.00 | 108.7 |
| CHARGE NOW FIRST | rule | 1.00 | 1.00 | 77.2 |
| JOINT CHARGE NOW | rule | 0.33 | 0.67 | 97.0 |
| MARCH OF THE TABLE | rule | - | 1.00 | 64.7 |
| PROMISE KNOWS THE FIGHT | rule | - | 1.00 | 1.4 |
| HOLDER ASSIGNMENT | rule | 0.67 | - | 4.8 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 14.3 |
| FIGHT ORDER BAND | gate | - | 0.33 | 4.3 |
| ONE PROMISE A TARGET | rule | - | 0.33 | 215.6 |
| PROMISE READS THE TABLE | rule | 0.33 | - | 99.3 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 0.9 |
| WALKS ON ITS ROUTE | rule | 0.33 | - | 40.6 |

### Plans: ccut-c940641-p17

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.7 | 40% | 41 | 85 | 207% |
| Mine | move | 23.0 | 96% | 1186 | 0 | 0% |
| Mine | shoot | 13.7 | 49% | 2542 | 1287 | 51% |
| Opponent | charge | 3.0 | 67% | 440 | 190 | 43% |
| Opponent | join | 2.7 | 100% | 100 | 0 | 0% |
| Opponent | move | 36.3 | 92% | 1953 | 0 | 0% |
| Opponent | shoot | 3.7 | 55% | 271 | 198 | 73% |
| Opponent | support | 1.0 | 33% | 23 | 0 | 0% |

### Packages: hunt the guns, ccut-c940641-p17

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 43 |
| Opponent | 0.3 | 1 | 0 | 100% | 100% | 0% | 2.0 | 547 | 463 | 100% | 195 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 43 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 540 |
| Vampire Counts | 1.0 | 1 | 0 | 100% | 100% | 0% | 2.0 | 547 | 463 | 100% | 45 |

### Battle groups: ccut-c940641-p17

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 0.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 2.0 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p17

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | - | 0 (1) | 0 (1) | 0 (1) |
| Mine | Character | 12 | 34 (12) | 34 | 0 | 32 | 67% | 2.5 | 0 (4) | 0 (4) | 72 (3) | 52 (6) | 0 (5) |
| Mine | Fast Hammer | 5 | 19 (5) | 0 | 19 | 20 | 0% | 3.4 | 12 (3) | 0 (1) | 50 (1) | 34 (3) | 0 (2) |
| Mine | Hammer | 4 | 26 (4) | 10 | 17 | 0 | 50% | 1.0 | 0 (1) | 37 (3) | - | 14 (3) | 57 (1) |
| Mine | Shooter | 5 | 36 (5) | 32 | 4 | 54 | 0% | 1.2 | 0 (1) | 22 (2) | 70 (2) | 36 (5) | - |
| Mine | War machine | 11 | 42 (11) | 42 | 0 | 64 | 9% | 1.4 | 91 (5) | 0 (6) | - | 0 (2) | 51 (9) |
| Mine | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 50% | 3.0 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Chaff | 5 | 85 (5) | 85 | 0 | 34 | 80% | 2.0 | 139 (3) | 0 (2) | - | 85 (5) | - |
| Opponent | Character | 11 | 21 (11) | 21 | 0 | 27 | 27% | 2.5 | 0 (3) | 0 (4) | 56 (3) | 33 (6) | 13 (4) |
| Opponent | Clean-up | 1 | 146 (1) | 0 | 146 | 0 | 0% | 3.0 | - | 146 (1) | - | 146 (1) | - |
| Opponent | Fast Hammer | 6 | 45 (6) | 11 | 35 | 0 | 17% | 2.2 | 8 (3) | 101 (3) | - | 65 (4) | 23 (2) |
| Opponent | Fragile | 2 | 0 (2) | 0 | 0 | 100 | 100% | - | - | 0 (1) | 0 (1) | - | 0 (2) |
| Opponent | Hammer | 4 | 65 (4) | 65 | 0 | 69 | 0% | 2.8 | 65 (2) | 134 (1) | 0 (1) | 94 (3) | 0 (1) |
| Opponent | Holder | 4 | 99 (4) | 0 | 99 | 19 | 50% | 3.0 | - | 13 (2) | 171 (2) | 99 (4) | - |
| Opponent | Shooter | 2 | 0 (2) | 0 | 0 | 100 | 0% | 2.5 | - | - | 0 (2) | 0 (1) | 0 (1) |
| Opponent | War machine | 2 | 39 (2) | 39 | 0 | 100 | 0% | 1.0 | - | 39 (2) | - | 79 (1) | 0 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | - | - | 0 (2) | - |

### Charged fights: ccut-c940641-p17

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 3 | 407 | 101 | 2.0 | 1.2 | 50 | 78 | -28 | 1 of 6 | 6 of 6 | +0 | -34 |
| Opponent | Grand Cathay | 1 | 294 | 340 | 2.0 | 1.0 | 170 | 0 | +170 | 0 of 2 | 2 of 2 | - | +170 |
| Opponent | Skaven | 1 | 0 | 0 | 3.0 | 1.0 | 0 | 0 | +0 | 2 of 3 | 1 of 3 | - | +0 |
| Opponent | Vampire Counts | 1 | 0 | 380 | 3.0 | 1.7 | 127 | 0 | +127 | 1 of 3 | 2 of 3 | +0 | +190 |
| **Opponent** | all armies | 3 | 98 | 240 | 2.7 | 1.2 | 90 | 0 | +90 | 3 of 8 | 5 of 8 | +0 | +103 |

### Effective charges: ccut-c940641-p17

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Empire of Man | 6 | 0 | 0 | 1 (net -71) | 0 | 0 | 5 (net -19) | 0 | 17% (1 of 6) |
| Opponent | Grand Cathay | 2 | 0 | 0 | 0 | 1 (net +125) | 1 (net +215) | 0 | 0 | 0% (0 of 2) |
| Opponent | Skaven | 3 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 1 (net +0) | 0 | 0% (0 of 3) |
| Opponent | Vampire Counts | 3 | 1 (net +250) | 0 | 0 | 1 (net +130) | 0 | 1 (net +0) | 0 | 0% (0 of 3) |

### Charged fights, damage counted: ccut-c940641-p17

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 181 | 145 | -71 | 297 | 281 | +16 | +8.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 5 | 206 | 141 | -19 | 60 | 51 | +9 | +4.2 |
| Mine | All fights | 6 | 202 | 142 | -28 | 99 | 89 | +10 | +4.9 |
| Opponent | Long shot (under 50%) | 2 | 22 | 182 | +125 | 140 | 4 | +136 | +605.0 |
| Opponent | 76-89% | 3 | 144 | 111 | +85 | 197 | 0 | +197 | +137.1 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 267 | 227 | +0 | 85 | 43 | +42 | +15.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 205 | 45 | +215 | 215 | 0 | +215 | +104.9 |
| Opponent | All fights | 8 | 152 | 149 | +90 | 157 | 12 | +145 | +95.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p17 | move | 20 | 2 (10%) | 2 (10%) | 6 (30%) | 12 (60%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0827 |
| Invocation of Nehek | Opponent | L0827 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Jet | Opponent | L0810 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721 |
| Twice-Blessed Armour | Opponent | L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |

# Doctrine scorecard: ccut-c940641-p43

### Scorecard: ccut-c940641-p43

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1118 | 2 | 1 | Mine | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | - | 3 | 2 | 0 | 0 | 0 | 413 |
| L1135 | 1 | 1 | Mine | yes | 0 | 3 | 1 | 2 | 0 | 0 | 0 | 165 |
| L1135 | 1 | 1 | Opponent | no | 0 | 3 | 1 | 5 | 0 | 0 | 0 | 126 |
| L1228 | 4 | 1 | Mine | no | 2 | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Opponent | no | 6 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 50% | 1.0 | 2.3 | 1.0 | 1.0 | 0.0 | 0.0 | 0.0 | 165.0 |
| **Average** | | | Opponent | 0% | 3.0 | 3.0 | 1.3 | 2.7 | 0.0 | 0.0 | 0.0 | 179.7 |

### KPIs: ccut-c940641-p43

Rules off - Opponent only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 33% (5 of 15) | 0% (0 of 15) | 17% (5 of 30) |
| Winner chose to follow up after the loser gave ground |  | 100% (3 of 3); on the table 100% | 100% (2 of 2); on the table 100% | 100% (5 of 5); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 100% (1 of 1); on the table 100% | 100% (1 of 1); on the table 100% |
| Winner chose to pursue after the loser fled |  | 100% (2 of 2); on the table 100% | 50% (1 of 2); on the table 50% | 75% (3 of 4); on the table 75% |
| Winner chose to follow up or pursue (all three) |  | 100% (5 of 5); on the table 100% | 80% (4 of 5); on the table 80% | 90% (9 of 10); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 32% (23 of 72) | 33% (6 of 18) | 32% (29 of 90) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 39% (23 of 59) | 43% (6 of 14) | 40% (29 of 73) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 71% (4265 of 5998) | 63% (3764 of 6000) | 67% (8029 of 11998) |
|   infantry points that never fought | lower | 87% (633 of 730) | 95% (742 of 782) | 91% (1375 of 1512) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 64% (16 of 25) | 81% (21 of 26) | 73% (37 of 51) |
| Bound items with a magic missile used (at least once a game) |  | 43% (3 of 7); 2.3 uses a game | 50% (1 of 2); 1.7 uses a game | 44% (4 of 9); 2.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 3); 0.0 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 63% (3544 of 5614) | 79% (4466 of 5644) | 71% (8010 of 11258) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.7 (22%) | 0.3 (8%) | 4.0 (20%) |
| MARCHED: its unit marched | 7.7 (47%) | 0.0 (0%) | 7.7 (38%) |
| CHARGED: its unit charged | 0.7 (4%) | 0.0 (0%) | 0.7 (3%) |
| IN COMBAT: engaged in combat | 4.3 (27%) | 0.0 (0%) | 4.3 (21%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.3 (8%) | 0.3 (2%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 1.3 (33%) | 1.3 (7%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.3 (8%) | 0.3 (2%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 1.7 (42%) | 1.7 (8%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 1.3 | 5.3 | 0.7 | 9.7 | 0.7 | 2.3 |
| not cast | 2.7 | 10.7 | 5.3 | 20.3 | 3.3 | 25.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 7.0 (66%) | 0.0 (0%) | 4.0 (20%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 7.7 (38%) | 1.0 (30%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (6%) | 0.0 (0%) | 4.3 (21%) | 1.0 (30%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 2.0 (19%) | 2.0 (38%) | 0.3 (2%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (10%) | 0.0 (0%) |
| OFF THE TABLE: off the table or not arrived | 1.3 (50%) | 0.0 (0%) | 1.3 (25%) | 1.3 (7%) | 0.0 (0%) | 2.7 (10%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.3 (3%) | 0.3 (6%) | 0.3 (2%) | 0.0 (0%) | 0.7 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (3%) | 0.0 (0%) | 0.0 (0%) | 1.0 (30%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (8%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.3 (50%) | 0.3 (3%) | 1.7 (31%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 20.7 (81%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 0.7 a game | 0.3 a game |
| stood (cast and not dispelled) | - | 50% (1 of 2) | 50% (1 of 2) |
| the unit moved after it | - | 0% (0 of 1) | 0% (0 of 1) |
| it charged on its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| the enemy charged it first | - | 0% (0 of 1) | 0% (0 of 1) |
| it fought by the end of its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 1) | 0% (0 of 1) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (1 of 1) | 100% (1 of 1) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 69% (38 of 55) | 69% (52 of 75) | 69% (90 of 130) |
|   cavalry | - | 94% (17 of 18) | 94% (17 of 18) |
|   character | - | 89% (8 of 9) | 89% (8 of 9) |
|   chariot | 73% (8 of 11) | 80% (8 of 10) | 76% (16 of 21) |
|   infantry | 69% (9 of 13) | 40% (12 of 30) | 49% (21 of 43) |
|   monster | - | 88% (7 of 8) | 88% (7 of 8) |
|   war machine | 68% (21 of 31) | - | 68% (21 of 31) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (41%) | 3.0 (39%) | 5.3 (40%) |
| CHARGED: it charged | 0.0 (0%) | 0.7 (9%) | 0.7 (5%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 0.3 (4%) | 0.3 (2%) |
| MOVED: a war machine that moved | 1.3 (24%) | 0.0 (0%) | 1.3 (10%) |
| NO TARGET IN RANGE | 0.0 (0%) | 1.0 (13%) | 1.0 (8%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 1.7 (22%) | 1.7 (12%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 1.0 (13%) | 1.0 (8%) |
| SHELTERED: the target was sheltered | 1.3 (24%) | 0.0 (0%) | 1.3 (10%) |
| OTHER BAR | 0.7 (12%) | 0.0 (0%) | 0.7 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.7 | 2.0 | 75% | 6.4 pts | 43 pts |
| character | 2.7 | 1.3 | 75% | 16.4 pts | 44 pts |
| chariot | 5.3 | 3.0 | 56% | 21.3 pts | 114 pts |
| infantry | 10.0 | 0.3 | 97% | 1.8 pts | 18 pts |
| monster | 2.3 | 1.7 | 57% | 15.7 pts | 37 pts |
| war machine | 7.7 | 6.0 | 57% | 18.1 pts | 139 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 2.0 | 2.5 |
| Charges that made contact a game | 2.7 | 1.0 | 1.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.17 declared, 1.00 contact (6 units) | - | 1.17 declared, 1.00 contact (6 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 1.00 contact (1 units) | - | 1.00 declared, 1.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.11 declared, 0.11 contact (9 units) | 0.23 declared, 0.12 contact (26 units) | 0.20 declared, 0.11 contact (35 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (3 of 6) | - | 75% (3 of 4) | 60% (6 of 10) |
| Character in a unit | 100% (3 of 3) | 100% (3 of 3) | 100% (1 of 1) | 100% (7 of 7) |
| Character on its own | - | 57% (4 of 7) | 50% (2 of 4) | 55% (6 of 11) |
| Chariot | 50% (2 of 4) | - | - | 50% (2 of 4) |
| Infantry | 75% (6 of 8) | - | - | 75% (6 of 8) |
| Monster | - | 100% (1 of 1) | - | 100% (1 of 1) |
| Monstrous | 100% (2 of 2) | 50% (1 of 2) | - | 75% (3 of 4) |
| War Machines | 100% (6 of 6) | - | - | 100% (6 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 3 | 100% (5 of 5); on the table 100% | 32% (23 of 72) | 71% | 64% (16 of 25) | 43% (3 of 7); 2.3 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| Ogre Kingdoms | 1 | 50% (1 of 2); on the table 50% | 0% (0 of 6) | 61% | 57% (4 of 7) | 100% (1 of 1); 5.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 100% (3 of 3); on the table 100% | 83% (5 of 6) | 49% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | - | 17% (1 of 6) | 78% | 100% (12 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p43, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (2) | 100% (2) | 100% (4) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.67 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.33 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: ccut-c940641-p43

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 1.0 |
| Strategy | Charge objectives carried out (made contact) | 88% (7 of 8) | 50% (1 of 2) |
| Strategy | Shoot objectives carried out (shot that target) | 31% (11 of 35) | 73% (24 of 33) |
| Strategy | Support requests answered (helper made contact too) | 100% (2 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 67% (2 of 3) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 4) | 40% (2 of 5) |
| Strategy | Lone characters that fought | 75% (6 of 8) | 33% (1 of 3) |
| Movement | Charges halted short of contact | 0.0 | 1.0 |
| Movement | Idle units | 1.0 | 2.7 |
| Movement | Points that never moved of their own | 165.0 | 179.7 |
| Movement | Fights charged into per game | 2.0 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 5, net +0 | 0 of 1 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 5, net +0 | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 5 | 0 of 1 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 5, net +230 | 0 of 1 |
| Shooting | Shots by shooting units (incl. breath weapons) | 5.7 | 18.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 18% (3 of 17) | 46% (26 of 56) |
| Shooting | Points destroyed by shooting units | 34.0 | 55.0 |
| Shooting | War machine shots | 7.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 52% (11 of 21) | - |
| Shooting | Points destroyed by war machines | 0.0 | 105.0 |
| Magic | Magic missiles cast | 5.3 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 50% (8 of 16) | 50% (1 of 2) |
| Magic | Wounds caused by magic missiles | 9.3 | 1.7 |
| Magic | Wounds caused by other spells | 2.7 | - |
| Magic | Points destroyed by magic (all spells) | 25.0 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.3 / 1.0 / 0.7 / 0.7 | 0.7 / 0.0 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 192.0 | 0.0 |
| Combat | Points run down | 37.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +92 | -46 |
| Combat | Net per 100 charger points, damage counted | +24.6 | -83.8 |
| Combat | First round won (charged fights) | 83% | 33% |
| Combat | Net points per charged fight | +95 | -92 |
| Combat | Net points per supported fight / lone fight | +0 / +114 | - / -92 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 6 | 2 of 3 |
| Game | Points lost | 160.0 | 426.7 |
| Game | VP from objectives | 936.7 | 450.0 |
| Game | Lone holders (player turns) | 1.0 | 3.0 |

- Mine won / drew / lost: 3 / 0 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +762 VP
- The side that went first won 3 of 3 games with a winner
- Points traded per game (both sides' losses): 587
- Games not ended: 0; findings 2, warnings 0

### Opponent rules: ccut-c940641-p43

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 15.7 | +9.8 | 0.0 | 100.0 | 24.7 | +253.1 | 0.0 | 321.3 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +24.9 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.7 | +0.0 | 0.0 | 55.0 | - | - | - | - |
| BACKUP TARGETS | 0.7 | +2.4 | 0.0 | 0.0 | 0.7 | +7.9 | 0.0 | 0.0 |
| BEST PRIZE | 0.3 | -13.7 | 0.0 | 0.0 | - | - | - | - |
| BOMBING RUN | 0.3 | +10.9 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 5.7 | +25.3 | 34.0 | 220.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 2.0 | +31.7 | 37.0 | 0.0 | 1.0 | +4.0 | 0.0 | 0.0 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 3.7 | +51.3 | 61.7 | 0.0 | 1.3 | +15.5 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.7 | +23.6 | 0.0 | 41.0 |
| CHAFF PASSED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.7 | +54.6 | 0.0 | 37.0 |
| CHARGE LOSSES | 20.3 | -429.3 | 0.0 | 150.0 | 18.0 | -1514.9 | 0.0 | 273.7 |
| CHARGE NOW FIRST | 1.0 | +0.0 | 190.0 | 0.0 | 1.3 | +0.0 | 55.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.0 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 0.7 | +100.6 | 0.0 | 91.3 |
| COVER ONCE | 9.0 | -459.9 | 0.0 | 100.0 | 10.7 | -1318.8 | 0.0 | 153.0 |
| DENIED BY THE FIGHT | 0.3 | -2.4 | 61.7 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 6.0 | -45.0 | 0.0 | 0.0 | 8.3 | -61.2 | 0.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +70.7 | 52.7 | 0.0 | - | - | - | - |
| EVASIVE BY THE ODDS | - | - | - | - | 1.3 | +9.4 | 0.0 | 0.0 |
| EXACT ROUND | 1.7 | +4.2 | 214.7 | 0.0 | 0.7 | -4.1 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.3 | +0.3 | 251.7 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 3.7 | +75.8 | 0.0 | 50.0 | 28.7 | +263.7 | 0.0 | 164.3 |
| FEATURE BUFFS | 1.3 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| FIGHT LIFT | - | - | - | - | 0.3 | +1.9 | 0.0 | 0.0 |
| FIGHT TO THE END | 0.3 | +3.1 | 61.7 | 0.0 | 0.7 | -0.9 | 0.0 | 0.0 |
| FIVE ACTION | 85.0 | +6488.0 | 502.7 | 640.0 | 81.7 | +3879.2 | 915.0 | 445.3 |
| FLANK NOT WEIGHED | 4.0 | +0.0 | 0.0 | 100.0 | 8.0 | +0.0 | 0.0 | 100.3 |
| FOLLOW UP WEIGHED | 0.7 | +154.1 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 3.0 | +459.9 | 251.7 | 0.0 | 0.7 | +103.3 | 0.0 | 0.0 |
| FREED FROM HIS FIGHT | 1.0 | +0.0 | 0.0 | 100.0 | 8.0 | +0.0 | 0.0 | 41.3 |
| FRIEND CHARGES FIRST | - | - | - | - | 0.3 | -18.0 | 55.0 | 0.0 |
| FRIEND SHOOTS FIRST | 2.0 | -11.2 | 0.0 | 0.0 | 1.3 | -16.8 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -1.6 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP ITS SCREEN | - | - | - | - | 0.3 | -2.7 | 0.0 | 0.0 |
| GOAL WALK | 3.0 | +193.3 | 0.0 | 0.0 | 12.3 | +1031.7 | 0.0 | 0.0 |
| GUN FIGURES | - | - | - | - | 0.3 | +46.3 | 50.0 | 0.0 |
| GUN MASK | 5.3 | +169.3 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 52.7 |
| HE REFORMS ONCE FREED | 0.7 | +0.0 | 0.0 | 100.0 | 6.0 | +0.0 | 0.0 | 41.3 |
| HIS CHARGE BY HIS RUN | 13.7 | +0.0 | 0.0 | 150.0 | 9.7 | +0.0 | 0.0 | 205.7 |
| HIS CHARGE LIST | 5.7 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 111.7 |
| HIS LEGAL MOVES | 5.0 | +0.0 | 0.0 | 100.0 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 4.0 | -18.3 | 0.0 | 0.0 | 11.3 | -87.7 | 0.0 | 52.7 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 33.7 | +8.0 | 100.0 | 0.0 |
| HIS MOVE WHY | 32.7 | +0.0 | 0.0 | 100.0 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 17.3 | +37.8 | 0.0 | 52.7 |
| HIS ONE QUARTER | 6.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 68.0 |
| HIS OWN BEST MOVE | 9.0 | +0.0 | 0.0 | 100.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 37.3 | +1379.3 | 0.0 | 100.0 | 47.7 | +2346.7 | 0.0 | 315.0 |
| HIS SHOTS BY HIS RUN | 45.3 | +976.4 | 0.0 | 150.0 | 48.0 | +1515.5 | 0.0 | 415.3 |
| HIS TURN DENIED | 0.3 | +43.1 | 61.7 | 0.0 | - | - | - | - |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 18.7 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 11.7 | +1152.9 | 0.0 | 0.0 | 5.7 | +697.1 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.3 | -72.5 | 251.7 | 0.0 | 0.3 | -24.9 | 0.0 | 0.0 |
| HUNT IN PAIRS | 1.7 | +213.3 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | 1.0 | -29.6 | 0.0 | 0.0 | 11.0 | -199.4 | 0.0 | 100.3 |
| JOINT CHARGE NOW | 1.0 | +145.7 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 3.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +33.7 | 0.0 | 0.0 | 0.3 | +15.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 1.0 | +0.0 | 98.7 | 0.0 | 5.0 | +0.0 | 0.0 | 160.3 |
| LONE WIZARD KEPT IN | 0.7 | +52.8 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 2.0 | -16.7 | 162.0 | 0.0 | 0.7 | +6.4 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.3 | +1.5 | 0.0 | 50.0 | - | - | - | - |
| MANOEUVRE | 2.7 | -17.8 | 0.0 | 0.0 | 1.3 | -4.7 | 0.0 | 0.0 |
| MARCH BY THE SUM | 1.7 | +222.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 3.0 | +181.8 | 0.0 | 0.0 | 0.3 | +14.8 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 2.7 | +226.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 4.0 | +163.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH WHEELS ONLY | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 6.7 | +101.6 | 0.0 | 50.0 | 3.0 | +82.1 | 0.0 | 0.0 |
| MEETS IN TIME | 1.7 | +155.5 | 0.0 | 0.0 | 4.0 | +307.2 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 7.3 | +168.6 | 0.0 | 0.0 | 4.3 | +39.0 | 0.0 | 52.7 |
| MISSILES NEXT TURN | 13.3 | +142.7 | 0.0 | 0.0 | 3.7 | +26.8 | 0.0 | 52.7 |
| MISSILES ON ONE TARGET | 0.7 | -11.7 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 0.3 | -2.9 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 6.3 | +530.5 | 0.0 | 50.0 | 1.3 | +50.3 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.0 | +251.4 | 0.0 | 0.0 | 8.0 | +376.7 | 0.0 | 52.7 |
| NEXT CHARGE BY LIST | 4.3 | +451.9 | 0.0 | 0.0 | 1.0 | +51.6 | 55.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -33.3 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.0 | -116.3 | 251.7 | 0.0 | 0.3 | -70.8 | 0.0 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 1.3 | -0.3 | 0.0 | 0.0 | 0.3 | -0.6 | 0.0 | 0.0 |
| OFF BEST | 6.3 | -236.4 | 37.0 | 0.0 | 3.7 | -74.1 | 0.0 | 100.3 |
| OGRE LOADER SECOND SHOT | 4.3 | +27.4 | 0.0 | 55.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 6.7 | -143.6 | 0.0 | 100.0 | 5.3 | -105.3 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 0.3 | +131.7 | 0.0 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 7.0 | -14.5 | 0.0 | 0.0 | 1.7 | +68.7 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.7 | -13.2 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +8.2 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.7 | +1.8 | 162.0 | 0.0 | 0.3 | +1.2 | 0.0 | 0.0 |
| PATHS CROSS | 0.3 | +13.1 | 0.0 | 0.0 | 0.3 | +151.5 | 0.0 | 0.0 |
| PLAN RESULT | 36.7 | +417.8 | 318.7 | 265.0 | 37.3 | +392.1 | 320.0 | 582.7 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 8.0 | -104.1 | 0.0 | 50.0 | 3.3 | -10.1 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.0 | -4.8 | 0.0 | 50.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.7 | -2.9 | 0.0 | 0.0 | 1.3 | -30.6 | 0.0 | 0.0 |
| QUARTER ODDS | 21.7 | +2667.1 | 68.0 | 0.0 | 14.7 | +1414.9 | 0.0 | 68.0 |
| REAL GROUND | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.3 | +5.4 | 0.0 | 0.0 |
| REDIRECT COUNTER | - | - | - | - | 3.3 | +564.2 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 0.7 | +0.0 | 0.0 | 11.3 |
| REFORMS TO MEET IT | 0.7 | -19.5 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RESERVE FALL BACK | 0.3 | +4.9 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.0 | +83.0 | 251.7 | 0.0 | 0.7 | -57.4 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 0.3 | -11.1 | 0.0 | 0.0 | 0.3 | -16.6 | 0.0 | 0.0 |
| RUN DOWN | 2.0 | -10.7 | 251.7 | 0.0 | 0.7 | -18.8 | 0.0 | 0.0 |
| SAME CHARGE LATER | - | - | - | - | 0.3 | -7.6 | 55.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 0.7 | +2.9 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.7 | -77.7 | 0.0 | 27.3 |
| SEARCH SPOT | 1.0 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| SECOND LOOK | 0.3 | +8.7 | 37.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 2.0 | -358.1 | 0.0 | 50.0 | 2.3 | -51.6 | 0.0 | 11.3 |
| SET UP BY THE SET | 2.7 | +366.2 | 0.0 | 50.0 | 4.3 | -27.2 | 0.0 | 11.3 |
| SET UP TOGETHER | 0.3 | +1.5 | 0.0 | 50.0 | - | - | - | - |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.7 | -1.1 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 11.3 | +0.0 | 0.0 | 220.0 | 11.0 | +0.0 | 0.0 | 13.7 |
| SHOOTS FROM THE BEST SPOT | 3.0 | +79.9 | 0.0 | 0.0 | 1.0 | +8.9 | 110.0 | 0.0 |
| SHOT OR CHARGE | 0.3 | -40.9 | 61.7 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 23.0 | -170.7 | 0.0 | 150.0 | 31.3 | -359.2 | 0.0 | 109.3 |
| SHOTS AFTER THE MOVES | 4.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 15.0 | +631.3 | 0.0 | 320.0 | 17.0 | +674.1 | 0.0 | 153.0 |
| SPELL WORTH | 0.7 | +0.8 | 0.0 | 0.0 | 2.0 | +16.6 | 91.3 | 91.3 |
| SPELLS IN THE FIGHT | 0.3 | +2.9 | 100.3 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 1.3 | +0.0 | 0.0 | 100.0 | 4.0 | +0.0 | 0.0 | 11.3 |
| STAND AND SHOOT | 0.7 | -10.2 | 162.0 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | - | - | - | - | 9.0 | +0.0 | 0.0 | 100.3 |
| STANDS STILL | 41.0 | +0.0 | 251.0 | 540.0 | 42.7 | +0.0 | 915.0 | 281.0 |
| STAY WORTH | 27.3 | +50.2 | 183.0 | 660.0 | 26.0 | +172.8 | 530.0 | 0.0 |
| STRIKE BY THE ODDS | 0.3 | +11.2 | 61.7 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.7 | +137.8 | 0.0 | 100.0 | 8.3 | +532.8 | 0.0 | 30.0 |
| SUPPORT WORKED OUT | 2.7 | +137.8 | 0.0 | 100.0 | 8.3 | +532.8 | 0.0 | 30.0 |
| SURE REACH TOGETHER | 0.3 | +0.6 | 0.0 | 0.0 | 0.7 | +2.0 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | -8.8 | 0.0 | 0.0 | 0.3 | +0.9 | 0.0 | 11.3 |
| THE DEARER SUM KEEPS ITS PLAN | 2.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | - | - | - | - | 0.3 | -18.3 | 0.0 | 0.0 |
| THE PROMISED MOVE | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE RISK READS HIS RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 0.7 | +0.0 | 0.0 | 50.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 1.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.0 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 36.3 | +0.0 | 0.0 | 320.0 | 39.7 | +0.0 | 0.0 | 200.7 |
| TIED UP BY THE SUM | 0.7 | +95.8 | 37.0 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 28.3 | +441.5 | 0.0 | 100.0 | 7.0 | +70.7 | 0.0 | 30.0 |
| WAITS AGAIN | 1.7 | +0.0 | 0.0 | 50.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.3 | +0.0 | 0.0 | 50.0 | 2.0 | +0.0 | 210.0 | 0.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | +2.0 | 0.0 | 0.0 |
| WHO HITS BACK | 0.3 | +78.9 | 0.0 | 0.0 | - | - | - | - |
| WHOLE FIGHT | - | - | - | - | 0.3 | +1.7 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | - | - | - | - | 3.3 | -1038.6 | 0.0 | 205.7 |
| WHOLE FIGHT GAIN | 0.3 | +11.0 | 0.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 2.3 | +42.6 | 0.0 | 0.0 | 5.3 | +228.6 | 0.0 | 52.7 |

### Rule changes: ccut-c940641-p43

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 121 | 121 | 80 | 26.67 | +1414 | +17.7 |
| HIS MOVE AS HE DECIDES | 101 | 101 | 77 | 25.67 | +0 | +0.0 |
| HIS MOVE WHY | 98 | 98 | 66 | 22.00 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 280 | 263 | 65 | 21.67 | +1673 | +25.7 |
| HIS SHOT LIST | 255 | 240 | 59 | 19.67 | +1454 | +24.6 |
| HOLDER ASSIGNMENT | 52 | 52 | 46 | 15.33 | +3699 | +80.4 |
| FIVE ACTION | 500 | 480 | 35 | 11.67 | +1816 | +51.9 |
| OFF BEST | 30 | 30 | 30 | 10.00 | -931 | -31.0 |
| THE TABLE AGAIN | 36 | 36 | 26 | 8.67 | +0 | +0.0 |
| DEPLOY BY FIGURES | 43 | 43 | 22 | 7.33 | +408 | +18.6 |
| HARD STAY DROPPED | 22 | 22 | 22 | 7.33 | +0 | +0.0 |
| QUARTER ODDS | 109 | 107 | 19 | 6.33 | +1299 | +68.3 |
| HIS ONE MOVE | 52 | 52 | 18 | 6.00 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| SHOT RISK POINTS | 163 | 155 | 17 | 5.67 | +506 | +29.8 |
| GOAL WALK | 46 | 44 | 15 | 5.00 | +519 | +34.6 |
| OGRE LOADER SECOND SHOT | 13 | 13 | 13 | 4.33 | +82 | +6.3 |
| TIME ON OUR SIDE | 106 | 84 | 13 | 4.33 | +78 | +6.0 |
| MOVE TO CHARGE COMPUTED | 23 | 22 | 12 | 4.00 | +584 | +48.7 |
| SET UP BY THE SET | 21 | 18 | 11 | 3.67 | +359 | +32.7 |
| SUPPORT ADDS | 33 | 31 | 11 | 3.67 | +526 | +47.8 |
| SUPPORT WORKED OUT | 33 | 31 | 11 | 3.67 | +526 | +47.8 |
| COVER ONCE | 59 | 51 | 10 | 3.33 | +286 | +28.6 |
| MEETS IN TIME | 17 | 17 | 10 | 3.33 | +481 | +48.1 |
| PROMISE BY ITS OWN SUM | 34 | 34 | 10 | 3.33 | -343 | -34.3 |
| SHOOTS FROM THE BEST SPOT | 12 | 12 | 9 | 3.00 | +33 | +3.7 |
| ARTILLERY RE-ROLL WEIGHED | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| CAST JOB | 9 | 9 | 8 | 2.67 | +4 | +0.5 |
| MARCH OF THE TABLE | 8 | 8 | 8 | 2.67 | -678 | -84.8 |
| NEXT CHARGE BY LIST | 16 | 16 | 8 | 2.67 | +497 | +62.1 |
| CHARGE LOSSES | 115 | 109 | 7 | 2.33 | +693 | +99.1 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CASTING BLOCK | 15 | 15 | 6 | 2.00 | +17 | +2.9 |
| GUN MASK | 16 | 15 | 6 | 2.00 | +224 | +37.4 |
| MARCH CHECK | 10 | 9 | 6 | 2.00 | +142 | +23.7 |
| SHOTS IN THE MOVE | 96 | 77 | 6 | 2.00 | +114 | +19.0 |
| THE RISK READS HIS RUN | 18 | 18 | 6 | 2.00 | +0 | +0.0 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| FOUR ROUNDS | 11 | 10 | 5 | 1.67 | +717 | +143.4 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +148 | +29.7 |
| MARCH BY THE SUM | 5 | 5 | 5 | 1.67 | +667 | +133.4 |
| MOVE ORDER | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| SHOTS AFTER THE MOVES | 25 | 25 | 5 | 1.67 | +0 | +0.0 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| MISSILES IN THE MOVE | 35 | 25 | 4 | 1.33 | +102 | +25.4 |
| STAY WORTH | 160 | 147 | 4 | 1.33 | +33 | +8.2 |
| WOUNDS ON THE RANKS | 23 | 22 | 4 | 1.33 | +160 | +39.9 |
| EVASIVE BY THE ODDS | 4 | 4 | 3 | 1.00 | +25 | +8.4 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +462 | +154.1 |
| HUNT IN PAIRS | 5 | 4 | 3 | 1.00 | +126 | +42.0 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | +437 | +145.8 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| STRIKE BY THE ODDS | 3 | 3 | 3 | 1.00 | +34 | +11.2 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +164 | +82.0 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FALLS SHORT | 97 | 88 | 2 | 0.67 | +33 | +16.7 |
| HIS MOVE AND SHOT | 46 | 45 | 2 | 0.67 | +12 | +5.9 |
| IDLE COST | 36 | 27 | 2 | 0.67 | +3 | +1.7 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +158 | +79.2 |
| MANOEUVRE | 12 | 12 | 2 | 0.67 | +10 | +4.8 |
| MAX FOR POSITIONING | 29 | 26 | 2 | 0.67 | +0 | +0.0 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -40 | -19.8 |
| PATHS CROSS | 2 | 2 | 2 | 0.67 | +494 | +246.9 |
| PROMISE KNOWS THE FIGHT | 7 | 6 | 2 | 0.67 | -15 | -7.3 |
| PROMISE READS THE TABLE | 6 | 6 | 2 | 0.67 | -13 | -6.5 |
| REDIRECT FOR A FRIEND IN REACH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SCREEN BY WHAT IT SAVES | 5 | 5 | 2 | 0.67 | +21 | +10.6 |
| SWIFTSTRIDE BY POINTS | 2 | 2 | 2 | 0.67 | -24 | -11.8 |
| THE ROW IN ITS ORDER | 10 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 10 | 10 | 2 | 0.67 | +323 | +161.5 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -41 | -41.0 |
| BOMBING RUN | 1 | 1 | 1 | 0.33 | +33 | +32.7 |
| CANNON PLANNED TARGET | 17 | 17 | 1 | 0.33 | -7 | -7.3 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +25 | +24.6 |
| EXACT ROUND | 7 | 7 | 1 | 0.33 | +25 | +24.6 |
| LOST AFTER ESCAPE | 8 | 8 | 1 | 0.33 | +12 | +12.5 |
| MISSILES NEXT TURN | 51 | 28 | 1 | 0.33 | +0 | +0.2 |
| NEARER NOT NEEDED | 42 | 40 | 1 | 0.33 | +21 | +21.4 |
| ONE OBJECTIVE FORMULA | 26 | 20 | 1 | 0.33 | +3 | +3.0 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +20 | +19.9 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +15 | +14.6 |
| SEARCH SPOT | 3 | 3 | 1 | 0.33 | +12 | +12.1 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +26 | +26.2 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| TIED UP BY THE SUM | 2 | 1 | 1 | 0.33 | +20 | +19.9 |
| WHO HITS BACK | 1 | 1 | 1 | 0.33 | +226 | +226.1 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 4 | 3 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CHAFF IN THE MOVE | 5 | 5 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 7 | 7 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 29 | 22 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 2 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 9 | 8 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FIGHT TO THE END | 3 | 3 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 36 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 27 | 25 | 0 | 0.00 | - | - |
| FRIEND CHARGES FIRST | 1 | 1 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 10 | 8 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 1 | 1 | 0 | 0.00 | - | - |
| GUN FIGURES | 1 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 20 | 19 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 70 | 64 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 40 | 36 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 29 | 27 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 32 | 32 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 32 | 31 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 72 | 72 | 0 | 0.00 | - | - |
| HONEST WORTH | 8 | 7 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 14 | 14 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 1 | not checked | - | - | - | - |
| MARCH OVER CASTS | 12 | 12 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 2 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 1 | trace | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 7 | 6 | 0 | 0.00 | - | - |
| NO LATE CUT | 5 | 5 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 5 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 3 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 36 | 26 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 1 | 1 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 222 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 10 | 10 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 2 | 2 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK BY ARC | 8 | 7 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 8 | 7 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 13 | 10 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 67 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 8 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 16 | 16 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 2 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 27 | 25 | 0 | 0.00 | - | - |
| STANDS STILL | 251 | 243 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 3 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 13 | not checked | - | - | - | - |
| THE PROMISE ADDS | 1 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 18 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 4 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 15 | not checked | - | - | - | - |
| THE TABLE BINDS | 228 | not checked | - | - | - | - |
| WAITS AGAIN | 5 | 5 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 7 | 7 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p43

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.00 | 3.00 | 23.6 |
| ARMY TABLE | rule | 2.00 | 2.67 | 99.7 |
| PROMISE BY ITS OWN SUM | rule | 3.00 | 0.33 | 34.3 |
| MARCH OF THE TABLE | rule | 2.67 | - | 84.8 |
| NO REASON | gate | 1.33 | - | 62.9 |
| HOLDER ASSIGNMENT | rule | 1.00 | - | 15.7 |
| SET UP BY THE SET | rule | - | 1.00 | 37.9 |
| ONE PROMISE A TARGET | rule | 0.67 | - | 19.8 |
| PROMISE KNOWS THE FIGHT | rule | 0.67 | - | 7.3 |
| PROMISE READS THE TABLE | rule | - | 0.67 | 6.5 |
| RULE SWITCHED OFF | gate | - | 0.67 | 56.2 |
| BEST PRIZE | rule | 0.33 | - | 41.0 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 7.3 |
| JOINT CHARGE NOW | rule | 0.33 | - | 27.0 |
| SWIFTSTRIDE BY POINTS | rule | 0.33 | - | 26.3 |

### Plans: ccut-c940641-p43

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.7 | 100% | 204 | 181 | 88% |
| Mine | move | 25.0 | 100% | 2065 | 0 | 0% |
| Mine | shoot | 10.0 | 27% | 439 | 237 | 54% |
| Opponent | charge | 0.7 | 0% | 58 | 0 | 0% |
| Opponent | move | 25.7 | 94% | 1170 | 0 | 0% |
| Opponent | shoot | 10.0 | 37% | 844 | 392 | 46% |
| Opponent | support | 1.0 | 67% | 66 | 0 | 0% |

### Battle groups: ccut-c940641-p43

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 3.3 | 20% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p43

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 12 | 39 (12) | 39 | 0 | 0 | 25% | 3.1 | - | 20 (7) | 64 (5) | 51 (7) | 30 (5) |
| Mine | Fast Hammer | 4 | 10 (4) | 10 | 0 | 15 | 50% | 2.0 | 34 (2) | 0 (2) | - | 16 (3) | 0 (1) |
| Mine | Holder | 5 | 80 (5) | 5 | 75 | 0 | 60% | 3.0 | - | 124 (3) | 12 (2) | 73 (4) | 107 (1) |
| Mine | Shooter | 2 | 464 (2) | 0 | 464 | 0 | 0% | 1.0 | 309 (1) | 619 (1) | - | 464 (2) | - |
| Mine | War machine | 6 | 0 (6) | 0 | 0 | 33 | 0% | 1.5 | 0 (2) | 0 (2) | 0 (2) | 0 (1) | 0 (5) |
| Opponent | Chaff | 6 | 0 (6) | 0 | 0 | 41 | 50% | 2.7 | 0 (5) | 0 (1) | - | 0 (5) | 0 (1) |
| Opponent | Character | 7 | 8 (7) | 8 | 0 | 14 | 14% | 2.8 | 72 (1) | 0 (5) | - | 14 (5) | 0 (1) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 32 | 67% | 1.0 | - | 0 (3) | - | 0 (2) | 0 (1) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 100 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 4 | 16 (4) | 0 | 16 | 14 | 25% | 2.7 | - | 18 (3) | 0 (1) | 18 (3) | 0 (1) |
| Opponent | Hammer | 8 | 27 (8) | 21 | 7 | 32 | 50% | 1.2 | 85 (2) | 18 (2) | 0 (4) | 10 (5) | 56 (3) |
| Opponent | Holder | 1 | 108 (1) | 0 | 108 | 100 | 0% | 1.0 | - | 108 (1) | - | 108 (1) | - |
| Opponent | Shooter | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 2.0 | - | 0 (1) | - | 0 (1) | - |

### Charged fights: ccut-c940641-p43

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 3 | 59 | 190 | 2.0 | 1.3 | 95 | 0 | +95 | 3 of 6 | 5 of 6 | +0 | +114 |
| Opponent | Ogre Kingdoms | 1 | 480 | 0 | 3.0 | 1.0 | 0 | 92 | -92 | 2 of 3 | 1 of 3 | - | -92 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Opponent** | all armies | 3 | 160 | 0 | 1.0 | 1.0 | 0 | 92 | -92 | 2 of 3 | 1 of 3 | - | -92 |

### Effective charges: ccut-c940641-p43

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 6 | 1 (net +0) | 0 | 1 (net +0) | 1 (net +0) | 0 | 2 (net +230) | 1 | 20% (1 of 5) |
| Opponent | Ogre Kingdoms | 3 | 0 | 0 | 0 | 1 (net -185) | 0 | 0 | 2 | 0% (0 of 1) |

### Charged fights, damage counted: ccut-c940641-p43

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 233 | 185 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 1 | 801 | 494 | +0 | 49 | 0 | +49 | +6.2 |
| Mine | 76-89% | 1 | 233 | 185 | +0 | 0 | 116 | -116 | -50.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 301 | 204 | +230 | 254 | 0 | +254 | +84.5 |
| Mine | No odds | 1 | 379 | 111 | +111 | 111 | 0 | +111 | +29.3 |
| Mine | All fights | 6 | 375 | 231 | +95 | 111 | 19 | +92 | +24.6 |
| Opponent | 76-89% | 1 | 40 | 233 | -185 | 0 | 185 | -185 | -462.5 |
| Opponent | No odds | 2 | 62 | 233 | -45 | 77 | 54 | +24 | +38.4 |
| Opponent | All fights | 3 | 55 | 233 | -92 | 52 | 97 | -46 | -83.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p43 | move | 21 | 0 (0%) | 0 (0%) | 2 (10%) | 19 (90%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Clockwork Compass | Mine | L1228 |
| Elixir of Power | Mine | L1118, L1135 |
| Fistful of Laurels | Opponent | L1118 |
| Ring of Doom | Mine | L1118, L1135, L1228 |
| Ring of Jet | Mine | L1118, L1135, L1228 |

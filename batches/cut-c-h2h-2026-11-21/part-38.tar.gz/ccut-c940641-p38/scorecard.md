# Doctrine scorecard: ccut-c940641-p38

### Scorecard: ccut-c940641-p38

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0222 | 6 | 1 | Mine | no | 0 | 2 | 5 | 2 | 1 | 0 | 0 | 0 |
| L0222 | 6 | 1 | Opponent | no | 5 | 2 | 3 | 0 | 0 | 0 | 0 | 72 |
| L0307 | 1 | 1 | Mine | yes | 1 | 6 | 1 | 2 | 0 | 0 | 0 | 590 |
| L0307 | 1 | 1 | Opponent | no | 14 | 4 | 2 | 3 | 1 | 0 | 0 | 250 |
| L0323 | 5 | 1 | Mine | no | - | 2 | 1 | 2 | 0 | 0 | 0 | 535 |
| L0323 | 5 | 1 | Opponent | yes | - | 3 | 2 | 2 | 1 | 0 | 0 | 185 |
| **Average** | | | Mine | 33% | 0.5 | 3.3 | 2.3 | 2.0 | 0.3 | 0.0 | 0.0 | 375.0 |
| **Average** | | | Opponent | 33% | 9.5 | 3.0 | 2.3 | 1.7 | 0.7 | 0.0 | 0.0 | 169.0 |

### KPIs: ccut-c940641-p38

Rules off - Opponent only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 38% (5 of 13) | 0% (0 of 15) | 18% (5 of 28) |
| Winner chose to follow up after the loser gave ground |  | 100% (5 of 5); on the table 100% | 100% (5 of 5); on the table 100% | 100% (10 of 10); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fled |  | - | 100% (2 of 2); on the table 100% | 100% (2 of 2); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 100% (5 of 5); on the table 100% | 88% (7 of 8); on the table 88% | 92% (12 of 13); on the table 92% |
| Magic missiles tried each own turn | 50%+ | 50% (18 of 36) | 67% (4 of 6) | 52% (22 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 53% (18 of 34) | 67% (4 of 6) | 55% (22 of 40) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 50% (1 of 2) | - | 50% (1 of 2) |
| Points that never fought | lower | 52% (3048 of 5897) | 56% (3356 of 5999) | 54% (6404 of 11896) |
|   infantry points that never fought | lower | 47% (679 of 1437) | 88% (828 of 938) | 63% (1507 of 2375) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 73% (16 of 22) | 45% (9 of 20) | 60% (25 of 42) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 2.3 uses a game | 0.0 uses a game | 100% (2 of 2); 1.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (2 of 4); 0.7 uses a game | 0% (0 of 1); 0.0 uses a game | 40% (2 of 5); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 72% (3224 of 4484) | 35% (1613 of 4648) | 53% (4837 of 9132) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 4.0 (67%) | 0.0 (0%) | 4.0 (60%) |
| MARCHED: its unit marched | 0.7 (11%) | 0.3 (50%) | 1.0 (15%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.3 (50%) | 0.3 (5%) |
| IN COMBAT: engaged in combat | 0.7 (11%) | 0.0 (0%) | 0.7 (10%) |
| REAR RANK: in a rear rank | 0.7 (11%) | 0.0 (0%) | 0.7 (10%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 6.0 | 1.7 | 7.3 | 0.7 | 0.0 |
| not cast | 0.0 | 2.3 | 6.7 | 1.3 | 8.0 |
| NOT CHOSEN: could have been cast at a target | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (17%) |
| NO TARGET: no enemy in range, sight and arc it may target | - | 0.3 (14%) | 4.0 (60%) | 0.7 (50%) | 0.0 (0%) |
| MARCHED: its unit marched | - | 0.0 (0%) | 1.0 (15%) | 0.3 (25%) | 0.0 (0%) |
| CHARGED: its unit charged | - | 0.0 (0%) | 0.3 (5%) | 0.3 (25%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | - | 0.7 (29%) | 0.7 (10%) | 0.0 (0%) | 0.0 (0%) |
| REAR RANK: in a rear rank | - | 0.3 (14%) | 0.7 (10%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) |
| HELD BACK: the computer weighed it and chose not to cast it | - | 1.0 (43%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | - | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 6.3 (79%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.7 a game | 0.0 a game | 0.8 a game |
| stood (cast and not dispelled) | 20% (1 of 5) | - | 20% (1 of 5) |
| the unit moved after it | 100% (1 of 1) | - | 100% (1 of 1) |
| it charged on its next turn | 0% (0 of 1) | - | 0% (0 of 1) |
| the enemy charged it first | 0% (0 of 1) | - | 0% (0 of 1) |
| it fought by the end of its next turn | 0% (0 of 1) | - | 0% (0 of 1) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 1) | - | 0% (0 of 1) |
| none of these (no charge, no fight, no charge escaped) | 100% (1 of 1) | - | 100% (1 of 1) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 80% (40 of 50) | 67% (72 of 107) | 71% (112 of 157) |
|   cavalry | - | 87% (13 of 15) | 87% (13 of 15) |
|   character | - | 0% (0 of 17) | 0% (0 of 17) |
|   chariot | 67% (14 of 21) | 50% (3 of 6) | 63% (17 of 27) |
|   infantry | - | 79% (46 of 58) | 79% (46 of 58) |
|   war machine | 90% (26 of 29) | 91% (10 of 11) | 90% (36 of 40) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.0 (30%) | 0.7 (6%) | 1.7 (11%) |
| CHARGED: it charged | 0.7 (20%) | 2.0 (17%) | 2.7 (18%) |
| IN COMBAT: it fought this turn or the last | 0.0 (0%) | 1.7 (14%) | 1.7 (11%) |
| MOVED: a war machine that moved | 0.3 (10%) | 0.3 (3%) | 0.7 (4%) |
| NO TARGET IN RANGE | 0.3 (10%) | 5.0 (43%) | 5.3 (36%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 1.0 (9%) | 1.0 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (20%) | 1.0 (9%) | 1.7 (11%) |
| OTHER BAR | 0.3 (10%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 6.3 | 0.3 | 95% | 0.2 pts | 1 pts |
| chariot | 5.7 | 3.3 | 53% | 20.7 pts | 117 pts |
| infantry | 18.0 | 10.0 | 72% | 8.7 pts | 156 pts |
| war machine | 12.3 | 10.0 | 81% | 29.8 pts | 368 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 4.0 | 3.5 |
| Charges that made contact a game | 2.0 | 2.7 | 2.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (4 units) | 1.00 declared, 0.00 contact (1 units) | 0.20 declared, 0.00 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.45 declared, 0.30 contact (20 units) | 0.37 declared, 0.27 contact (30 units) | 0.40 declared, 0.28 contact (50 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 100% (3 of 3) | 0% (0 of 1) | - | 75% (3 of 4) |
| Character in a unit | 80% (4 of 5) | 50% (1 of 2) | - | 71% (5 of 7) |
| Character on its own | 100% (1 of 1) | - | 20% (1 of 5) | 33% (2 of 6) |
| Chariot | - | 75% (3 of 4) | - | 75% (3 of 4) |
| Infantry | 0% (0 of 2) | 67% (2 of 3) | - | 40% (2 of 5) |
| Monster | 20% (1 of 5) | - | - | 20% (1 of 5) |
| War Machines | 78% (7 of 9) | 100% (2 of 2) | - | 82% (9 of 11) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1 | 100% (4 of 4); on the table 100% | 42% (5 of 12) | 6% | 67% (4 of 6) | 100% (2 of 2); 7.0 uses a game | 0.0 uses a game | 50% (1 of 2); 1.0 uses a game |
| Chaos Dwarfs | 2 | 100% (1 of 1); on the table 100% | 54% (13 of 24) | 73% | 75% (12 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Empire of Man | 1 | 100% (3 of 3); on the table 100% | 67% (4 of 6) | 91% | 80% (8 of 10) | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Tomb Kings of Khemri | 2 | 80% (4 of 5); on the table 80% | - | 39% | 10% (1 of 10) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p38, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 38% (3) | 50% (1) | 40% (4) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.33 | 0.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.67 | 0.00 | 0.67 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.00 | 0.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: ccut-c940641-p38

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 0.7 | 2.7 |
| Strategy | Charge objectives carried out (made contact) | 57% (4 of 7) | 42% (5 of 12) |
| Strategy | Shoot objectives carried out (shot that target) | 52% (22 of 42) | 54% (19 of 35) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | - |
| Strategy | Joined characters whose unit fought | 86% (6 of 7) | 0% (0 of 4) |
| Strategy | Lone characters that fought | 20% (1 of 5) | 43% (3 of 7) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 2.0 | 1.7 |
| Movement | Points that never moved of their own | 375.0 | 169.0 |
| Movement | Fights charged into per game | 2.0 | 2.7 |
| Movement | Charges with odds: long shots (under 50%) | 1 of 4, net -52 | 1 of 8, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 4 | 3 of 8, net +210 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 4 | 1 of 8, net +85 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 4, net +69 | 2 of 8, net -48 |
| Shooting | Shots by shooting units (incl. breath weapons) | 4.7 | 22.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 36% (5 of 14) | 29% (20 of 68) |
| Shooting | Points destroyed by shooting units | 93.7 | 64.0 |
| Shooting | War machine shots | 9.0 | 3.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 22% (6 of 27) | 60% (6 of 10) |
| Shooting | Points destroyed by war machines | 65.0 | 0.0 |
| Magic | Magic missiles cast | 3.3 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 50% (5 of 10) | 25% (1 of 4) |
| Magic | Wounds caused by magic missiles | 8.0 | 0.7 |
| Magic | Points destroyed by magic (all spells) | 83.3 | 46.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 5.3 / 0.0 / 0.0 / 0.7 |
| Combat | Points destroyed in combat | 250.3 | 261.0 |
| Combat | Points run down | 0.0 | 58.7 |
| Combat | Net points per charged fight, damage counted | +25 | +103 |
| Combat | Net per 100 charger points, damage counted | +36.0 | +38.7 |
| Combat | First round won (charged fights) | 83% | 88% |
| Combat | Net points per charged fight | +36 | +81 |
| Combat | Net points per supported fight / lone fight | - / +36 | - / +81 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 6 | 2 of 8 |
| Game | Points lost | 648.3 | 524.0 |
| Game | VP from objectives | 350.0 | 916.7 |
| Game | Lone holders (player turns) | 0.5 | 9.5 |

- Mine won / drew / lost: 0 / 0 / 3 of 3 ended games (of 3); mean margin (Mine - Opponent) -710 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 1172
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ccut-c940641-p38

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 11.7 | +177.0 | 0.0 | 206.7 | 25.3 | +494.1 | 0.0 | 252.7 |
| ARTILLERY RE-ROLL WEIGHED | 2.7 | +0.0 | 0.0 | 123.3 | - | - | - | - |
| BACKUP TARGETS | - | - | - | - | 0.7 | +0.6 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 8.3 | +16.2 | 88.3 | 433.3 | 3.3 | +63.6 | 0.0 | 83.3 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 41.7 |
| CARRIES OUT SET-UP | - | - | - | - | 0.3 | -129.9 | 30.3 | 0.0 |
| CAST JOB | 3.0 | +87.4 | 187.3 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CHAFF IN THE MOVE | 1.3 | +16.7 | 0.0 | 40.0 | 0.3 | +0.6 | 0.0 | 24.0 |
| CHALLENGE BY POINTS | 0.3 | +9.3 | 0.0 | 0.0 | 0.3 | +9.2 | 0.0 | 24.0 |
| CHARGE LOSSES | 21.0 | -610.9 | 0.0 | 152.0 | 18.3 | -318.5 | 0.0 | 228.7 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 46.0 | 17.3 | 3.0 | +0.0 | 247.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 7.7 | +0.0 | 0.0 | 0.0 | 12.3 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 28.3 | 0.3 | +0.0 | 30.3 | 0.0 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.7 | +85.4 | 0.0 | 0.0 | - | - | - | - |
| COVER ONCE | 15.3 | -934.6 | 0.0 | 205.0 | 3.3 | -116.8 | 0.0 | 18.3 |
| DEPLOY BY FIGURES | 9.0 | -61.4 | 0.0 | 0.0 | 7.3 | -45.6 | 0.0 | 65.0 |
| EDGE GIVE GROUND | - | - | - | - | 0.3 | +10.2 | 76.7 | 65.0 |
| ENGINEER BY LORE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 2.0 | +7.9 | 108.3 | 17.3 | 4.0 | +49.4 | 378.7 | 65.0 |
| FALL BACK GOOD ORDER | 2.3 | +0.0 | 114.0 | 63.0 | 3.0 | +6.3 | 292.0 | 65.0 |
| FALLS SHORT | 7.0 | +173.3 | 0.0 | 184.0 | 14.0 | +161.6 | 0.0 | 44.0 |
| FEATURE BUFFS | 6.3 | +131.2 | 0.0 | 0.0 | 4.0 | +81.7 | 0.0 | 24.0 |
| FIGHT TO THE END | - | - | - | - | 1.0 | -1.5 | 210.3 | 65.0 |
| FIVE ACTION | 83.7 | +3462.3 | 879.7 | 1741.3 | 102.7 | +8436.0 | 1190.0 | 946.3 |
| FLANK NOT WEIGHED | 11.0 | +0.0 | 0.0 | 140.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | - | - | - | - | 1.0 | +212.7 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.7 | +83.7 | 132.3 | 63.0 | 4.0 | +190.1 | 378.7 | 65.0 |
| FREED FROM HIS FIGHT | 6.7 | +0.0 | 0.0 | 91.3 | 3.0 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | - | - | - | - | 1.3 | -10.0 | 0.0 | 0.0 |
| FRIENDS SHOTS CHECKED | 0.3 | -1.4 | 0.0 | 30.3 | - | - | - | - |
| GOAL WALK | 12.7 | +776.5 | 0.0 | 74.0 | 18.0 | +2355.5 | 0.0 | 93.3 |
| GUN FIGURES | 3.3 | +135.9 | 252.3 | 0.0 | - | - | - | - |
| GUN MASK | - | - | - | - | 0.7 | -48.2 | 0.0 | 0.0 |
| HARD STAY DROPPED | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 4.0 | +0.0 | 0.0 | 34.7 | 1.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 17.3 | +0.0 | 0.0 | 152.0 | 4.0 | +0.0 | 0.0 | 65.0 |
| HIS CHARGE DENIED | 0.3 | +5.8 | 0.0 | 0.0 | 0.3 | +9.0 | 28.3 | 0.0 |
| HIS CHARGE LIST | 4.7 | +0.0 | 0.0 | 113.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.0 | +0.0 | 0.0 | 28.3 | 4.7 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 2.7 | -13.0 | 0.0 | 0.0 | 5.3 | -85.1 | 0.0 | 22.0 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 31.3 | +9.0 | 546.3 | 0.0 |
| HIS MOVE WHY | 24.0 | +0.0 | 0.0 | 247.7 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 26.0 | -5.8 | 0.0 | 0.0 |
| HIS ONE QUARTER | 4.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 187.3 |
| HIS OWN BEST MOVE | 5.7 | +0.0 | 0.0 | 45.7 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 6.7 | +0.0 | 0.0 | 72.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 42.0 | +1015.0 | 0.0 | 381.7 | 55.0 | +1757.3 | 0.0 | 593.3 |
| HIS SHOTS BY HIS RUN | 41.3 | +607.2 | 0.0 | 464.7 | 45.3 | +893.3 | 0.0 | 499.7 |
| HIS TURN DENIED | 1.0 | +4.2 | 70.0 | 45.7 | 0.7 | +3.0 | 103.7 | 65.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 19.7 | +0.0 | 0.0 | 112.0 | 26.0 | +0.0 | 0.0 | 72.0 |
| HOLDER ASSIGNMENT | 8.7 | +892.0 | 0.0 | 56.0 | 15.0 | +1313.4 | 0.0 | 24.0 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.0 | -21.4 | 132.3 | 45.7 | 3.3 | -130.6 | 378.7 | 65.0 |
| IDLE COST | 5.7 | -35.9 | 0.0 | 101.0 | 12.3 | -201.2 | 0.0 | 135.0 |
| JOINT CHARGE NOW | 0.7 | +0.3 | 44.0 | 0.0 | - | - | - | - |
| KEEP FALLS | 0.7 | +8.1 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 0.7 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 1.3 | +45.8 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 1.0 | +0.0 | 18.3 | 58.7 | 13.7 | +0.0 | 331.0 | 555.3 |
| LONE WIZARD KEPT IN | 0.7 | +17.5 | 0.0 | 0.0 | 1.0 | +78.3 | 0.0 | 0.0 |
| LONG SHOT | 1.0 | +17.8 | 68.0 | 28.3 | - | - | - | - |
| LOST AFTER ESCAPE | 0.7 | -0.0 | 18.3 | 0.0 | 1.3 | +1.9 | 58.3 | 0.0 |
| LOST CHARGE | 0.3 | -1.9 | 18.3 | 0.0 | 0.3 | -0.3 | 103.3 | 0.0 |
| MAKE SURE TOGETHER | - | - | - | - | 1.0 | +3.7 | 0.0 | 0.0 |
| MANOEUVRE | 2.3 | +0.0 | 0.0 | 27.0 | 1.7 | -24.9 | 0.0 | 23.3 |
| MARCH AT ESCAPER | 0.3 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 0.3 | +3.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 1.3 | +44.1 | 0.0 | 54.0 | - | - | - | - |
| MARCH OF THE TABLE | 0.3 | +3.1 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.0 | +16.4 | 0.0 | 0.0 | 0.3 | +22.6 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.7 | +54.1 | 0.0 | 110.7 | 3.0 | +46.1 | 0.0 | 93.7 |
| MEETS IN TIME | 3.3 | +203.8 | 0.0 | 0.0 | 1.7 | +142.6 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 7.0 | +175.3 | 0.0 | 54.0 | 1.3 | +57.4 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 8.7 | +113.7 | 0.0 | 54.0 | 1.3 | +32.7 | 0.0 | 0.0 |
| MISSILES ON ONE TARGET | 0.3 | -12.5 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 1.7 | +0.0 | 20.0 | 0.0 | 1.0 | +0.0 | 22.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | 0.7 | -0.7 | 56.7 | 0.0 | - | - | - | - |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 4.7 | +175.9 | 0.0 | 119.7 | 6.3 | +493.3 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.3 | +18.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 6.3 | +326.3 | 0.0 | 30.3 | 11.3 | +487.9 | 0.0 | 70.0 |
| NEXT CHARGE BY LIST | 2.3 | +99.6 | 0.0 | 63.0 | 4.3 | +275.3 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.3 | -47.6 | 110.3 | 63.0 | 3.3 | -118.9 | 320.0 | 65.0 |
| NO LATE CUT | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 5.0 | -93.5 | 24.0 | 212.0 | 8.0 | -165.6 | 0.0 | 107.3 |
| OGRE LOADER SECOND SHOT | 1.0 | +0.4 | 0.0 | 76.7 | - | - | - | - |
| ONE CHALLENGE TEST | 0.3 | +0.7 | 24.0 | 28.3 | - | - | - | - |
| ONE FIGHT FORMULA | 3.3 | -19.9 | 0.0 | 194.7 | 6.7 | -136.0 | 0.0 | 65.0 |
| ONE OBJECTIVE FORMULA | 6.3 | +36.2 | 0.0 | 56.0 | 5.7 | +102.0 | 0.0 | 24.0 |
| ONE PROMISE A TARGET | 0.3 | -1.6 | 0.0 | 17.3 | 0.3 | -10.8 | 0.0 | 0.0 |
| ONE ROUTE | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | - | - | - | - | 1.0 | +6.4 | 100.7 | 0.0 |
| OPENS UP | - | - | - | - | 1.0 | +62.1 | 30.3 | 0.0 |
| OVERRUNS AWAY | 0.3 | +0.7 | 0.0 | 0.0 | 2.0 | +31.5 | 217.3 | 0.0 |
| PIVOT GUARDS FLANK | 0.3 | -0.6 | 0.0 | 0.0 | - | - | - | - |
| PLAN RESULT | 39.7 | +609.8 | 632.0 | 1119.3 | 46.7 | +741.4 | 280.3 | 798.7 |
| PROMISE BELOW ZERO | 0.7 | +0.0 | 0.0 | 120.7 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 7.3 | -118.3 | 0.0 | 28.3 | 9.0 | -205.9 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.7 | -11.5 | 0.0 | 28.3 | - | - | - | - |
| PROMISE READS THE TABLE | - | - | - | - | 1.0 | -68.0 | 0.0 | 0.0 |
| QUARTER ODDS | 13.0 | +726.7 | 374.7 | 0.0 | 15.7 | +2000.9 | 60.7 | 187.3 |
| RANDOM MOVE BY FIGURES | 0.7 | +0.0 | 0.0 | 56.7 | - | - | - | - |
| REAL GROUND | - | - | - | - | 2.3 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.3 | +69.5 | 0.0 | 120.7 | 2.3 | +108.3 | 0.0 | 92.0 |
| REDIRECT FOR A FRIEND IN REACH | 2.0 | +0.0 | 0.0 | 82.3 | 4.0 | +0.0 | 0.0 | 44.0 |
| REDIRECT WEIGHED | - | - | - | - | 1.0 | +55.4 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 0.3 | -0.2 | 0.0 | 0.0 | 1.7 | -80.7 | 0.0 | 0.0 |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +1.4 | 0.0 | 0.0 |
| RESERVE MOVE SPELL | 0.3 | +6.6 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 2.7 | +31.4 | 132.3 | 63.0 | 3.3 | +18.7 | 294.0 | 65.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 1.7 | +34.5 | 163.3 | 65.0 |
| RUN DOWN | 0.3 | -0.8 | 0.0 | 0.0 | 2.7 | -11.2 | 218.7 | 65.0 |
| SCOUT SPOT | - | - | - | - | 2.0 | +1.8 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 1.3 | -155.4 | 0.0 | 40.0 | - | - | - | - |
| SEARCH SPOT | 0.3 | +7.6 | 0.0 | 0.0 | 1.0 | +0.9 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +3.3 | 24.0 | 28.3 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 0.3 | -0.8 | 0.0 | 0.0 |
| SET UP BY THE SET | - | - | - | - | 1.7 | -101.2 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 1.7 | +7.0 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | 0.7 | -2.6 | 0.0 | 20.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +1.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 14.3 | +0.0 | 0.0 | 556.7 | 11.7 | +0.0 | 0.0 | 120.0 |
| SHOOTS FROM THE BEST SPOT | 6.0 | +218.7 | 361.3 | 0.0 | 2.0 | +31.6 | 46.7 | 0.0 |
| SHOT OR CHARGE | 0.7 | -10.3 | 44.0 | 0.0 | 1.3 | -5.8 | 160.7 | 18.3 |
| SHOT RISK POINTS | 24.3 | -266.5 | 0.0 | 357.3 | 29.0 | +9.5 | 0.0 | 571.3 |
| SHOTS AFTER THE MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 14.0 | +546.9 | 0.0 | 536.7 | 24.7 | +416.4 | 0.0 | 212.0 |
| SPELLS IN THE FIGHT | 0.3 | -2.3 | 0.0 | 0.0 | 0.3 | +2.3 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 5.0 | +0.0 | 0.0 | 119.7 | 5.3 | +0.0 | 0.0 | 23.3 |
| STAND AND SHOOT | 1.7 | -2.0 | 108.3 | 28.3 | 0.3 | -5.0 | 103.3 | 0.0 |
| STANDS FOR A REASON | 1.3 | +0.0 | 0.0 | 54.0 | 6.7 | +0.0 | 206.7 | 44.0 |
| STANDS STILL | 40.7 | +0.0 | 747.3 | 1300.7 | 37.3 | +0.0 | 811.3 | 332.0 |
| STAY WORTH | 19.3 | -399.0 | 46.7 | 1050.0 | 36.3 | +406.2 | 730.0 | 329.0 |
| STRIKE BY THE ODDS | - | - | - | - | 0.3 | +5.9 | 0.0 | 0.0 |
| STUBBORN BY POINTS | 0.7 | +28.7 | 65.0 | 76.7 | - | - | - | - |
| STUCK PIVOT | 0.3 | +0.0 | 0.0 | 56.7 | - | - | - | - |
| SUPPORT ADDS | 2.7 | +159.9 | 0.0 | 56.7 | 4.0 | +45.0 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 24.0 | 28.3 | - | - | - | - |
| SUPPORT WORKED OUT | 2.7 | +159.9 | 0.0 | 56.7 | 4.0 | +45.0 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 1.0 | +4.6 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 28.3 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 0.3 | -21.1 | 0.0 | 0.0 | 0.7 | -63.5 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.7 | +0.0 | 0.0 | 27.0 | 2.7 | +0.0 | 0.0 | 23.3 |
| THE ROW KEEPS ITS WAY | 2.3 | +0.0 | 0.0 | 17.3 | 1.0 | +0.0 | 0.0 | 23.3 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 23.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 38.7 | +0.0 | 0.0 | 816.7 | 48.7 | +0.0 | 0.0 | 440.7 |
| TIED UP BY THE SUM | 0.7 | +31.6 | 46.0 | 17.3 | 1.7 | +187.3 | 112.0 | 0.0 |
| TIME ON OUR SIDE | 21.7 | +290.8 | 0.0 | 267.3 | 18.0 | +212.2 | 0.0 | 84.7 |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 56.7 | 0.7 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 1.7 | +0.0 | 0.0 | 103.3 | - | - | - | - |
| WEAPON BY POINTS | 0.3 | +0.0 | 0.0 | 28.3 | 0.3 | +0.0 | 0.0 | 143.7 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -4.0 | 56.7 | 0.0 |
| WHO FIGHTS | - | - | - | - | 0.7 | -37.3 | 30.3 | 0.0 |
| WHO HITS BACK | 0.3 | +3.1 | 0.0 | 0.0 | 0.3 | +2.5 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +3.2 | 28.3 | 0.0 |
| WHOLE FIGHT DANGER | 2.7 | -326.1 | 0.0 | 17.3 | 1.0 | -16.9 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 2.7 | +85.2 | 0.0 | 0.0 | 1.0 | +29.3 | 0.0 | 0.0 |

### Rule changes: ccut-c940641-p38

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 111 | 111 | 75 | 25.00 | +1854 | +24.7 |
| HIS SHOT LIST | 291 | 286 | 75 | 25.00 | +1640 | +21.9 |
| HIS MOVE AS HE DECIDES | 94 | 94 | 67 | 22.33 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 71 | 71 | 67 | 22.33 | +4853 | +72.4 |
| HIS MOVE WHY | 72 | 72 | 48 | 16.00 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 44 | 44 | 44 | 14.67 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 260 | 250 | 40 | 13.33 | +495 | +12.4 |
| OFF BEST | 39 | 39 | 39 | 13.00 | -778 | -19.9 |
| DEPLOY BY FIGURES | 49 | 49 | 32 | 10.67 | +405 | +12.6 |
| THE TABLE AGAIN | 36 | 36 | 32 | 10.67 | +0 | +0.0 |
| HIS ONE MOVE | 78 | 77 | 27 | 9.00 | +0 | +0.0 |
| FIVE ACTION | 559 | 544 | 26 | 8.67 | +946 | +36.4 |
| GOAL WALK | 92 | 89 | 24 | 8.00 | +1683 | +70.1 |
| MOVE TO CHARGE COMPUTED | 33 | 31 | 23 | 7.67 | +690 | +30.0 |
| PROMISE BY ITS OWN SUM | 49 | 49 | 19 | 6.33 | -972 | -51.2 |
| REDIRECT FOR A FRIEND IN REACH | 18 | 18 | 18 | 6.00 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 20 | 20 | 17 | 5.67 | +563 | +33.1 |
| TIME ON OUR SIDE | 119 | 100 | 17 | 5.67 | +88 | +5.2 |
| SHOT RISK POINTS | 160 | 154 | 14 | 4.67 | +414 | +29.5 |
| FOUR ROUNDS | 20 | 18 | 9 | 3.00 | +249 | +27.6 |
| STAY WORTH | 167 | 150 | 9 | 3.00 | +17 | +1.9 |
| ARTILLERY RE-ROLL WEIGHED | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| MOVE ORDER | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| QUARTER ODDS | 86 | 85 | 8 | 2.67 | +508 | +63.5 |
| SUPPORT ADDS | 20 | 20 | 8 | 2.67 | +146 | +18.2 |
| SUPPORT WORKED OUT | 20 | 20 | 8 | 2.67 | +146 | +18.2 |
| COVER ONCE | 56 | 42 | 7 | 2.33 | +386 | +55.1 |
| HARD STAY DROPPED | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 24 | 24 | 7 | 2.33 | +93 | +13.3 |
| THE RISK READS HIS RUN | 18 | 18 | 7 | 2.33 | +0 | +0.0 |
| CANNON SIGHT KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| MAX FOR POSITIONING | 17 | 14 | 6 | 2.00 | +10 | +1.6 |
| MEETS IN TIME | 15 | 15 | 6 | 2.00 | +516 | +86.1 |
| SCOUT WAITS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| SHOTS IN THE MOVE | 116 | 88 | 6 | 2.00 | +370 | +61.7 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 5 | 5 | 5 | 1.67 | +288 | +57.5 |
| TIED UP BY THE SUM | 7 | 7 | 5 | 1.67 | +119 | +23.8 |
| CANNON PLANNED TARGET | 35 | 35 | 4 | 1.33 | +0 | +0.0 |
| CHAFF IN THE MOVE | 5 | 5 | 4 | 1.33 | +3 | +0.8 |
| CHARGE NOW FIRST | 11 | 11 | 4 | 1.33 | -60 | -15.1 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +137 | +34.3 |
| MARCH CHECK | 4 | 4 | 4 | 1.33 | +54 | +13.4 |
| NEARER NOT NEEDED | 53 | 50 | 4 | 1.33 | +163 | +40.7 |
| SHOTS AFTER THE MOVES | 27 | 27 | 4 | 1.33 | +0 | +0.0 |
| FALLS SHORT | 63 | 52 | 3 | 1.00 | +76 | +25.5 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +638 | +212.7 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MISSILES IN THE MOVE | 25 | 14 | 3 | 1.00 | +48 | +16.1 |
| OGRE LOADER SECOND SHOT | 3 | 3 | 3 | 1.00 | +1 | +0.4 |
| REDIRECT COUNTER | 14 | 11 | 3 | 1.00 | +52 | +17.3 |
| REDIRECT WEIGHED | 3 | 3 | 3 | 1.00 | +626 | +208.6 |
| SET UP BY THE SET | 5 | 5 | 3 | 1.00 | +90 | +30.0 |
| WHOLE FIGHT DANGER | 11 | 11 | 3 | 1.00 | +211 | +70.4 |
| CASTER AWAY FROM SCREEN | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +55 | +27.7 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| EXACT ROUND | 18 | 17 | 2 | 0.67 | +56 | +28.2 |
| HIS CHARGE DENIED | 2 | 2 | 2 | 0.67 | +28 | +13.9 |
| HIS MOVE AND SHOT | 24 | 24 | 2 | 0.67 | +92 | +46.0 |
| HONEST WORTH | 16 | 14 | 2 | 0.67 | +123 | +61.5 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +1 | +0.5 |
| KEEP FALLS | 2 | 2 | 2 | 0.67 | +119 | +59.4 |
| ONE FIGHT FORMULA | 30 | 18 | 2 | 0.67 | +1 | +0.6 |
| ONE OBJECTIVE FORMULA | 36 | 30 | 2 | 0.67 | +26 | +13.0 |
| ONE PROMISE A TARGET | 2 | 2 | 2 | 0.67 | -37 | -18.6 |
| OPENS UP | 3 | 2 | 2 | 0.67 | +37 | +18.7 |
| RISK BY ARC | 18 | 16 | 2 | 0.67 | +60 | +29.9 |
| SEARCH SPOT | 4 | 4 | 2 | 0.67 | +26 | +12.9 |
| STUBBORN BY POINTS | 2 | 2 | 2 | 0.67 | +86 | +43.2 |
| THE ROW IN ITS ORDER | 19 | 2 | 2 | 0.67 | +0 | +0.0 |
| WEAPON BY POINTS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +17 | +8.3 |
| CARRIES OUT SET-UP | 1 | 1 | 1 | 0.33 | -390 | -389.7 |
| CHARGE LOSSES | 118 | 113 | 1 | 0.33 | +7 | +6.8 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EDGE GIVE GROUND | 1 | 1 | 1 | 0.33 | +15 | +15.5 |
| FEATURE BUFFS | 31 | 31 | 1 | 0.33 | +12 | +12.2 |
| FRIEND SHOOTS FIRST | 4 | 4 | 1 | 0.33 | +0 | +0.2 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | -4 | -4.3 |
| IDLE COST | 54 | 27 | 1 | 0.33 | +1 | +1.2 |
| MANOEUVRE | 12 | 12 | 1 | 0.33 | +6 | +5.9 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +11 | +11.4 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -9 | -9.4 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +55 | +55.1 |
| NO DOUBLE ROUNDS | 17 | 16 | 1 | 0.33 | +128 | +128.0 |
| OVERRUNS AWAY | 7 | 6 | 1 | 0.33 | +11 | +11.3 |
| PIVOT GUARDS FLANK | 1 | 1 | 1 | 0.33 | -2 | -1.9 |
| PROMISE KNOWS THE FIGHT | 2 | 2 | 1 | 0.33 | -34 | -34.5 |
| PROMISE READS THE TABLE | 3 | 3 | 1 | 0.33 | -5 | -5.2 |
| RANDOM MOVE BY FIGURES | 2 | 2 | 1 | 0.33 | +0 | +0.0 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +4 | +4.2 |
| RESERVE MOVE SPELL | 1 | 1 | 1 | 0.33 | +21 | +20.9 |
| ROUNDS AFTER TERROR | 5 | 4 | 1 | 0.33 | +14 | +13.5 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +10 | +9.8 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +4 | +4.0 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +18 | +17.8 |
| STUCK PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SURE REACH TOGETHER | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| BACKUP TARGETS | 2 | 1 | 0 | 0.00 | - | - |
| CAST JOB | 9 | 9 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 60 | 59 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 2 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 16 | 15 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 3 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 43 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 29 | 29 | 0 | 0.00 | - | - |
| GUN FIGURES | 10 | not checked | - | - | - | - |
| GUN MASK | 2 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 17 | 17 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 64 | 62 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 15 | 15 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 23 | 22 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 17 | 17 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 25 | 24 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 20 | 20 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 5 | 4 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 137 | 137 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 17 | 17 | 0 | 0.00 | - | - |
| LONG SHOT | 3 | 2 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 6 | 5 | 0 | 0.00 | - | - |
| LOST CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| MAKE SURE TOGETHER | 3 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 4 | 4 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 7 | 7 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 30 | 20 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 2 | trace | - | - | - | - |
| MOVE SPELL SPOT | 1 | not checked | - | - | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| ONE CHALLENGE TEST | 1 | not checked | - | - | - | - |
| ONE ROUTE | 7 | 7 | 0 | 0.00 | - | - |
| OPENS A LANE | 3 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 259 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 7 | 7 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 6 | 6 | 0 | 0.00 | - | - |
| RUN DOWN | 9 | 8 | 0 | 0.00 | - | - |
| SCOUT SPOT | 6 | 6 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 4 | 4 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 5 | 4 | 0 | 0.00 | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 78 | not checked | - | - | - | - |
| SHOT OR CHARGE | 6 | 5 | 0 | 0.00 | - | - |
| SPELLS IN THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 31 | 21 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 6 | 5 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 24 | 21 | 0 | 0.00 | - | - |
| STANDS STILL | 234 | 226 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE PROMISE ADDS | 3 | 3 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 10 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 2 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 7 | not checked | - | - | - | - |
| THE TABLE BINDS | 262 | not checked | - | - | - | - |
| WAITS AGAIN | 6 | 5 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 5 | 5 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | 2 | 0 | 0.00 | - | - |
| WHO FIGHTS | 2 | 1 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 11 | 11 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p38

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.33 | 7.00 | 22.5 |
| PROMISE BY ITS OWN SUM | rule | 3.33 | 3.00 | 51.2 |
| CHARGE NOW FIRST | rule | 0.33 | 1.00 | 15.1 |
| AFTERMATH BAND | gate | 0.33 | 0.33 | 2.5 |
| ARMY TABLE | rule | - | 0.67 | 32.0 |
| ONE PROMISE A TARGET | rule | 0.33 | 0.33 | 18.6 |
| RULE SWITCHED OFF | gate | - | 0.67 | 1.4 |
| CARRIES OUT SET-UP | rule | - | 0.33 | 389.7 |
| FRIENDS SHOTS CHECKED | rule | 0.33 | - | 4.3 |
| JOINT CHARGE NOW | rule | 0.33 | - | 19.4 |
| MARCH OF THE TABLE | rule | 0.33 | - | 9.4 |
| NO REASON | gate | 0.33 | - | 4.0 |
| PIVOT GUARDS FLANK | rule | 0.33 | - | 1.9 |
| PROMISE KNOWS THE FIGHT | rule | 0.33 | - | 34.5 |
| PROMISE READS THE TABLE | rule | - | 0.33 | 5.2 |

### Plans: ccut-c940641-p38

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.3 | 57% | 93 | 85 | 91% |
| Mine | move | 23.7 | 94% | 1302 | 0 | 0% |
| Mine | shoot | 13.0 | 46% | 289 | 525 | 181% |
| Mine | support | 0.7 | 50% | 1 | 0 | 0% |
| Opponent | charge | 3.3 | 80% | 469 | 409 | 87% |
| Opponent | move | 34.3 | 95% | 2594 | 0 | 0% |
| Opponent | shoot | 9.0 | 48% | 452 | 333 | 74% |

### Battle groups: ccut-c940641-p38

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.3 | 43% | 100% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 2.3 | 57% | 75% | 25% | 0% | 33% | 0% | 0% | 67% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p38

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | Character | 7 | 57 (7) | 57 | 0 | 8 | 14% | 2.8 | 0 (1) | 149 (1) | 56 (5) | 64 (6) | 0 (1) |
| Mine | Clean-up | 4 | 18 (4) | 18 | 0 | 24 | 75% | 3.0 | 0 (1) | 23 (3) | - | 0 (3) | 73 (1) |
| Mine | Fast Hammer | 5 | 39 (5) | 39 | 0 | 84 | 0% | 3.4 | - | 81 (3) | 0 (2) | 46 (4) | 0 (1) |
| Mine | Hammer | 9 | 18 (9) | 12 | 6 | 23 | 11% | 2.4 | 0 (1) | 0 (4) | 44 (4) | 24 (7) | 0 (2) |
| Mine | Holder | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Mine | War machine | 8 | 17 (8) | 17 | 0 | 69 | 0% | 1.1 | 0 (2) | 32 (5) | 0 (1) | 0 (3) | 27 (5) |
| Mine | Wizard | 5 | 45 (5) | 45 | 0 | 0 | 0% | 3.8 | 229 (1) | 0 (2) | 0 (2) | 108 (2) | 0 (3) |
| Opponent | Chaff | 5 | 56 (5) | 48 | 9 | 60 | 0% | 1.2 | 231 (1) | 11 (4) | - | 56 (5) | - |
| Opponent | Character | 8 | 29 (8) | 29 | 0 | 29 | 50% | 2.2 | 34 (3) | 28 (2) | 23 (3) | 36 (6) | 0 (2) |
| Opponent | Clean-up | 4 | 68 (4) | 0 | 68 | 29 | 100% | - | 0 (2) | 0 (1) | 139 (1) | 79 (3) | 0 (1) |
| Opponent | Fast Hammer | 6 | 47 (6) | 47 | 0 | 17 | 17% | 3.6 | 16 (3) | 77 (3) | - | 14 (2) | 63 (4) |
| Opponent | Holder | 9 | 57 (9) | 0 | 57 | 28 | 0% | 2.1 | 0 (2) | 102 (4) | 29 (3) | 125 (4) | 0 (5) |
| Opponent | Shooter | 2 | 113 (2) | 54 | 59 | 0 | 0% | 1.5 | 59 (1) | 172 (1) | - | 59 (1) | 172 (1) |
| Opponent | War machine | 3 | 0 (3) | 0 | 0 | 67 | 33% | 1.0 | 0 (3) | - | - | 0 (2) | 0 (1) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 0 | 0% | 1.0 | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |

### Charged fights: ccut-c940641-p38

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 55 | 199 | 5.0 | 1.0 | 40 | 10 | +29 | 1 of 5 | 4 of 5 | - | +29 |
| Mine | Chaos Dwarfs | 2 | 336 | 33 | 0.5 | 1.0 | 66 | 0 | +66 | 0 of 1 | 1 of 1 | - | +66 |
| **Mine** | all armies | 3 | 242 | 88 | 2.0 | 1.0 | 44 | 9 | +36 | 1 of 6 | 5 of 6 | - | +36 |
| Opponent | Empire of Man | 1 | 140 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 2 | 96 | 568 | 3.5 | 1.0 | 162 | 69 | +93 | 1 of 7 | 6 of 7 | - | +93 |
| **Opponent** | all armies | 3 | 111 | 379 | 2.7 | 1.0 | 142 | 61 | +81 | 2 of 8 | 7 of 8 | - | +81 |

### Effective charges: ccut-c940641-p38

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 1 (net -52) | 0 | 0 | 1 (net +55) | 0 | 1 (net +72) | 2 | 0% (0 of 3) |
| Mine | Chaos Dwarfs | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +66) | 0 | 0% (0 of 1) |
| Opponent | Empire of Man | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 7 | 0 | 0 | 3 (net +210) | 1 (net +30) | 1 (net +85) | 2 (net -48) | 0 | 43% (3 of 7) |

### Charged fights, damage counted: ccut-c940641-p38

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 1 | 52 | 195 | -52 | 32 | 52 | -20 | -37.5 |
| Mine | 76-89% | 1 | 52 | 55 | +55 | 55 | 35 | +20 | +39.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 72 | 69 | +69 | 69 | 30 | +39 | +54.1 |
| Mine | No odds | 2 | 85 | 64 | +36 | 36 | 0 | +36 | +42.4 |
| Mine | All fights | 6 | 70 | 86 | +36 | 50 | 25 | +25 | +36.0 |
| Opponent | Long shot (under 50%) | 1 | 189 | 314 | +0 | 262 | 105 | +157 | +82.9 |
| Opponent | Effective (55-75%) | 3 | 277 | 210 | +210 | 248 | 39 | +208 | +75.4 |
| Opponent | 76-89% | 1 | 195 | 85 | +30 | 85 | 55 | +30 | +15.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 252 | 126 | -48 | 213 | 228 | -14 | -5.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 411 | 85 | +85 | 85 | 46 | +39 | +9.6 |
| Opponent | All fights | 8 | 266 | 171 | +81 | 200 | 97 | +103 | +38.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p38 | move | 23 | 8 (35%) | 7 (30%) | 2 (9%) | 13 (57%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Ring of Doom | Mine | L0222 |
| Twice-Blessed Armour | Opponent | L0307 |
| Witch Hunter's Ward | Opponent | L0307 |

# Doctrine scorecard: ccut-c940641-p26

### Scorecard: ccut-c940641-p26

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0218 | 2 | 1 | Mine | - | - | - | 0 | 9 | 0 | 0 | 0 | 285 |
| L0218 | 2 | 1 | Opponent | - | - | - | 0 | 5 | 0 | 0 | 0 | 148 |
| L0235 | 1 | 1 | Mine | no | 4 | 6 | 0 | 7 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Opponent | yes | 4 | 3 | 1 | 4 | 0 | 0 | 0 | 125 |
| L0319 | 1 | 1 | Mine | no | 4 | - | 0 | 0 | 0 | 0 | 0 | 335 |
| L0319 | 1 | 1 | Opponent | no | 2 | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 4.0 | 6.0 | 0.0 | 5.3 | 0.0 | 0.0 | 0.0 | 206.7 |
| **Average** | | | Opponent | 50% | 3.0 | 3.0 | 0.7 | 3.7 | 0.0 | 0.0 | 0.0 | 91.0 |

### KPIs: ccut-c940641-p26

Rules off - Opponent only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 12% (1 of 8) | 0% (0 of 13) | 5% (1 of 21) |
| Winner chose to follow up after the loser gave ground |  | 0% (0 of 1); on the table 100% | 100% (1 of 1); on the table 100% | 50% (1 of 2); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | - | - | - |
| Winner chose to follow up or pursue (all three) |  | 0% (0 of 1); on the table 100% | 100% (1 of 1); on the table 100% | 50% (1 of 2); on the table 100% |
| Magic missiles tried each own turn | 50%+ | 52% (22 of 42) | 21% (5 of 24) | 41% (27 of 66) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 52% (22 of 42) | 21% (5 of 24) | 41% (27 of 66) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | 75% (9 of 12) | - | 75% (9 of 12) |
| Points that never fought | lower | 86% (5002 of 5797) | 76% (4535 of 6000) | 81% (9537 of 11797) |
|   infantry points that never fought | lower | 77% (1060 of 1374) | 85% (717 of 842) | 80% (1777 of 2216) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 85% (17 of 20) | 52% (14 of 27) | 66% (31 of 47) |
| Bound items with a magic missile used (at least once a game) |  | 100% (4 of 4); 6.3 uses a game | 50% (1 of 2); 1.7 uses a game | 83% (5 of 6); 4.0 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 80% (4 of 5); 1.3 uses a game | 100% (1 of 1); 0.3 uses a game | 83% (5 of 6); 0.8 uses a game |
|   their share of the points of units over 100 pts | lower | 80% (3233 of 4039) | 49% (2701 of 5515) | 62% (5934 of 9554) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 6.0 (90%) | 0.0 (0%) | 6.0 (46%) |
| MARCHED: its unit marched | 0.7 (10%) | 0.3 (5%) | 1.0 (8%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 4.3 (68%) | 4.3 (33%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 1.7 (26%) | 1.7 (13%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- |
| tried | 1.3 | 4.3 | 9.0 | 0.0 |
| not cast | 2.7 | 5.7 | 13.0 | 28.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.0 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.7 (25%) | 0.0 (0%) | 6.0 (46%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 1.0 (8%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 2.0 (75%) | 4.0 (71%) | 4.3 (33%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 1.7 (13%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.0 (0%) | 1.7 (29%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 26.0 (93%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.7 a game | 1.7 a game | 2.2 a game |
| stood (cast and not dispelled) | 75% (6 of 8) | 20% (1 of 5) | 54% (7 of 13) |
| the unit moved after it | 83% (5 of 6) | 0% (0 of 1) | 71% (5 of 7) |
| it charged on its next turn | 0% (0 of 6) | 0% (0 of 1) | 0% (0 of 7) |
| the enemy charged it first | 0% (0 of 6) | 0% (0 of 1) | 0% (0 of 7) |
| it fought by the end of its next turn | 0% (0 of 6) | 0% (0 of 1) | 0% (0 of 7) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 6) | 0% (0 of 1) | 0% (0 of 7) |
| none of these (no charge, no fight, no charge escaped) | 100% (6 of 6) | 100% (1 of 1) | 100% (7 of 7) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 67% (22 of 33) | 54% (45 of 84) | 57% (67 of 117) |
|   cavalry | - | 56% (10 of 18) | 56% (10 of 18) |
|   character | - | 50% (6 of 12) | 50% (6 of 12) |
|   chariot | 50% (6 of 12) | 58% (7 of 12) | 54% (13 of 24) |
|   infantry | - | 40% (12 of 30) | 40% (12 of 30) |
|   monster | - | 83% (10 of 12) | 83% (10 of 12) |
|   war machine | 76% (16 of 21) | - | 76% (16 of 21) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.3 (36%) | 2.3 (18%) | 3.7 (22%) |
| CHARGED: it charged | 0.0 (0%) | 0.7 (5%) | 0.7 (4%) |
| IN COMBAT: it fought this turn or the last | 0.3 (9%) | 0.0 (0%) | 0.3 (2%) |
| MOVED: a war machine that moved | 0.7 (18%) | 0.0 (0%) | 0.7 (4%) |
| NO TARGET IN RANGE | 0.0 (0%) | 6.7 (51%) | 6.7 (40%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (36%) | 1.3 (10%) | 2.7 (16%) |
| SHELTERED: the target was sheltered | 0.0 (0%) | 0.3 (3%) | 0.3 (2%) |
| OTHER BAR | 0.0 (0%) | 1.7 (13%) | 1.7 (10%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.7 | 0.3 | 93% | 0.8 pts | 4 pts |
| character | 2.0 | 1.0 | 67% | 14.2 pts | 28 pts |
| chariot | 4.3 | 5.3 | 38% | 22.7 pts | 99 pts |
| infantry | 4.0 | 2.7 | 58% | 6.3 pts | 25 pts |
| monster | 3.3 | 3.7 | 50% | 14.8 pts | 49 pts |
| war machine | 5.3 | 2.7 | 75% | 6.3 pts | 34 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 0.3 | 3.0 | 1.7 |
| Charges that made contact a game | 0.3 | 1.0 | 0.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.00 declared, 0.00 contact (2 units) | - | 0.00 declared, 0.00 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.04 declared, 0.04 contact (25 units) | 0.31 declared, 0.10 contact (29 units) | 0.19 declared, 0.07 contact (54 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 33% (1 of 3) | 0% (0 of 1) | - | 25% (1 of 4) |
| Character in a unit | 86% (6 of 7) | 71% (5 of 7) | - | 79% (11 of 14) |
| Character on its own | 100% (1 of 1) | 100% (1 of 1) | 50% (1 of 2) | 75% (3 of 4) |
| Chariot | 50% (1 of 2) | 100% (2 of 2) | - | 75% (3 of 4) |
| Infantry | 60% (3 of 5) | 33% (1 of 3) | - | 50% (4 of 8) |
| Monster | 100% (2 of 2) | 0% (0 of 1) | - | 67% (2 of 3) |
| Monstrous | 100% (2 of 2) | 25% (1 of 4) | - | 50% (3 of 6) |
| War Machines | 100% (3 of 3) | 100% (1 of 1) | - | 100% (4 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 2 | 0% (0 of 1); on the table 100% | 73% (22 of 30) | 99% | 83% (10 of 12) | 100% (4 of 4); 9.5 uses a game | 0.0 uses a game | 75% (3 of 4); 1.5 uses a game |
| Chaos Dwarfs | 1 | - | 0% (0 of 12) | 63% | 88% (7 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 100% | 57% (4 of 7) | 100% (1 of 1); 5.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (1 of 1); on the table 100% | 0% (0 of 12) | 33% | 38% (3 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Wood Elf Realms | 1 | - | 83% (5 of 6) | 94% | 58% (7 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p26, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 67% (2) | 100% (1) | 75% (3) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.33 | 1.00 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.33 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: ccut-c940641-p26

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 1.3 | 1.3 |
| Strategy | Charge objectives carried out (made contact) | 100% (1 of 1) | 25% (1 of 4) |
| Strategy | Shoot objectives carried out (shot that target) | 52% (11 of 21) | 28% (5 of 18) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 50% (2 of 4) |
| Strategy | Joined characters whose unit fought | 0% (0 of 10) | 67% (4 of 6) |
| Strategy | Lone characters that fought | 20% (1 of 5) | 33% (1 of 3) |
| Movement | Charges halted short of contact | 0.0 | 0.3 |
| Movement | Idle units | 5.3 | 3.7 |
| Movement | Points that never moved of their own | 206.7 | 91.0 |
| Movement | Fights charged into per game | 0.3 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 1 | 0 of 1 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 1, net -52 | 0 of 1 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 1 | 1 of 1, net +0 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 0 of 1 | 0 of 1 |
| Shooting | Shots by shooting units (incl. breath weapons) | 2.0 | 15.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 83% (5 of 6) | 42% (19 of 45) |
| Shooting | Points destroyed by shooting units | 0.0 | 38.3 |
| Shooting | War machine shots | 5.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (7 of 16) | - |
| Shooting | Points destroyed by war machines | 0.0 | 28.3 |
| Magic | Magic missiles cast | 4.3 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 38% (5 of 13) | 0% (0 of 4) |
| Magic | Wounds caused by magic missiles | 11.0 | 2.7 |
| Magic | Points destroyed by magic (all spells) | 41.7 | 17.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.0 / 0.0 / 0.0 / 0.0 | 0.0 / 1.3 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 0.0 | 193.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +2 | +162 |
| Combat | Net per 100 charger points, damage counted | +3.0 | +40.7 |
| Combat | First round won (charged fights) | 100% | 100% |
| Combat | Net points per charged fight | -52 | +176 |
| Combat | Net points per supported fight / lone fight | - / -52 | - / +176 |
| Combat | Charged fights on a top-3 enemy unit | 0 of 1 | 2 of 3 |
| Game | Points lost | 357.0 | 60.0 |
| Game | VP from objectives | 686.7 | 1160.0 |
| Game | Lone holders (player turns) | 4.0 | 3.0 |

- Mine won / drew / lost: 0 / 0 / 3 of 3 ended games (of 3); mean margin (Mine - Opponent) -783 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 417
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: ccut-c940641-p26

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | - | - | - | - | 1.0 | +0.0 | 0.0 | 41.7 |
| AFTERMATH IN POINTS | 0.3 | +1.9 | 0.0 | 17.3 | - | - | - | - |
| ARMY TABLE | 20.3 | +281.0 | 0.0 | 44.7 | 25.0 | +157.0 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| BEST PRIZE | - | - | - | - | 0.3 | -5.3 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 1.3 | +0.0 | 55.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 4.3 | +36.3 | 91.7 | 73.3 | - | - | - | - |
| CANNON SIGHT KEPT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 3.3 | +9.3 | 0.0 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | 1.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.3 | +24.4 | 0.0 | 0.0 | 2.3 | +39.6 | 103.3 | 0.0 |
| CASTS AFTER FRIENDS | 2.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | 0.7 | +20.0 | 0.0 | 10.0 | 1.0 | +0.6 | 0.0 | 0.0 |
| CHAFF PASSED | - | - | - | - | 2.0 | -2.7 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 0.3 | +9.8 | 0.0 | 0.0 | - | - | - | - |
| CHARGE LOSSES | 15.3 | -302.8 | 0.0 | 216.0 | 11.0 | -318.4 | 0.0 | 0.0 |
| CHARGE NOW FIRST | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 11.7 | +0.0 | 0.0 | 20.0 | 12.0 | +0.0 | 0.0 | 18.3 |
| CONVEYANCE SEARCH | 2.3 | +360.0 | 0.0 | 0.0 | 1.7 | +174.4 | 0.0 | 0.0 |
| COVER ONCE | 3.3 | -147.3 | 0.0 | 151.0 | 3.7 | -100.4 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 9.7 | +22.3 | 0.0 | 28.3 | 8.3 | +76.7 | 0.0 | 41.7 |
| ELIXIR WORTH | - | - | - | - | 0.3 | +5.4 | 0.0 | 0.0 |
| ENGINEER BY LORE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 0.3 | +9.4 | 0.0 | 17.3 | 1.0 | +13.1 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 0.3 | +12.5 | 0.0 | 17.3 | 1.7 | +0.0 | 0.0 | 0.0 |
| FALLBACK BY WORTH | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FALLS SHORT | 22.7 | +298.6 | 0.0 | 48.3 | 4.0 | +124.6 | 0.0 | 0.0 |
| FEATURE BUFFS | 11.3 | +541.6 | 0.0 | 60.7 | 0.7 | +29.0 | 0.0 | 0.0 |
| FIVE ACTION | 97.7 | +7206.5 | 110.0 | 587.3 | 104.7 | +6730.5 | 293.3 | 36.7 |
| FLANK NOT WEIGHED | 6.3 | +0.0 | 0.0 | 27.3 | 3.3 | +0.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 0.3 | +17.3 | 0.0 | 17.3 | 1.7 | +62.9 | 0.0 | 0.0 |
| FREED FROM HIS FIGHT | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| GIVES UP | - | - | - | - | 0.3 | -8.6 | 0.0 | 0.0 |
| GOAL WALK | 7.7 | +828.4 | 0.0 | 0.0 | 13.7 | +1051.0 | 0.0 | 0.0 |
| GROUND FLIERS | 0.3 | +6.5 | 0.0 | 0.0 | - | - | - | - |
| GUN FIGURES | 2.0 | +4.1 | 0.0 | 0.0 | 2.0 | +38.5 | 28.3 | 0.0 |
| HARD STAY DROPPED | 4.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 9.3 | +0.0 | 0.0 | 78.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE DENIED | - | - | - | - | 1.0 | +61.3 | 0.0 | 0.0 |
| HIS CHARGE LIST | 2.7 | +0.0 | 0.0 | 0.0 | 7.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 1.7 | +0.0 | 0.0 | 78.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 9.0 | -135.8 | 0.0 | 84.0 | 4.0 | -59.4 | 0.0 | 0.0 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 37.7 | +10.0 | 245.0 | 0.0 |
| HIS MOVE WHY | 27.3 | +0.0 | 0.0 | 205.7 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 18.3 | -35.8 | 0.0 | 0.0 |
| HIS ONE QUARTER | 4.7 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 2.7 | +0.0 | 0.0 | 78.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | - | - | - | - | 25.7 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVER COMES | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 63.3 | +2127.4 | 0.0 | 156.0 | 69.3 | +3385.8 | 0.0 | 36.7 |
| HIS SHOTS BY HIS RUN | 59.3 | +1120.1 | 0.0 | 423.3 | 42.3 | +1083.8 | 0.0 | 36.7 |
| HIS TURN DENIED | - | - | - | - | 0.3 | +16.8 | 0.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 34.3 | +0.0 | 0.0 | 121.3 | 22.0 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 15.3 | +1670.0 | 0.0 | 30.3 | 14.0 | +1375.1 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | - | - | - | - | 1.7 | -63.6 | 0.0 | 0.0 |
| IDLE COST | 17.7 | -97.8 | 0.0 | 0.0 | 4.0 | -67.2 | 0.0 | 18.3 |
| KEEP FALLS | 0.3 | +1.2 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 2.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | - | - | - | - | 0.7 | +17.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 1.3 | +0.0 | 0.0 | 113.3 | 1.0 | +0.0 | 17.3 | 0.0 |
| LONE WIZARD KEPT IN | 1.3 | +116.7 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 0.3 | +0.3 | 0.0 | 17.3 | 0.3 | -0.2 | 0.0 | 0.0 |
| MANOEUVRE | 0.7 | +45.0 | 0.0 | 0.0 | 3.3 | -38.3 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.3 | +17.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH BY THE SUM | 1.0 | +265.2 | 0.0 | 0.0 | 0.3 | +15.6 | 0.0 | 0.0 |
| MARCH CHECK | 0.7 | +22.1 | 0.0 | 0.0 | 1.7 | +70.3 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +1.0 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 1.3 | -103.9 | 0.0 | 0.0 | 0.3 | +119.1 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.7 | +96.0 | 0.0 | 38.3 | 0.7 | +8.0 | 0.0 | 0.0 |
| MEETS IN TIME | 3.3 | +262.7 | 0.0 | 0.0 | 3.0 | +302.4 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 7.0 | +306.3 | 0.0 | 0.0 | 4.7 | +85.1 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 6.7 | +266.9 | 0.0 | 0.0 | 4.7 | +61.8 | 0.0 | 0.0 |
| MISSILES ON ONE TARGET | 1.7 | -166.4 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 2.3 | +0.0 | 10.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 1.3 | -151.2 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 2.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 5.3 | +665.2 | 0.0 | 52.0 | 0.3 | +11.8 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.7 | +36.7 | 0.0 | 0.0 | 0.3 | +1.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 4.0 | +263.5 | 0.0 | 0.0 | 12.0 | +557.4 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 2.3 | +346.9 | 0.0 | 17.3 | - | - | - | - |
| NO DOUBLE ROUNDS | 0.3 | -5.8 | 0.0 | 17.3 | 1.7 | -15.9 | 0.0 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 4.7 | -2029.9 | 0.0 | 113.3 | 1.7 | -44.4 | 0.0 | 0.0 |
| OGRE LOADER SECOND SHOT | 1.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 5.0 | -38.3 | 0.0 | 166.3 | 2.7 | -70.3 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 8.0 | +153.5 | 0.0 | 0.0 | 4.3 | -151.7 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 1.3 | -91.9 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | 1.3 | +2.9 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | - | - | - | - | 0.7 | +15.9 | 0.0 | 0.0 |
| OVERRUNS AWAY | - | - | - | - | 0.3 | +6.4 | 0.0 | 0.0 |
| PLAN RESULT | 44.0 | +138.9 | 18.3 | 515.0 | 45.3 | +229.8 | 223.0 | 18.3 |
| PROMISE BY ITS OWN SUM | 10.7 | -4045.8 | 0.0 | 224.0 | 3.7 | -108.5 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 1.0 | -1.6 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | 1.3 | -3.0 | 0.0 | 146.7 | - | - | - | - |
| QUARTER ODDS | 17.7 | +1381.7 | 0.0 | 293.3 | 17.7 | +2406.3 | 0.0 | 0.0 |
| RANDOM MOVE BY FIGURES | 4.0 | +68.3 | 0.0 | 0.0 | - | - | - | - |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | 0.3 | +7.1 | 0.0 | 10.0 | - | - | - | - |
| REDIRECT COUNTER | 3.3 | +61.1 | 0.0 | 48.3 | 2.0 | -64.9 | 0.0 | 0.0 |
| REDIRECT FOR A FRIEND IN REACH | 4.0 | +10.6 | 0.0 | 48.3 | 3.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 3.3 | -230.7 | 0.0 | 34.7 | - | - | - | - |
| RESERVE FALL BACK | - | - | - | - | 0.3 | +43.8 | 0.0 | 0.0 |
| RISK BY ARC | 0.3 | -5.8 | 0.0 | 17.3 | 1.0 | +0.9 | 0.0 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.7 | -13.8 | 0.0 | 0.0 |
| RUN DOWN | 0.3 | -1.3 | 0.0 | 17.3 | 1.3 | -1.0 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 0.7 | -0.1 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | 0.3 | -11.3 | 0.0 | 0.0 | - | - | - | - |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +1.7 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +2.2 | 0.0 | 0.0 |
| SET CREDITED ONCE | 1.3 | -5.6 | 0.0 | 20.0 | - | - | - | - |
| SET UP BY THE SET | 1.7 | +62.1 | 0.0 | 20.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SET-UP ANY TARGET | - | - | - | - | 0.3 | +8.4 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 6.3 | +0.0 | 0.0 | 73.3 | 6.0 | +0.0 | 0.0 | 0.0 |
| SHOOTS FROM THE BEST SPOT | 0.7 | +4.5 | 0.0 | 0.0 | 3.3 | +52.6 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -1.5 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.3 | +0.0 | 18.3 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 52.0 | +455.7 | 0.0 | 289.7 | 51.7 | +594.8 | 0.0 | 36.7 |
| SHOTS AFTER THE MOVES | 2.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 7.7 | +177.9 | 0.0 | 73.3 | 19.3 | +407.9 | 0.0 | 0.0 |
| SPELL SETS UP CHARGE | - | - | - | - | 0.3 | +8.4 | 0.0 | 0.0 |
| SPOT AS THE GAME MOVES | 11.3 | +0.0 | 0.0 | 204.7 | 6.0 | +0.0 | 0.0 | 0.0 |
| STANDS FOR A REASON | 2.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 41.0 | +0.0 | 110.0 | 164.0 | 48.7 | +0.0 | 293.3 | 0.0 |
| STAY WORTH | 18.3 | +78.6 | 110.0 | 323.3 | 22.0 | +59.8 | 236.7 | 0.0 |
| STUCK PIVOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 3.0 | +317.1 | 0.0 | 113.3 | 2.0 | +51.4 | 0.0 | 0.0 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 3.0 | +317.1 | 0.0 | 113.3 | 2.0 | +51.4 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 0.3 | +2.7 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.7 | +0.9 | 0.0 | 0.0 |
| THE DEARER SUM KEEPS ITS PLAN | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 6.7 | +0.0 | 0.0 | 131.7 | 3.7 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 44.3 | +0.0 | 0.0 | 290.0 | 50.3 | +0.0 | 0.0 | 18.3 |
| TIED UP BY THE SUM | - | - | - | - | 0.7 | +83.9 | 0.0 | 0.0 |
| TIME ON OUR SIDE | 9.0 | +154.0 | 0.0 | 30.3 | 66.3 | +503.3 | 0.0 | 0.0 |
| WAITS AGAIN | 1.0 | +0.0 | 0.0 | 30.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 56.7 | 0.0 |
| WHO FIGHTS | 0.3 | -6.5 | 0.0 | 17.3 | 0.7 | +2.4 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 1.0 | -48.7 | 0.0 | 30.3 | 1.3 | -61.9 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 6.3 | +480.9 | 0.0 | 0.0 | 2.3 | +148.9 | 0.0 | 0.0 |

### Rule changes: ccut-c940641-p26

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| SHOT RISK POINTS | 311 | 305 | 109 | 36.33 | +2399 | +22.0 |
| HIS SHOT LIST | 398 | 394 | 101 | 33.67 | +906 | +9.0 |
| HIS SHOTS BY HIS RUN | 305 | 288 | 87 | 29.00 | +1765 | +20.3 |
| HIS MOVE AS HE DECIDES | 113 | 113 | 83 | 27.67 | +0 | +0.0 |
| ARMY TABLE | 136 | 136 | 82 | 27.33 | +1110 | +13.5 |
| HOLDER ASSIGNMENT | 88 | 88 | 82 | 27.33 | +4909 | +59.9 |
| HIS MOVE WHY | 82 | 82 | 50 | 16.67 | +0 | +0.0 |
| DEPLOY BY FIGURES | 54 | 54 | 36 | 12.00 | +491 | +13.6 |
| TIME ON OUR SIDE | 226 | 206 | 32 | 10.67 | +118 | +3.7 |
| HARD STAY DROPPED | 25 | 25 | 25 | 8.33 | +0 | +0.0 |
| FIVE ACTION | 607 | 586 | 24 | 8.00 | +726 | +30.2 |
| PROMISE BY ITS OWN SUM | 43 | 43 | 22 | 7.33 | -12463 | -566.5 |
| THE TABLE AGAIN | 36 | 36 | 22 | 7.33 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 21 | 21 | 21 | 7.00 | +26 | +1.2 |
| HIS ONE MOVE | 55 | 55 | 19 | 6.33 | +0 | +0.0 |
| OFF BEST | 19 | 19 | 19 | 6.33 | -6223 | -327.5 |
| GOAL WALK | 64 | 59 | 16 | 5.33 | +778 | +48.6 |
| QUARTER ODDS | 106 | 100 | 16 | 5.33 | +1713 | +107.1 |
| MEETS IN TIME | 19 | 19 | 13 | 4.33 | +889 | +68.4 |
| MOVE ORDER | 13 | 13 | 13 | 4.33 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| WOUNDS ON THE RANKS | 26 | 26 | 10 | 3.33 | +633 | +63.3 |
| MOVE TO CHARGE COMPUTED | 17 | 14 | 9 | 3.00 | +755 | +83.8 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 9 | 3.00 | +205 | +22.8 |
| STAY WORTH | 121 | 103 | 9 | 3.00 | +40 | +4.4 |
| CAST JOB | 10 | 10 | 8 | 2.67 | +10 | +1.2 |
| CASTING BLOCK | 8 | 8 | 7 | 2.33 | +61 | +8.7 |
| CHARGE LOSSES | 79 | 75 | 7 | 2.33 | +506 | +72.2 |
| LEGAL CHARGES ONLY | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CHAFF PASSED | 6 | 6 | 6 | 2.00 | -8 | -1.3 |
| FALLS SHORT | 80 | 59 | 6 | 2.00 | +90 | +15.0 |
| SHOOTS FROM THE BEST SPOT | 12 | 12 | 6 | 2.00 | +19 | +3.2 |
| MISSILES IN THE MOVE | 35 | 21 | 5 | 1.67 | +209 | +41.8 |
| SUPPORT ADDS | 15 | 14 | 5 | 1.67 | +111 | +22.2 |
| SUPPORT WORKED OUT | 15 | 14 | 5 | 1.67 | +111 | +22.2 |
| THE RISK READS HIS RUN | 18 | 18 | 5 | 1.67 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 4 | 4 | 4 | 1.33 | +350 | +87.5 |
| MARCH BY THE SUM | 4 | 4 | 4 | 1.33 | +842 | +210.6 |
| ONE PROMISE A TARGET | 4 | 4 | 4 | 1.33 | -276 | -68.9 |
| PROMISE SHOT AWAY | 4 | 4 | 4 | 1.33 | -9 | -2.2 |
| ADVANCE LANE KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| FEATURE BUFFS | 36 | 35 | 3 | 1.00 | +67 | +22.4 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| MARCH CHECK | 7 | 7 | 3 | 1.00 | +98 | +32.6 |
| MAX FOR POSITIONING | 10 | 6 | 3 | 1.00 | +0 | +0.0 |
| MOVES UNITS SPELL | 3 | 3 | 3 | 1.00 | +114 | +38.2 |
| NEXT CHARGE BY LIST | 7 | 6 | 3 | 1.00 | +313 | +104.4 |
| OGRE LOADER SECOND SHOT | 3 | 3 | 3 | 1.00 | +1 | +0.4 |
| PROMISE KNOWS THE FIGHT | 3 | 3 | 3 | 1.00 | -5 | -1.6 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| SEARCH SPOT | 4 | 4 | 3 | 1.00 | +5 | +1.7 |
| THE ROW IN ITS ORDER | 31 | 3 | 3 | 1.00 | +0 | +0.0 |
| CANNON SIGHT KEPT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 5 | 5 | 2 | 0.67 | +26 | +13.1 |
| HIS CHARGE DENIED | 3 | 2 | 2 | 0.67 | +145 | +72.7 |
| LANE BY FIGURES | 2 | 2 | 2 | 0.67 | +53 | +26.6 |
| ONE OBJECTIVE FORMULA | 37 | 23 | 2 | 0.67 | +220 | +110.2 |
| SHOTS AFTER THE MOVES | 15 | 15 | 2 | 0.67 | +0 | +0.0 |
| SHOTS IN THE MOVE | 81 | 64 | 2 | 0.67 | +14 | +6.8 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 2 | 2 | 2 | 0.67 | +3 | +1.4 |
| TIED UP BY THE SUM | 2 | 2 | 2 | 0.67 | +145 | +72.7 |
| WHOLE FIGHT DANGER | 7 | 7 | 2 | 0.67 | +331 | +165.5 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +6 | +5.6 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -16 | -16.0 |
| CANNON PLANNED TARGET | 13 | 13 | 1 | 0.33 | +0 | +0.2 |
| CHALLENGE BY POINTS | 1 | 1 | 1 | 0.33 | +29 | +29.3 |
| CHARGE NOW FIRST | 3 | 3 | 1 | 0.33 | -2 | -1.5 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.33 | +16 | +16.1 |
| FOUR ROUNDS | 6 | 5 | 1 | 0.33 | +49 | +48.8 |
| HIS TURN DENIED | 1 | 1 | 1 | 0.33 | +17 | +16.6 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +6 | +6.3 |
| MANOEUVRE | 12 | 12 | 1 | 0.33 | +135 | +135.1 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -3 | -2.9 |
| NEARER NOT NEEDED | 48 | 44 | 1 | 0.33 | +150 | +149.8 |
| REDIRECT COUNTER | 16 | 11 | 1 | 0.33 | +3 | +2.8 |
| REDIRECT WEIGHED | 1 | 1 | 1 | 0.33 | +110 | +109.9 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +132 | +131.5 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +7 | +6.6 |
| SET UP BY THE SET | 6 | 6 | 1 | 0.33 | +10 | +9.8 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SHOT REPLANNED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SUPPORT NARROWED | 1 | 1 | 1 | 0.33 | -40 | -39.9 |
| SURE REACH TOGETHER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CANNON PLAN MISSED | 4 | 4 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 7 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 71 | 69 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 12 | not checked | - | - | - | - |
| COVER ONCE | 21 | 10 | 0 | 0.00 | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| EXACT ROUND | 4 | 4 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 6 | 5 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 29 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| GUN FIGURES | 12 | not checked | - | - | - | - |
| HE REFORMS ONCE FREED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 36 | 35 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 29 | 28 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 12 | 11 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 39 | 36 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 27 | 25 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 14 | 13 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 77 | 74 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 2 | 2 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 169 | 166 | 0 | 0.00 | - | - |
| HONEST WORTH | 5 | 4 | 0 | 0.00 | - | - |
| IDLE COST | 65 | 49 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 23 | 22 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 2 | 2 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 9 | 9 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 34 | 22 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 5 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 4 | trace | - | - | - | - |
| MOVE SPELL SPOT | 6 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 6 | 5 | 0 | 0.00 | - | - |
| NO LATE CUT | 6 | 5 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| ONE FIGHT FORMULA | 23 | 11 | 0 | 0.00 | - | - |
| ONE ROUTE | 9 | 9 | 0 | 0.00 | - | - |
| OPENS A LANE | 4 | not checked | - | - | - | - |
| OPENS UP | 2 | 2 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 1 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 268 | trace | - | - | - | - |
| REAL GROUND | 9 | 9 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 10 | 9 | 0 | 0.00 | - | - |
| RISK BY ARC | 4 | 3 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 3 | 3 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 5 | 4 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 1 | 1 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SET-UP ANY TARGET | 1 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 37 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL SETS UP CHARGE | 1 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 52 | 46 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 15 | 15 | 0 | 0.00 | - | - |
| STANDS STILL | 269 | 258 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 4 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 18 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 2 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 13 | not checked | - | - | - | - |
| THE TABLE BINDS | 284 | not checked | - | - | - | - |
| WAITS AGAIN | 4 | 2 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 3 | 3 | 0 | 0.00 | - | - |
| WHO FIGHTS | 3 | 2 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p26

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 5.67 | 1.67 | 566.5 |
| JOB FIRST | gate | 4.67 | 1.67 | 327.5 |
| ARMY TABLE | rule | - | 4.67 | 65.7 |
| HOLDER ASSIGNMENT | rule | 0.33 | 1.33 | 34.2 |
| PROMISE SHOT AWAY | rule | 1.33 | - | 2.2 |
| ONE PROMISE A TARGET | rule | 1.00 | - | 97.7 |
| CHAFF PASSED | rule | - | 0.67 | 3.7 |
| PROMISE KNOWS THE FIGHT | rule | 0.67 | - | 2.2 |
| BEST PRIZE | rule | - | 0.33 | 16.0 |
| CHARGE NOW FIRST | rule | - | 0.33 | 1.5 |
| MARCH OF THE TABLE | rule | 0.33 | - | 2.9 |
| SUPPORT NARROWED | rule | - | 0.33 | 39.9 |

### Plans: ccut-c940641-p26

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | move | 38.0 | 95% | 2845 | 0 | 0% |
| Mine | shoot | 5.7 | 65% | 149 | 139 | 93% |
| Mine | support | 0.3 | 0% | 11 | 0 | 0% |
| Opponent | charge | 1.3 | 75% | 120 | 32 | 26% |
| Opponent | move | 40.0 | 98% | 2353 | 0 | 0% |
| Opponent | shoot | 4.0 | 50% | 157 | 198 | 126% |

### Battle groups: ccut-c940641-p26

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 3.3 | 30% | 33% | 0% | - | 0% | 0% | 0% | 100% | 0% |
| Opponent | REDIRECT COUNTER | 2.0 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p26

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 2 | 0 (2) | 0 | 0 | 50 | 100% | - | - | 0 (2) | - | 0 (2) | - |
| Mine | Character | 11 | 7 (11) | 7 | 0 | 12 | 36% | 2.7 | - | 0 (5) | 15 (5) | 8 (10) | - |
| Mine | Clean-up | 2 | 226 (2) | 0 | 226 | 49 | 100% | - | 316 (1) | - | 132 (1) | 226 (2) | - |
| Mine | Fast Hammer | 10 | 0 (10) | 0 | 0 | 63 | 90% | 6.0 | 0 (6) | 0 (1) | 0 (3) | 0 (7) | 0 (3) |
| Mine | Hammer | 9 | 27 (9) | 0 | 27 | 16 | 44% | 3.2 | 0 (2) | 17 (4) | 83 (3) | 27 (9) | - |
| Mine | Holder | 2 | 60 (2) | 0 | 60 | 0 | 100% | - | 119 (1) | - | 0 (1) | - | 60 (2) |
| Mine | War machine | 4 | 0 (4) | 0 | 0 | 19 | 0% | 1.2 | 0 (4) | - | - | - | 0 (4) |
| Mine | Wizard | 4 | 0 (4) | 0 | 0 | 0 | 75% | 1.0 | 0 (2) | 0 (1) | 0 (1) | 0 (2) | 0 (2) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 8 | 15 (8) | 0 | 15 | 14 | 75% | 5.5 | 31 (3) | 0 (4) | 0 (1) | 17 (7) | 0 (1) |
| Opponent | Character | 7 | 25 (7) | 25 | 0 | 0 | 0% | 3.0 | 63 (1) | 24 (5) | 0 (1) | 20 (5) | 33 (2) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 0 | 67% | 2.0 | - | 0 (3) | - | 0 (3) | - |
| Opponent | Fast Hammer | 1 | 30 (1) | 30 | 0 | 0 | 0% | 5.0 | - | 30 (1) | - | 30 (1) | - |
| Opponent | Hammer | 10 | 74 (10) | 11 | 63 | 6 | 50% | 2.4 | 21 (5) | 134 (4) | 42 (1) | 30 (5) | 106 (5) |
| Opponent | Shooter | 4 | 121 (4) | 6 | 115 | 0 | 0% | 2.0 | 0 (1) | 154 (2) | 150 (1) | 88 (3) | 237 (1) |
| Opponent | Wizard | 2 | 0 (2) | 0 | 0 | 0 | 0% | 5.0 | - | 0 (2) | - | 0 (2) | - |

### Charged fights: ccut-c940641-p26

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 2 | 62 | 0 | 0.5 | 1.0 | 0 | 52 | -52 | 0 of 1 | 1 of 1 | - | -52 |
| Mine | Chaos Dwarfs | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 42 | 0 | 0.3 | 1.0 | 0 | 52 | -52 | 0 of 1 | 1 of 1 | - | -52 |
| Opponent | Ogre Kingdoms | 1 | 170 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 529 | 2.0 | 1.0 | 264 | 0 | +264 | 2 of 2 | 2 of 2 | - | +264 |
| Opponent | Wood Elf Realms | 1 | 82 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 0 | - | +0 |
| **Opponent** | all armies | 3 | 84 | 176 | 1.0 | 1.0 | 176 | 0 | +176 | 2 of 3 | 2 of 2 | - | +176 |

### Effective charges: ccut-c940641-p26

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 1 | 0 | 0 | 1 (net -52) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: ccut-c940641-p26

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 52 | 125 | -52 | 54 | 52 | +2 | +3.0 |
| Mine | All fights | 1 | 52 | 125 | -52 | 54 | 52 | +2 | +3.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 499 | 85 | +0 | 85 | 0 | +85 | +17.0 |
| Opponent | No odds | 2 | 346 | 312 | +264 | 278 | 78 | +200 | +57.7 |
| Opponent | All fights | 3 | 397 | 236 | +176 | 213 | 52 | +162 | +40.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p26 | move | 17 | 3 (18%) | 1 (6%) | 1 (6%) | 13 (76%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Elixir of Power | Opponent | L0319 |
| Fistful of Laurels | Opponent | L0218 |
| Ring of Doom | Mine | L0218, L0235 |

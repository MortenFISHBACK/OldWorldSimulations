# Doctrine scorecard: ccut-c940641-p31

### Scorecard: ccut-c940641-p31

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1114 | 4 | 1 | Mine | no | 2 | 2 | 1 | 0 | 0 | 0 | 0 | 165 |
| L1114 | 4 | 1 | Opponent | no | 2 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L1131 | 3 | 1 | Mine | no | 0 | - | 1 | 0 | 0 | 0 | 0 | 427 |
| L1131 | 3 | 1 | Opponent | yes | 1 | 3 | 2 | 2 | 0 | 0 | 0 | 340 |
| L1224 | 6 | 1 | Mine | no | 14 | 2 | 5 | 0 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 0 | - | 0 | 2 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 5.3 | 2.0 | 2.3 | 0.0 | 0.0 | 0.0 | 0.0 | 307.3 |
| **Average** | | | Opponent | 33% | 1.0 | 3.0 | 0.7 | 1.7 | 0.3 | 0.0 | 0.0 | 113.3 |

### KPIs: ccut-c940641-p31

Rules off - Opponent only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 62% (10 of 16) | 0% (0 of 14) | 33% (10 of 30) |
| Winner chose to follow up after the loser gave ground |  | 0% (0 of 2); on the table 50% | 100% (2 of 2); on the table 100% | 50% (2 of 4); on the table 75% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | 50% (1 of 2); on the table 50% | 33% (1 of 3); on the table 33% |
| Winner chose to pursue after the loser fled |  | - | 67% (2 of 3); on the table 67% | 67% (2 of 3); on the table 67% |
| Winner chose to follow up or pursue (all three) |  | 0% (0 of 3); on the table 33% | 71% (5 of 7); on the table 71% | 50% (5 of 10); on the table 60% |
| Magic missiles tried each own turn | 50%+ | 21% (14 of 66) | 28% (5 of 18) | 23% (19 of 84) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 39% (14 of 36) | 38% (5 of 13) | 39% (19 of 49) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 58% (7 of 12) | 58% (7 of 12) |
| Points that never fought | lower | 53% (3160 of 5998) | 44% (2621 of 5998) | 48% (5781 of 11996) |
|   infantry points that never fought | lower | 100% (730 of 730) | 52% (471 of 913) | 73% (1201 of 1643) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 52% (13 of 25) | 71% (20 of 28) | 62% (33 of 53) |
| Bound items with a magic missile used (at least once a game) |  | 86% (6 of 7); 6.3 uses a game | 100% (1 of 1); 0.3 uses a game | 88% (7 of 8); 3.3 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 17% (1 of 6); 0.3 uses a game | 17% (1 of 6); 0.2 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 33% (1 of 3); 0.3 uses a game | 0.0 uses a game | 33% (1 of 3); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 48% (2703 of 5614) | 79% (4602 of 5828) | 64% (7305 of 11442) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.7 (10%) | 0.7 (15%) | 2.3 (11%) |
| MARCHED: its unit marched | 5.0 (29%) | 2.0 (46%) | 7.0 (32%) |
| CHARGED: its unit charged | 0.7 (4%) | 0.0 (0%) | 0.7 (3%) |
| IN COMBAT: engaged in combat | 8.7 (50%) | 0.0 (0%) | 8.7 (40%) |
| FLEEING: fleeing | 1.3 (8%) | 0.0 (0%) | 1.3 (6%) |
| GONE: slain | 0.0 (0%) | 1.7 (38%) | 1.7 (8%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 2.0 | 5.0 | 1.3 | 6.3 | 1.0 | 4.0 |
| not cast | 2.0 | 7.0 | 2.7 | 21.7 | 7.0 | 32.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (4%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 4.0 (57%) | 0.0 (0%) | 2.3 (11%) | 0.3 (5%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 7.0 (32%) | 1.7 (24%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) | 0.3 (5%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.3 (5%) | 0.0 (0%) | 8.7 (40%) | 2.3 (33%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (5%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.7 (10%) | 0.0 (0%) | 1.3 (6%) | 0.7 (10%) | 1.3 (4%) |
| GONE: slain | 1.0 (50%) | 1.7 (24%) | 1.7 (62%) | 1.7 (8%) | 0.0 (0%) | 4.3 (14%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (5%) | 0.0 (0%) | 0.0 (0%) | 1.3 (19%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.0 (50%) | 0.0 (0%) | 1.0 (38%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 25.0 (78%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.3 a game | 0.7 a game |
| stood (cast and not dispelled) | - | 75% (3 of 4) | 75% (3 of 4) |
| the unit moved after it | - | 0% (0 of 3) | 0% (0 of 3) |
| it charged on its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| the enemy charged it first | - | 33% (1 of 3) | 33% (1 of 3) |
| it fought by the end of its next turn | - | 33% (1 of 3) | 33% (1 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 3) | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | - | 67% (2 of 3) | 67% (2 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 81% (46 of 57) | 40% (8 of 20) | 70% (54 of 77) |
|   cavalry | - | 55% (6 of 11) | 55% (6 of 11) |
|   character | - | 0% (0 of 6) | 0% (0 of 6) |
|   chariot | 44% (4 of 9) | - | 44% (4 of 9) |
|   infantry | 100% (12 of 12) | 67% (2 of 3) | 93% (14 of 15) |
|   war machine | 83% (30 of 36) | - | 83% (30 of 36) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.3 (36%) | 0.3 (8%) | 1.7 (22%) |
| IN COMBAT: it fought this turn or the last | 0.3 (9%) | 0.3 (8%) | 0.7 (9%) |
| MOVED: a war machine that moved | 0.7 (18%) | 0.0 (0%) | 0.7 (9%) |
| NO TARGET IN RANGE | 0.0 (0%) | 1.7 (42%) | 1.7 (22%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 1.0 (25%) | 1.0 (13%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 0.7 (17%) | 0.7 (9%) |
| SHELTERED: the target was sheltered | 1.0 (27%) | 0.0 (0%) | 1.0 (13%) |
| OTHER BAR | 0.3 (9%) | 0.0 (0%) | 0.3 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.7 | 0.7 | 82% | 6.7 pts | 25 pts |
| chariot | 1.3 | 0.7 | 50% | 21.8 pts | 29 pts |
| infantry | 9.3 | 1.7 | 89% | 5.6 pts | 52 pts |
| war machine | 11.3 | 10.0 | 59% | 21.9 pts | 248 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 1.3 | 2.2 |
| Charges that made contact a game | 2.7 | 1.0 | 1.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.14 declared, 1.00 contact (7 units) | 0.00 declared, 0.00 contact (3 units) | 0.80 declared, 0.70 contact (10 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.10 declared, 0.10 contact (10 units) | 0.20 declared, 0.15 contact (20 units) | 0.17 declared, 0.13 contact (30 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 55% (6 of 11) | 50% (1 of 2) | 50% (1 of 2) | 53% (8 of 15) |
| Character in a unit | 100% (1 of 1) | - | - | 100% (1 of 1) |
| Character on its own | 67% (4 of 6) | 50% (3 of 6) | 71% (5 of 7) | 63% (12 of 19) |
| Chariot | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Infantry | 67% (4 of 6) | 50% (1 of 2) | - | 62% (5 of 8) |
| Monster | 50% (1 of 2) | - | - | 50% (1 of 2) |
| War Machines | 83% (5 of 6) | - | - | 83% (5 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 3 | 0% (0 of 3); on the table 33% | 21% (14 of 66) | 53% | 52% (13 of 25) | 86% (6 of 7); 6.3 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| High Elf Realms | 1 | - | 17% (1 of 6) | 51% | 78% (7 of 9) | 0.0 uses a game | 17% (1 of 6); 1.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (2 of 2); on the table 100% | 33% (2 of 6) | 38% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | 60% (3 of 5); on the table 60% | 33% (2 of 6) | 42% | 58% (7 of 12) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p31, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (2) | 83% (5) | 88% (7) |
| ...free all their last turn and able to turn (per game) | 0.67 | 1.67 | 2.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.67 | 0.67 | 1.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.33 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: ccut-c940641-p31

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 4.3 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 88% (7 of 8) | 50% (2 of 4) |
| Strategy | Shoot objectives carried out (shot that target) | 29% (16 of 55) | 60% (3 of 5) |
| Strategy | Support requests answered (helper made contact too) | - | 0% (0 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 80% (4 of 5) | - |
| Strategy | Joined characters whose unit fought | 0% (0 of 3) | - |
| Strategy | Lone characters that fought | 89% (8 of 9) | 55% (6 of 11) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.0 | 1.7 |
| Movement | Points that never moved of their own | 307.3 | 113.3 |
| Movement | Fights charged into per game | 2.7 | 1.0 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 8 | 1 of 2, net +654 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 8, net +485 | 0 of 2 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 8, net -160 | 0 of 2 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 8, net +88 | 1 of 2, net +150 |
| Shooting | Shots by shooting units (incl. breath weapons) | 5.3 | 4.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 38% (6 of 16) | 33% (4 of 12) |
| Shooting | Points destroyed by shooting units | 41.0 | 0.0 |
| Shooting | War machine shots | 10.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 53% (17 of 32) | - |
| Shooting | Points destroyed by war machines | 67.0 | 0.0 |
| Magic | Magic missiles cast | 3.0 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 44% (4 of 9) | 75% (3 of 4) |
| Magic | Wounds caused by magic missiles | 4.3 | 1.7 |
| Magic | Wounds caused by other spells | 4.3 | 1.3 |
| Magic | Points destroyed by magic (all spells) | 246.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 1.7 / 1.7 / 1.0 | 0.7 / 0.0 / 1.0 / 0.0 |
| Combat | Points destroyed in combat | 503.7 | 127.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +152 | +300 |
| Combat | Net per 100 charger points, damage counted | +45.9 | +144.3 |
| Combat | First round won (charged fights) | 100% | 100% |
| Combat | Net points per charged fight | +142 | +346 |
| Combat | Net points per supported fight / lone fight | - / +142 | - / +346 |
| Combat | Charged fights on a top-3 enemy unit | 4 of 8 | 2 of 3 |
| Game | Points lost | 438.7 | 841.3 |
| Game | VP from objectives | 766.7 | 610.0 |
| Game | Lone holders (player turns) | 5.3 | 1.0 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +559 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 1280
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: ccut-c940641-p31

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +15.8 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 7.0 | +46.7 | 0.0 | 0.0 | 26.3 | -133.2 | 0.0 | 645.7 |
| ARTILLERY RE-ROLL WEIGHED | 7.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ASSAILMENT BY POINTS | 0.3 | +5.4 | 0.0 | 0.0 | 0.7 | +7.3 | 0.0 | 295.0 |
| BACKUP TARGETS | - | - | - | - | 1.0 | +6.0 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.3 | +6.0 | 77.7 | 0.0 |
| CANNON PLAN MISSED | 0.3 | +0.0 | 67.0 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 9.7 | +386.0 | 434.7 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 4.7 | +153.3 | 447.3 | 0.0 | 0.3 | +0.7 | 119.3 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 1.0 | +0.0 | 0.0 | 323.3 |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 2.7 | +223.9 | 0.0 | 60.0 |
| CHALLENGE BY POINTS | 0.3 | +4.2 | 0.0 | 0.0 | 0.7 | +22.5 | 0.0 | 50.3 |
| CHARGE LOSSES | 7.7 | -412.1 | 0.0 | 288.7 | 26.7 | -1148.5 | 0.0 | 570.3 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 439.0 | 126.3 | 0.3 | +0.0 | 50.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 5.7 | +0.0 | 0.0 | 0.0 | 10.3 | +0.0 | 0.0 | 156.7 |
| COMBAT PIVOT | 0.7 | +0.0 | 128.3 | 77.7 | - | - | - | - |
| CONVEYANCE SEARCH | - | - | - | - | 1.3 | +225.1 | 323.3 | 323.3 |
| COVER ONCE | 9.3 | -658.7 | 0.0 | 50.0 | 10.3 | -594.5 | 0.0 | 425.0 |
| DENIED BY THE FIGHT | 0.7 | -7.9 | 59.0 | 0.0 | 0.3 | -0.9 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 6.0 | +5.5 | 0.0 | 0.0 | 6.7 | +127.1 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -14.2 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 1.7 | +19.6 | 417.0 | 126.3 | 1.0 | +0.6 | 50.0 | 0.0 |
| FACES THE THREAT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.7 | +4.7 | 309.3 | 126.3 | 1.3 | +1.1 | 169.3 | 0.0 |
| FALLS SHORT | - | - | - | - | 23.7 | +221.6 | 0.0 | 915.7 |
| FIGHT TO THE END | 2.0 | +40.7 | 377.0 | 0.0 | 0.3 | +24.9 | 119.3 | 0.0 |
| FIVE ACTION | 82.3 | +6710.7 | 2989.3 | 465.0 | 83.3 | +4195.9 | 288.7 | 2047.7 |
| FLANK NOT WEIGHED | 7.0 | +0.0 | 0.0 | 169.3 | 9.3 | +0.0 | 0.0 | 304.7 |
| FOLLOW UP WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +44.2 | 0.0 | 0.0 |
| FOUR ROUNDS | 3.0 | +366.3 | 476.0 | 126.3 | 1.3 | +200.9 | 169.3 | 0.0 |
| FREED FROM HIS FIGHT | 4.3 | +0.0 | 0.0 | 0.0 | 16.3 | +0.0 | 0.0 | 611.3 |
| FRIEND SHOOTS FIRST | 2.7 | -39.2 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.7 | -23.3 | 53.7 | 0.0 | 0.3 | -0.3 | 0.0 | 0.0 |
| GOAL WALK | 1.0 | +73.0 | 0.0 | 0.0 | 11.7 | +1634.4 | 0.0 | 161.0 |
| GUN MASK | 3.7 | +208.6 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 2.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 2.3 | +0.0 | 0.0 | 0.0 | 17.3 | +0.0 | 0.0 | 272.7 |
| HIS CHARGE BY HIS RUN | 6.7 | +0.0 | 0.0 | 288.7 | 16.0 | +0.0 | 0.0 | 346.7 |
| HIS CHARGE DENIED | 0.3 | +9.1 | 0.0 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 0.7 | +0.0 | 0.0 | 0.0 | 7.3 | +0.0 | 0.0 | 383.7 |
| HIS LEGAL MOVES | 3.7 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 290.0 |
| HIS MOVE AND SHOT | 2.3 | -26.4 | 0.0 | 0.0 | 8.0 | -131.1 | 0.0 | 380.3 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 31.3 | +7.0 | 669.0 | 0.0 |
| HIS MOVE WHY | 10.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 18.7 | +43.8 | 0.0 | 41.0 |
| HIS ONE QUARTER | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 6.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 145.0 |
| HIS RANDOM MOVE | 10.0 | +0.0 | 0.0 | 338.7 | - | - | - | - |
| HIS RANDOM MOVER COMES | 0.7 | +0.0 | 0.0 | 238.7 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 11.3 | +128.5 | 0.0 | 0.0 | 66.0 | +5296.8 | 0.0 | 1929.7 |
| HIS SHOTS BY HIS RUN | 17.7 | +239.2 | 0.0 | 338.7 | 57.7 | +2423.3 | 0.0 | 1435.3 |
| HIS TURN DENIED | 0.3 | +21.0 | 59.0 | 0.0 | 0.7 | +44.3 | 0.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 12.0 | +0.0 | 0.0 | 0.0 | 12.7 | +0.0 | 0.0 | 40.0 |
| HOLDER ASSIGNMENT | 10.7 | +1091.8 | 0.0 | 0.0 | 9.3 | +992.2 | 0.0 | 20.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.7 | -129.2 | 309.3 | 126.3 | 1.0 | -51.3 | 119.3 | 0.0 |
| HUNT IN PAIRS | 0.7 | +22.0 | 0.0 | 0.0 | - | - | - | - |
| HUNT RESULT | - | - | - | - | 0.7 | +57.8 | 0.0 | 0.0 |
| HUNT THE GUNS | - | - | - | - | 0.7 | +225.5 | 0.0 | 0.0 |
| IDLE COST | - | - | - | - | 17.7 | -311.2 | 0.0 | 492.0 |
| JOINT CHARGE NOW | - | - | - | - | 0.7 | +32.7 | 0.0 | 0.0 |
| KEEP FALLS | 0.3 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 1.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.0 | +5.5 | 0.0 | 0.0 | 0.7 | +40.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.3 | +0.0 | 333.0 | 310.7 | 8.3 | +0.0 | 204.0 | 564.0 |
| LONE WIZARD KEPT IN | 0.7 | +41.6 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 2.0 | +2.2 | 377.0 | 0.0 | 0.7 | -1.9 | 169.3 | 0.0 |
| MANOEUVRE | 1.0 | +7.9 | 0.0 | 0.0 | 1.7 | -41.1 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.7 | +4.9 | 0.0 | 0.0 |
| MARCH BY THE SUM | 1.7 | +38.5 | 0.0 | 0.0 | 0.3 | +10.2 | 0.0 | 166.7 |
| MARCH CHECK | 2.7 | +110.8 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 2.3 | +49.7 | 0.0 | 0.0 | 0.7 | +5.1 | 0.0 | 0.0 |
| MARCH OVER CASTS | 3.3 | +176.3 | 0.0 | 0.0 | 2.0 | +228.1 | 0.0 | 323.3 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 5.3 | +143.7 | 0.0 | 0.0 | 2.7 | +102.0 | 0.0 | 233.3 |
| MEETS IN TIME | 3.7 | +420.3 | 0.0 | 0.0 | 3.7 | +347.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 9.7 | +257.7 | 0.0 | 0.0 | 2.3 | +16.2 | 0.0 | 156.7 |
| MISSILES NEXT TURN | 14.3 | +226.1 | 0.0 | 0.0 | 5.7 | +24.9 | 0.0 | 480.0 |
| MISSILES ON ONE TARGET | 0.7 | -27.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | - | - | - | - | 3.0 | +0.0 | 0.0 | 156.7 |
| MOVE SPELL SPOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 323.3 |
| MOVE TO CHARGE COMPUTED | 8.3 | +782.7 | 0.0 | 50.0 | 6.7 | +683.1 | 0.0 | 95.3 |
| NEARER NOT NEEDED | 5.3 | +227.7 | 0.0 | 119.3 | 5.7 | +196.4 | 0.0 | 73.7 |
| NEXT CHARGE BY LIST | 6.0 | +579.7 | 16.7 | 0.0 | 3.3 | +391.5 | 0.0 | 95.3 |
| NO DOUBLE ROUNDS | 2.3 | -153.2 | 402.3 | 0.0 | 1.3 | -27.3 | 169.3 | 0.0 |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT WORTH A CAST | 1.0 | -0.3 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 7.3 | -356.9 | 0.0 | 0.0 | 4.7 | -476.1 | 0.0 | 20.0 |
| OGRE LOADER SECOND SHOT | 10.0 | +142.5 | 0.0 | 0.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 6.3 | -146.0 | 0.0 | 50.0 | 6.0 | -150.0 | 0.0 | 349.3 |
| ONE OBJECTIVE FORMULA | 4.0 | +32.9 | 0.0 | 0.0 | 3.7 | -57.1 | 0.0 | 20.0 |
| ONE PROMISE A TARGET | 1.3 | -113.1 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | 0.3 | +11.8 | 20.0 | 126.3 | - | - | - | - |
| OVERRUNS AWAY | 0.7 | +27.9 | 79.0 | 126.3 | 0.3 | +1.5 | 50.0 | 0.0 |
| OWN CAST FIRST | 0.3 | -6.9 | 0.0 | 0.0 | - | - | - | - |
| PATHS CROSS | - | - | - | - | 0.3 | -11.1 | 0.0 | 0.0 |
| PLAN RESULT | 36.3 | +1382.2 | 757.0 | 669.0 | 41.0 | +241.9 | 67.0 | 1587.0 |
| PROMISE BELOW ZERO | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 12.7 | -381.8 | 0.0 | 50.0 | 10.0 | -382.3 | 0.0 | 47.7 |
| PROMISE IN STEPS | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 1.0 | -15.2 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 95.3 |
| PROMISE READS THE TABLE | 1.3 | -5.6 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | 1.3 | -5.1 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 15.0 | +1668.6 | 508.0 | 0.0 | 14.3 | +1417.6 | 119.3 | 0.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.0 | +44.1 | 0.0 | 0.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT COUNTER | - | - | - | - | 2.0 | +159.3 | 0.0 | 80.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 0.7 | +0.0 | 0.0 | 40.0 |
| REFORMS TO MEET IT | 3.7 | -130.5 | 0.0 | 0.0 | 0.3 | -7.4 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RISK BY ARC | 3.0 | +89.4 | 476.0 | 126.3 | 1.3 | -89.9 | 169.3 | 0.0 |
| RISK ON THE WAY | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| RUN DOWN | 1.3 | -23.9 | 225.7 | 0.0 | 1.3 | -10.1 | 169.3 | 0.0 |
| SAME CHARGE LATER | 0.3 | -2.0 | 0.0 | 0.0 | - | - | - | - |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.0 | +86.3 | 0.0 | 40.0 |
| SEARCH SPOT | 0.3 | +2.9 | 0.0 | 119.3 | 1.0 | +7.1 | 0.0 | 0.0 |
| SECOND HUNTER | - | - | - | - | 0.3 | -13.4 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +6.2 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 1.3 | -56.6 | 0.0 | 0.0 | 0.3 | -8.1 | 0.0 | 0.0 |
| SET UP BY THE SET | 2.3 | +68.1 | 0.0 | 0.0 | 2.7 | +30.5 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 0.7 | -4.7 | 0.0 | 40.0 |
| SHOOTERS ON THE TABLE | 18.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 79.0 |
| SHOOTS FROM THE BEST SPOT | 6.3 | +175.9 | 608.0 | 0.0 | 0.7 | +86.5 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.7 | -27.4 | 210.3 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.3 | +0.0 | 67.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 8.3 | -84.1 | 0.0 | 288.7 | 48.3 | +1437.2 | 0.0 | 1183.0 |
| SHOTS AFTER THE MOVES | 5.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.7 | +1051.7 | 0.0 | 0.0 | 3.0 | +55.0 | 0.0 | 100.0 |
| SPELL WORTH | 1.0 | +10.9 | 0.0 | 0.0 | 1.0 | +19.5 | 313.3 | 313.3 |
| SPELLS IN THE FIGHT | 0.3 | +4.5 | 166.7 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 2.7 | +0.0 | 0.0 | 119.3 | 8.7 | +0.0 | 0.0 | 565.3 |
| STAND AND SHOOT | - | - | - | - | 0.3 | -2.6 | 50.0 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 4.0 | +0.0 | 0.0 | 156.7 |
| STANDS STILL | 46.7 | +0.0 | 2513.3 | 0.0 | 21.7 | +0.0 | 119.3 | 290.0 |
| STAY WORTH | 33.0 | -230.6 | 1216.7 | 0.0 | 3.7 | -62.0 | 119.3 | 0.0 |
| STOPS | - | - | - | - | 0.7 | +59.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 2.7 | +263.1 | 0.0 | 0.0 | 3.7 | +200.0 | 0.0 | 117.7 |
| SUPPORT NARROWED | 0.3 | +0.0 | 16.7 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 2.7 | +263.1 | 0.0 | 0.0 | 3.7 | +200.0 | 0.0 | 117.7 |
| SURE REACH TOGETHER | - | - | - | - | 1.0 | +4.9 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | 0.3 | -13.0 | 0.0 | 119.3 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 0.3 | +0.0 | 0.0 | 119.3 | 3.0 | +0.0 | 0.0 | 70.3 |
| THE ROW KEEPS ITS WAY | 2.0 | +0.0 | 0.0 | 119.3 | 3.0 | +0.0 | 0.0 | 90.3 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 1.7 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 2.0 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 90.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 37.7 | +0.0 | 0.0 | 169.3 | 40.7 | +0.0 | 0.0 | 1010.3 |
| TIED UP BY THE SUM | 1.3 | +163.0 | 99.0 | 126.3 | 1.0 | +39.4 | 50.0 | 0.0 |
| TIME ON OUR SIDE | 29.3 | +499.7 | 0.0 | 169.3 | - | - | - | - |
| WAITS AGAIN | 3.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 0.7 | +0.0 | 82.0 | 0.0 | - | - | - | - |
| WHO HITS BACK | 0.3 | +86.0 | 0.0 | 0.0 | 0.7 | +108.1 | 0.0 | 128.3 |
| WHOLE FIGHT DANGER | 1.0 | -303.9 | 0.0 | 238.7 | 2.7 | -142.5 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 3.0 | +19.6 | 0.0 | 238.7 | - | - | - | - |

### Rule changes: ccut-c940641-p31

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 94 | 94 | 73 | 24.33 | +0 | +0.0 |
| ARMY TABLE | 100 | 100 | 65 | 21.67 | +782 | +12.0 |
| HOLDER ASSIGNMENT | 60 | 60 | 54 | 18.00 | +3164 | +58.6 |
| HIS SHOT LIST | 232 | 222 | 48 | 16.00 | +2099 | +43.7 |
| FIVE ACTION | 497 | 477 | 46 | 15.33 | +3426 | +74.5 |
| HIS SHOTS BY HIS RUN | 226 | 216 | 39 | 13.00 | +662 | +17.0 |
| LEGAL CHARGES ONLY | 38 | 38 | 38 | 12.67 | +0 | +0.0 |
| OFF BEST | 36 | 36 | 36 | 12.00 | -2499 | -69.4 |
| OGRE LOADER SECOND SHOT | 30 | 30 | 30 | 10.00 | +428 | +14.3 |
| SHOT RISK POINTS | 170 | 160 | 30 | 10.00 | +1850 | +61.7 |
| MOVE TO CHARGE COMPUTED | 45 | 42 | 29 | 9.67 | +1277 | +44.0 |
| PROMISE BY ITS OWN SUM | 68 | 68 | 29 | 9.67 | -2292 | -79.0 |
| THE TABLE AGAIN | 36 | 36 | 24 | 8.00 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 21 | 21 | 21 | 7.00 | +0 | +0.0 |
| DEPLOY BY FIGURES | 38 | 38 | 18 | 6.00 | +443 | +24.6 |
| HIS MOVE WHY | 30 | 30 | 18 | 6.00 | +0 | +0.0 |
| HIS ONE MOVE | 56 | 56 | 18 | 6.00 | +0 | +0.0 |
| QUARTER ODDS | 88 | 87 | 17 | 5.67 | +517 | +30.4 |
| NEXT CHARGE BY LIST | 28 | 26 | 15 | 5.00 | +812 | +54.1 |
| CAST JOB | 15 | 15 | 13 | 4.33 | +44 | +3.4 |
| CHARGE LOSSES | 103 | 100 | 13 | 4.33 | +1209 | +93.0 |
| MEETS IN TIME | 22 | 22 | 12 | 4.00 | +535 | +44.6 |
| COVER ONCE | 59 | 41 | 10 | 3.33 | +462 | +46.2 |
| HARD STAY DROPPED | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| TIME ON OUR SIDE | 88 | 68 | 10 | 3.33 | +138 | +13.8 |
| MARCH OF THE TABLE | 9 | 9 | 9 | 3.00 | -164 | -18.2 |
| MOVE ORDER | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 21 | 21 | 9 | 3.00 | +131 | +14.6 |
| THE RISK READS HIS RUN | 18 | 18 | 9 | 3.00 | +0 | +0.0 |
| GOAL WALK | 38 | 38 | 8 | 2.67 | +1764 | +220.6 |
| FOUR ROUNDS | 13 | 12 | 7 | 2.33 | +712 | +101.7 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 7 | 2.33 | +132 | +18.9 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| MARCH BY THE SUM | 6 | 6 | 6 | 2.00 | +146 | +24.3 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| FALLS SHORT | 71 | 61 | 5 | 1.67 | +25 | +5.0 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +137 | +27.3 |
| MARCH CHECK | 8 | 7 | 5 | 1.67 | +83 | +16.6 |
| SET UP BY THE SET | 15 | 15 | 5 | 1.67 | +184 | +36.9 |
| TIED UP BY THE SUM | 7 | 7 | 5 | 1.67 | +270 | +54.0 |
| CANNON PLANNED TARGET | 29 | 29 | 4 | 1.33 | -87 | -21.8 |
| IDLE COST | 53 | 37 | 4 | 1.33 | +25 | +6.2 |
| ONE PROMISE A TARGET | 4 | 4 | 4 | 1.33 | -339 | -84.8 |
| PROMISE SHOT AWAY | 4 | 4 | 4 | 1.33 | -15 | -3.8 |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 4 | 1.33 | +0 | +0.0 |
| SUPPORT ADDS | 19 | 17 | 4 | 1.33 | +300 | +74.9 |
| SUPPORT WORKED OUT | 19 | 17 | 4 | 1.33 | +300 | +74.9 |
| ASSAILMENT BY POINTS | 3 | 3 | 3 | 1.00 | +38 | +12.7 |
| CHAFF IN THE MOVE | 8 | 8 | 3 | 1.00 | +94 | +31.3 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +80 | +26.7 |
| MANOEUVRE | 8 | 8 | 3 | 1.00 | +40 | +13.5 |
| MAX FOR POSITIONING | 24 | 22 | 3 | 1.00 | +19 | +6.4 |
| MISSILES IN THE MOVE | 36 | 26 | 3 | 1.00 | +98 | +32.8 |
| PROMISE KNOWS THE FIGHT | 14 | 12 | 3 | 1.00 | -46 | -15.2 |
| SEARCH SPOT | 4 | 4 | 3 | 1.00 | +30 | +10.0 |
| SHOTS AFTER THE MOVES | 19 | 19 | 3 | 1.00 | +0 | +0.0 |
| WHO HITS BACK | 3 | 3 | 3 | 1.00 | +350 | +116.6 |
| WOUNDS ON THE RANKS | 9 | 9 | 3 | 1.00 | +6 | +2.0 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FOLLOW UP WEIGHED | 2 | 2 | 2 | 0.67 | +132 | +66.2 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +98 | +49.0 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +125 | +62.4 |
| ONE OBJECTIVE FORMULA | 23 | 16 | 2 | 0.67 | +81 | +40.4 |
| REDIRECT FOR A FRIEND IN REACH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| STAY WORTH | 110 | 97 | 2 | 0.67 | +5 | +2.3 |
| SUPPORT NARROWED | 3 | 3 | 2 | 0.67 | -29 | -14.5 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +47 | +47.2 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -14 | -14.2 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 8 | 8 | 1 | 0.33 | -64 | -64.0 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 12 | 11 | 1 | 0.33 | +8 | +8.4 |
| FIGHT TO THE END | 7 | 6 | 1 | 0.33 | +59 | +58.6 |
| HIS MOVE AND SHOT | 31 | 31 | 1 | 0.33 | +2 | +2.2 |
| KEEP FALLS | 1 | 1 | 1 | 0.33 | +3 | +3.3 |
| NEARER NOT NEEDED | 33 | 30 | 1 | 0.33 | +23 | +23.3 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +25 | +24.8 |
| OVERRUNS AWAY | 3 | 3 | 1 | 0.33 | +25 | +24.8 |
| OWN CAST FIRST | 1 | 1 | 1 | 0.33 | -21 | -20.9 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | -33 | -33.4 |
| REDIRECT COUNTER | 6 | 5 | 1 | 0.33 | +0 | +0.0 |
| RISK BY ARC | 13 | 12 | 1 | 0.33 | +8 | +8.4 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +18 | +18.5 |
| SHOT REPLANNED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 59 | 37 | 1 | 0.33 | +4 | +3.8 |
| SURE REACH TOGETHER | 3 | 3 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | -39 | -39.0 |
| BACKUP TARGETS | 3 | 3 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 48 | 48 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 4 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | not checked | - | - | - | - |
| EXACT ROUND | 8 | 8 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 49 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 62 | 56 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 8 | 8 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 2 | 0 | 0.00 | - | - |
| GUN MASK | 11 | 11 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 59 | 50 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 68 | 66 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 24 | 22 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 26 | 26 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 7 | 7 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 27 | 26 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 30 | 29 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 2 | 2 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 3 | 3 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 74 | 74 | 0 | 0.00 | - | - |
| HONEST WORTH | 11 | 10 | 0 | 0.00 | - | - |
| HUNT IN PAIRS | 2 | not checked | - | - | - | - |
| HUNT RESULT | 2 | trace | - | - | - | - |
| HUNT THE GUNS | 2 | trace | - | - | - | - |
| KEPT FROM ITS LAST STOP | 10 | 10 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 8 | 7 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 16 | 16 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 60 | 40 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 2 | not checked | - | - | - | - |
| MOVE SPELL SPOT | 3 | not checked | - | - | - | - |
| NO DOUBLE ROUNDS | 11 | 10 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 3 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 37 | 25 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 232 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE IN STEPS | 5 | 5 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 4 | 4 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 12 | 11 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 3 | 3 | 0 | 0.00 | - | - |
| RUN DOWN | 8 | 8 | 0 | 0.00 | - | - |
| SAME CHARGE LATER | 1 | 1 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 5 | 5 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 65 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 6 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 34 | 28 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 12 | 11 | 0 | 0.00 | - | - |
| STANDS STILL | 205 | 195 | 0 | 0.00 | - | - |
| STOPS | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE ROW IN ITS ORDER | 10 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 15 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 5 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 13 | not checked | - | - | - | - |
| THE TABLE BINDS | 235 | not checked | - | - | - | - |
| WAITS AGAIN | 12 | 11 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 11 | 10 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p31

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 7.00 | 4.00 | 66.5 |
| PROMISE BY ITS OWN SUM | rule | 5.00 | 4.67 | 79.0 |
| ARMY TABLE | rule | 2.33 | 2.33 | 76.0 |
| MARCH OF THE TABLE | rule | 2.00 | 0.33 | 23.4 |
| ONE PROMISE A TARGET | rule | 1.33 | - | 84.8 |
| PROMISE SHOT AWAY | rule | 1.33 | - | 3.8 |
| HOLDER ASSIGNMENT | rule | 0.67 | 0.33 | 32.8 |
| PROMISE KNOWS THE FIGHT | rule | 1.00 | - | 15.2 |
| SUPPORT NARROWED | rule | 0.33 | 0.33 | 14.5 |
| AFTERMATH BAND | gate | - | 0.33 | 3.7 |
| BEST PRIZE | rule | - | 0.33 | 14.2 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 156.9 |
| CHARGE NOW FIRST | rule | 0.33 | - | 64.0 |
| JOINT CHARGE NOW | rule | - | 0.33 | 61.9 |
| NO REASON | gate | 0.33 | - | 243.6 |
| OWN CAST FIRST | rule | 0.33 | - | 20.9 |
| PATHS CROSS | rule | - | 0.33 | 33.4 |
| RULE SWITCHED OFF | gate | - | 0.33 | 55.7 |
| SWIFTSTRIDE BY POINTS | rule | 0.33 | - | 39.0 |

### Plans: ccut-c940641-p31

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.0 | 78% | 395 | 544 | 138% |
| Mine | move | 18.3 | 98% | 1328 | 0 | 0% |
| Mine | shoot | 15.0 | 47% | 1121 | 838 | 75% |
| Opponent | charge | 1.3 | 100% | 434 | 224 | 52% |
| Opponent | join | 1.0 | 100% | 35 | 0 | 0% |
| Opponent | move | 36.0 | 93% | 1614 | 0 | 0% |
| Opponent | shoot | 1.7 | 20% | 45 | 18 | 39% |
| Opponent | support | 1.0 | 67% | 100 | 0 | 0% |

### Packages: hunt the guns, ccut-c940641-p31

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Opponent | 0.7 | 2 | 0 | 0% | 0% | 100% | - | 338 | 87 | 0% | 67 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 2.0 | 2 | 0 | 0% | 0% | 100% | - | 338 | 87 | 0% | 201 |

### Battle groups: ccut-c940641-p31

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 2.0 | 67% | 50% | 0% | - | 100% | 0% | 0% | 0% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p31

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 9 | 101 (9) | 101 | 0 | 30 | 11% | 3.2 | 87 (2) | 116 (6) | - | 105 (5) | 118 (3) |
| Mine | Clean-up | 2 | 74 (2) | 0 | 74 | 0 | 0% | 3.0 | 0 (1) | 139 (1) | - | 74 (2) | - |
| Mine | Fast Hammer | 4 | 42 (4) | 12 | 30 | 50 | 25% | 3.0 | 41 (2) | 42 (2) | - | 64 (3) | 0 (1) |
| Mine | Holder | 1 | 158 (1) | 0 | 158 | 0 | 0% | 1.0 | 158 (1) | - | - | 158 (1) | - |
| Mine | Shooter | 4 | 67 (4) | 0 | 67 | 0 | 25% | 2.3 | 68 (3) | 62 (1) | - | 74 (3) | 54 (1) |
| Mine | War machine | 6 | 20 (6) | 20 | 0 | 0 | 0% | 1.0 | 61 (2) | 0 (2) | 0 (2) | 0 (1) | 24 (5) |
| Mine | Wizard | 3 | 0 (3) | 0 | 0 | 33 | 33% | 2.0 | 0 (2) | 0 (1) | - | 0 (3) | - |
| Opponent | Chaff | 2 | 150 (2) | 0 | 150 | 100 | 0% | 4.5 | - | 300 (1) | 0 (1) | 150 (2) | - |
| Opponent | Character | 10 | 14 (10) | 14 | 0 | 53 | 30% | 3.3 | 15 (3) | 19 (5) | 0 (2) | 11 (5) | 19 (5) |
| Opponent | Fast Hammer | 9 | 31 (9) | 0 | 31 | 60 | 33% | 2.5 | 40 (2) | 29 (7) | - | 27 (5) | 37 (4) |
| Opponent | Hammer | 3 | 143 (3) | 143 | 0 | 0 | 33% | 3.0 | 229 (2) | 0 (1) | - | 229 (2) | 0 (1) |
| Opponent | Holder | 5 | 77 (5) | 45 | 32 | 0 | 80% | 5.0 | 34 (3) | 0 (1) | 229 (1) | 107 (2) | 44 (3) |
| Opponent | Shooter | 1 | 0 (1) | 0 | 0 | 100 | 0% | 1.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 3.0 | - | - | 0 (1) | - | 0 (1) |

### Charged fights: ccut-c940641-p31

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 3 | 354 | 504 | 2.7 | 1.0 | 189 | 47 | +142 | 4 of 8 | 8 of 8 | - | +142 |
| Opponent | High Elf Realms | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Vampire Counts | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Warriors of Chaos | 1 | 0 | 1037 | 3.0 | 1.0 | 346 | 0 | +346 | 2 of 3 | 3 of 3 | - | +346 |
| **Opponent** | all armies | 3 | 0 | 346 | 1.0 | 1.0 | 346 | 0 | +346 | 2 of 3 | 3 of 3 | - | +346 |

### Effective charges: ccut-c940641-p31

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 8 | 0 | 0 | 2 (net +485) | 2 (net +152) | 2 (net -160) | 2 (net +88) | 0 | 25% (2 of 8) |
| Opponent | Warriors of Chaos | 3 | 1 (net +654) | 0 | 0 | 0 | 0 | 1 (net +150) | 1 | 0% (0 of 2) |

### Charged fights, damage counted: ccut-c940641-p31

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 2 | 374 | 485 | +485 | 534 | 65 | +470 | +125.6 |
| Mine | 76-89% | 2 | 225 | 152 | +152 | 152 | 35 | +117 | +51.8 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 369 | 189 | +88 | 193 | 0 | +193 | +52.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 356 | 60 | -160 | 114 | 285 | -171 | -47.8 |
| Mine | All fights | 8 | 331 | 222 | +142 | 248 | 96 | +152 | +45.9 |
| Opponent | Long shot (under 50%) | 1 | 392 | 358 | +654 | 654 | 85 | +569 | +145.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 116 | 150 | +150 | 232 | 0 | +232 | +200.4 |
| Opponent | No odds | 1 | 116 | 233 | +233 | 233 | 134 | +99 | +85.3 |
| Opponent | All fights | 3 | 208 | 247 | +346 | 373 | 73 | +300 | +144.3 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p31 | move | 25 | 2 (8%) | 0 (0%) | 1 (4%) | 22 (88%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1224 |
| Clockwork Compass | Mine | L1224 |
| Elixir of Power | Mine | L1114, L1131 |
| Invocation of Nehek | Opponent | L1224 |
| Opal Amulet | Opponent | L1114 |
| Ring of Doom | Mine | L1114, L1131, L1224 |
| Ring of Doom | Opponent | L1131 |
| Ring of Jet | Mine | L1114, L1131, L1224 |

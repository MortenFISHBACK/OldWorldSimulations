# Doctrine scorecard: ccut-c940641-p32

### Scorecard: ccut-c940641-p32

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1319 | 5 | 1 | Mine | yes | - | - | 0 | 1 | 0 | 0 | 0 | 291 |
| L1319 | 5 | 1 | Opponent | yes | - | 2 | 3 | 6 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 10 | 2 | 2 | 0 | 0 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 5 | 2 | 5 | 1 | 0 | 0 | 0 | 236 |
| L1431 | 3 | 1 | Mine | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Opponent | yes | 4 | - | 1 | 1 | 0 | 0 | 0 | 286 |
| **Average** | | | Mine | 33% | 5.0 | 2.0 | 2.0 | 0.7 | 0.0 | 0.0 | 0.0 | 143.7 |
| **Average** | | | Opponent | 67% | 4.5 | 2.0 | 3.0 | 2.7 | 0.0 | 0.0 | 0.0 | 174.0 |

### KPIs: ccut-c940641-p32

Rules off - Opponent only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 13) | 0% (0 of 12) | 0% (0 of 25) |
| Winner chose to follow up after the loser gave ground |  | 100% (2 of 2); on the table 100% | 100% (2 of 2); on the table 100% | 100% (4 of 4); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 0% (0 of 1); on the table 0% | 25% (1 of 4); on the table 25% | 20% (1 of 5); on the table 20% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 2); on the table 0% | 25% (1 of 4); on the table 25% | 17% (1 of 6); on the table 17% |
| Winner chose to follow up or pursue (all three) |  | 40% (2 of 5); on the table 40% | 40% (4 of 10); on the table 40% | 40% (6 of 15); on the table 40% |
| Magic missiles tried each own turn | 50%+ | 22% (4 of 18) | 62% (15 of 24) | 45% (19 of 42) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 29% (4 of 14) | 75% (15 of 20) | 56% (19 of 34) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 50% (6 of 12) | 50% (6 of 12) |
| Points that never fought | lower | 38% (2290 of 6000) | 42% (2494 of 6000) | 40% (4784 of 12000) |
|   infantry points that never fought | lower | 43% (569 of 1315) | 22% (200 of 921) | 34% (769 of 2236) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 64% (16 of 25) | 66% (21 of 32) | 65% (37 of 57) |
| Bound items with a magic missile used (at least once a game) |  | 100% (2 of 2); 3.3 uses a game | 50% (1 of 2); 0.7 uses a game | 75% (3 of 4); 2.0 uses a game |
| Bound items with another spell used |  | 30% (3 of 10); 1.7 uses a game | 0.0 uses a game | 30% (3 of 10); 0.8 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 59% (3364 of 5720) | 62% (3623 of 5830) | 60% (6987 of 11550) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.0 (43%) | 1.0 (33%) | 3.0 (39%) |
| MARCHED: its unit marched | 1.0 (21%) | 0.7 (22%) | 1.7 (22%) |
| CHARGED: its unit charged | 0.3 (7%) | 0.0 (0%) | 0.3 (4%) |
| IN COMBAT: engaged in combat | 0.7 (14%) | 0.3 (11%) | 1.0 (13%) |
| GONE: slain | 0.7 (14%) | 1.0 (33%) | 1.7 (22%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 5.0 | 2.0 | 2.3 | 6.3 | 0.3 | 2.3 |
| not cast | 3.0 | 2.0 | 3.7 | 7.7 | 1.7 | 21.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.3 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 2.0 (100%) | 0.0 (0%) | 3.0 (39%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (22%) | 0.3 (20%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (13%) | 0.3 (20%) | 0.0 (0%) |
| GONE: slain | 0.7 (22%) | 0.0 (0%) | 0.7 (18%) | 1.7 (22%) | 0.0 (0%) | 1.3 (6%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (60%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (78%) | 0.0 (0%) | 3.0 (82%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 19.0 (88%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 2.0 a game | 0.3 a game | 1.2 a game |
| stood (cast and not dispelled) | 50% (3 of 6) | - | 50% (3 of 6) |
| the unit moved after it | 33% (1 of 3) | - | 33% (1 of 3) |
| it charged on its next turn | 0% (0 of 3) | - | 0% (0 of 3) |
| the enemy charged it first | 33% (1 of 3) | - | 33% (1 of 3) |
| it fought by the end of its next turn | 33% (1 of 3) | - | 33% (1 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | 0% (0 of 3) | - | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | 67% (2 of 3) | - | 67% (2 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 73% (63 of 86) | 76% (22 of 29) | 74% (85 of 115) |
|   cavalry | 83% (10 of 12) | 88% (15 of 17) | 86% (25 of 29) |
|   character | 39% (9 of 23) | 0% (0 of 4) | 33% (9 of 27) |
|   infantry | 74% (20 of 27) | 88% (7 of 8) | 77% (27 of 35) |
|   war machine | 100% (24 of 24) | - | 100% (24 of 24) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (26%) | 1.0 (43%) | 3.0 (30%) |
| CHARGED: it charged | 2.0 (26%) | 0.3 (14%) | 2.3 (23%) |
| IN COMBAT: it fought this turn or the last | 0.7 (9%) | 0.0 (0%) | 0.7 (7%) |
| NO TARGET IN RANGE | 2.0 (26%) | 1.0 (43%) | 3.0 (30%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (4%) | 0.0 (0%) | 0.3 (3%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.7 (9%) | 0.0 (0%) | 0.7 (7%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 13.7 | 2.7 | 85% | 7.1 pts | 97 pts |
| character | 5.0 | 1.0 | 87% | 10.4 pts | 52 pts |
| infantry | 16.0 | 4.3 | 79% | 6.0 pts | 96 pts |
| war machine | 8.0 | 1.3 | 83% | 2.0 pts | 16 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.0 | 5.0 | 4.0 |
| Charges that made contact a game | 2.7 | 4.0 | 3.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.67 contact (3 units) | 0.00 declared, 0.00 contact (1 units) | 0.75 declared, 0.50 contact (4 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | - | - |
|   per unit a game, the other units (no war machines, no joined characters) | 0.27 declared, 0.27 contact (22 units) | 0.65 declared, 0.52 contact (23 units) | 0.47 declared, 0.40 contact (45 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 53% (8 of 15) | 100% (2 of 2) | - | 59% (10 of 17) |
| Character in a unit | 100% (4 of 4) | 50% (1 of 2) | 100% (1 of 1) | 86% (6 of 7) |
| Character on its own | 67% (2 of 3) | 50% (2 of 4) | 33% (2 of 6) | 46% (6 of 13) |
| Infantry | 83% (10 of 12) | 50% (1 of 2) | - | 79% (11 of 14) |
| Monster | 50% (1 of 2) | - | - | 50% (1 of 2) |
| Monstrous | 50% (1 of 2) | 100% (2 of 2) | - | 75% (3 of 4) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 3 | 40% (2 of 5); on the table 40% | 22% (4 of 18) | 38% | 64% (16 of 25) | 100% (2 of 2); 3.3 uses a game | 30% (3 of 10); 1.7 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | - | 100% (12 of 12) | 82% | 88% (7 of 8) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Warriors of Chaos | 1 | 50% (1 of 2); on the table 50% | 17% (1 of 6) | 8% | 67% (8 of 12) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 38% (3 of 8); on the table 38% | 33% (2 of 6) | 34% | 50% (6 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p32, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 57% (4) | 40% (2) | 50% (6) |
| ...free all their last turn and able to turn (per game) | 0.67 | 0.67 | 1.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.00 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.33 | 0.67 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: ccut-c940641-p32

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 4.0 | 3.0 |
| Strategy | Charge objectives carried out (made contact) | 86% (6 of 7) | 50% (6 of 12) |
| Strategy | Shoot objectives carried out (shot that target) | 64% (21 of 33) | 22% (4 of 18) |
| Strategy | Support requests answered (helper made contact too) | - | 50% (1 of 2) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | - | 0% (0 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 100% (4 of 4) |
| Strategy | Joined characters whose unit fought | - | 29% (2 of 7) |
| Strategy | Lone characters that fought | 75% (6 of 8) | 100% (5 of 5) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 0.7 | 2.7 |
| Movement | Points that never moved of their own | 143.7 | 174.0 |
| Movement | Fights charged into per game | 2.7 | 3.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 6 | 1 of 9, net +498 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 6, net +0 | 1 of 9, net +320 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 6, net +144 | 0 of 9 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 of 6, net +38 | 6 of 9, net +148 |
| Shooting | Shots by shooting units (incl. breath weapons) | 14.0 | 8.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 40% (17 of 42) | 79% (19 of 24) |
| Shooting | Points destroyed by shooting units | 18.3 | 0.0 |
| Shooting | War machine shots | 8.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 54% (13 of 24) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | 1.3 | 3.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 25% (1 of 4) | 9% (1 of 11) |
| Magic | Wounds caused by magic missiles | 3.0 | 1.7 |
| Magic | Wounds caused by other spells | 5.0 | - |
| Magic | Points destroyed by magic (all spells) | 40.0 | 50.3 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.0 / 0.0 / 2.0 / 0.0 | 1.3 / 1.3 / 0.0 / 0.0 |
| Combat | Points destroyed in combat | 226.3 | 507.7 |
| Combat | Points run down | 0.0 | 59.0 |
| Combat | Net points per charged fight, damage counted | +71 | +150 |
| Combat | Net per 100 charger points, damage counted | +18.7 | +66.2 |
| Combat | First round won (charged fights) | 88% | 82% |
| Combat | Net points per charged fight | +89 | +172 |
| Combat | Net points per supported fight / lone fight | - / +89 | +0 / +190 |
| Combat | Charged fights on a top-3 enemy unit | 1 of 8 | 5 of 11 |
| Game | Points lost | 716.3 | 332.7 |
| Game | VP from objectives | 743.3 | 513.3 |
| Game | Lone holders (player turns) | 5.0 | 4.5 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) -194 VP
- The side that went first won 0 of 3 games with a winner
- Points traded per game (both sides' losses): 1049
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: ccut-c940641-p32

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | 0.3 | +11.6 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 31.0 | +372.6 | 0.0 | 996.7 | 20.3 | +55.1 | 0.0 | 233.0 |
| ASSAILMENT BY POINTS | 0.7 | +5.9 | 0.0 | 133.3 | - | - | - | - |
| BOUND ASSAILMENT | 0.3 | +0.0 | 0.0 | 50.3 | - | - | - | - |
| CANNON PLAN MISSED | 0.7 | +0.0 | 18.3 | 0.0 | - | - | - | - |
| CANNON PLANNED TARGET | 8.0 | +47.7 | 55.0 | 0.0 | - | - | - | - |
| CASTING BLOCK | - | - | - | - | 3.0 | +37.3 | 115.7 | 0.0 |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 133.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF PASSED | 0.3 | -1.2 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 1.3 | +39.6 | 0.0 | 109.3 | 1.0 | +13.1 | 0.0 | 113.0 |
| CHAMPION KNOWS CHALLENGE | 0.3 | -1.6 | 0.0 | 0.0 | 0.7 | -4.7 | 54.0 | 0.0 |
| CHARGE LOSSES | 19.0 | -658.9 | 0.0 | 983.0 | 17.0 | -1129.5 | 0.0 | 391.7 |
| CHARGE NOW FIRST | 2.0 | +0.0 | 122.7 | 99.0 | 2.0 | +0.0 | 424.7 | 0.0 |
| CHARGER SLAIN LOST | - | - | - | - | 0.3 | -3.3 | 54.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 5.3 | +0.0 | 0.0 | 115.7 | 4.7 | +0.0 | 0.0 | 0.0 |
| COMBAT PIVOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 1.7 | +228.8 | 266.7 | 266.7 | - | - | - | - |
| COVER ONCE | 7.7 | -484.7 | 0.0 | 486.7 | 8.3 | -620.7 | 0.0 | 191.7 |
| DENIED BY THE FIGHT | 0.3 | -1.3 | 0.0 | 0.0 | - | - | - | - |
| DEPLOY BY FIGURES | 7.3 | -21.6 | 0.0 | 0.0 | 7.7 | +43.4 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | - | - | - | - | 0.3 | -16.3 | 59.0 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +0.5 | 48.0 | 0.0 | 0.3 | +15.7 | 59.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 2.7 | +73.4 | 0.0 | 0.0 |
| EXACT ROUND | 1.0 | +4.7 | 76.7 | 0.0 | 2.3 | +27.8 | 319.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.0 | +2.9 | 36.7 | 99.0 | 3.7 | +2.2 | 440.7 | 0.0 |
| FALLS SHORT | - | - | - | - | 20.0 | +230.6 | 0.0 | 313.0 |
| FIGHT TO THE END | - | - | - | - | 1.0 | +21.5 | 214.7 | 0.0 |
| FIRE IN ORDER | 0.7 | +0.0 | 48.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 95.7 | +6207.6 | 381.3 | 2331.0 | 75.7 | +3946.9 | 1737.3 | 858.7 |
| FLANK NOT WEIGHED | 5.7 | +0.0 | 0.0 | 281.7 | 5.7 | +0.0 | 0.0 | 184.0 |
| FOLLOW UP WEIGHED | 0.3 | +233.1 | 0.0 | 0.0 | 1.7 | +152.5 | 0.0 | 0.0 |
| FOUR ROUNDS | 2.7 | +195.9 | 161.3 | 99.0 | 4.3 | +229.9 | 624.3 | 0.0 |
| FREED FROM HIS FIGHT | 3.3 | +0.0 | 0.0 | 100.7 | 5.7 | +0.0 | 0.0 | 144.0 |
| FRIEND SHOOTS FIRST | 0.7 | -5.3 | 0.0 | 198.0 | 0.7 | -3.7 | 0.0 | 0.0 |
| GIVES UP | 0.7 | -10.0 | 38.7 | 0.0 | - | - | - | - |
| GOAL WALK | 6.7 | +358.3 | 0.0 | 462.7 | 4.0 | +153.3 | 0.0 | 0.0 |
| GUN FIGURES | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| GUN MASK | 0.3 | -1.8 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 3.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 115.3 |
| HE REFORMS ONCE FREED | 2.7 | +0.0 | 0.0 | 100.7 | 3.0 | +0.0 | 0.0 | 144.0 |
| HIS CHARGE BY HIS RUN | 9.0 | +0.0 | 0.0 | 935.3 | 12.0 | +0.0 | 0.0 | 343.7 |
| HIS CHARGE LIST | 2.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 38.7 |
| HIS LEGAL MOVES | 3.7 | +0.0 | 0.0 | 663.3 | 4.3 | +0.0 | 0.0 | 144.0 |
| HIS MOVE AND SHOT | 2.7 | -17.7 | 0.0 | 181.0 | 3.7 | -39.0 | 0.0 | 86.7 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 39.7 | +13.0 | 1205.0 | 0.0 |
| HIS MOVE WHY | 24.3 | +0.0 | 0.0 | 916.3 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 27.3 | -123.5 | 0.0 | 48.0 |
| HIS ONE QUARTER | 6.7 | +0.0 | 0.0 | 299.3 | 2.7 | +0.0 | 0.0 | 48.0 |
| HIS OWN BEST MOVE | 6.3 | +0.0 | 0.0 | 663.3 | 0.7 | +0.0 | 0.0 | 48.0 |
| HIS RANDOM MOVE | 15.7 | +0.0 | 0.0 | 190.7 | - | - | - | - |
| HIS RANDOM MOVER COMES | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 36.0 | +1189.9 | 0.0 | 1121.7 | 43.3 | +1100.0 | 0.0 | 525.3 |
| HIS SHOTS BY HIS RUN | 36.3 | +788.5 | 0.0 | 1204.0 | 48.0 | +1138.4 | 0.0 | 565.3 |
| HIS TURN DENIED | 0.3 | +7.3 | 0.0 | 0.0 | 0.3 | +17.1 | 54.0 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 17.0 | +0.0 | 0.0 | 402.7 | 8.3 | +0.0 | 0.0 | 288.0 |
| HOLDER ASSIGNMENT | 10.3 | +717.3 | 0.0 | 201.3 | 5.3 | +389.4 | 0.0 | 144.0 |
| HOLDS AMBUSHERS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.7 | -97.4 | 161.3 | 99.0 | 2.3 | -63.6 | 466.0 | 0.0 |
| IDLE COST | - | - | - | - | 12.3 | -186.4 | 0.0 | 105.0 |
| JOINT CHARGE NOW | - | - | - | - | 1.0 | +4.4 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +97.5 | 0.0 | 0.0 | 0.3 | +7.0 | 0.0 | 0.0 |
| LATE ONLY FROM HERE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 5.7 | +0.0 | 144.0 | 104.3 | 4.0 | +0.0 | 489.3 | 65.0 |
| LONG SHOT | - | - | - | - | 0.3 | +2.8 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.7 | -0.2 | 38.7 | 0.0 | 2.3 | +5.3 | 222.3 | 0.0 |
| LOST CHARGE | - | - | - | - | 0.3 | -0.6 | 59.0 | 0.0 |
| MANOEUVRE | 0.3 | +0.0 | 0.0 | 0.0 | 2.3 | +27.7 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +30.0 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.7 | +28.7 | 0.0 | 0.0 |
| MARCH CHECK | - | - | - | - | 1.0 | +59.5 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +25.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 0.3 | +58.5 | 0.0 | 133.3 | 0.7 | +8.6 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 2.0 | +79.6 | 0.0 | 0.0 | 1.3 | +48.1 | 0.0 | 65.0 |
| MEETS IN TIME | 3.3 | +197.2 | 0.0 | 0.0 | 4.3 | +88.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 4.7 | +76.1 | 0.0 | 187.3 | 5.0 | +137.6 | 0.0 | 65.0 |
| MISSILES NEXT TURN | 7.3 | +52.9 | 0.0 | 320.7 | 5.3 | +100.4 | 0.0 | 65.0 |
| MOVE ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 1.0 | +0.0 | 0.0 | 133.3 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 7.3 | +808.7 | 0.0 | 198.0 | 6.3 | +707.8 | 0.0 | 0.0 |
| MOVES UNITS SPELL | - | - | - | - | 0.3 | +1.4 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.0 | +253.6 | 0.0 | 50.3 | 7.3 | +293.5 | 0.0 | 48.0 |
| NEXT CHARGE BY LIST | 4.7 | +464.2 | 0.0 | 198.0 | 4.0 | +556.3 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | 0.7 | -1.3 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 2.7 | -88.8 | 161.3 | 99.0 | 4.0 | -181.5 | 525.3 | 0.0 |
| NO LATE CUT | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 0.0 | 0.3 | -0.1 | 0.0 | 0.0 |
| OFF BEST | 6.7 | -323.5 | 0.0 | 59.0 | 6.0 | -196.9 | 99.0 | 157.3 |
| ONE CHALLENGE TEST | - | - | - | - | 1.0 | -5.2 | 50.3 | 0.0 |
| ONE FIGHT FORMULA | 4.3 | -141.2 | 0.0 | 153.0 | 4.7 | -82.3 | 0.0 | 48.0 |
| ONE JOINT FIGURE | - | - | - | - | 0.7 | -3.1 | 0.0 | 0.0 |
| ONE OBJECTIVE FORMULA | 5.3 | +15.1 | 0.0 | 151.0 | 1.3 | +19.3 | 0.0 | 144.0 |
| ONE PROMISE A TARGET | 0.3 | -1.1 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OPENS UP | 0.7 | +44.7 | 38.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.3 | +37.0 | 36.7 | 99.0 | 1.0 | +23.8 | 172.0 | 0.0 |
| PLAN RESULT | 43.0 | +683.8 | 55.0 | 1259.0 | 37.7 | +865.3 | 761.3 | 494.0 |
| PROMISE BY ITS OWN SUM | 9.7 | -417.2 | 0.0 | 0.0 | 5.0 | -10.4 | 0.0 | 38.7 |
| PROMISE IN STEPS | 0.7 | +0.0 | 0.0 | 198.0 | - | - | - | - |
| PROMISE KNOWS THE FIGHT | 1.3 | -0.0 | 0.0 | 0.0 | 0.3 | -11.1 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | - | - | - | - | 0.7 | -43.3 | 0.0 | 0.0 |
| PROMISE SHOT AWAY | 0.3 | -1.1 | 36.7 | 0.0 | 0.3 | -0.2 | 0.0 | 0.0 |
| QUARTER ODDS | 25.3 | +2431.5 | 38.0 | 724.0 | 21.3 | +2609.7 | 364.7 | 232.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.0 | +4.6 | 0.0 | 0.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.3 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 1.0 | -15.3 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | 0.7 | +0.0 | 0.0 | 50.3 | 1.0 | +0.0 | 0.0 | 48.0 |
| RESERVE FALL BACK | - | - | - | - | 0.7 | +16.9 | 0.0 | 0.0 |
| RISK BY ARC | 2.3 | -14.4 | 113.3 | 99.0 | 3.0 | -85.4 | 520.0 | 0.0 |
| RISK ON THE WAY | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 1.7 | -33.3 | 124.7 | 0.0 | 0.7 | -10.0 | 249.0 | 0.0 |
| RUN DOWN | 2.3 | -97.6 | 113.3 | 99.0 | 3.7 | -37.6 | 409.7 | 0.0 |
| SEARCH SPOT | - | - | - | - | 0.3 | +9.1 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.3 | +4.6 | 99.0 | 0.0 |
| SELF MOVE SPELL | - | - | - | - | 2.0 | +2.3 | 0.0 | 0.0 |
| SET CREDITED ONCE | 1.7 | -35.4 | 0.0 | 0.0 | 1.0 | -18.6 | 0.0 | 0.0 |
| SET UP BY THE SET | 3.0 | +98.5 | 0.0 | 0.0 | 1.7 | -18.7 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 12.0 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 74.7 |
| SHOOTS FROM THE BEST SPOT | 3.0 | +56.6 | 0.0 | 0.0 | 0.7 | +41.5 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.7 | -3.6 | 249.0 | 0.0 |
| SHOT RISK POINTS | 20.7 | -411.1 | 0.0 | 748.0 | 28.7 | -289.0 | 0.0 | 565.3 |
| SHOTS AFTER THE MOVES | 5.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 22.0 | +447.8 | 0.0 | 421.0 | 6.7 | +198.5 | 0.0 | 74.7 |
| SPELL WORTH | 3.0 | +85.2 | 266.7 | 266.7 | 1.7 | +16.3 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | +1.2 | 38.7 | 0.0 | 0.7 | -5.3 | 50.3 | 0.0 |
| SPOT AS THE GAME MOVES | 4.0 | +0.0 | 0.0 | 98.0 | 12.0 | +0.0 | 0.0 | 105.0 |
| STAND AND SHOOT | 0.7 | -6.3 | 38.0 | 0.0 | 1.0 | -19.2 | 233.7 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 6.0 | +0.0 | 580.3 | 76.0 |
| STANDS STILL | 47.0 | +0.0 | 220.0 | 260.3 | 22.3 | +0.0 | 1113.0 | 308.0 |
| STAY WORTH | 32.3 | +30.4 | 220.0 | 59.0 | 12.0 | +86.9 | 681.0 | 76.0 |
| STRIKE BY THE ODDS | 0.3 | +13.2 | 0.0 | 0.0 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 7.3 | +515.2 | 0.0 | 201.3 | 2.3 | +105.1 | 0.0 | 86.7 |
| SUPPORT NARROWED | 1.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 59.0 | 0.0 |
| SUPPORT WORKED OUT | 7.3 | +515.2 | 0.0 | 201.3 | 2.3 | +105.1 | 0.0 | 86.7 |
| SURE REACH TOGETHER | 1.3 | +2.5 | 0.0 | 0.0 | - | - | - | - |
| SWIFTSTRIDE BY POINTS | 0.3 | +14.6 | 0.0 | 99.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 3.0 | +0.0 | 0.0 | 99.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 1.0 | -79.1 | 0.0 | 0.0 | 0.7 | -43.3 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 3.3 | +0.0 | 0.0 | 213.7 | 3.3 | +0.0 | 0.0 | 48.0 |
| THE ROW KEEPS ITS WAY | 2.3 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| THE STEP BACK IS MADE | 1.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 45.7 | +0.0 | 0.0 | 1065.7 | 33.0 | +0.0 | 0.0 | 428.7 |
| TIED UP BY THE SUM | 1.7 | +188.3 | 122.7 | 99.0 | 0.3 | +45.2 | 59.0 | 0.0 |
| TIME ON OUR SIDE | 44.7 | +520.3 | 73.3 | 1121.3 | - | - | - | - |
| WAITS AGAIN | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 48.0 |
| WHAT THE JOINER ADDS | - | - | - | - | 0.7 | -10.0 | 198.0 | 0.0 |
| WHO FIGHTS | - | - | - | - | 1.0 | -7.2 | 50.3 | 0.0 |
| WHO HITS BACK | 1.3 | +326.2 | 0.0 | 99.0 | 0.3 | +13.6 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.3 | +0.8 | 99.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.7 | -159.3 | 0.0 | 235.0 | 3.0 | -776.2 | 0.0 | 48.0 |
| WHOLE FIGHT GAIN | - | - | - | - | 0.7 | +22.1 | 0.0 | 0.0 |
| WOUNDED STAYS OUT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | - | - | - | - | 3.0 | +98.2 | 0.0 | 0.0 |

### Rule changes: ccut-c940641-p32

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 154 | 154 | 107 | 35.67 | +1690 | +15.8 |
| HIS MOVE AS HE DECIDES | 119 | 119 | 80 | 26.67 | +0 | +0.0 |
| HIS MOVE WHY | 73 | 73 | 44 | 14.67 | +0 | +0.0 |
| HIS SHOTS BY HIS RUN | 253 | 245 | 44 | 14.67 | +709 | +16.1 |
| HIS SHOT LIST | 238 | 228 | 42 | 14.00 | +1318 | +31.4 |
| HOLDER ASSIGNMENT | 47 | 47 | 40 | 13.33 | +2524 | +63.1 |
| OFF BEST | 38 | 38 | 38 | 12.67 | -1561 | -41.1 |
| FIVE ACTION | 514 | 498 | 34 | 11.33 | +1630 | +47.9 |
| LEGAL CHARGES ONLY | 29 | 29 | 29 | 9.67 | +0 | +0.0 |
| THE TABLE AGAIN | 36 | 36 | 29 | 9.67 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 41 | 37 | 28 | 9.33 | +1853 | +66.2 |
| DEPLOY BY FIGURES | 45 | 45 | 26 | 8.67 | +294 | +11.3 |
| HARD STAY DROPPED | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| QUARTER ODDS | 140 | 136 | 20 | 6.67 | +2094 | +104.7 |
| HIS ONE MOVE | 82 | 82 | 18 | 6.00 | +0 | +0.0 |
| CHARGE LOSSES | 108 | 102 | 16 | 5.33 | +1885 | +117.8 |
| NEXT CHARGE BY LIST | 26 | 23 | 16 | 5.33 | +1721 | +107.6 |
| PROMISE BY ITS OWN SUM | 44 | 44 | 15 | 5.00 | -1283 | -85.5 |
| ADVANCE LANE KEPT | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| SHOT RISK POINTS | 148 | 140 | 12 | 4.00 | +523 | +43.6 |
| THE RISK READS HIS RUN | 18 | 18 | 12 | 4.00 | +0 | +0.0 |
| FOUR ROUNDS | 21 | 20 | 11 | 3.67 | +307 | +27.9 |
| MOVE ORDER | 11 | 11 | 11 | 3.67 | +0 | +0.0 |
| SHOOTS FROM THE BEST SPOT | 11 | 11 | 10 | 3.33 | +103 | +10.3 |
| TIME ON OUR SIDE | 134 | 114 | 10 | 3.33 | +77 | +7.7 |
| WHOLE FIGHT DANGER | 17 | 17 | 10 | 3.33 | +925 | +92.5 |
| MEETS IN TIME | 23 | 23 | 8 | 2.67 | +188 | +23.5 |
| CANNON PLANNED TARGET | 24 | 24 | 7 | 2.33 | -6 | -0.8 |
| CHALLENGE BY POINTS | 7 | 7 | 7 | 2.33 | +158 | +22.6 |
| STAY WORTH | 133 | 116 | 7 | 2.33 | +81 | +11.6 |
| FOLLOW UP WEIGHED | 6 | 6 | 6 | 2.00 | +1157 | +192.8 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 6 | 2.00 | +14 | +2.3 |
| SET UP BY THE SET | 14 | 13 | 6 | 2.00 | +542 | +90.3 |
| CHARGE NOW FIRST | 12 | 12 | 5 | 1.67 | -288 | -57.6 |
| COVER ONCE | 48 | 29 | 5 | 1.67 | +108 | +21.7 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +314 | +62.7 |
| RISK BY ARC | 16 | 15 | 5 | 1.67 | +143 | +28.6 |
| SUPPORT ADDS | 29 | 27 | 5 | 1.67 | +122 | +24.4 |
| SUPPORT WORKED OUT | 29 | 27 | 5 | 1.67 | +122 | +24.4 |
| TIED UP BY THE SUM | 6 | 6 | 5 | 1.67 | +210 | +41.9 |
| WHO HITS BACK | 5 | 5 | 5 | 1.67 | +791 | +158.2 |
| CASTING BLOCK | 9 | 9 | 4 | 1.33 | +14 | +3.5 |
| EVASIVE BY THE ODDS | 8 | 8 | 4 | 1.33 | +194 | +48.4 |
| GOAL WALK | 32 | 32 | 4 | 1.33 | +174 | +43.6 |
| IDLE COST | 37 | 26 | 4 | 1.33 | +61 | +15.2 |
| ONE FIGHT FORMULA | 27 | 12 | 4 | 1.33 | +16 | +4.0 |
| REDIRECT FOR A FRIEND IN REACH | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| HOLDS AMBUSHERS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| JOINT CHARGE NOW | 3 | 3 | 3 | 1.00 | +13 | +4.5 |
| MANOEUVRE | 8 | 8 | 3 | 1.00 | +89 | +29.7 |
| MAX FOR POSITIONING | 10 | 8 | 3 | 1.00 | +29 | +9.7 |
| NO DOUBLE ROUNDS | 20 | 20 | 3 | 1.00 | +116 | +38.7 |
| ASSAILMENT BY POINTS | 2 | 2 | 2 | 0.67 | +18 | +8.9 |
| EDGE GIVE GROUND | 2 | 2 | 2 | 0.67 | +20 | +9.9 |
| FIRE IN ORDER | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| MARCH BY THE SUM | 2 | 2 | 2 | 0.67 | +86 | +43.0 |
| MARCH CHECK | 3 | 3 | 2 | 0.67 | +118 | +58.9 |
| OPENS UP | 2 | 2 | 2 | 0.67 | +118 | +59.0 |
| PROMISE KNOWS THE FIGHT | 5 | 5 | 2 | 0.67 | -33 | -16.7 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -4 | -1.9 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +51 | +25.4 |
| SHOTS IN THE MOVE | 86 | 56 | 2 | 0.67 | +30 | +15.2 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| AFTERMATH WITH FRIENDS | 1 | 1 | 1 | 0.33 | +35 | +34.8 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.33 | +0 | +0.1 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | -4 | -3.7 |
| COMBAT PIVOT | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| EXACT ROUND | 10 | 9 | 1 | 0.33 | +12 | +12.1 |
| FALLS SHORT | 60 | 48 | 1 | 0.33 | +37 | +36.8 |
| HIS MOVE AND SHOT | 19 | 15 | 1 | 0.33 | +2 | +2.1 |
| MARCH OF THE TABLE | 1 | 1 | 1 | 0.33 | -77 | -77.1 |
| MISSILES IN THE MOVE | 29 | 21 | 1 | 0.33 | +2 | +2.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +4 | +4.3 |
| ONE OBJECTIVE FORMULA | 20 | 11 | 1 | 0.33 | +4 | +4.3 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -3 | -3.2 |
| OVERRUNS AWAY | 4 | 4 | 1 | 0.33 | +33 | +33.0 |
| REFUSING RETIRES | 5 | 5 | 1 | 0.33 | -13 | -13.0 |
| SEARCH SPOT | 1 | 1 | 1 | 0.33 | +27 | +27.3 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +14 | +13.9 |
| SET CREDITED ONCE | 8 | 7 | 1 | 0.33 | +6 | +5.9 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SHOTS AFTER THE MOVES | 21 | 21 | 1 | 0.33 | +0 | +0.0 |
| SPELLS IN THE FIGHT | 3 | 3 | 1 | 0.33 | +3 | +3.4 |
| STRIKE BY THE ODDS | 1 | 1 | 1 | 0.33 | +40 | +39.5 |
| SUPPORT NARROWED | 5 | 5 | 1 | 0.33 | -39 | -38.8 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +44 | +43.8 |
| THE ROW IN ITS ORDER | 20 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 2 | 2 | 1 | 0.33 | +25 | +25.1 |
| WOUNDS ON THE RANKS | 9 | 9 | 1 | 0.33 | +15 | +14.9 |
| CANNON PLAN MISSED | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 4 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 3 | 3 | 0 | 0.00 | - | - |
| CHARGER SLAIN LOST | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 30 | 27 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 5 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 1 | 1 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 14 | 13 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 3 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 34 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 27 | 26 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 4 | 4 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 2 | not checked | - | - | - | - |
| GUN MASK | 1 | 1 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 17 | 17 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 63 | 60 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 19 | 17 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 24 | 23 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 28 | 26 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 21 | 19 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 47 | 42 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 3 | 2 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 76 | 75 | 0 | 0.00 | - | - |
| HONEST WORTH | 15 | 14 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 8 | 7 | 0 | 0.00 | - | - |
| LATE ONLY FROM HERE | 2 | 2 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 9 | 9 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 2 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 38 | 28 | 0 | 0.00 | - | - |
| MOVE SPELL SPOT | 3 | not checked | - | - | - | - |
| NEARER NOT NEEDED | 40 | 37 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 2 | 2 | 0 | 0.00 | - | - |
| NO LATE CUT | 4 | 4 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 2 | not checked | - | - | - | - |
| ONE CHALLENGE TEST | 3 | 3 | 0 | 0.00 | - | - |
| ONE JOINT FIGURE | 2 | 2 | 0 | 0.00 | - | - |
| ONE ROUTE | 2 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 242 | trace | - | - | - | - |
| PROMISE IN STEPS | 2 | 2 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 2 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 2 | 2 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 3 | 3 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 7 | 7 | 0 | 0.00 | - | - |
| RUN DOWN | 18 | 18 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SHOOTERS ON THE TABLE | 52 | not checked | - | - | - | - |
| SHOT OR CHARGE | 2 | 2 | 0 | 0.00 | - | - |
| SPELL WORTH | 14 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 48 | 47 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 5 | 5 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 18 | 18 | 0 | 0.00 | - | - |
| STANDS STILL | 208 | 202 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 4 | 3 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 12 | not checked | - | - | - | - |
| THE PROMISE ADDS | 5 | 4 | 0 | 0.00 | - | - |
| THE ROW KEEPS ITS WAY | 20 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 3 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 15 | not checked | - | - | - | - |
| THE TABLE BINDS | 236 | not checked | - | - | - | - |
| WAITS AGAIN | 8 | 8 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 2 | not checked | - | - | - | - |
| WHO FIGHTS | 3 | 3 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 1 | not checked | - | - | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p32

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 5.67 | 4.00 | 33.6 |
| ARMY TABLE | rule | 3.33 | 3.00 | 67.6 |
| PROMISE BY ITS OWN SUM | rule | 4.67 | 0.33 | 85.5 |
| CHARGE NOW FIRST | rule | 1.00 | 0.67 | 57.6 |
| RULE SWITCHED OFF | gate | - | 1.67 | 47.9 |
| CANNON PLANNED TARGET | rule | 0.67 | - | 3.5 |
| HOLDER ASSIGNMENT | rule | 0.67 | - | 31.1 |
| NO REASON | gate | 0.67 | - | 43.9 |
| AFTERMATH NEEDS NEXT CHARGE | gate | 0.33 | - | 242.3 |
| CHAFF PASSED | rule | 0.33 | - | 3.7 |
| DEPLOY BY FIGURES | rule | - | 0.33 | 6.7 |
| FALLBACK | gate | - | 0.33 | 17.5 |
| JOINT CHARGE NOW | rule | - | 0.33 | 9.6 |
| MARCH OF THE TABLE | rule | 0.33 | - | 77.1 |
| ONE PROMISE A TARGET | rule | 0.33 | - | 3.2 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.33 | 33.2 |
| PROMISE SHOT AWAY | rule | 0.33 | - | 3.4 |
| REFUSING RETIRES | rule | - | 0.33 | 13.0 |
| SUPPORT NARROWED | rule | 0.33 | - | 38.8 |

### Plans: ccut-c940641-p32

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 2.7 | 75% | 443 | 254 | 57% |
| Mine | move | 32.3 | 97% | 1780 | 0 | 0% |
| Mine | shoot | 8.0 | 54% | 243 | 430 | 177% |
| Opponent | charge | 3.0 | 56% | 229 | 513 | 224% |
| Opponent | join | 1.3 | 75% | 41 | 0 | 0% |
| Opponent | move | 28.3 | 96% | 1352 | 0 | 0% |
| Opponent | shoot | 5.0 | 40% | 165 | 353 | 213% |

### Deployment: positions vs output by unit type: ccut-c940641-p32

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 8 | 32 (8) | 32 | 0 | 35 | 12% | 2.1 | 42 (6) | 0 (2) | - | 17 (2) | 36 (6) |
| Mine | Clean-up | 3 | 62 (3) | 0 | 62 | 37 | 0% | 2.7 | 98 (2) | 0 (1) | - | 98 (2) | 0 (1) |
| Mine | Fast Hammer | 7 | 34 (7) | 0 | 34 | 57 | 43% | 4.0 | 60 (3) | 20 (3) | 0 (1) | 89 (2) | 12 (5) |
| Mine | Holder | 2 | 39 (2) | 0 | 39 | 0 | 50% | 5.0 | 39 (2) | - | - | 39 (2) | - |
| Mine | Shooter | 5 | 0 (5) | 0 | 0 | 60 | 0% | 1.8 | 0 (4) | 0 (1) | - | 0 (4) | 0 (1) |
| Mine | War machine | 4 | 20 (4) | 20 | 0 | 0 | 0% | 1.0 | 0 (2) | 39 (2) | - | 39 (2) | 0 (2) |
| Opponent | Chaff | 3 | 0 (3) | 0 | 0 | 32 | 100% | - | 0 (3) | - | - | 0 (3) | - |
| Opponent | Character | 9 | 73 (9) | 73 | 0 | 5 | 22% | 2.6 | 123 (3) | 18 (6) | - | 137 (4) | 39 (5) |
| Opponent | Clean-up | 3 | 36 (3) | 36 | 0 | 0 | 33% | 1.5 | - | 36 (3) | - | 0 (1) | 52 (2) |
| Opponent | Fast Hammer | 3 | 38 (3) | 0 | 38 | 0 | 33% | 2.5 | 171 (1) | 0 (2) | - | 0 (1) | 75 (2) |
| Opponent | Hammer | 8 | 47 (8) | 47 | 0 | 0 | 38% | 3.4 | 0 (4) | 84 (2) | 136 (2) | 32 (5) | 81 (3) |
| Opponent | Holder | 3 | 29 (3) | 0 | 29 | 100 | 0% | 5.3 | 62 (1) | 0 (1) | 21 (1) | 42 (2) | 0 (1) |
| Opponent | Shooter | 3 | 0 (3) | 0 | 0 | 62 | 0% | 1.0 | - | 0 (2) | 0 (1) | - | 0 (3) |
| Opponent | Wizard | 3 | 0 (3) | 0 | 0 | 34 | 0% | 1.3 | 0 (1) | 0 (2) | - | 0 (2) | 0 (1) |

### Charged fights: ccut-c940641-p32

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 3 | 58 | 238 | 2.7 | 1.0 | 89 | 0 | +89 | 1 of 8 | 7 of 8 | - | +89 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 826 | 3.0 | 1.0 | 275 | 0 | +275 | 1 of 3 | 3 of 3 | - | +275 |
| Opponent | Warriors of Chaos | 1 | 0 | 320 | 2.0 | 1.0 | 160 | 0 | +160 | 2 of 2 | 0 of 2 | - | +160 |
| Opponent | Wood Elf Realms | 1 | 151 | 859 | 6.0 | 1.2 | 143 | 18 | +125 | 2 of 6 | 6 of 6 | +0 | +150 |
| **Opponent** | all armies | 3 | 50 | 668 | 3.7 | 1.1 | 182 | 10 | +172 | 5 of 11 | 9 of 11 | +0 | +190 |

### Effective charges: ccut-c940641-p32

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 8 | 0 | 0 | 1 (net +0) | 1 (net +311) | 1 (net +144) | 3 (net +38) | 2 | 17% (1 of 6) |
| Opponent | Orc & Goblin Tribes | 3 | 1 (net +498) | 0 | 0 | 0 | 0 | 2 (net +164) | 0 | 0% (0 of 3) |
| Opponent | Warriors of Chaos | 2 | 0 | 0 | 1 (net +320) | 0 | 0 | 0 | 1 | 100% (1 of 1) |
| Opponent | Wood Elf Realms | 6 | 0 | 0 | 0 | 1 (net +0) | 0 | 4 (net +140) | 1 | 0% (0 of 5) |

### Charged fights, damage counted: ccut-c940641-p32

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 1 | 151 | 116 | +0 | 70 | 91 | -21 | -13.9 |
| Mine | 76-89% | 1 | 500 | 116 | +311 | 311 | 0 | +311 | +62.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 3 | 310 | 117 | +38 | 66 | 68 | -2 | -0.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 489 | 144 | +144 | 144 | 0 | +144 | +29.4 |
| Mine | No odds | 2 | 494 | 172 | +72 | 72 | 0 | +72 | +14.6 |
| Mine | All fights | 8 | 382 | 134 | +89 | 108 | 37 | +71 | +18.7 |
| Opponent | Long shot (under 50%) | 1 | 350 | 247 | +498 | 498 | 0 | +498 | +142.3 |
| Opponent | Effective (55-75%) | 1 | 116 | 177 | +320 | 320 | 142 | +178 | +153.7 |
| Opponent | 76-89% | 1 | 125 | 230 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 6 | 279 | 214 | +148 | 168 | 37 | +131 | +46.8 |
| Opponent | No odds | 2 | 111 | 374 | +94 | 148 | 55 | +94 | +84.2 |
| Opponent | All fights | 11 | 226 | 244 | +172 | 193 | 43 | +150 | +66.2 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p32 | move | 22 | 4 (18%) | 3 (14%) | 5 (23%) | 13 (59%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Elixir of Power | Opponent | L1319 |
| Opal Amulet | Mine | L1431 |
| Ring of Doom | Opponent | L1431 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |

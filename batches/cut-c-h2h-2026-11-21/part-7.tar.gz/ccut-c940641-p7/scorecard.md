# Doctrine scorecard: ccut-c940641-p7

### Scorecard: ccut-c940641-p7

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1114 | 4 | 1 | Mine | no | 4 | 2 | 0 | 0 | 0 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | no | 3 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L1131 | 3 | 1 | Mine | no | 0 | - | 1 | 0 | 0 | 0 | 0 | 330 |
| L1131 | 3 | 1 | Opponent | no | 0 | 5 | 1 | 4 | 1 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 12 | 1 | 8 | 0 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 0 | - | 0 | 2 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 5.3 | 1.5 | 3.0 | 0.0 | 0.0 | 0.0 | 0.0 | 330.0 |
| **Average** | | | Opponent | 0% | 1.0 | 3.5 | 0.7 | 2.7 | 0.7 | 0.0 | 0.0 | 56.7 |

### KPIs: ccut-c940641-p7

Rules off - Mine only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 41% (7 of 17) | 0% (0 of 11) | 25% (7 of 28) |
| Winner chose to follow up after the loser gave ground |  | 100% (4 of 4); on the table 100% | 100% (1 of 1); on the table 100% | 100% (5 of 5); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | - | - |
| Winner chose to pursue after the loser fled |  | 50% (1 of 2); on the table 50% | - | 50% (1 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 83% (5 of 6); on the table 83% | 100% (1 of 1); on the table 100% | 86% (6 of 7); on the table 86% |
| Magic missiles tried each own turn | 50%+ | 35% (23 of 66) | 22% (4 of 18) | 32% (27 of 84) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 44% (23 of 52) | 36% (4 of 11) | 43% (27 of 63) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 75% (9 of 12) | 75% (9 of 12) |
| Points that never fought | lower | 47% (2829 of 5998) | 53% (3186 of 5998) | 50% (6015 of 11996) |
|   infantry points that never fought | lower | 100% (730 of 730) | 71% (648 of 913) | 84% (1378 of 1643) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 48% (12 of 25) | 75% (21 of 28) | 62% (33 of 53) |
| Bound items with a magic missile used (at least once a game) |  | 100% (7 of 7); 8.3 uses a game | 100% (1 of 1); 0.7 uses a game | 100% (8 of 8); 4.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 17% (1 of 6); 0.7 uses a game | 17% (1 of 6); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 3); 0.0 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 43% (2415 of 5614) | 72% (4204 of 5828) | 58% (6619 of 11442) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 3.0 (21%) | 1.3 (29%) | 4.3 (23%) |
| MARCHED: its unit marched | 6.3 (44%) | 1.0 (21%) | 7.3 (39%) |
| CHARGED: its unit charged | 0.3 (2%) | 0.0 (0%) | 0.3 (2%) |
| IN COMBAT: engaged in combat | 4.0 (28%) | 0.3 (7%) | 4.3 (23%) |
| FLEEING: fleeing | 0.0 (0%) | 1.0 (21%) | 1.0 (5%) |
| GONE: slain | 0.7 (5%) | 1.0 (21%) | 1.7 (9%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 1.7 | 4.0 | 1.7 | 9.0 | 3.0 | 2.0 |
| not cast | 2.3 | 8.0 | 2.3 | 19.0 | 5.0 | 34.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 5.3 (67%) | 0.0 (0%) | 4.3 (23%) | 0.3 (7%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 7.3 (39%) | 0.7 (13%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.7 (8%) | 0.3 (14%) | 4.3 (23%) | 0.7 (13%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (5%) | 0.0 (0%) | 0.0 (0%) |
| GONE: slain | 1.0 (43%) | 1.0 (12%) | 1.0 (43%) | 1.7 (9%) | 0.0 (0%) | 3.3 (10%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 1.0 (12%) | 0.0 (0%) | 0.0 (0%) | 3.3 (67%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.3 (57%) | 0.0 (0%) | 1.0 (43%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 30.3 (89%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.7 a game | 0.8 a game |
| stood (cast and not dispelled) | - | 60% (3 of 5) | 60% (3 of 5) |
| the unit moved after it | - | 33% (1 of 3) | 33% (1 of 3) |
| it charged on its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| the enemy charged it first | - | 33% (1 of 3) | 33% (1 of 3) |
| it fought by the end of its next turn | - | 33% (1 of 3) | 33% (1 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 3) | 0% (0 of 3) |
| none of these (no charge, no fight, no charge escaped) | - | 67% (2 of 3) | 67% (2 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 89% (47 of 53) | 26% (5 of 19) | 72% (52 of 72) |
|   cavalry | - | 40% (2 of 5) | 40% (2 of 5) |
|   character | - | 0% (0 of 10) | 0% (0 of 10) |
|   chariot | 78% (7 of 9) | - | 78% (7 of 9) |
|   infantry | 92% (11 of 12) | 75% (3 of 4) | 88% (14 of 16) |
|   war machine | 91% (29 of 32) | - | 91% (29 of 32) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 0.7 (33%) | 0.7 (14%) | 1.3 (20%) |
| CHARGED: it charged | 0.0 (0%) | 0.7 (14%) | 0.7 (10%) |
| IN COMBAT: it fought this turn or the last | 1.0 (50%) | 0.0 (0%) | 1.0 (15%) |
| NO TARGET IN RANGE | 0.0 (0%) | 2.7 (57%) | 2.7 (40%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.3 (7%) | 0.3 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 0.0 (0%) | 0.3 (7%) | 0.3 (5%) |
| SHELTERED: the target was sheltered | 0.3 (17%) | 0.0 (0%) | 0.3 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 1.3 | 0.3 | 75% | 5.4 pts | 7 pts |
| chariot | 2.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| infantry | 9.0 | 0.7 | 93% | 3.5 pts | 32 pts |
| war machine | 10.7 | 8.0 | 66% | 15.9 pts | 170 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.3 | 1.0 | 2.2 |
| Charges that made contact a game | 2.3 | 0.7 | 1.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.86 contact (7 units) | 0.00 declared, 0.00 contact (3 units) | 0.70 declared, 0.60 contact (10 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 0.00 declared, 0.00 contact (1 units) | 0.00 declared, 0.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.30 declared, 0.10 contact (10 units) | 0.16 declared, 0.11 contact (19 units) | 0.21 declared, 0.10 contact (29 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 64% (7 of 11) | 50% (1 of 2) | 50% (1 of 2) | 60% (9 of 15) |
| Character in a unit | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Character on its own | 100% (5 of 5) | 0% (0 of 6) | 57% (4 of 7) | 50% (9 of 18) |
| Chariot | 100% (2 of 2) | - | - | 100% (2 of 2) |
| Infantry | 67% (4 of 6) | 50% (1 of 2) | - | 62% (5 of 8) |
| Monster | 50% (1 of 2) | - | - | 50% (1 of 2) |
| War Machines | 83% (5 of 6) | - | - | 83% (5 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 3 | 83% (5 of 6); on the table 83% | 35% (23 of 66) | 47% | 48% (12 of 25) | 100% (7 of 7); 8.3 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| High Elf Realms | 1 | - | 17% (1 of 6) | 68% | 67% (6 of 9) | 0.0 uses a game | 17% (1 of 6); 2.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 100% (1 of 1); on the table 100% | 17% (1 of 6) | 29% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | - | 33% (2 of 6) | 62% | 83% (10 of 12) | 100% (1 of 1); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p7, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (1) | 100% (6) | 88% (7) |
| ...free all their last turn and able to turn (per game) | 0.33 | 2.00 | 2.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 1.67 | 2.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: ccut-c940641-p7

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 4.3 | 3.7 |
| Strategy | Charge objectives carried out (made contact) | 56% (5 of 9) | 100% (2 of 2) |
| Strategy | Shoot objectives carried out (shot that target) | 19% (9 of 48) | 33% (1 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 67% (4 of 6) | 0% (0 of 1) |
| Strategy | Joined characters whose unit fought | 33% (1 of 3) | 0% (0 of 1) |
| Strategy | Lone characters that fought | 78% (7 of 9) | 50% (5 of 10) |
| Movement | Charges halted short of contact | 0.3 | 0.0 |
| Movement | Idle units | 0.0 | 2.7 |
| Movement | Points that never moved of their own | 330.0 | 56.7 |
| Movement | Fights charged into per game | 2.3 | 0.7 |
| Movement | Charges with odds: long shots (under 50%) | 0 of 6 | 1 of 2, net +0 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 6, net +69 | 0 of 2 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 6, net +60 | 0 of 2 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 6, net +98 | 1 of 2, net +165 |
| Shooting | Shots by shooting units (incl. breath weapons) | 6.0 | 2.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 56% (10 of 18) | 14% (1 of 7) |
| Shooting | Points destroyed by shooting units | 50.3 | 0.0 |
| Shooting | War machine shots | 9.7 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 41% (12 of 29) | - |
| Shooting | Points destroyed by war machines | 59.0 | 0.0 |
| Magic | Magic missiles cast | 6.7 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 15% (3 of 20) | 0% (0 of 2) |
| Magic | Wounds caused by magic missiles | 14.3 | 4.3 |
| Magic | Wounds caused by other spells | 2.7 | 2.3 |
| Magic | Points destroyed by magic (all spells) | 443.3 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.3 / 2.0 / 0.3 / 1.3 | 1.0 / 0.3 / 1.0 / 0.0 |
| Combat | Points destroyed in combat | 87.7 | 283.3 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +93 | -16 |
| Combat | Net per 100 charger points, damage counted | +36.1 | -3.5 |
| Combat | First round won (charged fights) | 71% | 50% |
| Combat | Net points per charged fight | +85 | +82 |
| Combat | Net points per supported fight / lone fight | - / +85 | - / +82 |
| Combat | Charged fights on a top-3 enemy unit | 4 of 7 | 1 of 2 |
| Game | Points lost | 468.0 | 823.3 |
| Game | VP from objectives | 603.3 | 580.0 |
| Game | Lone holders (player turns) | 5.3 | 1.0 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +332 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 1291
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: ccut-c940641-p7

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 14.3 | +362.3 | 0.0 | 0.0 | 28.0 | -29.9 | 0.0 | 700.7 |
| ARTILLERY RE-ROLL WEIGHED | 8.7 | +0.0 | 0.0 | 165.0 | - | - | - | - |
| ASSAILMENT BY POINTS | - | - | - | - | 0.3 | +1.7 | 0.0 | 128.3 |
| BACKUP TARGETS | - | - | - | - | 0.7 | +4.1 | 0.0 | 0.0 |
| BOMBING RUN | 0.3 | +7.9 | 0.0 | 50.0 | - | - | - | - |
| CANNON PLANNED TARGET | 9.7 | +265.6 | 237.7 | 220.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 5.3 | +109.1 | 118.0 | 0.0 | 0.7 | +1.3 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 1.0 | +0.0 | 0.0 | 156.7 |
| CASTS FROM BEHIND | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 3.3 | +165.1 | 0.0 | 160.0 |
| CHALLENGE BY POINTS | 0.3 | +3.7 | 0.0 | 0.0 | 1.0 | +27.4 | 0.0 | 332.7 |
| CHARGE LOSSES | 9.0 | -310.9 | 0.0 | 0.0 | 26.0 | -1272.6 | 0.0 | 1282.3 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 449.7 | 136.7 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 8.7 | +0.0 | 0.0 | 238.7 | 8.3 | +0.0 | 0.0 | 206.7 |
| CONVEYANCE SEARCH | - | - | - | - | 1.7 | +192.8 | 156.7 | 156.7 |
| COVER ONCE | 9.0 | -669.0 | 0.0 | 0.0 | 6.0 | -393.5 | 0.0 | 449.7 |
| DEPLOY BY FIGURES | 6.0 | +5.5 | 0.0 | 0.0 | 6.7 | +127.1 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.3 | -8.1 | 114.3 | 0.0 | 0.3 | -21.8 | 119.3 | 0.0 |
| EDGE GIVE GROUND | 0.3 | +18.2 | 114.3 | 0.0 | 0.3 | +28.7 | 0.0 | 0.0 |
| EXACT ROUND | 2.0 | +27.7 | 449.7 | 136.7 | 0.3 | +9.4 | 55.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.7 | +3.5 | 438.3 | 68.3 | 0.7 | +15.1 | 119.3 | 0.0 |
| FALLS SHORT | - | - | - | - | 21.0 | +153.9 | 0.0 | 983.3 |
| FIGHT TO THE END | 1.7 | +43.2 | 447.0 | 68.3 | 0.3 | +15.2 | 0.0 | 0.0 |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 80.3 | +6484.0 | 1601.7 | 1154.0 | 77.7 | +4421.7 | 174.3 | 2379.3 |
| FLANK NOT WEIGHED | 7.3 | +0.0 | 0.0 | 0.0 | 5.0 | +0.0 | 0.0 | 564.0 |
| FOLLOW UP WEIGHED | 1.0 | +97.7 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 3.3 | +370.7 | 631.7 | 136.7 | 1.0 | +227.0 | 174.3 | 0.0 |
| FREED FROM HIS FIGHT | 2.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FRIEND SHOOTS FIRST | 1.0 | -4.0 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 0.3 | -4.5 | 114.3 | 0.0 | - | - | - | - |
| GOAL WALK | - | - | - | - | 14.3 | +2032.7 | 0.0 | 228.7 |
| GUN MASK | 6.0 | +380.6 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 1.0 | +0.0 | 0.0 | 119.3 | 1.7 | +0.0 | 0.0 | 41.0 |
| HE REFORMS ONCE FREED | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | 13.3 | +0.0 | 0.0 | 1086.0 |
| HIS CHARGE DENIED | 0.3 | +6.9 | 20.0 | 68.3 | - | - | - | - |
| HIS CHARGE LIST | 2.7 | +0.0 | 0.0 | 0.0 | 9.3 | +0.0 | 0.0 | 530.3 |
| HIS LEGAL MOVES | 6.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 376.0 |
| HIS MOVE AND SHOT | 2.3 | -12.2 | 0.0 | 0.0 | 12.0 | -258.7 | 0.0 | 728.0 |
| HIS MOVE AS HE DECIDES | 38.7 | +10.7 | 1343.7 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 26.0 | +0.0 | 0.0 | 1018.3 |
| HIS ONE MOVE | 22.3 | +87.3 | 0.0 | 100.0 | - | - | - | - |
| HIS ONE QUARTER | 3.7 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 2.0 | +0.0 | 0.0 | 0.0 | 4.3 | +0.0 | 0.0 | 376.0 |
| HIS RANDOM MOVE | 14.3 | +0.0 | 0.0 | 100.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 2.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 13.0 | +87.3 | 0.0 | 338.7 | 64.0 | +5120.2 | 0.0 | 2346.0 |
| HIS SHOTS BY HIS RUN | 16.0 | +139.9 | 0.0 | 477.3 | 56.7 | +1866.0 | 0.0 | 2114.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 12.3 | +0.0 | 0.0 | 238.7 | 13.3 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 9.0 | +955.3 | 0.0 | 119.3 | 8.7 | +905.2 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.0 | -70.7 | 503.3 | 68.3 | 1.0 | -124.2 | 174.3 | 0.0 |
| IDLE COST | - | - | - | - | 19.7 | -331.3 | 0.0 | 814.3 |
| JOINT CHARGE NOW | 0.3 | -12.0 | 114.3 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 0.7 | +0.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.0 | +5.5 | 0.0 | 0.0 | 0.7 | +40.1 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 3.0 | +0.0 | 460.3 | 0.0 | 3.7 | +0.0 | 0.0 | 129.7 |
| LONE WIZARD KEPT IN | 0.7 | +41.6 | 0.0 | 0.0 | - | - | - | - |
| LOST AFTER ESCAPE | 2.0 | -0.9 | 506.7 | 68.3 | 0.3 | -0.8 | 0.0 | 0.0 |
| MANOEUVRE | 0.3 | +9.7 | 0.0 | 0.0 | 2.0 | +5.6 | 0.0 | 0.0 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +0.7 | 0.0 | 0.0 |
| MARCH BY THE SUM | 2.7 | +233.4 | 0.0 | 0.0 | 0.7 | +69.5 | 0.0 | 0.0 |
| MARCH CHECK | 4.0 | +309.2 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 1.3 | +95.4 | 0.0 | 0.0 | - | - | - | - |
| MARCH OVER CASTS | 4.7 | +184.6 | 0.0 | 0.0 | 1.3 | +163.4 | 0.0 | 156.7 |
| MARCH WHEELS ONLY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| MAX FOR POSITIONING | 6.7 | +150.1 | 0.0 | 0.0 | 1.0 | +3.7 | 0.0 | 65.0 |
| MEETS IN TIME | 3.7 | +420.3 | 0.0 | 0.0 | 3.7 | +347.5 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 14.3 | +420.4 | 0.0 | 0.0 | 1.7 | +15.8 | 0.0 | 130.0 |
| MISSILES NEXT TURN | 16.3 | +371.9 | 0.0 | 0.0 | 5.0 | +21.9 | 0.0 | 286.7 |
| MISSILES ON ONE TARGET | 0.3 | -6.5 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL SPOT | - | - | - | - | 1.0 | +0.0 | 0.0 | 156.7 |
| MOVE TO CHARGE COMPUTED | 10.0 | +923.0 | 0.0 | 0.0 | 3.0 | +268.9 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 5.3 | +220.9 | 0.0 | 0.0 | 6.0 | +238.3 | 0.0 | 154.3 |
| NEXT CHARGE BY LIST | 4.0 | +517.4 | 0.0 | 0.0 | 2.0 | +223.0 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.3 | -126.3 | 437.7 | 136.7 | 1.0 | -20.4 | 174.3 | 0.0 |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +0.0 | 0.0 | 20.0 |
| NOT WORTH A CAST | 1.3 | -0.3 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 9.3 | -572.8 | 47.7 | 160.0 | 6.0 | -393.7 | 0.0 | 120.0 |
| OGRE LOADER SECOND SHOT | 13.3 | +96.2 | 0.0 | 55.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 114.3 |
| ONE FIGHT FORMULA | 7.7 | -169.0 | 0.0 | 0.0 | 3.3 | -87.4 | 0.0 | 65.0 |
| ONE JOINT FIGURE | 0.3 | +23.1 | 114.3 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 3.0 | -15.4 | 0.0 | 119.3 | 3.3 | -82.5 | 0.0 | 0.0 |
| ONE PROMISE A TARGET | 0.3 | -31.6 | 0.0 | 0.0 | - | - | - | - |
| ONE ROUTE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| OPENS A LANE | 0.7 | +1.5 | 0.0 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 0.3 | +0.5 | 47.7 | 0.0 | 0.7 | +3.5 | 174.3 | 0.0 |
| PATHS CROSS | 0.7 | +61.0 | 0.0 | 0.0 | 0.7 | +41.9 | 0.0 | 0.0 |
| PLAN RESULT | 36.3 | +1310.2 | 759.3 | 686.0 | 39.3 | +182.3 | 0.0 | 1682.3 |
| PROMISE BY ITS OWN SUM | 14.0 | -388.2 | 0.0 | 0.0 | 6.0 | -179.0 | 0.0 | 114.3 |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 0.0 | 0.3 | -0.2 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 2.3 | -76.1 | 0.0 | 0.0 | - | - | - | - |
| PROMISE SHOT AWAY | 0.7 | -3.1 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 13.3 | +1854.7 | 100.7 | 0.0 | 15.0 | +2283.4 | 55.0 | 0.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 4.0 | +151.2 | 0.0 | 0.0 |
| REAL GROUND | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.7 | +80.8 | 0.0 | 40.0 |
| REDIRECT COUNTER | - | - | - | - | 1.0 | +95.6 | 0.0 | 60.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.3 | +102.3 | 0.0 | 80.0 |
| REFORMS TO MEET IT | 3.0 | -190.7 | 0.0 | 0.0 | 2.0 | -152.9 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 47.7 |
| RESERVE FALL BACK | 0.7 | +33.5 | 0.0 | 50.0 | - | - | - | - |
| RISK BY ARC | 3.3 | +74.5 | 631.7 | 136.7 | 1.0 | -152.0 | 174.3 | 0.0 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | - | - | - | - | 0.7 | -31.5 | 174.3 | 0.0 |
| RUN DOWN | 0.7 | -5.4 | 112.7 | 0.0 | 0.7 | -35.9 | 119.3 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 2.0 | +98.8 | 0.0 | 80.0 |
| SEARCH SPOT | 2.0 | +48.2 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SECOND LOOK | 0.3 | +19.0 | 47.7 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | 1.0 | -15.1 | 0.0 | 0.0 | 1.0 | -49.1 | 0.0 | 50.3 |
| SET UP BY THE SET | 2.3 | +340.2 | 0.0 | 0.0 | 3.0 | +30.3 | 119.3 | 50.3 |
| SET UP TOGETHER | - | - | - | - | 0.7 | +1.5 | 0.0 | 0.0 |
| SHOOTER COUNTED ONCE | - | - | - | - | 1.3 | -7.3 | 0.0 | 80.0 |
| SHOOTERS ON THE TABLE | 15.0 | +0.0 | 0.0 | 220.0 | 2.0 | +0.0 | 0.0 | 40.0 |
| SHOOTS FROM THE BEST SPOT | 5.0 | +225.6 | 519.0 | 0.0 | 1.0 | +7.2 | 0.0 | 0.0 |
| SHOT OR CHARGE | 1.0 | -23.1 | 105.0 | 0.0 | - | - | - | - |
| SHOT RISK POINTS | 6.3 | -50.5 | 0.0 | 0.0 | 39.7 | +1116.8 | 0.0 | 1541.0 |
| SHOTS AFTER THE MOVES | 5.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOTS IN THE MOVE | 16.0 | +647.8 | 0.0 | 270.0 | 2.3 | +36.1 | 0.0 | 141.0 |
| SPELL WORTH | 0.7 | +2.5 | 0.0 | 0.0 | 1.0 | +28.8 | 313.3 | 313.3 |
| SPELLS IN THE FIGHT | 1.0 | -24.4 | 285.0 | 68.3 | - | - | - | - |
| SPOT AS THE GAME MOVES | 7.0 | +0.0 | 0.0 | 50.0 | 7.0 | +0.0 | 0.0 | 467.0 |
| STANDS FOR A REASON | - | - | - | - | 2.7 | +0.0 | 0.0 | 82.0 |
| STANDS STILL | 35.3 | +0.0 | 970.0 | 678.7 | 16.3 | +0.0 | 0.0 | 338.7 |
| STAY WORTH | 26.7 | -240.9 | 138.0 | 160.0 | 2.0 | +15.2 | 0.0 | 100.0 |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 4.3 | +226.9 | 0.0 | 100.0 | 3.7 | +177.4 | 0.0 | 167.0 |
| SUPPORT NARROWED | 1.0 | +0.0 | 144.7 | 68.3 | - | - | - | - |
| SUPPORT WORKED OUT | 4.3 | +226.9 | 0.0 | 100.0 | 3.7 | +177.4 | 0.0 | 167.0 |
| SURE REACH TOGETHER | 0.7 | +0.5 | 0.0 | 0.0 | 0.7 | +2.1 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +1.8 | 0.0 | 65.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE PROMISE ADDS | 1.3 | -180.2 | 0.0 | 0.0 | - | - | - | - |
| THE PROMISED MOVE | 0.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 114.3 |
| THE ROW READS HIS LAST RUN | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 114.3 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 37.3 | +0.0 | 0.0 | 508.7 | 38.0 | +0.0 | 0.0 | 1229.7 |
| TIED UP BY THE SUM | 1.3 | +87.9 | 125.0 | 68.3 | 0.3 | +40.9 | 55.0 | 0.0 |
| TIME ON OUR SIDE | 29.0 | +503.1 | 41.0 | 766.0 | - | - | - | - |
| WAITS AGAIN | 3.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| WHO HITS BACK | 0.3 | +2.1 | 0.0 | 0.0 | 0.3 | +103.3 | 0.0 | 128.3 |
| WHOLE FIGHT DANGER | 2.7 | -244.4 | 0.0 | 0.0 | 3.3 | -419.0 | 0.0 | 543.7 |
| WHOLE FIGHT GAIN | 0.3 | +12.0 | 114.3 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 1.3 | +5.3 | 0.0 | 0.0 | 2.0 | +15.9 | 0.0 | 0.0 |

### Rule changes: ccut-c940641-p7

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| ARMY TABLE | 127 | 127 | 94 | 31.33 | +1260 | +13.4 |
| HIS MOVE AS HE DECIDES | 116 | 116 | 84 | 28.00 | +0 | +0.0 |
| HIS MOVE WHY | 78 | 78 | 55 | 18.33 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 53 | 53 | 47 | 15.67 | +3370 | +71.7 |
| HIS SHOT LIST | 231 | 222 | 46 | 15.33 | +2286 | +49.7 |
| OFF BEST | 46 | 46 | 46 | 15.33 | -2899 | -63.0 |
| OGRE LOADER SECOND SHOT | 40 | 40 | 40 | 13.33 | +289 | +7.2 |
| HIS SHOTS BY HIS RUN | 218 | 207 | 38 | 12.67 | +790 | +20.8 |
| FIVE ACTION | 474 | 454 | 33 | 11.00 | +2921 | +88.5 |
| THE TABLE AGAIN | 36 | 36 | 30 | 10.00 | +0 | +0.0 |
| SHOT RISK POINTS | 138 | 128 | 29 | 9.67 | +2115 | +72.9 |
| ARTILLERY RE-ROLL WEIGHED | 26 | 26 | 26 | 8.67 | +0 | +0.0 |
| PROMISE BY ITS OWN SUM | 60 | 60 | 26 | 8.67 | -1702 | -65.5 |
| LEGAL CHARGES ONLY | 20 | 20 | 20 | 6.67 | +0 | +0.0 |
| DEPLOY BY FIGURES | 38 | 38 | 18 | 6.00 | +443 | +24.6 |
| HIS ONE MOVE | 67 | 60 | 18 | 6.00 | +0 | +0.0 |
| QUARTER ODDS | 85 | 84 | 18 | 6.00 | +2036 | +113.1 |
| MOVE TO CHARGE COMPUTED | 39 | 29 | 17 | 5.67 | +582 | +34.2 |
| GOAL WALK | 43 | 43 | 14 | 4.67 | +2138 | +152.7 |
| CAST JOB | 18 | 18 | 13 | 4.33 | +26 | +2.0 |
| MEETS IN TIME | 22 | 22 | 12 | 4.00 | +535 | +44.6 |
| TIME ON OUR SIDE | 87 | 70 | 11 | 3.67 | +91 | +8.2 |
| CHARGE LOSSES | 105 | 97 | 10 | 3.33 | +1292 | +129.2 |
| MARCH BY THE SUM | 10 | 10 | 10 | 3.33 | +909 | +90.9 |
| MARCH CHECK | 12 | 11 | 10 | 3.33 | +436 | +43.6 |
| NEXT CHARGE BY LIST | 18 | 13 | 10 | 3.33 | +459 | +45.9 |
| SHOOTS FROM THE BEST SPOT | 18 | 18 | 10 | 3.33 | +136 | +13.6 |
| IDLE COST | 59 | 40 | 9 | 3.00 | +134 | +14.9 |
| MOVE ORDER | 9 | 9 | 9 | 3.00 | +0 | +0.0 |
| RANDOM MOVE BY FIGURES | 12 | 12 | 9 | 3.00 | +454 | +50.4 |
| FOUR ROUNDS | 13 | 12 | 8 | 2.67 | +762 | +95.3 |
| HARD STAY DROPPED | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| COVER ONCE | 45 | 32 | 6 | 2.00 | +114 | +19.0 |
| SCREEN BY WHAT IT SAVES | 6 | 6 | 6 | 2.00 | +38 | +6.3 |
| THE RISK READS HIS RUN | 18 | 18 | 6 | 2.00 | +0 | +0.0 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 10 | 10 | 5 | 1.67 | +38 | +7.5 |
| HOLDS AMBUSHERS | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +137 | +27.3 |
| MAX FOR POSITIONING | 23 | 22 | 5 | 1.67 | +51 | +10.2 |
| SET UP BY THE SET | 16 | 15 | 5 | 1.67 | +393 | +78.6 |
| SHOTS AFTER THE MOVES | 16 | 16 | 5 | 1.67 | +0 | +0.0 |
| TIED UP BY THE SUM | 5 | 5 | 5 | 1.67 | +229 | +45.8 |
| CHALLENGE BY POINTS | 4 | 4 | 4 | 1.33 | +94 | +23.4 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +293 | +73.3 |
| MANOEUVRE | 7 | 7 | 4 | 1.33 | +63 | +15.7 |
| MARCH OF THE TABLE | 4 | 4 | 4 | 1.33 | -286 | -71.5 |
| MISSILES IN THE MOVE | 48 | 34 | 4 | 1.33 | +82 | +20.5 |
| PATHS CROSS | 4 | 4 | 4 | 1.33 | +309 | +77.2 |
| SEARCH SPOT | 7 | 7 | 4 | 1.33 | +145 | +36.1 |
| SUPPORT ADDS | 24 | 24 | 4 | 1.33 | +263 | +65.7 |
| SUPPORT WORKED OUT | 24 | 24 | 4 | 1.33 | +263 | +65.7 |
| NEARER NOT NEEDED | 34 | 33 | 3 | 1.00 | +39 | +13.1 |
| PROMISE READS THE TABLE | 7 | 7 | 3 | 1.00 | -88 | -29.2 |
| STAY WORTH | 86 | 70 | 3 | 1.00 | +31 | +10.5 |
| CANNON PLANNED TARGET | 29 | 29 | 2 | 0.67 | -157 | -78.5 |
| CHARGE NOW FIRST | 8 | 8 | 2 | 0.67 | -133 | -66.6 |
| EDGE GIVE GROUND | 2 | 2 | 2 | 0.67 | +72 | +36.1 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +125 | +62.4 |
| ONE FIGHT FORMULA | 33 | 18 | 2 | 0.67 | +11 | +5.4 |
| PROMISE SHOT AWAY | 2 | 2 | 2 | 0.67 | -9 | -4.5 |
| REDIRECT FOR A FRIEND IN REACH | 4 | 4 | 2 | 0.67 | +0 | +0.0 |
| RESERVE FALL BACK | 2 | 2 | 2 | 0.67 | +100 | +50.1 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHO HITS BACK | 2 | 2 | 2 | 0.67 | +277 | +138.7 |
| WHOLE FIGHT DANGER | 18 | 17 | 2 | 0.67 | +246 | +122.9 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +5 | +5.1 |
| BOMBING RUN | 1 | 1 | 1 | 0.33 | +24 | +23.6 |
| CASTS FROM BEHIND | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FALLS SHORT | 63 | 54 | 1 | 0.33 | +5 | +5.1 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| HIS CHARGE DENIED | 1 | 1 | 1 | 0.33 | +3 | +3.0 |
| HIS MOVE AND SHOT | 43 | 42 | 1 | 0.33 | +3 | +3.1 |
| JOINT CHARGE NOW | 1 | 1 | 1 | 0.33 | -36 | -36.2 |
| MISSILES NEXT TURN | 64 | 43 | 1 | 0.33 | +19 | +19.5 |
| NO DOUBLE ROUNDS | 10 | 9 | 1 | 0.33 | +61 | +61.0 |
| ONE JOINT FIGURE | 1 | 1 | 1 | 0.33 | +11 | +11.2 |
| ONE OBJECTIVE FORMULA | 19 | 11 | 1 | 0.33 | +10 | +10.3 |
| ONE PROMISE A TARGET | 1 | 1 | 1 | 0.33 | -95 | -94.8 |
| PROMISE KNOWS THE FIGHT | 2 | 1 | 1 | 0.33 | -1 | -0.6 |
| REFUSING RETIRES | 1 | 1 | 1 | 0.33 | -5 | -5.2 |
| RISK BY ARC | 13 | 12 | 1 | 0.33 | +3 | +3.0 |
| SECOND LOOK | 1 | 1 | 1 | 0.33 | +57 | +57.1 |
| SHOTS IN THE MOVE | 55 | 33 | 1 | 0.33 | +9 | +9.1 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +5 | +5.4 |
| THE ROW IN ITS ORDER | 15 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHOLE FIGHT GAIN | 1 | 1 | 1 | 0.33 | +11 | +11.2 |
| BACKUP TARGETS | 2 | 2 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 3 | trace | - | - | - | - |
| CLOSES ON WHAT IT BEATS | 51 | 49 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 5 | not checked | - | - | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| EXACT ROUND | 7 | 7 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 10 | 9 | 0 | 0.00 | - | - |
| FIGHT TO THE END | 6 | 5 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 37 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 8 | 7 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 3 | 3 | 0 | 0.00 | - | - |
| GIVES UP | 1 | 1 | 0 | 0.00 | - | - |
| GUN MASK | 18 | 15 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 4 | 3 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 58 | 51 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 36 | 35 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 31 | 24 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 29 | 28 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 19 | 19 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 43 | 41 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 7 | 7 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 77 | 76 | 0 | 0.00 | - | - |
| HONEST WORTH | 12 | 11 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 10 | 9 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 7 | 6 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 18 | 18 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 2 | 1 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 1 | not checked | - | - | - | - |
| MOVE SPELL SPOT | 3 | not checked | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 4 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| ONE ROUTE | 2 | 1 | 0 | 0.00 | - | - |
| OPENS A LANE | 2 | 2 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 3 | 2 | 0 | 0.00 | - | - |
| PLAN RESULT | 227 | trace | - | - | - | - |
| REAL GROUND | 2 | 1 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 2 | 2 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 3 | 3 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 15 | 15 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 2 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 4 | 3 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 6 | 6 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 2 | not checked | - | - | - | - |
| SHOOTER COUNTED ONCE | 4 | 4 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 51 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL WORTH | 5 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 42 | 37 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 8 | 7 | 0 | 0.00 | - | - |
| STANDS STILL | 155 | 152 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 3 | 3 | 0 | 0.00 | - | - |
| SURE REACH TOGETHER | 4 | 4 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE PROMISE ADDS | 4 | 2 | 0 | 0.00 | - | - |
| THE PROMISED MOVE | 4 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 16 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 1 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 9 | not checked | - | - | - | - |
| THE TABLE BINDS | 226 | not checked | - | - | - | - |
| WAITS AGAIN | 14 | 12 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 10 | 10 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p7

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 7.67 | 5.67 | 68.4 |
| PROMISE BY ITS OWN SUM | rule | 7.33 | 1.33 | 65.5 |
| ARMY TABLE | rule | 2.33 | 6.00 | 109.2 |
| RULE SWITCHED OFF | gate | 1.67 | - | 32.6 |
| MARCH OF THE TABLE | rule | 1.33 | - | 71.5 |
| PROMISE READS THE TABLE | rule | 1.00 | - | 29.2 |
| CHARGE NOW FIRST | rule | 0.33 | 0.33 | 66.6 |
| PROMISE SHOT AWAY | rule | 0.67 | - | 4.5 |
| AFTERMATH BAND | gate | - | 0.33 | 0.7 |
| CANNON PLANNED TARGET | rule | 0.33 | - | 156.9 |
| HOLDER ASSIGNMENT | rule | 0.33 | - | 52.5 |
| JOINT CHARGE NOW | rule | 0.33 | - | 36.2 |
| ONE PROMISE A TARGET | rule | 0.33 | - | 94.8 |
| PROMISE KNOWS THE FIGHT | rule | - | 0.33 | 0.6 |
| REFUSING RETIRES | rule | - | 0.33 | 5.2 |

### Plans: ccut-c940641-p7

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.3 | 70% | 521 | 452 | 87% |
| Mine | move | 20.0 | 97% | 1993 | 0 | 0% |
| Mine | shoot | 13.0 | 72% | 558 | 859 | 154% |
| Opponent | charge | 1.0 | 67% | 135 | 174 | 129% |
| Opponent | join | 1.3 | 100% | 54 | 0 | 0% |
| Opponent | move | 35.0 | 90% | 2059 | 0 | 0% |
| Opponent | shoot | 0.7 | 50% | 19 | 8 | 41% |
| Opponent | support | 1.3 | 75% | 158 | 0 | 0% |

### Battle groups: ccut-c940641-p7

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 1.0 | 100% | 100% | 0% | - | 67% | 0% | 0% | 33% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p7

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 9 | 59 (9) | 59 | 0 | 23 | 11% | 2.9 | 81 (2) | 62 (6) | - | 27 (4) | 94 (4) |
| Mine | Clean-up | 2 | 90 (2) | 0 | 90 | 0 | 0% | 1.5 | 0 (1) | 170 (1) | - | 90 (2) | - |
| Mine | Fast Hammer | 4 | 9 (4) | 0 | 9 | 50 | 25% | 2.3 | 0 (2) | 13 (2) | - | 14 (3) | 0 (1) |
| Mine | Holder | 1 | 35 (1) | 0 | 35 | 0 | 0% | 1.0 | 35 (1) | - | - | 35 (1) | - |
| Mine | Shooter | 4 | 205 (4) | 143 | 62 | 0 | 0% | 1.8 | 174 (3) | 341 (1) | - | 205 (4) | - |
| Mine | War machine | 6 | 18 (6) | 18 | 0 | 50 | 0% | 1.0 | 0 (2) | 54 (2) | 0 (2) | 0 (1) | 21 (5) |
| Mine | Wizard | 3 | 28 (3) | 28 | 0 | 0 | 0% | 2.7 | 59 (2) | 0 (1) | - | 28 (3) | - |
| Opponent | Chaff | 2 | 150 (2) | 0 | 150 | 100 | 0% | 4.0 | - | 300 (1) | 0 (1) | 150 (2) | - |
| Opponent | Character | 10 | 38 (10) | 38 | 0 | 41 | 50% | 3.0 | 0 (3) | 66 (5) | 50 (2) | 73 (5) | 0 (5) |
| Opponent | Fast Hammer | 9 | 33 (9) | 0 | 33 | 68 | 56% | 2.8 | 30 (2) | 34 (7) | - | 17 (5) | 55 (4) |
| Opponent | Hammer | 3 | 105 (3) | 105 | 0 | 0 | 33% | 3.5 | 0 (2) | 282 (1) | - | 0 (2) | 282 (1) |
| Opponent | Holder | 5 | 18 (5) | 0 | 18 | 0 | 80% | 6.0 | 0 (1) | 0 (2) | 46 (2) | 34 (2) | 0 (3) |
| Opponent | Shooter | 1 | 0 (1) | 0 | 0 | 100 | 0% | 1.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | - | - | 0 (1) | - | 0 (1) |

### Charged fights: ccut-c940641-p7

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 3 | 553 | 267 | 2.3 | 1.0 | 114 | 29 | +85 | 4 of 7 | 5 of 7 | - | +85 |
| Opponent | High Elf Realms | 1 | 0 | 165 | 1.0 | 1.0 | 165 | 0 | +165 | 0 of 1 | 1 of 1 | - | +165 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| **Opponent** | all armies | 3 | 0 | 55 | 0.7 | 1.0 | 82 | 0 | +82 | 1 of 2 | 1 of 2 | - | +82 |

### Effective charges: ccut-c940641-p7

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 7 | 0 | 0 | 2 (net +69) | 0 | 2 (net +60) | 2 (net +98) | 1 | 33% (2 of 6) |
| Opponent | High Elf Realms | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +165) | 0 | 0% (0 of 1) |
| Opponent | Warriors of Chaos | 1 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |

### Charged fights, damage counted: ccut-c940641-p7

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Effective (55-75%) | 2 | 270 | 314 | +69 | 172 | 102 | +69 | +25.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 306 | 332 | +98 | 98 | 0 | +98 | +31.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 211 | 60 | +60 | 107 | 0 | +107 | +50.9 |
| Mine | No odds | 1 | 233 | 143 | +143 | 143 | 39 | +104 | +44.7 |
| Mine | All fights | 7 | 258 | 222 | +85 | 128 | 35 | +93 | +36.1 |
| Opponent | Long shot (under 50%) | 1 | 392 | 358 | +0 | 0 | 196 | -196 | -50.0 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 489 | 165 | +165 | 165 | 0 | +165 | +33.7 |
| Opponent | All fights | 2 | 440 | 262 | +82 | 82 | 98 | -16 | -3.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p7 | move | 18 | 4 (22%) | 3 (17%) | 0 (0%) | 14 (78%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1224 |
| Clockwork Compass | Mine | L1224 |
| Elixir of Power | Mine | L1114, L1131 |
| Invocation of Nehek | Opponent | L1224 |
| Opal Amulet | Opponent | L1114 |
| Ring of Doom | Mine | L1114, L1131, L1224 |
| Ring of Doom | Opponent | L1131 |
| Ring of Jet | Mine | L1114, L1131, L1224 |

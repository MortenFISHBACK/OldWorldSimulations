# Doctrine scorecard: ccut-c940641-p15

### Scorecard: ccut-c940641-p15

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0409 | 1 | 1 | Mine | no | 11 | 3 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 399 |
| L0425 | 5 | 1 | Mine | yes | - | 3 | 3 | 5 | 0 | 0 | 0 | 310 |
| L0425 | 5 | 1 | Opponent | no | - | 4 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0512 | 2 | 1 | Mine | - | - | - | 0 | 2 | 0 | 0 | 0 | 473 |
| L0512 | 2 | 1 | Opponent | - | - | 3 | 1 | 0 | 1 | 0 | 0 | 0 |
| **Average** | | | Mine | 50% | 11.0 | 3.0 | 1.0 | 3.0 | 0.0 | 0.0 | 0.0 | 261.0 |
| **Average** | | | Opponent | 0% | 0.0 | 3.5 | 1.3 | 2.0 | 0.3 | 0.0 | 0.0 | 133.0 |

### KPIs: ccut-c940641-p15

Rules off - Mine only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 13) | 0% (0 of 15) | 0% (0 of 28) |
| Winner chose to follow up after the loser gave ground |  | 100% (4 of 4); on the table 100% | - | 100% (4 of 4); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | - | 0% (0 of 1); on the table 0% | 0% (0 of 1); on the table 0% |
| Winner chose to pursue after the loser fled |  | - | 50% (1 of 2); on the table 50% | 50% (1 of 2); on the table 50% |
| Winner chose to follow up or pursue (all three) |  | 100% (4 of 4); on the table 100% | 33% (1 of 3); on the table 33% | 71% (5 of 7); on the table 71% |
| Magic missiles tried each own turn | 50%+ | 33% (4 of 12) | 64% (23 of 36) | 56% (27 of 48) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 50% (4 of 8) | 64% (23 of 36) | 61% (27 of 44) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 68% (4082 of 5998) | 66% (3953 of 5998) | 67% (8035 of 11996) |
|   infantry points that never fought | lower | 83% (1185 of 1424) | 94% (1119 of 1187) | 88% (2304 of 2611) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% (14 of 23) | 81% (22 of 27) | 72% (36 of 50) |
| Bound items with a magic missile used (at least once a game) |  | 0.0 uses a game | 100% (3 of 3); 3.0 uses a game | 100% (3 of 3); 1.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 58% (2975 of 5120) | 86% (4674 of 5442) | 72% (7649 of 10562) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 0.3 (12%) | 2.7 (62%) | 3.0 (43%) |
| MARCHED: its unit marched | 1.0 (38%) | 1.7 (38%) | 2.7 (38%) |
| IN COMBAT: engaged in combat | 0.7 (25%) | 0.0 (0%) | 0.7 (10%) |
| GONE: slain | 0.7 (25%) | 0.0 (0%) | 0.7 (10%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 6.3 | 2.0 | 1.3 | 9.0 | 0.7 | 1.0 |
| not cast | 3.7 | 4.0 | 4.7 | 7.0 | 1.3 | 19.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.7 (14%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 3.7 (92%) | 2.7 (57%) | 3.0 (43%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.7 (38%) | 0.3 (25%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.7 (18%) | 0.0 (0%) | 1.3 (29%) | 0.7 (10%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (75%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (5%) |
| GONE: slain | 0.7 (18%) | 0.0 (0%) | 0.7 (14%) | 0.7 (10%) | 0.0 (0%) | 2.0 (11%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.3 (8%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.3 (64%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.3 (70%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.3 a game | 0.7 a game |
| stood (cast and not dispelled) | - | 75% (3 of 4) | 75% (3 of 4) |
| the unit moved after it | - | 100% (3 of 3) | 100% (3 of 3) |
| it charged on its next turn | - | 0% (0 of 3) | 0% (0 of 3) |
| the enemy charged it first | - | 0% (0 of 3) | 0% (0 of 3) |
| it fought by the end of its next turn | - | 33% (1 of 3) | 33% (1 of 3) |
| it moved out of a charge the enemy had planned (not charged first) | - | 33% (1 of 3) | 33% (1 of 3) |
| none of these (no charge, no fight, no charge escaped) | - | 67% (2 of 3) | 67% (2 of 3) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (66 of 101) | 61% (41 of 67) | 64% (107 of 168) |
|   cavalry | 33% (4 of 12) | - | 33% (4 of 12) |
|   character | 96% (23 of 24) | 100% (3 of 3) | 96% (26 of 27) |
|   chariot | 21% (5 of 24) | 50% (2 of 4) | 25% (7 of 28) |
|   infantry | 83% (10 of 12) | 52% (14 of 27) | 62% (24 of 39) |
|   monster | - | 67% (4 of 6) | 67% (4 of 6) |
|   war machine | 83% (24 of 29) | 67% (18 of 27) | 75% (42 of 56) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 3.0 (26%) | 1.3 (15%) | 4.3 (21%) |
| MOVED: a war machine that moved | 0.3 (3%) | 1.0 (12%) | 1.3 (7%) |
| NO TARGET IN RANGE | 6.0 (51%) | 1.0 (12%) | 7.0 (34%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 1.3 (15%) | 1.3 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.7 (14%) | 2.0 (23%) | 3.7 (18%) |
| SHELTERED: the target was sheltered | 0.7 (6%) | 1.7 (19%) | 2.3 (11%) |
| OTHER BAR | 0.0 (0%) | 0.3 (4%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 1.3 | 0.3 | 75% | 0.4 pts | 1 pts |
| character | 8.7 | 1.7 | 81% | 7.0 pts | 60 pts |
| chariot | 2.3 | 5.3 | 43% | 21.8 pts | 51 pts |
| infantry | 11.3 | 2.3 | 82% | 6.8 pts | 77 pts |
| monster | 2.7 | 2.0 | 25% | 48.4 pts | 129 pts |
| war machine | 14.3 | 8.7 | 72% | 16.5 pts | 236 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 2.0 | 2.0 | 2.0 |
| Charges that made contact a game | 1.7 | 1.3 | 1.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 1.00 contact (2 units) | 0.00 declared, 0.00 contact (3 units) | 0.40 declared, 0.40 contact (5 units) |
|   per unit a game, units carrying another wizard (or one alone) | - | 1.00 declared, 0.50 contact (2 units) | 1.00 declared, 0.50 contact (2 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.18 declared, 0.14 contact (22 units) | 0.24 declared, 0.18 contact (17 units) | 0.21 declared, 0.15 contact (39 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (2 of 4) | 100% (2 of 2) | - | 67% (4 of 6) |
| Character in a unit | 80% (4 of 5) | 50% (1 of 2) | - | 71% (5 of 7) |
| Character on its own | 100% (2 of 2) | 80% (4 of 5) | 75% (3 of 4) | 82% (9 of 11) |
| Chariot | - | 80% (4 of 5) | - | 80% (4 of 5) |
| Infantry | 67% (8 of 12) | 67% (2 of 3) | - | 67% (10 of 15) |
| Monstrous | - | 0% (0 of 1) | - | 0% (0 of 1) |
| War Machines | 80% (4 of 5) | - | - | 80% (4 of 5) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Chaos Dwarfs | 2 | 100% (4 of 4); on the table 100% | 33% (4 of 12) | 71% | 62% (10 of 16) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Dwarfen Mountain Holds | 1 | - | - | 62% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 1 | - | 58% (7 of 12) | 74% | 75% (9 of 12) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Grand Cathay | 1 | - | 61% (11 of 18) | 90% | 78% (7 of 9) | 100% (3 of 3); 9.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Vampire Counts | 1 | 33% (1 of 3); on the table 33% | 83% (5 of 6) | 34% | 100% (6 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p15, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (4) | 80% (4) | 89% (8) |
| ...free all their last turn and able to turn (per game) | 0.33 | 0.00 | 0.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 1.00 | 1.33 |
| ...with the charger already in that arc before they moved (per game) | 0.00 | 0.00 | 0.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.33 | 0.33 |

### Quality by phase: ccut-c940641-p15

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.7 | 4.0 |
| Strategy | Charge objectives carried out (made contact) | 83% (5 of 6) | 50% (3 of 6) |
| Strategy | Shoot objectives carried out (shot that target) | 26% (10 of 38) | 35% (16 of 46) |
| Strategy | Support requests answered (helper made contact too) | - | 100% (1 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | - | 50% (1 of 2) |
| Strategy | Joined characters whose unit fought | 60% (3 of 5) | 17% (1 of 6) |
| Strategy | Lone characters that fought | 50% (3 of 6) | 50% (4 of 8) |
| Movement | Charges halted short of contact | 0.3 | 0.7 |
| Movement | Idle units | 3.0 | 2.0 |
| Movement | Points that never moved of their own | 261.0 | 133.0 |
| Movement | Fights charged into per game | 1.7 | 1.3 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 5, net +134 | 0 of 3 |
| Movement | Charges with odds: sweet spot (55-75%) | 0 of 5 | 1 of 3, net +0 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 0 of 5 | 0 of 3 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 5, net +125 | 1 of 3, net +0 |
| Shooting | Shots by shooting units (incl. breath weapons) | 14.0 | 7.7 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (21 of 42) | 57% (13 of 23) |
| Shooting | Points destroyed by shooting units | 232.0 | 193.3 |
| Shooting | War machine shots | 8.0 | 6.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 71% (17 of 24) | 21% (4 of 19) |
| Shooting | Points destroyed by war machines | 0.0 | 53.3 |
| Magic | Magic missiles cast | 1.0 | 4.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 67% (2 of 3) | 58% (7 of 12) |
| Magic | Wounds caused by magic missiles | 3.7 | 3.3 |
| Magic | Wounds caused by other spells | - | 0.3 |
| Magic | Points destroyed by magic (all spells) | 84.7 | 39.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 2.3 / 0.0 / 0.0 / 0.0 | 2.0 / 0.7 / 0.7 / 0.0 |
| Combat | Points destroyed in combat | 261.0 | 0.0 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +157 | +12 |
| Combat | Net per 100 charger points, damage counted | +39.6 | +5.9 |
| Combat | First round won (charged fights) | 80% | 50% |
| Combat | Net points per charged fight | +157 | +0 |
| Combat | Net points per supported fight / lone fight | - / +157 | - / +0 |
| Combat | Charged fights on a top-3 enemy unit | 3 of 5 | 4 of 4 |
| Game | Points lost | 252.3 | 511.0 |
| Game | VP from objectives | 876.7 | 340.0 |
| Game | Lone holders (player turns) | 11.0 | 0.0 |

- Mine won / drew / lost: 3 / 0 / 0 of 3 ended games (of 3); mean margin (Mine - Opponent) +812 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 763
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ccut-c940641-p15

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ARMY TABLE | 19.0 | +442.0 | 0.0 | 43.3 | 17.0 | -145.8 | 0.0 | 30.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 31.7 | 3.7 | +0.0 | 0.0 | 41.7 |
| ASSAILMENT BY POINTS | - | - | - | - | 0.3 | +0.5 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.3 | +3.7 | 0.0 | 0.0 | 0.3 | +0.6 | 0.0 | 0.0 |
| BLOWS WHERE AIMED | - | - | - | - | 0.3 | -4.3 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 7.7 | +45.8 | 289.3 | 31.7 | 5.3 | +147.6 | 85.0 | 83.3 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 1.3 | +96.8 | 346.0 | 386.7 | 9.7 | +121.2 | 340.7 | 578.7 |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 0.7 | +4.9 | 0.0 | 30.0 |
| CHAFF PASSED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | 1.0 | +47.7 | 0.0 | 0.0 | - | - | - | - |
| CHARACTER GUNS | 2.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| CHARGE LOSSES | 15.7 | -476.1 | 0.0 | 271.3 | 9.3 | -278.3 | 0.0 | 144.7 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW FIRST | 0.7 | +0.0 | 88.3 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CLOSES ON WHAT IT BEATS | 6.3 | +0.0 | 0.0 | 0.0 | 7.7 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | - | - | - | - | 0.7 | +23.5 | 0.0 | 0.0 |
| COVER ONCE | 11.7 | -1590.8 | 0.0 | 31.7 | 7.3 | -551.0 | 0.0 | 84.7 |
| DENIED BY THE FIGHT | - | - | - | - | 0.3 | -0.7 | 0.0 | 0.0 |
| DEPLOY BY FIGURES | 8.7 | +61.0 | 0.0 | 0.0 | 6.3 | +5.3 | 0.0 | 0.0 |
| DUEL STOPS AT THE KILL | 0.7 | -77.2 | 0.0 | 0.0 | - | - | - | - |
| EXACT ROUND | 1.3 | +17.3 | 171.7 | 0.0 | 1.7 | +17.6 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 1.7 | +0.0 | 130.0 | 0.0 | 1.7 | +0.2 | 0.0 | 0.0 |
| FALLBACK BY WORTH | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| FALLS SHORT | 7.7 | +93.1 | 0.0 | 386.7 | 17.3 | +206.5 | 0.0 | 518.7 |
| FEATURE BUFFS | 0.7 | +2.1 | 0.0 | 0.0 | - | - | - | - |
| FIGHT LIFT | 0.3 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 0.7 | +85.1 | 88.3 | 0.0 | 1.3 | -9.0 | 0.0 | 0.0 |
| FIVE ACTION | 105.0 | +6526.8 | 1096.3 | 958.0 | 91.0 | +3559.1 | 2057.3 | 1403.3 |
| FLANK NOT WEIGHED | 6.0 | +0.0 | 0.0 | 60.7 | 5.3 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 1.0 | +341.7 | 0.0 | 0.0 | - | - | - | - |
| FOUR ROUNDS | 2.0 | +569.5 | 171.7 | 0.0 | 2.0 | +116.4 | 0.0 | 0.0 |
| FREED FROM HIS FIGHT | 2.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| GIVES UP | 0.3 | -4.0 | 0.0 | 0.0 | 0.3 | -9.5 | 0.0 | 0.0 |
| GOAL WALK | 12.3 | +952.4 | 0.0 | 0.0 | 3.7 | +94.4 | 0.0 | 169.3 |
| GUN FIGURES | 0.7 | +1.7 | 15.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| GUN MASK | 1.3 | +64.9 | 0.0 | 0.0 | 1.7 | +65.9 | 0.0 | 0.0 |
| HARD STAY DROPPED | 2.0 | +0.0 | 0.0 | 193.3 | 2.0 | +0.0 | 0.0 | 0.0 |
| HE REFORMS ONCE FREED | 1.3 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS CHARGE BY HIS RUN | 8.3 | +0.0 | 0.0 | 78.0 | 3.3 | +0.0 | 0.0 | 72.3 |
| HIS CHARGE DENIED | - | - | - | - | 0.7 | +107.6 | 0.0 | 0.0 |
| HIS CHARGE LIST | 7.7 | +0.0 | 0.0 | 0.0 | 8.7 | +0.0 | 0.0 | 169.3 |
| HIS LEGAL MOVES | 3.0 | +0.0 | 0.0 | 193.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 3.0 | -16.5 | 0.0 | 0.0 | 1.3 | -15.4 | 0.0 | 0.0 |
| HIS MOVE AS HE DECIDES | 37.7 | +11.0 | 622.0 | 0.0 | - | - | - | - |
| HIS MOVE WHY | - | - | - | - | 25.7 | +0.0 | 0.0 | 633.3 |
| HIS ONE MOVE | 23.7 | -53.8 | 0.0 | 0.0 | - | - | - | - |
| HIS ONE QUARTER | 4.3 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 1.7 | +0.0 | 0.0 | 193.3 | 1.3 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 50.0 | +3761.6 | 0.0 | 508.0 | 45.3 | +3056.4 | 0.0 | 628.0 |
| HIS SHOTS BY HIS RUN | 33.7 | +711.0 | 0.0 | 508.0 | 22.0 | +619.5 | 0.0 | 289.3 |
| HIS TURN DENIED | 1.0 | +27.0 | 171.7 | 0.0 | - | - | - | - |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 15.3 | +0.0 | 0.0 | 0.0 | 9.0 | +0.0 | 0.0 | 0.0 |
| HOLDER ASSIGNMENT | 9.3 | +1221.6 | 0.0 | 0.0 | 7.3 | +547.1 | 0.0 | 0.0 |
| HOLDS AMBUSHERS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 2.0 | -189.2 | 171.7 | 0.0 | 1.7 | -76.9 | 0.0 | 0.0 |
| HUNT IN PAIRS | 1.0 | +43.0 | 0.0 | 0.0 | 3.3 | +491.8 | 0.0 | 289.3 |
| IDLE COST | 5.3 | -94.5 | 0.0 | 0.0 | 11.3 | -180.2 | 0.0 | 401.3 |
| JOINT CHARGE NOW | - | - | - | - | 0.7 | +171.0 | 0.0 | 0.0 |
| KEPT FROM ITS LAST STOP | 2.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +64.9 | 0.0 | 0.0 | - | - | - | - |
| LEGAL CHARGES ONLY | 2.7 | +0.0 | 88.3 | 0.0 | 2.3 | +0.0 | 0.0 | 176.7 |
| LONE WIZARD KEPT IN | - | - | - | - | 0.7 | +30.1 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 0.7 | -1.5 | 88.3 | 0.0 | 2.0 | +7.9 | 0.0 | 0.0 |
| MANOEUVRE | 1.7 | +5.3 | 0.0 | 0.0 | 3.7 | -23.5 | 0.0 | 0.0 |
| MARCH BY THE SUM | 0.3 | +14.7 | 0.0 | 0.0 | - | - | - | - |
| MARCH CHECK | 0.3 | +23.1 | 0.0 | 0.0 | 3.0 | +188.9 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.7 | +15.1 | 0.0 | 0.0 | 1.0 | +42.5 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.7 | +17.7 | 0.0 | 0.0 | 1.0 | +5.6 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.3 | +99.9 | 0.0 | 408.3 | 5.7 | +168.0 | 0.0 | 144.7 |
| MEETS IN TIME | 5.3 | +153.6 | 0.0 | 0.0 | 2.3 | +33.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 1.3 | +74.3 | 0.0 | 386.7 | 11.7 | +124.2 | 0.0 | 289.3 |
| MISSILES NEXT TURN | 2.3 | +57.5 | 0.0 | 386.7 | 12.0 | +108.9 | 0.0 | 144.7 |
| MOVE ORDER | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 2.7 | +122.1 | 0.0 | 386.7 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 1.0 | -65.3 | 0.0 | 0.0 | - | - | - | - |
| MOVE TO CHARGE COMPUTED | 2.3 | +188.5 | 0.0 | 193.3 | 2.0 | +171.6 | 0.0 | 72.3 |
| NEARER NOT NEEDED | 9.3 | +396.1 | 0.0 | 0.0 | 10.7 | +476.1 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 1.7 | +143.8 | 0.0 | 0.0 | 1.0 | +31.1 | 0.0 | 72.3 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -10.0 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 2.0 | -80.6 | 171.7 | 0.0 | 1.0 | -66.7 | 0.0 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NOT TURNED | - | - | - | - | 0.3 | +5.9 | 0.0 | 0.0 |
| OFF BEST | 6.0 | -345.3 | 0.0 | 31.7 | 6.3 | -391.3 | 0.0 | 114.0 |
| OGRE LOADER SECOND SHOT | - | - | - | - | 2.3 | +36.2 | 0.0 | 0.0 |
| ONE CHECK AFTER THE LAST CHANGE | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 3.0 | -87.0 | 0.0 | 386.7 | 4.7 | -74.1 | 0.0 | 217.0 |
| ONE OBJECTIVE FORMULA | 3.0 | -76.7 | 0.0 | 0.0 | 3.3 | -205.4 | 0.0 | 0.0 |
| ONE ROUTE | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| OPENS A LANE | - | - | - | - | 2.0 | +46.7 | 150.0 | 0.0 |
| OVERRUNS AWAY | 0.3 | +4.0 | 41.7 | 0.0 | 0.7 | +1.6 | 0.0 | 0.0 |
| PATHS CROSS | 0.3 | +19.0 | 0.0 | 0.0 | 0.7 | -2.2 | 0.0 | 0.0 |
| PLAN RESULT | 46.0 | +826.9 | 667.0 | 571.3 | 42.0 | +1114.6 | 883.0 | 788.7 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 4.3 | -72.1 | 0.0 | 193.3 | 5.0 | -157.4 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | 0.3 | +0.0 | 0.0 | 193.3 | 1.7 | +0.0 | 0.0 | 0.0 |
| QUARTER ODDS | 19.0 | +2064.3 | 83.3 | 0.0 | 14.0 | +1070.2 | 0.0 | 83.3 |
| REAL GROUND | 1.3 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 1.0 | +199.1 | 0.0 | 21.7 | 1.7 | +148.2 | 0.0 | 15.0 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 1.3 | +0.0 | 0.0 | 15.0 |
| REFORMS TO MEET IT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| REFUSING RETIRES | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +20.8 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 1.7 | -71.6 | 171.7 | 0.0 | 2.0 | -83.1 | 0.0 | 0.0 |
| RISK ON THE WAY | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ROUNDS AFTER TERROR | 0.7 | -11.1 | 83.3 | 0.0 | - | - | - | - |
| RUN DOWN | 0.7 | +0.0 | 83.3 | 0.0 | 1.7 | -20.4 | 0.0 | 0.0 |
| SCOUT SPOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 0.7 | -19.6 | 0.0 | 30.0 |
| SEARCH SPOT | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 4.7 | -248.6 | 0.0 | 217.0 |
| SET UP BY THE SET | 0.3 | +0.0 | 0.0 | 0.0 | 5.3 | +248.8 | 0.0 | 217.0 |
| SHOOTERS IN TWO RANKS | 0.7 | +1.3 | 0.0 | 0.0 | 0.3 | +0.7 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 13.3 | +0.0 | 0.0 | 225.0 | 14.0 | +0.0 | 0.0 | 387.7 |
| SHOOTS FROM THE BEST SPOT | 2.3 | +112.3 | 0.0 | 0.0 | 3.0 | +14.7 | 0.0 | 0.0 |
| SHOT OR CHARGE | - | - | - | - | 0.3 | -6.8 | 0.0 | 0.0 |
| SHOT RISK POINTS | 25.3 | +593.2 | 0.0 | 486.3 | 18.7 | -120.6 | 0.0 | 386.3 |
| SHOTS AFTER THE MOVES | 2.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 16.3 | +1114.1 | 0.0 | 31.7 | 17.0 | +543.3 | 0.0 | 83.3 |
| SPELL WORTH | 0.7 | +4.1 | 0.0 | 0.0 | 2.0 | +54.9 | 289.3 | 289.3 |
| SPOT AS THE GAME MOVES | 4.7 | +0.0 | 0.0 | 0.0 | 9.7 | +0.0 | 0.0 | 157.0 |
| STANDS FOR A REASON | 0.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 63.3 | 289.3 |
| STANDS STILL | 58.7 | +0.0 | 924.7 | 571.3 | 43.3 | +0.0 | 2057.3 | 817.7 |
| STAY WORTH | 24.7 | -153.4 | 635.3 | 386.7 | 30.0 | -56.5 | 1157.3 | 414.3 |
| STRIKE BY THE ODDS | 0.7 | +3.2 | 0.0 | 0.0 | - | - | - | - |
| STUBBORN BY POINTS | 0.3 | +34.1 | 0.0 | 0.0 | - | - | - | - |
| SUPPORT ADDS | 6.0 | +398.6 | 0.0 | 43.3 | 3.3 | +815.3 | 0.0 | 0.0 |
| SUPPORT NARROWED | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| SUPPORT WORKED OUT | 6.0 | +398.6 | 0.0 | 43.3 | 3.3 | +815.3 | 0.0 | 0.0 |
| SURE REACH TOGETHER | - | - | - | - | 1.3 | +33.6 | 0.0 | 72.3 |
| THE DEARER SUM KEEPS ITS PLAN | 1.0 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 2.7 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 0.0 |
| THE ROW KEEPS ITS WAY | 2.0 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| THE ROW READS HIS LAST RUN | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE STEP BACK IS MADE | 1.7 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 49.7 | +0.0 | 0.0 | 479.0 | 42.0 | +0.0 | 0.0 | 716.7 |
| TIED UP BY THE SUM | 0.7 | +59.1 | 41.7 | 0.0 | - | - | - | - |
| TIME ON OUR SIDE | 36.7 | +411.1 | 0.0 | 138.7 | 15.7 | +165.9 | 0.0 | 0.0 |
| WAITS AGAIN | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| WAR ENGINE JOBS | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WHAT THE JOINER ADDS | - | - | - | - | 1.3 | +2.9 | 0.0 | 0.0 |
| WHOLE FIGHT | - | - | - | - | 0.7 | +17.5 | 0.0 | 0.0 |
| WHOLE FIGHT DANGER | 2.7 | -126.0 | 0.0 | 0.0 | 0.7 | -19.1 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 3.7 | +76.3 | 0.0 | 0.0 | - | - | - | - |

### Rule changes: ccut-c940641-p15

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 113 | 113 | 80 | 26.67 | +0 | +0.0 |
| ARMY TABLE | 108 | 108 | 77 | 25.67 | +1603 | +20.8 |
| HIS SHOT LIST | 286 | 271 | 59 | 19.67 | +1520 | +25.8 |
| HIS MOVE WHY | 77 | 77 | 55 | 18.33 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 50 | 50 | 48 | 16.00 | +4173 | +86.9 |
| HIS SHOTS BY HIS RUN | 167 | 152 | 41 | 13.67 | +469 | +11.4 |
| OFF BEST | 37 | 37 | 37 | 12.33 | -2210 | -59.7 |
| CAST JOB | 33 | 33 | 29 | 9.67 | +163 | +5.6 |
| SHOT RISK POINTS | 132 | 125 | 27 | 9.00 | +622 | +23.0 |
| THE TABLE AGAIN | 36 | 36 | 25 | 8.33 | +0 | +0.0 |
| DEPLOY BY FIGURES | 45 | 45 | 22 | 7.33 | +460 | +20.9 |
| HIS ONE MOVE | 71 | 69 | 21 | 7.00 | +0 | +0.0 |
| TIME ON OUR SIDE | 157 | 147 | 21 | 7.00 | +38 | +1.8 |
| ARTILLERY RE-ROLL WEIGHED | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| LEGAL CHARGES ONLY | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| COVER ONCE | 57 | 48 | 13 | 4.33 | +365 | +28.1 |
| HARD STAY DROPPED | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| SUPPORT ADDS | 28 | 27 | 11 | 3.67 | +139 | +12.6 |
| SUPPORT WORKED OUT | 28 | 27 | 11 | 3.67 | +139 | +12.6 |
| MEETS IN TIME | 23 | 23 | 10 | 3.33 | +383 | +38.3 |
| QUARTER ODDS | 99 | 91 | 10 | 3.33 | +647 | +64.7 |
| GOAL WALK | 48 | 47 | 9 | 3.00 | +417 | +46.4 |
| MARCH CHECK | 10 | 10 | 9 | 3.00 | +253 | +28.1 |
| PROMISE BY ITS OWN SUM | 28 | 28 | 9 | 3.00 | -688 | -76.5 |
| SET UP BY THE SET | 17 | 17 | 9 | 3.00 | +464 | +51.5 |
| FIVE ACTION | 588 | 566 | 8 | 2.67 | +261 | +32.7 |
| CHARGE LOSSES | 75 | 69 | 7 | 2.33 | +146 | +20.9 |
| FOUR ROUNDS | 12 | 12 | 7 | 2.33 | +1155 | +165.1 |
| OGRE LOADER SECOND SHOT | 7 | 7 | 7 | 2.33 | +108 | +15.5 |
| SHOOTS FROM THE BEST SPOT | 16 | 16 | 7 | 2.33 | +66 | +9.4 |
| STAY WORTH | 164 | 151 | 7 | 2.33 | +33 | +4.8 |
| ADVANCE LANE KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| HUNT IN PAIRS | 13 | 11 | 5 | 1.67 | +276 | +55.3 |
| IDLE COST | 50 | 41 | 5 | 1.67 | +16 | +3.2 |
| MANOEUVRE | 16 | 16 | 5 | 1.67 | +59 | +11.9 |
| MARCH OF THE TABLE | 5 | 5 | 5 | 1.67 | -173 | -34.5 |
| MOVE ORDER | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| NEARER NOT NEEDED | 60 | 60 | 5 | 1.67 | +214 | +42.8 |
| CANNON SIGHT KEPT | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| LANE BY FIGURES | 4 | 4 | 4 | 1.33 | +195 | +48.6 |
| MOVE TO CHARGE COMPUTED | 13 | 7 | 4 | 1.33 | +260 | +64.9 |
| REDIRECT FOR A FRIEND IN REACH | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| SHOTS IN THE MOVE | 100 | 78 | 4 | 1.33 | +215 | +53.8 |
| THE RISK READS HIS RUN | 18 | 18 | 4 | 1.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 3 | 3 | 3 | 1.00 | +143 | +47.7 |
| FOLLOW UP WEIGHED | 3 | 3 | 3 | 1.00 | +1025 | +341.7 |
| MAX FOR POSITIONING | 24 | 21 | 3 | 1.00 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 8 | 6 | 3 | 1.00 | +247 | +82.5 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +50 | +16.8 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +6 | +2.0 |
| SHOTS AFTER THE MOVES | 19 | 19 | 3 | 1.00 | +0 | +0.0 |
| CANNON PLANNED TARGET | 39 | 39 | 2 | 0.67 | +0 | +0.0 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| CHAFF IN THE MOVE | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FALLS SHORT | 75 | 66 | 2 | 0.67 | +26 | +12.8 |
| HOLDS AMBUSHERS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| HONEST WORTH | 11 | 11 | 2 | 0.67 | +100 | +49.8 |
| JOINT CHARGE NOW | 2 | 2 | 2 | 0.67 | +513 | +256.4 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +90 | +45.1 |
| MISSILES IN THE MOVE | 39 | 29 | 2 | 0.67 | +160 | +80.0 |
| REDIRECT COUNTER | 8 | 5 | 2 | 0.67 | +423 | +211.7 |
| REFUSING RETIRES | 3 | 3 | 2 | 0.67 | -61 | -30.4 |
| SCOUT WAITS | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| STRIKE BY THE ODDS | 2 | 2 | 2 | 0.67 | +10 | +4.8 |
| THE ROW IN ITS ORDER | 15 | 2 | 2 | 0.67 | +0 | +0.0 |
| TIED UP BY THE SUM | 2 | 2 | 2 | 0.67 | +79 | +39.5 |
| WOUNDS ON THE RANKS | 11 | 10 | 2 | 0.67 | +21 | +10.5 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +2 | +1.6 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHAFF PASSED | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -3 | -3.2 |
| FIGHT TO THE END | 6 | 6 | 1 | 0.33 | +40 | +40.5 |
| HIS TURN DENIED | 3 | 3 | 1 | 0.33 | +2 | +2.1 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +44 | +44.1 |
| ONE OBJECTIVE FORMULA | 19 | 14 | 1 | 0.33 | +41 | +41.4 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +62 | +62.5 |
| RISK BY ARC | 11 | 11 | 1 | 0.33 | +36 | +36.1 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +102 | +102.3 |
| SURE REACH TOGETHER | 4 | 3 | 1 | 0.33 | +44 | +44.2 |
| BACKUP TARGETS | 2 | 1 | 0 | 0.00 | - | - |
| BLOWS WHERE AIMED | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 2 | trace | - | - | - | - |
| CHARACTER GUNS | 13 | 11 | 0 | 0.00 | - | - |
| CHARGE NOW FIRST | 3 | 3 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 42 | 41 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 2 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| DUEL STOPS AT THE KILL | 2 | 2 | 0 | 0.00 | - | - |
| EXACT ROUND | 9 | 9 | 0 | 0.00 | - | - |
| FALL BACK GOOD ORDER | 10 | 10 | 0 | 0.00 | - | - |
| FALLBACK BY WORTH | 1 | 1 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 2 | 2 | 0 | 0.00 | - | - |
| FIGHT LIFT | 1 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 34 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 12 | 10 | 0 | 0.00 | - | - |
| GIVES UP | 2 | 2 | 0 | 0.00 | - | - |
| GUN FIGURES | 3 | not checked | - | - | - | - |
| GUN MASK | 9 | 8 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 8 | 6 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 35 | 33 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 49 | 46 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 13 | 11 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 13 | 10 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 15 | 10 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 9 | 9 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 73 | 73 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 15 | 15 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 8 | 8 | 0 | 0.00 | - | - |
| MARCH OVER CASTS | 5 | 5 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 10 | 10 | 0 | 0.00 | - | - |
| MISSILES NEXT TURN | 43 | 34 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 8 | 5 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 3 | trace | - | - | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 9 | 9 | 0 | 0.00 | - | - |
| NO LATE CUT | 5 | 5 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 1 | 1 | 0 | 0.00 | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE FIGHT FORMULA | 23 | 15 | 0 | 0.00 | - | - |
| ONE ROUTE | 10 | 10 | 0 | 0.00 | - | - |
| OPENS A LANE | 6 | 6 | 0 | 0.00 | - | - |
| OVERRUNS AWAY | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 264 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 6 | 2 | 0 | 0.00 | - | - |
| REAL GROUND | 10 | 10 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 1 | not checked | - | - | - | - |
| RISK ON THE WAY | 2 | 2 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 7 | 7 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 2 | 2 | 0 | 0.00 | - | - |
| SEARCH SPOT | 1 | 1 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 14 | 14 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 82 | not checked | - | - | - | - |
| SHOT OR CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| SPELL WORTH | 8 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 43 | 38 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 9 | 9 | 0 | 0.00 | - | - |
| STANDS STILL | 306 | 299 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 6 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 11 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 1 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 11 | not checked | - | - | - | - |
| THE TABLE BINDS | 275 | not checked | - | - | - | - |
| WAITS AGAIN | 5 | 4 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 4 | 4 | 0 | 0.00 | - | - |
| WHAT THE JOINER ADDS | 4 | 4 | 0 | 0.00 | - | - |
| WHOLE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 10 | 9 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p15

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 4.33 | 6.00 | 55.7 |
| ARMY TABLE | rule | 1.67 | 3.33 | 64.3 |
| PROMISE BY ITS OWN SUM | rule | 1.67 | 1.33 | 76.5 |
| MARCH OF THE TABLE | rule | 0.67 | 1.00 | 34.5 |
| RULE SWITCHED OFF | gate | 1.67 | - | 66.2 |
| HOLDER ASSIGNMENT | rule | - | 1.00 | 28.9 |
| REFUSING RETIRES | rule | - | 0.67 | 30.4 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 3.2 |
| NO REASON | gate | - | 0.33 | 153.6 |
| PATHS CROSS | rule | - | 0.33 | 6.7 |

### Plans: ccut-c940641-p15

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 1.7 | 40% | 538 | 126 | 23% |
| Mine | join | 0.3 | 100% | 10 | 0 | 0% |
| Mine | move | 33.3 | 98% | 2155 | 0 | 0% |
| Mine | shoot | 10.7 | 53% | 284 | 701 | 247% |
| Opponent | charge | 1.3 | 25% | 175 | 0 | 0% |
| Opponent | join | 1.7 | 100% | 93 | 0 | 0% |
| Opponent | move | 26.0 | 97% | 1209 | 0 | 0% |
| Opponent | shoot | 12.7 | 66% | 602 | 1115 | 185% |
| Opponent | support | 0.3 | 0% | 0 | 0 | - |

### Battle groups: ccut-c940641-p15

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 1.0 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 1.7 | 0% | - | - | - | - | - | - | - | - |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p15

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaff | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Character | 11 | 66 (11) | 66 | 0 | 27 | 18% | 2.6 | 78 (7) | 32 (4) | - | 89 (8) | 0 (3) |
| Mine | Clean-up | 6 | 92 (6) | 0 | 92 | 0 | 100% | - | 0 (3) | 185 (2) | 250 (1) | 113 (5) | 0 (1) |
| Mine | Fast Hammer | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Hammer | 6 | 3 (6) | 3 | 0 | 0 | 50% | 4.0 | 12 (2) | 0 (4) | - | 4 (5) | 0 (1) |
| Mine | Holder | 2 | 11 (2) | 0 | 11 | 0 | 100% | - | 22 (1) | 0 (1) | - | 11 (2) | - |
| Mine | Shooter | 2 | 146 (2) | 0 | 146 | 0 | 0% | 1.5 | 293 (1) | 0 (1) | - | 146 (2) | - |
| Mine | War machine | 5 | 0 (5) | 0 | 0 | 20 | 0% | 1.2 | 0 (2) | 0 (1) | 0 (2) | - | 0 (5) |
| Opponent | Chaff | 4 | 0 (4) | 0 | 0 | 18 | 75% | 6.0 | 0 (4) | - | - | 0 (3) | 0 (1) |
| Opponent | Character | 9 | 0 (9) | 0 | 0 | 52 | 33% | 3.7 | 0 (2) | 0 (5) | 0 (1) | 0 (5) | 0 (3) |
| Opponent | Clean-up | 2 | 0 (2) | 0 | 0 | 57 | 100% | - | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 1 | 0 (1) | 0 | 0 | 0 | 0% | 4.0 | 0 (1) | - | - | - | 0 (1) |
| Opponent | Hammer | 3 | 83 (3) | 83 | 0 | 38 | 33% | 1.5 | - | 83 (3) | - | 118 (2) | 0 (1) |
| Opponent | Holder | 3 | 22 (3) | 22 | 0 | 0 | 0% | 5.0 | - | 0 (2) | 70 (1) | 32 (2) | 0 (1) |
| Opponent | Shooter | 3 | 87 (3) | 0 | 87 | 0 | 0% | 1.0 | - | 231 (1) | 14 (2) | 115 (2) | 29 (1) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | War machine | 5 | 23 (5) | 23 | 0 | 35 | 0% | 1.6 | - | - | 23 (5) | - | 23 (5) |
| Opponent | Wizard | 5 | 0 (5) | 0 | 0 | 0 | 40% | 2.3 | 0 (3) | 0 (2) | - | 0 (2) | 0 (3) |

### Charged fights: ccut-c940641-p15

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 2 | 150 | 392 | 2.5 | 1.0 | 157 | 0 | +157 | 3 of 5 | 4 of 5 | - | +157 |
| Mine | Dwarfen Mountain Holds | 1 | 651 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| **Mine** | all armies | 3 | 317 | 261 | 1.7 | 1.0 | 157 | 0 | +157 | 3 of 5 | 4 of 5 | - | +157 |
| Opponent | Empire of Man | 1 | 580 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 277 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 0 of 1 | - | +0 |
| Opponent | Vampire Counts | 1 | 0 | 0 | 3.0 | 1.0 | 0 | 0 | +0 | 3 of 3 | 2 of 3 | - | +0 |
| **Opponent** | all armies | 3 | 286 | 0 | 1.3 | 1.0 | 0 | 0 | +0 | 4 of 4 | 2 of 4 | - | +0 |

### Effective charges: ccut-c940641-p15

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Chaos Dwarfs | 5 | 2 (net +134) | 0 | 0 | 1 (net +265) | 0 | 2 (net +125) | 0 | 0% (0 of 5) |
| Opponent | Vampire Counts | 3 | 0 | 1 (net +0) | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 33% (1 of 3) |

### Charged fights, damage counted: ccut-c940641-p15

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 480 | 348 | +134 | 134 | 0 | +134 | +27.9 |
| Mine | 76-89% | 1 | 339 | 265 | +265 | 265 | 0 | +265 | +78.2 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 339 | 125 | +125 | 125 | 0 | +125 | +36.9 |
| Mine | All fights | 5 | 395 | 242 | +157 | 157 | 0 | +157 | +39.6 |
| Opponent | 50-54% | 1 | 68 | 339 | +0 | 0 | 75 | -75 | -110.2 |
| Opponent | Effective (55-75%) | 1 | 480 | 480 | +0 | 343 | 0 | +343 | +71.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 1 | 50 | 339 | +0 | 0 | 0 | +0 | +0.0 |
| Opponent | No odds | 1 | 205 | 239 | +0 | 280 | 501 | -220 | -107.5 |
| Opponent | All fights | 4 | 201 | 349 | +0 | 156 | 144 | +12 | +5.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p15 | move | 12 | 3 (25%) | 3 (25%) | 2 (17%) | 7 (58%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L0425 |
| Clockwork Compass | Opponent | L0512 |
| Invocation of Nehek | Opponent | L0425 |
| Ring of Doom | Opponent | L0512 |
| Ring of Jet | Opponent | L0512 |

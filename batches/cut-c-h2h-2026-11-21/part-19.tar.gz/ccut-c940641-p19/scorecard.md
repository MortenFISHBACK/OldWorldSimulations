# Doctrine scorecard: ccut-c940641-p19

### Scorecard: ccut-c940641-p19

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1118 | 2 | 1 | Mine | - | - | 2 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 3 | 4 | 2 | 0 | 0 | 0 | 413 |
| L1135 | 1 | 1 | Mine | no | 0 | 3 | 1 | 1 | 0 | 0 | 0 | 330 |
| L1135 | 1 | 1 | Opponent | no | 1 | 5 | 1 | 2 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 4 | 2 | 1 | 2 | 0 | 0 | 0 | 330 |
| L1228 | 4 | 1 | Opponent | no | 2 | - | 0 | 0 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 0% | 2.0 | 2.3 | 1.0 | 1.0 | 0.0 | 0.0 | 0.0 | 330.0 |
| **Average** | | | Opponent | 0% | 1.5 | 4.0 | 1.7 | 1.3 | 0.0 | 0.0 | 0.0 | 137.7 |

### KPIs: ccut-c940641-p19

Rules off - Mine only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 29% (4 of 14) | 7% (1 of 14) | 18% (5 of 28) |
| Winner chose to follow up after the loser gave ground |  | 75% (3 of 4); on the table 75% | - | 75% (3 of 4); on the table 75% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (2 of 2); on the table 100% | 100% (1 of 1); on the table 100% | 100% (3 of 3); on the table 100% |
| Winner chose to pursue after the loser fled |  | 100% (5 of 5); on the table 100% | - | 100% (5 of 5); on the table 100% |
| Winner chose to follow up or pursue (all three) |  | 91% (10 of 11); on the table 91% | 100% (1 of 1); on the table 100% | 92% (11 of 12); on the table 92% |
| Magic missiles tried each own turn | 50%+ | 31% (22 of 72) | 44% (8 of 18) | 33% (30 of 90) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 42% (22 of 52) | 50% (8 of 16) | 44% (30 of 68) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | - | - |
| Points that never fought | lower | 55% (3294 of 5998) | 37% (2196 of 6000) | 46% (5490 of 11998) |
|   infantry points that never fought | lower | 87% (633 of 730) | 52% (407 of 782) | 69% (1040 of 1512) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 68% (17 of 25) | 73% (19 of 26) | 71% (36 of 51) |
| Bound items with a magic missile used (at least once a game) |  | 57% (4 of 7); 4.0 uses a game | 50% (1 of 2); 0.3 uses a game | 56% (5 of 9); 2.2 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 0% (0 of 3); 0.0 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
|   their share of the points of units over 100 pts | lower | 61% (3421 of 5614) | 69% (3890 of 5644) | 65% (7311 of 11258) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 4.7 (28%) | 0.7 (20%) | 5.3 (27%) |
| MARCHED: its unit marched | 4.7 (28%) | 0.0 (0%) | 4.7 (23%) |
| CHARGED: its unit charged | 0.7 (4%) | 0.0 (0%) | 0.7 (3%) |
| IN COMBAT: engaged in combat | 6.0 (36%) | 0.0 (0%) | 6.0 (30%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 1.7 (50%) | 1.7 (8%) |
| GONE: slain | 0.7 (4%) | 0.0 (0%) | 0.7 (3%) |
| OFF THE TABLE: off the table or not arrived | 0.0 (0%) | 0.7 (20%) | 0.7 (3%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.3 (10%) | 0.3 (2%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.3 | 6.3 | 1.3 | 10.0 | 0.7 | 3.7 |
| not cast | 0.7 | 9.7 | 4.7 | 20.0 | 3.3 | 24.3 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 7.0 (72%) | 0.0 (0%) | 5.3 (27%) | 0.0 (0%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 4.7 (23%) | 1.7 (50%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.3 (7%) | 6.0 (30%) | 1.3 (40%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 2.0 (21%) | 2.0 (43%) | 1.7 (8%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (10%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (1%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.7 (3%) | 0.0 (0%) | 0.0 (0%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (50%) | 0.7 (7%) | 0.7 (14%) | 0.7 (3%) | 0.0 (0%) | 1.3 (5%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (2%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 0.3 (50%) | 0.0 (0%) | 1.7 (36%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 21.0 (86%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.0 a game | 1.3 a game | 0.7 a game |
| stood (cast and not dispelled) | - | 25% (1 of 4) | 25% (1 of 4) |
| the unit moved after it | - | 0% (0 of 1) | 0% (0 of 1) |
| it charged on its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| the enemy charged it first | - | 0% (0 of 1) | 0% (0 of 1) |
| it fought by the end of its next turn | - | 0% (0 of 1) | 0% (0 of 1) |
| it moved out of a charge the enemy had planned (not charged first) | - | 0% (0 of 1) | 0% (0 of 1) |
| none of these (no charge, no fight, no charge escaped) | - | 100% (1 of 1) | 100% (1 of 1) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 66% (31 of 47) | 59% (48 of 81) | 62% (79 of 128) |
|   cavalry | - | 80% (16 of 20) | 80% (16 of 20) |
|   character | - | 58% (7 of 12) | 58% (7 of 12) |
|   chariot | 56% (5 of 9) | 80% (8 of 10) | 68% (13 of 19) |
|   infantry | 70% (7 of 10) | 43% (12 of 28) | 50% (19 of 38) |
|   monster | - | 45% (5 of 11) | 45% (5 of 11) |
|   war machine | 68% (19 of 28) | - | 68% (19 of 28) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 1.0 (19%) | 3.3 (30%) | 4.3 (27%) |
| CHARGED: it charged | 1.0 (19%) | 0.7 (6%) | 1.7 (10%) |
| IN COMBAT: it fought this turn or the last | 0.3 (6%) | 1.0 (9%) | 1.3 (8%) |
| NO TARGET IN RANGE | 0.0 (0%) | 3.3 (30%) | 3.3 (20%) |
| ONLY IN COMBAT: the only targets were in combat | 0.0 (0%) | 0.7 (6%) | 0.7 (4%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (25%) | 1.3 (12%) | 2.7 (16%) |
| SHELTERED: the target was sheltered | 1.3 (25%) | 0.7 (6%) | 2.0 (12%) |
| OTHER BAR | 0.3 (6%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 7.3 | 0.0 | 100% | 0.0 pts | 0 pts |
| character | 2.3 | 1.3 | 71% | 30.8 pts | 72 pts |
| chariot | 4.3 | 1.3 | 85% | 14.3 pts | 62 pts |
| infantry | 8.7 | 3.0 | 81% | 7.6 pts | 66 pts |
| monster | 1.7 | 1.3 | 60% | 7.5 pts | 13 pts |
| war machine | 7.3 | 10.3 | 41% | 35.2 pts | 258 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.0 | 2.0 | 3.5 |
| Charges that made contact a game | 4.0 | 1.7 | 2.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.67 declared, 1.50 contact (6 units) | - | 1.67 declared, 1.50 contact (6 units) |
|   per unit a game, units carrying another wizard (or one alone) | 2.00 declared, 1.00 contact (1 units) | - | 2.00 declared, 1.00 contact (1 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.33 declared, 0.22 contact (9 units) | 0.23 declared, 0.19 contact (26 units) | 0.26 declared, 0.20 contact (35 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 83% (5 of 6) | - | 75% (3 of 4) | 80% (8 of 10) |
| Character in a unit | 100% (1 of 1) | 100% (2 of 2) | - | 100% (3 of 3) |
| Character on its own | 100% (2 of 2) | 62% (5 of 8) | 20% (1 of 5) | 53% (8 of 15) |
| Chariot | 50% (2 of 4) | - | - | 50% (2 of 4) |
| Infantry | 75% (6 of 8) | - | - | 75% (6 of 8) |
| Monster | - | 0% (0 of 1) | - | 0% (0 of 1) |
| Monstrous | 100% (2 of 2) | 100% (2 of 2) | - | 100% (4 of 4) |
| War Machines | 83% (5 of 6) | - | - | 83% (5 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Grand Cathay | 3 | 91% (10 of 11); on the table 91% | 31% (22 of 72) | 55% | 68% (17 of 25) | 57% (4 of 7); 4.0 uses a game | 0.0 uses a game | 0% (0 of 3); 0.0 uses a game |
| Ogre Kingdoms | 1 | - | 0% (0 of 6) | 70% | 57% (4 of 7) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 1 | - | 50% (3 of 6) | 6% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Wood Elf Realms | 1 | 100% (1 of 1); on the table 100% | 83% (5 of 6) | 35% | 83% (10 of 12) | 0% (0 of 1); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p19, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 80% (4) | 43% (3) | 58% (7) |
| ...free all their last turn and able to turn (per game) | 0.67 | 1.00 | 1.67 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.00 | 0.00 |
| ...with the charger already in that arc before they moved (per game) | 0.33 | 0.67 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.00 | 0.00 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.00 | 0.00 |

### Quality by phase: ccut-c940641-p19

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.7 | 1.0 |
| Strategy | Charge objectives carried out (made contact) | 80% (12 of 15) | 75% (3 of 4) |
| Strategy | Shoot objectives carried out (shot that target) | 46% (16 of 35) | 73% (24 of 33) |
| Strategy | Support requests answered (helper made contact too) | 100% (3 of 3) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 14% (1 of 7) | 0% (0 of 2) |
| Strategy | Joined characters whose unit fought | 33% (1 of 3) | 50% (1 of 2) |
| Strategy | Lone characters that fought | 67% (6 of 9) | 83% (5 of 6) |
| Movement | Charges halted short of contact | 0.0 | 0.0 |
| Movement | Idle units | 1.0 | 1.3 |
| Movement | Points that never moved of their own | 330.0 | 137.7 |
| Movement | Fights charged into per game | 3.0 | 1.7 |
| Movement | Charges with odds: long shots (under 50%) | 2 of 9, net +470 | 1 of 3, net -301 |
| Movement | Charges with odds: sweet spot (55-75%) | 1 of 9, net +931 | 0 of 3 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 1 of 9, net +41 | 0 of 3 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 of 9, net +91 | 2 of 3, net +265 |
| Shooting | Shots by shooting units (incl. breath weapons) | 4.0 | 16.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 0% (0 of 12) | 43% (21 of 49) |
| Shooting | Points destroyed by shooting units | 0.0 | 55.0 |
| Shooting | War machine shots | 6.3 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 21% (4 of 19) | - |
| Shooting | Points destroyed by war machines | 34.0 | 55.0 |
| Magic | Magic missiles cast | 6.3 | 1.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 21% (4 of 19) | 100% (5 of 5) |
| Magic | Wounds caused by magic missiles | 9.7 | 1.3 |
| Magic | Wounds caused by other spells | 1.0 | - |
| Magic | Points destroyed by magic (all spells) | 134.7 | 0.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 2.3 / 0.7 / 0.3 | 1.3 / 0.7 / 0.3 / 0.0 |
| Combat | Points destroyed in combat | 466.0 | 176.7 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +254 | +53 |
| Combat | Net per 100 charger points, damage counted | +65.6 | +27.9 |
| Combat | First round won (charged fights) | 78% | 40% |
| Combat | Net points per charged fight | +253 | +46 |
| Combat | Net points per supported fight / lone fight | +624 / +68 | - / +46 |
| Combat | Charged fights on a top-3 enemy unit | 5 of 9 | 4 of 5 |
| Game | Points lost | 509.7 | 1003.0 |
| Game | VP from objectives | 756.7 | 346.7 |
| Game | Lone holders (player turns) | 2.0 | 1.5 |

- Mine won / drew / lost: 2 / 0 / 1 of 3 ended games (of 3); mean margin (Mine - Opponent) +920 VP
- The side that went first won 2 of 3 games with a winner
- Points traded per game (both sides' losses): 1513
- Games not ended: 0; findings 2, warnings 0

### Opponent rules: ccut-c940641-p19

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | 0.3 | +4.6 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 10.7 | +129.8 | 0.0 | 255.3 | 24.3 | +487.1 | 0.0 | 123.3 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +12.5 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 2.3 | +0.0 | 0.0 | 55.0 | - | - | - | - |
| ASSAILMENT BY POINTS | 0.7 | +5.4 | 0.0 | 0.0 | 0.3 | +1.6 | 0.0 | 117.0 |
| BEST PRIZE | 0.3 | -13.7 | 0.0 | 0.0 | - | - | - | - |
| BOMBING RUN | 0.7 | +21.7 | 0.0 | 50.0 | - | - | - | - |
| CANNON PLANNED TARGET | 6.0 | +141.3 | 356.7 | 275.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 2.3 | +59.2 | 160.3 | 0.0 | - | - | - | - |
| CASTER AWAY FROM SCREEN | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 2.7 | +33.8 | 0.0 | 0.0 | 2.7 | +6.3 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| CHALLENGE BY POINTS | - | - | - | - | 0.7 | +80.0 | 0.0 | 41.7 |
| CHAMPION KNOWS CHALLENGE | - | - | - | - | 0.3 | +3.5 | 0.0 | 0.0 |
| CHARGE LOSSES | 17.7 | -440.5 | 0.0 | 494.0 | 14.7 | -590.2 | 0.0 | 426.3 |
| CHARGE NOW FIRST | 2.3 | +0.0 | 446.0 | 77.7 | 1.0 | +0.0 | 77.7 | 0.0 |
| CLOSES ON WHAT IT BEATS | 6.3 | +0.0 | 0.0 | 358.0 | 7.3 | +0.0 | 0.0 | 22.7 |
| COMBAT PIVOT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | - | - | - | - | 1.3 | +115.6 | 0.0 | 0.0 |
| COVER ONCE | 4.7 | -227.2 | 0.0 | 246.0 | 9.3 | -811.4 | 0.0 | 137.3 |
| DENIED BY THE FIGHT | 0.7 | -11.6 | 0.0 | 77.7 | - | - | - | - |
| DEPLOY BY FIGURES | 6.0 | -45.0 | 0.0 | 0.0 | 8.3 | -61.2 | 0.0 | 0.0 |
| EVASIVE BY THE ODDS | - | - | - | - | 1.7 | +54.0 | 0.0 | 83.7 |
| EXACT ROUND | 2.0 | +12.0 | 108.3 | 0.0 | 1.0 | -0.0 | 127.7 | 0.0 |
| FALL BACK GOOD ORDER | 3.3 | +34.1 | 536.0 | 77.7 | 1.0 | +6.0 | 127.7 | 0.0 |
| FALLS SHORT | 4.7 | +69.8 | 0.0 | 99.0 | 17.0 | +295.8 | 0.0 | 218.0 |
| FEATURE BUFFS | 1.3 | +2.5 | 0.0 | 477.3 | 0.7 | +58.3 | 0.0 | 0.0 |
| FIGHT LIFT | - | - | - | - | 0.7 | +13.9 | 0.0 | 0.0 |
| FIGHT TO THE END | 1.7 | +22.7 | 600.7 | 0.0 | - | - | - | - |
| FIRE IN ORDER | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FIVE ACTION | 74.0 | +5499.1 | 2150.3 | 1717.3 | 79.0 | +4733.6 | 732.7 | 906.7 |
| FLANK NOT WEIGHED | 3.7 | +0.0 | 0.0 | 119.3 | 6.7 | +0.0 | 0.0 | 169.7 |
| FOLLOW UP WEIGHED | 1.0 | +252.9 | 0.0 | 77.7 | 0.3 | +67.5 | 0.0 | 0.0 |
| FOUR ROUNDS | 5.0 | +1008.1 | 1150.3 | 77.7 | 1.3 | +107.7 | 127.7 | 0.0 |
| FREED FROM HIS FIGHT | 1.0 | +0.0 | 0.0 | 0.0 | 9.0 | +0.0 | 0.0 | 26.7 |
| FRIEND SHOOTS FIRST | 0.3 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| FRIENDS SHOTS CHECKED | 0.3 | -1.2 | 0.0 | 0.0 | - | - | - | - |
| GIVES UP | 1.0 | -6.0 | 249.3 | 0.0 | - | - | - | - |
| GOAL WALK | 3.7 | +238.1 | 0.0 | 0.0 | 15.3 | +1449.8 | 0.0 | 68.0 |
| GUN FIGURES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| GUN MASK | 2.0 | +106.4 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 3.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 42.0 |
| HE REFORMS ONCE FREED | - | - | - | - | 4.0 | +0.0 | 0.0 | 26.7 |
| HIS CHARGE BY HIS RUN | 12.3 | +0.0 | 0.0 | 394.0 | 9.0 | +0.0 | 0.0 | 426.3 |
| HIS CHARGE DENIED | - | - | - | - | 0.3 | +18.5 | 0.0 | 0.0 |
| HIS CHARGE LIST | 2.7 | +0.0 | 0.0 | 238.7 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 3.3 | +0.0 | 0.0 | 77.7 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS MOVE AND SHOT | 5.7 | -18.8 | 0.0 | 155.3 | 5.3 | -34.9 | 0.0 | 11.3 |
| HIS MOVE AS HE DECIDES | 41.3 | +10.0 | 1054.0 | 0.0 | - | - | - | - |
| HIS ONE MOVE | 18.3 | +7.8 | 0.0 | 155.3 | - | - | - | - |
| HIS ONE QUARTER | 2.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 83.3 |
| HIS OWN BEST MOVE | 2.7 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS SHOT LIST | 32.3 | +695.6 | 0.0 | 991.7 | 48.7 | +2236.4 | 0.0 | 623.3 |
| HIS SHOTS BY HIS RUN | 29.0 | +922.6 | 0.0 | 991.7 | 43.3 | +1474.4 | 0.0 | 623.3 |
| HIS TURN DENIED | 0.7 | +14.4 | 0.0 | 77.7 | 0.3 | +9.3 | 77.7 | 0.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 13.0 | +0.0 | 0.0 | 954.7 | 7.7 | +0.0 | 0.0 | 238.0 |
| HOLDER ASSIGNMENT | 8.0 | +816.0 | 0.0 | 238.7 | 5.3 | +680.6 | 0.0 | 119.0 |
| HOLDS AMBUSHERS | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.3 | -101.6 | 627.0 | 77.7 | 1.0 | -35.6 | 77.7 | 0.0 |
| HUNT IN PAIRS | 2.0 | +75.7 | 0.0 | 77.7 | - | - | - | - |
| IDLE COST | 1.0 | -23.1 | 0.0 | 0.0 | 10.0 | -152.4 | 0.0 | 112.7 |
| JOINT CHARGE NOW | 2.0 | +69.2 | 963.3 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 1.7 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +33.7 | 0.0 | 0.0 | 0.3 | +15.7 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 4.7 | +0.0 | 273.7 | 77.7 | 4.7 | +0.0 | 77.7 | 538.7 |
| LONE WIZARD KEPT IN | 0.7 | +52.8 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | - | - | - | - | 0.3 | -4.6 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 3.7 | -7.8 | 1042.0 | 77.7 | 0.7 | +1.7 | 77.7 | 0.0 |
| LOST CHARGE | 0.3 | -3.3 | 41.7 | 0.0 | - | - | - | - |
| MANOEUVRE | 1.7 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 41.7 |
| MARCH AT ESCAPER | - | - | - | - | 0.3 | +4.6 | 0.0 | 0.0 |
| MARCH BY THE SUM | 1.3 | +135.4 | 0.0 | 0.0 | 0.3 | +23.5 | 0.0 | 0.0 |
| MARCH CHECK | 3.0 | +111.9 | 0.0 | 0.0 | - | - | - | - |
| MARCH OF THE TABLE | 1.0 | +128.3 | 0.0 | 77.7 | 0.3 | +15.8 | 0.0 | 0.0 |
| MARCH OVER CASTS | 2.3 | -30.9 | 0.0 | 77.7 | 0.3 | -1.6 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 3.3 | +61.4 | 0.0 | 77.7 | 1.7 | +42.8 | 0.0 | 0.0 |
| MEETS IN TIME | 1.7 | +155.5 | 0.0 | 0.0 | 4.0 | +307.2 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 7.0 | +201.2 | 0.0 | 0.0 | 3.3 | +27.5 | 0.0 | 119.0 |
| MISSILES NEXT TURN | 13.0 | +143.5 | 0.0 | 77.7 | 4.0 | +27.1 | 0.0 | 119.0 |
| MISSILES ON ONE TARGET | 0.7 | -26.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 2.3 | +0.0 | 0.0 | 41.7 |
| MOVE SPELL OUT OF RANGE | - | - | - | - | 0.7 | -24.1 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 5.3 | +631.6 | 0.0 | 155.3 | 2.3 | +154.6 | 0.0 | 0.0 |
| NEARER NOT NEEDED | 6.3 | +252.8 | 0.0 | 287.7 | 4.7 | +211.6 | 0.0 | 0.0 |
| NEXT CHARGE BY LIST | 2.3 | +242.1 | 0.0 | 155.3 | 2.3 | +154.6 | 0.0 | 0.0 |
| NEXT OBJECTIVE NEARER | - | - | - | - | 0.3 | -33.3 | 0.0 | 0.0 |
| NO DOUBLE ROUNDS | 3.0 | -100.8 | 264.3 | 77.7 | 1.0 | -153.9 | 127.7 | 0.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| NO SECOND RUN | - | - | - | - | 5.7 | +0.0 | 0.0 | 0.0 |
| NOT WORTH A CAST | 0.3 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| OFF BEST | 3.3 | -55.2 | 0.0 | 229.3 | 3.7 | -75.9 | 0.0 | 0.0 |
| OGRE LOADER SECOND SHOT | 3.0 | +31.0 | 34.0 | 55.0 | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ONE FIGHT FORMULA | 4.0 | -65.4 | 0.0 | 197.0 | 2.3 | -50.2 | 0.0 | 0.0 |
| ONE JOINT FIGURE | 0.7 | +263.1 | 362.7 | 0.0 | - | - | - | - |
| ONE OBJECTIVE FORMULA | 4.3 | +172.0 | 0.0 | 238.7 | 1.3 | -20.2 | 0.0 | 119.0 |
| OPENS UP | 0.3 | +8.2 | 11.3 | 0.0 | - | - | - | - |
| OVERRUNS AWAY | 1.3 | +8.1 | 83.3 | 0.0 | 0.3 | +3.0 | 50.0 | 0.0 |
| PATHS CROSS | - | - | - | - | 0.3 | +5.7 | 0.0 | 0.0 |
| PLAN RESULT | 34.3 | +1407.0 | 794.0 | 867.0 | 36.3 | +544.4 | 275.0 | 1054.0 |
| PROMISE BELOW ZERO | 0.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| PROMISE BY ITS OWN SUM | 4.7 | -106.0 | 0.0 | 0.0 | 2.7 | +0.0 | 0.0 | 0.0 |
| PROMISE KNOWS THE FIGHT | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| PROMISE READS THE TABLE | 0.3 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| QUARTER ODDS | 13.3 | +2118.1 | 412.3 | 77.7 | 10.0 | +1014.1 | 77.7 | 243.3 |
| REDIRECT COUNTER | - | - | - | - | 4.0 | +446.7 | 0.0 | 38.3 |
| REDIRECT FOR A FRIEND IN REACH | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| REFORMS TO MEET IT | 3.3 | -581.5 | 0.0 | 155.3 | 0.3 | -84.1 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +0.9 | 0.0 | 50.0 | 1.0 | +17.9 | 0.0 | 0.0 |
| RESTRAINS TO SHOOT | - | - | - | - | 0.7 | +12.3 | 0.0 | 0.0 |
| RISK BY ARC | 5.0 | +60.1 | 1150.3 | 77.7 | 1.0 | +80.3 | 127.7 | 0.0 |
| ROUNDS AFTER TERROR | - | - | - | - | 0.7 | -21.1 | 127.7 | 0.0 |
| RUN DOWN | 4.0 | -34.3 | 746.0 | 77.7 | 1.3 | -31.0 | 127.7 | 0.0 |
| SCOUT SPOT | - | - | - | - | 0.7 | +2.9 | 0.0 | 0.0 |
| SCOUT WAITS | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 0.3 | +15.7 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 0.7 | -59.6 | 0.0 | 0.0 |
| SET UP BY THE SET | 0.3 | +21.3 | 0.0 | 0.0 | 2.3 | +52.2 | 0.0 | 0.0 |
| SET UP TOGETHER | - | - | - | - | 1.0 | +5.9 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | - | - | - | - | 0.3 | +0.3 | 0.0 | 0.0 |
| SHOOTERS ON THE TABLE | 11.0 | +0.0 | 0.0 | 324.0 | 9.7 | +0.0 | 0.0 | 141.7 |
| SHOOTS FROM THE BEST SPOT | 2.7 | +32.3 | 74.0 | 0.0 | 3.3 | +97.0 | 110.0 | 0.0 |
| SHOT OR CHARGE | 2.0 | -27.8 | 271.7 | 77.7 | 0.3 | -6.9 | 0.0 | 0.0 |
| SHOT RISK POINTS | 17.0 | -192.9 | 0.0 | 484.7 | 29.3 | +3.0 | 0.0 | 596.0 |
| SHOTS AFTER THE MOVES | 4.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 0.0 |
| SHOTS IN THE MOVE | 11.7 | +555.2 | 0.0 | 429.0 | 15.0 | +567.4 | 0.0 | 155.0 |
| SPELL WORTH | 1.3 | +23.3 | 0.0 | 0.0 | 3.3 | +53.2 | 0.0 | 117.0 |
| SPOT AS THE GAME MOVES | 4.7 | +0.0 | 0.0 | 169.3 | 8.3 | +0.0 | 0.0 | 236.3 |
| STAND AND SHOOT | 0.3 | -1.7 | 0.0 | 0.0 | - | - | - | - |
| STANDS FOR A REASON | - | - | - | - | 4.3 | +0.0 | 0.0 | 0.0 |
| STANDS STILL | 40.3 | +0.0 | 1000.0 | 907.0 | 32.7 | +0.0 | 605.0 | 320.3 |
| STANDS TO CAST | - | - | - | - | 0.3 | +42.9 | 0.0 | 0.0 |
| STAY WORTH | 27.0 | +111.9 | 926.0 | 1077.0 | 25.3 | +167.7 | 385.0 | 438.3 |
| STRIKE BY THE ODDS | 1.0 | +25.5 | 544.0 | 0.0 | 0.3 | +3.5 | 0.0 | 0.0 |
| SUPPORT ADDS | 1.3 | +58.1 | 0.0 | 0.0 | 6.7 | +677.9 | 0.0 | 0.0 |
| SUPPORT NARROWED | 0.3 | +0.0 | 41.7 | 0.0 | - | - | - | - |
| SUPPORT WORKED OUT | 1.3 | +58.1 | 0.0 | 0.0 | 6.7 | +677.9 | 0.0 | 0.0 |
| SWIFTSTRIDE BY POINTS | - | - | - | - | 0.3 | +1.2 | 0.0 | 42.0 |
| THE DEARER SUM KEEPS ITS PLAN | 1.7 | +0.0 | 0.0 | 0.0 | 1.3 | +0.0 | 0.0 | 0.0 |
| THE RISK READS HIS RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| THE ROW IN ITS ORDER | 0.3 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 34.0 | 55.0 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 0.0 | 3.7 | +0.0 | 0.0 | 213.7 |
| THE ROW READS HIS LAST RUN | 2.7 | +0.0 | 0.0 | 119.3 | - | - | - | - |
| THE STEP BACK IS MADE | 0.7 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 160.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 5.7 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 31.3 | +0.0 | 0.0 | 740.3 | 37.7 | +0.0 | 0.0 | 453.3 |
| TIED UP BY THE SUM | 2.0 | +131.9 | 145.3 | 0.0 | 0.7 | +102.4 | 127.7 | 0.0 |
| TIME ON OUR SIDE | 23.7 | +351.1 | 0.0 | 366.3 | 15.7 | +146.4 | 0.0 | 75.0 |
| WAITS AGAIN | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WAR ENGINE JOBS | 0.7 | +0.0 | 41.7 | 0.0 | 1.0 | +0.0 | 110.0 | 0.0 |
| WHO GETS IN | 0.7 | +100.8 | 362.7 | 0.0 | - | - | - | - |
| WHOLE FIGHT DANGER | 2.0 | -128.4 | 0.0 | 119.3 | 1.3 | -189.7 | 0.0 | 41.7 |
| WHOLE FIGHT GAIN | 0.7 | +86.1 | 362.7 | 0.0 | - | - | - | - |
| WOUNDED STAYS OUT | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| WOUNDS ON THE RANKS | 3.3 | +46.8 | 0.0 | 238.7 | 2.7 | +139.1 | 0.0 | 238.0 |

### Rule changes: ccut-c940641-p19

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 124 | 124 | 94 | 31.33 | +0 | +0.0 |
| ARMY TABLE | 105 | 105 | 81 | 27.00 | +1471 | +18.2 |
| HIS SHOTS BY HIS RUN | 217 | 207 | 47 | 15.67 | +1347 | +28.7 |
| HIS SHOT LIST | 243 | 233 | 46 | 15.33 | +1183 | +25.7 |
| HOLDER ASSIGNMENT | 40 | 40 | 34 | 11.33 | +2697 | +79.3 |
| LEGAL CHARGES ONLY | 28 | 28 | 28 | 9.33 | +0 | +0.0 |
| THE TABLE AGAIN | 35 | 35 | 25 | 8.33 | +0 | +0.0 |
| DEPLOY BY FIGURES | 43 | 43 | 22 | 7.33 | +408 | +18.6 |
| OFF BEST | 21 | 21 | 21 | 7.00 | -393 | -18.7 |
| GOAL WALK | 57 | 54 | 17 | 5.67 | +794 | +46.7 |
| HIS ONE MOVE | 55 | 55 | 17 | 5.67 | +0 | +0.0 |
| SHOT RISK POINTS | 139 | 133 | 17 | 5.67 | +425 | +25.0 |
| HARD STAY DROPPED | 15 | 15 | 15 | 5.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 23 | 23 | 15 | 5.00 | +1261 | +84.1 |
| FIVE ACTION | 459 | 448 | 12 | 4.00 | +659 | +54.9 |
| SUPPORT ADDS | 24 | 24 | 11 | 3.67 | +418 | +38.0 |
| SUPPORT WORKED OUT | 24 | 24 | 11 | 3.67 | +418 | +38.0 |
| TIME ON OUR SIDE | 118 | 100 | 11 | 3.67 | +26 | +2.4 |
| MEETS IN TIME | 17 | 17 | 10 | 3.33 | +481 | +48.1 |
| COVER ONCE | 42 | 26 | 9 | 3.00 | +248 | +27.6 |
| FOUR ROUNDS | 19 | 19 | 9 | 3.00 | +728 | +80.9 |
| NEXT CHARGE BY LIST | 14 | 14 | 9 | 3.00 | +493 | +54.8 |
| OGRE LOADER SECOND SHOT | 9 | 9 | 9 | 3.00 | +93 | +10.3 |
| MOVE ORDER | 8 | 8 | 8 | 2.67 | +0 | +0.0 |
| QUARTER ODDS | 70 | 70 | 8 | 2.67 | +666 | +83.3 |
| THE RISK READS HIS RUN | 18 | 18 | 8 | 2.67 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| MARCH CHECK | 9 | 9 | 7 | 2.33 | +215 | +30.7 |
| SET UP BY THE SET | 8 | 8 | 7 | 2.33 | +248 | +35.5 |
| SHOOTS FROM THE BEST SPOT | 18 | 18 | 7 | 2.33 | +17 | +2.4 |
| ADVANCE LANE KEPT | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| CHARGE LOSSES | 97 | 93 | 6 | 2.00 | +149 | +24.9 |
| JOINT CHARGE NOW | 6 | 6 | 6 | 2.00 | +207 | +34.5 |
| STAY WORTH | 157 | 145 | 6 | 2.00 | +30 | +5.1 |
| TIED UP BY THE SUM | 8 | 8 | 6 | 2.00 | +212 | +35.3 |
| CANNON SIGHT KEPT | 5 | 5 | 5 | 1.67 | +0 | +0.0 |
| CASTING BLOCK | 16 | 16 | 5 | 1.67 | +34 | +6.8 |
| LANE BY FIGURES | 5 | 5 | 5 | 1.67 | +148 | +29.7 |
| MARCH BY THE SUM | 5 | 5 | 5 | 1.67 | +477 | +95.4 |
| CAST JOB | 7 | 7 | 4 | 1.33 | +8 | +1.9 |
| EVASIVE BY THE ODDS | 5 | 5 | 4 | 1.33 | +98 | +24.6 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +961 | +240.3 |
| HOLDS AMBUSHERS | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| MARCH OF THE TABLE | 4 | 4 | 4 | 1.33 | -432 | -108.1 |
| MISSILES IN THE MOVE | 31 | 24 | 4 | 1.33 | +121 | +30.4 |
| RESERVE FALL BACK | 4 | 4 | 4 | 1.33 | +56 | +14.0 |
| RISK BY ARC | 18 | 18 | 4 | 1.33 | +208 | +51.9 |
| STRIKE BY THE ODDS | 4 | 4 | 4 | 1.33 | +87 | +21.8 |
| WOUNDS ON THE RANKS | 18 | 18 | 4 | 1.33 | +123 | +30.7 |
| ASSAILMENT BY POINTS | 3 | 3 | 3 | 1.00 | +21 | +7.0 |
| FALLS SHORT | 65 | 56 | 3 | 1.00 | +25 | +8.3 |
| IDLE COST | 33 | 16 | 3 | 1.00 | +83 | +27.7 |
| PROMISE BY ITS OWN SUM | 22 | 22 | 3 | 1.00 | -318 | -106.0 |
| SCOUT WAITS | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| THE ROW IN ITS ORDER | 18 | 3 | 3 | 1.00 | +0 | +0.0 |
| BOMBING RUN | 2 | 2 | 2 | 0.67 | +65 | +32.6 |
| CHALLENGE BY POINTS | 2 | 2 | 2 | 0.67 | +240 | +120.0 |
| COMBAT PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FALL BACK GOOD ORDER | 13 | 13 | 2 | 0.67 | +18 | +9.2 |
| LONE WIZARD KEPT IN | 2 | 2 | 2 | 0.67 | +158 | +79.2 |
| MAX FOR POSITIONING | 15 | 15 | 2 | 0.67 | +25 | +12.5 |
| REDIRECT FOR A FRIEND IN REACH | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| RESTRAINS TO SHOOT | 2 | 2 | 2 | 0.67 | +37 | +18.4 |
| SHOTS IN THE MOVE | 80 | 66 | 2 | 0.67 | +71 | +35.7 |
| WHO GETS IN | 2 | 2 | 2 | 0.67 | +302 | +151.1 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +14 | +13.7 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -41 | -41.0 |
| CANNON PLANNED TARGET | 18 | 18 | 1 | 0.33 | +7 | +7.3 |
| CASTER AWAY FROM SCREEN | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| CHARGE NOW FIRST | 10 | 10 | 1 | 0.33 | -58 | -57.5 |
| FIRE IN ORDER | 1 | 1 | 1 | 0.33 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 1 | 1 | 1 | 0.33 | -4 | -3.6 |
| HIS MOVE AND SHOT | 33 | 33 | 1 | 0.33 | +0 | +0.0 |
| HIS TURN DENIED | 3 | 3 | 1 | 0.33 | +8 | +7.9 |
| HUNT IN PAIRS | 6 | 4 | 1 | 0.33 | +78 | +77.9 |
| MANOEUVRE | 8 | 8 | 1 | 0.33 | +0 | +0.0 |
| MISSILES NEXT TURN | 51 | 37 | 1 | 0.33 | +0 | +0.2 |
| ONE FIGHT FORMULA | 19 | 12 | 1 | 0.33 | +40 | +39.7 |
| ONE JOINT FIGURE | 2 | 2 | 1 | 0.33 | +221 | +221.1 |
| ONE OBJECTIVE FORMULA | 17 | 14 | 1 | 0.33 | +3 | +2.9 |
| OPENS UP | 1 | 1 | 1 | 0.33 | +20 | +19.9 |
| PATHS CROSS | 1 | 1 | 1 | 0.33 | +17 | +17.0 |
| REFORMS TO MEET IT | 11 | 11 | 1 | 0.33 | +134 | +134.5 |
| SEARCH SPOT | 1 | 1 | 1 | 0.33 | +47 | +47.2 |
| SHOOTERS IN TWO RANKS | 1 | 1 | 1 | 0.33 | +1 | +1.0 |
| SHOTS AFTER THE MOVES | 23 | 23 | 1 | 0.33 | +0 | +0.0 |
| STANDS TO CAST | 1 | 1 | 1 | 0.33 | -57 | -57.5 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +4 | +3.5 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 1 | trace | - | - | - | - |
| CHAMPION KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 41 | 39 | 0 | 0.00 | - | - |
| CONVEYANCE SEARCH | 4 | not checked | - | - | - | - |
| DENIED BY THE FIGHT | 2 | 2 | 0 | 0.00 | - | - |
| EXACT ROUND | 9 | 9 | 0 | 0.00 | - | - |
| FEATURE BUFFS | 6 | 6 | 0 | 0.00 | - | - |
| FIGHT LIFT | 2 | not checked | - | - | - | - |
| FIGHT TO THE END | 5 | 5 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 31 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 30 | 30 | 0 | 0.00 | - | - |
| FRIEND SHOOTS FIRST | 1 | 1 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GUN FIGURES | 1 | not checked | - | - | - | - |
| GUN MASK | 6 | 6 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 12 | 12 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 64 | 64 | 0 | 0.00 | - | - |
| HIS CHARGE DENIED | 1 | 1 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 20 | 17 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 19 | 19 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 14 | 14 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 19 | 19 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 62 | 62 | 0 | 0.00 | - | - |
| HONEST WORTH | 13 | 13 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 7 | 7 | 0 | 0.00 | - | - |
| LONG SHOT | 1 | 1 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 13 | 13 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | 1 | 0 | 0.00 | - | - |
| MARCH AT ESCAPER | 1 | trace | - | - | - | - |
| MARCH OVER CASTS | 8 | 8 | 0 | 0.00 | - | - |
| MISSILES ON ONE TARGET | 2 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 2 | trace | - | - | - | - |
| NEARER NOT NEEDED | 33 | 32 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 12 | 12 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 17 | 17 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 1 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 2 | not checked | - | - | - | - |
| OVERRUNS AWAY | 5 | 5 | 0 | 0.00 | - | - |
| PLAN RESULT | 212 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| PROMISE READS THE TABLE | 1 | 1 | 0 | 0.00 | - | - |
| REDIRECT COUNTER | 12 | 11 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 2 | 2 | 0 | 0.00 | - | - |
| RUN DOWN | 16 | 16 | 0 | 0.00 | - | - |
| SCOUT SPOT | 2 | 2 | 0 | 0.00 | - | - |
| SET CREDITED ONCE | 2 | 2 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 3 | 2 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 62 | not checked | - | - | - | - |
| SHOT OR CHARGE | 7 | 7 | 0 | 0.00 | - | - |
| SPELL WORTH | 14 | not checked | - | - | - | - |
| SPOT AS THE GAME MOVES | 39 | 34 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 1 | 1 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 13 | 12 | 0 | 0.00 | - | - |
| STANDS STILL | 219 | 213 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 1 | 1 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 9 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 14 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 8 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 12 | not checked | - | - | - | - |
| THE TABLE BINDS | 207 | not checked | - | - | - | - |
| WAITS AGAIN | 2 | 2 | 0 | 0.00 | - | - |
| WAR ENGINE JOBS | 5 | 5 | 0 | 0.00 | - | - |
| WHOLE FIGHT DANGER | 10 | 10 | 0 | 0.00 | - | - |
| WHOLE FIGHT GAIN | 2 | 2 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 1 | 1 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p19

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| JOB FIRST | gate | 3.00 | 2.00 | 18.3 |
| ARMY TABLE | rule | 0.33 | 2.00 | 76.1 |
| NO REASON | gate | - | 1.67 | 23.0 |
| MARCH OF THE TABLE | rule | 1.00 | 0.33 | 108.1 |
| PROMISE BY ITS OWN SUM | rule | 1.00 | - | 106.0 |
| AFTERMATH BAND | gate | 0.33 | - | 3.6 |
| BEST PRIZE | rule | 0.33 | - | 41.0 |
| CHARGE NOW FIRST | rule | 0.33 | - | 57.5 |
| FRIENDS SHOTS CHECKED | rule | 0.33 | - | 3.6 |
| HOLDER ASSIGNMENT | rule | - | 0.33 | 4.6 |
| JOINT CHARGE NOW | rule | 0.33 | - | 557.3 |
| SET UP BY THE SET | rule | - | 0.33 | 10.5 |
| STANDS TO CAST | rule | - | 0.33 | 57.5 |

### Plans: ccut-c940641-p19

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 4.7 | 64% | 1037 | 938 | 90% |
| Mine | move | 18.7 | 93% | 1339 | 0 | 0% |
| Mine | shoot | 11.0 | 48% | 490 | 469 | 96% |
| Opponent | charge | 1.0 | 67% | 110 | 128 | 116% |
| Opponent | move | 26.0 | 91% | 1660 | 0 | 0% |
| Opponent | shoot | 9.3 | 32% | 530 | 417 | 79% |

### Battle groups: ccut-c940641-p19

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Opponent | REDIRECT COUNTER | 4.0 | 25% | 100% | 67% | 100% | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p19

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Character | 12 | 90 (12) | 90 | 0 | 18 | 25% | 2.9 | - | 138 (7) | 32 (4) | 44 (5) | 121 (6) |
| Mine | Fast Hammer | 4 | 12 (4) | 12 | 0 | 50 | 25% | 2.7 | 42 (2) | 0 (2) | - | 19 (3) | 0 (1) |
| Mine | Holder | 5 | 54 (5) | 13 | 41 | 0 | 40% | 2.3 | - | 67 (4) | 0 (1) | 88 (3) | 0 (2) |
| Mine | Shooter | 2 | 186 (2) | 0 | 186 | 76 | 0% | 1.0 | 62 (1) | 309 (1) | - | 186 (2) | - |
| Mine | War machine | 6 | 10 (6) | 10 | 0 | 50 | 0% | 1.5 | 31 (2) | 0 (2) | 0 (2) | 62 (1) | 0 (5) |
| Opponent | Chaff | 6 | 38 (6) | 0 | 38 | 56 | 33% | 3.5 | 0 (5) | 250 (1) | - | 53 (5) | 0 (1) |
| Opponent | Character | 7 | 20 (7) | 20 | 0 | 32 | 14% | 2.5 | 46 (2) | 22 (3) | - | 18 (4) | 47 (1) |
| Opponent | Clean-up | 3 | 0 (3) | 0 | 0 | 68 | 67% | 1.0 | - | 0 (3) | - | 0 (2) | 0 (1) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 4 | 8 (4) | 0 | 8 | 90 | 0% | 2.2 | - | 9 (3) | 0 (1) | 9 (3) | 0 (1) |
| Opponent | Hammer | 8 | 30 (8) | 30 | 0 | 48 | 12% | 3.0 | 45 (2) | 0 (2) | 49 (4) | 48 (5) | 0 (3) |
| Opponent | Holder | 1 | 108 (1) | 0 | 108 | 100 | 0% | 2.0 | - | 108 (1) | - | 108 (1) | - |
| Opponent | Shooter | 2 | 12 (2) | 0 | 12 | 0 | 0% | 1.5 | 21 (1) | 0 (1) | - | 12 (2) | - |
| Opponent | Wizard | 1 | 0 (1) | 0 | 0 | 100 | 0% | 2.0 | - | - | - | - | - |

### Charged fights: ccut-c940641-p19

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 3 | 169 | 759 | 3.0 | 1.3 | 253 | 0 | +253 | 5 of 9 | 7 of 9 | +624 | +68 |
| Opponent | Ogre Kingdoms | 1 | 330 | 297 | 4.0 | 1.0 | 74 | 75 | -1 | 3 of 4 | 1 of 4 | - | -1 |
| Opponent | Warriors of Chaos | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Wood Elf Realms | 1 | 0 | 233 | 1.0 | 1.0 | 233 | 0 | +233 | 1 of 1 | 1 of 1 | - | +233 |
| **Opponent** | all armies | 3 | 110 | 177 | 1.7 | 1.0 | 106 | 60 | +46 | 4 of 5 | 2 of 5 | - | +46 |

### Effective charges: ccut-c940641-p19

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Grand Cathay | 9 | 2 (net +470) | 0 | 1 (net +931) | 1 (net +0) | 1 (net +41) | 4 (net +91) | 0 | 11% (1 of 9) |
| Opponent | Ogre Kingdoms | 4 | 1 (net -301) | 0 | 0 | 0 | 0 | 1 (net +297) | 2 | 0% (0 of 2) |
| Opponent | Wood Elf Realms | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +233) | 0 | 0% (0 of 1) |

### Charged fights, damage counted: ccut-c940641-p19

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 2 | 648 | 426 | +470 | 470 | 0 | +470 | +72.5 |
| Mine | Effective (55-75%) | 1 | 713 | 494 | +931 | 986 | 0 | +986 | +138.4 |
| Mine | 76-89% | 1 | 233 | 251 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 4 | 226 | 133 | +91 | 113 | 35 | +79 | +34.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 1 | 334 | 41 | +41 | 41 | 0 | +41 | +12.3 |
| Mine | All fights | 9 | 387 | 241 | +253 | 269 | 15 | +254 | +65.6 |
| Opponent | Long shot (under 50%) | 1 | 90 | 233 | -301 | 0 | 319 | -319 | -354.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 366 | 192 | +265 | 407 | 103 | +305 | +83.1 |
| Opponent | No odds | 2 | 62 | 233 | +0 | 0 | 13 | -13 | -20.6 |
| Opponent | All fights | 5 | 189 | 216 | +46 | 163 | 110 | +53 | +27.9 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p19 | move | 12 | 4 (33%) | 2 (17%) | 2 (17%) | 6 (50%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Clockwork Compass | Mine | L1228 |
| Elixir of Power | Mine | L1118, L1135 |
| Fistful of Laurels | Opponent | L1118 |
| Ring of Doom | Mine | L1118, L1135, L1228 |
| Ring of Jet | Mine | L1118, L1135, L1228 |

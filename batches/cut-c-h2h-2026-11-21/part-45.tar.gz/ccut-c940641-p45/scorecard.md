# Doctrine scorecard: ccut-c940641-p45

### Scorecard: ccut-c940641-p45

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L1531 | 1 | 1 | Mine | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 60 |
| L1531 | 1 | 1 | Opponent | yes | 3 | 2 | 2 | 2 | 3 | 0 | 0 | 170 |
| L1629 | 3 | 1 | Mine | yes | 15 | 1 | 4 | 0 | 0 | 0 | 0 | 200 |
| L1629 | 3 | 1 | Opponent | no | 1 | 3 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Mine | yes | - | 4 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Opponent | yes | - | 4 | 5 | 4 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 67% | 7.5 | 2.3 | 3.3 | 0.7 | 0.3 | 0.0 | 0.0 | 86.7 |
| **Average** | | | Opponent | 67% | 2.0 | 3.0 | 3.0 | 2.7 | 1.0 | 0.0 | 0.0 | 56.7 |

### KPIs: ccut-c940641-p45

Rules off - Opponent only: END REPLAY OUT OF THE WAIT, NO SECOND RUN, NO OLD ONE-MOVE GUESS.

Morten 2026-11-10; 3 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Turns the army played defensive (its shooting and magic 1.5x the enemy's; else offensive) |  | 0% (0 of 17) | 0% (0 of 15) | 0% (0 of 32) |
| Winner chose to follow up after the loser gave ground |  | 100% (4 of 4); on the table 100% | 100% (2 of 2); on the table 100% | 100% (6 of 6); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 50% (1 of 2); on the table 50% | 100% (3 of 3); on the table 100% | 80% (4 of 5); on the table 80% |
| Winner chose to pursue after the loser fled |  | 0% (0 of 1); on the table 0% | 0% (0 of 3); on the table 33% | 0% (0 of 4); on the table 25% |
| Winner chose to follow up or pursue (all three) |  | 71% (5 of 7); on the table 71% | 62% (5 of 8); on the table 75% | 67% (10 of 15); on the table 73% |
| Magic missiles tried each own turn | 50%+ | - | 17% (2 of 12) | 17% (2 of 12) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | - | 25% (2 of 8) | 25% (2 of 8) |
| Random moves turned off the straight line at the nearest enemy (risk weighed) |  | - | 80% (8 of 10) | 80% (8 of 10) |
| Points that never fought | lower | 45% (2727 of 6000) | 28% (1656 of 5999) | 37% (4383 of 11999) |
|   infantry points that never fought | lower | 61% (812 of 1332) | 48% (410 of 855) | 56% (1222 of 2187) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 55% (11 of 20) | 68% (17 of 25) | 62% (28 of 45) |
| Bound items with a magic missile used (at least once a game) |  | 50% (1 of 2); 0.3 uses a game | 100% (1 of 1); 0.7 uses a game | 67% (2 of 3); 0.5 uses a game |
| Bound items with another spell used |  | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 100% (1 of 1); 0.3 uses a game | 0.0 uses a game | 100% (1 of 1); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 55% (2805 of 5135) | 62% (3356 of 5430) | 58% (6161 of 10565) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | - | 1.7 (50%) | 1.7 (50%) |
| MARCHED: its unit marched | - | 0.3 (10%) | 0.3 (10%) |
| IN COMBAT: engaged in combat | - | 1.0 (30%) | 1.0 (30%) |
| GONE: slain | - | 0.3 (10%) | 0.3 (10%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Assailments |
| --- | --- | --- | --- | --- | --- |
| tried | 5.0 | 1.7 | 0.3 | 0.7 | 1.3 |
| not cast | 5.0 | 0.3 | 1.7 | 3.3 | 18.7 |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (50%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (10%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.0 (30%) | 0.0 (0%) |
| GONE: slain | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (10%) | 3.0 (16%) |
| STUPIDITY: Stupidity | 0.3 (7%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.3 (7%) | 0.3 (100%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 4.3 (87%) | 0.0 (0%) | 1.7 (100%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.7 (84%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.3 a game | 0.0 a game | 0.2 a game |
| stood (cast and not dispelled) | - | - | - |
| the unit moved after it | - | - | - |
| it charged on its next turn | - | - | - |
| the enemy charged it first | - | - | - |
| it fought by the end of its next turn | - | - | - |
| it moved out of a charge the enemy had planned (not charged first) | - | - | - |
| none of these (no charge, no fight, no charge escaped) | - | - | - |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (55 of 90) | 33% (2 of 6) | 59% (57 of 96) |
|   cavalry | 75% (9 of 12) | 40% (2 of 5) | 65% (11 of 17) |
|   character | 30% (3 of 10) | 0% (0 of 1) | 27% (3 of 11) |
|   chariot | 0% (0 of 6) | - | 0% (0 of 6) |
|   infantry | 70% (26 of 37) | - | 70% (26 of 37) |
|   monster | 38% (5 of 13) | - | 38% (5 of 13) |
|   war machine | 100% (12 of 12) | - | 100% (12 of 12) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.0 (17%) | 0.3 (25%) | 2.3 (18%) |
| CHARGED: it charged | 2.0 (17%) | 0.0 (0%) | 2.0 (15%) |
| FLEEING: it fled or was fleeing | 0.3 (3%) | 0.0 (0%) | 0.3 (3%) |
| IN COMBAT: it fought this turn or the last | 1.7 (14%) | 0.0 (0%) | 1.7 (13%) |
| NO TARGET IN RANGE | 3.3 (29%) | 0.3 (25%) | 3.7 (28%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (3%) | 0.7 (50%) | 1.0 (8%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.0 (17%) | 0.0 (0%) | 2.0 (15%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.7 | 1.3 | 73% | 2.2 pts | 8 pts |
| character | 1.0 | 1.0 | 33% | 38.7 pts | 39 pts |
| infantry | 14.0 | 3.7 | 79% | 6.2 pts | 86 pts |
| monster | 1.7 | 0.0 | 100% | 0.0 pts | 0 pts |
| war machine | 4.0 | 3.0 | 75% | 26.4 pts | 105 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 5.0 | 3.7 | 4.3 |
| Charges that made contact a game | 4.0 | 2.7 | 3.3 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | - | 1.00 declared, 0.50 contact (2 units) | 1.00 declared, 0.50 contact (2 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.50 declared, 0.50 contact (4 units) | 0.67 declared, 0.33 contact (3 units) | 0.57 declared, 0.43 contact (7 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.65 declared, 0.50 contact (20 units) | 0.35 declared, 0.30 contact (20 units) | 0.50 declared, 0.40 contact (40 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 60% (3 of 5) | 67% (2 of 3) | 100% (2 of 2) | 70% (7 of 10) |
| Character in a unit | 100% (2 of 2) | - | 0% (0 of 1) | 67% (2 of 3) |
| Character on its own | 60% (3 of 5) | 100% (2 of 2) | 50% (4 of 8) | 60% (9 of 15) |
| Chariot | 0% (0 of 1) | - | - | 0% (0 of 1) |
| Infantry | 57% (4 of 7) | 0% (0 of 3) | - | 40% (4 of 10) |
| Monster | 100% (6 of 6) | - | - | 100% (6 of 6) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 1 | 100% (1 of 1); on the table 100% | - | 35% | 43% (3 of 7) | 50% (1 of 2); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 50% (2 of 4); on the table 50% | - | 54% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 1 | 100% (2 of 2); on the table 100% | - | 48% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 1 | 60% (3 of 5); on the table 60% | 17% (1 of 6) | 27% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 2 | 67% (2 of 3); on the table 100% | 17% (1 of 6) | 28% | 74% (14 of 19) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ccut-c940641-p45, 3 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 100% (4) | 64% (7) | 73% (11) |
| ...free all their last turn and able to turn (per game) | 1.33 | 2.00 | 3.33 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.00 | 0.33 | 0.33 |
| ...with the charger already in that arc before they moved (per game) | 1.00 | 1.33 | 2.33 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 0.00 | 0.33 | 0.33 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.00 | 0.00 | 0.00 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 0.00 | 0.67 | 0.67 |

### Quality by phase: ccut-c940641-p45

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.3 | 4.3 |
| Strategy | Charge objectives carried out (made contact) | 62% (8 of 13) | 0% (0 of 8) |
| Strategy | Shoot objectives carried out (shot that target) | 50% (9 of 18) | 0% (0 of 3) |
| Strategy | Support requests answered (helper made contact too) | 0% (0 of 1) | 100% (1 of 1) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 100% (1 of 1) |
| Strategy | Joined characters whose unit fought | 0% (0 of 1) | 50% (2 of 4) |
| Strategy | Lone characters that fought | 75% (6 of 8) | 56% (5 of 9) |
| Movement | Charges halted short of contact | 0.7 | 0.3 |
| Movement | Idle units | 0.7 | 2.7 |
| Movement | Points that never moved of their own | 86.7 | 56.7 |
| Movement | Fights charged into per game | 4.0 | 2.0 |
| Movement | Charges with odds: long shots (under 50%) | 3 of 11, net +0 | 0 of 2 |
| Movement | Charges with odds: sweet spot (55-75%) | 2 of 11, net +0 | 0 of 2 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 2 of 11, net +290 | 0 of 2 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 of 11, net +378 | 2 of 2, net +158 |
| Shooting | Shots by shooting units (incl. breath weapons) | 16.3 | 1.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 41% (20 of 49) | 25% (1 of 4) |
| Shooting | Points destroyed by shooting units | 0.0 | 0.0 |
| Shooting | War machine shots | 4.0 | - |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 42% (5 of 12) | - |
| Shooting | Points destroyed by war machines | 0.0 | 0.0 |
| Magic | Magic missiles cast | - | 0.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | - | 0% (0 of 1) |
| Magic | Wounds caused by magic missiles | 1.3 | 1.0 |
| Magic | Wounds caused by other spells | 0.3 | - |
| Magic | Points destroyed by magic (all spells) | 77.3 | 20.0 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 1.0 / 0.7 / 0.0 | 2.0 / 0.0 / 0.7 / 0.0 |
| Combat | Points destroyed in combat | 603.3 | 105.3 |
| Combat | Points run down | 0.0 | 0.0 |
| Combat | Net points per charged fight, damage counted | +148 | +92 |
| Combat | Net per 100 charger points, damage counted | +54.3 | +30.8 |
| Combat | First round won (charged fights) | 67% | 83% |
| Combat | Net points per charged fight | +131 | +51 |
| Combat | Net points per supported fight / lone fight | - / +131 | +158 / -2 |
| Combat | Charged fights on a top-3 enemy unit | 6 of 12 | 1 of 6 |
| Game | Points lost | 278.0 | 688.0 |
| Game | VP from objectives | 693.3 | 613.3 |
| Game | Lone holders (player turns) | 7.5 | 2.0 |

- Mine won / drew / lost: 1 / 0 / 2 of 3 ended games (of 3); mean margin (Mine - Opponent) +485 VP
- The side that went first won 1 of 3 games with a winner
- Points traded per game (both sides' losses): 966
- Games not ended: 0; findings 1, warnings 0

### Opponent rules: ccut-c940641-p45

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| AFTERMATH IN POINTS | - | - | - | - | 0.3 | +26.6 | 0.0 | 0.0 |
| AFTERMATH WITH FRIENDS | 0.7 | +11.6 | 0.0 | 0.0 | - | - | - | - |
| ARMY TABLE | 22.0 | +273.3 | 0.0 | 94.0 | 23.0 | -156.4 | 0.0 | 109.7 |
| ARRIVAL HUNT | - | - | - | - | 0.3 | +1.1 | 0.0 | 0.0 |
| ASSAILMENT BY POINTS | - | - | - | - | 0.3 | +3.8 | 0.0 | 155.0 |
| BACKUP TARGETS | - | - | - | - | 0.3 | +4.2 | 0.0 | 0.0 |
| BEST OVERALL | - | - | - | - | 0.3 | +5.2 | 0.0 | 0.0 |
| BEST PRIZE | - | - | - | - | 0.3 | -13.9 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 4.0 | +49.6 | 442.7 | 0.0 | - | - | - | - |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CAST JOB | 0.7 | +39.3 | 130.0 | 0.0 | 1.7 | +12.6 | 94.0 | 0.0 |
| CASTS FROM BEHIND | - | - | - | - | 0.7 | +0.0 | 0.0 | 0.0 |
| CHAFF IN THE MOVE | - | - | - | - | 1.3 | +17.2 | 0.0 | 0.0 |
| CHAFF PASSED | 1.0 | -0.1 | 0.0 | 0.0 | - | - | - | - |
| CHALLENGE BY POINTS | 1.0 | +13.4 | 0.0 | 105.7 | 1.3 | +10.8 | 0.0 | 155.0 |
| CHAMPION KNOWS CHALLENGE | 0.3 | -4.3 | 0.0 | 0.0 | 0.3 | -0.9 | 0.0 | 0.0 |
| CHARGE LOSSES | 5.7 | -179.8 | 0.0 | 116.7 | 15.7 | -627.0 | 0.0 | 471.7 |
| CHARGE NOT DECLARED | - | - | - | - | 0.3 | +0.0 | 47.0 | 0.0 |
| CHARGE NOW FIRST | 3.0 | +0.0 | 192.7 | 0.0 | 2.0 | +0.0 | 238.7 | 62.0 |
| CLOSES ON WHAT IT BEATS | 11.0 | +0.0 | 0.0 | 113.3 | 11.3 | +0.0 | 0.0 | 0.0 |
| COVER ONCE | 8.7 | -573.0 | 0.0 | 78.7 | 11.7 | -849.4 | 0.0 | 358.3 |
| DENIED BY THE FIGHT | 0.7 | -0.7 | 0.0 | 0.0 | 0.3 | -1.2 | 0.0 | 62.0 |
| DEPLOY BY FIGURES | 7.3 | -26.0 | 0.0 | 0.0 | 6.3 | +63.8 | 0.0 | 0.0 |
| EXACT ROUND | 1.3 | +9.1 | 252.3 | 0.0 | 1.7 | +6.2 | 210.7 | 124.0 |
| FACES THE THREAT | - | - | - | - | 0.3 | +5.2 | 0.0 | 0.0 |
| FALL BACK GOOD ORDER | 2.3 | +4.5 | 97.3 | 0.0 | 2.7 | +8.6 | 203.0 | 124.0 |
| FALLS SHORT | - | - | - | - | 18.7 | +231.8 | 0.0 | 118.0 |
| FEATURE BUFFS | 2.0 | +18.5 | 0.0 | 0.0 | 2.0 | +101.5 | 0.0 | 0.0 |
| FIGHT LIFT | 1.0 | +30.9 | 0.0 | 0.0 | - | - | - | - |
| FIGHT TO THE END | 1.7 | +35.5 | 40.7 | 0.0 | 1.0 | +16.6 | 47.0 | 0.0 |
| FIVE ACTION | 90.0 | +6762.4 | 658.0 | 799.0 | 77.7 | +4729.3 | 418.7 | 1196.7 |
| FLANK NOT WEIGHED | 6.3 | +0.0 | 0.0 | 117.0 | 12.7 | +0.0 | 0.0 | 494.3 |
| FOLLOW UP WEIGHED | 1.0 | +118.1 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| FOUR ROUNDS | 4.7 | +537.5 | 376.0 | 0.0 | 3.7 | +195.8 | 324.7 | 124.0 |
| FREED FROM HIS FIGHT | 4.7 | +0.0 | 0.0 | 55.3 | 8.7 | +0.0 | 0.0 | 233.3 |
| GIVES UP | 0.7 | -10.4 | 155.0 | 0.0 | 0.3 | -5.3 | 58.3 | 0.0 |
| GOAL WALK | 8.7 | +765.3 | 0.0 | 0.0 | 8.0 | +601.3 | 0.0 | 0.0 |
| GUN MASK | 0.7 | +1.8 | 0.0 | 0.0 | - | - | - | - |
| HARD STAY DROPPED | 1.3 | +0.0 | 0.0 | 40.0 | - | - | - | - |
| HE REFORMS ONCE FREED | 1.3 | +0.0 | 0.0 | 55.3 | 3.7 | +0.0 | 0.0 | 95.3 |
| HIS CHARGE BY HIS RUN | 5.0 | +0.0 | 0.0 | 116.7 | 12.3 | +0.0 | 0.0 | 471.7 |
| HIS CHARGE DENIED | 1.0 | +33.2 | 155.0 | 0.0 | - | - | - | - |
| HIS CHARGE LIST | 2.7 | +0.0 | 0.0 | 0.0 | 4.0 | +0.0 | 0.0 | 0.0 |
| HIS LEGAL MOVES | 4.3 | +0.0 | 0.0 | 0.0 | 9.0 | +0.0 | 0.0 | 223.7 |
| HIS MOVE AND SHOT | 2.0 | -26.1 | 0.0 | 0.0 | 6.0 | -59.9 | 0.0 | 0.0 |
| HIS MOVE AS HE DECIDES | - | - | - | - | 40.3 | +13.3 | 461.3 | 0.0 |
| HIS MOVE WHY | 11.0 | +0.0 | 0.0 | 290.0 | - | - | - | - |
| HIS ONE MOVE | - | - | - | - | 24.0 | -69.6 | 0.0 | 68.7 |
| HIS ONE QUARTER | 5.0 | +0.0 | 0.0 | 27.7 | 6.7 | +0.0 | 0.0 | 0.0 |
| HIS OWN BEST MOVE | 9.0 | +0.0 | 0.0 | 0.0 | 3.0 | +0.0 | 0.0 | 0.0 |
| HIS RANDOM MOVE | 9.3 | +0.0 | 0.0 | 40.0 | - | - | - | - |
| HIS RANDOM MOVER COMES | 1.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HIS RUN AFTER OUR TURN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS RUN AFTER THE TABLE | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| HIS SHOT LIST | 11.0 | +273.5 | 0.0 | 231.3 | 33.7 | +667.3 | 0.0 | 543.3 |
| HIS SHOTS BY HIS RUN | 11.7 | +111.8 | 0.0 | 250.0 | 39.7 | +925.9 | 0.0 | 1042.7 |
| HIS TURN DENIED | - | - | - | - | 0.7 | +2.5 | 58.3 | 62.0 |
| HIS TURN RUN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| HOLD ODDS | 16.3 | +0.0 | 0.0 | 0.0 | 15.3 | +0.0 | 0.0 | 113.3 |
| HOLDER ASSIGNMENT | 10.0 | +672.6 | 0.0 | 0.0 | 7.7 | +715.2 | 0.0 | 56.7 |
| HOLDS AMBUSHERS | 0.3 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| HONEST WORTH | 3.7 | -187.9 | 221.0 | 0.0 | 3.3 | -112.3 | 324.7 | 124.0 |
| HUNT KEPT | 1.0 | +0.0 | 130.0 | 0.0 | - | - | - | - |
| HUNT THE GUNS | 0.3 | +87.3 | 0.0 | 0.0 | - | - | - | - |
| IDLE COST | - | - | - | - | 13.7 | -192.4 | 0.0 | 334.7 |
| JOIN BY POINTS | - | - | - | - | 0.3 | +10.8 | 0.0 | 38.7 |
| JOINT CHARGE NOW | 0.7 | +52.3 | 0.0 | 0.0 | 1.0 | -54.5 | 152.3 | 0.0 |
| JOINT KNOWS CHALLENGE | 0.3 | -24.1 | 0.0 | 0.0 | - | - | - | - |
| KEPT FROM ITS LAST STOP | 0.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 0.0 |
| LANE BY FIGURES | 1.3 | +91.8 | 0.0 | 0.0 | 1.0 | +8.0 | 0.0 | 0.0 |
| LEGAL CHARGES ONLY | 17.0 | +0.0 | 857.0 | 395.7 | 6.0 | +0.0 | 0.0 | 1298.7 |
| LONE WIZARD KEPT IN | 0.3 | +5.0 | 0.0 | 0.0 | - | - | - | - |
| LONG SHOT | 0.3 | -19.1 | 0.0 | 0.0 | 0.7 | +25.9 | 0.0 | 0.0 |
| LOST AFTER ESCAPE | 2.7 | +8.7 | 224.0 | 0.0 | 1.3 | +2.5 | 0.0 | 62.0 |
| LOST CHARGE | - | - | - | - | 0.3 | -0.2 | 58.7 | 0.0 |
| MANOEUVRE | 2.3 | +0.9 | 0.0 | 66.3 | 2.0 | +41.5 | 0.0 | 28.3 |
| MARCH AT ESCAPER | - | - | - | - | 0.7 | +2.5 | 0.0 | 0.0 |
| MARCH BY THE SUM | - | - | - | - | 0.3 | +0.4 | 0.0 | 0.0 |
| MARCH CHECK | 0.3 | +8.7 | 0.0 | 0.0 | 0.3 | +9.1 | 0.0 | 0.0 |
| MARCH OF THE TABLE | 0.3 | +11.5 | 0.0 | 0.0 | 1.3 | +1.8 | 0.0 | 0.0 |
| MARCH OVER CASTS | 0.3 | -36.5 | 0.0 | 0.0 | 0.7 | -24.5 | 0.0 | 0.0 |
| MARCH WHEELS ONLY | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| MAX FOR POSITIONING | 2.3 | +40.9 | 0.0 | 0.0 | 3.3 | +89.4 | 0.0 | 53.7 |
| MEETS IN TIME | 3.7 | +211.0 | 0.0 | 0.0 | 3.3 | +109.0 | 0.0 | 0.0 |
| MISSILES IN THE MOVE | 2.0 | +36.0 | 0.0 | 132.7 | 1.7 | +38.4 | 0.0 | 0.0 |
| MISSILES NEXT TURN | 2.7 | +28.2 | 0.0 | 132.7 | 3.3 | +25.5 | 0.0 | 0.0 |
| MOVE ORDER | 2.0 | +0.0 | 0.0 | 0.0 | 2.0 | +0.0 | 0.0 | 0.0 |
| MOVE TO CHARGE COMPUTED | 10.3 | +521.7 | 0.0 | 27.7 | 7.7 | +527.0 | 0.0 | 223.7 |
| MOVES UNITS SPELL | 0.3 | +2.4 | 0.0 | 0.0 | - | - | - | - |
| NEARER NOT NEEDED | 10.3 | +469.8 | 0.0 | 250.0 | 4.0 | +139.4 | 0.0 | 40.7 |
| NEXT CHARGE BY LIST | 4.3 | +289.5 | 0.0 | 0.0 | 2.7 | +198.5 | 0.0 | 155.0 |
| NEXT OBJECTIVE NEARER | 0.3 | -26.4 | 0.0 | 0.0 | - | - | - | - |
| NO DOUBLE ROUNDS | 4.7 | -311.8 | 376.0 | 0.0 | 3.3 | -228.7 | 277.7 | 124.0 |
| NO LATE CUT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO OLD ONE-MOVE GUESS | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NO SECOND RUN | 6.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| NOT TURNED | - | - | - | - | 0.7 | -7.3 | 0.0 | 38.7 |
| NOT WORTH A CAST | 1.0 | -0.8 | 0.0 | 0.0 | 0.7 | -0.2 | 0.0 | 0.0 |
| OFF BEST | 4.0 | -59.7 | 0.0 | 58.7 | 5.3 | -221.8 | 58.7 | 79.3 |
| ONE CHECK AFTER THE LAST CHANGE | 0.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| ONE FIGHT FORMULA | 7.0 | -171.1 | 0.0 | 27.7 | 6.0 | -146.8 | 0.0 | 208.7 |
| ONE OBJECTIVE FORMULA | 4.3 | +46.0 | 0.0 | 0.0 | 3.3 | +116.5 | 0.0 | 28.3 |
| ONE ROUTE | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| OPENS UP | - | - | - | - | 0.7 | +32.3 | 55.3 | 0.0 |
| OVERRUNS AWAY | 0.7 | +4.5 | 40.7 | 0.0 | 1.0 | +13.5 | 27.7 | 0.0 |
| PATHS CROSS | - | - | - | - | 1.0 | +27.0 | 0.0 | 0.0 |
| PLAN RESULT | 41.3 | +611.4 | 581.7 | 536.0 | 39.0 | +355.4 | 27.7 | 1086.0 |
| PROMISE BELOW ZERO | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| PROMISE BY ITS OWN SUM | 15.7 | -294.3 | 0.0 | 27.7 | 11.7 | -405.6 | 0.0 | 68.7 |
| PROMISE KNOWS THE FIGHT | 0.7 | +0.0 | 0.0 | 27.7 | 1.0 | +0.0 | 0.0 | 0.0 |
| QUARTER ODDS | 26.0 | +3073.8 | 158.3 | 55.3 | 22.0 | +2007.1 | 144.3 | 124.0 |
| RANDOM MOVE BY FIGURES | - | - | - | - | 3.3 | +97.8 | 0.0 | 170.0 |
| REAL GROUND | - | - | - | - | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT BY WHAT IT STOPS | - | - | - | - | 0.3 | -1.6 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.3 | +60.6 | 0.0 | 0.0 | 3.3 | +298.0 | 0.0 | 43.3 |
| REDIRECT FOR A FRIEND IN REACH | 2.3 | +0.0 | 0.0 | 0.0 | 1.0 | +0.0 | 0.0 | 0.0 |
| REDIRECT WEIGHED | 0.3 | +0.0 | 0.0 | 0.0 | 0.7 | +38.6 | 0.0 | 62.0 |
| REFORMS TO MEET IT | 3.3 | -234.1 | 0.0 | 0.0 | 0.3 | -0.3 | 0.0 | 0.0 |
| REFUSING RETIRES | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| RESERVE FALL BACK | 0.3 | +4.0 | 0.0 | 0.0 | - | - | - | - |
| RESTRAINS TO SHOOT | 0.3 | +10.7 | 0.0 | 0.0 | - | - | - | - |
| RISK BY ARC | 3.3 | -13.7 | 192.7 | 0.0 | 3.0 | +204.4 | 230.7 | 124.0 |
| RISK ON THE WAY | - | - | - | - | 0.3 | +0.0 | 0.0 | 0.0 |
| ROUNDS AFTER TERROR | 1.0 | -38.8 | 69.0 | 0.0 | 1.0 | -31.6 | 74.7 | 62.0 |
| RUN DOWN | 2.7 | -96.2 | 107.7 | 0.0 | 2.7 | -37.9 | 161.0 | 62.0 |
| SCREEN BY WHAT IT SAVES | - | - | - | - | 1.0 | -98.8 | 0.0 | 0.0 |
| SEARCH SPOT | 0.7 | +6.2 | 0.0 | 0.0 | 0.7 | +31.7 | 0.0 | 0.0 |
| SECOND LOOK | - | - | - | - | 0.7 | +29.6 | 86.3 | 0.0 |
| SELF MOVE SPELL | 2.0 | +38.1 | 0.0 | 0.0 | - | - | - | - |
| SET CREDITED ONCE | - | - | - | - | 0.3 | -2.4 | 0.0 | 0.0 |
| SET UP BY THE SET | 1.0 | +16.0 | 56.7 | 0.0 | 4.7 | +15.8 | 0.0 | 0.0 |
| SET UP TOGETHER | 0.3 | +22.8 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 1.0 | +2.0 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS ON THE TABLE | 7.7 | +0.0 | 0.0 | 58.7 | 2.0 | +0.0 | 0.0 | 38.7 |
| SHOOTS FROM THE BEST SPOT | 1.0 | +31.7 | 0.0 | 0.0 | 0.3 | +9.4 | 0.0 | 0.0 |
| SHOT OR CHARGE | 0.7 | -2.5 | 113.3 | 0.0 | 0.3 | -3.0 | 47.0 | 0.0 |
| SHOT RISK POINTS | 7.0 | -25.6 | 0.0 | 40.0 | 23.0 | -381.3 | 0.0 | 443.3 |
| SHOTS AFTER THE MOVES | 3.3 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOTS IN THE MOVE | 16.7 | +315.1 | 0.0 | 203.3 | 0.7 | +10.4 | 0.0 | 56.7 |
| SPELL WORTH | 1.7 | +45.1 | 0.0 | 0.0 | 3.0 | +6.0 | 0.0 | 0.0 |
| SPELLS IN THE FIGHT | 0.3 | -5.4 | 155.0 | 0.0 | - | - | - | - |
| SPOT AS THE GAME MOVES | 5.3 | +0.0 | 0.0 | 141.0 | 10.3 | +0.0 | 0.0 | 122.7 |
| STAND AND SHOOT | 0.3 | -5.5 | 28.3 | 0.0 | 0.7 | -6.5 | 55.3 | 0.0 |
| STANDS FOR A REASON | - | - | - | - | 1.3 | +0.0 | 94.0 | 0.0 |
| STANDS STILL | 37.3 | +0.0 | 282.0 | 255.3 | 17.7 | +0.0 | 94.0 | 170.0 |
| STAY WORTH | 16.7 | +3.1 | 152.0 | 176.0 | 1.3 | +2.8 | 94.0 | 0.0 |
| STOPS | 0.3 | +6.1 | 0.0 | 0.0 | - | - | - | - |
| STRIKE BY THE ODDS | 1.0 | +8.1 | 0.0 | 0.0 | - | - | - | - |
| STUBBORN BY POINTS | 0.3 | +23.1 | 0.0 | 0.0 | - | - | - | - |
| STUCK PIVOT | - | - | - | - | 0.7 | +0.0 | 0.0 | 56.7 |
| STUPIDITY NEXT TURN | - | - | - | - | 2.0 | +0.0 | 0.0 | 0.0 |
| SUPPORT ADDS | 5.7 | +180.7 | 0.0 | 152.7 | 7.0 | +399.5 | 0.0 | 67.0 |
| SUPPORT NARROWED | - | - | - | - | 0.7 | +0.0 | 94.0 | 0.0 |
| SUPPORT WORKED OUT | 5.7 | +180.7 | 0.0 | 152.7 | 7.0 | +399.5 | 0.0 | 67.0 |
| SURE REACH TOGETHER | 1.0 | +6.3 | 0.0 | 20.0 | 1.0 | +3.4 | 0.0 | 28.3 |
| SWIFTSTRIDE BY POINTS | 0.3 | +12.3 | 0.0 | 0.0 | - | - | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 2.0 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| THE PROMISED MOVE | - | - | - | - | 0.3 | +0.0 | 0.0 | 28.3 |
| THE RISK READS HIS RUN | - | - | - | - | 6.0 | +0.0 | 0.0 | 0.0 |
| THE ROW IN ITS ORDER | 2.3 | +0.0 | 0.0 | 0.0 | 5.3 | +0.0 | 0.0 | 67.0 |
| THE ROW KEEPS ITS WAY | 1.0 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 205.3 |
| THE ROW READS HIS LAST RUN | - | - | - | - | 1.3 | +0.0 | 0.0 | 28.3 |
| THE STEP BACK IS MADE | 0.3 | +0.0 | 0.0 | 0.0 | 3.3 | +0.0 | 0.0 | 40.7 |
| THE TABLE AGAIN | 6.0 | +0.0 | 0.0 | 0.0 | 6.0 | +0.0 | 0.0 | 0.0 |
| THE TABLE BINDS | 42.3 | +0.0 | 0.0 | 376.0 | 37.7 | +0.0 | 0.0 | 509.3 |
| TIED UP BY THE SUM | 1.7 | +227.3 | 192.7 | 0.0 | 1.7 | +196.3 | 250.0 | 62.0 |
| TIME ON OUR SIDE | 45.3 | +503.2 | 0.0 | 677.7 | - | - | - | - |
| TWO OR MORE ARRIVE | 0.3 | +0.3 | 0.0 | 0.0 | - | - | - | - |
| WAITS AGAIN | 2.7 | +0.0 | 0.0 | 0.0 | 1.7 | +0.0 | 0.0 | 68.7 |
| WHO GETS IN | - | - | - | - | 0.3 | -45.9 | 58.3 | 0.0 |
| WHO HITS BACK | 0.7 | +54.7 | 0.0 | 0.0 | 1.0 | +134.0 | 0.0 | 62.0 |
| WHOLE FIGHT DANGER | 3.0 | -143.0 | 0.0 | 116.7 | 1.7 | -212.7 | 0.0 | 56.7 |
| WHOLE FIGHT GAIN | 0.3 | +41.6 | 0.0 | 0.0 | 0.3 | +34.1 | 47.0 | 0.0 |
| WOUNDED STAYS OUT | 0.7 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| WOUNDS ON THE RANKS | 0.3 | +1.9 | 0.0 | 0.0 | 3.7 | +67.2 | 0.0 | 0.0 |

### Rule changes: ccut-c940641-p45

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| HIS MOVE AS HE DECIDES | 121 | 121 | 81 | 27.00 | +0 | +0.0 |
| ARMY TABLE | 135 | 135 | 80 | 26.67 | +974 | +12.2 |
| LEGAL CHARGES ONLY | 69 | 69 | 69 | 23.00 | +0 | +0.0 |
| HOLDER ASSIGNMENT | 53 | 53 | 50 | 16.67 | +3230 | +64.6 |
| FIVE ACTION | 503 | 471 | 41 | 13.67 | +1897 | +46.3 |
| PROMISE BY ITS OWN SUM | 82 | 82 | 40 | 13.33 | -2100 | -52.5 |
| THE TABLE AGAIN | 36 | 36 | 32 | 10.67 | +0 | +0.0 |
| HIS SHOT LIST | 134 | 124 | 30 | 10.00 | +288 | +9.6 |
| OFF BEST | 28 | 28 | 28 | 9.33 | -845 | -30.2 |
| DEPLOY BY FIGURES | 41 | 41 | 25 | 8.33 | +230 | +9.2 |
| HIS SHOTS BY HIS RUN | 154 | 145 | 24 | 8.00 | +219 | +9.1 |
| HIS MOVE WHY | 33 | 33 | 21 | 7.00 | +0 | +0.0 |
| MOVE TO CHARGE COMPUTED | 54 | 40 | 21 | 7.00 | +592 | +28.2 |
| HIS ONE MOVE | 72 | 65 | 18 | 6.00 | +0 | +0.0 |
| FOUR ROUNDS | 25 | 23 | 17 | 5.67 | +780 | +45.9 |
| QUARTER ODDS | 144 | 133 | 17 | 5.67 | +1205 | +70.9 |
| THE RISK READS HIS RUN | 18 | 18 | 13 | 4.33 | +0 | +0.0 |
| MOVE ORDER | 12 | 12 | 12 | 4.00 | +0 | +0.0 |
| REDIRECT FOR A FRIEND IN REACH | 10 | 10 | 10 | 3.33 | +0 | +0.0 |
| SHOT RISK POINTS | 90 | 80 | 10 | 3.33 | +175 | +17.5 |
| TIME ON OUR SIDE | 136 | 122 | 10 | 3.33 | +63 | +6.3 |
| SUPPORT ADDS | 38 | 36 | 9 | 3.00 | +328 | +36.4 |
| SUPPORT WORKED OUT | 38 | 36 | 9 | 3.00 | +328 | +36.4 |
| COVER ONCE | 61 | 39 | 8 | 2.67 | +11 | +1.4 |
| MEETS IN TIME | 21 | 21 | 8 | 2.67 | +429 | +53.6 |
| RANDOM MOVE BY FIGURES | 10 | 10 | 8 | 2.67 | +293 | +36.7 |
| ADVANCE LANE KEPT | 7 | 7 | 7 | 2.33 | +0 | +0.0 |
| CHALLENGE BY POINTS | 7 | 7 | 7 | 2.33 | +73 | +10.4 |
| GOAL WALK | 50 | 49 | 7 | 2.33 | +303 | +43.3 |
| IDLE COST | 41 | 34 | 7 | 2.33 | +42 | +6.0 |
| LANE BY FIGURES | 7 | 7 | 7 | 2.33 | +300 | +42.8 |
| SET UP BY THE SET | 17 | 17 | 7 | 2.33 | +161 | +23.0 |
| TIED UP BY THE SUM | 10 | 8 | 7 | 2.33 | +154 | +22.0 |
| CAST JOB | 7 | 7 | 6 | 2.00 | +76 | +12.7 |
| CHARGE NOW FIRST | 15 | 15 | 6 | 2.00 | -352 | -58.7 |
| HOLDS AMBUSHERS | 6 | 6 | 6 | 2.00 | +0 | +0.0 |
| NEXT CHARGE BY LIST | 21 | 19 | 6 | 2.00 | +401 | +66.8 |
| JOINT CHARGE NOW | 5 | 5 | 5 | 1.67 | -7 | -1.3 |
| MANOEUVRE | 13 | 13 | 5 | 1.67 | +141 | +28.1 |
| MARCH OF THE TABLE | 5 | 5 | 5 | 1.67 | -40 | -8.0 |
| WHO HITS BACK | 5 | 5 | 5 | 1.67 | +453 | +90.5 |
| CHARGE LOSSES | 64 | 59 | 4 | 1.33 | +105 | +26.2 |
| FALLS SHORT | 56 | 42 | 4 | 1.33 | +21 | +5.2 |
| FOLLOW UP WEIGHED | 4 | 4 | 4 | 1.33 | +354 | +88.6 |
| HARD STAY DROPPED | 4 | 4 | 4 | 1.33 | +0 | +0.0 |
| MAX FOR POSITIONING | 17 | 16 | 4 | 1.33 | +23 | +5.8 |
| RISK BY ARC | 19 | 17 | 4 | 1.33 | +160 | +40.0 |
| SEARCH SPOT | 4 | 4 | 4 | 1.33 | +114 | +28.4 |
| SHOOTS FROM THE BEST SPOT | 4 | 4 | 4 | 1.33 | +29 | +7.1 |
| CANNON SIGHT KEPT | 3 | 3 | 3 | 1.00 | +0 | +0.0 |
| CHAFF IN THE MOVE | 4 | 4 | 3 | 1.00 | +0 | +0.0 |
| CHAFF PASSED | 3 | 3 | 3 | 1.00 | -0 | -0.1 |
| EXACT ROUND | 9 | 9 | 3 | 1.00 | +6 | +2.1 |
| PATHS CROSS | 3 | 3 | 3 | 1.00 | +81 | +27.0 |
| REDIRECT COUNTER | 17 | 15 | 3 | 1.00 | +342 | +113.9 |
| REDIRECT WEIGHED | 3 | 3 | 3 | 1.00 | +167 | +55.7 |
| SHOOTERS IN TWO RANKS | 3 | 3 | 3 | 1.00 | +6 | +2.0 |
| STAY WORTH | 54 | 51 | 3 | 1.00 | +4 | +1.2 |
| AFTERMATH WITH FRIENDS | 2 | 2 | 2 | 0.67 | +35 | +17.5 |
| CASTS FROM BEHIND | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| FEATURE BUFFS | 12 | 12 | 2 | 0.67 | +140 | +69.8 |
| MARCH CHECK | 2 | 2 | 2 | 0.67 | +48 | +23.8 |
| NEARER NOT NEEDED | 43 | 41 | 2 | 0.67 | +87 | +43.4 |
| ONE FIGHT FORMULA | 39 | 20 | 2 | 0.67 | +11 | +5.5 |
| ONE OBJECTIVE FORMULA | 23 | 15 | 2 | 0.67 | +48 | +23.9 |
| SECOND LOOK | 2 | 2 | 2 | 0.67 | +89 | +44.4 |
| SHOTS AFTER THE MOVES | 10 | 10 | 2 | 0.67 | +0 | +0.0 |
| SHOTS IN THE MOVE | 52 | 39 | 2 | 0.67 | +10 | +4.9 |
| STRIKE BY THE ODDS | 3 | 3 | 2 | 0.67 | +18 | +8.8 |
| STUCK PIVOT | 2 | 2 | 2 | 0.67 | +0 | +0.0 |
| WHOLE FIGHT DANGER | 14 | 12 | 2 | 0.67 | +59 | +29.7 |
| WHOLE FIGHT GAIN | 2 | 2 | 2 | 0.67 | +98 | +48.8 |
| AFTERMATH IN POINTS | 1 | 1 | 1 | 0.33 | +80 | +79.9 |
| ASSAILMENT BY POINTS | 1 | 1 | 1 | 0.33 | +11 | +11.3 |
| BEST OVERALL | 1 | 1 | 1 | 0.33 | +16 | +15.5 |
| BEST PRIZE | 1 | 1 | 1 | 0.33 | -42 | -41.7 |
| CHARGE NOT DECLARED | 1 | 1 | 1 | 0.33 | -111 | -110.9 |
| FACES THE THREAT | 1 | 1 | 1 | 0.33 | +16 | +15.5 |
| FALL BACK GOOD ORDER | 15 | 13 | 1 | 0.33 | +0 | +0.1 |
| FIGHT TO THE END | 8 | 8 | 1 | 0.33 | +19 | +19.2 |
| HIS CHARGE DENIED | 3 | 3 | 1 | 0.33 | +6 | +5.5 |
| JOIN BY POINTS | 1 | 1 | 1 | 0.33 | +32 | +32.3 |
| LONE WIZARD KEPT IN | 1 | 1 | 1 | 0.33 | +15 | +15.0 |
| LONG SHOT | 3 | 3 | 1 | 0.33 | +3 | +2.8 |
| MARCH BY THE SUM | 1 | 1 | 1 | 0.33 | +1 | +1.3 |
| MISSILES IN THE MOVE | 11 | 8 | 1 | 0.33 | +15 | +15.0 |
| MISSILES NEXT TURN | 18 | 13 | 1 | 0.33 | +0 | +0.0 |
| MOVES UNITS SPELL | 1 | 1 | 1 | 0.33 | +7 | +7.3 |
| OPENS UP | 2 | 1 | 1 | 0.33 | +0 | +0.1 |
| OVERRUNS AWAY | 5 | 5 | 1 | 0.33 | +0 | +0.1 |
| RESERVE FALL BACK | 1 | 1 | 1 | 0.33 | +12 | +11.9 |
| RESTRAINS TO SHOOT | 1 | 1 | 1 | 0.33 | +32 | +32.1 |
| STUBBORN BY POINTS | 1 | 1 | 1 | 0.33 | +69 | +69.4 |
| SURE REACH TOGETHER | 6 | 6 | 1 | 0.33 | +0 | +0.0 |
| SWIFTSTRIDE BY POINTS | 1 | 1 | 1 | 0.33 | +37 | +36.8 |
| THE ROW IN ITS ORDER | 23 | 1 | 1 | 0.33 | +0 | +0.0 |
| WHO GETS IN | 1 | 1 | 1 | 0.33 | -138 | -137.9 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| BACKUP TARGETS | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLANNED TARGET | 12 | 12 | 0 | 0.00 | - | - |
| CHAMPION KNOWS CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| CLOSES ON WHAT IT BEATS | 67 | 62 | 0 | 0.00 | - | - |
| DENIED BY THE FIGHT | 3 | 3 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 57 | not checked | - | - | - | - |
| FREED FROM HIS FIGHT | 40 | 37 | 0 | 0.00 | - | - |
| GIVES UP | 3 | 3 | 0 | 0.00 | - | - |
| GUN MASK | 2 | 2 | 0 | 0.00 | - | - |
| HE REFORMS ONCE FREED | 15 | 15 | 0 | 0.00 | - | - |
| HIS CHARGE BY HIS RUN | 52 | 47 | 0 | 0.00 | - | - |
| HIS CHARGE LIST | 20 | 17 | 0 | 0.00 | - | - |
| HIS LEGAL MOVES | 40 | 33 | 0 | 0.00 | - | - |
| HIS MOVE AND SHOT | 24 | 22 | 0 | 0.00 | - | - |
| HIS ONE QUARTER | 35 | 31 | 0 | 0.00 | - | - |
| HIS OWN BEST MOVE | 36 | 32 | 0 | 0.00 | - | - |
| HIS RANDOM MOVE | 28 | 27 | 0 | 0.00 | - | - |
| HIS RANDOM MOVER COMES | 4 | 3 | 0 | 0.00 | - | - |
| HIS RUN AFTER OUR TURN | 36 | 36 | 0 | 0.00 | - | - |
| HIS RUN AFTER THE TABLE | 18 | 18 | 0 | 0.00 | - | - |
| HIS TURN DENIED | 2 | 2 | 0 | 0.00 | - | - |
| HIS TURN RUN | 36 | 36 | 0 | 0.00 | - | - |
| HOLD ODDS | 95 | 92 | 0 | 0.00 | - | - |
| HONEST WORTH | 21 | 19 | 0 | 0.00 | - | - |
| HUNT KEPT | 3 | trace | - | - | - | - |
| HUNT THE GUNS | 1 | trace | - | - | - | - |
| JOINT KNOWS CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| KEPT FROM ITS LAST STOP | 7 | 7 | 0 | 0.00 | - | - |
| LOST AFTER ESCAPE | 12 | 12 | 0 | 0.00 | - | - |
| LOST CHARGE | 1 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 3 | 3 | 0 | 0.00 | - | - |
| MARCH WHEELS ONLY | 3 | 3 | 0 | 0.00 | - | - |
| NEXT OBJECTIVE NEARER | 1 | 1 | 0 | 0.00 | - | - |
| NO DOUBLE ROUNDS | 24 | 22 | 0 | 0.00 | - | - |
| NO LATE CUT | 2 | 2 | 0 | 0.00 | - | - |
| NO OLD ONE-MOVE GUESS | 18 | 18 | 0 | 0.00 | - | - |
| NO SECOND RUN | 18 | 18 | 0 | 0.00 | - | - |
| NOT TURNED | 2 | 2 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 5 | not checked | - | - | - | - |
| ONE CHECK AFTER THE LAST CHANGE | 4 | not checked | - | - | - | - |
| ONE ROUTE | 3 | 3 | 0 | 0.00 | - | - |
| PLAN RESULT | 241 | trace | - | - | - | - |
| PROMISE BELOW ZERO | 1 | 1 | 0 | 0.00 | - | - |
| PROMISE KNOWS THE FIGHT | 5 | 4 | 0 | 0.00 | - | - |
| REAL GROUND | 3 | 3 | 0 | 0.00 | - | - |
| REDIRECT BY WHAT IT STOPS | 1 | 1 | 0 | 0.00 | - | - |
| REFORMS TO MEET IT | 11 | 10 | 0 | 0.00 | - | - |
| REFUSING RETIRES | 1 | 1 | 0 | 0.00 | - | - |
| RISK ON THE WAY | 1 | 1 | 0 | 0.00 | - | - |
| ROUNDS AFTER TERROR | 6 | 6 | 0 | 0.00 | - | - |
| RUN DOWN | 16 | 14 | 0 | 0.00 | - | - |
| SCREEN BY WHAT IT SAVES | 3 | 3 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 6 | not checked | - | - | - | - |
| SET CREDITED ONCE | 1 | 1 | 0 | 0.00 | - | - |
| SET UP TOGETHER | 1 | 1 | 0 | 0.00 | - | - |
| SHOOTERS ON THE TABLE | 29 | not checked | - | - | - | - |
| SHOT OR CHARGE | 3 | 3 | 0 | 0.00 | - | - |
| SPELL WORTH | 14 | not checked | - | - | - | - |
| SPELLS IN THE FIGHT | 1 | 1 | 0 | 0.00 | - | - |
| SPOT AS THE GAME MOVES | 47 | 43 | 0 | 0.00 | - | - |
| STAND AND SHOOT | 3 | 2 | 0 | 0.00 | - | - |
| STANDS FOR A REASON | 4 | 4 | 0 | 0.00 | - | - |
| STANDS STILL | 165 | 160 | 0 | 0.00 | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| STUPIDITY NEXT TURN | 6 | 6 | 0 | 0.00 | - | - |
| SUPPORT NARROWED | 2 | 2 | 0 | 0.00 | - | - |
| THE DEARER SUM KEEPS ITS PLAN | 8 | not checked | - | - | - | - |
| THE PROMISED MOVE | 1 | not checked | - | - | - | - |
| THE ROW KEEPS ITS WAY | 13 | not checked | - | - | - | - |
| THE ROW READS HIS LAST RUN | 4 | not checked | - | - | - | - |
| THE STEP BACK IS MADE | 11 | not checked | - | - | - | - |
| THE TABLE BINDS | 240 | not checked | - | - | - | - |
| TWO OR MORE ARRIVE | 1 | not checked | - | - | - | - |
| WAITS AGAIN | 13 | 11 | 0 | 0.00 | - | - |
| WOUNDED STAYS OUT | 2 | 2 | 0 | 0.00 | - | - |
| WOUNDS ON THE RANKS | 12 | 12 | 0 | 0.00 | - | - |

### Off best figure: ccut-c940641-p45

Each pick below the best figure on its list, by whose say: a gate (OFF BEST rows, OffBest.cs) or a rule whose own row says it took the lower figure. Per side: times a game; VP a time = the best figure minus the one taken, by the row's own numbers. NO REASON = nothing named it (code the tests never reach).

| Reason | Kind | Mine a game | Opponent a game | VP a time |
| --- | --- | --- | --- | --- |
| PROMISE BY ITS OWN SUM | rule | 7.67 | 5.67 | 52.5 |
| JOB FIRST | gate | 3.33 | 3.00 | 34.0 |
| ARMY TABLE | rule | 1.67 | 3.67 | 73.8 |
| HOLDER ASSIGNMENT | rule | 1.67 | 0.67 | 39.4 |
| CHARGE NOW FIRST | rule | 1.67 | 0.33 | 58.7 |
| RULE SWITCHED OFF | gate | - | 2.00 | 28.9 |
| MARCH OF THE TABLE | rule | 0.33 | 1.00 | 10.0 |
| JOINT CHARGE NOW | rule | - | 0.67 | 109.6 |
| NO REASON | gate | 0.67 | - | 2.9 |
| SET UP BY THE SET | rule | - | 0.67 | 52.1 |
| BEST PRIZE | rule | - | 0.33 | 41.7 |
| CHARGE NOT DECLARED | rule | - | 0.33 | 110.9 |
| FALLBACK | gate | - | 0.33 | 18.8 |
| WHO GETS IN | rule | - | 0.33 | 137.9 |

### Plans: ccut-c940641-p45

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 4.3 | 54% | 645 | 440 | 68% |
| Mine | move | 32.7 | 94% | 1941 | 0 | 0% |
| Mine | shoot | 4.3 | 38% | 271 | 171 | 63% |
| Opponent | charge | 2.7 | 62% | 266 | 292 | 110% |
| Opponent | join | 3.7 | 82% | 139 | 0 | 0% |
| Opponent | move | 31.3 | 97% | 1579 | 0 | 0% |
| Opponent | shoot | 0.7 | 100% | 5 | 63 | 1331% |
| Opponent | support | 0.7 | 100% | 12 | 0 | 0% |

### Packages: hunt the guns, ccut-c940641-p45

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.3 | 1 | 1 | - | - | - | - | - | - | - | 0 |
| Opponent | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| High Elf Realms | 1.0 | 1 | 1 | - | - | - | - | - | - | - | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: ccut-c940641-p45

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | REDIRECT COUNTER | 2.3 | 0% | - | - | - | - | - | - | - | - |
| Opponent | REDIRECT COUNTER | 3.3 | 20% | 50% | 0% | - | 0% | 0% | 0% | 100% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ccut-c940641-p45

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 94 (3) | 94 | 0 | 0 | 0% | 6.0 | 94 (3) | - | - | 94 (3) | - |
| Mine | Chaff | 2 | 338 (2) | 0 | 338 | 0 | 0% | 1.5 | 262 (1) | 412 (1) | - | 262 (1) | 412 (1) |
| Mine | Character | 8 | 60 (8) | 60 | 0 | 5 | 25% | 1.8 | 92 (4) | 24 (3) | 0 (1) | 78 (5) | 6 (3) |
| Mine | Clean-up | 1 | 70 (1) | 0 | 70 | 0 | 100% | - | 70 (1) | - | - | 70 (1) | - |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 100 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Mine | Fast Hammer | 4 | 21 (4) | 21 | 0 | 21 | 50% | 2.0 | 26 (3) | 0 (1) | - | 0 (3) | 170 (1) |
| Mine | Hammer | 3 | 17 (3) | 0 | 17 | 26 | 33% | 1.5 | 0 (1) | 23 (2) | - | 0 (1) | 23 (2) |
| Mine | Shooter | 6 | 25 (6) | 7 | 18 | 38 | 0% | 1.3 | 12 (3) | 43 (3) | - | 50 (3) | 0 (3) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 0% | 3.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | War machine | 2 | 0 (2) | 0 | 0 | 0 | 0% | 1.0 | 0 (2) | - | - | 0 (1) | 0 (1) |
| Mine | Wizard | 1 | 0 (1) | 0 | 0 | 0 | 0% | 1.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 5 | 0 (5) | 0 | 0 | 17 | 80% | 1.0 | 0 (2) | 0 (3) | - | 0 (1) | 0 (4) |
| Opponent | Character | 10 | 11 (10) | 11 | 0 | 52 | 40% | 2.8 | 11 (4) | 15 (5) | 0 (1) | 20 (7) | 0 (3) |
| Opponent | Clean-up | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Fast Hammer | 6 | 25 (6) | 23 | 2 | 14 | 17% | 3.8 | 30 (3) | 20 (3) | - | 45 (4) | 0 (2) |
| Opponent | Hammer | 5 | 13 (5) | 0 | 13 | 36 | 0% | 3.4 | 20 (3) | 0 (2) | - | 15 (4) | 0 (1) |
| Opponent | Holder | 4 | 49 (4) | 0 | 49 | 17 | 75% | 5.0 | 0 (2) | 117 (2) | - | 80 (2) | 13 (2) |
| Opponent | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Wizard | 3 | 13 (3) | 13 | 0 | 44 | 0% | 3.0 | 0 (1) | 0 (1) | 31 (1) | 31 (1) | 0 (2) |

### Charged fights: ccut-c940641-p45

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 1 | 232 | 195 | 3.0 | 1.0 | 65 | 0 | +65 | 3 of 3 | 1 of 3 | - | +65 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 1336 | 6.0 | 1.0 | 223 | 0 | +223 | 1 of 6 | 6 of 6 | - | +223 |
| Mine | Lizardmen | 1 | 0 | 45 | 3.0 | 1.0 | 15 | 0 | +15 | 2 of 3 | 1 of 3 | - | +15 |
| **Mine** | all armies | 3 | 77 | 525 | 4.0 | 1.0 | 131 | 0 | +131 | 6 of 12 | 8 of 12 | - | +131 |
| Opponent | Vampire Counts | 1 | 0 | 316 | 4.0 | 1.5 | 79 | 46 | +32 | 0 of 4 | 3 of 4 | +158 | -93 |
| Opponent | Warriors of Chaos | 2 | 30 | 88 | 1.0 | 1.0 | 88 | 0 | +88 | 1 of 2 | 2 of 2 | - | +88 |
| **Opponent** | all armies | 3 | 20 | 164 | 2.0 | 1.3 | 82 | 31 | +51 | 1 of 6 | 5 of 6 | +158 | -2 |

### Effective charges: ccut-c940641-p45

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | High Elf Realms | 3 | 0 | 1 (net +0) | 1 (net +0) | 1 (net +195) | 0 | 0 | 0 | 33% (1 of 3) |
| Mine | Kingdom of Bretonnia | 6 | 1 (net +0) | 0 | 1 (net +0) | 0 | 2 (net +290) | 2 (net +378) | 0 | 17% (1 of 6) |
| Mine | Lizardmen | 3 | 2 (net +0) | 0 | 0 | 0 | 0 | 0 | 1 | 0% (0 of 2) |
| Opponent | Vampire Counts | 4 | 0 | 0 | 0 | 0 | 0 | 2 (net +158) | 2 | 0% (0 of 2) |

### Charged fights, damage counted: ccut-c940641-p45

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 3 | 212 | 322 | +0 | 121 | 55 | +66 | +31.2 |
| Mine | 50-54% | 1 | 497 | 201 | +0 | 201 | 110 | +91 | +18.3 |
| Mine | Effective (55-75%) | 2 | 248 | 283 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | 76-89% | 1 | 115 | 195 | +195 | 195 | 86 | +109 | +94.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 323 | 188 | +378 | 378 | 0 | +378 | +117.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 2 | 371 | 104 | +290 | 320 | 31 | +289 | +77.9 |
| Mine | No odds | 1 | 141 | 45 | +45 | 45 | 0 | +45 | +31.9 |
| Mine | All fights | 12 | 273 | 213 | +131 | 183 | 35 | +148 | +54.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 2 | 304 | 158 | +158 | 176 | 0 | +176 | +57.9 |
| Opponent | No odds | 4 | 295 | 168 | -2 | 96 | 46 | +50 | +16.8 |
| Opponent | All fights | 6 | 298 | 164 | +51 | 123 | 31 | +92 | +30.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ccut-c940641-p45 | move | 28 | 5 (18%) | 4 (14%) | 4 (14%) | 19 (68%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Opponent | L1727 |
| Invocation of Nehek | Opponent | L1727 |
| Ring of Doom | Mine | L1531 |
| Ring of Doom | Opponent | L1531 |

# Doctrine scorecard: ef2-mine-f5fe7c8-p3

### Scorecard: ef2-mine-f5fe7c8-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | 2 | 1 | 1 | 1 | 0 | 0 | 322 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 5 | 1 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 4 | - | 0 | 1 | 0 | 0 | 0 | 387 |
| L0126 | 6 | 1 | Opponent | no | 8 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 4 | - | 0 | 5 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Opponent | no | 8 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | yes | 2 | 1 | 3 | 2 | 0 | 0 | 0 | 170 |
| L0226 | 4 | 1 | Opponent | no | 1 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | yes | - | 4 | 2 | 1 | 0 | 0 | 0 | 590 |
| L0311 | 5 | 1 | Opponent | yes | - | 5 | 1 | 0 | 0 | 0 | 0 | 526 |
| L0327 | 3 | 1 | Mine | yes | 1 | 3 | 2 | 0 | 0 | 0 | 0 | 590 |
| L0327 | 3 | 1 | Opponent | no | 9 | 2 | 6 | 3 | 1 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 3 | 1 | 4 | 1 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | yes | - | 6 | 2 | 1 | 0 | 0 | 0 | 479 |
| L0429 | 3 | 1 | Mine | yes | 6 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 1 | 1 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 0 | 6 | 0 | 0 | 0 | 0 | 0 | 686 |
| L0516 | 6 | 1 | Opponent | no | 1 | 3 | 3 | 1 | 1 | 0 | 0 | 200 |
| L0533 | 5 | 1 | Mine | yes | - | - | 0 | 2 | 0 | 0 | 0 | 548 |
| L0533 | 5 | 1 | Opponent | yes | - | 6 | 1 | 6 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 615 |
| L0620 | 2 | 1 | Opponent | - | - | 6 | 2 | 4 | 1 | 0 | 0 | 95 |
| L0709 | 1 | 1 | Mine | yes | 2 | 2 | 4 | 0 | 1 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | no | 3 | 2 | 2 | 0 | 0 | 0 | 0 | 524 |
| L0725 | 5 | 1 | Mine | yes | - | 4 | 1 | 1 | 0 | 0 | 0 | 375 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | yes | - | 6 | 1 | 1 | 0 | 0 | 0 | 515 |
| L0815 | 5 | 1 | Opponent | yes | - | 3 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0831 | 3 | 1 | Mine | yes | 12 | 2 | 3 | 1 | 0 | 0 | 0 | 605 |
| L0831 | 3 | 1 | Opponent | no | 0 | - | 1 | 3 | 2 | 0 | 0 | 170 |
| L0922 | 4 | 1 | Mine | no | 1 | 2 | 3 | 0 | 0 | 0 | 0 | 515 |
| L0922 | 4 | 1 | Opponent | no | 1 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1013 | 5 | 1 | Mine | yes | - | 2 | 4 | 1 | 0 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | no | - | 2 | 1 | 2 | 3 | 0 | 0 | 317 |
| L1030 | 4 | 1 | Mine | no | 0 | 2 | 3 | 0 | 1 | 0 | 0 | 627 |
| L1030 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 1 | 2 | 6 | 0 | 0 | 0 | 0 | 330 |
| L1122 | 6 | 1 | Opponent | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 242 |
| L1216 | 4 | 1 | Mine | no | 0 | 2 | 4 | 0 | 2 | 0 | 0 | 524 |
| L1216 | 4 | 1 | Opponent | no | 5 | 2 | 3 | 2 | 0 | 0 | 0 | 260 |
| L1232 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 330 |
| L1232 | 2 | 1 | Opponent | - | - | 1 | 4 | 3 | 1 | 0 | 0 | 170 |
| L1327 | 1 | 1 | Mine | no | 6 | 4 | 3 | 0 | 0 | 0 | 0 | 140 |
| L1327 | 1 | 1 | Opponent | no | 2 | 2 | 4 | 5 | 0 | 0 | 0 | 50 |
| L1422 | 6 | 1 | Mine | no | 8 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1422 | 6 | 1 | Opponent | no | 3 | 1 | 4 | 0 | 0 | 0 | 0 | 170 |
| L1519 | 1 | 1 | Mine | no | 0 | 3 | 4 | 0 | 0 | 0 | 0 | 199 |
| L1519 | 1 | 1 | Opponent | no | 3 | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | yes | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | no | - | 4 | 3 | 1 | 0 | 0 | 0 | 639 |
| L1633 | 1 | 1 | Mine | no | 1 | 2 | 1 | 3 | 0 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 1 | 1 | 4 | 3 | 0 | 0 | 0 | 144 |
| L1731 | 3 | 1 | Mine | no | 1 | 4 | 5 | 0 | 1 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Opponent | no | 0 | 2 | 0 | 2 | 0 | 0 | 0 | 340 |
| L1831 | 1 | 1 | Mine | no | 10 | 3 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 1 | 6 | 1 | 1 | 1 | 0 | 0 | 340 |
| L1932 | 6 | 1 | Mine | no | 3 | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1932 | 6 | 1 | Opponent | no | 3 | 2 | 6 | 1 | 1 | 0 | 0 | 340 |
| L2033 | 5 | 1 | Mine | no | - | - | 1 | 7 | 1 | 0 | 0 | 420 |
| L2033 | 5 | 1 | Opponent | yes | - | - | 0 | 5 | 1 | 0 | 0 | 405 |
| L2223 | 3 | 1 | Mine | no | 4 | 2 | 5 | 0 | 0 | 0 | 0 | 332 |
| L2223 | 3 | 1 | Opponent | no | 4 | 1 | 6 | 0 | 1 | 0 | 0 | 185 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 2 | 0 | 1 | 0 | 0 | 185 |
| L2327 | 5 | 1 | Opponent | yes | - | 2 | 6 | 2 | 1 | 0 | 0 | 190 |
| L2433 | 3 | 1 | Mine | no | 9 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 0 | 1 | 5 | 1 | 0 | 0 | 0 | 236 |
| L2630 | 2 | 1 | Mine | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 5 | 4 | 0 | 0 | 0 | 519 |
| L2832 | 6 | 1 | Mine | no | 0 | - | 0 | 1 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Opponent | no | 0 | 2 | 0 | 4 | 0 | 0 | 0 | 0 |
| L3133 | 1 | 1 | Mine | no | 2 | 6 | 2 | 2 | 1 | 0 | 0 | 120 |
| L3133 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 0 | 0 | 0 | 334 |
| **Average** | | | Mine | 41% | 3.3 | 2.8 | 2.8 | 1.0 | 0.3 | 0.0 | 0.0 | 279.9 |
| **Average** | | | Opponent | 22% | 2.3 | 2.5 | 3.2 | 2.0 | 0.4 | 0.0 | 0.0 | 214.0 |

### KPIs: ef2-mine-f5fe7c8-p3

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Winner chose to follow up after the loser gave ground |  | 94% (50 of 53); on the table 94% | 100% (58 of 58); on the table 100% | 97% (108 of 111); on the table 97% |
| Winner chose to pursue after the loser fell back in good order |  | 85% (11 of 13); on the table 85% | 79% (11 of 14); on the table 79% | 81% (22 of 27); on the table 81% |
| Winner chose to pursue after the loser fled |  | 77% (20 of 26); on the table 81% | 64% (23 of 36); on the table 64% | 69% (43 of 62); on the table 71% |
| Winner chose to follow up or pursue (all three) |  | 88% (81 of 92); on the table 89% | 85% (92 of 108); on the table 85% | 86% (173 of 200); on the table 87% |
| Magic missiles tried each own turn | 50%+ | 28% (97 of 342) | 31% (60 of 192) | 29% (157 of 534) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 43% (91 of 214) | 43% (60 of 141) | 43% (151 of 355) |
| Points that never fought | lower | 34% (23574 of 68801) | 38% (27099 of 71990) | 36% (50673 of 140791) |
|   infantry points that never fought | lower | 40% (5681 of 14174) | 53% (7482 of 14220) | 46% (13163 of 28394) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 56% (152 of 272) | 62% (178 of 285) | 59% (330 of 557) |
| Bound items with a magic missile used (at least once a game) |  | 96% (24 of 25); 1.5 uses a game | 92% (22 of 24); 1.8 uses a game | 94% (46 of 49); 1.7 uses a game |
| Bound items with another spell used |  | 64% (9 of 14); 0.5 uses a game | 50% (3 of 6); 0.2 uses a game | 60% (12 of 20); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 45% (9 of 20); 0.2 uses a game | 36% (5 of 14); 0.1 uses a game | 41% (14 of 34); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 51% (30105 of 59391) | 54% (34851 of 64043) | 53% (64956 of 123434) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.3 (19%) | 0.9 (24%) | 2.2 (21%) |
| MARCHED: its unit marched | 1.6 (24%) | 1.0 (27%) | 2.6 (25%) |
| CHARGED: its unit charged | 0.3 (4%) | 0.2 (7%) | 0.5 (5%) |
| IN COMBAT: engaged in combat | 1.7 (25%) | 0.8 (23%) | 2.5 (24%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| FLEEING: fleeing | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) |
| GONE: slain | 0.7 (10%) | 0.4 (11%) | 1.1 (11%) |
| OFF THE TABLE: off the table or not arrived | 1.0 (15%) | 0.1 (3%) | 1.1 (11%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.8 | 1.1 | 2.0 | 4.4 | 0.9 | 1.7 |
| not cast | 4.1 | 1.6 | 4.2 | 10.5 | 2.4 | 19.0 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.2 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.7 (44%) | 0.3 (8%) | 2.2 (21%) | 0.2 (10%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.6 (25%) | 0.5 (21%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (5%) | 0.1 (5%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.3 (7%) | 0.2 (14%) | 0.8 (19%) | 2.5 (24%) | 0.4 (17%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (4%) | 0.0 (0%) | 0.2 (6%) | 0.1 (1%) | 0.0 (1%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (2%) | 0.0 (1%) | 0.1 (1%) | 0.1 (2%) | 0.3 (2%) |
| GONE: slain | 1.2 (29%) | 0.2 (10%) | 0.6 (15%) | 1.1 (11%) | 0.3 (12%) | 2.8 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (7%) | 0.3 (17%) | 0.3 (7%) | 1.1 (11%) | 0.0 (0%) | 0.5 (3%) |
| STUPIDITY: Stupidity | 0.0 (1%) | 0.0 (0%) | 0.1 (2%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.1 (7%) | 0.0 (1%) | 0.1 (1%) | 0.8 (31%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.1 (51%) | 0.1 (7%) | 1.7 (40%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.1 (74%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.3 a game | 0.8 a game | 1.0 a game |
| stood (cast and not dispelled) | 61% (22 of 36) | 74% (14 of 19) | 65% (36 of 55) |
| the unit moved after it | 86% (19 of 22) | 79% (11 of 14) | 83% (30 of 36) |
| it charged on its next turn | 5% (1 of 22) | 7% (1 of 14) | 6% (2 of 36) |
| the enemy charged it first | 27% (6 of 22) | 21% (3 of 14) | 25% (9 of 36) |
| it fought by the end of its next turn | 14% (3 of 22) | 0% (0 of 14) | 8% (3 of 36) |
| it moved out of a charge the enemy had planned (not charged first) | 23% (5 of 22) | 14% (2 of 14) | 19% (7 of 36) |
| none of these (no charge, no fight, no charge escaped) | 45% (10 of 22) | 57% (8 of 14) | 50% (18 of 36) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (482 of 786) | 54% (328 of 603) | 58% (810 of 1389) |
|   cavalry | 63% (43 of 68) | 50% (54 of 109) | 55% (97 of 177) |
|   character | 46% (49 of 107) | 18% (22 of 123) | 31% (71 of 230) |
|   chariot | 37% (35 of 95) | 56% (18 of 32) | 42% (53 of 127) |
|   infantry | 54% (117 of 215) | 67% (172 of 257) | 61% (289 of 472) |
|   monster | 36% (13 of 36) | 40% (2 of 5) | 37% (15 of 41) |
|   war machine | 85% (225 of 265) | 78% (60 of 77) | 83% (285 of 342) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (32%) | 2.0 (26%) | 4.7 (29%) |
| CHARGED: it charged | 1.2 (14%) | 1.9 (25%) | 3.1 (19%) |
| FLEEING: it fled or was fleeing | 0.1 (2%) | 0.3 (4%) | 0.4 (3%) |
| IN COMBAT: it fought this turn or the last | 0.9 (10%) | 0.8 (11%) | 1.7 (10%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.1 (1%) | 0.1 (1%) |
| FREE: none of these - no target in range or sight, or held its fire | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.1 (13%) | 0.9 (12%) | 2.0 (13%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (5%) | 0.3 (4%) | 0.8 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (15%) | 0.9 (12%) | 2.2 (14%) |
| SHELTERED: the target was sheltered | 0.2 (3%) | 0.2 (3%) | 0.5 (3%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| OTHER BAR | 0.3 (4%) | 0.2 (2%) | 0.5 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.1 | 1.0 | 81% | 6.3 pts | 26 pts |
| character | 2.4 | 0.7 | 78% | 6.5 pts | 16 pts |
| chariot | 1.5 | 1.0 | 70% | 17.0 pts | 25 pts |
| infantry | 12.3 | 4.7 | 71% | 10.3 pts | 127 pts |
| monster | 0.5 | 0.1 | 82% | 9.7 pts | 5 pts |
| war machine | 8.3 | 6.5 | 62% | 22.8 pts | 189 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.1 | 5.9 | 5.0 |
| Charges that made contact a game | 3.4 | 3.9 | 3.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.85 declared, 0.62 contact (26 units) | 0.94 declared, 0.67 contact (18 units) | 0.89 declared, 0.64 contact (44 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.40 declared, 1.00 contact (5 units) | 1.82 declared, 1.36 contact (11 units) | 1.69 declared, 1.25 contact (16 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.55 declared, 0.47 contact (219 units) | 0.66 declared, 0.43 contact (265 units) | 0.61 declared, 0.45 contact (484 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 62% (48 of 77) | 60% (9 of 15) | 50% (5 of 10) | 61% (62 of 102) |
| Character in a unit | 90% (27 of 30) | 70% (7 of 10) | 50% (3 of 6) | 80% (37 of 46) |
| Character on its own | 77% (36 of 47) | 54% (25 of 46) | 28% (19 of 69) | 49% (80 of 162) |
| Chariot | 73% (8 of 11) | 75% (9 of 12) | - | 74% (17 of 23) |
| Infantry | 69% (48 of 70) | 38% (16 of 42) | 20% (1 of 5) | 56% (65 of 117) |
| Monster | 62% (21 of 34) | 43% (3 of 7) | - | 59% (24 of 41) |
| Monstrous | 90% (9 of 10) | 45% (5 of 11) | - | 67% (14 of 21) |
| War Machines | 67% (29 of 43) | 100% (2 of 2) | - | 69% (31 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (11 of 11); on the table 100% | 24% (23 of 96) | 12% | 55% (12 of 22) | 83% (5 of 6); 2.5 uses a game | 50% (1 of 2); 0.2 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 71% (5 of 7); on the table 71% | 58% (21 of 36) | 42% | 56% (18 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 75% (3 of 4); on the table 75% | - | 66% | 67% (16 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 80% (12 of 15); on the table 80% | 33% (10 of 30) | 32% | 66% (39 of 59) | 0.0 uses a game | 50% (1 of 2); 0.7 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 8 | 89% (16 of 18); on the table 89% | 26% (50 of 192) | 40% | 49% (36 of 74) | 94% (17 of 18); 5.6 uses a game | 50% (2 of 4); 0.8 uses a game | 25% (2 of 8); 0.2 uses a game |
| High Elf Realms | 7 | 80% (8 of 10); on the table 80% | 24% (10 of 42) | 31% | 56% (30 of 54) | 100% (9 of 9); 3.1 uses a game | 67% (8 of 12); 1.7 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | 90% (9 of 10); on the table 90% | - | 35% | 28% (5 of 18) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Lizardmen | 1 | 100% (2 of 2); on the table 100% | 33% (2 of 6) | 17% | 86% (6 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 0% (0 of 1); on the table 100% | 0% (0 of 6) | 11% | 43% (3 of 7) | 100% (1 of 1); 5.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (7 of 7); on the table 100% | 25% (3 of 12) | 3% | 56% (9 of 16) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Skaven | 2 | 67% (2 of 3); on the table 67% | 25% (3 of 12) | 62% | 79% (11 of 14) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Tomb Kings of Khemri | 6 | 100% (12 of 12); on the table 100% | 0% (0 of 6) | 35% | 58% (15 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 93% (40 of 43); on the table 93% | 33% (18 of 54) | 28% | 54% (25 of 46) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 11 | 77% (36 of 47); on the table 77% | 50% (15 of 30) | 41% | 64% (61 of 96) | 100% (4 of 4); 0.6 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 6 | 100% (10 of 10); on the table 100% | 17% (2 of 12) | 48% | 71% (44 of 62) | 91% (10 of 11); 5.3 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ef2-mine-f5fe7c8-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 57% (52) | 49% (43) | 53% (95) |
| ...free all their last turn and able to turn (per game) | 0.86 | 0.69 | 1.56 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.31 | 0.17 | 0.47 |
| ...with the charger already in that arc before they moved (per game) | 0.58 | 0.47 | 1.06 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.11 | 1.08 | 2.19 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.64 | 0.67 | 1.31 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 8.06 | 7.44 | 15.50 |

### Quality by phase: ef2-mine-f5fe7c8-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.2 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 62% (80 of 129) | 44% (77 of 176) |
| Strategy | Shoot objectives carried out (shot that target) | 43% (148 of 343) | 52% (83 of 159) |
| Strategy | Close-in objectives charged next turn | 17% (31 of 180) | 17% (33 of 192) |
| Strategy | Support requests answered (helper made contact too) | 50% (7 of 14) | 25% (5 of 20) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 22% (2 of 9) | 50% (2 of 4) |
| Strategy | Joined characters whose unit fought | 57% (20 of 35) | 29% (10 of 34) |
| Strategy | Lone characters that fought | 77% (77 of 100) | 78% (78 of 100) |
| Movement | Charges halted short of contact | 0.1 | 0.6 |
| Movement | Idle units | 1.0 | 2.0 |
| Movement | Points that never moved of their own | 279.9 | 214.0 |
| Movement | Fights charged into per game | 3.3 | 3.4 |
| Movement | Charges with odds: long shots (under 50%) | 15 of 105, net +86 | 13 of 104, net +84 |
| Movement | Charges with odds: sweet spot (55-75%) | 20 of 105, net -38 | 22 of 104, net +105 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 8 of 105, net +13 | 13 of 104, net +54 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 40 of 105, net +83 | 35 of 104, net +134 |
| Shooting | Shots by shooting units (incl. breath weapons) | 7.7 | 8.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 42% (118 of 278) | 42% (136 of 322) |
| Shooting | Points destroyed by shooting units | 51.5 | 37.7 |
| Shooting | War machine shots | 6.2 | 2.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 51% (114 of 225) | 32% (23 of 73) |
| Shooting | Points destroyed by war machines | 62.2 | 15.1 |
| Magic | Magic missiles cast | 2.0 | 1.1 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 46% (33 of 72) | 31% (12 of 39) |
| Magic | Wounds caused by magic missiles | 3.0 | 1.6 |
| Magic | Wounds caused by other spells | 1.5 | 1.2 |
| Magic | Points destroyed by magic (all spells) | 119.0 | 24.7 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.4 / 0.2 / 0.8 / 0.2 | 2.0 / 0.3 / 0.3 / 0.5 |
| Combat | Points destroyed in combat | 343.9 | 418.5 |
| Combat | Points run down | 53.3 | 94.7 |
| Combat | Net points per charged fight, damage counted | +52 | +94 |
| Combat | Net per 100 charger points, damage counted | +20.9 | +32.5 |
| Combat | First round won (charged fights) | 63% | 62% |
| Combat | Net points per charged fight | +46 | +100 |
| Combat | Net points per supported fight / lone fight | +65 / +45 | +202 / +84 |
| Combat | Charged fights on a top-3 enemy unit | 32 of 119 | 55 of 121 |
| Game | Points lost | 746.2 | 681.1 |
| Game | VP from objectives | 536.9 | 528.3 |
| Game | Lone holders (player turns) | 3.3 | 2.3 |

- Mine won / drew / lost: 13 / 8 / 15 of 36 ended games (of 36); mean margin (Mine - Opponent) -77 VP
- The side that went first won 18 of 28 games with a winner
- Points traded per game (both sides' losses): 1427
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ef2-mine-f5fe7c8-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | 0.0 | +0.3 | 0.0 | 2.5 | 0.1 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.6 | +0.0 | 0.0 | 11.5 | 0.2 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.9 | +6.1 | 0.0 | 31.2 | 0.8 | +6.8 | 0.0 | 25.0 |
| BEST PREY | 4.1 | +249.7 | 167.7 | 108.6 | 3.8 | +210.1 | 126.6 | 109.1 |
| BEST PRIZE | - | - | - | - | 0.1 | -0.6 | 7.0 | 0.0 |
| BLOCKED CHARGE HANDED OVER | 0.0 | +1.1 | 0.0 | 0.0 | - | - | - | - |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 7.3 | 0.0 | 0.1 | +0.0 | 10.9 | 1.1 |
| BLOCKED WHEEL | 0.5 | +13.2 | 0.0 | 5.8 | 0.4 | +4.2 | 0.0 | 7.1 |
| BOMBING RUN | 0.1 | +1.7 | 1.8 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | - | - | - | - | 0.0 | +0.0 | 0.0 | 4.2 |
| CANNON PLAN MISSED | 1.0 | +0.0 | 70.3 | 10.8 | 0.1 | +0.0 | 13.6 | 3.5 |
| CANNON PLANNED TARGET | 5.3 | +147.6 | 244.0 | 82.4 | 1.1 | +65.2 | 55.9 | 42.1 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 2.9 | 11.3 | 0.1 | +0.0 | 21.7 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | -6.2 | 27.7 | 8.9 | 0.1 | -7.1 | 6.9 | 0.0 |
| CAST JOB | 1.2 | +38.7 | 56.6 | 16.2 | 0.5 | +10.1 | 33.2 | 16.3 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +42.9 | 19.2 | 8.9 | 0.1 | +1.9 | 3.2 | 0.0 |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 9.9 | 0.4 | +0.0 | 0.0 | 19.4 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | - | - | - | - | 0.0 | +0.4 | 0.0 | 0.0 |
| CATCH ODDS | 0.0 | +1.0 | 0.0 | 5.8 | - | - | - | - |
| CHAFF PASSED | 0.2 | -0.2 | 0.0 | 3.5 | 0.0 | +0.0 | 0.0 | 0.0 |
| CHAMPION TAKES THE CHALLENGE | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CHARGE NOW WEIGHED | 0.4 | -43.2 | 10.8 | 20.8 | 0.7 | -57.2 | 0.9 | 37.2 |
| CHARIOT NO STATIC JOB | 1.0 | +0.0 | 6.0 | 9.1 | 0.6 | +0.0 | 19.7 | 6.1 |
| CHEAP HELPER | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.9 | +108.1 | 33.4 | 34.3 | 0.5 | +35.6 | 11.8 | 19.4 |
| COUNTER-CHARGE COVER | 7.2 | +276.3 | 0.0 | 151.1 | 7.3 | +622.0 | 0.0 | 105.7 |
| EDGE GIVE GROUND | 0.4 | +17.6 | 45.3 | 11.6 | 0.2 | +6.5 | 13.5 | 0.0 |
| ELIXIR WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| ENEMY FORECAST | 10.7 | +311.3 | 97.1 | 297.8 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.1 | +85.5 | 0.0 | 18.0 | 1.1 | +96.9 | 0.0 | 25.8 |
| FALLBACK BY WORTH | 6.4 | +59.2 | 0.0 | 125.0 | 6.8 | +123.8 | 0.0 | 66.5 |
| FIGHT LIFT | 0.1 | +1.9 | 3.3 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.1 | +0.5 | 0.0 | 3.1 | - | - | - | - |
| FLANK NOT WEIGHED | 0.5 | +0.0 | 0.0 | 6.5 | 0.3 | +0.0 | 0.0 | 0.0 |
| FOCUS FIRE | - | - | - | - | 0.0 | +0.2 | 1.8 | 0.0 |
| FOLLOW UP WEIGHED | 0.8 | +92.2 | 0.0 | 18.1 | 1.2 | +192.1 | 0.0 | 37.2 |
| FORECAST RESULT | 37.7 | +2050.1 | 570.5 | 809.4 | 40.1 | +1880.2 | 697.3 | 1103.2 |
| FRIENDS SHOTS CHECKED | 0.2 | +5.6 | 0.0 | 4.6 | 0.2 | +8.2 | 0.0 | 0.0 |
| GIVES UP | 1.1 | -26.0 | 119.9 | 79.5 | 1.5 | -56.6 | 187.6 | 19.6 |
| GIVES UP ITS SCREEN | 0.6 | -9.5 | 16.9 | 24.9 | 0.5 | -10.2 | 24.8 | 6.2 |
| GROUND FLIERS | 0.1 | +0.7 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 3.9 | 4.3 | - | - | - | - |
| HELPER UNSEEN | 0.3 | +0.0 | 0.0 | 14.5 | 0.4 | +0.0 | 7.6 | 4.7 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.1 | +1.9 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.2 | +14.8 | 9.2 | 6.7 | 0.1 | +6.2 | 8.9 | 3.2 |
| HUNT DROPPED | 0.1 | +0.0 | 0.0 | 4.5 | 0.0 | +0.0 | 0.0 | 1.5 |
| HUNT IN PAIRS | 0.2 | +7.3 | 0.0 | 5.4 | 0.7 | +47.4 | 0.0 | 5.4 |
| HUNT KEPT | 0.1 | +4.6 | 9.2 | 2.9 | 0.1 | +0.5 | 9.3 | 0.0 |
| HUNT RESULT | 0.2 | +34.3 | 4.6 | 7.8 | 0.1 | +6.8 | 0.0 | 4.4 |
| HUNT THE GUNS | 0.2 | +86.8 | 13.5 | 5.2 | 0.2 | +53.8 | 7.8 | 3.2 |
| JOINT CHARGE PLAN | 0.1 | +5.2 | 0.0 | 3.2 | 0.2 | +3.7 | 20.2 | 3.2 |
| KEEP FALLS | 0.1 | +1.8 | 0.0 | 6.1 | - | - | - | - |
| KEEPS ITS PREY | 0.2 | +2.7 | 12.5 | 0.0 | 0.2 | +1.1 | 0.0 | 0.0 |
| KEEPS ITS TARGET | 2.2 | +65.0 | 185.1 | 122.3 | 2.2 | +65.8 | 155.9 | 10.1 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.5 | +70.3 | 104.5 | 86.3 | 2.3 | +120.6 | 171.2 | 20.3 |
| KILLS COUNT NEXT TURN | 8.9 | +345.7 | 286.1 | 243.4 | 9.9 | +407.9 | 374.1 | 216.9 |
| LONE CHARACTER SAFE SPOT | 0.6 | +10.9 | 13.8 | 2.5 | 0.4 | +36.3 | 5.1 | 3.2 |
| LONE WIZARD HOLDS BACK | 1.2 | +0.0 | 95.7 | 76.3 | 1.4 | +0.0 | 68.8 | 19.4 |
| LONE WIZARD KEPT IN | 0.6 | +37.3 | 0.0 | 0.0 | 0.3 | +22.1 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.9 | +58.8 | 47.6 | 36.4 | 0.9 | +36.2 | 28.0 | 6.5 |
| MANOEUVRE | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +2.5 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.2 | +0.4 | 0.0 | 9.0 | 0.2 | +2.8 | 0.0 | 3.2 |
| MARCH CHECK | 0.5 | +16.8 | 0.0 | 29.2 | 0.6 | +36.1 | 0.0 | 3.2 |
| MARCH ODDS | 0.7 | +56.9 | 38.6 | 5.1 | 0.8 | +42.9 | 19.9 | 2.9 |
| MARCH OVER CASTS | 1.1 | +17.9 | 0.0 | 32.7 | 1.1 | -5.4 | 0.0 | 12.1 |
| MAX FOR POSITIONING | 4.4 | +102.1 | 0.0 | 104.3 | 4.8 | +213.8 | 0.0 | 70.6 |
| MISSILES IN THE MOVE | 3.8 | +131.6 | 0.0 | 88.3 | 3.1 | +40.1 | 0.0 | 27.5 |
| MISSILES NEXT TURN | 5.2 | +90.3 | 0.0 | 149.4 | 4.9 | +44.3 | 0.0 | 54.6 |
| MODEL FACING | 0.0 | +2.9 | 0.0 | 0.0 | - | - | - | - |
| MOVE AND CAST | 0.4 | +23.5 | 0.0 | 18.4 | 0.5 | +24.7 | 0.0 | 11.8 |
| MOVE SPELL IN RANGE | 0.2 | +4.9 | 0.0 | 10.6 | 0.0 | +0.7 | 0.0 | 6.5 |
| MOVE SPELL OUT OF RANGE | 0.5 | -20.7 | 0.0 | 55.4 | 0.2 | -5.7 | 0.0 | 7.6 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.1 | +3.1 | 2.4 | 0.0 |
| NO RALLY LEFT | 0.1 | +5.2 | 0.0 | 1.5 | - | - | - | - |
| NOT NEEDED | 0.1 | -5.4 | 10.0 | 1.7 | 0.2 | -16.5 | 26.4 | 2.0 |
| NOT TURNED | 8.1 | +140.4 | 0.0 | 195.0 | 7.4 | +74.1 | 0.0 | 121.2 |
| NOT WORTH A CAST | 0.3 | -0.2 | 0.0 | 33.6 | 0.7 | -0.9 | 0.0 | 0.0 |
| OPENS A LANE | 0.1 | +0.2 | 15.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| OPENS UP | 0.3 | +15.7 | 16.8 | 15.7 | 0.1 | +8.4 | 4.4 | 0.0 |
| OVERRUNS AWAY | 0.6 | +12.5 | 56.9 | 54.4 | 0.5 | +13.0 | 50.8 | 0.0 |
| PATHS CROSS | 2.3 | +107.5 | 0.0 | 62.5 | 2.2 | +163.1 | 0.0 | 12.9 |
| PLAN LEADS | 1.3 | +112.8 | 16.2 | 56.6 | 0.8 | +63.6 | 21.3 | 0.0 |
| PLAN RESULT | 37.3 | +1258.1 | 1129.9 | 1023.6 | 36.9 | +1197.3 | 1030.2 | 811.3 |
| PURSUES BIG PREY | 0.1 | -5.3 | 0.0 | 10.9 | 0.1 | -5.8 | 0.0 | 0.0 |
| PURSUES ON | 0.0 | +0.1 | 0.0 | 0.0 | - | - | - | - |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +12.5 | 0.0 | 0.0 | 0.1 | +4.9 | 0.0 | 3.8 |
| REDIRECT COUNTER | 2.7 | +70.6 | 0.0 | 48.3 | 3.8 | +276.3 | 0.0 | 49.4 |
| REDIRECT WEIGHED | 0.2 | +6.4 | 7.8 | 0.0 | 0.3 | +1.1 | 3.5 | 11.3 |
| RESTRAINS TO SHOOT | 0.1 | +7.2 | 0.0 | 7.4 | - | - | - | - |
| RISK BY ARC | 2.4 | +82.1 | 201.6 | 145.7 | 2.8 | +41.1 | 205.9 | 43.0 |
| SAFE SURE CHARGE | - | - | - | - | 0.0 | -2.8 | 3.2 | 0.0 |
| SAFER THAN THE JOB | 0.6 | +26.7 | 0.0 | 5.5 | 0.7 | +44.6 | 0.0 | 31.3 |
| SCOUT SPOT | 0.4 | +0.3 | 0.0 | 0.9 | 0.3 | +0.8 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.9 | 0.3 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 1.8 | +72.8 | 0.0 | 28.9 | 1.5 | +98.7 | 0.0 | 20.6 |
| SECOND HUNTER | 0.0 | -0.8 | 0.0 | 0.0 | - | - | - | - |
| SELF MOVE SPELL | 0.5 | +64.1 | 0.0 | 0.0 | 0.2 | +66.6 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.3 | +93.0 | 47.6 | 39.7 | 1.4 | +71.2 | 28.0 | 9.7 |
| SET-UP ANY TARGET | 0.6 | +83.5 | 24.4 | 24.4 | 0.2 | +19.4 | 0.0 | 7.6 |
| SET-UP MISSED | 0.1 | +13.1 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.3 | +0.6 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.8 | +0.0 | 112.8 | 1.8 | 0.2 | +0.0 | 57.4 | 3.5 |
| SHOTS IN THE MOVE | 12.6 | +480.9 | 0.0 | 184.2 | 8.4 | +265.3 | 0.0 | 121.9 |
| SPELL CATCH ODDS | 0.1 | -0.8 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.7 | +123.9 | 24.4 | 24.4 | 0.2 | +19.4 | 0.0 | 7.6 |
| SPELL WORTH | 1.4 | +32.1 | 115.9 | 112.6 | 2.5 | +34.8 | 73.4 | 65.4 |
| STANDS TO CAST | - | - | - | - | 0.0 | +0.4 | 3.2 | 0.0 |
| STOPS | 0.1 | +1.4 | 8.9 | 0.0 | 0.1 | +0.3 | 2.4 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 4.7 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -9.3 | 9.9 | 11.5 | 0.1 | -2.7 | 12.4 | 11.3 |
| SURE REACH TOGETHER | 0.4 | -0.3 | 5.5 | 19.6 | 0.6 | +7.7 | 20.2 | 8.6 |
| THROUGH LINE OF FIRE | 0.5 | +15.1 | 0.0 | 5.2 | 0.2 | +5.4 | 0.0 | 4.6 |
| TURN WORTH | 0.6 | -35.8 | 52.4 | 45.8 | 0.6 | -44.8 | 33.8 | 3.9 |
| TWO OR MORE ARRIVE | 0.4 | +5.5 | 0.0 | 7.7 | 0.4 | +4.2 | 0.0 | 5.2 |
| WEARS DOWN | 0.9 | +42.8 | 88.2 | 42.5 | 1.0 | +32.4 | 83.6 | 40.0 |
| WHO HITS BACK | 0.1 | +6.5 | 0.0 | 0.0 | 0.3 | +34.9 | 0.0 | 24.4 |
| WHOLE FIGHT | 0.4 | +27.7 | 60.3 | 24.8 | 0.5 | +5.5 | 39.2 | 7.8 |
| WHOLE FIGHT GAIN | 0.4 | +30.1 | 31.1 | 14.0 | 0.4 | +30.4 | 20.7 | 19.4 |

### Rule changes: ef2-mine-f5fe7c8-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| KILLS COUNT NEXT TURN | 675 | 664 | 184 | 5.11 | +6774 | +36.8 |
| PATHS CROSS | 165 | 165 | 165 | 4.58 | +9744 | +59.1 |
| BEST PREY | 285 | 275 | 119 | 3.31 | +4929 | +41.4 |
| FALLBACK BY WORTH | 476 | 476 | 114 | 3.17 | +6587 | +57.8 |
| SEARCH SPOT | 118 | 118 | 114 | 3.17 | +6223 | +54.6 |
| COUNTER-CHARGE COVER | 520 | 244 | 99 | 2.75 | +4586 | +46.3 |
| FACES THE THREAT | 79 | 79 | 79 | 2.19 | +6566 | +83.1 |
| FOLLOW UP WEIGHED | 73 | 73 | 73 | 2.03 | +10237 | +140.2 |
| ARTILLERY RE-ROLL WEIGHED | 68 | 68 | 68 | 1.89 | +0 | +0.0 |
| ENEMY FORECAST | 386 | 382 | 66 | 1.83 | +763 | +11.6 |
| MAX FOR POSITIONING | 331 | 170 | 57 | 1.58 | +518 | +9.1 |
| SHOTS IN THE MOVE | 756 | 463 | 57 | 1.58 | +1651 | +29.0 |
| CANNON SIGHT KEPT | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| CANNON PLANNED TARGET | 229 | 229 | 52 | 1.44 | -466 | -9.0 |
| KEEPS ITS TARGET | 157 | 155 | 49 | 1.36 | +874 | +17.8 |
| MARCH ODDS | 52 | 52 | 48 | 1.33 | +808 | +16.8 |
| SAFER THAN THE JOB | 47 | 47 | 47 | 1.31 | +2565 | +54.6 |
| KILLS COUNT | 137 | 125 | 45 | 1.25 | +1888 | +42.0 |
| RISK BY ARC | 187 | 171 | 45 | 1.25 | +1315 | +29.2 |
| CHARGE NOW WEIGHED | 40 | 40 | 40 | 1.11 | +3040 | +76.0 |
| HOLDS AMBUSHERS | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| CHARIOT NO STATIC JOB | 57 | 57 | 35 | 0.97 | -2850 | -81.4 |
| SHOT REPLANNED | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| MOVE AND CAST | 33 | 33 | 33 | 0.92 | +1734 | +52.5 |
| PLAN LEADS | 75 | 75 | 33 | 0.92 | +2099 | +63.6 |
| BLOCKED WHEEL | 32 | 32 | 32 | 0.89 | +626 | +19.6 |
| LONE WIZARD KEPT IN | 32 | 32 | 32 | 0.89 | +2140 | +66.9 |
| SET UP TOGETHER | 95 | 77 | 32 | 0.89 | +2202 | +68.8 |
| ADVANCE LANE KEPT | 31 | 31 | 31 | 0.86 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 95 | 95 | 31 | 0.86 | -2985 | -96.3 |
| MISSILES IN THE MOVE | 245 | 124 | 29 | 0.81 | +754 | +26.0 |
| REDIRECT COUNTER | 233 | 86 | 28 | 0.78 | +1571 | +56.1 |
| THROUGH LINE OF FIRE | 26 | 26 | 26 | 0.72 | +736 | +28.3 |
| SCOUT WAITS | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| MARCH CHECK | 42 | 29 | 23 | 0.64 | +589 | +25.6 |
| CAST JOB | 62 | 60 | 22 | 0.61 | +543 | +24.7 |
| REDIRECT WEIGHED | 17 | 17 | 17 | 0.47 | +1630 | +95.9 |
| CASTING BLOCK | 19 | 19 | 16 | 0.44 | +665 | +41.6 |
| SHOOTERS IN TWO RANKS | 16 | 16 | 16 | 0.44 | +27 | +1.7 |
| MAKE SURE TOGETHER | 65 | 40 | 14 | 0.39 | +756 | +54.0 |
| WHO HITS BACK | 14 | 14 | 14 | 0.39 | -601 | -42.9 |
| FRIENDS SHOTS CHECKED | 12 | 12 | 12 | 0.33 | +498 | +41.5 |
| STUCK PIVOT | 12 | 12 | 12 | 0.33 | +0 | +0.0 |
| WEARS DOWN | 66 | 62 | 12 | 0.33 | +691 | +57.6 |
| SURE CHARGE BEATS ADVANCE | 11 | 11 | 11 | 0.31 | -432 | -39.2 |
| MANOEUVRE | 10 | 10 | 10 | 0.28 | +212 | +21.2 |
| WHOLE FIGHT | 30 | 29 | 10 | 0.28 | +800 | +80.0 |
| WHOLE FIGHT GAIN | 29 | 24 | 10 | 0.28 | +749 | +74.9 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| BLOCKED CHARGE SKIPPED | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| CHAFF PASSED | 8 | 8 | 8 | 0.22 | -7 | -0.9 |
| HUNT ADVANCE | 11 | 11 | 8 | 0.22 | +428 | +53.5 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +141 | +20.1 |
| RAIDS THE BAGGAGE NEXT TURN | 7 | 7 | 6 | 0.17 | +250 | +41.6 |
| EDGE GIVE GROUND | 19 | 17 | 5 | 0.14 | +205 | +40.9 |
| HUNT IN PAIRS | 33 | 21 | 5 | 0.14 | +500 | +100.0 |
| MISSILES NEXT TURN | 364 | 163 | 5 | 0.14 | +54 | +10.7 |
| PURSUES BIG PREY | 5 | 5 | 5 | 0.14 | -400 | -79.9 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| KEEP FALLS | 4 | 4 | 4 | 0.11 | +170 | +42.5 |
| OVERRUNS AWAY | 42 | 39 | 4 | 0.11 | +88 | +22.0 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.11 | +261 | +65.1 |
| BEST PRIZE | 3 | 3 | 3 | 0.08 | -185 | -61.7 |
| CARRIES OUT SET-UP | 9 | 9 | 3 | 0.08 | -479 | -159.8 |
| NO RALLY LEFT | 3 | 3 | 3 | 0.08 | +65 | +21.7 |
| OPENS UP | 15 | 12 | 3 | 0.08 | +47 | +15.6 |
| SURE REACH TOGETHER | 36 | 25 | 3 | 0.08 | +21 | +7.1 |
| BACKUP TARGETS | 58 | 30 | 2 | 0.06 | +2 | +0.8 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +60 | +29.8 |
| FIRE AND FLEE | 2 | 2 | 2 | 0.06 | +19 | +9.7 |
| HORN WORTH | 2 | 2 | 2 | 0.06 | +67 | +33.5 |
| NEEDED THERE | 3 | 3 | 2 | 0.06 | +0 | +0.0 |
| BLOCKED CHARGE HANDED OVER | 1 | 1 | 1 | 0.03 | +39 | +39.0 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.1 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -32 | -32.3 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +4 | +3.8 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +8 | +7.7 |
| GIVES UP | 93 | 88 | 1 | 0.03 | +4 | +4.4 |
| GIVES UP ITS SCREEN | 41 | 41 | 1 | 0.03 | +2 | +2.0 |
| JOINT CHARGE PLAN | 12 | 12 | 1 | 0.03 | +89 | +88.8 |
| KEEPS ITS PREY | 14 | 14 | 1 | 0.03 | +2 | +2.2 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| MODEL FACING | 1 | 1 | 1 | 0.03 | +105 | +105.0 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +2 | +2.0 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -144 | -143.8 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | +9 | +8.6 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| ARRIVAL HUNT | 3 | 3 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 40 | 40 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 4 | 4 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 43 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | not checked | - | - | - | - |
| CHEAP HELPER | 4 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 48 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 6 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 29 | not checked | - | - | - | - |
| FORECAST RESULT | 2802 | trace | - | - | - | - |
| GROUND FLIERS | 3 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 1 | not checked | - | - | - | - |
| HELPER UNSEEN | 26 | 24 | 0 | 0.00 | - | - |
| HUNT DROPPED | 3 | trace | - | - | - | - |
| HUNT KEPT | 7 | trace | - | - | - | - |
| HUNT RESULT | 10 | trace | - | - | - | - |
| HUNT THE GUNS | 14 | trace | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 36 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 13 | trace | - | - | - | - |
| MARCH OVER CASTS | 76 | 76 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 8 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 26 | trace | - | - | - | - |
| MOVE SPELL SPOT | 18 | not checked | - | - | - | - |
| NOT NEEDED | 14 | 14 | 0 | 0.00 | - | - |
| NOT TURNED | 558 | 558 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 38 | not checked | - | - | - | - |
| OPENS A LANE | 7 | not checked | - | - | - | - |
| PLAN RESULT | 2671 | trace | - | - | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 27 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 26 | not checked | - | - | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SPELL CATCH ODDS | 3 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 30 | not checked | - | - | - | - |
| SPELL WORTH | 140 | not checked | - | - | - | - |
| STOPS | 6 | 6 | 0 | 0.00 | - | - |
| TURN WORTH | 40 | 38 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 29 | 28 | 0 | 0.00 | - | - |

### Plans: ef2-mine-f5fe7c8-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.4 | 16% | 601 | 394 | 66% |
| Mine | charge | 2.9 | 66% | 290 | 253 | 87% |
| Mine | close in | 4.9 | 22% | 380 | 123 | 32% |
| Mine | hold | 4.1 | 40% | 307 | 0 | 0% |
| Mine | join | 0.8 | 97% | 24 | 0 | 0% |
| Mine | shoot | 8.2 | 65% | 206 | 488 | 236% |
| Mine | support | 3.9 | 90% | 236 | 0 | 0% |
| Opponent | advance | 12.6 | 18% | 558 | 357 | 64% |
| Opponent | charge | 4.0 | 56% | 434 | 391 | 90% |
| Opponent | close in | 5.2 | 23% | 361 | 138 | 38% |
| Opponent | hold | 3.7 | 33% | 355 | 0 | 0% |
| Opponent | join | 1.0 | 97% | 42 | 0 | 0% |
| Opponent | shoot | 4.1 | 64% | 105 | 310 | 294% |
| Opponent | support | 6.2 | 89% | 239 | 0 | 0% |

### Enemy forecast: ef2-mine-f5fe7c8-p3

Per side (the computer that made the forecast) and expected action: forecasts a game, right (it did the expected action on the expected target), gone (missed, but the target or the enemy was gone before it acted), and what the enemy did instead; right of judged leaves the gone ones out.

| Side | Expected | A game | Right | Gone | Right of judged | Did charge | Did shoot | Did move | Same target |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.9 | 56% | 11% | 63% | 67% | 9% | 24% | 60% |
| Mine | shoot | 7.3 | 33% | 17% | 39% | 2% | 68% | 30% | 33% |
| Mine | move | 26.5 | 77% | 3% | 79% | 7% | 16% | 77% | - |
| Mine | all | 37.7 | 66% | 6% | 71% | 13% | 25% | 62% | - |
| Opponent | charge | 3.1 | 49% | 17% | 59% | 54% | 15% | 32% | 54% |
| Opponent | shoot | 13.4 | 30% | 23% | 38% | 1% | 71% | 28% | 30% |
| Opponent | move | 23.6 | 68% | 3% | 70% | 9% | 24% | 68% | - |
| Opponent | all | 40.1 | 53% | 11% | 60% | 10% | 39% | 51% | - |

Expected moves (the enemy's own plan): how far the expected end was from where the unit ended, against the guess that it stays where it stood.

| Side | Moves a game | Median miss | Median miss if it stays | Within 3" | Within 6" | Better than stays |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | 19.6 | 6.5" | 3.9" | 22% | 47% | 19% |
| Opponent | 15.1 | 6.9" | 3.8" | 24% | 45% | 24% |

### Packages: hunt the guns, ef2-mine-f5fe7c8-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.2 | 8 | 1 | 43% | 57% | 0% | 2.5 | 417 | 177 | 43% | 27 |
| Opponent | 0.2 | 6 | 3 | 0% | 33% | 0% | 2.0 | 366 | 81 | 33% | 62 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 1.2 | 5 | 0 | 40% | 60% | 0% | 2.7 | 427 | 202 | 40% | 13 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 28 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Empire of Man | 0.3 | 2 | 1 | 0% | 0% | 0% | - | 542 | 0 | 0% | 110 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 78 |
| High Elf Realms | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 581 | 0 | 0% | 9 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 67 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.0 | 1 | 0 | 100% | 100% | 0% | 2.0 | 237 | 229 | 100% | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 138 |
| Tomb Kings of Khemri | 0.3 | 2 | 1 | 0% | 0% | 0% | - | 264 | 0 | 0% | 44 |
| Vampire Counts | 0.1 | 1 | 1 | - | - | - | - | - | - | - | 33 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 31 |
| Wood Elf Realms | 0.3 | 2 | 1 | 0% | 100% | 0% | 2.0 | 253 | 243 | 100% | 60 |

### Battle groups: ef2-mine-f5fe7c8-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 7.2 | 26% | 46% | 9% | 67% | 25% | 7% | 7% | 62% | 0% |
| Mine | REDIRECT COUNTER | 2.7 | 22% | 76% | 5% | 100% | 15% | 5% | 0% | 70% | 10% |
| Opponent | COUNTER-CHARGE COVER | 7.3 | 19% | 51% | 20% | 50% | 33% | 5% | 21% | 41% | 0% |
| Opponent | REDIRECT COUNTER | 3.8 | 20% | 71% | 25% | 29% | 38% | 0% | 14% | 43% | 5% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ef2-mine-f5fe7c8-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 3.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | Chaff | 40 | 68 (40) | 33 | 35 | 67 | 35% | 3.2 | 48 (20) | 86 (8) | 89 (12) | 86 (32) | 0 (8) |
| Mine | Character | 120 | 51 (120) | 51 | 0 | 42 | 14% | 2.4 | 51 (40) | 60 (54) | 81 (6) | 61 (58) | 52 (42) |
| Mine | Clean-up | 15 | 48 (15) | 10 | 38 | 47 | 27% | 2.7 | 71 (7) | 33 (6) | 12 (2) | 80 (8) | 8 (7) |
| Mine | Fast Hammer | 43 | 26 (43) | 11 | 15 | 31 | 23% | 3.2 | 22 (24) | 37 (13) | 14 (6) | 29 (31) | 19 (12) |
| Mine | Fragile | 3 | 0 (3) | 0 | 0 | 67 | 67% | 3.0 | 0 (3) | - | - | 0 (1) | 0 (2) |
| Mine | Hammer | 50 | 35 (50) | 24 | 11 | 40 | 6% | 2.7 | 23 (13) | 34 (32) | 84 (5) | 42 (34) | 22 (16) |
| Mine | Holder | 25 | 41 (25) | 2 | 39 | 38 | 48% | 3.2 | 9 (8) | 67 (11) | 15 (6) | 72 (12) | 11 (13) |
| Mine | Shooter | 38 | 82 (38) | 43 | 39 | 37 | 0% | 1.8 | 119 (11) | 76 (25) | 0 (2) | 107 (22) | 54 (16) |
| Mine | Support | 4 | 0 (4) | 0 | 0 | 58 | 25% | 2.0 | 0 (1) | - | - | 0 (1) | - |
| Mine | War machine | 52 | 34 (52) | 34 | 0 | 41 | 2% | 1.1 | 55 (14) | 27 (34) | 24 (4) | 17 (14) | 41 (38) |
| Mine | Wizard | 15 | 0 (15) | 0 | 0 | 44 | 13% | 2.1 | 0 (3) | 0 (7) | 0 (1) | 0 (8) | 0 (3) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 73 | 34 (73) | 8 | 26 | 54 | 45% | 2.5 | 41 (31) | 64 (13) | 11 (29) | 42 (52) | 17 (21) |
| Opponent | Character | 101 | 63 (101) | 63 | 0 | 26 | 18% | 2.3 | 62 (36) | 68 (48) | 18 (9) | 71 (50) | 54 (43) |
| Opponent | Clean-up | 9 | 44 (9) | 12 | 32 | 42 | 22% | 3.4 | 21 (3) | 28 (4) | 148 (2) | 61 (5) | 29 (4) |
| Opponent | Fast Hammer | 60 | 43 (60) | 27 | 16 | 48 | 27% | 2.7 | 42 (31) | 51 (17) | 29 (12) | 40 (32) | 46 (28) |
| Opponent | Fragile | 3 | 0 (3) | 0 | 0 | 100 | 33% | 2.0 | - | 0 (2) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | Hammer | 47 | 20 (47) | 14 | 7 | 39 | 32% | 2.9 | 5 (15) | 27 (28) | 0 (4) | 22 (25) | 18 (22) |
| Opponent | Holder | 40 | 62 (40) | 3 | 59 | 29 | 40% | 2.9 | 34 (11) | 95 (17) | 38 (11) | 72 (29) | 42 (10) |
| Opponent | Shooter | 28 | 42 (28) | 27 | 16 | 47 | 4% | 1.1 | 0 (7) | 60 (20) | 0 (1) | 60 (17) | 19 (11) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 0 | 75% | 4.0 | 0 (1) | 0 (1) | 0 (2) | 0 (2) | 0 (2) |
| Opponent | War machine | 17 | 48 (17) | 48 | 0 | 70 | 6% | 1.5 | 0 (3) | 79 (10) | 9 (4) | 36 (3) | 50 (14) |
| Opponent | Wizard | 33 | 10 (33) | 10 | 0 | 30 | 18% | 1.7 | 3 (14) | 20 (7) | 0 (4) | 7 (12) | 8 (13) |

### Charged fights: ef2-mine-f5fe7c8-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 156 | 62 | 1.8 | 1.0 | 36 | 0 | +36 | 1 of 7 | 5 of 7 | - | +36 |
| Mine | Chaos Dwarfs | 4 | 209 | 117 | 2.5 | 1.0 | 47 | 0 | +47 | 2 of 10 | 8 of 10 | - | +47 |
| Mine | Dwarfen Mountain Holds | 3 | 427 | 44 | 1.7 | 1.2 | 27 | 24 | +3 | 1 of 5 | 0 of 5 | +0 | +3 |
| Mine | Empire of Man | 5 | 209 | 224 | 3.2 | 1.0 | 70 | 29 | +40 | 3 of 16 | 11 of 15 | - | +40 |
| Mine | Grand Cathay | 5 | 477 | 300 | 4.0 | 1.1 | 75 | 18 | +57 | 5 of 20 | 17 of 20 | +0 | +60 |
| Mine | High Elf Realms | 4 | 357 | 365 | 4.2 | 1.0 | 86 | 14 | +72 | 6 of 17 | 12 of 17 | - | +72 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 712 | 5.0 | 1.4 | 142 | 0 | +142 | 0 of 5 | 5 of 5 | +209 | +98 |
| Mine | Lizardmen | 1 | 0 | 608 | 5.0 | 1.2 | 122 | 165 | -43 | 3 of 5 | 0 of 5 | -69 | -37 |
| Mine | Ogre Kingdoms | 1 | 116 | 339 | 6.0 | 1.2 | 56 | 60 | -3 | 2 of 6 | 3 of 6 | -234 | +43 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 783 | 8.0 | 1.0 | 98 | 21 | +77 | 2 of 8 | 7 of 8 | - | +77 |
| Mine | Skaven | 1 | 0 | 505 | 1.0 | 1.0 | 505 | 420 | +85 | 1 of 1 | 0 of 1 | - | +85 |
| Mine | Tomb Kings of Khemri | 2 | 132 | 333 | 4.0 | 1.0 | 83 | 32 | +52 | 2 of 8 | 3 of 8 | - | +52 |
| Mine | Vampire Counts | 2 | 202 | 504 | 4.5 | 1.2 | 112 | 137 | -25 | 3 of 9 | 3 of 9 | +202 | -90 |
| Mine | Warriors of Chaos | 2 | 0 | 255 | 1.0 | 1.0 | 255 | 58 | +197 | 1 of 2 | 0 of 2 | - | +197 |
| **Mine** | all armies | 36 | 233 | 279 | 3.3 | 1.1 | 85 | 38 | +46 | 32 of 119 | 74 of 118 | +65 | +45 |
| Opponent | Empire of Man | 1 | 380 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 2 of 2 | 1 of 2 | - | +0 |
| Opponent | Grand Cathay | 3 | 120 | 499 | 4.3 | 1.2 | 115 | 96 | +19 | 6 of 13 | 7 of 13 | +83 | +7 |
| Opponent | High Elf Realms | 3 | 348 | 90 | 0.7 | 1.0 | 135 | 63 | +72 | 1 of 2 | 0 of 2 | - | +72 |
| Opponent | Kingdom of Bretonnia | 2 | 0 | 616 | 3.5 | 1.1 | 176 | 38 | +138 | 3 of 7 | 2 of 7 | -264 | +205 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 199 | 3.0 | 1.0 | 66 | 18 | +48 | 1 of 3 | 2 of 3 | - | +48 |
| Opponent | Skaven | 1 | 235 | 186 | 2.0 | 1.0 | 93 | 50 | +43 | 1 of 2 | 0 of 2 | - | +43 |
| Opponent | Tomb Kings of Khemri | 4 | 62 | 596 | 3.5 | 1.2 | 170 | 43 | +128 | 7 of 14 | 7 of 14 | +335 | +71 |
| Opponent | Vampire Counts | 6 | 0 | 944 | 5.3 | 1.2 | 177 | 34 | +143 | 15 of 32 | 26 of 32 | +432 | +90 |
| Opponent | Warriors of Chaos | 9 | 0 | 452 | 3.6 | 1.2 | 127 | 11 | +116 | 14 of 32 | 22 of 32 | +32 | +131 |
| Opponent | Wood Elf Realms | 6 | 87 | 108 | 2.3 | 1.0 | 46 | 16 | +30 | 5 of 14 | 8 of 14 | - | +30 |
| **Opponent** | all armies | 36 | 77 | 449 | 3.4 | 1.1 | 133 | 34 | +100 | 55 of 121 | 75 of 121 | +202 | +84 |

### Effective charges: ef2-mine-f5fe7c8-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 7 | 1 (net +0) | 1 (net +0) | 0 | 1 (net +165) | 0 | 4 (net +21) | 0 | 0% (0 of 7) |
| Mine | Chaos Dwarfs | 10 | 0 | 0 | 1 (net +0) | 5 (net +0) | 0 | 1 (net +0) | 3 | 14% (1 of 7) |
| Mine | Dwarfen Mountain Holds | 5 | 0 | 0 | 2 (net -60) | 2 (net +0) | 0 | 1 (net +133) | 0 | 40% (2 of 5) |
| Mine | Empire of Man | 16 | 2 (net +108) | 0 | 4 (net -66) | 3 (net +107) | 1 (net +72) | 3 (net +35) | 3 | 31% (4 of 13) |
| Mine | Grand Cathay | 20 | 4 (net +65) | 1 (net +386) | 1 (net +0) | 4 (net +32) | 2 (net -157) | 8 (net +84) | 0 | 5% (1 of 20) |
| Mine | High Elf Realms | 17 | 1 (net -60) | 0 | 1 (net -115) | 2 (net +210) | 3 (net +94) | 9 (net +71) | 1 | 6% (1 of 16) |
| Mine | Kingdom of Bretonnia | 5 | 2 (net +95) | 0 | 0 | 0 | 0 | 2 (net +209) | 1 | 0% (0 of 4) |
| Mine | Lizardmen | 5 | 0 | 0 | 3 (net -25) | 0 | 0 | 0 | 2 | 100% (3 of 3) |
| Mine | Ogre Kingdoms | 6 | 1 (net +195) | 0 | 3 (net -89) | 0 | 0 | 1 (net +144) | 1 | 60% (3 of 5) |
| Mine | Orc & Goblin Tribes | 8 | 0 | 0 | 1 (net +340) | 1 (net -165) | 0 | 4 (net +103) | 2 | 17% (1 of 6) |
| Mine | Skaven | 1 | 1 (net +85) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 8 | 1 (net +0) | 0 | 2 (net -127) | 2 (net +60) | 2 (net +33) | 1 (net +480) | 0 | 25% (2 of 8) |
| Mine | Vampire Counts | 9 | 2 (net +202) | 0 | 2 (net +0) | 0 | 0 | 4 (net -44) | 1 | 25% (2 of 8) |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +197) | 0 | 0% (0 of 2) |
| Opponent | Empire of Man | 2 | 0 | 0 | 1 (net +0) | 0 | 0 | 1 (net +0) | 0 | 50% (1 of 2) |
| Opponent | Grand Cathay | 13 | 3 (net +156) | 0 | 2 (net -32) | 2 (net +0) | 0 | 4 (net +93) | 2 | 18% (2 of 11) |
| Opponent | High Elf Realms | 2 | 1 (net +270) | 0 | 0 | 1 (net -126) | 0 | 0 | 0 | 0% (0 of 2) |
| Opponent | Kingdom of Bretonnia | 7 | 1 (net +138) | 0 | 2 (net +79) | 0 | 0 | 3 (net +200) | 1 | 33% (2 of 6) |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 0 | 0 | 1 (net +199) | 0 | 1 (net +0) | 1 | 0% (0 of 2) |
| Opponent | Skaven | 2 | 0 | 0 | 0 | 1 (net -100) | 0 | 1 (net +186) | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 14 | 1 (net +466) | 0 | 3 (net +85) | 2 (net +250) | 3 (net -20) | 4 (net +125) | 1 | 23% (3 of 13) |
| Opponent | Vampire Counts | 32 | 4 (net -56) | 1 (net -233) | 6 (net +192) | 9 (net +254) | 6 (net +106) | 5 (net +213) | 1 | 19% (6 of 31) |
| Opponent | Warriors of Chaos | 32 | 2 (net -15) | 0 | 8 (net +101) | 2 (net +416) | 4 (net +31) | 13 (net +134) | 3 | 28% (8 of 29) |
| Opponent | Wood Elf Realms | 14 | 1 (net +0) | 0 | 0 | 2 (net +0) | 0 | 3 (net +79) | 8 | 0% (0 of 6) |

### Charged fights, damage counted: ef2-mine-f5fe7c8-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 15 | 269 | 212 | +86 | 127 | 59 | +68 | +25.3 |
| Mine | 50-54% | 2 | 216 | 223 | +193 | 220 | 44 | +176 | +81.7 |
| Mine | Effective (55-75%) | 20 | 232 | 183 | -38 | 70 | 89 | -19 | -8.2 |
| Mine | 76-89% | 20 | 255 | 154 | +49 | 75 | 17 | +58 | +22.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 40 | 232 | 161 | +83 | 137 | 45 | +92 | +39.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 8 | 377 | 95 | +13 | 94 | 60 | +35 | +9.2 |
| Mine | No odds | 14 | 224 | 170 | +12 | 79 | 73 | +6 | +2.6 |
| Mine | All fights | 119 | 249 | 168 | +46 | 106 | 54 | +52 | +20.9 |
| Opponent | Long shot (under 50%) | 13 | 284 | 249 | +84 | 204 | 167 | +37 | +13.1 |
| Opponent | 50-54% | 1 | 50 | 440 | -233 | 0 | 233 | -233 | -466.0 |
| Opponent | Effective (55-75%) | 22 | 338 | 249 | +105 | 168 | 65 | +103 | +30.5 |
| Opponent | 76-89% | 20 | 301 | 243 | +180 | 210 | 55 | +154 | +51.2 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 35 | 314 | 215 | +134 | 172 | 18 | +154 | +49.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 13 | 337 | 77 | +54 | 65 | 19 | +45 | +13.5 |
| Opponent | No odds | 17 | 142 | 233 | -4 | 74 | 86 | -12 | -8.7 |
| Opponent | All fights | 121 | 289 | 219 | +100 | 154 | 60 | +94 | +32.5 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ef2-mine-f5fe7c8-p3 | move | 463 | 117 (25%) | 87 (19%) | 56 (12%) | 290 (63%) |
| ef2-mine-f5fe7c8-p3 | objective | 372 | 64 (17%) | 44 (12%) | 54 (15%) | 254 (68%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

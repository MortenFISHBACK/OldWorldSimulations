# Doctrine scorecard: ef2-opp-f5fe7c8-p2

### Scorecard: ef2-opp-f5fe7c8-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 5 | 2 | 3 | 2 | 0 | 0 | 0 | 377 |
| L0106 | 4 | 1 | Opponent | no | 0 | 5 | 2 | 0 | 0 | 0 | 0 | 1011 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 2 | 1 | 0 | 0 | 0 |
| L0122 | 2 | 1 | Opponent | - | - | 1 | 1 | 0 | 0 | 0 | 0 | 55 |
| L0206 | 2 | 1 | Mine | - | - | - | 0 | 7 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 1 | 0 | 1 | 0 | 0 | 0 | 615 |
| L0222 | 6 | 1 | Mine | no | 0 | 2 | 3 | 5 | 1 | 0 | 0 | 0 |
| L0222 | 6 | 1 | Opponent | no | 4 | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | yes | 2 | - | 2 | 1 | 0 | 0 | 0 | 760 |
| L0307 | 1 | 1 | Opponent | yes | 1 | 6 | 1 | 1 | 0 | 0 | 0 | 420 |
| L0323 | 5 | 1 | Mine | no | - | 4 | 1 | 1 | 0 | 0 | 0 | 590 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 2 | 3 | 1 | 0 | 0 | 140 |
| L0409 | 1 | 1 | Mine | no | 4 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 7 | 3 | 1 | 1 | 0 | 0 | 0 | 524 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | no | - | - | 1 | 3 | 1 | 0 | 0 | 516 |
| L0512 | 2 | 1 | Mine | - | - | 5 | 4 | 2 | 0 | 0 | 0 | 548 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 5 | 3 | 0 | 0 | 0 | 0 | 0 | 678 |
| L0528 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 1 | 0 | 0 | 0 |
| L0616 | 4 | 1 | Mine | no | 0 | 4 | 5 | 1 | 0 | 0 | 0 | 615 |
| L0616 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 1 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 5 | 1 | 0 | 0 | 0 | 0 | 743 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 5 | 3 | 0 | 0 | 0 | 139 |
| L0721 | 1 | 1 | Mine | yes | 6 | 2 | 3 | 0 | 0 | 0 | 0 | 420 |
| L0721 | 1 | 1 | Opponent | no | 0 | - | 0 | 4 | 0 | 0 | 0 | 290 |
| L0810 | 6 | 1 | Mine | no | 1 | 2 | 1 | 2 | 0 | 0 | 0 | 605 |
| L0810 | 6 | 1 | Opponent | no | 10 | 2 | 4 | 1 | 0 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 753 |
| L0827 | 5 | 1 | Opponent | yes | - | 3 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0918 | 6 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 8 | 2 | 5 | 3 | 0 | 0 | 0 | 234 |
| L0934 | 4 | 1 | Mine | no | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 736 |
| L0934 | 4 | 1 | Opponent | yes | 0 | 2 | 8 | 4 | 0 | 0 | 0 | 160 |
| L1026 | 6 | 1 | Mine | no | 0 | 2 | 6 | 1 | 0 | 0 | 0 | 623 |
| L1026 | 6 | 1 | Opponent | no | 2 | 3 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | 2 | 6 | 0 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 3 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1135 | 1 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 501 |
| L1135 | 1 | 1 | Opponent | yes | 5 | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L1228 | 4 | 1 | Mine | no | 4 | 3 | 2 | 0 | 0 | 0 | 0 | 524 |
| L1228 | 4 | 1 | Opponent | no | 0 | - | 1 | 3 | 2 | 0 | 0 | 351 |
| L1323 | 3 | 1 | Mine | no | 3 | 2 | 3 | 1 | 0 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | no | 0 | 2 | 0 | 1 | 1 | 0 | 0 | 132 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1418 | 2 | 1 | Opponent | - | - | 3 | 3 | 2 | 2 | 0 | 0 | 297 |
| L1435 | 1 | 1 | Mine | no | 7 | 3 | 0 | 1 | 0 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Opponent | no | 3 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 0 | 2 | 3 | 0 | 1 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 5 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1629 | 3 | 1 | Mine | no | 0 | 5 | 3 | 0 | 0 | 0 | 0 | 536 |
| L1629 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 1 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | yes | - | 5 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1727 | 5 | 1 | Opponent | no | - | 2 | 4 | 3 | 1 | 0 | 0 | 60 |
| L1827 | 3 | 1 | Mine | no | 1 | 2 | 2 | 1 | 0 | 0 | 0 | 297 |
| L1827 | 3 | 1 | Opponent | no | 10 | 2 | 6 | 3 | 1 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 1 | 1 | 3 | 2 | 1 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Opponent | no | 0 | 2 | 6 | 2 | 0 | 0 | 0 | 60 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 2 | 2 | 1 | 0 | 0 | 402 |
| L2029 | 1 | 1 | Opponent | no | 6 | 3 | 2 | 2 | 0 | 0 | 0 | 377 |
| L2131 | 1 | 1 | Mine | yes | 1 | - | 3 | 3 | 0 | 0 | 0 | 722 |
| L2131 | 1 | 1 | Opponent | yes | 5 | 2 | 3 | 0 | 0 | 0 | 0 | 170 |
| L2235 | 3 | 1 | Mine | no | 1 | 1 | 3 | 0 | 0 | 0 | 0 | 225 |
| L2235 | 3 | 1 | Opponent | no | 0 | 3 | 3 | 0 | 1 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Mine | no | - | 5 | 2 | 2 | 0 | 0 | 0 | 343 |
| L2429 | 5 | 1 | Opponent | yes | - | 3 | 4 | 3 | 0 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Mine | no | 0 | 2 | 0 | 0 | 2 | 0 | 0 | 0 |
| L2535 | 3 | 1 | Opponent | no | 7 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | yes | - | 4 | 2 | 1 | 0 | 0 | 0 | 50 |
| L2735 | 5 | 1 | Opponent | yes | - | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Mine | no | 7 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 0 | 1 | 3 | 3 | 0 | 0 | 0 | 144 |
| **Average** | | | Mine | 20% | 2.0 | 2.7 | 2.5 | 1.2 | 0.2 | 0.0 | 0.0 | 331.6 |
| **Average** | | | Opponent | 27% | 3.0 | 2.4 | 3.0 | 1.8 | 0.4 | 0.0 | 0.0 | 186.8 |

### KPIs: ef2-opp-f5fe7c8-p2

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Winner chose to follow up after the loser gave ground |  | 97% (60 of 62); on the table 98% | 100% (59 of 59); on the table 100% | 98% (119 of 121); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 87% (13 of 15); on the table 87% | 90% (18 of 20); on the table 90% | 89% (31 of 35); on the table 89% |
| Winner chose to pursue after the loser fled |  | 58% (14 of 24); on the table 75% | 92% (35 of 38); on the table 92% | 79% (49 of 62); on the table 85% |
| Winner chose to follow up or pursue (all three) |  | 86% (87 of 101); on the table 91% | 96% (112 of 117); on the table 96% | 91% (199 of 218); on the table 94% |
| Magic missiles tried each own turn | 50%+ | 27% (91 of 342) | 28% (43 of 156) | 27% (134 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 43% (91 of 210) | 39% (43 of 110) | 42% (134 of 320) |
| Points that never fought | lower | 30% (21597 of 71583) | 36% (26237 of 71989) | 33% (47834 of 143572) |
|   infantry points that never fought | lower | 39% (6421 of 16324) | 56% (7840 of 14029) | 47% (14261 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 63% (178 of 284) | 54% (159 of 297) | 58% (337 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 85% (17 of 20); 1.3 uses a game | 83% (15 of 18); 1.1 uses a game | 84% (32 of 38); 1.2 uses a game |
| Bound items with another spell used |  | 50% (9 of 18); 0.5 uses a game | 50% (1 of 2); 0.0 uses a game | 50% (10 of 20); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 55% (11 of 20); 0.3 uses a game | 29% (2 of 7); 0.1 uses a game | 48% (13 of 27); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 58% (34972 of 60231) | 47% (29880 of 63281) | 53% (64852 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.7 (25%) | 0.9 (28%) | 2.6 (26%) |
| MARCHED: its unit marched | 1.2 (18%) | 0.6 (19%) | 1.9 (18%) |
| CHARGED: its unit charged | 0.2 (4%) | 0.1 (4%) | 0.4 (4%) |
| IN COMBAT: engaged in combat | 1.9 (27%) | 0.7 (21%) | 2.5 (25%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.2 (5%) | 0.2 (2%) |
| GONE: slain | 1.0 (14%) | 0.6 (18%) | 1.6 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.8 (12%) | 0.1 (2%) | 0.9 (9%) |
| STUPIDITY: Stupidity | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.1 (2%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.5 | 1.6 | 1.1 | 3.7 | 0.4 | 2.6 |
| not cast | 4.3 | 3.3 | 3.9 | 10.1 | 1.9 | 19.1 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) | 1.4 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.4 (42%) | 0.2 (6%) | 2.6 (26%) | 0.4 (20%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.9 (18%) | 0.5 (27%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (4%) | 0.0 (1%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.4 (12%) | 0.9 (23%) | 2.5 (25%) | 0.4 (23%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (7%) | 0.3 (9%) | 0.2 (5%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) |
| GONE: slain | 1.7 (39%) | 0.7 (20%) | 0.7 (18%) | 1.6 (15%) | 0.2 (9%) | 3.9 (20%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (5%) | 0.2 (7%) | 0.5 (13%) | 0.9 (9%) | 0.1 (6%) | 1.1 (6%) |
| STUPIDITY: Stupidity | 0.2 (4%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.3 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.2 (6%) | 0.0 (0%) | 0.0 (0%) | 0.2 (13%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.7 (40%) | 0.1 (4%) | 1.3 (34%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 12.3 (64%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.6 a game | 0.6 a game | 0.6 a game |
| stood (cast and not dispelled) | 79% (15 of 19) | 52% (11 of 21) | 65% (26 of 40) |
| the unit moved after it | 73% (11 of 15) | 45% (5 of 11) | 62% (16 of 26) |
| it charged on its next turn | 13% (2 of 15) | 9% (1 of 11) | 12% (3 of 26) |
| the enemy charged it first | 13% (2 of 15) | 36% (4 of 11) | 23% (6 of 26) |
| it fought by the end of its next turn | 13% (2 of 15) | 27% (3 of 11) | 19% (5 of 26) |
| it moved out of a charge the enemy had planned (not charged first) | 13% (2 of 15) | 9% (1 of 11) | 12% (3 of 26) |
| none of these (no charge, no fight, no charge escaped) | 60% (9 of 15) | 36% (4 of 11) | 50% (13 of 26) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 65% (540 of 833) | 52% (415 of 804) | 58% (955 of 1637) |
|   cavalry | 59% (45 of 76) | 52% (90 of 172) | 54% (135 of 248) |
|   character | 57% (50 of 87) | 26% (30 of 116) | 39% (80 of 203) |
|   chariot | 36% (31 of 85) | 57% (28 of 49) | 44% (59 of 134) |
|   infantry | 57% (143 of 250) | 56% (168 of 298) | 57% (311 of 548) |
|   monster | 57% (21 of 37) | 53% (18 of 34) | 55% (39 of 71) |
|   war machine | 84% (250 of 298) | 60% (81 of 135) | 76% (331 of 433) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.4 (30%) | 3.2 (30%) | 5.7 (30%) |
| CHARGED: it charged | 1.1 (14%) | 1.9 (18%) | 3.1 (16%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.2 (2%) | 0.3 (1%) |
| IN COMBAT: it fought this turn or the last | 1.0 (13%) | 0.4 (4%) | 1.4 (8%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 1.2 (14%) | 1.8 (16%) | 2.9 (16%) |
| ONLY IN COMBAT: the only targets were in combat | 0.3 (4%) | 0.7 (7%) | 1.0 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.3 (16%) | 1.6 (14%) | 2.8 (15%) |
| SHELTERED: the target was sheltered | 0.4 (5%) | 0.5 (5%) | 0.9 (5%) |
| OTHER BAR | 0.2 (3%) | 0.5 (4%) | 0.7 (4%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.6 | 0.9 | 86% | 3.1 pts | 17 pts |
| character | 2.4 | 0.9 | 79% | 7.1 pts | 17 pts |
| chariot | 1.6 | 1.5 | 64% | 21.2 pts | 35 pts |
| infantry | 11.9 | 5.1 | 69% | 9.5 pts | 113 pts |
| monster | 1.2 | 0.5 | 70% | 10.8 pts | 13 pts |
| war machine | 9.2 | 7.5 | 58% | 26.1 pts | 240 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.9 | 6.2 | 5.1 |
| Charges that made contact a game | 2.9 | 4.5 | 3.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.72 declared, 0.60 contact (25 units) | 0.64 declared, 0.50 contact (14 units) | 0.69 declared, 0.56 contact (39 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.38 declared, 0.25 contact (8 units) | 1.42 declared, 1.25 contact (12 units) | 1.00 declared, 0.85 contact (20 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.48 declared, 0.35 contact (249 units) | 0.67 declared, 0.48 contact (295 units) | 0.58 declared, 0.42 contact (544 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 66% (48 of 73) | 72% (13 of 18) | 50% (6 of 12) | 65% (67 of 103) |
| Character in a unit | 75% (21 of 28) | 58% (11 of 19) | 33% (1 of 3) | 66% (33 of 50) |
| Character on its own | 80% (35 of 44) | 43% (15 of 35) | 24% (15 of 63) | 46% (65 of 142) |
| Chariot | 71% (12 of 17) | 62% (8 of 13) | - | 67% (20 of 30) |
| Infantry | 50% (47 of 94) | 65% (22 of 34) | 33% (1 of 3) | 53% (70 of 131) |
| Monster | 59% (17 of 29) | 89% (8 of 9) | - | 66% (25 of 38) |
| Monstrous | 50% (7 of 14) | 71% (10 of 14) | - | 61% (17 of 28) |
| War Machines | 67% (38 of 57) | 100% (2 of 2) | - | 68% (40 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 62% (5 of 8); on the table 62% | 20% (20 of 102) | 43% | 45% (10 of 22) | 67% (4 of 6); 3.2 uses a game | 50% (1 of 2); 0.8 uses a game | 100% (6 of 6); 1.5 uses a game |
| Chaos Dwarfs | 4 | 100% (14 of 14); on the table 100% | 42% (15 of 36) | 40% | 50% (16 of 32) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Dwarfen Mountain Holds | 6 | 85% (11 of 13); on the table 100% | - | 51% | 72% (39 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 75% (6 of 8); on the table 75% | 33% (16 of 48) | 41% | 70% (53 of 76) | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game | 0% (0 of 4); 0.0 uses a game |
| Grand Cathay | 6 | 88% (28 of 32); on the table 88% | 28% (38 of 138) | 30% | 46% (25 of 54) | 100% (14 of 14); 6.5 uses a game | 50% (1 of 2); 0.2 uses a game | 17% (1 of 6); 0.2 uses a game |
| High Elf Realms | 4 | 100% (13 of 13); on the table 100% | 17% (3 of 18) | 24% | 67% (22 of 33) | 67% (2 of 3); 1.2 uses a game | 50% (7 of 14); 3.5 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 100% (3 of 3); on the table 100% | - | 50% | 67% (8 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | 100% (3 of 3); on the table 100% | - | 44% | 57% (4 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 82% (9 of 11); on the table 91% | 0% (0 of 18) | 22% | 79% (22 of 28) | 100% (4 of 4); 1.2 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (3 of 3); on the table 100% | 17% (2 of 12) | 6% | 62% (5 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 3 | 100% (4 of 4); on the table 100% | 28% (5 of 18) | 20% | 72% (18 of 25) | 100% (2 of 2); 2.3 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Tomb Kings of Khemri | 5 | 84% (16 of 19); on the table 89% | - | 35% | 32% (8 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 96% (26 of 27); on the table 100% | 36% (24 of 66) | 22% | 67% (36 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 97% (35 of 36); on the table 97% | 33% (6 of 18) | 33% | 37% (27 of 73) | 100% (2 of 2); 0.7 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 96% (23 of 24); on the table 96% | 21% (5 of 24) | 33% | 56% (44 of 78) | 57% (4 of 7); 1.9 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ef2-opp-f5fe7c8-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 49% (45) | 50% (34) | 49% (79) |
| ...free all their last turn and able to turn (per game) | 0.72 | 0.64 | 1.36 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.28 | 0.11 | 0.39 |
| ...with the charger already in that arc before they moved (per game) | 0.47 | 0.36 | 0.83 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.36 | 0.83 | 2.19 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.50 | 0.67 | 1.17 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 7.06 | 6.36 | 13.42 |

### Quality by phase: ef2-opp-f5fe7c8-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 55% (64 of 116) | 47% (98 of 210) |
| Strategy | Shoot objectives carried out (shot that target) | 47% (152 of 325) | 56% (97 of 174) |
| Strategy | Close-in objectives charged next turn | 13% (18 of 139) | 13% (25 of 196) |
| Strategy | Support requests answered (helper made contact too) | 62% (8 of 13) | 50% (16 of 32) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 50% (1 of 2) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 39% (7 of 18) | 35% (6 of 17) |
| Strategy | Joined characters whose unit fought | 65% (26 of 40) | 42% (16 of 38) |
| Strategy | Lone characters that fought | 83% (87 of 105) | 79% (67 of 85) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 1.2 | 1.8 |
| Movement | Points that never moved of their own | 331.6 | 186.8 |
| Movement | Fights charged into per game | 2.7 | 3.8 |
| Movement | Charges with odds: long shots (under 50%) | 7 of 84, net -133 | 20 of 123, net +24 |
| Movement | Charges with odds: sweet spot (55-75%) | 7 of 84, net +156 | 26 of 123, net +123 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 11 of 84, net +42 | 6 of 123, net +179 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 38 of 84, net +90 | 44 of 123, net +206 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.2 | 10.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 39% (130 of 331) | 40% (150 of 372) |
| Shooting | Points destroyed by shooting units | 111.1 | 57.4 |
| Shooting | War machine shots | 6.9 | 2.2 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 59% (148 of 250) | 53% (43 of 81) |
| Shooting | Points destroyed by war machines | 76.0 | 58.6 |
| Magic | Magic missiles cast | 1.8 | 0.7 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 24% (15 of 63) | 46% (12 of 26) |
| Magic | Wounds caused by magic missiles | 2.7 | 1.4 |
| Magic | Wounds caused by other spells | 2.1 | 1.4 |
| Magic | Points destroyed by magic (all spells) | 74.6 | 25.1 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.7 / 0.6 / 1.1 / 0.1 | 1.7 / 0.5 / 0.8 / 0.2 |
| Combat | Points destroyed in combat | 312.5 | 519.8 |
| Combat | Points run down | 84.6 | 201.9 |
| Combat | Net points per charged fight, damage counted | +58 | +124 |
| Combat | Net per 100 charger points, damage counted | +19.7 | +45.7 |
| Combat | First round won (charged fights) | 71% | 58% |
| Combat | Net points per charged fight | +50 | +130 |
| Combat | Net points per supported fight / lone fight | +44 / +51 | +204 / +117 |
| Combat | Charged fights on a top-3 enemy unit | 33 of 96 | 68 of 137 |
| Game | Points lost | 980.0 | 660.4 |
| Game | VP from objectives | 417.2 | 712.8 |
| Game | Lone holders (player turns) | 2.0 | 3.0 |

- Mine won / drew / lost: 12 / 5 / 19 of 36 ended games (of 36); mean margin (Mine - Opponent) -618 VP
- The side that went first won 17 of 31 games with a winner
- Points traded per game (both sides' losses): 1640
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ef2-opp-f5fe7c8-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +5.6 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.6 | +0.0 | 0.0 | 20.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.9 | +5.4 | 0.0 | 36.1 | 1.0 | +13.7 | 0.0 | 13.7 |
| BEST PREY | 3.7 | +194.3 | 143.2 | 161.9 | 4.6 | +333.2 | 389.2 | 185.8 |
| BEST PRIZE | 0.0 | +0.6 | 3.5 | 0.0 | 0.0 | +0.5 | 0.9 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 5.1 | 0.0 | 0.1 | +0.0 | 0.0 | 16.6 |
| BLOCKED WHEEL | 0.3 | +2.0 | 0.0 | 7.4 | 0.6 | +19.2 | 0.0 | 8.8 |
| BOMBING RUN | 0.1 | +1.7 | 3.5 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | 0.2 | +0.0 | 0.0 | 23.6 | - | - | - | - |
| CANNON PLAN MISSED | 0.9 | +0.0 | 90.3 | 16.5 | 0.2 | +0.0 | 42.6 | 0.0 |
| CANNON PLANNED TARGET | 5.2 | +129.5 | 403.2 | 91.0 | 1.6 | +103.8 | 145.2 | 6.7 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 2.4 | 0.5 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 5.4 | 15.1 | - | - | - | - |
| CARRIES OUT SET-UP | 0.0 | +0.0 | 1.1 | 0.0 | 0.2 | -2.1 | 14.5 | 0.0 |
| CAST JOB | 0.8 | +18.9 | 79.2 | 27.1 | 0.3 | +5.9 | 32.5 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +22.7 | 18.8 | 8.2 | 0.1 | +6.3 | 14.1 | 0.0 |
| CASTS AFTER FRIENDS | 0.4 | +0.0 | 0.0 | 35.8 | 0.4 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.2 | -0.5 | 9.2 | 0.0 | 0.4 | -0.8 | 6.3 | 0.0 |
| CHARGE NOW WEIGHED | 0.5 | -31.4 | 11.4 | 17.4 | 0.7 | -48.9 | 30.2 | 23.1 |
| CHARIOT NO STATIC JOB | 0.8 | +0.0 | 12.2 | 13.2 | 0.4 | +0.0 | 3.2 | 5.5 |
| CHEAP HELPER | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 10.9 | 5.8 |
| CONVEYANCE SEARCH | 0.4 | +60.0 | 19.2 | 16.5 | 0.5 | +62.3 | 12.2 | 5.3 |
| COUNTER-CHARGE COVER | 10.3 | +806.5 | 0.0 | 335.9 | 5.4 | +279.3 | 0.0 | 89.5 |
| EDGE GIVE GROUND | 0.1 | +0.7 | 5.5 | 0.0 | 0.3 | +19.7 | 19.9 | 2.8 |
| ELIXIR WORTH | 0.0 | +0.8 | 0.0 | 0.0 | - | - | - | - |
| ENEMY FORECAST | - | - | - | - | 6.8 | +181.2 | 117.4 | 108.3 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 2.4 | - | - | - | - |
| FACES THE THREAT | 1.4 | +113.1 | 0.0 | 97.9 | 0.8 | +75.9 | 0.0 | 17.1 |
| FALLBACK BY WORTH | 5.8 | +126.8 | 0.0 | 128.9 | 7.6 | +65.9 | 0.0 | 120.8 |
| FIGHT LIFT | 0.1 | +0.3 | 9.3 | 17.8 | 0.0 | +1.9 | 13.1 | 0.0 |
| FIRE AND FLEE | 0.1 | +0.6 | 0.0 | 1.7 | 0.1 | +1.2 | 8.0 | 6.1 |
| FLANK NOT WEIGHED | 0.5 | +0.0 | 0.0 | 6.2 | 0.3 | +0.0 | 0.0 | 1.4 |
| FOCUS FIRE | 0.1 | +4.3 | 4.7 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| FOLLOW UP WEIGHED | 1.1 | +151.7 | 0.0 | 68.8 | 1.4 | +241.0 | 0.0 | 32.8 |
| FORECAST RESULT | 42.6 | +2818.6 | 941.7 | 856.2 | 40.3 | +1750.0 | 1219.4 | 1395.0 |
| FRIENDS SHOTS CHECKED | 0.4 | +34.3 | 0.0 | 8.6 | 0.2 | +11.9 | 0.0 | 0.0 |
| GIVES UP | 1.0 | -28.1 | 127.2 | 49.5 | 1.4 | -52.6 | 184.8 | 51.2 |
| GIVES UP ITS SCREEN | 0.3 | -4.0 | 9.9 | 3.5 | 1.5 | -43.9 | 131.2 | 18.6 |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 17.9 | 0.0 |
| HELPER UNSEEN | 0.1 | +0.0 | 1.7 | 1.7 | 0.5 | +0.0 | 23.9 | 10.2 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.2 | +2.0 | 15.0 | 5.5 | 0.2 | +3.0 | 29.6 | 0.0 |
| HUNT DROPPED | 0.1 | +0.0 | 15.0 | 4.0 | 0.1 | +0.0 | 11.0 | 0.0 |
| HUNT IN PAIRS | 0.3 | +24.5 | 0.0 | 0.0 | 0.8 | +27.8 | 0.0 | 21.1 |
| HUNT KEPT | 0.1 | +0.0 | 5.3 | 0.9 | 0.2 | +7.1 | 45.7 | 0.0 |
| HUNT RESULT | 0.2 | +5.3 | 20.3 | 5.9 | 0.3 | +114.3 | 24.7 | 0.0 |
| HUNT THE GUNS | 0.2 | +59.9 | 15.0 | 5.5 | 0.3 | +154.6 | 60.1 | 0.0 |
| JOINT CHARGE PLAN | 0.0 | +5.6 | 0.0 | 0.0 | 0.2 | +2.6 | 8.6 | 0.0 |
| KEEP FALLS | 0.1 | +1.7 | 0.0 | 6.1 | - | - | - | - |
| KEEPS ITS PREY | 0.2 | +1.4 | 16.2 | 16.0 | 0.3 | +3.8 | 22.5 | 8.4 |
| KEEPS ITS TARGET | 1.5 | +45.0 | 81.9 | 83.6 | 2.7 | +80.0 | 348.8 | 57.3 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 1.6 | +91.6 | 128.7 | 38.2 | 2.3 | +97.1 | 157.0 | 11.4 |
| KILLS COUNT NEXT TURN | 6.7 | +231.9 | 277.6 | 282.0 | 10.1 | +502.2 | 660.2 | 276.5 |
| LONE CHARACTER SAFE SPOT | 0.4 | +10.5 | 2.0 | 16.9 | 0.2 | +1.1 | 6.5 | 7.2 |
| LONE WIZARD HOLDS BACK | 1.0 | +0.0 | 46.0 | 37.8 | 0.9 | +0.0 | 63.7 | 34.7 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 0.0 | 0.3 | +23.5 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.5 | +20.7 | 0.0 | 1.4 | 1.1 | +44.6 | 30.4 | 31.3 |
| MANOEUVRE | 0.1 | +6.4 | 0.0 | 6.5 | 0.2 | +5.9 | 0.0 | 5.1 |
| MARCH AT ESCAPER | 0.0 | +0.6 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 0.0 |
| MARCH CHECK | 0.5 | +16.9 | 0.0 | 15.5 | 0.5 | +14.5 | 0.0 | 0.0 |
| MARCH ODDS | 0.6 | +40.6 | 27.2 | 33.3 | 0.6 | +43.3 | 59.3 | 3.0 |
| MARCH OVER CASTS | 0.8 | +8.0 | 0.0 | 40.5 | 0.7 | +18.1 | 0.0 | 10.6 |
| MAX FOR POSITIONING | 5.1 | +174.9 | 0.0 | 190.3 | 4.6 | +141.8 | 0.0 | 73.1 |
| MISSILES IN THE MOVE | 3.1 | +72.6 | 0.0 | 119.3 | 2.6 | +41.8 | 0.0 | 48.1 |
| MISSILES NEXT TURN | 4.2 | +53.5 | 0.0 | 173.4 | 3.4 | +38.4 | 0.0 | 73.6 |
| MODEL FACING | 0.3 | +83.9 | 0.0 | 3.3 | 0.2 | +45.4 | 0.0 | 0.0 |
| MOVE AND CAST | 0.2 | +8.9 | 0.0 | 11.1 | 0.2 | +14.7 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.1 | +2.1 | 0.0 | 16.1 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -19.5 | 0.0 | 25.0 | 0.3 | -10.1 | 20.1 | 17.8 |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 22.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | 0.1 | +7.0 | 1.7 | 0.0 | 0.1 | +2.9 | 6.3 | 0.0 |
| NOT NEEDED | 0.2 | -10.7 | 22.7 | 0.0 | 0.4 | -24.9 | 75.8 | 0.0 |
| NOT TURNED | 7.1 | +107.4 | 0.0 | 252.0 | 6.4 | +95.9 | 0.0 | 134.3 |
| NOT WORTH A CAST | 0.4 | -0.3 | 0.0 | 0.0 | 0.6 | -0.5 | 0.0 | 0.0 |
| OPENS A LANE | 0.1 | +3.5 | 8.4 | 2.8 | - | - | - | - |
| OPENS UP | 0.2 | +17.2 | 6.3 | 12.3 | 0.2 | +18.3 | 4.2 | 5.4 |
| OVERRUNS AWAY | 0.5 | +16.9 | 50.1 | 9.6 | 0.5 | +9.7 | 89.6 | 3.5 |
| PATHS CROSS | 1.8 | +129.0 | 0.0 | 9.1 | 2.8 | +178.9 | 0.0 | 28.4 |
| PERIAPT WORTH | 0.0 | +3.4 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 15.0 |
| PLAN LEADS | 1.4 | +155.5 | 18.9 | 31.7 | 1.2 | +70.7 | 23.4 | 20.3 |
| PLAN RESULT | 36.3 | +1424.9 | 1321.3 | 1434.7 | 40.7 | +1572.0 | 1928.9 | 875.6 |
| PURSUES BIG PREY | 0.1 | -12.6 | 0.0 | 0.0 | 0.2 | -14.8 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +4.9 | 0.0 | 0.0 | 0.1 | +5.1 | 0.0 | 0.0 |
| REDIRECT COUNTER | 3.3 | +206.5 | 0.0 | 55.7 | 3.3 | +185.1 | 0.0 | 50.3 |
| REDIRECT WEIGHED | 0.3 | +2.7 | 3.5 | 10.6 | 0.4 | +11.2 | 15.5 | 5.4 |
| RESTRAINS TO SHOOT | 0.1 | +4.5 | 0.0 | 5.1 | 0.0 | +0.3 | 0.0 | 0.0 |
| RISK BY ARC | 2.1 | +64.3 | 176.1 | 93.2 | 3.5 | +76.7 | 392.7 | 78.6 |
| SAFER THAN THE JOB | 0.5 | +29.0 | 0.0 | 0.0 | 0.7 | +37.2 | 0.0 | 26.3 |
| SCOUT SPOT | 0.3 | +0.6 | 0.0 | 1.5 | 0.5 | +2.1 | 0.0 | 0.9 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 1.5 | 0.6 | +0.0 | 0.0 | 0.9 |
| SEARCH SPOT | 1.7 | +97.6 | 0.0 | 48.8 | 1.7 | +92.8 | 0.0 | 33.6 |
| SECOND HUNTER | - | - | - | - | 0.1 | -0.6 | 19.6 | 0.0 |
| SELF MOVE SPELL | 0.2 | +12.5 | 0.0 | 31.0 | - | - | - | - |
| SET UP TOGETHER | 0.7 | +27.4 | 9.6 | 3.4 | 2.0 | +90.8 | 30.4 | 55.1 |
| SET-UP ANY TARGET | 0.1 | +21.7 | 5.3 | 2.6 | 0.1 | +13.7 | 3.5 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.0 | +4.6 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.5 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.6 | +0.0 | 163.4 | 6.4 | 0.4 | +0.0 | 69.8 | 0.0 |
| SHOTS IN THE MOVE | 12.9 | +466.0 | 0.0 | 240.1 | 10.6 | +329.4 | 0.0 | 97.6 |
| SPELL CATCH ODDS | 0.0 | -0.6 | 5.3 | 2.6 | 0.1 | -0.1 | 3.5 | 0.0 |
| SPELL SETS UP CHARGE | 0.2 | +55.3 | 19.2 | 16.5 | 0.2 | +44.7 | 3.5 | 0.0 |
| SPELL WORTH | 0.8 | +24.7 | 97.7 | 90.0 | 1.6 | +34.7 | 109.4 | 75.2 |
| STANDS TO CAST | - | - | - | - | 0.0 | +2.8 | 0.0 | 0.0 |
| STOPS | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +15.6 | 54.2 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 4.7 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -10.8 | 1.1 | 23.4 | 0.1 | -9.7 | 9.3 | 5.6 |
| SURE REACH TOGETHER | 0.4 | +8.8 | 0.0 | 14.0 | 1.0 | -4.4 | 0.0 | 14.2 |
| THROUGH LINE OF FIRE | 0.5 | +21.3 | 0.0 | 14.4 | 0.2 | +8.4 | 0.0 | 19.6 |
| TURN WORTH | 0.5 | -30.9 | 57.8 | 0.0 | 0.4 | -27.4 | 19.1 | 5.4 |
| TWO OR MORE ARRIVE | 0.1 | +1.3 | 9.6 | 0.0 | 0.4 | +1.2 | 10.9 | 18.2 |
| WEARS DOWN | 0.7 | +29.2 | 89.8 | 23.7 | 2.0 | +61.7 | 312.4 | 76.0 |
| WHO HITS BACK | 0.2 | +17.9 | 0.0 | 7.0 | 0.1 | +7.5 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.2 | +12.1 | 24.3 | 4.2 | 0.5 | +23.7 | 117.9 | 11.2 |
| WHOLE FIGHT GAIN | 0.2 | +20.3 | 20.4 | 14.5 | 0.5 | +49.2 | 48.2 | 5.5 |

### Rule changes: ef2-opp-f5fe7c8-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| KILLS COUNT NEXT TURN | 603 | 598 | 198 | 5.50 | +7337 | +37.1 |
| PATHS CROSS | 168 | 168 | 168 | 4.67 | +11085 | +66.0 |
| BEST PREY | 299 | 297 | 134 | 3.72 | +6233 | +46.5 |
| FALLBACK BY WORTH | 482 | 482 | 124 | 3.44 | +6939 | +56.0 |
| SEARCH SPOT | 121 | 121 | 117 | 3.25 | +6918 | +59.1 |
| COUNTER-CHARGE COVER | 563 | 294 | 111 | 3.08 | +4461 | +40.2 |
| FOLLOW UP WEIGHED | 88 | 88 | 88 | 2.44 | +14140 | +160.7 |
| FACES THE THREAT | 79 | 79 | 79 | 2.19 | +6804 | +86.1 |
| ARTILLERY RE-ROLL WEIGHED | 68 | 68 | 68 | 1.89 | +0 | +0.0 |
| CANNON SIGHT KEPT | 65 | 65 | 65 | 1.81 | +0 | +0.0 |
| MAX FOR POSITIONING | 347 | 182 | 59 | 1.64 | +396 | +6.7 |
| SHOTS IN THE MOVE | 848 | 511 | 58 | 1.61 | +1239 | +21.4 |
| ENEMY FORECAST | 245 | 244 | 51 | 1.42 | +208 | +4.1 |
| ADVANCE LANE KEPT | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| CHARGE NOW WEIGHED | 42 | 42 | 42 | 1.17 | +4102 | +97.7 |
| SAFER THAN THE JOB | 42 | 42 | 42 | 1.17 | +2386 | +56.8 |
| KILLS COUNT | 143 | 136 | 41 | 1.14 | +1257 | +30.7 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| MARCH ODDS | 40 | 40 | 40 | 1.11 | +1060 | +26.5 |
| RISK BY ARC | 201 | 185 | 37 | 1.03 | +1034 | +27.9 |
| CANNON PLANNED TARGET | 247 | 247 | 36 | 1.00 | -495 | -13.8 |
| PLAN LEADS | 97 | 97 | 36 | 1.00 | +1825 | +50.7 |
| SET UP TOGETHER | 98 | 82 | 36 | 1.00 | +1615 | +44.9 |
| BLOCKED WHEEL | 35 | 35 | 35 | 0.97 | +762 | +21.8 |
| KEEPS ITS TARGET | 150 | 146 | 34 | 0.94 | +637 | +18.7 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2266 | +68.7 |
| SHOT REPLANNED | 33 | 33 | 33 | 0.92 | +0 | +0.0 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| CHARIOT NO STATIC JOB | 41 | 41 | 28 | 0.78 | -2345 | -83.8 |
| REDIRECT COUNTER | 239 | 83 | 26 | 0.72 | +941 | +36.2 |
| REDIRECT WEIGHED | 25 | 25 | 25 | 0.69 | +1252 | +50.1 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +49 | +2.0 |
| MARCH CHECK | 34 | 27 | 24 | 0.67 | +638 | +26.6 |
| THROUGH LINE OF FIRE | 24 | 24 | 24 | 0.67 | +1069 | +44.5 |
| CAST JOB | 39 | 38 | 22 | 0.61 | +273 | +12.4 |
| CHAFF PASSED | 22 | 22 | 22 | 0.61 | -44 | -2.0 |
| LONE WIZARD HOLDS BACK | 66 | 66 | 21 | 0.58 | -1850 | -88.1 |
| MAKE SURE TOGETHER | 59 | 35 | 21 | 0.58 | +1000 | +47.6 |
| MODEL FACING | 20 | 20 | 20 | 0.56 | +4655 | +232.7 |
| FRIENDS SHOTS CHECKED | 19 | 19 | 19 | 0.53 | +1665 | +87.6 |
| MISSILES IN THE MOVE | 205 | 99 | 19 | 0.53 | +447 | +23.5 |
| WHOLE FIGHT GAIN | 26 | 21 | 17 | 0.47 | +558 | +32.8 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| MOVE AND CAST | 14 | 14 | 14 | 0.39 | +851 | +60.8 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| WEARS DOWN | 97 | 90 | 14 | 0.39 | +308 | +22.0 |
| CASTER AWAY FROM SCREEN | 12 | 12 | 12 | 0.33 | +0 | +0.0 |
| CASTING BLOCK | 18 | 17 | 12 | 0.33 | +450 | +37.5 |
| MANOEUVRE | 11 | 11 | 11 | 0.31 | +443 | +40.3 |
| PURSUES BIG PREY | 11 | 11 | 11 | 0.31 | -987 | -89.7 |
| STUCK PIVOT | 11 | 11 | 11 | 0.31 | +0 | +0.0 |
| WHO HITS BACK | 11 | 11 | 11 | 0.31 | -629 | -57.2 |
| SURE CHARGE BEATS ADVANCE | 10 | 10 | 10 | 0.28 | -738 | -73.8 |
| SURE REACH TOGETHER | 49 | 37 | 9 | 0.25 | +85 | +9.4 |
| BLOCKED CHARGE SKIPPED | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| BOUND ASSAILMENT | 6 | 6 | 6 | 0.17 | +1 | +0.2 |
| FIRE AND FLEE | 6 | 6 | 6 | 0.17 | +65 | +10.8 |
| MISSILES NEXT TURN | 274 | 119 | 6 | 0.17 | +30 | +4.9 |
| OVERRUNS AWAY | 36 | 35 | 6 | 0.17 | +194 | +32.4 |
| HUNT IN PAIRS | 38 | 23 | 5 | 0.14 | +274 | +54.8 |
| KEEP FALLS | 5 | 5 | 5 | 0.14 | +236 | +47.2 |
| OPENS UP | 12 | 10 | 5 | 0.14 | +338 | +67.6 |
| WHOLE FIGHT | 28 | 23 | 5 | 0.14 | +266 | +53.2 |
| FOCUS FIRE | 4 | 4 | 4 | 0.11 | +155 | +38.9 |
| HUNT ADVANCE | 14 | 14 | 4 | 0.11 | +93 | +23.3 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| NEEDED THERE | 5 | 5 | 4 | 0.11 | +0 | +0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 4 | 4 | 4 | 0.11 | +132 | +32.9 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.11 | +171 | +42.7 |
| OPENS A LANE | 4 | 3 | 3 | 0.08 | +68 | +22.7 |
| BEST PRIZE | 2 | 2 | 2 | 0.06 | -44 | -21.8 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +59 | +29.7 |
| EDGE GIVE GROUND | 14 | 13 | 2 | 0.06 | +242 | +121.0 |
| JOINT CHARGE PLAN | 7 | 7 | 2 | 0.06 | +20 | +9.9 |
| PERIAPT WORTH | 2 | 2 | 2 | 0.06 | +130 | +65.1 |
| BACKUP TARGETS | 69 | 32 | 1 | 0.03 | +2 | +1.8 |
| CARRIES OUT SET-UP | 8 | 8 | 1 | 0.03 | -77 | -76.9 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -0 | -0.3 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +28 | +27.5 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +5 | +5.1 |
| KEEPS ITS PREY | 21 | 21 | 1 | 0.03 | +1 | +1.4 |
| MOVE SPELL IN RANGE | 2 | 2 | 1 | 0.03 | +0 | +0.3 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | -47 | -46.8 |
| STOPS | 10 | 10 | 1 | 0.03 | +78 | +78.1 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 3 | 3 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 39 | 39 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 4 | 4 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 29 | trace | - | - | - | - |
| CHEAP HELPER | 10 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 30 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 3 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 28 | not checked | - | - | - | - |
| FORECAST RESULT | 2982 | trace | - | - | - | - |
| GIVES UP | 89 | 84 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 65 | 62 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 23 | 20 | 0 | 0.00 | - | - |
| HUNT DROPPED | 6 | trace | - | - | - | - |
| HUNT KEPT | 9 | trace | - | - | - | - |
| HUNT RESULT | 19 | trace | - | - | - | - |
| HUNT THE GUNS | 19 | trace | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 20 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 3 | trace | - | - | - | - |
| MARCH OVER CASTS | 53 | 53 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 21 | trace | - | - | - | - |
| MOVE SPELL SPOT | 10 | not checked | - | - | - | - |
| NOT NEEDED | 22 | 22 | 0 | 0.00 | - | - |
| NOT TURNED | 483 | 483 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 37 | not checked | - | - | - | - |
| PLAN RESULT | 2772 | trace | - | - | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SECOND HUNTER | 4 | 4 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 8 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 10 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SPELL CATCH ODDS | 3 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 16 | not checked | - | - | - | - |
| SPELL WORTH | 85 | not checked | - | - | - | - |
| TURN WORTH | 31 | 29 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 19 | 18 | 0 | 0.00 | - | - |

### Plans: ef2-opp-f5fe7c8-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.6 | 18% | 631 | 435 | 69% |
| Mine | charge | 2.7 | 59% | 271 | 245 | 90% |
| Mine | close in | 3.8 | 20% | 263 | 81 | 31% |
| Mine | hold | 4.1 | 37% | 300 | 0 | 0% |
| Mine | join | 0.6 | 90% | 13 | 0 | 0% |
| Mine | shoot | 7.9 | 63% | 275 | 665 | 242% |
| Mine | support | 4.6 | 88% | 219 | 0 | 0% |
| Opponent | advance | 14.6 | 20% | 713 | 585 | 82% |
| Opponent | charge | 4.8 | 56% | 576 | 468 | 81% |
| Opponent | close in | 5.4 | 24% | 450 | 171 | 38% |
| Opponent | hold | 4.4 | 46% | 419 | 0 | 0% |
| Opponent | join | 0.7 | 100% | 30 | 0 | 0% |
| Opponent | shoot | 4.0 | 70% | 160 | 348 | 218% |
| Opponent | support | 6.8 | 91% | 423 | 0 | 0% |

### Enemy forecast: ef2-opp-f5fe7c8-p2

Per side (the computer that made the forecast) and expected action: forecasts a game, right (it did the expected action on the expected target), gone (missed, but the target or the enemy was gone before it acted), and what the enemy did instead; right of judged leaves the gone ones out.

| Side | Expected | A game | Right | Gone | Right of judged | Did charge | Did shoot | Did move | Same target |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 4.6 | 49% | 17% | 59% | 57% | 12% | 31% | 51% |
| Mine | shoot | 7.8 | 29% | 17% | 34% | 3% | 63% | 34% | 29% |
| Mine | move | 30.1 | 73% | 2% | 75% | 7% | 19% | 73% | - |
| Mine | all | 42.6 | 62% | 7% | 67% | 12% | 26% | 62% | - |
| Opponent | charge | 2.7 | 54% | 13% | 62% | 61% | 11% | 28% | 57% |
| Opponent | shoot | 14.6 | 36% | 18% | 44% | 1% | 70% | 28% | 37% |
| Opponent | move | 23.0 | 69% | 4% | 72% | 7% | 24% | 69% | - |
| Opponent | all | 40.3 | 56% | 10% | 62% | 8% | 40% | 52% | - |

Expected moves (the enemy's own plan): how far the expected end was from where the unit ended, against the guess that it stays where it stood.

| Side | Moves a game | Median miss | Median miss if it stays | Within 3" | Within 6" | Better than stays |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | 20.6 | 6.9" | 4.3" | 21% | 43% | 19% |
| Opponent | 14.8 | 6.4" | 3.6" | 21% | 48% | 22% |

### Packages: hunt the guns, ef2-opp-f5fe7c8-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.2 | 7 | 0 | 14% | 14% | 0% | 4.0 | 308 | 27 | 14% | 57 |
| Opponent | 0.3 | 12 | 0 | 58% | 75% | 0% | 2.7 | 464 | 343 | 75% | 110 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.8 | 3 | 0 | 0% | 0% | 0% | - | 330 | 0 | 0% | 26 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 379 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Empire of Man | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 554 | 0 | 0% | 105 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 72 |
| High Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 220 | 0 | 0% | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 236 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.5 | 6 | 0 | 67% | 67% | 0% | 3.0 | 413 | 265 | 67% | 105 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 228 |
| Tomb Kings of Khemri | 0.4 | 2 | 0 | 0% | 50% | 0% | 3.0 | 252 | 210 | 50% | 28 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 8 |
| Warriors of Chaos | 0.6 | 5 | 0 | 60% | 80% | 0% | 2.5 | 505 | 396 | 80% | 156 |
| Wood Elf Realms | 0.1 | 1 | 0 | 100% | 100% | 0% | 3.0 | 446 | 318 | 100% | 0 |

### Battle groups: ef2-opp-f5fe7c8-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 10.3 | 24% | 41% | 9% | 62% | 34% | 15% | 12% | 39% | 0% |
| Mine | REDIRECT COUNTER | 3.3 | 22% | 52% | 4% | 0% | 27% | 8% | 0% | 62% | 4% |
| Opponent | COUNTER-CHARGE COVER | 5.4 | 18% | 53% | 21% | 14% | 30% | 15% | 26% | 30% | 0% |
| Opponent | REDIRECT COUNTER | 3.3 | 23% | 81% | 19% | 20% | 23% | 0% | 9% | 64% | 5% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ef2-opp-f5fe7c8-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 0 (5) | 0 | 0 | 0 | 100% | - | - | 0 (4) | 0 (1) | 0 (5) | - |
| Mine | Chaff | 44 | 59 (44) | 42 | 17 | 71 | 41% | 3.0 | 93 (24) | 37 (5) | 12 (15) | 47 (30) | 87 (14) |
| Mine | Character | 123 | 46 (123) | 46 | 0 | 48 | 14% | 2.4 | 37 (33) | 59 (55) | 27 (9) | 51 (56) | 46 (41) |
| Mine | Clean-up | 12 | 44 (12) | 0 | 44 | 60 | 58% | 2.4 | 12 (3) | 30 (6) | 122 (3) | 66 (7) | 16 (5) |
| Mine | Fast Hammer | 45 | 36 (45) | 21 | 15 | 64 | 20% | 2.9 | 50 (24) | 21 (10) | 15 (11) | 37 (31) | 35 (14) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 80 | 20% | 2.0 | - | 0 (3) | 0 (2) | 0 (5) | - |
| Mine | Hammer | 58 | 32 (58) | 23 | 9 | 59 | 16% | 2.8 | 8 (15) | 41 (33) | 38 (10) | 34 (38) | 29 (20) |
| Mine | Holder | 28 | 41 (28) | 13 | 28 | 52 | 43% | 3.1 | 9 (10) | 49 (13) | 83 (5) | 61 (18) | 8 (10) |
| Mine | Shooter | 43 | 76 (43) | 19 | 57 | 59 | 2% | 1.8 | 43 (7) | 86 (26) | 66 (10) | 97 (27) | 38 (16) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 50% | 2.0 | - | 0 (2) | - | - | 0 (2) |
| Mine | War machine | 59 | 55 (59) | 55 | 0 | 43 | 5% | 1.2 | 67 (13) | 55 (36) | 39 (10) | 12 (10) | 64 (49) |
| Mine | Wizard | 22 | 44 (22) | 44 | 0 | 66 | 14% | 2.3 | 95 (5) | 42 (8) | 55 (3) | 55 (7) | 69 (9) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 100 | 0% | 4.5 | 0 (1) | 0 (1) | - | 0 (1) | 0 (1) |
| Opponent | Chaff | 89 | 44 (89) | 28 | 16 | 47 | 38% | 2.7 | 54 (35) | 20 (20) | 50 (34) | 57 (63) | 14 (26) |
| Opponent | Character | 94 | 87 (94) | 87 | 0 | 32 | 20% | 2.3 | 106 (47) | 81 (35) | 13 (6) | 92 (62) | 88 (26) |
| Opponent | Clean-up | 10 | 38 (10) | 4 | 34 | 62 | 20% | 3.1 | 18 (6) | 93 (3) | 0 (1) | 15 (7) | 108 (3) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 50 | 50% | 3.0 | - | 0 (2) | - | 0 (1) | 0 (1) |
| Opponent | Fast Hammer | 45 | 42 (45) | 35 | 7 | 39 | 36% | 2.9 | 37 (28) | 75 (8) | 20 (9) | 48 (28) | 31 (17) |
| Opponent | Fragile | 5 | 0 (5) | 0 | 0 | 46 | 60% | 1.5 | - | 0 (4) | 0 (1) | 0 (4) | 0 (1) |
| Opponent | Hammer | 69 | 40 (69) | 30 | 10 | 50 | 20% | 2.7 | 21 (19) | 46 (37) | 54 (13) | 35 (40) | 48 (29) |
| Opponent | Holder | 33 | 88 (33) | 23 | 65 | 8 | 42% | 2.9 | 26 (5) | 105 (23) | 46 (5) | 107 (19) | 55 (14) |
| Opponent | Shooter | 35 | 96 (35) | 24 | 72 | 20 | 0% | 1.8 | 56 (11) | 116 (17) | 101 (7) | 117 (23) | 63 (12) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |
| Opponent | War machine | 24 | 72 (24) | 72 | 0 | 8 | 4% | 2.0 | 65 (6) | 75 (15) | 68 (3) | 0 (2) | 78 (22) |
| Opponent | Wizard | 29 | 13 (29) | 13 | 0 | 49 | 3% | 1.6 | 18 (10) | 11 (10) | 20 (5) | 23 (13) | 0 (12) |

### Charged fights: ef2-opp-f5fe7c8-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 106 | 357 | 1.8 | 1.1 | 204 | 0 | +204 | 4 of 7 | 7 of 7 | +72 | +226 |
| Mine | Chaos Dwarfs | 4 | 330 | 312 | 1.8 | 1.1 | 178 | 44 | +134 | 6 of 7 | 5 of 7 | +0 | +156 |
| Mine | Dwarfen Mountain Holds | 4 | 754 | 35 | 1.2 | 1.2 | 28 | 71 | -43 | 2 of 5 | 3 of 5 | -65 | -38 |
| Mine | Empire of Man | 5 | 265 | 8 | 1.4 | 1.0 | 6 | 92 | -86 | 4 of 7 | 4 of 7 | - | -86 |
| Mine | Grand Cathay | 4 | 272 | 624 | 4.8 | 1.1 | 131 | 0 | +131 | 5 of 19 | 13 of 19 | +351 | +119 |
| Mine | High Elf Realms | 4 | 97 | 284 | 3.8 | 1.1 | 76 | 40 | +35 | 4 of 15 | 13 of 15 | +216 | +8 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 170 | 2.0 | 1.0 | 85 | 0 | +85 | 1 of 2 | 2 of 2 | - | +85 |
| Mine | Lizardmen | 1 | 45 | 436 | 4.0 | 1.0 | 109 | 0 | +109 | 0 of 4 | 2 of 4 | - | +109 |
| Mine | Ogre Kingdoms | 1 | 186 | 0 | 3.0 | 1.3 | 0 | 140 | -140 | 1 of 3 | 1 of 3 | -419 | +0 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 535 | 5.0 | 1.0 | 107 | 22 | +85 | 1 of 5 | 4 of 5 | - | +85 |
| Mine | Skaven | 2 | 333 | 0 | 2.5 | 1.0 | 0 | 340 | -340 | 2 of 5 | 2 of 5 | - | -340 |
| Mine | Tomb Kings of Khemri | 1 | 838 | 376 | 7.0 | 1.0 | 54 | 0 | +54 | 1 of 7 | 5 of 7 | - | +54 |
| Mine | Vampire Counts | 3 | 42 | 155 | 2.7 | 1.2 | 58 | 44 | +14 | 1 of 8 | 5 of 8 | -23 | +19 |
| Mine | Warriors of Chaos | 1 | 0 | 844 | 2.0 | 1.0 | 422 | 0 | +422 | 1 of 2 | 2 of 2 | - | +422 |
| **Mine** | all armies | 36 | 262 | 259 | 2.7 | 1.1 | 97 | 47 | +50 | 33 of 96 | 68 of 96 | +44 | +51 |
| Opponent | Dwarfen Mountain Holds | 2 | 67 | 143 | 2.5 | 1.0 | 57 | 0 | +57 | 0 of 5 | 4 of 5 | - | +57 |
| Opponent | Empire of Man | 2 | 758 | 70 | 2.0 | 1.0 | 35 | 138 | -103 | 1 of 4 | 1 of 4 | - | -103 |
| Opponent | Grand Cathay | 2 | 294 | 760 | 3.5 | 1.4 | 217 | 0 | +217 | 5 of 7 | 5 of 7 | +457 | +121 |
| Opponent | Kingdom of Bretonnia | 1 | 0 | 60 | 1.0 | 1.0 | 60 | 0 | +60 | 0 of 1 | 0 of 1 | - | +60 |
| Opponent | Ogre Kingdoms | 3 | 42 | 429 | 5.0 | 1.3 | 86 | 94 | -8 | 6 of 15 | 7 of 15 | -30 | -2 |
| Opponent | Skaven | 1 | 281 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 242 | 893 | 3.0 | 1.5 | 298 | 74 | +224 | 8 of 12 | 6 of 12 | +255 | +202 |
| Opponent | Vampire Counts | 6 | 0 | 667 | 4.2 | 1.1 | 160 | 82 | +79 | 14 of 25 | 10 of 25 | -246 | +107 |
| Opponent | Warriors of Chaos | 8 | 47 | 774 | 3.8 | 1.3 | 206 | 1 | +205 | 17 of 30 | 21 of 30 | +262 | +191 |
| Opponent | Wood Elf Realms | 7 | 155 | 841 | 5.3 | 1.1 | 159 | 6 | +154 | 16 of 37 | 24 of 37 | +365 | +135 |
| **Opponent** | all armies | 36 | 141 | 637 | 3.8 | 1.2 | 167 | 37 | +130 | 68 of 137 | 79 of 137 | +204 | +117 |

### Effective charges: ef2-opp-f5fe7c8-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 7 | 0 | 0 | 0 | 0 | 0 | 7 (net +204) | 0 | 0% (0 of 7) |
| Mine | Chaos Dwarfs | 7 | 1 (net +217) | 0 | 1 (net +254) | 2 (net +135) | 0 | 3 (net +65) | 0 | 14% (1 of 7) |
| Mine | Dwarfen Mountain Holds | 5 | 1 (net -65) | 0 | 0 | 1 (net +0) | 0 | 2 (net +70) | 1 | 0% (0 of 4) |
| Mine | Empire of Man | 7 | 0 | 0 | 2 (net -132) | 2 (net -190) | 1 (net +40) | 2 (net +0) | 0 | 29% (2 of 7) |
| Mine | Grand Cathay | 19 | 0 | 0 | 3 (net +368) | 6 (net +99) | 2 (net +30) | 8 (net +93) | 0 | 16% (3 of 19) |
| Mine | High Elf Realms | 15 | 1 (net -60) | 0 | 0 | 6 (net +54) | 2 (net +65) | 5 (net +28) | 1 | 0% (0 of 14) |
| Mine | Kingdom of Bretonnia | 2 | 0 | 0 | 0 | 1 (net +0) | 0 | 1 (net +170) | 0 | 0% (0 of 2) |
| Mine | Lizardmen | 4 | 1 (net +190) | 0 | 0 | 1 (net +0) | 1 (net +60) | 1 (net +186) | 0 | 0% (0 of 4) |
| Mine | Ogre Kingdoms | 3 | 0 | 1 (net +0) | 0 | 0 | 0 | 1 (net -419) | 1 | 0% (0 of 2) |
| Mine | Orc & Goblin Tribes | 5 | 1 (net +250) | 0 | 0 | 0 | 1 (net +45) | 0 | 3 | 0% (0 of 2) |
| Mine | Skaven | 5 | 2 (net -731) | 0 | 0 | 1 (net +0) | 1 (net +0) | 0 | 1 | 0% (0 of 4) |
| Mine | Tomb Kings of Khemri | 7 | 0 | 0 | 1 (net +0) | 0 | 1 (net +0) | 1 (net +126) | 4 | 33% (1 of 3) |
| Mine | Vampire Counts | 8 | 0 | 0 | 0 | 0 | 2 (net +62) | 5 (net -25) | 1 | 0% (0 of 7) |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +422) | 0 | 0% (0 of 2) |
| Opponent | Dwarfen Mountain Holds | 5 | 0 | 0 | 1 (net +0) | 2 (net +75) | 0 | 1 (net +55) | 1 | 25% (1 of 4) |
| Opponent | Empire of Man | 4 | 2 (net -276) | 0 | 1 (net +140) | 1 (net +0) | 0 | 0 | 0 | 25% (1 of 4) |
| Opponent | Grand Cathay | 7 | 2 (net +92) | 0 | 1 (net +138) | 2 (net +446) | 0 | 2 (net +152) | 0 | 14% (1 of 7) |
| Opponent | Ogre Kingdoms | 15 | 2 (net +82) | 1 (net -90) | 2 (net +150) | 3 (net -85) | 0 | 3 (net +123) | 4 | 18% (2 of 11) |
| Opponent | Skaven | 1 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 100% (1 of 1) |
| Opponent | Tomb Kings of Khemri | 12 | 2 (net -256) | 0 | 2 (net +133) | 2 (net +166) | 1 (net +347) | 5 (net +451) | 0 | 17% (2 of 12) |
| Opponent | Vampire Counts | 25 | 7 (net +32) | 0 | 5 (net +203) | 1 (net +255) | 2 (net +104) | 7 (net +12) | 3 | 23% (5 of 22) |
| Opponent | Warriors of Chaos | 30 | 4 (net +76) | 0 | 5 (net +35) | 5 (net +243) | 0 | 15 (net +295) | 1 | 17% (5 of 29) |
| Opponent | Wood Elf Realms | 37 | 1 (net +663) | 1 (net +0) | 8 (net +145) | 9 (net +166) | 3 (net +174) | 11 (net +141) | 4 | 24% (8 of 33) |

### Charged fights, damage counted: ef2-opp-f5fe7c8-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 7 | 171 | 265 | -133 | 114 | 264 | -151 | -88.1 |
| Mine | 50-54% | 1 | 34 | 190 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 7 | 371 | 285 | +156 | 204 | 94 | +110 | +29.7 |
| Mine | 76-89% | 20 | 258 | 222 | +40 | 96 | 47 | +49 | +19.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 38 | 318 | 185 | +90 | 153 | 44 | +108 | +34.1 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 378 | 69 | +42 | 64 | 9 | +55 | +14.6 |
| Mine | No odds | 12 | 244 | 153 | -3 | 68 | 57 | +11 | +4.5 |
| Mine | All fights | 96 | 293 | 189 | +50 | 120 | 62 | +58 | +19.7 |
| Opponent | Long shot (under 50%) | 20 | 217 | 294 | +24 | 178 | 145 | +33 | +15.0 |
| Opponent | 50-54% | 2 | 172 | 270 | -45 | 85 | 155 | -70 | -40.7 |
| Opponent | Effective (55-75%) | 26 | 261 | 230 | +123 | 154 | 28 | +127 | +48.5 |
| Opponent | 76-89% | 25 | 215 | 192 | +163 | 189 | 43 | +146 | +67.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 44 | 325 | 215 | +206 | 236 | 41 | +194 | +59.7 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 568 | 121 | +179 | 179 | 39 | +141 | +24.8 |
| Opponent | No odds | 14 | 188 | 208 | +3 | 93 | 80 | +13 | +7.1 |
| Opponent | All fights | 137 | 272 | 221 | +130 | 184 | 60 | +124 | +45.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ef2-opp-f5fe7c8-p2 | move | 488 | 118 (24%) | 92 (19%) | 54 (11%) | 316 (65%) |
| ef2-opp-f5fe7c8-p2 | objective | 335 | 43 (13%) | 38 (11%) | 44 (13%) | 248 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

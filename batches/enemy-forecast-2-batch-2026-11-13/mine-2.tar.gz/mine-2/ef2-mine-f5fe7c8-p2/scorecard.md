# Doctrine scorecard: ef2-mine-f5fe7c8-p2

### Scorecard: ef2-mine-f5fe7c8-p2

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0106 | 4 | 1 | Mine | no | 4 | 5 | 1 | 1 | 0 | 0 | 0 | 442 |
| L0106 | 4 | 1 | Opponent | no | 0 | 6 | 0 | 1 | 0 | 0 | 0 | 1109 |
| L0122 | 2 | 1 | Mine | - | - | - | 0 | 1 | 1 | 0 | 0 | 317 |
| L0122 | 2 | 1 | Opponent | - | - | 1 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Mine | - | - | - | 0 | 7 | 1 | 0 | 0 | 0 |
| L0206 | 2 | 1 | Opponent | - | - | 1 | 0 | 1 | 0 | 0 | 0 | 615 |
| L0222 | 6 | 1 | Mine | no | 2 | 3 | 2 | 5 | 0 | 0 | 0 | 0 |
| L0222 | 6 | 1 | Opponent | no | 1 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L0307 | 1 | 1 | Mine | yes | 0 | 4 | 3 | 0 | 0 | 0 | 0 | 760 |
| L0307 | 1 | 1 | Opponent | yes | 1 | 4 | 1 | 2 | 0 | 0 | 0 | 420 |
| L0323 | 5 | 1 | Mine | no | - | 4 | 1 | 2 | 0 | 0 | 0 | 590 |
| L0323 | 5 | 1 | Opponent | yes | - | 2 | 2 | 3 | 1 | 0 | 0 | 140 |
| L0409 | 1 | 1 | Mine | no | 3 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0409 | 1 | 1 | Opponent | no | 12 | 4 | 1 | 0 | 0 | 0 | 0 | 1122 |
| L0425 | 5 | 1 | Mine | yes | - | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L0425 | 5 | 1 | Opponent | no | - | - | 1 | 3 | 2 | 0 | 0 | 348 |
| L0512 | 2 | 1 | Mine | - | - | 4 | 2 | 1 | 0 | 0 | 0 | 686 |
| L0512 | 2 | 1 | Opponent | - | - | 2 | 1 | 1 | 1 | 0 | 0 | 330 |
| L0528 | 6 | 1 | Mine | no | 0 | 5 | 2 | 0 | 0 | 0 | 0 | 970 |
| L0528 | 6 | 1 | Opponent | no | 0 | 2 | 1 | 2 | 1 | 0 | 0 | 351 |
| L0616 | 4 | 1 | Mine | no | 0 | 2 | 1 | 0 | 0 | 0 | 0 | 798 |
| L0616 | 4 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 200 |
| L0632 | 2 | 1 | Mine | - | - | 3 | 2 | 0 | 0 | 0 | 0 | 615 |
| L0632 | 2 | 1 | Opponent | - | - | 2 | 6 | 3 | 0 | 0 | 0 | 0 |
| L0721 | 1 | 1 | Mine | yes | 4 | 3 | 3 | 0 | 0 | 0 | 0 | 420 |
| L0721 | 1 | 1 | Opponent | no | 0 | 6 | 2 | 4 | 1 | 0 | 0 | 290 |
| L0810 | 6 | 1 | Mine | no | 9 | 3 | 1 | 2 | 0 | 0 | 0 | 605 |
| L0810 | 6 | 1 | Opponent | no | 19 | 2 | 1 | 0 | 1 | 0 | 0 | 330 |
| L0827 | 5 | 1 | Mine | no | - | - | 1 | 1 | 0 | 0 | 0 | 435 |
| L0827 | 5 | 1 | Opponent | yes | - | 1 | 4 | 6 | 0 | 0 | 0 | 60 |
| L0918 | 6 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 420 |
| L0918 | 6 | 1 | Opponent | no | 2 | 4 | 2 | 2 | 1 | 0 | 0 | 234 |
| L0934 | 4 | 1 | Mine | no | 2 | 1 | 1 | 0 | 0 | 0 | 0 | 632 |
| L0934 | 4 | 1 | Opponent | no | 0 | 2 | 7 | 4 | 0 | 0 | 0 | 216 |
| L1026 | 6 | 1 | Mine | no | 6 | 2 | 6 | 0 | 0 | 0 | 0 | 330 |
| L1026 | 6 | 1 | Opponent | no | 5 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1118 | 2 | 1 | Mine | - | - | - | 0 | 1 | 0 | 0 | 0 | 330 |
| L1118 | 2 | 1 | Opponent | - | - | 3 | 2 | 1 | 0 | 0 | 0 | 251 |
| L1135 | 1 | 1 | Mine | yes | 1 | 3 | 2 | 0 | 1 | 0 | 0 | 330 |
| L1135 | 1 | 1 | Opponent | yes | 0 | 2 | 4 | 2 | 1 | 0 | 0 | 158 |
| L1228 | 4 | 1 | Mine | no | 2 | 3 | 1 | 1 | 0 | 0 | 0 | 524 |
| L1228 | 4 | 1 | Opponent | no | 0 | 6 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1323 | 3 | 1 | Mine | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 140 |
| L1323 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 132 |
| L1418 | 2 | 1 | Mine | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 177 |
| L1418 | 2 | 1 | Opponent | - | - | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| L1435 | 1 | 1 | Mine | no | 0 | 3 | 0 | 1 | 0 | 0 | 0 | 123 |
| L1435 | 1 | 1 | Opponent | no | 1 | 1 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Mine | no | 8 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1531 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L1629 | 3 | 1 | Mine | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 200 |
| L1629 | 3 | 1 | Opponent | no | 0 | 2 | 6 | 2 | 0 | 0 | 0 | 170 |
| L1727 | 5 | 1 | Mine | yes | - | 3 | 4 | 0 | 0 | 0 | 0 | 98 |
| L1727 | 5 | 1 | Opponent | yes | - | 3 | 5 | 4 | 0 | 0 | 0 | 60 |
| L1827 | 3 | 1 | Mine | no | 0 | 2 | 4 | 0 | 0 | 0 | 0 | 297 |
| L1827 | 3 | 1 | Opponent | no | 6 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L1927 | 1 | 1 | Mine | no | 1 | 1 | 3 | 1 | 0 | 0 | 0 | 226 |
| L1927 | 1 | 1 | Opponent | no | 1 | 2 | 4 | 3 | 0 | 0 | 0 | 60 |
| L2029 | 1 | 1 | Mine | no | 0 | - | 0 | 2 | 1 | 0 | 0 | 210 |
| L2029 | 1 | 1 | Opponent | no | 6 | 2 | 4 | 1 | 0 | 0 | 0 | 207 |
| L2131 | 1 | 1 | Mine | yes | 2 | 2 | 0 | 3 | 1 | 0 | 0 | 787 |
| L2131 | 1 | 1 | Opponent | yes | 1 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Mine | no | 0 | 1 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2235 | 3 | 1 | Opponent | no | 0 | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Mine | no | - | - | 5 | 0 | 1 | 0 | 0 | 0 |
| L2429 | 5 | 1 | Opponent | yes | - | 4 | 4 | 5 | 0 | 0 | 0 | 170 |
| L2535 | 3 | 1 | Mine | no | 0 | 4 | 2 | 2 | 0 | 0 | 0 | 68 |
| L2535 | 3 | 1 | Opponent | no | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Mine | yes | - | 2 | 2 | 3 | 1 | 0 | 0 | 0 |
| L2735 | 5 | 1 | Opponent | yes | - | 2 | 1 | 2 | 0 | 0 | 0 | 140 |
| L3033 | 3 | 1 | Mine | yes | 6 | 3 | 6 | 1 | 0 | 0 | 0 | 0 |
| L3033 | 3 | 1 | Opponent | no | 0 | 1 | 7 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 27% | 2.1 | 2.7 | 2.2 | 1.2 | 0.2 | 0.0 | 0.0 | 320.3 |
| **Average** | | | Opponent | 27% | 2.3 | 2.5 | 2.7 | 1.9 | 0.3 | 0.0 | 0.0 | 197.6 |

### KPIs: ef2-mine-f5fe7c8-p2

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Winner chose to follow up after the loser gave ground |  | 97% (77 of 79); on the table 99% | 97% (60 of 62); on the table 97% | 97% (137 of 141); on the table 98% |
| Winner chose to pursue after the loser fell back in good order |  | 92% (11 of 12); on the table 92% | 88% (14 of 16); on the table 94% | 89% (25 of 28); on the table 93% |
| Winner chose to pursue after the loser fled |  | 85% (17 of 20); on the table 90% | 69% (27 of 39); on the table 85% | 75% (44 of 59); on the table 86% |
| Winner chose to follow up or pursue (all three) |  | 95% (105 of 111); on the table 96% | 86% (101 of 117); on the table 92% | 90% (206 of 228); on the table 94% |
| Magic missiles tried each own turn | 50%+ | 27% (93 of 342) | 31% (49 of 156) | 29% (142 of 498) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 42% (81 of 192) | 44% (49 of 111) | 43% (130 of 303) |
| Points that never fought | lower | 31% (22478 of 71583) | 37% (26362 of 71989) | 34% (48840 of 143572) |
|   infantry points that never fought | lower | 32% (5294 of 16324) | 61% (8600 of 14029) | 46% (13894 of 30353) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% (172 of 284) | 53% (158 of 297) | 57% (330 of 581) |
| Bound items with a magic missile used (at least once a game) |  | 85% (17 of 20); 1.4 uses a game | 83% (15 of 18); 1.1 uses a game | 84% (32 of 38); 1.3 uses a game |
| Bound items with another spell used |  | 56% (10 of 18); 0.8 uses a game | 50% (1 of 2); 0.1 uses a game | 55% (11 of 20); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 65% (13 of 20); 0.4 uses a game | 29% (2 of 7); 0.1 uses a game | 56% (15 of 27); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 56% (33741 of 60231) | 46% (29380 of 63281) | 51% (63121 of 123512) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.8 (27%) | 0.6 (21%) | 2.4 (25%) |
| MARCHED: its unit marched | 1.1 (16%) | 0.6 (21%) | 1.8 (18%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.1 (3%) | 0.1 (1%) |
| IN COMBAT: engaged in combat | 1.3 (19%) | 0.4 (15%) | 1.8 (18%) |
| REAR RANK: in a rear rank | 0.0 (0%) | 0.1 (5%) | 0.1 (1%) |
| FLEEING: fleeing | 0.3 (4%) | 0.1 (2%) | 0.4 (4%) |
| GONE: slain | 1.5 (21%) | 0.7 (22%) | 2.1 (22%) |
| OFF THE TABLE: off the table or not arrived | 0.7 (10%) | 0.1 (3%) | 0.8 (8%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (1%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.1 (1%) | 0.2 (7%) | 0.2 (3%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.5 | 1.0 | 1.1 | 3.9 | 0.4 | 1.9 |
| not cast | 4.3 | 3.9 | 3.9 | 9.9 | 1.9 | 19.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.1 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 1.2 (31%) | 0.1 (4%) | 2.4 (25%) | 0.5 (26%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.8 (18%) | 0.4 (20%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (1%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (1%) | 0.2 (6%) | 0.4 (10%) | 1.8 (18%) | 0.2 (11%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.3 (8%) | 0.4 (11%) | 0.3 (9%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.1 (3%) | 0.1 (1%) | 0.4 (4%) | 0.1 (4%) | 0.7 (4%) |
| GONE: slain | 1.3 (30%) | 1.2 (31%) | 0.9 (24%) | 2.1 (22%) | 0.4 (21%) | 4.7 (24%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (9%) | 0.4 (9%) | 0.7 (18%) | 0.8 (8%) | 0.1 (6%) | 1.3 (7%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.2 (5%) | 0.0 (0%) | 0.0 (0%) | 0.2 (10%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.2 (3%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (47%) | 0.1 (3%) | 1.3 (34%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 11.6 (59%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 0.6 a game | 0.6 a game | 0.6 a game |
| stood (cast and not dispelled) | 47% (9 of 19) | 55% (12 of 22) | 51% (21 of 41) |
| the unit moved after it | 56% (5 of 9) | 67% (8 of 12) | 62% (13 of 21) |
| it charged on its next turn | 11% (1 of 9) | 8% (1 of 12) | 10% (2 of 21) |
| the enemy charged it first | 11% (1 of 9) | 8% (1 of 12) | 10% (2 of 21) |
| it fought by the end of its next turn | 22% (2 of 9) | 8% (1 of 12) | 14% (3 of 21) |
| it moved out of a charge the enemy had planned (not charged first) | 22% (2 of 9) | 17% (2 of 12) | 19% (4 of 21) |
| none of these (no charge, no fight, no charge escaped) | 67% (6 of 9) | 67% (8 of 12) | 67% (14 of 21) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (566 of 880) | 50% (404 of 809) | 57% (970 of 1689) |
|   cavalry | 60% (50 of 83) | 52% (85 of 163) | 55% (135 of 246) |
|   character | 57% (50 of 88) | 23% (26 of 114) | 38% (76 of 202) |
|   chariot | 44% (47 of 107) | 62% (28 of 45) | 49% (75 of 152) |
|   infantry | 53% (132 of 251) | 49% (153 of 314) | 50% (285 of 565) |
|   monster | 53% (24 of 45) | 52% (23 of 44) | 53% (47 of 89) |
|   war machine | 86% (263 of 306) | 69% (89 of 129) | 81% (352 of 435) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.5 (28%) | 2.9 (26%) | 5.4 (27%) |
| CHARGED: it charged | 1.2 (14%) | 2.0 (18%) | 3.3 (16%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.2 (1%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 1.1 (12%) | 0.8 (7%) | 1.8 (9%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (0%) |
| NO TARGET IN RANGE | 1.1 (12%) | 2.1 (19%) | 3.2 (16%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (5%) | 0.7 (6%) | 1.1 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.6 (18%) | 1.8 (16%) | 3.4 (17%) |
| SHELTERED: the target was sheltered | 0.4 (4%) | 0.1 (1%) | 0.5 (2%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.3 (4%) | 0.6 (5%) | 0.9 (5%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.6 | 1.3 | 82% | 5.2 pts | 29 pts |
| character | 2.2 | 1.0 | 69% | 15.4 pts | 34 pts |
| chariot | 2.1 | 1.4 | 64% | 14.0 pts | 29 pts |
| infantry | 10.6 | 4.3 | 71% | 9.4 pts | 100 pts |
| monster | 1.5 | 0.6 | 70% | 8.5 pts | 13 pts |
| war machine | 9.8 | 8.5 | 62% | 26.8 pts | 262 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.1 | 6.2 | 5.2 |
| Charges that made contact a game | 3.2 | 4.4 | 3.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.72 declared, 0.68 contact (25 units) | 0.93 declared, 0.71 contact (14 units) | 0.79 declared, 0.69 contact (39 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.00 declared, 0.83 contact (6 units) | 1.09 declared, 0.91 contact (11 units) | 1.06 declared, 0.88 contact (17 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.50 declared, 0.38 contact (248 units) | 0.69 declared, 0.48 contact (288 units) | 0.60 declared, 0.43 contact (536 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 67% (49 of 73) | 67% (12 of 18) | 50% (6 of 12) | 65% (67 of 103) |
| Character in a unit | 75% (18 of 24) | 58% (7 of 12) | 0% (0 of 2) | 66% (25 of 38) |
| Character on its own | 75% (36 of 48) | 55% (23 of 42) | 25% (16 of 64) | 49% (75 of 154) |
| Chariot | 71% (12 of 17) | 54% (7 of 13) | - | 63% (19 of 30) |
| Infantry | 50% (47 of 94) | 50% (17 of 34) | 33% (1 of 3) | 50% (65 of 131) |
| Monster | 52% (15 of 29) | 89% (8 of 9) | - | 61% (23 of 38) |
| Monstrous | 43% (6 of 14) | 64% (9 of 14) | - | 54% (15 of 28) |
| War Machines | 68% (39 of 57) | 100% (2 of 2) | - | 69% (41 of 59) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (9 of 9); on the table 100% | 26% (27 of 102) | 39% | 50% (11 of 22) | 67% (4 of 6); 2.5 uses a game | 100% (2 of 2); 1.0 uses a game | 100% (6 of 6); 1.5 uses a game |
| Chaos Dwarfs | 4 | 100% (16 of 16); on the table 100% | 39% (14 of 36) | 48% | 62% (20 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 6 | 78% (7 of 9); on the table 78% | - | 52% | 67% (36 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 7 | 100% (16 of 16); on the table 100% | 25% (12 of 48) | 35% | 55% (42 of 76) | 0.0 uses a game | 100% (2 of 2); 0.7 uses a game | 25% (1 of 4); 0.1 uses a game |
| Grand Cathay | 6 | 82% (9 of 11); on the table 91% | 29% (40 of 138) | 39% | 57% (31 of 54) | 93% (13 of 14); 8.2 uses a game | 50% (1 of 2); 0.2 uses a game | 17% (1 of 6); 0.2 uses a game |
| High Elf Realms | 4 | 100% (21 of 21); on the table 100% | 11% (2 of 18) | 29% | 45% (15 of 33) | 100% (3 of 3); 2.0 uses a game | 43% (6 of 14); 5.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 2 | 100% (4 of 4); on the table 100% | - | 53% | 50% (6 of 12) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game |
| Lizardmen | 1 | 100% (3 of 3); on the table 100% | - | 50% | 71% (5 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 4 | 87% (20 of 23); on the table 91% | 0% (0 of 18) | 34% | 71% (20 of 28) | 100% (4 of 4); 2.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 1 | 100% (2 of 2); on the table 100% | 33% (4 of 12) | 3% | 50% (4 of 8) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Skaven | 3 | 60% (3 of 5); on the table 100% | 11% (2 of 18) | 16% | 80% (20 of 25) | 100% (2 of 2); 1.3 uses a game | 0.0 uses a game | 33% (1 of 3); 0.3 uses a game |
| Tomb Kings of Khemri | 5 | 100% (14 of 14); on the table 100% | - | 32% | 20% (5 of 25) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 9 | 79% (31 of 39); on the table 90% | 36% (24 of 66) | 29% | 72% (39 of 54) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 94% (29 of 31); on the table 94% | 56% (10 of 18) | 26% | 41% (30 of 73) | 100% (2 of 2); 0.2 uses a game | 0.0 uses a game | 100% (1 of 1); 0.1 uses a game |
| Wood Elf Realms | 7 | 88% (22 of 25); on the table 92% | 29% (7 of 24) | 28% | 59% (46 of 78) | 57% (4 of 7); 1.3 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ef2-mine-f5fe7c8-p2, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 46% (42) | 56% (42) | 50% (84) |
| ...free all their last turn and able to turn (per game) | 0.75 | 0.81 | 1.56 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.08 | 0.25 |
| ...with the charger already in that arc before they moved (per game) | 0.36 | 0.61 | 0.97 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.31 | 1.14 | 2.44 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.56 | 0.81 | 1.36 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 8.00 | 7.22 | 15.22 |

### Quality by phase: ef2-mine-f5fe7c8-p2

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 2.8 | 3.3 |
| Strategy | Charge objectives carried out (made contact) | 55% (66 of 121) | 46% (88 of 191) |
| Strategy | Shoot objectives carried out (shot that target) | 46% (148 of 320) | 54% (95 of 176) |
| Strategy | Close-in objectives charged next turn | 13% (17 of 126) | 14% (28 of 206) |
| Strategy | Support requests answered (helper made contact too) | 32% (6 of 19) | 71% (15 of 21) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (3 of 3) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 43% (3 of 7) | 71% (5 of 7) |
| Strategy | Joined characters whose unit fought | 67% (26 of 39) | 31% (8 of 26) |
| Strategy | Lone characters that fought | 77% (82 of 106) | 82% (80 of 97) |
| Movement | Charges halted short of contact | 0.1 | 0.4 |
| Movement | Idle units | 1.2 | 1.9 |
| Movement | Points that never moved of their own | 320.3 | 197.6 |
| Movement | Fights charged into per game | 2.9 | 3.5 |
| Movement | Charges with odds: long shots (under 50%) | 11 of 90, net +99 | 15 of 109, net +195 |
| Movement | Charges with odds: sweet spot (55-75%) | 16 of 90, net +119 | 21 of 109, net +81 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 6 of 90, net +83 | 5 of 109, net +152 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 37 of 90, net +110 | 42 of 109, net +183 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.0 | 9.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 44% (144 of 325) | 49% (169 of 343) |
| Shooting | Points destroyed by shooting units | 62.7 | 82.9 |
| Shooting | War machine shots | 7.3 | 2.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 54% (143 of 263) | 44% (39 of 89) |
| Shooting | Points destroyed by war machines | 108.3 | 53.6 |
| Magic | Magic missiles cast | 1.6 | 0.9 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 46% (26 of 57) | 47% (15 of 32) |
| Magic | Wounds caused by magic missiles | 2.1 | 1.4 |
| Magic | Wounds caused by other spells | 1.4 | 1.3 |
| Magic | Points destroyed by magic (all spells) | 57.5 | 30.8 |
| Magic | Augments / hexes / assailments / vortexes cast | 0.8 / 0.3 / 0.6 / 0.0 | 1.9 / 0.2 / 0.7 / 0.1 |
| Combat | Points destroyed in combat | 344.0 | 484.1 |
| Combat | Points run down | 119.7 | 118.7 |
| Combat | Net points per charged fight, damage counted | +77 | +117 |
| Combat | Net per 100 charger points, damage counted | +28.3 | +40.6 |
| Combat | First round won (charged fights) | 63% | 65% |
| Combat | Net points per charged fight | +86 | +129 |
| Combat | Net points per supported fight / lone fight | +257 / +68 | +212 / +110 |
| Combat | Charged fights on a top-3 enemy unit | 32 of 105 | 57 of 127 |
| Game | Points lost | 914.4 | 750.9 |
| Game | VP from objectives | 536.9 | 643.1 |
| Game | Lone holders (player turns) | 2.1 | 2.3 |

- Mine won / drew / lost: 16 / 3 / 17 of 36 ended games (of 36); mean margin (Mine - Opponent) -300 VP
- The side that went first won 14 of 33 games with a winner
- Points traded per game (both sides' losses): 1665
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ef2-mine-f5fe7c8-p2

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.1 | +2.5 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.8 | +0.0 | 0.0 | 13.8 | 0.4 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 1.1 | +5.7 | 0.0 | 47.2 | 0.9 | +11.1 | 0.0 | 0.0 |
| BEST PREY | 4.4 | +198.7 | 146.4 | 164.9 | 4.9 | +330.8 | 310.9 | 126.6 |
| BEST PRIZE | - | - | - | - | 0.1 | -0.1 | 13.5 | 13.7 |
| BLOCKED CHARGE SKIPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 24.3 | 0.0 |
| BLOCKED WHEEL | 0.3 | -2.8 | 0.0 | 7.1 | 0.4 | +13.3 | 0.0 | 3.1 |
| BOMBING RUN | 0.0 | +1.6 | 0.0 | 0.0 | 0.0 | +0.4 | 4.7 | 0.0 |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 3.5 | - | - | - | - |
| CANNON PLAN MISSED | 1.0 | +0.0 | 139.6 | 3.5 | 0.2 | +0.0 | 18.5 | 8.1 |
| CANNON PLANNED TARGET | 5.7 | +225.4 | 543.7 | 83.2 | 1.7 | +71.8 | 198.2 | 18.3 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 2.4 | 0.5 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | +0.0 | 5.4 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.0 | -2.3 | 0.0 | 0.0 | 0.1 | -0.1 | 10.1 | 5.7 |
| CAST JOB | 0.7 | +8.0 | 30.4 | 26.3 | 0.4 | +11.5 | 29.0 | 10.6 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +46.8 | 39.9 | 32.3 | 0.2 | +16.3 | 27.6 | 4.4 |
| CASTS AFTER FRIENDS | 0.4 | +0.0 | 0.0 | 30.0 | 0.3 | +0.0 | 0.0 | 52.8 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH ODDS | 0.0 | +0.3 | 0.0 | 11.1 | - | - | - | - |
| CHAFF PASSED | 0.4 | -1.9 | 9.2 | 28.5 | 0.5 | -0.9 | 15.1 | 9.7 |
| CHARGE NOW WEIGHED | 0.4 | -40.0 | 27.5 | 33.1 | 0.9 | -82.6 | 64.1 | 39.6 |
| CHARIOT NO STATIC JOB | 0.8 | +0.0 | 7.1 | 30.0 | 0.4 | +0.0 | 5.6 | 0.0 |
| CHEAP HELPER | 0.1 | +0.0 | 9.3 | 2.1 | 0.2 | +0.0 | 19.9 | 0.0 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 1.8 | 0.0 |
| CONVEYANCE SEARCH | 0.4 | +69.5 | 8.9 | 15.1 | 0.5 | +64.8 | 20.2 | 53.6 |
| COUNTER-CHARGE COVER | 8.7 | +320.0 | 0.0 | 243.4 | 7.5 | +700.7 | 0.0 | 182.4 |
| EDGE GIVE GROUND | 0.1 | +0.1 | 5.1 | 0.0 | 0.3 | +7.8 | 31.7 | 0.0 |
| ELIXIR WORTH | 0.0 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| ENEMY FORECAST | 10.8 | +313.2 | 73.0 | 366.1 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 2.4 | - | - | - | - |
| FACES THE THREAT | 1.3 | +71.5 | 0.0 | 68.8 | 1.1 | +95.1 | 0.0 | 56.4 |
| FALLBACK BY WORTH | 6.5 | +76.9 | 0.0 | 72.6 | 8.4 | +73.3 | 0.0 | 74.9 |
| FIGHT LIFT | 0.0 | +0.0 | 0.0 | 16.1 | 0.1 | +2.0 | 0.0 | 0.0 |
| FIRE AND FLEE | 0.1 | +1.4 | 0.0 | 1.7 | 0.1 | +1.6 | 0.0 | 7.4 |
| FLANK NOT WEIGHED | 0.7 | +0.0 | 0.0 | 11.3 | 0.4 | +0.0 | 0.0 | 29.6 |
| FOCUS FIRE | 0.0 | +2.7 | 0.0 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 1.3 | +188.3 | 0.0 | 49.3 | 1.3 | +195.4 | 0.0 | 40.2 |
| FORECAST RESULT | 43.4 | +2585.5 | 916.9 | 1077.9 | 40.0 | +1877.1 | 1045.8 | 1297.4 |
| FRIENDS SHOTS CHECKED | 0.2 | +6.8 | 0.0 | 21.9 | 0.3 | +12.8 | 0.0 | 0.0 |
| GIVES UP | 1.0 | -33.5 | 101.1 | 71.7 | 1.6 | -51.1 | 251.4 | 76.3 |
| GIVES UP ITS SCREEN | 0.4 | -4.3 | 24.1 | 8.0 | 1.2 | -38.1 | 100.5 | 9.1 |
| GROUND FLIERS | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | - | - | - | - | 0.1 | +0.0 | 2.4 | 0.0 |
| HELPER UNSEEN | 0.1 | +0.0 | 15.1 | 9.6 | 0.3 | +0.0 | 55.8 | 6.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +0.8 | 0.0 | 1.4 | 0.3 | +6.8 | 25.7 | 3.0 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.4 | +24.7 | 0.0 | 10.2 | 0.5 | +24.2 | 0.0 | 22.0 |
| HUNT KEPT | - | - | - | - | 0.2 | +5.1 | 20.3 | 0.0 |
| HUNT RESULT | 0.1 | +9.8 | 9.8 | 0.0 | 0.3 | +49.8 | 16.1 | 0.9 |
| HUNT THE GUNS | 0.1 | +26.0 | 9.8 | 1.4 | 0.3 | +131.0 | 18.1 | 3.0 |
| JOINT CHARGE PLAN | 0.1 | +5.8 | 9.6 | 0.0 | 0.2 | +13.0 | 0.0 | 20.7 |
| KEEP FALLS | 0.1 | +1.2 | 0.0 | 6.1 | - | - | - | - |
| KEEPS ITS PREY | 0.2 | +1.0 | 0.0 | 8.6 | 0.1 | +1.1 | 1.5 | 4.7 |
| KEEPS ITS TARGET | 1.4 | +42.5 | 108.0 | 53.1 | 2.7 | +80.8 | 260.7 | 104.0 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| KILLS COUNT | 1.6 | +80.2 | 135.4 | 31.6 | 2.4 | +107.5 | 302.0 | 61.1 |
| KILLS COUNT NEXT TURN | 7.3 | +277.1 | 254.9 | 310.4 | 11.6 | +546.1 | 720.1 | 305.8 |
| LONE CHARACTER SAFE SPOT | 0.2 | +1.5 | 0.0 | 0.0 | 0.2 | +6.0 | 0.0 | 16.6 |
| LONE WIZARD HOLDS BACK | 1.0 | +0.0 | 29.0 | 54.4 | 0.9 | +0.0 | 53.8 | 25.7 |
| LONE WIZARD KEPT IN | 0.6 | +39.4 | 0.0 | 3.6 | 0.3 | +23.5 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.6 | +41.9 | 19.3 | 18.3 | 1.1 | +51.2 | 18.8 | 27.3 |
| MANOEUVRE | 0.2 | +4.9 | 0.0 | 0.0 | 0.2 | +2.0 | 0.0 | 4.4 |
| MARCH AT ESCAPER | - | - | - | - | 0.1 | +0.3 | 0.0 | 0.0 |
| MARCH CHECK | 0.4 | +2.3 | 0.0 | 20.5 | 0.5 | +35.4 | 0.0 | 19.9 |
| MARCH ODDS | 0.6 | +51.1 | 22.7 | 40.3 | 0.6 | +47.6 | 30.2 | 27.2 |
| MARCH OVER CASTS | 0.8 | +11.2 | 0.0 | 60.4 | 0.7 | +2.1 | 0.0 | 29.2 |
| MAX FOR POSITIONING | 4.6 | +92.1 | 0.0 | 184.8 | 5.4 | +235.1 | 0.0 | 156.6 |
| MISSILES IN THE MOVE | 3.2 | +78.3 | 0.0 | 144.9 | 2.4 | +59.3 | 0.0 | 113.9 |
| MISSILES NEXT TURN | 4.2 | +54.9 | 0.0 | 200.0 | 3.4 | +57.2 | 0.0 | 148.7 |
| MODEL FACING | 0.4 | +100.1 | 0.0 | 3.3 | 0.3 | +55.8 | 0.0 | 0.0 |
| MOVE AND CAST | 0.2 | +7.1 | 0.0 | 15.0 | 0.2 | +12.7 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.1 | +2.1 | 0.0 | 16.1 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.3 | -26.3 | 0.0 | 12.5 | 0.2 | -5.2 | 0.0 | 18.9 |
| MOVE SPELL SPOT | 0.1 | +0.0 | 0.0 | 11.1 | 0.1 | +0.0 | 0.0 | 22.3 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | - | - | - | - |
| NEEDED THERE | - | - | - | - | 0.1 | +10.3 | 8.3 | 0.0 |
| NOT NEEDED | 0.2 | -11.8 | 24.5 | 17.3 | 0.3 | -16.6 | 65.2 | 0.0 |
| NOT TURNED | 8.0 | +114.5 | 0.0 | 288.0 | 7.2 | +68.3 | 0.0 | 165.2 |
| NOT WORTH A CAST | 0.5 | -0.3 | 0.0 | 53.8 | 0.6 | -0.5 | 0.0 | 1.7 |
| OPENS A LANE | 0.1 | +1.3 | 14.1 | 6.5 | - | - | - | - |
| OPENS UP | 0.1 | +14.4 | 6.9 | 0.0 | 0.2 | +16.2 | 13.9 | 5.4 |
| OVERRUNS AWAY | 0.4 | +9.7 | 19.8 | 10.9 | 0.7 | +15.9 | 79.0 | 24.8 |
| PATHS CROSS | 2.1 | +117.9 | 0.0 | 66.1 | 2.9 | +153.1 | 0.0 | 44.1 |
| PERIAPT WORTH | - | - | - | - | 0.0 | +1.8 | 0.0 | 0.0 |
| PLAN LEADS | 1.5 | +149.7 | 14.8 | 19.3 | 1.0 | +69.7 | 33.5 | 0.0 |
| PLAN RESULT | 36.4 | +1316.3 | 1325.4 | 1282.4 | 41.4 | +1716.4 | 1965.2 | 1019.6 |
| PURSUES BIG PREY | 0.1 | -11.2 | 0.0 | 0.0 | 0.1 | -6.1 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.1 | +13.2 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +8.2 | 0.0 | 3.4 | 0.0 | +3.3 | 0.0 | 0.0 |
| REDIRECT COUNTER | 3.1 | +90.7 | 0.0 | 51.2 | 4.4 | +278.5 | 0.0 | 62.6 |
| REDIRECT WEIGHED | 0.2 | +5.1 | 6.0 | 8.6 | 0.4 | +16.6 | 26.6 | 19.1 |
| RESTRAINS TO SHOOT | 0.1 | +1.3 | 0.0 | 0.0 | 0.2 | +6.6 | 0.0 | 0.0 |
| RISK BY ARC | 2.1 | +100.4 | 204.8 | 97.1 | 3.0 | +60.0 | 346.6 | 108.3 |
| SAFE SURE CHARGE | - | - | - | - | 0.0 | -9.9 | 0.0 | 0.0 |
| SAFER THAN THE JOB | 0.6 | +26.6 | 0.0 | 6.6 | 0.8 | +64.7 | 0.0 | 7.0 |
| SCOUT SPOT | 0.3 | +0.6 | 0.0 | 3.1 | 0.5 | +2.1 | 0.0 | 0.0 |
| SCOUT WAITS | 0.3 | +0.0 | 0.0 | 3.1 | 0.6 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 1.4 | +66.2 | 0.0 | 20.3 | 1.9 | +97.4 | 0.0 | 30.8 |
| SECOND HUNTER | - | - | - | - | 0.1 | -0.5 | 4.6 | 0.0 |
| SELF MOVE SPELL | 0.3 | +5.5 | 0.0 | 9.1 | - | - | - | - |
| SET UP TOGETHER | 0.8 | +43.7 | 19.3 | 18.3 | 1.9 | +88.1 | 30.4 | 37.2 |
| SET-UP ANY TARGET | 0.2 | +24.3 | 3.6 | 2.6 | 0.1 | +10.1 | 0.0 | 7.6 |
| SET-UP MISSED | 0.0 | +2.0 | 8.9 | 2.6 | 0.1 | +16.7 | 3.5 | 19.7 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.8 | 0.0 | 0.0 | 0.3 | +0.5 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.8 | +0.0 | 188.6 | 14.8 | 0.5 | +0.0 | 115.3 | 12.4 |
| SHOTS IN THE MOVE | 13.4 | +541.6 | 0.0 | 262.1 | 9.8 | +340.4 | 0.0 | 121.7 |
| SPELL OFF EDGE | 0.0 | +10.0 | 0.0 | 9.9 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.3 | +66.8 | 3.6 | 2.6 | 0.2 | +51.4 | 13.7 | 25.5 |
| SPELL WORTH | 0.6 | +10.6 | 58.0 | 61.8 | 1.7 | +36.0 | 35.1 | 54.6 |
| STANDS TO CAST | 0.1 | +2.2 | 1.8 | 0.0 | 0.0 | +1.6 | 0.0 | 0.0 |
| STOPS | 0.0 | +0.0 | 9.8 | 0.0 | 0.1 | +8.8 | 12.6 | 0.0 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 10.6 |
| SUPPORT JOB KEPT | - | - | - | - | 0.1 | +0.0 | 11.3 | 0.0 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -4.5 | 2.8 | 1.4 | 0.1 | -1.8 | 0.0 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +1.9 | 0.0 | 10.2 | 0.8 | -12.5 | 10.9 | 11.9 |
| THROUGH LINE OF FIRE | 0.3 | +11.9 | 0.0 | 9.1 | 0.2 | +8.1 | 0.0 | 3.0 |
| TURN WORTH | 0.4 | -29.9 | 28.4 | 0.0 | 0.3 | -17.8 | 15.1 | 13.8 |
| TWO OR MORE ARRIVE | 0.1 | +0.6 | 19.3 | 0.0 | 0.4 | +2.0 | 6.5 | 1.1 |
| WEARS DOWN | 0.8 | +34.1 | 125.8 | 32.8 | 1.4 | +39.0 | 148.1 | 73.2 |
| WHO HITS BACK | 0.1 | +2.2 | 0.0 | 12.1 | 0.1 | +11.7 | 0.0 | 10.9 |
| WHOLE FIGHT | 0.2 | -5.1 | 38.8 | 14.1 | 0.4 | +3.0 | 51.5 | 40.4 |
| WHOLE FIGHT GAIN | 0.3 | +23.2 | 57.0 | 5.5 | 0.5 | +36.0 | 52.3 | 1.8 |

### Rule changes: ef2-mine-f5fe7c8-p2

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| KILLS COUNT NEXT TURN | 681 | 672 | 212 | 5.89 | +6297 | +29.7 |
| PATHS CROSS | 180 | 180 | 180 | 5.00 | +9759 | +54.2 |
| BEST PREY | 336 | 328 | 149 | 4.14 | +6146 | +41.2 |
| FALLBACK BY WORTH | 535 | 535 | 125 | 3.47 | +5408 | +43.3 |
| SEARCH SPOT | 116 | 116 | 116 | 3.22 | +5891 | +50.8 |
| COUNTER-CHARGE COVER | 582 | 259 | 104 | 2.89 | +5193 | +49.9 |
| FOLLOW UP WEIGHED | 94 | 94 | 94 | 2.61 | +13816 | +147.0 |
| FACES THE THREAT | 88 | 88 | 88 | 2.44 | +5998 | +68.2 |
| ARTILLERY RE-ROLL WEIGHED | 78 | 78 | 78 | 2.17 | +0 | +0.0 |
| CANNON SIGHT KEPT | 65 | 65 | 65 | 1.81 | +0 | +0.0 |
| ENEMY FORECAST | 388 | 381 | 59 | 1.64 | +276 | +4.7 |
| SHOTS IN THE MOVE | 835 | 475 | 58 | 1.61 | +1321 | +22.8 |
| MAX FOR POSITIONING | 361 | 172 | 53 | 1.47 | +432 | +8.1 |
| SAFER THAN THE JOB | 49 | 49 | 49 | 1.36 | +3287 | +67.1 |
| CANNON PLANNED TARGET | 267 | 267 | 46 | 1.28 | -504 | -10.9 |
| CHARGE NOW WEIGHED | 46 | 46 | 46 | 1.28 | +4535 | +98.6 |
| RISK BY ARC | 184 | 168 | 45 | 1.25 | +1648 | +36.6 |
| SHOT REPLANNED | 45 | 45 | 45 | 1.25 | +0 | +0.0 |
| ADVANCE LANE KEPT | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| KEEPS ITS TARGET | 148 | 145 | 42 | 1.17 | +758 | +18.1 |
| HOLDS AMBUSHERS | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| KILLS COUNT | 143 | 134 | 40 | 1.11 | +1452 | +36.3 |
| SET UP TOGETHER | 95 | 76 | 39 | 1.08 | +2304 | +59.1 |
| MARCH ODDS | 43 | 40 | 38 | 1.06 | +1140 | +30.0 |
| PLAN LEADS | 89 | 89 | 36 | 1.00 | +1499 | +41.6 |
| REDIRECT COUNTER | 269 | 101 | 34 | 0.94 | +1790 | +52.7 |
| LONE WIZARD KEPT IN | 33 | 33 | 33 | 0.92 | +2266 | +68.7 |
| SCOUT WAITS | 32 | 32 | 32 | 0.89 | +0 | +0.0 |
| CHAFF PASSED | 31 | 31 | 31 | 0.86 | -99 | -3.2 |
| LONE WIZARD HOLDS BACK | 68 | 68 | 27 | 0.75 | -2023 | -74.9 |
| BLOCKED WHEEL | 25 | 25 | 25 | 0.69 | +379 | +15.2 |
| SHOOTERS IN TWO RANKS | 25 | 25 | 25 | 0.69 | +49 | +2.0 |
| MODEL FACING | 24 | 24 | 24 | 0.67 | +5614 | +233.9 |
| MARCH CHECK | 30 | 23 | 23 | 0.64 | +998 | +43.4 |
| MISSILES IN THE MOVE | 202 | 99 | 23 | 0.64 | +627 | +27.3 |
| CASTING BLOCK | 25 | 25 | 22 | 0.61 | +1340 | +60.9 |
| CHARIOT NO STATIC JOB | 45 | 45 | 22 | 0.61 | -1688 | -76.7 |
| MAKE SURE TOGETHER | 62 | 42 | 21 | 0.58 | +1412 | +67.3 |
| REDIRECT WEIGHED | 21 | 21 | 21 | 0.58 | +687 | +32.7 |
| THROUGH LINE OF FIRE | 20 | 20 | 20 | 0.56 | +721 | +36.1 |
| CAST JOB | 40 | 36 | 18 | 0.50 | +282 | +15.7 |
| FRIENDS SHOTS CHECKED | 18 | 18 | 18 | 0.50 | +707 | +39.3 |
| STUCK PIVOT | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| WEARS DOWN | 78 | 73 | 16 | 0.44 | +454 | +28.4 |
| CASTS FROM BEHIND | 15 | 15 | 15 | 0.42 | +0 | +0.0 |
| MANOEUVRE | 15 | 15 | 15 | 0.42 | +248 | +16.5 |
| MOVE AND CAST | 15 | 15 | 15 | 0.42 | +713 | +47.5 |
| SHORT GUN FORWARD | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| CASTER AWAY FROM SCREEN | 12 | 12 | 12 | 0.33 | +0 | +0.0 |
| RESTRAINS TO SHOOT | 11 | 11 | 11 | 0.31 | +283 | +25.7 |
| WHOLE FIGHT GAIN | 28 | 22 | 11 | 0.31 | +477 | +43.3 |
| SURE CHARGE BEATS ADVANCE | 9 | 9 | 9 | 0.25 | -227 | -25.2 |
| PURSUES BIG PREY | 8 | 8 | 8 | 0.22 | -622 | -77.8 |
| BLOCKED CHARGE SKIPPED | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| OPENS UP | 13 | 11 | 7 | 0.19 | +345 | +49.2 |
| FIRE AND FLEE | 6 | 6 | 6 | 0.17 | +109 | +18.2 |
| HUNT IN PAIRS | 31 | 14 | 6 | 0.17 | +458 | +76.4 |
| WHOLE FIGHT | 23 | 20 | 6 | 0.17 | +438 | +73.0 |
| BACKUP TARGETS | 70 | 36 | 5 | 0.14 | +63 | +12.5 |
| KEEP FALLS | 5 | 5 | 5 | 0.14 | +161 | +32.3 |
| OVERRUNS AWAY | 41 | 37 | 5 | 0.14 | +53 | +10.7 |
| RAIDS THE BAGGAGE NEXT TURN | 5 | 5 | 5 | 0.14 | +118 | +23.7 |
| SURE REACH TOGETHER | 40 | 31 | 5 | 0.14 | +26 | +5.2 |
| WHO HITS BACK | 5 | 5 | 5 | 0.14 | -481 | -96.2 |
| HUNT ADVANCE | 13 | 13 | 4 | 0.11 | +116 | +29.1 |
| KEEPS SCOUTS OR AMBUSH | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| MOVES UNITS SPELL | 4 | 4 | 4 | 0.11 | +122 | +30.4 |
| NEEDED THERE | 4 | 4 | 4 | 0.11 | +0 | +0.0 |
| STANDS TO CAST | 4 | 4 | 4 | 0.11 | -13 | -3.1 |
| BEST PRIZE | 3 | 3 | 3 | 0.08 | -312 | -104.2 |
| MISSILES NEXT TURN | 275 | 116 | 3 | 0.08 | +31 | +10.4 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +72 | +35.8 |
| CARRIES OUT SET-UP | 6 | 6 | 2 | 0.06 | -86 | -43.1 |
| JOINT CHARGE PLAN | 10 | 10 | 2 | 0.06 | +290 | +145.1 |
| RAIDS THE BAGGAGE | 2 | 2 | 2 | 0.06 | +441 | +220.6 |
| SUPPORT JOB KEPT | 2 | 2 | 2 | 0.06 | +79 | +39.4 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.1 |
| CATCH ODDS | 1 | 1 | 1 | 0.03 | -1 | -1.3 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| EDGE GIVE GROUND | 12 | 11 | 1 | 0.03 | +21 | +21.0 |
| ELIXIR WORTH | 1 | 1 | 1 | 0.03 | +7 | +6.8 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +96 | +96.0 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +9 | +8.7 |
| KEEPS ITS PREY | 10 | 10 | 1 | 0.03 | +0 | +0.3 |
| MOVE SPELL IN RANGE | 2 | 2 | 1 | 0.03 | +0 | +0.3 |
| NOT NEEDED | 17 | 16 | 1 | 0.03 | +9 | +8.9 |
| OPENS A LANE | 4 | 2 | 1 | 0.03 | +19 | +19.1 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +64 | +64.4 |
| SAFE SURE CHARGE | 1 | 1 | 1 | 0.03 | -449 | -448.8 |
| STOPS | 6 | 6 | 1 | 0.03 | +2 | +1.8 |
| TWO OR MORE ARRIVE | 17 | 12 | 1 | 0.03 | +5 | +4.7 |
| ALREADY CARRIED | 1 | not checked | - | - | - | - |
| ARRIVAL HUNT | 3 | 3 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 44 | 44 | 0 | 0.00 | - | - |
| CARRIES OUT COUNTER | 3 | 3 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 24 | trace | - | - | - | - |
| CHEAP HELPER | 10 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 32 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 42 | not checked | - | - | - | - |
| FORECAST RESULT | 3003 | trace | - | - | - | - |
| GIVES UP | 94 | 87 | 0 | 0.00 | - | - |
| GIVES UP ITS SCREEN | 60 | 58 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 3 | not checked | - | - | - | - |
| HELPER UNSEEN | 16 | 13 | 0 | 0.00 | - | - |
| HUNT DROPPED | 6 | trace | - | - | - | - |
| HUNT KEPT | 6 | trace | - | - | - | - |
| HUNT RESULT | 13 | trace | - | - | - | - |
| HUNT THE GUNS | 13 | trace | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 13 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 2 | trace | - | - | - | - |
| MARCH OVER CASTS | 54 | 54 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 16 | trace | - | - | - | - |
| MOVE SPELL SPOT | 7 | not checked | - | - | - | - |
| NOT TURNED | 548 | 548 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 40 | not checked | - | - | - | - |
| PLAN RESULT | 2804 | trace | - | - | - | - |
| SCOUT SPOT | 28 | 28 | 0 | 0.00 | - | - |
| SECOND HUNTER | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 10 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 9 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SPELL OFF EDGE | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 17 | not checked | - | - | - | - |
| SPELL WORTH | 81 | not checked | - | - | - | - |
| TURN WORTH | 25 | 23 | 0 | 0.00 | - | - |

### Plans: ef2-mine-f5fe7c8-p2

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.4 | 17% | 627 | 330 | 53% |
| Mine | charge | 3.1 | 57% | 332 | 303 | 91% |
| Mine | close in | 3.5 | 24% | 234 | 98 | 42% |
| Mine | hold | 4.2 | 36% | 354 | 0 | 0% |
| Mine | join | 0.7 | 100% | 21 | 0 | 0% |
| Mine | shoot | 7.8 | 64% | 272 | 586 | 216% |
| Mine | support | 4.8 | 91% | 255 | 0 | 0% |
| Opponent | advance | 15.8 | 24% | 751 | 606 | 81% |
| Opponent | charge | 4.2 | 63% | 518 | 495 | 96% |
| Opponent | close in | 5.7 | 29% | 456 | 284 | 62% |
| Opponent | hold | 4.2 | 41% | 422 | 0 | 0% |
| Opponent | join | 0.8 | 90% | 33 | 0 | 0% |
| Opponent | shoot | 4.1 | 60% | 153 | 331 | 216% |
| Opponent | support | 6.6 | 95% | 352 | 0 | 0% |

### Enemy forecast: ef2-mine-f5fe7c8-p2

Per side (the computer that made the forecast) and expected action: forecasts a game, right (it did the expected action on the expected target), gone (missed, but the target or the enemy was gone before it acted), and what the enemy did instead; right of judged leaves the gone ones out.

| Side | Expected | A game | Right | Gone | Right of judged | Did charge | Did shoot | Did move | Same target |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 4.0 | 53% | 17% | 64% | 63% | 6% | 30% | 56% |
| Mine | shoot | 7.5 | 32% | 19% | 39% | 3% | 66% | 31% | 33% |
| Mine | move | 31.9 | 72% | 2% | 74% | 8% | 20% | 72% | - |
| Mine | all | 43.4 | 63% | 7% | 68% | 12% | 26% | 61% | - |
| Opponent | charge | 2.9 | 58% | 10% | 65% | 63% | 18% | 19% | 67% |
| Opponent | shoot | 13.7 | 37% | 17% | 44% | 1% | 72% | 27% | 37% |
| Opponent | move | 23.3 | 68% | 3% | 70% | 7% | 26% | 68% | - |
| Opponent | all | 40.0 | 56% | 9% | 62% | 9% | 41% | 50% | - |

Expected moves (the enemy's own plan): how far the expected end was from where the unit ended, against the guess that it stays where it stood.

| Side | Moves a game | Median miss | Median miss if it stays | Within 3" | Within 6" | Better than stays |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | 21.6 | 6.6" | 3.7" | 21% | 45% | 17% |
| Opponent | 14.8 | 6.6" | 4.0" | 21% | 46% | 22% |

### Packages: hunt the guns, ef2-mine-f5fe7c8-p2

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 3 | 0 | 33% | 33% | 0% | 2.0 | 312 | 117 | 33% | 59 |
| Opponent | 0.3 | 10 | 0 | 30% | 40% | 0% | 2.8 | 472 | 179 | 40% | 110 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 388 | 0 | 0% | 90 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 379 |
| Dwarfen Mountain Holds | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 354 | 351 | 100% | 20 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 18 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 64 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 276 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 1.0 | 4 | 0 | 75% | 75% | 0% | 2.7 | 489 | 338 | 75% | 105 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 48 |
| Tomb Kings of Khemri | 0.2 | 1 | 0 | 0% | 100% | 0% | 3.0 | 458 | 439 | 100% | 28 |
| Vampire Counts | 0.2 | 2 | 0 | 0% | 0% | 0% | - | 367 | 0 | 0% | 5 |
| Warriors of Chaos | 0.2 | 2 | 0 | 0% | 0% | 0% | - | 467 | 0 | 0% | 185 |
| Wood Elf Realms | 0.3 | 2 | 0 | 0% | 0% | 0% | - | 414 | 0 | 0% | 89 |

### Battle groups: ef2-mine-f5fe7c8-p2

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 8.7 | 20% | 68% | 13% | 38% | 37% | 7% | 7% | 48% | 0% |
| Mine | REDIRECT COUNTER | 3.1 | 20% | 77% | 18% | 0% | 17% | 0% | 0% | 83% | 0% |
| Opponent | COUNTER-CHARGE COVER | 7.5 | 17% | 63% | 22% | 30% | 25% | 6% | 17% | 53% | 0% |
| Opponent | REDIRECT COUNTER | 4.4 | 21% | 73% | 15% | 20% | 18% | 0% | 7% | 75% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ef2-mine-f5fe7c8-p2

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 5 | 83 (5) | 83 | 0 | 35 | 20% | 3.8 | 124 (3) | - | 0 (1) | 127 (3) | 0 (1) |
| Mine | Chaff | 44 | 43 (44) | 2 | 41 | 57 | 45% | 2.5 | 79 (24) | 0 (5) | 0 (15) | 55 (30) | 19 (14) |
| Mine | Character | 123 | 52 (123) | 52 | 0 | 53 | 14% | 2.5 | 50 (35) | 68 (53) | 34 (8) | 56 (54) | 63 (42) |
| Mine | Clean-up | 12 | 60 (12) | 7 | 54 | 77 | 42% | 2.6 | 24 (3) | 64 (6) | 94 (3) | 78 (7) | 38 (5) |
| Mine | Fast Hammer | 45 | 48 (45) | 30 | 18 | 52 | 27% | 2.8 | 41 (24) | 35 (10) | 88 (11) | 44 (31) | 56 (14) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 40 | 0% | 2.2 | - | 0 (3) | 0 (2) | 0 (5) | - |
| Mine | Hammer | 58 | 39 (58) | 29 | 9 | 45 | 10% | 2.9 | 32 (15) | 28 (33) | 96 (10) | 36 (38) | 43 (20) |
| Mine | Holder | 28 | 34 (28) | 6 | 28 | 51 | 32% | 3.4 | 0 (9) | 48 (13) | 59 (6) | 60 (15) | 5 (13) |
| Mine | Shooter | 43 | 107 (43) | 45 | 62 | 56 | 2% | 1.8 | 64 (7) | 100 (26) | 152 (10) | 152 (27) | 25 (16) |
| Mine | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | - | 0 (2) |
| Mine | War machine | 59 | 55 (59) | 55 | 0 | 38 | 2% | 1.1 | 38 (13) | 59 (36) | 61 (10) | 82 (10) | 50 (49) |
| Mine | Wizard | 22 | 22 (22) | 22 | 0 | 43 | 9% | 2.6 | 20 (7) | 60 (6) | 18 (3) | 65 (6) | 19 (10) |
| Opponent | Blocker | 2 | 0 (2) | 0 | 0 | 62 | 50% | 5.0 | 0 (2) | - | - | 0 (2) | - |
| Opponent | Chaff | 89 | 68 (89) | 41 | 27 | 39 | 36% | 2.7 | 85 (35) | 10 (20) | 92 (34) | 72 (63) | 59 (26) |
| Opponent | Character | 94 | 75 (94) | 75 | 0 | 41 | 21% | 2.4 | 85 (44) | 87 (30) | 42 (6) | 78 (59) | 93 (21) |
| Opponent | Clean-up | 10 | 26 (10) | 0 | 26 | 81 | 40% | 2.7 | 0 (6) | 91 (3) | 0 (1) | 0 (7) | 106 (3) |
| Opponent | Early | 2 | 0 (2) | 0 | 0 | 50 | 50% | 4.0 | 0 (1) | 0 (1) | - | 0 (2) | - |
| Opponent | Fast Hammer | 45 | 41 (45) | 31 | 10 | 48 | 24% | 3.1 | 29 (28) | 53 (8) | 68 (9) | 31 (28) | 60 (17) |
| Opponent | Fragile | 5 | 0 (5) | 0 | 0 | 61 | 40% | 2.3 | - | 0 (4) | 0 (1) | 0 (3) | 0 (2) |
| Opponent | Hammer | 69 | 37 (69) | 24 | 13 | 36 | 26% | 2.7 | 13 (19) | 51 (37) | 23 (13) | 31 (40) | 46 (29) |
| Opponent | Holder | 33 | 61 (33) | 8 | 53 | 10 | 39% | 2.9 | 40 (7) | 73 (23) | 15 (3) | 76 (17) | 42 (16) |
| Opponent | Shooter | 35 | 108 (35) | 38 | 70 | 36 | 6% | 1.8 | 181 (11) | 80 (17) | 70 (7) | 139 (23) | 59 (12) |
| Opponent | Support | 3 | 0 (3) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (2) | - | 0 (1) | 0 (2) |
| Opponent | War machine | 24 | 75 (24) | 75 | 0 | 19 | 12% | 1.6 | 121 (6) | 67 (15) | 39 (3) | 0 (2) | 82 (22) |
| Opponent | Wizard | 29 | 25 (29) | 25 | 0 | 60 | 3% | 1.4 | 22 (10) | 42 (6) | 20 (5) | 50 (10) | 0 (11) |

### Charged fights: ef2-mine-f5fe7c8-p2

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 45 | 123 | 0.8 | 1.0 | 164 | 17 | +147 | 1 of 3 | 3 of 3 | - | +147 |
| Mine | Chaos Dwarfs | 4 | 273 | 463 | 2.8 | 1.1 | 168 | 8 | +160 | 8 of 11 | 9 of 11 | +479 | +128 |
| Mine | Dwarfen Mountain Holds | 4 | 548 | 122 | 1.2 | 1.0 | 98 | 26 | +72 | 2 of 5 | 2 of 5 | - | +72 |
| Mine | Empire of Man | 5 | 501 | 250 | 2.0 | 1.1 | 125 | 28 | +97 | 4 of 10 | 8 of 10 | +210 | +85 |
| Mine | Grand Cathay | 4 | 310 | 534 | 2.8 | 1.2 | 194 | 0 | +194 | 2 of 11 | 8 of 11 | +990 | +115 |
| Mine | High Elf Realms | 4 | 109 | 438 | 3.8 | 1.1 | 117 | 10 | +107 | 4 of 15 | 14 of 15 | +0 | +115 |
| Mine | Kingdom of Bretonnia | 1 | 579 | 0 | 3.0 | 1.0 | 0 | 0 | +0 | 1 of 3 | 1 of 3 | - | +0 |
| Mine | Lizardmen | 1 | 0 | 310 | 4.0 | 1.0 | 78 | 0 | +78 | 0 of 4 | 2 of 4 | - | +78 |
| Mine | Ogre Kingdoms | 1 | 0 | 233 | 7.0 | 1.1 | 33 | 33 | -0 | 1 of 7 | 2 of 6 | -234 | +39 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 1330 | 7.0 | 1.3 | 190 | 69 | +121 | 2 of 7 | 4 of 7 | +424 | -0 |
| Mine | Skaven | 2 | 0 | 102 | 1.5 | 1.3 | 68 | 180 | -112 | 0 of 3 | 2 of 3 | +205 | -270 |
| Mine | Tomb Kings of Khemri | 1 | 0 | 1281 | 7.0 | 1.0 | 183 | 25 | +158 | 2 of 7 | 3 of 7 | - | +158 |
| Mine | Vampire Counts | 3 | 0 | 274 | 4.7 | 1.1 | 59 | 94 | -36 | 4 of 14 | 8 of 14 | +38 | -48 |
| Mine | Warriors of Chaos | 1 | 0 | 768 | 5.0 | 1.0 | 154 | 96 | +58 | 1 of 5 | 0 of 5 | - | +58 |
| **Mine** | all armies | 36 | 228 | 359 | 2.9 | 1.1 | 123 | 37 | +86 | 32 of 105 | 66 of 104 | +257 | +68 |
| Opponent | Dwarfen Mountain Holds | 2 | 374 | 143 | 2.0 | 1.5 | 72 | 0 | +72 | 0 of 4 | 3 of 4 | +85 | +67 |
| Opponent | Empire of Man | 2 | 912 | 108 | 1.5 | 1.7 | 72 | 0 | +72 | 1 of 3 | 3 of 3 | +95 | +60 |
| Opponent | Grand Cathay | 2 | 201 | 400 | 3.0 | 1.5 | 134 | 34 | +99 | 4 of 6 | 2 of 6 | +89 | +109 |
| Opponent | Kingdom of Bretonnia | 1 | 120 | 521 | 3.0 | 1.0 | 174 | 0 | +174 | 1 of 3 | 3 of 3 | - | +174 |
| Opponent | Ogre Kingdoms | 3 | 264 | 483 | 4.7 | 1.2 | 104 | 9 | +95 | 4 of 14 | 7 of 14 | +123 | +90 |
| Opponent | Skaven | 1 | 425 | 189 | 2.0 | 1.5 | 94 | 0 | +94 | 1 of 2 | 2 of 2 | +189 | +0 |
| Opponent | Tomb Kings of Khemri | 4 | 227 | 968 | 4.2 | 1.4 | 228 | 99 | +128 | 9 of 17 | 10 of 17 | +221 | +90 |
| Opponent | Vampire Counts | 6 | 9 | 420 | 3.0 | 1.0 | 140 | 38 | +102 | 7 of 18 | 11 of 18 | - | +102 |
| Opponent | Warriors of Chaos | 8 | 8 | 735 | 3.9 | 1.3 | 190 | 23 | +167 | 18 of 31 | 25 of 31 | +215 | +156 |
| Opponent | Wood Elf Realms | 7 | 98 | 628 | 4.1 | 1.1 | 152 | 13 | +139 | 12 of 29 | 16 of 29 | +399 | +97 |
| **Opponent** | all armies | 36 | 167 | 559 | 3.5 | 1.2 | 159 | 30 | +129 | 57 of 127 | 82 of 127 | +212 | +110 |

### Effective charges: ef2-mine-f5fe7c8-p2

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 0 | 0 | 0 | 1 (net -52) | 0 | 1 (net +128) | 1 | 0% (0 of 2) |
| Mine | Chaos Dwarfs | 11 | 2 (net +258) | 0 | 2 (net +366) | 3 (net +0) | 1 (net +143) | 3 (net +123) | 0 | 18% (2 of 11) |
| Mine | Dwarfen Mountain Holds | 5 | 0 | 1 (net +351) | 1 (net -65) | 1 (net -65) | 0 | 2 (net +70) | 0 | 20% (1 of 5) |
| Mine | Empire of Man | 10 | 0 | 0 | 2 (net +68) | 2 (net -36) | 0 | 6 (net +151) | 0 | 20% (2 of 10) |
| Mine | Grand Cathay | 11 | 0 | 0 | 2 (net +525) | 0 | 1 (net +60) | 8 (net +128) | 0 | 18% (2 of 11) |
| Mine | High Elf Realms | 15 | 0 | 0 | 1 (net +40) | 2 (net +91) | 1 (net +66) | 7 (net +133) | 4 | 9% (1 of 11) |
| Mine | Kingdom of Bretonnia | 3 | 0 | 0 | 0 | 3 (net +0) | 0 | 0 | 0 | 0% (0 of 3) |
| Mine | Lizardmen | 4 | 2 (net +125) | 0 | 1 (net +0) | 0 | 1 (net +60) | 0 | 0 | 25% (1 of 4) |
| Mine | Ogre Kingdoms | 7 | 0 | 0 | 2 (net +0) | 1 (net +0) | 0 | 1 (net -234) | 3 | 50% (2 of 4) |
| Mine | Orc & Goblin Tribes | 7 | 3 (net +304) | 0 | 1 (net +186) | 0 | 1 (net +45) | 0 | 2 | 20% (1 of 5) |
| Mine | Skaven | 3 | 1 (net -540) | 0 | 0 | 2 (net +102) | 0 | 0 | 0 | 0% (0 of 3) |
| Mine | Tomb Kings of Khemri | 7 | 0 | 0 | 1 (net +599) | 1 (net +0) | 0 | 3 (net +103) | 2 | 20% (1 of 5) |
| Mine | Vampire Counts | 14 | 3 (net -15) | 0 | 3 (net -258) | 2 (net -225) | 1 (net +125) | 3 (net +127) | 2 | 25% (3 of 12) |
| Mine | Warriors of Chaos | 5 | 0 | 0 | 0 | 1 (net +190) | 0 | 3 (net +33) | 1 | 0% (0 of 4) |
| Opponent | Dwarfen Mountain Holds | 4 | 1 (net +85) | 0 | 2 (net +73) | 0 | 0 | 1 (net +55) | 0 | 50% (2 of 4) |
| Opponent | Empire of Man | 3 | 0 | 0 | 2 (net +60) | 0 | 1 (net +95) | 0 | 0 | 67% (2 of 3) |
| Opponent | Grand Cathay | 6 | 2 (net +69) | 0 | 0 | 2 (net +106) | 0 | 1 (net +150) | 1 | 0% (0 of 5) |
| Opponent | Kingdom of Bretonnia | 3 | 0 | 0 | 0 | 0 | 0 | 2 (net +150) | 1 | 0% (0 of 2) |
| Opponent | Ogre Kingdoms | 14 | 3 (net +152) | 0 | 2 (net +164) | 3 (net +222) | 0 | 2 (net -45) | 4 | 20% (2 of 10) |
| Opponent | Skaven | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +94) | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 17 | 2 (net +432) | 0 | 2 (net -112) | 4 (net -75) | 2 (net +71) | 5 (net +292) | 2 | 13% (2 of 15) |
| Opponent | Vampire Counts | 18 | 2 (net +24) | 0 | 5 (net +81) | 2 (net -22) | 0 | 9 (net +158) | 0 | 28% (5 of 18) |
| Opponent | Warriors of Chaos | 31 | 0 | 1 (net -670) | 5 (net +188) | 6 (net +202) | 0 | 13 (net +230) | 6 | 20% (5 of 25) |
| Opponent | Wood Elf Realms | 29 | 5 (net +267) | 1 (net +0) | 3 (net -6) | 7 (net +147) | 2 (net +262) | 7 (net +170) | 4 | 12% (3 of 25) |

### Charged fights, damage counted: ef2-mine-f5fe7c8-p2

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 11 | 251 | 168 | +99 | 163 | 86 | +77 | +30.7 |
| Mine | 50-54% | 1 | 50 | 351 | +351 | 351 | 25 | +326 | +652.0 |
| Mine | Effective (55-75%) | 16 | 303 | 232 | +119 | 171 | 88 | +83 | +27.4 |
| Mine | 76-89% | 19 | 263 | 213 | -3 | 68 | 68 | +0 | +0.0 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 37 | 257 | 176 | +110 | 160 | 49 | +111 | +43.3 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 6 | 385 | 72 | +83 | 83 | 0 | +83 | +21.6 |
| Mine | No odds | 15 | 285 | 155 | +76 | 116 | 48 | +68 | +23.8 |
| Mine | All fights | 105 | 274 | 183 | +86 | 137 | 59 | +77 | +28.3 |
| Opponent | Long shot (under 50%) | 15 | 281 | 235 | +195 | 204 | 61 | +143 | +50.9 |
| Opponent | 50-54% | 2 | 157 | 299 | -335 | 88 | 371 | -284 | -180.7 |
| Opponent | Effective (55-75%) | 21 | 260 | 246 | +81 | 141 | 58 | +83 | +32.0 |
| Opponent | 76-89% | 24 | 344 | 194 | +116 | 169 | 60 | +109 | +31.8 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 42 | 302 | 213 | +183 | 217 | 48 | +169 | +56.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 5 | 469 | 82 | +152 | 177 | 27 | +150 | +32.0 |
| Opponent | No odds | 18 | 191 | 198 | +66 | 85 | 24 | +61 | +32.1 |
| Opponent | All fights | 127 | 289 | 211 | +129 | 172 | 54 | +117 | +40.6 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ef2-mine-f5fe7c8-p2 | move | 481 | 101 (21%) | 77 (16%) | 61 (13%) | 319 (66%) |
| ef2-mine-f5fe7c8-p2 | objective | 332 | 45 (14%) | 38 (11%) | 42 (13%) | 245 (74%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0106, L0122, L2429, L2535, L2735 |
| Charmed Shield | Opponent | L0425, L0827, L0934, L1026, L1727, L1827, L1927 |
| Clockwork Compass | Mine | L1228 |
| Clockwork Compass | Opponent | L0512 |
| Elixir of Power | Mine | L1118, L1135, L1927 |
| Fistful of Laurels | Mine | L1827 |
| Fistful of Laurels | Opponent | L0918, L1118, L1418 |
| Horn of the Wild Hunt | Opponent | L3033 |
| Invocation of Nehek | Mine | L2429, L2535, L2735 |
| Invocation of Nehek | Opponent | L0425, L0827, L1727, L1827, L1927 |
| Opal Amulet | Mine | L1418, L1435 |
| Periapt of Soul Exchange | Mine | L2029, L2131 |
| Periapt of Soul Exchange | Opponent | L0721 |
| Ring of Doom | Mine | L0206, L0222, L1118, L1135, L1228, L1531 |
| Ring of Doom | Opponent | L0512, L1531, L2131, L3033 |
| Ring of Jet | Mine | L1026, L1118, L1135, L1228 |
| Ring of Jet | Opponent | L0512, L0810 |
| Standard of the Fell Warrior | Mine | L1323 |
| Storm Daemon (Renegade 2.0) | Mine | L2131 |
| Storm Daemon (Renegade 2.0) | Opponent | L0721 |
| Twice-Blessed Armour | Mine | L0721, L1026 |
| Twice-Blessed Armour | Opponent | L0307, L0810 |
| Witch Hunter's Ward | Mine | L0721, L0810, L0827 |
| Witch Hunter's Ward | Opponent | L0307 |

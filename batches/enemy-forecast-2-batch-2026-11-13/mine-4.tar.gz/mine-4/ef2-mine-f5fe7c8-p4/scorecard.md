# Doctrine scorecard: ef2-mine-f5fe7c8-p4

### Scorecard: ef2-mine-f5fe7c8-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 13 | 6 | 1 | 2 | 1 | 0 | 0 | 350 |
| L0114 | 6 | 1 | Opponent | no | 2 | 2 | 5 | 1 | 0 | 0 | 0 | 123 |
| L0130 | 4 | 1 | Mine | no | 6 | - | 0 | 0 | 1 | 0 | 0 | 65 |
| L0130 | 4 | 1 | Opponent | no | 0 | 1 | 5 | 1 | 1 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | yes | 0 | 3 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Opponent | no | 1 | 1 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 2 | 3 | 6 | 0 | 0 | 0 | 81 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | yes | 1 | 2 | 4 | 0 | 0 | 0 | 0 | 675 |
| L0315 | 3 | 1 | Opponent | yes | 6 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | 4 | 3 | 0 | 1 | 0 | 0 | 709 |
| L0332 | 2 | 1 | Opponent | - | - | 1 | 5 | 2 | 1 | 0 | 0 | 170 |
| L0417 | 3 | 1 | Mine | yes | 4 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 2 | 2 | 3 | 0 | 1 | 0 | 0 | 135 |
| L0434 | 2 | 1 | Mine | - | - | 3 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0520 | 4 | 1 | Mine | no | 1 | 3 | 1 | 0 | 0 | 0 | 0 | 771 |
| L0520 | 4 | 1 | Opponent | no | 2 | 4 | 0 | 5 | 0 | 0 | 0 | 420 |
| L0608 | 2 | 1 | Mine | - | - | 6 | 1 | 2 | 0 | 0 | 0 | 798 |
| L0608 | 2 | 1 | Opponent | - | - | 5 | 2 | 2 | 0 | 0 | 0 | 605 |
| L0624 | 6 | 1 | Mine | no | 0 | 3 | 4 | 0 | 0 | 0 | 0 | 743 |
| L0624 | 6 | 1 | Opponent | no | 4 | - | 1 | 1 | 0 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | yes | - | 4 | 2 | 1 | 0 | 0 | 0 | 375 |
| L0713 | 5 | 1 | Opponent | yes | - | 3 | 3 | 2 | 0 | 0 | 0 | 302 |
| L0729 | 3 | 1 | Mine | no | 2 | 1 | 0 | 1 | 0 | 0 | 0 | 452 |
| L0729 | 3 | 1 | Opponent | no | 6 | 2 | 1 | 0 | 0 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | no | 0 | 4 | 0 | 1 | 0 | 0 | 0 | 605 |
| L0819 | 3 | 1 | Opponent | no | 4 | 2 | 5 | 3 | 2 | 0 | 0 | 226 |
| L0835 | 1 | 1 | Mine | no | 0 | 4 | 3 | 0 | 0 | 0 | 0 | 717 |
| L0835 | 1 | 1 | Opponent | no | 1 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | 2 | 1 | 1 | 0 | 0 | 0 | 677 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 4 | 5 | 1 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | yes | 3 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1017 | 3 | 1 | Opponent | no | 5 | 1 | 7 | 2 | 0 | 0 | 0 | 175 |
| L1034 | 2 | 1 | Mine | - | - | 1 | 3 | 1 | 0 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 2 | 5 | 3 | 0 | 0 | 0 | 0 |
| L1126 | 4 | 1 | Mine | no | 4 | 6 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1126 | 4 | 1 | Opponent | no | 2 | 2 | 5 | 2 | 1 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | - | 0 | 5 | 0 | 0 | 0 | 715 |
| L1314 | 6 | 1 | Mine | no | 6 | 2 | 4 | 0 | 1 | 0 | 0 | 302 |
| L1314 | 6 | 1 | Opponent | no | 7 | 1 | 4 | 0 | 0 | 0 | 0 | 0 |
| L1331 | 5 | 1 | Mine | yes | - | 3 | 4 | 3 | 0 | 0 | 0 | 317 |
| L1331 | 5 | 1 | Opponent | no | - | - | 0 | 1 | 4 | 0 | 0 | 340 |
| L1427 | 5 | 1 | Mine | yes | - | 3 | 2 | 2 | 0 | 0 | 0 | 177 |
| L1427 | 5 | 1 | Opponent | no | - | 2 | 4 | 3 | 0 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | no | - | 5 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 2 | 6 | 1 | 1 | 0 | 0 | 60 |
| L1621 | 1 | 1 | Mine | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 475 |
| L1621 | 1 | 1 | Opponent | no | 0 | 5 | 0 | 2 | 0 | 0 | 0 | 290 |
| L1719 | 3 | 1 | Mine | no | 6 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Opponent | yes | 1 | 2 | 6 | 0 | 0 | 0 | 0 | 490 |
| L1819 | 1 | 1 | Mine | no | 6 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 0 | 2 | 9 | 0 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | yes | - | 3 | 4 | 2 | 1 | 0 | 0 | 305 |
| L1835 | 5 | 1 | Opponent | yes | - | 3 | 2 | 3 | 0 | 0 | 0 | 140 |
| L2021 | 5 | 1 | Mine | yes | - | 3 | 1 | 5 | 0 | 0 | 0 | 210 |
| L2021 | 5 | 1 | Opponent | yes | - | 4 | 5 | 3 | 0 | 0 | 0 | 145 |
| L2123 | 5 | 1 | Mine | yes | - | - | 1 | 6 | 1 | 0 | 0 | 355 |
| L2123 | 5 | 1 | Opponent | yes | - | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Mine | yes | 2 | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L2227 | 1 | 1 | Opponent | no | 1 | 1 | 6 | 1 | 0 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Mine | yes | 5 | - | 1 | 0 | 2 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Opponent | no | 1 | 1 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Mine | yes | 4 | 2 | 3 | 3 | 1 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 3 | 1 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Mine | no | 7 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 163 |
| L2930 | 2 | 1 | Mine | - | - | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 2 | 4 | 1 | 0 | 0 | 0 | 207 |
| L3234 | 6 | 1 | Mine | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 46% | 3.3 | 2.9 | 2.4 | 1.4 | 0.3 | 0.0 | 0.0 | 291.1 |
| **Average** | | | Opponent | 29% | 2.3 | 2.1 | 3.5 | 1.8 | 0.3 | 0.0 | 0.0 | 135.4 |

### KPIs: ef2-mine-f5fe7c8-p4

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Winner chose to follow up after the loser gave ground |  | 98% (40 of 41); on the table 98% | 100% (66 of 66); on the table 100% | 99% (106 of 107); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 88% (7 of 8); on the table 100% | 94% (16 of 17); on the table 100% | 92% (23 of 25); on the table 100% |
| Winner chose to pursue after the loser fled |  | 83% (29 of 35); on the table 83% | 83% (30 of 36); on the table 83% | 83% (59 of 71); on the table 83% |
| Winner chose to follow up or pursue (all three) |  | 90% (76 of 84); on the table 92% | 94% (112 of 119); on the table 95% | 93% (188 of 203); on the table 94% |
| Magic missiles tried each own turn | 50%+ | 27% (73 of 271) | 32% (55 of 172) | 29% (128 of 443) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 40% (73 of 184) | 45% (55 of 122) | 42% (128 of 306) |
| Points that never fought | lower | 33% (22703 of 67942) | 37% (26377 of 71984) | 35% (49080 of 139926) |
|   infantry points that never fought | lower | 42% (6419 of 15347) | 58% (8038 of 13804) | 50% (14457 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 61% (165 of 270) | 55% (155 of 280) | 58% (320 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 91% (20 of 22); 1.7 uses a game | 78% (7 of 9); 0.6 uses a game | 87% (27 of 31); 1.2 uses a game |
| Bound items with another spell used |  | 44% (7 of 16); 0.4 uses a game | 50% (10 of 20); 0.4 uses a game | 47% (17 of 36); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 58% (11 of 19); 0.3 uses a game | 67% (10 of 15); 0.3 uses a game | 62% (21 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 57% (32713 of 57750) | 48% (30622 of 63347) | 52% (63335 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.5 (27%) | 0.9 (26%) | 2.3 (27%) |
| MARCHED: its unit marched | 1.4 (25%) | 0.5 (15%) | 1.9 (22%) |
| CHARGED: its unit charged | 0.1 (2%) | 0.3 (10%) | 0.4 (5%) |
| IN COMBAT: engaged in combat | 1.4 (26%) | 0.6 (20%) | 2.1 (24%) |
| REAR RANK: in a rear rank | 0.0 (1%) | 0.2 (5%) | 0.2 (2%) |
| FLEEING: fleeing | 0.1 (1%) | 0.2 (5%) | 0.2 (3%) |
| GONE: slain | 0.8 (14%) | 0.4 (13%) | 1.2 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (3%) | 0.2 (5%) | 0.3 (3%) |
| STUPIDITY: Stupidity | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.2 | 1.2 | 1.8 | 3.6 | 0.3 | 2.2 |
| not cast | 2.9 | 2.6 | 3.1 | 8.8 | 1.7 | 20.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.5 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 0.8 (30%) | 0.1 (5%) | 2.3 (27%) | 0.3 (18%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.9 (22%) | 0.6 (33%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (5%) | 0.0 (0%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.2 (6%) | 0.4 (16%) | 0.8 (25%) | 2.1 (24%) | 0.6 (33%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (7%) | 0.2 (6%) | 0.3 (9%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.3 (11%) | 0.1 (3%) | 0.2 (3%) | 0.0 (0%) | 1.0 (5%) |
| GONE: slain | 0.6 (21%) | 0.5 (18%) | 0.5 (17%) | 1.2 (14%) | 0.2 (11%) | 3.1 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (10%) | 0.1 (2%) | 0.1 (4%) | 0.3 (3%) | 0.0 (0%) | 0.7 (3%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (2%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.3 (11%) | 0.1 (2%) | 0.1 (1%) | 0.1 (3%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.5 (51%) | 0.2 (6%) | 1.1 (36%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.4 (70%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.4 a game | 0.5 a game | 0.9 a game |
| stood (cast and not dispelled) | 65% (28 of 43) | 56% (5 of 9) | 63% (33 of 52) |
| the unit moved after it | 79% (22 of 28) | 40% (2 of 5) | 73% (24 of 33) |
| it charged on its next turn | 0% (0 of 28) | 0% (0 of 5) | 0% (0 of 33) |
| the enemy charged it first | 43% (12 of 28) | 0% (0 of 5) | 36% (12 of 33) |
| it fought by the end of its next turn | 39% (11 of 28) | 0% (0 of 5) | 33% (11 of 33) |
| it moved out of a charge the enemy had planned (not charged first) | 11% (3 of 28) | 60% (3 of 5) | 18% (6 of 33) |
| none of these (no charge, no fight, no charge escaped) | 43% (12 of 28) | 40% (2 of 5) | 42% (14 of 33) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 61% (515 of 843) | 53% (284 of 532) | 58% (799 of 1375) |
|   cavalry | 56% (41 of 73) | 71% (82 of 115) | 65% (123 of 188) |
|   character | 40% (38 of 96) | 17% (20 of 121) | 27% (58 of 217) |
|   chariot | 37% (33 of 90) | 65% (15 of 23) | 42% (48 of 113) |
|   infantry | 61% (156 of 257) | 63% (142 of 224) | 62% (298 of 481) |
|   monster | 34% (14 of 41) | 19% (4 of 21) | 29% (18 of 62) |
|   war machine | 81% (233 of 286) | 75% (21 of 28) | 81% (254 of 314) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (25%) | 1.5 (22%) | 3.8 (24%) |
| CHARGED: it charged | 1.1 (12%) | 1.9 (27%) | 3.0 (19%) |
| FLEEING: it fled or was fleeing | 0.2 (2%) | 0.2 (3%) | 0.4 (2%) |
| IN COMBAT: it fought this turn or the last | 0.8 (9%) | 0.4 (6%) | 1.2 (8%) |
| NO TARGET IN RANGE | 1.8 (20%) | 1.1 (16%) | 2.9 (18%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (5%) | 0.7 (10%) | 1.2 (7%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 2.0 (22%) | 1.0 (15%) | 3.0 (19%) |
| SHELTERED: the target was sheltered | 0.2 (2%) | 0.1 (1%) | 0.2 (2%) |
| OTHER BAR | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.7 | 1.9 | 75% | 7.0 pts | 39 pts |
| character | 1.9 | 0.6 | 78% | 9.5 pts | 18 pts |
| chariot | 1.4 | 0.6 | 76% | 10.5 pts | 14 pts |
| infantry | 12.3 | 4.8 | 73% | 10.6 pts | 130 pts |
| monster | 0.6 | 0.0 | 95% | 2.0 pts | 1 pts |
| war machine | 7.1 | 4.7 | 72% | 19.9 pts | 140 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 3.8 | 6.5 | 5.2 |
| Charges that made contact a game | 2.8 | 4.5 | 3.6 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.65 declared, 0.59 contact (17 units) | 1.12 declared, 0.56 contact (16 units) | 0.88 declared, 0.58 contact (33 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.33 declared, 1.00 contact (9 units) | 1.21 declared, 0.93 contact (14 units) | 1.26 declared, 0.96 contact (23 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.46 declared, 0.32 contact (252 units) | 0.65 declared, 0.46 contact (305 units) | 0.56 declared, 0.39 contact (557 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 51% (41 of 81) | 44% (7 of 16) | 67% (4 of 6) | 50% (52 of 103) |
| Character in a unit | 77% (20 of 26) | 69% (9 of 13) | 100% (1 of 1) | 75% (30 of 40) |
| Character on its own | 79% (31 of 39) | 59% (17 of 29) | 30% (23 of 77) | 49% (71 of 145) |
| Chariot | 73% (11 of 15) | 83% (10 of 12) | - | 78% (21 of 27) |
| Infantry | 49% (41 of 83) | 48% (12 of 25) | 17% (1 of 6) | 47% (54 of 114) |
| Monster | 62% (21 of 34) | 86% (12 of 14) | - | 69% (33 of 48) |
| Monstrous | 93% (13 of 14) | 93% (13 of 14) | - | 93% (26 of 28) |
| War Machines | 72% (31 of 43) | 100% (2 of 2) | - | 73% (33 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (6 of 6); on the table 100% | 33% (34 of 102) | 30% | 50% (11 of 22) | 100% (6 of 6); 4.5 uses a game | 100% (2 of 2); 0.8 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 100% (11 of 11); on the table 100% | 25% (6 of 24) | 26% | 62% (20 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 80% (4 of 5); on the table 80% | - | 68% | 78% (21 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 77% (10 of 13); on the table 77% | 56% (10 of 18) | 48% | 61% (38 of 62) | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game | 80% (4 of 5); 0.7 uses a game |
| Grand Cathay | 4 | 100% (9 of 9); on the table 100% | 17% (14 of 84) | 36% | 43% (16 of 37) | 89% (8 of 9); 7.2 uses a game | 50% (1 of 2); 0.5 uses a game | 25% (1 of 4); 0.2 uses a game |
| High Elf Realms | 9 | 96% (23 of 24); on the table 96% | 14% (5 of 36) | 32% | 54% (38 of 70) | 100% (7 of 7); 2.8 uses a game | 43% (13 of 30); 2.3 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (1 of 1); on the table 100% | - | 19% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 1); 0.0 uses a game |
| Lizardmen | 3 | 100% (14 of 14); on the table 100% | 50% (3 of 6) | 27% | 67% (14 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 75% (3 of 4); on the table 75% | 17% (1 of 6) | 27% | 100% (14 of 14) | 50% (1 of 2); 0.5 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (8 of 8); on the table 100% | 14% (6 of 42) | 17% | 75% (18 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 6 | 100% (8 of 8); on the table 100% | 39% (16 of 41) | 51% | 71% (32 of 45) | 67% (2 of 3); 0.3 uses a game | 0.0 uses a game | 50% (3 of 6); 0.5 uses a game |
| Tomb Kings of Khemri | 4 | 77% (10 of 13); on the table 77% | 0% (0 of 6) | 29% | 50% (10 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 94% (29 of 31); on the table 94% | 40% (24 of 60) | 33% | 45% (19 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 90% (28 of 31); on the table 97% | 33% (4 of 12) | 33% | 47% (34 of 72) | 100% (2 of 2); 0.6 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 96% (24 of 25); on the table 96% | 83% (5 of 6) | 32% | 59% (33 of 56) | 50% (1 of 2); 0.7 uses a game | 0.0 uses a game | 50% (2 of 4); 0.3 uses a game |

Flank and rear charges a unit could have turned to face (ef2-mine-f5fe7c8-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 45% (45) | 58% (42) | 51% (87) |
| ...free all their last turn and able to turn (per game) | 0.86 | 0.75 | 1.61 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.17 | 0.08 | 0.25 |
| ...with the charger already in that arc before they moved (per game) | 0.69 | 0.50 | 1.19 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.42 | 0.83 | 2.25 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.53 | 0.36 | 0.89 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 7.64 | 8.33 | 15.97 |

### Quality by phase: ef2-mine-f5fe7c8-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 52% (67 of 129) | 42% (81 of 192) |
| Strategy | Shoot objectives carried out (shot that target) | 41% (133 of 327) | 52% (69 of 133) |
| Strategy | Close-in objectives charged next turn | 21% (31 of 148) | 13% (24 of 187) |
| Strategy | Support requests answered (helper made contact too) | 55% (6 of 11) | 45% (17 of 38) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 54% (7 of 13) | 100% (6 of 6) |
| Strategy | Joined characters whose unit fought | 45% (14 of 31) | 37% (11 of 30) |
| Strategy | Lone characters that fought | 80% (74 of 92) | 78% (67 of 86) |
| Movement | Charges halted short of contact | 0.2 | 0.2 |
| Movement | Idle units | 1.4 | 1.8 |
| Movement | Points that never moved of their own | 291.1 | 135.4 |
| Movement | Fights charged into per game | 2.7 | 3.8 |
| Movement | Charges with odds: long shots (under 50%) | 6 of 88, net -75 | 19 of 110, net +2 |
| Movement | Charges with odds: sweet spot (55-75%) | 12 of 88, net +23 | 19 of 110, net +31 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 11 of 88, net +95 | 7 of 110, net +34 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 34 of 88, net +100 | 34 of 110, net +150 |
| Shooting | Shots by shooting units (incl. breath weapons) | 8.8 | 8.8 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 49% (154 of 317) | 47% (149 of 315) |
| Shooting | Points destroyed by shooting units | 43.6 | 47.6 |
| Shooting | War machine shots | 6.5 | 0.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 59% (137 of 233) | 33% (7 of 21) |
| Shooting | Points destroyed by war machines | 60.6 | 7.8 |
| Magic | Magic missiles cast | 1.4 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 28% (14 of 50) | 26% (11 of 42) |
| Magic | Wounds caused by magic missiles | 4.1 | 1.3 |
| Magic | Wounds caused by other spells | 1.7 | 1.2 |
| Magic | Points destroyed by magic (all spells) | 83.1 | 28.6 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.0 / 0.4 / 0.6 / 0.1 | 2.1 / 0.3 / 0.7 / 0.1 |
| Combat | Points destroyed in combat | 254.2 | 478.7 |
| Combat | Points run down | 144.8 | 89.2 |
| Combat | Net points per charged fight, damage counted | +92 | +91 |
| Combat | Net per 100 charger points, damage counted | +31.2 | +30.7 |
| Combat | First round won (charged fights) | 62% | 62% |
| Combat | Net points per charged fight | +84 | +95 |
| Combat | Net points per supported fight / lone fight | +266 / +62 | +100 / +94 |
| Combat | Charged fights on a top-3 enemy unit | 30 of 96 | 70 of 136 |
| Game | Points lost | 826.4 | 661.9 |
| Game | VP from objectives | 458.1 | 638.6 |
| Game | Lone holders (player turns) | 3.3 | 2.3 |

- Mine won / drew / lost: 11 / 3 / 22 of 36 ended games (of 36); mean margin (Mine - Opponent) -351 VP
- The side that went first won 17 of 33 games with a winner
- Points traded per game (both sides' losses): 1488
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ef2-mine-f5fe7c8-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARTILLERY RE-ROLL WEIGHED | 1.1 | +0.0 | 0.0 | 15.3 | 0.1 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.9 | +7.2 | 0.0 | 21.4 | 1.2 | +14.7 | 0.0 | 6.4 |
| BEST PREY | 3.7 | +201.3 | 93.0 | 91.8 | 4.5 | +310.4 | 135.4 | 70.9 |
| BEST PRIZE | 0.0 | +2.3 | 3.0 | 0.0 | 0.1 | +3.1 | 8.2 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.2 | +0.0 | 21.5 | 0.0 | 0.2 | +0.0 | 13.5 | 7.9 |
| BLOCKED WHEEL | 0.6 | +3.2 | 0.0 | 1.8 | 0.5 | +14.3 | 0.0 | 12.5 |
| BOMBING RUN | 0.0 | +0.4 | 0.0 | 0.0 | - | - | - | - |
| BOUND ASSAILMENT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CANNON PLAN MISSED | 0.7 | +0.0 | 46.7 | 7.9 | 0.1 | +0.0 | 4.9 | 0.0 |
| CANNON PLANNED TARGET | 4.8 | +205.7 | 202.1 | 80.8 | 0.4 | +10.4 | 17.4 | 10.8 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 10.9 | 0.0 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | -1.4 | 21.8 | 13.9 | - | - | - | - |
| CARRIES OUT SET-UP | 0.1 | -0.2 | 46.1 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CAST JOB | 0.9 | +23.8 | 52.4 | 20.5 | 0.3 | +3.1 | 15.2 | 4.5 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.4 | +45.0 | 12.3 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 0.8 | +0.0 | 0.0 | 31.1 | 0.2 | +0.0 | 0.0 | 9.1 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.2 | 0.0 | 0.0 | 0.1 | +2.5 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.2 | 0.0 | 2.6 | 0.2 | -0.5 | 0.0 | 4.0 |
| CHAMPION TAKES THE CHALLENGE | 0.0 | +3.1 | 5.5 | 0.0 | - | - | - | - |
| CHARGE NOW WEIGHED | 0.5 | -29.2 | 6.6 | 38.3 | 0.7 | -40.4 | 26.1 | 13.3 |
| CHARIOT NO STATIC JOB | 0.4 | +0.0 | 7.8 | 16.2 | 0.2 | +0.0 | 4.0 | 3.2 |
| CHEAP HELPER | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 16.4 | 6.5 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.9 | +100.2 | 12.1 | 29.4 | 0.2 | +50.2 | 0.0 | 0.0 |
| COUNTER-CHARGE COVER | 6.3 | +169.6 | 0.0 | 161.0 | 6.6 | +542.2 | 0.0 | 110.9 |
| EDGE GIVE GROUND | - | - | - | - | 0.2 | +13.5 | 16.5 | 19.8 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +0.9 | 0.0 | 0.0 |
| ENEMY FORECAST | 10.3 | +308.5 | 111.7 | 301.7 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.4 | +116.0 | 0.0 | 34.0 | 0.8 | +65.7 | 0.0 | 7.0 |
| FALLBACK BY WORTH | 6.3 | +49.9 | 0.0 | 137.8 | 7.5 | +88.8 | 0.0 | 61.5 |
| FIGHT LIFT | 0.2 | +0.9 | 1.5 | 0.0 | - | - | - | - |
| FLANK NOT WEIGHED | 0.2 | +0.0 | 0.0 | 15.3 | 0.2 | +0.0 | 0.0 | 15.0 |
| FOCUS FIRE | 0.0 | +0.1 | 1.5 | 0.0 | 0.0 | +0.6 | 1.2 | 0.0 |
| FOLLOW UP WEIGHED | 1.0 | +127.2 | 0.0 | 57.7 | 1.3 | +199.2 | 0.0 | 24.1 |
| FORECAST RESULT | 39.9 | +2185.9 | 500.4 | 885.6 | 40.5 | +2348.5 | 920.2 | 1057.8 |
| FRIENDS SHOTS CHECKED | 0.2 | +8.8 | 0.0 | 10.2 | 0.1 | +5.0 | 0.0 | 3.5 |
| GIVES UP | 1.3 | -30.2 | 185.9 | 39.6 | 1.4 | -69.4 | 202.3 | 33.6 |
| GIVES UP ITS SCREEN | 0.5 | -7.1 | 34.6 | 11.5 | 1.0 | -18.4 | 54.0 | 16.9 |
| GROUND FLIERS | 0.1 | +0.2 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | 0.1 | +0.0 | 3.0 | 1.1 | 0.4 | +0.0 | 30.4 | 12.7 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +0.1 | 0.0 | 2.0 | 0.2 | +5.0 | 0.0 | 3.1 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 11.0 | 1.9 |
| HUNT IN PAIRS | 0.6 | +17.8 | 0.0 | 21.5 | 0.4 | +14.4 | 0.0 | 0.0 |
| HUNT KEPT | - | - | - | - | 0.0 | +0.9 | 0.0 | 0.0 |
| HUNT RESULT | 0.1 | +0.0 | 0.0 | 2.0 | 0.2 | +0.0 | 11.0 | 5.0 |
| HUNT THE GUNS | 0.1 | +11.2 | 0.0 | 2.0 | 0.2 | +62.2 | 0.0 | 3.1 |
| JOINT CHARGE PLAN | 0.0 | +0.0 | 15.0 | 0.0 | - | - | - | - |
| KEEP FALLS | 0.1 | +0.7 | 0.0 | 7.5 | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.1 | +1.0 | 4.8 | 8.2 | 0.5 | +3.5 | 11.0 | 0.0 |
| KEEPS ITS TARGET | 1.8 | +52.5 | 212.0 | 59.1 | 2.3 | +70.0 | 163.1 | 73.0 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.7 | +57.2 | 113.1 | 28.8 | 2.1 | +128.1 | 122.0 | 53.2 |
| KILLS COUNT NEXT TURN | 8.2 | +347.9 | 400.5 | 264.3 | 10.8 | +530.4 | 328.4 | 175.5 |
| LONE CHARACTER SAFE SPOT | 0.5 | +4.5 | 20.6 | 10.8 | 0.2 | +7.7 | 8.0 | 18.2 |
| LONE WIZARD HOLDS BACK | 1.0 | +0.0 | 117.6 | 38.0 | 1.0 | +0.0 | 21.6 | 28.9 |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.5 | +29.3 | 68.5 | 29.4 | 0.4 | +13.0 | 10.2 | 1.1 |
| MANOEUVRE | 0.2 | +4.5 | 0.0 | 12.0 | 0.1 | +13.8 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +1.7 | 0.0 | 0.0 | 0.1 | +0.4 | 0.0 | 6.4 |
| MARCH CHECK | 0.5 | +11.2 | 0.0 | 0.0 | 0.4 | +12.3 | 0.0 | 21.4 |
| MARCH ODDS | 0.7 | +36.1 | 22.9 | 10.2 | 0.6 | +46.1 | 18.4 | 10.9 |
| MARCH OVER CASTS | 1.0 | +46.2 | 0.0 | 26.4 | 0.6 | +31.3 | 0.0 | 29.1 |
| MAX FOR POSITIONING | 4.2 | +82.3 | 0.0 | 119.3 | 4.5 | +154.1 | 0.0 | 55.5 |
| MISSILES IN THE MOVE | 3.4 | +107.0 | 0.0 | 67.9 | 2.1 | +26.2 | 0.0 | 25.2 |
| MISSILES NEXT TURN | 4.9 | +97.5 | 0.0 | 109.2 | 3.0 | +25.7 | 0.0 | 53.1 |
| MODEL FACING | 0.2 | +38.0 | 0.0 | 3.3 | - | - | - | - |
| MOVE AND CAST | 0.3 | +7.4 | 0.0 | 5.5 | 0.1 | +2.1 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.3 | +6.1 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL NOT WORTH | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.7 | -38.7 | 26.0 | 65.8 | 0.1 | -2.9 | 0.0 | 2.6 |
| MOVE SPELL SPOT | 0.6 | +0.0 | 0.0 | 10.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +3.3 | 5.5 | 0.0 | 0.1 | +7.2 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.1 | +0.3 | 0.0 | 1.1 | 0.0 | +0.1 | 0.0 | 0.0 |
| NOT NEEDED | 0.2 | -12.9 | 41.1 | 1.1 | 0.2 | -7.7 | 30.8 | 0.0 |
| NOT TURNED | 7.6 | +87.3 | 0.0 | 266.6 | 8.3 | +134.5 | 0.0 | 122.8 |
| NOT WORTH A CAST | 0.5 | -0.4 | 0.0 | 29.7 | 0.2 | -0.1 | 0.0 | 0.0 |
| OPENS A LANE | 0.4 | +2.9 | 17.0 | 16.2 | 0.2 | +1.3 | 20.3 | 0.0 |
| OPENS UP | 0.3 | +17.8 | 16.1 | 0.0 | 0.3 | +27.0 | 25.2 | 0.0 |
| OVERRUNS AWAY | 0.5 | +8.4 | 39.1 | 4.2 | 0.4 | +3.3 | 34.0 | 20.6 |
| PATHS CROSS | 2.1 | +123.3 | 0.0 | 46.9 | 2.9 | +228.6 | 0.0 | 25.8 |
| PERIAPT WORTH | 0.1 | +5.7 | 0.0 | 0.0 | 0.0 | +2.8 | 0.0 | 0.0 |
| PLAN LEADS | 1.2 | +115.9 | 32.4 | 25.7 | 1.1 | +83.2 | 24.1 | 7.1 |
| PLAN RESULT | 37.6 | +1396.5 | 1009.0 | 1047.2 | 38.7 | +1314.2 | 1341.8 | 906.3 |
| PURSUES BIG PREY | 0.1 | -5.0 | 0.0 | 0.0 | 0.1 | -1.3 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | 0.0 | +4.9 | 0.0 | 2.2 | 0.0 | +6.6 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +4.7 | 0.0 | 2.2 | 0.1 | +5.0 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.6 | +66.9 | 0.0 | 42.9 | 5.4 | +369.3 | 0.0 | 90.1 |
| REDIRECT WEIGHED | 0.1 | +2.3 | 3.0 | 0.0 | 0.4 | +19.0 | 23.4 | 10.9 |
| RESTRAINS TO SHOOT | 0.1 | +5.9 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| RISK BY ARC | 2.6 | +87.7 | 263.9 | 62.9 | 2.9 | +54.5 | 253.0 | 111.7 |
| SAFE SURE CHARGE | 0.0 | -0.8 | 0.0 | 0.0 | 0.0 | -0.6 | 0.0 | 0.0 |
| SAFER THAN THE JOB | 0.5 | +23.3 | 0.0 | 10.8 | 0.4 | +15.8 | 0.0 | 1.6 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 1.5 | +68.4 | 0.0 | 74.2 | 2.0 | +118.9 | 0.0 | 40.4 |
| SECOND HUNTER | - | - | - | - | 0.1 | -0.0 | 0.0 | 0.0 |
| SELF MOVE SPELL | 0.2 | +53.2 | 0.0 | 21.9 | 0.4 | +20.3 | 0.0 | 27.2 |
| SET UP TOGETHER | 0.7 | +31.0 | 68.5 | 30.3 | 0.8 | +25.9 | 10.2 | 5.1 |
| SET-UP ANY TARGET | 0.6 | +85.1 | 10.2 | 10.2 | 0.0 | +1.2 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +24.2 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.3 | +0.7 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.2 | +0.0 | 32.2 | 5.3 | 0.3 | +0.0 | 48.0 | 0.0 |
| SHOTS IN THE MOVE | 13.5 | +550.2 | 0.0 | 224.2 | 7.0 | +181.7 | 0.0 | 81.1 |
| SPELL CATCH ODDS | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.6 | +91.6 | 10.2 | 10.2 | 0.1 | +17.4 | 0.0 | 0.0 |
| SPELL WORTH | 1.4 | +23.2 | 60.8 | 55.3 | 2.4 | +39.2 | 34.2 | 31.5 |
| STANDS TO CAST | - | - | - | - | 0.0 | +1.5 | 0.0 | 0.0 |
| STOPS | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| STUCK PIVOT | 0.3 | +0.0 | 0.0 | 13.5 | 0.3 | +0.0 | 0.0 | 5.8 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -2.0 | 23.8 | 0.0 | 0.2 | -13.8 | 36.1 | 0.0 |
| SURE REACH TOGETHER | 0.4 | +2.3 | 0.0 | 7.7 | 0.7 | -5.4 | 0.0 | 3.2 |
| THROUGH LINE OF FIRE | 0.3 | +13.3 | 0.0 | 5.6 | 0.3 | +23.5 | 0.0 | 1.9 |
| TURN WORTH | 0.5 | -36.5 | 31.1 | 7.9 | 0.4 | -34.5 | 43.6 | 5.5 |
| TWO OR MORE ARRIVE | 0.3 | +0.5 | 64.7 | 5.2 | 0.2 | +1.1 | 0.0 | 0.0 |
| WEARS DOWN | 1.0 | +45.2 | 128.9 | 41.8 | 1.3 | +35.5 | 105.6 | 92.1 |
| WHO HITS BACK | 0.3 | +27.5 | 0.0 | 19.0 | 0.2 | +8.9 | 0.0 | 9.7 |
| WHOLE FIGHT | 0.3 | +43.5 | 98.0 | 17.6 | 0.5 | +51.0 | 58.6 | 9.8 |
| WHOLE FIGHT GAIN | 0.1 | +9.1 | 7.0 | 6.4 | 0.6 | +33.7 | 64.8 | 15.1 |

### Rule changes: ef2-mine-f5fe7c8-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| KILLS COUNT NEXT TURN | 685 | 676 | 192 | 5.33 | +7292 | +38.0 |
| PATHS CROSS | 179 | 179 | 179 | 4.97 | +12667 | +70.8 |
| BEST PREY | 295 | 287 | 126 | 3.50 | +4499 | +35.7 |
| SEARCH SPOT | 127 | 127 | 124 | 3.44 | +6743 | +54.4 |
| FALLBACK BY WORTH | 496 | 496 | 99 | 2.75 | +4990 | +50.4 |
| COUNTER-CHARGE COVER | 464 | 234 | 97 | 2.69 | +4395 | +45.3 |
| FOLLOW UP WEIGHED | 82 | 82 | 82 | 2.28 | +11750 | +143.3 |
| FACES THE THREAT | 81 | 81 | 81 | 2.25 | +6542 | +80.8 |
| ENEMY FORECAST | 370 | 365 | 68 | 1.89 | +541 | +7.9 |
| SHOTS IN THE MOVE | 736 | 471 | 60 | 1.67 | +1475 | +24.6 |
| RISK BY ARC | 198 | 177 | 49 | 1.36 | +1733 | +35.4 |
| CANNON SIGHT KEPT | 48 | 48 | 48 | 1.33 | +0 | +0.0 |
| MARCH ODDS | 47 | 47 | 45 | 1.25 | +891 | +19.8 |
| CHARGE NOW WEIGHED | 43 | 43 | 43 | 1.19 | +2093 | +48.7 |
| ADVANCE LANE KEPT | 41 | 41 | 41 | 1.14 | +0 | +0.0 |
| MAX FOR POSITIONING | 314 | 166 | 41 | 1.14 | +366 | +8.9 |
| ARTILLERY RE-ROLL WEIGHED | 40 | 40 | 40 | 1.11 | +0 | +0.0 |
| KILLS COUNT | 137 | 124 | 40 | 1.11 | +2259 | +56.5 |
| BLOCKED WHEEL | 37 | 37 | 37 | 1.03 | +633 | +17.1 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| KEEPS ITS TARGET | 147 | 144 | 34 | 0.94 | +522 | +15.3 |
| SAFER THAN THE JOB | 32 | 32 | 32 | 0.89 | +1406 | +43.9 |
| PLAN LEADS | 80 | 80 | 30 | 0.83 | +1422 | +47.4 |
| CAST JOB | 46 | 46 | 28 | 0.78 | +329 | +11.8 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| REDIRECT COUNTER | 285 | 112 | 28 | 0.78 | +2014 | +71.9 |
| CANNON PLANNED TARGET | 187 | 187 | 27 | 0.75 | -98 | -3.6 |
| MISSILES IN THE MOVE | 201 | 107 | 24 | 0.67 | +458 | +19.1 |
| STUCK PIVOT | 24 | 24 | 24 | 0.67 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 23 | 23 | 23 | 0.64 | +1327 | +57.7 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| SHOT REPLANNED | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 72 | 72 | 18 | 0.50 | -849 | -47.2 |
| WHO HITS BACK | 18 | 18 | 18 | 0.50 | -1039 | -57.7 |
| MARCH CHECK | 32 | 20 | 17 | 0.47 | +240 | +14.1 |
| REDIRECT WEIGHED | 17 | 17 | 17 | 0.47 | +685 | +40.3 |
| SHOOTERS IN TWO RANKS | 17 | 17 | 17 | 0.47 | +36 | +2.1 |
| CASTER AWAY FROM SCREEN | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| CHARIOT NO STATIC JOB | 22 | 22 | 16 | 0.44 | -1409 | -88.1 |
| SET UP TOGETHER | 54 | 41 | 16 | 0.44 | +527 | +32.9 |
| WEARS DOWN | 83 | 77 | 16 | 0.44 | +443 | +27.7 |
| MOVE AND CAST | 15 | 15 | 15 | 0.42 | +343 | +22.9 |
| WHOLE FIGHT | 27 | 25 | 15 | 0.42 | +1612 | +107.5 |
| CHAFF PASSED | 14 | 14 | 14 | 0.39 | -26 | -1.9 |
| WHOLE FIGHT GAIN | 28 | 24 | 14 | 0.39 | +340 | +24.3 |
| MANOEUVRE | 14 | 14 | 13 | 0.36 | +661 | +50.8 |
| BLOCKED CHARGE SKIPPED | 12 | 12 | 12 | 0.33 | +0 | +0.0 |
| CASTING BLOCK | 13 | 13 | 12 | 0.33 | +1101 | +91.7 |
| FRIENDS SHOTS CHECKED | 11 | 11 | 11 | 0.31 | +499 | +45.4 |
| MAKE SURE TOGETHER | 33 | 24 | 11 | 0.31 | +401 | +36.5 |
| SURE CHARGE BEATS ADVANCE | 10 | 10 | 10 | 0.28 | -569 | -56.9 |
| BACKUP TARGETS | 75 | 36 | 9 | 0.25 | +31 | +3.4 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| OPENS UP | 22 | 20 | 9 | 0.25 | +313 | +34.7 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| MODEL FACING | 8 | 8 | 8 | 0.22 | +1368 | +171.0 |
| HUNT IN PAIRS | 37 | 30 | 7 | 0.19 | +261 | +37.3 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| PURSUES BIG PREY | 5 | 5 | 5 | 0.14 | -228 | -45.5 |
| BEST PRIZE | 4 | 4 | 4 | 0.11 | -36 | -9.0 |
| HUNT ADVANCE | 8 | 8 | 4 | 0.11 | +90 | +22.5 |
| KEEP FALLS | 4 | 4 | 4 | 0.11 | +90 | +22.4 |
| MISSILES NEXT TURN | 283 | 140 | 4 | 0.11 | +4 | +1.1 |
| OVERRUNS AWAY | 32 | 28 | 4 | 0.11 | +51 | +12.8 |
| RAIDS THE BAGGAGE NEXT TURN | 4 | 4 | 4 | 0.11 | +283 | +70.7 |
| EDGE GIVE GROUND | 8 | 8 | 3 | 0.08 | +284 | +94.6 |
| NEEDED THERE | 3 | 3 | 3 | 0.08 | +0 | +0.0 |
| NO RALLY LEFT | 3 | 3 | 3 | 0.08 | +3 | +1.1 |
| PERIAPT WORTH | 3 | 3 | 3 | 0.08 | +304 | +101.4 |
| RESTRAINS TO SHOOT | 3 | 3 | 3 | 0.08 | +221 | +73.8 |
| SURE REACH TOGETHER | 37 | 25 | 3 | 0.08 | +38 | +12.7 |
| CARRIES OUT SET-UP | 6 | 6 | 2 | 0.06 | -8 | -3.8 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +34 | +16.9 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +26 | +12.8 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| RAIDS THE BAGGAGE | 2 | 2 | 2 | 0.06 | +369 | +184.4 |
| SAFE SURE CHARGE | 2 | 2 | 2 | 0.06 | -70 | -35.1 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +14 | +13.8 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.2 |
| CARRIES OUT COUNTER | 3 | 3 | 1 | 0.03 | -49 | -48.7 |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| GIVES UP ITS SCREEN | 53 | 51 | 1 | 0.03 | +24 | +23.7 |
| KEEPS ITS PREY | 22 | 22 | 1 | 0.03 | +13 | +13.0 |
| STANDS TO CAST | 1 | 1 | 1 | 0.03 | +38 | +37.5 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| CANNON PLAN MISSED | 27 | 27 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 39 | trace | - | - | - | - |
| CATCH FLIERS | 3 | not checked | - | - | - | - |
| CHEAP HELPER | 8 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 38 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 6 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 15 | not checked | - | - | - | - |
| FORECAST RESULT | 2897 | trace | - | - | - | - |
| GIVES UP | 98 | 92 | 0 | 0.00 | - | - |
| GROUND FLIERS | 2 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 18 | 17 | 0 | 0.00 | - | - |
| HUNT DROPPED | 6 | trace | - | - | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT RESULT | 8 | trace | - | - | - | - |
| HUNT THE GUNS | 8 | trace | - | - | - | - |
| JOINT CHARGE PLAN | 1 | 1 | 0 | 0.00 | - | - |
| LONE CHARACTER SAFE SPOT | 26 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 8 | trace | - | - | - | - |
| MARCH OVER CASTS | 57 | 57 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 10 | 6 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 30 | trace | - | - | - | - |
| MOVE SPELL SPOT | 22 | not checked | - | - | - | - |
| NOT NEEDED | 15 | 13 | 0 | 0.00 | - | - |
| NOT TURNED | 575 | 575 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 26 | not checked | - | - | - | - |
| OPENS A LANE | 19 | 10 | 0 | 0.00 | - | - |
| PLAN RESULT | 2746 | trace | - | - | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SECOND HUNTER | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 22 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 23 | not checked | - | - | - | - |
| SET-UP MISSED | 4 | trace | - | - | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 26 | not checked | - | - | - | - |
| SPELL WORTH | 137 | not checked | - | - | - | - |
| STOPS | 1 | 1 | 0 | 0.00 | - | - |
| TURN WORTH | 35 | 31 | 0 | 0.00 | - | - |
| TWO OR MORE ARRIVE | 16 | 14 | 0 | 0.00 | - | - |

### Plans: ef2-mine-f5fe7c8-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.2 | 17% | 622 | 372 | 60% |
| Mine | charge | 2.9 | 60% | 289 | 271 | 94% |
| Mine | close in | 4.1 | 31% | 278 | 140 | 50% |
| Mine | hold | 4.9 | 38% | 522 | 0 | 0% |
| Mine | join | 0.8 | 93% | 21 | 0 | 0% |
| Mine | shoot | 7.9 | 62% | 357 | 614 | 172% |
| Mine | support | 4.9 | 89% | 305 | 0 | 0% |
| Opponent | advance | 15.0 | 17% | 821 | 427 | 52% |
| Opponent | charge | 4.6 | 54% | 540 | 501 | 93% |
| Opponent | close in | 5.1 | 25% | 332 | 160 | 48% |
| Opponent | hold | 4.0 | 40% | 348 | 0 | 0% |
| Opponent | join | 0.6 | 95% | 26 | 0 | 0% |
| Opponent | shoot | 3.2 | 67% | 66 | 229 | 349% |
| Opponent | support | 6.2 | 88% | 225 | 0 | 0% |

### Enemy forecast: ef2-mine-f5fe7c8-p4

Per side (the computer that made the forecast) and expected action: forecasts a game, right (it did the expected action on the expected target), gone (missed, but the target or the enemy was gone before it acted), and what the enemy did instead; right of judged leaves the gone ones out.

| Side | Expected | A game | Right | Gone | Right of judged | Did charge | Did shoot | Did move | Same target |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 4.2 | 48% | 15% | 57% | 58% | 9% | 33% | 51% |
| Mine | shoot | 5.2 | 26% | 23% | 33% | 3% | 59% | 38% | 28% |
| Mine | move | 30.5 | 77% | 2% | 78% | 9% | 14% | 77% | - |
| Mine | all | 39.9 | 67% | 6% | 71% | 13% | 20% | 67% | - |
| Opponent | charge | 2.7 | 64% | 9% | 71% | 67% | 10% | 22% | 69% |
| Opponent | shoot | 13.4 | 33% | 21% | 43% | 1% | 73% | 26% | 34% |
| Opponent | move | 24.4 | 70% | 3% | 72% | 7% | 23% | 70% | - |
| Opponent | all | 40.5 | 57% | 9% | 63% | 9% | 39% | 52% | - |

Expected moves (the enemy's own plan): how far the expected end was from where the unit ended, against the guess that it stays where it stood.

| Side | Moves a game | Median miss | Median miss if it stays | Within 3" | Within 6" | Better than stays |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | 22.2 | 7.0" | 3.8" | 19% | 43% | 20% |
| Opponent | 15.6 | 6.8" | 4.0" | 20% | 44% | 22% |

### Packages: hunt the guns, ef2-mine-f5fe7c8-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 2 | 0 | 0% | 0% | 0% | - | 201 | 0 | 0% | 9 |
| Opponent | 0.2 | 6 | 0 | 0% | 0% | 0% | - | 373 | 0 | 0% | 65 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 113 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 21 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 41 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 283 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 225 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 28 |
| Tomb Kings of Khemri | 1.2 | 5 | 0 | 0% | 0% | 0% | - | 345 | 0 | 0% | 0 |
| Vampire Counts | 0.4 | 3 | 0 | 0% | 0% | 0% | - | 305 | 0 | 0% | 6 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 21 |

### Battle groups: ef2-mine-f5fe7c8-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 6.3 | 31% | 51% | 11% | 38% | 21% | 24% | 11% | 44% | 0% |
| Mine | REDIRECT COUNTER | 2.6 | 38% | 80% | 0% | - | 29% | 3% | 11% | 49% | 9% |
| Opponent | COUNTER-CHARGE COVER | 6.6 | 16% | 59% | 11% | 25% | 24% | 18% | 9% | 48% | 0% |
| Opponent | REDIRECT COUNTER | 5.4 | 20% | 82% | 16% | 17% | 22% | 0% | 12% | 66% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ef2-mine-f5fe7c8-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 0 (4) | 0 | 0 | 100 | 75% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 49 | 41 (49) | 20 | 21 | 74 | 37% | 2.6 | 43 (21) | 0 (11) | 62 (17) | 53 (32) | 17 (17) |
| Mine | Character | 106 | 45 (106) | 45 | 0 | 43 | 16% | 2.1 | 37 (33) | 55 (50) | 42 (10) | 42 (48) | 53 (45) |
| Mine | Clean-up | 14 | 56 (14) | 17 | 39 | 37 | 21% | 3.5 | 19 (6) | 74 (5) | 85 (3) | 45 (7) | 65 (7) |
| Mine | Early | 1 | 139 (1) | 139 | 0 | 0 | 0% | 5.0 | - | 139 (1) | - | - | 139 (1) |
| Mine | Fast Hammer | 39 | 29 (39) | 19 | 10 | 56 | 18% | 2.7 | 27 (24) | 40 (9) | 19 (6) | 29 (28) | 29 (11) |
| Mine | Fragile | 4 | 29 (4) | 29 | 0 | 54 | 25% | 2.3 | 0 (3) | 108 (1) | - | 108 (1) | 0 (3) |
| Mine | Hammer | 64 | 33 (64) | 24 | 9 | 52 | 16% | 2.7 | 60 (10) | 24 (44) | 48 (10) | 31 (39) | 34 (25) |
| Mine | Holder | 30 | 80 (30) | 20 | 60 | 26 | 37% | 2.8 | 27 (7) | 107 (17) | 71 (5) | 83 (17) | 78 (12) |
| Mine | Shooter | 35 | 77 (35) | 31 | 46 | 31 | 3% | 1.6 | 57 (11) | 108 (19) | 0 (5) | 90 (23) | 53 (12) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Mine | War machine | 56 | 34 (56) | 34 | 0 | 34 | 7% | 1.3 | 45 (20) | 27 (31) | 29 (5) | 45 (7) | 33 (49) |
| Mine | Wizard | 17 | 38 (17) | 38 | 0 | 48 | 6% | 2.1 | 60 (5) | 60 (7) | - | 79 (3) | 54 (9) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | - | 0 (1) |
| Opponent | Chaff | 82 | 51 (82) | 16 | 35 | 58 | 43% | 2.9 | 80 (30) | 38 (21) | 36 (31) | 53 (62) | 45 (20) |
| Opponent | Character | 97 | 63 (97) | 63 | 0 | 26 | 22% | 2.1 | 69 (42) | 62 (38) | 71 (8) | 71 (49) | 61 (39) |
| Opponent | Clean-up | 12 | 110 (12) | 10 | 100 | 34 | 42% | 2.4 | 102 (3) | 135 (6) | 54 (3) | 131 (7) | 90 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 0 | 0% | 4.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 54 | 41 (54) | 25 | 16 | 46 | 30% | 2.8 | 38 (27) | 31 (17) | 77 (10) | 44 (34) | 36 (20) |
| Opponent | Fragile | 16 | 8 (16) | 8 | 0 | 75 | 25% | 1.6 | 0 (2) | 0 (8) | 41 (3) | 13 (10) | 0 (3) |
| Opponent | Hammer | 64 | 37 (64) | 31 | 6 | 39 | 33% | 2.9 | 33 (20) | 38 (38) | 38 (6) | 40 (42) | 31 (22) |
| Opponent | Holder | 27 | 45 (27) | 5 | 40 | 25 | 52% | 3.9 | 23 (8) | 63 (15) | 0 (3) | 65 (11) | 30 (15) |
| Opponent | Shooter | 34 | 101 (34) | 40 | 61 | 36 | 0% | 1.6 | 89 (9) | 112 (23) | 31 (2) | 89 (20) | 118 (14) |
| Opponent | Support | 6 | 0 (6) | 0 | 0 | 100 | 17% | 3.4 | - | 0 (1) | 0 (2) | 0 (1) | 0 (2) |
| Opponent | War machine | 6 | 52 (6) | 52 | 0 | 30 | 0% | 1.8 | 88 (3) | 0 (3) | - | 88 (3) | 0 (3) |
| Opponent | Wizard | 20 | 21 (20) | 21 | 0 | 34 | 5% | 2.0 | 34 (9) | 36 (4) | 0 (3) | 30 (11) | 15 (5) |

### Charged fights: ef2-mine-f5fe7c8-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 252 | 18 | 1.2 | 1.0 | 14 | 17 | -3 | 0 of 5 | 2 of 5 | - | -3 |
| Mine | Chaos Dwarfs | 4 | 65 | 236 | 2.8 | 1.1 | 86 | 37 | +49 | 5 of 11 | 8 of 11 | +234 | +31 |
| Mine | Dwarfen Mountain Holds | 3 | 188 | 70 | 1.7 | 1.0 | 42 | 26 | +16 | 4 of 5 | 2 of 5 | - | +16 |
| Mine | Empire of Man | 5 | 357 | 144 | 1.8 | 1.1 | 80 | 89 | -9 | 4 of 9 | 4 of 9 | +393 | -59 |
| Mine | Grand Cathay | 4 | 347 | 341 | 2.8 | 1.2 | 124 | 15 | +109 | 2 of 11 | 8 of 11 | +375 | +50 |
| Mine | High Elf Realms | 4 | 260 | 168 | 2.8 | 1.0 | 61 | 36 | +25 | 0 of 11 | 6 of 11 | - | +25 |
| Mine | Kingdom of Bretonnia | 1 | 45 | 587 | 5.0 | 1.0 | 117 | 0 | +117 | 2 of 5 | 4 of 5 | - | +117 |
| Mine | Lizardmen | 1 | 55 | 1234 | 4.0 | 1.2 | 308 | 0 | +308 | 2 of 4 | 3 of 4 | +255 | +326 |
| Mine | Ogre Kingdoms | 2 | 0 | 247 | 3.5 | 1.1 | 71 | 82 | -12 | 3 of 7 | 5 of 7 | +255 | -56 |
| Mine | Skaven | 2 | 222 | 33 | 0.5 | 1.0 | 66 | 0 | +66 | 0 of 1 | 0 of 1 | - | +66 |
| Mine | Tomb Kings of Khemri | 2 | 22 | 396 | 3.0 | 1.0 | 132 | 0 | +132 | 2 of 6 | 3 of 6 | - | +132 |
| Mine | Vampire Counts | 2 | 54 | 818 | 5.0 | 1.3 | 164 | 4 | +160 | 3 of 10 | 8 of 10 | +162 | +159 |
| Mine | Warriors of Chaos | 2 | 0 | 994 | 5.5 | 1.1 | 181 | 14 | +167 | 3 of 11 | 7 of 11 | +290 | +154 |
| **Mine** | all armies | 36 | 187 | 299 | 2.7 | 1.1 | 112 | 29 | +84 | 30 of 96 | 60 of 96 | +266 | +62 |
| Opponent | Empire of Man | 1 | 340 | 0 | 1.0 | 1.0 | 0 | 214 | -214 | 1 of 1 | 0 of 1 | - | -214 |
| Opponent | High Elf Realms | 5 | 150 | 601 | 3.4 | 1.1 | 177 | 83 | +94 | 11 of 17 | 11 of 17 | -651 | +140 |
| Opponent | Lizardmen | 2 | 0 | 562 | 4.5 | 1.0 | 125 | 76 | +49 | 6 of 9 | 5 of 9 | - | +49 |
| Opponent | Orc & Goblin Tribes | 3 | 89 | 719 | 6.0 | 1.0 | 120 | 14 | +105 | 4 of 18 | 10 of 18 | - | +105 |
| Opponent | Skaven | 4 | 60 | 186 | 2.2 | 1.3 | 82 | 13 | +69 | 5 of 9 | 7 of 9 | +186 | +11 |
| Opponent | Tomb Kings of Khemri | 2 | 205 | 1038 | 5.5 | 1.0 | 189 | 12 | +176 | 5 of 11 | 8 of 11 | - | +176 |
| Opponent | Vampire Counts | 6 | 64 | 354 | 3.5 | 1.1 | 101 | 31 | +70 | 12 of 21 | 12 of 21 | +98 | +68 |
| Opponent | Warriors of Chaos | 7 | 0 | 477 | 3.4 | 1.1 | 139 | 28 | +111 | 12 of 24 | 16 of 24 | +207 | +98 |
| Opponent | Wood Elf Realms | 6 | 106 | 487 | 4.3 | 1.3 | 112 | 17 | +95 | 14 of 26 | 16 of 26 | +124 | +84 |
| **Opponent** | all armies | 36 | 84 | 486 | 3.8 | 1.1 | 129 | 34 | +95 | 70 of 136 | 85 of 136 | +100 | +94 |

### Effective charges: ef2-mine-f5fe7c8-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 1 (net +0) | 0 | 0 | 1 (net +70) | 0 | 3 (net -28) | 0 | 0% (0 of 5) |
| Mine | Chaos Dwarfs | 11 | 1 (net +0) | 0 | 2 (net +0) | 1 (net -339) | 1 (net +234) | 3 (net +164) | 3 | 25% (2 of 8) |
| Mine | Dwarfen Mountain Holds | 5 | 1 (net +0) | 0 | 2 (net +0) | 1 (net +210) | 0 | 1 (net -128) | 0 | 40% (2 of 5) |
| Mine | Empire of Man | 9 | 1 (net -110) | 1 (net +0) | 1 (net -265) | 3 (net +46) | 0 | 2 (net +196) | 1 | 12% (1 of 8) |
| Mine | Grand Cathay | 11 | 0 | 0 | 2 (net +36) | 4 (net +296) | 1 (net +0) | 3 (net -18) | 1 | 20% (2 of 10) |
| Mine | High Elf Realms | 11 | 0 | 0 | 1 (net +66) | 6 (net +81) | 0 | 4 (net -68) | 0 | 9% (1 of 11) |
| Mine | Kingdom of Bretonnia | 5 | 0 | 0 | 0 | 2 (net +0) | 1 (net +92) | 1 (net +140) | 1 | 0% (0 of 4) |
| Mine | Lizardmen | 4 | 0 | 0 | 0 | 2 (net +490) | 1 (net +0) | 1 (net +255) | 0 | 0% (0 of 4) |
| Mine | Ogre Kingdoms | 7 | 1 (net -575) | 0 | 1 (net +0) | 0 | 0 | 4 (net +124) | 1 | 17% (1 of 6) |
| Mine | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +66) | 0 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 6 | 1 (net +233) | 0 | 0 | 1 (net +0) | 1 (net +54) | 2 (net +252) | 1 | 0% (0 of 5) |
| Mine | Vampire Counts | 10 | 0 | 0 | 1 (net +109) | 2 (net +300) | 3 (net +150) | 4 (net +110) | 0 | 10% (1 of 10) |
| Mine | Warriors of Chaos | 11 | 0 | 0 | 2 (net +145) | 1 (net +168) | 3 (net +71) | 5 (net +233) | 0 | 18% (2 of 11) |
| Opponent | Empire of Man | 1 | 0 | 0 | 0 | 1 (net -214) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | High Elf Realms | 17 | 4 (net -240) | 1 (net +0) | 3 (net +84) | 2 (net +591) | 1 (net +0) | 4 (net +267) | 2 | 20% (3 of 15) |
| Opponent | Lizardmen | 9 | 1 (net +0) | 0 | 0 | 6 (net +50) | 0 | 0 | 2 | 0% (0 of 7) |
| Opponent | Orc & Goblin Tribes | 18 | 1 (net +0) | 0 | 2 (net +376) | 1 (net +185) | 0 | 1 (net +0) | 13 | 40% (2 of 5) |
| Opponent | Skaven | 9 | 3 (net +164) | 0 | 0 | 0 | 2 (net +18) | 4 (net +24) | 0 | 0% (0 of 9) |
| Opponent | Tomb Kings of Khemri | 11 | 2 (net +241) | 0 | 1 (net -70) | 1 (net +115) | 0 | 5 (net +228) | 2 | 11% (1 of 9) |
| Opponent | Vampire Counts | 21 | 5 (net -59) | 1 (net +0) | 4 (net -14) | 6 (net +114) | 1 (net +0) | 2 (net +388) | 2 | 21% (4 of 19) |
| Opponent | Warriors of Chaos | 24 | 2 (net +162) | 0 | 2 (net +15) | 6 (net +121) | 2 (net +83) | 8 (net +112) | 4 | 10% (2 of 20) |
| Opponent | Wood Elf Realms | 26 | 1 (net +0) | 0 | 7 (net -45) | 6 (net +245) | 1 (net +36) | 10 (net +111) | 1 | 28% (7 of 25) |

### Charged fights, damage counted: ef2-mine-f5fe7c8-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 6 | 154 | 313 | -75 | 61 | 144 | -83 | -53.7 |
| Mine | 50-54% | 1 | 164 | 343 | +0 | 0 | 0 | +0 | +0.0 |
| Mine | Effective (55-75%) | 12 | 277 | 266 | +23 | 84 | 61 | +23 | +8.3 |
| Mine | 76-89% | 24 | 325 | 205 | +146 | 190 | 31 | +159 | +48.7 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 34 | 283 | 187 | +100 | 150 | 41 | +109 | +38.7 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 11 | 439 | 101 | +95 | 103 | 5 | +98 | +22.3 |
| Mine | No odds | 8 | 211 | 122 | +34 | 101 | 42 | +59 | +28.0 |
| Mine | All fights | 96 | 295 | 196 | +84 | 135 | 43 | +92 | +31.2 |
| Opponent | Long shot (under 50%) | 19 | 300 | 293 | +2 | 127 | 163 | -36 | -12.1 |
| Opponent | 50-54% | 2 | 118 | 143 | +0 | 0 | 19 | -19 | -15.8 |
| Opponent | Effective (55-75%) | 19 | 284 | 231 | +31 | 69 | 42 | +27 | +9.7 |
| Opponent | 76-89% | 29 | 310 | 236 | +153 | 215 | 53 | +162 | +52.3 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 34 | 305 | 240 | +150 | 175 | 25 | +150 | +49.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 300 | 70 | +34 | 42 | 14 | +29 | +9.7 |
| Opponent | No odds | 26 | 293 | 176 | +96 | 141 | 40 | +101 | +34.4 |
| Opponent | All fights | 136 | 297 | 223 | +95 | 146 | 55 | +91 | +30.7 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ef2-mine-f5fe7c8-p4 | move | 455 | 115 (25%) | 78 (17%) | 46 (10%) | 294 (65%) |
| ef2-mine-f5fe7c8-p4 | objective | 335 | 54 (16%) | 44 (13%) | 41 (12%) | 240 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |

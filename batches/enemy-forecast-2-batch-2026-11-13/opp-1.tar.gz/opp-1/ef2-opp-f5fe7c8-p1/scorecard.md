# Doctrine scorecard: ef2-opp-f5fe7c8-p1

### Scorecard: ef2-opp-f5fe7c8-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 2 | 5 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0102 | 6 | 1 | Opponent | no | 2 | 1 | 1 | 7 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Mine | no | 5 | 4 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Opponent | no | 6 | 2 | 4 | 4 | 1 | 0 | 0 | 302 |
| L0135 | 3 | 1 | Mine | yes | 3 | - | 0 | 1 | 0 | 0 | 0 | 639 |
| L0135 | 3 | 1 | Opponent | yes | 4 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 1 | 2 | 3 | 1 | 0 | 0 | 170 |
| L0218 | 2 | 1 | Opponent | - | - | 4 | 1 | 2 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 0 | 2 | 5 | 3 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Opponent | no | 0 | 1 | 4 | 3 | 1 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 5 | 2 | 5 | 0 | 0 | 0 | 0 | 590 |
| L0319 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Mine | yes | 13 | 2 | 3 | 1 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 0 | 3 | 1 | 2 | 0 | 0 | 0 | 1120 |
| L0421 | 1 | 1 | Mine | no | 0 | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 0 | - | 0 | 3 | 1 | 0 | 0 | 285 |
| L0508 | 4 | 1 | Mine | no | 0 | - | 0 | 2 | 0 | 0 | 0 | 698 |
| L0508 | 4 | 1 | Opponent | no | 0 | 4 | 2 | 2 | 0 | 0 | 0 | 605 |
| L0524 | 2 | 1 | Mine | - | - | 5 | 1 | 1 | 0 | 0 | 0 | 771 |
| L0524 | 2 | 1 | Opponent | - | - | 2 | 0 | 2 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 0 | - | 3 | 1 | 0 | 0 | 0 | 743 |
| L0612 | 6 | 1 | Opponent | no | 4 | 2 | 2 | 1 | 0 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | 2 | 2 | 0 | 0 | 0 | 0 | 801 |
| L0628 | 4 | 1 | Opponent | no | 2 | 3 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0717 | 3 | 1 | Mine | no | 2 | 2 | 4 | 0 | 1 | 0 | 0 | 375 |
| L0717 | 3 | 1 | Opponent | no | 2 | 2 | 5 | 1 | 2 | 0 | 0 | 175 |
| L0733 | 1 | 1 | Mine | no | 4 | 5 | 2 | 1 | 1 | 0 | 0 | 420 |
| L0733 | 1 | 1 | Opponent | no | 0 | 1 | 5 | 2 | 0 | 0 | 0 | 108 |
| L0823 | 1 | 1 | Mine | no | 3 | 2 | 2 | 1 | 0 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 0 | 1 | 0 | 0 | 60 |
| L0913 | 1 | 1 | Mine | no | 2 | 2 | 1 | 1 | 0 | 0 | 0 | 726 |
| L0913 | 1 | 1 | Opponent | no | 8 | - | 1 | 0 | 0 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 1 | 4 | 2 | 1 | 0 | 0 | 0 | 629 |
| L0930 | 6 | 1 | Opponent | no | 4 | 2 | 2 | 1 | 1 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 0 | 2 | 6 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 0 | - | 3 | 4 | 1 | 0 | 0 | 577 |
| L1114 | 4 | 1 | Mine | no | 0 | 2 | 3 | 0 | 1 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1131 | 3 | 1 | Mine | no | 0 | - | 1 | 0 | 0 | 0 | 0 | 330 |
| L1131 | 3 | 1 | Opponent | no | 0 | 4 | 1 | 2 | 2 | 0 | 0 | 562 |
| L1224 | 6 | 1 | Mine | no | 7 | 2 | 2 | 0 | 1 | 0 | 0 | 524 |
| L1224 | 6 | 1 | Opponent | no | 6 | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | no | - | 2 | 2 | 3 | 2 | 0 | 0 | 302 |
| L1319 | 5 | 1 | Opponent | yes | - | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | no | 5 | 2 | 3 | 0 | 1 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 158 |
| L1431 | 3 | 1 | Mine | yes | 9 | 2 | 1 | 0 | 0 | 0 | 0 | 177 |
| L1431 | 3 | 1 | Opponent | no | 0 | - | 1 | 2 | 3 | 0 | 0 | 562 |
| L1527 | 3 | 1 | Mine | no | 1 | 2 | 3 | 0 | 0 | 0 | 0 | 199 |
| L1527 | 3 | 1 | Opponent | no | 0 | 2 | 7 | 0 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | yes | - | 2 | 4 | 2 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | yes | - | 1 | 4 | 2 | 0 | 0 | 0 | 211 |
| L1723 | 1 | 1 | Mine | yes | 3 | 2 | 6 | 0 | 0 | 0 | 0 | 98 |
| L1723 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 0 | 3 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | yes | - | 4 | 3 | 2 | 2 | 0 | 0 | 234 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 4 | 1 | 1 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Mine | yes | 1 | 2 | 5 | 1 | 1 | 0 | 0 | 226 |
| L1923 | 3 | 1 | Opponent | no | 0 | 1 | 9 | 1 | 2 | 0 | 0 | 245 |
| L2025 | 3 | 1 | Mine | yes | 3 | 3 | 2 | 0 | 1 | 0 | 0 | 402 |
| L2025 | 3 | 1 | Opponent | no | 3 | 4 | 5 | 3 | 0 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | no | 5 | - | 0 | 2 | 0 | 0 | 0 | 1162 |
| L2127 | 3 | 1 | Opponent | no | 9 | 1 | 5 | 2 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | yes | - | 3 | 3 | 0 | 0 | 0 | 0 | 144 |
| L2231 | 5 | 1 | Opponent | yes | - | 1 | 6 | 1 | 2 | 0 | 0 | 340 |
| L2335 | 1 | 1 | Mine | no | 0 | 1 | 3 | 1 | 1 | 0 | 0 | 0 |
| L2335 | 1 | 1 | Opponent | no | 1 | 4 | 4 | 0 | 1 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | 2 | 3 | 5 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | yes | - | - | 1 | 2 | 1 | 0 | 0 | 170 |
| L2730 | 6 | 1 | Mine | no | 2 | 3 | 7 | 3 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 0 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 170 |
| L2934 | 6 | 1 | Opponent | no | 0 | 3 | 0 | 1 | 0 | 0 | 0 | 267 |
| **Average** | | | Mine | 29% | 2.6 | 2.5 | 2.7 | 1.2 | 0.4 | 0.0 | 0.0 | 334.6 |
| **Average** | | | Opponent | 18% | 1.8 | 2.3 | 2.9 | 1.7 | 0.6 | 0.0 | 0.0 | 172.7 |

### KPIs: ef2-opp-f5fe7c8-p1

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Winner chose to follow up after the loser gave ground |  | 98% (49 of 50); on the table 100% | 98% (45 of 46); on the table 100% | 98% (94 of 96); on the table 100% |
| Winner chose to pursue after the loser fell back in good order |  | 88% (15 of 17); on the table 88% | 94% (15 of 16); on the table 94% | 91% (30 of 33); on the table 91% |
| Winner chose to pursue after the loser fled |  | 76% (29 of 38); on the table 76% | 82% (31 of 38); on the table 87% | 79% (60 of 76); on the table 82% |
| Winner chose to follow up or pursue (all three) |  | 89% (93 of 105); on the table 90% | 91% (91 of 100); on the table 94% | 90% (184 of 205); on the table 92% |
| Magic missiles tried each own turn | 50%+ | 22% (72 of 330) | 26% (54 of 210) | 23% (126 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 34% (72 of 214) | 40% (54 of 135) | 36% (126 of 349) |
| Points that never fought | lower | 39% (27873 of 71484) | 34% (24230 of 71889) | 36% (52103 of 143373) |
|   infantry points that never fought | lower | 54% (9184 of 16863) | 56% (7411 of 13348) | 55% (16595 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 51% (141 of 279) | 62% (182 of 295) | 56% (323 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 95% (21 of 22); 2.1 uses a game | 75% (15 of 20); 1.3 uses a game | 86% (36 of 42); 1.7 uses a game |
| Bound items with another spell used |  | 75% (12 of 16); 0.6 uses a game | 50% (4 of 8); 0.1 uses a game | 67% (16 of 24); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 58% (11 of 19); 0.3 uses a game | 58% (7 of 12); 0.2 uses a game | 58% (18 of 31); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 45% (26648 of 59666) | 55% (34494 of 62699) | 50% (61142 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 2.0 (28%) | 1.4 (33%) | 3.4 (30%) |
| MARCHED: its unit marched | 1.3 (18%) | 0.5 (12%) | 1.8 (16%) |
| CHARGED: its unit charged | 0.2 (3%) | 0.1 (3%) | 0.4 (3%) |
| IN COMBAT: engaged in combat | 1.8 (24%) | 0.8 (17%) | 2.5 (22%) |
| REAR RANK: in a rear rank | 0.3 (5%) | 0.1 (3%) | 0.5 (4%) |
| FLEEING: fleeing | 0.1 (1%) | 0.1 (3%) | 0.2 (2%) |
| GONE: slain | 1.1 (16%) | 1.2 (28%) | 2.3 (20%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (3%) | 0.0 (0%) | 0.2 (2%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.6 | 1.3 | 1.2 | 3.5 | 0.3 | 2.1 |
| not cast | 4.4 | 3.0 | 3.4 | 11.5 | 2.1 | 21.9 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.7 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.1 (37%) | 0.2 (7%) | 3.4 (30%) | 0.5 (23%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.8 (16%) | 0.4 (20%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.4 (3%) | 0.0 (1%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.0 (1%) | 0.4 (14%) | 0.5 (14%) | 2.5 (22%) | 0.7 (32%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (5%) | 0.4 (12%) | 0.5 (15%) | 0.5 (4%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.2 (2%) | 0.0 (0%) | 0.6 (3%) |
| GONE: slain | 1.5 (34%) | 0.6 (21%) | 0.9 (27%) | 2.3 (20%) | 0.3 (15%) | 4.9 (23%) |
| OFF THE TABLE: off the table or not arrived | 0.3 (7%) | 0.2 (6%) | 0.1 (2%) | 0.2 (2%) | 0.0 (0%) | 0.5 (2%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.1 (2%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (3%) | 0.0 (0%) | 0.0 (0%) | 0.2 (8%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.2 (49%) | 0.2 (6%) | 1.1 (33%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.0 (64%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.0 a game | 0.4 a game | 0.7 a game |
| stood (cast and not dispelled) | 53% (17 of 32) | 46% (6 of 13) | 51% (23 of 45) |
| the unit moved after it | 71% (12 of 17) | 67% (4 of 6) | 70% (16 of 23) |
| it charged on its next turn | 6% (1 of 17) | 0% (0 of 6) | 4% (1 of 23) |
| the enemy charged it first | 24% (4 of 17) | 17% (1 of 6) | 22% (5 of 23) |
| it fought by the end of its next turn | 24% (4 of 17) | 17% (1 of 6) | 22% (5 of 23) |
| it moved out of a charge the enemy had planned (not charged first) | 29% (5 of 17) | 17% (1 of 6) | 26% (6 of 23) |
| none of these (no charge, no fight, no charge escaped) | 41% (7 of 17) | 67% (4 of 6) | 48% (11 of 23) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 62% (562 of 909) | 56% (346 of 613) | 60% (908 of 1522) |
|   cavalry | 35% (27 of 77) | 60% (72 of 121) | 50% (99 of 198) |
|   character | 50% (49 of 98) | 39% (46 of 119) | 44% (95 of 217) |
|   chariot | 50% (47 of 94) | 80% (28 of 35) | 58% (75 of 129) |
|   infantry | 57% (180 of 315) | 58% (141 of 244) | 57% (321 of 559) |
|   monster | 58% (23 of 40) | 25% (6 of 24) | 45% (29 of 64) |
|   war machine | 83% (236 of 285) | 76% (53 of 70) | 81% (289 of 355) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.7 (28%) | 1.9 (26%) | 4.7 (27%) |
| CHARGED: it charged | 1.6 (17%) | 1.6 (21%) | 3.2 (19%) |
| FLEEING: it fled or was fleeing | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| IN COMBAT: it fought this turn or the last | 0.7 (7%) | 0.6 (8%) | 1.3 (7%) |
| FREE: none of these - no target in range or sight, or held its fire | 0.3 (3%) | 0.0 (0%) | 0.3 (2%) |
| NO TARGET IN RANGE | 1.3 (14%) | 1.0 (13%) | 2.3 (14%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (4%) | 0.6 (8%) | 0.9 (6%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.8 (18%) | 1.1 (15%) | 2.8 (17%) |
| SHELTERED: the target was sheltered | 0.4 (4%) | 0.5 (7%) | 0.9 (5%) |
| STUPIDITY | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR | 0.2 (2%) | 0.1 (1%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 3.9 | 1.1 | 78% | 5.6 pts | 22 pts |
| character | 2.8 | 0.8 | 76% | 7.2 pts | 20 pts |
| chariot | 2.1 | 1.2 | 66% | 11.4 pts | 24 pts |
| infantry | 13.0 | 4.6 | 74% | 8.9 pts | 116 pts |
| monster | 0.9 | 0.3 | 65% | 9.7 pts | 8 pts |
| war machine | 8.0 | 6.6 | 61% | 27.1 pts | 218 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.9 | 5.2 | 5.1 |
| Charges that made contact a game | 3.8 | 3.6 | 3.7 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.00 declared, 0.91 contact (22 units) | 0.62 declared, 0.44 contact (16 units) | 0.84 declared, 0.71 contact (38 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.20 declared, 0.80 contact (5 units) | 1.60 declared, 1.40 contact (10 units) | 1.47 declared, 1.20 contact (15 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.58 declared, 0.43 contact (259 units) | 0.57 declared, 0.38 contact (284 units) | 0.57 declared, 0.41 contact (543 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 50% (35 of 70) | 38% (8 of 21) | 25% (2 of 8) | 45% (45 of 99) |
| Character in a unit | 81% (30 of 37) | 75% (15 of 20) | 0% (0 of 1) | 78% (45 of 58) |
| Character on its own | 82% (41 of 50) | 65% (26 of 40) | 28% (18 of 65) | 55% (85 of 155) |
| Chariot | 81% (13 of 16) | 50% (5 of 10) | - | 69% (18 of 26) |
| Infantry | 54% (48 of 89) | 47% (17 of 36) | 0% (0 of 2) | 51% (65 of 127) |
| Monster | 56% (18 of 32) | 80% (8 of 10) | - | 62% (26 of 42) |
| Monstrous | 73% (8 of 11) | 29% (4 of 14) | - | 48% (12 of 25) |
| War Machines | 63% (26 of 41) | 100% (1 of 1) | - | 64% (27 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 89% (16 of 18); on the table 89% | 33% (45 of 138) | 56% | 58% (19 of 33) | 100% (9 of 9); 5.5 uses a game | 100% (3 of 3); 1.2 uses a game | 78% (7 of 9); 1.2 uses a game |
| Chaos Dwarfs | 3 | 73% (8 of 11); on the table 73% | 25% (6 of 24) | 43% | 33% (8 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |
| Dwarfen Mountain Holds | 5 | 82% (9 of 11); on the table 82% | - | 59% | 78% (32 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 88% (15 of 17); on the table 94% | 42% (15 of 36) | 53% | 52% (33 of 64) | 0.0 uses a game | 100% (2 of 2); 1.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 5 | 80% (12 of 15); on the table 80% | 8% (9 of 108) | 45% | 48% (21 of 44) | 92% (11 of 12); 9.2 uses a game | 100% (1 of 1); 0.4 uses a game | 40% (2 of 5); 0.4 uses a game |
| High Elf Realms | 6 | 100% (20 of 20); on the table 100% | 17% (5 of 30) | 28% | 47% (23 of 49) | 100% (5 of 5); 2.3 uses a game | 56% (10 of 18); 2.0 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (2 of 2); on the table 100% | - | 37% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 100% (4 of 4); on the table 100% | - | 31% | 57% (8 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 100% (6 of 6); on the table 100% | 0% (0 of 12) | 33% | 62% (13 of 21) | 67% (2 of 3); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (5 of 5); on the table 100% | 33% (12 of 36) | 6% | 50% (12 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 4 | 88% (7 of 8); on the table 88% | 20% (6 of 30) | 25% | 71% (24 of 34) | 100% (3 of 3); 0.8 uses a game | 0.0 uses a game | 75% (3 of 4); 0.8 uses a game |
| Tomb Kings of Khemri | 6 | 85% (22 of 26); on the table 92% | 0% (0 of 12) | 19% | 33% (10 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 85% (22 of 26); on the table 88% | 24% (13 of 54) | 27% | 54% (27 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 100% (19 of 19); on the table 100% | 30% (9 of 30) | 39% | 68% (50 of 74) | 100% (4 of 4); 1.6 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 100% (17 of 17); on the table 100% | 20% (6 of 30) | 31% | 61% (40 of 66) | 33% (2 of 6); 1.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ef2-opp-f5fe7c8-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 50% (38) | 51% (37) | 50% (75) |
| ...free all their last turn and able to turn (per game) | 0.75 | 0.72 | 1.47 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.14 | 0.11 | 0.25 |
| ...with the charger already in that arc before they moved (per game) | 0.56 | 0.44 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.08 | 0.75 | 1.83 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.81 | 0.61 | 1.42 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 7.72 | 7.97 | 15.69 |

### Quality by phase: ef2-opp-f5fe7c8-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 54% (85 of 156) | 46% (69 of 151) |
| Strategy | Shoot objectives carried out (shot that target) | 51% (182 of 359) | 63% (97 of 154) |
| Strategy | Close-in objectives charged next turn | 15% (23 of 151) | 12% (24 of 199) |
| Strategy | Support requests answered (helper made contact too) | 62% (13 of 21) | 44% (8 of 18) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 67% (2 of 3) | 60% (3 of 5) |
| Strategy | Hexes on a unit its side charged or shot that turn | 47% (7 of 15) | 33% (1 of 3) |
| Strategy | Joined characters whose unit fought | 30% (14 of 47) | 41% (16 of 39) |
| Strategy | Lone characters that fought | 85% (84 of 99) | 76% (74 of 97) |
| Movement | Charges halted short of contact | 0.2 | 0.1 |
| Movement | Idle units | 1.2 | 1.7 |
| Movement | Points that never moved of their own | 334.6 | 172.7 |
| Movement | Fights charged into per game | 3.1 | 3.1 |
| Movement | Charges with odds: long shots (under 50%) | 9 of 103, net +181 | 11 of 91, net +122 |
| Movement | Charges with odds: sweet spot (55-75%) | 18 of 103, net +97 | 14 of 91, net +123 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 19 of 103, net +93 | 10 of 91, net +73 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 33 of 103, net +129 | 23 of 91, net +133 |
| Shooting | Shots by shooting units (incl. breath weapons) | 10.0 | 9.0 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 42% (150 of 360) | 40% (131 of 324) |
| Shooting | Points destroyed by shooting units | 94.3 | 28.3 |
| Shooting | War machine shots | 6.6 | 1.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 55% (129 of 236) | 28% (15 of 53) |
| Shooting | Points destroyed by war machines | 84.8 | 28.8 |
| Magic | Magic missiles cast | 1.4 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 21% (11 of 52) | 44% (16 of 36) |
| Magic | Wounds caused by magic missiles | 4.4 | 1.5 |
| Magic | Wounds caused by other spells | 2.0 | 0.8 |
| Magic | Points destroyed by magic (all spells) | 97.1 | 6.9 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.5 / 0.8 / 0.1 | 1.4 / 0.2 / 0.6 / 0.1 |
| Combat | Points destroyed in combat | 429.3 | 394.8 |
| Combat | Points run down | 80.4 | 136.5 |
| Combat | Net points per charged fight, damage counted | +105 | +110 |
| Combat | Net per 100 charger points, damage counted | +35.4 | +40.0 |
| Combat | First round won (charged fights) | 65% | 62% |
| Combat | Net points per charged fight | +104 | +119 |
| Combat | Net points per supported fight / lone fight | +164 / +89 | +239 / +97 |
| Combat | Charged fights on a top-3 enemy unit | 42 of 113 | 45 of 112 |
| Game | Points lost | 740.8 | 852.0 |
| Game | VP from objectives | 704.4 | 570.0 |
| Game | Lone holders (player turns) | 2.6 | 1.8 |

- Mine won / drew / lost: 18 / 6 / 12 of 36 ended games (of 36); mean margin (Mine - Opponent) +224 VP
- The side that went first won 13 of 30 games with a winner
- Points traded per game (both sides' losses): 1593
- Games not ended: 0; findings 1, warnings 1

### Opponent rules: ef2-opp-f5fe7c8-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 3.5 |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.3 | +0.0 | 0.0 | 9.0 | 0.4 | +0.0 | 0.0 | 0.0 |
| BACKUP TARGETS | 0.7 | +5.6 | 0.0 | 25.2 | 1.1 | +10.8 | 0.0 | 37.0 |
| BEST PREY | 4.2 | +257.1 | 157.8 | 178.6 | 4.3 | +252.0 | 177.7 | 127.2 |
| BEST PRIZE | 0.1 | -4.4 | 6.9 | 11.1 | 0.0 | -7.2 | 2.1 | 13.9 |
| BLOCKED CHARGE HANDED OVER | 0.0 | +1.4 | 4.8 | 0.0 | - | - | - | - |
| BLOCKED CHARGE SKIPPED | 0.2 | +0.0 | 32.1 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.5 | +8.9 | 0.0 | 3.2 | 0.3 | +26.3 | 0.0 | 11.6 |
| CANNON PLAN MISSED | 0.9 | +0.0 | 101.8 | 12.9 | 0.1 | +0.0 | 19.0 | 7.2 |
| CANNON PLANNED TARGET | 4.9 | +163.0 | 322.5 | 75.1 | 1.2 | +34.0 | 91.1 | 9.9 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | -0.2 | 1.9 | 0.0 | 0.0 | +0.0 | 0.0 | 3.1 |
| CARRIES OUT SET-UP | 0.1 | -3.2 | 24.5 | 5.2 | 0.1 | +0.0 | 9.3 | 0.0 |
| CAST JOB | 0.9 | +26.8 | 84.8 | 25.5 | 0.4 | +5.5 | 31.1 | 0.0 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +55.3 | 20.7 | 29.5 | 0.2 | +3.0 | 0.0 | 0.0 |
| CASTS AFTER FRIENDS | 0.5 | +0.0 | 0.0 | 61.8 | 0.2 | +0.0 | 0.0 | 27.8 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +0.8 | 0.0 | 6.6 | - | - | - | - |
| CHAFF PASSED | 0.1 | -0.0 | 0.0 | 3.8 | 0.2 | -0.3 | 12.7 | 0.0 |
| CHAMPION TAKES THE CHALLENGE | 0.0 | +5.4 | 5.1 | 0.0 | 0.0 | +0.4 | 8.0 | 0.0 |
| CHARGE NOW WEIGHED | 0.4 | -23.6 | 19.9 | 12.4 | 0.6 | -48.0 | 19.6 | 51.0 |
| CHARIOT NO STATIC JOB | 1.0 | +0.0 | 4.1 | 7.8 | 0.5 | +0.0 | 0.0 | 12.8 |
| CHEAP HELPER | 0.2 | +0.0 | 18.3 | 2.4 | 0.0 | +0.0 | 7.4 | 0.0 |
| CONTINUE AHEAD WEIGHED | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CONVEYANCE SEARCH | 0.4 | +31.8 | 39.9 | 42.1 | 0.3 | +107.4 | 15.5 | 18.7 |
| COUNTER-CHARGE COVER | 8.6 | +708.2 | 0.0 | 191.8 | 5.2 | +247.1 | 0.0 | 166.8 |
| EDGE GIVE GROUND | 0.1 | +11.1 | 16.7 | 0.0 | 0.0 | +1.8 | 0.0 | 0.0 |
| ELIXIR WORTH | 0.0 | +0.3 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| ENEMY FORECAST | - | - | - | - | 6.9 | +162.3 | 109.8 | 188.1 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.1 | +94.1 | 0.0 | 53.0 | 0.8 | +48.2 | 0.0 | 51.4 |
| FALLBACK BY WORTH | 6.4 | +87.4 | 0.0 | 104.1 | 7.4 | +99.5 | 0.0 | 94.5 |
| FIRE AND FLEE | 0.0 | +0.6 | 0.0 | 3.1 | 0.1 | +0.9 | 9.6 | 3.2 |
| FLANK NOT WEIGHED | 0.3 | +0.0 | 0.0 | 6.8 | 0.2 | +0.0 | 0.0 | 7.1 |
| FOCUS FIRE | 0.0 | +2.5 | 0.0 | 1.7 | 0.0 | +0.5 | 1.5 | 0.0 |
| FOLLOW UP WEIGHED | 1.2 | +136.6 | 0.0 | 73.2 | 0.9 | +174.3 | 0.0 | 36.6 |
| FORECAST RESULT | 40.2 | +2056.7 | 581.2 | 1154.2 | 41.9 | +2439.6 | 1297.7 | 1064.8 |
| FRIENDS SHOTS CHECKED | 0.4 | +25.1 | 0.0 | 7.8 | 0.1 | +14.6 | 0.0 | 1.8 |
| GIVES UP | 1.3 | -33.0 | 217.1 | 32.5 | 1.4 | -44.1 | 182.3 | 48.5 |
| GIVES UP ITS SCREEN | 0.8 | -17.6 | 48.4 | 11.9 | 0.9 | -14.1 | 111.2 | 12.9 |
| GROUND FLIERS | 0.0 | +0.5 | 0.0 | 0.0 | - | - | - | - |
| HELPER ALREADY ASKED | 0.1 | +0.0 | 19.0 | 1.8 | 0.0 | +0.0 | 0.0 | 3.2 |
| HELPER UNSEEN | 0.2 | +0.0 | 26.8 | 6.6 | 0.2 | +0.0 | 25.1 | 17.1 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +6.0 | 0.0 | 2.9 |
| HUNT DROPPED | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 3.6 | 0.0 |
| HUNT IN PAIRS | 0.3 | +26.3 | 0.0 | 5.7 | 0.5 | +24.9 | 0.0 | 10.5 |
| HUNT RESULT | 0.1 | +11.4 | 10.5 | 0.0 | 0.2 | +15.7 | 7.9 | 4.7 |
| HUNT THE GUNS | 0.1 | +24.1 | 0.0 | 0.0 | 0.2 | +57.3 | 19.1 | 4.7 |
| JOINT CHARGE PLAN | 0.0 | +0.2 | 0.0 | 0.0 | 0.2 | +15.2 | 0.0 | 0.0 |
| KEEP FALLS | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.2 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.3 | +2.0 | 14.8 | 0.0 | 0.3 | +3.5 | 5.1 | 36.4 |
| KEEPS ITS TARGET | 1.9 | +56.7 | 216.4 | 37.4 | 2.1 | +62.5 | 189.7 | 48.1 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.8 | +71.3 | 127.7 | 59.8 | 1.8 | +62.3 | 149.2 | 35.7 |
| KILLS COUNT NEXT TURN | 8.1 | +315.5 | 396.0 | 254.5 | 10.1 | +469.7 | 497.8 | 327.4 |
| LONE CHARACTER SAFE SPOT | 0.2 | +20.5 | 6.6 | 0.0 | 0.5 | +7.2 | 0.0 | 18.2 |
| LONE WIZARD HOLDS BACK | 0.6 | +0.0 | 17.2 | 49.0 | 0.8 | +0.0 | 68.4 | 47.8 |
| LONE WIZARD KEPT IN | 0.7 | +49.1 | 0.0 | 0.0 | 0.2 | +24.5 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.6 | +35.8 | 0.0 | 14.1 | 0.6 | +56.1 | 42.7 | 17.1 |
| MANOEUVRE | 0.3 | +12.1 | 0.0 | 4.2 | 0.1 | +2.0 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +0.7 | 0.0 | 0.0 | 0.2 | +1.5 | 0.0 | 1.7 |
| MARCH CHECK | 0.8 | +48.2 | 0.0 | 10.6 | 0.7 | +22.1 | 0.0 | 6.4 |
| MARCH ODDS | 0.8 | +60.5 | 64.5 | 5.7 | 0.7 | +37.2 | 19.9 | 30.3 |
| MARCH OVER CASTS | 1.1 | +11.3 | 0.0 | 22.6 | 1.0 | -20.6 | 0.0 | 26.2 |
| MAX FOR POSITIONING | 4.9 | +216.3 | 0.0 | 93.1 | 4.7 | +121.8 | 0.0 | 132.5 |
| MISSILES IN THE MOVE | 3.1 | +138.6 | 0.0 | 100.5 | 2.6 | +34.9 | 0.0 | 89.1 |
| MISSILES NEXT TURN | 4.5 | +107.9 | 0.0 | 152.1 | 3.9 | +32.7 | 0.0 | 138.6 |
| MODEL FACING | 0.1 | +22.1 | 0.0 | 1.7 | - | - | - | - |
| MOVE AND CAST | 0.3 | +13.0 | 0.0 | 4.3 | 0.1 | +10.4 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.1 | +4.5 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.4 | -94.7 | 0.0 | 16.0 | - | - | - | - |
| MOVE SPELL SPOT | 0.2 | +0.0 | 0.0 | 11.1 | 0.1 | +0.0 | 0.0 | 11.1 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NEEDED THERE | 0.0 | +0.0 | 0.0 | 0.0 | 0.0 | +0.0 | 10.2 | 0.0 |
| NO RALLY LEFT | 0.0 | +0.4 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 4.2 |
| NOT NEEDED | 0.4 | -18.0 | 44.5 | 3.5 | 0.3 | -14.4 | 53.6 | 0.0 |
| NOT TURNED | 7.7 | +170.4 | 0.0 | 209.6 | 8.0 | +111.7 | 0.0 | 163.6 |
| NOT WORTH A CAST | 1.0 | -0.8 | 0.0 | 46.8 | 0.3 | -0.3 | 0.0 | 0.0 |
| OPENS A LANE | 0.1 | +0.4 | 11.6 | 0.0 | 0.1 | +0.1 | 5.1 | 0.0 |
| OPENS UP | 0.2 | +28.7 | 21.5 | 0.0 | 0.2 | +12.9 | 8.1 | 0.0 |
| OVERRUNS AWAY | 0.7 | +30.3 | 94.7 | 19.0 | 0.3 | +6.9 | 36.1 | 7.9 |
| PATHS CROSS | 2.5 | +174.1 | 0.0 | 32.0 | 2.9 | +181.4 | 0.0 | 45.4 |
| PERIAPT WORTH | 0.0 | +1.7 | 0.0 | 15.0 | 0.1 | +5.6 | 0.0 | 15.0 |
| PLAN LEADS | 1.1 | +93.2 | 35.7 | 8.9 | 1.2 | +129.4 | 36.4 | 3.5 |
| PLAN RESULT | 38.3 | +1667.0 | 1472.3 | 1018.5 | 37.9 | +1155.8 | 1408.8 | 1141.1 |
| PURSUES BIG PREY | 0.1 | -4.4 | 0.0 | 0.0 | 0.2 | -15.6 | 0.0 | 13.9 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.0 | +6.6 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +4.9 | 0.0 | 0.0 | 0.1 | +8.2 | 0.0 | 4.2 |
| REDIRECT COUNTER | 3.5 | +162.4 | 0.0 | 20.4 | 4.4 | +203.8 | 0.0 | 85.1 |
| REDIRECT WEIGHED | 0.1 | +1.1 | 8.3 | 11.1 | 0.3 | -0.9 | 10.8 | 30.7 |
| RESTRAINS TO SHOOT | 0.1 | +1.9 | 0.0 | 7.2 | 0.1 | +5.0 | 0.0 | 0.0 |
| RISK BY ARC | 3.0 | +88.0 | 362.2 | 92.1 | 2.2 | +44.2 | 248.5 | 59.8 |
| SAFER THAN THE JOB | 0.8 | +51.8 | 0.0 | 26.4 | 0.6 | +23.8 | 0.0 | 35.8 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.0 | 0.3 | +0.5 | 0.0 | 1.9 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 1.9 |
| SEARCH SPOT | 1.6 | +74.6 | 0.0 | 53.9 | 1.9 | +108.6 | 0.0 | 29.3 |
| SELF MOVE SPELL | 0.2 | +19.1 | 0.0 | 20.0 | 0.3 | +5.1 | 0.0 | 18.1 |
| SET UP TOGETHER | 0.7 | +48.0 | 0.0 | 14.1 | 2.2 | +122.3 | 65.7 | 50.6 |
| SET-UP ANY TARGET | 0.2 | +20.3 | 21.3 | 21.0 | 0.2 | +36.7 | 15.5 | 18.7 |
| SET-UP MISSED | 0.0 | +1.2 | 0.0 | 0.0 | 0.1 | +15.5 | 0.0 | 0.0 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.2 | +0.6 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.3 | 0.0 | +0.0 | 0.0 | 3.8 |
| SHOT REPLANNED | 0.6 | +0.0 | 119.8 | 10.2 | 0.2 | +0.0 | 47.6 | 4.5 |
| SHOTS IN THE MOVE | 13.7 | +557.4 | 0.0 | 202.0 | 8.4 | +163.6 | 0.0 | 141.5 |
| SPELL SETS UP CHARGE | 0.2 | +20.3 | 21.3 | 21.0 | 0.2 | +95.5 | 15.5 | 18.7 |
| SPELL WORTH | 0.9 | +19.8 | 146.1 | 144.4 | 1.5 | +31.3 | 74.8 | 81.3 |
| STANDS TO CAST | 0.1 | +4.1 | 12.4 | 15.0 | - | - | - | - |
| STOPS | 0.0 | +0.0 | 0.0 | 0.0 | 0.1 | +0.3 | 19.1 | 1.8 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 5.8 | 0.2 | +0.0 | 0.0 | 8.8 |
| SUPPORT JOB KEPT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| SURE CHARGE BEATS ADVANCE | 0.2 | -10.1 | 5.9 | 9.6 | 0.3 | -11.8 | 30.8 | 1.9 |
| SURE REACH TOGETHER | 0.4 | -3.3 | 0.0 | 6.9 | 0.8 | +5.8 | 23.0 | 47.8 |
| THROUGH LINE OF FIRE | 0.6 | +23.5 | 0.0 | 26.6 | 0.2 | +8.4 | 0.0 | 0.0 |
| TURN WORTH | 0.5 | -35.7 | 32.2 | 14.0 | 0.4 | -24.8 | 39.0 | 0.0 |
| TWO OR MORE ARRIVE | 0.3 | +4.5 | 0.0 | 6.5 | 0.4 | +2.8 | 6.5 | 6.5 |
| WEARS DOWN | 1.3 | +75.5 | 221.7 | 34.5 | 0.9 | +30.3 | 141.1 | 17.4 |
| WHO HITS BACK | 0.2 | +28.7 | 0.0 | 16.1 | 0.1 | +6.4 | 0.0 | 8.2 |
| WHOLE FIGHT | 0.4 | +35.2 | 45.2 | 14.2 | 0.4 | +49.7 | 119.8 | 1.2 |
| WHOLE FIGHT GAIN | 0.5 | +30.0 | 52.1 | 8.1 | 0.4 | +49.3 | 49.4 | 9.8 |

### Rule changes: ef2-opp-f5fe7c8-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| PATHS CROSS | 196 | 196 | 196 | 5.44 | +12799 | +65.3 |
| KILLS COUNT NEXT TURN | 656 | 643 | 189 | 5.25 | +7835 | +41.5 |
| FALLBACK BY WORTH | 498 | 498 | 141 | 3.92 | +6731 | +47.7 |
| BEST PREY | 305 | 297 | 131 | 3.64 | +5208 | +39.8 |
| SEARCH SPOT | 129 | 129 | 125 | 3.47 | +6623 | +53.0 |
| COUNTER-CHARGE COVER | 496 | 243 | 106 | 2.94 | +4820 | +45.5 |
| FOLLOW UP WEIGHED | 76 | 76 | 76 | 2.11 | +11192 | +147.3 |
| FACES THE THREAT | 66 | 66 | 66 | 1.83 | +5121 | +77.6 |
| SHOTS IN THE MOVE | 795 | 483 | 63 | 1.75 | +1561 | +24.8 |
| ARTILLERY RE-ROLL WEIGHED | 62 | 62 | 62 | 1.72 | +0 | +0.0 |
| MAX FOR POSITIONING | 347 | 188 | 61 | 1.69 | +494 | +8.1 |
| SAFER THAN THE JOB | 51 | 51 | 51 | 1.42 | +2723 | +53.4 |
| CANNON PLANNED TARGET | 219 | 219 | 48 | 1.33 | -421 | -8.8 |
| ADVANCE LANE KEPT | 47 | 47 | 47 | 1.31 | +0 | +0.0 |
| CANNON SIGHT KEPT | 47 | 47 | 47 | 1.31 | +0 | +0.0 |
| MARCH ODDS | 52 | 52 | 46 | 1.28 | +808 | +17.6 |
| REDIRECT COUNTER | 286 | 107 | 45 | 1.25 | +1996 | +44.3 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| RISK BY ARC | 190 | 176 | 43 | 1.19 | +1055 | +24.5 |
| ENEMY FORECAST | 250 | 248 | 40 | 1.11 | +271 | +6.8 |
| SET UP TOGETHER | 105 | 85 | 39 | 1.08 | +1942 | +49.8 |
| PLAN LEADS | 83 | 83 | 37 | 1.03 | +2275 | +61.5 |
| CHARIOT NO STATIC JOB | 56 | 56 | 36 | 1.00 | -3311 | -92.0 |
| CHARGE NOW WEIGHED | 34 | 34 | 34 | 0.94 | +674 | +19.8 |
| LONE WIZARD KEPT IN | 34 | 34 | 34 | 0.94 | +2648 | +77.9 |
| KEEPS ITS TARGET | 143 | 141 | 33 | 0.92 | +579 | +17.5 |
| BLOCKED WHEEL | 30 | 30 | 30 | 0.83 | +1267 | +42.2 |
| CAST JOB | 45 | 45 | 30 | 0.83 | +535 | +17.8 |
| KILLS COUNT | 129 | 121 | 30 | 0.83 | +1176 | +39.2 |
| MARCH CHECK | 53 | 32 | 30 | 0.83 | +770 | +25.7 |
| SHOT REPLANNED | 29 | 29 | 29 | 0.81 | +0 | +0.0 |
| THROUGH LINE OF FIRE | 28 | 28 | 28 | 0.78 | +1149 | +41.0 |
| MISSILES IN THE MOVE | 205 | 108 | 27 | 0.75 | +1042 | +38.6 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| SHOOTERS IN TWO RANKS | 23 | 23 | 23 | 0.64 | +53 | +2.3 |
| CASTING BLOCK | 24 | 24 | 21 | 0.58 | +1099 | +52.3 |
| WEARS DOWN | 81 | 76 | 21 | 0.58 | +568 | +27.0 |
| CASTER AWAY FROM SCREEN | 19 | 19 | 19 | 0.53 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 19 | 19 | 19 | 0.53 | +1430 | +75.3 |
| LONE WIZARD HOLDS BACK | 48 | 48 | 17 | 0.47 | -767 | -45.1 |
| SURE CHARGE BEATS ADVANCE | 17 | 17 | 17 | 0.47 | -789 | -46.4 |
| MOVE AND CAST | 15 | 15 | 15 | 0.42 | +841 | +56.1 |
| REDIRECT WEIGHED | 15 | 15 | 15 | 0.42 | +830 | +55.3 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| WHO HITS BACK | 14 | 14 | 14 | 0.39 | -974 | -69.5 |
| WHOLE FIGHT GAIN | 33 | 27 | 14 | 0.39 | +499 | +35.6 |
| MAKE SURE TOGETHER | 44 | 24 | 13 | 0.36 | +858 | +66.0 |
| MANOEUVRE | 13 | 13 | 12 | 0.33 | +509 | +42.4 |
| BLOCKED CHARGE SKIPPED | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| CHAFF PASSED | 10 | 10 | 10 | 0.28 | -11 | -1.1 |
| MISSILES NEXT TURN | 302 | 154 | 10 | 0.28 | +45 | +4.5 |
| STUCK PIVOT | 10 | 10 | 10 | 0.28 | +0 | +0.0 |
| PURSUES BIG PREY | 9 | 9 | 9 | 0.25 | -720 | -80.0 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| OPENS UP | 17 | 16 | 7 | 0.19 | +226 | +32.3 |
| OVERRUNS AWAY | 38 | 34 | 7 | 0.19 | +192 | +27.4 |
| RESTRAINS TO SHOOT | 7 | 7 | 7 | 0.19 | +248 | +35.5 |
| SURE REACH TOGETHER | 44 | 35 | 7 | 0.19 | +118 | +16.9 |
| WHOLE FIGHT | 28 | 27 | 7 | 0.19 | +1227 | +175.3 |
| BACKUP TARGETS | 65 | 29 | 6 | 0.17 | +28 | +4.6 |
| HUNT IN PAIRS | 27 | 15 | 6 | 0.17 | +486 | +81.0 |
| JOINT CHARGE PLAN | 7 | 7 | 5 | 0.14 | +187 | +37.4 |
| RAIDS THE BAGGAGE NEXT TURN | 5 | 5 | 5 | 0.14 | +211 | +42.2 |
| FIRE AND FLEE | 4 | 4 | 4 | 0.11 | +53 | +13.2 |
| MODEL FACING | 4 | 4 | 4 | 0.11 | +796 | +198.9 |
| BEST PRIZE | 3 | 3 | 3 | 0.08 | -415 | -138.4 |
| KEEP FALLS | 3 | 3 | 3 | 0.08 | +17 | +5.6 |
| PERIAPT WORTH | 3 | 3 | 3 | 0.08 | +263 | +87.7 |
| STANDS TO CAST | 3 | 3 | 3 | 0.08 | +53 | +17.8 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +14 | +7.2 |
| FOCUS FIRE | 2 | 2 | 2 | 0.06 | +105 | +52.6 |
| GIVES UP | 100 | 97 | 2 | 0.06 | +42 | +20.8 |
| HUNT ADVANCE | 4 | 4 | 2 | 0.06 | +55 | +27.3 |
| KEEPS ITS PREY | 21 | 19 | 2 | 0.06 | +36 | +18.1 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +4 | +1.8 |
| BLOCKED CHARGE HANDED OVER | 1 | 1 | 1 | 0.03 | +50 | +50.0 |
| CARRIES OUT COUNTER | 2 | 2 | 1 | 0.03 | -7 | -7.2 |
| CARRIES OUT SET-UP | 6 | 6 | 1 | 0.03 | -113 | -113.4 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| EDGE GIVE GROUND | 6 | 6 | 1 | 0.03 | +95 | +95.2 |
| RAIDS THE BAGGAGE | 1 | 1 | 1 | 0.03 | +191 | +191.4 |
| STOPS | 4 | 4 | 1 | 0.03 | +5 | +4.6 |
| SUPPORT JOB KEPT | 1 | 1 | 1 | 0.03 | -24 | -24.5 |
| TWO OR MORE ARRIVE | 26 | 24 | 1 | 0.03 | +20 | +19.6 |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 38 | 38 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 27 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 2 | 2 | 0 | 0.00 | - | - |
| CHEAP HELPER | 10 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 26 | not checked | - | - | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 19 | not checked | - | - | - | - |
| FORECAST RESULT | 2956 | trace | - | - | - | - |
| GIVES UP ITS SCREEN | 59 | 56 | 0 | 0.00 | - | - |
| GROUND FLIERS | 1 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 4 | not checked | - | - | - | - |
| HELPER UNSEEN | 17 | 16 | 0 | 0.00 | - | - |
| HUNT DROPPED | 3 | trace | - | - | - | - |
| HUNT RESULT | 8 | trace | - | - | - | - |
| HUNT THE GUNS | 8 | trace | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 27 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 9 | trace | - | - | - | - |
| MARCH OVER CASTS | 77 | 77 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 5 | 3 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 15 | trace | - | - | - | - |
| MOVE SPELL SPOT | 10 | not checked | - | - | - | - |
| NEEDED THERE | 2 | 2 | 0 | 0.00 | - | - |
| NOT NEEDED | 25 | 25 | 0 | 0.00 | - | - |
| NOT TURNED | 565 | 565 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 48 | not checked | - | - | - | - |
| OPENS A LANE | 5 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 2744 | trace | - | - | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 16 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 13 | not checked | - | - | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SPELL SETS UP CHARGE | 15 | not checked | - | - | - | - |
| SPELL WORTH | 88 | not checked | - | - | - | - |
| TURN WORTH | 30 | 28 | 0 | 0.00 | - | - |

### Plans: ef2-opp-f5fe7c8-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.7 | 18% | 568 | 387 | 68% |
| Mine | charge | 3.6 | 62% | 400 | 374 | 93% |
| Mine | close in | 4.2 | 33% | 310 | 213 | 69% |
| Mine | hold | 4.7 | 43% | 296 | 0 | 0% |
| Mine | join | 0.5 | 88% | 15 | 0 | 0% |
| Mine | shoot | 8.4 | 67% | 314 | 693 | 220% |
| Mine | support | 4.2 | 90% | 190 | 0 | 0% |
| Opponent | advance | 13.3 | 18% | 733 | 405 | 55% |
| Opponent | charge | 3.5 | 62% | 395 | 364 | 92% |
| Opponent | close in | 5.4 | 19% | 428 | 158 | 37% |
| Opponent | hold | 3.8 | 46% | 286 | 0 | 0% |
| Opponent | join | 1.2 | 95% | 44 | 0 | 0% |
| Opponent | shoot | 3.6 | 68% | 76 | 232 | 306% |
| Opponent | support | 7.1 | 91% | 372 | 0 | 0% |

### Enemy forecast: ef2-opp-f5fe7c8-p1

Per side (the computer that made the forecast) and expected action: forecasts a game, right (it did the expected action on the expected target), gone (missed, but the target or the enemy was gone before it acted), and what the enemy did instead; right of judged leaves the gone ones out.

| Side | Expected | A game | Right | Gone | Right of judged | Did charge | Did shoot | Did move | Same target |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.4 | 50% | 15% | 59% | 57% | 8% | 35% | 51% |
| Mine | shoot | 7.3 | 29% | 19% | 36% | 2% | 63% | 35% | 30% |
| Mine | move | 29.5 | 76% | 2% | 77% | 8% | 17% | 76% | - |
| Mine | all | 40.2 | 65% | 6% | 70% | 11% | 24% | 65% | - |
| Opponent | charge | 3.0 | 58% | 11% | 66% | 66% | 12% | 22% | 60% |
| Opponent | shoot | 14.7 | 34% | 23% | 44% | 2% | 67% | 32% | 35% |
| Opponent | move | 24.2 | 69% | 4% | 72% | 9% | 22% | 69% | - |
| Opponent | all | 41.9 | 56% | 11% | 63% | 10% | 37% | 53% | - |

Expected moves (the enemy's own plan): how far the expected end was from where the unit ended, against the guess that it stays where it stood.

| Side | Moves a game | Median miss | Median miss if it stays | Within 3" | Within 6" | Better than stays |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | 20.7 | 6.6" | 4.3" | 22% | 46% | 20% |
| Opponent | 15.9 | 6.3" | 4.0" | 22% | 48% | 23% |

### Packages: hunt the guns, ef2-opp-f5fe7c8-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 2 | 0 | 50% | 50% | 0% | 2.0 | 434 | 205 | 50% | 29 |
| Opponent | 0.2 | 6 | 0 | 33% | 33% | 0% | 2.0 | 344 | 94 | 33% | 109 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 228 |
| Dwarfen Mountain Holds | 0.4 | 2 | 0 | 50% | 50% | 0% | 2.0 | 434 | 205 | 50% | 70 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 67 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 84 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 495 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 98 |
| Tomb Kings of Khemri | 0.5 | 3 | 0 | 33% | 33% | 0% | 2.0 | 200 | 45 | 33% | 32 |
| Vampire Counts | 0.1 | 1 | 0 | 100% | 100% | 0% | 2.0 | 447 | 430 | 100% | 36 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 685 | 0 | 0% | 154 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 329 | 0 | 0% | 3 |

### Battle groups: ef2-opp-f5fe7c8-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 8.6 | 24% | 43% | 14% | 50% | 38% | 14% | 9% | 39% | 0% |
| Mine | REDIRECT COUNTER | 3.5 | 24% | 47% | 13% | 0% | 19% | 0% | 4% | 77% | 0% |
| Opponent | COUNTER-CHARGE COVER | 5.2 | 26% | 69% | 18% | 11% | 35% | 10% | 10% | 45% | 0% |
| Opponent | REDIRECT COUNTER | 4.4 | 23% | 65% | 16% | 0% | 26% | 0% | 10% | 55% | 10% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ef2-opp-f5fe7c8-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 27 (3) | 27 | 0 | 19 | 33% | 5.0 | 0 (1) | 49 (2) | - | 73 (1) | 0 (2) |
| Mine | Chaff | 45 | 38 (45) | 25 | 13 | 47 | 42% | 2.7 | 22 (16) | 25 (8) | 56 (21) | 28 (30) | 56 (15) |
| Mine | Character | 124 | 56 (124) | 56 | 0 | 47 | 15% | 2.3 | 68 (29) | 66 (63) | 11 (10) | 73 (65) | 47 (37) |
| Mine | Clean-up | 20 | 92 (20) | 37 | 55 | 16 | 30% | 4.3 | 82 (10) | 111 (8) | 38 (2) | 123 (11) | 52 (9) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 0 | 0% | 3.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast Hammer | 40 | 59 (40) | 39 | 20 | 25 | 35% | 3.0 | 75 (21) | 75 (6) | 27 (13) | 62 (30) | 54 (10) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 40 | 0% | 2.8 | - | 0 (5) | - | 0 (1) | 0 (4) |
| Mine | Hammer | 56 | 38 (56) | 21 | 17 | 55 | 23% | 2.2 | 53 (10) | 34 (36) | 41 (10) | 44 (37) | 27 (19) |
| Mine | Holder | 26 | 79 (26) | 10 | 69 | 15 | 46% | 3.1 | 55 (10) | 95 (11) | 93 (5) | 74 (14) | 85 (12) |
| Mine | Shooter | 45 | 90 (45) | 32 | 58 | 33 | 2% | 1.7 | 54 (7) | 89 (31) | 141 (7) | 90 (26) | 90 (19) |
| Mine | Support | 5 | 0 (5) | 0 | 0 | 42 | 40% | 2.0 | - | 0 (2) | 0 (3) | 0 (4) | 0 (1) |
| Mine | War machine | 56 | 60 (56) | 60 | 0 | 41 | 4% | 1.2 | 85 (13) | 53 (38) | 47 (5) | 46 (10) | 63 (46) |
| Mine | Wizard | 22 | 84 (22) | 84 | 0 | 37 | 14% | 2.5 | 17 (8) | 176 (9) | 30 (2) | 97 (7) | 87 (12) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 81 | 52 (81) | 13 | 39 | 52 | 38% | 2.9 | 76 (29) | 63 (21) | 20 (31) | 70 (56) | 6 (25) |
| Opponent | Character | 113 | 51 (113) | 51 | 0 | 42 | 25% | 2.4 | 76 (40) | 43 (52) | 24 (7) | 61 (68) | 45 (31) |
| Opponent | Clean-up | 12 | 41 (12) | 39 | 1 | 56 | 8% | 2.5 | 69 (5) | 18 (7) | - | 49 (9) | 12 (3) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 53 | 41 (53) | 21 | 19 | 57 | 26% | 3.2 | 24 (23) | 43 (15) | 71 (15) | 42 (38) | 37 (15) |
| Opponent | Fragile | 9 | 73 (9) | 73 | 0 | 87 | 22% | 2.7 | 0 (1) | 0 (2) | 0 (3) | 0 (5) | 0 (1) |
| Opponent | Hammer | 63 | 48 (63) | 40 | 7 | 48 | 21% | 2.9 | 46 (20) | 38 (38) | 142 (5) | 46 (37) | 50 (26) |
| Opponent | Holder | 35 | 39 (35) | 2 | 37 | 21 | 60% | 3.3 | 6 (4) | 55 (25) | 0 (4) | 76 (11) | 23 (22) |
| Opponent | Shooter | 31 | 55 (31) | 19 | 37 | 50 | 6% | 1.4 | 67 (7) | 62 (19) | 9 (5) | 64 (17) | 42 (14) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 50% | 6.0 | 0 (1) | 0 (1) | - | - | 0 (2) |
| Opponent | War machine | 13 | 71 (13) | 71 | 0 | 27 | 8% | 1.8 | 240 (3) | 28 (7) | 34 (3) | 0 (2) | 82 (11) |
| Opponent | Wizard | 24 | 21 (24) | 21 | 0 | 47 | 12% | 2.2 | 24 (7) | 26 (7) | 13 (6) | 24 (10) | 19 (10) |

### Charged fights: ef2-opp-f5fe7c8-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 233 | 141 | 2.4 | 1.2 | 59 | 27 | +32 | 4 of 12 | 8 of 12 | -46 | +58 |
| Mine | Chaos Dwarfs | 3 | 145 | 931 | 4.7 | 1.4 | 199 | 7 | +193 | 8 of 14 | 9 of 14 | +235 | +169 |
| Mine | Dwarfen Mountain Holds | 4 | 446 | 0 | 1.8 | 1.1 | 0 | 51 | -51 | 3 of 7 | 3 of 7 | -60 | -50 |
| Mine | Empire of Man | 5 | 754 | 230 | 2.4 | 1.2 | 96 | 54 | +41 | 1 of 12 | 6 of 12 | +86 | +32 |
| Mine | Grand Cathay | 4 | 382 | 520 | 3.0 | 1.2 | 173 | 0 | +173 | 8 of 12 | 8 of 12 | +442 | +120 |
| Mine | High Elf Realms | 4 | 135 | 557 | 3.5 | 1.3 | 159 | 42 | +117 | 4 of 14 | 9 of 14 | +339 | +57 |
| Mine | Kingdom of Bretonnia | 1 | 45 | 1431 | 6.0 | 1.2 | 238 | 0 | +238 | 2 of 6 | 6 of 6 | +0 | +286 |
| Mine | Lizardmen | 1 | 70 | 776 | 5.0 | 1.2 | 155 | 81 | +74 | 2 of 5 | 2 of 5 | +60 | +78 |
| Mine | Ogre Kingdoms | 1 | 136 | 66 | 2.0 | 1.0 | 33 | 114 | -81 | 1 of 2 | 0 of 2 | - | -81 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 331 | 4.0 | 1.0 | 83 | 14 | +69 | 1 of 4 | 3 of 4 | - | +69 |
| Mine | Skaven | 2 | 72 | 127 | 1.5 | 1.0 | 85 | 22 | +63 | 2 of 3 | 2 of 3 | - | +63 |
| Mine | Tomb Kings of Khemri | 2 | 163 | 527 | 5.0 | 1.2 | 105 | 58 | +48 | 2 of 10 | 8 of 10 | +57 | +45 |
| Mine | Vampire Counts | 2 | 0 | 609 | 3.0 | 1.3 | 203 | 16 | +187 | 2 of 6 | 4 of 6 | +192 | +185 |
| Mine | Warriors of Chaos | 1 | 0 | 1082 | 6.0 | 1.0 | 180 | 0 | +180 | 2 of 6 | 6 of 6 | - | +180 |
| **Mine** | all armies | 36 | 276 | 421 | 3.1 | 1.2 | 134 | 30 | +104 | 42 of 113 | 74 of 113 | +164 | +89 |
| Opponent | Beastmen Brayherds | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 0 of 1 | - | +0 |
| Opponent | Dwarfen Mountain Holds | 1 | 685 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 1 | 250 | 289 | 1.0 | 1.0 | 289 | 0 | +289 | 1 of 1 | 1 of 1 | - | +289 |
| Opponent | Grand Cathay | 1 | 285 | 662 | 3.0 | 1.0 | 221 | 0 | +221 | 2 of 3 | 2 of 3 | - | +221 |
| Opponent | High Elf Realms | 2 | 62 | 230 | 2.5 | 1.0 | 92 | 100 | -8 | 3 of 5 | 3 of 5 | - | -8 |
| Opponent | Lizardmen | 1 | 0 | 326 | 3.0 | 1.0 | 109 | 62 | +47 | 1 of 3 | 2 of 3 | - | +47 |
| Opponent | Ogre Kingdoms | 2 | 42 | 497 | 4.5 | 1.1 | 110 | 26 | +84 | 2 of 9 | 7 of 9 | +0 | +95 |
| Opponent | Orc & Goblin Tribes | 2 | 0 | 674 | 3.0 | 1.0 | 225 | 9 | +216 | 3 of 6 | 3 of 6 | - | +216 |
| Opponent | Skaven | 2 | 0 | 0 | 1.0 | 1.0 | 0 | 372 | -372 | 1 of 2 | 0 of 2 | - | -372 |
| Opponent | Tomb Kings of Khemri | 4 | 107 | 904 | 5.0 | 1.1 | 181 | 13 | +168 | 8 of 20 | 16 of 20 | +301 | +144 |
| Opponent | Vampire Counts | 6 | 11 | 665 | 4.7 | 1.3 | 143 | 26 | +116 | 10 of 28 | 18 of 28 | +214 | +77 |
| Opponent | Warriors of Chaos | 7 | 6 | 243 | 2.0 | 1.0 | 122 | 42 | +79 | 4 of 14 | 7 of 14 | - | +79 |
| Opponent | Wood Elf Realms | 6 | 56 | 556 | 3.3 | 1.2 | 167 | 6 | +160 | 10 of 20 | 11 of 20 | +290 | +117 |
| **Opponent** | all armies | 36 | 64 | 465 | 3.1 | 1.2 | 149 | 31 | +119 | 45 of 112 | 70 of 112 | +239 | +97 |

### Effective charges: ef2-opp-f5fe7c8-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 12 | 1 (net -137) | 1 (net -137) | 1 (net +0) | 1 (net +110) | 2 (net +0) | 5 (net +109) | 1 | 9% (1 of 11) |
| Mine | Chaos Dwarfs | 14 | 2 (net +456) | 1 (net -95) | 0 | 2 (net +341) | 3 (net +48) | 4 (net +252) | 2 | 0% (0 of 12) |
| Mine | Dwarfen Mountain Holds | 7 | 0 | 1 (net -100) | 1 (net -60) | 2 (net -30) | 1 (net -138) | 2 (net +0) | 0 | 14% (1 of 7) |
| Mine | Empire of Man | 12 | 1 (net +0) | 0 | 1 (net -227) | 2 (net +34) | 0 | 7 (net +93) | 1 | 9% (1 of 11) |
| Mine | Grand Cathay | 12 | 0 | 0 | 5 (net +154) | 6 (net +195) | 0 | 1 (net +140) | 0 | 42% (5 of 12) |
| Mine | High Elf Realms | 14 | 0 | 0 | 3 (net -48) | 2 (net +78) | 4 (net +209) | 4 (net +198) | 1 | 23% (3 of 13) |
| Mine | Kingdom of Bretonnia | 6 | 1 (net +666) | 0 | 0 | 0 | 2 (net +76) | 3 (net +204) | 0 | 0% (0 of 6) |
| Mine | Lizardmen | 5 | 1 (net +90) | 0 | 0 | 2 (net -202) | 1 (net +60) | 1 (net +626) | 0 | 0% (0 of 5) |
| Mine | Ogre Kingdoms | 2 | 0 | 0 | 0 | 0 | 0 | 1 (net -228) | 1 | 0% (0 of 1) |
| Mine | Orc & Goblin Tribes | 4 | 0 | 0 | 0 | 0 | 0 | 1 (net +66) | 3 | 0% (0 of 1) |
| Mine | Skaven | 3 | 2 (net +94) | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 33% (1 of 3) |
| Mine | Tomb Kings of Khemri | 10 | 0 | 0 | 2 (net +22) | 1 (net +170) | 4 (net +86) | 3 (net -26) | 0 | 20% (2 of 10) |
| Mine | Vampire Counts | 6 | 1 (net -95) | 1 (net +285) | 1 (net +662) | 1 (net +0) | 1 (net +98) | 0 | 1 | 20% (1 of 5) |
| Mine | Warriors of Chaos | 6 | 0 | 0 | 3 (net +233) | 1 (net +0) | 1 (net +267) | 1 (net +115) | 0 | 50% (3 of 6) |
| Opponent | Beastmen Brayherds | 1 | 0 | 1 (net +0) | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | Empire of Man | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +289) | 0 | 0% (0 of 1) |
| Opponent | Grand Cathay | 3 | 1 (net +128) | 0 | 0 | 2 (net +267) | 0 | 0 | 0 | 0% (0 of 3) |
| Opponent | High Elf Realms | 5 | 2 (net +148) | 1 (net -500) | 0 | 0 | 0 | 1 (net +165) | 1 | 0% (0 of 4) |
| Opponent | Lizardmen | 3 | 0 | 0 | 2 (net +48) | 0 | 0 | 0 | 1 | 100% (2 of 2) |
| Opponent | Ogre Kingdoms | 9 | 0 | 0 | 2 (net +0) | 3 (net +253) | 0 | 2 (net +0) | 2 | 29% (2 of 7) |
| Opponent | Orc & Goblin Tribes | 6 | 0 | 0 | 0 | 2 (net +212) | 0 | 0 | 4 | 0% (0 of 2) |
| Opponent | Skaven | 2 | 0 | 0 | 0 | 1 (net -92) | 0 | 1 (net -652) | 0 | 0% (0 of 2) |
| Opponent | Tomb Kings of Khemri | 20 | 0 | 0 | 2 (net +177) | 8 (net +208) | 2 (net +24) | 4 (net +232) | 4 | 12% (2 of 16) |
| Opponent | Vampire Counts | 28 | 3 (net -20) | 2 (net -255) | 5 (net +225) | 6 (net +28) | 5 (net +101) | 4 (net +294) | 3 | 20% (5 of 25) |
| Opponent | Warriors of Chaos | 14 | 3 (net +128) | 0 | 2 (net +76) | 1 (net -289) | 2 (net +55) | 2 (net +354) | 4 | 20% (2 of 10) |
| Opponent | Wood Elf Realms | 20 | 2 (net +296) | 0 | 1 (net +0) | 6 (net +252) | 1 (net +65) | 8 (net +55) | 2 | 6% (1 of 18) |

### Charged fights, damage counted: ef2-opp-f5fe7c8-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 9 | 319 | 251 | +181 | 219 | 34 | +185 | +57.8 |
| Mine | 50-54% | 4 | 108 | 238 | -12 | 79 | 83 | -4 | -4.1 |
| Mine | Effective (55-75%) | 18 | 281 | 213 | +97 | 143 | 57 | +86 | +30.7 |
| Mine | 76-89% | 20 | 269 | 203 | +95 | 167 | 76 | +91 | +33.9 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 33 | 268 | 176 | +129 | 185 | 52 | +133 | +49.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 19 | 425 | 103 | +93 | 118 | 19 | +99 | +23.2 |
| Mine | No odds | 10 | 269 | 129 | +49 | 73 | 19 | +54 | +20.2 |
| Mine | All fights | 113 | 295 | 178 | +104 | 153 | 48 | +105 | +35.4 |
| Opponent | Long shot (under 50%) | 11 | 303 | 296 | +122 | 158 | 91 | +67 | +22.2 |
| Opponent | 50-54% | 4 | 90 | 214 | -252 | 66 | 303 | -237 | -261.5 |
| Opponent | Effective (55-75%) | 14 | 280 | 245 | +123 | 165 | 35 | +130 | +46.4 |
| Opponent | 76-89% | 29 | 235 | 175 | +161 | 209 | 58 | +150 | +63.9 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 23 | 262 | 207 | +133 | 185 | 57 | +127 | +48.6 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 10 | 411 | 82 | +73 | 84 | 7 | +77 | +18.7 |
| Opponent | No odds | 21 | 293 | 176 | +132 | 144 | 18 | +125 | +42.8 |
| Opponent | All fights | 112 | 275 | 195 | +119 | 165 | 55 | +110 | +40.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ef2-opp-f5fe7c8-p1 | move | 459 | 110 (24%) | 71 (15%) | 58 (13%) | 291 (63%) |
| ef2-opp-f5fe7c8-p1 | objective | 350 | 47 (13%) | 33 (9%) | 46 (13%) | 257 (73%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

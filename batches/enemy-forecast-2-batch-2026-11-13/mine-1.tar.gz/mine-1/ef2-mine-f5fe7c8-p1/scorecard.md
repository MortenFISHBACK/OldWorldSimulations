# Doctrine scorecard: ef2-mine-f5fe7c8-p1

### Scorecard: ef2-mine-f5fe7c8-p1

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0102 | 6 | 1 | Mine | no | 3 | 3 | 0 | 0 | 0 | 0 | 0 | 387 |
| L0102 | 6 | 1 | Opponent | no | 3 | 4 | 4 | 4 | 0 | 0 | 0 | 0 |
| L0118 | 4 | 1 | Mine | no | 3 | - | 0 | 1 | 1 | 0 | 0 | 95 |
| L0118 | 4 | 1 | Opponent | no | 0 | 2 | 1 | 1 | 0 | 0 | 0 | 0 |
| L0135 | 3 | 1 | Mine | yes | 1 | 2 | 1 | 1 | 0 | 0 | 0 | 322 |
| L0135 | 3 | 1 | Opponent | no | 4 | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0218 | 2 | 1 | Mine | - | - | 1 | 2 | 4 | 0 | 0 | 0 | 170 |
| L0218 | 2 | 1 | Opponent | - | - | 3 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0235 | 1 | 1 | Mine | no | 5 | 2 | 1 | 3 | 1 | 0 | 0 | 170 |
| L0235 | 1 | 1 | Opponent | no | 5 | 1 | 3 | 2 | 1 | 0 | 0 | 0 |
| L0319 | 1 | 1 | Mine | no | 8 | 3 | 3 | 1 | 0 | 0 | 0 | 675 |
| L0319 | 1 | 1 | Opponent | no | 0 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Mine | yes | 5 | 2 | 5 | 2 | 0 | 0 | 0 | 0 |
| L0405 | 3 | 1 | Opponent | no | 0 | 3 | 1 | 2 | 0 | 0 | 0 | 1019 |
| L0421 | 1 | 1 | Mine | no | 0 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L0421 | 1 | 1 | Opponent | no | 1 | - | 0 | 4 | 2 | 0 | 0 | 447 |
| L0508 | 4 | 1 | Mine | no | 6 | 3 | 1 | 1 | 0 | 0 | 0 | 548 |
| L0508 | 4 | 1 | Opponent | no | 0 | - | 0 | 5 | 0 | 0 | 0 | 605 |
| L0524 | 2 | 1 | Mine | - | - | 5 | 1 | 1 | 0 | 0 | 0 | 889 |
| L0524 | 2 | 1 | Opponent | - | - | 2 | 4 | 4 | 0 | 0 | 0 | 0 |
| L0612 | 6 | 1 | Mine | no | 3 | - | 3 | 2 | 1 | 0 | 0 | 798 |
| L0612 | 6 | 1 | Opponent | no | 8 | 2 | 1 | 0 | 1 | 0 | 0 | 330 |
| L0628 | 4 | 1 | Mine | no | 0 | 2 | 2 | 1 | 0 | 0 | 0 | 1292 |
| L0628 | 4 | 1 | Opponent | no | 2 | 3 | 3 | 0 | 1 | 0 | 0 | 0 |
| L0717 | 3 | 1 | Mine | no | 3 | 2 | 4 | 0 | 1 | 0 | 0 | 375 |
| L0717 | 3 | 1 | Opponent | yes | 0 | 2 | 3 | 1 | 1 | 0 | 0 | 224 |
| L0733 | 1 | 1 | Mine | no | 5 | 5 | 2 | 0 | 0 | 0 | 0 | 375 |
| L0733 | 1 | 1 | Opponent | no | 0 | 1 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0823 | 1 | 1 | Mine | no | 2 | - | 0 | 1 | 1 | 0 | 0 | 515 |
| L0823 | 1 | 1 | Opponent | no | 0 | 2 | 2 | 3 | 0 | 0 | 0 | 66 |
| L0913 | 1 | 1 | Mine | no | 1 | 3 | 1 | 1 | 0 | 0 | 0 | 524 |
| L0913 | 1 | 1 | Opponent | no | 4 | 3 | 1 | 0 | 1 | 0 | 0 | 140 |
| L0930 | 6 | 1 | Mine | no | 1 | - | 1 | 0 | 0 | 0 | 0 | 733 |
| L0930 | 6 | 1 | Opponent | no | 8 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1021 | 1 | 1 | Mine | no | 0 | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1021 | 1 | 1 | Opponent | no | 5 | - | 2 | 4 | 1 | 0 | 0 | 355 |
| L1114 | 4 | 1 | Mine | no | 0 | 2 | 4 | 0 | 1 | 0 | 0 | 330 |
| L1114 | 4 | 1 | Opponent | no | 5 | 2 | 3 | 0 | 0 | 0 | 0 | 0 |
| L1131 | 3 | 1 | Mine | no | 4 | - | 4 | 0 | 0 | 0 | 0 | 330 |
| L1131 | 3 | 1 | Opponent | no | 2 | 4 | 3 | 0 | 2 | 0 | 0 | 170 |
| L1224 | 6 | 1 | Mine | no | 5 | 2 | 0 | 0 | 0 | 0 | 0 | 330 |
| L1224 | 6 | 1 | Opponent | no | 9 | 6 | 6 | 2 | 0 | 0 | 0 | 0 |
| L1319 | 5 | 1 | Mine | no | - | 2 | 3 | 3 | 0 | 0 | 0 | 317 |
| L1319 | 5 | 1 | Opponent | yes | - | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L1335 | 3 | 1 | Mine | yes | 2 | 3 | 4 | 0 | 0 | 0 | 0 | 140 |
| L1335 | 3 | 1 | Opponent | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L1431 | 3 | 1 | Mine | yes | 6 | 3 | 3 | 0 | 0 | 0 | 0 | 177 |
| L1431 | 3 | 1 | Opponent | yes | 2 | - | 1 | 1 | 1 | 0 | 0 | 170 |
| L1527 | 3 | 1 | Mine | yes | 4 | 2 | 4 | 0 | 0 | 0 | 0 | 199 |
| L1527 | 3 | 1 | Opponent | no | 0 | 2 | 3 | 3 | 0 | 0 | 0 | 0 |
| L1625 | 5 | 1 | Mine | no | - | 2 | 7 | 0 | 0 | 0 | 0 | 200 |
| L1625 | 5 | 1 | Opponent | no | - | 3 | 3 | 1 | 1 | 0 | 0 | 0 |
| L1723 | 1 | 1 | Mine | yes | 3 | 2 | 8 | 0 | 0 | 0 | 0 | 49 |
| L1723 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 0 | 1 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Mine | no | - | 2 | 2 | 2 | 0 | 0 | 0 | 0 |
| L1823 | 5 | 1 | Opponent | yes | - | 2 | 3 | 1 | 0 | 0 | 0 | 72 |
| L1923 | 3 | 1 | Mine | yes | 1 | 2 | 7 | 0 | 1 | 0 | 0 | 0 |
| L1923 | 3 | 1 | Opponent | no | 0 | 1 | 5 | 0 | 0 | 0 | 0 | 0 |
| L2025 | 3 | 1 | Mine | yes | 1 | 3 | 2 | 2 | 1 | 0 | 0 | 210 |
| L2025 | 3 | 1 | Opponent | yes | 1 | 2 | 1 | 2 | 0 | 0 | 0 | 0 |
| L2127 | 3 | 1 | Mine | no | 4 | - | 0 | 2 | 1 | 0 | 0 | 420 |
| L2127 | 3 | 1 | Opponent | yes | 11 | 1 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2231 | 5 | 1 | Mine | no | - | 2 | 4 | 0 | 0 | 0 | 0 | 170 |
| L2231 | 5 | 1 | Opponent | yes | - | 2 | 4 | 3 | 1 | 0 | 0 | 170 |
| L2335 | 1 | 1 | Mine | no | 0 | 1 | 2 | 0 | 0 | 0 | 0 | 132 |
| L2335 | 1 | 1 | Opponent | no | 2 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Mine | yes | - | 3 | 2 | 4 | 0 | 0 | 0 | 0 |
| L2531 | 5 | 1 | Opponent | yes | - | 2 | 3 | 3 | 1 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Mine | no | 0 | - | 5 | 3 | 0 | 0 | 0 | 0 |
| L2730 | 6 | 1 | Opponent | no | 8 | 2 | 4 | 2 | 0 | 0 | 0 | 0 |
| L2934 | 6 | 1 | Mine | no | 1 | 2 | 2 | 1 | 0 | 0 | 0 | 170 |
| L2934 | 6 | 1 | Opponent | no | 1 | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| **Average** | | | Mine | 26% | 2.7 | 2.4 | 2.7 | 1.1 | 0.2 | 0.0 | 0.0 | 315.9 |
| **Average** | | | Opponent | 24% | 2.8 | 2.4 | 2.9 | 1.8 | 0.4 | 0.0 | 0.0 | 104.7 |

### KPIs: ef2-mine-f5fe7c8-p1

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Winner chose to follow up after the loser gave ground |  | 92% (60 of 65); on the table 94% | 97% (36 of 37); on the table 97% | 94% (96 of 102); on the table 95% |
| Winner chose to pursue after the loser fell back in good order |  | 79% (11 of 14); on the table 79% | 83% (20 of 24); on the table 88% | 82% (31 of 38); on the table 84% |
| Winner chose to pursue after the loser fled |  | 68% (15 of 22); on the table 73% | 74% (34 of 46); on the table 76% | 72% (49 of 68); on the table 75% |
| Winner chose to follow up or pursue (all three) |  | 85% (86 of 101); on the table 87% | 84% (90 of 107); on the table 86% | 85% (176 of 208); on the table 87% |
| Magic missiles tried each own turn | 50%+ | 30% (98 of 330) | 34% (72 of 210) | 31% (170 of 540) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 43% (98 of 226) | 48% (72 of 149) | 45% (170 of 375) |
| Points that never fought | lower | 36% (25406 of 71484) | 33% (23436 of 71889) | 34% (48842 of 143373) |
|   infantry points that never fought | lower | 43% (7223 of 16863) | 57% (7605 of 13348) | 49% (14828 of 30211) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 51% (142 of 279) | 56% (164 of 295) | 53% (306 of 574) |
| Bound items with a magic missile used (at least once a game) |  | 95% (21 of 22); 1.9 uses a game | 80% (16 of 20); 1.4 uses a game | 88% (37 of 42); 1.7 uses a game |
| Bound items with another spell used |  | 50% (8 of 16); 0.7 uses a game | 75% (6 of 8); 0.2 uses a game | 58% (14 of 24); 0.4 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 58% (11 of 19); 0.3 uses a game | 67% (8 of 12); 0.2 uses a game | 61% (19 of 31); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 46% (27417 of 59666) | 48% (30108 of 62699) | 47% (57525 of 122365) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.4 (22%) | 1.4 (36%) | 2.8 (27%) |
| MARCHED: its unit marched | 1.3 (20%) | 0.4 (11%) | 1.7 (16%) |
| CHARGED: its unit charged | 0.8 (12%) | 0.2 (4%) | 0.9 (9%) |
| IN COMBAT: engaged in combat | 1.6 (25%) | 0.8 (21%) | 2.4 (23%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.1 (3%) | 0.2 (2%) |
| FLEEING: fleeing | 0.3 (5%) | 0.0 (0%) | 0.3 (3%) |
| GONE: slain | 0.9 (14%) | 0.7 (17%) | 1.6 (15%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (2%) | 0.2 (6%) | 0.3 (3%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 3.9 | 1.4 | 1.4 | 4.7 | 0.3 | 2.3 |
| not cast | 4.1 | 3.0 | 3.3 | 10.3 | 2.0 | 21.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.6 (7%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.0 (34%) | 0.4 (13%) | 2.8 (27%) | 0.6 (27%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.7 (16%) | 0.4 (18%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.9 (9%) | 0.2 (12%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (2%) | 0.6 (19%) | 0.4 (13%) | 2.4 (23%) | 0.5 (25%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.2 (5%) | 0.3 (11%) | 0.4 (13%) | 0.2 (2%) | 0.0 (0%) | 0.0 (0%) |
| NO CASTS LEFT: every cast used on other spells | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (1%) | 0.0 (0%) | 0.0 (1%) | 0.3 (3%) | 0.0 (0%) | 0.4 (2%) |
| GONE: slain | 1.1 (28%) | 0.6 (19%) | 0.7 (20%) | 1.6 (15%) | 0.2 (10%) | 3.1 (14%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (5%) | 0.2 (6%) | 0.1 (3%) | 0.3 (3%) | 0.0 (0%) | 1.0 (5%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.1 (3%) | 0.0 (1%) | 0.0 (0%) | 0.1 (7%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.4 (57%) | 0.2 (7%) | 1.2 (36%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 15.4 (71%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.1 a game | 0.5 a game | 0.8 a game |
| stood (cast and not dispelled) | 66% (21 of 32) | 64% (9 of 14) | 65% (30 of 46) |
| the unit moved after it | 62% (13 of 21) | 89% (8 of 9) | 70% (21 of 30) |
| it charged on its next turn | 0% (0 of 21) | 0% (0 of 9) | 0% (0 of 30) |
| the enemy charged it first | 19% (4 of 21) | 11% (1 of 9) | 17% (5 of 30) |
| it fought by the end of its next turn | 24% (5 of 21) | 11% (1 of 9) | 20% (6 of 30) |
| it moved out of a charge the enemy had planned (not charged first) | 19% (4 of 21) | 0% (0 of 9) | 13% (4 of 30) |
| none of these (no charge, no fight, no charge escaped) | 52% (11 of 21) | 89% (8 of 9) | 63% (19 of 30) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 64% (576 of 899) | 56% (342 of 611) | 61% (918 of 1510) |
|   cavalry | 45% (34 of 75) | 67% (80 of 120) | 58% (114 of 195) |
|   character | 52% (51 of 99) | 28% (32 of 114) | 39% (83 of 213) |
|   chariot | 56% (42 of 75) | 69% (22 of 32) | 60% (64 of 107) |
|   infantry | 56% (172 of 307) | 59% (149 of 253) | 57% (321 of 560) |
|   monster | 51% (23 of 45) | 34% (12 of 35) | 44% (35 of 80) |
|   war machine | 85% (254 of 298) | 82% (47 of 57) | 85% (301 of 355) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.4 (27%) | 1.8 (24%) | 4.2 (26%) |
| CHARGED: it charged | 1.4 (15%) | 1.5 (20%) | 2.9 (18%) |
| FLEEING: it fled or was fleeing | 0.3 (3%) | 0.2 (3%) | 0.6 (3%) |
| IN COMBAT: it fought this turn or the last | 0.6 (7%) | 0.7 (9%) | 1.3 (8%) |
| NO TARGET IN RANGE | 1.5 (17%) | 1.1 (14%) | 2.6 (16%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (5%) | 0.3 (4%) | 0.8 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.6 (18%) | 1.3 (17%) | 2.9 (18%) |
| SHELTERED: the target was sheltered | 0.4 (5%) | 0.3 (4%) | 0.8 (5%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| OTHER BAR | 0.2 (2%) | 0.1 (2%) | 0.3 (2%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.6 | 1.2 | 81% | 5.8 pts | 26 pts |
| character | 2.6 | 1.0 | 76% | 7.7 pts | 20 pts |
| chariot | 1.8 | 1.1 | 64% | 10.1 pts | 19 pts |
| infantry | 12.9 | 5.0 | 72% | 9.6 pts | 125 pts |
| monster | 1.1 | 0.3 | 85% | 3.8 pts | 4 pts |
| war machine | 8.4 | 6.6 | 61% | 25.8 pts | 216 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.9 | 5.9 | 5.4 |
| Charges that made contact a game | 3.3 | 4.3 | 3.8 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 1.38 declared, 0.76 contact (21 units) | 0.38 declared, 0.31 contact (16 units) | 0.95 declared, 0.57 contact (37 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.50 declared, 0.50 contact (6 units) | 1.50 declared, 1.00 contact (8 units) | 1.07 declared, 0.79 contact (14 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.56 declared, 0.39 contact (256 units) | 0.69 declared, 0.49 contact (286 units) | 0.63 declared, 0.44 contact (542 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 43% (30 of 70) | 43% (9 of 21) | 25% (2 of 8) | 41% (41 of 99) |
| Character in a unit | 71% (27 of 38) | 59% (16 of 27) | 0% (0 of 3) | 63% (43 of 68) |
| Character on its own | 73% (36 of 49) | 45% (15 of 33) | 22% (14 of 63) | 45% (65 of 145) |
| Chariot | 75% (12 of 16) | 80% (8 of 10) | - | 77% (20 of 26) |
| Infantry | 55% (49 of 89) | 44% (16 of 36) | 50% (1 of 2) | 52% (66 of 127) |
| Monster | 66% (21 of 32) | 60% (6 of 10) | - | 64% (27 of 42) |
| Monstrous | 73% (8 of 11) | 57% (8 of 14) | - | 64% (16 of 25) |
| War Machines | 66% (27 of 41) | 100% (1 of 1) | - | 67% (28 of 42) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 6 | 87% (13 of 15); on the table 93% | 46% (64 of 138) | 37% | 48% (16 of 33) | 100% (9 of 9); 5.5 uses a game | 67% (2 of 3); 1.3 uses a game | 89% (8 of 9); 1.3 uses a game |
| Chaos Dwarfs | 3 | 86% (6 of 7); on the table 86% | 25% (6 of 24) | 37% | 54% (13 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 0.3 uses a game |
| Dwarfen Mountain Holds | 5 | 83% (10 of 12); on the table 83% | - | 56% | 66% (27 of 41) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 73% (11 of 15); on the table 80% | 33% (12 of 36) | 53% | 50% (32 of 64) | 0.0 uses a game | 50% (1 of 2); 0.7 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 5 | 88% (7 of 8); on the table 88% | 18% (19 of 108) | 33% | 41% (18 of 44) | 92% (11 of 12); 7.6 uses a game | 0% (0 of 1); 0.0 uses a game | 20% (1 of 5); 0.2 uses a game |
| High Elf Realms | 6 | 73% (16 of 22); on the table 73% | 20% (6 of 30) | 30% | 41% (20 of 49) | 100% (5 of 5); 3.3 uses a game | 61% (11 of 18); 3.3 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (5 of 5); on the table 100% | - | 14% | 33% (2 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 2 | 100% (12 of 12); on the table 100% | - | 31% | 57% (8 of 14) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 3 | 60% (6 of 10); on the table 60% | 25% (3 of 12) | 41% | 57% (12 of 21) | 100% (3 of 3); 2.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (6 of 6); on the table 100% | 36% (13 of 36) | 17% | 54% (13 of 24) | 0.0 uses a game | 0.0 uses a game | 100% (3 of 3); 1.0 uses a game |
| Skaven | 4 | 100% (8 of 8); on the table 100% | 20% (6 of 30) | 35% | 65% (22 of 34) | 100% (3 of 3); 1.2 uses a game | 0.0 uses a game | 75% (3 of 4); 0.8 uses a game |
| Tomb Kings of Khemri | 6 | 74% (17 of 23); on the table 74% | 8% (1 of 12) | 24% | 47% (14 of 30) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 86% (25 of 29); on the table 93% | 46% (25 of 54) | 28% | 62% (31 of 50) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 8 | 95% (19 of 20); on the table 95% | 30% (9 of 30) | 25% | 55% (41 of 74) | 100% (4 of 4); 1.6 uses a game | 0.0 uses a game | 50% (1 of 2); 0.1 uses a game |
| Wood Elf Realms | 6 | 94% (15 of 16); on the table 94% | 20% (6 of 30) | 37% | 56% (37 of 66) | 33% (2 of 6); 1.2 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ef2-mine-f5fe7c8-p1, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 51% (44) | 44% (31) | 48% (75) |
| ...free all their last turn and able to turn (per game) | 0.61 | 0.47 | 1.08 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.33 | 0.25 | 0.58 |
| ...with the charger already in that arc before they moved (per game) | 0.47 | 0.28 | 0.75 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.11 | 0.67 | 1.78 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.64 | 0.53 | 1.17 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 6.86 | 8.08 | 14.94 |

### Quality by phase: ef2-mine-f5fe7c8-p1

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.4 |
| Strategy | Charge objectives carried out (made contact) | 45% (69 of 155) | 44% (80 of 180) |
| Strategy | Shoot objectives carried out (shot that target) | 48% (175 of 362) | 60% (91 of 152) |
| Strategy | Close-in objectives charged next turn | 17% (23 of 138) | 18% (37 of 210) |
| Strategy | Support requests answered (helper made contact too) | 44% (7 of 16) | 61% (17 of 28) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | 67% (2 of 3) |
| Strategy | Hexes on a unit its side charged or shot that turn | 55% (6 of 11) | 71% (5 of 7) |
| Strategy | Joined characters whose unit fought | 40% (21 of 53) | 60% (26 of 43) |
| Strategy | Lone characters that fought | 80% (74 of 93) | 80% (74 of 93) |
| Movement | Charges halted short of contact | 0.4 | 0.2 |
| Movement | Idle units | 1.1 | 1.8 |
| Movement | Points that never moved of their own | 315.9 | 104.7 |
| Movement | Fights charged into per game | 2.9 | 3.6 |
| Movement | Charges with odds: long shots (under 50%) | 15 of 96, net +101 | 21 of 109, net +41 |
| Movement | Charges with odds: sweet spot (55-75%) | 19 of 96, net -36 | 14 of 109, net +36 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 7 of 96, net +127 | 9 of 109, net +77 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 37 of 96, net +64 | 39 of 109, net +112 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.7 | 9.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 47% (162 of 348) | 53% (178 of 335) |
| Shooting | Points destroyed by shooting units | 85.7 | 25.1 |
| Shooting | War machine shots | 7.1 | 1.3 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 51% (130 of 254) | 36% (17 of 47) |
| Shooting | Points destroyed by war machines | 94.2 | 16.5 |
| Magic | Magic missiles cast | 1.6 | 1.2 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 25% (15 of 59) | 61% (27 of 44) |
| Magic | Wounds caused by magic missiles | 3.8 | 1.6 |
| Magic | Wounds caused by other spells | 2.2 | 1.3 |
| Magic | Points destroyed by magic (all spells) | 78.8 | 54.2 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.2 / 0.4 / 0.9 / 0.1 | 1.4 / 0.3 / 0.5 / 0.1 |
| Combat | Points destroyed in combat | 394.9 | 414.0 |
| Combat | Points run down | 34.7 | 112.6 |
| Combat | Net points per charged fight, damage counted | +55 | +76 |
| Combat | Net per 100 charger points, damage counted | +21.5 | +27.8 |
| Combat | First round won (charged fights) | 58% | 57% |
| Combat | Net points per charged fight | +43 | +76 |
| Combat | Net points per supported fight / lone fight | +93 / +38 | +143 / +65 |
| Combat | Charged fights on a top-3 enemy unit | 44 of 106 | 59 of 130 |
| Game | Points lost | 764.1 | 732.0 |
| Game | VP from objectives | 668.9 | 601.4 |
| Game | Lone holders (player turns) | 2.7 | 2.8 |

- Mine won / drew / lost: 16 / 6 / 14 of 36 ended games (of 36); mean margin (Mine - Opponent) +57 VP
- The side that went first won 11 of 30 games with a winner
- Points traded per game (both sides' losses): 1496
- Games not ended: 0; findings 0, warnings 1

### Opponent rules: ef2-mine-f5fe7c8-p1

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 3.5 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 7.2 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.2 | +0.0 | 0.0 | 20.4 | 0.1 | +0.0 | 0.0 | 4.6 |
| BACKUP TARGETS | 0.8 | +6.4 | 0.0 | 5.1 | 0.9 | +7.3 | 0.0 | 25.5 |
| BEST PREY | 3.2 | +166.2 | 74.1 | 116.6 | 4.9 | +371.1 | 202.2 | 141.4 |
| BEST PRIZE | - | - | - | - | 0.1 | +3.7 | 4.7 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 1.1 | 0.0 | 0.1 | +0.0 | 18.0 | 0.0 |
| BLOCKED WHEEL | 0.6 | +9.9 | 0.0 | 10.8 | 0.4 | +22.6 | 0.0 | 6.1 |
| BOMBING RUN | 0.0 | +1.7 | 0.0 | 4.2 | - | - | - | - |
| BOUND ASSAILMENT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 1.1 | +0.0 | 143.4 | 16.1 | 0.1 | +0.0 | 8.6 | 2.6 |
| CANNON PLANNED TARGET | 5.4 | +203.8 | 438.8 | 81.1 | 1.2 | +35.6 | 65.9 | 23.2 |
| CANNON SIGHT KEPT | 1.0 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | -0.3 | 2.4 | 0.0 | 0.1 | +0.0 | 1.4 | 2.6 |
| CARRIES OUT SET-UP | 0.1 | -1.1 | 9.5 | 0.0 | 0.1 | -2.5 | 14.5 | 0.0 |
| CAST JOB | 0.5 | +18.2 | 42.2 | 15.0 | 0.3 | +5.5 | 9.6 | 5.4 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.6 | +99.2 | 37.4 | 0.0 | 0.2 | +3.8 | 4.7 | 0.0 |
| CASTS AFTER FRIENDS | 0.7 | +0.0 | 0.0 | 33.3 | 0.3 | +0.0 | 0.0 | 0.0 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.1 | +0.9 | 0.0 | 6.6 | 0.0 | +0.3 | 0.0 | 0.0 |
| CATCH ODDS | 0.0 | +1.2 | 0.0 | 0.0 | 0.0 | +2.2 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -0.5 | 0.0 | 6.9 | 0.2 | -0.5 | 0.0 | 8.4 |
| CHARGE NOW WEIGHED | 0.4 | -24.6 | 5.1 | 23.6 | 0.7 | -52.9 | 34.6 | 35.0 |
| CHARIOT NO STATIC JOB | 1.0 | +0.0 | 3.2 | 21.6 | 0.7 | +0.0 | 9.8 | 4.2 |
| CHEAP HELPER | 0.2 | +0.0 | 5.0 | 5.3 | 0.2 | +0.0 | 18.4 | 4.5 |
| CONTINUE AHEAD WEIGHED | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| CONVEYANCE SEARCH | 0.6 | +64.1 | 9.1 | 14.7 | 0.3 | +100.7 | 16.2 | 15.2 |
| COUNTER-CHARGE COVER | 6.3 | +237.2 | 0.0 | 235.9 | 7.8 | +628.7 | 0.0 | 131.5 |
| EDGE GIVE GROUND | 0.0 | +1.1 | 4.7 | 0.0 | 0.1 | +3.6 | 25.4 | 0.0 |
| ELIXIR WORTH | 0.0 | +0.3 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| ENEMY FORECAST | 10.2 | +263.9 | 144.1 | 355.3 | - | - | - | - |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.1 | +70.9 | 0.0 | 45.1 | 0.7 | +49.4 | 0.0 | 17.2 |
| FALLBACK BY WORTH | 6.4 | +118.3 | 0.0 | 106.9 | 8.3 | +159.1 | 0.0 | 121.6 |
| FIRE AND FLEE | 0.0 | +1.4 | 0.0 | 2.9 | 0.1 | +0.6 | 2.4 | 3.2 |
| FLANK NOT WEIGHED | 0.2 | +0.0 | 0.0 | 3.6 | 0.2 | +0.0 | 0.0 | 15.0 |
| FOLLOW UP WEIGHED | 1.2 | +164.7 | 0.0 | 24.9 | 0.7 | +84.6 | 0.0 | 15.8 |
| FORECAST RESULT | 41.5 | +2091.8 | 600.2 | 1011.2 | 40.7 | +2541.0 | 1142.9 | 980.5 |
| FRIENDS SHOTS CHECKED | 0.2 | +14.1 | 0.0 | 0.0 | 0.1 | +14.9 | 0.0 | 0.0 |
| GIVES UP | 1.4 | -38.8 | 141.7 | 62.2 | 1.5 | -51.9 | 197.9 | 25.1 |
| GIVES UP ITS SCREEN | 0.8 | -20.8 | 45.8 | 13.4 | 1.2 | -20.3 | 99.8 | 13.8 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 7.1 | 1.8 | 0.0 | +0.0 | 0.0 | 0.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 12.3 | 1.2 | 0.3 | +0.0 | 43.3 | 4.0 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.8 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.0 | +0.3 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.0 | +0.0 | 5.9 | 0.0 | 0.1 | +4.9 | 0.0 | 6.1 |
| HUNT DROPPED | 0.0 | +0.0 | 5.9 | 0.0 | 0.0 | +0.0 | 0.0 | 1.2 |
| HUNT IN PAIRS | 0.3 | +23.5 | 0.0 | 5.7 | 0.5 | +22.1 | 0.0 | 5.4 |
| HUNT KEPT | - | - | - | - | 0.0 | +0.0 | 0.0 | 0.0 |
| HUNT RESULT | 0.1 | +12.2 | 5.9 | 0.0 | 0.2 | +26.3 | 0.0 | 8.8 |
| HUNT THE GUNS | 0.1 | +18.5 | 5.9 | 1.7 | 0.2 | +78.3 | 22.6 | 9.2 |
| JOINT CHARGE PLAN | 0.0 | +0.2 | 5.1 | 0.0 | 0.1 | +4.9 | 4.9 | 0.0 |
| KEEP FALLS | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.2 | +0.9 | 8.1 | 11.7 | 0.2 | +1.5 | 0.8 | 0.0 |
| KEEPS ITS TARGET | 1.8 | +53.3 | 150.9 | 60.6 | 2.1 | +64.2 | 232.6 | 35.0 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.6 | +69.4 | 89.5 | 43.5 | 2.1 | +86.4 | 161.8 | 41.6 |
| KILLS COUNT NEXT TURN | 7.1 | +255.2 | 273.5 | 258.2 | 10.8 | +517.7 | 500.8 | 249.2 |
| LONE CHARACTER SAFE SPOT | 0.1 | +13.1 | 0.0 | 0.0 | 0.5 | +15.5 | 22.4 | 12.0 |
| LONE WIZARD HOLDS BACK | 0.8 | +0.0 | 48.8 | 45.6 | 1.0 | +0.0 | 38.8 | 58.3 |
| LONE WIZARD KEPT IN | 0.7 | +49.1 | 0.0 | 0.0 | 0.2 | +24.5 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.4 | +19.3 | 11.7 | 0.0 | 0.7 | +54.2 | 15.2 | 4.5 |
| MANOEUVRE | 0.2 | +2.3 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.1 | +2.4 | 0.0 | 0.0 | 0.2 | +2.4 | 0.0 | 0.0 |
| MARCH CHECK | 0.5 | +16.2 | 0.0 | 6.2 | 0.9 | +53.2 | 0.0 | 5.5 |
| MARCH ODDS | 0.7 | +60.1 | 44.2 | 37.3 | 0.5 | +35.1 | 7.8 | 5.4 |
| MARCH OVER CASTS | 1.0 | -3.5 | 0.0 | 5.7 | 0.9 | +2.5 | 0.0 | 14.1 |
| MAX FOR POSITIONING | 4.2 | +107.4 | 0.0 | 171.2 | 5.5 | +172.1 | 0.0 | 134.1 |
| MISSILES IN THE MOVE | 3.1 | +157.5 | 0.0 | 74.6 | 3.0 | +43.4 | 0.0 | 36.1 |
| MISSILES NEXT TURN | 4.3 | +126.8 | 0.0 | 94.3 | 4.2 | +39.6 | 0.0 | 50.2 |
| MODEL FACING | 0.2 | +56.4 | 0.0 | 5.0 | - | - | - | - |
| MOVE AND CAST | 0.2 | +2.3 | 0.0 | 0.0 | 0.1 | +3.3 | 0.0 | 5.4 |
| MOVE SPELL IN RANGE | 0.1 | +5.6 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL NOT WORTH | 0.0 | -0.0 | 0.0 | 0.0 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.4 | -76.9 | 0.0 | 3.6 | 0.0 | -1.3 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.3 | +0.0 | 0.0 | 23.8 | 0.2 | +0.0 | 0.0 | 12.3 |
| MOVES UNITS SPELL | 0.1 | +3.4 | 0.0 | 0.0 | 0.1 | +1.8 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.1 | +27.2 | 8.3 | 0.0 |
| NO RALLY LEFT | 0.0 | +11.8 | 0.0 | 0.0 | - | - | - | - |
| NOT NEEDED | 0.2 | -6.3 | 26.5 | 0.0 | 0.3 | -18.6 | 40.4 | 3.2 |
| NOT TURNED | 6.9 | +131.1 | 0.0 | 233.4 | 8.1 | +165.6 | 0.0 | 157.3 |
| NOT WORTH A CAST | 1.1 | -0.9 | 0.0 | 40.1 | 0.3 | -0.2 | 0.0 | 0.0 |
| OPENS A LANE | 0.3 | +1.9 | 15.4 | 11.1 | 0.1 | +0.5 | 13.3 | 0.0 |
| OPENS UP | 0.3 | +43.4 | 19.1 | 0.0 | 0.2 | +15.6 | 9.0 | 15.0 |
| OVERRUNS AWAY | 0.7 | +9.3 | 39.9 | 38.2 | 0.6 | +12.5 | 41.7 | 15.9 |
| PATHS CROSS | 2.2 | +155.8 | 0.0 | 30.5 | 3.0 | +225.9 | 0.0 | 33.0 |
| PERIAPT WORTH | 0.0 | +1.6 | 0.0 | 0.0 | 0.1 | +4.8 | 0.0 | 15.0 |
| PLAN LEADS | 1.1 | +85.6 | 24.9 | 26.7 | 0.9 | +87.4 | 52.0 | 3.5 |
| PLAN RESULT | 37.3 | +1469.1 | 1348.7 | 1010.8 | 39.1 | +1368.8 | 1356.6 | 968.8 |
| PURSUES BIG PREY | 0.0 | -6.9 | 0.0 | 0.0 | 0.1 | -13.1 | 0.0 | 0.0 |
| PURSUES ON | - | - | - | - | 0.0 | +0.8 | 0.0 | 7.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.0 | +6.6 | 0.0 | 1.5 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +6.9 | 0.0 | 2.0 | 0.1 | +8.2 | 0.0 | 0.0 |
| REDIRECT COUNTER | 2.8 | +113.9 | 0.0 | 29.4 | 5.6 | +410.4 | 0.0 | 83.1 |
| REDIRECT WEIGHED | 0.3 | +0.0 | 0.0 | 34.9 | 0.4 | +8.6 | 6.5 | 4.4 |
| RESTRAINS TO SHOOT | 0.2 | +5.2 | 0.0 | 27.8 | 0.1 | +4.7 | 0.0 | 5.1 |
| RISK BY ARC | 3.1 | +78.3 | 249.3 | 114.9 | 3.2 | +76.9 | 290.1 | 74.4 |
| SAFER THAN THE JOB | 0.6 | +23.1 | 0.0 | 13.4 | 0.5 | +30.6 | 0.0 | 5.1 |
| SCOUT SPOT | 0.4 | +0.6 | 0.0 | 0.0 | 0.3 | +0.5 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 1.8 | +70.1 | 0.0 | 22.9 | 2.0 | +139.8 | 0.0 | 41.1 |
| SELF MOVE SPELL | 0.2 | +9.9 | 0.0 | 0.0 | 0.2 | +13.7 | 0.0 | 9.1 |
| SET UP TOGETHER | 0.6 | +33.0 | 21.5 | 16.4 | 1.7 | +94.6 | 21.8 | 20.6 |
| SET-UP ANY TARGET | 0.2 | +21.2 | 0.0 | 3.6 | 0.1 | +19.2 | 0.0 | 0.0 |
| SET-UP MISSED | - | - | - | - | 0.0 | +4.0 | 0.0 | 7.6 |
| SHOOTERS IN TWO RANKS | 0.4 | +0.9 | 0.0 | 0.0 | 0.2 | +0.6 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.3 | 0.0 | +0.0 | 0.0 | 3.8 |
| SHOT REPLANNED | 1.1 | +0.0 | 268.2 | 22.6 | 0.1 | +0.0 | 20.6 | 2.6 |
| SHOTS IN THE MOVE | 14.2 | +626.5 | 0.0 | 225.9 | 7.9 | +191.4 | 0.0 | 95.1 |
| SPELL CATCH ODDS | 0.1 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.3 | +56.2 | 0.0 | 14.7 | 0.2 | +86.4 | 12.3 | 0.0 |
| SPELL WORTH | 0.8 | +10.4 | 84.6 | 75.5 | 1.7 | +36.2 | 110.1 | 110.1 |
| STANDS TO CAST | 0.1 | +6.2 | 15.8 | 0.0 | 0.0 | +0.3 | 0.0 | 0.0 |
| STOPS | 0.0 | +0.0 | 0.0 | 1.7 | 0.1 | +2.7 | 22.6 | 3.1 |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 4.0 |
| SUPPORT JOB KEPT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SURE CHARGE BEATS ADVANCE | 0.1 | -1.3 | 0.0 | 4.5 | 0.2 | -6.6 | 19.7 | 19.3 |
| SURE REACH TOGETHER | 0.4 | -6.0 | 0.0 | 26.2 | 0.7 | +10.0 | 5.5 | 18.7 |
| THROUGH LINE OF FIRE | 0.6 | +17.3 | 0.0 | 22.5 | 0.2 | +2.4 | 0.0 | 6.0 |
| TURN WORTH | 0.4 | -24.9 | 39.3 | 14.0 | 0.4 | -17.4 | 21.2 | 0.0 |
| TWO OR MORE ARRIVE | 0.2 | +3.2 | 11.7 | 7.8 | 0.5 | +3.2 | 11.4 | 10.5 |
| WEARS DOWN | 1.2 | +74.2 | 121.3 | 68.6 | 1.4 | +43.4 | 150.7 | 17.4 |
| WHO HITS BACK | 0.2 | +10.9 | 0.0 | 7.3 | 0.3 | +17.4 | 0.0 | 2.3 |
| WHOLE FIGHT | 0.4 | +10.6 | 49.3 | 1.1 | 0.6 | +31.7 | 100.6 | 11.2 |
| WHOLE FIGHT GAIN | 0.2 | +15.3 | 46.2 | 4.2 | 0.5 | +30.5 | 47.5 | 13.2 |

### Rule changes: ef2-mine-f5fe7c8-p1

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| KILLS COUNT NEXT TURN | 643 | 629 | 193 | 5.36 | +7237 | +37.5 |
| PATHS CROSS | 188 | 188 | 188 | 5.22 | +13740 | +73.1 |
| FALLBACK BY WORTH | 527 | 527 | 157 | 4.36 | +9988 | +63.6 |
| BEST PREY | 289 | 283 | 133 | 3.69 | +5789 | +43.5 |
| SEARCH SPOT | 135 | 135 | 133 | 3.69 | +7562 | +56.9 |
| COUNTER-CHARGE COVER | 506 | 251 | 120 | 3.33 | +5452 | +45.4 |
| SHOTS IN THE MOVE | 797 | 521 | 71 | 1.97 | +1665 | +23.4 |
| FOLLOW UP WEIGHED | 66 | 66 | 66 | 1.83 | +8974 | +136.0 |
| CANNON PLANNED TARGET | 237 | 237 | 65 | 1.81 | -368 | -5.7 |
| FACES THE THREAT | 64 | 64 | 64 | 1.78 | +4332 | +67.7 |
| RISK BY ARC | 228 | 204 | 60 | 1.67 | +1379 | +23.0 |
| ENEMY FORECAST | 368 | 360 | 56 | 1.56 | +462 | +8.3 |
| MAX FOR POSITIONING | 349 | 192 | 53 | 1.47 | +355 | +6.7 |
| KILLS COUNT | 132 | 120 | 48 | 1.33 | +1825 | +38.0 |
| ADVANCE LANE KEPT | 47 | 47 | 47 | 1.31 | +0 | +0.0 |
| ARTILLERY RE-ROLL WEIGHED | 47 | 47 | 47 | 1.31 | +0 | +0.0 |
| CANNON SIGHT KEPT | 47 | 47 | 47 | 1.31 | +0 | +0.0 |
| HOLDS AMBUSHERS | 44 | 44 | 44 | 1.22 | +0 | +0.0 |
| SHOT REPLANNED | 43 | 43 | 43 | 1.19 | +0 | +0.0 |
| KEEPS ITS TARGET | 141 | 134 | 42 | 1.17 | +584 | +13.9 |
| SAFER THAN THE JOB | 42 | 42 | 42 | 1.17 | +1931 | +46.0 |
| MARCH ODDS | 43 | 41 | 41 | 1.14 | +791 | +19.3 |
| REDIRECT COUNTER | 299 | 121 | 38 | 1.06 | +2104 | +55.4 |
| CHARGE NOW WEIGHED | 37 | 37 | 37 | 1.03 | +1304 | +35.2 |
| BLOCKED WHEEL | 35 | 35 | 35 | 0.97 | +1170 | +33.4 |
| CHARIOT NO STATIC JOB | 62 | 62 | 34 | 0.94 | -3286 | -96.7 |
| LONE WIZARD KEPT IN | 34 | 34 | 34 | 0.94 | +2648 | +77.9 |
| SET UP TOGETHER | 82 | 63 | 34 | 0.94 | +1838 | +54.0 |
| THROUGH LINE OF FIRE | 32 | 32 | 32 | 0.89 | +711 | +22.2 |
| PLAN LEADS | 75 | 75 | 30 | 0.83 | +1885 | +62.8 |
| CASTING BLOCK | 32 | 32 | 27 | 0.75 | +2142 | +79.4 |
| MARCH CHECK | 52 | 32 | 27 | 0.75 | +871 | +32.3 |
| REDIRECT WEIGHED | 27 | 27 | 27 | 0.75 | +511 | +18.9 |
| SCOUT WAITS | 26 | 26 | 26 | 0.72 | +0 | +0.0 |
| WEARS DOWN | 95 | 87 | 24 | 0.67 | +1028 | +42.8 |
| SHOOTERS IN TWO RANKS | 23 | 23 | 23 | 0.64 | +53 | +2.3 |
| MAKE SURE TOGETHER | 37 | 25 | 22 | 0.61 | +1126 | +51.2 |
| CAST JOB | 30 | 26 | 21 | 0.58 | +406 | +19.3 |
| CASTER AWAY FROM SCREEN | 19 | 19 | 19 | 0.53 | +0 | +0.0 |
| WHO HITS BACK | 19 | 19 | 19 | 0.53 | -1105 | -58.2 |
| CHAFF PASSED | 18 | 18 | 18 | 0.50 | -36 | -2.0 |
| LONE WIZARD HOLDS BACK | 64 | 64 | 18 | 0.50 | -714 | -39.6 |
| MISSILES IN THE MOVE | 221 | 114 | 16 | 0.44 | +565 | +35.3 |
| CASTS FROM BEHIND | 14 | 14 | 14 | 0.39 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 13 | 13 | 13 | 0.36 | +1043 | +80.2 |
| STUCK PIVOT | 13 | 13 | 13 | 0.36 | +0 | +0.0 |
| MISSILES NEXT TURN | 306 | 142 | 12 | 0.33 | +56 | +4.7 |
| OPENS UP | 18 | 18 | 12 | 0.33 | +708 | +59.0 |
| MANOEUVRE | 11 | 11 | 11 | 0.31 | +147 | +13.3 |
| MOVE AND CAST | 10 | 10 | 10 | 0.28 | +204 | +20.4 |
| RESTRAINS TO SHOOT | 10 | 10 | 10 | 0.28 | +355 | +35.5 |
| MODEL FACING | 8 | 8 | 8 | 0.22 | +2030 | +253.8 |
| SHORT GUN FORWARD | 8 | 8 | 8 | 0.22 | +0 | +0.0 |
| SURE CHARGE BEATS ADVANCE | 8 | 8 | 8 | 0.22 | -284 | -35.5 |
| BLOCKED CHARGE SKIPPED | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +186 | +26.5 |
| PURSUES BIG PREY | 6 | 6 | 6 | 0.17 | -720 | -120.0 |
| WHOLE FIGHT GAIN | 26 | 21 | 6 | 0.17 | +269 | +44.9 |
| OVERRUNS AWAY | 47 | 42 | 5 | 0.14 | +155 | +31.0 |
| RAIDS THE BAGGAGE NEXT TURN | 6 | 6 | 5 | 0.14 | +241 | +48.2 |
| SURE REACH TOGETHER | 40 | 31 | 5 | 0.14 | +101 | +20.1 |
| HUNT IN PAIRS | 28 | 15 | 4 | 0.11 | +274 | +68.5 |
| CARRIES OUT SET-UP | 7 | 7 | 3 | 0.08 | -129 | -43.0 |
| EDGE GIVE GROUND | 6 | 5 | 3 | 0.08 | +55 | +18.2 |
| ELIXIR WORTH | 3 | 3 | 3 | 0.08 | +22 | +7.3 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.08 | +72 | +23.9 |
| GIVES UP | 104 | 96 | 3 | 0.08 | +49 | +16.4 |
| PERIAPT WORTH | 3 | 3 | 3 | 0.08 | +231 | +77.0 |
| WHOLE FIGHT | 33 | 29 | 3 | 0.08 | +259 | +86.2 |
| BACKUP TARGETS | 62 | 24 | 2 | 0.06 | +2 | +1.0 |
| BEST PRIZE | 2 | 2 | 2 | 0.06 | -232 | -116.2 |
| CATCH ODDS | 2 | 2 | 2 | 0.06 | -85 | -42.6 |
| JOINT CHARGE PLAN | 4 | 4 | 2 | 0.06 | +90 | +45.1 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| STANDS TO CAST | 3 | 2 | 2 | 0.06 | +70 | +35.0 |
| TWO OR MORE ARRIVE | 28 | 26 | 2 | 0.06 | +4 | +2.2 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +62 | +62.5 |
| BOUND ASSAILMENT | 1 | 1 | 1 | 0.03 | +0 | +0.1 |
| CARRIES OUT COUNTER | 3 | 3 | 1 | 0.03 | -12 | -12.3 |
| CONTINUE AHEAD WEIGHED | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| HORN WORTH | 1 | 1 | 1 | 0.03 | +12 | +12.1 |
| HUNT ADVANCE | 3 | 3 | 1 | 0.03 | +38 | +38.3 |
| KEEP FALLS | 1 | 1 | 1 | 0.03 | +5 | +5.2 |
| KEEPS ITS PREY | 14 | 12 | 1 | 0.03 | +3 | +3.2 |
| NEEDED THERE | 2 | 2 | 1 | 0.03 | +0 | +0.0 |
| NO RALLY LEFT | 1 | 1 | 1 | 0.03 | +413 | +412.6 |
| PURSUES ON | 1 | 1 | 1 | 0.03 | +28 | +27.9 |
| RAIDS THE BAGGAGE | 1 | 1 | 1 | 0.03 | +202 | +202.4 |
| SUPPORT JOB KEPT | 1 | 1 | 1 | 0.03 | +41 | +40.9 |
| ALREADY CARRIED | 2 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 44 | 44 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 36 | trace | - | - | - | - |
| CATCH FLIERS | 4 | not checked | - | - | - | - |
| CHEAP HELPER | 15 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 31 | not checked | - | - | - | - |
| ENGINEER BY LORE | 2 | 2 | 0 | 0.00 | - | - |
| FLANK NOT WEIGHED | 14 | not checked | - | - | - | - |
| FORECAST RESULT | 2959 | trace | - | - | - | - |
| GIVES UP ITS SCREEN | 69 | 66 | 0 | 0.00 | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 17 | 15 | 0 | 0.00 | - | - |
| HUNT DROPPED | 2 | trace | - | - | - | - |
| HUNT KEPT | 1 | trace | - | - | - | - |
| HUNT RESULT | 8 | trace | - | - | - | - |
| HUNT THE GUNS | 8 | trace | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 24 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 13 | trace | - | - | - | - |
| MARCH OVER CASTS | 69 | 69 | 0 | 0.00 | - | - |
| MOVE SPELL IN RANGE | 5 | 3 | 0 | 0.00 | - | - |
| MOVE SPELL NOT WORTH | 1 | not checked | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 15 | trace | - | - | - | - |
| MOVE SPELL SPOT | 16 | not checked | - | - | - | - |
| NOT NEEDED | 18 | 17 | 0 | 0.00 | - | - |
| NOT TURNED | 538 | 538 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 49 | not checked | - | - | - | - |
| OPENS A LANE | 16 | 11 | 0 | 0.00 | - | - |
| PLAN RESULT | 2752 | trace | - | - | - | - |
| SCOUT SPOT | 23 | 23 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 18 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 11 | not checked | - | - | - | - |
| SET-UP MISSED | 1 | trace | - | - | - | - |
| SPELL CATCH ODDS | 2 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 17 | not checked | - | - | - | - |
| SPELL WORTH | 87 | not checked | - | - | - | - |
| STOPS | 5 | 5 | 0 | 0.00 | - | - |
| TURN WORTH | 30 | 27 | 0 | 0.00 | - | - |

### Plans: ef2-mine-f5fe7c8-p1

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 11.6 | 14% | 562 | 288 | 51% |
| Mine | charge | 3.6 | 52% | 396 | 306 | 77% |
| Mine | close in | 3.8 | 30% | 250 | 149 | 60% |
| Mine | hold | 4.6 | 41% | 324 | 0 | 0% |
| Mine | join | 0.4 | 100% | 13 | 0 | 0% |
| Mine | shoot | 8.6 | 68% | 442 | 726 | 164% |
| Mine | support | 4.7 | 93% | 276 | 0 | 0% |
| Opponent | advance | 13.6 | 20% | 724 | 470 | 65% |
| Opponent | charge | 4.6 | 55% | 450 | 432 | 96% |
| Opponent | close in | 5.7 | 34% | 462 | 225 | 49% |
| Opponent | hold | 3.5 | 46% | 231 | 0 | 0% |
| Opponent | join | 1.1 | 95% | 38 | 0 | 0% |
| Opponent | shoot | 3.6 | 64% | 68 | 242 | 354% |
| Opponent | support | 7.1 | 91% | 324 | 0 | 0% |

### Enemy forecast: ef2-mine-f5fe7c8-p1

Per side (the computer that made the forecast) and expected action: forecasts a game, right (it did the expected action on the expected target), gone (missed, but the target or the enemy was gone before it acted), and what the enemy did instead; right of judged leaves the gone ones out.

| Side | Expected | A game | Right | Gone | Right of judged | Did charge | Did shoot | Did move | Same target |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.8 | 48% | 12% | 54% | 59% | 9% | 31% | 49% |
| Mine | shoot | 7.3 | 30% | 20% | 37% | 1% | 63% | 36% | 30% |
| Mine | move | 30.4 | 73% | 3% | 75% | 10% | 17% | 73% | - |
| Mine | all | 41.5 | 63% | 7% | 67% | 13% | 25% | 62% | - |
| Opponent | charge | 3.1 | 57% | 11% | 64% | 72% | 13% | 15% | 62% |
| Opponent | shoot | 15.2 | 30% | 24% | 39% | 2% | 71% | 27% | 31% |
| Opponent | move | 22.4 | 69% | 3% | 71% | 8% | 23% | 69% | - |
| Opponent | all | 40.7 | 53% | 11% | 60% | 11% | 40% | 49% | - |

Expected moves (the enemy's own plan): how far the expected end was from where the unit ended, against the guess that it stays where it stood.

| Side | Moves a game | Median miss | Median miss if it stays | Within 3" | Within 6" | Better than stays |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | 20.7 | 6.8" | 4.2" | 19% | 43% | 19% |
| Opponent | 14.4 | 6.5" | 4.7" | 20% | 45% | 24% |

### Packages: hunt the guns, ef2-mine-f5fe7c8-p1

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 2 | 0 | 50% | 50% | 0% | 2.0 | 332 | 219 | 50% | 20 |
| Opponent | 0.2 | 6 | 0 | 33% | 33% | 0% | 2.0 | 470 | 158 | 33% | 108 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 103 |
| Dwarfen Mountain Holds | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 441 | 438 | 100% | 57 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 114 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 119 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Kingdom of Bretonnia | 1.0 | 1 | 0 | 0% | 0% | 0% | - | 224 | 0 | 0% | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 360 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 18 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 36 |
| Tomb Kings of Khemri | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 56 |
| Vampire Counts | 0.4 | 3 | 0 | 33% | 33% | 0% | 2.0 | 426 | 152 | 33% | 20 |
| Warriors of Chaos | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 685 | 0 | 0% | 75 |
| Wood Elf Realms | 0.3 | 2 | 0 | 50% | 50% | 0% | 2.0 | 428 | 246 | 50% | 120 |

### Battle groups: ef2-mine-f5fe7c8-p1

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 6.3 | 30% | 37% | 6% | 25% | 38% | 11% | 10% | 41% | 0% |
| Mine | REDIRECT COUNTER | 2.8 | 29% | 59% | 21% | 50% | 13% | 4% | 0% | 70% | 13% |
| Opponent | COUNTER-CHARGE COVER | 7.8 | 19% | 56% | 17% | 33% | 49% | 9% | 9% | 33% | 0% |
| Opponent | REDIRECT COUNTER | 5.6 | 18% | 64% | 28% | 20% | 31% | 0% | 4% | 58% | 8% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ef2-mine-f5fe7c8-p1

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 3 | 27 (3) | 27 | 0 | 44 | 0% | 5.3 | 0 (1) | 34 (2) | - | 73 (1) | 0 (2) |
| Mine | Chaff | 45 | 34 (45) | 17 | 17 | 61 | 40% | 2.2 | 46 (16) | 67 (8) | 12 (21) | 43 (30) | 16 (15) |
| Mine | Character | 124 | 53 (124) | 53 | 0 | 40 | 16% | 2.5 | 49 (34) | 62 (64) | 15 (10) | 56 (65) | 53 (43) |
| Mine | Clean-up | 20 | 65 (20) | 26 | 38 | 18 | 35% | 3.2 | 66 (10) | 66 (8) | 38 (2) | 81 (11) | 43 (9) |
| Mine | Fast | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Fast Hammer | 40 | 35 (40) | 19 | 16 | 50 | 28% | 3.0 | 41 (21) | 55 (6) | 16 (13) | 46 (30) | 11 (10) |
| Mine | Fragile | 5 | 0 (5) | 0 | 0 | 80 | 20% | 2.2 | - | 0 (5) | - | 0 (1) | 0 (4) |
| Mine | Hammer | 56 | 32 (56) | 17 | 15 | 51 | 16% | 2.6 | 31 (10) | 35 (36) | 22 (10) | 32 (37) | 32 (19) |
| Mine | Holder | 26 | 94 (26) | 2 | 92 | 28 | 46% | 3.4 | 118 (7) | 75 (14) | 149 (4) | 117 (13) | 79 (12) |
| Mine | Shooter | 45 | 122 (45) | 51 | 71 | 46 | 2% | 1.9 | 100 (7) | 110 (31) | 200 (7) | 137 (27) | 98 (18) |
| Mine | Support | 5 | 22 (5) | 22 | 0 | 28 | 20% | 3.0 | - | 0 (2) | 78 (2) | 78 (2) | 0 (2) |
| Mine | War machine | 56 | 59 (56) | 59 | 0 | 34 | 4% | 1.3 | 61 (13) | 54 (38) | 90 (5) | 52 (10) | 61 (46) |
| Mine | Wizard | 22 | 27 (22) | 27 | 0 | 40 | 18% | 2.5 | 55 (7) | 27 (7) | 0 (2) | 79 (4) | 18 (12) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 100 | 0% | 6.0 | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 81 | 38 (81) | 11 | 26 | 51 | 33% | 2.6 | 38 (29) | 45 (21) | 33 (31) | 51 (56) | 4 (25) |
| Opponent | Character | 113 | 57 (113) | 57 | 0 | 38 | 18% | 2.5 | 72 (39) | 55 (53) | 33 (8) | 62 (67) | 58 (33) |
| Opponent | Clean-up | 12 | 60 (12) | 50 | 10 | 43 | 25% | 2.8 | 91 (5) | 35 (7) | - | 78 (9) | 0 (3) |
| Opponent | Early | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | 0 (1) | - | - | 0 (1) | - |
| Opponent | Fast Hammer | 53 | 51 (53) | 30 | 21 | 34 | 25% | 3.1 | 50 (23) | 65 (15) | 37 (15) | 61 (38) | 28 (15) |
| Opponent | Fragile | 9 | 6 (9) | 6 | 0 | 45 | 22% | 3.1 | - | 11 (5) | 0 (4) | 7 (7) | 0 (2) |
| Opponent | Hammer | 63 | 37 (63) | 30 | 7 | 43 | 29% | 2.5 | 21 (20) | 46 (38) | 11 (5) | 34 (37) | 41 (26) |
| Opponent | Holder | 35 | 51 (35) | 4 | 47 | 25 | 46% | 3.7 | 40 (6) | 79 (18) | 13 (11) | 77 (12) | 34 (23) |
| Opponent | Shooter | 31 | 58 (31) | 17 | 41 | 34 | 3% | 1.5 | 83 (7) | 61 (19) | 14 (5) | 58 (17) | 58 (14) |
| Opponent | Support | 2 | 0 (2) | 0 | 0 | 0 | 100% | - | 0 (1) | 0 (1) | - | - | 0 (2) |
| Opponent | War machine | 13 | 49 (13) | 49 | 0 | 60 | 23% | 1.1 | 0 (3) | 49 (7) | 95 (3) | 0 (2) | 57 (11) |
| Opponent | Wizard | 24 | 6 (24) | 6 | 0 | 41 | 8% | 2.4 | 14 (6) | 4 (8) | 0 (7) | 9 (11) | 0 (10) |

### Charged fights: ef2-mine-f5fe7c8-p1

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 185 | 41 | 1.0 | 1.2 | 41 | 17 | +24 | 0 of 5 | 3 of 5 | -85 | +51 |
| Mine | Chaos Dwarfs | 3 | 50 | 546 | 3.3 | 1.1 | 164 | 93 | +71 | 8 of 10 | 5 of 10 | -100 | +90 |
| Mine | Dwarfen Mountain Holds | 4 | 633 | 102 | 2.0 | 1.0 | 51 | 45 | +6 | 3 of 8 | 3 of 8 | - | +6 |
| Mine | Empire of Man | 5 | 510 | 120 | 1.8 | 1.1 | 67 | 21 | +46 | 1 of 9 | 3 of 9 | +185 | +28 |
| Mine | Grand Cathay | 4 | 340 | 364 | 3.8 | 1.2 | 97 | 38 | +59 | 8 of 15 | 8 of 15 | +158 | +34 |
| Mine | High Elf Realms | 4 | 103 | 417 | 3.5 | 1.1 | 119 | 78 | +41 | 7 of 14 | 9 of 14 | +198 | +15 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 1612 | 9.0 | 1.0 | 179 | 0 | +179 | 4 of 9 | 6 of 9 | - | +179 |
| Mine | Lizardmen | 1 | 540 | 521 | 6.0 | 1.0 | 87 | 0 | +87 | 0 of 6 | 5 of 6 | - | +87 |
| Mine | Ogre Kingdoms | 1 | 70 | 66 | 3.0 | 1.3 | 22 | 11 | +11 | 1 of 3 | 2 of 3 | +66 | -17 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 136 | 6.0 | 1.0 | 23 | 110 | -87 | 2 of 6 | 4 of 6 | - | -87 |
| Mine | Skaven | 2 | 38 | 326 | 2.5 | 1.0 | 130 | 13 | +117 | 2 of 5 | 3 of 5 | - | +117 |
| Mine | Tomb Kings of Khemri | 2 | 352 | 137 | 4.5 | 1.1 | 30 | 166 | -136 | 4 of 9 | 6 of 9 | -431 | -99 |
| Mine | Vampire Counts | 2 | 0 | 488 | 3.0 | 1.3 | 163 | 23 | +139 | 4 of 6 | 3 of 6 | +513 | +65 |
| Mine | Warriors of Chaos | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | - | +0 |
| **Mine** | all armies | 36 | 259 | 284 | 2.9 | 1.1 | 96 | 53 | +43 | 44 of 106 | 61 of 106 | +93 | +38 |
| Opponent | Beastmen Brayherds | 1 | 0 | 77 | 3.0 | 1.0 | 26 | 0 | +26 | 2 of 3 | 2 of 3 | - | +26 |
| Opponent | Dwarfen Mountain Holds | 1 | 310 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Empire of Man | 1 | 0 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | Grand Cathay | 1 | 531 | 0 | 1.0 | 1.0 | 0 | 0 | +0 | 1 of 1 | 1 of 1 | - | +0 |
| Opponent | High Elf Realms | 2 | 392 | 484 | 3.5 | 1.0 | 138 | 22 | +117 | 3 of 7 | 4 of 7 | - | +117 |
| Opponent | Lizardmen | 1 | 0 | 1088 | 4.0 | 1.2 | 272 | 0 | +272 | 2 of 4 | 0 of 4 | +238 | +283 |
| Opponent | Ogre Kingdoms | 2 | 26 | 651 | 4.0 | 1.9 | 163 | 64 | +99 | 4 of 8 | 6 of 8 | +183 | -41 |
| Opponent | Orc & Goblin Tribes | 2 | 35 | 890 | 4.5 | 1.0 | 198 | 12 | +186 | 3 of 9 | 5 of 9 | - | +186 |
| Opponent | Skaven | 2 | 0 | 0 | 1.5 | 1.0 | 0 | 101 | -101 | 2 of 3 | 2 of 3 | - | -101 |
| Opponent | Tomb Kings of Khemri | 4 | 9 | 635 | 4.8 | 1.3 | 134 | 47 | +87 | 9 of 19 | 14 of 19 | +246 | +44 |
| Opponent | Vampire Counts | 6 | 112 | 320 | 4.5 | 1.2 | 71 | 67 | +4 | 12 of 27 | 12 of 26 | +29 | -0 |
| Opponent | Warriors of Chaos | 7 | 0 | 396 | 3.1 | 1.0 | 126 | 5 | +121 | 11 of 22 | 15 of 22 | +0 | +126 |
| Opponent | Wood Elf Realms | 6 | 166 | 382 | 4.5 | 1.1 | 85 | 35 | +50 | 10 of 27 | 13 of 27 | +116 | +39 |
| **Opponent** | all armies | 36 | 96 | 410 | 3.6 | 1.2 | 113 | 37 | +76 | 59 of 130 | 74 of 129 | +143 | +65 |

### Effective charges: ef2-mine-f5fe7c8-p1

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 0 | 0 | 1 (net +0) | 1 (net +126) | 0 | 3 (net -3) | 0 | 20% (1 of 5) |
| Mine | Chaos Dwarfs | 10 | 3 (net +174) | 0 | 3 (net +13) | 1 (net +73) | 1 (net +384) | 2 (net -155) | 0 | 30% (3 of 10) |
| Mine | Dwarfen Mountain Holds | 8 | 0 | 0 | 3 (net +14) | 1 (net +41) | 0 | 3 (net +27) | 1 | 43% (3 of 7) |
| Mine | Empire of Man | 9 | 0 | 1 (net +109) | 2 (net -94) | 3 (net +16) | 0 | 3 (net +147) | 0 | 22% (2 of 9) |
| Mine | Grand Cathay | 15 | 2 (net +85) | 0 | 4 (net -1) | 4 (net +0) | 0 | 5 (net +144) | 0 | 27% (4 of 15) |
| Mine | High Elf Realms | 14 | 2 (net +58) | 0 | 0 | 2 (net +58) | 1 (net +395) | 6 (net +39) | 3 | 0% (0 of 11) |
| Mine | Kingdom of Bretonnia | 9 | 2 (net +176) | 0 | 0 | 1 (net +580) | 1 (net +45) | 5 (net +127) | 0 | 0% (0 of 9) |
| Mine | Lizardmen | 6 | 1 (net +90) | 0 | 2 (net +30) | 1 (net +371) | 0 | 2 (net +0) | 0 | 33% (2 of 6) |
| Mine | Ogre Kingdoms | 3 | 1 (net +0) | 0 | 0 | 1 (net +66) | 0 | 0 | 1 | 0% (0 of 2) |
| Mine | Orc & Goblin Tribes | 6 | 0 | 0 | 0 | 0 | 2 (net +33) | 0 | 4 | 0% (0 of 2) |
| Mine | Skaven | 5 | 2 (net +94) | 0 | 0 | 0 | 1 (net +0) | 2 (net +199) | 0 | 0% (0 of 5) |
| Mine | Tomb Kings of Khemri | 9 | 1 (net -122) | 0 | 3 (net -379) | 1 (net +0) | 0 | 3 (net +13) | 1 | 38% (3 of 8) |
| Mine | Vampire Counts | 6 | 1 (net +195) | 0 | 1 (net +513) | 1 (net +0) | 0 | 3 (net +43) | 0 | 17% (1 of 6) |
| Mine | Warriors of Chaos | 1 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0% (0 of 1) |
| Opponent | Beastmen Brayherds | 3 | 0 | 0 | 1 (net +0) | 0 | 0 | 2 (net +38) | 0 | 33% (1 of 3) |
| Opponent | Grand Cathay | 1 | 0 | 0 | 0 | 1 (net +0) | 0 | 0 | 0 | 0% (0 of 1) |
| Opponent | High Elf Realms | 7 | 1 (net +296) | 0 | 0 | 3 (net +174) | 0 | 2 (net -76) | 1 | 0% (0 of 6) |
| Opponent | Lizardmen | 4 | 1 (net +0) | 1 (net +238) | 1 (net +661) | 0 | 0 | 1 (net +189) | 0 | 25% (1 of 4) |
| Opponent | Ogre Kingdoms | 8 | 2 (net +285) | 0 | 1 (net +65) | 1 (net -185) | 0 | 2 (net +318) | 2 | 17% (1 of 6) |
| Opponent | Orc & Goblin Tribes | 9 | 2 (net +146) | 0 | 0 | 1 (net +321) | 0 | 2 (net +288) | 4 | 0% (0 of 5) |
| Opponent | Skaven | 3 | 0 | 0 | 0 | 2 (net -151) | 0 | 1 (net +0) | 0 | 0% (0 of 3) |
| Opponent | Tomb Kings of Khemri | 19 | 0 | 0 | 3 (net -231) | 8 (net +110) | 2 (net +91) | 6 (net +213) | 0 | 16% (3 of 19) |
| Opponent | Vampire Counts | 27 | 8 (net -56) | 0 | 2 (net -25) | 2 (net +0) | 2 (net +47) | 10 (net +45) | 3 | 8% (2 of 24) |
| Opponent | Warriors of Chaos | 22 | 1 (net +499) | 1 (net +663) | 4 (net -30) | 1 (net +177) | 3 (net +118) | 6 (net +135) | 6 | 25% (4 of 16) |
| Opponent | Wood Elf Realms | 27 | 6 (net -59) | 0 | 2 (net +318) | 5 (net +148) | 2 (net +32) | 7 (net +70) | 5 | 9% (2 of 22) |

### Charged fights, damage counted: ef2-mine-f5fe7c8-p1

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 15 | 266 | 228 | +101 | 169 | 71 | +98 | +36.9 |
| Mine | 50-54% | 1 | 189 | 109 | +109 | 109 | 42 | +67 | +35.4 |
| Mine | Effective (55-75%) | 19 | 270 | 173 | -36 | 95 | 113 | -17 | -6.4 |
| Mine | 76-89% | 17 | 242 | 149 | +84 | 91 | 15 | +76 | +31.3 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 37 | 229 | 196 | +64 | 119 | 40 | +78 | +34.2 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 7 | 373 | 94 | +127 | 176 | 16 | +160 | +42.9 |
| Mine | No odds | 10 | 262 | 183 | -103 | 81 | 151 | -70 | -26.7 |
| Mine | All fights | 106 | 256 | 180 | +43 | 117 | 62 | +55 | +21.5 |
| Opponent | Long shot (under 50%) | 21 | 253 | 265 | +41 | 173 | 106 | +68 | +26.8 |
| Opponent | 50-54% | 2 | 464 | 309 | +450 | 450 | 8 | +442 | +95.4 |
| Opponent | Effective (55-75%) | 14 | 253 | 237 | +36 | 133 | 91 | +42 | +16.6 |
| Opponent | 76-89% | 24 | 313 | 244 | +90 | 144 | 54 | +90 | +28.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 39 | 247 | 186 | +112 | 138 | 31 | +106 | +43.1 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 458 | 87 | +77 | 138 | 72 | +67 | +14.6 |
| Opponent | No odds | 21 | 224 | 178 | +21 | 66 | 60 | +6 | +2.7 |
| Opponent | All fights | 130 | 275 | 209 | +76 | 137 | 61 | +76 | +27.8 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ef2-mine-f5fe7c8-p1 | move | 471 | 105 (22%) | 73 (15%) | 60 (13%) | 306 (65%) |
| ef2-mine-f5fe7c8-p1 | objective | 348 | 60 (17%) | 42 (12%) | 59 (17%) | 229 (66%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0102, L0118, L0135, L2531, L2730 |
| Charmed Shield | Opponent | L0524, L1224, L1527, L1625, L2025, L2127, L2934 |
| Clockwork Compass | Mine | L1224 |
| Clockwork Compass | Opponent | L0612 |
| Elixir of Power | Mine | L1114, L1131, L1923 |
| Elixir of Power | Opponent | L0319, L1319 |
| Fistful of Laurels | Mine | L1823 |
| Fistful of Laurels | Opponent | L0118, L0218 |
| Horn of the Wild Hunt | Opponent | L0733 |
| Invocation of Nehek | Mine | L2531, L2730 |
| Invocation of Nehek | Opponent | L0524, L1224, L1527, L1625, L2025, L2127 |
| Opal Amulet | Mine | L1431 |
| Opal Amulet | Opponent | L1114 |
| Periapt of Soul Exchange | Mine | L2025, L2127 |
| Periapt of Soul Exchange | Opponent | L0421, L1021 |
| Ring of Doom | Mine | L0218, L0235, L1114, L1131, L1224, L1527 |
| Ring of Doom | Opponent | L0102, L0612, L0733, L1131, L1431, L2231, L2531 |
| Ring of Jet | Mine | L1021, L1114, L1131, L1224 |
| Ring of Jet | Opponent | L0612 |
| Standard of the Fell Warrior | Mine | L1319, L1335 |
| Standard of the Fell Warrior | Opponent | L0913 |
| Storm Daemon (Renegade 2.0) | Mine | L2127 |
| Storm Daemon (Renegade 2.0) | Opponent | L0421, L1021 |
| Twice-Blessed Armour | Mine | L0717, L0733, L1021 |
| Witch Hunter's Ward | Mine | L0717, L0733, L0823 |
| Witch Hunter's Ward | Opponent | L0508 |

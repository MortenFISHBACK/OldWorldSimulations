# Doctrine scorecard: ef2-opp-f5fe7c8-p3

### Scorecard: ef2-opp-f5fe7c8-p3

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0110 | 2 | 1 | Mine | - | - | 2 | 1 | 2 | 1 | 0 | 0 | 95 |
| L0110 | 2 | 1 | Opponent | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L0126 | 6 | 1 | Mine | no | 4 | - | 0 | 1 | 0 | 0 | 0 | 387 |
| L0126 | 6 | 1 | Opponent | no | 8 | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0210 | 6 | 1 | Mine | no | 4 | 3 | 0 | 6 | 1 | 0 | 0 | 170 |
| L0210 | 6 | 1 | Opponent | no | 0 | 4 | 1 | 1 | 0 | 0 | 0 | 330 |
| L0226 | 4 | 1 | Mine | no | 1 | 1 | 1 | 2 | 0 | 0 | 0 | 170 |
| L0226 | 4 | 1 | Opponent | no | 10 | 2 | 0 | 1 | 0 | 0 | 0 | 0 |
| L0311 | 5 | 1 | Mine | no | - | 4 | 1 | 1 | 0 | 0 | 0 | 590 |
| L0311 | 5 | 1 | Opponent | yes | - | - | 2 | 1 | 0 | 0 | 0 | 330 |
| L0327 | 3 | 1 | Mine | yes | 7 | 3 | 3 | 0 | 0 | 0 | 0 | 590 |
| L0327 | 3 | 1 | Opponent | no | 2 | - | 1 | 3 | 2 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Mine | yes | - | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0413 | 5 | 1 | Opponent | no | - | 3 | 0 | 2 | 1 | 0 | 0 | 140 |
| L0429 | 3 | 1 | Mine | no | 2 | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L0429 | 3 | 1 | Opponent | no | 2 | 2 | 6 | 1 | 2 | 0 | 0 | 170 |
| L0516 | 6 | 1 | Mine | no | 5 | 6 | 1 | 1 | 0 | 0 | 0 | 771 |
| L0516 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 1 | 1 | 0 | 0 | 280 |
| L0533 | 5 | 1 | Mine | no | - | - | 0 | 1 | 0 | 0 | 0 | 548 |
| L0533 | 5 | 1 | Opponent | yes | - | 6 | 0 | 5 | 0 | 0 | 0 | 0 |
| L0620 | 2 | 1 | Mine | - | - | 2 | 4 | 0 | 0 | 0 | 0 | 615 |
| L0620 | 2 | 1 | Opponent | - | - | 4 | 0 | 5 | 1 | 0 | 0 | 0 |
| L0709 | 1 | 1 | Mine | yes | 2 | 2 | 1 | 0 | 1 | 0 | 0 | 420 |
| L0709 | 1 | 1 | Opponent | yes | 3 | 6 | 2 | 1 | 0 | 0 | 0 | 420 |
| L0725 | 5 | 1 | Mine | yes | - | 5 | 1 | 0 | 0 | 0 | 0 | 375 |
| L0725 | 5 | 1 | Opponent | yes | - | 2 | 3 | 4 | 0 | 0 | 0 | 0 |
| L0815 | 5 | 1 | Mine | no | - | - | 0 | 0 | 0 | 0 | 0 | 560 |
| L0815 | 5 | 1 | Opponent | yes | - | 3 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0831 | 3 | 1 | Mine | yes | 11 | 2 | 3 | 1 | 0 | 0 | 0 | 605 |
| L0831 | 3 | 1 | Opponent | no | 0 | - | 0 | 4 | 2 | 0 | 0 | 170 |
| L0922 | 4 | 1 | Mine | no | 0 | 3 | 4 | 0 | 0 | 0 | 0 | 515 |
| L0922 | 4 | 1 | Opponent | no | 2 | 2 | 2 | 0 | 0 | 0 | 0 | 55 |
| L1013 | 5 | 1 | Mine | yes | - | 2 | 5 | 0 | 0 | 0 | 0 | 330 |
| L1013 | 5 | 1 | Opponent | no | - | 4 | 2 | 0 | 2 | 0 | 0 | 302 |
| L1030 | 4 | 1 | Mine | no | 2 | 6 | 1 | 0 | 0 | 0 | 0 | 330 |
| L1030 | 4 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1122 | 6 | 1 | Mine | no | 3 | 6 | 1 | 0 | 0 | 0 | 0 | 427 |
| L1122 | 6 | 1 | Opponent | no | 0 | 2 | 6 | 0 | 0 | 0 | 0 | 0 |
| L1216 | 4 | 1 | Mine | no | 0 | 2 | 5 | 1 | 0 | 0 | 0 | 524 |
| L1216 | 4 | 1 | Opponent | no | 1 | - | 1 | 1 | 1 | 0 | 0 | 200 |
| L1232 | 2 | 1 | Mine | - | - | 6 | 0 | 0 | 0 | 0 | 0 | 498 |
| L1232 | 2 | 1 | Opponent | - | - | 2 | 3 | 7 | 0 | 0 | 0 | 0 |
| L1327 | 1 | 1 | Mine | no | 18 | 4 | 3 | 0 | 0 | 0 | 0 | 140 |
| L1327 | 1 | 1 | Opponent | no | 0 | 2 | 1 | 5 | 1 | 0 | 0 | 50 |
| L1422 | 6 | 1 | Mine | no | 11 | 2 | 7 | 0 | 0 | 0 | 0 | 123 |
| L1422 | 6 | 1 | Opponent | no | 0 | 1 | 5 | 0 | 0 | 0 | 0 | 170 |
| L1519 | 1 | 1 | Mine | no | 0 | 2 | 2 | 0 | 1 | 0 | 0 | 0 |
| L1519 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Mine | no | - | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1535 | 5 | 1 | Opponent | yes | - | 1 | 3 | 2 | 0 | 0 | 0 | 408 |
| L1633 | 1 | 1 | Mine | no | 2 | 2 | 3 | 1 | 0 | 0 | 0 | 200 |
| L1633 | 1 | 1 | Opponent | no | 1 | 1 | 4 | 3 | 0 | 0 | 0 | 236 |
| L1731 | 3 | 1 | Mine | no | 3 | 4 | 4 | 0 | 1 | 0 | 0 | 0 |
| L1731 | 3 | 1 | Opponent | no | 3 | 3 | 2 | 0 | 1 | 0 | 0 | 628 |
| L1831 | 1 | 1 | Mine | no | 9 | 3 | 5 | 0 | 1 | 0 | 0 | 0 |
| L1831 | 1 | 1 | Opponent | no | 4 | 2 | 2 | 0 | 2 | 0 | 0 | 170 |
| L1932 | 6 | 1 | Mine | no | 6 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1932 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 2 | 0 | 0 | 0 | 340 |
| L2033 | 5 | 1 | Mine | yes | - | - | 0 | 2 | 1 | 0 | 0 | 248 |
| L2033 | 5 | 1 | Opponent | yes | - | 5 | 3 | 2 | 1 | 0 | 0 | 234 |
| L2223 | 3 | 1 | Mine | no | 2 | 2 | 6 | 0 | 1 | 0 | 0 | 242 |
| L2223 | 3 | 1 | Opponent | no | 1 | 1 | 11 | 0 | 0 | 0 | 0 | 185 |
| L2327 | 5 | 1 | Mine | yes | - | 2 | 2 | 1 | 0 | 0 | 0 | 185 |
| L2327 | 5 | 1 | Opponent | yes | - | 2 | 3 | 1 | 0 | 0 | 0 | 190 |
| L2433 | 3 | 1 | Mine | no | 4 | 3 | 3 | 1 | 0 | 0 | 0 | 0 |
| L2433 | 3 | 1 | Opponent | no | 1 | 1 | 4 | 3 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Mine | - | - | 2 | 6 | 2 | 0 | 0 | 0 | 0 |
| L2630 | 2 | 1 | Opponent | - | - | 2 | 2 | 1 | 0 | 0 | 0 | 0 |
| L2832 | 6 | 1 | Mine | no | 2 | - | 0 | 0 | 2 | 0 | 0 | 357 |
| L2832 | 6 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 1 | 0 | 0 | 0 |
| L3133 | 1 | 1 | Mine | no | 0 | 5 | 1 | 0 | 1 | 0 | 0 | 0 |
| L3133 | 1 | 1 | Opponent | no | 0 | 2 | 5 | 2 | 0 | 0 | 0 | 641 |
| **Average** | | | Mine | 25% | 4.3 | 3.0 | 2.2 | 0.8 | 0.3 | 0.0 | 0.0 | 278.2 |
| **Average** | | | Opponent | 25% | 1.7 | 2.5 | 2.7 | 1.9 | 0.5 | 0.0 | 0.0 | 166.1 |

### KPIs: ef2-opp-f5fe7c8-p3

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Winner chose to follow up after the loser gave ground |  | 92% (61 of 66); on the table 94% | 97% (33 of 34); on the table 97% | 94% (94 of 100); on the table 95% |
| Winner chose to pursue after the loser fell back in good order |  | 90% (9 of 10); on the table 90% | 92% (12 of 13); on the table 92% | 91% (21 of 23); on the table 91% |
| Winner chose to pursue after the loser fled |  | 76% (16 of 21); on the table 95% | 59% (23 of 39); on the table 72% | 65% (39 of 60); on the table 80% |
| Winner chose to follow up or pursue (all three) |  | 89% (86 of 97); on the table 94% | 79% (68 of 86); on the table 85% | 84% (154 of 183); on the table 90% |
| Magic missiles tried each own turn | 50%+ | 25% (87 of 342) | 40% (76 of 192) | 31% (163 of 534) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 38% (87 of 227) | 49% (76 of 155) | 43% (163 of 382) |
| Points that never fought | lower | 37% (25670 of 68801) | 39% (28296 of 71990) | 38% (53966 of 140791) |
|   infantry points that never fought | lower | 47% (6601 of 14174) | 53% (7508 of 14220) | 50% (14109 of 28394) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 60% (164 of 272) | 60% (170 of 285) | 60% (334 of 557) |
| Bound items with a magic missile used (at least once a game) |  | 88% (22 of 25); 1.4 uses a game | 92% (22 of 24); 2.0 uses a game | 90% (44 of 49); 1.7 uses a game |
| Bound items with another spell used |  | 50% (7 of 14); 0.4 uses a game | 33% (2 of 6); 0.2 uses a game | 45% (9 of 20); 0.3 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 50% (10 of 20); 0.3 uses a game | 29% (4 of 14); 0.1 uses a game | 41% (14 of 34); 0.2 uses a game |
|   their share of the points of units over 100 pts | lower | 52% (30681 of 59391) | 53% (34008 of 64043) | 52% (64689 of 123434) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.5 (21%) | 1.2 (36%) | 2.6 (26%) |
| MARCHED: its unit marched | 1.9 (27%) | 0.8 (23%) | 2.7 (26%) |
| CHARGED: its unit charged | 0.3 (4%) | 0.2 (7%) | 0.5 (5%) |
| IN COMBAT: engaged in combat | 1.6 (22%) | 0.7 (21%) | 2.2 (22%) |
| REAR RANK: in a rear rank | 0.1 (1%) | 0.1 (2%) | 0.1 (1%) |
| FLEEING: fleeing | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) |
| GONE: slain | 0.8 (11%) | 0.3 (9%) | 1.1 (10%) |
| OFF THE TABLE: off the table or not arrived | 0.8 (12%) | 0.1 (2%) | 0.9 (9%) |
| STUPIDITY: Stupidity | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.6 | 1.0 | 2.0 | 4.5 | 0.9 | 1.9 |
| not cast | 4.2 | 1.6 | 4.2 | 10.3 | 2.4 | 18.8 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) | 1.2 (6%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (1%) | 0.7 (44%) | 0.3 (8%) | 2.6 (26%) | 0.6 (24%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.7 (26%) | 0.6 (26%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.5 (5%) | 0.1 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.2 (11%) | 0.8 (18%) | 2.2 (22%) | 0.2 (8%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.1 (3%) | 0.0 (0%) | 0.2 (4%) | 0.1 (1%) | 0.1 (2%) | 0.0 (0%) |
| FLEEING: fleeing | 0.1 (3%) | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) | 0.0 (1%) | 0.5 (3%) |
| GONE: slain | 1.2 (28%) | 0.3 (19%) | 0.9 (21%) | 1.1 (10%) | 0.2 (10%) | 2.4 (13%) |
| OFF THE TABLE: off the table or not arrived | 0.4 (9%) | 0.2 (14%) | 0.2 (5%) | 0.9 (9%) | 0.1 (5%) | 0.6 (3%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (0%) | 0.1 (1%) | 0.1 (1%) | 0.0 (0%) | 0.0 (0%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.1 (3%) | 0.0 (2%) | 0.0 (0%) | 0.1 (1%) | 0.5 (22%) | 0.0 (0%) |
| NOT OFFERED: not in the cast list | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 2.0 (47%) | 0.2 (11%) | 1.7 (41%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 14.0 (75%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.4 a game | 0.7 a game | 1.0 a game |
| stood (cast and not dispelled) | 53% (20 of 38) | 68% (13 of 19) | 58% (33 of 57) |
| the unit moved after it | 90% (18 of 20) | 100% (13 of 13) | 94% (31 of 33) |
| it charged on its next turn | 5% (1 of 20) | 8% (1 of 13) | 6% (2 of 33) |
| the enemy charged it first | 20% (4 of 20) | 8% (1 of 13) | 15% (5 of 33) |
| it fought by the end of its next turn | 10% (2 of 20) | 8% (1 of 13) | 9% (3 of 33) |
| it moved out of a charge the enemy had planned (not charged first) | 25% (5 of 20) | 8% (1 of 13) | 18% (6 of 33) |
| none of these (no charge, no fight, no charge escaped) | 45% (9 of 20) | 77% (10 of 13) | 58% (19 of 33) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 62% (481 of 776) | 56% (351 of 631) | 59% (832 of 1407) |
|   cavalry | 65% (42 of 65) | 54% (59 of 110) | 58% (101 of 175) |
|   character | 39% (43 of 110) | 24% (30 of 127) | 31% (73 of 237) |
|   chariot | 41% (38 of 92) | 53% (16 of 30) | 44% (54 of 122) |
|   infantry | 57% (112 of 197) | 67% (182 of 273) | 63% (294 of 470) |
|   monster | 40% (17 of 42) | 67% (2 of 3) | 42% (19 of 45) |
|   war machine | 85% (229 of 270) | 70% (62 of 88) | 81% (291 of 358) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.3 (28%) | 1.8 (24%) | 4.2 (26%) |
| CHARGED: it charged | 1.2 (15%) | 1.6 (20%) | 2.8 (17%) |
| FLEEING: it fled or was fleeing | 0.1 (1%) | 0.1 (1%) | 0.2 (1%) |
| IN COMBAT: it fought this turn or the last | 0.9 (11%) | 0.6 (8%) | 1.5 (9%) |
| MOVED: a war machine that moved | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| FREE: none of these - no target in range or sight, or held its fire | 0.1 (1%) | 0.0 (0%) | 0.1 (1%) |
| NO TARGET IN RANGE | 1.1 (14%) | 1.2 (15%) | 2.3 (14%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (5%) | 0.3 (4%) | 0.7 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.6 (19%) | 1.4 (18%) | 2.9 (18%) |
| SHELTERED: the target was sheltered | 0.1 (2%) | 0.6 (7%) | 0.7 (4%) |
| STUPIDITY | 0.0 (0%) | 0.1 (1%) | 0.1 (0%) |
| OTHER BAR | 0.3 (4%) | 0.1 (2%) | 0.5 (3%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 4.4 | 0.9 | 82% | 5.5 pts | 24 pts |
| character | 2.4 | 0.9 | 69% | 9.0 pts | 22 pts |
| chariot | 1.5 | 1.2 | 67% | 24.9 pts | 37 pts |
| infantry | 12.4 | 4.1 | 75% | 9.2 pts | 114 pts |
| monster | 0.6 | 0.2 | 77% | 7.3 pts | 4 pts |
| war machine | 8.3 | 7.3 | 61% | 23.9 pts | 198 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.2 | 5.5 | 4.9 |
| Charges that made contact a game | 3.1 | 3.9 | 3.5 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.92 declared, 0.76 contact (25 units) | 0.94 declared, 0.61 contact (18 units) | 0.93 declared, 0.70 contact (43 units) |
|   per unit a game, units carrying another wizard (or one alone) | 0.40 declared, 0.20 contact (5 units) | 0.82 declared, 0.45 contact (11 units) | 0.69 declared, 0.38 contact (16 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.59 declared, 0.42 contact (218 units) | 0.65 declared, 0.47 contact (266 units) | 0.62 declared, 0.44 contact (484 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 61% (47 of 77) | 60% (9 of 15) | 40% (4 of 10) | 59% (60 of 102) |
| Character in a unit | 92% (36 of 39) | 87% (13 of 15) | 40% (2 of 5) | 86% (51 of 59) |
| Character on its own | 84% (32 of 38) | 71% (29 of 41) | 30% (21 of 70) | 55% (82 of 149) |
| Chariot | 82% (9 of 11) | 58% (7 of 12) | - | 70% (16 of 23) |
| Infantry | 66% (46 of 70) | 38% (16 of 42) | 20% (1 of 5) | 54% (63 of 117) |
| Monster | 50% (17 of 34) | 57% (4 of 7) | - | 51% (21 of 41) |
| Monstrous | 70% (7 of 10) | 27% (3 of 11) | - | 48% (10 of 21) |
| War Machines | 67% (29 of 43) | 100% (2 of 2) | - | 69% (31 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (3 of 3); on the table 100% | 21% (20 of 96) | 30% | 59% (13 of 22) | 83% (5 of 6); 3.2 uses a game | 100% (2 of 2); 0.5 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 76% (16 of 21); on the table 86% | 53% (19 of 36) | 50% | 59% (19 of 32) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.2 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (4 of 4); on the table 100% | - | 89% | 75% (18 of 24) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 79% (11 of 14); on the table 79% | 43% (13 of 30) | 39% | 69% (41 of 59) | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |
| Grand Cathay | 8 | 92% (11 of 12); on the table 100% | 32% (61 of 192) | 56% | 65% (48 of 74) | 83% (15 of 18); 4.2 uses a game | 50% (2 of 4); 1.0 uses a game | 25% (2 of 8); 0.2 uses a game |
| High Elf Realms | 7 | 91% (20 of 22); on the table 91% | 19% (8 of 42) | 31% | 52% (28 of 54) | 100% (9 of 9); 3.6 uses a game | 42% (5 of 12); 1.4 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 3 | - | - | 52% | 50% (9 of 18) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Lizardmen | 1 | 100% (4 of 4); on the table 100% | 17% (1 of 6) | 16% | 43% (3 of 7) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 1 | 88% (7 of 8); on the table 88% | 17% (1 of 6) | 4% | 29% (2 of 7) | 100% (1 of 1); 1.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 2 | 100% (1 of 1); on the table 100% | 25% (3 of 12) | 0% | 69% (11 of 16) | 0.0 uses a game | 0.0 uses a game | 0% (0 of 2); 0.0 uses a game |
| Skaven | 2 | 80% (4 of 5); on the table 100% | 42% (5 of 12) | 44% | 64% (9 of 14) | 0.0 uses a game | 0.0 uses a game | 50% (1 of 2); 0.5 uses a game |
| Tomb Kings of Khemri | 6 | 100% (10 of 10); on the table 100% | 33% (2 of 6) | 19% | 31% (8 of 26) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 95% (19 of 20); on the table 100% | 37% (20 of 54) | 34% | 54% (25 of 46) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 11 | 70% (35 of 50); on the table 80% | 30% (9 of 30) | 30% | 60% (58 of 96) | 100% (4 of 4); 1.3 uses a game | 0.0 uses a game | 100% (2 of 2); 0.2 uses a game |
| Wood Elf Realms | 6 | 100% (9 of 9); on the table 100% | 8% (1 of 12) | 45% | 68% (42 of 62) | 91% (10 of 11); 5.8 uses a game | 0.0 uses a game | 0% (0 of 5); 0.0 uses a game |

Flank and rear charges a unit could have turned to face (ef2-opp-f5fe7c8-p3, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 52% (44) | 50% (38) | 51% (82) |
| ...free all their last turn and able to turn (per game) | 0.69 | 0.75 | 1.44 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.28 | 0.11 | 0.39 |
| ...with the charger already in that arc before they moved (per game) | 0.44 | 0.44 | 0.89 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.56 | 0.89 | 2.44 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.64 | 0.58 | 1.22 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 7.86 | 6.94 | 14.81 |

### Quality by phase: ef2-opp-f5fe7c8-p3

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.2 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 53% (64 of 120) | 43% (73 of 169) |
| Strategy | Shoot objectives carried out (shot that target) | 43% (152 of 352) | 51% (82 of 160) |
| Strategy | Close-in objectives charged next turn | 15% (27 of 179) | 17% (33 of 196) |
| Strategy | Support requests answered (helper made contact too) | 92% (11 of 12) | 34% (10 of 29) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (2 of 2) | 100% (1 of 1) |
| Strategy | Hexes on a unit its side charged or shot that turn | 50% (6 of 12) | 60% (3 of 5) |
| Strategy | Joined characters whose unit fought | 45% (17 of 38) | 52% (23 of 44) |
| Strategy | Lone characters that fought | 68% (66 of 97) | 71% (64 of 90) |
| Movement | Charges halted short of contact | 0.1 | 0.2 |
| Movement | Idle units | 0.8 | 1.9 |
| Movement | Points that never moved of their own | 278.2 | 166.1 |
| Movement | Fights charged into per game | 2.8 | 3.2 |
| Movement | Charges with odds: long shots (under 50%) | 9 of 85, net +17 | 11 of 97, net +60 |
| Movement | Charges with odds: sweet spot (55-75%) | 12 of 85, net +90 | 12 of 97, net +229 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 13 of 85, net +95 | 9 of 97, net +71 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 33 of 85, net +58 | 41 of 97, net +70 |
| Shooting | Shots by shooting units (incl. breath weapons) | 7.6 | 9.5 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 46% (126 of 274) | 50% (170 of 341) |
| Shooting | Points destroyed by shooting units | 45.0 | 51.0 |
| Shooting | War machine shots | 6.4 | 1.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 50% (114 of 229) | 42% (29 of 69) |
| Shooting | Points destroyed by war machines | 91.4 | 8.3 |
| Magic | Magic missiles cast | 1.6 | 1.3 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 33% (19 of 58) | 26% (12 of 46) |
| Magic | Wounds caused by magic missiles | 2.7 | 2.4 |
| Magic | Wounds caused by other spells | 1.7 | 1.1 |
| Magic | Points destroyed by magic (all spells) | 74.5 | 27.9 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.3 / 0.3 / 0.6 / 0.2 | 1.8 / 0.2 / 0.2 / 0.4 |
| Combat | Points destroyed in combat | 316.7 | 340.5 |
| Combat | Points run down | 86.3 | 108.2 |
| Combat | Net points per charged fight, damage counted | +73 | +92 |
| Combat | Net per 100 charger points, damage counted | +23.6 | +33.0 |
| Combat | First round won (charged fights) | 74% | 63% |
| Combat | Net points per charged fight | +77 | +85 |
| Combat | Net points per supported fight / lone fight | +107 / +73 | +187 / +64 |
| Combat | Charged fights on a top-3 enemy unit | 27 of 99 | 50 of 116 |
| Game | Points lost | 723.8 | 705.8 |
| Game | VP from objectives | 557.2 | 524.4 |
| Game | Lone holders (player turns) | 4.3 | 1.7 |

- Mine won / drew / lost: 12 / 7 / 17 of 36 ended games (of 36); mean margin (Mine - Opponent) -39 VP
- The side that went first won 11 of 29 games with a winner
- Points traded per game (both sides' losses): 1430
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ef2-opp-f5fe7c8-p3

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | 0.0 | +0.1 | 0.0 | 0.0 | 0.0 | +0.2 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 1.8 | +0.0 | 0.0 | 10.6 | 0.1 | +0.0 | 0.0 | 4.6 |
| BACKUP TARGETS | 0.8 | +6.4 | 0.0 | 30.3 | 0.6 | +5.3 | 0.0 | 7.7 |
| BEST PREY | 4.1 | +281.7 | 140.6 | 100.4 | 3.9 | +227.7 | 217.6 | 97.3 |
| BEST PRIZE | 0.0 | -2.9 | 3.1 | 11.0 | 0.0 | -7.6 | 4.6 | 0.0 |
| BLOCKED CHARGE HANDED OVER | 0.0 | +0.9 | 5.9 | 0.0 | - | - | - | - |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 9.3 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| BLOCKED WHEEL | 0.6 | +6.7 | 0.0 | 0.0 | 0.2 | +4.8 | 0.0 | 0.0 |
| BOMBING RUN | 0.0 | +0.8 | 0.0 | 0.0 | 0.0 | +0.5 | 0.0 | 4.2 |
| CANNON PLAN MISSED | 1.0 | +0.0 | 67.8 | 13.3 | 0.1 | +0.0 | 0.0 | 0.0 |
| CANNON PLANNED TARGET | 5.4 | +177.4 | 309.9 | 76.4 | 1.1 | +38.5 | 61.5 | 41.1 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 0.0 | 0.3 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.1 | -1.5 | 14.5 | 2.6 | 0.0 | -0.7 | 0.0 | 0.0 |
| CARRIES OUT SET-UP | 0.1 | -2.3 | 10.1 | 0.0 | 0.1 | -6.0 | 21.6 | 4.5 |
| CAST JOB | 0.9 | +23.7 | 103.4 | 24.2 | 0.5 | +12.9 | 28.5 | 6.5 |
| CASTER AWAY FROM SCREEN | 0.2 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +48.1 | 15.3 | 18.4 | 0.1 | +1.6 | 3.2 | 0.0 |
| CASTS AFTER FRIENDS | 0.6 | +0.0 | 0.0 | 31.4 | 0.5 | +0.0 | 0.0 | 17.6 |
| CASTS FROM BEHIND | 0.0 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.6 | 0.0 | 0.0 | - | - | - | - |
| CHAFF PASSED | 0.1 | -0.1 | 0.0 | 0.0 | 0.2 | -0.3 | 7.1 | 9.4 |
| CHAMPION TAKES THE CHALLENGE | 0.0 | +0.8 | 0.0 | 3.2 | - | - | - | - |
| CHARGE NOW WEIGHED | 0.6 | -66.1 | 0.0 | 42.4 | 0.7 | -63.8 | 17.0 | 40.8 |
| CHARIOT NO STATIC JOB | 0.8 | +0.0 | 7.6 | 19.8 | 0.6 | +0.0 | 16.9 | 20.0 |
| CHEAP HELPER | 0.1 | +0.0 | 13.3 | 1.2 | 0.2 | +0.0 | 9.3 | 6.1 |
| CONVEYANCE SEARCH | 0.8 | +53.7 | 34.4 | 42.2 | 0.4 | +47.6 | 6.5 | 6.5 |
| COUNTER-CHARGE COVER | 8.3 | +700.7 | 0.0 | 187.5 | 5.7 | +269.5 | 0.0 | 122.9 |
| EDGE GIVE GROUND | 0.2 | +11.8 | 34.2 | 0.0 | 0.2 | +2.8 | 22.2 | 0.0 |
| ENEMY FORECAST | - | - | - | - | 7.4 | +164.8 | 104.0 | 184.0 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.6 | +150.1 | 0.0 | 11.3 | 0.9 | +74.2 | 0.0 | 46.8 |
| FALLBACK BY WORTH | 6.0 | +94.0 | 0.0 | 102.5 | 6.5 | +84.6 | 0.0 | 94.7 |
| FIGHT LIFT | 0.1 | +0.7 | 0.0 | 0.0 | 0.0 | +1.6 | 5.9 | 1.7 |
| FIRE AND FLEE | - | - | - | - | 0.0 | +0.4 | 11.0 | 3.9 |
| FLANK NOT WEIGHED | 0.3 | +0.0 | 0.0 | 11.6 | 0.2 | +0.0 | 0.0 | 12.4 |
| FOLLOW UP WEIGHED | 1.1 | +155.8 | 0.0 | 18.5 | 0.9 | +116.6 | 0.0 | 52.4 |
| FORECAST RESULT | 38.6 | +2148.0 | 544.3 | 996.3 | 38.4 | +1649.7 | 754.4 | 850.9 |
| FRIENDS SHOTS CHECKED | 0.3 | +28.4 | 0.0 | 0.0 | 0.1 | +14.9 | 0.0 | 0.0 |
| GIVES UP | 1.1 | -28.6 | 136.6 | 7.6 | 1.6 | -49.3 | 160.4 | 64.8 |
| GIVES UP ITS SCREEN | 0.5 | -11.7 | 61.5 | 12.2 | 0.8 | -18.0 | 51.8 | 12.2 |
| GROUND FLIERS | 0.1 | +1.5 | 0.0 | 0.0 | 0.0 | +0.1 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 0.0 | 3.1 | 0.0 | +0.0 | 10.2 | 0.0 |
| HELPER UNSEEN | 0.2 | +0.0 | 45.7 | 2.9 | 0.7 | +0.0 | 56.5 | 12.2 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.7 | +0.0 | 0.0 | 0.0 |
| HORN WORTH | - | - | - | - | 0.1 | +1.7 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.1 | +6.4 | 4.6 | 1.4 | 0.1 | +5.7 | 5.4 | 3.2 |
| HUNT DROPPED | 0.1 | +0.0 | 4.6 | 0.0 | 0.0 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.4 | +4.5 | 0.0 | 12.1 | 0.6 | +23.9 | 0.0 | 0.0 |
| HUNT KEPT | 0.1 | +3.1 | 13.8 | 1.4 | - | - | - | - |
| HUNT RESULT | 0.2 | +22.0 | 4.6 | 0.0 | 0.1 | +6.8 | 0.0 | 0.0 |
| HUNT THE GUNS | 0.2 | +93.8 | 14.6 | 3.1 | 0.1 | +31.5 | 5.4 | 3.2 |
| JOINT CHARGE PLAN | 0.1 | +7.4 | 0.0 | 3.2 | 0.2 | +5.2 | 9.5 | 2.0 |
| KEEP FALLS | 0.1 | +2.6 | 0.0 | 0.0 | 0.0 | +0.5 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.2 | +2.3 | 9.6 | 20.4 | 0.2 | +1.6 | 13.9 | 0.0 |
| KEEPS ITS TARGET | 1.6 | +49.2 | 135.5 | 34.6 | 1.9 | +57.5 | 187.3 | 24.2 |
| KEEPS SCOUTS OR AMBUSH | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 1.6 | +81.5 | 161.3 | 30.4 | 2.1 | +108.4 | 136.8 | 60.4 |
| KILLS COUNT NEXT TURN | 8.9 | +309.2 | 308.9 | 266.3 | 10.0 | +434.4 | 503.1 | 242.5 |
| LONE CHARACTER SAFE SPOT | 0.6 | +37.8 | 9.5 | 23.2 | 0.3 | +3.4 | 26.7 | 15.5 |
| LONE WIZARD HOLDS BACK | 1.6 | +0.0 | 108.9 | 26.5 | 1.5 | +0.0 | 45.2 | 46.8 |
| LONE WIZARD KEPT IN | 0.6 | +37.3 | 0.0 | 0.0 | 0.3 | +22.1 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.9 | +57.5 | 53.5 | 1.4 | 1.2 | +51.6 | 53.0 | 28.3 |
| MANOEUVRE | 0.2 | +11.7 | 0.0 | 0.0 | 0.1 | +6.7 | 0.0 | 0.0 |
| MARCH AT ESCAPER | 0.2 | +0.5 | 0.0 | 10.2 | 0.1 | +0.2 | 0.0 | 3.2 |
| MARCH CHECK | 0.7 | +17.6 | 0.0 | 6.8 | 0.9 | +38.3 | 0.0 | 19.1 |
| MARCH ODDS | 0.8 | +42.8 | 21.2 | 20.8 | 0.7 | +47.0 | 21.5 | 18.5 |
| MARCH OVER CASTS | 1.0 | +36.9 | 0.0 | 20.5 | 1.2 | -21.3 | 0.0 | 40.3 |
| MAX FOR POSITIONING | 4.5 | +156.6 | 0.0 | 111.6 | 3.7 | +124.6 | 0.0 | 77.6 |
| MISSILES IN THE MOVE | 3.5 | +123.6 | 0.0 | 98.9 | 3.5 | +56.2 | 0.0 | 61.8 |
| MISSILES NEXT TURN | 5.2 | +83.6 | 0.0 | 142.5 | 5.0 | +49.9 | 0.0 | 109.6 |
| MODEL FACING | 0.1 | +11.3 | 0.0 | 1.7 | - | - | - | - |
| MOVE AND CAST | 0.4 | +39.8 | 0.0 | 17.4 | 0.2 | +4.3 | 0.0 | 6.5 |
| MOVE SPELL IN RANGE | 0.2 | +11.1 | 0.0 | 31.7 | 0.0 | +0.7 | 0.0 | 6.5 |
| MOVE SPELL OUT OF RANGE | 0.3 | -10.6 | 0.0 | 64.6 | 0.1 | -0.9 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.4 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 11.1 |
| MOVES UNITS SPELL | 0.1 | +3.6 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 0.0 |
| NEEDED THERE | - | - | - | - | 0.0 | +1.6 | 0.0 | 0.0 |
| NO RALLY LEFT | 0.1 | +2.8 | 0.0 | 1.8 | - | - | - | - |
| NOT NEEDED | 0.2 | -8.9 | 27.7 | 13.0 | 0.4 | -35.1 | 43.1 | 7.6 |
| NOT TURNED | 7.9 | +137.5 | 0.0 | 219.3 | 6.9 | +50.5 | 0.0 | 150.1 |
| NOT WORTH A CAST | 0.5 | -0.3 | 0.0 | 51.7 | 0.8 | -4.8 | 0.0 | 6.5 |
| OPENS A LANE | 0.1 | +0.1 | 0.0 | 0.0 | 0.1 | +0.9 | 5.6 | 5.4 |
| OPENS UP | 0.3 | +28.7 | 14.2 | 0.0 | 0.1 | +10.1 | 5.1 | 0.0 |
| OVERRUNS AWAY | 0.5 | +14.8 | 32.4 | 7.6 | 0.4 | +6.6 | 34.5 | 5.6 |
| PATHS CROSS | 2.8 | +134.3 | 0.0 | 47.4 | 2.7 | +169.2 | 0.0 | 32.6 |
| PERIAPT WORTH | 0.0 | +1.5 | 0.0 | 0.0 | - | - | - | - |
| PLAN LEADS | 1.2 | +109.8 | 41.1 | 12.8 | 0.9 | +82.6 | 17.5 | 12.8 |
| PLAN RESULT | 36.6 | +1552.9 | 1262.1 | 835.6 | 37.8 | +1395.9 | 1122.9 | 1026.7 |
| PURSUES BIG PREY | 0.0 | -0.9 | 0.0 | 0.0 | 0.1 | -18.4 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.0 | +4.9 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +10.6 | 0.0 | 1.5 | 0.1 | +5.9 | 0.0 | 2.6 |
| REDIRECT COUNTER | 2.9 | +145.5 | 0.0 | 47.0 | 3.2 | +142.8 | 0.0 | 60.1 |
| REDIRECT WEIGHED | 0.3 | +20.0 | 14.3 | 0.0 | 0.3 | +1.6 | 0.0 | 1.1 |
| RESTRAINS TO SHOOT | 0.1 | +5.2 | 0.0 | 10.5 | 0.0 | +0.8 | 0.0 | 0.0 |
| RISK BY ARC | 2.2 | +71.6 | 196.6 | 63.7 | 2.9 | +50.7 | 216.9 | 61.5 |
| SAFER THAN THE JOB | 0.6 | +40.1 | 0.0 | 10.3 | 0.6 | +13.1 | 0.0 | 16.0 |
| SCOUT SPOT | 0.4 | +0.3 | 0.0 | 0.9 | 0.3 | +0.8 | 0.0 | 0.0 |
| SCOUT WAITS | 0.4 | +0.0 | 0.0 | 0.9 | 0.3 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 1.2 | +56.7 | 0.0 | 39.2 | 1.1 | +41.7 | 0.0 | 38.9 |
| SECOND HUNTER | 0.0 | -0.0 | 0.0 | 1.7 | - | - | - | - |
| SELF MOVE SPELL | 0.4 | +53.7 | 0.0 | 21.9 | 0.2 | +54.6 | 0.0 | 0.0 |
| SET UP TOGETHER | 1.4 | +103.7 | 62.9 | 30.6 | 1.8 | +93.0 | 53.0 | 60.4 |
| SET-UP ANY TARGET | 0.5 | +84.8 | 20.2 | 21.8 | 0.2 | +22.6 | 0.0 | 0.0 |
| SET-UP MISSED | 0.1 | +7.5 | 0.0 | 10.6 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.3 | +0.6 | 0.0 | 0.0 | 0.1 | +0.1 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SHOT REPLANNED | 0.5 | +0.0 | 81.1 | 7.2 | 0.1 | +0.0 | 22.0 | 1.8 |
| SHOTS IN THE MOVE | 11.9 | +517.9 | 0.0 | 174.3 | 9.0 | +246.3 | 0.0 | 162.4 |
| SPELL SETS UP CHARGE | 0.6 | +99.7 | 20.2 | 21.8 | 0.2 | +31.6 | 0.0 | 0.0 |
| SPELL WORTH | 1.4 | +24.6 | 38.6 | 38.6 | 2.2 | +30.9 | 102.4 | 94.9 |
| STANDS TO CAST | 0.1 | +2.0 | 0.0 | 0.0 | 0.0 | +2.0 | 0.0 | 0.0 |
| STOPS | 0.2 | +7.0 | 23.8 | 1.7 | - | - | - | - |
| STUCK PIVOT | 0.1 | +0.0 | 0.0 | 4.7 | 0.3 | +0.0 | 0.0 | 4.7 |
| SUPPORT JOB KEPT | 0.0 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| SURE CHARGE BEATS ADVANCE | 0.2 | -5.0 | 3.8 | 0.0 | 0.1 | -4.0 | 8.9 | 0.0 |
| SURE REACH TOGETHER | 0.3 | -10.3 | 18.7 | 16.7 | 0.7 | +12.3 | 0.0 | 11.7 |
| THROUGH LINE OF FIRE | 0.5 | +14.0 | 0.0 | 11.4 | 0.2 | +10.4 | 0.0 | 22.9 |
| TURN WORTH | 0.4 | -31.7 | 42.8 | 2.4 | 0.5 | -34.5 | 36.3 | 9.9 |
| TWO OR MORE ARRIVE | 0.4 | +4.7 | 5.9 | 8.1 | 0.6 | +6.5 | 23.8 | 27.4 |
| WEARS DOWN | 0.7 | +51.6 | 84.1 | 20.4 | 0.9 | +26.2 | 79.8 | 32.1 |
| WHO HITS BACK | 0.1 | +11.1 | 0.0 | 16.1 | 0.2 | +10.4 | 0.0 | 4.7 |
| WHOLE FIGHT | 0.4 | +5.6 | 45.6 | 7.1 | 0.4 | +6.6 | 44.0 | 0.5 |
| WHOLE FIGHT GAIN | 0.2 | +22.0 | 15.2 | 6.8 | 0.6 | +45.1 | 46.3 | 11.5 |

### Rule changes: ef2-opp-f5fe7c8-p3

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| PATHS CROSS | 196 | 196 | 196 | 5.44 | +10927 | +55.8 |
| KILLS COUNT NEXT TURN | 683 | 678 | 176 | 4.89 | +5659 | +32.2 |
| BEST PREY | 287 | 280 | 120 | 3.33 | +4595 | +38.3 |
| FALLBACK BY WORTH | 451 | 451 | 106 | 2.94 | +6432 | +60.7 |
| COUNTER-CHARGE COVER | 504 | 229 | 96 | 2.67 | +4588 | +47.8 |
| FACES THE THREAT | 88 | 88 | 88 | 2.44 | +8072 | +91.7 |
| SEARCH SPOT | 83 | 83 | 82 | 2.28 | +3545 | +43.2 |
| SHOTS IN THE MOVE | 753 | 469 | 73 | 2.03 | +1844 | +25.3 |
| FOLLOW UP WEIGHED | 72 | 72 | 72 | 2.00 | +9807 | +136.2 |
| ARTILLERY RE-ROLL WEIGHED | 71 | 71 | 71 | 1.97 | +0 | +0.0 |
| ENEMY FORECAST | 268 | 263 | 60 | 1.67 | +417 | +7.0 |
| CANNON SIGHT KEPT | 56 | 56 | 56 | 1.56 | +0 | +0.0 |
| MARCH ODDS | 53 | 52 | 51 | 1.42 | +718 | +14.1 |
| MAX FOR POSITIONING | 297 | 147 | 46 | 1.28 | +374 | +8.1 |
| SET UP TOGETHER | 115 | 92 | 45 | 1.25 | +2689 | +59.7 |
| CHARGE NOW WEIGHED | 44 | 44 | 44 | 1.22 | +3291 | +74.8 |
| SAFER THAN THE JOB | 44 | 44 | 44 | 1.22 | +1916 | +43.5 |
| RISK BY ARC | 183 | 164 | 43 | 1.19 | +1414 | +32.9 |
| KILLS COUNT | 132 | 121 | 41 | 1.14 | +2484 | +60.6 |
| HOLDS AMBUSHERS | 39 | 39 | 39 | 1.08 | +0 | +0.0 |
| LONE WIZARD HOLDS BACK | 113 | 113 | 39 | 1.08 | -3320 | -85.1 |
| PLAN LEADS | 79 | 79 | 39 | 1.08 | +2501 | +64.1 |
| CANNON PLANNED TARGET | 231 | 231 | 37 | 1.03 | -230 | -6.2 |
| LONE WIZARD KEPT IN | 32 | 32 | 32 | 0.89 | +2140 | +66.9 |
| ADVANCE LANE KEPT | 31 | 31 | 31 | 0.86 | +0 | +0.0 |
| CHARIOT NO STATIC JOB | 51 | 51 | 30 | 0.83 | -1721 | -57.4 |
| BLOCKED WHEEL | 29 | 29 | 29 | 0.81 | +414 | +14.3 |
| KEEPS ITS TARGET | 128 | 126 | 25 | 0.69 | +383 | +15.3 |
| MISSILES IN THE MOVE | 253 | 116 | 25 | 0.69 | +600 | +24.0 |
| REDIRECT COUNTER | 219 | 80 | 25 | 0.69 | +1498 | +59.9 |
| SCOUT WAITS | 25 | 25 | 25 | 0.69 | +0 | +0.0 |
| MARCH CHECK | 57 | 32 | 24 | 0.67 | +325 | +13.5 |
| THROUGH LINE OF FIRE | 24 | 24 | 24 | 0.67 | +878 | +36.6 |
| MOVE AND CAST | 23 | 23 | 23 | 0.64 | +1589 | +69.1 |
| SHOT REPLANNED | 23 | 23 | 23 | 0.64 | +0 | +0.0 |
| CAST JOB | 52 | 50 | 22 | 0.61 | +426 | +19.3 |
| REDIRECT WEIGHED | 21 | 21 | 21 | 0.58 | +1782 | +84.9 |
| MAKE SURE TOGETHER | 73 | 46 | 20 | 0.56 | +1099 | +55.0 |
| WEARS DOWN | 56 | 52 | 18 | 0.50 | +686 | +38.1 |
| CASTING BLOCK | 20 | 20 | 17 | 0.47 | +728 | +42.9 |
| SHOOTERS IN TWO RANKS | 16 | 16 | 16 | 0.44 | +27 | +1.7 |
| STUCK PIVOT | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| FRIENDS SHOTS CHECKED | 15 | 15 | 15 | 0.42 | +1556 | +103.7 |
| WHOLE FIGHT GAIN | 30 | 27 | 14 | 0.39 | +657 | +46.9 |
| SURE CHARGE BEATS ADVANCE | 11 | 11 | 11 | 0.31 | -324 | -29.4 |
| CHAFF PASSED | 10 | 10 | 10 | 0.28 | -16 | -1.6 |
| MANOEUVRE | 10 | 10 | 10 | 0.28 | +662 | +66.2 |
| CASTER AWAY FROM SCREEN | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| OPENS UP | 13 | 10 | 9 | 0.25 | +597 | +66.4 |
| WHO HITS BACK | 9 | 9 | 9 | 0.25 | -860 | -95.6 |
| MISSILES NEXT TURN | 368 | 162 | 7 | 0.19 | +47 | +6.8 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +141 | +20.1 |
| RAIDS THE BAGGAGE NEXT TURN | 7 | 7 | 7 | 0.19 | +192 | +27.5 |
| BLOCKED CHARGE SKIPPED | 6 | 6 | 6 | 0.17 | +0 | +0.0 |
| HUNT IN PAIRS | 34 | 19 | 6 | 0.17 | +75 | +12.4 |
| PURSUES BIG PREY | 6 | 6 | 6 | 0.17 | -695 | -115.8 |
| WHOLE FIGHT | 30 | 22 | 6 | 0.17 | +277 | +46.1 |
| RESTRAINS TO SHOOT | 5 | 5 | 5 | 0.14 | +217 | +43.4 |
| SHORT GUN FORWARD | 5 | 5 | 5 | 0.14 | +0 | +0.0 |
| CARRIES OUT SET-UP | 8 | 8 | 4 | 0.11 | -298 | -74.5 |
| SURE REACH TOGETHER | 37 | 30 | 4 | 0.11 | +9 | +2.2 |
| HORN WORTH | 3 | 3 | 3 | 0.08 | +62 | +20.5 |
| HUNT ADVANCE | 8 | 8 | 3 | 0.08 | +250 | +83.4 |
| JOINT CHARGE PLAN | 12 | 12 | 3 | 0.08 | +114 | +37.9 |
| KEEP FALLS | 3 | 3 | 3 | 0.08 | +161 | +53.7 |
| MODEL FACING | 3 | 3 | 3 | 0.08 | +408 | +135.8 |
| NO RALLY LEFT | 3 | 3 | 3 | 0.08 | +27 | +9.0 |
| OVERRUNS AWAY | 32 | 28 | 3 | 0.08 | +81 | +27.0 |
| BACKUP TARGETS | 47 | 17 | 2 | 0.06 | +2 | +1.0 |
| BEST PRIZE | 2 | 2 | 2 | 0.06 | -378 | -188.8 |
| BOMBING RUN | 2 | 2 | 2 | 0.06 | +44 | +22.1 |
| CARRIES OUT COUNTER | 5 | 5 | 2 | 0.06 | -82 | -41.0 |
| EDGE GIVE GROUND | 14 | 14 | 2 | 0.06 | +122 | +61.1 |
| KEEPS ITS PREY | 13 | 12 | 2 | 0.06 | +1 | +0.7 |
| STANDS TO CAST | 3 | 2 | 2 | 0.06 | -53 | -26.4 |
| STOPS | 6 | 6 | 2 | 0.06 | +113 | +56.6 |
| TWO OR MORE ARRIVE | 37 | 36 | 2 | 0.06 | +3 | +1.7 |
| BLOCKED CHARGE HANDED OVER | 1 | 1 | 1 | 0.03 | +33 | +32.6 |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 1 | 0.03 | +5 | +5.0 |
| FIRE AND FLEE | 1 | 1 | 1 | 0.03 | +15 | +15.4 |
| GIVES UP | 96 | 87 | 1 | 0.03 | +64 | +64.4 |
| GIVES UP ITS SCREEN | 48 | 46 | 1 | 0.03 | +14 | +14.2 |
| KEEPS SCOUTS OR AMBUSH | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| MOVE SPELL IN RANGE | 10 | 5 | 1 | 0.03 | +53 | +53.0 |
| NEEDED THERE | 1 | 1 | 1 | 0.03 | +0 | +0.0 |
| PERIAPT WORTH | 1 | 1 | 1 | 0.03 | +54 | +54.4 |
| RAIDS THE BAGGAGE | 1 | 1 | 1 | 0.03 | +169 | +169.1 |
| SUPPORT JOB KEPT | 1 | 1 | 1 | 0.03 | +20 | +20.2 |
| ALREADY CARRIED | 3 | not checked | - | - | - | - |
| ARRIVAL HUNT | 2 | 2 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 38 | 38 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 41 | trace | - | - | - | - |
| CATCH FLIERS | 1 | not checked | - | - | - | - |
| CHEAP HELPER | 10 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 42 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 5 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 19 | not checked | - | - | - | - |
| FORECAST RESULT | 2771 | trace | - | - | - | - |
| GROUND FLIERS | 3 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 2 | not checked | - | - | - | - |
| HELPER UNSEEN | 32 | 24 | 0 | 0.00 | - | - |
| HUNT DROPPED | 4 | trace | - | - | - | - |
| HUNT KEPT | 4 | trace | - | - | - | - |
| HUNT RESULT | 10 | trace | - | - | - | - |
| HUNT THE GUNS | 11 | trace | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 32 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 9 | trace | - | - | - | - |
| MARCH OVER CASTS | 80 | 80 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 13 | trace | - | - | - | - |
| MOVE SPELL SPOT | 22 | not checked | - | - | - | - |
| NOT NEEDED | 23 | 22 | 0 | 0.00 | - | - |
| NOT TURNED | 533 | 533 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 44 | not checked | - | - | - | - |
| OPENS A LANE | 5 | 1 | 0 | 0.00 | - | - |
| PLAN RESULT | 2679 | trace | - | - | - | - |
| SCOUT SPOT | 24 | 24 | 0 | 0.00 | - | - |
| SECOND HUNTER | 1 | 1 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 24 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 23 | not checked | - | - | - | - |
| SET-UP MISSED | 2 | trace | - | - | - | - |
| SPELL SETS UP CHARGE | 27 | not checked | - | - | - | - |
| SPELL WORTH | 127 | not checked | - | - | - | - |
| TURN WORTH | 35 | 29 | 0 | 0.00 | - | - |

### Plans: ef2-opp-f5fe7c8-p3

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 12.4 | 20% | 547 | 430 | 79% |
| Mine | charge | 2.8 | 69% | 268 | 290 | 108% |
| Mine | close in | 4.9 | 27% | 331 | 162 | 49% |
| Mine | hold | 3.6 | 44% | 223 | 0 | 0% |
| Mine | join | 0.7 | 96% | 23 | 0 | 0% |
| Mine | shoot | 8.5 | 63% | 228 | 671 | 294% |
| Mine | support | 3.8 | 87% | 197 | 0 | 0% |
| Opponent | advance | 13.5 | 21% | 716 | 529 | 74% |
| Opponent | charge | 4.2 | 61% | 344 | 407 | 118% |
| Opponent | close in | 5.3 | 27% | 406 | 177 | 44% |
| Opponent | hold | 4.1 | 32% | 387 | 0 | 0% |
| Opponent | join | 0.9 | 90% | 38 | 0 | 0% |
| Opponent | shoot | 3.6 | 64% | 87 | 285 | 326% |
| Opponent | support | 6.2 | 92% | 286 | 0 | 0% |

### Enemy forecast: ef2-opp-f5fe7c8-p3

Per side (the computer that made the forecast) and expected action: forecasts a game, right (it did the expected action on the expected target), gone (missed, but the target or the enemy was gone before it acted), and what the enemy did instead; right of judged leaves the gone ones out.

| Side | Expected | A game | Right | Gone | Right of judged | Did charge | Did shoot | Did move | Same target |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.7 | 48% | 13% | 55% | 54% | 14% | 32% | 54% |
| Mine | shoot | 7.5 | 31% | 18% | 38% | 1% | 68% | 31% | 32% |
| Mine | move | 27.4 | 74% | 3% | 77% | 9% | 17% | 74% | - |
| Mine | all | 38.6 | 63% | 7% | 68% | 12% | 26% | 62% | - |
| Opponent | charge | 2.6 | 47% | 16% | 56% | 56% | 9% | 35% | 49% |
| Opponent | shoot | 12.4 | 36% | 19% | 45% | 2% | 73% | 26% | 37% |
| Opponent | move | 23.4 | 67% | 5% | 70% | 9% | 24% | 67% | - |
| Opponent | all | 38.4 | 56% | 10% | 62% | 10% | 39% | 52% | - |

Expected moves (the enemy's own plan): how far the expected end was from where the unit ended, against the guess that it stays where it stood.

| Side | Moves a game | Median miss | Median miss if it stays | Within 3" | Within 6" | Better than stays |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | 19.2 | 6.2" | 3.9" | 24% | 49% | 22% |
| Opponent | 14.8 | 6.2" | 4.0" | 24% | 48% | 26% |

### Packages: hunt the guns, ef2-opp-f5fe7c8-p3

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.2 | 8 | 1 | 43% | 43% | 0% | 2.7 | 447 | 113 | 29% | 16 |
| Opponent | 0.1 | 3 | 0 | 0% | 33% | 0% | 2.0 | 378 | 81 | 33% | 84 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.8 | 3 | 1 | 50% | 50% | 0% | 4.0 | 380 | 82 | 0% | 47 |
| Chaos Dwarfs | 0.2 | 1 | 0 | 100% | 100% | 0% | 2.0 | 427 | 418 | 100% | 28 |
| Dwarfen Mountain Holds | 0.7 | 2 | 0 | 0% | 0% | 0% | - | 553 | 0 | 0% | 0 |
| Empire of Man | 0.3 | 2 | 0 | 50% | 50% | 0% | 2.0 | 417 | 104 | 50% | 47 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 21 |
| High Elf Realms | 0.1 | 1 | 0 | 0% | 0% | 0% | - | 581 | 0 | 0% | 188 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 217 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Tomb Kings of Khemri | 0.2 | 1 | 0 | 0% | 0% | 0% | - | 298 | 0 | 0% | 12 |
| Vampire Counts | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 24 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 24 |
| Wood Elf Realms | 0.2 | 1 | 0 | 0% | 100% | 0% | 2.0 | 253 | 243 | 100% | 60 |

### Battle groups: ef2-opp-f5fe7c8-p3

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 8.3 | 20% | 50% | 8% | 80% | 44% | 9% | 5% | 42% | 0% |
| Mine | REDIRECT COUNTER | 2.9 | 27% | 68% | 14% | 0% | 17% | 12% | 12% | 58% | 0% |
| Opponent | COUNTER-CHARGE COVER | 5.7 | 20% | 57% | 19% | 62% | 21% | 9% | 15% | 56% | 0% |
| Opponent | REDIRECT COUNTER | 3.2 | 22% | 64% | 8% | 0% | 30% | 0% | 9% | 52% | 9% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ef2-opp-f5fe7c8-p3

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 1 | 160 (1) | 160 | 0 | 0 | 0% | 4.0 | - | 160 (1) | - | 160 (1) | - |
| Mine | Chaff | 40 | 39 (40) | 12 | 27 | 63 | 48% | 2.5 | 37 (20) | 0 (8) | 67 (12) | 50 (32) | 0 (8) |
| Mine | Character | 120 | 46 (120) | 46 | 0 | 31 | 21% | 2.5 | 46 (42) | 53 (56) | 54 (7) | 52 (57) | 48 (48) |
| Mine | Clean-up | 15 | 62 (15) | 24 | 38 | 44 | 7% | 3.1 | 69 (7) | 50 (6) | 89 (2) | 76 (8) | 45 (7) |
| Mine | Fast Hammer | 43 | 40 (43) | 21 | 19 | 47 | 14% | 3.3 | 38 (24) | 48 (13) | 19 (6) | 45 (31) | 25 (12) |
| Mine | Fragile | 3 | 0 (3) | 0 | 0 | 33 | 33% | 5.5 | 0 (3) | - | - | 0 (1) | 0 (2) |
| Mine | Hammer | 50 | 52 (50) | 35 | 17 | 35 | 12% | 2.7 | 20 (13) | 58 (32) | 88 (5) | 35 (34) | 84 (16) |
| Mine | Holder | 25 | 37 (25) | 0 | 37 | 44 | 28% | 3.3 | 22 (6) | 65 (10) | 4 (8) | 50 (12) | 27 (12) |
| Mine | Shooter | 38 | 62 (38) | 27 | 34 | 39 | 3% | 1.8 | 18 (10) | 84 (25) | 0 (3) | 60 (24) | 65 (14) |
| Mine | Support | 4 | 46 (4) | 46 | 0 | 58 | 0% | 3.8 | 0 (1) | - | - | 0 (1) | - |
| Mine | War machine | 52 | 46 (52) | 46 | 0 | 35 | 2% | 1.1 | 60 (14) | 42 (34) | 36 (4) | 46 (14) | 47 (38) |
| Mine | Wizard | 15 | 0 (15) | 0 | 0 | 47 | 13% | 2.4 | 0 (2) | 0 (8) | 0 (1) | 0 (6) | 0 (5) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 73 | 33 (73) | 8 | 25 | 55 | 48% | 2.8 | 15 (31) | 93 (13) | 17 (29) | 38 (52) | 21 (21) |
| Opponent | Character | 101 | 44 (101) | 44 | 0 | 33 | 18% | 2.3 | 55 (38) | 40 (52) | 43 (5) | 61 (54) | 31 (41) |
| Opponent | Clean-up | 9 | 45 (9) | 22 | 23 | 36 | 33% | 3.0 | 53 (3) | 14 (4) | 138 (2) | 78 (5) | 15 (4) |
| Opponent | Fast Hammer | 60 | 48 (60) | 35 | 13 | 43 | 25% | 2.7 | 43 (31) | 35 (17) | 92 (12) | 50 (32) | 46 (28) |
| Opponent | Fragile | 3 | 62 (3) | 62 | 0 | 67 | 33% | 3.5 | - | 92 (2) | 0 (1) | 92 (2) | 0 (1) |
| Opponent | Hammer | 47 | 75 (47) | 62 | 13 | 38 | 26% | 3.4 | 102 (15) | 67 (28) | 58 (4) | 66 (25) | 86 (22) |
| Opponent | Holder | 40 | 55 (40) | 11 | 44 | 37 | 38% | 2.5 | 25 (8) | 63 (19) | 67 (13) | 58 (26) | 50 (14) |
| Opponent | Shooter | 28 | 42 (28) | 30 | 12 | 36 | 0% | 1.2 | 5 (7) | 58 (20) | 0 (1) | 48 (17) | 35 (11) |
| Opponent | Support | 4 | 0 (4) | 0 | 0 | 33 | 100% | - | 0 (1) | 0 (1) | 0 (1) | 0 (2) | 0 (1) |
| Opponent | War machine | 17 | 28 (17) | 28 | 0 | 55 | 6% | 1.4 | 0 (3) | 9 (10) | 85 (4) | 36 (3) | 27 (14) |
| Opponent | Wizard | 33 | 19 (33) | 19 | 0 | 25 | 9% | 2.4 | 0 (15) | 36 (8) | 61 (5) | 27 (17) | 14 (11) |

### Charged fights: ef2-opp-f5fe7c8-p3

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 80 | 86 | 0.8 | 1.0 | 115 | 55 | +60 | 0 of 3 | 3 of 3 | - | +60 |
| Mine | Chaos Dwarfs | 4 | 272 | 154 | 3.0 | 1.2 | 51 | 17 | +34 | 6 of 12 | 10 of 12 | +96 | +13 |
| Mine | Dwarfen Mountain Holds | 3 | 302 | 102 | 1.7 | 1.0 | 61 | 0 | +61 | 3 of 5 | 4 of 5 | - | +61 |
| Mine | Empire of Man | 5 | 223 | 125 | 2.6 | 1.1 | 48 | 36 | +12 | 2 of 13 | 13 of 13 | +104 | +4 |
| Mine | Grand Cathay | 5 | 496 | 245 | 2.0 | 1.0 | 122 | 0 | +122 | 0 of 10 | 7 of 10 | - | +122 |
| Mine | High Elf Realms | 4 | 210 | 862 | 4.8 | 1.3 | 181 | 44 | +138 | 7 of 19 | 13 of 19 | +86 | +151 |
| Mine | Kingdom of Bretonnia | 1 | 0 | 0 | 1.0 | 1.0 | 0 | 275 | -275 | 0 of 1 | 0 of 1 | - | -275 |
| Mine | Lizardmen | 1 | 311 | 896 | 4.0 | 1.0 | 224 | 44 | +180 | 0 of 4 | 3 of 4 | - | +180 |
| Mine | Ogre Kingdoms | 1 | 116 | 314 | 5.0 | 1.4 | 63 | 44 | +19 | 2 of 5 | 5 of 5 | +0 | +24 |
| Mine | Orc & Goblin Tribes | 1 | 0 | 137 | 3.0 | 1.0 | 46 | 151 | -106 | 1 of 3 | 2 of 3 | - | -106 |
| Mine | Skaven | 1 | 19 | 0 | 1.0 | 2.0 | 0 | 65 | -65 | 1 of 1 | 0 of 1 | -65 | - |
| Mine | Tomb Kings of Khemri | 2 | 35 | 713 | 5.0 | 1.0 | 143 | 12 | +130 | 2 of 10 | 7 of 10 | - | +130 |
| Mine | Vampire Counts | 2 | 164 | 742 | 5.0 | 1.2 | 148 | 10 | +138 | 2 of 10 | 4 of 10 | +304 | +96 |
| Mine | Warriors of Chaos | 2 | 0 | 0 | 1.5 | 1.0 | 0 | 40 | -40 | 1 of 3 | 2 of 3 | - | -40 |
| **Mine** | all armies | 36 | 211 | 300 | 2.8 | 1.1 | 109 | 32 | +77 | 27 of 99 | 73 of 99 | +107 | +73 |
| Opponent | Empire of Man | 1 | 618 | 0 | 2.0 | 1.0 | 0 | 0 | +0 | 0 of 2 | 1 of 2 | - | +0 |
| Opponent | Grand Cathay | 3 | 263 | 318 | 2.3 | 1.3 | 136 | 23 | +113 | 3 of 7 | 4 of 7 | +580 | +35 |
| Opponent | High Elf Realms | 3 | 175 | 145 | 1.7 | 1.0 | 87 | 0 | +87 | 4 of 5 | 3 of 5 | - | +87 |
| Opponent | Kingdom of Bretonnia | 2 | 0 | 106 | 1.5 | 1.3 | 71 | 0 | +71 | 1 of 3 | 2 of 3 | +117 | +48 |
| Opponent | Orc & Goblin Tribes | 1 | 0 | 0 | 3.0 | 1.0 | 0 | 0 | +0 | 2 of 3 | 1 of 3 | - | +0 |
| Opponent | Skaven | 1 | 240 | 0 | 1.0 | 2.0 | 0 | 0 | +0 | 0 of 1 | 1 of 1 | +0 | - |
| Opponent | Tomb Kings of Khemri | 4 | 0 | 565 | 4.8 | 1.1 | 119 | 28 | +91 | 11 of 19 | 11 of 19 | +70 | +93 |
| Opponent | Vampire Counts | 6 | 0 | 473 | 4.2 | 1.2 | 114 | 73 | +40 | 13 of 25 | 16 of 25 | +44 | +39 |
| Opponent | Warriors of Chaos | 9 | 0 | 603 | 3.6 | 1.2 | 170 | 36 | +133 | 10 of 32 | 22 of 31 | +320 | +81 |
| Opponent | Wood Elf Realms | 6 | 161 | 318 | 3.2 | 1.1 | 100 | 23 | +77 | 6 of 19 | 12 of 19 | +195 | +63 |
| **Opponent** | all armies | 36 | 87 | 390 | 3.2 | 1.2 | 121 | 36 | +85 | 50 of 116 | 73 of 115 | +187 | +64 |

### Effective charges: ef2-opp-f5fe7c8-p3

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 3 | 0 | 0 | 0 | 0 | 0 | 2 (net +7) | 1 | 0% (0 of 2) |
| Mine | Chaos Dwarfs | 12 | 2 (net +29) | 0 | 2 (net +0) | 2 (net +200) | 0 | 4 (net -12) | 2 | 20% (2 of 10) |
| Mine | Dwarfen Mountain Holds | 5 | 1 (net +0) | 0 | 2 (net +105) | 0 | 0 | 2 (net +48) | 0 | 40% (2 of 5) |
| Mine | Empire of Man | 13 | 0 | 0 | 3 (net -47) | 4 (net +9) | 0 | 6 (net +43) | 0 | 23% (3 of 13) |
| Mine | Grand Cathay | 10 | 1 (net +0) | 0 | 1 (net +0) | 3 (net +50) | 0 | 3 (net +120) | 2 | 12% (1 of 8) |
| Mine | High Elf Realms | 19 | 1 (net +195) | 0 | 2 (net +471) | 4 (net +153) | 6 (net +45) | 4 (net +90) | 2 | 12% (2 of 17) |
| Mine | Kingdom of Bretonnia | 1 | 1 (net -275) | 0 | 0 | 0 | 0 | 0 | 0 | 0% (0 of 1) |
| Mine | Lizardmen | 4 | 0 | 0 | 0 | 0 | 1 (net +608) | 3 (net +38) | 0 | 0% (0 of 4) |
| Mine | Ogre Kingdoms | 5 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 4 | 0% (0 of 1) |
| Mine | Orc & Goblin Tribes | 3 | 0 | 0 | 0 | 0 | 0 | 1 (net -213) | 2 | 0% (0 of 1) |
| Mine | Tomb Kings of Khemri | 10 | 1 (net +233) | 0 | 1 (net -122) | 1 (net +550) | 3 (net +59) | 4 (net +116) | 0 | 10% (1 of 10) |
| Mine | Vampire Counts | 10 | 2 (net -30) | 1 (net +434) | 1 (net +190) | 2 (net +0) | 2 (net +86) | 2 (net +320) | 0 | 10% (1 of 10) |
| Mine | Warriors of Chaos | 3 | 0 | 0 | 0 | 1 (net +0) | 0 | 2 (net -60) | 0 | 0% (0 of 3) |
| Opponent | Empire of Man | 2 | 0 | 0 | 0 | 0 | 0 | 2 (net +0) | 0 | 0% (0 of 2) |
| Opponent | Grand Cathay | 7 | 2 (net -81) | 0 | 2 (net +360) | 1 (net +85) | 1 (net +84) | 1 (net +65) | 0 | 29% (2 of 7) |
| Opponent | High Elf Realms | 5 | 0 | 0 | 0 | 2 (net +218) | 0 | 2 (net +0) | 1 | 0% (0 of 4) |
| Opponent | Kingdom of Bretonnia | 3 | 1 (net +0) | 0 | 0 | 1 (net +117) | 0 | 1 (net +95) | 0 | 0% (0 of 3) |
| Opponent | Skaven | 1 | 0 | 0 | 0 | 0 | 0 | 1 (net +0) | 0 | 0% (0 of 1) |
| Opponent | Tomb Kings of Khemri | 19 | 1 (net +0) | 0 | 0 | 4 (net +165) | 2 (net +70) | 9 (net +73) | 3 | 0% (0 of 16) |
| Opponent | Vampire Counts | 25 | 4 (net -35) | 1 (net -610) | 2 (net +368) | 6 (net +104) | 4 (net +73) | 6 (net +24) | 2 | 9% (2 of 23) |
| Opponent | Warriors of Chaos | 32 | 2 (net +348) | 1 (net +636) | 5 (net +154) | 4 (net +27) | 2 (net +59) | 16 (net +84) | 2 | 17% (5 of 30) |
| Opponent | Wood Elf Realms | 19 | 1 (net +270) | 0 | 3 (net +173) | 4 (net -26) | 0 | 3 (net +193) | 8 | 27% (3 of 11) |

### Charged fights, damage counted: ef2-opp-f5fe7c8-p3

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 9 | 283 | 337 | +17 | 124 | 137 | -13 | -4.7 |
| Mine | 50-54% | 1 | 402 | 479 | +434 | 479 | 88 | +391 | +97.3 |
| Mine | Effective (55-75%) | 12 | 245 | 258 | +90 | 150 | 73 | +77 | +31.4 |
| Mine | 76-89% | 17 | 325 | 158 | +103 | 145 | 34 | +111 | +34.1 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 33 | 236 | 160 | +58 | 108 | 47 | +61 | +25.9 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 13 | 476 | 100 | +95 | 145 | 73 | +72 | +15.2 |
| Mine | No odds | 14 | 366 | 209 | +74 | 123 | 39 | +84 | +22.8 |
| Mine | All fights | 99 | 308 | 190 | +77 | 132 | 59 | +73 | +23.6 |
| Opponent | Long shot (under 50%) | 11 | 219 | 344 | +60 | 154 | 96 | +58 | +26.4 |
| Opponent | 50-54% | 2 | 559 | 284 | +13 | 376 | 363 | +13 | +2.3 |
| Opponent | Effective (55-75%) | 12 | 394 | 227 | +229 | 249 | 27 | +222 | +56.4 |
| Opponent | 76-89% | 22 | 360 | 252 | +88 | 136 | 37 | +98 | +27.4 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 41 | 223 | 175 | +70 | 124 | 40 | +85 | +38.0 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 9 | 384 | 96 | +71 | 131 | 75 | +55 | +14.4 |
| Opponent | No odds | 19 | 193 | 241 | +54 | 98 | 32 | +66 | +33.9 |
| Opponent | All fights | 116 | 280 | 218 | +85 | 143 | 50 | +92 | +33.0 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ef2-opp-f5fe7c8-p3 | move | 440 | 92 (21%) | 74 (17%) | 48 (11%) | 300 (68%) |
| ef2-opp-f5fe7c8-p3 | objective | 375 | 59 (16%) | 44 (12%) | 46 (12%) | 270 (72%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0110, L0126, L2433, L2630 |
| Charmed Shield | Opponent | L0126, L0226, L0327, L0725, L1327, L2327 |
| Clockwork Compass | Mine | L1216, L1232 |
| Elixir of Power | Mine | L1122, L1932 |
| Elixir of Power | Opponent | L0311, L1519 |
| Fistful of Laurels | Mine | L1831 |
| Horn of the Wild Hunt | Opponent | L0533, L1633, L2033, L2433, L3133 |
| Invocation of Nehek | Mine | L2433 |
| Invocation of Nehek | Opponent | L0327, L0725, L1327, L2327 |
| Opal Amulet | Mine | L1422 |
| Periapt of Soul Exchange | Mine | L2033 |
| Periapt of Soul Exchange | Opponent | L0620 |
| Ring of Doom | Mine | L0210, L0226, L1122, L1216, L1232, L1519, L1535, L3133 |
| Ring of Doom | Opponent | L0311, L0533, L0815, L0831, L1633, L1731, L1831, L2033, L2433, L3133 |
| Ring of Jet | Mine | L1013, L1030, L1122, L1216, L1232 |
| Ring of Jet | Opponent | L0110, L0210, L0311 |
| Standard of the Fell Warrior | Mine | L1327 |
| Standard of the Fell Warrior | Opponent | L0413, L1013 |
| Twice-Blessed Armour | Mine | L0709, L0725, L1013, L1030 |
| Twice-Blessed Armour | Opponent | L0110, L0210 |
| Witch Hunter's Ward | Mine | L0709, L0725, L0815, L0831 |

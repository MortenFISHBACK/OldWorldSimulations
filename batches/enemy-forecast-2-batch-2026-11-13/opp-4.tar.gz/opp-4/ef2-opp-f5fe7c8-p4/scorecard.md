# Doctrine scorecard: ef2-opp-f5fe7c8-p4

### Scorecard: ef2-opp-f5fe7c8-p4

| Match-up | Scenario | Seed | Side | Far marker / quarter contested by round 3 | Lone holders (player turns) | Round of the first Hammer charge | Lone charges into a block / monster / character | Idle units | Wounded Lords / monsters lost | Doctrine flags raised | Answers changed after a flag | Points that never moved of their own |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| L0114 | 6 | 1 | Mine | no | 11 | 2 | 0 | 1 | 1 | 0 | 0 | 0 |
| L0114 | 6 | 1 | Opponent | no | 5 | 2 | 5 | 1 | 0 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Mine | no | 1 | - | 0 | 0 | 1 | 0 | 0 | 0 |
| L0130 | 4 | 1 | Opponent | no | 0 | 1 | 9 | 3 | 1 | 0 | 0 | 0 |
| L0214 | 4 | 1 | Mine | yes | 5 | - | 1 | 6 | 1 | 0 | 0 | 170 |
| L0214 | 4 | 1 | Opponent | no | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| L0230 | 2 | 1 | Mine | - | - | 2 | 1 | 2 | 0 | 0 | 0 | 81 |
| L0230 | 2 | 1 | Opponent | - | - | 2 | 2 | 3 | 0 | 0 | 0 | 0 |
| L0315 | 3 | 1 | Mine | no | 1 | 6 | 3 | 0 | 0 | 0 | 0 | 760 |
| L0315 | 3 | 1 | Opponent | yes | 3 | 3 | 3 | 2 | 0 | 0 | 0 | 0 |
| L0332 | 2 | 1 | Mine | - | - | 4 | 2 | 1 | 0 | 0 | 0 | 590 |
| L0332 | 2 | 1 | Opponent | - | - | 2 | 2 | 6 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Mine | no | 2 | 2 | 9 | 1 | 0 | 0 | 0 | 0 |
| L0417 | 3 | 1 | Opponent | yes | 7 | 2 | 5 | 0 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Mine | - | - | 4 | 2 | 2 | 0 | 0 | 0 | 0 |
| L0434 | 2 | 1 | Opponent | - | - | 1 | 4 | 1 | 0 | 0 | 0 | 115 |
| L0520 | 4 | 1 | Mine | no | 0 | 3 | 3 | 0 | 0 | 0 | 0 | 1258 |
| L0520 | 4 | 1 | Opponent | no | 5 | - | 0 | 2 | 2 | 0 | 0 | 210 |
| L0608 | 2 | 1 | Mine | - | - | 3 | 1 | 2 | 0 | 0 | 0 | 615 |
| L0608 | 2 | 1 | Opponent | - | - | 5 | 1 | 2 | 0 | 0 | 0 | 605 |
| L0624 | 6 | 1 | Mine | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 615 |
| L0624 | 6 | 1 | Opponent | no | 5 | 3 | 4 | 1 | 2 | 0 | 0 | 0 |
| L0713 | 5 | 1 | Mine | yes | - | 4 | 2 | 3 | 1 | 0 | 0 | 375 |
| L0713 | 5 | 1 | Opponent | yes | - | 2 | 2 | 0 | 0 | 0 | 0 | 479 |
| L0729 | 3 | 1 | Mine | yes | 6 | 1 | 1 | 1 | 0 | 0 | 0 | 375 |
| L0729 | 3 | 1 | Opponent | no | 0 | 2 | 2 | 2 | 1 | 0 | 0 | 170 |
| L0819 | 3 | 1 | Mine | no | 0 | 3 | 2 | 0 | 0 | 0 | 0 | 805 |
| L0819 | 3 | 1 | Opponent | no | 2 | 2 | 1 | 3 | 0 | 0 | 0 | 0 |
| L0835 | 1 | 1 | Mine | no | 0 | 4 | 0 | 0 | 0 | 0 | 0 | 515 |
| L0835 | 1 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L0926 | 2 | 1 | Mine | - | - | 2 | 1 | 2 | 0 | 0 | 0 | 560 |
| L0926 | 2 | 1 | Opponent | - | - | 2 | 7 | 4 | 0 | 0 | 0 | 0 |
| L1017 | 3 | 1 | Mine | yes | 1 | 2 | 2 | 0 | 0 | 0 | 0 | 330 |
| L1017 | 3 | 1 | Opponent | no | 5 | 1 | 5 | 2 | 1 | 0 | 0 | 175 |
| L1034 | 2 | 1 | Mine | - | - | 1 | 2 | 1 | 0 | 0 | 0 | 330 |
| L1034 | 2 | 1 | Opponent | - | - | 3 | 4 | 1 | 0 | 0 | 0 | 0 |
| L1126 | 4 | 1 | Mine | no | 0 | 3 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1126 | 4 | 1 | Opponent | no | 2 | 2 | 3 | 2 | 0 | 0 | 0 | 0 |
| L1220 | 2 | 1 | Mine | - | - | 2 | 3 | 0 | 0 | 0 | 0 | 330 |
| L1220 | 2 | 1 | Opponent | - | - | 2 | 4 | 6 | 1 | 0 | 0 | 210 |
| L1314 | 6 | 1 | Mine | no | 3 | 3 | 4 | 0 | 1 | 0 | 0 | 317 |
| L1314 | 6 | 1 | Opponent | no | 6 | 2 | 4 | 0 | 0 | 0 | 0 | 123 |
| L1331 | 5 | 1 | Mine | yes | - | 4 | 1 | 3 | 1 | 0 | 0 | 140 |
| L1331 | 5 | 1 | Opponent | no | - | 3 | 1 | 4 | 0 | 0 | 0 | 286 |
| L1427 | 5 | 1 | Mine | yes | - | 3 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1427 | 5 | 1 | Opponent | yes | - | 2 | 7 | 2 | 1 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Mine | yes | - | 2 | 7 | 1 | 1 | 0 | 0 | 0 |
| L1523 | 5 | 1 | Opponent | yes | - | 4 | 5 | 2 | 1 | 0 | 0 | 192 |
| L1621 | 1 | 1 | Mine | no | 1 | 3 | 3 | 0 | 0 | 0 | 0 | 200 |
| L1621 | 1 | 1 | Opponent | no | 0 | - | 0 | 5 | 0 | 0 | 0 | 290 |
| L1719 | 3 | 1 | Mine | no | 6 | 2 | 2 | 0 | 0 | 0 | 0 | 0 |
| L1719 | 3 | 1 | Opponent | yes | 1 | 2 | 6 | 0 | 0 | 0 | 0 | 490 |
| L1819 | 1 | 1 | Mine | no | 0 | 5 | 5 | 1 | 2 | 0 | 0 | 0 |
| L1819 | 1 | 1 | Opponent | no | 0 | 2 | 6 | 1 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Mine | yes | - | 1 | 2 | 1 | 0 | 0 | 0 | 0 |
| L1835 | 5 | 1 | Opponent | yes | - | 3 | 5 | 1 | 0 | 0 | 0 | 0 |
| L2021 | 5 | 1 | Mine | no | - | - | 1 | 4 | 0 | 0 | 0 | 210 |
| L2021 | 5 | 1 | Opponent | yes | - | 4 | 3 | 4 | 0 | 0 | 0 | 355 |
| L2123 | 5 | 1 | Mine | yes | - | - | 3 | 4 | 0 | 0 | 0 | 420 |
| L2123 | 5 | 1 | Opponent | yes | - | 3 | 4 | 1 | 0 | 0 | 0 | 60 |
| L2227 | 1 | 1 | Mine | yes | 4 | 2 | 3 | 0 | 1 | 0 | 0 | 72 |
| L2227 | 1 | 1 | Opponent | no | 0 | 1 | 7 | 1 | 2 | 0 | 0 | 60 |
| L2331 | 3 | 1 | Mine | yes | 1 | 3 | 5 | 0 | 1 | 0 | 0 | 0 |
| L2331 | 3 | 1 | Opponent | no | 0 | 2 | 6 | 2 | 2 | 0 | 0 | 562 |
| L2527 | 1 | 1 | Mine | no | 0 | 2 | 4 | 2 | 1 | 0 | 0 | 0 |
| L2527 | 1 | 1 | Opponent | no | 0 | 1 | 1 | 4 | 0 | 0 | 0 | 250 |
| L2634 | 6 | 1 | Mine | no | 8 | 2 | 4 | 1 | 0 | 0 | 0 | 0 |
| L2634 | 6 | 1 | Opponent | no | 0 | 2 | 4 | 1 | 0 | 0 | 0 | 107 |
| L2930 | 2 | 1 | Mine | - | - | 2 | 1 | 1 | 1 | 0 | 0 | 0 |
| L2930 | 2 | 1 | Opponent | - | - | 5 | 1 | 3 | 0 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Mine | no | 1 | 2 | 5 | 1 | 1 | 0 | 0 | 0 |
| L3234 | 6 | 1 | Opponent | no | 0 | 2 | 6 | 1 | 0 | 0 | 0 | 56 |
| **Average** | | | Mine | 39% | 2.4 | 2.7 | 2.6 | 1.1 | 0.4 | 0.0 | 0.0 | 261.1 |
| **Average** | | | Opponent | 32% | 2.0 | 2.3 | 3.7 | 2.1 | 0.4 | 0.0 | 0.0 | 133.2 |

### KPIs: ef2-opp-f5fe7c8-p4

Morten 2026-11-10; 36 games. A % is of the times it could happen (follow ups: winners after a won round, "on the table" adds the restrains whose Restraint test failed; missiles: the army's missiles x its turns, dead wizards included; points: army points).

| KPI | Target | Mine | Opponent | Both |
| --- | --- | --- | --- | --- |
| Winner chose to follow up after the loser gave ground |  | 100% (67 of 67); on the table 100% | 95% (54 of 57); on the table 98% | 98% (121 of 124); on the table 99% |
| Winner chose to pursue after the loser fell back in good order |  | 100% (8 of 8); on the table 100% | 100% (17 of 17); on the table 100% | 100% (25 of 25); on the table 100% |
| Winner chose to pursue after the loser fled |  | 79% (22 of 28); on the table 82% | 72% (28 of 39); on the table 82% | 75% (50 of 67); on the table 82% |
| Winner chose to follow up or pursue (all three) |  | 94% (97 of 103); on the table 95% | 88% (99 of 113); on the table 93% | 91% (196 of 216); on the table 94% |
| Magic missiles tried each own turn | 50%+ | 34% (91 of 266) | 24% (43 of 176) | 30% (134 of 442) |
|   tried when they could be (not in combat, slain, fleeing or off the table) | 50%+ | 46% (91 of 198) | 39% (43 of 111) | 43% (134 of 309) |
| Points that never fought | lower | 33% (22496 of 67942) | 35% (25226 of 71984) | 34% (47722 of 139926) |
|   infantry points that never fought | lower | 43% (6670 of 15347) | 60% (8270 of 13804) | 51% (14940 of 29151) |
| Units over 100 pts that earned no points (no kill, no objective) | lower | 64% (174 of 270) | 56% (156 of 280) | 60% (330 of 550) |
| Bound items with a magic missile used (at least once a game) |  | 91% (20 of 22); 1.8 uses a game | 89% (8 of 9); 0.6 uses a game | 90% (28 of 31); 1.2 uses a game |
| Bound items with another spell used |  | 56% (9 of 16); 0.7 uses a game | 55% (11 of 20); 0.6 uses a game | 56% (20 of 36); 0.6 uses a game |
| One-use items used (Chalice of Dark Rain, Arch-Lightning Rod ...) |  | 68% (13 of 19); 0.4 uses a game | 60% (9 of 15); 0.2 uses a game | 65% (22 of 34); 0.3 uses a game |
|   their share of the points of units over 100 pts | lower | 59% (33802 of 57750) | 50% (31627 of 63347) | 54% (65429 of 121097) |

Why missiles were not tried (per game, and the share of the missiles not tried):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| NO TARGET: no enemy in range, sight and arc it may target | 1.4 (28%) | 0.6 (16%) | 1.9 (23%) |
| MARCHED: its unit marched | 1.4 (28%) | 0.8 (21%) | 2.1 (25%) |
| CHARGED: its unit charged | 0.1 (2%) | 0.2 (5%) | 0.3 (4%) |
| IN COMBAT: engaged in combat | 1.1 (22%) | 0.6 (17%) | 1.7 (20%) |
| REAR RANK: in a rear rank | 0.0 (1%) | 0.3 (9%) | 0.4 (4%) |
| FLEEING: fleeing | 0.0 (1%) | 0.2 (6%) | 0.2 (3%) |
| GONE: slain | 0.6 (12%) | 0.9 (26%) | 1.5 (18%) |
| OFF THE TABLE: off the table or not arrived | 0.2 (4%) | 0.0 (1%) | 0.2 (3%) |
| STUPIDITY: Stupidity | 0.1 (2%) | 0.0 (0%) | 0.1 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (1%) | 0.0 (0%) | 0.0 (0%) |

Why spells were not cast, both sides (a game; in brackets the share of that kind's spells not cast). A spell counts once a turn in the phase it is cast in, dead wizards included:

| Reason | Enchantments | Hexes | Movement spells | Magic missiles | Vortexes | Assailments |
| --- | --- | --- | --- | --- | --- | --- |
| tried | 4.2 | 1.0 | 1.8 | 3.7 | 0.4 | 2.3 |
| not cast | 2.9 | 2.8 | 3.1 | 8.6 | 1.6 | 20.7 |
| NOT CHOSEN: could have been cast at a target | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 1.6 (8%) |
| NO TARGET: no enemy in range, sight and arc it may target | 0.0 (0%) | 1.0 (36%) | 0.2 (5%) | 1.9 (23%) | 0.4 (22%) | 0.0 (0%) |
| MARCHED: its unit marched | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 2.1 (25%) | 0.4 (26%) | 0.0 (0%) |
| CHARGED: its unit charged | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.3 (4%) | 0.0 (2%) | 0.0 (0%) |
| IN COMBAT: engaged in combat | 0.1 (3%) | 0.3 (11%) | 0.4 (15%) | 1.7 (20%) | 0.4 (22%) | 0.0 (0%) |
| REAR RANK: in a rear rank | 0.1 (5%) | 0.1 (4%) | 0.3 (10%) | 0.4 (4%) | 0.0 (0%) | 0.0 (0%) |
| FLEEING: fleeing | 0.2 (6%) | 0.3 (11%) | 0.0 (1%) | 0.2 (3%) | 0.0 (0%) | 1.0 (5%) |
| GONE: slain | 0.8 (27%) | 0.6 (23%) | 0.5 (16%) | 1.5 (18%) | 0.2 (12%) | 4.2 (20%) |
| OFF THE TABLE: off the table or not arrived | 0.1 (4%) | 0.1 (2%) | 0.2 (5%) | 0.2 (3%) | 0.0 (0%) | 0.1 (1%) |
| STUPIDITY: Stupidity | 0.1 (3%) | 0.0 (0%) | 0.0 (1%) | 0.1 (1%) | 0.0 (0%) | 0.2 (1%) |
| OTHER BAR: another bar (miscast, baggage ...) | 0.0 (0%) | 0.3 (10%) | 0.0 (1%) | 0.0 (0%) | 0.2 (16%) | 0.0 (0%) |
| HELD BACK: the computer weighed it and chose not to cast it | 1.6 (53%) | 0.1 (4%) | 1.4 (45%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NOT IN COMBAT: Assailment: the wizard fought in no combat | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) | 13.6 (66%) |

Movement spells (Conveyance): tries a game, and what the unit did when the spell stood (by the end of its side's next turn):

| Movement spells | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Movement spells tried | 1.5 a game | 0.4 a game | 1.0 a game |
| stood (cast and not dispelled) | 63% (31 of 49) | 50% (3 of 6) | 62% (34 of 55) |
| the unit moved after it | 65% (20 of 31) | 67% (2 of 3) | 65% (22 of 34) |
| it charged on its next turn | 3% (1 of 31) | 0% (0 of 3) | 3% (1 of 34) |
| the enemy charged it first | 35% (11 of 31) | 0% (0 of 3) | 32% (11 of 34) |
| it fought by the end of its next turn | 29% (9 of 31) | 0% (0 of 3) | 26% (9 of 34) |
| it moved out of a charge the enemy had planned (not charged first) | 23% (7 of 31) | 0% (0 of 3) | 21% (7 of 34) |
| none of these (no charge, no fight, no charge escaped) | 39% (12 of 31) | 100% (3 of 3) | 44% (15 of 34) |

Shooting: own turns a shooting unit or war machine was on the table (from its first action until it was gone), and how often it shot:

| Shooters | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Shot when on the table | 62% (530 of 850) | 54% (288 of 530) | 59% (818 of 1380) |
|   cavalry | 64% (49 of 77) | 73% (80 of 110) | 69% (129 of 187) |
|   character | 39% (39 of 99) | 19% (22 of 117) | 28% (61 of 216) |
|   chariot | 47% (48 of 102) | 72% (13 of 18) | 51% (61 of 120) |
|   infantry | 59% (156 of 263) | 64% (146 of 229) | 61% (302 of 492) |
|   monster | 49% (17 of 35) | 22% (5 of 23) | 38% (22 of 58) |
|   war machine | 81% (221 of 274) | 67% (22 of 33) | 79% (243 of 307) |

Why a shooter on the table did not shoot (per game, and the share of its turns not shot):

| Reason | Mine | Opponent | Both |
| --- | --- | --- | --- |
| MARCHED: its unit marched | 2.4 (27%) | 1.8 (26%) | 4.2 (27%) |
| CHARGED: it charged | 1.3 (15%) | 1.6 (24%) | 3.0 (19%) |
| FLEEING: it fled or was fleeing | 0.3 (3%) | 0.1 (2%) | 0.4 (2%) |
| IN COMBAT: it fought this turn or the last | 0.9 (10%) | 0.2 (4%) | 1.1 (7%) |
| MOVED: a war machine that moved | 0.0 (0%) | 0.0 (0%) | 0.0 (0%) |
| NO TARGET IN RANGE | 1.6 (18%) | 1.0 (15%) | 2.6 (17%) |
| ONLY IN COMBAT: the only targets were in combat | 0.4 (4%) | 0.4 (7%) | 0.8 (5%) |
| NO LINE OF SIGHT: in range, out of arc or sight | 1.4 (16%) | 1.5 (22%) | 2.9 (19%) |
| SHELTERED: the target was sheltered | 0.4 (4%) | 0.0 (0%) | 0.4 (2%) |
| OTHER BAR | 0.2 (2%) | 0.0 (0%) | 0.2 (1%) |

What the shots were worth (Morten: wounds count, not only kills): wounds x the target's points / its Wounds at the start (both sides):

| Shooter | Shots a game | Wounds a game | Shots that wounded nothing | Worth a shot | Worth a game |
| --- | --- | --- | --- | --- | --- |
| cavalry | 5.8 | 1.7 | 78% | 8.5 pts | 49 pts |
| character | 2.2 | 0.8 | 71% | 8.1 pts | 18 pts |
| chariot | 1.7 | 1.5 | 57% | 17.1 pts | 29 pts |
| infantry | 12.4 | 5.4 | 71% | 11.3 pts | 140 pts |
| monster | 0.8 | 0.1 | 89% | 7.1 pts | 5 pts |
| war machine | 6.8 | 5.2 | 64% | 24.6 pts | 166 pts |

Charges (declared, and made contact) a game, and per unit by the wizard it carries:

| Charges | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charges declared a game | 4.5 | 6.6 | 5.6 |
| Charges that made contact a game | 3.1 | 4.9 | 4.0 |
|   per unit a game, units carrying a magic-missile wizard (or one alone) | 0.71 declared, 0.59 contact (17 units) | 0.83 declared, 0.67 contact (18 units) | 0.77 declared, 0.63 contact (35 units) |
|   per unit a game, units carrying another wizard (or one alone) | 1.11 declared, 0.89 contact (9 units) | 1.08 declared, 0.69 contact (13 units) | 1.09 declared, 0.77 contact (22 units) |
|   per unit a game, the other units (no war machines, no joined characters) | 0.57 declared, 0.37 contact (247 units) | 0.69 declared, 0.52 contact (302 units) | 0.64 declared, 0.45 contact (549 units) |

Units over 100 pts that earned no points, by troop type and points (both sides; % of such units, earned nothing of all):

| Troop type | 101-199 | 200-349 | 350+ | All |
| --- | --- | --- | --- | --- |
| Cavalry | 51% (41 of 81) | 50% (8 of 16) | 83% (5 of 6) | 52% (54 of 103) |
| Character in a unit | 86% (30 of 35) | 44% (7 of 16) | 100% (1 of 1) | 73% (38 of 52) |
| Character on its own | 77% (23 of 30) | 65% (17 of 26) | 30% (23 of 77) | 47% (63 of 133) |
| Chariot | 67% (10 of 15) | 75% (9 of 12) | - | 70% (19 of 27) |
| Infantry | 59% (49 of 83) | 48% (12 of 25) | 17% (1 of 6) | 54% (62 of 114) |
| Monster | 74% (25 of 34) | 79% (11 of 14) | - | 75% (36 of 48) |
| Monstrous | 57% (8 of 14) | 93% (13 of 14) | - | 75% (21 of 28) |
| War Machines | 81% (35 of 43) | 100% (2 of 2) | - | 82% (37 of 45) |

By army (both sides of every game it played):

| Army | Sides | Chose to follow up / pursue | Missiles tried | Points never fought | Units 100+ that earned nothing | Bound missile items | Other bound items | One-use items |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 4 | 100% (16 of 16); on the table 100% | 46% (47 of 102) | 10% | 50% (11 of 22) | 100% (6 of 6); 5.0 uses a game | 100% (2 of 2); 1.5 uses a game | 83% (5 of 6); 1.2 uses a game |
| Chaos Dwarfs | 4 | 88% (7 of 8); on the table 88% | 25% (6 of 24) | 33% | 69% (22 of 32) | 0.0 uses a game | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game |
| Dwarfen Mountain Holds | 3 | 100% (7 of 7); on the table 100% | - | 66% | 81% (22 of 27) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Empire of Man | 6 | 83% (5 of 6); on the table 83% | 33% (6 of 18) | 51% | 73% (45 of 62) | 0.0 uses a game | 100% (2 of 2); 0.5 uses a game | 60% (3 of 5); 0.5 uses a game |
| Grand Cathay | 4 | 100% (10 of 10); on the table 100% | 31% (26 of 84) | 40% | 54% (20 of 37) | 100% (9 of 9); 6.8 uses a game | 50% (1 of 2); 0.8 uses a game | 25% (1 of 4); 0.2 uses a game |
| High Elf Realms | 9 | 86% (25 of 29); on the table 93% | 17% (6 of 36) | 29% | 46% (32 of 70) | 100% (7 of 7); 2.9 uses a game | 50% (15 of 30); 3.7 uses a game | 0.0 uses a game |
| Kingdom of Bretonnia | 1 | 100% (3 of 3); on the table 100% | - | 19% | 50% (3 of 6) | 0.0 uses a game | 0.0 uses a game | 100% (1 of 1); 1.0 uses a game |
| Lizardmen | 3 | 100% (15 of 15); on the table 100% | 100% (6 of 6) | 28% | 62% (13 of 21) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Ogre Kingdoms | 2 | 67% (4 of 6); on the table 67% | 0% (0 of 6) | 29% | 86% (12 of 14) | 0% (0 of 2); 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Orc & Goblin Tribes | 3 | 100% (7 of 7); on the table 100% | 2% (1 of 42) | 17% | 62% (15 of 24) | 0.0 uses a game | 0.0 uses a game | 67% (2 of 3); 0.7 uses a game |
| Skaven | 6 | 82% (9 of 11); on the table 91% | 40% (16 of 40) | 56% | 78% (35 of 45) | 100% (3 of 3); 1.3 uses a game | 0.0 uses a game | 67% (4 of 6); 0.7 uses a game |
| Tomb Kings of Khemri | 4 | 93% (14 of 15); on the table 93% | 0% (0 of 6) | 22% | 30% (6 of 20) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Vampire Counts | 8 | 91% (40 of 44); on the table 95% | 22% (13 of 60) | 31% | 52% (22 of 42) | 0.0 uses a game | 0.0 uses a game | 0.0 uses a game |
| Warriors of Chaos | 9 | 85% (17 of 20); on the table 95% | 17% (2 of 12) | 31% | 57% (41 of 72) | 100% (2 of 2); 0.4 uses a game | 0.0 uses a game | 100% (3 of 3); 0.3 uses a game |
| Wood Elf Realms | 6 | 89% (17 of 19); on the table 89% | 83% (5 of 6) | 32% | 55% (31 of 56) | 50% (1 of 2); 0.5 uses a game | 0.0 uses a game | 25% (1 of 4); 0.2 uses a game |

Flank and rear charges a unit could have turned to face (ef2-opp-f5fe7c8-p4, 36 games; the side is the charged unit's):

| Measure | Mine | Opponent | Both |
| --- | --- | --- | --- |
| Charged units hit only in a flank or rear (% of formed units charged) | 54% (57) | 51% (32) | 53% (89) |
| ...free all their last turn and able to turn (per game) | 1.00 | 0.53 | 1.53 |
| ...left out: fought, charged, random mover or war machine in their own turn (per game) | 0.28 | 0.14 | 0.42 |
| ...with the charger already in that arc before they moved (per game) | 0.69 | 0.31 | 1.00 |
| Turned to face a threat or took a way out: FACES THE THREAT (per game) | 1.36 | 0.83 | 2.19 |
| Stood instead of an exposed job's move: SAFER THAN THE JOB (per game) | 0.61 | 0.56 | 1.17 |
| Kept its job with an enemy able to reach its flank or rear: NOT TURNED (per game) | 7.67 | 8.22 | 15.89 |

### Quality by phase: ef2-opp-f5fe7c8-p4

Per game and side; a % is of the tries. Dice-only numbers (casting, Panic, Rally, Break, charge rolls) are left out (Morten 2026-11-08).

| Phase | Number | Mine | Opponent |
| --- | --- | --- | --- |
| Deployment | Characters standing alone | 3.1 | 3.6 |
| Strategy | Charge objectives carried out (made contact) | 56% (79 of 142) | 42% (81 of 194) |
| Strategy | Shoot objectives carried out (shot that target) | 45% (149 of 330) | 41% (58 of 141) |
| Strategy | Close-in objectives charged next turn | 16% (28 of 175) | 16% (29 of 176) |
| Strategy | Support requests answered (helper made contact too) | 22% (2 of 9) | 41% (12 of 29) |
| Strategy | Augments that last this turn, on a unit that fought or charged that turn | 100% (1 of 1) | - |
| Strategy | Hexes on a unit its side charged or shot that turn | 67% (6 of 9) | 88% (7 of 8) |
| Strategy | Joined characters whose unit fought | 69% (24 of 35) | 46% (16 of 35) |
| Strategy | Lone characters that fought | 80% (70 of 88) | 88% (71 of 81) |
| Movement | Charges halted short of contact | 0.2 | 0.2 |
| Movement | Idle units | 1.1 | 2.1 |
| Movement | Points that never moved of their own | 261.1 | 133.2 |
| Movement | Fights charged into per game | 2.8 | 4.2 |
| Movement | Charges with odds: long shots (under 50%) | 7 of 92, net -55 | 18 of 122, net -93 |
| Movement | Charges with odds: sweet spot (55-75%) | 11 of 92, net +24 | 21 of 122, net +2 |
| Movement | Charges with odds: overkill (90%+, target under 250 pts, chargers over 3x) | 15 of 92, net +30 | 10 of 122, net +58 |
| Movement | Charges with odds: 90%+ not overkill (target 250+ pts or chargers up to 3x) | 37 of 92, net +78 | 42 of 122, net +108 |
| Shooting | Shots by shooting units (incl. breath weapons) | 9.4 | 8.9 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 49% (165 of 340) | 45% (145 of 320) |
| Shooting | Points destroyed by shooting units | 74.4 | 36.1 |
| Shooting | War machine shots | 6.1 | 0.6 |
| Shooting |   aimed at a top-3 enemy unit or that turn's charge target | 60% (132 of 221) | 36% (8 of 22) |
| Shooting | Points destroyed by war machines | 65.2 | 8.4 |
| Magic | Magic missiles cast | 1.8 | 1.0 |
| Magic |   aimed at a top-3 enemy unit or that turn's charge target | 45% (29 of 65) | 11% (4 of 35) |
| Magic | Wounds caused by magic missiles | 3.8 | 1.3 |
| Magic | Wounds caused by other spells | 1.4 | 1.9 |
| Magic | Points destroyed by magic (all spells) | 87.0 | 31.4 |
| Magic | Augments / hexes / assailments / vortexes cast | 1.1 / 0.2 / 0.6 / 0.2 | 1.6 / 0.4 / 0.8 / 0.1 |
| Combat | Points destroyed in combat | 275.6 | 404.1 |
| Combat | Points run down | 137.3 | 119.9 |
| Combat | Net points per charged fight, damage counted | +44 | +56 |
| Combat | Net per 100 charger points, damage counted | +16.7 | +18.1 |
| Combat | First round won (charged fights) | 68% | 53% |
| Combat | Net points per charged fight | +29 | +47 |
| Combat | Net points per supported fight / lone fight | +113 / +15 | +45 / +47 |
| Combat | Charged fights on a top-3 enemy unit | 29 of 101 | 76 of 152 |
| Game | Points lost | 709.5 | 731.4 |
| Game | VP from objectives | 573.9 | 573.6 |
| Game | Lone holders (player turns) | 2.4 | 2.0 |

- Mine won / drew / lost: 14 / 7 / 15 of 36 ended games (of 36); mean margin (Mine - Opponent) +8 VP
- The side that went first won 15 of 29 games with a winner
- Points traded per game (both sides' losses): 1441
- Games not ended: 0; findings 0, warnings 0

### Opponent rules: ef2-opp-f5fe7c8-p4

Each time Medium or Hard took an option one of the rules changed. Fired = a game; figure = the VP the rule added to the option (minus: took off), a game; won / lost = the VP of its target / of the unit itself destroyed that round or the next, a game.

| Rule | Mine fired | Mine figure | Mine won | Mine lost | Opponent fired | Opponent figure | Opponent won | Opponent lost |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ADVANCE LANE KEPT | 0.6 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| ALREADY CARRIED | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| ARRIVAL HUNT | - | - | - | - | 0.0 | +0.1 | 0.0 | 0.0 |
| ARTILLERY RE-ROLL WEIGHED | 0.8 | +0.0 | 0.0 | 17.8 | 0.1 | +0.0 | 0.0 | 3.5 |
| BACKUP TARGETS | 1.2 | +8.3 | 0.0 | 42.1 | 1.1 | +8.5 | 0.0 | 24.2 |
| BEST PREY | 5.1 | +287.3 | 166.0 | 160.2 | 4.9 | +306.8 | 128.2 | 83.4 |
| BEST PRIZE | 0.0 | -0.9 | 0.0 | 8.6 | 0.1 | +5.7 | 4.7 | 0.0 |
| BLOCKED CHARGE SKIPPED | 0.1 | +0.0 | 0.0 | 9.4 | 0.1 | +0.0 | 16.3 | 0.0 |
| BLOCKED WHEEL | 0.6 | +13.8 | 0.0 | 9.9 | 0.4 | +12.9 | 0.0 | 7.0 |
| BOMBING RUN | 0.0 | +0.4 | 1.1 | 0.0 | - | - | - | - |
| CANNON PLAN MISSED | 0.8 | +0.0 | 79.3 | 5.3 | 0.2 | +0.0 | 34.3 | 0.0 |
| CANNON PLANNED TARGET | 4.8 | +119.5 | 273.4 | 65.1 | 0.3 | +13.3 | 21.0 | 6.9 |
| CANNON SIGHT KEPT | 1.3 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| CARRIES OUT COUNTER | 0.0 | -2.8 | 0.0 | 0.0 | - | - | - | - |
| CARRIES OUT SET-UP | 0.1 | -0.7 | 17.1 | 0.0 | 0.0 | +0.0 | 5.2 | 0.0 |
| CAST JOB | 0.8 | +20.2 | 45.6 | 2.2 | 0.3 | +8.7 | 45.1 | 13.9 |
| CASTER AWAY FROM SCREEN | 0.3 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| CASTING BLOCK | 0.5 | +60.6 | 29.1 | 0.0 | - | - | - | - |
| CASTS AFTER FRIENDS | 1.0 | +0.0 | 0.0 | 53.7 | 0.2 | +0.0 | 0.0 | 9.1 |
| CASTS FROM BEHIND | 0.1 | +0.0 | 0.0 | 0.0 | 0.2 | +0.0 | 0.0 | 0.0 |
| CATCH FLIERS | 0.0 | +0.2 | 0.0 | 0.0 | 0.0 | +0.9 | 0.0 | 0.0 |
| CHAFF PASSED | 0.2 | -1.1 | 32.0 | 0.0 | 0.2 | -0.1 | 14.9 | 7.0 |
| CHAMPION TAKES THE CHALLENGE | 0.0 | +10.3 | 0.0 | 0.0 | - | - | - | - |
| CHARGE NOW WEIGHED | 0.6 | -44.1 | 22.9 | 32.7 | 0.6 | -32.0 | 9.4 | 19.7 |
| CHARIOT NO STATIC JOB | 0.5 | +0.0 | 8.7 | 17.1 | 0.3 | +0.0 | 0.0 | 5.3 |
| CHEAP HELPER | - | - | - | - | 0.1 | +0.0 | 9.0 | 0.0 |
| CONVEYANCE SEARCH | 0.9 | +110.3 | 10.2 | 41.6 | 0.1 | +4.9 | 0.0 | 0.0 |
| COUNTER-CHARGE COVER | 8.8 | +555.1 | 0.0 | 169.9 | 6.2 | +292.9 | 0.0 | 136.9 |
| EDGE GIVE GROUND | - | - | - | - | 0.1 | +3.6 | 8.2 | 13.3 |
| ELIXIR WORTH | - | - | - | - | 0.1 | +2.9 | 0.0 | 0.0 |
| ENEMY FORECAST | - | - | - | - | 7.1 | +153.6 | 51.9 | 201.6 |
| ENGINEER BY LORE | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| FACES THE THREAT | 1.4 | +128.3 | 0.0 | 42.6 | 0.8 | +70.4 | 0.0 | 24.9 |
| FALLBACK BY WORTH | 6.8 | +76.5 | 0.0 | 53.0 | 6.8 | +41.4 | 0.0 | 72.3 |
| FIGHT LIFT | 0.1 | +1.0 | 12.2 | 11.0 | - | - | - | - |
| FIRE AND FLEE | - | - | - | - | 0.1 | +0.8 | 1.2 | 13.9 |
| FLANK NOT WEIGHED | 0.4 | +0.0 | 0.0 | 28.7 | 0.2 | +0.0 | 0.0 | 6.4 |
| FOCUS FIRE | 0.0 | +0.1 | 1.5 | 0.0 | - | - | - | - |
| FOLLOW UP WEIGHED | 0.8 | +97.6 | 0.0 | 23.9 | 1.2 | +154.3 | 0.0 | 25.0 |
| FORECAST RESULT | 38.6 | +2500.4 | 549.8 | 971.1 | 41.7 | +2160.3 | 1189.0 | 1009.7 |
| FRIENDS SHOTS CHECKED | 0.4 | +16.8 | 0.0 | 5.4 | 0.1 | +8.7 | 0.0 | 0.0 |
| GIVES UP | 1.0 | -31.6 | 140.2 | 29.7 | 1.6 | -66.7 | 110.2 | 57.9 |
| GIVES UP ITS SCREEN | 0.6 | -7.7 | 74.3 | 9.5 | 1.1 | -30.3 | 39.3 | 13.5 |
| GROUND FLIERS | 0.1 | +0.3 | 0.0 | 0.0 | 0.0 | +2.0 | 0.0 | 0.0 |
| HELPER ALREADY ASKED | 0.0 | +0.0 | 0.0 | 1.8 | 0.2 | +0.0 | 19.0 | 2.2 |
| HELPER UNSEEN | 0.2 | +0.0 | 21.9 | 2.9 | 0.4 | +0.0 | 11.5 | 11.5 |
| HOLDS AMBUSHERS | 0.4 | +0.0 | 0.0 | 0.0 | 0.6 | +0.0 | 0.0 | 0.0 |
| HUNT ADVANCE | 0.0 | +0.0 | 5.3 | 3.4 | 0.1 | +3.0 | 3.5 | 0.0 |
| HUNT DROPPED | - | - | - | - | 0.1 | +0.0 | 0.0 | 0.0 |
| HUNT IN PAIRS | 0.3 | +14.5 | 0.0 | 9.4 | 0.6 | +20.7 | 0.0 | 5.4 |
| HUNT RESULT | 0.1 | +32.6 | 31.5 | 3.4 | 0.1 | +8.1 | 0.0 | 0.0 |
| HUNT THE GUNS | 0.1 | +38.8 | 31.4 | 5.2 | 0.1 | +53.3 | 3.5 | 0.0 |
| JOINT CHARGE PLAN | 0.1 | +5.4 | 13.7 | 0.0 | - | - | - | - |
| KEEP FALLS | 0.1 | +1.5 | 0.0 | 0.0 | 0.0 | +1.4 | 0.0 | 0.0 |
| KEEPS ITS PREY | 0.1 | +1.3 | 1.5 | 0.0 | 0.3 | +1.3 | 2.6 | 10.6 |
| KEEPS ITS TARGET | 1.8 | +52.5 | 188.4 | 53.1 | 2.3 | +68.3 | 96.1 | 59.2 |
| KEEPS SCOUTS OR AMBUSH | 0.1 | +0.0 | 0.0 | 0.0 | - | - | - | - |
| KILLS COUNT | 2.1 | +93.6 | 119.8 | 66.9 | 2.3 | +156.2 | 146.5 | 61.0 |
| KILLS COUNT NEXT TURN | 9.9 | +345.9 | 445.8 | 248.3 | 10.4 | +549.3 | 303.4 | 188.4 |
| LONE CHARACTER SAFE SPOT | 0.4 | +25.4 | 16.2 | 20.0 | 0.2 | +6.1 | 7.0 | 0.0 |
| LONE WIZARD HOLDS BACK | 1.2 | +0.0 | 88.3 | 40.7 | 1.0 | +0.0 | 10.9 | 39.6 |
| LONE WIZARD KEPT IN | 0.6 | +26.9 | 0.0 | 0.0 | 0.2 | +20.3 | 0.0 | 0.0 |
| MAKE SURE TOGETHER | 0.5 | +26.3 | 3.8 | 15.9 | 0.4 | +11.6 | 12.9 | 1.7 |
| MANOEUVRE | 0.2 | +5.8 | 0.0 | 1.8 | 0.2 | +5.2 | 0.0 | 3.4 |
| MARCH AT ESCAPER | 0.2 | +1.0 | 0.0 | 0.0 | 0.1 | +0.3 | 0.0 | 15.0 |
| MARCH CHECK | 0.5 | +32.9 | 0.0 | 19.6 | 0.3 | +8.5 | 0.0 | 3.2 |
| MARCH ODDS | 1.0 | +49.7 | 53.5 | 13.9 | 0.5 | +59.6 | 19.0 | 10.9 |
| MARCH OVER CASTS | 0.9 | +16.7 | 0.0 | 24.1 | 0.8 | -4.0 | 0.0 | 34.6 |
| MAX FOR POSITIONING | 4.9 | +163.3 | 0.0 | 96.8 | 4.1 | +118.3 | 0.0 | 98.0 |
| MISSILES IN THE MOVE | 3.7 | +120.9 | 0.0 | 70.6 | 1.9 | +32.6 | 0.0 | 6.9 |
| MISSILES NEXT TURN | 5.1 | +93.0 | 0.0 | 110.6 | 2.7 | +29.1 | 0.0 | 41.5 |
| MODEL FACING | 0.3 | +58.0 | 0.0 | 1.7 | - | - | - | - |
| MOVE AND CAST | 0.1 | +6.0 | 0.0 | 0.0 | 0.1 | +4.6 | 0.0 | 0.0 |
| MOVE SPELL IN RANGE | 0.3 | +6.4 | 0.0 | 4.7 | - | - | - | - |
| MOVE SPELL OUT OF RANGE | 0.8 | -55.5 | 2.2 | 33.3 | 0.1 | -1.4 | 0.0 | 0.0 |
| MOVE SPELL SPOT | 0.6 | +0.0 | 0.0 | 24.1 | - | - | - | - |
| MOVES UNITS SPELL | 0.1 | +3.3 | 0.0 | 0.0 | 0.1 | +0.6 | 0.0 | 0.0 |
| NEEDED THERE | 0.1 | +4.7 | 7.4 | 0.0 | 0.1 | +18.4 | 7.4 | 0.0 |
| NO RALLY LEFT | 0.0 | +0.1 | 0.0 | 3.4 | 0.0 | +1.2 | 0.0 | 0.0 |
| NOT NEEDED | 0.4 | -14.6 | 36.2 | 4.9 | 0.3 | -27.5 | 37.1 | 3.3 |
| NOT TURNED | 7.7 | +91.5 | 0.0 | 183.8 | 8.2 | +135.1 | 0.0 | 154.1 |
| NOT WORTH A CAST | 0.7 | -0.5 | 0.0 | 1.7 | 0.3 | -0.1 | 0.0 | 0.0 |
| OPENS A LANE | 0.2 | +0.7 | 14.6 | 0.0 | 0.2 | +1.7 | 28.3 | 0.0 |
| OPENS UP | 0.2 | +9.5 | 16.0 | 0.0 | 0.2 | +6.8 | 7.0 | 13.9 |
| OVERRUNS AWAY | 0.5 | +9.1 | 42.9 | 21.6 | 0.2 | +4.2 | 19.5 | 8.2 |
| PATHS CROSS | 2.1 | +127.7 | 0.0 | 53.5 | 2.6 | +198.4 | 0.0 | 38.3 |
| PERIAPT WORTH | 0.1 | +4.5 | 0.0 | 0.0 | 0.1 | +4.9 | 0.0 | 0.0 |
| PLAN LEADS | 1.2 | +115.2 | 37.9 | 16.8 | 0.9 | +79.8 | 19.3 | 25.6 |
| PLAN RESULT | 39.4 | +1587.5 | 1431.0 | 963.1 | 37.6 | +1261.4 | 1151.1 | 1034.2 |
| PURSUES BIG PREY | 0.0 | -0.7 | 0.0 | 0.0 | 0.1 | -4.2 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE | - | - | - | - | 0.0 | +4.9 | 0.0 | 0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 0.1 | +9.9 | 0.0 | 0.0 | 0.2 | +14.8 | 0.0 | 1.5 |
| REDIRECT COUNTER | 3.2 | +149.3 | 0.0 | 62.8 | 4.6 | +168.4 | 0.0 | 95.0 |
| REDIRECT WEIGHED | 0.4 | +6.2 | 13.6 | 2.4 | 0.4 | +31.5 | 23.0 | 12.8 |
| RESTRAINS TO SHOOT | 0.1 | +3.0 | 0.0 | 2.9 | 0.1 | +2.9 | 0.0 | 3.4 |
| RISK BY ARC | 2.7 | +101.9 | 192.7 | 101.1 | 3.1 | +54.3 | 187.9 | 129.8 |
| SAFER THAN THE JOB | 0.6 | +43.6 | 0.0 | 32.9 | 0.6 | +19.4 | 0.0 | 5.9 |
| SCOUT SPOT | 0.4 | +0.5 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SCOUT WAITS | 0.5 | +0.0 | 0.0 | 0.0 | 0.1 | +0.0 | 0.0 | 0.0 |
| SEARCH SPOT | 1.4 | +79.4 | 0.0 | 11.7 | 1.8 | +65.4 | 0.0 | 30.7 |
| SECOND HUNTER | 0.0 | -0.0 | 13.1 | 0.0 | 0.0 | -0.0 | 0.0 | 0.0 |
| SELF MOVE SPELL | 0.2 | +55.2 | 0.0 | 0.0 | 0.4 | +20.6 | 0.0 | 18.1 |
| SET UP TOGETHER | 0.6 | +36.2 | 3.8 | 19.2 | 0.7 | +16.8 | 16.4 | 1.7 |
| SET-UP ANY TARGET | 0.6 | +88.6 | 10.2 | 29.4 | - | - | - | - |
| SET-UP MISSED | 0.1 | +11.7 | 0.0 | 0.0 | - | - | - | - |
| SHOOTERS IN TWO RANKS | 0.3 | +0.7 | 0.0 | 0.0 | 0.2 | +0.3 | 0.0 | 0.0 |
| SHORT GUN FORWARD | 0.2 | +0.0 | 0.0 | 3.2 | 0.0 | +0.0 | 0.0 | 0.0 |
| SHOT REPLANNED | 0.5 | +0.0 | 97.1 | 2.6 | 0.3 | +0.0 | 59.2 | 4.9 |
| SHOTS IN THE MOVE | 13.2 | +501.4 | 0.0 | 237.5 | 7.1 | +172.2 | 0.0 | 94.0 |
| SPELL CATCH ODDS | 0.0 | -0.2 | 0.0 | 0.0 | - | - | - | - |
| SPELL SETS UP CHARGE | 0.6 | +88.6 | 10.2 | 29.4 | - | - | - | - |
| SPELL WORTH | 1.6 | +22.9 | 106.5 | 119.1 | 2.2 | +40.8 | 98.9 | 96.2 |
| STANDS TO CAST | 0.1 | +0.5 | 0.0 | 0.0 | 0.1 | +4.2 | 0.0 | 0.0 |
| STOPS | 0.1 | +0.3 | 26.1 | 1.8 | 0.0 | +0.0 | 0.0 | 0.0 |
| STUCK PIVOT | 0.2 | +0.0 | 0.0 | 8.8 | 0.4 | +0.0 | 0.0 | 0.0 |
| SURE CHARGE BEATS ADVANCE | 0.1 | -7.5 | 19.9 | 3.1 | 0.1 | -0.5 | 2.4 | 0.0 |
| SURE REACH TOGETHER | 0.3 | +4.1 | 0.0 | 10.2 | 0.4 | +5.6 | 3.5 | 7.3 |
| THROUGH LINE OF FIRE | 0.5 | +10.4 | 0.0 | 16.3 | 0.4 | +18.6 | 0.0 | 0.0 |
| TURN WORTH | 0.8 | -49.4 | 57.3 | 8.6 | 0.2 | -11.5 | 10.6 | 0.0 |
| TWO OR MORE ARRIVE | 0.2 | +0.4 | 0.0 | 2.1 | 0.1 | +1.1 | 0.0 | 0.0 |
| WEARS DOWN | 0.8 | +30.5 | 89.1 | 32.2 | 1.4 | +51.8 | 65.4 | 90.5 |
| WHO HITS BACK | 0.3 | +20.2 | 0.0 | 3.6 | 0.1 | +0.6 | 0.0 | 0.0 |
| WHOLE FIGHT | 0.4 | +23.8 | 69.7 | 0.0 | 0.5 | -1.3 | 28.0 | 0.0 |
| WHOLE FIGHT GAIN | 0.2 | +13.2 | 22.8 | 7.4 | 0.7 | +66.4 | 61.1 | 20.4 |

### Rule changes: ef2-opp-f5fe7c8-p4

Per rule, both sides, the whole batch: fired = rows; checked = rows that say whether the decision would have gone the other way without the rule; changed = it would have; VP = what the changes were worth by the rule's own numbers (taken minus replaced); a game = changed / games.

| Rule | Fired | Checked | Changed | Changed a game | VP of the changes | VP a change |
| --- | --- | --- | --- | --- | --- | --- |
| KILLS COUNT NEXT TURN | 734 | 723 | 215 | 5.97 | +8511 | +39.6 |
| PATHS CROSS | 169 | 169 | 169 | 4.69 | +11741 | +69.5 |
| BEST PREY | 357 | 349 | 148 | 4.11 | +6454 | +43.6 |
| SEARCH SPOT | 113 | 113 | 111 | 3.08 | +5246 | +47.3 |
| COUNTER-CHARGE COVER | 539 | 270 | 109 | 3.03 | +4663 | +42.8 |
| FALLBACK BY WORTH | 491 | 491 | 89 | 2.47 | +4245 | +47.7 |
| FACES THE THREAT | 79 | 79 | 79 | 2.19 | +7154 | +90.6 |
| FOLLOW UP WEIGHED | 73 | 73 | 73 | 2.03 | +9069 | +124.2 |
| MARCH ODDS | 53 | 53 | 50 | 1.39 | +1132 | +22.6 |
| RISK BY ARC | 206 | 198 | 49 | 1.36 | +1494 | +30.5 |
| CANNON SIGHT KEPT | 48 | 48 | 48 | 1.33 | +0 | +0.0 |
| KILLS COUNT | 158 | 150 | 48 | 1.33 | +2622 | +54.6 |
| SHOTS IN THE MOVE | 730 | 471 | 47 | 1.31 | +1265 | +26.9 |
| CHARGE NOW WEIGHED | 42 | 42 | 42 | 1.17 | +2189 | +52.1 |
| SAFER THAN THE JOB | 42 | 42 | 42 | 1.17 | +2266 | +54.0 |
| ADVANCE LANE KEPT | 41 | 41 | 41 | 1.14 | +0 | +0.0 |
| ENEMY FORECAST | 254 | 252 | 38 | 1.06 | +219 | +5.8 |
| BLOCKED WHEEL | 37 | 37 | 37 | 1.03 | +963 | +26.0 |
| ARTILLERY RE-ROLL WEIGHED | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| HOLDS AMBUSHERS | 35 | 35 | 35 | 0.97 | +0 | +0.0 |
| MAX FOR POSITIONING | 326 | 161 | 34 | 0.94 | +178 | +5.2 |
| KEEPS ITS TARGET | 145 | 143 | 33 | 0.92 | +601 | +18.2 |
| THROUGH LINE OF FIRE | 31 | 31 | 31 | 0.86 | +1043 | +33.6 |
| SHOT REPLANNED | 29 | 29 | 29 | 0.81 | +0 | +0.0 |
| LONE WIZARD KEPT IN | 28 | 28 | 28 | 0.78 | +1699 | +60.7 |
| REDIRECT WEIGHED | 28 | 28 | 28 | 0.78 | +1412 | +50.4 |
| REDIRECT COUNTER | 280 | 100 | 27 | 0.75 | +1839 | +68.1 |
| LONE WIZARD HOLDS BACK | 80 | 80 | 26 | 0.72 | -1130 | -43.5 |
| PLAN LEADS | 77 | 77 | 24 | 0.67 | +1047 | +43.6 |
| STUCK PIVOT | 24 | 24 | 24 | 0.67 | +0 | +0.0 |
| CANNON PLANNED TARGET | 183 | 183 | 23 | 0.64 | -930 | -40.4 |
| CAST JOB | 37 | 37 | 22 | 0.61 | +535 | +24.3 |
| WHOLE FIGHT GAIN | 33 | 33 | 22 | 0.61 | +876 | +39.8 |
| SCOUT WAITS | 21 | 21 | 21 | 0.58 | +0 | +0.0 |
| CHARIOT NO STATIC JOB | 28 | 28 | 19 | 0.53 | -1822 | -95.9 |
| FRIENDS SHOTS CHECKED | 17 | 17 | 17 | 0.47 | +918 | +54.0 |
| SHOOTERS IN TWO RANKS | 17 | 17 | 17 | 0.47 | +36 | +2.1 |
| CASTER AWAY FROM SCREEN | 16 | 16 | 16 | 0.44 | +0 | +0.0 |
| CHAFF PASSED | 16 | 16 | 16 | 0.44 | -42 | -2.7 |
| MANOEUVRE | 15 | 15 | 15 | 0.42 | +397 | +26.5 |
| MARCH CHECK | 30 | 16 | 15 | 0.42 | +568 | +37.9 |
| CASTING BLOCK | 18 | 18 | 14 | 0.39 | +1537 | +109.8 |
| SET UP TOGETHER | 49 | 39 | 14 | 0.39 | +222 | +15.8 |
| MISSILES IN THE MOVE | 202 | 94 | 13 | 0.36 | +336 | +25.8 |
| WHO HITS BACK | 13 | 13 | 13 | 0.36 | -542 | -41.7 |
| WEARS DOWN | 80 | 78 | 11 | 0.31 | +403 | +36.6 |
| MODEL FACING | 10 | 10 | 10 | 0.28 | +2087 | +208.7 |
| CASTS FROM BEHIND | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| SHORT GUN FORWARD | 9 | 9 | 9 | 0.25 | +0 | +0.0 |
| WHOLE FIGHT | 32 | 30 | 9 | 0.25 | +415 | +46.1 |
| MAKE SURE TOGETHER | 31 | 21 | 8 | 0.22 | +136 | +17.0 |
| MOVE AND CAST | 8 | 8 | 8 | 0.22 | +382 | +47.7 |
| BACKUP TARGETS | 83 | 39 | 7 | 0.19 | +9 | +1.3 |
| BLOCKED CHARGE SKIPPED | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| MOVES UNITS SPELL | 7 | 7 | 7 | 0.19 | +138 | +19.7 |
| NEEDED THERE | 7 | 7 | 7 | 0.19 | +0 | +0.0 |
| RAIDS THE BAGGAGE NEXT TURN | 9 | 9 | 7 | 0.19 | +385 | +55.0 |
| SURE CHARGE BEATS ADVANCE | 7 | 7 | 7 | 0.19 | -289 | -41.2 |
| KEEP FALLS | 5 | 5 | 5 | 0.14 | +442 | +88.5 |
| PURSUES BIG PREY | 5 | 5 | 5 | 0.14 | -175 | -35.1 |
| MISSILES NEXT TURN | 281 | 123 | 4 | 0.11 | +30 | +7.5 |
| PERIAPT WORTH | 4 | 4 | 4 | 0.11 | +338 | +84.4 |
| RESTRAINS TO SHOOT | 4 | 4 | 4 | 0.11 | +213 | +53.2 |
| STANDS TO CAST | 4 | 4 | 4 | 0.11 | -126 | -31.4 |
| BEST PRIZE | 3 | 3 | 3 | 0.08 | -103 | -34.3 |
| FIRE AND FLEE | 3 | 3 | 3 | 0.08 | +29 | +9.6 |
| OPENS UP | 12 | 12 | 3 | 0.08 | +99 | +33.0 |
| OVERRUNS AWAY | 27 | 27 | 3 | 0.08 | +35 | +11.6 |
| SURE REACH TOGETHER | 26 | 14 | 3 | 0.08 | +0 | +0.0 |
| ELIXIR WORTH | 2 | 2 | 2 | 0.06 | +103 | +51.5 |
| GIVES UP | 93 | 89 | 2 | 0.06 | +19 | +9.7 |
| HUNT IN PAIRS | 32 | 17 | 2 | 0.06 | +129 | +64.4 |
| KEEPS SCOUTS OR AMBUSH | 2 | 2 | 2 | 0.06 | +0 | +0.0 |
| NO RALLY LEFT | 2 | 2 | 2 | 0.06 | +34 | +17.0 |
| BOMBING RUN | 1 | 1 | 1 | 0.03 | +15 | +14.7 |
| CARRIES OUT COUNTER | 1 | 1 | 1 | 0.03 | -100 | -99.5 |
| CARRIES OUT SET-UP | 3 | 3 | 1 | 0.03 | -26 | -26.4 |
| EDGE GIVE GROUND | 4 | 4 | 1 | 0.03 | +16 | +16.1 |
| FOCUS FIRE | 1 | 1 | 1 | 0.03 | +4 | +3.6 |
| GIVES UP ITS SCREEN | 63 | 62 | 1 | 0.03 | +19 | +19.0 |
| HUNT ADVANCE | 5 | 5 | 1 | 0.03 | +31 | +30.6 |
| JOINT CHARGE PLAN | 5 | 5 | 1 | 0.03 | +48 | +48.0 |
| KEEPS ITS PREY | 16 | 15 | 1 | 0.03 | +8 | +8.0 |
| MOVE SPELL IN RANGE | 11 | 4 | 1 | 0.03 | +18 | +17.8 |
| RAIDS THE BAGGAGE | 1 | 1 | 1 | 0.03 | +161 | +160.7 |
| STOPS | 4 | 4 | 1 | 0.03 | +7 | +7.2 |
| TWO OR MORE ARRIVE | 13 | 11 | 1 | 0.03 | +12 | +12.5 |
| ALREADY CARRIED | 4 | not checked | - | - | - | - |
| ARRIVAL HUNT | 1 | 1 | 0 | 0.00 | - | - |
| CANNON PLAN MISSED | 34 | 34 | 0 | 0.00 | - | - |
| CASTS AFTER FRIENDS | 42 | trace | - | - | - | - |
| CATCH FLIERS | 2 | not checked | - | - | - | - |
| CHAMPION TAKES THE CHALLENGE | 1 | 1 | 0 | 0.00 | - | - |
| CHEAP HELPER | 4 | not checked | - | - | - | - |
| CONVEYANCE SEARCH | 37 | not checked | - | - | - | - |
| ENGINEER BY LORE | 4 | 4 | 0 | 0.00 | - | - |
| FIGHT LIFT | 4 | not checked | - | - | - | - |
| FLANK NOT WEIGHED | 21 | not checked | - | - | - | - |
| FORECAST RESULT | 2893 | trace | - | - | - | - |
| GROUND FLIERS | 3 | not checked | - | - | - | - |
| HELPER ALREADY ASKED | 7 | not checked | - | - | - | - |
| HELPER UNSEEN | 23 | 22 | 0 | 0.00 | - | - |
| HUNT DROPPED | 4 | trace | - | - | - | - |
| HUNT RESULT | 9 | trace | - | - | - | - |
| HUNT THE GUNS | 9 | trace | - | - | - | - |
| LONE CHARACTER SAFE SPOT | 21 | not checked | - | - | - | - |
| MARCH AT ESCAPER | 11 | trace | - | - | - | - |
| MARCH OVER CASTS | 61 | 61 | 0 | 0.00 | - | - |
| MOVE SPELL OUT OF RANGE | 32 | trace | - | - | - | - |
| MOVE SPELL SPOT | 21 | not checked | - | - | - | - |
| NOT NEEDED | 23 | 23 | 0 | 0.00 | - | - |
| NOT TURNED | 572 | 572 | 0 | 0.00 | - | - |
| NOT WORTH A CAST | 37 | not checked | - | - | - | - |
| OPENS A LANE | 15 | 7 | 0 | 0.00 | - | - |
| PLAN RESULT | 2770 | trace | - | - | - | - |
| SCOUT SPOT | 19 | 19 | 0 | 0.00 | - | - |
| SECOND HUNTER | 2 | 2 | 0 | 0.00 | - | - |
| SELF MOVE SPELL | 20 | not checked | - | - | - | - |
| SET-UP ANY TARGET | 21 | not checked | - | - | - | - |
| SET-UP MISSED | 3 | trace | - | - | - | - |
| SPELL CATCH ODDS | 1 | not checked | - | - | - | - |
| SPELL SETS UP CHARGE | 21 | not checked | - | - | - | - |
| SPELL WORTH | 134 | not checked | - | - | - | - |
| TURN WORTH | 37 | 37 | 0 | 0.00 | - | - |

### Plans: ef2-opp-f5fe7c8-p4

Each unit's objective against what came of it by the next Start of Turn: plans a game, the share that happened (charge: in contact or the target gone or fled; close in / advance: charging it now; shoot: wounds lost; hold: holds the marker; support / join: still in place), VP planned and won a game, won as a share of planned.

| Side | Plan | Plans | Happened | Planned VP | Won VP | Won of planned |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | advance | 14.0 | 21% | 580 | 463 | 80% |
| Mine | charge | 3.2 | 65% | 290 | 317 | 109% |
| Mine | close in | 4.8 | 29% | 272 | 144 | 53% |
| Mine | hold | 4.3 | 35% | 374 | 0 | 0% |
| Mine | join | 0.7 | 92% | 16 | 0 | 0% |
| Mine | shoot | 8.1 | 61% | 306 | 664 | 217% |
| Mine | support | 4.3 | 86% | 285 | 0 | 0% |
| Opponent | advance | 14.1 | 18% | 778 | 377 | 48% |
| Opponent | charge | 4.6 | 51% | 545 | 383 | 70% |
| Opponent | close in | 4.7 | 29% | 406 | 138 | 34% |
| Opponent | hold | 4.3 | 29% | 427 | 0 | 0% |
| Opponent | join | 0.5 | 94% | 24 | 0 | 0% |
| Opponent | shoot | 3.4 | 70% | 112 | 366 | 326% |
| Opponent | support | 6.0 | 89% | 235 | 0 | 0% |

### Enemy forecast: ef2-opp-f5fe7c8-p4

Per side (the computer that made the forecast) and expected action: forecasts a game, right (it did the expected action on the expected target), gone (missed, but the target or the enemy was gone before it acted), and what the enemy did instead; right of judged leaves the gone ones out.

| Side | Expected | A game | Right | Gone | Right of judged | Did charge | Did shoot | Did move | Same target |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | charge | 3.5 | 52% | 13% | 60% | 66% | 10% | 25% | 54% |
| Mine | shoot | 5.7 | 24% | 32% | 35% | 2% | 56% | 42% | 25% |
| Mine | move | 29.4 | 78% | 2% | 79% | 9% | 13% | 78% | - |
| Mine | all | 38.6 | 67% | 7% | 73% | 13% | 19% | 68% | - |
| Opponent | charge | 2.9 | 58% | 16% | 69% | 66% | 10% | 25% | 62% |
| Opponent | shoot | 13.6 | 36% | 19% | 45% | 2% | 74% | 24% | 37% |
| Opponent | move | 25.2 | 69% | 3% | 70% | 8% | 24% | 69% | - |
| Opponent | all | 41.7 | 57% | 9% | 63% | 10% | 39% | 51% | - |

Expected moves (the enemy's own plan): how far the expected end was from where the unit ended, against the guess that it stays where it stood.

| Side | Moves a game | Median miss | Median miss if it stays | Within 3" | Within 6" | Better than stays |
| --- | --- | --- | --- | --- | --- | --- |
| Mine | 21.2 | 7.2" | 4.0" | 21% | 43% | 21% |
| Opponent | 16.1 | 7.0" | 4.0" | 23% | 45% | 22% |

### Packages: hunt the guns, ef2-opp-f5fe7c8-p4

Each hunt of an enemy war machine or lone Wizard (hidden HUNT rows). Reached/killed/broken/worked are shares of the hunts that ended; turns to kill counts the Start of Turns from the hunt's first; planned = the quarry's VP + its output for the turns left; the last column is the points the enemy's war machines destroyed, a game.

| Side | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | 0.1 | 4 | 0 | 50% | 75% | 25% | 2.0 | 349 | 293 | 75% | 5 |
| Opponent | 0.1 | 5 | 0 | 0% | 20% | 0% | 2.0 | 384 | 58 | 20% | 72 |

| Army | Jobs a game | Jobs | Open at the end | Reached | Killed | Broken | Turns to kill | Planned VP a job | Won VP a job | Worked (won 2/3+) | Enemy war machines' kills a game |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Beastmen Brayherds | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Chaos Dwarfs | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Dwarfen Mountain Holds | 0.7 | 2 | 0 | 100% | 100% | 0% | 2.0 | 493 | 487 | 100% | 58 |
| Empire of Man | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 21 |
| Grand Cathay | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| High Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 7 |
| Kingdom of Bretonnia | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Lizardmen | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 117 |
| Ogre Kingdoms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |
| Orc & Goblin Tribes | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 117 |
| Skaven | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 105 |
| Tomb Kings of Khemri | 1.0 | 4 | 0 | 0% | 25% | 25% | 2.0 | 320 | 50 | 25% | 0 |
| Vampire Counts | 0.4 | 3 | 0 | 0% | 33% | 0% | 2.0 | 350 | 97 | 33% | 0 |
| Warriors of Chaos | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 119 |
| Wood Elf Realms | 0.0 | 0 | 0 | - | - | - | - | - | - | - | 0 |

### Battle groups: ef2-opp-f5fe7c8-p4

Promised counter-charges (rows a game; of the rows: the unit charged that round or the next, by an enemy the row named; of those charges: answered by a counter-charge on the charger, by a friend the row named; when no counter came, why).

| Side | Rule | Rows | Charged | By named enemy | Answered | By named friend | Charger gone or fled | Friend gone | Friend charged another | Friend charged nothing | No friend named |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | COUNTER-CHARGE COVER | 8.8 | 29% | 43% | 10% | 33% | 33% | 16% | 12% | 39% | 0% |
| Mine | REDIRECT COUNTER | 3.2 | 32% | 54% | 3% | 0% | 19% | 3% | 14% | 56% | 8% |
| Opponent | COUNTER-CHARGE COVER | 6.2 | 20% | 58% | 18% | 0% | 35% | 14% | 3% | 49% | 0% |
| Opponent | REDIRECT COUNTER | 4.6 | 22% | 69% | 11% | 25% | 19% | 3% | 12% | 66% | 0% |

Group aims (GROUP AIM rows a game; aims = unit and target; of those: the unit charged the target within three rounds, and its partner charged it the same round).

| Side | Rows | Aims | Charged it | Together |
| --- | --- | --- | --- | --- |
| Mine | 0.0 | 0 | - | - |
| Opponent | 0.0 | 0 | - | - |

### Deployment: positions vs output by unit type: ef2-opp-f5fe7c8-p4

Output = kills + objectives per 100 of its own points (units in brackets). Kills = the Victory Points of the enemy units it put out of the battle (a fight's points shared by the wounds caused); objectives = the markers, hill, baggage and trophies it scored (game logs from 2026-11-08 on; quarters at the end of the battle belong to no one unit). Acted = fought, shot or cast; round = the mean round of its first action. Joined characters count where their unit deployed.

| Side | Type | Units | Output per 100 | Kills per 100 | Objectives per 100 | Lost per 100 | Never acted | First action round | Output per 100: left | Output per 100: centre | Output per 100: right | Output per 100: front half | Output per 100: back half |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Blocker | 4 | 0 (4) | 0 | 0 | 100 | 75% | 4.0 | - | 0 (1) | - | - | 0 (1) |
| Mine | Chaff | 49 | 49 (49) | 32 | 17 | 66 | 29% | 2.6 | 16 (21) | 60 (11) | 87 (17) | 61 (32) | 27 (17) |
| Mine | Character | 106 | 45 (106) | 44 | 1 | 38 | 15% | 2.4 | 38 (35) | 59 (48) | 0 (7) | 43 (46) | 54 (44) |
| Mine | Clean-up | 14 | 106 (14) | 34 | 72 | 32 | 36% | 3.2 | 97 (6) | 125 (5) | 87 (3) | 140 (7) | 77 (7) |
| Mine | Early | 1 | 0 (1) | 0 | 0 | 0 | 0% | 5.0 | - | 0 (1) | - | 0 (1) | - |
| Mine | Fast Hammer | 39 | 37 (39) | 25 | 12 | 34 | 15% | 2.5 | 26 (24) | 69 (9) | 31 (6) | 40 (28) | 28 (11) |
| Mine | Fragile | 4 | 27 (4) | 27 | 0 | 73 | 0% | 2.8 | 37 (3) | 0 (1) | - | 0 (1) | 37 (3) |
| Mine | Hammer | 64 | 34 (64) | 23 | 11 | 46 | 12% | 2.8 | 13 (10) | 31 (44) | 80 (10) | 26 (39) | 45 (25) |
| Mine | Holder | 30 | 77 (30) | 6 | 71 | 22 | 37% | 3.4 | 5 (6) | 130 (17) | 4 (7) | 131 (17) | 2 (13) |
| Mine | Shooter | 35 | 96 (35) | 58 | 38 | 31 | 0% | 1.5 | 71 (11) | 107 (19) | 105 (5) | 135 (23) | 25 (12) |
| Mine | Support | 1 | 0 (1) | 0 | 0 | 0 | 0% | 6.0 | - | - | 0 (1) | 0 (1) | - |
| Mine | War machine | 56 | 38 (56) | 38 | 0 | 34 | 7% | 1.2 | 22 (20) | 52 (31) | 32 (5) | 14 (7) | 41 (49) |
| Mine | Wizard | 17 | 20 (17) | 20 | 0 | 52 | 12% | 2.3 | 0 (5) | 60 (6) | 0 (1) | 0 (4) | 44 (8) |
| Opponent | Blocker | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | - | 0 (1) |
| Opponent | Chaff | 82 | 40 (82) | 13 | 28 | 59 | 40% | 2.8 | 46 (30) | 32 (21) | 42 (31) | 47 (62) | 15 (20) |
| Opponent | Character | 97 | 53 (97) | 53 | 0 | 33 | 21% | 2.1 | 57 (43) | 53 (44) | 37 (7) | 56 (49) | 51 (45) |
| Opponent | Clean-up | 12 | 135 (12) | 21 | 114 | 24 | 42% | 2.9 | 95 (3) | 162 (6) | 90 (3) | 152 (7) | 119 (5) |
| Opponent | Fast | 1 | 0 (1) | 0 | 0 | 0 | 100% | - | - | 0 (1) | - | 0 (1) | - |
| Opponent | Fast Hammer | 54 | 40 (54) | 25 | 15 | 42 | 31% | 2.8 | 29 (27) | 49 (17) | 65 (10) | 46 (34) | 32 (20) |
| Opponent | Fragile | 16 | 18 (16) | 18 | 0 | 61 | 6% | 2.1 | 0 (2) | 0 (8) | 90 (3) | 28 (10) | 0 (3) |
| Opponent | Hammer | 64 | 20 (64) | 16 | 3 | 44 | 36% | 3.1 | 55 (20) | 9 (38) | 18 (6) | 16 (42) | 25 (22) |
| Opponent | Holder | 27 | 62 (27) | 34 | 28 | 26 | 59% | 3.6 | 7 (10) | 100 (14) | 0 (3) | 89 (16) | 21 (11) |
| Opponent | Shooter | 34 | 103 (34) | 38 | 65 | 37 | 0% | 1.5 | 162 (9) | 91 (23) | 10 (2) | 117 (20) | 83 (14) |
| Opponent | Support | 6 | 41 (6) | 41 | 0 | 15 | 17% | 3.4 | 61 (4) | 0 (2) | - | 0 (3) | 80 (3) |
| Opponent | War machine | 6 | 27 (6) | 27 | 0 | 19 | 0% | 1.7 | 30 (3) | 22 (3) | - | 30 (3) | 22 (3) |
| Opponent | Wizard | 20 | 2 (20) | 2 | 0 | 45 | 10% | 2.5 | 0 (11) | 7 (4) | 0 (2) | 3 (10) | 0 (7) |

### Charged fights: ef2-opp-f5fe7c8-p4

| Side | Army | Games | Points won by shooting + magic per game | Points won in charged fights per game | Fights per game | Chargers per fight | Points won per fight | Points lost per fight | Net per fight | On a top-3 enemy unit | Won the first round | Net per combined fight | Net per lone fight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 4 | 281 | 85 | 1.2 | 1.6 | 68 | 17 | +51 | 0 of 5 | 5 of 5 | +114 | -42 |
| Mine | Chaos Dwarfs | 4 | 84 | 18 | 2.8 | 1.1 | 7 | 50 | -44 | 5 of 11 | 3 of 11 | +0 | -48 |
| Mine | Dwarfen Mountain Holds | 3 | 318 | 248 | 2.3 | 1.1 | 106 | 87 | +19 | 2 of 7 | 2 of 7 | +470 | -56 |
| Mine | Empire of Man | 5 | 307 | 35 | 1.4 | 1.1 | 25 | 54 | -28 | 1 of 7 | 5 of 7 | +0 | -33 |
| Mine | Grand Cathay | 4 | 321 | 221 | 2.8 | 1.2 | 80 | 60 | +21 | 3 of 11 | 10 of 11 | +0 | +25 |
| Mine | High Elf Realms | 4 | 453 | 319 | 3.2 | 1.0 | 98 | 46 | +52 | 2 of 13 | 11 of 13 | - | +52 |
| Mine | Kingdom of Bretonnia | 1 | 145 | 0 | 3.0 | 1.0 | 0 | 286 | -286 | 2 of 3 | 0 of 3 | - | -286 |
| Mine | Lizardmen | 1 | 55 | 1234 | 4.0 | 1.2 | 308 | 0 | +308 | 2 of 4 | 3 of 4 | +255 | +326 |
| Mine | Ogre Kingdoms | 2 | 0 | 28 | 2.5 | 1.0 | 11 | 88 | -77 | 1 of 5 | 2 of 5 | - | -77 |
| Mine | Skaven | 2 | 316 | 35 | 1.5 | 1.3 | 23 | 48 | -25 | 2 of 3 | 2 of 3 | +70 | -72 |
| Mine | Tomb Kings of Khemri | 2 | 0 | 804 | 5.0 | 1.1 | 161 | 6 | +155 | 4 of 10 | 9 of 10 | +60 | +165 |
| Mine | Vampire Counts | 2 | 140 | 366 | 6.5 | 1.1 | 56 | 3 | +53 | 2 of 13 | 8 of 13 | +109 | +49 |
| Mine | Warriors of Chaos | 2 | 0 | 396 | 4.5 | 1.2 | 88 | 74 | +14 | 3 of 9 | 9 of 9 | +140 | -23 |
| **Mine** | all armies | 36 | 227 | 222 | 2.8 | 1.1 | 79 | 50 | +29 | 29 of 101 | 69 of 101 | +113 | +15 |
| Opponent | Empire of Man | 1 | 468 | 0 | 0.0 | - | - | - | - | - | - | - | - |
| Opponent | High Elf Realms | 5 | 143 | 573 | 5.0 | 1.2 | 115 | 65 | +50 | 15 of 25 | 13 of 25 | +50 | +50 |
| Opponent | Lizardmen | 2 | 0 | 594 | 5.5 | 1.1 | 108 | 26 | +82 | 9 of 11 | 5 of 11 | +369 | +54 |
| Opponent | Orc & Goblin Tribes | 3 | 0 | 557 | 5.3 | 1.1 | 104 | 19 | +85 | 4 of 16 | 9 of 16 | -310 | +111 |
| Opponent | Skaven | 4 | 44 | 24 | 1.8 | 1.0 | 14 | 6 | +7 | 3 of 7 | 3 of 7 | - | +7 |
| Opponent | Tomb Kings of Khemri | 2 | 158 | 550 | 4.0 | 1.1 | 138 | 0 | +138 | 5 of 8 | 6 of 8 | +540 | +80 |
| Opponent | Vampire Counts | 6 | 40 | 425 | 5.7 | 1.2 | 75 | 52 | +23 | 20 of 34 | 15 of 34 | +57 | +16 |
| Opponent | Warriors of Chaos | 7 | 12 | 312 | 3.1 | 1.0 | 99 | 44 | +55 | 10 of 22 | 12 of 22 | +485 | +34 |
| Opponent | Wood Elf Realms | 6 | 122 | 316 | 4.8 | 1.1 | 65 | 50 | +16 | 10 of 29 | 18 of 29 | -291 | +51 |
| **Opponent** | all armies | 36 | 76 | 376 | 4.2 | 1.1 | 89 | 42 | +47 | 76 of 152 | 81 of 152 | +45 | +47 |

### Effective charges: ef2-opp-f5fe7c8-p4

Each fight by the chance to win the first round the computer picked the charge by (the general's question, or the static opponent's objective line); net = points won minus lost per fight. Fights without a figure (the test player, or a charge picked another way) are counted apart.

| Side | Army | Fights | Long shot (under 50%) | 50-54% | Effective (55-75%) | 76-89% | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 90%+ not overkill (target 250+ pts or chargers up to 3x) | No figure | Effective share |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Beastmen Brayherds | 5 | 1 (net -85) | 0 | 0 | 0 | 0 | 4 (net +85) | 0 | 0% (0 of 5) |
| Mine | Chaos Dwarfs | 11 | 2 (net -48) | 0 | 1 (net -120) | 2 (net -170) | 1 (net +0) | 3 (net +24) | 2 | 11% (1 of 9) |
| Mine | Dwarfen Mountain Holds | 7 | 0 | 1 (net -612) | 2 (net +265) | 0 | 0 | 3 (net +71) | 1 | 33% (2 of 6) |
| Mine | Empire of Man | 7 | 1 (net +0) | 0 | 3 (net -63) | 1 (net +0) | 0 | 1 (net -10) | 1 | 50% (3 of 6) |
| Mine | Grand Cathay | 11 | 0 | 0 | 0 | 2 (net -184) | 2 (net +0) | 6 (net +136) | 1 | 0% (0 of 10) |
| Mine | High Elf Realms | 13 | 0 | 0 | 1 (net +431) | 3 (net -114) | 3 (net +63) | 6 (net +67) | 0 | 8% (1 of 13) |
| Mine | Kingdom of Bretonnia | 3 | 0 | 0 | 0 | 1 (net -471) | 1 (net -386) | 1 (net +0) | 0 | 0% (0 of 3) |
| Mine | Lizardmen | 4 | 0 | 0 | 0 | 2 (net +490) | 1 (net +0) | 1 (net +255) | 0 | 0% (0 of 4) |
| Mine | Ogre Kingdoms | 5 | 0 | 0 | 0 | 1 (net -405) | 0 | 3 (net +18) | 1 | 0% (0 of 4) |
| Mine | Skaven | 3 | 1 (net -145) | 0 | 0 | 1 (net +70) | 0 | 1 (net +0) | 0 | 0% (0 of 3) |
| Mine | Tomb Kings of Khemri | 10 | 2 (net -30) | 0 | 1 (net +251) | 3 (net +286) | 1 (net +60) | 2 (net +135) | 1 | 11% (1 of 9) |
| Mine | Vampire Counts | 13 | 0 | 0 | 1 (net +0) | 3 (net +74) | 4 (net +77) | 4 (net +50) | 1 | 8% (1 of 12) |
| Mine | Warriors of Chaos | 9 | 0 | 0 | 2 (net -322) | 2 (net +46) | 2 (net +140) | 2 (net +142) | 1 | 25% (2 of 8) |
| Opponent | High Elf Realms | 25 | 3 (net -388) | 0 | 3 (net +99) | 5 (net +56) | 1 (net +0) | 9 (net +100) | 4 | 14% (3 of 21) |
| Opponent | Lizardmen | 11 | 2 (net +155) | 0 | 0 | 4 (net -70) | 0 | 2 (net +217) | 3 | 0% (0 of 8) |
| Opponent | Orc & Goblin Tribes | 16 | 0 | 0 | 1 (net -310) | 2 (net +92) | 0 | 3 (net +140) | 10 | 17% (1 of 6) |
| Opponent | Skaven | 7 | 2 (net -22) | 1 (net +0) | 1 (net +0) | 0 | 0 | 3 (net +32) | 0 | 14% (1 of 7) |
| Opponent | Tomb Kings of Khemri | 8 | 0 | 2 (net +0) | 0 | 1 (net +210) | 2 (net +32) | 2 (net +340) | 1 | 0% (0 of 7) |
| Opponent | Vampire Counts | 34 | 6 (net +26) | 1 (net +0) | 8 (net +39) | 8 (net +26) | 4 (net +69) | 5 (net +75) | 2 | 25% (8 of 32) |
| Opponent | Warriors of Chaos | 22 | 2 (net -240) | 0 | 3 (net +96) | 3 (net +149) | 2 (net +98) | 8 (net +131) | 4 | 17% (3 of 18) |
| Opponent | Wood Elf Realms | 29 | 3 (net -152) | 0 | 5 (net -107) | 4 (net +177) | 1 (net +45) | 10 (net +57) | 6 | 22% (5 of 23) |

### Charged fights, damage counted: ef2-opp-f5fe7c8-p4

Gone = units destroyed, run down or fled off in the fight (the older figure). Damage = also each unit's share of wounds lost while the fight ran, and half its points when it fled and was not caught. Per 100 = net with damage counted per 100 points of chargers.

| Side | Band | Fights | Chargers' points per fight | Target's points per fight | Net per fight (gone) | Won per fight (damage) | Lost per fight (damage) | Net per fight (damage) | Net per 100 charger points |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Mine | Long shot (under 50%) | 7 | 199 | 263 | -55 | 4 | 55 | -51 | -25.8 |
| Mine | 50-54% | 1 | 239 | 192 | -612 | 0 | 612 | -612 | -256.1 |
| Mine | Effective (55-75%) | 11 | 210 | 243 | +24 | 177 | 114 | +62 | +29.6 |
| Mine | 76-89% | 21 | 301 | 216 | +14 | 152 | 114 | +38 | +12.6 |
| Mine | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 37 | 196 | 143 | +78 | 106 | 20 | +85 | +43.5 |
| Mine | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 15 | 475 | 103 | +30 | 70 | 31 | +38 | +8.1 |
| Mine | No odds | 9 | 235 | 229 | -2 | 67 | 42 | +25 | +10.7 |
| Mine | All fights | 101 | 265 | 179 | +29 | 106 | 62 | +44 | +16.7 |
| Opponent | Long shot (under 50%) | 18 | 215 | 260 | -93 | 70 | 164 | -94 | -43.6 |
| Opponent | 50-54% | 4 | 349 | 305 | +0 | 102 | 0 | +102 | +29.3 |
| Opponent | Effective (55-75%) | 21 | 358 | 278 | +2 | 105 | 117 | -12 | -3.2 |
| Opponent | 76-89% | 27 | 331 | 221 | +65 | 144 | 59 | +85 | +25.7 |
| Opponent | 90%+ not overkill (target 250+ pts or chargers up to 3x) | 42 | 298 | 217 | +108 | 140 | 11 | +129 | +43.2 |
| Opponent | Overkill (90%+, target under 250 pts, chargers over 3x its points) | 10 | 380 | 69 | +58 | 65 | 0 | +65 | +17.0 |
| Opponent | No odds | 30 | 292 | 181 | +62 | 101 | 47 | +55 | +18.8 |
| Opponent | All fights | 152 | 308 | 217 | +47 | 114 | 58 | +56 | +18.1 |

## Charges set up by the last move (next turn: charged that unit / made contact / charged another / no charge)

| Batch | Source | Set-ups | Charged it | Made contact | Charged another | No charge |
| --- | --- | --- | --- | --- | --- | --- |
| ef2-opp-f5fe7c8-p4 | move | 463 | 118 (25%) | 83 (18%) | 47 (10%) | 298 (64%) |
| ef2-opp-f5fe7c8-p4 | objective | 351 | 56 (16%) | 38 (11%) | 47 (13%) | 248 (71%) |

## Decision items and abilities without guidance

| Item or ability | Side | Match-ups |
| --- | --- | --- |
| Charmed Shield | Mine | L0114, L0130, L2527, L2634 |
| Charmed Shield | Opponent | L0434, L0624, L0926, L1034, L1126, L1427, L2227, L2527, L2634, L3234 |
| Clockwork Compass | Mine | L1220 |
| Elixir of Power | Mine | L1126 |
| Elixir of Power | Opponent | L0819, L1719, L1819 |
| Fistful of Laurels | Mine | L1819, L1835 |
| Invocation of Nehek | Mine | L2527 |
| Invocation of Nehek | Opponent | L0624, L1427, L2227, L2527 |
| Opal Amulet | Mine | L1427 |
| Opal Amulet | Opponent | L0114, L0214, L1314 |
| Periapt of Soul Exchange | Mine | L2021, L2123 |
| Periapt of Soul Exchange | Opponent | L0520, L1220, L1621, L2021 |
| Ring of Doom | Mine | L0214, L0230, L1126, L1220, L1523 |
| Ring of Doom | Opponent | L0315, L1331, L2331 |
| Ring of Jet | Mine | L1017, L1034, L1126, L1220 |
| Standard of the Fell Warrior | Mine | L1314, L1331 |
| Standard of the Fell Warrior | Opponent | L0713 |
| Storm Daemon (Renegade 2.0) | Mine | L2123 |
| Storm Daemon (Renegade 2.0) | Opponent | L1621, L2021 |
| Twice-Blessed Armour | Mine | L0713, L0729, L1017, L1034 |
| Witch Hunter's Ward | Mine | L0713, L0729, L0819, L0835 |
| Witch Hunter's Ward | Opponent | L0608 |
